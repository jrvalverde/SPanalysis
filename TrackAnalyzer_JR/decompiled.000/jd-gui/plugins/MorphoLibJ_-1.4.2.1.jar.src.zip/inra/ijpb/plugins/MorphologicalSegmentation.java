/*      */ package inra.ijpb.plugins;
/*      */ import ij.IJ;
/*      */ import ij.ImagePlus;
/*      */ import ij.ImageStack;
/*      */ import ij.WindowManager;
/*      */ import ij.gui.ImageCanvas;
/*      */ import ij.gui.ImageRoi;
/*      */ import ij.gui.ImageWindow;
/*      */ import ij.gui.Roi;
/*      */ import ij.process.ImageProcessor;
/*      */ import inra.ijpb.binary.BinaryImages;
/*      */ import inra.ijpb.morphology.MinimaAndMaxima3D;
/*      */ import inra.ijpb.morphology.Morphology;
/*      */ import inra.ijpb.morphology.Strel;
/*      */ import inra.ijpb.morphology.Strel3D;
/*      */ import inra.ijpb.util.ColorMaps;
/*      */ import java.awt.Color;
/*      */ import java.awt.GridBagConstraints;
/*      */ import java.awt.GridBagLayout;
/*      */ import java.awt.Insets;
/*      */ import java.awt.event.ActionEvent;
/*      */ import java.awt.event.AdjustmentEvent;
/*      */ import java.awt.event.KeyEvent;
/*      */ import java.awt.event.KeyListener;
/*      */ import java.awt.image.ColorModel;
/*      */ import javax.swing.BorderFactory;
/*      */ import javax.swing.ImageIcon;
/*      */ import javax.swing.JButton;
/*      */ import javax.swing.JCheckBox;
/*      */ import javax.swing.JComboBox;
/*      */ import javax.swing.JLabel;
/*      */ import javax.swing.JPanel;
/*      */ import javax.swing.JRadioButton;
/*      */ import javax.swing.JTextField;
/*      */ 
/*      */ public class MorphologicalSegmentation implements PlugIn {
/*      */   private CustomWindow win;
/*      */   ImagePlus inputImage;
/*      */   ImageStack inputStackCopy;
/*      */   ImagePlus displayImage;
/*      */   ImageStack gradientStack;
/*      */   ImagePlus resultImage;
/*      */   JPanel paramsPanel;
/*      */   Panel all;
/*      */   boolean inputIs2D;
/*      */   JPanel inputImagePanel;
/*      */   ButtonGroup inputImageButtons;
/*      */   JRadioButton borderButton;
/*      */   JRadioButton objectButton;
/*      */   static String borderImageText = "Border Image";
/*      */   static String objectImageText = "Object Image";
/*      */   JPanel radioPanel;
/*      */   ImageIcon borderIcon;
/*      */   ImageIcon objectIcon;
/*      */   JLabel inputImagePicture;
/*      */   JPanel buttonsAndPicPanel;
/*      */   JPanel gradientOptionsPanel;
/*      */   JPanel gradientTypePanel;
/*      */   JLabel gradientTypeLabel;
/*      */   String[] gradientOptions;
/*      */   JComboBox<String> gradientList;
/*      */   JPanel gradientSizePanel;
/*      */   JLabel gradientRadiusSizeLabel;
/*      */   JTextField gradientRadiusSizeText;
/*      */   int gradientRadius;
/*      */   boolean showGradient;
/*      */   JCheckBox gradientCheckBox;
/*      */   JPanel showGradientPanel;
/*      */   private boolean applyGradient;
/*      */   JPanel segmentationPanel;
/*      */   JPanel dynamicPanel;
/*      */   JLabel dynamicLabel;
/*      */   JTextField dynamicText;
/*      */   JPanel advancedOptionsPanel;
/*      */   JCheckBox advancedOptionsCheckBox;
/*      */   private boolean selectAdvancedOptions;
/*      */   JPanel damsPanel;
/*      */   JCheckBox damsCheckBox;
/*      */   private boolean calculateDams;
/*      */   JPanel connectivityPanel;
/*      */   JLabel connectivityLabel;
/*      */   String[] connectivityOptions;
/*      */   JComboBox<String> connectivityList;
/*      */   JButton segmentButton;
/*      */   JPanel displayPanel;
/*      */   JLabel displayLabel;
/*      */   static String overlaidBasinsText = "Overlaid basins";
/*      */   static String overlaidDamsText = "Overlaid dams";
/*      */   static String catchmentBasinsText = "Catchment basins";
/*      */   static String watershedLinesText = "Watershed lines";
/*      */   String[] resultDisplayOption;
/*      */   JComboBox<String> resultDisplayList;
/*      */   JPanel resultDisplayPanel;
/*      */   JCheckBox toggleOverlayCheckBox;
/*      */   JPanel overlayPanel;
/*      */   JButton resultButton;
/*      */   private boolean showColorOverlay;
/*      */   final ExecutorService exec;
/*      */   JPanel postProcessPanel;
/*      */   JButton mergeButton;
/*      */   JButton shuffleColorsButton;
/*      */   
/*      */   public MorphologicalSegmentation() {
/*  104 */     this.inputImage = null;
/*      */     
/*  106 */     this.inputStackCopy = null;
/*      */ 
/*      */     
/*  109 */     this.displayImage = null;
/*      */ 
/*      */     
/*  112 */     this.gradientStack = null;
/*      */ 
/*      */     
/*  115 */     this.resultImage = null;
/*      */ 
/*      */     
/*  118 */     this.paramsPanel = new JPanel();
/*      */ 
/*      */     
/*  121 */     this.all = new Panel();
/*      */ 
/*      */     
/*  124 */     this.inputIs2D = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  140 */     this.inputImagePanel = new JPanel();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  152 */     this.radioPanel = new JPanel(new GridLayout(0, 1));
/*      */     
/*  154 */     this.borderIcon = new ImageIcon(MorphologicalSegmentation.class.getResource("/gradient-icon.png"));
/*  155 */     this.objectIcon = new ImageIcon(MorphologicalSegmentation.class.getResource("/blobs-icon.png"));
/*      */     
/*  157 */     this.buttonsAndPicPanel = new JPanel();
/*      */ 
/*      */     
/*  160 */     this.gradientOptionsPanel = new JPanel();
/*      */     
/*  162 */     this.gradientTypePanel = new JPanel();
/*      */ 
/*      */ 
/*      */     
/*  166 */     this.gradientOptions = new String[] { "Morphological", "Internal", "External" };
/*      */ 
/*      */ 
/*      */     
/*  170 */     this.gradientSizePanel = new JPanel();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  176 */     this.gradientRadius = 1;
/*      */     
/*  178 */     this.showGradient = false;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  183 */     this.showGradientPanel = new JPanel();
/*      */     
/*  185 */     this.applyGradient = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  202 */     this.segmentationPanel = new JPanel();
/*      */ 
/*      */     
/*  205 */     this.dynamicPanel = new JPanel();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  212 */     this.advancedOptionsPanel = new JPanel();
/*      */ 
/*      */ 
/*      */     
/*  216 */     this.selectAdvancedOptions = false;
/*      */ 
/*      */     
/*  219 */     this.damsPanel = new JPanel();
/*      */ 
/*      */ 
/*      */     
/*  223 */     this.calculateDams = true;
/*      */ 
/*      */     
/*  226 */     this.connectivityPanel = new JPanel();
/*      */ 
/*      */ 
/*      */     
/*  230 */     this.connectivityOptions = new String[] { "6", "26" };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  248 */     this.displayPanel = new JPanel();
/*      */ 
/*      */     
/*  251 */     this.displayLabel = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  263 */     this
/*  264 */       .resultDisplayOption = new String[] { overlaidBasinsText, overlaidDamsText, catchmentBasinsText, watershedLinesText };
/*      */     
/*  266 */     this.resultDisplayList = null;
/*      */     
/*  268 */     this.resultDisplayPanel = new JPanel();
/*      */ 
/*      */     
/*  271 */     this.toggleOverlayCheckBox = null;
/*      */     
/*  273 */     this.overlayPanel = new JPanel();
/*      */ 
/*      */     
/*  276 */     this.resultButton = null;
/*      */ 
/*      */     
/*  279 */     this.showColorOverlay = false;
/*      */ 
/*      */     
/*  282 */     this.exec = Executors.newFixedThreadPool(1);
/*      */ 
/*      */     
/*  285 */     this.postProcessPanel = new JPanel();
/*      */     
/*  287 */     this.mergeButton = null;
/*      */     
/*  289 */     this.shuffleColorsButton = null;
/*      */ 
/*      */     
/*  292 */     this.segmentationThread = null;
/*      */ 
/*      */     
/*  295 */     this.segmentText = "Run";
/*      */     
/*  297 */     this.segmentTip = "Run the morphological segmentation";
/*      */     
/*  299 */     this.stopText = "STOP";
/*      */     
/*  301 */     this.stopTip = "Click to abort segmentation";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  342 */     this.opacity = 0.3333333333333333D;
/*      */   }
/*      */   private Thread segmentationThread; private String segmentText; private String segmentTip; private String stopText; private String stopTip;
/*      */   public enum ResultMode {
/*      */     OVERLAID_BASINS, OVERLAID_DAMS, BASINS, LINES; } public static String RUN_SEGMENTATION = "segment"; public static String SHOW_RESULT_OVERLAY = "toggleOverlay";
/*      */   public static String CREATE_IMAGE = "createResultImage";
/*      */   public static String SET_INPUT_TYPE = "setInputImageType";
/*      */   public static String SHOW_GRADIENT = "setShowGradient";
/*      */   public static String SET_DISPLAY = "setDisplayFormat";
/*      */   public static String SET_RADIUS = "setGradientRadius";
/*      */   public static String SET_GRADIENT_TYPE = "setGradientType";
/*      */   public static String MERGE_LABELS = "mergeLabels";
/*      */   public static String SHUFFLE_COLORS = "shuffleColors";
/*      */   double opacity;
/*      */   
/*  357 */   private class CustomWindow extends StackWindow { private ActionListener listener = new ActionListener()
/*      */       {
/*      */ 
/*      */         
/*      */         public void actionPerformed(final ActionEvent e)
/*      */         {
/*  363 */           final String command = e.getActionCommand();
/*      */ 
/*      */ 
/*      */           
/*  367 */           (MorphologicalSegmentation.CustomWindow.access$3(MorphologicalSegmentation.CustomWindow.this)).exec.submit(new Runnable()
/*      */               {
/*      */                 
/*      */                 public void run()
/*      */                 {
/*  372 */                   if (e.getSource() == (MorphologicalSegmentation.CustomWindow.access$3(MorphologicalSegmentation.CustomWindow.null.access$0(MorphologicalSegmentation.CustomWindow.null.this))).segmentButton) {
/*      */                     
/*  374 */                     MorphologicalSegmentation.CustomWindow.null.access$0(MorphologicalSegmentation.CustomWindow.null.this).runSegmentation(command);
/*      */                   
/*      */                   }
/*  377 */                   else if (e.getSource() == (MorphologicalSegmentation.CustomWindow.access$3(MorphologicalSegmentation.CustomWindow.null.access$0(MorphologicalSegmentation.CustomWindow.null.this))).toggleOverlayCheckBox) {
/*      */                     
/*  379 */                     MorphologicalSegmentation.CustomWindow.null.access$0(MorphologicalSegmentation.CustomWindow.null.this).toggleOverlay();
/*      */                     
/*  381 */                     String[] arg = new String[0];
/*  382 */                     MorphologicalSegmentation.record(MorphologicalSegmentation.SHOW_RESULT_OVERLAY, arg);
/*      */                   
/*      */                   }
/*  385 */                   else if (e.getSource() == (MorphologicalSegmentation.CustomWindow.access$3(MorphologicalSegmentation.CustomWindow.null.access$0(MorphologicalSegmentation.CustomWindow.null.this))).resultButton) {
/*      */                     
/*  387 */                     MorphologicalSegmentation.CustomWindow.null.access$0(MorphologicalSegmentation.CustomWindow.null.this).createResultImage();
/*      */                   
/*      */                   }
/*  390 */                   else if (e.getSource() == (MorphologicalSegmentation.CustomWindow.access$3(MorphologicalSegmentation.CustomWindow.null.access$0(MorphologicalSegmentation.CustomWindow.null.this))).advancedOptionsCheckBox) {
/*      */                     
/*  392 */                     (MorphologicalSegmentation.CustomWindow.access$3(MorphologicalSegmentation.CustomWindow.null.access$0(MorphologicalSegmentation.CustomWindow.null.this))).selectAdvancedOptions = !(MorphologicalSegmentation.CustomWindow.access$3(MorphologicalSegmentation.CustomWindow.null.access$0(MorphologicalSegmentation.CustomWindow.null.this))).selectAdvancedOptions;
/*  393 */                     MorphologicalSegmentation.CustomWindow.access$3(MorphologicalSegmentation.CustomWindow.null.access$0(MorphologicalSegmentation.CustomWindow.null.this)).enableAdvancedOptions((MorphologicalSegmentation.CustomWindow.access$3(MorphologicalSegmentation.CustomWindow.null.access$0(MorphologicalSegmentation.CustomWindow.null.this))).selectAdvancedOptions);
/*      */                   
/*      */                   }
/*  396 */                   else if (e.getSource() == (MorphologicalSegmentation.CustomWindow.access$3(MorphologicalSegmentation.CustomWindow.null.access$0(MorphologicalSegmentation.CustomWindow.null.this))).gradientCheckBox) {
/*      */                     
/*  398 */                     MorphologicalSegmentation.CustomWindow.null.access$0(MorphologicalSegmentation.CustomWindow.null.this).setShowGradient(!(MorphologicalSegmentation.CustomWindow.access$3(MorphologicalSegmentation.CustomWindow.null.access$0(MorphologicalSegmentation.CustomWindow.null.this))).showGradient);
/*      */                     
/*  400 */                     String[] arg = { String.valueOf((MorphologicalSegmentation.CustomWindow.access$3(MorphologicalSegmentation.CustomWindow.null.access$0(MorphologicalSegmentation.CustomWindow.null.this))).showGradient) };
/*  401 */                     MorphologicalSegmentation.record(MorphologicalSegmentation.SHOW_GRADIENT, arg);
/*      */                   
/*      */                   }
/*  404 */                   else if (e.getSource() == (MorphologicalSegmentation.CustomWindow.access$3(MorphologicalSegmentation.CustomWindow.null.access$0(MorphologicalSegmentation.CustomWindow.null.this))).resultDisplayList) {
/*      */                     
/*  406 */                     if ((MorphologicalSegmentation.CustomWindow.access$3(MorphologicalSegmentation.CustomWindow.null.access$0(MorphologicalSegmentation.CustomWindow.null.this))).showColorOverlay) {
/*  407 */                       MorphologicalSegmentation.CustomWindow.null.access$0(MorphologicalSegmentation.CustomWindow.null.this).updateResultOverlay();
/*      */                     }
/*  409 */                     String[] arg = { (String)(MorphologicalSegmentation.CustomWindow.access$3(MorphologicalSegmentation.CustomWindow.null.access$0(MorphologicalSegmentation.CustomWindow.null.this))).resultDisplayList.getSelectedItem() };
/*  410 */                     MorphologicalSegmentation.record(MorphologicalSegmentation.SET_DISPLAY, arg);
/*      */                   
/*      */                   }
/*  413 */                   else if (command == MorphologicalSegmentation.objectImageText || command == MorphologicalSegmentation.borderImageText) {
/*      */                     
/*  415 */                     MorphologicalSegmentation.CustomWindow.null.access$0(MorphologicalSegmentation.CustomWindow.null.this).setInputImageType(command);
/*      */                     
/*  417 */                     if (command == MorphologicalSegmentation.objectImageText) {
/*  418 */                       (MorphologicalSegmentation.CustomWindow.access$3(MorphologicalSegmentation.CustomWindow.null.access$0(MorphologicalSegmentation.CustomWindow.null.this))).inputImagePicture.setIcon((MorphologicalSegmentation.CustomWindow.access$3(MorphologicalSegmentation.CustomWindow.null.access$0(MorphologicalSegmentation.CustomWindow.null.this))).objectIcon);
/*      */                     } else {
/*  420 */                       (MorphologicalSegmentation.CustomWindow.access$3(MorphologicalSegmentation.CustomWindow.null.access$0(MorphologicalSegmentation.CustomWindow.null.this))).inputImagePicture.setIcon((MorphologicalSegmentation.CustomWindow.access$3(MorphologicalSegmentation.CustomWindow.null.access$0(MorphologicalSegmentation.CustomWindow.null.this))).borderIcon);
/*      */                     } 
/*  422 */                     String type = (command == MorphologicalSegmentation.objectImageText) ? "object" : "border";
/*      */                     
/*  424 */                     String[] arg = { type };
/*  425 */                     MorphologicalSegmentation.record(MorphologicalSegmentation.SET_INPUT_TYPE, arg);
/*      */                   }
/*  427 */                   else if (e.getSource() == (MorphologicalSegmentation.CustomWindow.access$3(MorphologicalSegmentation.CustomWindow.null.access$0(MorphologicalSegmentation.CustomWindow.null.this))).mergeButton) {
/*      */                     
/*  429 */                     MorphologicalSegmentation.CustomWindow.access$3(MorphologicalSegmentation.CustomWindow.null.access$0(MorphologicalSegmentation.CustomWindow.null.this)).setParamsEnabled(false);
/*  430 */                     MorphologicalSegmentation.CustomWindow.null.access$0(MorphologicalSegmentation.CustomWindow.null.this).mergeLabels();
/*  431 */                     MorphologicalSegmentation.CustomWindow.access$3(MorphologicalSegmentation.CustomWindow.null.access$0(MorphologicalSegmentation.CustomWindow.null.this)).setParamsEnabled(true);
/*      */                   }
/*  433 */                   else if (e.getSource() == (MorphologicalSegmentation.CustomWindow.access$3(MorphologicalSegmentation.CustomWindow.null.access$0(MorphologicalSegmentation.CustomWindow.null.this))).shuffleColorsButton) {
/*      */                     
/*  435 */                     MorphologicalSegmentation.CustomWindow.null.access$0(MorphologicalSegmentation.CustomWindow.null.this).shuffleColors();
/*      */                   } 
/*      */                 }
/*      */               });
/*      */         }
/*      */       };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private static final long serialVersionUID = -6201855439028581892L;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     CustomWindow(ImagePlus imp) {
/*  454 */       super(imp, new ImageCanvas(imp));
/*      */       
/*  456 */       ImageCanvas canvas = getCanvas();
/*      */       
/*  458 */       Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
/*  459 */       double screenWidth = screenSize.getWidth();
/*  460 */       double screenHeight = screenSize.getHeight();
/*      */ 
/*      */       
/*  463 */       while ((this.ic.getWidth() < screenWidth / 2.0D || 
/*  464 */         this.ic.getHeight() < screenHeight / 2.0D) && 
/*  465 */         this.ic.getMagnification() < 32.0D) {
/*      */         
/*  467 */         int canvasWidth = this.ic.getWidth();
/*  468 */         this.ic.zoomIn(0, 0);
/*      */         
/*  470 */         if (canvasWidth == this.ic.getWidth()) {
/*      */           
/*  472 */           this.ic.zoomOut(0, 0);
/*      */           
/*      */           break;
/*      */         } 
/*      */       } 
/*  477 */       while ((this.ic.getWidth() > 0.75D * screenWidth || 
/*  478 */         this.ic.getHeight() > 0.75D * screenHeight) && 
/*  479 */         this.ic.getMagnification() > 0.013888888888888888D) {
/*      */         
/*  481 */         int canvasWidth = this.ic.getWidth();
/*  482 */         this.ic.zoomOut(0, 0);
/*      */         
/*  484 */         if (canvasWidth == this.ic.getWidth()) {
/*      */           
/*  486 */           this.ic.zoomIn(0, 0);
/*      */           
/*      */           break;
/*      */         } 
/*      */       } 
/*  491 */       setTitle("Morphological Segmentation");
/*      */ 
/*      */       
/*  494 */       Toolbar.getInstance().setTool(7);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  499 */       MorphologicalSegmentation.this.borderButton = new JRadioButton(MorphologicalSegmentation.borderImageText);
/*  500 */       MorphologicalSegmentation.this.borderButton.setSelected(!MorphologicalSegmentation.this.applyGradient);
/*  501 */       MorphologicalSegmentation.this.borderButton.setActionCommand(MorphologicalSegmentation.borderImageText);
/*  502 */       MorphologicalSegmentation.this.borderButton.addActionListener(this.listener);
/*  503 */       MorphologicalSegmentation.this.borderButton.setToolTipText("input image has object borders already highlighted");
/*      */       
/*  505 */       MorphologicalSegmentation.this.inputImagePicture = new JLabel(MorphologicalSegmentation.this.borderIcon);
/*  506 */       MorphologicalSegmentation.this.inputImagePicture.setToolTipText("simplified model of your image");
/*      */       
/*  508 */       MorphologicalSegmentation.this.objectButton = new JRadioButton(MorphologicalSegmentation.objectImageText);
/*  509 */       MorphologicalSegmentation.this.objectButton.setActionCommand(MorphologicalSegmentation.objectImageText);
/*  510 */       MorphologicalSegmentation.this.objectButton.addActionListener(this.listener);
/*  511 */       MorphologicalSegmentation.this.objectButton.setToolTipText("input image has highlighted objects (dark or bright)");
/*      */       
/*  513 */       MorphologicalSegmentation.this.inputImageButtons = new ButtonGroup();
/*  514 */       MorphologicalSegmentation.this.inputImageButtons.add(MorphologicalSegmentation.this.borderButton);
/*  515 */       MorphologicalSegmentation.this.inputImageButtons.add(MorphologicalSegmentation.this.objectButton);
/*  516 */       MorphologicalSegmentation.this.radioPanel.add(MorphologicalSegmentation.this.borderButton);
/*  517 */       MorphologicalSegmentation.this.radioPanel.add(MorphologicalSegmentation.this.objectButton);
/*      */       
/*  519 */       MorphologicalSegmentation.this.buttonsAndPicPanel.add(MorphologicalSegmentation.this.radioPanel);
/*  520 */       MorphologicalSegmentation.this.buttonsAndPicPanel.add(MorphologicalSegmentation.this.inputImagePicture);
/*      */ 
/*      */       
/*  523 */       MorphologicalSegmentation.this.gradientTypeLabel = new JLabel("Gradient type ");
/*  524 */       MorphologicalSegmentation.this.gradientTypeLabel.setToolTipText("type of gradient filter to apply");
/*  525 */       MorphologicalSegmentation.this.gradientList = new JComboBox<String>(MorphologicalSegmentation.this.gradientOptions);
/*  526 */       MorphologicalSegmentation.this.gradientTypePanel.add(MorphologicalSegmentation.this.gradientTypeLabel);
/*  527 */       MorphologicalSegmentation.this.gradientTypePanel.add(MorphologicalSegmentation.this.gradientList);
/*  528 */       MorphologicalSegmentation.this.gradientTypePanel.setToolTipText("type of gradient filter to apply");
/*      */       
/*  530 */       MorphologicalSegmentation.this.gradientRadiusSizeLabel = new JLabel("Gradient radius");
/*  531 */       MorphologicalSegmentation.this.gradientRadiusSizeLabel.setToolTipText("radius in pixels of the gradient filter");
/*  532 */       MorphologicalSegmentation.this.gradientRadiusSizeText = new JTextField(String.valueOf(MorphologicalSegmentation.this.gradientRadius), 5);
/*  533 */       MorphologicalSegmentation.this.gradientRadiusSizeText.setToolTipText("radius in pixels of the gradient filter");
/*  534 */       MorphologicalSegmentation.this.gradientSizePanel.add(MorphologicalSegmentation.this.gradientRadiusSizeLabel);
/*  535 */       MorphologicalSegmentation.this.gradientSizePanel.add(MorphologicalSegmentation.this.gradientRadiusSizeText);
/*      */       
/*  537 */       MorphologicalSegmentation.this.gradientCheckBox = new JCheckBox("Show gradient", false);
/*  538 */       MorphologicalSegmentation.this.gradientCheckBox.setToolTipText("display gradient image instead of input image");
/*  539 */       MorphologicalSegmentation.this.gradientCheckBox.addActionListener(this.listener);
/*  540 */       MorphologicalSegmentation.this.showGradientPanel.add(MorphologicalSegmentation.this.gradientCheckBox);
/*      */       
/*  542 */       GridBagLayout gradientOptionsLayout = new GridBagLayout();
/*  543 */       GridBagConstraints gradientOptionsConstraints = new GridBagConstraints();
/*  544 */       gradientOptionsConstraints.anchor = 17;
/*  545 */       gradientOptionsConstraints.gridwidth = 1;
/*  546 */       gradientOptionsConstraints.gridheight = 1;
/*  547 */       gradientOptionsConstraints.gridx = 0;
/*  548 */       gradientOptionsConstraints.gridy = 0;
/*  549 */       MorphologicalSegmentation.this.gradientOptionsPanel.setLayout(gradientOptionsLayout);
/*      */       
/*  551 */       MorphologicalSegmentation.this.gradientOptionsPanel.add(MorphologicalSegmentation.this.gradientTypePanel, gradientOptionsConstraints);
/*  552 */       gradientOptionsConstraints.gridy++;
/*  553 */       MorphologicalSegmentation.this.gradientOptionsPanel.add(MorphologicalSegmentation.this.gradientSizePanel, gradientOptionsConstraints);
/*  554 */       gradientOptionsConstraints.gridy++;
/*  555 */       MorphologicalSegmentation.this.gradientOptionsPanel.add(MorphologicalSegmentation.this.showGradientPanel, gradientOptionsConstraints);
/*  556 */       gradientOptionsConstraints.gridy++;
/*      */       
/*  558 */       MorphologicalSegmentation.this.gradientOptionsPanel.setBorder(BorderFactory.createTitledBorder(""));
/*      */       
/*  560 */       MorphologicalSegmentation.this.enableGradientOptions(MorphologicalSegmentation.this.applyGradient);
/*      */ 
/*      */       
/*  563 */       MorphologicalSegmentation.this.inputImagePanel.setBorder(BorderFactory.createTitledBorder("Input Image"));
/*  564 */       GridBagLayout inputImageLayout = new GridBagLayout();
/*  565 */       GridBagConstraints inputImageConstraints = new GridBagConstraints();
/*  566 */       inputImageConstraints.anchor = 10;
/*  567 */       inputImageConstraints.fill = 0;
/*  568 */       inputImageConstraints.gridwidth = 1;
/*  569 */       inputImageConstraints.gridheight = 1;
/*  570 */       inputImageConstraints.gridx = 0;
/*  571 */       inputImageConstraints.gridy = 0;
/*  572 */       inputImageConstraints.insets = new Insets(5, 5, 6, 6);
/*  573 */       MorphologicalSegmentation.this.inputImagePanel.setLayout(inputImageLayout);
/*      */       
/*  575 */       MorphologicalSegmentation.this.inputImagePanel.add(MorphologicalSegmentation.this.buttonsAndPicPanel, inputImageConstraints);
/*  576 */       inputImageConstraints.gridy++;
/*  577 */       inputImageConstraints.anchor = 18;
/*  578 */       inputImageConstraints.fill = 2;
/*  579 */       MorphologicalSegmentation.this.inputImagePanel.add(MorphologicalSegmentation.this.gradientOptionsPanel, inputImageConstraints);
/*  580 */       inputImageConstraints.gridy++;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  586 */       MorphologicalSegmentation.this.dynamicLabel = new JLabel("Tolerance");
/*  587 */       MorphologicalSegmentation.this.dynamicLabel.setToolTipText("Tolerance in the search of local minima");
/*  588 */       MorphologicalSegmentation.this.dynamicText = new JTextField("10", 5);
/*  589 */       MorphologicalSegmentation.this.dynamicText.setToolTipText("Tolerance in the search of local minima");
/*  590 */       MorphologicalSegmentation.this.dynamicPanel.add(MorphologicalSegmentation.this.dynamicLabel);
/*  591 */       MorphologicalSegmentation.this.dynamicPanel.add(MorphologicalSegmentation.this.dynamicText);
/*  592 */       MorphologicalSegmentation.this.dynamicPanel.setToolTipText("Tolerance in the search of local minima");
/*      */ 
/*      */       
/*  595 */       MorphologicalSegmentation.this.advancedOptionsCheckBox = new JCheckBox("Advanced options", MorphologicalSegmentation.this.selectAdvancedOptions);
/*  596 */       MorphologicalSegmentation.this.advancedOptionsCheckBox.setToolTipText("Enable advanced options");
/*  597 */       MorphologicalSegmentation.this.advancedOptionsCheckBox.addActionListener(this.listener);
/*      */ 
/*      */       
/*  600 */       MorphologicalSegmentation.this.damsCheckBox = new JCheckBox("Calculate dams", MorphologicalSegmentation.this.calculateDams);
/*  601 */       MorphologicalSegmentation.this.damsCheckBox.setToolTipText("Calculate watershed dams");
/*  602 */       MorphologicalSegmentation.this.damsPanel.add(MorphologicalSegmentation.this.damsCheckBox);
/*      */ 
/*      */       
/*  605 */       if (MorphologicalSegmentation.this.inputIs2D)
/*  606 */         MorphologicalSegmentation.this.connectivityOptions = new String[] { "4", "8" }; 
/*  607 */       MorphologicalSegmentation.this.connectivityList = new JComboBox<String>(MorphologicalSegmentation.this.connectivityOptions);
/*  608 */       MorphologicalSegmentation.this.connectivityList.setToolTipText("Voxel connectivity to use");
/*  609 */       MorphologicalSegmentation.this.connectivityLabel = new JLabel("Connectivity");
/*  610 */       MorphologicalSegmentation.this.connectivityPanel.add(MorphologicalSegmentation.this.connectivityLabel);
/*  611 */       MorphologicalSegmentation.this.connectivityPanel.add(MorphologicalSegmentation.this.connectivityList);
/*  612 */       MorphologicalSegmentation.this.connectivityPanel.setToolTipText("Voxel connectivity to use");
/*      */       
/*  614 */       MorphologicalSegmentation.this.enableAdvancedOptions(MorphologicalSegmentation.this.selectAdvancedOptions);
/*      */ 
/*      */       
/*  617 */       GridBagLayout advancedOptionsLayout = new GridBagLayout();
/*  618 */       GridBagConstraints advancedOptoinsConstraints = new GridBagConstraints();
/*  619 */       advancedOptoinsConstraints.anchor = 17;
/*  620 */       advancedOptoinsConstraints.gridwidth = 1;
/*  621 */       advancedOptoinsConstraints.gridheight = 1;
/*  622 */       advancedOptoinsConstraints.gridx = 0;
/*  623 */       advancedOptoinsConstraints.gridy = 0;
/*  624 */       MorphologicalSegmentation.this.advancedOptionsPanel.setLayout(advancedOptionsLayout);
/*      */       
/*  626 */       MorphologicalSegmentation.this.advancedOptionsPanel.add(MorphologicalSegmentation.this.damsPanel, advancedOptoinsConstraints);
/*  627 */       advancedOptoinsConstraints.gridy++;
/*  628 */       MorphologicalSegmentation.this.advancedOptionsPanel.add(MorphologicalSegmentation.this.connectivityPanel, advancedOptoinsConstraints);
/*      */       
/*  630 */       MorphologicalSegmentation.this.advancedOptionsPanel.setBorder(BorderFactory.createTitledBorder(""));
/*      */ 
/*      */       
/*  633 */       MorphologicalSegmentation.this.segmentButton = new JButton(MorphologicalSegmentation.this.segmentText);
/*  634 */       MorphologicalSegmentation.this.segmentButton.setToolTipText(MorphologicalSegmentation.this.segmentTip);
/*  635 */       MorphologicalSegmentation.this.segmentButton.addActionListener(this.listener);
/*      */ 
/*      */       
/*  638 */       MorphologicalSegmentation.this.segmentationPanel.setBorder(BorderFactory.createTitledBorder("Watershed Segmentation"));
/*  639 */       GridBagLayout segmentationLayout = new GridBagLayout();
/*  640 */       GridBagConstraints segmentationConstraints = new GridBagConstraints();
/*  641 */       segmentationConstraints.anchor = 18;
/*  642 */       segmentationConstraints.fill = 2;
/*  643 */       segmentationConstraints.gridwidth = 1;
/*  644 */       segmentationConstraints.gridheight = 1;
/*  645 */       segmentationConstraints.gridx = 0;
/*  646 */       segmentationConstraints.gridy = 0;
/*  647 */       segmentationConstraints.insets = new Insets(5, 5, 6, 6);
/*  648 */       MorphologicalSegmentation.this.segmentationPanel.setLayout(segmentationLayout);
/*      */       
/*  650 */       MorphologicalSegmentation.this.segmentationPanel.add(MorphologicalSegmentation.this.dynamicPanel, segmentationConstraints);
/*  651 */       segmentationConstraints.gridy++;
/*  652 */       MorphologicalSegmentation.this.segmentationPanel.add(MorphologicalSegmentation.this.advancedOptionsCheckBox, segmentationConstraints);
/*  653 */       segmentationConstraints.gridy++;
/*  654 */       MorphologicalSegmentation.this.segmentationPanel.add(MorphologicalSegmentation.this.advancedOptionsPanel, segmentationConstraints);
/*  655 */       segmentationConstraints.gridy++;
/*  656 */       segmentationConstraints.anchor = 10;
/*  657 */       segmentationConstraints.fill = 0;
/*  658 */       MorphologicalSegmentation.this.segmentationPanel.add(MorphologicalSegmentation.this.segmentButton, segmentationConstraints);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  663 */       MorphologicalSegmentation.this.displayLabel = new JLabel("Display");
/*  664 */       MorphologicalSegmentation.this.displayLabel.setEnabled(false);
/*  665 */       MorphologicalSegmentation.this.resultDisplayList = new JComboBox<String>(MorphologicalSegmentation.this.resultDisplayOption);
/*  666 */       MorphologicalSegmentation.this.resultDisplayList.setEnabled(false);
/*  667 */       MorphologicalSegmentation.this.resultDisplayList.setToolTipText("Select how to display segmentation results");
/*  668 */       MorphologicalSegmentation.this.resultDisplayList.addActionListener(this.listener);
/*      */       
/*  670 */       MorphologicalSegmentation.this.resultDisplayPanel.add(MorphologicalSegmentation.this.displayLabel);
/*  671 */       MorphologicalSegmentation.this.resultDisplayPanel.add(MorphologicalSegmentation.this.resultDisplayList);
/*      */ 
/*      */       
/*  674 */       MorphologicalSegmentation.this.showColorOverlay = false;
/*  675 */       MorphologicalSegmentation.this.toggleOverlayCheckBox = new JCheckBox("Show result overlay");
/*  676 */       MorphologicalSegmentation.this.toggleOverlayCheckBox.setEnabled(MorphologicalSegmentation.this.showColorOverlay);
/*  677 */       MorphologicalSegmentation.this.toggleOverlayCheckBox.setToolTipText("Toggle overlay with segmentation result");
/*  678 */       MorphologicalSegmentation.this.toggleOverlayCheckBox.addActionListener(this.listener);
/*  679 */       MorphologicalSegmentation.this.overlayPanel.add(MorphologicalSegmentation.this.toggleOverlayCheckBox);
/*      */ 
/*      */       
/*  682 */       MorphologicalSegmentation.this.resultButton = new JButton("Create Image");
/*  683 */       MorphologicalSegmentation.this.resultButton.setEnabled(false);
/*  684 */       MorphologicalSegmentation.this.resultButton.setToolTipText("Show segmentation result in new window");
/*  685 */       MorphologicalSegmentation.this.resultButton.addActionListener(this.listener);
/*      */ 
/*      */       
/*  688 */       MorphologicalSegmentation.this.displayPanel.setBorder(BorderFactory.createTitledBorder("Results"));
/*  689 */       GridBagLayout displayLayout = new GridBagLayout();
/*  690 */       GridBagConstraints displayConstraints = new GridBagConstraints();
/*  691 */       displayConstraints.anchor = 18;
/*  692 */       displayConstraints.fill = 2;
/*  693 */       displayConstraints.gridwidth = 1;
/*  694 */       displayConstraints.gridheight = 1;
/*  695 */       displayConstraints.gridx = 0;
/*  696 */       displayConstraints.gridy = 0;
/*  697 */       displayConstraints.insets = new Insets(5, 5, 6, 6);
/*  698 */       MorphologicalSegmentation.this.displayPanel.setLayout(displayLayout);
/*      */       
/*  700 */       MorphologicalSegmentation.this.displayPanel.add(MorphologicalSegmentation.this.resultDisplayPanel, displayConstraints);
/*  701 */       displayConstraints.gridy++;
/*  702 */       MorphologicalSegmentation.this.displayPanel.add(MorphologicalSegmentation.this.overlayPanel, displayConstraints);
/*  703 */       displayConstraints.gridy++;
/*  704 */       displayConstraints.anchor = 10;
/*  705 */       displayConstraints.fill = 0;
/*  706 */       MorphologicalSegmentation.this.displayPanel.add(MorphologicalSegmentation.this.resultButton, displayConstraints);
/*      */ 
/*      */       
/*  709 */       MorphologicalSegmentation.this.mergeButton = new JButton("Merge labels");
/*  710 */       MorphologicalSegmentation.this.mergeButton.setEnabled(false);
/*  711 */       MorphologicalSegmentation.this.mergeButton.setToolTipText("Merge labels selected by freehand or point ROI");
/*      */       
/*  713 */       MorphologicalSegmentation.this.mergeButton.addActionListener(this.listener);
/*      */       
/*  715 */       MorphologicalSegmentation.this.shuffleColorsButton = new JButton("Shuffle colors");
/*  716 */       MorphologicalSegmentation.this.shuffleColorsButton.setEnabled(false);
/*  717 */       MorphologicalSegmentation.this.shuffleColorsButton.setToolTipText("Shuffle color labels");
/*  718 */       MorphologicalSegmentation.this.shuffleColorsButton.addActionListener(this.listener);
/*      */       
/*  720 */       GridBagLayout mergingLayout = new GridBagLayout();
/*  721 */       MorphologicalSegmentation.this.postProcessPanel.setLayout(mergingLayout);
/*      */       
/*  723 */       GridBagConstraints ppConstraints = new GridBagConstraints();
/*  724 */       ppConstraints.anchor = 18;
/*  725 */       ppConstraints.fill = 2;
/*  726 */       ppConstraints.gridwidth = 1;
/*  727 */       ppConstraints.gridheight = 1;
/*  728 */       ppConstraints.gridx = 0;
/*  729 */       ppConstraints.gridy = 0;
/*  730 */       ppConstraints.insets = new Insets(5, 5, 6, 6);
/*      */       
/*  732 */       MorphologicalSegmentation.this.postProcessPanel.add(MorphologicalSegmentation.this.mergeButton, ppConstraints);
/*  733 */       ppConstraints.gridy++;
/*  734 */       MorphologicalSegmentation.this.postProcessPanel.add(MorphologicalSegmentation.this.shuffleColorsButton, ppConstraints);
/*  735 */       MorphologicalSegmentation.this.postProcessPanel.setBorder(BorderFactory.createTitledBorder(
/*  736 */             "Post-processing"));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  742 */       GridBagLayout paramsLayout = new GridBagLayout();
/*  743 */       GridBagConstraints paramsConstraints = new GridBagConstraints();
/*  744 */       paramsConstraints.insets = new Insets(5, 5, 6, 6);
/*  745 */       MorphologicalSegmentation.this.paramsPanel.setLayout(paramsLayout);
/*  746 */       paramsConstraints.anchor = 18;
/*  747 */       paramsConstraints.fill = 2;
/*  748 */       paramsConstraints.gridwidth = 1;
/*  749 */       paramsConstraints.gridheight = 1;
/*  750 */       paramsConstraints.gridx = 0;
/*  751 */       paramsConstraints.gridy = 0;
/*  752 */       MorphologicalSegmentation.this.paramsPanel.add(MorphologicalSegmentation.this.inputImagePanel, paramsConstraints);
/*  753 */       paramsConstraints.gridy++;
/*  754 */       MorphologicalSegmentation.this.paramsPanel.add(MorphologicalSegmentation.this.segmentationPanel, paramsConstraints);
/*  755 */       paramsConstraints.gridy++;
/*  756 */       MorphologicalSegmentation.this.paramsPanel.add(MorphologicalSegmentation.this.displayPanel, paramsConstraints);
/*  757 */       paramsConstraints.gridy++;
/*  758 */       MorphologicalSegmentation.this.paramsPanel.add(MorphologicalSegmentation.this.postProcessPanel, paramsConstraints);
/*  759 */       paramsConstraints.gridy++;
/*      */ 
/*      */ 
/*      */       
/*  763 */       GridBagLayout layout = new GridBagLayout();
/*  764 */       GridBagConstraints allConstraints = new GridBagConstraints();
/*  765 */       MorphologicalSegmentation.this.all.setLayout(layout);
/*      */ 
/*      */       
/*  768 */       allConstraints.anchor = 18;
/*  769 */       allConstraints.fill = 1;
/*  770 */       allConstraints.gridwidth = 1;
/*  771 */       allConstraints.gridheight = 1;
/*  772 */       allConstraints.gridx = 0;
/*  773 */       allConstraints.gridy = 0;
/*  774 */       allConstraints.weightx = 0.0D;
/*  775 */       allConstraints.weighty = 0.0D;
/*      */       
/*  777 */       MorphologicalSegmentation.this.all.add(MorphologicalSegmentation.this.paramsPanel, allConstraints);
/*      */ 
/*      */       
/*  780 */       allConstraints.gridx++;
/*  781 */       allConstraints.weightx = 1.0D;
/*  782 */       allConstraints.weighty = 1.0D;
/*  783 */       MorphologicalSegmentation.this.all.add((Component)canvas, allConstraints);
/*      */       
/*  785 */       allConstraints.gridy++;
/*  786 */       allConstraints.weightx = 0.0D;
/*  787 */       allConstraints.weighty = 0.0D;
/*      */ 
/*      */ 
/*      */       
/*  791 */       if (this.sliceSelector != null) {
/*      */         
/*  793 */         this.sliceSelector.setValue(MorphologicalSegmentation.this.inputImage.getCurrentSlice());
/*  794 */         MorphologicalSegmentation.this.displayImage.setSlice(MorphologicalSegmentation.this.inputImage.getCurrentSlice());
/*      */         
/*  796 */         MorphologicalSegmentation.this.all.add(this.sliceSelector, allConstraints);
/*      */         
/*  798 */         if (this.zSelector != null)
/*  799 */           MorphologicalSegmentation.this.all.add((Component)this.zSelector, allConstraints); 
/*  800 */         if (this.tSelector != null)
/*  801 */           MorphologicalSegmentation.this.all.add((Component)this.tSelector, allConstraints); 
/*  802 */         if (this.cSelector != null) {
/*  803 */           MorphologicalSegmentation.this.all.add((Component)this.cSelector, allConstraints);
/*      */         }
/*      */       } 
/*  806 */       allConstraints.gridy--;
/*      */ 
/*      */       
/*  809 */       GridBagLayout wingb = new GridBagLayout();
/*  810 */       GridBagConstraints winc = new GridBagConstraints();
/*  811 */       winc.anchor = 18;
/*  812 */       winc.fill = 1;
/*  813 */       winc.weightx = 1.0D;
/*  814 */       winc.weighty = 1.0D;
/*  815 */       setLayout(wingb);
/*  816 */       add(MorphologicalSegmentation.this.all, winc);
/*      */ 
/*      */       
/*  819 */       pack();
/*  820 */       setMinimumSize(getPreferredSize());
/*      */ 
/*      */       
/*  823 */       if (this.sliceSelector != null) {
/*      */ 
/*      */         
/*  826 */         this.sliceSelector.addAdjustmentListener(new AdjustmentListener()
/*      */             {
/*      */               public void adjustmentValueChanged(final AdjustmentEvent e)
/*      */               {
/*  830 */                 (MorphologicalSegmentation.CustomWindow.access$3(MorphologicalSegmentation.CustomWindow.this)).exec.submit(new Runnable() {
/*      */                       public void run() {
/*  832 */                         if (e.getSource() == (MorphologicalSegmentation.CustomWindow.null.access$0(MorphologicalSegmentation.CustomWindow.null.this)).sliceSelector)
/*      */                         {
/*  834 */                           if ((MorphologicalSegmentation.CustomWindow.access$3(MorphologicalSegmentation.CustomWindow.null.access$0(MorphologicalSegmentation.CustomWindow.null.this))).showColorOverlay) {
/*      */                             
/*  836 */                             MorphologicalSegmentation.CustomWindow.null.access$0(MorphologicalSegmentation.CustomWindow.null.this).updateResultOverlay();
/*  837 */                             (MorphologicalSegmentation.CustomWindow.access$3(MorphologicalSegmentation.CustomWindow.null.access$0(MorphologicalSegmentation.CustomWindow.null.this))).displayImage.updateAndDraw();
/*      */                           } 
/*      */                         }
/*      */                       }
/*      */                     });
/*      */               }
/*      */             });
/*      */ 
/*      */ 
/*      */         
/*  847 */         addMouseWheelListener(new MouseWheelListener()
/*      */             {
/*      */               
/*      */               public void mouseWheelMoved(MouseWheelEvent e)
/*      */               {
/*  852 */                 (MorphologicalSegmentation.CustomWindow.access$3(MorphologicalSegmentation.CustomWindow.this)).exec.submit(new Runnable()
/*      */                     {
/*      */                       public void run() {
/*  855 */                         if ((MorphologicalSegmentation.CustomWindow.access$3(MorphologicalSegmentation.CustomWindow.null.access$0(MorphologicalSegmentation.CustomWindow.null.this))).showColorOverlay) {
/*      */                           
/*  857 */                           MorphologicalSegmentation.CustomWindow.null.access$0(MorphologicalSegmentation.CustomWindow.null.this).updateResultOverlay();
/*  858 */                           (MorphologicalSegmentation.CustomWindow.access$3(MorphologicalSegmentation.CustomWindow.null.access$0(MorphologicalSegmentation.CustomWindow.null.this))).displayImage.updateAndDraw();
/*      */                         } 
/*      */                       }
/*      */                     });
/*      */               }
/*      */             });
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  868 */         KeyListener keyListener = new KeyListener()
/*      */           {
/*      */             public void keyTyped(KeyEvent e) {}
/*      */ 
/*      */ 
/*      */             
/*      */             public void keyReleased(final KeyEvent e) {
/*  875 */               (MorphologicalSegmentation.CustomWindow.access$3(MorphologicalSegmentation.CustomWindow.this)).exec.submit(new Runnable()
/*      */                   {
/*      */                     public void run() {
/*  878 */                       if (e.getKeyCode() == 37 || 
/*  879 */                         e.getKeyCode() == 39 || 
/*  880 */                         e.getKeyCode() == 153 || 
/*  881 */                         e.getKeyCode() == 160 || 
/*  882 */                         e.getKeyCode() == 44 || 
/*  883 */                         e.getKeyCode() == 46)
/*      */                       {
/*  885 */                         if ((MorphologicalSegmentation.CustomWindow.access$3(MorphologicalSegmentation.CustomWindow.null.access$0(MorphologicalSegmentation.CustomWindow.null.this))).showColorOverlay) {
/*      */                           
/*  887 */                           MorphologicalSegmentation.CustomWindow.null.access$0(MorphologicalSegmentation.CustomWindow.null.this).updateResultOverlay();
/*  888 */                           (MorphologicalSegmentation.CustomWindow.access$3(MorphologicalSegmentation.CustomWindow.null.access$0(MorphologicalSegmentation.CustomWindow.null.this))).displayImage.updateAndDraw();
/*      */                         } 
/*      */                       }
/*      */                     }
/*      */                   });
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             public void keyPressed(KeyEvent e) {}
/*      */           };
/*  900 */         addKeyListener(keyListener);
/*  901 */         canvas.addKeyListener(keyListener);
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void windowClosing(WindowEvent e) {
/*  913 */       super.windowClosing(e);
/*      */       
/*  915 */       if (MorphologicalSegmentation.this.inputImage != null) {
/*      */         
/*  917 */         if (MorphologicalSegmentation.this.displayImage != null) {
/*  918 */           MorphologicalSegmentation.this.inputImage.setSlice(MorphologicalSegmentation.this.displayImage.getCurrentSlice());
/*      */         }
/*      */         
/*  921 */         MorphologicalSegmentation.this.inputImage.getWindow().setVisible(true);
/*      */       } 
/*      */ 
/*      */       
/*  925 */       MorphologicalSegmentation.this.borderButton.removeActionListener(this.listener);
/*  926 */       MorphologicalSegmentation.this.objectButton.removeActionListener(this.listener);
/*  927 */       MorphologicalSegmentation.this.gradientCheckBox.removeActionListener(this.listener);
/*  928 */       MorphologicalSegmentation.this.advancedOptionsCheckBox.removeActionListener(this.listener);
/*  929 */       MorphologicalSegmentation.this.segmentButton.removeActionListener(this.listener);
/*  930 */       MorphologicalSegmentation.this.resultDisplayList.removeActionListener(this.listener);
/*  931 */       MorphologicalSegmentation.this.toggleOverlayCheckBox.removeActionListener(this.listener);
/*  932 */       MorphologicalSegmentation.this.resultButton.removeActionListener(this.listener);
/*      */       
/*  934 */       if (MorphologicalSegmentation.this.displayImage != null)
/*      */       {
/*      */         
/*  937 */         MorphologicalSegmentation.this.displayImage = null;
/*      */       }
/*      */       
/*  940 */       MorphologicalSegmentation.this.exec.shutdownNow();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     void setDynamic(double dynamic) {
/*  950 */       MorphologicalSegmentation.this.dynamicText.setText(Double.toString(dynamic));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     void setCalculateDams(boolean b) {
/*  960 */       MorphologicalSegmentation.this.calculateDams = b;
/*  961 */       MorphologicalSegmentation.this.damsCheckBox.setSelected(b);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     void setConnectivity(int connectivity) {
/*  971 */       if ((MorphologicalSegmentation.this.inputImage.getImageStackSize() > 1 && (connectivity == 6 || connectivity == 26)) || (
/*  972 */         MorphologicalSegmentation.this.inputImage.getImageStackSize() == 1 && (connectivity == 4 || connectivity == 8))) {
/*  973 */         MorphologicalSegmentation.this.connectivityList.setSelectedItem(Integer.toString(connectivity));
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     String getSegmentText() {
/*  982 */       return MorphologicalSegmentation.this.segmentText;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private void runSegmentation(String command) {
/*  991 */       if (command.equals(MorphologicalSegmentation.this.segmentText)) {
/*      */         final int connectivity;
/*      */         final double dynamic;
/*  994 */         final int readConn = 
/*  995 */           Integer.parseInt(
/*  996 */             (String)MorphologicalSegmentation.this.connectivityList.getSelectedItem());
/*      */ 
/*      */ 
/*      */         
/* 1000 */         if (MorphologicalSegmentation.this.inputIs2D) {
/* 1001 */           connectivity = (readConn == 4) ? 6 : 26;
/*      */         } else {
/* 1003 */           connectivity = readConn;
/*      */         } 
/*      */ 
/*      */         
/*      */         try {
/* 1008 */           dynamic = Double.parseDouble(MorphologicalSegmentation.this.dynamicText.getText());
/*      */         }
/* 1010 */         catch (NullPointerException ex) {
/*      */           
/* 1012 */           IJ.error("Morphological Segmentation", "ERROR: missing dynamic value");
/*      */           
/*      */           return;
/* 1015 */         } catch (NumberFormatException ex) {
/*      */           
/* 1017 */           IJ.error("Morphological Segmentation", "ERROR: dynamic value must be a number");
/*      */           
/*      */           return;
/*      */         } 
/* 1021 */         double max = 255.0D;
/* 1022 */         int bitDepth = MorphologicalSegmentation.this.inputImage.getBitDepth();
/* 1023 */         if (bitDepth == 16) {
/* 1024 */           max = 65535.0D;
/* 1025 */         } else if (bitDepth == 32) {
/* 1026 */           max = 3.4028234663852886E38D;
/*      */         } 
/* 1028 */         if (dynamic < 0.0D || dynamic > max) {
/*      */           
/* 1030 */           IJ.error("Morphological Segmentation", "ERROR: the dynamic value must be a number between 0 and " + max);
/*      */           
/*      */           return;
/*      */         } 
/*      */         
/* 1035 */         MorphologicalSegmentation.this.segmentButton.setText(MorphologicalSegmentation.this.stopText);
/* 1036 */         MorphologicalSegmentation.this.segmentButton.setToolTipText(MorphologicalSegmentation.this.stopTip);
/* 1037 */         MorphologicalSegmentation.this.segmentButton.setSize(MorphologicalSegmentation.this.segmentButton.getMinimumSize());
/* 1038 */         MorphologicalSegmentation.this.segmentButton.repaint();
/*      */         
/* 1040 */         final Thread oldThread = MorphologicalSegmentation.this.segmentationThread;
/*      */ 
/*      */         
/* 1043 */         Thread newThread = new Thread()
/*      */           {
/*      */             
/*      */             public void run()
/*      */             {
/* 1048 */               if (oldThread != null) {
/*      */                 
/*      */                 try {
/* 1051 */                   IJ.log("Waiting for old task to finish...");
/* 1052 */                   oldThread.join();
/*      */                 }
/* 1054 */                 catch (InterruptedException interruptedException) {}
/*      */               }
/*      */ 
/*      */               
/* 1058 */               (MorphologicalSegmentation.CustomWindow.access$3(MorphologicalSegmentation.CustomWindow.this)).calculateDams = (MorphologicalSegmentation.CustomWindow.access$3(MorphologicalSegmentation.CustomWindow.this)).damsCheckBox.isSelected();
/*      */ 
/*      */               
/* 1061 */               MorphologicalSegmentation.CustomWindow.access$3(MorphologicalSegmentation.CustomWindow.this).setParamsEnabled(false);
/*      */ 
/*      */               
/* 1064 */               ImageStack image = (MorphologicalSegmentation.CustomWindow.access$3(MorphologicalSegmentation.CustomWindow.this)).inputStackCopy;
/*      */               
/* 1066 */               long start = System.currentTimeMillis();
/*      */               
/* 1068 */               if ((MorphologicalSegmentation.CustomWindow.access$3(MorphologicalSegmentation.CustomWindow.this)).applyGradient) {
/*      */ 
/*      */                 
/*      */                 try {
/* 1072 */                   (MorphologicalSegmentation.CustomWindow.access$3(MorphologicalSegmentation.CustomWindow.this)).gradientRadius = Integer.parseInt((MorphologicalSegmentation.CustomWindow.access$3(MorphologicalSegmentation.CustomWindow.this)).gradientRadiusSizeText.getText());
/*      */                 }
/* 1074 */                 catch (NullPointerException ex) {
/*      */                   
/* 1076 */                   IJ.error("Morphological Segmentation", "ERROR: missing gradient radius value");
/*      */                   
/*      */                   return;
/* 1079 */                 } catch (NumberFormatException ex) {
/*      */                   
/* 1081 */                   IJ.error("Morphological Segmentation", "ERROR: radius value must be an integer number");
/*      */                   
/*      */                   return;
/*      */                 } 
/* 1085 */                 long t1 = System.currentTimeMillis();
/* 1086 */                 String extra = "";
/* 1087 */                 if ((MorphologicalSegmentation.CustomWindow.access$3(MorphologicalSegmentation.CustomWindow.this)).gradientList.getSelectedItem().equals("Internal")) {
/* 1088 */                   extra = " internal";
/* 1089 */                 } else if ((MorphologicalSegmentation.CustomWindow.access$3(MorphologicalSegmentation.CustomWindow.this)).gradientList.getSelectedItem().equals("External")) {
/* 1090 */                   extra = " external";
/* 1091 */                 }  IJ.log("Applying morphological" + extra + " gradient to input image...");
/*      */                 
/* 1093 */                 if (image.getSize() > 1) {
/*      */                   
/* 1095 */                   Strel3D strel = Strel3D.Shape.CUBE.fromRadius((MorphologicalSegmentation.CustomWindow.access$3(MorphologicalSegmentation.CustomWindow.this)).gradientRadius);
/* 1096 */                   if ((MorphologicalSegmentation.CustomWindow.access$3(MorphologicalSegmentation.CustomWindow.this)).gradientList.getSelectedItem().equals("Internal")) {
/* 1097 */                     image = Morphology.internalGradient(image, strel);
/* 1098 */                   } else if ((MorphologicalSegmentation.CustomWindow.access$3(MorphologicalSegmentation.CustomWindow.this)).gradientList.getSelectedItem().equals("External")) {
/* 1099 */                     image = Morphology.externalGradient(image, strel);
/*      */                   } else {
/* 1101 */                     image = Morphology.gradient(image, strel);
/*      */                   } 
/*      */                 } else {
/*      */                   
/* 1105 */                   Strel strel = Strel.Shape.SQUARE.fromRadius((MorphologicalSegmentation.CustomWindow.access$3(MorphologicalSegmentation.CustomWindow.this)).gradientRadius);
/* 1106 */                   ImageProcessor gradient = null;
/* 1107 */                   if ((MorphologicalSegmentation.CustomWindow.access$3(MorphologicalSegmentation.CustomWindow.this)).gradientList.getSelectedItem().equals("Internal")) {
/* 1108 */                     gradient = Morphology.internalGradient(image.getProcessor(1), strel);
/* 1109 */                   } else if ((MorphologicalSegmentation.CustomWindow.access$3(MorphologicalSegmentation.CustomWindow.this)).gradientList.getSelectedItem().equals("External")) {
/* 1110 */                     gradient = Morphology.internalGradient(image.getProcessor(1), strel);
/*      */                   } else {
/* 1112 */                     gradient = Morphology.gradient(image.getProcessor(1), strel);
/* 1113 */                   }  image = new ImageStack(image.getWidth(), image.getHeight());
/* 1114 */                   image.addSlice(gradient);
/*      */                 } 
/*      */ 
/*      */                 
/* 1118 */                 (MorphologicalSegmentation.CustomWindow.access$3(MorphologicalSegmentation.CustomWindow.this)).gradientStack = image;
/*      */                 
/* 1120 */                 long t2 = System.currentTimeMillis();
/* 1121 */                 IJ.log("Morphological" + extra + " gradient took " + (t2 - t1) + " ms.");
/*      */ 
/*      */                 
/* 1124 */                 String[] arrayOfString = { (MorphologicalSegmentation.CustomWindow.access$3(MorphologicalSegmentation.CustomWindow.this)).gradientRadiusSizeText.getText() };
/* 1125 */                 MorphologicalSegmentation.record(MorphologicalSegmentation.SET_RADIUS, arrayOfString);
/*      */                 
/* 1127 */                 arrayOfString = new String[] { (String)(MorphologicalSegmentation.CustomWindow.access$3(this.this$1)).gradientList.getSelectedItem() };
/* 1128 */                 MorphologicalSegmentation.record(MorphologicalSegmentation.SET_GRADIENT_TYPE, arrayOfString);
/*      */               } 
/*      */               
/* 1131 */               IJ.log("Running extended minima with dynamic value " + dynamic + "...");
/* 1132 */               long step0 = System.currentTimeMillis();
/*      */ 
/*      */               
/* 1135 */               ImageStack regionalMinima = MinimaAndMaxima3D.extendedMinima(image, dynamic, connectivity);
/*      */               
/* 1137 */               if (regionalMinima == null) {
/*      */                 
/* 1139 */                 IJ.log("The segmentation was interrupted!");
/* 1140 */                 IJ.showStatus("The segmentation was interrupted!");
/* 1141 */                 IJ.showProgress(1.0D);
/*      */                 
/*      */                 return;
/*      */               } 
/* 1145 */               long step1 = System.currentTimeMillis();
/* 1146 */               IJ.log("Regional minima took " + (step1 - step0) + " ms.");
/*      */               
/* 1148 */               IJ.log("Imposing regional minima on original image (connectivity = " + readConn + ")...");
/*      */ 
/*      */               
/* 1151 */               ImageStack imposedMinima = MinimaAndMaxima3D.imposeMinima(image, regionalMinima, connectivity);
/*      */               
/* 1153 */               if (imposedMinima == null) {
/*      */                 
/* 1155 */                 IJ.log("The segmentation was interrupted!");
/* 1156 */                 IJ.showStatus("The segmentation was interrupted!");
/* 1157 */                 IJ.showProgress(1.0D);
/*      */                 
/*      */                 return;
/*      */               } 
/* 1161 */               long step2 = System.currentTimeMillis();
/* 1162 */               IJ.log("Imposition took " + (step2 - step1) + " ms.");
/*      */               
/* 1164 */               IJ.log("Labeling regional minima...");
/*      */ 
/*      */               
/* 1167 */               ImageStack labeledMinima = BinaryImages.componentsLabeling(regionalMinima, connectivity, 32);
/* 1168 */               if (labeledMinima == null) {
/*      */                 
/* 1170 */                 IJ.log("The segmentation was interrupted!");
/* 1171 */                 IJ.showStatus("The segmentation was interrupted!");
/* 1172 */                 IJ.showProgress(1.0D);
/*      */                 
/*      */                 return;
/*      */               } 
/* 1176 */               long step3 = System.currentTimeMillis();
/* 1177 */               IJ.log("Connected components took " + (step3 - step2) + " ms.");
/*      */ 
/*      */               
/* 1180 */               IJ.log("Running watershed...");
/*      */               
/* 1182 */               ImageStack resultStack = null;
/*      */               
/*      */               try {
/* 1185 */                 resultStack = Watershed.computeWatershed(imposedMinima, labeledMinima, 
/* 1186 */                     connectivity, (MorphologicalSegmentation.CustomWindow.access$3(MorphologicalSegmentation.CustomWindow.this)).calculateDams);
/*      */               }
/* 1188 */               catch (Exception ex) {
/*      */                 
/* 1190 */                 ex.printStackTrace();
/* 1191 */                 IJ.log("Error while runing watershed: " + ex.getMessage());
/*      */               }
/* 1193 */               catch (OutOfMemoryError err) {
/*      */                 
/* 1195 */                 err.printStackTrace();
/* 1196 */                 IJ.log("Error: the plugin run out of memory. Please use a smaller input image.");
/*      */               } 
/* 1198 */               if (resultStack == null) {
/*      */                 
/* 1200 */                 IJ.log("The segmentation was interrupted!");
/* 1201 */                 IJ.showStatus("The segmentation was interrupted!");
/* 1202 */                 IJ.showProgress(1.0D);
/*      */                 
/* 1204 */                 (MorphologicalSegmentation.CustomWindow.access$3(MorphologicalSegmentation.CustomWindow.this)).segmentButton.setText((MorphologicalSegmentation.CustomWindow.access$3(MorphologicalSegmentation.CustomWindow.this)).segmentText);
/* 1205 */                 (MorphologicalSegmentation.CustomWindow.access$3(MorphologicalSegmentation.CustomWindow.this)).segmentButton.setToolTipText((MorphologicalSegmentation.CustomWindow.access$3(MorphologicalSegmentation.CustomWindow.this)).segmentTip);
/*      */                 
/*      */                 return;
/*      */               } 
/* 1209 */               (MorphologicalSegmentation.CustomWindow.access$3(MorphologicalSegmentation.CustomWindow.this)).resultImage = new ImagePlus("watershed", resultStack);
/* 1210 */               (MorphologicalSegmentation.CustomWindow.access$3(MorphologicalSegmentation.CustomWindow.this)).resultImage.setCalibration((MorphologicalSegmentation.CustomWindow.access$3(MorphologicalSegmentation.CustomWindow.this)).inputImage.getCalibration());
/*      */               
/* 1212 */               long end = System.currentTimeMillis();
/* 1213 */               IJ.log("Watershed 3d took " + (end - step3) + " ms.");
/* 1214 */               IJ.log("Whole plugin took " + (end - start) + " ms.");
/*      */ 
/*      */               
/* 1217 */               Images3D.optimizeDisplayRange((MorphologicalSegmentation.CustomWindow.access$3(MorphologicalSegmentation.CustomWindow.this)).resultImage);
/*      */               
/* 1219 */               byte[][] colorMap = ColorMaps.CommonLabelMaps.fromLabel(ColorMaps.CommonLabelMaps.GOLDEN_ANGLE.getLabel()).computeLut(255, false);
/* 1220 */               ColorModel cm = ColorMaps.createColorModel(colorMap, Color.BLACK);
/* 1221 */               (MorphologicalSegmentation.CustomWindow.access$3(MorphologicalSegmentation.CustomWindow.this)).resultImage.getProcessor().setColorModel(cm);
/* 1222 */               (MorphologicalSegmentation.CustomWindow.access$3(MorphologicalSegmentation.CustomWindow.this)).resultImage.getImageStack().setColorModel(cm);
/* 1223 */               (MorphologicalSegmentation.CustomWindow.access$3(MorphologicalSegmentation.CustomWindow.this)).resultImage.updateAndDraw();
/*      */ 
/*      */               
/* 1226 */               MorphologicalSegmentation.CustomWindow.this.updateDisplayImage();
/* 1227 */               MorphologicalSegmentation.CustomWindow.this.updateResultOverlay();
/*      */               
/* 1229 */               (MorphologicalSegmentation.CustomWindow.access$3(MorphologicalSegmentation.CustomWindow.this)).showColorOverlay = true;
/* 1230 */               (MorphologicalSegmentation.CustomWindow.access$3(MorphologicalSegmentation.CustomWindow.this)).toggleOverlayCheckBox.setSelected(true);
/*      */ 
/*      */               
/* 1233 */               MorphologicalSegmentation.CustomWindow.access$3(MorphologicalSegmentation.CustomWindow.this).setParamsEnabled(true);
/*      */               
/* 1235 */               (MorphologicalSegmentation.CustomWindow.access$3(MorphologicalSegmentation.CustomWindow.this)).segmentButton.setText((MorphologicalSegmentation.CustomWindow.access$3(MorphologicalSegmentation.CustomWindow.this)).segmentText);
/* 1236 */               (MorphologicalSegmentation.CustomWindow.access$3(MorphologicalSegmentation.CustomWindow.this)).segmentButton.setToolTipText((MorphologicalSegmentation.CustomWindow.access$3(MorphologicalSegmentation.CustomWindow.this)).segmentTip);
/*      */               
/* 1238 */               (MorphologicalSegmentation.CustomWindow.access$3(MorphologicalSegmentation.CustomWindow.this)).segmentationThread = null;
/*      */ 
/*      */               
/* 1241 */               String[] arg = {
/* 1242 */                   "tolerance=" + Double.toString(dynamic), 
/* 1243 */                   "calculateDams=" + (MorphologicalSegmentation.CustomWindow.access$3(MorphologicalSegmentation.CustomWindow.this)).calculateDams, 
/* 1244 */                   "connectivity=" + Integer.toString(readConn) };
/* 1245 */               MorphologicalSegmentation.record(MorphologicalSegmentation.RUN_SEGMENTATION, arg);
/*      */             }
/*      */           };
/*      */         
/* 1249 */         MorphologicalSegmentation.this.segmentationThread = newThread;
/* 1250 */         newThread.start();
/*      */       
/*      */       }
/* 1253 */       else if (command.equals(MorphologicalSegmentation.this.stopText)) {
/*      */         
/* 1255 */         if (MorphologicalSegmentation.this.segmentationThread != null) {
/* 1256 */           MorphologicalSegmentation.this.segmentationThread.interrupt();
/*      */         } else {
/* 1258 */           IJ.log("Error: interrupting segmentation failed becaused the thread is null!");
/*      */         } 
/*      */         
/* 1261 */         MorphologicalSegmentation.this.segmentButton.setText(MorphologicalSegmentation.this.segmentText);
/* 1262 */         MorphologicalSegmentation.this.segmentButton.setToolTipText(MorphologicalSegmentation.this.segmentTip);
/*      */         
/* 1264 */         MorphologicalSegmentation.this.setParamsEnabled(true);
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     void updateDisplayImage() {
/* 1273 */       int slice = MorphologicalSegmentation.this.displayImage.getCurrentSlice();
/* 1274 */       if (MorphologicalSegmentation.this.applyGradient && MorphologicalSegmentation.this.showGradient && MorphologicalSegmentation.this.gradientStack != null) {
/* 1275 */         MorphologicalSegmentation.this.displayImage.setStack(MorphologicalSegmentation.this.gradientStack);
/*      */       } else {
/* 1277 */         MorphologicalSegmentation.this.displayImage.setStack(MorphologicalSegmentation.this.inputStackCopy);
/* 1278 */       }  MorphologicalSegmentation.this.displayImage.setSlice(slice);
/* 1279 */       MorphologicalSegmentation.this.displayImage.updateAndDraw();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     void toggleOverlay() {
/* 1287 */       MorphologicalSegmentation.this.showColorOverlay = !MorphologicalSegmentation.this.showColorOverlay;
/*      */       
/* 1289 */       MorphologicalSegmentation.this.toggleOverlayCheckBox.setSelected(MorphologicalSegmentation.this.showColorOverlay);
/*      */       
/* 1291 */       if (MorphologicalSegmentation.this.showColorOverlay) {
/* 1292 */         updateResultOverlay();
/*      */       } else {
/* 1294 */         MorphologicalSegmentation.this.displayImage.setOverlay(null);
/* 1295 */       }  MorphologicalSegmentation.this.displayImage.updateAndDraw();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     void createResultImage() {
/* 1303 */       if (MorphologicalSegmentation.this.resultImage != null) {
/*      */ 
/*      */         
/* 1306 */         String displayOption = (String)MorphologicalSegmentation.this.resultDisplayList.getSelectedItem();
/*      */         
/* 1308 */         ImagePlus watershedResult = null;
/*      */ 
/*      */         
/* 1311 */         if (displayOption.equals(MorphologicalSegmentation.catchmentBasinsText)) {
/* 1312 */           watershedResult = getResult(MorphologicalSegmentation.ResultMode.BASINS);
/* 1313 */         } else if (displayOption.equals(MorphologicalSegmentation.overlaidDamsText)) {
/* 1314 */           watershedResult = getResult(MorphologicalSegmentation.ResultMode.OVERLAID_DAMS);
/* 1315 */         } else if (displayOption.equals(MorphologicalSegmentation.watershedLinesText)) {
/* 1316 */           watershedResult = getResult(MorphologicalSegmentation.ResultMode.LINES);
/* 1317 */         } else if (displayOption.equals(MorphologicalSegmentation.overlaidBasinsText)) {
/* 1318 */           watershedResult = getResult(MorphologicalSegmentation.ResultMode.OVERLAID_BASINS);
/*      */         } 
/* 1320 */         if (watershedResult != null) {
/*      */           
/* 1322 */           watershedResult.show();
/* 1323 */           watershedResult.setSlice(MorphologicalSegmentation.this.displayImage.getCurrentSlice());
/*      */         } 
/*      */ 
/*      */         
/* 1327 */         MorphologicalSegmentation.record(MorphologicalSegmentation.CREATE_IMAGE, new String[0]);
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     void mergeLabels() {
/* 1335 */       if (MorphologicalSegmentation.this.resultImage == null) {
/*      */         
/* 1337 */         IJ.error("You need to run the segmentation before merging labels!");
/*      */         
/*      */         return;
/*      */       } 
/* 1341 */       Roi roi = MorphologicalSegmentation.this.displayImage.getRoi();
/* 1342 */       if (roi == null) {
/*      */         
/* 1344 */         IJ.showMessage("Please select some labels to merge using any of the selection tools");
/*      */ 
/*      */         
/*      */         return;
/*      */       } 
/*      */       
/* 1350 */       LabelImages.mergeLabels(MorphologicalSegmentation.this.resultImage, roi, true);
/*      */ 
/*      */       
/* 1353 */       MorphologicalSegmentation.this.resultImage.deleteRoi();
/* 1354 */       MorphologicalSegmentation.this.resultImage.updateAndDraw();
/*      */       
/* 1356 */       if (MorphologicalSegmentation.this.showColorOverlay) {
/* 1357 */         updateResultOverlay();
/*      */       }
/*      */       
/* 1360 */       MorphologicalSegmentation.record(MorphologicalSegmentation.MERGE_LABELS, new String[0]);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     void shuffleColors() {
/* 1368 */       if (MorphologicalSegmentation.this.resultImage != null) {
/*      */         
/* 1370 */         byte[][] colorMap = ColorMaps.CommonLabelMaps.fromLabel(
/* 1371 */             ColorMaps.CommonLabelMaps.GOLDEN_ANGLE.getLabel())
/* 1372 */           .computeLut(255, false);
/*      */         
/* 1374 */         long seed = (new Random()).nextInt();
/* 1375 */         colorMap = ColorMaps.shuffleLut(colorMap, seed);
/*      */         
/* 1377 */         ColorModel cm = ColorMaps.createColorModel(
/* 1378 */             colorMap, Color.BLACK);
/* 1379 */         MorphologicalSegmentation.this.resultImage.getProcessor().setColorModel(cm);
/* 1380 */         MorphologicalSegmentation.this.resultImage.getImageStack().setColorModel(cm);
/* 1381 */         MorphologicalSegmentation.this.resultImage.updateAndDraw();
/* 1382 */         if (MorphologicalSegmentation.this.showColorOverlay) {
/* 1383 */           updateResultOverlay();
/*      */         }
/*      */       } 
/* 1386 */       MorphologicalSegmentation.record(MorphologicalSegmentation.SHUFFLE_COLORS, new String[0]);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     void setInputImageType(String command) {
/* 1397 */       MorphologicalSegmentation.this.applyGradient = (command == MorphologicalSegmentation.objectImageText);
/* 1398 */       MorphologicalSegmentation.this.enableGradientOptions(MorphologicalSegmentation.this.applyGradient);
/*      */       
/* 1400 */       updateDisplayImage();
/* 1401 */       if (MorphologicalSegmentation.this.showColorOverlay) {
/* 1402 */         updateResultOverlay();
/*      */       }
/* 1404 */       if (MorphologicalSegmentation.this.applyGradient) {
/* 1405 */         MorphologicalSegmentation.this.objectButton.setSelected(true);
/*      */       } else {
/* 1407 */         MorphologicalSegmentation.this.borderButton.setSelected(true);
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     ImagePlus getResult(MorphologicalSegmentation.ResultMode mode) {
/*      */       ImageStack is;
/* 1417 */       String title = MorphologicalSegmentation.this.inputImage.getTitle();
/* 1418 */       String ext = "";
/* 1419 */       int index = title.lastIndexOf(".");
/* 1420 */       if (index != -1) {
/*      */         
/* 1422 */         ext = title.substring(index);
/* 1423 */         title = title.substring(0, index);
/*      */       } 
/*      */       
/* 1426 */       ImagePlus result = null;
/*      */ 
/*      */       
/* 1429 */       if (!MorphologicalSegmentation.this.showColorOverlay) {
/*      */         
/* 1431 */         result = MorphologicalSegmentation.this.displayImage.duplicate();
/*      */         
/* 1433 */         if (MorphologicalSegmentation.this.applyGradient && MorphologicalSegmentation.this.showGradient)
/* 1434 */           title = String.valueOf(title) + "-gradient"; 
/* 1435 */         result.setTitle(String.valueOf(title) + ext);
/* 1436 */         return result;
/*      */       } 
/*      */ 
/*      */       
/* 1440 */       switch (mode) {
/*      */         case OVERLAID_BASINS:
/* 1442 */           result = MorphologicalSegmentation.this.displayImage.duplicate();
/* 1443 */           result.setOverlay(null);
/* 1444 */           is = new ImageStack(MorphologicalSegmentation.this.displayImage.getWidth(), MorphologicalSegmentation.this.displayImage.getHeight());
/*      */           
/* 1446 */           for (this.slice = 1; this.slice <= result.getImageStackSize(); this.slice++) {
/*      */             
/* 1448 */             ImagePlus aux = new ImagePlus("", result.getImageStack().getProcessor(this.slice));
/* 1449 */             ImageRoi roi = new ImageRoi(0, 0, MorphologicalSegmentation.this.resultImage.getImageStack().getProcessor(this.slice));
/* 1450 */             roi.setOpacity(MorphologicalSegmentation.this.opacity);
/* 1451 */             aux.setOverlay(new Overlay((Roi)roi));
/* 1452 */             aux = aux.flatten();
/* 1453 */             is.addSlice(aux.getProcessor());
/*      */           } 
/* 1455 */           result.setStack(is);
/* 1456 */           if (MorphologicalSegmentation.this.applyGradient && MorphologicalSegmentation.this.showGradient)
/* 1457 */             title = String.valueOf(title) + "-gradient"; 
/* 1458 */           result.setTitle(String.valueOf(title) + "-overlaid-basins" + ext);
/*      */           break;
/*      */         case null:
/* 1461 */           result = MorphologicalSegmentation.this.resultImage.duplicate();
/* 1462 */           result.setTitle(String.valueOf(title) + "-catchment-basins" + ext);
/*      */           break;
/*      */         case OVERLAID_DAMS:
/* 1465 */           result = MorphologicalSegmentation.this.getWatershedLines(MorphologicalSegmentation.this.resultImage);
/* 1466 */           result = ColorImages.binaryOverlay(MorphologicalSegmentation.this.displayImage, result, Color.red);
/* 1467 */           if (MorphologicalSegmentation.this.applyGradient && MorphologicalSegmentation.this.showGradient)
/* 1468 */             title = String.valueOf(title) + "-gradient"; 
/* 1469 */           result.setTitle(String.valueOf(title) + "-overlaid-dams" + ext);
/*      */           break;
/*      */         case LINES:
/* 1472 */           result = MorphologicalSegmentation.this.getWatershedLines(MorphologicalSegmentation.this.resultImage);
/* 1473 */           IJ.run(result, "Invert", "stack");
/* 1474 */           result.setTitle(String.valueOf(title) + "-watershed-lines" + ext);
/*      */           break;
/*      */       } 
/*      */       
/* 1478 */       return result;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     void setShowGradient(boolean bool) {
/* 1487 */       MorphologicalSegmentation.this.showGradient = bool;
/* 1488 */       MorphologicalSegmentation.this.gradientCheckBox.setSelected(bool);
/* 1489 */       updateDisplayImage();
/* 1490 */       if (MorphologicalSegmentation.this.showColorOverlay) {
/* 1491 */         updateResultOverlay();
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     void setResultDisplayOption(String option) {
/* 1500 */       if (Arrays.<String>asList(MorphologicalSegmentation.this.resultDisplayOption).contains(option)) {
/* 1501 */         MorphologicalSegmentation.this.resultDisplayList.setSelectedItem(option);
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     String getResultDisplayOption() {
/* 1510 */       return (String)MorphologicalSegmentation.this.resultDisplayList.getSelectedItem();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     void updateResultOverlay() {
/* 1519 */       if (MorphologicalSegmentation.this.resultImage != null) {
/*      */         
/* 1521 */         int slice = MorphologicalSegmentation.this.displayImage.getCurrentSlice();
/*      */         
/* 1523 */         String displayOption = (String)MorphologicalSegmentation.this.resultDisplayList.getSelectedItem();
/*      */         
/* 1525 */         ImageRoi roi = null;
/*      */         
/* 1527 */         if (displayOption.equals(MorphologicalSegmentation.catchmentBasinsText)) {
/*      */           
/* 1529 */           roi = new ImageRoi(0, 0, MorphologicalSegmentation.this.resultImage.getImageStack().getProcessor(slice));
/* 1530 */           roi.setOpacity(1.0D);
/*      */         }
/* 1532 */         else if (displayOption.equals(MorphologicalSegmentation.overlaidDamsText)) {
/*      */           
/* 1534 */           ImageProcessor lines = BinaryImages.binarize(MorphologicalSegmentation.this.resultImage.getImageStack().getProcessor(slice));
/* 1535 */           lines.invert();
/* 1536 */           lines.setLut(LUT.createLutFromColor(Color.red));
/* 1537 */           roi = new ImageRoi(0, 0, lines);
/* 1538 */           roi.setZeroTransparent(true);
/* 1539 */           roi.setOpacity(1.0D);
/*      */         }
/* 1541 */         else if (displayOption.equals(MorphologicalSegmentation.watershedLinesText)) {
/*      */           
/* 1543 */           roi = new ImageRoi(0, 0, BinaryImages.binarize(MorphologicalSegmentation.this.resultImage.getImageStack().getProcessor(slice)));
/* 1544 */           roi.setOpacity(1.0D);
/*      */         }
/* 1546 */         else if (displayOption.equals(MorphologicalSegmentation.overlaidBasinsText)) {
/*      */           
/* 1548 */           roi = new ImageRoi(0, 0, MorphologicalSegmentation.this.resultImage.getImageStack().getProcessor(slice));
/* 1549 */           roi.setOpacity(MorphologicalSegmentation.this.opacity);
/*      */         } 
/*      */         
/* 1552 */         MorphologicalSegmentation.this.displayImage.setOverlay(new Overlay((Roi)roi));
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     boolean isShowResultOverlaySelected() {
/* 1562 */       return MorphologicalSegmentation.this.showColorOverlay;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     void setGradientRadius(int radius) {
/* 1571 */       if (radius > 0) {
/*      */         
/* 1573 */         MorphologicalSegmentation.this.gradientRadius = radius;
/* 1574 */         MorphologicalSegmentation.this.gradientRadiusSizeText.setText(String.valueOf(radius));
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     void setGradientType(String method) {
/* 1583 */       if (method != null)
/*      */       {
/* 1585 */         MorphologicalSegmentation.this.gradientList.setSelectedItem(method);
/*      */       }
/*      */     } }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   ImagePlus getWatershedLines(ImagePlus labels) {
/* 1598 */     ImagePlus lines = BinaryImages.binarize(labels);
/* 1599 */     IJ.run(lines, "Invert", "stack");
/* 1600 */     return lines;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void setParamsEnabled(boolean enabled) {
/* 1611 */     this.dynamicText.setEnabled(enabled);
/* 1612 */     this.dynamicLabel.setEnabled(enabled);
/* 1613 */     this.advancedOptionsCheckBox.setEnabled(enabled);
/* 1614 */     this.toggleOverlayCheckBox.setEnabled(enabled);
/* 1615 */     this.resultButton.setEnabled(enabled);
/* 1616 */     this.resultDisplayList.setEnabled(enabled);
/* 1617 */     this.displayLabel.setEnabled(enabled);
/* 1618 */     if (this.selectAdvancedOptions)
/* 1619 */       enableAdvancedOptions(enabled); 
/* 1620 */     if (this.applyGradient)
/* 1621 */       enableGradientOptions(enabled); 
/* 1622 */     this.mergeButton.setEnabled(enabled);
/* 1623 */     this.shuffleColorsButton.setEnabled(enabled);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void enableAdvancedOptions(boolean enabled) {
/* 1633 */     this.damsCheckBox.setEnabled(enabled);
/* 1634 */     this.connectivityLabel.setEnabled(enabled);
/* 1635 */     this.connectivityList.setEnabled(enabled);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void enableGradientOptions(boolean enabled) {
/* 1645 */     this.gradientList.setEnabled(enabled);
/* 1646 */     this.gradientRadiusSizeLabel.setEnabled(enabled);
/* 1647 */     this.gradientRadiusSizeText.setEnabled(enabled);
/* 1648 */     this.gradientCheckBox.setEnabled(enabled);
/* 1649 */     this.gradientTypeLabel.setEnabled(enabled);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void run(String arg0) {
/* 1655 */     if (IJ.getVersion().compareTo("1.48a") < 0) {
/*      */       
/* 1657 */       IJ.error("Morphological Segmentation", "ERROR: detected ImageJ version " + IJ.getVersion() + 
/* 1658 */           ".\nMorphological Segmentation requires version 1.48a or superior, please update ImageJ!");
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/* 1663 */     if (WindowManager.getCurrentImage() == null) {
/*      */       
/* 1665 */       this.inputImage = IJ.openImage();
/* 1666 */       if (this.inputImage == null)
/*      */         return; 
/*      */     } else {
/* 1669 */       this.inputImage = WindowManager.getCurrentImage();
/*      */     } 
/* 1671 */     if (this.inputImage.getType() == 3 || 
/* 1672 */       this.inputImage.getType() == 4) {
/*      */       
/* 1674 */       IJ.error("Morphological Segmentation", "This plugin only works on grayscale images.\nPlease convert it to 8, 16 or 32-bit.");
/*      */       
/*      */       return;
/*      */     } 
/* 1678 */     this.inputStackCopy = this.inputImage.getImageStack().duplicate();
/* 1679 */     this.displayImage = new ImagePlus(this.inputImage.getTitle(), 
/* 1680 */         this.inputStackCopy);
/* 1681 */     this.displayImage.setTitle("Morphological Segmentation");
/* 1682 */     this.displayImage.setSlice(this.inputImage.getCurrentSlice());
/*      */ 
/*      */     
/* 1685 */     this.inputImage.getWindow().setVisible(false);
/*      */ 
/*      */     
/* 1688 */     this.inputIs2D = (this.inputImage.getImageStackSize() == 1);
/*      */ 
/*      */     
/* 1691 */     if (!this.inputIs2D && 
/* 1692 */       !this.displayImage.isHyperStack() && 
/* 1693 */       this.displayImage.getNSlices() == 1)
/*      */     {
/*      */       
/* 1696 */       this.displayImage.setDimensions(1, this.displayImage.getNFrames(), 1);
/*      */     }
/*      */ 
/*      */     
/* 1700 */     SwingUtilities.invokeLater(
/* 1701 */         new Runnable() {
/*      */           public void run() {
/* 1703 */             MorphologicalSegmentation.this.win = new MorphologicalSegmentation.CustomWindow(MorphologicalSegmentation.this.displayImage);
/* 1704 */             MorphologicalSegmentation.this.win.pack();
/*      */           }
/*      */         });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void record(String command, String... args) {
/* 1723 */     command = "call(\"inra.ijpb.plugins.MorphologicalSegmentation." + command;
/* 1724 */     for (int i = 0; i < args.length; i++)
/* 1725 */       command = String.valueOf(command) + "\", \"" + args[i]; 
/* 1726 */     command = String.valueOf(command) + "\");\n";
/* 1727 */     if (Recorder.record) {
/* 1728 */       Recorder.recordString(command);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void segment(String dynamic, String calculateDams, String connectivity, String usePriorityQueue) {
/* 1747 */     ImageWindow iw = WindowManager.getCurrentImage().getWindow();
/* 1748 */     if (iw instanceof CustomWindow) {
/*      */ 
/*      */       
/* 1751 */       CustomWindow win = (CustomWindow)iw;
/* 1752 */       win.setDynamic(Double.parseDouble(dynamic.replace("tolerance=", "")));
/* 1753 */       win.setCalculateDams(calculateDams.contains("true"));
/* 1754 */       win.setConnectivity(Integer.parseInt(connectivity.replace("connectivity=", "")));
/* 1755 */       win.runSegmentation(win.getSegmentText());
/*      */     } else {
/*      */       
/* 1758 */       IJ.log("Error: Morphological Segmentation GUI not detected.");
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void segment(String dynamic, String calculateDams, String connectivity) {
/* 1772 */     ImageWindow iw = WindowManager.getCurrentImage().getWindow();
/* 1773 */     if (iw instanceof CustomWindow) {
/*      */ 
/*      */       
/* 1776 */       CustomWindow win = (CustomWindow)iw;
/* 1777 */       win.setDynamic(Double.parseDouble(dynamic.replace("tolerance=", "")));
/* 1778 */       win.setCalculateDams(calculateDams.contains("true"));
/* 1779 */       win.setConnectivity(Integer.parseInt(connectivity.replace("connectivity=", "")));
/* 1780 */       win.runSegmentation(win.getSegmentText());
/*      */     } else {
/*      */       
/* 1783 */       IJ.log("Error: Morphological Segmentation GUI not detected.");
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static void toggleOverlay() {
/* 1790 */     ImageWindow iw = WindowManager.getCurrentImage().getWindow();
/* 1791 */     if (iw instanceof CustomWindow) {
/*      */       
/* 1793 */       CustomWindow win = (CustomWindow)iw;
/* 1794 */       win.toggleOverlay();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void mergeLabels() {
/* 1803 */     ImageWindow iw = WindowManager.getCurrentImage().getWindow();
/* 1804 */     if (iw instanceof CustomWindow) {
/*      */       
/* 1806 */       CustomWindow win = (CustomWindow)iw;
/* 1807 */       win.mergeLabels();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void shuffleColors() {
/* 1815 */     ImageWindow iw = WindowManager.getCurrentImage().getWindow();
/* 1816 */     if (iw instanceof CustomWindow) {
/*      */       
/* 1818 */       CustomWindow win = (CustomWindow)iw;
/* 1819 */       win.shuffleColors();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void createResultImage() {
/* 1828 */     ImageWindow iw = WindowManager.getCurrentImage().getWindow();
/* 1829 */     if (iw instanceof CustomWindow) {
/*      */       
/* 1831 */       CustomWindow win = (CustomWindow)iw;
/* 1832 */       String mode = win.getResultDisplayOption();
/*      */       
/* 1834 */       ImagePlus result = null;
/*      */       
/* 1836 */       if (mode.equals(catchmentBasinsText)) {
/* 1837 */         result = win.getResult(ResultMode.BASINS);
/* 1838 */       } else if (mode.equals(overlaidBasinsText)) {
/* 1839 */         result = win.getResult(ResultMode.OVERLAID_BASINS);
/* 1840 */       } else if (mode.equals(watershedLinesText)) {
/* 1841 */         result = win.getResult(ResultMode.LINES);
/* 1842 */       } else if (mode.equals(overlaidDamsText)) {
/* 1843 */         result = win.getResult(ResultMode.OVERLAID_DAMS);
/*      */       } 
/* 1845 */       if (result != null) {
/*      */         
/* 1847 */         result.show();
/* 1848 */         result.setSlice(win.getImagePlus().getCurrentSlice());
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void setInputImageType(String type) {
/* 1859 */     ImageWindow iw = WindowManager.getCurrentImage().getWindow();
/* 1860 */     if (iw instanceof CustomWindow) {
/*      */       
/* 1862 */       CustomWindow win = (CustomWindow)iw;
/*      */       
/* 1864 */       if (type.equals("object")) {
/* 1865 */         win.setInputImageType(objectImageText);
/* 1866 */       } else if (type.equals("border")) {
/* 1867 */         win.setInputImageType(borderImageText);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void setShowGradient(String bool) {
/* 1877 */     ImageWindow iw = WindowManager.getCurrentImage().getWindow();
/* 1878 */     if (iw instanceof CustomWindow) {
/*      */       
/* 1880 */       CustomWindow win = (CustomWindow)iw;
/* 1881 */       if (bool.equals("true")) {
/* 1882 */         win.setShowGradient(true);
/* 1883 */       } else if (bool.equals("false")) {
/* 1884 */         win.setShowGradient(false);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void setDisplayFormat(String format) {
/* 1894 */     ImageWindow iw = WindowManager.getCurrentImage().getWindow();
/* 1895 */     if (iw instanceof CustomWindow) {
/*      */       
/* 1897 */       CustomWindow win = (CustomWindow)iw;
/* 1898 */       win.setResultDisplayOption(format);
/* 1899 */       if (win.isShowResultOverlaySelected()) {
/* 1900 */         win.updateResultOverlay();
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void setGradientRadius(String radius) {
/* 1910 */     ImageWindow iw = WindowManager.getCurrentImage().getWindow();
/* 1911 */     if (iw instanceof CustomWindow) {
/*      */       
/* 1913 */       CustomWindow win = (CustomWindow)iw;
/* 1914 */       win.setGradientRadius(Integer.parseInt(radius));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void setGradientType(String method) {
/* 1923 */     ImageWindow iw = WindowManager.getCurrentImage().getWindow();
/* 1924 */     if (iw instanceof CustomWindow) {
/*      */       
/* 1926 */       CustomWindow win = (CustomWindow)iw;
/* 1927 */       win.setGradientType(method);
/*      */     } 
/*      */   }
/*      */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/plugins/MorphologicalSegmentation.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */