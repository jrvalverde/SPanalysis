/*    */ package inra.ijpb.plugins;
/*    */ 
/*    */ import ij.IJ;
/*    */ import ij.ImagePlus;
/*    */ import ij.ImageStack;
/*    */ import ij.plugin.PlugIn;
/*    */ import ij.process.ImageProcessor;
/*    */ import inra.ijpb.morphology.Reconstruction;
/*    */ import inra.ijpb.morphology.Reconstruction3D;
/*    */ import inra.ijpb.util.IJUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class KillBordersPlugin
/*    */   implements PlugIn
/*    */ {
/*    */   public void run(String arg0) {
/* 43 */     ImagePlus resultPlus, imagePlus = IJ.getImage();
/*    */     
/* 45 */     String newName = String.valueOf(imagePlus.getShortTitle()) + "-killBorders";
/*    */ 
/*    */     
/* 48 */     long t0 = System.currentTimeMillis();
/* 49 */     if (imagePlus.getStackSize() == 1) {
/*    */ 
/*    */       
/* 52 */       ImageProcessor image = imagePlus.getProcessor();
/* 53 */       ImageProcessor result = Reconstruction.killBorders(image);
/* 54 */       if (!(result instanceof ij.process.ColorProcessor))
/* 55 */         result.setLut(image.getLut()); 
/* 56 */       resultPlus = new ImagePlus(newName, result);
/*    */     
/*    */     }
/*    */     else {
/*    */ 
/*    */       
/* 62 */       ImageStack image = imagePlus.getStack();
/* 63 */       ImageStack result = Reconstruction3D.killBorders(image);
/* 64 */       result.setColorModel(image.getColorModel());
/* 65 */       resultPlus = new ImagePlus(newName, result);
/*    */     } 
/* 67 */     long elapsedTime = System.currentTimeMillis() - t0;
/*    */     
/* 69 */     resultPlus.copyScale(imagePlus);
/* 70 */     resultPlus.show();
/*    */     
/* 72 */     if (imagePlus.getStackSize() > 1)
/*    */     {
/* 74 */       resultPlus.setSlice(imagePlus.getCurrentSlice());
/*    */     }
/*    */     
/* 77 */     IJUtils.showElapsedTime("Kill Borders", elapsedTime, imagePlus);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/plugins/KillBordersPlugin.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */