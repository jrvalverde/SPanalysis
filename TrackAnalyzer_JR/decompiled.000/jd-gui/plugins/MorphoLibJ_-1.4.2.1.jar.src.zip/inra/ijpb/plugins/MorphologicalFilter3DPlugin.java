/*     */ package inra.ijpb.plugins;
/*     */ 
/*     */ import ij.IJ;
/*     */ import ij.ImagePlus;
/*     */ import ij.ImageStack;
/*     */ import ij.WindowManager;
/*     */ import ij.gui.GenericDialog;
/*     */ import ij.plugin.PlugIn;
/*     */ import inra.ijpb.algo.Algo;
/*     */ import inra.ijpb.algo.DefaultAlgoListener;
/*     */ import inra.ijpb.morphology.Morphology;
/*     */ import inra.ijpb.morphology.Strel3D;
/*     */ import inra.ijpb.util.IJUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MorphologicalFilter3DPlugin
/*     */   implements PlugIn
/*     */ {
/*     */   public void run(String arg) {
/*  56 */     if (IJ.getVersion().compareTo("1.48a") < 0) {
/*     */       
/*  58 */       IJ.error("Morphological Filter 3D", "ERROR: detected ImageJ version " + IJ.getVersion() + 
/*  59 */           ".\nThis plugin requires version 1.48a or superior, please update ImageJ!");
/*     */       
/*     */       return;
/*     */     } 
/*  63 */     ImagePlus imagePlus = WindowManager.getCurrentImage();
/*  64 */     if (imagePlus == null) {
/*     */       
/*  66 */       IJ.error("No image", "Need at least one image to work");
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/*  71 */     GenericDialog gd = new GenericDialog("Morphological Filters (3D)");
/*     */     
/*  73 */     gd.addChoice("Operation", Morphology.Operation.getAllLabels(), 
/*  74 */         Morphology.Operation.DILATION.toString());
/*  75 */     gd.addChoice("Element Shape", Strel3D.Shape.getAllLabels(), 
/*  76 */         Strel3D.Shape.CUBE.toString());
/*  77 */     gd.addNumericField("X-Radius (in voxels)", 2.0D, 0);
/*  78 */     gd.addNumericField("Y-Radius (in voxels)", 2.0D, 0);
/*  79 */     gd.addNumericField("Z-Radius (in voxels)", 2.0D, 0);
/*  80 */     gd.addCheckbox("Show Element", false);
/*     */ 
/*     */     
/*  83 */     gd.showDialog();
/*     */     
/*  85 */     if (gd.wasCanceled()) {
/*     */       return;
/*     */     }
/*  88 */     long t0 = System.currentTimeMillis();
/*     */ 
/*     */     
/*  91 */     Morphology.Operation op = Morphology.Operation.fromLabel(gd.getNextChoice());
/*  92 */     Strel3D.Shape strelShape = Strel3D.Shape.fromLabel(gd.getNextChoice());
/*  93 */     int radiusX = (int)gd.getNextNumber();
/*  94 */     int radiusY = (int)gd.getNextNumber();
/*  95 */     int radiusZ = (int)gd.getNextNumber();
/*  96 */     boolean showStrel = gd.getNextBoolean();
/*     */ 
/*     */     
/*  99 */     Strel3D strel = strelShape.fromRadiusList(radiusX, radiusY, radiusZ);
/* 100 */     strel.showProgress(true);
/* 101 */     DefaultAlgoListener.monitor((Algo)strel);
/*     */ 
/*     */     
/* 104 */     if (showStrel)
/*     */     {
/* 106 */       showStrelImage(strel);
/*     */     }
/*     */ 
/*     */     
/* 110 */     ImagePlus resPlus = process(imagePlus, op, strel);
/*     */     
/* 112 */     if (resPlus == null) {
/*     */       return;
/*     */     }
/*     */     
/* 116 */     resPlus.show();
/* 117 */     resPlus.setSlice(imagePlus.getCurrentSlice());
/*     */ 
/*     */     
/* 120 */     long t1 = System.currentTimeMillis();
/* 121 */     IJUtils.showElapsedTime(op.toString(), (t1 - t0), imagePlus);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void showStrelImage(Strel3D strel) {
/* 132 */     int[] dim = strel.getSize();
/* 133 */     int sizeX = dim[0] + 10;
/* 134 */     int sizeY = dim[1] + 10;
/* 135 */     int sizeZ = dim[2] + 10;
/*     */ 
/*     */     
/* 138 */     ImageStack stack = ImageStack.create(sizeX, sizeY, sizeZ, 8);
/* 139 */     stack.setVoxel(sizeX / 2, sizeY / 2, sizeZ / 2, 255.0D);
/* 140 */     stack = Morphology.dilation(stack, strel);
/*     */ 
/*     */     
/* 143 */     ImagePlus strelImage = new ImagePlus("Structuring Element", stack);
/* 144 */     strelImage.setSlice((sizeZ - 1) / 2 + 1);
/* 145 */     strelImage.show();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ImagePlus process(ImagePlus image, Morphology.Operation op, Strel3D strel) {
/* 151 */     if (image == null) {
/* 152 */       return null;
/*     */     }
/*     */     
/* 155 */     ImageStack inputStack = image.getStack();
/*     */ 
/*     */     
/* 158 */     ImageStack resultStack = op.apply(inputStack, strel);
/*     */ 
/*     */     
/* 161 */     String newName = String.valueOf(image.getShortTitle()) + "-" + op.toString();
/* 162 */     ImagePlus resultPlus = new ImagePlus(newName, resultStack);
/* 163 */     resultPlus.copyScale(image);
/*     */ 
/*     */     
/* 166 */     return resultPlus;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/plugins/MorphologicalFilter3DPlugin.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */