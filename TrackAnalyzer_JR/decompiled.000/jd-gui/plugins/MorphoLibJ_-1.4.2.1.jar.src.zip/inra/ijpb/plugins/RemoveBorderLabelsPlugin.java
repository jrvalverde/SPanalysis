/*     */ package inra.ijpb.plugins;
/*     */ 
/*     */ import ij.IJ;
/*     */ import ij.ImagePlus;
/*     */ import ij.ImageStack;
/*     */ import ij.gui.GenericDialog;
/*     */ import ij.plugin.PlugIn;
/*     */ import inra.ijpb.label.LabelImages;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.TreeSet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RemoveBorderLabelsPlugin
/*     */   implements PlugIn
/*     */ {
/*     */   public void run(String arg0) {
/*  57 */     ImagePlus imagePlus = IJ.getImage();
/*  58 */     boolean isStack = (imagePlus.getStackSize() > 1);
/*     */ 
/*     */     
/*  61 */     GenericDialog gd = new GenericDialog("Remove Border Labels");
/*  62 */     gd.addCheckbox("Left", true);
/*  63 */     gd.addCheckbox("Right", true);
/*  64 */     gd.addCheckbox("Top", true);
/*  65 */     gd.addCheckbox("Bottom", true);
/*  66 */     if (isStack) {
/*     */       
/*  68 */       gd.addCheckbox("Front", true);
/*  69 */       gd.addCheckbox("Back", true);
/*     */     } 
/*     */     
/*  72 */     gd.showDialog();
/*  73 */     if (gd.wasCanceled()) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/*  78 */     boolean removeLeft = gd.getNextBoolean();
/*  79 */     boolean removeRight = gd.getNextBoolean();
/*  80 */     boolean removeTop = gd.getNextBoolean();
/*  81 */     boolean removeBottom = gd.getNextBoolean();
/*  82 */     boolean removeFront = false, removeBack = false;
/*  83 */     if (isStack) {
/*     */       
/*  85 */       removeFront = gd.getNextBoolean();
/*  86 */       removeBack = gd.getNextBoolean();
/*     */     } 
/*     */     
/*  89 */     IJ.showStatus("Identifies border labels");
/*     */     
/*  91 */     ImagePlus resultPlus = remove(imagePlus, removeLeft, removeRight, 
/*  92 */         removeTop, removeBottom, removeFront, removeBack);
/*     */ 
/*     */     
/*  95 */     resultPlus.show();
/*  96 */     if (isStack) {
/*     */       
/*  98 */       resultPlus.setZ(imagePlus.getZ());
/*  99 */       resultPlus.setSlice(imagePlus.getCurrentSlice());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImagePlus remove(ImagePlus labelImage, boolean removeLeft, boolean removeRight, boolean removeTop, boolean removeBottom, boolean removeFront, boolean removeBack) {
/* 123 */     TreeSet<Integer> labelSet = new TreeSet<Integer>();
/* 124 */     ImageStack image = labelImage.getStack();
/* 125 */     if (removeLeft)
/* 126 */       labelSet.addAll(findBorderLabelsLeft(image)); 
/* 127 */     if (removeRight)
/* 128 */       labelSet.addAll(findBorderLabelsRight(image)); 
/* 129 */     if (removeTop)
/* 130 */       labelSet.addAll(findBorderLabelsTop(image)); 
/* 131 */     if (removeBottom)
/* 132 */       labelSet.addAll(findBorderLabelsBottom(image)); 
/* 133 */     if (removeFront)
/* 134 */       labelSet.addAll(findBorderLabelsFront(image)); 
/* 135 */     if (removeBack) {
/* 136 */       labelSet.addAll(findBorderLabelsBack(image));
/*     */     }
/*     */ 
/*     */     
/* 140 */     int[] labels = new int[labelSet.size()];
/* 141 */     int i = 0;
/* 142 */     Iterator<Integer> iter = labelSet.iterator();
/* 143 */     while (iter.hasNext()) {
/* 144 */       labels[i++] = ((Integer)iter.next()).intValue();
/*     */     }
/*     */ 
/*     */     
/* 148 */     IJ.showStatus("Duplicates image");
/* 149 */     ImagePlus resultPlus = labelImage.duplicate();
/*     */ 
/*     */     
/* 152 */     IJ.showStatus("Remove border labels");
/* 153 */     LabelImages.replaceLabels(resultPlus, labels, 0);
/* 154 */     IJ.showStatus("");
/*     */     
/* 156 */     resultPlus.setTitle(String.valueOf(labelImage.getShortTitle()) + "-killBorders");
/* 157 */     return resultPlus;
/*     */   }
/*     */   
/*     */   private static final Collection<Integer> findBorderLabelsLeft(ImageStack image) {
/* 161 */     int sizeY = image.getHeight();
/* 162 */     int sizeZ = image.getSize();
/*     */     
/* 164 */     TreeSet<Integer> labelSet = new TreeSet<Integer>();
/*     */     
/* 166 */     for (int z = 0; z < sizeZ; z++) {
/* 167 */       for (int y = 0; y < sizeY; y++) {
/* 168 */         labelSet.add(Integer.valueOf((int)image.getVoxel(0, y, z)));
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 173 */     labelSet.remove(Integer.valueOf(0));
/*     */     
/* 175 */     return labelSet;
/*     */   }
/*     */   
/*     */   private static final Collection<Integer> findBorderLabelsRight(ImageStack image) {
/* 179 */     int sizeX = image.getWidth();
/* 180 */     int sizeY = image.getHeight();
/* 181 */     int sizeZ = image.getSize();
/*     */     
/* 183 */     TreeSet<Integer> labelSet = new TreeSet<Integer>();
/*     */     
/* 185 */     for (int z = 0; z < sizeZ; z++) {
/* 186 */       for (int y = 0; y < sizeY; y++) {
/* 187 */         labelSet.add(Integer.valueOf((int)image.getVoxel(sizeX - 1, y, z)));
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 192 */     labelSet.remove(Integer.valueOf(0));
/*     */     
/* 194 */     return labelSet;
/*     */   }
/*     */   
/*     */   private static final Collection<Integer> findBorderLabelsTop(ImageStack image) {
/* 198 */     int sizeX = image.getWidth();
/* 199 */     int sizeZ = image.getSize();
/*     */     
/* 201 */     TreeSet<Integer> labelSet = new TreeSet<Integer>();
/*     */     
/* 203 */     for (int z = 0; z < sizeZ; z++) {
/* 204 */       for (int x = 0; x < sizeX; x++) {
/* 205 */         labelSet.add(Integer.valueOf((int)image.getVoxel(x, 0, z)));
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 210 */     labelSet.remove(Integer.valueOf(0));
/*     */     
/* 212 */     return labelSet;
/*     */   }
/*     */   
/*     */   private static final Collection<Integer> findBorderLabelsBottom(ImageStack image) {
/* 216 */     int sizeX = image.getWidth();
/* 217 */     int sizeY = image.getHeight();
/* 218 */     int sizeZ = image.getSize();
/*     */     
/* 220 */     TreeSet<Integer> labelSet = new TreeSet<Integer>();
/*     */     
/* 222 */     for (int z = 0; z < sizeZ; z++) {
/* 223 */       for (int x = 0; x < sizeX; x++) {
/* 224 */         labelSet.add(Integer.valueOf((int)image.getVoxel(x, sizeY - 1, z)));
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 229 */     labelSet.remove(Integer.valueOf(0));
/*     */     
/* 231 */     return labelSet;
/*     */   }
/*     */   
/*     */   private static final Collection<Integer> findBorderLabelsFront(ImageStack image) {
/* 235 */     int sizeX = image.getWidth();
/* 236 */     int sizeY = image.getHeight();
/*     */     
/* 238 */     TreeSet<Integer> labelSet = new TreeSet<Integer>();
/*     */     
/* 240 */     for (int y = 0; y < sizeY; y++) {
/* 241 */       for (int x = 0; x < sizeX; x++) {
/* 242 */         labelSet.add(Integer.valueOf((int)image.getVoxel(x, y, 0)));
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 247 */     labelSet.remove(Integer.valueOf(0));
/*     */     
/* 249 */     return labelSet;
/*     */   }
/*     */   
/*     */   private static final Collection<Integer> findBorderLabelsBack(ImageStack image) {
/* 253 */     int sizeX = image.getWidth();
/* 254 */     int sizeY = image.getHeight();
/* 255 */     int sizeZ = image.getSize();
/*     */     
/* 257 */     TreeSet<Integer> labelSet = new TreeSet<Integer>();
/*     */     
/* 259 */     for (int y = 0; y < sizeY; y++) {
/* 260 */       for (int x = 0; x < sizeX; x++) {
/* 261 */         labelSet.add(Integer.valueOf((int)image.getVoxel(x, y, sizeZ - 1)));
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 266 */     labelSet.remove(Integer.valueOf(0));
/*     */     
/* 268 */     return labelSet;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/plugins/RemoveBorderLabelsPlugin.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */