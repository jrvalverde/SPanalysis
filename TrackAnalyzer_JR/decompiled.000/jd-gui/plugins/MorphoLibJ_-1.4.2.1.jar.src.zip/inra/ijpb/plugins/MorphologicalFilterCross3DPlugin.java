/*     */ package inra.ijpb.plugins;
/*     */ 
/*     */ import ij.IJ;
/*     */ import ij.ImagePlus;
/*     */ import ij.ImageStack;
/*     */ import ij.WindowManager;
/*     */ import ij.gui.GenericDialog;
/*     */ import ij.plugin.PlugIn;
/*     */ import ij.process.ByteProcessor;
/*     */ import ij.process.ImageProcessor;
/*     */ import inra.ijpb.morphology.Morphology;
/*     */ import inra.ijpb.morphology.Strel3D;
/*     */ import inra.ijpb.morphology.strel.Cross3DStrel;
/*     */ import inra.ijpb.util.IJUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MorphologicalFilterCross3DPlugin
/*     */   implements PlugIn
/*     */ {
/*     */   public void run(String arg) {
/*  53 */     ImagePlus imagePlus = WindowManager.getCurrentImage();
/*  54 */     if (imagePlus == null) {
/*  55 */       IJ.error("No image", "Need at least one image to work");
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/*  60 */     GenericDialog gd = new GenericDialog("Morphological Filter");
/*     */     
/*  62 */     gd.addChoice("Operation", Morphology.Operation.getAllLabels(), 
/*  63 */         Morphology.Operation.DILATION.toString());
/*  64 */     gd.addCheckbox("Show Element", false);
/*     */ 
/*     */     
/*  67 */     gd.showDialog();
/*     */     
/*  69 */     if (gd.wasCanceled()) {
/*     */       return;
/*     */     }
/*  72 */     long t0 = System.currentTimeMillis();
/*     */ 
/*     */     
/*  75 */     Morphology.Operation op = Morphology.Operation.fromLabel(gd.getNextChoice());
/*  76 */     boolean showStrel = gd.getNextBoolean();
/*     */ 
/*     */     
/*  79 */     Cross3DStrel cross3DStrel = new Cross3DStrel();
/*  80 */     cross3DStrel.showProgress(true);
/*     */ 
/*     */     
/*  83 */     if (showStrel) {
/*  84 */       showStrelImage((Strel3D)cross3DStrel);
/*     */     }
/*     */ 
/*     */     
/*  88 */     ImagePlus resPlus = process(imagePlus, op, (Strel3D)cross3DStrel);
/*     */     
/*  90 */     if (resPlus == null) {
/*     */       return;
/*     */     }
/*     */     
/*  94 */     resPlus.show();
/*  95 */     resPlus.setSlice(imagePlus.getCurrentSlice());
/*     */ 
/*     */     
/*  98 */     long t1 = System.currentTimeMillis();
/*  99 */     IJUtils.showElapsedTime(op.toString(), (t1 - t0), imagePlus);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void showStrelImage(Strel3D strel) {
/* 110 */     int[] dim = strel.getSize();
/* 111 */     int width = dim[0] + 20;
/* 112 */     int height = dim[1] + 20;
/*     */ 
/*     */     
/* 115 */     ByteProcessor byteProcessor = new ByteProcessor(width, height);
/* 116 */     byteProcessor.set(width / 2, height / 2, 255);
/* 117 */     ImageStack stack = new ImageStack();
/* 118 */     stack.addSlice((ImageProcessor)byteProcessor);
/* 119 */     stack = Morphology.dilation(stack, strel);
/* 120 */     ImageProcessor imageProcessor = stack.getProcessor(1);
/*     */ 
/*     */     
/* 123 */     if (!imageProcessor.isInvertedLut()) {
/* 124 */       imageProcessor.invertLut();
/*     */     }
/*     */     
/* 127 */     ImagePlus maskImage = new ImagePlus("Element", imageProcessor);
/* 128 */     maskImage.show();
/*     */   }
/*     */ 
/*     */   
/*     */   public ImagePlus process(ImagePlus image, Morphology.Operation op, Strel3D strel) {
/* 133 */     if (image == null) {
/* 134 */       return null;
/*     */     }
/*     */     
/* 137 */     ImageStack inputStack = image.getStack();
/*     */ 
/*     */     
/* 140 */     ImageStack resultStack = op.apply(inputStack, strel);
/*     */ 
/*     */     
/* 143 */     ImagePlus resultPlus = new ImagePlus(op.toString(), resultStack);
/* 144 */     resultPlus.copyScale(image);
/*     */ 
/*     */     
/* 147 */     return resultPlus;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/plugins/MorphologicalFilterCross3DPlugin.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */