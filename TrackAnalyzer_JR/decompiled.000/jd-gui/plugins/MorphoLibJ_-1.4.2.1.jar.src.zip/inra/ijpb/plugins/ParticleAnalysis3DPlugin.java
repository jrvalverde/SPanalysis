/*     */ package inra.ijpb.plugins;
/*     */ 
/*     */ import ij.IJ;
/*     */ import ij.ImagePlus;
/*     */ import ij.ImageStack;
/*     */ import ij.gui.GenericDialog;
/*     */ import ij.measure.Calibration;
/*     */ import ij.measure.ResultsTable;
/*     */ import ij.plugin.PlugIn;
/*     */ import inra.ijpb.geometry.Ellipsoid;
/*     */ import inra.ijpb.geometry.Point3D;
/*     */ import inra.ijpb.geometry.Sphere;
/*     */ import inra.ijpb.label.LabelImages;
/*     */ import inra.ijpb.measure.IntrinsicVolumes3D;
/*     */ import inra.ijpb.measure.region3d.EquivalentEllipsoid;
/*     */ import inra.ijpb.measure.region3d.LargestInscribedBall;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public class ParticleAnalysis3DPlugin
/*     */   implements PlugIn
/*     */ {
/*  67 */   private static final String[] connectivityNames = new String[] {
/*  68 */       "C6", "C26"
/*     */     };
/*     */   
/*  71 */   private static final int[] connectivityValues = new int[] { 6, 26 };
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  76 */   private static final String[] surfaceAreaMethods = new String[] {
/*  77 */       "Crofton  (3 dirs.)", 
/*  78 */       "Crofton (13 dirs.)"
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  84 */   private static final int[] dirNumbers = new int[] {
/*  85 */       3, 13
/*     */     };
/*     */ 
/*     */   
/*     */   public boolean debug = false;
/*     */ 
/*     */   
/*     */   boolean computeVolume = true;
/*     */ 
/*     */   
/*     */   boolean computeSurface = true;
/*     */   
/*     */   boolean computeEulerNumber = true;
/*     */   
/*     */   boolean computeSphericity = true;
/*     */   
/*     */   boolean computeEllipsoid = true;
/*     */   
/*     */   boolean computeElongations = true;
/*     */   
/*     */   boolean computeInscribedBall = true;
/*     */   
/* 107 */   String surfaceAreaMethod = surfaceAreaMethods[1];
/* 108 */   int surfaceAreaDirs = 3;
/* 109 */   int connectivity = 6;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void run(String args) {
/* 120 */     ImagePlus imagePlus = IJ.getImage();
/*     */     
/* 122 */     if (imagePlus.getStackSize() == 1) {
/*     */       
/* 124 */       IJ.error("Requires a Stack");
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 129 */     GenericDialog gd = new GenericDialog("Particles Analysis 3D");
/* 130 */     gd.addCheckbox("Volume", true);
/* 131 */     gd.addCheckbox("Surface Area", true);
/* 132 */     gd.addCheckbox("Sphericity", true);
/* 133 */     gd.addCheckbox("Euler Number", true);
/* 134 */     gd.addCheckbox("Equivalent Ellipsoid", true);
/* 135 */     gd.addCheckbox("Ellipsoid Elongation", true);
/* 136 */     gd.addCheckbox("Max. Inscribed Ball", true);
/* 137 */     gd.addMessage("");
/* 138 */     gd.addChoice("Surface area method:", surfaceAreaMethods, surfaceAreaMethods[1]);
/* 139 */     gd.addChoice("Euler Connectivity:", connectivityNames, connectivityNames[1]);
/* 140 */     gd.showDialog();
/*     */ 
/*     */     
/* 143 */     if (gd.wasCanceled()) {
/*     */       return;
/*     */     }
/*     */     
/* 147 */     this.computeVolume = gd.getNextBoolean();
/* 148 */     this.computeSurface = gd.getNextBoolean();
/* 149 */     this.computeSphericity = gd.getNextBoolean() & this.computeVolume & this.computeSurface;
/* 150 */     this.computeEulerNumber = gd.getNextBoolean();
/* 151 */     this.computeEllipsoid = gd.getNextBoolean();
/* 152 */     this.computeElongations = gd.getNextBoolean() & this.computeEllipsoid;
/* 153 */     this.computeInscribedBall = gd.getNextBoolean();
/*     */ 
/*     */ 
/*     */     
/* 157 */     this.surfaceAreaDirs = dirNumbers[gd.getNextChoiceIndex()];
/* 158 */     this.connectivity = connectivityValues[gd.getNextChoiceIndex()];
/*     */ 
/*     */     
/* 161 */     ResultsTable table = process(imagePlus);
/*     */ 
/*     */     
/* 164 */     String tableName = String.valueOf(imagePlus.getShortTitle()) + "-morpho";
/*     */ 
/*     */     
/* 167 */     table.show(tableName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResultsTable process(ImagePlus imagePlus) {
/* 180 */     if (imagePlus == null) {
/* 181 */       return null;
/*     */     }
/*     */     
/* 184 */     ImageStack image = imagePlus.getStack();
/* 185 */     Calibration calib = imagePlus.getCalibration();
/*     */     
/* 187 */     return process(image, calib);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResultsTable process(ImageStack image, Calibration calib) {
/* 202 */     double[] resol = { 1.0D, 1.0D, 1.0D };
/* 203 */     if (calib != null && calib.scaled()) {
/*     */       
/* 205 */       resol[0] = calib.pixelWidth;
/* 206 */       resol[1] = calib.pixelHeight;
/* 207 */       resol[2] = calib.pixelDepth;
/*     */     } 
/*     */ 
/*     */     
/* 211 */     double[] volumes = null;
/* 212 */     double[] surfaces = null;
/* 213 */     double[] eulerNumbers = null;
/* 214 */     double[] sphericities = null;
/* 215 */     Ellipsoid[] ellipsoids = null;
/* 216 */     double[][] elongations = null;
/* 217 */     Sphere[] inscribedBalls = null;
/*     */ 
/*     */ 
/*     */     
/* 221 */     int[] labels = LabelImages.findAllLabels(image);
/*     */ 
/*     */ 
/*     */     
/* 225 */     if (this.computeVolume)
/*     */     {
/* 227 */       volumes = IntrinsicVolumes3D.volumes(image, labels, calib);
/*     */     }
/* 229 */     if (this.computeSurface)
/*     */     {
/* 231 */       surfaces = IntrinsicVolumes3D.surfaceAreas(image, labels, calib, this.surfaceAreaDirs);
/*     */     }
/* 233 */     if (this.computeEulerNumber)
/*     */     {
/* 235 */       eulerNumbers = IntrinsicVolumes3D.eulerNumbers(image, labels, this.connectivity);
/*     */     }
/* 237 */     if (this.computeSphericity)
/*     */     {
/* 239 */       sphericities = IntrinsicVolumes3D.sphericity(volumes, surfaces);
/*     */     }
/*     */ 
/*     */     
/* 243 */     if (this.computeEllipsoid)
/*     */     {
/* 245 */       ellipsoids = EquivalentEllipsoid.equivalentEllipsoids(image, labels, calib);
/*     */     }
/* 247 */     if (this.computeElongations)
/*     */     {
/* 249 */       elongations = Ellipsoid.elongations(ellipsoids);
/*     */     }
/*     */ 
/*     */     
/* 253 */     if (this.computeInscribedBall)
/*     */     {
/* 255 */       inscribedBalls = LargestInscribedBall.largestInscribedBalls(image, labels, calib);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 260 */     ResultsTable table = new ResultsTable();
/* 261 */     for (int i = 0; i < labels.length; i++) {
/*     */       
/* 263 */       table.incrementCounter();
/* 264 */       table.addLabel(Integer.toString(labels[i]));
/*     */ 
/*     */       
/* 267 */       if (this.computeVolume)
/* 268 */         table.addValue("Volume", volumes[i]); 
/* 269 */       if (this.computeSurface)
/* 270 */         table.addValue("SurfaceArea", surfaces[i]); 
/* 271 */       if (this.computeSphericity)
/* 272 */         table.addValue("Sphericity", sphericities[i]); 
/* 273 */       if (this.computeEulerNumber) {
/* 274 */         table.addValue("EulerNumber", eulerNumbers[i]);
/*     */       }
/*     */       
/* 277 */       if (this.computeEllipsoid) {
/*     */ 
/*     */         
/* 280 */         Ellipsoid elli = ellipsoids[i];
/* 281 */         Point3D center = elli.center();
/* 282 */         table.addValue("Elli.Center.X", center.getX());
/* 283 */         table.addValue("Elli.Center.Y", center.getY());
/* 284 */         table.addValue("Elli.Center.Z", center.getZ());
/*     */         
/* 286 */         table.addValue("Elli.R1", elli.radius1());
/* 287 */         table.addValue("Elli.R2", elli.radius2());
/* 288 */         table.addValue("Elli.R3", elli.radius3());
/*     */         
/* 290 */         table.addValue("Elli.Azim", elli.phi());
/* 291 */         table.addValue("Elli.Elev", elli.theta());
/* 292 */         table.addValue("Elli.Roll", elli.psi());
/*     */       } 
/* 294 */       if (this.computeElongations) {
/*     */         
/* 296 */         table.addValue("Elli.R1/R2", elongations[i][0]);
/* 297 */         table.addValue("Elli.R1/R3", elongations[i][1]);
/* 298 */         table.addValue("Elli.R2/R3", elongations[i][2]);
/*     */       } 
/*     */       
/* 301 */       if (this.computeInscribedBall) {
/*     */         
/* 303 */         Sphere ball = inscribedBalls[i];
/* 304 */         Point3D center = ball.center();
/*     */         
/* 306 */         table.addValue("InscrBall.Center.X", center.getX());
/* 307 */         table.addValue("InscrBall.Center.Y", center.getY());
/* 308 */         table.addValue("InscrBall.Center.Z", center.getZ());
/* 309 */         table.addValue("InscrBall.Radius", ball.radius());
/*     */       } 
/*     */     } 
/*     */     
/* 313 */     return table;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/plugins/ParticleAnalysis3DPlugin.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */