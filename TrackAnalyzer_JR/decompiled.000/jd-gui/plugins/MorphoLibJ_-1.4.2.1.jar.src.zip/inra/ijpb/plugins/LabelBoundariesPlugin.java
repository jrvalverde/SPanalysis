/*    */ package inra.ijpb.plugins;
/*    */ 
/*    */ import ij.IJ;
/*    */ import ij.ImagePlus;
/*    */ import ij.ImageStack;
/*    */ import ij.plugin.PlugIn;
/*    */ import ij.process.ImageProcessor;
/*    */ import inra.ijpb.label.LabelImages;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LabelBoundariesPlugin
/*    */   implements PlugIn
/*    */ {
/*    */   public void run(String arg0) {
/* 42 */     ImagePlus resultPlus, imagePlus = IJ.getImage();
/*    */     
/* 44 */     ImageStack stack = imagePlus.getStack();
/*    */ 
/*    */     
/* 47 */     if (stack.getSize() > 1) {
/*    */       
/* 49 */       ImageStack boundaries = LabelImages.labelBoundaries(stack);
/*    */       
/* 51 */       String newName = String.valueOf(imagePlus.getShortTitle()) + "-bnd";
/* 52 */       resultPlus = new ImagePlus(newName, boundaries);
/*    */     }
/*    */     else {
/*    */       
/* 56 */       ImageProcessor boundaries = LabelImages.labelBoundaries(
/* 57 */           stack.getProcessor(1));
/*    */       
/* 59 */       String newName = String.valueOf(imagePlus.getShortTitle()) + "-bnd";
/* 60 */       resultPlus = new ImagePlus(newName, boundaries);
/*    */     } 
/*    */     
/* 63 */     resultPlus.copyScale(imagePlus);
/*    */ 
/*    */     
/* 66 */     resultPlus.show();
/* 67 */     if (imagePlus.getStackSize() > 1) {
/* 68 */       resultPlus.setZ(imagePlus.getZ());
/* 69 */       resultPlus.setSlice(imagePlus.getCurrentSlice());
/*    */     } 
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/plugins/LabelBoundariesPlugin.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */