/*     */ package inra.ijpb.plugins;
/*     */ 
/*     */ import ij.IJ;
/*     */ import ij.ImagePlus;
/*     */ import ij.gui.GenericDialog;
/*     */ import ij.plugin.PlugIn;
/*     */ import inra.ijpb.label.select.LabelSizeFiltering;
/*     */ import inra.ijpb.label.select.RelationalOperator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LabelSizeFilteringPlugin
/*     */   implements PlugIn
/*     */ {
/*     */   public enum Operation
/*     */   {
/*  44 */     GT("Greater_Than", RelationalOperator.GT),
/*  45 */     LT("Lower_Than", RelationalOperator.LT),
/*  46 */     GE("Greater_Than_Or_Equal", RelationalOperator.GE),
/*  47 */     LE("Lower_Than_Or_Equal", RelationalOperator.LE),
/*  48 */     EQ("Equal", RelationalOperator.EQ),
/*  49 */     NE("Not_Equal", RelationalOperator.NE);
/*     */ 
/*     */     
/*     */     private final String label;
/*     */ 
/*     */     
/*     */     private final RelationalOperator operator;
/*     */ 
/*     */     
/*     */     Operation(String label, RelationalOperator operator) {
/*  59 */       this.label = label;
/*  60 */       this.operator = operator;
/*     */     }
/*     */ 
/*     */     
/*     */     public ImagePlus applyTo(ImagePlus image, int sizeLimit) {
/*  65 */       LabelSizeFiltering algo = new LabelSizeFiltering(this.operator, sizeLimit);
/*  66 */       return algo.process(image);
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/*  71 */       return this.label;
/*     */     }
/*     */ 
/*     */     
/*     */     public static String[] getAllLabels() {
/*  76 */       int n = (values()).length;
/*  77 */       String[] result = new String[n];
/*     */       
/*  79 */       int i = 0; byte b; int j; Operation[] arrayOfOperation;
/*  80 */       for (j = (arrayOfOperation = values()).length, b = 0; b < j; ) { Operation op = arrayOfOperation[b];
/*  81 */         result[i++] = op.label; b++; }
/*     */       
/*  83 */       return result;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static Operation fromLabel(String opLabel) {
/*  97 */       if (opLabel != null)
/*  98 */         opLabel = opLabel.toLowerCase();  byte b; int i; Operation[] arrayOfOperation;
/*  99 */       for (i = (arrayOfOperation = values()).length, b = 0; b < i; ) { Operation op = arrayOfOperation[b];
/* 100 */         String cmp = op.label.toLowerCase();
/* 101 */         if (cmp.equals(opLabel))
/* 102 */           return op;  b++; }
/*     */       
/* 104 */       throw new IllegalArgumentException("Unable to parse Operation with label: " + opLabel);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void run(String args) {
/* 111 */     ImagePlus imagePlus = IJ.getImage();
/*     */ 
/*     */     
/* 114 */     boolean isPlanar = (imagePlus.getStackSize() == 1);
/*     */ 
/*     */     
/* 117 */     String title = "Label Size Filtering";
/* 118 */     GenericDialog gd = new GenericDialog(title);
/* 119 */     gd.addChoice("Operation", 
/* 120 */         Operation.getAllLabels(), 
/* 121 */         Operation.GT.label);
/* 122 */     String label = isPlanar ? "Size Limit (pixels):" : "Size Limit (voxels)";
/* 123 */     gd.addNumericField(label, 100.0D, 0);
/* 124 */     gd.showDialog();
/*     */ 
/*     */     
/* 127 */     if (gd.wasCanceled()) {
/*     */       return;
/*     */     }
/* 130 */     Operation op = Operation.fromLabel(gd.getNextChoice());
/* 131 */     int sizeLimit = (int)gd.getNextNumber();
/*     */ 
/*     */     
/* 134 */     ImagePlus resultPlus = op.applyTo(imagePlus, sizeLimit);
/*     */ 
/*     */     
/* 137 */     resultPlus.copyScale(imagePlus);
/* 138 */     resultPlus.setDisplayRange(imagePlus.getDisplayRangeMin(), imagePlus.getDisplayRangeMax());
/* 139 */     resultPlus.setLut(imagePlus.getProcessor().getLut());
/*     */ 
/*     */     
/* 142 */     resultPlus.show();
/* 143 */     if (imagePlus.getStackSize() > 1) {
/*     */       
/* 145 */       resultPlus.setZ(imagePlus.getZ());
/* 146 */       resultPlus.setSlice(imagePlus.getCurrentSlice());
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/plugins/LabelSizeFilteringPlugin.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */