/*     */ package inra.ijpb.plugins;
/*     */ 
/*     */ import ij.IJ;
/*     */ import ij.ImagePlus;
/*     */ import ij.WindowManager;
/*     */ import ij.gui.GenericDialog;
/*     */ import ij.plugin.PlugIn;
/*     */ import ij.process.ImageProcessor;
/*     */ import inra.ijpb.morphology.MinimaAndMaxima;
/*     */ import inra.ijpb.util.IJUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ImposeMinAndMaxPlugin
/*     */   implements PlugIn
/*     */ {
/*     */   public enum Operation
/*     */   {
/*  43 */     IMPOSE_MINIMA("Impose Minima"),
/*  44 */     IMPOSE_MAXIMA("Impose Maxima");
/*     */     
/*     */     private final String label;
/*     */     
/*     */     Operation(String label) {
/*  49 */       this.label = label;
/*     */     }
/*     */ 
/*     */     
/*     */     public ImageProcessor applyTo(ImageProcessor image, ImageProcessor markers) {
/*  54 */       if (this == IMPOSE_MINIMA)
/*  55 */         return MinimaAndMaxima.imposeMinima(image, markers); 
/*  56 */       if (this == IMPOSE_MAXIMA) {
/*  57 */         return MinimaAndMaxima.imposeMaxima(image, markers);
/*     */       }
/*  59 */       throw new RuntimeException(
/*  60 */           "Unable to process the " + this + " operation");
/*     */     }
/*     */ 
/*     */     
/*     */     public ImageProcessor applyTo(ImageProcessor image, ImageProcessor markers, int conn) {
/*  65 */       if (this == IMPOSE_MINIMA)
/*  66 */         return MinimaAndMaxima.imposeMinima(image, markers, conn); 
/*  67 */       if (this == IMPOSE_MAXIMA) {
/*  68 */         return MinimaAndMaxima.imposeMaxima(image, markers, conn);
/*     */       }
/*  70 */       throw new RuntimeException(
/*  71 */           "Unable to process the " + this + " operation");
/*     */     }
/*     */     
/*     */     public String toString() {
/*  75 */       return this.label;
/*     */     }
/*     */     
/*     */     public static String[] getAllLabels() {
/*  79 */       int n = (values()).length;
/*  80 */       String[] result = new String[n];
/*     */       
/*  82 */       int i = 0; byte b; int j; Operation[] arrayOfOperation;
/*  83 */       for (j = (arrayOfOperation = values()).length, b = 0; b < j; ) { Operation op = arrayOfOperation[b];
/*  84 */         result[i++] = op.label; b++; }
/*     */       
/*  86 */       return result;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static Operation fromLabel(String opLabel) {
/*  99 */       if (opLabel != null)
/* 100 */         opLabel = opLabel.toLowerCase();  byte b; int i; Operation[] arrayOfOperation;
/* 101 */       for (i = (arrayOfOperation = values()).length, b = 0; b < i; ) { Operation op = arrayOfOperation[b];
/* 102 */         String cmp = op.label.toLowerCase();
/* 103 */         if (cmp.equals(opLabel))
/* 104 */           return op;  b++; }
/*     */       
/* 106 */       throw new IllegalArgumentException("Unable to parse Operation with label: " + opLabel);
/*     */     }
/*     */   }
/*     */   
/* 110 */   private static final String[] connectivityLabels = new String[] { "4", "8" };
/* 111 */   private static final int[] connectivityValues = new int[] { 4, 8 };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void run(String arg) {
/* 122 */     int[] indices = WindowManager.getIDList();
/* 123 */     if (indices == null) {
/* 124 */       IJ.error("No image", "Need at least one image to work");
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 129 */     String[] imageNames = new String[indices.length];
/* 130 */     for (int i = 0; i < indices.length; i++) {
/* 131 */       imageNames[i] = WindowManager.getImage(indices[i]).getTitle();
/*     */     }
/*     */ 
/*     */     
/* 135 */     GenericDialog gd = new GenericDialog("Impose Min & Max");
/*     */     
/* 137 */     gd.addChoice("Original Image", imageNames, IJ.getImage().getTitle());
/* 138 */     gd.addChoice("Marker Image", imageNames, IJ.getImage().getTitle());
/* 139 */     gd.addChoice("Operation", 
/* 140 */         Operation.getAllLabels(), 
/* 141 */         Operation.IMPOSE_MINIMA.label);
/* 142 */     gd.addChoice("Connectivity", connectivityLabels, connectivityLabels[0]);
/* 143 */     gd.showDialog();
/*     */     
/* 145 */     if (gd.wasCanceled()) {
/*     */       return;
/*     */     }
/*     */     
/* 149 */     int refImageIndex = gd.getNextChoiceIndex();
/* 150 */     ImagePlus refImage = WindowManager.getImage(refImageIndex + 1);
/* 151 */     int markerImageIndex = gd.getNextChoiceIndex();
/* 152 */     ImagePlus markerImage = WindowManager.getImage(markerImageIndex + 1);
/* 153 */     Operation op = Operation.fromLabel(gd.getNextChoice());
/* 154 */     int conn = connectivityValues[gd.getNextChoiceIndex()];
/*     */ 
/*     */     
/* 157 */     ImageProcessor refProc = refImage.getProcessor();
/* 158 */     ImageProcessor markerProc = markerImage.getProcessor();
/*     */     
/* 160 */     long t0 = System.currentTimeMillis();
/*     */ 
/*     */     
/* 163 */     ImageProcessor recProc = op.applyTo(refProc, markerProc, conn);
/*     */ 
/*     */     
/* 166 */     recProc.setColorModel(refProc.getColorModel());
/*     */ 
/*     */     
/* 169 */     String newName = createResultImageName(refImage);
/* 170 */     ImagePlus resultImage = new ImagePlus(newName, recProc);
/* 171 */     resultImage.copyScale(markerImage);
/* 172 */     resultImage.show();
/*     */     
/* 174 */     long t1 = System.currentTimeMillis();
/* 175 */     IJ.showStatus("Elapsed time: " + ((t1 - t0) / 1000.0D) + "s");
/* 176 */     IJUtils.showElapsedTime(op.toString(), (t1 - t0), refImage);
/*     */   }
/*     */   
/*     */   private static String createResultImageName(ImagePlus baseImage) {
/* 180 */     return String.valueOf(baseImage.getShortTitle()) + "-imp";
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/plugins/ImposeMinAndMaxPlugin.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */