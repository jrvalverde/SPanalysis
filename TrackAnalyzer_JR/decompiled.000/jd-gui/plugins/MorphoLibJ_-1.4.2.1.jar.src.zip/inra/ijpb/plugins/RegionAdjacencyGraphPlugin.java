/*     */ package inra.ijpb.plugins;
/*     */ 
/*     */ import ij.IJ;
/*     */ import ij.ImagePlus;
/*     */ import ij.WindowManager;
/*     */ import ij.gui.GenericDialog;
/*     */ import ij.gui.Line;
/*     */ import ij.gui.Overlay;
/*     */ import ij.gui.Roi;
/*     */ import ij.measure.ResultsTable;
/*     */ import ij.plugin.PlugIn;
/*     */ import ij.process.ImageProcessor;
/*     */ import inra.ijpb.label.LabelImages;
/*     */ import inra.ijpb.label.RegionAdjacencyGraph;
/*     */ import inra.ijpb.measure.region2d.Centroid;
/*     */ import java.awt.Color;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RegionAdjacencyGraphPlugin
/*     */   implements PlugIn
/*     */ {
/*     */   public void run(String arg0) {
/*  56 */     ImagePlus imagePlus = IJ.getImage();
/*     */     
/*  58 */     boolean isPlanar = (imagePlus.getStackSize() == 1);
/*  59 */     boolean showRAG = false;
/*  60 */     ImagePlus targetPlus = imagePlus;
/*     */     
/*  62 */     if (isPlanar) {
/*     */ 
/*     */       
/*  65 */       int[] indices = WindowManager.getIDList();
/*  66 */       String[] imageNames = new String[indices.length];
/*  67 */       for (int i = 0; i < indices.length; i++)
/*     */       {
/*  69 */         imageNames[i] = WindowManager.getImage(indices[i]).getTitle();
/*     */       }
/*     */ 
/*     */       
/*  73 */       String selectedImageName = IJ.getImage().getTitle();
/*     */       
/*  75 */       GenericDialog gd = new GenericDialog("Region Adjacency Graph");
/*  76 */       gd.addCheckbox("Show RAG", true);
/*  77 */       gd.addChoice("Image to overlay", imageNames, selectedImageName);
/*     */       
/*  79 */       gd.showDialog();
/*  80 */       if (gd.wasCanceled()) {
/*     */         return;
/*     */       }
/*     */ 
/*     */       
/*  85 */       showRAG = gd.getNextBoolean();
/*  86 */       int targetImageIndex = gd.getNextChoiceIndex();
/*  87 */       targetPlus = WindowManager.getImage(indices[targetImageIndex]);
/*     */     } 
/*     */     
/*  90 */     Set<RegionAdjacencyGraph.LabelPair> adjList = RegionAdjacencyGraph.computeAdjacencies(imagePlus);
/*     */     
/*  92 */     if (showRAG)
/*     */     {
/*  94 */       overlayRAG(adjList, imagePlus, targetPlus);
/*     */     }
/*     */     
/*  97 */     ResultsTable table = createTable(adjList);
/*  98 */     String newName = String.valueOf(imagePlus.getShortTitle()) + "-RAG";
/*  99 */     table.show(newName);
/*     */   }
/*     */ 
/*     */   
/*     */   private void overlayRAG(Set<RegionAdjacencyGraph.LabelPair> adjList, ImagePlus imagePlus, ImagePlus targetPlus) {
/* 104 */     IJ.log("display RAG");
/*     */ 
/*     */     
/* 107 */     ImageProcessor image = imagePlus.getProcessor();
/* 108 */     int[] labels = LabelImages.findAllLabels(image);
/* 109 */     Map<Integer, Integer> labelMap = LabelImages.mapLabelIndices(labels);
/* 110 */     double[][] centroids = Centroid.centroids(image, labels);
/*     */ 
/*     */     
/* 113 */     Overlay overlay = new Overlay();
/*     */ 
/*     */     
/* 116 */     for (RegionAdjacencyGraph.LabelPair pair : adjList) {
/*     */ 
/*     */       
/* 119 */       int ind1 = ((Integer)labelMap.get(Integer.valueOf(pair.label1))).intValue();
/* 120 */       int ind2 = ((Integer)labelMap.get(Integer.valueOf(pair.label2))).intValue();
/*     */ 
/*     */       
/* 123 */       int x1 = (int)centroids[ind1][0];
/* 124 */       int y1 = (int)centroids[ind1][1];
/* 125 */       int x2 = (int)centroids[ind2][0];
/* 126 */       int y2 = (int)centroids[ind2][1];
/*     */ 
/*     */       
/* 129 */       Line line = new Line(x1, y1, x2, y2);
/*     */       
/* 131 */       line.setStrokeColor(Color.GREEN);
/* 132 */       line.setStrokeWidth(2.0F);
/* 133 */       overlay.add((Roi)line);
/*     */     } 
/*     */     
/* 136 */     targetPlus.setOverlay(overlay);
/*     */   }
/*     */ 
/*     */   
/*     */   private ResultsTable createTable(Set<RegionAdjacencyGraph.LabelPair> adjList) {
/* 141 */     ResultsTable table = new ResultsTable();
/* 142 */     table.setPrecision(0);
/*     */ 
/*     */     
/* 145 */     for (RegionAdjacencyGraph.LabelPair pair : adjList) {
/*     */       
/* 147 */       table.incrementCounter();
/* 148 */       table.addValue("Label 1", pair.label1);
/* 149 */       table.addValue("Label 2", pair.label2);
/*     */     } 
/*     */     
/* 152 */     return table;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/plugins/RegionAdjacencyGraphPlugin.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */