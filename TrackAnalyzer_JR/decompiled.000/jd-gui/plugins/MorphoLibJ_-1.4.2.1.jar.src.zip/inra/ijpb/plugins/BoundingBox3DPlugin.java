/*    */ package inra.ijpb.plugins;
/*    */ 
/*    */ import ij.IJ;
/*    */ import ij.ImagePlus;
/*    */ import ij.measure.ResultsTable;
/*    */ import ij.plugin.PlugIn;
/*    */ import inra.ijpb.measure.region3d.BoundingBox3D;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BoundingBox3DPlugin
/*    */   implements PlugIn
/*    */ {
/*    */   public void run(String args) {
/* 47 */     ImagePlus imagePlus = IJ.getImage();
/*    */     
/* 49 */     if (imagePlus.getStackSize() == 1) {
/* 50 */       IJ.error("Requires a Stack");
/*    */       
/*    */       return;
/*    */     } 
/*    */     
/* 55 */     ResultsTable table = (new BoundingBox3D()).computeTable(imagePlus);
/*    */ 
/*    */     
/* 58 */     String tableName = String.valueOf(imagePlus.getShortTitle()) + "-bbox";
/*    */ 
/*    */     
/* 61 */     table.show(tableName);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/plugins/BoundingBox3DPlugin.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */