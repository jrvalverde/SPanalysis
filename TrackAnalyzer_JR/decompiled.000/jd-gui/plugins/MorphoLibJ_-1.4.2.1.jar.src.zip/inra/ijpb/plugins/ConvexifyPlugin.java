/*    */ package inra.ijpb.plugins;
/*    */ 
/*    */ import ij.IJ;
/*    */ import ij.ImagePlus;
/*    */ import ij.plugin.PlugIn;
/*    */ import ij.process.ImageProcessor;
/*    */ import inra.ijpb.measure.region2d.Convexity;
/*    */ import inra.ijpb.util.IJUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ConvexifyPlugin
/*    */   implements PlugIn
/*    */ {
/*    */   public void run(String arg0) {
/* 43 */     ImagePlus imagePlus = IJ.getImage();
/*    */ 
/*    */ 
/*    */     
/* 47 */     if (imagePlus.getStackSize() > 1) {
/*    */       
/* 49 */       IJ.showMessage("Invalid Input", "Requires a binary 2D image as input");
/*    */       return;
/*    */     } 
/* 52 */     ImageProcessor image = imagePlus.getProcessor();
/* 53 */     if (image instanceof ij.process.ColorProcessor) {
/*    */       
/* 55 */       IJ.showMessage("Invalid Input", "Requires a binary 2D image as input");
/*    */       
/*    */       return;
/*    */     } 
/*    */     
/* 60 */     long t0 = System.currentTimeMillis();
/* 61 */     ImageProcessor result = Convexity.convexify(image);
/* 62 */     long elapsedTime = System.currentTimeMillis() - t0;
/*    */ 
/*    */     
/* 65 */     result.setLut(image.getLut());
/* 66 */     String newName = String.valueOf(imagePlus.getShortTitle()) + "-convex";
/* 67 */     ImagePlus resultPlus = new ImagePlus(newName, result);
/*    */     
/* 69 */     resultPlus.copyScale(imagePlus);
/* 70 */     resultPlus.show();
/*    */ 
/*    */     
/* 73 */     IJUtils.showElapsedTime("Convexify", elapsedTime, imagePlus);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/plugins/ConvexifyPlugin.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */