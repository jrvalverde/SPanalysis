/*     */ package inra.ijpb.plugins;
/*     */ 
/*     */ import ij.IJ;
/*     */ import ij.ImagePlus;
/*     */ import ij.ImageStack;
/*     */ import ij.gui.GenericDialog;
/*     */ import ij.plugin.PlugIn;
/*     */ import inra.ijpb.morphology.MinimaAndMaxima3D;
/*     */ import inra.ijpb.util.IJUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ExtendedMinAndMax3DPlugin
/*     */   implements PlugIn
/*     */ {
/*     */   public enum Operation
/*     */   {
/*  48 */     EXTENDED_MAXIMA("Extended Maxima", "emax"),
/*  49 */     EXTENDED_MINIMA("Extended Minima", "emin");
/*     */     
/*     */     private final String label;
/*     */     private final String suffix;
/*     */     
/*     */     Operation(String label, String suffix) {
/*  55 */       this.label = label;
/*  56 */       this.suffix = suffix;
/*     */     }
/*     */     
/*     */     public ImageStack apply(ImageStack image, int dynamic) {
/*  60 */       if (this == EXTENDED_MAXIMA)
/*  61 */         return MinimaAndMaxima3D.extendedMaxima(image, dynamic); 
/*  62 */       if (this == EXTENDED_MINIMA) {
/*  63 */         return MinimaAndMaxima3D.extendedMinima(image, dynamic);
/*     */       }
/*  65 */       throw new RuntimeException(
/*  66 */           "Unable to process the " + this + " morphological operation");
/*     */     }
/*     */     
/*     */     public ImageStack apply(ImageStack image, int dynamic, int connectivity) {
/*  70 */       if (this == EXTENDED_MAXIMA)
/*  71 */         return MinimaAndMaxima3D.extendedMaxima(image, dynamic, connectivity); 
/*  72 */       if (this == EXTENDED_MINIMA) {
/*  73 */         return MinimaAndMaxima3D.extendedMinima(image, dynamic, connectivity);
/*     */       }
/*  75 */       throw new RuntimeException(
/*  76 */           "Unable to process the " + this + " morphological operation");
/*     */     }
/*     */     
/*     */     public String toString() {
/*  80 */       return this.label;
/*     */     }
/*     */     
/*     */     public String getSuffix() {
/*  84 */       return this.suffix;
/*     */     }
/*     */     
/*     */     public static String[] getAllLabels() {
/*  88 */       int n = (values()).length;
/*  89 */       String[] result = new String[n];
/*     */       
/*  91 */       int i = 0; byte b; int j; Operation[] arrayOfOperation;
/*  92 */       for (j = (arrayOfOperation = values()).length, b = 0; b < j; ) { Operation op = arrayOfOperation[b];
/*  93 */         result[i++] = op.label; b++; }
/*     */       
/*  95 */       return result;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static Operation fromLabel(String opLabel) {
/* 108 */       if (opLabel != null)
/* 109 */         opLabel = opLabel.toLowerCase();  byte b; int i; Operation[] arrayOfOperation;
/* 110 */       for (i = (arrayOfOperation = values()).length, b = 0; b < i; ) { Operation op = arrayOfOperation[b];
/* 111 */         String cmp = op.label.toLowerCase();
/* 112 */         if (cmp.equals(opLabel))
/* 113 */           return op;  b++; }
/*     */       
/* 115 */       throw new IllegalArgumentException("Unable to parse Operation with label: " + opLabel);
/*     */     }
/*     */   }
/*     */   
/* 119 */   private static final String[] connectivityLabels = new String[] { "6", "26" };
/* 120 */   private static final int[] connectivityValues = new int[] { 6, 26 };
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void run(String arg) {
/*     */     double minValue, maxValue;
/* 127 */     if (IJ.getVersion().compareTo("1.48a") < 0) {
/*     */       
/* 129 */       IJ.error("Regional Minima and Maxima", "ERROR: detected ImageJ version " + IJ.getVersion() + 
/* 130 */           ".\nThis plugin requires version 1.48a or superior, please update ImageJ!");
/*     */       
/*     */       return;
/*     */     } 
/* 134 */     ImagePlus imagePlus = IJ.getImage();
/*     */     
/* 136 */     if (imagePlus.getStackSize() == 1) {
/* 137 */       IJ.error("Requires a Stack");
/*     */       
/*     */       return;
/*     */     } 
/* 141 */     ImageStack stack = imagePlus.getStack();
/* 142 */     int sizeX = stack.getWidth();
/* 143 */     int sizeY = stack.getHeight();
/* 144 */     int sizeZ = stack.getSize();
/* 145 */     boolean isGray8 = (stack.getBitDepth() == 8);
/*     */     
/* 147 */     if (isGray8) {
/* 148 */       minValue = 1.0D;
/* 149 */       maxValue = 255.0D;
/*     */     } else {
/* 151 */       minValue = Double.MAX_VALUE;
/* 152 */       maxValue = Double.MIN_VALUE;
/* 153 */       for (int z = 0; z < sizeZ; z++) {
/* 154 */         for (int y = 0; y < sizeY; y++) {
/* 155 */           for (int x = 0; x < sizeX; x++) {
/* 156 */             double val = stack.getVoxel(x, y, z);
/* 157 */             minValue = Math.min(minValue, val);
/* 158 */             maxValue = Math.max(maxValue, val);
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 165 */     GenericDialog gd = new GenericDialog("Extended Min & Max 3D");
/* 166 */     gd.addChoice("Operation", Operation.getAllLabels(), 
/* 167 */         Operation.EXTENDED_MINIMA.label);
/* 168 */     gd.addSlider("Dynamic", minValue, maxValue, 10.0D);
/* 169 */     gd.addChoice("Connectivity", connectivityLabels, connectivityLabels[0]);
/*     */     
/* 171 */     gd.showDialog();
/* 172 */     if (gd.wasCanceled()) {
/*     */       return;
/*     */     }
/* 175 */     long t0 = System.currentTimeMillis();
/*     */ 
/*     */     
/* 178 */     Operation op = Operation.fromLabel(gd.getNextChoice());
/* 179 */     int dynamic = (int)gd.getNextNumber();
/* 180 */     int conn = connectivityValues[gd.getNextChoiceIndex()];
/*     */     
/* 182 */     ImageStack result = op.apply(stack, dynamic, conn);
/*     */     
/* 184 */     String newName = createResultImageName(imagePlus, op);
/* 185 */     ImagePlus resultPlus = new ImagePlus(newName, result);
/* 186 */     resultPlus.copyScale(imagePlus);
/*     */     
/* 188 */     resultPlus.show();
/*     */     
/* 190 */     resultPlus.setSlice(imagePlus.getCurrentSlice());
/*     */     
/* 192 */     long t1 = System.currentTimeMillis();
/* 193 */     IJUtils.showElapsedTime(op.toString(), (t1 - t0), imagePlus);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String createResultImageName(ImagePlus baseImage, Operation op) {
/* 201 */     return String.valueOf(baseImage.getShortTitle()) + "-" + op.getSuffix();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/plugins/ExtendedMinAndMax3DPlugin.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */