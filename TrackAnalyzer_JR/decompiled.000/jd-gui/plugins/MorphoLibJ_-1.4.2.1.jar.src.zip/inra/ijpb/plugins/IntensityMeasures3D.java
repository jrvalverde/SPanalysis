/*     */ package inra.ijpb.plugins;
/*     */ 
/*     */ import ij.IJ;
/*     */ import ij.ImagePlus;
/*     */ import ij.WindowManager;
/*     */ import ij.gui.GenericDialog;
/*     */ import ij.plugin.PlugIn;
/*     */ import inra.ijpb.measure.IntensityMeasures;
/*     */ import inra.ijpb.measure.ResultsBuilder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IntensityMeasures3D
/*     */   implements PlugIn
/*     */ {
/*  41 */   static int inputIndex = 0;
/*  42 */   static int labelsIndex = 1;
/*  43 */   static String[] measureLabels = new String[] { "Mean", "StdDev", "Max", 
/*  44 */       "Min", "Median", "Mode", "Skewness", "Kurtosis", 
/*  45 */       "NumberOfVoxels", "Volume", "NeighborsMean", "NeighborsStdDev", 
/*  46 */       "NeighborsMax", "NeighborsMin", "NeighborsMedian", 
/*  47 */       "NeighborsMode", "NeighborsSkewness", "NeighborsKurtosis" };
/*     */   
/*  49 */   static boolean[] measureStates = new boolean[] { 
/*     */       true, true, true, true, true, true, true, true, true, true, 
/*     */       true, true, true, true, true, true, true, true };
/*     */ 
/*     */ 
/*     */   
/*     */   public void run(String arg) {
/*  56 */     int nbima = WindowManager.getImageCount();
/*     */     
/*  58 */     if (nbima < 2) {
/*     */       
/*  60 */       IJ.error("Intensity Measures 2D/3D input error", 
/*  61 */           "ERROR: At least two images need to be open to run Intensity Measures 2D/3D");
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/*  66 */     String[] names = new String[nbima];
/*     */     
/*  68 */     for (int i = 0; i < nbima; i++) {
/*  69 */       names[i] = WindowManager.getImage(i + 1).getShortTitle();
/*     */     }
/*  71 */     if (inputIndex > nbima - 1)
/*  72 */       inputIndex = nbima - 1; 
/*  73 */     if (labelsIndex > nbima - 1) {
/*  74 */       labelsIndex = nbima - 1;
/*     */     }
/*  76 */     GenericDialog gd = new GenericDialog("Intensity Measurements 2D/3D");
/*  77 */     gd.addChoice("Input", names, names[inputIndex]);
/*  78 */     gd.addChoice("Labels", names, names[labelsIndex]);
/*  79 */     gd.addMessage("Measurements:");
/*  80 */     gd.addCheckboxGroup(measureLabels.length / 2 + 1, 2, measureLabels, 
/*  81 */         measureStates);
/*     */     
/*  83 */     gd.showDialog();
/*     */     
/*  85 */     if (gd.wasOKed()) {
/*     */       
/*  87 */       inputIndex = gd.getNextChoiceIndex();
/*  88 */       labelsIndex = gd.getNextChoiceIndex();
/*     */       
/*  90 */       for (int j = 0; j < measureStates.length; j++) {
/*  91 */         measureStates[j] = gd.getNextBoolean();
/*     */       }
/*  93 */       boolean calculateMeasures = false;
/*  94 */       int numMeasures = 0;
/*  95 */       for (int k = 0; k < measureStates.length; k++) {
/*  96 */         if (measureStates[k]) {
/*     */           
/*  98 */           calculateMeasures = true;
/*  99 */           numMeasures++;
/*     */         } 
/*     */       } 
/* 102 */       if (!calculateMeasures) {
/*     */         return;
/*     */       }
/* 105 */       ImagePlus inputImage = WindowManager.getImage(inputIndex + 1);
/* 106 */       ImagePlus labelImage = WindowManager.getImage(labelsIndex + 1);
/*     */       
/* 108 */       if (inputImage.getWidth() != labelImage.getWidth() || 
/* 109 */         inputImage.getHeight() != labelImage.getHeight()) {
/*     */         
/* 111 */         IJ.error("Intensity Measures 2D/3D input error", "Error: input and label images must have the same size");
/*     */         
/*     */         return;
/*     */       } 
/*     */       
/* 116 */       ResultsBuilder rb = new ResultsBuilder();
/*     */       
/* 118 */       IntensityMeasures im = new IntensityMeasures(inputImage, labelImage);
/* 119 */       int calculated = 0;
/* 120 */       if (measureStates[0]) {
/*     */         
/* 122 */         IJ.showStatus("Calculating mean intensity...");
/* 123 */         IJ.showProgress(calculated, numMeasures);
/* 124 */         rb.addResult(im.getMean());
/* 125 */         calculated++;
/*     */       } 
/*     */       
/* 128 */       if (measureStates[1]) {
/*     */         
/* 130 */         IJ.showStatus("Calculating standard deviation of intensity...");
/* 131 */         IJ.showProgress(calculated, numMeasures);
/* 132 */         rb.addResult(im.getStdDev());
/* 133 */         calculated++;
/*     */       } 
/*     */       
/* 136 */       if (measureStates[2]) {
/*     */         
/* 138 */         IJ.showStatus("Calculating maximum intensity...");
/* 139 */         IJ.showProgress(calculated, numMeasures);
/* 140 */         rb.addResult(im.getMax());
/* 141 */         calculated++;
/*     */       } 
/*     */       
/* 144 */       if (measureStates[3]) {
/*     */         
/* 146 */         IJ.showStatus("Calculating minimum intensity...");
/* 147 */         IJ.showProgress(calculated, numMeasures);
/* 148 */         rb.addResult(im.getMin());
/* 149 */         calculated++;
/*     */       } 
/*     */       
/* 152 */       if (measureStates[4]) {
/*     */         
/* 154 */         IJ.showStatus("Calculating median intensity...");
/* 155 */         IJ.showProgress(calculated, numMeasures);
/* 156 */         rb.addResult(im.getMedian());
/* 157 */         calculated++;
/*     */       } 
/*     */       
/* 160 */       if (measureStates[5]) {
/*     */         
/* 162 */         IJ.showStatus("Calculating intensity mode...");
/* 163 */         IJ.showProgress(calculated, numMeasures);
/* 164 */         rb.addResult(im.getMode());
/* 165 */         calculated++;
/*     */       } 
/*     */       
/* 168 */       if (measureStates[6]) {
/*     */         
/* 170 */         IJ.showStatus("Calculating intensity skewness...");
/* 171 */         IJ.showProgress(calculated, numMeasures);
/* 172 */         rb.addResult(im.getSkewness());
/* 173 */         calculated++;
/*     */       } 
/*     */       
/* 176 */       if (measureStates[7]) {
/*     */         
/* 178 */         IJ.showStatus("Calculating minimum kurtosis...");
/* 179 */         IJ.showProgress(calculated, numMeasures);
/* 180 */         rb.addResult(im.getKurtosis());
/* 181 */         calculated++;
/*     */       } 
/*     */       
/* 184 */       if (measureStates[8]) {
/*     */         
/* 186 */         IJ.showStatus("Calculating number of pixels/voxels...");
/* 187 */         IJ.showProgress(calculated, numMeasures);
/* 188 */         rb.addResult(im.getNumberOfVoxels());
/* 189 */         calculated++;
/*     */       } 
/*     */       
/* 192 */       if (measureStates[9]) {
/*     */         
/* 194 */         IJ.showStatus("Calculating volume...");
/* 195 */         IJ.showProgress(calculated, numMeasures);
/* 196 */         rb.addResult(im.getVolume());
/* 197 */         calculated++;
/*     */       } 
/*     */       
/* 200 */       if (measureStates[10]) {
/*     */         
/* 202 */         IJ.showStatus("Calculating neighbors mean intensity...");
/* 203 */         IJ.showProgress(calculated, numMeasures);
/* 204 */         rb.addResult(im.getNeighborsMean());
/* 205 */         calculated++;
/*     */       } 
/*     */       
/* 208 */       if (measureStates[11]) {
/*     */         
/* 210 */         IJ.showStatus("Calculating neighbors standard deviation of intensity...");
/* 211 */         IJ.showProgress(calculated, numMeasures);
/* 212 */         rb.addResult(im.getNeighborsStdDev());
/* 213 */         calculated++;
/*     */       } 
/*     */       
/* 216 */       if (measureStates[12]) {
/*     */         
/* 218 */         IJ.showStatus("Calculating neighbors maximum intensity...");
/* 219 */         IJ.showProgress(calculated, numMeasures);
/* 220 */         rb.addResult(im.getNeighborsMax());
/* 221 */         calculated++;
/*     */       } 
/*     */       
/* 224 */       if (measureStates[13]) {
/*     */         
/* 226 */         IJ.showStatus("Calculating neighbors minimum intensity...");
/* 227 */         IJ.showProgress(calculated, numMeasures);
/* 228 */         rb.addResult(im.getNeighborsMin());
/*     */       } 
/*     */       
/* 231 */       if (measureStates[14]) {
/*     */         
/* 233 */         IJ.showStatus("Calculating neighbors median intensity...");
/* 234 */         IJ.showProgress(calculated, numMeasures);
/* 235 */         rb.addResult(im.getNeighborsMedian());
/* 236 */         calculated++;
/*     */       } 
/*     */       
/* 239 */       if (measureStates[15]) {
/*     */         
/* 241 */         IJ.showStatus("Calculating neighbors intensity mode...");
/* 242 */         IJ.showProgress(calculated, numMeasures);
/* 243 */         rb.addResult(im.getNeighborsMode());
/* 244 */         calculated++;
/*     */       } 
/*     */       
/* 247 */       if (measureStates[16]) {
/*     */         
/* 249 */         IJ.showStatus("Calculating neighbors intensity skewness...");
/* 250 */         IJ.showProgress(calculated, numMeasures);
/* 251 */         rb.addResult(im.getNeighborsSkewness());
/* 252 */         calculated++;
/*     */       } 
/*     */       
/* 255 */       if (measureStates[17]) {
/*     */         
/* 257 */         IJ.showStatus("Calculating neighbors intensity kurtosis...");
/* 258 */         IJ.showProgress(calculated, numMeasures);
/* 259 */         rb.addResult(im.getNeighborsKurtosis());
/* 260 */         calculated++;
/*     */       } 
/* 262 */       IJ.showStatus("Done");
/* 263 */       IJ.showProgress(calculated, numMeasures);
/*     */       
/* 265 */       rb.getResultsTable().show(String.valueOf(inputImage.getShortTitle()) + 
/* 266 */           "-intensity-measurements");
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/plugins/IntensityMeasures3D.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */