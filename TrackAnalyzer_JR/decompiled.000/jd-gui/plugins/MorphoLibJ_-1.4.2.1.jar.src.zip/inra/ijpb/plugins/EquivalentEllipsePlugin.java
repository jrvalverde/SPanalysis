/*     */ package inra.ijpb.plugins;
/*     */ 
/*     */ import ij.IJ;
/*     */ import ij.ImagePlus;
/*     */ import ij.WindowManager;
/*     */ import ij.gui.GenericDialog;
/*     */ import ij.gui.Line;
/*     */ import ij.gui.Overlay;
/*     */ import ij.gui.PolygonRoi;
/*     */ import ij.gui.Roi;
/*     */ import ij.measure.Calibration;
/*     */ import ij.measure.ResultsTable;
/*     */ import ij.plugin.PlugIn;
/*     */ import inra.ijpb.geometry.Ellipse;
/*     */ import inra.ijpb.label.LabelImages;
/*     */ import inra.ijpb.measure.region2d.EquivalentEllipse;
/*     */ import java.awt.Color;
/*     */ import java.awt.geom.Point2D;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EquivalentEllipsePlugin
/*     */   implements PlugIn
/*     */ {
/*     */   public void run(String args) {
/*  74 */     int[] indices = WindowManager.getIDList();
/*  75 */     if (indices == null) {
/*     */       
/*  77 */       IJ.error("No image", "Need at least one image to work");
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/*  82 */     String[] imageNames = new String[indices.length];
/*  83 */     for (int i = 0; i < indices.length; i++)
/*     */     {
/*  85 */       imageNames[i] = WindowManager.getImage(indices[i]).getTitle();
/*     */     }
/*     */ 
/*     */     
/*  89 */     String selectedImageName = IJ.getImage().getTitle();
/*     */ 
/*     */     
/*  92 */     GenericDialog gd = new GenericDialog("Equivalent Ellipse");
/*  93 */     gd.addChoice("Label Image:", imageNames, selectedImageName);
/*  94 */     gd.addCheckbox("Overlay Ellipse", true);
/*  95 */     gd.addCheckbox("Overlay Axes", true);
/*  96 */     gd.addChoice("Image to overlay:", imageNames, selectedImageName);
/*  97 */     gd.showDialog();
/*     */     
/*  99 */     if (gd.wasCanceled()) {
/*     */       return;
/*     */     }
/*     */     
/* 103 */     int labelImageIndex = gd.getNextChoiceIndex();
/* 104 */     ImagePlus labelImage = WindowManager.getImage(labelImageIndex + 1);
/* 105 */     boolean showEllipse = gd.getNextBoolean();
/* 106 */     boolean showAxes = gd.getNextBoolean();
/* 107 */     int resultImageIndex = gd.getNextChoiceIndex();
/*     */ 
/*     */     
/* 110 */     if (!LabelImages.isLabelImageType(labelImage)) {
/*     */       
/* 112 */       IJ.showMessage("Input image should be a label image");
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 117 */     EquivalentEllipse op = new EquivalentEllipse();
/* 118 */     Map<Integer, Ellipse> ellipses = op.analyzeRegions(labelImage);
/* 119 */     ResultsTable results = op.createTable(ellipses);
/*     */ 
/*     */     
/* 122 */     String tableName = String.valueOf(labelImage.getShortTitle()) + "-Ellipses";
/* 123 */     results.show(tableName);
/*     */ 
/*     */     
/* 126 */     if (showEllipse || showAxes) {
/*     */ 
/*     */       
/* 129 */       ImagePlus resultImage = WindowManager.getImage(resultImageIndex + 1);
/* 130 */       showResultsAsOverlay(ellipses, resultImage, showEllipse, showAxes);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void showResultsAsOverlay(Map<Integer, Ellipse> results, ImagePlus target, boolean showEllipse, boolean showAxes) {
/* 148 */     Calibration calib = target.getCalibration();
/*     */ 
/*     */     
/* 151 */     Overlay overlay = new Overlay();
/*     */ 
/*     */     
/* 154 */     for (Iterator<Integer> iterator = results.keySet().iterator(); iterator.hasNext(); ) { int label = ((Integer)iterator.next()).intValue();
/*     */ 
/*     */       
/* 157 */       Ellipse ellipse = results.get(Integer.valueOf(label));
/* 158 */       ellipse = uncalibrate(ellipse, calib);
/*     */ 
/*     */       
/* 161 */       if (showEllipse)
/*     */       {
/* 163 */         addRoiToOverlay(overlay, createRoi(ellipse), Color.BLUE);
/*     */       }
/*     */ 
/*     */       
/* 167 */       if (showAxes) {
/*     */         
/* 169 */         addRoiToOverlay(overlay, createMajorAxisRoi(ellipse), Color.BLUE);
/* 170 */         addRoiToOverlay(overlay, createMinorAxisRoi(ellipse), Color.BLUE);
/*     */       }  }
/*     */ 
/*     */     
/* 174 */     target.setOverlay(overlay);
/*     */   }
/*     */ 
/*     */   
/*     */   private static final void addRoiToOverlay(Overlay overlay, Roi roi, Color color) {
/* 179 */     roi.setStrokeColor(color);
/* 180 */     overlay.add(roi);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final Ellipse uncalibrate(Ellipse ellipse, Calibration calib) {
/* 195 */     Point2D center = ellipse.center();
/* 196 */     double xc = (center.getX() - calib.xOrigin) / calib.pixelWidth;
/* 197 */     double yc = (center.getY() - calib.yOrigin) / calib.pixelHeight;
/* 198 */     double radius1 = ellipse.radius1() / calib.pixelWidth;
/* 199 */     double radius2 = ellipse.radius2() / calib.pixelWidth;
/* 200 */     return new Ellipse(xc, yc, radius1, radius2, ellipse.orientation());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static final Roi createRoi(Ellipse ellipse) {
/* 206 */     Point2D center = ellipse.center();
/* 207 */     double xc = center.getX();
/* 208 */     double yc = center.getY();
/*     */     
/* 210 */     double r1 = ellipse.radius1();
/* 211 */     double r2 = ellipse.radius2();
/* 212 */     double theta = Math.toRadians(ellipse.orientation());
/*     */     
/* 214 */     double cot = Math.cos(theta);
/* 215 */     double sit = Math.sin(theta);
/*     */     
/* 217 */     int nVertices = 100;
/* 218 */     float[] xv = new float[nVertices];
/* 219 */     float[] yv = new float[nVertices];
/* 220 */     for (int i = 0; i < nVertices; i++) {
/*     */       
/* 222 */       double t = i * Math.PI * 2.0D / nVertices;
/* 223 */       double x = Math.cos(t) * r1;
/* 224 */       double y = Math.sin(t) * r2;
/*     */       
/* 226 */       xv[i] = (float)(x * cot - y * sit + xc);
/* 227 */       yv[i] = (float)(x * sit + y * cot + yc);
/*     */     } 
/*     */     
/* 230 */     return (Roi)new PolygonRoi(xv, yv, nVertices, 2);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static final Roi createMajorAxisRoi(Ellipse ellipse) {
/* 236 */     Point2D center = ellipse.center();
/* 237 */     double xc = center.getX();
/* 238 */     double yc = center.getY();
/*     */     
/* 240 */     double r1 = ellipse.radius1();
/* 241 */     double theta = Math.toRadians(ellipse.orientation());
/*     */     
/* 243 */     double cot = Math.cos(theta);
/* 244 */     double sit = Math.sin(theta);
/*     */     
/* 246 */     double x1 = xc + r1 * cot;
/* 247 */     double y1 = yc + r1 * sit;
/* 248 */     double x2 = xc - r1 * cot;
/* 249 */     double y2 = yc - r1 * sit;
/* 250 */     return (Roi)new Line(x1, y1, x2, y2);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static final Roi createMinorAxisRoi(Ellipse ellipse) {
/* 256 */     Point2D center = ellipse.center();
/* 257 */     double xc = center.getX();
/* 258 */     double yc = center.getY();
/*     */     
/* 260 */     double r2 = ellipse.radius2();
/* 261 */     double theta = Math.toRadians(ellipse.orientation() + 90.0D);
/*     */     
/* 263 */     double cot = Math.cos(theta);
/* 264 */     double sit = Math.sin(theta);
/*     */     
/* 266 */     double x1 = xc + r2 * cot;
/* 267 */     double y1 = yc + r2 * sit;
/* 268 */     double x2 = xc - r2 * cot;
/* 269 */     double y2 = yc - r2 * sit;
/* 270 */     return (Roi)new Line(x1, y1, x2, y2);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/plugins/EquivalentEllipsePlugin.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */