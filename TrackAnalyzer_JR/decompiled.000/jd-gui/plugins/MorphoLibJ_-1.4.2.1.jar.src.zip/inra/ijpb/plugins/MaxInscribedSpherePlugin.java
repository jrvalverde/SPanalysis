/*     */ package inra.ijpb.plugins;
/*     */ 
/*     */ import ij.IJ;
/*     */ import ij.ImagePlus;
/*     */ import ij.WindowManager;
/*     */ import ij.gui.GenericDialog;
/*     */ import ij.measure.ResultsTable;
/*     */ import ij.plugin.PlugIn;
/*     */ import inra.ijpb.algo.Algo;
/*     */ import inra.ijpb.algo.DefaultAlgoListener;
/*     */ import inra.ijpb.label.LabelImages;
/*     */ import inra.ijpb.measure.region3d.LargestInscribedBall;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MaxInscribedSpherePlugin
/*     */   implements PlugIn
/*     */ {
/*     */   public void run(String arg0) {
/*  52 */     int[] indices = WindowManager.getIDList();
/*  53 */     if (indices == null) {
/*     */       
/*  55 */       IJ.error("No image", "Need at least one image to work");
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/*  60 */     String[] imageNames = new String[indices.length];
/*  61 */     for (int i = 0; i < indices.length; i++)
/*     */     {
/*  63 */       imageNames[i] = WindowManager.getImage(indices[i]).getTitle();
/*     */     }
/*     */ 
/*     */     
/*  67 */     String selectedImageName = IJ.getImage().getTitle();
/*     */ 
/*     */     
/*  70 */     GenericDialog gd = new GenericDialog("Max. Inscribed Sphere");
/*  71 */     gd.addChoice("Label Image:", imageNames, selectedImageName);
/*     */ 
/*     */ 
/*     */     
/*  75 */     gd.showDialog();
/*     */     
/*  77 */     if (gd.wasCanceled()) {
/*     */       return;
/*     */     }
/*     */     
/*  81 */     int labelImageIndex = gd.getNextChoiceIndex();
/*  82 */     ImagePlus labelImage = WindowManager.getImage(labelImageIndex + 1);
/*     */ 
/*     */ 
/*     */     
/*  86 */     if (labelImage.getStackSize() <= 1) {
/*     */       
/*  88 */       IJ.showMessage("Input image should be a 3D label image");
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/*  93 */     if (!LabelImages.isLabelImageType(labelImage)) {
/*     */       
/*  95 */       IJ.showMessage("Input image should be a 3D label image");
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 100 */     LargestInscribedBall algo = new LargestInscribedBall();
/* 101 */     DefaultAlgoListener.monitor((Algo)algo);
/* 102 */     ResultsTable table = algo.computeTable(labelImage);
/*     */ 
/*     */     
/* 105 */     String tableName = String.valueOf(labelImage.getShortTitle()) + "-MaxInscribedSphere";
/* 106 */     table.show(tableName);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/plugins/MaxInscribedSpherePlugin.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */