/*     */ package inra.ijpb.plugins;
/*     */ 
/*     */ import ij.IJ;
/*     */ import ij.ImagePlus;
/*     */ import ij.gui.DialogListener;
/*     */ import ij.gui.GenericDialog;
/*     */ import ij.gui.NonBlockingGenericDialog;
/*     */ import ij.gui.Roi;
/*     */ import ij.gui.RoiListener;
/*     */ import ij.gui.Toolbar;
/*     */ import ij.plugin.filter.ExtendedPlugInFilter;
/*     */ import ij.plugin.filter.PlugInFilterRunner;
/*     */ import ij.process.ByteProcessor;
/*     */ import ij.process.ColorProcessor;
/*     */ import ij.process.FloatProcessor;
/*     */ import ij.process.ImageProcessor;
/*     */ import ij.process.ShortProcessor;
/*     */ import inra.ijpb.morphology.Reconstruction;
/*     */ import inra.ijpb.util.IJUtils;
/*     */ import java.awt.AWTEvent;
/*     */ import java.awt.Color;
/*     */ import java.awt.event.ActionEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class InteractiveMorphologicalReconstruction
/*     */   implements ExtendedPlugInFilter, DialogListener
/*     */ {
/*  61 */   private int flags = 16842783;
/*     */   
/*     */   PlugInFilterRunner pfr;
/*     */   
/*     */   int nPasses;
/*     */   
/*     */   boolean previewing = false;
/*     */   
/*     */   private ImagePlus imagePlus;
/*     */   
/*     */   private ImageProcessor baseImage;
/*     */   
/*  73 */   private static Conn2D connectivity = Conn2D.C4;
/*  74 */   private static Operation operation = Operation.BY_DILATION;
/*     */   
/*     */   private NonBlockingGenericDialog gd;
/*     */   private ImageProcessor result;
/*     */   private RoiListener listener;
/*     */   
/*     */   enum Operation
/*     */   {
/*  82 */     BY_DILATION("By Dilation"),
/*  83 */     BY_EROSION("By Erosion");
/*     */     
/*     */     private final String label;
/*     */     
/*     */     Operation(String label) {
/*  88 */       this.label = label;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImageProcessor applyTo(ImageProcessor marker, ImageProcessor mask, int conn) {
/*  96 */       if (this == BY_DILATION)
/*  97 */         return Reconstruction.reconstructByDilation(marker, mask, conn); 
/*  98 */       if (this == BY_EROSION) {
/*  99 */         return Reconstruction.reconstructByErosion(marker, mask, conn);
/*     */       }
/* 101 */       throw new RuntimeException(
/* 102 */           "Unable to process the " + this + " operation");
/*     */     }
/*     */     
/*     */     public String toString() {
/* 106 */       return this.label;
/*     */     }
/*     */     
/*     */     public static String[] getAllLabels() {
/* 110 */       int n = (values()).length;
/* 111 */       String[] result = new String[n];
/*     */       
/* 113 */       int i = 0; byte b; int j; Operation[] arrayOfOperation;
/* 114 */       for (j = (arrayOfOperation = values()).length, b = 0; b < j; ) { Operation op = arrayOfOperation[b];
/* 115 */         result[i++] = op.label; b++; }
/*     */       
/* 117 */       return result;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static Operation fromLabel(String opLabel) {
/* 130 */       if (opLabel != null)
/* 131 */         opLabel = opLabel.toLowerCase();  byte b; int i; Operation[] arrayOfOperation;
/* 132 */       for (i = (arrayOfOperation = values()).length, b = 0; b < i; ) { Operation op = arrayOfOperation[b];
/* 133 */         String cmp = op.label.toLowerCase();
/* 134 */         if (cmp.equals(opLabel))
/* 135 */           return op;  b++; }
/*     */       
/* 137 */       throw new IllegalArgumentException("Unable to parse Operation with label: " + opLabel);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   enum Conn2D
/*     */   {
/* 145 */     C4("4", 4),
/* 146 */     C8("8", 8);
/*     */     
/*     */     private final String label;
/*     */     private final int value;
/*     */     
/*     */     Conn2D(String label, int value) {
/* 152 */       this.label = label;
/* 153 */       this.value = value;
/*     */     }
/*     */     
/*     */     public String toString() {
/* 157 */       return this.label;
/*     */     }
/*     */     
/*     */     public int getValue() {
/* 161 */       return this.value;
/*     */     }
/*     */     
/*     */     public static String[] getAllLabels() {
/* 165 */       int n = (values()).length;
/* 166 */       String[] result = new String[n];
/*     */       
/* 168 */       int i = 0; byte b; int j; Conn2D[] arrayOfConn2D;
/* 169 */       for (j = (arrayOfConn2D = values()).length, b = 0; b < j; ) { Conn2D op = arrayOfConn2D[b];
/* 170 */         result[i++] = op.label; b++; }
/*     */       
/* 172 */       return result;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static Conn2D fromLabel(String opLabel) {
/* 180 */       if (opLabel != null)
/* 181 */         opLabel = opLabel.toLowerCase();  byte b; int i; Conn2D[] arrayOfConn2D;
/* 182 */       for (i = (arrayOfConn2D = values()).length, b = 0; b < i; ) { Conn2D op = arrayOfConn2D[b];
/* 183 */         String cmp = op.label.toLowerCase();
/* 184 */         if (cmp.equals(opLabel))
/* 185 */           return op;  b++; }
/*     */       
/* 187 */       throw new IllegalArgumentException("Unable to parse Conn2D with label: " + opLabel);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int setup(String arg, ImagePlus imp) {
/* 202 */     if (imp == null) {
/* 203 */       return 4096;
/*     */     }
/* 205 */     if (arg.equals("final")) {
/*     */       
/* 207 */       this.imagePlus.setProcessor(this.baseImage);
/* 208 */       this.imagePlus.draw();
/*     */       
/* 210 */       if (this.result != null) {
/*     */ 
/*     */         
/* 213 */         String newName = createResultImageName(this.imagePlus);
/* 214 */         ImagePlus resPlus = new ImagePlus(newName, this.result);
/* 215 */         resPlus.copyScale(this.imagePlus);
/* 216 */         resPlus.show();
/*     */       } 
/* 218 */       Roi.removeRoiListener(this.listener);
/* 219 */       return 4096;
/*     */     } 
/*     */     
/* 222 */     return this.flags;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int showDialog(ImagePlus imp, String command, final PlugInFilterRunner pfr) {
/* 231 */     this.imagePlus = imp;
/* 232 */     this.baseImage = imp.getProcessor().duplicate();
/* 233 */     this.pfr = pfr;
/*     */ 
/*     */     
/* 236 */     this.listener = new RoiListener()
/*     */       {
/*     */         public void roiModified(ImagePlus imp, int id)
/*     */         {
/* 240 */           if (imp == InteractiveMorphologicalReconstruction.this.imagePlus) {
/*     */ 
/*     */             
/* 243 */             InteractiveMorphologicalReconstruction.this.gd.getPreviewCheckbox().setState(false);
/*     */             
/* 245 */             pfr.dialogItemChanged((GenericDialog)InteractiveMorphologicalReconstruction.this.gd, 
/* 246 */                 new ActionEvent(InteractiveMorphologicalReconstruction.this.gd.getPreviewCheckbox(), 
/* 247 */                   1001, "Preview"));
/*     */           } 
/*     */         }
/*     */       };
/* 251 */     Roi.addRoiListener(this.listener);
/*     */ 
/*     */     
/* 254 */     Toolbar.getInstance().setTool(7);
/*     */ 
/*     */     
/* 257 */     this.gd = new NonBlockingGenericDialog("Interactive Morphological Reconstruction");
/*     */ 
/*     */     
/* 260 */     this.gd.addChoice("Type of Reconstruction", 
/* 261 */         Operation.getAllLabels(), 
/* 262 */         operation.label);
/* 263 */     this.gd.addChoice("Connectivity", 
/* 264 */         Conn2D.getAllLabels(), 
/* 265 */         connectivity.label);
/* 266 */     this.gd.addPreviewCheckbox(pfr);
/* 267 */     this.gd.addDialogListener(this);
/* 268 */     this.previewing = true;
/* 269 */     this.gd.addHelp("http://imagej.net/MorphoLibJ");
/* 270 */     this.gd.showDialog();
/* 271 */     this.previewing = false;
/*     */     
/* 273 */     if (this.gd.wasCanceled()) {
/* 274 */       return 4096;
/*     */     }
/*     */     
/* 277 */     operation = Operation.fromLabel(this.gd.getNextChoice());
/* 278 */     connectivity = Conn2D.fromLabel(this.gd.getNextChoice());
/*     */     
/* 280 */     return this.flags;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean dialogItemChanged(GenericDialog gd, AWTEvent evt) {
/* 290 */     operation = Operation.fromLabel(gd.getNextChoice());
/* 291 */     connectivity = Conn2D.fromLabel(gd.getNextChoice());
/*     */     
/* 293 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setNPasses(int nPasses) {
/* 298 */     this.nPasses = nPasses;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void run(ImageProcessor image) {
/* 306 */     if (image == null)
/*     */       return; 
/* 308 */     long t0 = System.currentTimeMillis();
/*     */ 
/*     */     
/* 311 */     this.result = process(image, this.imagePlus.getRoi());
/*     */     
/* 313 */     if (this.result == null) {
/*     */ 
/*     */       
/* 316 */       this.gd.getPreviewCheckbox().setState(false);
/* 317 */       this.pfr.dialogItemChanged((GenericDialog)this.gd, 
/* 318 */           new ActionEvent(this.gd.getPreviewCheckbox(), 
/* 319 */             1001, "Preview"));
/*     */       return;
/*     */     } 
/* 322 */     if (this.previewing) {
/*     */ 
/*     */       
/* 325 */       image.setPixels(this.result.getPixels());
/*     */       
/* 327 */       image.resetMinAndMax();
/*     */       
/* 329 */       if (image.isInvertedLut()) {
/* 330 */         image.invertLut();
/*     */       }
/*     */     } 
/* 333 */     long t1 = System.currentTimeMillis();
/* 334 */     IJUtils.showElapsedTime(operation.toString(), (t1 - t0), this.imagePlus);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ImageProcessor process(ImageProcessor mask, Roi roi) {
/*     */     FloatProcessor floatProcessor;
/* 345 */     if (mask == null || this.imagePlus == null || this.baseImage == null) {
/*     */       
/* 347 */       IJ.showMessage("Please run the plugin with an image open.");
/* 348 */       return null;
/*     */     } 
/* 350 */     if (roi == null) {
/*     */       
/* 352 */       IJ.showMessage("Please define the markers using for example the point selection tool.");
/*     */       
/* 354 */       return null;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 359 */     if (mask instanceof ByteProcessor) {
/*     */       
/* 361 */       ByteProcessor byteProcessor = new ByteProcessor(mask.getWidth(), mask.getHeight());
/* 362 */       byteProcessor.setValue(255.0D);
/*     */     }
/* 364 */     else if (mask instanceof ShortProcessor) {
/*     */       
/* 366 */       ShortProcessor shortProcessor = new ShortProcessor(mask.getWidth(), mask.getHeight());
/* 367 */       shortProcessor.setValue(65535.0D);
/*     */     }
/* 369 */     else if (mask instanceof ColorProcessor) {
/*     */       
/* 371 */       ColorProcessor colorProcessor = new ColorProcessor(mask.getWidth(), mask.getHeight());
/* 372 */       colorProcessor.setColor(Color.WHITE);
/*     */     }
/*     */     else {
/*     */       
/* 376 */       floatProcessor = new FloatProcessor(mask.getWidth(), mask.getHeight());
/* 377 */       floatProcessor.setValue(3.4028234663852886E38D);
/*     */     } 
/*     */ 
/*     */     
/* 381 */     if (roi.isArea()) {
/* 382 */       floatProcessor.fill(roi);
/*     */     } else {
/* 384 */       floatProcessor.draw(roi);
/*     */     } 
/*     */     
/* 387 */     if (operation == Operation.BY_EROSION) {
/* 388 */       floatProcessor.invert();
/*     */     }
/*     */     
/* 391 */     return operation.applyTo((ImageProcessor)floatProcessor, mask, connectivity.getValue());
/*     */   }
/*     */   
/*     */   private static String createResultImageName(ImagePlus baseImage) {
/* 395 */     return String.valueOf(baseImage.getShortTitle()) + "-rec";
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/plugins/InteractiveMorphologicalReconstruction.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */