/*     */ package inra.ijpb.plugins;
/*     */ 
/*     */ import ij.IJ;
/*     */ import ij.ImagePlus;
/*     */ import ij.WindowManager;
/*     */ import ij.gui.DialogListener;
/*     */ import ij.gui.GenericDialog;
/*     */ import ij.gui.Overlay;
/*     */ import ij.gui.Roi;
/*     */ import ij.gui.TextRoi;
/*     */ import ij.measure.Calibration;
/*     */ import ij.measure.ResultsTable;
/*     */ import ij.plugin.PlugIn;
/*     */ import ij.text.TextPanel;
/*     */ import ij.text.TextWindow;
/*     */ import inra.ijpb.util.IJUtils;
/*     */ import java.awt.AWTEvent;
/*     */ import java.awt.Choice;
/*     */ import java.awt.Frame;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DrawTableValuesPlugin
/*     */   implements PlugIn, DialogListener
/*     */ {
/*  55 */   static String selectedHeaderNameSave = null;
/*     */   static boolean calibratedPositionSave = false;
/*  57 */   static String xPosHeaderNameSave = null;
/*  58 */   static String yPosHeaderNameSave = null;
/*  59 */   static int xOffsetSave = -10;
/*  60 */   static int yOffsetSave = -10;
/*  61 */   static String valueHeaderNameSave = null;
/*  62 */   static String patternSave = null;
/*     */ 
/*     */   
/*     */   ImagePlus targetImagePlus;
/*     */   
/*     */   ImagePlus resultPlus;
/*     */   
/*  69 */   ResultsTable table = null;
/*     */   
/*  71 */   GenericDialog gd = null;
/*     */   
/*  73 */   String selectedHeaderName = selectedHeaderNameSave;
/*     */   boolean calibratedPosition = false;
/*  75 */   String xPosHeaderName = xPosHeaderNameSave;
/*  76 */   String yPosHeaderName = yPosHeaderNameSave;
/*  77 */   int xOffset = xOffsetSave;
/*  78 */   int yOffset = yOffsetSave;
/*  79 */   String valueHeaderName = valueHeaderNameSave;
/*  80 */   String pattern = patternSave;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void run(String arg0) {
/*  89 */     this.targetImagePlus = IJ.getImage();
/*     */ 
/*     */     
/*  92 */     TextWindow[] textWindows = IJUtils.getTableWindows();
/*  93 */     if (textWindows.length == 0) {
/*     */       
/*  95 */       IJ.error("Requires at least one Table window");
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 100 */     createDialog();
/* 101 */     this.gd.showDialog();
/*     */ 
/*     */     
/* 104 */     if (this.gd.wasCanceled())
/*     */       return; 
/* 106 */     parseDialogOptions();
/* 107 */     saveDialogOptions();
/*     */     
/* 109 */     drawValues(this.targetImagePlus);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private GenericDialog createDialog() {
/* 115 */     TextWindow[] textWindows = IJUtils.getTableWindows();
/* 116 */     if (textWindows.length == 0) {
/*     */       
/* 118 */       IJ.error("Requires at least one Table window");
/* 119 */       return null;
/*     */     } 
/* 121 */     String[] tableNames = new String[textWindows.length];
/* 122 */     for (int i = 0; i < textWindows.length; i++) {
/* 123 */       tableNames[i] = textWindows[i].getTitle();
/*     */     }
/*     */ 
/*     */     
/* 127 */     TextPanel tp = textWindows[0].getTextPanel();
/* 128 */     ResultsTable table = tp.getResultsTable();
/* 129 */     this.table = table;
/*     */ 
/*     */     
/* 132 */     String[] headings = table.getHeadings();
/* 133 */     String defaultHeading = headings[0];
/* 134 */     if (defaultHeading.equals("Label") && headings.length > 1)
/*     */     {
/* 136 */       defaultHeading = headings[1];
/*     */     }
/*     */     
/* 139 */     this.gd = new GenericDialog("Draw Text from Column");
/* 140 */     this.gd.addChoice("Results Table:", tableNames, tableNames[0]);
/* 141 */     this.gd.addCheckbox("Calibrated Position:", false);
/* 142 */     this.gd.addChoice("X-Position:", headings, defaultHeading);
/* 143 */     this.gd.addChoice("Y-Position:", headings, defaultHeading);
/* 144 */     this.gd.addNumericField("X-Offset:", this.xOffset, 0, 5, "pixels");
/* 145 */     this.gd.addNumericField("Y-Offset:", this.yOffset, 0, 5, "pixels");
/* 146 */     this.gd.addChoice("Values:", headings, defaultHeading);
/* 147 */     this.gd.addStringField("Pattern:", "%5.2f", 10);
/*     */ 
/*     */     
/* 150 */     Vector<Choice> choices = this.gd.getChoices();
/* 151 */     replaceStrings(choices.get(1), headings, chooseDefaultHeading(headings, this.xPosHeaderName));
/* 152 */     replaceStrings(choices.get(2), headings, chooseDefaultHeading(headings, this.yPosHeaderName));
/* 153 */     replaceStrings(choices.get(3), headings, chooseDefaultHeading(headings, this.valueHeaderName));
/*     */     
/* 155 */     this.gd.addDialogListener(this);
/*     */     
/* 157 */     return this.gd;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void parseDialogOptions() {
/* 166 */     String tableName = this.gd.getNextChoice();
/* 167 */     Frame tableFrame = WindowManager.getFrame(tableName);
/* 168 */     this.table = ((TextWindow)tableFrame).getTextPanel().getResultsTable();
/*     */     
/* 170 */     this.calibratedPosition = this.gd.getNextBoolean();
/* 171 */     this.xPosHeaderName = this.gd.getNextChoice();
/* 172 */     this.yPosHeaderName = this.gd.getNextChoice();
/* 173 */     this.xOffset = (int)this.gd.getNextNumber();
/* 174 */     this.yOffset = (int)this.gd.getNextNumber();
/* 175 */     this.valueHeaderName = this.gd.getNextChoice();
/* 176 */     this.pattern = this.gd.getNextString();
/*     */   }
/*     */ 
/*     */   
/*     */   private void saveDialogOptions() {
/* 181 */     calibratedPositionSave = this.calibratedPosition;
/* 182 */     xPosHeaderNameSave = this.xPosHeaderName;
/* 183 */     yPosHeaderNameSave = this.yPosHeaderName;
/* 184 */     xOffsetSave = this.xOffset;
/* 185 */     yOffsetSave = this.yOffset;
/* 186 */     valueHeaderNameSave = this.valueHeaderName;
/* 187 */     patternSave = this.pattern;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean dialogItemChanged(GenericDialog gd, AWTEvent evt) {
/* 193 */     if (gd.wasCanceled() || gd.wasOKed())
/*     */     {
/* 195 */       return true;
/*     */     }
/*     */ 
/*     */     
/* 199 */     Vector<Choice> choices = gd.getChoices();
/* 200 */     if (choices == null) {
/*     */       
/* 202 */       IJ.log("empty choices array...");
/* 203 */       return false;
/*     */     } 
/*     */ 
/*     */     
/* 207 */     if (evt.getSource() == choices.get(0)) {
/*     */       
/* 209 */       String tableName = ((Choice)evt.getSource()).getSelectedItem();
/* 210 */       Frame tableFrame = WindowManager.getFrame(tableName);
/* 211 */       this.table = ((TextWindow)tableFrame).getTextPanel().getResultsTable();
/*     */ 
/*     */       
/* 214 */       String[] headings = this.table.getHeadings();
/* 215 */       replaceStrings(choices.get(1), headings, chooseDefaultHeading(headings, this.xPosHeaderName));
/* 216 */       replaceStrings(choices.get(2), headings, chooseDefaultHeading(headings, this.yPosHeaderName));
/* 217 */       replaceStrings(choices.get(3), headings, chooseDefaultHeading(headings, this.valueHeaderName));
/*     */     } 
/*     */     
/* 220 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   private String chooseDefaultHeading(String[] headings, String proposedHeading) {
/* 225 */     if (containsString(headings, proposedHeading))
/*     */     {
/* 227 */       return proposedHeading;
/*     */     }
/*     */ 
/*     */     
/* 231 */     if (headings[0].equals("Label") && headings.length > 1)
/*     */     {
/* 233 */       return headings[1];
/*     */     }
/*     */ 
/*     */     
/* 237 */     return headings[0];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean containsString(String[] strings, String string) {
/* 244 */     if (string == null)
/* 245 */       return false;  byte b; int i; String[] arrayOfString;
/* 246 */     for (i = (arrayOfString = strings).length, b = 0; b < i; ) { String str = arrayOfString[b];
/*     */       
/* 248 */       if (string.equals(str))
/* 249 */         return true;  b++; }
/*     */     
/* 251 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   private void replaceStrings(Choice choice, String[] strings, String defaultString) {
/* 256 */     choice.removeAll(); byte b; int i; String[] arrayOfString;
/* 257 */     for (i = (arrayOfString = strings).length, b = 0; b < i; ) { String str = arrayOfString[b];
/*     */       
/* 259 */       choice.add(str); b++; }
/*     */     
/* 261 */     choice.select(defaultString);
/*     */   }
/*     */ 
/*     */   
/*     */   public void drawValues(ImagePlus target) {
/* 266 */     Overlay overlay = new Overlay();
/*     */ 
/*     */     
/* 269 */     double[] xPos = getColumnValues(this.table, this.xPosHeaderName);
/* 270 */     double[] yPos = getColumnValues(this.table, this.yPosHeaderName);
/* 271 */     if (this.calibratedPosition) {
/*     */       
/* 273 */       Calibration calib = target.getCalibration();
/* 274 */       for (int j = 0; j < xPos.length; j++) {
/*     */         
/* 276 */         xPos[j] = xPos[j] * calib.pixelWidth + calib.xOrigin;
/* 277 */         yPos[j] = yPos[j] * calib.pixelHeight + calib.yOrigin;
/*     */       } 
/*     */     } 
/*     */     
/* 281 */     double[] values = getColumnValues(this.table, this.valueHeaderName);
/*     */     
/* 283 */     for (int i = 0; i < xPos.length; i++) {
/*     */       
/* 285 */       TextRoi textRoi = new TextRoi(
/* 286 */           xPos[i] + this.xOffset, 
/* 287 */           yPos[i] + this.yOffset, 
/* 288 */           String.format(this.pattern, new Object[] { Double.valueOf(values[i]) }));
/* 289 */       overlay.add((Roi)textRoi);
/*     */     } 
/*     */     
/* 292 */     target.setOverlay(overlay);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private double[] getColumnValues(ResultsTable table, String heading) {
/* 298 */     String[] allHeaders = table.getHeadings();
/*     */ 
/*     */     
/* 301 */     boolean hasRowLabels = hasRowLabelColumn(table);
/* 302 */     if (hasRowLabels && heading.equals(allHeaders[0])) {
/*     */ 
/*     */       
/* 305 */       int nr = table.size();
/* 306 */       double[] values = new double[nr];
/* 307 */       for (int r = 0; r < nr; r++) {
/*     */         
/* 309 */         String label = table.getLabel(r);
/* 310 */         values[r] = Double.parseDouble(label);
/*     */       } 
/* 312 */       return values;
/*     */     } 
/*     */ 
/*     */     
/* 316 */     int index = table.getColumnIndex(heading);
/* 317 */     if (index == -1)
/*     */     {
/* 319 */       throw new RuntimeException("Unable to find column index from header: " + heading);
/*     */     }
/* 321 */     return table.getColumnAsDoubles(index);
/*     */   }
/*     */ 
/*     */   
/*     */   private static final boolean hasRowLabelColumn(ResultsTable table) {
/* 326 */     return (table.getLastColumn() == (table.getHeadings()).length - 2);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/plugins/DrawTableValuesPlugin.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */