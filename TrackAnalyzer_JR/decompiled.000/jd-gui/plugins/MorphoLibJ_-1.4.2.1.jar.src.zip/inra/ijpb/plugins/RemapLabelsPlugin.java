/*    */ package inra.ijpb.plugins;
/*    */ 
/*    */ import ij.IJ;
/*    */ import ij.ImagePlus;
/*    */ import ij.plugin.PlugIn;
/*    */ import inra.ijpb.label.LabelImages;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RemapLabelsPlugin
/*    */   implements PlugIn
/*    */ {
/*    */   public void run(String arg) {
/* 44 */     ImagePlus imagePlus = IJ.getImage();
/* 45 */     LabelImages.remapLabels(imagePlus);
/*    */     
/* 47 */     imagePlus.draw();
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/plugins/RemapLabelsPlugin.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */