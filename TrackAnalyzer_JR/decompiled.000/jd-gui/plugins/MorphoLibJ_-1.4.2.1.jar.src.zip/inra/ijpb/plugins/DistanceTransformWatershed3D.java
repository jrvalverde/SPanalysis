/*     */ package inra.ijpb.plugins;
/*     */ 
/*     */ import ij.IJ;
/*     */ import ij.ImagePlus;
/*     */ import ij.ImageStack;
/*     */ import ij.WindowManager;
/*     */ import ij.gui.GenericDialog;
/*     */ import ij.plugin.PlugIn;
/*     */ import inra.ijpb.binary.BinaryImages;
/*     */ import inra.ijpb.binary.ChamferWeights3D;
/*     */ import inra.ijpb.data.image.Images3D;
/*     */ import inra.ijpb.util.IJUtils;
/*     */ import inra.ijpb.watershed.ExtendedMinimaWatershed;
/*     */ import java.awt.Font;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DistanceTransformWatershed3D
/*     */   implements PlugIn
/*     */ {
/*     */   private ChamferWeights3D weights;
/*     */   private static boolean floatProcessing = false;
/*     */   private static boolean normalize = true;
/*  53 */   private static int dynamic = 2;
/*  54 */   private static String weightLabel = ChamferWeights3D.BORGEFORS.toString();
/*     */   
/*  56 */   private static Conn3D connectivity = Conn3D.C6;
/*     */ 
/*     */ 
/*     */   
/*     */   enum Conn3D
/*     */   {
/*  62 */     C6("6", 6),
/*  63 */     C26("26", 26);
/*     */     
/*     */     private final String label;
/*     */     private final int value;
/*     */     
/*     */     Conn3D(String label, int value) {
/*  69 */       this.label = label;
/*  70 */       this.value = value;
/*     */     }
/*     */     
/*     */     public String toString() {
/*  74 */       return this.label;
/*     */     }
/*     */     
/*     */     public int getValue() {
/*  78 */       return this.value;
/*     */     }
/*     */     
/*     */     public static String[] getAllLabels() {
/*  82 */       int n = (values()).length;
/*  83 */       String[] result = new String[n];
/*     */       
/*  85 */       int i = 0; byte b; int j; Conn3D[] arrayOfConn3D;
/*  86 */       for (j = (arrayOfConn3D = values()).length, b = 0; b < j; ) { Conn3D op = arrayOfConn3D[b];
/*  87 */         result[i++] = op.label; b++; }
/*     */       
/*  89 */       return result;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static Conn3D fromLabel(String opLabel) {
/*  99 */       if (opLabel != null)
/* 100 */         opLabel = opLabel.toLowerCase();  byte b; int i; Conn3D[] arrayOfConn3D;
/* 101 */       for (i = (arrayOfConn3D = values()).length, b = 0; b < i; ) { Conn3D op = arrayOfConn3D[b];
/* 102 */         String cmp = op.label.toLowerCase();
/* 103 */         if (cmp.equals(opLabel))
/* 104 */           return op;  b++; }
/*     */       
/* 106 */       throw new IllegalArgumentException("Unable to parse Conn3D with label: " + opLabel);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void run(String arg) {
/* 115 */     ImagePlus result, image = WindowManager.getCurrentImage();
/* 116 */     if (image == null) {
/*     */       
/* 118 */       IJ.error("Distance Transform Watershed 3D", 
/* 119 */           "Need at least one image to work");
/*     */       
/*     */       return;
/*     */     } 
/* 123 */     if (!BinaryImages.isBinaryImage(image))
/*     */     {
/* 125 */       IJ.error("Distance Transform Watershed 3D", "Input image is not binary (8-bit with only 0 or 255 values)");
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 130 */     GenericDialog gd = new GenericDialog("Distance Transform Watershed 3D");
/* 131 */     gd.setInsets(0, 0, 0);
/* 132 */     gd.addMessage("Distance map options:", 
/* 133 */         new Font("SansSerif", 1, 12));
/* 134 */     gd.addChoice("Distances", ChamferWeights3D.getAllLabels(), weightLabel);
/* 135 */     String[] outputTypes = { "32 bits", "16 bits" };
/* 136 */     gd.addChoice("Output Type", outputTypes, outputTypes[floatProcessing ? 0 : 1]);
/* 137 */     gd.setInsets(0, 0, 0);
/* 138 */     gd.addCheckbox("Normalize weights", normalize);
/* 139 */     gd.setInsets(20, 0, 0);
/* 140 */     gd.addMessage("Watershed options:", 
/* 141 */         new Font("SansSerif", 1, 12));
/* 142 */     gd.addNumericField("Dynamic", dynamic, 2);
/* 143 */     gd.addChoice("Connectivity", Conn3D.getAllLabels(), 
/* 144 */         connectivity.label);
/* 145 */     gd.addHelp("http://imagej.net/MorphoLibJ#Utilities_for_binary_images");
/* 146 */     gd.showDialog();
/*     */ 
/*     */     
/* 149 */     if (gd.wasCanceled()) {
/*     */       return;
/*     */     }
/*     */     
/* 153 */     weightLabel = gd.getNextChoice();
/* 154 */     floatProcessing = (gd.getNextChoiceIndex() == 0);
/* 155 */     normalize = gd.getNextBoolean();
/* 156 */     dynamic = (int)gd.getNextNumber();
/* 157 */     connectivity = Conn3D.fromLabel(gd.getNextChoice());
/*     */ 
/*     */     
/* 160 */     this.weights = ChamferWeights3D.fromLabel(weightLabel);
/*     */     
/* 162 */     long t0 = System.currentTimeMillis();
/*     */ 
/*     */     
/* 165 */     if (floatProcessing) {
/* 166 */       result = processFloat(image, this.weights.getFloatWeights(), normalize);
/*     */     } else {
/* 168 */       result = processShort(image, this.weights.getShortWeights(), normalize);
/*     */     } 
/* 170 */     Images3D.optimizeDisplayRange(result);
/*     */ 
/*     */     
/* 173 */     result.show();
/* 174 */     result.setSlice(image.getCurrentSlice());
/*     */ 
/*     */     
/* 177 */     long t1 = System.currentTimeMillis();
/* 178 */     IJUtils.showElapsedTime("Distance Transform Watershed 3D", (
/* 179 */         t1 - t0), image);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ImagePlus processFloat(ImagePlus image, float[] weights, boolean normalize) {
/* 187 */     ImageStack dist = 
/* 188 */       BinaryImages.distanceMap(image.getImageStack(), weights, 
/* 189 */         normalize);
/*     */     
/* 191 */     Images3D.invert(dist);
/*     */     
/* 193 */     ImageStack result = ExtendedMinimaWatershed.extendedMinimaWatershed(
/* 194 */         dist, image.getImageStack(), dynamic, connectivity.value, 32, false);
/* 195 */     ImagePlus ip = new ImagePlus(String.valueOf(image.getShortTitle()) + "dist-watershed", 
/* 196 */         result);
/* 197 */     ip.setCalibration(image.getCalibration());
/* 198 */     return ip;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ImagePlus processShort(ImagePlus image, short[] weights, boolean normalize) {
/* 207 */     ImageStack dist = 
/* 208 */       BinaryImages.distanceMap(image.getImageStack(), weights, 
/* 209 */         normalize);
/*     */     
/* 211 */     Images3D.invert(dist);
/*     */     
/* 213 */     ImageStack result = ExtendedMinimaWatershed.extendedMinimaWatershed(
/* 214 */         dist, image.getImageStack(), dynamic, connectivity.value, 16, false);
/* 215 */     ImagePlus ip = new ImagePlus(String.valueOf(image.getShortTitle()) + "dist-watershed", 
/* 216 */         result);
/* 217 */     ip.setCalibration(image.getCalibration());
/* 218 */     return ip;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/plugins/DistanceTransformWatershed3D.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */