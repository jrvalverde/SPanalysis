/*     */ package inra.ijpb.plugins;
/*     */ 
/*     */ import ij.IJ;
/*     */ import ij.ImagePlus;
/*     */ import ij.WindowManager;
/*     */ import ij.gui.GenericDialog;
/*     */ import ij.plugin.PlugIn;
/*     */ import inra.ijpb.binary.BinaryImages;
/*     */ import inra.ijpb.data.image.Images3D;
/*     */ import inra.ijpb.watershed.Watershed;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Watershed3DPlugin
/*     */   implements PlugIn
/*     */ {
/*     */   public static boolean use26neighbors = true;
/*  49 */   public static double hMin = 0.0D;
/*  50 */   public static double hMax = 255.0D;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ImagePlus process(ImagePlus input, ImagePlus mask, int connectivity, double hMin, double hMax) {
/*  70 */     long start = System.currentTimeMillis();
/*     */     
/*  72 */     ImagePlus resultImage = Watershed.computeWatershed(input, mask, connectivity, hMin, hMax);
/*     */     
/*  74 */     long end = System.currentTimeMillis();
/*  75 */     IJ.log("Watershed 3d took " + (end - start) + " ms.");
/*     */     
/*  77 */     return resultImage;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void run(String arg) {
/*  87 */     int nbima = WindowManager.getImageCount();
/*     */     
/*  89 */     if (nbima == 0) {
/*     */       
/*  91 */       IJ.error("Classic Watershed", 
/*  92 */           "ERROR: At least one image needs to be open to run watershed.");
/*     */       
/*     */       return;
/*     */     } 
/*  96 */     String[] names = new String[nbima];
/*  97 */     String[] namesMask = new String[nbima + 1];
/*     */     
/*  99 */     namesMask[0] = "None";
/*     */     
/* 101 */     for (int i = 0; i < nbima; i++) {
/*     */       
/* 103 */       names[i] = WindowManager.getImage(i + 1).getTitle();
/* 104 */       namesMask[i + 1] = WindowManager.getImage(i + 1).getTitle();
/*     */     } 
/*     */     
/* 107 */     GenericDialog gd = new GenericDialog("Classic Watershed");
/*     */     
/* 109 */     int inputIndex = 0;
/* 110 */     int maskIndex = (nbima > 1) ? 2 : 0;
/*     */ 
/*     */     
/* 113 */     switch (WindowManager.getImage(inputIndex + 1).getBitDepth()) {
/*     */       case 8:
/* 115 */         if (hMax > 255.0D)
/* 116 */           hMax = 255.0D; 
/*     */         break;
/*     */       case 16:
/* 119 */         if (hMax > 65535.0D)
/* 120 */           hMax = 65535.0D; 
/*     */         break;
/*     */       case 32:
/* 123 */         if (hMax > 3.4028234663852886E38D) {
/* 124 */           hMax = 3.4028234663852886E38D;
/*     */         }
/*     */         break;
/*     */     } 
/*     */     
/* 129 */     gd.addChoice("Input", names, names[inputIndex]);
/* 130 */     gd.addChoice("Mask", namesMask, namesMask[maskIndex]);
/* 131 */     gd.addCheckbox("Use diagonal connectivity", use26neighbors);
/* 132 */     gd.addNumericField("Min h", hMin, 1);
/* 133 */     gd.addNumericField("Max h", hMax, 1);
/*     */     
/* 135 */     gd.showDialog();
/*     */     
/* 137 */     if (gd.wasOKed()) {
/*     */       
/* 139 */       inputIndex = gd.getNextChoiceIndex();
/* 140 */       maskIndex = gd.getNextChoiceIndex();
/* 141 */       use26neighbors = gd.getNextBoolean();
/* 142 */       hMin = gd.getNextNumber();
/* 143 */       hMax = gd.getNextNumber();
/*     */       
/* 145 */       ImagePlus inputImage = WindowManager.getImage(inputIndex + 1);
/* 146 */       ImagePlus maskImage = (maskIndex > 0) ? WindowManager.getImage(maskIndex) : null;
/*     */       
/* 148 */       if (maskImage != null)
/*     */       {
/* 150 */         if (!BinaryImages.isBinaryImage(maskImage)) {
/*     */           
/* 152 */           IJ.error("Classic Watershed", "Error: selected mask image is not binary!");
/*     */           
/*     */           return;
/*     */         } 
/*     */       }
/*     */       
/* 158 */       if (hMin < 0.0D) {
/* 159 */         hMin = 0.0D;
/*     */       }
/* 161 */       switch (WindowManager.getImage(inputIndex + 1).getBitDepth()) {
/*     */         case 8:
/* 163 */           if (hMax > 255.0D)
/* 164 */             hMax = 255.0D; 
/*     */           break;
/*     */         case 16:
/* 167 */           if (hMax > 65535.0D)
/* 168 */             hMax = 65535.0D; 
/*     */           break;
/*     */         case 32:
/* 171 */           if (hMax > 3.4028234663852886E38D)
/* 172 */             hMax = 3.4028234663852886E38D; 
/*     */           break;
/*     */         default:
/* 175 */           IJ.error("Classic Watershed", "Error: only grayscale images are valid input!");
/*     */           return;
/*     */       } 
/*     */ 
/*     */       
/* 180 */       int connectivity = use26neighbors ? 26 : 6;
/*     */ 
/*     */       
/* 183 */       if (inputImage.getImageStackSize() == 1) {
/* 184 */         connectivity = use26neighbors ? 8 : 4;
/*     */       }
/* 186 */       ImagePlus result = process(inputImage, maskImage, connectivity, hMin, hMax);
/*     */ 
/*     */       
/* 189 */       Images3D.optimizeDisplayRange(result);
/*     */ 
/*     */       
/* 192 */       result.setSlice(inputImage.getCurrentSlice());
/*     */ 
/*     */       
/* 195 */       result.show();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/plugins/Watershed3DPlugin.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */