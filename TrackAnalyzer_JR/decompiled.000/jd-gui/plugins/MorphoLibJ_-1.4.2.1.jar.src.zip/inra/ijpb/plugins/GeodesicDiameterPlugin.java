/*     */ package inra.ijpb.plugins;
/*     */ 
/*     */ import ij.IJ;
/*     */ import ij.ImagePlus;
/*     */ import ij.WindowManager;
/*     */ import ij.gui.GenericDialog;
/*     */ import ij.gui.Overlay;
/*     */ import ij.gui.PointRoi;
/*     */ import ij.gui.PolygonRoi;
/*     */ import ij.gui.Roi;
/*     */ import ij.measure.Calibration;
/*     */ import ij.measure.ResultsTable;
/*     */ import ij.plugin.PlugIn;
/*     */ import ij.plugin.frame.RoiManager;
/*     */ import inra.ijpb.algo.Algo;
/*     */ import inra.ijpb.algo.DefaultAlgoListener;
/*     */ import inra.ijpb.binary.ChamferWeights;
/*     */ import inra.ijpb.label.LabelImages;
/*     */ import inra.ijpb.measure.region2d.GeodesicDiameter;
/*     */ import inra.ijpb.util.IJUtils;
/*     */ import java.awt.Color;
/*     */ import java.awt.geom.Point2D;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GeodesicDiameterPlugin
/*     */   implements PlugIn
/*     */ {
/*     */   public void run(String arg0) {
/*  67 */     int[] indices = WindowManager.getIDList();
/*  68 */     if (indices == null) {
/*     */       
/*  70 */       IJ.error("No image", "Need at least one image to work");
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/*  75 */     String[] imageNames = new String[indices.length];
/*  76 */     for (int i = 0; i < indices.length; i++)
/*     */     {
/*  78 */       imageNames[i] = WindowManager.getImage(indices[i]).getTitle();
/*     */     }
/*     */ 
/*     */     
/*  82 */     String selectedImageName = IJ.getImage().getTitle();
/*     */ 
/*     */     
/*  85 */     GenericDialog gd = new GenericDialog("Geodesic Diameter");
/*  86 */     gd.addChoice("Label Image:", imageNames, selectedImageName);
/*     */     
/*  88 */     gd.addChoice("Distances", ChamferWeights.getAllLabels(), 
/*  89 */         ChamferWeights.CHESSKNIGHT.toString());
/*  90 */     gd.addCheckbox("Show Overlay Result", true);
/*  91 */     gd.addChoice("Image to overlay:", imageNames, selectedImageName);
/*  92 */     gd.addCheckbox("Export to ROI Manager", true);
/*  93 */     gd.showDialog();
/*     */     
/*  95 */     if (gd.wasCanceled()) {
/*     */       return;
/*     */     }
/*     */     
/*  99 */     int labelImageIndex = gd.getNextChoiceIndex();
/* 100 */     ImagePlus labelPlus = WindowManager.getImage(labelImageIndex + 1);
/* 101 */     ChamferWeights weights = ChamferWeights.fromLabel(gd.getNextChoice());
/* 102 */     boolean overlayPaths = gd.getNextBoolean();
/* 103 */     int resultImageIndex = gd.getNextChoiceIndex();
/* 104 */     boolean createPathRois = gd.getNextBoolean();
/*     */ 
/*     */     
/* 107 */     if (!LabelImages.isLabelImageType(labelPlus)) {
/*     */       
/* 109 */       IJ.showMessage("Input image should be a label image");
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 114 */     GeodesicDiameter algo = new GeodesicDiameter(weights);
/* 115 */     algo.setComputePaths(!(!overlayPaths && !createPathRois));
/* 116 */     DefaultAlgoListener.monitor((Algo)algo);
/*     */ 
/*     */     
/* 119 */     long start = System.nanoTime();
/* 120 */     Map<Integer, GeodesicDiameter.Result> geodDiams = algo.analyzeRegions(labelPlus);
/*     */ 
/*     */     
/* 123 */     long finalTime = System.nanoTime();
/* 124 */     float elapsedTime = (float)(finalTime - start) / 1000000.0F;
/*     */ 
/*     */     
/* 127 */     ResultsTable table = algo.createTable(geodDiams);
/* 128 */     String tableName = String.valueOf(labelPlus.getShortTitle()) + "-GeodDiameters";
/* 129 */     table.show(tableName);
/*     */ 
/*     */     
/* 132 */     if (overlayPaths || createPathRois) {
/*     */       
/* 134 */       boolean validPaths = true;
/* 135 */       for (GeodesicDiameter.Result geodDiam : geodDiams.values()) {
/*     */         
/* 137 */         if (Double.isInfinite(geodDiam.diameter)) {
/*     */           
/* 139 */           validPaths = false;
/*     */           
/*     */           break;
/*     */         } 
/*     */       } 
/* 144 */       if (!validPaths)
/*     */       {
/* 146 */         IJ.showMessage("Geodesic Diameter Warning", "Some geodesic diameters are infinite,\nmeaning that some particles are not connected.\nMaybe labeling was not performed, or label image was cropped?");
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 152 */       if (overlayPaths) {
/*     */ 
/*     */         
/* 155 */         ImagePlus resultImage = WindowManager.getImage(resultImageIndex + 1);
/* 156 */         drawPaths(resultImage, geodDiams);
/*     */       } 
/*     */       
/* 159 */       if (createPathRois)
/*     */       {
/* 161 */         createPathRois(labelPlus, geodDiams);
/*     */       }
/*     */     } 
/*     */     
/* 165 */     IJUtils.showElapsedTime("Geodesic Diameter", elapsedTime, labelPlus);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void drawPaths(ImagePlus target, Map<Integer, GeodesicDiameter.Result> geodDiams) {
/* 221 */     Overlay overlay = new Overlay();
/* 222 */     Calibration calib = target.getCalibration();
/*     */     
/* 224 */     for (GeodesicDiameter.Result result : geodDiams.values()) {
/*     */       
/* 226 */       Roi roi = createPathRoi(result.path, calib);
/* 227 */       roi.setStrokeColor(Color.RED);
/* 228 */       overlay.add(roi);
/*     */     } 
/*     */     
/* 231 */     target.setOverlay(overlay);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void createPathRois(ImagePlus target, Map<Integer, GeodesicDiameter.Result> geodDiams) {
/* 243 */     RoiManager manager = RoiManager.getRoiManager();
/* 244 */     Calibration calib = target.getCalibration();
/*     */ 
/*     */     
/* 247 */     int index = 0;
/* 248 */     for (GeodesicDiameter.Result result : geodDiams.values())
/*     */     {
/* 250 */       manager.add(target, createPathRoi(result.path, calib), index++);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private Roi createPathRoi(List<Point2D> path, Calibration calib) {
/* 256 */     if (path == null)
/*     */     {
/* 258 */       return null;
/*     */     }
/*     */     
/* 261 */     if (path.size() > 1) {
/*     */ 
/*     */       
/* 264 */       int n = path.size();
/* 265 */       float[] x = new float[n];
/* 266 */       float[] y = new float[n];
/* 267 */       int i = 0;
/* 268 */       for (Point2D pos : path) {
/*     */         
/* 270 */         pos = calibToPixel(pos, calib);
/* 271 */         x[i] = (float)(pos.getX() + 0.5D);
/* 272 */         y[i] = (float)(pos.getY() + 0.5D);
/* 273 */         i++;
/*     */       } 
/* 275 */       return (Roi)new PolygonRoi(x, y, n, 6);
/*     */     } 
/* 277 */     if (path.size() == 1) {
/*     */ 
/*     */       
/* 280 */       Point2D pos = calibToPixel(path.get(0), calib);
/* 281 */       return (Roi)new PointRoi(pos.getX() + 0.5D, pos.getY() + 0.5D);
/*     */     } 
/*     */ 
/*     */     
/* 285 */     throw new RuntimeException("Can not manage empty paths");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private Point2D calibToPixel(Point2D point, Calibration calib) {
/* 291 */     double x = (point.getX() - calib.xOrigin) / calib.pixelWidth;
/* 292 */     double y = (point.getY() - calib.yOrigin) / calib.pixelHeight;
/* 293 */     return new Point2D.Double(x, y);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/plugins/GeodesicDiameterPlugin.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */