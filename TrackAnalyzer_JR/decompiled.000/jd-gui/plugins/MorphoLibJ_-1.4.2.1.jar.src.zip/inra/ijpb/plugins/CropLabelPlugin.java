/*    */ package inra.ijpb.plugins;
/*    */ 
/*    */ import ij.IJ;
/*    */ import ij.ImagePlus;
/*    */ import ij.gui.GenericDialog;
/*    */ import ij.plugin.PlugIn;
/*    */ import inra.ijpb.label.LabelImages;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CropLabelPlugin
/*    */   implements PlugIn
/*    */ {
/*    */   public boolean debug = false;
/*    */   
/*    */   public void run(String args) {
/* 58 */     ImagePlus imagePlus = IJ.getImage();
/*    */ 
/*    */     
/* 61 */     GenericDialog gd = new GenericDialog("Crop Label");
/* 62 */     gd.addNumericField("Label", 1.0D, 0);
/* 63 */     gd.addNumericField("Border pixels", 1.0D, 0);
/* 64 */     gd.showDialog();
/*    */ 
/*    */     
/* 67 */     if (gd.wasCanceled()) {
/*    */       return;
/*    */     }
/*    */     
/* 71 */     int label = (int)gd.getNextNumber();
/* 72 */     int border = (int)gd.getNextNumber();
/*    */     
/* 74 */     ImagePlus croppedPlus = LabelImages.cropLabel(imagePlus, label, border);
/*    */ 
/*    */     
/* 77 */     croppedPlus.show();
/* 78 */     if (imagePlus.getStackSize() > 1)
/*    */     {
/* 80 */       croppedPlus.setSlice(croppedPlus.getStackSize() / 2);
/*    */     }
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/plugins/CropLabelPlugin.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */