/*     */ package inra.ijpb.plugins;
/*     */ 
/*     */ import ij.IJ;
/*     */ import ij.ImagePlus;
/*     */ import ij.ImageStack;
/*     */ import ij.gui.GenericDialog;
/*     */ import ij.plugin.PlugIn;
/*     */ import ij.process.ImageProcessor;
/*     */ import inra.ijpb.label.LabelImages;
/*     */ import inra.ijpb.measure.region2d.Centroid;
/*     */ import inra.ijpb.measure.region3d.Centroid3D;
/*     */ import java.util.HashMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ExpandLabelsPlugin
/*     */   implements PlugIn
/*     */ {
/*     */   public void run(String arg0) {
/*  63 */     ImagePlus resultPlus, imagePlus = IJ.getImage();
/*     */ 
/*     */     
/*  66 */     boolean isPlanar = (imagePlus.getStackSize() == 1);
/*  67 */     GenericDialog gd = new GenericDialog("Expand labels");
/*  68 */     gd.addNumericField("Dilation Coeff. (%)", 20.0D, 0);
/*  69 */     gd.showDialog();
/*     */ 
/*     */     
/*  72 */     if (gd.wasCanceled()) {
/*     */       return;
/*     */     }
/*  75 */     int expandRatio = (int)gd.getNextNumber();
/*     */     
/*  77 */     String newName = String.valueOf(imagePlus.getShortTitle()) + "-expandLbl";
/*     */ 
/*     */ 
/*     */     
/*  81 */     if (isPlanar) {
/*     */       
/*  83 */       ImageProcessor image = imagePlus.getProcessor();
/*  84 */       ImageProcessor result = expandLabels(image, expandRatio);
/*  85 */       resultPlus = new ImagePlus(newName, result);
/*     */     }
/*     */     else {
/*     */       
/*  89 */       ImageStack image = imagePlus.getStack();
/*  90 */       ImageStack result = expandLabels(image, expandRatio);
/*  91 */       result.setColorModel(image.getColorModel());
/*  92 */       resultPlus = new ImagePlus(newName, result);
/*     */     } 
/*     */ 
/*     */     
/*  96 */     resultPlus.copyScale(imagePlus);
/*     */ 
/*     */     
/*  99 */     double vmin = imagePlus.getDisplayRangeMin();
/* 100 */     double vmax = imagePlus.getDisplayRangeMax();
/* 101 */     resultPlus.setDisplayRange(vmin, vmax);
/*     */ 
/*     */     
/* 104 */     resultPlus.show();
/*     */ 
/*     */     
/* 107 */     if (imagePlus.getStackSize() > 1) {
/*     */       
/* 109 */       int newSlice = (int)Math.floor(imagePlus.getCurrentSlice() * (1.0D + expandRatio / 100.0D));
/* 110 */       resultPlus.setSlice(newSlice);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final ImageProcessor expandLabels(ImageProcessor image, float ratio) {
/* 123 */     int sizeX = image.getWidth();
/* 124 */     int sizeY = image.getHeight();
/*     */ 
/*     */     
/* 127 */     int sizeX2 = (int)Math.round(sizeX * (1.0D + ratio / 100.0D));
/* 128 */     int sizeY2 = (int)Math.round(sizeY * (1.0D + ratio / 100.0D));
/*     */ 
/*     */     
/* 131 */     ImageProcessor result = image.createProcessor(sizeX2, sizeY2);
/*     */ 
/*     */     
/* 134 */     int[] labels = LabelImages.findAllLabels(image);
/* 135 */     double[][] centroids = Centroid.centroids(image, labels);
/*     */ 
/*     */     
/* 138 */     int nLabels = labels.length;
/* 139 */     int[][] shifts = new int[nLabels][2];
/* 140 */     for (int i = 0; i < nLabels; i++) {
/*     */       
/* 142 */       shifts[i][0] = (int)Math.floor(centroids[i][0] * ratio / 100.0D);
/* 143 */       shifts[i][1] = (int)Math.floor(centroids[i][1] * ratio / 100.0D);
/*     */     } 
/*     */ 
/*     */     
/* 147 */     HashMap<Integer, Integer> labelIndices = new HashMap<Integer, Integer>();
/* 148 */     for (int j = 0; j < nLabels; j++)
/*     */     {
/* 150 */       labelIndices.put(Integer.valueOf(labels[j]), Integer.valueOf(j));
/*     */     }
/*     */     
/* 153 */     for (int y = 0; y < sizeY; y++) {
/*     */       
/* 155 */       for (int x = 0; x < sizeX; x++) {
/*     */         
/* 157 */         float label = image.getf(x, y);
/* 158 */         if (Float.compare(label, 0.0F) != 0) {
/*     */ 
/*     */           
/* 161 */           int index = ((Integer)labelIndices.get(Integer.valueOf((int)label))).intValue();
/* 162 */           int x2 = x + shifts[index][0];
/* 163 */           int y2 = y + shifts[index][1];
/* 164 */           result.setf(x2, y2, label);
/*     */         } 
/*     */       } 
/*     */     } 
/* 168 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final ImageStack expandLabels(ImageStack image, float ratio) {
/* 181 */     int sizeX = image.getWidth();
/* 182 */     int sizeY = image.getHeight();
/* 183 */     int sizeZ = image.getSize();
/*     */ 
/*     */     
/* 186 */     int sizeX2 = (int)Math.round(sizeX * (1.0D + (ratio / 100.0F)));
/* 187 */     int sizeY2 = (int)Math.round(sizeY * (1.0D + (ratio / 100.0F)));
/* 188 */     int sizeZ2 = (int)Math.round(sizeZ * (1.0D + (ratio / 100.0F)));
/*     */ 
/*     */     
/* 191 */     int bitDepth = image.getBitDepth();
/* 192 */     ImageStack result = ImageStack.create(sizeX2, sizeY2, sizeZ2, bitDepth);
/*     */ 
/*     */     
/* 195 */     int[] labels = LabelImages.findAllLabels(image);
/* 196 */     double[][] centroids = Centroid3D.centroids(image, labels);
/*     */ 
/*     */     
/* 199 */     int nLabels = labels.length;
/* 200 */     int[][] shifts = new int[nLabels][3];
/* 201 */     for (int i = 0; i < nLabels; i++) {
/*     */       
/* 203 */       shifts[i][0] = (int)Math.floor(centroids[i][0] * ratio / 100.0D);
/* 204 */       shifts[i][1] = (int)Math.floor(centroids[i][1] * ratio / 100.0D);
/* 205 */       shifts[i][2] = (int)Math.floor(centroids[i][2] * ratio / 100.0D);
/*     */     } 
/*     */ 
/*     */     
/* 209 */     HashMap<Integer, Integer> labelIndices = new HashMap<Integer, Integer>();
/* 210 */     for (int j = 0; j < nLabels; j++)
/*     */     {
/* 212 */       labelIndices.put(Integer.valueOf(labels[j]), Integer.valueOf(j));
/*     */     }
/*     */     
/* 215 */     for (int z = 0; z < sizeZ; z++) {
/*     */       
/* 217 */       for (int y = 0; y < sizeY; y++) {
/*     */         
/* 219 */         for (int x = 0; x < sizeX; x++) {
/*     */           
/* 221 */           double label = image.getVoxel(x, y, z);
/* 222 */           if (Double.compare(label, 0.0D) != 0) {
/*     */ 
/*     */             
/* 225 */             int index = ((Integer)labelIndices.get(Integer.valueOf((int)label))).intValue();
/* 226 */             int x2 = x + shifts[index][0];
/* 227 */             int y2 = y + shifts[index][1];
/* 228 */             int z2 = z + shifts[index][2];
/* 229 */             result.setVoxel(x2, y2, z2, label);
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/* 234 */     return result;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/plugins/ExpandLabelsPlugin.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */