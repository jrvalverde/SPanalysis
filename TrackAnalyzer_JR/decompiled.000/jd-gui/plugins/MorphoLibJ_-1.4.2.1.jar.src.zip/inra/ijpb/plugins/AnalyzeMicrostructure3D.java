/*     */ package inra.ijpb.plugins;
/*     */ 
/*     */ import ij.IJ;
/*     */ import ij.ImagePlus;
/*     */ import ij.ImageStack;
/*     */ import ij.gui.GenericDialog;
/*     */ import ij.measure.Calibration;
/*     */ import ij.measure.ResultsTable;
/*     */ import ij.plugin.PlugIn;
/*     */ import inra.ijpb.algo.Algo;
/*     */ import inra.ijpb.algo.DefaultAlgoListener;
/*     */ import inra.ijpb.measure.IntrinsicVolumes3D;
/*     */ import inra.ijpb.measure.region3d.BinaryConfigurationsHistogram3D;
/*     */ import inra.ijpb.measure.region3d.IntrinsicVolumes3DUtils;
/*     */ import inra.ijpb.util.IJUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AnalyzeMicrostructure3D
/*     */   implements PlugIn
/*     */ {
/*  37 */   private static final String[] dirNumberLabels = new String[] {
/*  38 */       "Crofton  (3 dirs.)", 
/*  39 */       "Crofton (13 dirs.)"
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  45 */   private static final int[] dirNumbers = new int[] {
/*  46 */       3, 13
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  52 */   private static final String[] connectivity3dNames = new String[] {
/*  53 */       "C6", "C26"
/*     */     };
/*     */   
/*  56 */   private static final int[] connectivity3dValues = new int[] { 6, 26 };
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  61 */   private static final String[] connectivity2dNames = new String[] {
/*  62 */       "C4", "C8"
/*     */     };
/*     */   
/*  65 */   private static final int[] connectivity2dValues = new int[] { 4, 8 };
/*     */ 
/*     */   
/*     */   boolean computeVolume = true;
/*     */   
/*     */   boolean computeSurface = true;
/*     */   
/*     */   boolean computeMeanBreadth = true;
/*     */   
/*     */   boolean computeEulerNumber = true;
/*     */   
/*  76 */   int surfaceAreaDirs = 13;
/*  77 */   int meanBreadthDirs = 13;
/*  78 */   int connectivity2d = 8;
/*  79 */   int connectivity = 6;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void run(String arg) {
/*  88 */     ImagePlus imagePlus = IJ.getImage();
/*     */     
/*  90 */     if (imagePlus.getStackSize() == 1) {
/*     */       
/*  92 */       IJ.error("Requires a Stack");
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/*  97 */     GenericDialog gd = new GenericDialog("Microstructure Analysis");
/*  98 */     gd.addCheckbox("Volume", true);
/*  99 */     gd.addCheckbox("Surface Area", true);
/* 100 */     gd.addCheckbox("Mean_Breadth", true);
/* 101 */     gd.addCheckbox("Euler Number", true);
/* 102 */     gd.addMessage("");
/* 103 */     gd.addChoice("Surface area method:", dirNumberLabels, dirNumberLabels[1]);
/* 104 */     gd.addChoice("Mean breadth method:", dirNumberLabels, dirNumberLabels[1]);
/* 105 */     gd.addChoice("Mean Breadth Conn.:", connectivity2dNames, connectivity2dNames[1]);
/* 106 */     gd.addChoice("Euler Connectivity:", connectivity3dNames, connectivity3dNames[1]);
/* 107 */     gd.showDialog();
/*     */ 
/*     */     
/* 110 */     if (gd.wasCanceled()) {
/*     */       return;
/*     */     }
/*     */     
/* 114 */     this.computeVolume = gd.getNextBoolean();
/* 115 */     this.computeSurface = gd.getNextBoolean();
/* 116 */     this.computeMeanBreadth = gd.getNextBoolean();
/* 117 */     this.computeEulerNumber = gd.getNextBoolean();
/*     */ 
/*     */     
/* 120 */     this.surfaceAreaDirs = dirNumbers[gd.getNextChoiceIndex()];
/* 121 */     this.meanBreadthDirs = dirNumbers[gd.getNextChoiceIndex()];
/* 122 */     this.connectivity2d = connectivity2dValues[gd.getNextChoiceIndex()];
/* 123 */     this.connectivity = connectivity3dValues[gd.getNextChoiceIndex()];
/*     */ 
/*     */     
/* 126 */     ResultsTable table = process(imagePlus);
/*     */ 
/*     */     
/* 129 */     String tableName = String.valueOf(imagePlus.getShortTitle()) + "-microstructure";
/*     */ 
/*     */     
/* 132 */     table.show(tableName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResultsTable process(ImagePlus imagePlus) {
/* 144 */     if (imagePlus == null) {
/* 145 */       return null;
/*     */     }
/*     */     
/* 148 */     ImageStack image = imagePlus.getStack();
/* 149 */     Calibration calib = imagePlus.getCalibration();
/*     */     
/* 151 */     long tic = System.nanoTime();
/* 152 */     ResultsTable table = process(image, calib);
/*     */     
/* 154 */     long toc = System.nanoTime();
/* 155 */     double dt = (toc - tic) / 1000000.0D;
/*     */     
/* 157 */     IJUtils.showElapsedTime("Microstructure 3D", dt, imagePlus);
/* 158 */     return table;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResultsTable process(ImageStack image, Calibration calib) {
/* 173 */     double[] resol = { 1.0D, 1.0D, 1.0D };
/* 174 */     if (calib != null && calib.scaled()) {
/*     */       
/* 176 */       resol[0] = calib.pixelWidth;
/* 177 */       resol[1] = calib.pixelHeight;
/* 178 */       resol[2] = calib.pixelDepth;
/*     */     } 
/*     */ 
/*     */     
/* 182 */     BinaryConfigurationsHistogram3D algo = new BinaryConfigurationsHistogram3D();
/* 183 */     DefaultAlgoListener.monitor((Algo)algo);
/* 184 */     IJ.showStatus("Compute Configuration Histogram");
/* 185 */     int[] histogram = algo.processInnerFrame(image);
/*     */ 
/*     */     
/* 188 */     double vol = IntrinsicVolumes3D.samplingVolume(image, calib);
/*     */ 
/*     */     
/* 191 */     IJ.showStatus("Create Table");
/* 192 */     ResultsTable table = new ResultsTable();
/*     */     
/* 194 */     table.incrementCounter();
/*     */     
/* 196 */     if (this.computeVolume) {
/*     */       
/* 198 */       double[] volumeLut = IntrinsicVolumes3DUtils.volumeLut(calib);
/* 199 */       double volume = BinaryConfigurationsHistogram3D.applyLut(histogram, volumeLut);
/* 200 */       table.addValue("VolumeDensity", volume / vol);
/*     */     } 
/* 202 */     if (this.computeSurface) {
/*     */       
/* 204 */       double[] surfaceAreaLut = IntrinsicVolumes3DUtils.surfaceAreaLut(calib, this.surfaceAreaDirs);
/* 205 */       double surfaceArea = BinaryConfigurationsHistogram3D.applyLut(histogram, surfaceAreaLut);
/* 206 */       table.addValue("SurfaceAreaDensity", surfaceArea / vol);
/*     */     } 
/* 208 */     if (this.computeMeanBreadth) {
/*     */       
/* 210 */       double[] meanBreadthLut = IntrinsicVolumes3DUtils.meanBreadthLut(calib, this.meanBreadthDirs, this.connectivity2d);
/* 211 */       double meanBreadth = BinaryConfigurationsHistogram3D.applyLut(histogram, meanBreadthLut);
/* 212 */       table.addValue("MeanBreadthDensity", meanBreadth / vol);
/*     */     } 
/* 214 */     if (this.computeEulerNumber) {
/*     */       
/* 216 */       double[] eulerNumberLut = IntrinsicVolumes3DUtils.eulerNumberLut(this.connectivity);
/* 217 */       double eulerNumber = BinaryConfigurationsHistogram3D.applyLut(histogram, eulerNumberLut);
/* 218 */       table.addValue("EulerNumberDensity", eulerNumber / vol);
/*     */     } 
/*     */     
/* 221 */     return table;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/plugins/AnalyzeMicrostructure3D.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */