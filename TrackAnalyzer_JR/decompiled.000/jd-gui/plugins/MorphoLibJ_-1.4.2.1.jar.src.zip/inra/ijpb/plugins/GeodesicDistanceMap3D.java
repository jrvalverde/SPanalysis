/*     */ package inra.ijpb.plugins;
/*     */ 
/*     */ import ij.IJ;
/*     */ import ij.ImagePlus;
/*     */ import ij.ImageStack;
/*     */ import ij.WindowManager;
/*     */ import ij.gui.GenericDialog;
/*     */ import ij.plugin.PlugIn;
/*     */ import ij.process.LUT;
/*     */ import inra.ijpb.algo.Algo;
/*     */ import inra.ijpb.algo.DefaultAlgoListener;
/*     */ import inra.ijpb.binary.ChamferWeights3D;
/*     */ import inra.ijpb.binary.geodesic.GeodesicDistanceTransform3DFloat;
/*     */ import inra.ijpb.data.image.Images3D;
/*     */ import inra.ijpb.util.ColorMaps;
/*     */ import java.awt.image.IndexColorModel;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GeodesicDistanceMap3D
/*     */   implements PlugIn
/*     */ {
/*     */   public void run(String arg0) {
/*  61 */     int[] indices = WindowManager.getIDList();
/*  62 */     if (indices == null) {
/*     */       
/*  64 */       IJ.error("No image", "Need at least one image to work");
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/*  69 */     String[] imageNames = new String[indices.length];
/*  70 */     for (int i = 0; i < indices.length; i++)
/*     */     {
/*  72 */       imageNames[i] = WindowManager.getImage(indices[i]).getTitle();
/*     */     }
/*     */ 
/*     */     
/*  76 */     GenericDialog gd = new GenericDialog("Geodesic Distance Map 3D");
/*     */     
/*  78 */     gd.addChoice("Marker Image", imageNames, IJ.getImage().getTitle());
/*  79 */     gd.addChoice("Mask Image", imageNames, IJ.getImage().getTitle());
/*     */     
/*  81 */     gd.addChoice("Distances", ChamferWeights3D.getAllLabels(), 
/*  82 */         ChamferWeights3D.BORGEFORS.toString());
/*     */ 
/*     */     
/*  85 */     gd.addCheckbox("Normalize weights", true);
/*     */     
/*  87 */     gd.showDialog();
/*     */     
/*  89 */     if (gd.wasCanceled()) {
/*     */       return;
/*     */     }
/*     */     
/*  93 */     int markerImageIndex = gd.getNextChoiceIndex();
/*  94 */     ImagePlus markerImage = WindowManager.getImage(markerImageIndex + 1);
/*  95 */     int maskImageIndex = gd.getNextChoiceIndex();
/*  96 */     ImagePlus maskImage = WindowManager.getImage(maskImageIndex + 1);
/*  97 */     String weightLabel = gd.getNextChoice();
/*     */ 
/*     */     
/* 100 */     ChamferWeights3D weights = ChamferWeights3D.fromLabel(weightLabel);
/*     */     
/* 102 */     boolean normalizeWeights = gd.getNextBoolean();
/*     */ 
/*     */     
/* 105 */     if (markerImage.getType() != 0) {
/*     */       
/* 107 */       IJ.showMessage("Marker image should be binary");
/*     */       return;
/*     */     } 
/* 110 */     if (maskImage.getType() != 0) {
/*     */       
/* 112 */       IJ.showMessage("Mask image should be binary");
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 117 */     String newName = String.valueOf(maskImage.getShortTitle()) + "-geodDist";
/*     */ 
/*     */ 
/*     */     
/* 121 */     ImagePlus res = process(markerImage, maskImage, newName, 
/* 122 */         weights.getFloatWeights(), normalizeWeights);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 129 */     res.show();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ImagePlus process(ImagePlus marker, ImagePlus mask, String newName, float[] weights, boolean normalize) {
/* 155 */     if (marker == null)
/*     */     {
/* 157 */       throw new IllegalArgumentException("Marker image not specified");
/*     */     }
/* 159 */     if (mask == null)
/*     */     {
/* 161 */       throw new IllegalArgumentException("Mask image not specified");
/*     */     }
/* 163 */     if (weights == null)
/*     */     {
/* 165 */       throw new IllegalArgumentException("Weights not specified");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 184 */     GeodesicDistanceTransform3DFloat geodesicDistanceTransform3DFloat = new GeodesicDistanceTransform3DFloat(weights, normalize);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 189 */     DefaultAlgoListener.monitor((Algo)geodesicDistanceTransform3DFloat);
/*     */ 
/*     */     
/* 192 */     ImageStack result = geodesicDistanceTransform3DFloat.geodesicDistanceMap(marker.getStack(), mask.getStack());
/* 193 */     ImagePlus resultPlus = new ImagePlus(newName, result);
/*     */ 
/*     */     
/* 196 */     double[] minMax = Images3D.findMinAndMax(resultPlus);
/* 197 */     resultPlus.setLut(createFireLUT(minMax[1]));
/* 198 */     resultPlus.setDisplayRange(0.0D, minMax[1]);
/*     */ 
/*     */     
/* 201 */     return resultPlus;
/*     */   }
/*     */ 
/*     */   
/*     */   private LUT createFireLUT(double maxVal) {
/* 206 */     byte[][] lut = ColorMaps.createFireLut(256);
/* 207 */     byte[] red = new byte[256];
/* 208 */     byte[] green = new byte[256];
/* 209 */     byte[] blue = new byte[256];
/* 210 */     for (int i = 0; i < 256; i++) {
/*     */       
/* 212 */       red[i] = lut[i][0];
/* 213 */       green[i] = lut[i][1];
/* 214 */       blue[i] = lut[i][2];
/*     */     } 
/* 216 */     IndexColorModel cm = new IndexColorModel(8, 256, red, green, blue);
/* 217 */     return new LUT(cm, 0.0D, maxVal);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/plugins/GeodesicDistanceMap3D.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */