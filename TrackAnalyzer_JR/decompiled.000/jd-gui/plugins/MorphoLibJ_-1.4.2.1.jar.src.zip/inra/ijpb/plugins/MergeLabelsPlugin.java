/*     */ package inra.ijpb.plugins;
/*     */ 
/*     */ import ij.IJ;
/*     */ import ij.ImagePlus;
/*     */ import ij.gui.GenericDialog;
/*     */ import ij.plugin.PlugIn;
/*     */ import inra.ijpb.label.LabelImages;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MergeLabelsPlugin
/*     */   implements PlugIn
/*     */ {
/*     */   enum GapManagement
/*     */   {
/*  23 */     NO_GAP("No Gap"),
/*  24 */     ORTHOGONAL("Orthogonal"),
/*  25 */     DIAGONAL("Diagonal");
/*     */     
/*     */     String label;
/*     */ 
/*     */     
/*     */     GapManagement(String label) {
/*  31 */       this.label = label;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static String[] getAllLabels() {
/*  42 */       GapManagement[] values = values();
/*  43 */       int n = values.length;
/*     */ 
/*     */       
/*  46 */       String[] result = new String[n];
/*  47 */       for (int i = 0; i < n; i++) {
/*  48 */         result[i] = (values[i]).label;
/*     */       }
/*  50 */       return result;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static GapManagement fromLabel(String label) {
/*  64 */       if (label != null)
/*  65 */         label = label.toLowerCase();  byte b; int i; GapManagement[] arrayOfGapManagement;
/*  66 */       for (i = (arrayOfGapManagement = values()).length, b = 0; b < i; ) { GapManagement type = arrayOfGapManagement[b];
/*     */         
/*  68 */         if (type.label.toLowerCase().equals(label))
/*  69 */           return type;  b++; }
/*     */       
/*  71 */       throw new IllegalArgumentException("Unable to parse Strel.Shape with label: " + label);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String toString() {
/*  79 */       return this.label;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void run(String arg) {
/*     */     int conn;
/*  92 */     ImagePlus imagePlus = IJ.getImage();
/*     */ 
/*     */     
/*  95 */     GenericDialog gd = new GenericDialog("Merge Labels");
/*  96 */     gd.addChoice("Gap Management", GapManagement.getAllLabels(), GapManagement.NO_GAP.toString());
/*  97 */     gd.showDialog();
/*     */     
/*  99 */     if (gd.wasCanceled()) {
/*     */       return;
/*     */     }
/* 102 */     int gapManagementIndex = gd.getNextChoiceIndex();
/*     */     
/* 104 */     switch (gapManagementIndex) {
/*     */ 
/*     */       
/*     */       case 0:
/* 108 */         LabelImages.mergeLabels(imagePlus, imagePlus.getRoi(), true);
/*     */         break;
/*     */ 
/*     */       
/*     */       case 1:
/* 113 */         conn = imagePlus.isStack() ? 6 : 4;
/* 114 */         LabelImages.mergeLabelsWithGap(imagePlus, imagePlus.getRoi(), conn, true);
/*     */         break;
/*     */ 
/*     */       
/*     */       case 2:
/* 119 */         conn = imagePlus.isStack() ? 26 : 6;
/* 120 */         LabelImages.mergeLabelsWithGap(imagePlus, imagePlus.getRoi(), conn, true);
/*     */         break;
/*     */     } 
/*     */ 
/*     */     
/* 125 */     imagePlus.updateAndDraw();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/plugins/MergeLabelsPlugin.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */