/*     */ package inra.ijpb.plugins;
/*     */ 
/*     */ import ij.IJ;
/*     */ import ij.ImagePlus;
/*     */ import ij.gui.DialogListener;
/*     */ import ij.gui.GenericDialog;
/*     */ import ij.plugin.filter.ExtendedPlugInFilter;
/*     */ import ij.plugin.filter.PlugInFilterRunner;
/*     */ import ij.process.ByteProcessor;
/*     */ import ij.process.ImageProcessor;
/*     */ import inra.ijpb.algo.Algo;
/*     */ import inra.ijpb.algo.DefaultAlgoListener;
/*     */ import inra.ijpb.morphology.Morphology;
/*     */ import inra.ijpb.morphology.Strel;
/*     */ import java.awt.AWTEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MorphologicalFilterPlugin
/*     */   implements ExtendedPlugInFilter, DialogListener
/*     */ {
/*  53 */   private int flags = 16842911;
/*     */ 
/*     */   
/*     */   PlugInFilterRunner pfr;
/*     */ 
/*     */   
/*     */   int nPasses;
/*     */   
/*     */   boolean previewing = false;
/*     */   
/*     */   private ImagePlus imagePlus;
/*     */   
/*     */   private ImageProcessor baseImage;
/*     */   
/*     */   private ImageProcessor result;
/*     */   
/*  69 */   private ImagePlus strelDisplay = null;
/*     */   
/*  71 */   Morphology.Operation op = Morphology.Operation.DILATION;
/*  72 */   Strel.Shape shape = Strel.Shape.SQUARE;
/*  73 */   int radius = 2;
/*     */ 
/*     */ 
/*     */   
/*     */   boolean showStrel;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int setup(String arg, ImagePlus imp) {
/*  83 */     if (arg.equals("about")) {
/*     */       
/*  85 */       showAbout();
/*  86 */       return 4096;
/*     */     } 
/*     */ 
/*     */     
/*  90 */     if (arg.equals("final")) {
/*     */ 
/*     */       
/*  93 */       resetPreview();
/*  94 */       this.imagePlus.updateAndDraw();
/*     */ 
/*     */       
/*  97 */       String newName = createResultImageName(this.imagePlus);
/*  98 */       ImagePlus resPlus = new ImagePlus(newName, this.result);
/*  99 */       resPlus.copyScale(this.imagePlus);
/* 100 */       resPlus.show();
/* 101 */       return 4096;
/*     */     } 
/*     */     
/* 104 */     return this.flags;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int showDialog(ImagePlus imp, String command, PlugInFilterRunner pfr) {
/* 111 */     this.imagePlus = imp;
/* 112 */     this.baseImage = imp.getProcessor().duplicate();
/*     */ 
/*     */     
/* 115 */     GenericDialog gd = new GenericDialog("Morphological Filters");
/*     */     
/* 117 */     gd.addChoice("Operation", Morphology.Operation.getAllLabels(), 
/* 118 */         this.op.toString());
/* 119 */     gd.addChoice("Element", Strel.Shape.getAllLabels(), 
/* 120 */         this.shape.toString());
/* 121 */     gd.addNumericField("Radius (in pixels)", this.radius, 0);
/* 122 */     gd.addCheckbox("Show Element", false);
/* 123 */     gd.addPreviewCheckbox(pfr);
/* 124 */     gd.addDialogListener(this);
/* 125 */     this.previewing = true;
/* 126 */     gd.addHelp("http://imagej.net/MorphoLibJ#Morphological_filters");
/* 127 */     gd.showDialog();
/* 128 */     this.previewing = false;
/*     */     
/* 130 */     if (gd.wasCanceled()) {
/*     */       
/* 132 */       resetPreview();
/* 133 */       return 4096;
/*     */     } 
/*     */     
/* 136 */     parseDialogParameters(gd);
/*     */ 
/*     */     
/* 139 */     gd.dispose();
/* 140 */     return this.flags;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean dialogItemChanged(GenericDialog gd, AWTEvent evt) {
/* 145 */     boolean wasPreview = this.previewing;
/* 146 */     parseDialogParameters(gd);
/*     */ 
/*     */     
/* 149 */     if (wasPreview && !this.previewing)
/*     */     {
/* 151 */       resetPreview();
/*     */     }
/* 153 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void parseDialogParameters(GenericDialog gd) {
/* 159 */     this.op = Morphology.Operation.fromLabel(gd.getNextChoice());
/* 160 */     this.shape = Strel.Shape.fromLabel(gd.getNextChoice());
/* 161 */     this.radius = (int)gd.getNextNumber();
/* 162 */     this.showStrel = gd.getNextBoolean();
/* 163 */     this.previewing = gd.getPreviewCheckbox().getState();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setNPasses(int nPasses) {
/* 168 */     this.nPasses = nPasses;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void run(ImageProcessor image) {
/* 175 */     Strel strel = this.shape.fromRadius(this.radius);
/*     */ 
/*     */     
/* 178 */     DefaultAlgoListener.monitor((Algo)strel);
/*     */ 
/*     */     
/* 181 */     if (this.showStrel)
/*     */     {
/* 183 */       showStrelImage(strel);
/*     */     }
/*     */ 
/*     */     
/* 187 */     this.result = this.op.apply(this.baseImage, strel);
/* 188 */     if (!(this.result instanceof ij.process.ColorProcessor)) {
/* 189 */       this.result.setLut(this.baseImage.getLut());
/*     */     }
/* 191 */     if (this.previewing) {
/*     */ 
/*     */       
/* 194 */       for (int i = 0; i < image.getPixelCount(); i++)
/*     */       {
/* 196 */         image.setf(i, this.result.getf(i));
/*     */       }
/* 198 */       image.resetMinAndMax();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void showAbout() {
/* 205 */     IJ.showMessage("MorphoLibJ", 
/* 206 */         "MorphoLibJ,\nhttp://imagej.net/MorphoLibJ\n\nby David Legland\n(david.legland@inra.fr)\nby Ignacio Arganda-Carreras\n(iargandacarreras@gmail.com)\nProject page:\nhttps://github.com/ijpb/MorphoLibJ\n");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void resetPreview() {
/* 221 */     ImageProcessor image = this.imagePlus.getProcessor();
/* 222 */     if (image instanceof ij.process.FloatProcessor) {
/*     */       
/* 224 */       for (int i = 0; i < image.getPixelCount(); i++) {
/* 225 */         image.setf(i, this.baseImage.getf(i));
/*     */       }
/*     */     } else {
/*     */       
/* 229 */       for (int i = 0; i < image.getPixelCount(); i++)
/* 230 */         image.set(i, this.baseImage.get(i)); 
/*     */     } 
/* 232 */     this.imagePlus.updateAndDraw();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void showStrelImage(Strel strel) {
/* 242 */     int[] dim = strel.getSize();
/* 243 */     int width = dim[0] + 20;
/* 244 */     int height = dim[1] + 20;
/*     */ 
/*     */     
/* 247 */     ByteProcessor byteProcessor = new ByteProcessor(width, height);
/* 248 */     byteProcessor.set(width / 2, height / 2, 255);
/* 249 */     ImageProcessor imageProcessor = Morphology.dilation((ImageProcessor)byteProcessor, strel);
/*     */ 
/*     */     
/* 252 */     if (!imageProcessor.isInvertedLut()) {
/* 253 */       imageProcessor.invertLut();
/*     */     }
/*     */     
/* 256 */     if (this.strelDisplay == null) {
/*     */       
/* 258 */       this.strelDisplay = new ImagePlus("Structuring Element", imageProcessor);
/*     */     }
/*     */     else {
/*     */       
/* 262 */       this.strelDisplay.setProcessor(imageProcessor);
/*     */     } 
/* 264 */     this.strelDisplay.show();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public ImagePlus exec(ImagePlus image, Morphology.Operation op, Strel strel) {
/* 284 */     if (image == null) {
/* 285 */       return null;
/*     */     }
/*     */     
/* 288 */     ImageProcessor inputProcessor = image.getProcessor();
/*     */ 
/*     */     
/* 291 */     ImageProcessor resultProcessor = op.apply(inputProcessor, strel);
/*     */ 
/*     */     
/* 294 */     resultProcessor.setColorModel(inputProcessor.getColorModel());
/*     */ 
/*     */     
/* 297 */     ImagePlus resultImage = new ImagePlus(op.toString(), resultProcessor);
/* 298 */     resultImage.copyScale(image);
/*     */ 
/*     */     
/* 301 */     return resultImage;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ImagePlus process(ImagePlus image, Morphology.Operation op, Strel strel) {
/* 319 */     if (image == null) {
/* 320 */       return null;
/*     */     }
/*     */     
/* 323 */     ImageProcessor inputProcessor = image.getProcessor();
/*     */ 
/*     */     
/* 326 */     ImageProcessor resultProcessor = op.apply(inputProcessor, strel);
/*     */ 
/*     */     
/* 329 */     resultProcessor.setColorModel(inputProcessor.getColorModel());
/*     */ 
/*     */     
/* 332 */     ImagePlus resultImage = new ImagePlus(op.toString(), resultProcessor);
/* 333 */     resultImage.copyScale(image);
/*     */ 
/*     */     
/* 336 */     return resultImage;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String createResultImageName(ImagePlus baseImage) {
/* 345 */     return String.valueOf(baseImage.getShortTitle()) + "-" + this.op.toString();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/plugins/MorphologicalFilterPlugin.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */