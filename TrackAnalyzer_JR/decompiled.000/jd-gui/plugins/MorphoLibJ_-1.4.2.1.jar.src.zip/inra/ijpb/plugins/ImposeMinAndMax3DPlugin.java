/*     */ package inra.ijpb.plugins;
/*     */ 
/*     */ import ij.IJ;
/*     */ import ij.ImagePlus;
/*     */ import ij.ImageStack;
/*     */ import ij.WindowManager;
/*     */ import ij.gui.GenericDialog;
/*     */ import ij.plugin.PlugIn;
/*     */ import inra.ijpb.morphology.MinimaAndMaxima3D;
/*     */ import inra.ijpb.util.IJUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ImposeMinAndMax3DPlugin
/*     */   implements PlugIn
/*     */ {
/*     */   public enum Operation
/*     */   {
/*  43 */     IMPOSE_MINIMA("Impose Minima"),
/*  44 */     IMPOSE_MAXIMA("Impose Maxima");
/*     */     
/*     */     private final String label;
/*     */     
/*     */     Operation(String label) {
/*  49 */       this.label = label;
/*     */     }
/*     */ 
/*     */     
/*     */     public ImageStack applyTo(ImageStack image, ImageStack markers) {
/*  54 */       if (this == IMPOSE_MINIMA)
/*  55 */         return MinimaAndMaxima3D.imposeMinima(image, markers); 
/*  56 */       if (this == IMPOSE_MAXIMA) {
/*  57 */         return MinimaAndMaxima3D.imposeMaxima(image, markers);
/*     */       }
/*  59 */       throw new RuntimeException(
/*  60 */           "Unable to process the " + this + " operation");
/*     */     }
/*     */ 
/*     */     
/*     */     public ImageStack applyTo(ImageStack image, ImageStack markers, int conn) {
/*  65 */       if (this == IMPOSE_MINIMA)
/*  66 */         return MinimaAndMaxima3D.imposeMinima(image, markers, conn); 
/*  67 */       if (this == IMPOSE_MAXIMA) {
/*  68 */         return MinimaAndMaxima3D.imposeMaxima(image, markers, conn);
/*     */       }
/*  70 */       throw new RuntimeException(
/*  71 */           "Unable to process the " + this + " operation");
/*     */     }
/*     */     
/*     */     public String toString() {
/*  75 */       return this.label;
/*     */     }
/*     */     
/*     */     public static String[] getAllLabels() {
/*  79 */       int n = (values()).length;
/*  80 */       String[] result = new String[n];
/*     */       
/*  82 */       int i = 0; byte b; int j; Operation[] arrayOfOperation;
/*  83 */       for (j = (arrayOfOperation = values()).length, b = 0; b < j; ) { Operation op = arrayOfOperation[b];
/*  84 */         result[i++] = op.label; b++; }
/*     */       
/*  86 */       return result;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static Operation fromLabel(String opLabel) {
/*  99 */       if (opLabel != null)
/* 100 */         opLabel = opLabel.toLowerCase();  byte b; int i; Operation[] arrayOfOperation;
/* 101 */       for (i = (arrayOfOperation = values()).length, b = 0; b < i; ) { Operation op = arrayOfOperation[b];
/* 102 */         String cmp = op.label.toLowerCase();
/* 103 */         if (cmp.equals(opLabel))
/* 104 */           return op;  b++; }
/*     */       
/* 106 */       throw new IllegalArgumentException("Unable to parse Operation with label: " + opLabel);
/*     */     }
/*     */   }
/*     */   
/* 110 */   private static final String[] connectivityLabels = new String[] { "6", "26" };
/* 111 */   private static final int[] connectivityValues = new int[] { 6, 26 };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void run(String arg) {
/* 120 */     if (IJ.getVersion().compareTo("1.48a") < 0) {
/*     */       
/* 122 */       IJ.error("Impose Min and Max 3D", "ERROR: detected ImageJ version " + IJ.getVersion() + 
/* 123 */           ".\nThis plugin requires version 1.48a or superior, please update ImageJ!");
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */ 
/*     */     
/* 130 */     int[] indices = WindowManager.getIDList();
/* 131 */     if (indices == null) {
/* 132 */       IJ.error("No image", "Need at least one image to work");
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 137 */     String[] imageNames = new String[indices.length];
/* 138 */     for (int i = 0; i < indices.length; i++) {
/* 139 */       imageNames[i] = WindowManager.getImage(indices[i]).getTitle();
/*     */     }
/*     */ 
/*     */     
/* 143 */     GenericDialog gd = new GenericDialog("Impose Min & Max 3D");
/*     */     
/* 145 */     gd.addChoice("Original Image", imageNames, IJ.getImage().getTitle());
/* 146 */     gd.addChoice("Marker Image", imageNames, IJ.getImage().getTitle());
/* 147 */     gd.addChoice("Operation", 
/* 148 */         Operation.getAllLabels(), 
/* 149 */         Operation.IMPOSE_MINIMA.label);
/* 150 */     gd.addChoice("Connectivity", connectivityLabels, connectivityLabels[0]);
/* 151 */     gd.showDialog();
/*     */     
/* 153 */     if (gd.wasCanceled()) {
/*     */       return;
/*     */     }
/*     */     
/* 157 */     int refImageIndex = gd.getNextChoiceIndex();
/* 158 */     ImagePlus refImage = WindowManager.getImage(refImageIndex + 1);
/* 159 */     int markerImageIndex = gd.getNextChoiceIndex();
/* 160 */     ImagePlus markerImage = WindowManager.getImage(markerImageIndex + 1);
/* 161 */     Operation op = Operation.fromLabel(gd.getNextChoice());
/* 162 */     int conn = connectivityValues[gd.getNextChoiceIndex()];
/*     */ 
/*     */     
/* 165 */     ImageStack refStack = refImage.getStack();
/* 166 */     ImageStack markerStack = markerImage.getStack();
/*     */     
/* 168 */     long t0 = System.currentTimeMillis();
/*     */ 
/*     */     
/* 171 */     ImageStack recProc = op.applyTo(refStack, markerStack, conn);
/*     */ 
/*     */     
/* 174 */     recProc.setColorModel(refStack.getColorModel());
/*     */ 
/*     */     
/* 177 */     String newName = createResultImageName(refImage);
/* 178 */     ImagePlus resultImage = new ImagePlus(newName, recProc);
/* 179 */     resultImage.copyScale(markerImage);
/* 180 */     resultImage.show();
/* 181 */     resultImage.setSlice(refImage.getCurrentSlice());
/*     */     
/* 183 */     long t1 = System.currentTimeMillis();
/* 184 */     IJUtils.showElapsedTime(op.toString(), (t1 - t0), refImage);
/*     */   }
/*     */   
/*     */   private static String createResultImageName(ImagePlus baseImage) {
/* 188 */     return String.valueOf(baseImage.getShortTitle()) + "-imp";
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/plugins/ImposeMinAndMax3DPlugin.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */