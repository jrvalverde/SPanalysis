/*     */ package inra.ijpb.plugins;
/*     */ 
/*     */ import ij.IJ;
/*     */ import ij.ImagePlus;
/*     */ import ij.WindowManager;
/*     */ import ij.gui.GenericDialog;
/*     */ import ij.plugin.PlugIn;
/*     */ import inra.ijpb.binary.BinaryImages;
/*     */ import inra.ijpb.data.image.Images3D;
/*     */ import inra.ijpb.watershed.Watershed;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MarkerControlledWatershed3DPlugin
/*     */   implements PlugIn
/*     */ {
/*     */   public static boolean binaryMarkers = true;
/*     */   public static boolean getDams = true;
/*     */   public static boolean use26neighbors = true;
/*     */   
/*     */   public ImagePlus process(ImagePlus input, ImagePlus marker, ImagePlus mask, int connectivity) {
/*  69 */     long start = System.currentTimeMillis();
/*     */     
/*  71 */     if (binaryMarkers) {
/*     */       
/*  73 */       IJ.log("-> Compute marker labels");
/*  74 */       marker = BinaryImages.componentsLabeling(marker, connectivity, 32);
/*     */     } 
/*     */     
/*  77 */     IJ.log("-> Running watershed...");
/*     */     
/*  79 */     ImagePlus resultImage = Watershed.computeWatershed(input, marker, mask, connectivity, getDams);
/*     */     
/*  81 */     long end = System.currentTimeMillis();
/*  82 */     IJ.log("Watershed 3d took " + (end - start) + " ms.");
/*     */     
/*  84 */     return resultImage;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void run(String arg) {
/*  94 */     int nbima = WindowManager.getImageCount();
/*     */     
/*  96 */     if (nbima < 2) {
/*     */       
/*  98 */       IJ.error("Marker-controlled Watershed", 
/*  99 */           "ERROR: At least two images need to be open to run Marker-controlled Watershed.");
/*     */       
/*     */       return;
/*     */     } 
/* 103 */     String[] names = new String[nbima];
/* 104 */     String[] namesMask = new String[nbima + 1];
/*     */     
/* 106 */     namesMask[0] = "None";
/*     */     
/* 108 */     for (int i = 0; i < nbima; i++) {
/*     */       
/* 110 */       names[i] = WindowManager.getImage(i + 1).getTitle();
/* 111 */       namesMask[i + 1] = WindowManager.getImage(i + 1).getTitle();
/*     */     } 
/*     */     
/* 114 */     GenericDialog gd = new GenericDialog("Marker-controlled Watershed");
/*     */     
/* 116 */     int inputIndex = 0;
/* 117 */     int markerIndex = (nbima > 1) ? 1 : 0;
/*     */     
/* 119 */     gd.addChoice("Input", names, names[inputIndex]);
/* 120 */     gd.addChoice("Marker", names, names[markerIndex]);
/* 121 */     gd.addChoice("Mask", namesMask, namesMask[0]);
/* 122 */     gd.addCheckbox("Binary markers", true);
/* 123 */     gd.addCheckbox("Calculate dams", getDams);
/* 124 */     gd.addCheckbox("Use diagonal connectivity", use26neighbors);
/*     */     
/* 126 */     gd.showDialog();
/*     */     
/* 128 */     if (gd.wasOKed()) {
/*     */       
/* 130 */       inputIndex = gd.getNextChoiceIndex();
/* 131 */       markerIndex = gd.getNextChoiceIndex();
/* 132 */       int maskIndex = gd.getNextChoiceIndex();
/* 133 */       binaryMarkers = gd.getNextBoolean();
/* 134 */       getDams = gd.getNextBoolean();
/* 135 */       use26neighbors = gd.getNextBoolean();
/*     */       
/* 137 */       ImagePlus inputImage = WindowManager.getImage(inputIndex + 1);
/* 138 */       ImagePlus markerImage = WindowManager.getImage(markerIndex + 1);
/* 139 */       ImagePlus maskImage = (maskIndex > 0) ? WindowManager.getImage(maskIndex) : null;
/*     */ 
/*     */ 
/*     */       
/* 143 */       int connectivity = use26neighbors ? 26 : 6;
/* 144 */       if (inputImage.getImageStackSize() == 1) {
/* 145 */         connectivity = use26neighbors ? 8 : 4;
/*     */       }
/* 147 */       ImagePlus result = process(inputImage, markerImage, maskImage, connectivity);
/*     */ 
/*     */       
/* 150 */       result.setSlice(inputImage.getCurrentSlice());
/*     */ 
/*     */       
/* 153 */       Images3D.optimizeDisplayRange(result);
/*     */ 
/*     */       
/* 156 */       result.show();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/plugins/MarkerControlledWatershed3DPlugin.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */