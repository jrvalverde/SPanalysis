/*     */ package inra.ijpb.plugins;
/*     */ 
/*     */ import ij.ImagePlus;
/*     */ import ij.gui.DialogListener;
/*     */ import ij.gui.GenericDialog;
/*     */ import ij.plugin.filter.ExtendedPlugInFilter;
/*     */ import ij.plugin.filter.PlugInFilterRunner;
/*     */ import ij.process.ImageProcessor;
/*     */ import inra.ijpb.algo.Algo;
/*     */ import inra.ijpb.algo.DefaultAlgoListener;
/*     */ import inra.ijpb.binary.ChamferWeights;
/*     */ import inra.ijpb.binary.distmap.DistanceTransform3x3Float;
/*     */ import inra.ijpb.binary.distmap.DistanceTransform3x3Short;
/*     */ import inra.ijpb.binary.distmap.DistanceTransform5x5Float;
/*     */ import inra.ijpb.binary.distmap.DistanceTransform5x5Short;
/*     */ import java.awt.AWTEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ChamferDistanceMapPlugin
/*     */   implements ExtendedPlugInFilter, DialogListener
/*     */ {
/*  55 */   private int flags = 16842765;
/*     */ 
/*     */   
/*     */   PlugInFilterRunner pfr;
/*     */ 
/*     */   
/*     */   int nPasses;
/*     */ 
/*     */   
/*     */   boolean previewing = false;
/*     */ 
/*     */   
/*     */   private ImagePlus imagePlus;
/*     */   
/*     */   private ImageProcessor baseImage;
/*     */   
/*     */   private ChamferWeights weights;
/*     */   
/*     */   private boolean floatProcessing = false;
/*     */   
/*     */   private boolean normalize = false;
/*     */   
/*     */   private ImageProcessor result;
/*     */ 
/*     */   
/*     */   public int setup(String arg, ImagePlus imp) {
/*  81 */     if (arg.equals("final")) {
/*     */       
/*  83 */       this.imagePlus.setProcessor(this.baseImage);
/*  84 */       this.imagePlus.draw();
/*     */ 
/*     */       
/*  87 */       String newName = createResultImageName(this.imagePlus);
/*  88 */       ImagePlus resPlus = new ImagePlus(newName, this.result);
/*  89 */       resPlus.copyScale(this.imagePlus);
/*  90 */       resPlus.show();
/*  91 */       return 4096;
/*     */     } 
/*     */     
/*  94 */     return this.flags;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int showDialog(ImagePlus imp, String command, PlugInFilterRunner pfr) {
/* 100 */     this.imagePlus = imp;
/* 101 */     this.baseImage = imp.getProcessor().duplicate();
/* 102 */     this.pfr = pfr;
/*     */ 
/*     */     
/* 105 */     GenericDialog gd = new GenericDialog("Chamfer Distance Map");
/* 106 */     gd.addChoice("Distances", ChamferWeights.getAllLabels(), 
/* 107 */         ChamferWeights.BORGEFORS.toString());
/* 108 */     String[] outputTypes = { "32 bits", "16 bits" };
/* 109 */     gd.addChoice("Output Type", outputTypes, outputTypes[0]);
/* 110 */     gd.addCheckbox("Normalize weights", true);
/* 111 */     gd.addPreviewCheckbox(pfr);
/* 112 */     gd.addDialogListener(this);
/* 113 */     this.previewing = true;
/* 114 */     gd.addHelp("https://imagej.net/MorphoLibJ");
/* 115 */     gd.showDialog();
/* 116 */     this.previewing = false;
/*     */ 
/*     */     
/* 119 */     if (gd.wasCanceled()) {
/* 120 */       return 4096;
/*     */     }
/*     */     
/* 123 */     String weightLabel = gd.getNextChoice();
/* 124 */     this.floatProcessing = (gd.getNextChoiceIndex() == 0);
/* 125 */     this.normalize = gd.getNextBoolean();
/*     */ 
/*     */     
/* 128 */     this.weights = ChamferWeights.fromLabel(weightLabel);
/*     */     
/* 130 */     return this.flags;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean dialogItemChanged(GenericDialog gd, AWTEvent evt) {
/* 140 */     String weightLabel = gd.getNextChoice();
/* 141 */     this.floatProcessing = (gd.getNextChoiceIndex() == 0);
/* 142 */     this.normalize = gd.getNextBoolean();
/*     */ 
/*     */     
/* 145 */     this.weights = ChamferWeights.fromLabel(weightLabel);
/* 146 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setNPasses(int nPasses) {
/* 151 */     this.nPasses = nPasses;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void run(ImageProcessor image) {
/* 159 */     if (this.floatProcessing) {
/*     */       
/* 161 */       this.result = processFloat(image, this.weights.getFloatWeights(), this.normalize);
/*     */     } else {
/*     */       
/* 164 */       this.result = processShort(image, this.weights.getShortWeights(), this.normalize);
/*     */     } 
/*     */     
/* 167 */     if (this.previewing) {
/*     */ 
/*     */       
/* 170 */       double valMax = this.result.getMax();
/* 171 */       for (int i = 0; i < image.getPixelCount(); i++)
/*     */       {
/* 173 */         image.set(i, (int)((255.0F * this.result.getf(i)) / valMax));
/*     */       }
/* 175 */       image.resetMinAndMax();
/* 176 */       if (image.isInvertedLut()) {
/* 177 */         image.invertLut();
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private ImageProcessor processFloat(ImageProcessor image, float[] weights, boolean normalize) {
/*     */     DistanceTransform5x5Float distanceTransform5x5Float;
/* 186 */     if (weights.length == 2) {
/* 187 */       DistanceTransform3x3Float distanceTransform3x3Float = new DistanceTransform3x3Float(weights, normalize);
/*     */     } else {
/* 189 */       distanceTransform5x5Float = new DistanceTransform5x5Float(weights, normalize);
/*     */     } 
/*     */ 
/*     */     
/* 193 */     DefaultAlgoListener.monitor((Algo)distanceTransform5x5Float);
/*     */ 
/*     */     
/* 196 */     return distanceTransform5x5Float.distanceMap(image);
/*     */   }
/*     */ 
/*     */   
/*     */   private ImageProcessor processShort(ImageProcessor image, short[] weights, boolean normalize) {
/*     */     DistanceTransform5x5Short distanceTransform5x5Short;
/* 202 */     if (weights.length == 2) {
/* 203 */       DistanceTransform3x3Short distanceTransform3x3Short = new DistanceTransform3x3Short(weights, normalize);
/*     */     } else {
/* 205 */       distanceTransform5x5Short = new DistanceTransform5x5Short(weights, normalize);
/*     */     } 
/*     */ 
/*     */     
/* 209 */     DefaultAlgoListener.monitor((Algo)distanceTransform5x5Short);
/*     */ 
/*     */     
/* 212 */     return distanceTransform5x5Short.distanceMap(image);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public Object[] exec(ImagePlus image, String newName, float[] weights, boolean normalize) {
/*     */     DistanceTransform5x5Float distanceTransform5x5Float;
/* 235 */     if (image == null) {
/* 236 */       System.err.println("Mask image not specified");
/* 237 */       return null;
/*     */     } 
/*     */     
/* 240 */     if (newName == null)
/* 241 */       newName = createResultImageName(image); 
/* 242 */     if (weights == null) {
/* 243 */       System.err.println("Weights not specified");
/* 244 */       return null;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 249 */     if (weights.length == 2) {
/* 250 */       DistanceTransform3x3Float distanceTransform3x3Float = new DistanceTransform3x3Float(weights, normalize);
/*     */     } else {
/* 252 */       distanceTransform5x5Float = new DistanceTransform5x5Float(weights, normalize);
/*     */     } 
/*     */     
/* 255 */     ImageProcessor result = distanceTransform5x5Float.distanceMap(image.getProcessor());
/* 256 */     ImagePlus resultPlus = new ImagePlus(newName, result);
/*     */ 
/*     */     
/* 259 */     return new Object[] { newName, resultPlus };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public Object[] exec(ImagePlus image, String newName, short[] weights, boolean normalize) {
/*     */     DistanceTransform5x5Short distanceTransform5x5Short;
/* 280 */     if (image == null) {
/* 281 */       System.err.println("Mask image not specified");
/* 282 */       return null;
/*     */     } 
/*     */     
/* 285 */     if (newName == null)
/* 286 */       newName = createResultImageName(image); 
/* 287 */     if (weights == null) {
/* 288 */       System.err.println("Weights not specified");
/* 289 */       return null;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 294 */     if (weights.length == 2) {
/* 295 */       DistanceTransform3x3Short distanceTransform3x3Short = new DistanceTransform3x3Short(weights, normalize);
/*     */     } else {
/* 297 */       distanceTransform5x5Short = new DistanceTransform5x5Short(weights, normalize);
/*     */     } 
/*     */ 
/*     */     
/* 301 */     ImageProcessor result = distanceTransform5x5Short.distanceMap(image.getProcessor());
/* 302 */     ImagePlus resultPlus = new ImagePlus(newName, result);
/*     */ 
/*     */     
/* 305 */     return new Object[] { newName, resultPlus };
/*     */   }
/*     */   
/*     */   private static String createResultImageName(ImagePlus baseImage) {
/* 309 */     return String.valueOf(baseImage.getShortTitle()) + "-dist";
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/plugins/ChamferDistanceMapPlugin.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */