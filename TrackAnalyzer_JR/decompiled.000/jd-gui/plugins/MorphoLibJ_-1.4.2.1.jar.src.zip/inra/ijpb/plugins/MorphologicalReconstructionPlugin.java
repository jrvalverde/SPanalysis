/*     */ package inra.ijpb.plugins;
/*     */ 
/*     */ import ij.IJ;
/*     */ import ij.ImagePlus;
/*     */ import ij.WindowManager;
/*     */ import ij.gui.GenericDialog;
/*     */ import ij.plugin.PlugIn;
/*     */ import ij.process.ImageProcessor;
/*     */ import inra.ijpb.morphology.Reconstruction;
/*     */ import inra.ijpb.util.IJUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MorphologicalReconstructionPlugin
/*     */   implements PlugIn
/*     */ {
/*     */   public enum Operation
/*     */   {
/*  48 */     BY_DILATION("By Dilation"),
/*  49 */     BY_EROSION("By Erosion");
/*     */     
/*     */     private final String label;
/*     */ 
/*     */     
/*     */     Operation(String label) {
/*  55 */       this.label = label;
/*     */     }
/*     */ 
/*     */     
/*     */     public ImageProcessor applyTo(ImageProcessor marker, ImageProcessor mask, int conn) {
/*  60 */       if (this == BY_DILATION)
/*  61 */         return Reconstruction.reconstructByDilation(marker, mask, conn); 
/*  62 */       if (this == BY_EROSION) {
/*  63 */         return Reconstruction.reconstructByErosion(marker, mask, conn);
/*     */       }
/*  65 */       throw new RuntimeException(
/*  66 */           "Unable to process the " + this + " operation");
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/*  71 */       return this.label;
/*     */     }
/*     */ 
/*     */     
/*     */     public static String[] getAllLabels() {
/*  76 */       int n = (values()).length;
/*  77 */       String[] result = new String[n];
/*     */       
/*  79 */       int i = 0; byte b; int j; Operation[] arrayOfOperation;
/*  80 */       for (j = (arrayOfOperation = values()).length, b = 0; b < j; ) { Operation op = arrayOfOperation[b];
/*  81 */         result[i++] = op.label; b++; }
/*     */       
/*  83 */       return result;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static Operation fromLabel(String opLabel) {
/*  97 */       if (opLabel != null)
/*  98 */         opLabel = opLabel.toLowerCase();  byte b; int i; Operation[] arrayOfOperation;
/*  99 */       for (i = (arrayOfOperation = values()).length, b = 0; b < i; ) { Operation op = arrayOfOperation[b];
/* 100 */         String cmp = op.label.toLowerCase();
/* 101 */         if (cmp.equals(opLabel))
/* 102 */           return op;  b++; }
/*     */       
/* 104 */       throw new IllegalArgumentException("Unable to parse Operation with label: " + opLabel);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   enum Conn2D
/*     */   {
/* 113 */     C4("4", 4),
/* 114 */     C8("8", 8);
/*     */     
/*     */     private final String label;
/*     */     
/*     */     private final int value;
/*     */     
/*     */     Conn2D(String label, int value) {
/* 121 */       this.label = label;
/* 122 */       this.value = value;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 127 */       return this.label;
/*     */     }
/*     */ 
/*     */     
/*     */     public int getValue() {
/* 132 */       return this.value;
/*     */     }
/*     */ 
/*     */     
/*     */     public static String[] getAllLabels() {
/* 137 */       int n = (values()).length;
/* 138 */       String[] result = new String[n];
/*     */       
/* 140 */       int i = 0; byte b; int j; Conn2D[] arrayOfConn2D;
/* 141 */       for (j = (arrayOfConn2D = values()).length, b = 0; b < j; ) { Conn2D op = arrayOfConn2D[b];
/* 142 */         result[i++] = op.label; b++; }
/*     */       
/* 144 */       return result;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static Conn2D fromLabel(String label) {
/* 157 */       if (label != null)
/* 158 */         label = label.toLowerCase();  byte b; int i; Conn2D[] arrayOfConn2D;
/* 159 */       for (i = (arrayOfConn2D = values()).length, b = 0; b < i; ) { Conn2D op = arrayOfConn2D[b];
/*     */         
/* 161 */         String cmp = op.label.toLowerCase();
/* 162 */         if (cmp.equals(label))
/* 163 */           return op;  b++; }
/*     */       
/* 165 */       throw new IllegalArgumentException("Unable to parse Conn2D with label: " + label);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void run(String arg) {
/* 179 */     int[] indices = WindowManager.getIDList();
/* 180 */     if (indices == null) {
/*     */       
/* 182 */       IJ.error("No image", "Need at least one image to work");
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 187 */     String[] imageNames = new String[indices.length];
/* 188 */     for (int i = 0; i < indices.length; i++)
/*     */     {
/* 190 */       imageNames[i] = WindowManager.getImage(indices[i]).getTitle();
/*     */     }
/*     */ 
/*     */     
/* 194 */     GenericDialog gd = new GenericDialog("Morphological Reconstruction");
/*     */     
/* 196 */     gd.addChoice("Marker Image", imageNames, IJ.getImage().getTitle());
/* 197 */     gd.addChoice("Mask Image", imageNames, IJ.getImage().getTitle());
/* 198 */     gd.addChoice("Type of Reconstruction", 
/* 199 */         Operation.getAllLabels(), 
/* 200 */         Operation.BY_DILATION.label);
/* 201 */     gd.addChoice("Connectivity", 
/* 202 */         Conn2D.getAllLabels(), 
/* 203 */         Conn2D.C4.label);
/* 204 */     gd.showDialog();
/*     */     
/* 206 */     if (gd.wasCanceled()) {
/*     */       return;
/*     */     }
/*     */     
/* 210 */     int markerImageIndex = gd.getNextChoiceIndex();
/* 211 */     ImagePlus markerImage = WindowManager.getImage(markerImageIndex + 1);
/* 212 */     int maskImageIndex = gd.getNextChoiceIndex();
/* 213 */     ImagePlus maskImage = WindowManager.getImage(maskImageIndex + 1);
/* 214 */     Operation op = Operation.fromLabel(gd.getNextChoice());
/* 215 */     int conn = Conn2D.fromLabel(gd.getNextChoice()).getValue();
/*     */ 
/*     */     
/* 218 */     ImageProcessor markerProc = markerImage.getProcessor();
/* 219 */     ImageProcessor maskProc = maskImage.getProcessor();
/*     */     
/* 221 */     long t0 = System.currentTimeMillis();
/*     */ 
/*     */     
/* 224 */     ImageProcessor recProc = op.applyTo(markerProc, maskProc, conn);
/*     */ 
/*     */     
/* 227 */     recProc.setColorModel(maskProc.getColorModel());
/*     */ 
/*     */     
/* 230 */     String newName = createResultImageName(markerImage);
/* 231 */     ImagePlus resultImage = new ImagePlus(newName, recProc);
/* 232 */     resultImage.copyScale(maskImage);
/* 233 */     resultImage.show();
/*     */     
/* 235 */     long t1 = System.currentTimeMillis();
/* 236 */     IJUtils.showElapsedTime(op.toString(), (t1 - t0), markerImage);
/*     */   }
/*     */ 
/*     */   
/*     */   private static String createResultImageName(ImagePlus baseImage) {
/* 241 */     return String.valueOf(baseImage.getShortTitle()) + "-rec";
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/plugins/MorphologicalReconstructionPlugin.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */