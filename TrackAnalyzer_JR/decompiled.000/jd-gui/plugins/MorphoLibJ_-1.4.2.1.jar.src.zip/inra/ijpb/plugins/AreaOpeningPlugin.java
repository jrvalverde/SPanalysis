/*     */ package inra.ijpb.plugins;
/*     */ 
/*     */ import ij.IJ;
/*     */ import ij.ImagePlus;
/*     */ import ij.gui.DialogListener;
/*     */ import ij.gui.GenericDialog;
/*     */ import ij.plugin.filter.ExtendedPlugInFilter;
/*     */ import ij.plugin.filter.PlugInFilterRunner;
/*     */ import ij.process.ImageProcessor;
/*     */ import inra.ijpb.binary.BinaryImages;
/*     */ import inra.ijpb.label.LabelImages;
/*     */ import java.awt.AWTEvent;
/*     */ import java.util.HashMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AreaOpeningPlugin
/*     */   implements ExtendedPlugInFilter, DialogListener
/*     */ {
/*  48 */   private int flags = 16842783;
/*     */   
/*     */   PlugInFilterRunner pfr;
/*     */   
/*     */   int nPasses;
/*     */   
/*     */   boolean previewing = false;
/*     */   
/*     */   private ImagePlus imagePlus;
/*     */   
/*     */   private ImageProcessor baseImage;
/*     */   
/*     */   private ImageProcessor result;
/*     */   
/*     */   private ImageProcessor labelImage;
/*     */   
/*     */   private HashMap<Integer, Integer> labelMap;
/*     */   
/*     */   private int[] pixelCountArray;
/*  67 */   int minPixelCount = 100;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int setup(String arg, ImagePlus imp) {
/*  73 */     this.imagePlus = imp;
/*     */     
/*  75 */     if (arg.equals("final")) {
/*     */ 
/*     */       
/*  78 */       this.imagePlus.setProcessor(this.baseImage);
/*  79 */       this.imagePlus.draw();
/*     */ 
/*     */       
/*  82 */       this.result = BinaryImages.areaOpening(this.baseImage, this.minPixelCount);
/*     */       
/*  84 */       this.result.invertLut();
/*     */ 
/*     */       
/*  87 */       String newName = String.valueOf(this.imagePlus.getShortTitle()) + "-areaOpen";
/*  88 */       ImagePlus resPlus = new ImagePlus(newName, this.result);
/*     */ 
/*     */       
/*  91 */       resPlus.copyScale(this.imagePlus);
/*  92 */       this.result.setColorModel(this.baseImage.getColorModel());
/*  93 */       resPlus.show();
/*  94 */       return 4096;
/*     */     } 
/*     */ 
/*     */     
/*  98 */     this.baseImage = imp.getProcessor().duplicate();
/*     */ 
/*     */     
/* 101 */     ImageProcessor image = this.imagePlus.getProcessor();
/*     */     
/*     */     try {
/* 104 */       this.labelImage = BinaryImages.componentsLabeling(image, 4, 16);
/*     */     }
/* 106 */     catch (RuntimeException ex) {
/*     */       
/* 108 */       IJ.error("Too many particles", ex.getMessage());
/* 109 */       return this.flags;
/*     */     } 
/*     */     
/* 112 */     int[] labels = LabelImages.findAllLabels(this.labelImage);
/* 113 */     this.labelMap = LabelImages.mapLabelIndices(labels);
/* 114 */     this.pixelCountArray = LabelImages.pixelCount(this.labelImage, labels);
/*     */     
/* 116 */     return this.flags;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int showDialog(ImagePlus imp, String command, PlugInFilterRunner pfr) {
/* 123 */     GenericDialog gd = new GenericDialog("Area Opening");
/*     */     
/* 125 */     gd.addNumericField("Pixel Number", 100.0D, 0, 10, "pixels");
/*     */     
/* 127 */     gd.addPreviewCheckbox(pfr);
/* 128 */     gd.addDialogListener(this);
/* 129 */     this.previewing = true;
/* 130 */     gd.showDialog();
/* 131 */     this.previewing = false;
/*     */     
/* 133 */     if (gd.wasCanceled()) {
/* 134 */       return 4096;
/*     */     }
/* 136 */     parseDialogParameters(gd);
/*     */ 
/*     */     
/* 139 */     gd.dispose();
/* 140 */     return this.flags;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void run(ImageProcessor image) {
/* 146 */     if (this.previewing)
/*     */     {
/*     */ 
/*     */       
/* 150 */       for (int i = 0; i < image.getPixelCount(); i++) {
/*     */         
/* 152 */         boolean keepPixel = false;
/* 153 */         int label = this.labelImage.get(i);
/* 154 */         if (label > 0) {
/*     */           
/* 156 */           int index = ((Integer)this.labelMap.get(Integer.valueOf(label))).intValue();
/* 157 */           keepPixel = (this.pixelCountArray[index] > this.minPixelCount);
/*     */         } 
/* 159 */         image.set(i, keepPixel ? 255 : 0);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean dialogItemChanged(GenericDialog gd, AWTEvent e) {
/* 167 */     parseDialogParameters(gd);
/* 168 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   private void parseDialogParameters(GenericDialog gd) {
/* 173 */     this.minPixelCount = (int)gd.getNextNumber();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setNPasses(int nPasses) {
/* 179 */     this.nPasses = nPasses;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/plugins/AreaOpeningPlugin.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */