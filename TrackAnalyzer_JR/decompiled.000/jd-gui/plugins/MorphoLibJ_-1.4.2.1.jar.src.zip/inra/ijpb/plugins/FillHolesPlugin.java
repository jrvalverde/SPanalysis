/*    */ package inra.ijpb.plugins;
/*    */ 
/*    */ import ij.IJ;
/*    */ import ij.ImagePlus;
/*    */ import ij.ImageStack;
/*    */ import ij.plugin.PlugIn;
/*    */ import ij.process.ImageProcessor;
/*    */ import inra.ijpb.morphology.Reconstruction;
/*    */ import inra.ijpb.morphology.Reconstruction3D;
/*    */ import inra.ijpb.util.IJUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FillHolesPlugin
/*    */   implements PlugIn
/*    */ {
/*    */   ImagePlus imp;
/*    */   
/*    */   public void run(String arg0) {
/* 45 */     ImagePlus resultPlus, imagePlus = IJ.getImage();
/*    */     
/* 47 */     String newName = String.valueOf(imagePlus.getShortTitle()) + "-fillHoles";
/*    */     
/* 49 */     long t0 = System.currentTimeMillis();
/*    */ 
/*    */     
/* 52 */     if (imagePlus.getStackSize() > 1) {
/*    */       
/* 54 */       ImageStack stack = imagePlus.getStack();
/* 55 */       ImageStack result = Reconstruction3D.fillHoles(stack);
/* 56 */       resultPlus = new ImagePlus(newName, result);
/*    */     
/*    */     }
/*    */     else {
/*    */       
/* 61 */       ImageProcessor image = imagePlus.getProcessor();
/* 62 */       ImageProcessor result = Reconstruction.fillHoles(image);
/* 63 */       resultPlus = new ImagePlus(newName, result);
/*    */     } 
/* 65 */     long elapsedTime = System.currentTimeMillis() - t0;
/*    */     
/* 67 */     resultPlus.show();
/* 68 */     resultPlus.copyScale(imagePlus);
/*    */     
/* 70 */     if (imagePlus.getStackSize() > 1)
/*    */     {
/* 72 */       resultPlus.setSlice(imagePlus.getCurrentSlice());
/*    */     }
/*    */     
/* 75 */     IJUtils.showElapsedTime("Fill Holes", elapsedTime, imagePlus);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/plugins/FillHolesPlugin.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */