/*     */ package inra.ijpb.plugins;
/*     */ 
/*     */ import ij.IJ;
/*     */ import ij.ImagePlus;
/*     */ import ij.ImageStack;
/*     */ import ij.gui.GenericDialog;
/*     */ import ij.plugin.PlugIn;
/*     */ import ij.process.ImageProcessor;
/*     */ import inra.ijpb.data.border.BorderManager;
/*     */ import inra.ijpb.data.border.BorderManager3D;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ExtendBordersPlugin
/*     */   implements PlugIn
/*     */ {
/*     */   public void run(String arg) {
/*  51 */     ImagePlus resPlus, imagePlus = IJ.getImage();
/*     */ 
/*     */     
/*  54 */     GenericDialog gd = new GenericDialog("Extend Image Borders");
/*  55 */     gd.addNumericField("Left", 0.0D, 0);
/*  56 */     gd.addNumericField("Right", 0.0D, 0);
/*  57 */     gd.addNumericField("Top", 0.0D, 0);
/*  58 */     gd.addNumericField("Bottom", 0.0D, 0);
/*  59 */     if (imagePlus.getStackSize() > 1) {
/*     */       
/*  61 */       gd.addNumericField("Front", 0.0D, 0);
/*  62 */       gd.addNumericField("Back", 0.0D, 0);
/*     */     } 
/*  64 */     gd.addChoice("Fill Value", BorderManager.Type.getAllLabels(), 
/*  65 */         BorderManager.Type.REPLICATED.toString());
/*     */     
/*  67 */     gd.showDialog();
/*     */     
/*  69 */     if (gd.wasCanceled()) {
/*     */       return;
/*     */     }
/*     */     
/*  73 */     int left = (int)gd.getNextNumber();
/*  74 */     int right = (int)gd.getNextNumber();
/*  75 */     int top = (int)gd.getNextNumber();
/*  76 */     int bottom = (int)gd.getNextNumber();
/*  77 */     int front = 0, back = 0;
/*  78 */     if (imagePlus.getStackSize() > 1) {
/*     */       
/*  80 */       front = (int)gd.getNextNumber();
/*  81 */       back = (int)gd.getNextNumber();
/*     */     } 
/*     */ 
/*     */     
/*  85 */     String label = gd.getNextChoice();
/*     */     
/*  87 */     if (imagePlus.getStackSize() == 1) {
/*     */       
/*  89 */       BorderManager.Type borderType = BorderManager.Type.fromLabel(label);
/*     */ 
/*     */       
/*  92 */       ImageProcessor image = imagePlus.getProcessor();
/*  93 */       BorderManager border = borderType.createBorderManager(image);
/*     */ 
/*     */       
/*  96 */       ImageProcessor res = process(image, left, right, top, bottom, border);
/*  97 */       resPlus = new ImagePlus(String.valueOf(imagePlus.getShortTitle()) + "-ext", res);
/*     */     }
/*     */     else {
/*     */       
/* 101 */       BorderManager3D.Type borderType = BorderManager3D.Type.fromLabel(label);
/*     */ 
/*     */       
/* 104 */       ImageStack image = imagePlus.getStack();
/* 105 */       BorderManager3D border = borderType.createBorderManager(image);
/*     */ 
/*     */       
/* 108 */       ImageStack res = process(image, left, right, top, bottom, front, back, border);
/* 109 */       resPlus = new ImagePlus(String.valueOf(imagePlus.getShortTitle()) + "-ext", res);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 114 */     resPlus.show();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public ImagePlus exec(ImagePlus image, int left, int right, int top, int bottom, BorderManager border) {
/* 121 */     ImageProcessor proc = image.getProcessor();
/* 122 */     ImageProcessor result = process(proc, left, right, top, bottom, border);
/* 123 */     return new ImagePlus(image.getTitle(), result);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final ImageProcessor process(ImageProcessor image, int left, int right, int top, int bottom, BorderManager border) {
/* 149 */     int width = image.getWidth();
/* 150 */     int height = image.getHeight();
/*     */ 
/*     */     
/* 153 */     int width2 = width + left + right;
/* 154 */     int height2 = height + top + bottom;
/* 155 */     ImageProcessor result = image.createProcessor(width2, height2);
/*     */ 
/*     */     
/* 158 */     for (int x = 0; x < width2; x++) {
/*     */       
/* 160 */       for (int y = 0; y < height2; y++)
/*     */       {
/* 162 */         result.set(x, y, border.get(x - left, y - top));
/*     */       }
/*     */     } 
/*     */     
/* 166 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final ImageStack process(ImageStack image, int left, int right, int top, int bottom, int front, int back, BorderManager3D border) {
/* 195 */     int width = image.getWidth();
/* 196 */     int height = image.getHeight();
/* 197 */     int depth = image.getSize();
/*     */ 
/*     */     
/* 200 */     int width2 = width + left + right;
/* 201 */     int height2 = height + top + bottom;
/* 202 */     int depth2 = depth + front + back;
/* 203 */     ImageStack result = ImageStack.create(width2, height2, depth2, image.getBitDepth());
/*     */ 
/*     */     
/* 206 */     for (int z = 0; z < depth2; z++) {
/*     */       
/* 208 */       for (int y = 0; y < height2; y++) {
/*     */         
/* 210 */         for (int x = 0; x < width2; x++)
/*     */         {
/* 212 */           result.setVoxel(x, y, z, border.get(x - left, y - top, z - front));
/*     */         }
/*     */       } 
/*     */     } 
/* 216 */     return result;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/plugins/ExtendBordersPlugin.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */