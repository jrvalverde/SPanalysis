/*     */ package inra.ijpb.plugins;
/*     */ 
/*     */ import ij.IJ;
/*     */ import ij.ImagePlus;
/*     */ import ij.WindowManager;
/*     */ import ij.gui.GenericDialog;
/*     */ import ij.gui.Overlay;
/*     */ import ij.gui.PolygonRoi;
/*     */ import ij.gui.Roi;
/*     */ import ij.measure.Calibration;
/*     */ import ij.measure.ResultsTable;
/*     */ import ij.plugin.PlugIn;
/*     */ import inra.ijpb.geometry.PointPair2D;
/*     */ import inra.ijpb.label.LabelImages;
/*     */ import inra.ijpb.measure.region2d.MaxFeretDiameter;
/*     */ import java.awt.Color;
/*     */ import java.awt.geom.Point2D;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MaxFeretDiameterPlugin
/*     */   implements PlugIn
/*     */ {
/*     */   public boolean debug = false;
/*     */   
/*     */   public void run(String arg) {
/*  79 */     int[] indices = WindowManager.getIDList();
/*  80 */     if (indices == null) {
/*     */       
/*  82 */       IJ.error("No image", "Need at least one image to work");
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/*  87 */     String[] imageNames = new String[indices.length];
/*  88 */     for (int i = 0; i < indices.length; i++)
/*     */     {
/*  90 */       imageNames[i] = WindowManager.getImage(indices[i]).getTitle();
/*     */     }
/*     */ 
/*     */     
/*  94 */     String selectedImageName = IJ.getImage().getTitle();
/*     */ 
/*     */     
/*  97 */     GenericDialog gd = new GenericDialog("Max. Feret Diameter");
/*  98 */     gd.addChoice("Label Image:", imageNames, selectedImageName);
/*     */     
/* 100 */     gd.addCheckbox("Show Overlay Result", true);
/* 101 */     gd.addChoice("Image to overlay:", imageNames, selectedImageName);
/* 102 */     gd.showDialog();
/*     */     
/* 104 */     if (gd.wasCanceled()) {
/*     */       return;
/*     */     }
/*     */     
/* 108 */     int labelImageIndex = gd.getNextChoiceIndex();
/* 109 */     ImagePlus labelPlus = WindowManager.getImage(labelImageIndex + 1);
/* 110 */     boolean overlay = gd.getNextBoolean();
/* 111 */     int resultImageIndex = gd.getNextChoiceIndex();
/*     */ 
/*     */     
/* 114 */     if (!LabelImages.isLabelImageType(labelPlus)) {
/*     */       
/* 116 */       IJ.showMessage("Input image should be a label image");
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 121 */     MaxFeretDiameter op = new MaxFeretDiameter();
/* 122 */     Map<Integer, PointPair2D> maxDiamsMap = op.analyzeRegions(labelPlus);
/*     */ 
/*     */     
/* 125 */     ResultsTable results = op.createTable(maxDiamsMap);
/*     */ 
/*     */     
/* 128 */     String tableName = String.valueOf(labelPlus.getShortTitle()) + "-FeretDiams";
/*     */ 
/*     */     
/* 131 */     results.show(tableName);
/*     */ 
/*     */     
/* 134 */     if (overlay) {
/*     */       
/* 136 */       ImagePlus resultImage = WindowManager.getImage(resultImageIndex + 1);
/* 137 */       drawDiameters(resultImage, maxDiamsMap);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void drawDiameters(ImagePlus target, Map<Integer, PointPair2D> geodDiams) {
/* 143 */     Overlay overlay = new Overlay();
/* 144 */     Calibration calib = target.getCalibration();
/*     */     
/* 146 */     for (PointPair2D result : geodDiams.values()) {
/*     */       
/* 148 */       Roi roi = createDiametersRoi(result, calib);
/* 149 */       roi.setStrokeColor(Color.BLUE);
/* 150 */       overlay.add(roi);
/*     */     } 
/*     */     
/* 153 */     target.setOverlay(overlay);
/*     */   }
/*     */ 
/*     */   
/*     */   private Roi createDiametersRoi(PointPair2D pointPair, Calibration calib) {
/* 158 */     if (pointPair == null)
/*     */     {
/* 160 */       return null;
/*     */     }
/*     */     
/* 163 */     Point2D p1 = calibToPixel(pointPair.p1, calib);
/* 164 */     Point2D p2 = calibToPixel(pointPair.p2, calib);
/*     */ 
/*     */     
/* 167 */     float[] x = new float[2];
/* 168 */     float[] y = new float[2];
/* 169 */     x[0] = (float)p1.getX();
/* 170 */     y[0] = (float)p1.getY();
/* 171 */     x[1] = (float)p2.getX();
/* 172 */     y[1] = (float)p2.getY();
/* 173 */     return (Roi)new PolygonRoi(x, y, 2, 6);
/*     */   }
/*     */ 
/*     */   
/*     */   private Point2D calibToPixel(Point2D point, Calibration calib) {
/* 178 */     double x = (point.getX() - calib.xOrigin) / calib.pixelWidth;
/* 179 */     double y = (point.getY() - calib.yOrigin) / calib.pixelHeight;
/* 180 */     return new Point2D.Double(x, y);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/plugins/MaxFeretDiameterPlugin.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */