/*     */ package inra.ijpb.plugins;
/*     */ 
/*     */ import ij.IJ;
/*     */ import ij.ImagePlus;
/*     */ import ij.gui.DialogListener;
/*     */ import ij.gui.GenericDialog;
/*     */ import ij.plugin.filter.ExtendedPlugInFilter;
/*     */ import ij.plugin.filter.PlugInFilterRunner;
/*     */ import ij.process.ImageProcessor;
/*     */ import inra.ijpb.morphology.MinimaAndMaxima;
/*     */ import java.awt.AWTEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ExtendedMinAndMaxPlugin
/*     */   implements ExtendedPlugInFilter, DialogListener
/*     */ {
/*     */   public enum Operation
/*     */   {
/*  51 */     EXTENDED_MAXIMA("Extended Maxima", "emax"),
/*  52 */     EXTENDED_MINIMA("Extended Minima", "emin");
/*     */     
/*     */     private final String label;
/*     */     private final String suffix;
/*     */     
/*     */     Operation(String label, String suffix) {
/*  58 */       this.label = label;
/*  59 */       this.suffix = suffix;
/*     */     }
/*     */     
/*     */     public ImageProcessor apply(ImageProcessor image, int dynamic) {
/*  63 */       if (this == EXTENDED_MAXIMA)
/*  64 */         return MinimaAndMaxima.extendedMaxima(image, dynamic); 
/*  65 */       if (this == EXTENDED_MINIMA) {
/*  66 */         return MinimaAndMaxima.extendedMinima(image, dynamic);
/*     */       }
/*  68 */       throw new RuntimeException(
/*  69 */           "Unable to process the " + this + " morphological operation");
/*     */     }
/*     */     
/*     */     public ImageProcessor apply(ImageProcessor image, int dynamic, int connectivity) {
/*  73 */       if (this == EXTENDED_MAXIMA)
/*  74 */         return MinimaAndMaxima.extendedMaxima(image, dynamic, connectivity); 
/*  75 */       if (this == EXTENDED_MINIMA) {
/*  76 */         return MinimaAndMaxima.extendedMinima(image, dynamic, connectivity);
/*     */       }
/*  78 */       throw new RuntimeException(
/*  79 */           "Unable to process the " + this + " morphological operation");
/*     */     }
/*     */     
/*     */     public String toString() {
/*  83 */       return this.label;
/*     */     }
/*     */     
/*     */     public String getSuffix() {
/*  87 */       return this.suffix;
/*     */     }
/*     */     
/*     */     public static String[] getAllLabels() {
/*  91 */       int n = (values()).length;
/*  92 */       String[] result = new String[n];
/*     */       
/*  94 */       int i = 0; byte b; int j; Operation[] arrayOfOperation;
/*  95 */       for (j = (arrayOfOperation = values()).length, b = 0; b < j; ) { Operation op = arrayOfOperation[b];
/*  96 */         result[i++] = op.label; b++; }
/*     */       
/*  98 */       return result;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static Operation fromLabel(String opLabel) {
/* 111 */       if (opLabel != null)
/* 112 */         opLabel = opLabel.toLowerCase();  byte b; int i; Operation[] arrayOfOperation;
/* 113 */       for (i = (arrayOfOperation = values()).length, b = 0; b < i; ) { Operation op = arrayOfOperation[b];
/* 114 */         String cmp = op.label.toLowerCase();
/* 115 */         if (cmp.equals(opLabel))
/* 116 */           return op;  b++; }
/*     */       
/* 118 */       throw new IllegalArgumentException("Unable to parse Operation with label: " + opLabel);
/*     */     }
/*     */   }
/*     */   
/* 122 */   private static final String[] connectivityLabels = new String[] { "4", "8" };
/* 123 */   private static final int[] connectivityValues = new int[] { 4, 8 };
/*     */ 
/*     */ 
/*     */   
/* 127 */   private int flags = 16842783;
/*     */ 
/*     */   
/*     */   PlugInFilterRunner pfr;
/*     */   
/*     */   int nPasses;
/*     */   
/*     */   boolean previewing = false;
/*     */   
/*     */   private ImagePlus imagePlus;
/*     */   
/*     */   private ImageProcessor baseImage;
/*     */   
/*     */   private ImageProcessor result;
/*     */   
/* 142 */   Operation op = Operation.EXTENDED_MINIMA;
/* 143 */   int dynamic = 10;
/* 144 */   int connectivity = 4;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int setup(String arg, ImagePlus imp) {
/* 151 */     if (arg.equals("about")) {
/* 152 */       showAbout();
/* 153 */       return 4096;
/*     */     } 
/*     */ 
/*     */     
/* 157 */     if (arg.equals("final")) {
/*     */       
/* 159 */       this.imagePlus.setProcessor(this.baseImage);
/* 160 */       this.imagePlus.draw();
/*     */ 
/*     */       
/* 163 */       this.result.invertLut();
/*     */ 
/*     */       
/* 166 */       String newName = createResultImageName(this.imagePlus);
/* 167 */       ImagePlus resPlus = new ImagePlus(newName, this.result);
/* 168 */       resPlus.copyScale(this.imagePlus);
/* 169 */       resPlus.show();
/* 170 */       return 4096;
/*     */     } 
/*     */     
/* 173 */     return this.flags;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int showDialog(ImagePlus imp, String command, PlugInFilterRunner pfr) {
/* 179 */     this.imagePlus = imp;
/* 180 */     this.baseImage = imp.getProcessor().duplicate();
/*     */ 
/*     */     
/* 183 */     GenericDialog gd = new GenericDialog("Extended Min & Max");
/*     */     
/* 185 */     gd.addChoice("Operation", Operation.getAllLabels(), Operation.EXTENDED_MINIMA.label);
/* 186 */     boolean isGray8 = this.baseImage instanceof ij.process.ByteProcessor;
/* 187 */     double minValue = isGray8 ? 1.0D : this.baseImage.getMin();
/* 188 */     double maxValue = isGray8 ? 255.0D : this.baseImage.getMax();
/* 189 */     gd.addSlider("Dynamic", minValue, maxValue, 10.0D);
/* 190 */     gd.addChoice("Connectivity", connectivityLabels, connectivityLabels[0]);
/*     */     
/* 192 */     gd.addPreviewCheckbox(pfr);
/* 193 */     gd.addDialogListener(this);
/* 194 */     this.previewing = true;
/* 195 */     gd.addHelp("https://imagej.net/MorphoLibJ");
/* 196 */     gd.showDialog();
/* 197 */     this.previewing = false;
/*     */     
/* 199 */     if (gd.wasCanceled()) {
/* 200 */       return 4096;
/*     */     }
/*     */     
/* 203 */     parseDialogParameters(gd);
/*     */ 
/*     */     
/* 206 */     gd.dispose();
/* 207 */     return this.flags;
/*     */   }
/*     */   
/*     */   public boolean dialogItemChanged(GenericDialog gd, AWTEvent evt) {
/* 211 */     parseDialogParameters(gd);
/* 212 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   private void parseDialogParameters(GenericDialog gd) {
/* 217 */     this.op = Operation.fromLabel(gd.getNextChoice());
/* 218 */     this.dynamic = (int)gd.getNextNumber();
/* 219 */     this.connectivity = connectivityValues[gd.getNextChoiceIndex()];
/*     */   }
/*     */   
/*     */   public void setNPasses(int nPasses) {
/* 223 */     this.nPasses = nPasses;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void run(ImageProcessor image) {
/* 230 */     this.result = this.op.apply(image, this.dynamic, this.connectivity);
/*     */     
/* 232 */     if (this.previewing) {
/*     */ 
/*     */       
/* 235 */       double valMax = this.result.getMax();
/* 236 */       for (int i = 0; i < image.getPixelCount(); i++) {
/* 237 */         image.set(i, 255 - (int)((255.0F * this.result.getf(i)) / valMax));
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void showAbout() {
/* 244 */     IJ.showMessage("Morphological Filters", 
/* 245 */         "Fast Grayscale Morphological Filtering,\nhttp://imagejdocu.tudor.lu/doku.php?id=plugin:morphology:fast_morphological_filters:start\n\nby David Legland\n(david.legland@grignon.inra.fr)");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String createResultImageName(ImagePlus baseImage) {
/* 257 */     return String.valueOf(baseImage.getShortTitle()) + "-" + this.op.getSuffix();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/plugins/ExtendedMinAndMaxPlugin.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */