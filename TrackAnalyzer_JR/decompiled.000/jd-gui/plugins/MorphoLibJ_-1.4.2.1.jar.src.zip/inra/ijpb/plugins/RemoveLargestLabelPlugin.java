/*    */ package inra.ijpb.plugins;
/*    */ 
/*    */ import ij.IJ;
/*    */ import ij.ImagePlus;
/*    */ import ij.plugin.PlugIn;
/*    */ import inra.ijpb.label.LabelImages;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RemoveLargestLabelPlugin
/*    */   implements PlugIn
/*    */ {
/*    */   public void run(String arg0) {
/* 45 */     ImagePlus imagePlus = IJ.getImage();
/*    */     
/* 47 */     ImagePlus resultPlus = imagePlus.duplicate();
/* 48 */     LabelImages.removeLargestLabel(resultPlus);
/* 49 */     String newName = String.valueOf(imagePlus.getShortTitle()) + "-killLargest";
/* 50 */     resultPlus.setTitle(newName);
/*    */ 
/*    */     
/* 53 */     resultPlus.show();
/* 54 */     if (imagePlus.getStackSize() > 1) {
/* 55 */       resultPlus.setZ(imagePlus.getZ());
/* 56 */       resultPlus.setSlice(imagePlus.getCurrentSlice());
/*    */     } 
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/plugins/RemoveLargestLabelPlugin.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */