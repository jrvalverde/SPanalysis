/*     */ package inra.ijpb.plugins;
/*     */ 
/*     */ import ij.IJ;
/*     */ import ij.ImagePlus;
/*     */ import ij.gui.DialogListener;
/*     */ import ij.gui.GenericDialog;
/*     */ import ij.gui.NonBlockingGenericDialog;
/*     */ import ij.gui.Roi;
/*     */ import ij.gui.RoiListener;
/*     */ import ij.gui.Toolbar;
/*     */ import ij.plugin.filter.ExtendedPlugInFilter;
/*     */ import ij.plugin.filter.PlugInFilterRunner;
/*     */ import ij.process.ByteProcessor;
/*     */ import ij.process.ImageProcessor;
/*     */ import ij.process.LUT;
/*     */ import inra.ijpb.algo.Algo;
/*     */ import inra.ijpb.algo.DefaultAlgoListener;
/*     */ import inra.ijpb.binary.BinaryImages;
/*     */ import inra.ijpb.binary.ChamferWeights;
/*     */ import inra.ijpb.binary.geodesic.GeodesicDistanceTransformFloat;
/*     */ import inra.ijpb.binary.geodesic.GeodesicDistanceTransformFloat5x5;
/*     */ import inra.ijpb.binary.geodesic.GeodesicDistanceTransformShort;
/*     */ import inra.ijpb.binary.geodesic.GeodesicDistanceTransformShort5x5;
/*     */ import inra.ijpb.util.ColorMaps;
/*     */ import inra.ijpb.util.IJUtils;
/*     */ import java.awt.AWTEvent;
/*     */ import java.awt.Color;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.image.IndexColorModel;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class InteractiveGeodesicDistanceMap
/*     */   implements ExtendedPlugInFilter, DialogListener
/*     */ {
/*  63 */   private int flags = 16842753;
/*     */   
/*     */   PlugInFilterRunner pfr;
/*     */   
/*     */   int nPasses;
/*     */   
/*     */   boolean previewing = false;
/*     */   
/*     */   private ImagePlus imagePlus;
/*     */   
/*     */   private ImageProcessor baseImage;
/*     */   
/*     */   private NonBlockingGenericDialog gd;
/*     */   
/*     */   private ImageProcessor result;
/*     */   
/*     */   private RoiListener listener;
/*     */   
/*  81 */   private ChamferWeights weights = ChamferWeights.CHESSKNIGHT;
/*     */ 
/*     */   
/*     */   private static boolean resultAsFloat = true;
/*     */ 
/*     */   
/*     */   private static boolean normalize = true;
/*     */ 
/*     */ 
/*     */   
/*     */   public int setup(String arg, ImagePlus imp) {
/*  92 */     if (imp == null) {
/*  93 */       return 4096;
/*     */     }
/*  95 */     if (arg.equals("final")) {
/*     */       
/*  97 */       this.imagePlus.setProcessor(this.baseImage);
/*  98 */       this.imagePlus.draw();
/*     */       
/* 100 */       if (this.result != null) {
/*     */ 
/*     */         
/* 103 */         String newName = createResultImageName(this.imagePlus);
/* 104 */         ImagePlus resPlus = new ImagePlus(newName, this.result);
/* 105 */         resPlus.copyScale(this.imagePlus);
/* 106 */         resPlus.show();
/*     */       } 
/* 108 */       Roi.removeRoiListener(this.listener);
/* 109 */       return 4096;
/*     */     } 
/* 111 */     return this.flags;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int showDialog(ImagePlus imp, String command, final PlugInFilterRunner pfr) {
/* 119 */     if (!BinaryImages.isBinaryImage(imp)) {
/*     */       
/* 121 */       IJ.error("Interactive Geodesic Distance Map", "Input image is not binary (8-bit with only 0 or 255 values)");
/*     */       
/* 123 */       return 4096;
/*     */     } 
/*     */ 
/*     */     
/* 127 */     this.imagePlus = imp;
/* 128 */     this.baseImage = imp.getProcessor().duplicate();
/* 129 */     this.pfr = pfr;
/*     */ 
/*     */     
/* 132 */     this.listener = new RoiListener()
/*     */       {
/*     */         public void roiModified(ImagePlus imp, int id)
/*     */         {
/* 136 */           if (imp == InteractiveGeodesicDistanceMap.this.imagePlus) {
/*     */ 
/*     */             
/* 139 */             InteractiveGeodesicDistanceMap.this.gd.getPreviewCheckbox().setState(false);
/*     */             
/* 141 */             pfr.dialogItemChanged((GenericDialog)InteractiveGeodesicDistanceMap.this.gd, 
/* 142 */                 new ActionEvent(InteractiveGeodesicDistanceMap.this.gd.getPreviewCheckbox(), 
/* 143 */                   1001, "Preview"));
/*     */           } 
/*     */         }
/*     */       };
/* 147 */     Roi.addRoiListener(this.listener);
/*     */ 
/*     */     
/* 150 */     Toolbar.getInstance().setTool(7);
/*     */ 
/*     */     
/* 153 */     this.gd = new NonBlockingGenericDialog("Interactive Geodesic Distance Map");
/*     */ 
/*     */     
/* 156 */     this.gd.addChoice("Distances", ChamferWeights.getAllLabels(), 
/* 157 */         this.weights.toString());
/* 158 */     String[] outputTypes = { "32 bits", "16 bits" };
/* 159 */     this.gd.addChoice("Output Type", outputTypes, 
/* 160 */         outputTypes[resultAsFloat ? 0 : 1]);
/* 161 */     this.gd.addCheckbox("Normalize weights", normalize);
/* 162 */     this.gd.addPreviewCheckbox(pfr);
/* 163 */     this.gd.addDialogListener(this);
/* 164 */     this.previewing = true;
/* 165 */     this.gd.addHelp("http://imagej.net/MorphoLibJ#Utilities_for_binary_images");
/* 166 */     this.gd.showDialog();
/* 167 */     this.previewing = false;
/*     */     
/* 169 */     if (this.gd.wasCanceled()) {
/* 170 */       return 4096;
/*     */     }
/*     */     
/* 173 */     this.weights = ChamferWeights.fromLabel(
/* 174 */         this.gd.getNextChoice());
/* 175 */     resultAsFloat = (this.gd.getNextChoiceIndex() == 0);
/* 176 */     normalize = this.gd.getNextBoolean();
/*     */     
/* 178 */     return this.flags;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean dialogItemChanged(GenericDialog gd, AWTEvent evt) {
/* 188 */     this.weights = ChamferWeights.fromLabel(gd.getNextChoice());
/* 189 */     resultAsFloat = (gd.getNextChoiceIndex() == 0);
/* 190 */     normalize = gd.getNextBoolean();
/* 191 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setNPasses(int nPasses) {
/* 196 */     this.nPasses = nPasses;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void run(ImageProcessor image) {
/* 204 */     if (image == null)
/*     */       return; 
/* 206 */     long t0 = System.currentTimeMillis();
/*     */ 
/*     */     
/* 209 */     if (resultAsFloat) {
/* 210 */       this.result = process(image, this.imagePlus.getRoi(), 
/* 211 */           this.weights.getFloatWeights(), normalize);
/*     */     } else {
/* 213 */       this.result = process(image, this.imagePlus.getRoi(), 
/* 214 */           this.weights.getShortWeights(), normalize);
/*     */     } 
/* 216 */     if (this.result == null) {
/*     */ 
/*     */       
/* 219 */       this.gd.getPreviewCheckbox().setState(false);
/* 220 */       this.pfr.dialogItemChanged((GenericDialog)this.gd, 
/* 221 */           new ActionEvent(this.gd.getPreviewCheckbox(), 
/* 222 */             1001, "Preview"));
/*     */       
/*     */       return;
/*     */     } 
/* 226 */     if (this.previewing) {
/*     */ 
/*     */       
/* 229 */       double valMax = this.result.getMax();
/*     */       
/* 231 */       for (int i = 0; i < image.getPixelCount(); i++)
/*     */       {
/* 233 */         image.set(i, (int)((255.0F * this.result.getf(i)) / valMax));
/*     */       }
/*     */       
/* 236 */       image.setLut(this.result.getLut());
/* 237 */       image.resetMinAndMax();
/* 238 */       if (image.isInvertedLut()) {
/* 239 */         image.invertLut();
/*     */       }
/*     */     } 
/* 242 */     long t1 = System.currentTimeMillis();
/* 243 */     IJUtils.showElapsedTime("Interactive Geodesic Distance Map", (
/* 244 */         t1 - t0), this.imagePlus);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ImageProcessor process(ImageProcessor mask, Roi roi, float[] weights, boolean normalize) {
/*     */     GeodesicDistanceTransformFloat5x5 geodesicDistanceTransformFloat5x5;
/* 266 */     if (mask == null || this.imagePlus == null || this.baseImage == null) {
/*     */       
/* 268 */       IJ.showMessage("Please run the plugin with an image open.");
/* 269 */       return null;
/*     */     } 
/*     */     
/* 272 */     if (weights == null) {
/*     */       
/* 274 */       IJ.showMessage("Weights not specified");
/* 275 */       return null;
/*     */     } 
/*     */     
/* 278 */     if (roi == null) {
/*     */       
/* 280 */       IJ.showMessage("Please define the markers using for example the point selection tool.");
/*     */       
/* 282 */       return null;
/*     */     } 
/*     */     
/* 285 */     ByteProcessor marker = new ByteProcessor(mask.getWidth(), 
/* 286 */         mask.getHeight());
/* 287 */     marker.setColor(Color.WHITE);
/* 288 */     marker.draw(roi);
/*     */ 
/*     */ 
/*     */     
/* 292 */     if (weights.length == 2) {
/* 293 */       GeodesicDistanceTransformFloat geodesicDistanceTransformFloat = new GeodesicDistanceTransformFloat(weights, normalize);
/*     */     } else {
/* 295 */       geodesicDistanceTransformFloat5x5 = new GeodesicDistanceTransformFloat5x5(weights, normalize);
/*     */     } 
/* 297 */     DefaultAlgoListener.monitor((Algo)geodesicDistanceTransformFloat5x5);
/*     */ 
/*     */     
/* 300 */     ImageProcessor result = geodesicDistanceTransformFloat5x5.geodesicDistanceMap((ImageProcessor)marker, mask);
/*     */ 
/*     */     
/* 303 */     double maxVal = result.getMax();
/* 304 */     result.setLut(createFireLUT(maxVal));
/*     */ 
/*     */     
/* 307 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ImageProcessor process(ImageProcessor mask, Roi roi, short[] weights, boolean normalize) {
/*     */     GeodesicDistanceTransformShort5x5 geodesicDistanceTransformShort5x5;
/* 328 */     if (mask == null || this.imagePlus == null || this.baseImage == null) {
/*     */       
/* 330 */       IJ.showMessage("Please run the plugin with an image open.");
/* 331 */       return null;
/*     */     } 
/*     */     
/* 334 */     if (weights == null) {
/*     */       
/* 336 */       IJ.showMessage("Weights not specified");
/* 337 */       return null;
/*     */     } 
/*     */     
/* 340 */     if (roi == null) {
/*     */       
/* 342 */       IJ.showMessage("Please define the markers using for example the point selection tool.");
/*     */       
/* 344 */       return null;
/*     */     } 
/*     */     
/* 347 */     ByteProcessor marker = new ByteProcessor(mask.getWidth(), 
/* 348 */         mask.getHeight());
/* 349 */     marker.setColor(Color.WHITE);
/* 350 */     marker.draw(roi);
/*     */ 
/*     */ 
/*     */     
/* 354 */     if (weights.length == 2) {
/* 355 */       GeodesicDistanceTransformShort geodesicDistanceTransformShort = new GeodesicDistanceTransformShort(weights, normalize);
/*     */     } else {
/* 357 */       geodesicDistanceTransformShort5x5 = new GeodesicDistanceTransformShort5x5(weights, normalize);
/*     */     } 
/* 359 */     DefaultAlgoListener.monitor((Algo)geodesicDistanceTransformShort5x5);
/*     */ 
/*     */     
/* 362 */     ImageProcessor result = geodesicDistanceTransformShort5x5.geodesicDistanceMap((ImageProcessor)marker, mask);
/*     */ 
/*     */     
/* 365 */     double maxVal = result.getMax();
/* 366 */     result.setLut(createFireLUT(maxVal));
/*     */ 
/*     */     
/* 369 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private LUT createFireLUT(double maxVal) {
/* 379 */     byte[][] lut = ColorMaps.createFireLut(256);
/* 380 */     byte[] red = new byte[256];
/* 381 */     byte[] green = new byte[256];
/* 382 */     byte[] blue = new byte[256];
/* 383 */     for (int i = 0; i < 256; i++) {
/*     */       
/* 385 */       red[i] = lut[i][0];
/* 386 */       green[i] = lut[i][1];
/* 387 */       blue[i] = lut[i][2];
/*     */     } 
/* 389 */     IndexColorModel cm = new IndexColorModel(8, 256, red, green, blue);
/* 390 */     return new LUT(cm, 0.0D, maxVal);
/*     */   }
/*     */ 
/*     */   
/*     */   private static String createResultImageName(ImagePlus baseImage) {
/* 395 */     return String.valueOf(baseImage.getShortTitle()) + "-geoddist";
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/plugins/InteractiveGeodesicDistanceMap.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */