/*     */ package inra.ijpb.plugins;
/*     */ 
/*     */ import ij.ImagePlus;
/*     */ import ij.gui.DialogListener;
/*     */ import ij.gui.GenericDialog;
/*     */ import ij.plugin.filter.ExtendedPlugInFilter;
/*     */ import ij.plugin.filter.PlugInFilterRunner;
/*     */ import ij.process.ImageProcessor;
/*     */ import inra.ijpb.algo.Algo;
/*     */ import inra.ijpb.algo.DefaultAlgoListener;
/*     */ import inra.ijpb.morphology.attrfilt.BoxDiagonalOpeningQueue;
/*     */ import java.awt.AWTEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GrayscaleBoxDiameterOpeningPlugin
/*     */   implements ExtendedPlugInFilter, DialogListener
/*     */ {
/*  46 */   private int flags = 16842783;
/*     */ 
/*     */   
/*     */   PlugInFilterRunner pfr;
/*     */   
/*     */   int nPasses;
/*     */   
/*     */   boolean previewing = false;
/*     */   
/*     */   private ImagePlus imagePlus;
/*     */   
/*     */   private ImageProcessor baseImage;
/*     */   
/*     */   private ImageProcessor result;
/*     */   
/*  61 */   int minDiagonalLength = 100;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int setup(String arg, ImagePlus imp) {
/*  67 */     this.imagePlus = imp;
/*     */     
/*  69 */     if (arg.equals("final")) {
/*     */ 
/*     */       
/*  72 */       this.imagePlus.setProcessor(this.baseImage);
/*  73 */       this.imagePlus.draw();
/*     */ 
/*     */       
/*  76 */       String newName = String.valueOf(this.imagePlus.getShortTitle()) + "-boxDiagOpen";
/*  77 */       ImagePlus resPlus = new ImagePlus(newName, this.result);
/*     */ 
/*     */       
/*  80 */       resPlus.copyScale(this.imagePlus);
/*  81 */       this.result.setColorModel(this.baseImage.getColorModel());
/*  82 */       resPlus.show();
/*  83 */       return 4096;
/*     */     } 
/*     */ 
/*     */     
/*  87 */     this.baseImage = imp.getProcessor().duplicate();
/*     */     
/*  89 */     return this.flags;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int showDialog(ImagePlus imp, String command, PlugInFilterRunner pfr) {
/*  96 */     GenericDialog gd = new GenericDialog("Gray Scale Box Diagonal Opening");
/*     */     
/*  98 */     gd.addNumericField("Diagonal Min.", 100.0D, 0, 10, "pixels");
/*     */     
/* 100 */     gd.addPreviewCheckbox(pfr);
/* 101 */     gd.addDialogListener(this);
/* 102 */     this.previewing = true;
/* 103 */     gd.showDialog();
/* 104 */     this.previewing = false;
/*     */     
/* 106 */     if (gd.wasCanceled()) {
/* 107 */       return 4096;
/*     */     }
/* 109 */     parseDialogParameters(gd);
/*     */ 
/*     */     
/* 112 */     gd.dispose();
/* 113 */     return this.flags;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void run(ImageProcessor image) {
/* 119 */     BoxDiagonalOpeningQueue algo = new BoxDiagonalOpeningQueue();
/* 120 */     DefaultAlgoListener.monitor((Algo)algo);
/* 121 */     this.result = algo.process(image, this.minDiagonalLength);
/*     */     
/* 123 */     if (this.previewing)
/*     */     {
/*     */       
/* 126 */       for (int i = 0; i < image.getPixelCount(); i++)
/*     */       {
/* 128 */         image.set(i, this.result.get(i));
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean dialogItemChanged(GenericDialog gd, AWTEvent e) {
/* 136 */     parseDialogParameters(gd);
/* 137 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   private void parseDialogParameters(GenericDialog gd) {
/* 142 */     this.minDiagonalLength = (int)gd.getNextNumber();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setNPasses(int nPasses) {
/* 148 */     this.nPasses = nPasses;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/plugins/GrayscaleBoxDiameterOpeningPlugin.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */