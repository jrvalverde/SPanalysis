/*    */ package inra.ijpb.plugins;
/*    */ 
/*    */ import ij.IJ;
/*    */ import ij.ImagePlus;
/*    */ import ij.gui.GenericDialog;
/*    */ import ij.plugin.PlugIn;
/*    */ import inra.ijpb.label.LabelImages;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LabelAreaOpeningPlugin
/*    */   implements PlugIn
/*    */ {
/*    */   public void run(String arg0) {
/* 38 */     ImagePlus imagePlus = IJ.getImage();
/*    */ 
/*    */     
/* 41 */     boolean isPlanar = (imagePlus.getStackSize() == 1);
/* 42 */     String title = "Label Size Opening";
/* 43 */     GenericDialog gd = new GenericDialog(title);
/* 44 */     String label = isPlanar ? "Min Pixel Number:" : "Min Voxel Number:";
/* 45 */     gd.addNumericField(label, 100.0D, 0);
/* 46 */     gd.showDialog();
/*    */ 
/*    */     
/* 49 */     if (gd.wasCanceled()) {
/*    */       return;
/*    */     }
/* 52 */     int nPixelMin = (int)gd.getNextNumber();
/*    */ 
/*    */     
/* 55 */     ImagePlus resultPlus = LabelImages.sizeOpening(imagePlus, nPixelMin);
/*    */ 
/*    */     
/* 58 */     resultPlus.show();
/* 59 */     if (imagePlus.getStackSize() > 1)
/* 60 */       resultPlus.setSlice(imagePlus.getCurrentSlice()); 
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/plugins/LabelAreaOpeningPlugin.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */