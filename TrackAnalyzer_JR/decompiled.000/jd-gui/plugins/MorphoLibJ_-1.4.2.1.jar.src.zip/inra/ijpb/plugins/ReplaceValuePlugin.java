/*    */ package inra.ijpb.plugins;
/*    */ 
/*    */ import ij.IJ;
/*    */ import ij.ImagePlus;
/*    */ import ij.gui.GenericDialog;
/*    */ import ij.plugin.PlugIn;
/*    */ import inra.ijpb.data.image.Images3D;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ReplaceValuePlugin
/*    */   implements PlugIn
/*    */ {
/*    */   public void run(String arg0) {
/* 41 */     ImagePlus imagePlus = IJ.getImage();
/*    */     
/* 43 */     GenericDialog gd = new GenericDialog("Replace Value");
/* 44 */     gd.addNumericField("Initial Value", 1.0D, 0);
/* 45 */     gd.addNumericField("Final Value", 0.0D, 0);
/* 46 */     gd.showDialog();
/*    */     
/* 48 */     if (gd.wasCanceled()) {
/*    */       return;
/*    */     }
/* 51 */     double initialValue = gd.getNextNumber();
/* 52 */     double finalValue = gd.getNextNumber();
/*    */     
/* 54 */     Images3D.replaceValue(imagePlus, initialValue, finalValue);
/* 55 */     imagePlus.updateAndDraw();
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/plugins/ReplaceValuePlugin.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */