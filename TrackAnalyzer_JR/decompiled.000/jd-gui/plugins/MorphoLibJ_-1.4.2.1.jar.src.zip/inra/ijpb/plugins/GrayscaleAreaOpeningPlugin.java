/*     */ package inra.ijpb.plugins;
/*     */ 
/*     */ import ij.ImagePlus;
/*     */ import ij.gui.DialogListener;
/*     */ import ij.gui.GenericDialog;
/*     */ import ij.plugin.filter.ExtendedPlugInFilter;
/*     */ import ij.plugin.filter.PlugInFilterRunner;
/*     */ import ij.process.ImageProcessor;
/*     */ import inra.ijpb.morphology.AttributeFiltering;
/*     */ import java.awt.AWTEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GrayscaleAreaOpeningPlugin
/*     */   implements ExtendedPlugInFilter, DialogListener
/*     */ {
/*  45 */   private int flags = 16842783;
/*     */ 
/*     */   
/*     */   PlugInFilterRunner pfr;
/*     */   
/*     */   int nPasses;
/*     */   
/*     */   boolean previewing = false;
/*     */   
/*     */   private ImagePlus imagePlus;
/*     */   
/*     */   private ImageProcessor baseImage;
/*     */   
/*     */   private ImageProcessor result;
/*     */   
/*  60 */   int minPixelCount = 100;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int setup(String arg, ImagePlus imp) {
/*  66 */     this.imagePlus = imp;
/*     */     
/*  68 */     if (arg.equals("final")) {
/*     */ 
/*     */       
/*  71 */       this.imagePlus.setProcessor(this.baseImage);
/*  72 */       this.imagePlus.draw();
/*     */ 
/*     */       
/*  75 */       String newName = String.valueOf(this.imagePlus.getShortTitle()) + "-areaOpen";
/*  76 */       ImagePlus resPlus = new ImagePlus(newName, this.result);
/*     */ 
/*     */       
/*  79 */       resPlus.copyScale(this.imagePlus);
/*  80 */       this.result.setColorModel(this.baseImage.getColorModel());
/*  81 */       resPlus.show();
/*  82 */       return 4096;
/*     */     } 
/*     */ 
/*     */     
/*  86 */     this.baseImage = imp.getProcessor().duplicate();
/*     */     
/*  88 */     return this.flags;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int showDialog(ImagePlus imp, String command, PlugInFilterRunner pfr) {
/*  95 */     GenericDialog gd = new GenericDialog("Gray Scale Area Opening");
/*     */     
/*  97 */     gd.addNumericField("Pixel Number", 100.0D, 0, 10, "pixels");
/*     */     
/*  99 */     gd.addPreviewCheckbox(pfr);
/* 100 */     gd.addDialogListener(this);
/* 101 */     this.previewing = true;
/* 102 */     gd.showDialog();
/* 103 */     this.previewing = false;
/*     */     
/* 105 */     if (gd.wasCanceled()) {
/* 106 */       return 4096;
/*     */     }
/* 108 */     parseDialogParameters(gd);
/*     */ 
/*     */     
/* 111 */     gd.dispose();
/* 112 */     return this.flags;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void run(ImageProcessor image) {
/* 118 */     this.result = AttributeFiltering.areaOpening(image, this.minPixelCount);
/*     */     
/* 120 */     if (this.previewing)
/*     */     {
/*     */       
/* 123 */       for (int i = 0; i < image.getPixelCount(); i++)
/*     */       {
/* 125 */         image.set(i, this.result.get(i));
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean dialogItemChanged(GenericDialog gd, AWTEvent e) {
/* 133 */     parseDialogParameters(gd);
/* 134 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   private void parseDialogParameters(GenericDialog gd) {
/* 139 */     this.minPixelCount = (int)gd.getNextNumber();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setNPasses(int nPasses) {
/* 145 */     this.nPasses = nPasses;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/plugins/GrayscaleAreaOpeningPlugin.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */