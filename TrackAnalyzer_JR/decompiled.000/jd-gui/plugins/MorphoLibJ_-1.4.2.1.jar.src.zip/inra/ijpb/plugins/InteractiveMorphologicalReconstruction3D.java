/*     */ package inra.ijpb.plugins;
/*     */ 
/*     */ import ij.IJ;
/*     */ import ij.ImagePlus;
/*     */ import ij.ImageStack;
/*     */ import ij.WindowManager;
/*     */ import ij.gui.NonBlockingGenericDialog;
/*     */ import ij.gui.PointRoi;
/*     */ import ij.gui.Roi;
/*     */ import ij.gui.Toolbar;
/*     */ import ij.plugin.PlugIn;
/*     */ import ij.plugin.frame.RoiManager;
/*     */ import ij.process.ByteProcessor;
/*     */ import ij.process.ColorProcessor;
/*     */ import ij.process.FloatProcessor;
/*     */ import ij.process.ImageProcessor;
/*     */ import ij.process.ShortProcessor;
/*     */ import inra.ijpb.data.image.Images3D;
/*     */ import inra.ijpb.morphology.Reconstruction3D;
/*     */ import inra.ijpb.util.IJUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class InteractiveMorphologicalReconstruction3D
/*     */   implements PlugIn
/*     */ {
/*  57 */   private static Conn3D connectivity = Conn3D.C6;
/*  58 */   private static Operation operation = Operation.BY_DILATION;
/*     */ 
/*     */   
/*     */   private NonBlockingGenericDialog gd;
/*     */ 
/*     */   
/*     */   enum Operation
/*     */   {
/*  66 */     BY_DILATION("By Dilation"),
/*  67 */     BY_EROSION("By Erosion");
/*     */     
/*     */     private final String label;
/*     */     
/*     */     Operation(String label) {
/*  72 */       this.label = label;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImageStack applyTo(ImageStack marker, ImageStack mask, int conn) {
/*  80 */       if (this == BY_DILATION)
/*  81 */         return Reconstruction3D.reconstructByDilation(
/*  82 */             marker, mask, conn); 
/*  83 */       if (this == BY_EROSION) {
/*  84 */         return Reconstruction3D.reconstructByErosion(
/*  85 */             marker, mask, conn);
/*     */       }
/*  87 */       throw new RuntimeException(
/*  88 */           "Unable to process the " + this + " operation");
/*     */     }
/*     */     
/*     */     public String toString() {
/*  92 */       return this.label;
/*     */     }
/*     */     
/*     */     public static String[] getAllLabels() {
/*  96 */       int n = (values()).length;
/*  97 */       String[] result = new String[n];
/*     */       
/*  99 */       int i = 0; byte b; int j; Operation[] arrayOfOperation;
/* 100 */       for (j = (arrayOfOperation = values()).length, b = 0; b < j; ) { Operation op = arrayOfOperation[b];
/* 101 */         result[i++] = op.label; b++; }
/*     */       
/* 103 */       return result;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static Operation fromLabel(String opLabel) {
/* 116 */       if (opLabel != null)
/* 117 */         opLabel = opLabel.toLowerCase();  byte b; int i; Operation[] arrayOfOperation;
/* 118 */       for (i = (arrayOfOperation = values()).length, b = 0; b < i; ) { Operation op = arrayOfOperation[b];
/* 119 */         String cmp = op.label.toLowerCase();
/* 120 */         if (cmp.equals(opLabel))
/* 121 */           return op;  b++; }
/*     */       
/* 123 */       throw new IllegalArgumentException("Unable to parse Operation with label: " + opLabel);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   enum Conn3D
/*     */   {
/* 131 */     C6("6", 6),
/* 132 */     C26("26", 26);
/*     */     
/*     */     private final String label;
/*     */     private final int value;
/*     */     
/*     */     Conn3D(String label, int value) {
/* 138 */       this.label = label;
/* 139 */       this.value = value;
/*     */     }
/*     */     
/*     */     public String toString() {
/* 143 */       return this.label;
/*     */     }
/*     */     
/*     */     public int getValue() {
/* 147 */       return this.value;
/*     */     }
/*     */     
/*     */     public static String[] getAllLabels() {
/* 151 */       int n = (values()).length;
/* 152 */       String[] result = new String[n];
/*     */       
/* 154 */       int i = 0; byte b; int j; Conn3D[] arrayOfConn3D;
/* 155 */       for (j = (arrayOfConn3D = values()).length, b = 0; b < j; ) { Conn3D op = arrayOfConn3D[b];
/* 156 */         result[i++] = op.label; b++; }
/*     */       
/* 158 */       return result;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static Conn3D fromLabel(String opLabel) {
/* 166 */       if (opLabel != null)
/* 167 */         opLabel = opLabel.toLowerCase();  byte b; int i; Conn3D[] arrayOfConn3D;
/* 168 */       for (i = (arrayOfConn3D = values()).length, b = 0; b < i; ) { Conn3D op = arrayOfConn3D[b];
/* 169 */         String cmp = op.label.toLowerCase();
/* 170 */         if (cmp.equals(opLabel))
/* 171 */           return op;  b++; }
/*     */       
/* 173 */       throw new IllegalArgumentException("Unable to parse Conn3D with label: " + 
/* 174 */           opLabel);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void run(String arg) {
/* 184 */     ImagePlus image = WindowManager.getCurrentImage();
/* 185 */     if (image == null || image.getImageStackSize() < 2) {
/*     */       
/* 187 */       IJ.error("Interactive Geodesic Reconstruction 3D", 
/* 188 */           "Need at least one 3D image to work");
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 193 */     Toolbar.getInstance().setTool(7);
/*     */ 
/*     */     
/* 196 */     this.gd = new NonBlockingGenericDialog("Interactive Geodesic Reconstruction 3D");
/*     */ 
/*     */     
/* 199 */     this.gd.addChoice("Type of Reconstruction", 
/* 200 */         Operation.getAllLabels(), 
/* 201 */         operation.label);
/* 202 */     this.gd.addChoice("Connectivity", 
/* 203 */         Conn3D.getAllLabels(), 
/* 204 */         connectivity.label);
/* 205 */     this.gd.addHelp("http://imagej.net/MorphoLibJ");
/* 206 */     this.gd.showDialog();
/*     */     
/* 208 */     if (this.gd.wasCanceled()) {
/*     */       return;
/*     */     }
/*     */     
/* 212 */     operation = Operation.fromLabel(this.gd.getNextChoice());
/* 213 */     connectivity = Conn3D.fromLabel(this.gd.getNextChoice());
/*     */     
/* 215 */     long t0 = System.currentTimeMillis();
/*     */ 
/*     */     
/* 218 */     ImagePlus result = process(image, image.getRoi());
/*     */     
/* 220 */     if (result == null) {
/*     */       return;
/*     */     }
/* 223 */     if (result.getBitDepth() != 24)
/*     */     {
/* 225 */       Images3D.optimizeDisplayRange(result);
/*     */     }
/*     */ 
/*     */     
/* 229 */     result.setSlice(image.getCurrentSlice());
/* 230 */     result.show();
/*     */     
/* 232 */     long t1 = System.currentTimeMillis();
/* 233 */     IJUtils.showElapsedTime(operation.toString(), (t1 - t0), image);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ImagePlus process(ImagePlus mask, Roi roi) {
/*     */     double maxValue;
/* 247 */     if (mask == null) {
/*     */       
/* 249 */       IJ.showMessage("Please run the plugin with an image open.");
/* 250 */       return null;
/*     */     } 
/* 252 */     if (roi == null) {
/*     */       
/* 254 */       IJ.showMessage("Please define the markers using the (multi) point selection tool or the ROI manager.");
/*     */       
/* 256 */       return null;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 262 */     int bitDepth = mask.getBitDepth();
/*     */ 
/*     */     
/* 265 */     if (bitDepth == 8) {
/* 266 */       maxValue = 255.0D;
/* 267 */     } else if (bitDepth == 16) {
/* 268 */       maxValue = 65535.0D;
/* 269 */     } else if (bitDepth == 24) {
/* 270 */       maxValue = 1.6777215E7D;
/*     */     } else {
/* 272 */       maxValue = 3.4028234663852886E38D;
/*     */     } 
/* 274 */     ImageStack markerStack = 
/* 275 */       new ImageStack(mask.getWidth(), mask.getHeight());
/* 276 */     ImageProcessor[] markerSlice = new ImageProcessor[mask.getImageStackSize()]; int n;
/* 277 */     for (n = 0; n < mask.getImageStackSize(); n++) {
/*     */       
/* 279 */       if (bitDepth == 8) {
/* 280 */         markerSlice[n] = (ImageProcessor)new ByteProcessor(mask.getWidth(), mask.getHeight());
/* 281 */       } else if (bitDepth == 16) {
/* 282 */         markerSlice[n] = (ImageProcessor)new ShortProcessor(mask.getWidth(), mask.getHeight());
/* 283 */       } else if (bitDepth == 24) {
/* 284 */         markerSlice[n] = (ImageProcessor)new ColorProcessor(mask.getWidth(), mask.getHeight());
/*     */       } else {
/* 286 */         markerSlice[n] = (ImageProcessor)new FloatProcessor(mask.getWidth(), mask.getHeight());
/*     */       } 
/* 288 */       markerSlice[n].setValue(maxValue);
/* 289 */       markerSlice[n].setColor(maxValue);
/*     */     } 
/*     */     
/* 292 */     if (roi instanceof PointRoi) {
/*     */       
/* 294 */       int[] xpoints = (roi.getPolygon()).xpoints;
/* 295 */       int[] ypoints = (roi.getPolygon()).ypoints;
/*     */       
/* 297 */       for (int i = 0; i < xpoints.length; i++)
/*     */       {
/* 299 */         markerSlice[((PointRoi)roi).getPointPosition(i) - 1].draw(
/* 300 */             (Roi)new PointRoi(xpoints[i], ypoints[i]));
/*     */       
/*     */       }
/*     */     }
/* 304 */     else if (RoiManager.getInstance() != null) {
/*     */       
/* 306 */       RoiManager manager = RoiManager.getInstance();
/* 307 */       int[] selected = manager.getSelectedIndexes();
/* 308 */       if (selected.length > 0) {
/*     */         
/* 310 */         for (int i = 0; i < selected.length; i++) {
/*     */           
/* 312 */           Roi selectedRoi = manager.getRoi(i);
/* 313 */           int slice = 
/* 314 */             manager.getSliceNumber(manager.getName(i));
/* 315 */           if (selectedRoi.isArea()) {
/* 316 */             markerSlice[slice - 1].fill(selectedRoi);
/*     */           } else {
/* 318 */             markerSlice[slice - 1].draw(selectedRoi);
/*     */           } 
/*     */         } 
/*     */       } else {
/*     */         
/* 323 */         IJ.error("Please select the ROIs you want to use as markers in the ROI manager.");
/*     */         
/* 325 */         return null;
/*     */       
/*     */       }
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 332 */       int slice = mask.getCurrentSlice();
/*     */       
/* 334 */       if (roi.isArea()) {
/* 335 */         markerSlice[slice - 1].fill(roi);
/*     */       } else {
/* 337 */         markerSlice[slice - 1].draw(roi);
/*     */       } 
/*     */     } 
/*     */     
/* 341 */     for (n = 0; n < mask.getImageStackSize(); n++)
/*     */     {
/* 343 */       markerStack.addSlice(markerSlice[n]);
/*     */     }
/*     */ 
/*     */     
/* 347 */     if (operation == Operation.BY_EROSION) {
/* 348 */       Images3D.invert(markerStack);
/*     */     }
/*     */     
/* 351 */     ImageStack result = 
/* 352 */       operation.applyTo(markerStack, mask.getImageStack(), 
/* 353 */         connectivity.getValue());
/*     */ 
/*     */     
/* 356 */     result.setColorModel(mask.getImageStack().getColorModel());
/*     */ 
/*     */     
/* 359 */     String newName = String.valueOf(mask.getShortTitle()) + "-rec";
/* 360 */     ImagePlus resultPlus = new ImagePlus(newName, result);
/* 361 */     resultPlus.copyScale(mask);
/*     */     
/* 363 */     resultPlus.setSlice(mask.getCurrentSlice());
/* 364 */     resultPlus.show();
/*     */     
/* 366 */     return resultPlus;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/plugins/InteractiveMorphologicalReconstruction3D.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */