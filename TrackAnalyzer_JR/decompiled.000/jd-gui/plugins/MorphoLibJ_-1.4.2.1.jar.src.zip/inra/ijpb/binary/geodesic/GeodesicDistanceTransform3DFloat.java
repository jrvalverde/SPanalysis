/*     */ package inra.ijpb.binary.geodesic;
/*     */ 
/*     */ import ij.ImageStack;
/*     */ import inra.ijpb.algo.AlgoStub;
/*     */ import inra.ijpb.binary.ChamferWeights3D;
/*     */ import inra.ijpb.data.image.Image3D;
/*     */ import inra.ijpb.data.image.Images3D;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GeodesicDistanceTransform3DFloat
/*     */   extends AlgoStub
/*     */   implements GeodesicDistanceTransform3D
/*     */ {
/*     */   private static final int DEFAULT_MASK_LABEL = 255;
/*     */   float[] weights;
/*     */   boolean normalizeMap = true;
/*  55 */   float backgroundValue = Float.POSITIVE_INFINITY;
/*     */   
/*  57 */   int maskLabel = 255;
/*     */ 
/*     */   
/*     */   ImageStack maskProc;
/*     */   
/*     */   Image3D result;
/*     */   
/*     */   int sizeX;
/*     */   
/*     */   int sizeY;
/*     */   
/*     */   int sizeZ;
/*     */   
/*     */   boolean modif;
/*     */ 
/*     */   
/*     */   public GeodesicDistanceTransform3DFloat(float[] weights) {
/*  74 */     this.weights = weights;
/*     */   }
/*     */ 
/*     */   
/*     */   public GeodesicDistanceTransform3DFloat(float[] weights, boolean normalizeMap) {
/*  79 */     this.weights = weights;
/*  80 */     this.normalizeMap = normalizeMap;
/*     */   }
/*     */ 
/*     */   
/*     */   public GeodesicDistanceTransform3DFloat(ChamferWeights3D weights, boolean normalizeMap) {
/*  85 */     this.weights = weights.getFloatWeights();
/*  86 */     this.normalizeMap = normalizeMap;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ImageStack geodesicDistanceMap(ImageStack marker, ImageStack mask) {
/*  99 */     this.maskProc = mask;
/*     */     
/* 101 */     this.sizeX = mask.getWidth();
/* 102 */     this.sizeY = mask.getHeight();
/* 103 */     this.sizeZ = mask.getSize();
/*     */     
/* 105 */     fireStatusChanged(this, "Initialization...");
/*     */ 
/*     */     
/* 108 */     ImageStack resultStack = ImageStack.create(this.sizeX, this.sizeY, this.sizeZ, 32);
/* 109 */     this.result = Images3D.createWrapper(resultStack);
/*     */ 
/*     */     
/* 112 */     for (int z = 0; z < this.sizeZ; z++) {
/*     */       
/* 114 */       for (int y = 0; y < this.sizeY; y++) {
/*     */         
/* 116 */         for (int x = 0; x < this.sizeX; x++) {
/*     */           
/* 118 */           if (marker.getVoxel(x, y, z) == 0.0D)
/*     */           {
/* 120 */             this.result.setValue(x, y, z, this.backgroundValue);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 127 */     int iter = 0;
/*     */     
/*     */     do {
/* 130 */       this.modif = false;
/*     */ 
/*     */       
/* 133 */       fireStatusChanged(this, "Forward iteration " + iter);
/* 134 */       forwardIteration();
/*     */ 
/*     */       
/* 137 */       fireStatusChanged(this, "Backward iteration " + iter);
/* 138 */       backwardIteration();
/*     */ 
/*     */       
/* 141 */       iter++;
/* 142 */     } while (this.modif);
/*     */ 
/*     */     
/* 145 */     if (this.normalizeMap) {
/*     */       
/* 147 */       fireStatusChanged(this, "Normalize map");
/* 148 */       for (int i = 0; i < this.sizeZ; i++) {
/*     */         
/* 150 */         for (int y = 0; y < this.sizeY; y++) {
/*     */           
/* 152 */           for (int x = 0; x < this.sizeX; x++) {
/*     */             
/* 154 */             double val = this.result.getValue(x, y, i) / this.weights[0];
/* 155 */             this.result.setValue(x, y, i, val);
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 187 */     return resultStack;
/*     */   }
/*     */ 
/*     */   
/*     */   private void forwardIteration() {
/* 192 */     int[][] shifts = { 
/* 193 */         { -1, -1, -1
/* 194 */         }, { 0, -1, -1
/* 195 */         }, { 1, -1, -1
/* 196 */         }, { -1, -1
/* 197 */         }, { 0, 0, -1
/* 198 */         }, { 1, -1
/* 199 */         }, { -1, 1, -1
/* 200 */         }, { 0, 1, -1
/* 201 */         }, { 1, 1, -1
/* 202 */         }, { -1, -1 }, 
/* 203 */         { 0, -1
/* 204 */         }, { 1, -1
/* 205 */         }, { -1 } };
/*     */ 
/*     */     
/* 208 */     double[] shiftWeights = { 
/* 209 */         this.weights[2], this.weights[1], this.weights[2], 
/* 210 */         this.weights[1], this.weights[0], this.weights[1], 
/* 211 */         this.weights[2], this.weights[1], this.weights[2], 
/* 212 */         this.weights[1], this.weights[0], this.weights[1], 
/* 213 */         this.weights[0] };
/*     */ 
/*     */     
/* 216 */     for (int z = 0; z < this.sizeZ; z++) {
/*     */       
/* 218 */       fireProgressChanged(this, z, this.sizeZ);
/* 219 */       for (int y = 0; y < this.sizeY; y++) {
/*     */         
/* 221 */         for (int x = 0; x < this.sizeX; x++) {
/*     */ 
/*     */           
/* 224 */           if (this.maskProc.getVoxel(x, y, z) == this.maskLabel) {
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 229 */             double value = this.result.getValue(x, y, z);
/* 230 */             double ref = value;
/*     */ 
/*     */             
/* 233 */             for (int i = 0; i < shifts.length; i++) {
/*     */               
/* 235 */               int[] shift = shifts[i];
/* 236 */               int x2 = x + shift[0];
/* 237 */               int y2 = y + shift[1];
/* 238 */               int z2 = z + shift[2];
/*     */               
/* 240 */               if (x2 >= 0 && x2 < this.sizeX)
/*     */               {
/* 242 */                 if (y2 >= 0 && y2 < this.sizeY)
/*     */                 {
/* 244 */                   if (z2 >= 0 && z2 < this.sizeZ) {
/*     */ 
/*     */                     
/* 247 */                     double newVal = this.result.getValue(x2, y2, z2) + shiftWeights[i];
/* 248 */                     value = Math.min(value, newVal);
/*     */                   }  }  } 
/*     */             } 
/* 251 */             if (value < ref) {
/*     */               
/* 253 */               this.modif = true;
/* 254 */               this.result.setValue(x, y, z, value);
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/* 260 */     fireProgressChanged(this, 1.0D, 1.0D);
/*     */   }
/*     */ 
/*     */   
/*     */   private void backwardIteration() {
/* 265 */     int[][] shifts = { 
/* 266 */         { 1, 1, 1
/* 267 */         }, { 0, 1, 1
/* 268 */         }, { -1, 1, 1
/* 269 */         }, { 1, 1
/* 270 */         }, { 0, 0, 1
/* 271 */         }, { -1, 1
/* 272 */         }, { 1, -1, 1
/* 273 */         }, { 0, -1, 1
/* 274 */         }, { -1, -1, 1
/* 275 */         }, { 1, 1 }, 
/* 276 */         { 0, 1
/* 277 */         }, { -1, 1
/* 278 */         }, { 1 } };
/*     */ 
/*     */     
/* 281 */     double[] shiftWeights = { 
/* 282 */         this.weights[2], this.weights[1], this.weights[2], 
/* 283 */         this.weights[1], this.weights[0], this.weights[1], 
/* 284 */         this.weights[2], this.weights[1], this.weights[2], 
/* 285 */         this.weights[1], this.weights[0], this.weights[1], 
/* 286 */         this.weights[0] };
/*     */ 
/*     */     
/* 289 */     for (int z = this.sizeZ - 1; z >= 0; z--) {
/*     */       
/* 291 */       fireProgressChanged(this, (this.sizeZ - 1 - z), this.sizeZ);
/* 292 */       for (int y = this.sizeY - 1; y >= 0; y--) {
/*     */         
/* 294 */         for (int x = this.sizeX - 1; x >= 0; x--) {
/*     */ 
/*     */           
/* 297 */           if (this.maskProc.getVoxel(x, y, z) == this.maskLabel) {
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 302 */             double value = this.result.getValue(x, y, z);
/* 303 */             double ref = value;
/*     */ 
/*     */             
/* 306 */             for (int i = 0; i < shifts.length; i++) {
/*     */               
/* 308 */               int[] shift = shifts[i];
/* 309 */               int x2 = x + shift[0];
/* 310 */               int y2 = y + shift[1];
/* 311 */               int z2 = z + shift[2];
/*     */               
/* 313 */               if (x2 >= 0 && x2 < this.sizeX)
/*     */               {
/* 315 */                 if (y2 >= 0 && y2 < this.sizeY)
/*     */                 {
/* 317 */                   if (z2 >= 0 && z2 < this.sizeZ) {
/*     */ 
/*     */                     
/* 320 */                     double newVal = this.result.getValue(x2, y2, z2) + shiftWeights[i];
/* 321 */                     value = Math.min(value, newVal);
/*     */                   }  }  } 
/*     */             } 
/* 324 */             if (value < ref) {
/*     */               
/* 326 */               this.modif = true;
/* 327 */               this.result.setValue(x, y, z, value);
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/* 333 */     fireProgressChanged(this, 1.0D, 1.0D);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/binary/geodesic/GeodesicDistanceTransform3DFloat.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */