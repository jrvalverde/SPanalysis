/*     */ package inra.ijpb.binary.geodesic;
/*     */ 
/*     */ import ij.IJ;
/*     */ import ij.measure.ResultsTable;
/*     */ import ij.process.ImageProcessor;
/*     */ import inra.ijpb.algo.AlgoStub;
/*     */ import inra.ijpb.binary.BinaryImages;
/*     */ import inra.ijpb.binary.ChamferWeights;
/*     */ import inra.ijpb.label.LabelImages;
/*     */ import inra.ijpb.label.LabelValues;
/*     */ import java.awt.Point;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.TreeMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public class GeodesicDiameterFloat
/*     */   extends AlgoStub
/*     */   implements GeodesicDiameter
/*     */ {
/*     */   float[] weights;
/*     */   GeodesicDistanceTransform calculator;
/*     */   int[][] shifts;
/*     */   ImageProcessor labelImage;
/*     */   ImageProcessor distanceMap;
/*     */   
/*     */   public GeodesicDiameterFloat(ChamferWeights chamferWeights) {
/* 108 */     this(chamferWeights.getFloatWeights());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GeodesicDiameterFloat(float[] weights) {
/* 120 */     this.weights = weights;
/* 121 */     chooseDistanceCalculator();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void chooseDistanceCalculator() {
/* 131 */     if (this.weights.length == 3) {
/*     */       
/* 133 */       this.calculator = new GeodesicDistanceTransformFloat5x5(this.weights, false);
/* 134 */       this.shifts = new int[][] { 
/* 135 */           { -1, -2 }, { 0, -2 }, { 1, -2
/* 136 */           }, { -2, -1 }, { -1, -1 }, { 0, -1 }, { 1, -1 }, { 2, -1
/* 137 */           }, { -2 }, { -1 }, { 1 }, { 2
/* 138 */           }, { -2, 1 }, { -1, 1 }, { 0, 1 }, { 1, 1 }, { 2, 1
/* 139 */           }, { -1, 2 }, { 0, 2 }, { 1, 2 } };
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 144 */       this.calculator = new GeodesicDistanceTransformFloat(this.weights, false);
/* 145 */       this.shifts = new int[][] {
/* 146 */           { -1, -1 }, { 0, -1 }, { 1, -1
/* 147 */           }, { -1 }, { 1
/* 148 */           }, { -1, 1 }, { 0, 1 }, { 1, 1 }
/*     */         };
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResultsTable analyzeImage(ImageProcessor labelImage) {
/* 170 */     if (labelImage == null) return null; 
/* 171 */     this.labelImage = labelImage;
/*     */ 
/*     */     
/* 174 */     fireStatusChanged(this, "Count labels in image");
/* 175 */     int[] labels = LabelImages.findAllLabels(labelImage);
/* 176 */     int nbLabels = labels.length;
/*     */     
/* 178 */     fireStatusChanged(this, "Compute binary masks");
/*     */ 
/*     */     
/* 181 */     ImageProcessor mask = BinaryImages.binarize(labelImage);
/*     */ 
/*     */     
/* 184 */     ImageProcessor marker = BinaryImages.binarizeBackground(labelImage);
/*     */     
/* 186 */     fireStatusChanged(this, "Initializing pseudo geodesic centers...");
/*     */ 
/*     */     
/* 189 */     this.distanceMap = this.calculator.geodesicDistanceMap(marker, mask);
/*     */ 
/*     */     
/* 192 */     LabelValues.PositionValuePair[] circles = LabelValues.findMaxValues(this.distanceMap, labelImage, labels);
/*     */ 
/*     */     
/* 195 */     marker.setValue(0.0D);
/* 196 */     marker.fill();
/* 197 */     for (int i = 0; i < nbLabels; i++) {
/*     */       
/* 199 */       Point center = circles[i].getPosition();
/* 200 */       if (center.x == -1) {
/*     */         
/* 202 */         IJ.showMessage("Particle Not Found", 
/* 203 */             "Could not find maximum for particle label " + i);
/*     */       } else {
/*     */         
/* 206 */         marker.set(center.x, center.y, 255);
/*     */       } 
/*     */     } 
/*     */     
/* 210 */     fireStatusChanged(this, "Computing first geodesic extremities...");
/*     */ 
/*     */     
/* 213 */     this.distanceMap = this.calculator.geodesicDistanceMap(marker, mask);
/*     */ 
/*     */ 
/*     */     
/* 217 */     Point[] pos1 = LabelValues.findPositionOfMaxValues(this.distanceMap, labelImage, labels);
/*     */ 
/*     */     
/* 220 */     marker.setValue(0.0D);
/* 221 */     marker.fill();
/* 222 */     for (int j = 0; j < nbLabels; j++) {
/*     */       
/* 224 */       if ((pos1[j]).x == -1) {
/*     */         
/* 226 */         IJ.showMessage("Particle Not Found", 
/* 227 */             "Could not find maximum for particle label " + j);
/*     */       } else {
/*     */         
/* 230 */         marker.set((pos1[j]).x, (pos1[j]).y, 255);
/*     */       } 
/*     */     } 
/* 233 */     fireStatusChanged(this, "Computing second geodesic extremities...");
/*     */ 
/*     */     
/* 236 */     this.distanceMap = this.calculator.geodesicDistanceMap(marker, mask);
/*     */ 
/*     */     
/* 239 */     LabelValues.PositionValuePair[] extremities = LabelValues.findMaxValues(this.distanceMap, labelImage, labels);
/*     */ 
/*     */     
/* 242 */     ResultsTable table = new ResultsTable();
/* 243 */     for (int k = 0; k < nbLabels; k++) {
/*     */ 
/*     */       
/* 246 */       double radius = circles[k].getValue() / this.weights[0];
/* 247 */       Point center = circles[k].getPosition();
/*     */       
/* 249 */       double value = extremities[k].getValue() / this.weights[0] + 1.0D;
/* 250 */       Point extremPos = extremities[k].getPosition();
/*     */ 
/*     */       
/* 253 */       table.incrementCounter();
/* 254 */       table.addValue("Label", labels[k]);
/* 255 */       table.addValue("Geod. Diam", value);
/* 256 */       table.addValue("Radius", radius);
/* 257 */       table.addValue("Geod. Elong.", Math.max(value / radius * 2.0D, 1.0D));
/* 258 */       table.addValue("xi", center.x);
/* 259 */       table.addValue("yi", center.y);
/* 260 */       table.addValue("x1", (pos1[k]).x);
/* 261 */       table.addValue("y1", (pos1[k]).y);
/* 262 */       table.addValue("x2", extremPos.x);
/* 263 */       table.addValue("y2", extremPos.y);
/*     */     } 
/*     */     
/* 266 */     fireStatusChanged(this, "");
/* 267 */     return table;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<Integer, List<Point>> longestGeodesicPaths() {
/* 283 */     int[] labels = LabelImages.findAllLabels(this.labelImage);
/*     */ 
/*     */ 
/*     */     
/* 287 */     Point[] pos1 = LabelValues.findPositionOfMinValues(this.distanceMap, this.labelImage, labels);
/*     */ 
/*     */     
/* 290 */     Point[] pos2 = LabelValues.findPositionOfMaxValues(this.distanceMap, this.labelImage, labels);
/*     */ 
/*     */     
/* 293 */     Map<Integer, List<Point>> result = new TreeMap<Integer, List<Point>>();
/*     */ 
/*     */     
/* 296 */     for (int i = 0; i < labels.length; i++) {
/*     */       
/* 298 */       int label = labels[i];
/*     */       
/* 300 */       List<Point> path = new ArrayList<Point>();
/* 301 */       path.add(pos2[i]);
/*     */       
/* 303 */       Point pos = pos2[i];
/*     */       
/*     */       try {
/* 306 */         while (!pos.equals(pos1[i]))
/*     */         {
/* 308 */           pos = findLowestNeighborPosition(pos);
/* 309 */           path.add(pos);
/*     */         }
/*     */       
/* 312 */       } catch (Exception ex) {
/*     */         
/* 314 */         throw new RuntimeException(String.format("Could not compute path for label %d, at position (%d, %d)", new Object[] {
/* 315 */                 Integer.valueOf(label), Integer.valueOf(pos.x), Integer.valueOf(pos.y)
/*     */               }));
/*     */       } 
/* 318 */       result.put(Integer.valueOf(label), path);
/*     */     } 
/*     */     
/* 321 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Point findLowestNeighborPosition(Point pos) {
/* 335 */     int refLabel = (int)this.labelImage.getf(pos.x, pos.y);
/* 336 */     Point nextPos = pos;
/* 337 */     float minDist = this.distanceMap.getf(pos.x, pos.y);
/*     */ 
/*     */     
/* 340 */     for (int i = 0; i < this.shifts.length; i++) {
/*     */ 
/*     */       
/* 343 */       int x = pos.x + this.shifts[i][0];
/* 344 */       int y = pos.y + this.shifts[i][1];
/*     */ 
/*     */       
/* 347 */       if (x >= 0 && x < this.distanceMap.getWidth())
/*     */       {
/*     */ 
/*     */         
/* 351 */         if (y >= 0 && y < this.distanceMap.getHeight())
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 357 */           if ((int)this.labelImage.getf(x, y) == refLabel) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 363 */             float dist = this.distanceMap.getf(x, y);
/* 364 */             if (dist < minDist) {
/*     */               
/* 366 */               minDist = dist;
/* 367 */               nextPos = new Point(x, y);
/*     */             } 
/*     */           }  }  } 
/*     */     } 
/* 371 */     if (nextPos.equals(pos))
/*     */     {
/* 373 */       throw new RuntimeException("Could not find a neighbor with smaller value");
/*     */     }
/*     */     
/* 376 */     return nextPos;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/binary/geodesic/GeodesicDiameterFloat.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */