package inra.ijpb.binary.geodesic;

import ij.measure.ResultsTable;
import ij.process.ImageProcessor;
import inra.ijpb.algo.Algo;

@Deprecated
public interface GeodesicDiameter extends Algo {
  ResultsTable analyzeImage(ImageProcessor paramImageProcessor);
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/binary/geodesic/GeodesicDiameter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */