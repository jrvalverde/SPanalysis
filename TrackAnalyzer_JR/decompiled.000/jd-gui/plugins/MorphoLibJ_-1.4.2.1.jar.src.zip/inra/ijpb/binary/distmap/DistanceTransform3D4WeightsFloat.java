/*     */ package inra.ijpb.binary.distmap;
/*     */ 
/*     */ import ij.ImageStack;
/*     */ import inra.ijpb.algo.AlgoStub;
/*     */ import inra.ijpb.binary.ChamferWeights3D;
/*     */ import inra.ijpb.data.image.Images3D;
/*     */ import java.util.ArrayList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DistanceTransform3D4WeightsFloat
/*     */   extends AlgoStub
/*     */   implements DistanceTransform3D
/*     */ {
/*     */   private float[] weights;
/*     */   private boolean normalizeMap = true;
/*     */   private int sizeX;
/*     */   private int sizeY;
/*     */   private int sizeZ;
/*     */   private byte[][] maskSlices;
/*     */   private float[][] resultSlices;
/*     */   
/*     */   public DistanceTransform3D4WeightsFloat(ChamferWeights3D weights) {
/*  80 */     this(weights.getFloatWeights(), true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DistanceTransform3D4WeightsFloat(float[] weights) {
/*  89 */     this.weights = weights;
/*  90 */     if (weights.length < 4)
/*     */     {
/*  92 */       throw new IllegalArgumentException("Weights array must have length equal to 4");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DistanceTransform3D4WeightsFloat(ChamferWeights3D weights, boolean normalize) {
/* 106 */     this(weights.getFloatWeights(), normalize);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DistanceTransform3D4WeightsFloat(float[] weights, boolean normalize) {
/* 119 */     this(weights);
/* 120 */     this.normalizeMap = normalize;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ImageStack distanceMap(ImageStack image) {
/* 143 */     this.sizeX = image.getWidth();
/* 144 */     this.sizeY = image.getHeight();
/* 145 */     this.sizeZ = image.getSize();
/*     */ 
/*     */     
/* 148 */     this.maskSlices = Images3D.getByteArrays(image);
/*     */ 
/*     */     
/* 151 */     ImageStack buffer = ImageStack.create(this.sizeX, this.sizeY, this.sizeZ, 32);
/* 152 */     this.resultSlices = Images3D.getFloatArrays(buffer);
/*     */ 
/*     */     
/* 155 */     initializeResultSlices();
/*     */ 
/*     */     
/* 158 */     forwardScan();
/* 159 */     backwardScan();
/*     */ 
/*     */     
/* 162 */     if (this.normalizeMap)
/*     */     {
/* 164 */       normalizeResultSlices();
/*     */     }
/*     */     
/* 167 */     fireStatusChanged(this, "");
/* 168 */     return buffer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void initializeResultSlices() {
/* 181 */     fireStatusChanged(this, "Initialization...");
/*     */ 
/*     */     
/* 184 */     for (int z = 0; z < this.sizeZ; z++) {
/*     */       
/* 186 */       byte[] maskSlice = this.maskSlices[z];
/* 187 */       float[] resultSlice = this.resultSlices[z];
/*     */       
/* 189 */       for (int y = 0; y < this.sizeY; y++) {
/*     */         
/* 191 */         for (int x = 0; x < this.sizeX; x++) {
/*     */           
/* 193 */           int index = this.sizeX * y + x;
/* 194 */           int val = maskSlice[index];
/* 195 */           resultSlice[index] = (val == 0) ? 0.0F : Float.MAX_VALUE;
/*     */         } 
/*     */       } 
/*     */     } 
/* 199 */     fireProgressChanged(this, 1.0D, 1.0D);
/*     */   }
/*     */ 
/*     */   
/*     */   private void forwardScan() {
/* 204 */     fireStatusChanged(this, "Forward scan...");
/*     */ 
/*     */     
/* 207 */     ArrayList<WeightedOffset> offsets = new ArrayList<WeightedOffset>();
/*     */ 
/*     */     
/* 210 */     offsets.add(new WeightedOffset(-1, -1, -2, this.weights[3]));
/* 211 */     offsets.add(new WeightedOffset(1, -1, -2, this.weights[3]));
/* 212 */     offsets.add(new WeightedOffset(-1, 1, -2, this.weights[3]));
/* 213 */     offsets.add(new WeightedOffset(1, 1, -2, this.weights[3]));
/*     */ 
/*     */     
/* 216 */     offsets.add(new WeightedOffset(-1, -1, -1, this.weights[2]));
/* 217 */     offsets.add(new WeightedOffset(0, -1, -1, this.weights[1]));
/* 218 */     offsets.add(new WeightedOffset(1, -1, -1, this.weights[2]));
/* 219 */     offsets.add(new WeightedOffset(-1, 0, -1, this.weights[1]));
/* 220 */     offsets.add(new WeightedOffset(0, 0, -1, this.weights[0]));
/* 221 */     offsets.add(new WeightedOffset(1, 0, -1, this.weights[1]));
/* 222 */     offsets.add(new WeightedOffset(-1, 1, -1, this.weights[2]));
/* 223 */     offsets.add(new WeightedOffset(0, 1, -1, this.weights[1]));
/* 224 */     offsets.add(new WeightedOffset(1, 1, -1, this.weights[2]));
/*     */     
/* 226 */     offsets.add(new WeightedOffset(-1, -2, -1, this.weights[3]));
/* 227 */     offsets.add(new WeightedOffset(1, -2, -1, this.weights[3]));
/* 228 */     offsets.add(new WeightedOffset(-2, -1, -1, this.weights[3]));
/* 229 */     offsets.add(new WeightedOffset(2, -1, -1, this.weights[3]));
/* 230 */     offsets.add(new WeightedOffset(-2, 1, -1, this.weights[3]));
/* 231 */     offsets.add(new WeightedOffset(2, 1, -1, this.weights[3]));
/* 232 */     offsets.add(new WeightedOffset(-1, 2, -1, this.weights[3]));
/* 233 */     offsets.add(new WeightedOffset(1, 2, -1, this.weights[3]));
/*     */ 
/*     */     
/* 236 */     offsets.add(new WeightedOffset(-1, -1, 0, this.weights[1]));
/* 237 */     offsets.add(new WeightedOffset(0, -1, 0, this.weights[0]));
/* 238 */     offsets.add(new WeightedOffset(1, -1, 0, this.weights[1]));
/* 239 */     offsets.add(new WeightedOffset(-1, 0, 0, this.weights[0]));
/*     */ 
/*     */     
/* 242 */     for (int z = 0; z < this.sizeZ; z++) {
/*     */       
/* 244 */       fireProgressChanged(this, z, this.sizeZ);
/*     */       
/* 246 */       byte[] maskSlice = this.maskSlices[z];
/* 247 */       float[] currentSlice = this.resultSlices[z];
/*     */       
/* 249 */       for (int y = 0; y < this.sizeY; y++) {
/*     */         
/* 251 */         for (int x = 0; x < this.sizeX; x++) {
/*     */           
/* 253 */           int index = this.sizeX * y + x;
/*     */ 
/*     */           
/* 256 */           if ((maskSlice[index] & 0xFF) != 0) {
/*     */ 
/*     */             
/* 259 */             double value = currentSlice[index];
/*     */             
/* 261 */             double newVal = 3.4028234663852886E38D;
/* 262 */             for (WeightedOffset offset : offsets) {
/*     */               
/* 264 */               int x2 = x + offset.dx;
/* 265 */               int y2 = y + offset.dy;
/* 266 */               int z2 = z + offset.dz;
/*     */ 
/*     */               
/* 269 */               if (x2 >= 0 && x2 < this.sizeX && y2 >= 0 && y2 < this.sizeY && z2 >= 0 && z2 < this.sizeZ)
/*     */               {
/* 271 */                 newVal = Math.min(newVal, (this.resultSlices[z2][this.sizeX * y2 + x2] + offset.weight));
/*     */               }
/*     */               
/* 274 */               if (newVal < value)
/*     */               {
/* 276 */                 currentSlice[index] = (float)newVal; } 
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/* 282 */     fireProgressChanged(this, 1.0D, 1.0D);
/*     */   }
/*     */ 
/*     */   
/*     */   private void backwardScan() {
/* 287 */     fireStatusChanged(this, "Backward scan...");
/*     */ 
/*     */     
/* 290 */     ArrayList<WeightedOffset> offsets = new ArrayList<WeightedOffset>();
/*     */ 
/*     */     
/* 293 */     offsets.add(new WeightedOffset(-1, -1, 2, this.weights[3]));
/* 294 */     offsets.add(new WeightedOffset(1, -1, 2, this.weights[3]));
/* 295 */     offsets.add(new WeightedOffset(-1, 1, 2, this.weights[3]));
/* 296 */     offsets.add(new WeightedOffset(1, 1, 2, this.weights[3]));
/*     */ 
/*     */     
/* 299 */     offsets.add(new WeightedOffset(-1, -1, 1, this.weights[2]));
/* 300 */     offsets.add(new WeightedOffset(0, -1, 1, this.weights[1]));
/* 301 */     offsets.add(new WeightedOffset(1, -1, 1, this.weights[2]));
/* 302 */     offsets.add(new WeightedOffset(-1, 0, 1, this.weights[1]));
/* 303 */     offsets.add(new WeightedOffset(0, 0, 1, this.weights[0]));
/* 304 */     offsets.add(new WeightedOffset(1, 0, 1, this.weights[1]));
/* 305 */     offsets.add(new WeightedOffset(-1, 1, 1, this.weights[2]));
/* 306 */     offsets.add(new WeightedOffset(0, 1, 1, this.weights[1]));
/* 307 */     offsets.add(new WeightedOffset(1, 1, 1, this.weights[2]));
/*     */     
/* 309 */     offsets.add(new WeightedOffset(-1, -2, 1, this.weights[3]));
/* 310 */     offsets.add(new WeightedOffset(1, -2, 1, this.weights[3]));
/* 311 */     offsets.add(new WeightedOffset(-2, -1, 1, this.weights[3]));
/* 312 */     offsets.add(new WeightedOffset(2, -1, 1, this.weights[3]));
/* 313 */     offsets.add(new WeightedOffset(-2, 1, 1, this.weights[3]));
/* 314 */     offsets.add(new WeightedOffset(2, 1, 1, this.weights[3]));
/* 315 */     offsets.add(new WeightedOffset(-1, 2, 1, this.weights[3]));
/* 316 */     offsets.add(new WeightedOffset(1, 2, 1, this.weights[3]));
/*     */ 
/*     */     
/* 319 */     offsets.add(new WeightedOffset(-1, 1, 0, this.weights[1]));
/* 320 */     offsets.add(new WeightedOffset(0, 1, 0, this.weights[0]));
/* 321 */     offsets.add(new WeightedOffset(1, 1, 0, this.weights[1]));
/* 322 */     offsets.add(new WeightedOffset(1, 0, 0, this.weights[0]));
/*     */ 
/*     */     
/* 325 */     for (int z = this.sizeZ - 1; z >= 0; z--) {
/*     */       
/* 327 */       fireProgressChanged(this, (this.sizeZ - 1 - z), this.sizeZ);
/*     */       
/* 329 */       byte[] maskSlice = this.maskSlices[z];
/* 330 */       float[] currentSlice = this.resultSlices[z];
/*     */       
/* 332 */       for (int y = this.sizeY - 1; y >= 0; y--) {
/*     */         
/* 334 */         for (int x = this.sizeX - 1; x >= 0; x--) {
/*     */           
/* 336 */           int index = this.sizeX * y + x;
/*     */ 
/*     */           
/* 339 */           if ((maskSlice[index] & 0xFF) != 0) {
/*     */ 
/*     */             
/* 342 */             double value = currentSlice[index];
/*     */             
/* 344 */             double newVal = 3.4028234663852886E38D;
/* 345 */             for (WeightedOffset offset : offsets) {
/*     */               
/* 347 */               int x2 = x + offset.dx;
/* 348 */               int y2 = y + offset.dy;
/* 349 */               int z2 = z + offset.dz;
/*     */ 
/*     */               
/* 352 */               if (x2 >= 0 && x2 < this.sizeX && y2 >= 0 && y2 < this.sizeY && z2 >= 0 && z2 < this.sizeZ)
/*     */               {
/* 354 */                 newVal = Math.min(newVal, (this.resultSlices[z2][this.sizeX * y2 + x2] + offset.weight));
/*     */               }
/*     */               
/* 357 */               if (newVal < value)
/*     */               {
/* 359 */                 currentSlice[index] = (float)newVal; } 
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/* 365 */     fireProgressChanged(this, 1.0D, 1.0D);
/*     */   }
/*     */ 
/*     */   
/*     */   private void normalizeResultSlices() {
/* 370 */     fireStatusChanged(this, "Normalize map...");
/* 371 */     for (int z = 0; z < this.sizeZ; z++) {
/*     */       
/* 373 */       fireProgressChanged(this, z, this.sizeZ);
/*     */       
/* 375 */       byte[] maskSlice = this.maskSlices[z];
/* 376 */       float[] resultSlice = this.resultSlices[z];
/*     */       
/* 378 */       for (int y = 0; y < this.sizeY; y++) {
/*     */         
/* 380 */         for (int x = 0; x < this.sizeX; x++) {
/*     */           
/* 382 */           int index = this.sizeX * y + x;
/* 383 */           if (maskSlice[index] != 0)
/*     */           {
/* 385 */             resultSlice[index] = resultSlice[index] / this.weights[0];
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/* 390 */     fireProgressChanged(this, 1.0D, 1.0D);
/*     */   }
/*     */ 
/*     */   
/*     */   private class WeightedOffset
/*     */   {
/*     */     int dx;
/*     */     int dy;
/*     */     int dz;
/*     */     float weight;
/*     */     
/*     */     public WeightedOffset(int dx, int dy, int dz, float weight) {
/* 402 */       this.dx = dx;
/* 403 */       this.dy = dy;
/* 404 */       this.dz = dz;
/* 405 */       this.weight = weight;
/*     */     }
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/binary/distmap/DistanceTransform3D4WeightsFloat.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */