/*     */ package inra.ijpb.binary.distmap;
/*     */ 
/*     */ import ij.process.FloatProcessor;
/*     */ import ij.process.ImageProcessor;
/*     */ import inra.ijpb.algo.AlgoEvent;
/*     */ import inra.ijpb.algo.AlgoStub;
/*     */ import inra.ijpb.binary.ChamferWeights;
/*     */ import inra.ijpb.label.LabelValues;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DistanceTransform5x5Float
/*     */   extends AlgoStub
/*     */   implements DistanceTransform
/*     */ {
/*     */   private float[] weights;
/*     */   private boolean normalizeMap = true;
/*     */   
/*     */   public DistanceTransform5x5Float() {
/*  86 */     this(new float[] { 5.0F, 7.0F, 11.0F }, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DistanceTransform5x5Float(ChamferWeights weights) {
/*  98 */     this(weights.getFloatWeights(), true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DistanceTransform5x5Float(float[] weights) {
/* 108 */     this(weights, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DistanceTransform5x5Float(ChamferWeights weights, boolean normalize) {
/* 123 */     this(weights.getFloatWeights(), normalize);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DistanceTransform5x5Float(float[] weights, boolean normalize) {
/* 138 */     if (weights.length < 3) {
/*     */       
/* 140 */       float[] newWeights = new float[3];
/* 141 */       newWeights[0] = weights[0];
/* 142 */       newWeights[1] = weights[1];
/* 143 */       newWeights[2] = weights[0] + weights[1];
/* 144 */       weights = newWeights;
/*     */     } 
/* 146 */     this.weights = weights;
/* 147 */     this.normalizeMap = normalize;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FloatProcessor distanceMap(ImageProcessor labelImage) {
/* 166 */     FloatProcessor distMap = initializeResult(labelImage);
/*     */ 
/*     */     
/* 169 */     forwardScan(distMap, labelImage);
/* 170 */     backwardScan(distMap, labelImage);
/*     */ 
/*     */     
/* 173 */     if (this.normalizeMap)
/*     */     {
/* 175 */       normalizeResult(distMap, labelImage);
/*     */     }
/*     */ 
/*     */     
/* 179 */     double maxVal = LabelValues.maxValueWithinLabels((ImageProcessor)distMap, labelImage);
/* 180 */     distMap.setMinAndMax(0.0D, maxVal);
/*     */ 
/*     */     
/* 183 */     if (distMap.isInvertedLut()) {
/* 184 */       distMap.invertLut();
/*     */     }
/* 186 */     fireStatusChanged(new AlgoEvent(this, ""));
/*     */     
/* 188 */     return distMap;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private FloatProcessor initializeResult(ImageProcessor labelImage) {
/* 197 */     fireStatusChanged(new AlgoEvent(this, "Initialization"));
/*     */ 
/*     */     
/* 200 */     int sizeX = labelImage.getWidth();
/* 201 */     int sizeY = labelImage.getHeight();
/*     */ 
/*     */     
/* 204 */     FloatProcessor distMap = new FloatProcessor(sizeX, sizeY);
/* 205 */     distMap.setValue(0.0D);
/* 206 */     distMap.fill();
/*     */ 
/*     */     
/* 209 */     for (int y = 0; y < sizeY; y++) {
/*     */       
/* 211 */       for (int x = 0; x < sizeX; x++) {
/*     */         
/* 213 */         int label = (int)labelImage.getf(x, y);
/* 214 */         distMap.setf(x, y, (label == 0) ? 0.0F : Float.POSITIVE_INFINITY);
/*     */       } 
/*     */     } 
/*     */     
/* 218 */     return distMap;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void forwardScan(FloatProcessor distMap, ImageProcessor labelImage) {
/* 224 */     fireStatusChanged(new AlgoEvent(this, "Forward Scan"));
/*     */ 
/*     */     
/* 227 */     int[] dx = { -1, 1, -2, -1, 1, 2, -1 };
/* 228 */     int[] dy = { -2, -2, -1, -1, -1, -1, -1 };
/*     */     
/* 230 */     float[] dw = {
/* 231 */         this.weights[2], this.weights[2], 
/* 232 */         this.weights[2], this.weights[1], this.weights[0], this.weights[1], this.weights[2], 
/* 233 */         this.weights[0]
/*     */       };
/*     */     
/* 236 */     int sizeX = labelImage.getWidth();
/* 237 */     int sizeY = labelImage.getHeight();
/*     */ 
/*     */     
/* 240 */     for (int y = 0; y < sizeY; y++) {
/*     */       
/* 242 */       fireProgressChanged(this, y, sizeY);
/* 243 */       for (int x = 0; x < sizeX; x++) {
/*     */ 
/*     */         
/* 246 */         int label = (int)labelImage.getf(x, y);
/*     */ 
/*     */         
/* 249 */         if (label != 0) {
/*     */ 
/*     */ 
/*     */           
/* 253 */           float currentDist = distMap.getf(x, y);
/* 254 */           float newDist = currentDist;
/*     */ 
/*     */           
/* 257 */           for (int i = 0; i < dx.length; i++) {
/*     */ 
/*     */             
/* 260 */             int x2 = x + dx[i];
/* 261 */             int y2 = y + dy[i];
/*     */ 
/*     */             
/* 264 */             if (x2 >= 0 && x2 < sizeX)
/*     */             {
/* 266 */               if (y2 >= 0 && y2 < sizeY)
/*     */               {
/*     */                 
/* 269 */                 if ((int)labelImage.getf(x2, y2) != label) {
/*     */ 
/*     */                   
/* 272 */                   newDist = Math.min(newDist, dw[i]);
/*     */                 
/*     */                 }
/*     */                 else {
/*     */                   
/* 277 */                   newDist = Math.min(newDist, distMap.getf(x2, y2) + dw[i]);
/*     */                 }  } 
/*     */             }
/*     */           } 
/* 281 */           if (newDist < currentDist)
/*     */           {
/* 283 */             distMap.setf(x, y, newDist);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/* 288 */     fireProgressChanged(this, sizeY, sizeY);
/*     */   }
/*     */ 
/*     */   
/*     */   private void backwardScan(FloatProcessor distMap, ImageProcessor labelImage) {
/* 293 */     fireStatusChanged(new AlgoEvent(this, "Backward Scan"));
/*     */     
/* 295 */     int[] dx = { 1, -1, 2, 1, -1, -2, 1 };
/* 296 */     int[] dy = { 2, 2, 1, 1, 1, 1, 1 };
/*     */     
/* 298 */     float[] dw = {
/* 299 */         this.weights[2], this.weights[2], 
/* 300 */         this.weights[2], this.weights[1], this.weights[0], this.weights[1], this.weights[2], 
/* 301 */         this.weights[0]
/*     */       };
/*     */     
/* 304 */     int sizeX = labelImage.getWidth();
/* 305 */     int sizeY = labelImage.getHeight();
/*     */ 
/*     */     
/* 308 */     for (int y = sizeY - 1; y >= 0; y--) {
/*     */       
/* 310 */       fireProgressChanged(this, (sizeY - 1 - y), sizeY);
/* 311 */       for (int x = sizeX - 1; x >= 0; x--) {
/*     */ 
/*     */         
/* 314 */         int label = (int)labelImage.getf(x, y);
/*     */ 
/*     */         
/* 317 */         if (label != 0) {
/*     */ 
/*     */ 
/*     */           
/* 321 */           float currentDist = distMap.getf(x, y);
/* 322 */           float newDist = currentDist;
/*     */ 
/*     */           
/* 325 */           for (int i = 0; i < dx.length; i++) {
/*     */ 
/*     */             
/* 328 */             int x2 = x + dx[i];
/* 329 */             int y2 = y + dy[i];
/*     */ 
/*     */             
/* 332 */             if (x2 >= 0 && x2 < sizeX)
/*     */             {
/* 334 */               if (y2 >= 0 && y2 < sizeY)
/*     */               {
/*     */                 
/* 337 */                 if ((int)labelImage.getf(x2, y2) != label) {
/*     */ 
/*     */                   
/* 340 */                   newDist = Math.min(newDist, dw[i]);
/*     */                 
/*     */                 }
/*     */                 else {
/*     */                   
/* 345 */                   newDist = Math.min(newDist, distMap.getf(x2, y2) + dw[i]);
/*     */                 }  } 
/*     */             }
/*     */           } 
/* 349 */           if (newDist < currentDist)
/*     */           {
/* 351 */             distMap.setf(x, y, newDist);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/* 356 */     fireProgressChanged(this, sizeY, sizeY);
/*     */   }
/*     */ 
/*     */   
/*     */   private void normalizeResult(FloatProcessor distMap, ImageProcessor labelImage) {
/* 361 */     fireStatusChanged(new AlgoEvent(this, "Normalization"));
/*     */ 
/*     */     
/* 364 */     int sizeX = labelImage.getWidth();
/* 365 */     int sizeY = labelImage.getHeight();
/*     */ 
/*     */     
/* 368 */     float w0 = this.weights[0];
/*     */     
/* 370 */     for (int y = 0; y < sizeY; y++) {
/*     */       
/* 372 */       for (int x = 0; x < sizeX; x++) {
/*     */         
/* 374 */         if ((int)labelImage.getf(x, y) > 0)
/*     */         {
/* 376 */           distMap.setf(x, y, distMap.getf(x, y) / w0);
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/binary/distmap/DistanceTransform5x5Float.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */