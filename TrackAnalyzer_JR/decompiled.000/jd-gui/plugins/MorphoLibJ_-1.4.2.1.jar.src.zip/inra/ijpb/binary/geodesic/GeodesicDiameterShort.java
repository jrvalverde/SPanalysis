/*     */ package inra.ijpb.binary.geodesic;
/*     */ 
/*     */ import ij.IJ;
/*     */ import ij.measure.ResultsTable;
/*     */ import ij.process.ImageProcessor;
/*     */ import inra.ijpb.algo.AlgoStub;
/*     */ import inra.ijpb.binary.BinaryImages;
/*     */ import inra.ijpb.binary.ChamferWeights;
/*     */ import inra.ijpb.label.LabelImages;
/*     */ import inra.ijpb.label.LabelValues;
/*     */ import java.awt.Point;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.TreeMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public class GeodesicDiameterShort
/*     */   extends AlgoStub
/*     */   implements GeodesicDiameter
/*     */ {
/*     */   short[] weights;
/*     */   GeodesicDistanceTransform calculator;
/*     */   int[][] shifts;
/*     */   ImageProcessor labelImage;
/*     */   ImageProcessor distanceMap;
/*     */   
/*     */   public GeodesicDiameterShort(ChamferWeights chamferWeights) {
/* 108 */     this(chamferWeights.getShortWeights());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GeodesicDiameterShort(short[] weights) {
/* 120 */     this.weights = weights;
/* 121 */     chooseDistanceCalculator();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void chooseDistanceCalculator() {
/* 131 */     if (this.weights.length == 3) {
/*     */       
/* 133 */       this.calculator = new GeodesicDistanceTransformShort5x5(this.weights, false);
/* 134 */       this.shifts = new int[][] { 
/* 135 */           { -1, -2 }, { 0, -2 }, { 1, -2
/* 136 */           }, { -2, -1 }, { -1, -1 }, { 0, -1 }, { 1, -1 }, { 2, -1
/* 137 */           }, { -2 }, { -1 }, { 1 }, { 2
/* 138 */           }, { -2, 1 }, { -1, 1 }, { 0, 1 }, { 1, 1 }, { 2, 1
/* 139 */           }, { -1, 2 }, { 0, 2 }, { 1, 2 } };
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 144 */       this.calculator = new GeodesicDistanceTransformShort(this.weights, false);
/* 145 */       this.shifts = new int[][] {
/* 146 */           { -1, -1 }, { 0, -1 }, { 1, -1
/* 147 */           }, { -1 }, { 1
/* 148 */           }, { -1, 1 }, { 0, 1 }, { 1, 1 }
/*     */         };
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResultsTable analyzeImage(ImageProcessor labelImage) {
/* 170 */     if (labelImage == null) return null; 
/* 171 */     this.labelImage = labelImage;
/*     */ 
/*     */     
/* 174 */     fireStatusChanged(this, "Count labels in image");
/* 175 */     int[] labels = LabelImages.findAllLabels(labelImage);
/* 176 */     int nbLabels = labels.length;
/*     */ 
/*     */     
/* 179 */     ImageProcessor mask = BinaryImages.binarize(labelImage);
/*     */ 
/*     */     
/* 182 */     ImageProcessor marker = BinaryImages.binarizeBackground(labelImage);
/*     */     
/* 184 */     fireStatusChanged(this, "Initializing pseudo geodesic centers...");
/*     */ 
/*     */     
/* 187 */     this.distanceMap = this.calculator.geodesicDistanceMap(marker, mask);
/*     */ 
/*     */     
/* 190 */     LabelValues.PositionValuePair[] circles = LabelValues.findMaxValues(this.distanceMap, labelImage, labels);
/*     */ 
/*     */     
/* 193 */     marker.setValue(0.0D);
/* 194 */     marker.fill();
/* 195 */     for (int i = 0; i < nbLabels; i++) {
/*     */       
/* 197 */       Point center = circles[i].getPosition();
/* 198 */       if (center.x == -1) {
/*     */         
/* 200 */         IJ.showMessage("Particle Not Found", 
/* 201 */             "Could not find maximum for particle label " + i);
/*     */       } else {
/*     */         
/* 204 */         marker.set(center.x, center.y, 255);
/*     */       } 
/*     */     } 
/*     */     
/* 208 */     fireStatusChanged(this, "Computing first geodesic extremities...");
/*     */ 
/*     */     
/* 211 */     this.distanceMap = this.calculator.geodesicDistanceMap(marker, mask);
/*     */ 
/*     */ 
/*     */     
/* 215 */     Point[] pos1 = LabelValues.findPositionOfMaxValues(this.distanceMap, labelImage, labels);
/*     */ 
/*     */     
/* 218 */     marker.setValue(0.0D);
/* 219 */     marker.fill();
/* 220 */     for (int j = 0; j < nbLabels; j++) {
/*     */       
/* 222 */       if ((pos1[j]).x == -1) {
/*     */         
/* 224 */         IJ.showMessage("Particle Not Found", 
/* 225 */             "Could not find maximum for particle label " + j);
/*     */       } else {
/*     */         
/* 228 */         marker.set((pos1[j]).x, (pos1[j]).y, 255);
/*     */       } 
/*     */     } 
/* 231 */     fireStatusChanged(this, "Computing second geodesic extremities...");
/*     */ 
/*     */     
/* 234 */     this.distanceMap = this.calculator.geodesicDistanceMap(marker, mask);
/*     */ 
/*     */ 
/*     */     
/* 238 */     LabelValues.PositionValuePair[] extremities = LabelValues.findMaxValues(this.distanceMap, labelImage, labels);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 244 */     ResultsTable table = new ResultsTable();
/*     */ 
/*     */     
/* 247 */     for (int k = 0; k < nbLabels; k++) {
/*     */ 
/*     */       
/* 250 */       double radius = circles[k].getValue() / this.weights[0];
/* 251 */       Point center = circles[k].getPosition();
/*     */       
/* 253 */       double value = extremities[k].getValue() / this.weights[0] + 1.0D;
/* 254 */       Point extremPos = extremities[k].getPosition();
/*     */ 
/*     */       
/* 257 */       table.incrementCounter();
/* 258 */       table.addValue("Label", labels[k]);
/* 259 */       table.addValue("Geod. Diam", value);
/* 260 */       table.addValue("Radius", radius);
/* 261 */       table.addValue("Geod. Elong.", Math.max(value / radius * 2.0D, 1.0D));
/* 262 */       table.addValue("xi", center.x);
/* 263 */       table.addValue("yi", center.y);
/* 264 */       table.addValue("x1", (pos1[k]).x);
/* 265 */       table.addValue("y1", (pos1[k]).y);
/* 266 */       table.addValue("x2", extremPos.x);
/* 267 */       table.addValue("y2", extremPos.y);
/*     */     } 
/*     */     
/* 270 */     fireStatusChanged(this, "");
/* 271 */     return table;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<Integer, List<Point>> longestGeodesicPaths() {
/* 286 */     int[] labels = LabelImages.findAllLabels(this.labelImage);
/*     */ 
/*     */ 
/*     */     
/* 290 */     Point[] pos1 = LabelValues.findPositionOfMinValues(this.distanceMap, this.labelImage, labels);
/*     */ 
/*     */     
/* 293 */     Point[] pos2 = LabelValues.findPositionOfMaxValues(this.distanceMap, this.labelImage, labels);
/*     */ 
/*     */     
/* 296 */     Map<Integer, List<Point>> result = new TreeMap<Integer, List<Point>>();
/*     */ 
/*     */     
/* 299 */     for (int i = 0; i < labels.length; i++) {
/*     */       
/* 301 */       int label = labels[i];
/*     */       
/* 303 */       List<Point> path = new ArrayList<Point>();
/* 304 */       path.add(pos2[i]);
/*     */       
/* 306 */       Point pos = pos2[i];
/*     */       
/*     */       try {
/* 309 */         while (!pos.equals(pos1[i]))
/*     */         {
/* 311 */           pos = findLowestNeighborPosition(pos);
/* 312 */           path.add(pos);
/*     */         }
/*     */       
/* 315 */       } catch (Exception ex) {
/*     */         
/* 317 */         throw new RuntimeException(String.format("Could not compute path for label %d, at position (%d, %d)", new Object[] {
/* 318 */                 Integer.valueOf(label), Integer.valueOf(pos.x), Integer.valueOf(pos.y)
/*     */               }));
/*     */       } 
/* 321 */       result.put(Integer.valueOf(label), path);
/*     */     } 
/*     */     
/* 324 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Point findLowestNeighborPosition(Point pos) {
/* 338 */     int refLabel = (int)this.labelImage.getf(pos.x, pos.y);
/* 339 */     Point nextPos = pos;
/* 340 */     float minDist = this.distanceMap.getf(pos.x, pos.y);
/*     */ 
/*     */     
/* 343 */     for (int i = 0; i < this.shifts.length; i++) {
/*     */ 
/*     */       
/* 346 */       int x = pos.x + this.shifts[i][0];
/* 347 */       int y = pos.y + this.shifts[i][1];
/*     */ 
/*     */       
/* 350 */       if (x >= 0 && x < this.distanceMap.getWidth())
/*     */       {
/*     */ 
/*     */         
/* 354 */         if (y >= 0 && y < this.distanceMap.getHeight())
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 360 */           if ((int)this.labelImage.getf(x, y) == refLabel) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 366 */             float dist = this.distanceMap.getf(x, y);
/* 367 */             if (dist < minDist) {
/*     */               
/* 369 */               minDist = dist;
/* 370 */               nextPos = new Point(x, y);
/*     */             } 
/*     */           }  }  } 
/*     */     } 
/* 374 */     if (nextPos.equals(pos))
/*     */     {
/* 376 */       throw new RuntimeException("Could not find a neighbor with smaller value");
/*     */     }
/*     */     
/* 379 */     return nextPos;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/binary/geodesic/GeodesicDiameterShort.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */