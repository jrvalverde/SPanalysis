package inra.ijpb.binary.geodesic;

import ij.ImageStack;
import inra.ijpb.algo.Algo;

public interface GeodesicDistanceTransform3D extends Algo {
  ImageStack geodesicDistanceMap(ImageStack paramImageStack1, ImageStack paramImageStack2);
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/binary/geodesic/GeodesicDistanceTransform3D.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */