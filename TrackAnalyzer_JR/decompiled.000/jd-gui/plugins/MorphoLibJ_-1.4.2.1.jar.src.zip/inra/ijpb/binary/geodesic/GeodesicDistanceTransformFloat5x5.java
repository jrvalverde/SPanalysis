/*     */ package inra.ijpb.binary.geodesic;
/*     */ 
/*     */ import ij.process.FloatProcessor;
/*     */ import ij.process.ImageProcessor;
/*     */ import inra.ijpb.algo.AlgoStub;
/*     */ import inra.ijpb.binary.ChamferWeights;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GeodesicDistanceTransformFloat5x5
/*     */   extends AlgoStub
/*     */   implements GeodesicDistanceTransform
/*     */ {
/*     */   public static final float MAX_DIST = InfinityF;
/*  44 */   float[] weights = new float[] { 5.0F, 7.0F, 11.0F };
/*     */ 
/*     */ 
/*     */   
/*     */   boolean normalizeMap = true;
/*     */ 
/*     */ 
/*     */   
/*     */   int sizeX;
/*     */ 
/*     */ 
/*     */   
/*     */   int sizeY;
/*     */ 
/*     */   
/*     */   ImageProcessor labelImage;
/*     */ 
/*     */   
/*     */   ImageProcessor distMap;
/*     */ 
/*     */   
/*     */   boolean modif;
/*     */ 
/*     */ 
/*     */   
/*     */   public GeodesicDistanceTransformFloat5x5() {}
/*     */ 
/*     */ 
/*     */   
/*     */   public GeodesicDistanceTransformFloat5x5(float[] weights) {
/*  74 */     this(weights, true);
/*     */   }
/*     */ 
/*     */   
/*     */   public GeodesicDistanceTransformFloat5x5(ChamferWeights weights, boolean normalizeMap) {
/*  79 */     this(weights.getFloatWeights(), normalizeMap);
/*     */   }
/*     */ 
/*     */   
/*     */   public GeodesicDistanceTransformFloat5x5(float[] weights, boolean normalizeMap) {
/*  84 */     this.weights = weights;
/*  85 */     this.normalizeMap = normalizeMap;
/*     */ 
/*     */     
/*  88 */     if (weights.length < 3) {
/*     */       
/*  90 */       float[] newWeights = new float[3];
/*  91 */       newWeights[0] = weights[0];
/*  92 */       newWeights[1] = weights[1];
/*  93 */       newWeights[2] = weights[0] + weights[1];
/*  94 */       this.weights = newWeights;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ImageProcessor geodesicDistanceMap(ImageProcessor marker, ImageProcessor mask) {
/* 122 */     this.sizeX = mask.getWidth();
/* 123 */     this.sizeY = mask.getHeight();
/*     */ 
/*     */     
/* 126 */     this.labelImage = mask;
/*     */ 
/*     */     
/* 129 */     fireStatusChanged(this, "Initialization...");
/* 130 */     this.distMap = (ImageProcessor)initialize(marker);
/*     */     
/* 132 */     int iter = 0;
/* 133 */     this.modif = true;
/* 134 */     while (this.modif) {
/*     */       
/* 136 */       this.modif = false;
/*     */ 
/*     */       
/* 139 */       fireStatusChanged(this, "Forward iteration " + iter);
/* 140 */       forwardIteration();
/*     */ 
/*     */       
/* 143 */       fireStatusChanged(this, "Backward iteration " + iter);
/* 144 */       backwardIteration();
/*     */ 
/*     */       
/* 147 */       iter++;
/*     */     } 
/*     */ 
/*     */     
/* 151 */     if (this.normalizeMap) {
/*     */       
/* 153 */       fireStatusChanged(this, "Normalize map");
/* 154 */       for (int j = 0; j < this.sizeY; j++) {
/*     */         
/* 156 */         for (int k = 0; k < this.sizeX; k++) {
/*     */           
/* 158 */           float val = this.distMap.getf(k, j);
/* 159 */           if (val != Float.POSITIVE_INFINITY)
/*     */           {
/* 161 */             this.distMap.setf(k, j, val / this.weights[0]);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 168 */     fireStatusChanged(this, "Normalize display");
/* 169 */     float maxVal = 0.0F;
/* 170 */     for (int i = 0; i < this.sizeX; i++) {
/*     */       
/* 172 */       for (int j = 0; j < this.sizeY; j++) {
/*     */         
/* 174 */         float val = this.distMap.getf(i, j);
/* 175 */         if (val != Float.POSITIVE_INFINITY)
/*     */         {
/* 177 */           maxVal = Math.max(maxVal, val);
/*     */         }
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 184 */     this.distMap.setMinAndMax(0.0D, maxVal);
/*     */     
/* 186 */     if (this.distMap.isInvertedLut())
/*     */     {
/* 188 */       this.distMap.invertLut();
/*     */     }
/*     */     
/* 191 */     return this.distMap;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private FloatProcessor initialize(ImageProcessor marker) {
/* 197 */     this.sizeX = marker.getWidth();
/* 198 */     this.sizeY = marker.getHeight();
/*     */     
/* 200 */     FloatProcessor distMap = new FloatProcessor(this.sizeX, this.sizeY);
/* 201 */     distMap.setValue(0.0D);
/* 202 */     distMap.fill();
/*     */ 
/*     */     
/* 205 */     for (int y = 0; y < this.sizeY; y++) {
/*     */       
/* 207 */       for (int x = 0; x < this.sizeX; x++) {
/*     */         
/* 209 */         int val = marker.get(x, y) & 0xFF;
/* 210 */         distMap.setf(x, y, (val == 0) ? Float.POSITIVE_INFINITY : 0.0F);
/*     */       } 
/*     */     } 
/*     */     
/* 214 */     return distMap;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void forwardIteration() {
/* 220 */     int[] dx = { -1, 1, -2, -1, 1, 2, -1 };
/* 221 */     int[] dy = { -2, -2, -1, -1, -1, -1, -1 };
/*     */     
/* 223 */     float[] dw = {
/* 224 */         this.weights[2], this.weights[2], 
/* 225 */         this.weights[2], this.weights[1], this.weights[0], this.weights[1], this.weights[2], 
/* 226 */         this.weights[0]
/*     */       };
/*     */     
/* 229 */     for (int y = 0; y < this.sizeY; y++) {
/*     */       
/* 231 */       fireProgressChanged(this, y, this.sizeY);
/* 232 */       for (int x = 0; x < this.sizeX; x++) {
/*     */ 
/*     */         
/* 235 */         int label = (int)this.labelImage.getf(x, y);
/*     */ 
/*     */         
/* 238 */         if (label != 0) {
/*     */ 
/*     */ 
/*     */           
/* 242 */           double currentDist = this.distMap.getf(x, y);
/* 243 */           double newDist = currentDist;
/*     */ 
/*     */           
/* 246 */           for (int i = 0; i < dx.length; i++) {
/*     */ 
/*     */             
/* 249 */             int x2 = x + dx[i];
/* 250 */             int y2 = y + dy[i];
/*     */ 
/*     */             
/* 253 */             if (x2 >= 0 && x2 < this.sizeX)
/*     */             {
/* 255 */               if (y2 >= 0 && y2 < this.sizeY)
/*     */               {
/*     */                 
/* 258 */                 if ((int)this.labelImage.getf(x2, y2) == label)
/*     */                 {
/*     */                   
/* 261 */                   newDist = Math.min(newDist, (this.distMap.getf(x2, y2) + dw[i])); } 
/*     */               }
/*     */             }
/*     */           } 
/* 265 */           if (newDist < currentDist) {
/*     */             
/* 267 */             this.distMap.setf(x, y, (float)newDist);
/* 268 */             this.modif = true;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/* 273 */     fireProgressChanged(this, this.sizeY, this.sizeY);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void backwardIteration() {
/* 279 */     int[] dx = { 1, -1, 2, 1, -1, -2, 1 };
/* 280 */     int[] dy = { 2, 2, 1, 1, 1, 1, 1 };
/*     */     
/* 282 */     float[] dw = {
/* 283 */         this.weights[2], this.weights[2], 
/* 284 */         this.weights[2], this.weights[1], this.weights[0], this.weights[1], this.weights[2], 
/* 285 */         this.weights[0]
/*     */       };
/*     */     
/* 288 */     for (int y = this.sizeY - 1; y >= 0; y--) {
/*     */       
/* 290 */       fireProgressChanged(this, (this.sizeY - 1 - y), this.sizeY);
/* 291 */       for (int x = this.sizeX - 1; x >= 0; x--) {
/*     */ 
/*     */         
/* 294 */         int label = (int)this.labelImage.getf(x, y);
/*     */ 
/*     */         
/* 297 */         if (label != 0) {
/*     */ 
/*     */ 
/*     */           
/* 301 */           double currentDist = this.distMap.getf(x, y);
/* 302 */           double newDist = currentDist;
/*     */ 
/*     */           
/* 305 */           for (int i = 0; i < dx.length; i++) {
/*     */ 
/*     */             
/* 308 */             int x2 = x + dx[i];
/* 309 */             int y2 = y + dy[i];
/*     */ 
/*     */             
/* 312 */             if (x2 >= 0 && x2 < this.sizeX)
/*     */             {
/* 314 */               if (y2 >= 0 && y2 < this.sizeY)
/*     */               {
/*     */                 
/* 317 */                 if ((int)this.labelImage.getf(x2, y2) == label)
/*     */                 {
/*     */                   
/* 320 */                   newDist = Math.min(newDist, (this.distMap.getf(x2, y2) + dw[i])); } 
/*     */               }
/*     */             }
/*     */           } 
/* 324 */           if (newDist < currentDist) {
/*     */             
/* 326 */             this.distMap.setf(x, y, (float)newDist);
/* 327 */             this.modif = true;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/* 332 */     fireProgressChanged(this, this.sizeY, this.sizeY);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/binary/geodesic/GeodesicDistanceTransformFloat5x5.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */