/*     */ package inra.ijpb.binary.distmap;
/*     */ 
/*     */ import ij.process.ImageProcessor;
/*     */ import ij.process.ShortProcessor;
/*     */ import inra.ijpb.algo.AlgoEvent;
/*     */ import inra.ijpb.algo.AlgoStub;
/*     */ import inra.ijpb.binary.ChamferWeights;
/*     */ import inra.ijpb.label.LabelValues;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DistanceTransform3x3Short
/*     */   extends AlgoStub
/*     */   implements DistanceTransform
/*     */ {
/*     */   private short[] weights;
/*     */   private boolean normalizeMap = true;
/*     */   
/*     */   public DistanceTransform3x3Short(short[] weights) {
/*  81 */     this(weights, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DistanceTransform3x3Short(ChamferWeights weights, boolean normalize) {
/*  96 */     this(weights.getShortWeights(), normalize);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DistanceTransform3x3Short(short[] weights, boolean normalize) {
/* 111 */     this.weights = weights;
/* 112 */     this.normalizeMap = normalize;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ShortProcessor distanceMap(ImageProcessor labelImage) {
/* 131 */     ShortProcessor distMap = initializeResult(labelImage);
/*     */ 
/*     */     
/* 134 */     forwardScan(distMap, labelImage);
/* 135 */     backwardScan(distMap, labelImage);
/*     */ 
/*     */     
/* 138 */     if (this.normalizeMap)
/*     */     {
/* 140 */       normalizeResult(distMap, labelImage);
/*     */     }
/*     */ 
/*     */     
/* 144 */     double maxVal = LabelValues.maxValueWithinLabels((ImageProcessor)distMap, labelImage);
/* 145 */     distMap.setMinAndMax(0.0D, maxVal);
/*     */ 
/*     */     
/* 148 */     if (distMap.isInvertedLut()) {
/* 149 */       distMap.invertLut();
/*     */     }
/* 151 */     fireStatusChanged(new AlgoEvent(this, ""));
/*     */     
/* 153 */     return distMap;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ShortProcessor initializeResult(ImageProcessor labelImage) {
/* 162 */     fireStatusChanged(new AlgoEvent(this, "Initialization"));
/*     */ 
/*     */     
/* 165 */     int sizeX = labelImage.getWidth();
/* 166 */     int sizeY = labelImage.getHeight();
/*     */ 
/*     */     
/* 169 */     ShortProcessor distMap = new ShortProcessor(sizeX, sizeY);
/* 170 */     distMap.setValue(0.0D);
/* 171 */     distMap.fill();
/*     */ 
/*     */     
/* 174 */     for (int y = 0; y < sizeY; y++) {
/*     */       
/* 176 */       for (int x = 0; x < sizeX; x++) {
/*     */         
/* 178 */         int label = (int)labelImage.getf(x, y);
/* 179 */         distMap.set(x, y, (label == 0) ? 0 : 32767);
/*     */       } 
/*     */     } 
/*     */     
/* 183 */     return distMap;
/*     */   }
/*     */ 
/*     */   
/*     */   private void forwardScan(ShortProcessor distMap, ImageProcessor labelImage) {
/* 188 */     fireStatusChanged(new AlgoEvent(this, "Forward Scan"));
/*     */     
/* 190 */     int[] dx = { -1, 1, -1 };
/* 191 */     int[] dy = { -1, -1, -1 };
/* 192 */     int[] dw = { this.weights[1], this.weights[0], this.weights[1], this.weights[0] };
/*     */ 
/*     */     
/* 195 */     int sizeX = labelImage.getWidth();
/* 196 */     int sizeY = labelImage.getHeight();
/*     */ 
/*     */     
/* 199 */     for (int y = 0; y < sizeY; y++) {
/*     */       
/* 201 */       fireProgressChanged(this, y, sizeY);
/* 202 */       for (int x = 0; x < sizeX; x++) {
/*     */ 
/*     */         
/* 205 */         int label = (int)labelImage.getf(x, y);
/*     */ 
/*     */         
/* 208 */         if (label != 0) {
/*     */ 
/*     */ 
/*     */           
/* 212 */           int currentDist = distMap.get(x, y);
/* 213 */           int newDist = currentDist;
/*     */ 
/*     */           
/* 216 */           for (int i = 0; i < dx.length; i++) {
/*     */ 
/*     */             
/* 219 */             int x2 = x + dx[i];
/* 220 */             int y2 = y + dy[i];
/*     */ 
/*     */             
/* 223 */             if (x2 >= 0 && x2 < sizeX)
/*     */             {
/* 225 */               if (y2 >= 0 && y2 < sizeY)
/*     */               {
/*     */                 
/* 228 */                 if ((int)labelImage.getf(x2, y2) != label) {
/*     */ 
/*     */                   
/* 231 */                   newDist = Math.min(newDist, dw[i]);
/*     */                 
/*     */                 }
/*     */                 else {
/*     */                   
/* 236 */                   newDist = Math.min(newDist, distMap.get(x2, y2) + dw[i]);
/*     */                 }  } 
/*     */             }
/*     */           } 
/* 240 */           if (newDist < currentDist)
/*     */           {
/* 242 */             distMap.set(x, y, newDist);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/* 247 */     fireProgressChanged(this, sizeY, sizeY);
/*     */   }
/*     */ 
/*     */   
/*     */   private void backwardScan(ShortProcessor distMap, ImageProcessor labelImage) {
/* 252 */     fireStatusChanged(new AlgoEvent(this, "Backward Scan"));
/*     */     
/* 254 */     int[] dx = { 1, -1, 1 };
/* 255 */     int[] dy = { 1, 1, 1 };
/* 256 */     int[] dw = { this.weights[1], this.weights[0], this.weights[1], this.weights[0] };
/*     */ 
/*     */     
/* 259 */     int sizeX = labelImage.getWidth();
/* 260 */     int sizeY = labelImage.getHeight();
/*     */ 
/*     */     
/* 263 */     for (int y = sizeY - 1; y >= 0; y--) {
/*     */       
/* 265 */       fireProgressChanged(this, (sizeY - 1 - y), sizeY);
/* 266 */       for (int x = sizeX - 1; x >= 0; x--) {
/*     */ 
/*     */         
/* 269 */         int label = (int)labelImage.getf(x, y);
/*     */ 
/*     */         
/* 272 */         if (label != 0) {
/*     */ 
/*     */ 
/*     */           
/* 276 */           int currentDist = distMap.get(x, y);
/* 277 */           int newDist = currentDist;
/*     */ 
/*     */           
/* 280 */           for (int i = 0; i < dx.length; i++) {
/*     */ 
/*     */             
/* 283 */             int x2 = x + dx[i];
/* 284 */             int y2 = y + dy[i];
/*     */ 
/*     */             
/* 287 */             if (x2 >= 0 && x2 < sizeX)
/*     */             {
/* 289 */               if (y2 >= 0 && y2 < sizeY)
/*     */               {
/*     */                 
/* 292 */                 if ((int)labelImage.getf(x2, y2) != label) {
/*     */ 
/*     */                   
/* 295 */                   newDist = Math.min(newDist, dw[i]);
/*     */                 
/*     */                 }
/*     */                 else {
/*     */                   
/* 300 */                   newDist = Math.min(newDist, distMap.get(x2, y2) + dw[i]);
/*     */                 }  } 
/*     */             }
/*     */           } 
/* 304 */           if (newDist < currentDist)
/*     */           {
/* 306 */             distMap.set(x, y, newDist);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/* 311 */     fireProgressChanged(this, sizeY, sizeY);
/*     */   }
/*     */ 
/*     */   
/*     */   private void normalizeResult(ShortProcessor distMap, ImageProcessor labelImage) {
/* 316 */     fireStatusChanged(new AlgoEvent(this, "Normalization"));
/*     */ 
/*     */     
/* 319 */     int sizeX = labelImage.getWidth();
/* 320 */     int sizeY = labelImage.getHeight();
/*     */ 
/*     */     
/* 323 */     int w0 = this.weights[0];
/*     */     
/* 325 */     for (int y = 0; y < sizeY; y++) {
/*     */       
/* 327 */       for (int x = 0; x < sizeX; x++) {
/*     */         
/* 329 */         if ((int)labelImage.getf(x, y) > 0)
/*     */         {
/* 331 */           distMap.set(x, y, distMap.get(x, y) / w0);
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/binary/distmap/DistanceTransform3x3Short.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */