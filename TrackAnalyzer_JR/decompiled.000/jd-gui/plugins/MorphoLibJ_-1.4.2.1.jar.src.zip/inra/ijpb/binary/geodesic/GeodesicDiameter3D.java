package inra.ijpb.binary.geodesic;

import ij.ImageStack;
import ij.measure.ResultsTable;
import inra.ijpb.algo.Algo;

public interface GeodesicDiameter3D extends Algo {
  ResultsTable process(ImageStack paramImageStack);
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/binary/geodesic/GeodesicDiameter3D.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */