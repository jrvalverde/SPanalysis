/*      */ package inra.ijpb.binary;
/*      */ 
/*      */ import ij.ImagePlus;
/*      */ import ij.ImageStack;
/*      */ import ij.process.ByteProcessor;
/*      */ import ij.process.FloatProcessor;
/*      */ import ij.process.ImageProcessor;
/*      */ import ij.process.ShortProcessor;
/*      */ import inra.ijpb.algo.Algo;
/*      */ import inra.ijpb.algo.DefaultAlgoListener;
/*      */ import inra.ijpb.binary.conncomp.FloodFillComponentsLabeling;
/*      */ import inra.ijpb.binary.conncomp.FloodFillComponentsLabeling3D;
/*      */ import inra.ijpb.binary.distmap.DistanceTransform3DFloat;
/*      */ import inra.ijpb.binary.distmap.DistanceTransform3DShort;
/*      */ import inra.ijpb.binary.distmap.DistanceTransform3x3Float;
/*      */ import inra.ijpb.binary.distmap.DistanceTransform3x3Short;
/*      */ import inra.ijpb.binary.distmap.DistanceTransform5x5Float;
/*      */ import inra.ijpb.binary.distmap.DistanceTransform5x5Short;
/*      */ import inra.ijpb.binary.geodesic.GeodesicDistanceTransformFloat;
/*      */ import inra.ijpb.binary.geodesic.GeodesicDistanceTransformFloat5x5;
/*      */ import inra.ijpb.binary.geodesic.GeodesicDistanceTransformShort;
/*      */ import inra.ijpb.binary.geodesic.GeodesicDistanceTransformShort5x5;
/*      */ import inra.ijpb.binary.skeleton.ImageJSkeleton;
/*      */ import inra.ijpb.data.image.Image3D;
/*      */ import inra.ijpb.data.image.Images3D;
/*      */ import inra.ijpb.label.LabelImages;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class BinaryImages
/*      */ {
/*      */   public static final boolean isBinaryImage(ImagePlus image) {
/*   78 */     if (image.getType() != 0 && 
/*   79 */       image.getType() != 3)
/*   80 */       return false; 
/*   81 */     for (int n = 1; n <= image.getImageStackSize(); n++) {
/*      */       
/*   83 */       int[] hist = 
/*   84 */         image.getImageStack().getProcessor(n).getHistogram();
/*   85 */       for (int i = 1; i < hist.length - 1; i++) {
/*   86 */         if (hist[i] > 0)
/*   87 */           return false; 
/*      */       } 
/*   89 */     }  return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final boolean isBinaryImage(ImageProcessor image) {
/*   99 */     if (!(image instanceof ByteProcessor))
/*  100 */       return false; 
/*  101 */     int[] hist = image.getHistogram();
/*  102 */     for (int i = 1; i < hist.length - 1; i++) {
/*  103 */       if (hist[i] > 0)
/*  104 */         return false; 
/*  105 */     }  return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int countForegroundPixels(ImageProcessor image) {
/*  118 */     int width = image.getWidth();
/*  119 */     int height = image.getHeight();
/*      */     
/*  121 */     int count = 0;
/*      */     
/*  123 */     for (int y = 0; y < height; y++) {
/*      */       
/*  125 */       for (int x = 0; x < width; x++) {
/*      */         
/*  127 */         if (image.getf(x, y) > 0.0F) {
/*  128 */           count++;
/*      */         }
/*      */       } 
/*      */     } 
/*  132 */     return count;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int countForegroundVoxels(ImageStack image) {
/*  145 */     int width = image.getWidth();
/*  146 */     int height = image.getHeight();
/*  147 */     int depth = image.getSize();
/*      */     
/*  149 */     int count = 0;
/*      */ 
/*      */     
/*  152 */     Image3D image3d = Images3D.createWrapper(image);
/*  153 */     for (int z = 0; z < depth; z++) {
/*      */       
/*  155 */       for (int y = 0; y < height; y++) {
/*      */         
/*  157 */         for (int x = 0; x < width; x++) {
/*      */           
/*  159 */           if (image3d.get(x, y, z) > 0)
/*  160 */             count++; 
/*      */         } 
/*      */       } 
/*      */     } 
/*  164 */     return count;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final ImagePlus componentsLabeling(ImagePlus imagePlus, int conn, int bitDepth) {
/*      */     ImagePlus labelPlus;
/*      */     double nLabels;
/*  196 */     if (imagePlus.getStackSize() == 1) {
/*      */       
/*  198 */       ImageProcessor labels = componentsLabeling(imagePlus.getProcessor(), 
/*  199 */           conn, bitDepth);
/*  200 */       labelPlus = new ImagePlus("Labels", labels);
/*  201 */       nLabels = findMax(labels);
/*      */     }
/*      */     else {
/*      */       
/*  205 */       ImageStack labels = componentsLabeling(imagePlus.getStack(), conn, 
/*  206 */           bitDepth);
/*  207 */       labelPlus = new ImagePlus("Labels", labels);
/*  208 */       nLabels = findMax(labels);
/*      */     } 
/*      */ 
/*      */     
/*  212 */     labelPlus.setDisplayRange(0.0D, nLabels);
/*  213 */     return labelPlus;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final double findMax(ImageProcessor image) {
/*  223 */     int sizeX = image.getWidth();
/*  224 */     int sizeY = image.getHeight();
/*      */ 
/*      */     
/*  227 */     double maxVal = 0.0D;
/*  228 */     for (int y = 0; y < sizeY; y++) {
/*      */       
/*  230 */       for (int x = 0; x < sizeX; x++)
/*      */       {
/*  232 */         maxVal = Math.max(maxVal, image.getf(x, y));
/*      */       }
/*      */     } 
/*      */     
/*  236 */     return maxVal;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final double findMax(ImageStack image) {
/*  246 */     int sizeX = image.getWidth();
/*  247 */     int sizeY = image.getHeight();
/*  248 */     int sizeZ = image.getSize();
/*      */ 
/*      */     
/*  251 */     double maxVal = 0.0D;
/*  252 */     for (int z = 0; z < sizeZ; z++) {
/*      */       
/*  254 */       for (int y = 0; y < sizeY; y++) {
/*      */         
/*  256 */         for (int x = 0; x < sizeX; x++)
/*      */         {
/*  258 */           maxVal = Math.max(maxVal, image.getVoxel(x, y, z));
/*      */         }
/*      */       } 
/*      */     } 
/*      */     
/*  263 */     return maxVal;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final ImageProcessor componentsLabeling(ImageProcessor image, int conn, int bitDepth) {
/*  290 */     FloodFillComponentsLabeling floodFillComponentsLabeling = new FloodFillComponentsLabeling(conn, bitDepth);
/*  291 */     DefaultAlgoListener.monitor((Algo)floodFillComponentsLabeling);
/*  292 */     return floodFillComponentsLabeling.computeLabels(image);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final ImageStack componentsLabeling(ImageStack image, int conn, int bitDepth) {
/*  319 */     FloodFillComponentsLabeling3D floodFillComponentsLabeling3D = new FloodFillComponentsLabeling3D(conn, bitDepth);
/*  320 */     DefaultAlgoListener.monitor((Algo)floodFillComponentsLabeling3D);
/*  321 */     return floodFillComponentsLabeling3D.computeLabels(image);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final ImagePlus distanceMap(ImagePlus imagePlus) {
/*      */     ImagePlus resultPlus;
/*  340 */     String newName = String.valueOf(imagePlus.getShortTitle()) + "-distMap";
/*      */ 
/*      */     
/*  343 */     if (imagePlus.getStackSize() == 1) {
/*      */ 
/*      */       
/*  346 */       ImageProcessor image = imagePlus.getProcessor();
/*  347 */       ImageProcessor result = distanceMap(image);
/*  348 */       resultPlus = new ImagePlus(newName, result);
/*      */     
/*      */     }
/*      */     else {
/*      */       
/*  353 */       ImageStack image = imagePlus.getStack();
/*  354 */       ImageStack result = distanceMap(image);
/*  355 */       resultPlus = new ImagePlus(newName, result);
/*      */     } 
/*      */     
/*  358 */     resultPlus.copyScale(imagePlus);
/*  359 */     return resultPlus;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final ImageProcessor distanceMap(ImageProcessor image) {
/*  380 */     return (ImageProcessor)distanceMap(image, new short[] { 5, 7, 11 }, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final ShortProcessor distanceMap(ImageProcessor image, short[] weights, boolean normalize) {
/*      */     DistanceTransform3x3Short distanceTransform3x3Short;
/*      */     DistanceTransform5x5Short distanceTransform5x5Short;
/*  408 */     switch (weights.length) {
/*      */       case 2:
/*  410 */         distanceTransform3x3Short = new DistanceTransform3x3Short(weights, normalize);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  420 */         return (ShortProcessor)distanceTransform3x3Short.distanceMap(image);case 3: distanceTransform5x5Short = new DistanceTransform5x5Short(weights, normalize); return (ShortProcessor)distanceTransform5x5Short.distanceMap(image);
/*      */     } 
/*      */     throw new IllegalArgumentException("Requires weight array with 2 or 3 elements");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final FloatProcessor distanceMap(ImageProcessor image, float[] weights, boolean normalize) {
/*      */     DistanceTransform3x3Float distanceTransform3x3Float;
/*      */     DistanceTransform5x5Float distanceTransform5x5Float;
/*  448 */     switch (weights.length) {
/*      */       
/*      */       case 2:
/*  451 */         distanceTransform3x3Float = new DistanceTransform3x3Float(weights, normalize);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  461 */         return (FloatProcessor)distanceTransform3x3Float.distanceMap(image);case 3: distanceTransform5x5Float = new DistanceTransform5x5Float(weights, normalize); return (FloatProcessor)distanceTransform5x5Float.distanceMap(image);
/*      */     } 
/*      */     throw new IllegalArgumentException("Requires weight array with 2 or 3 elements");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final ImageStack distanceMap(ImageStack image) {
/*  475 */     float[] weights = { 3.0F, 4.0F, 5.0F };
/*  476 */     DistanceTransform3DFloat distanceTransform3DFloat = new DistanceTransform3DFloat(weights);
/*  477 */     return distanceTransform3DFloat.distanceMap(image);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final ImageStack distanceMap(ImageStack image, short[] weights, boolean normalize) {
/*  497 */     DistanceTransform3DShort distanceTransform3DShort = new DistanceTransform3DShort(weights, normalize);
/*      */     
/*  499 */     return distanceTransform3DShort.distanceMap(image);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final ImageStack distanceMap(ImageStack image, float[] weights, boolean normalize) {
/*  519 */     DistanceTransform3DFloat distanceTransform3DFloat = new DistanceTransform3DFloat(weights, normalize);
/*  520 */     return distanceTransform3DFloat.distanceMap(image);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static final ImagePlus geodesicDistanceMap(ImagePlus markerPlus, ImagePlus maskPlus) {
/*  526 */     ImagePlus result = null;
/*  527 */     String newName = String.valueOf(markerPlus.getShortTitle()) + "-distMap";
/*      */     
/*  529 */     if (markerPlus.getStackSize() == 1 && maskPlus.getStackSize() == 1) {
/*      */       
/*  531 */       ImageProcessor distMap = geodesicDistanceMap(markerPlus.getProcessor(), maskPlus.getProcessor());
/*  532 */       result = new ImagePlus(newName, distMap);
/*      */     } 
/*      */     
/*  535 */     result.copyScale(markerPlus);
/*  536 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final ImageProcessor geodesicDistanceMap(ImageProcessor marker, ImageProcessor mask) {
/*  553 */     return geodesicDistanceMap(marker, mask, new short[] { 5, 7, 11 }, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final ImageProcessor geodesicDistanceMap(ImageProcessor marker, ImageProcessor mask, short[] weights, boolean normalize) {
/*      */     GeodesicDistanceTransformShort geodesicDistanceTransformShort;
/*      */     GeodesicDistanceTransformShort5x5 geodesicDistanceTransformShort5x5;
/*  576 */     switch (weights.length) {
/*      */       
/*      */       case 2:
/*  579 */         geodesicDistanceTransformShort = new GeodesicDistanceTransformShort(weights, normalize);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  589 */         return geodesicDistanceTransformShort.geodesicDistanceMap(marker, mask);case 3: geodesicDistanceTransformShort5x5 = new GeodesicDistanceTransformShort5x5(weights, normalize); return geodesicDistanceTransformShort5x5.geodesicDistanceMap(marker, mask);
/*      */     } 
/*      */     throw new IllegalArgumentException("Requires weight array with 2 or 3 elements");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final ImageProcessor geodesicDistanceMap(ImageProcessor marker, ImageProcessor mask, float[] weights, boolean normalize) {
/*      */     GeodesicDistanceTransformFloat geodesicDistanceTransformFloat;
/*      */     GeodesicDistanceTransformFloat5x5 geodesicDistanceTransformFloat5x5;
/*  612 */     switch (weights.length) {
/*      */       
/*      */       case 2:
/*  615 */         geodesicDistanceTransformFloat = new GeodesicDistanceTransformFloat(weights, normalize);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  625 */         return geodesicDistanceTransformFloat.geodesicDistanceMap(marker, mask);case 3: geodesicDistanceTransformFloat5x5 = new GeodesicDistanceTransformFloat5x5(weights, normalize); return geodesicDistanceTransformFloat5x5.geodesicDistanceMap(marker, mask);
/*      */     } 
/*      */     throw new IllegalArgumentException("Requires weight array with 2 or 3 elements");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final ImagePlus sizeOpening(ImagePlus imagePlus, int minElementCount) {
/*      */     ImagePlus resultPlus;
/*  647 */     String newName = String.valueOf(imagePlus.getShortTitle()) + "-sizeOpening";
/*      */     
/*  649 */     if (imagePlus.getStackSize() == 1) {
/*      */       
/*  651 */       ImageProcessor image = imagePlus.getProcessor();
/*  652 */       ImageProcessor result = areaOpening(image, minElementCount);
/*  653 */       resultPlus = new ImagePlus(newName, result);
/*      */     }
/*      */     else {
/*      */       
/*  657 */       ImageStack image = imagePlus.getStack();
/*  658 */       ImageStack result = LabelImages.volumeOpening(image, minElementCount);
/*  659 */       result.setColorModel(image.getColorModel());
/*  660 */       resultPlus = new ImagePlus(newName, result);
/*      */     } 
/*      */ 
/*      */     
/*  664 */     resultPlus.copyScale(imagePlus);
/*  665 */     return resultPlus;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final ImageProcessor areaOpening(ImageProcessor image, int nPixelMin) {
/*  684 */     FloodFillComponentsLabeling floodFillComponentsLabeling = new FloodFillComponentsLabeling(4, 16);
/*  685 */     ImageProcessor labelImage = floodFillComponentsLabeling.computeLabels(image);
/*      */ 
/*      */     
/*  688 */     return binarize(LabelImages.areaOpening(labelImage, nPixelMin));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final ImageStack volumeOpening(ImageStack image, int nVoxelMin) {
/*  707 */     ImageStack labelImage = componentsLabeling(image, 6, 16);
/*      */ 
/*      */     
/*  710 */     return binarize(LabelImages.volumeOpening(labelImage, nVoxelMin));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final ImagePlus keepLargestRegion(ImagePlus imagePlus) {
/*      */     ImagePlus resultPlus;
/*  725 */     String newName = String.valueOf(imagePlus.getShortTitle()) + "-largest";
/*      */ 
/*      */     
/*  728 */     if (imagePlus.getStackSize() == 1) {
/*      */ 
/*      */       
/*  731 */       ImageProcessor image = imagePlus.getProcessor();
/*  732 */       ImageProcessor result = keepLargestRegion(image);
/*  733 */       resultPlus = new ImagePlus(newName, result);
/*      */     
/*      */     }
/*      */     else {
/*      */       
/*  738 */       ImageStack image = imagePlus.getStack();
/*  739 */       ImageStack result = keepLargestRegion(image);
/*  740 */       resultPlus = new ImagePlus(newName, result);
/*      */     } 
/*      */     
/*  743 */     resultPlus.copyScale(imagePlus);
/*  744 */     return resultPlus;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final ImageProcessor keepLargestRegion(ImageProcessor image) {
/*  757 */     ImageProcessor labelImage = componentsLabeling(image, 4, 16);
/*  758 */     ImageProcessor result = binarize(LabelImages.keepLargestLabel(labelImage));
/*  759 */     result.setLut(image.getLut());
/*  760 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final ImageStack keepLargestRegion(ImageStack image) {
/*  773 */     ImageStack labelImage = componentsLabeling(image, 6, 16);
/*  774 */     ImageStack result = binarize(LabelImages.keepLargestLabel(labelImage));
/*  775 */     result.setColorModel(image.getColorModel());
/*  776 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final void removeLargestRegion(ImagePlus imagePlus) {
/*  790 */     if (imagePlus.getStackSize() == 1) {
/*      */       
/*  792 */       imagePlus.setProcessor(removeLargestRegion(imagePlus.getProcessor()));
/*      */     }
/*      */     else {
/*      */       
/*  796 */       imagePlus.setStack(removeLargestRegion(imagePlus.getStack()));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final ImageProcessor removeLargestRegion(ImageProcessor image) {
/*  812 */     ImageProcessor labelImage = componentsLabeling(image, 4, 16);
/*  813 */     LabelImages.removeLargestLabel(labelImage);
/*  814 */     ImageProcessor result = binarize(labelImage);
/*  815 */     result.setLut(image.getLut());
/*  816 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final ImageStack removeLargestRegion(ImageStack image) {
/*  831 */     ImageStack labelImage = componentsLabeling(image, 6, 16);
/*  832 */     LabelImages.removeLargestLabel(labelImage);
/*  833 */     ImageStack result = binarize(labelImage);
/*  834 */     result.setColorModel(image.getColorModel());
/*  835 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final ImagePlus binarize(ImagePlus imagePlus) {
/*      */     ImagePlus resultPlus;
/*  851 */     String title = String.valueOf(imagePlus.getShortTitle()) + "-bin";
/*  852 */     if (imagePlus.getStackSize() == 1) {
/*      */       
/*  854 */       ImageProcessor result = binarize(imagePlus.getProcessor());
/*  855 */       resultPlus = new ImagePlus(title, result);
/*      */     }
/*      */     else {
/*      */       
/*  859 */       ImageStack result = binarize(imagePlus.getStack());
/*  860 */       resultPlus = new ImagePlus(title, result);
/*      */     } 
/*  862 */     return resultPlus;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final ImageProcessor binarize(ImageProcessor image) {
/*  876 */     int width = image.getWidth();
/*  877 */     int height = image.getHeight();
/*  878 */     ByteProcessor byteProcessor = new ByteProcessor(width, height);
/*      */     
/*  880 */     for (int y = 0; y < height; y++) {
/*      */       
/*  882 */       for (int x = 0; x < width; x++) {
/*      */         
/*  884 */         if (image.get(x, y) > 0) {
/*  885 */           byteProcessor.set(x, y, 255);
/*      */         }
/*      */       } 
/*      */     } 
/*  889 */     return (ImageProcessor)byteProcessor;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final ImageStack binarize(ImageStack image) {
/*  903 */     int sizeX = image.getWidth();
/*  904 */     int sizeY = image.getHeight();
/*  905 */     int sizeZ = image.getSize();
/*      */     
/*  907 */     ImageStack result = ImageStack.create(sizeX, sizeY, sizeZ, 8);
/*      */     
/*  909 */     for (int z = 0; z < sizeZ; z++) {
/*      */       
/*  911 */       for (int y = 0; y < sizeY; y++) {
/*      */         
/*  913 */         for (int x = 0; x < sizeX; x++) {
/*      */           
/*  915 */           if (image.getVoxel(x, y, z) > 0.0D) {
/*  916 */             result.setVoxel(x, y, z, 255.0D);
/*      */           }
/*      */         } 
/*      */       } 
/*      */     } 
/*  921 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final ImagePlus binarizeBackground(ImagePlus imagePlus) {
/*      */     ImagePlus resultPlus;
/*  937 */     String title = String.valueOf(imagePlus.getShortTitle()) + "-bg";
/*  938 */     if (imagePlus.getStackSize() == 1) {
/*      */       
/*  940 */       ImageProcessor result = binarizeBackground(imagePlus.getProcessor());
/*  941 */       resultPlus = new ImagePlus(title, result);
/*      */     }
/*      */     else {
/*      */       
/*  945 */       ImageStack result = binarizeBackground(imagePlus.getStack());
/*  946 */       resultPlus = new ImagePlus(title, result);
/*      */     } 
/*  948 */     return resultPlus;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final ImageProcessor binarizeBackground(ImageProcessor image) {
/*  962 */     int width = image.getWidth();
/*  963 */     int height = image.getHeight();
/*  964 */     ByteProcessor byteProcessor = new ByteProcessor(width, height);
/*      */     
/*  966 */     for (int y = 0; y < height; y++) {
/*      */       
/*  968 */       for (int x = 0; x < width; x++) {
/*      */         
/*  970 */         if (image.get(x, y) == 0) {
/*  971 */           byteProcessor.set(x, y, 255);
/*      */         }
/*      */       } 
/*      */     } 
/*  975 */     return (ImageProcessor)byteProcessor;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final ImageStack binarizeBackground(ImageStack image) {
/*  989 */     int sizeX = image.getWidth();
/*  990 */     int sizeY = image.getHeight();
/*  991 */     int sizeZ = image.getSize();
/*      */     
/*  993 */     ImageStack result = ImageStack.create(sizeX, sizeY, sizeZ, 8);
/*      */     
/*  995 */     for (int z = 0; z < sizeZ; z++) {
/*      */       
/*  997 */       for (int y = 0; y < sizeY; y++) {
/*      */         
/*  999 */         for (int x = 0; x < sizeX; x++) {
/*      */           
/* 1001 */           if (image.getVoxel(x, y, z) == 0.0D) {
/* 1002 */             result.setVoxel(x, y, z, 255.0D);
/*      */           }
/*      */         } 
/*      */       } 
/*      */     } 
/* 1007 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final ImageProcessor skeleton(ImageProcessor image) {
/* 1021 */     return (new ImageJSkeleton()).process(image);
/*      */   }
/*      */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/binary/BinaryImages.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */