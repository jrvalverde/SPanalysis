/*     */ package inra.ijpb.binary.geodesic;
/*     */ 
/*     */ import ij.IJ;
/*     */ import ij.ImageStack;
/*     */ import ij.measure.ResultsTable;
/*     */ import inra.ijpb.algo.AlgoEvent;
/*     */ import inra.ijpb.algo.AlgoListener;
/*     */ import inra.ijpb.algo.AlgoStub;
/*     */ import inra.ijpb.binary.BinaryImages;
/*     */ import inra.ijpb.binary.ChamferWeights3D;
/*     */ import inra.ijpb.data.Cursor3D;
/*     */ import inra.ijpb.data.image.Images3D;
/*     */ import inra.ijpb.label.LabelImages;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GeodesicDiameter3DFloat
/*     */   extends AlgoStub
/*     */   implements GeodesicDiameter3D, AlgoListener
/*     */ {
/*     */   float[] weights;
/*  68 */   String currentStep = "";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GeodesicDiameter3DFloat(ChamferWeights3D chamferWeights) {
/*  83 */     this.weights = chamferWeights.getFloatWeights();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GeodesicDiameter3DFloat(float[] weights) {
/*  95 */     if (weights.length < 3)
/*     */     {
/*  97 */       throw new IllegalArgumentException("Requires an array with at least three elements");
/*     */     }
/*  99 */     this.weights = weights;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResultsTable process(ImageStack labelImage) {
/* 119 */     if (labelImage == null) return null;
/*     */ 
/*     */     
/* 122 */     int[] labels = LabelImages.findAllLabels(labelImage);
/* 123 */     int nbLabels = labels.length;
/*     */ 
/*     */ 
/*     */     
/* 127 */     GeodesicDistanceTransform3D geodDistMapAlgo = new GeodesicDistanceTransform3DFloat(this.weights, false);
/* 128 */     geodDistMapAlgo.addAlgoListener(this);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 134 */     ImageStack mask = BinaryImages.binarize(labelImage);
/*     */ 
/*     */     
/* 137 */     ImageStack marker = createMarkerOutsideLabels(labelImage);
/*     */     
/* 139 */     this.currentStep = "initCenters";
/* 140 */     fireStatusChanged(this, "Initializing pseudo geodesic centers...");
/*     */ 
/*     */     
/* 143 */     ImageStack distanceMap = geodDistMapAlgo.geodesicDistanceMap(marker, mask);
/*     */ 
/*     */     
/* 146 */     Cursor3D[] posCenter = findPositionOfMaxValues(distanceMap, labelImage, labels);
/*     */     
/* 148 */     float[] radii = findMaxValues(distanceMap, labelImage, labels);
/*     */ 
/*     */     
/* 151 */     Images3D.fill(marker, 0.0D);
/* 152 */     for (int i = 0; i < nbLabels; i++) {
/*     */       
/* 154 */       Cursor3D pos = posCenter[i];
/* 155 */       if (pos.getX() == -1) {
/*     */         
/* 157 */         IJ.showMessage("Particle Not Found", 
/* 158 */             "Could not find maximum for particle label " + i);
/*     */       } else {
/*     */         
/* 161 */         marker.setVoxel(pos.getX(), pos.getY(), pos.getZ(), 255.0D);
/*     */       } 
/*     */     } 
/* 164 */     this.currentStep = "firstEnds";
/* 165 */     fireStatusChanged(this, "Computing first geodesic extremities...");
/*     */ 
/*     */     
/* 168 */     distanceMap = geodDistMapAlgo.geodesicDistanceMap(marker, mask);
/*     */ 
/*     */ 
/*     */     
/* 172 */     Cursor3D[] pos1 = findPositionOfMaxValues(distanceMap, labelImage, labels);
/*     */ 
/*     */     
/* 175 */     Images3D.fill(marker, 0.0D);
/* 176 */     for (int j = 0; j < nbLabels; j++) {
/*     */       
/* 178 */       Cursor3D pos = pos1[j];
/* 179 */       if (pos.getX() == -1) {
/*     */         
/* 181 */         IJ.showMessage("Particle Not Found", 
/* 182 */             "Could not find maximum for particle label " + j);
/*     */       } else {
/*     */         
/* 185 */         marker.setVoxel(pos.getX(), pos.getY(), pos.getZ(), 255.0D);
/*     */       } 
/*     */     } 
/* 188 */     this.currentStep = "secondEnds";
/* 189 */     fireStatusChanged(this, "Computing second geodesic extremities...");
/*     */ 
/*     */     
/* 192 */     distanceMap = geodDistMapAlgo.geodesicDistanceMap(marker, mask);
/*     */ 
/*     */     
/* 195 */     float[] values = findMaxValues(distanceMap, labelImage, labels);
/*     */     
/* 197 */     Cursor3D[] pos2 = findPositionOfMaxValues(distanceMap, labelImage, labels);
/*     */ 
/*     */ 
/*     */     
/* 201 */     ResultsTable table = new ResultsTable();
/*     */ 
/*     */     
/* 204 */     for (int k = 0; k < nbLabels; k++) {
/*     */ 
/*     */       
/* 207 */       double radius = radii[k] / this.weights[0];
/* 208 */       double value = values[k] / this.weights[0] + 1.0D;
/*     */ 
/*     */       
/* 211 */       table.incrementCounter();
/* 212 */       table.addValue("Label", labels[k]);
/* 213 */       table.addValue("Geod. Diam.", value);
/* 214 */       table.addValue("Radius", radius);
/* 215 */       table.addValue("Geod. Elong.", Math.max(value / radius * 2.0D, 1.0D));
/* 216 */       table.addValue("xi", posCenter[k].getX());
/* 217 */       table.addValue("yi", posCenter[k].getY());
/* 218 */       table.addValue("zi", posCenter[k].getZ());
/* 219 */       table.addValue("x1", pos1[k].getX());
/* 220 */       table.addValue("y1", pos1[k].getY());
/* 221 */       table.addValue("z1", pos1[k].getZ());
/* 222 */       table.addValue("x2", pos2[k].getX());
/* 223 */       table.addValue("y2", pos2[k].getY());
/* 224 */       table.addValue("z2", pos2[k].getZ());
/*     */     } 
/*     */     
/* 227 */     return table;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ImageStack createMarkerOutsideLabels(ImageStack mask) {
/* 240 */     int sizeX = mask.getWidth();
/* 241 */     int sizeY = mask.getHeight();
/* 242 */     int sizeZ = mask.getSize();
/*     */ 
/*     */     
/* 245 */     ImageStack marker = ImageStack.create(sizeX, sizeY, sizeZ, 8);
/*     */ 
/*     */     
/* 248 */     for (int z = 0; z < sizeZ; z++) {
/*     */       
/* 250 */       for (int y = 0; y < sizeY; y++) {
/*     */         
/* 252 */         for (int x = 0; x < sizeX; x++)
/*     */         {
/* 254 */           marker.setVoxel(x, y, z, ((mask.getVoxel(x, y, z) == 0.0D) ? 'ÿ' : false));
/*     */         }
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 260 */     return marker;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Cursor3D[] findPositionOfMaxValues(ImageStack image, ImageStack labelImage, int[] labels) {
/* 270 */     int sizeX = labelImage.getWidth();
/* 271 */     int sizeY = labelImage.getHeight();
/* 272 */     int sizeZ = labelImage.getSize();
/*     */ 
/*     */     
/* 275 */     int nbLabel = labels.length;
/* 276 */     int maxLabel = 0;
/* 277 */     for (int i = 0; i < nbLabel; i++) {
/* 278 */       maxLabel = Math.max(maxLabel, labels[i]);
/*     */     }
/*     */ 
/*     */     
/* 282 */     int[] labelIndex = new int[maxLabel + 1];
/* 283 */     for (int j = 0; j < nbLabel; j++) {
/* 284 */       labelIndex[labels[j]] = j;
/*     */     }
/*     */ 
/*     */     
/* 288 */     Cursor3D[] posMax = new Cursor3D[nbLabel];
/* 289 */     float[] maxValues = new float[nbLabel];
/* 290 */     for (int k = 0; k < nbLabel; k++) {
/*     */       
/* 292 */       maxValues[k] = -1.0F;
/* 293 */       posMax[k] = new Cursor3D(-1, -1, -1);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 301 */     for (int z = 0; z < sizeZ; z++) {
/*     */       
/* 303 */       for (int y = 0; y < sizeY; y++) {
/*     */         
/* 305 */         for (int x = 0; x < sizeX; x++) {
/*     */           
/* 307 */           int label = (int)labelImage.getVoxel(x, y, z);
/*     */ 
/*     */           
/* 310 */           if (label != 0) {
/*     */ 
/*     */             
/* 313 */             int index = labelIndex[label];
/*     */ 
/*     */             
/* 316 */             float value = (float)image.getVoxel(x, y, z);
/* 317 */             if (value > maxValues[index]) {
/*     */               
/* 319 */               posMax[index] = new Cursor3D(x, y, z);
/* 320 */               maxValues[index] = value;
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/* 326 */     return posMax;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private float[] findMaxValues(ImageStack image, ImageStack labelImage, int[] labels) {
/* 336 */     int sizeX = labelImage.getWidth();
/* 337 */     int sizeY = labelImage.getHeight();
/* 338 */     int sizeZ = labelImage.getSize();
/*     */ 
/*     */     
/* 341 */     int nbLabel = labels.length;
/* 342 */     int maxLabel = 0;
/* 343 */     for (int i = 0; i < nbLabel; i++) {
/* 344 */       maxLabel = Math.max(maxLabel, labels[i]);
/*     */     }
/*     */ 
/*     */     
/* 348 */     int[] labelIndex = new int[maxLabel + 1];
/* 349 */     for (int j = 0; j < nbLabel; j++) {
/* 350 */       labelIndex[labels[j]] = j;
/*     */     }
/*     */     
/* 353 */     float[] maxValues = new float[nbLabel];
/* 354 */     for (int k = 0; k < nbLabel; k++) {
/* 355 */       maxValues[k] = Float.MIN_VALUE;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 362 */     for (int z = 0; z < sizeZ; z++) {
/*     */       
/* 364 */       for (int y = 0; y < sizeY; y++) {
/*     */         
/* 366 */         for (int x = 0; x < sizeX; x++) {
/*     */           
/* 368 */           int label = (int)labelImage.getVoxel(x, y, z);
/*     */ 
/*     */           
/* 371 */           if (label != 0) {
/*     */ 
/*     */             
/* 374 */             int index = labelIndex[label];
/*     */ 
/*     */             
/* 377 */             float value = (float)image.getVoxel(x, y, z);
/* 378 */             if (value > maxValues[index])
/* 379 */               maxValues[index] = value; 
/*     */           } 
/*     */         } 
/*     */       } 
/* 383 */     }  return maxValues;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void algoProgressChanged(AlgoEvent evt) {
/* 392 */     fireProgressChanged(new Event(this, evt));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void algoStatusChanged(AlgoEvent evt) {
/* 398 */     evt = new Event(this, evt);
/* 399 */     fireStatusChanged(evt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   class Event
/*     */     extends AlgoEvent
/*     */   {
/*     */     public Event(GeodesicDiameter3DFloat source, AlgoEvent evt) {
/* 409 */       super(source, "(GeodDiam3d) " + evt.getStatus(), evt.getCurrentProgress(), evt.getTotalProgress());
/* 410 */       if (!GeodesicDiameter3DFloat.this.currentStep.isEmpty())
/*     */       {
/* 412 */         this.status = "(GeodDiam3d-" + GeodesicDiameter3DFloat.this.currentStep + ") " + evt.getStatus();
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/binary/geodesic/GeodesicDiameter3DFloat.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */