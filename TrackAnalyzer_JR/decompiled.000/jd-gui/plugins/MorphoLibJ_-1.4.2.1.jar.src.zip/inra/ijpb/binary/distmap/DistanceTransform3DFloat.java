/*     */ package inra.ijpb.binary.distmap;
/*     */ 
/*     */ import ij.ImageStack;
/*     */ import inra.ijpb.algo.AlgoStub;
/*     */ import inra.ijpb.binary.ChamferWeights3D;
/*     */ import inra.ijpb.data.image.Images3D;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DistanceTransform3DFloat
/*     */   extends AlgoStub
/*     */   implements DistanceTransform3D
/*     */ {
/*     */   private float[] weights;
/*     */   private boolean normalizeMap = true;
/*     */   private int sizeX;
/*     */   private int sizeY;
/*     */   private int sizeZ;
/*     */   private byte[][] maskSlices;
/*     */   private float[][] resultSlices;
/*     */   
/*     */   public DistanceTransform3DFloat(ChamferWeights3D weights) {
/*  80 */     this(weights.getFloatWeights());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DistanceTransform3DFloat(float[] weights) {
/*  91 */     this.weights = weights;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DistanceTransform3DFloat(ChamferWeights3D weights, boolean normalize) {
/* 106 */     this(weights.getFloatWeights(), normalize);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DistanceTransform3DFloat(float[] weights, boolean normalize) {
/* 121 */     this.weights = weights;
/* 122 */     this.normalizeMap = normalize;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ImageStack distanceMap(ImageStack image) {
/* 145 */     this.sizeX = image.getWidth();
/* 146 */     this.sizeY = image.getHeight();
/* 147 */     this.sizeZ = image.getSize();
/*     */ 
/*     */     
/* 150 */     this.maskSlices = Images3D.getByteArrays(image);
/*     */ 
/*     */     
/* 153 */     ImageStack buffer = ImageStack.create(this.sizeX, this.sizeY, this.sizeZ, 32);
/* 154 */     this.resultSlices = Images3D.getFloatArrays(buffer);
/*     */ 
/*     */     
/* 157 */     initializeResultSlices();
/*     */ 
/*     */     
/* 160 */     forwardScan();
/* 161 */     backwardScan();
/*     */ 
/*     */     
/* 164 */     if (this.normalizeMap)
/*     */     {
/* 166 */       normalizeResultSlices();
/*     */     }
/*     */     
/* 169 */     fireStatusChanged(this, "");
/* 170 */     return buffer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void initializeResultSlices() {
/* 183 */     fireStatusChanged(this, "Initialization...");
/*     */ 
/*     */     
/* 186 */     for (int z = 0; z < this.sizeZ; z++) {
/*     */       
/* 188 */       byte[] maskSlice = this.maskSlices[z];
/* 189 */       float[] resultSlice = this.resultSlices[z];
/*     */       
/* 191 */       for (int y = 0; y < this.sizeY; y++) {
/*     */         
/* 193 */         for (int x = 0; x < this.sizeX; x++) {
/*     */           
/* 195 */           int index = this.sizeX * y + x;
/* 196 */           int val = maskSlice[index];
/* 197 */           resultSlice[index] = (val == 0) ? 0.0F : Float.MAX_VALUE;
/*     */         } 
/*     */       } 
/*     */     } 
/* 201 */     fireProgressChanged(this, 1.0D, 1.0D);
/*     */   }
/*     */ 
/*     */   
/*     */   private void forwardScan() {
/* 206 */     fireStatusChanged(this, "Forward scan...");
/*     */     
/* 208 */     for (int z = 0; z < this.sizeZ; z++) {
/*     */       
/* 210 */       fireProgressChanged(this, z, this.sizeZ);
/*     */       
/* 212 */       byte[] maskSlice = this.maskSlices[z];
/* 213 */       float[] resultSlice = this.resultSlices[z];
/*     */       
/* 215 */       float[] resultSlice2 = null;
/* 216 */       if (z > 0)
/*     */       {
/* 218 */         resultSlice2 = this.resultSlices[z - 1];
/*     */       }
/*     */       
/* 221 */       for (int y = 0; y < this.sizeY; y++) {
/*     */         
/* 223 */         for (int x = 0; x < this.sizeX; x++) {
/*     */           
/* 225 */           int index = this.sizeX * y + x;
/*     */ 
/*     */           
/* 228 */           if ((maskSlice[index] & 0xFF) != 0) {
/*     */ 
/*     */ 
/*     */             
/* 232 */             double ortho = 3.4028234663852886E38D;
/* 233 */             double diago = 3.4028234663852886E38D;
/* 234 */             double diag3 = 3.4028234663852886E38D;
/*     */ 
/*     */             
/* 237 */             if (z > 0) {
/*     */               
/* 239 */               if (y > 0) {
/*     */ 
/*     */                 
/* 242 */                 if (x > 0)
/*     */                 {
/* 244 */                   diag3 = Math.min(diag3, resultSlice2[this.sizeX * (y - 1) + x - 1]);
/*     */                 }
/* 246 */                 diago = Math.min(diago, resultSlice2[this.sizeX * (y - 1) + x]);
/* 247 */                 if (x < this.sizeX - 1)
/*     */                 {
/* 249 */                   diag3 = Math.min(diag3, resultSlice2[this.sizeX * (y - 1) + x + 1]);
/*     */                 }
/*     */               } 
/*     */ 
/*     */               
/* 254 */               if (x > 0)
/*     */               {
/* 256 */                 diago = Math.min(diago, resultSlice2[this.sizeX * y + x - 1]);
/*     */               }
/* 258 */               ortho = Math.min(ortho, resultSlice2[this.sizeX * y + x]);
/* 259 */               if (x < this.sizeX - 1)
/*     */               {
/* 261 */                 diago = Math.min(diago, resultSlice2[this.sizeX * y + x + 1]);
/*     */               }
/*     */               
/* 264 */               if (y < this.sizeY - 1) {
/*     */ 
/*     */                 
/* 267 */                 if (x > 0)
/*     */                 {
/* 269 */                   diag3 = Math.min(diag3, resultSlice2[this.sizeX * (y + 1) + x - 1]);
/*     */                 }
/* 271 */                 diago = Math.min(diago, resultSlice2[this.sizeX * (y + 1) + x]);
/* 272 */                 if (x < this.sizeX - 1)
/*     */                 {
/* 274 */                   diag3 = Math.min(diag3, resultSlice2[this.sizeX * (y + 1) + x + 1]);
/*     */                 }
/*     */               } 
/*     */             } 
/*     */ 
/*     */             
/* 280 */             if (y > 0) {
/*     */               
/* 282 */               if (x > 0)
/*     */               {
/* 284 */                 diago = Math.min(diago, resultSlice[this.sizeX * (y - 1) + x - 1]);
/*     */               }
/* 286 */               ortho = Math.min(ortho, resultSlice[this.sizeX * (y - 1) + x]);
/* 287 */               if (x < this.sizeX - 1)
/*     */               {
/* 289 */                 diago = Math.min(diago, resultSlice[this.sizeX * (y - 1) + x + 1]);
/*     */               }
/*     */             } 
/*     */ 
/*     */             
/* 294 */             if (x > 0)
/*     */             {
/* 296 */               ortho = Math.min(ortho, resultSlice[index - 1]);
/*     */             }
/*     */             
/* 299 */             double newVal = min3w(ortho, diago, diag3);
/* 300 */             updateIfNeeded(x, y, z, newVal);
/*     */           } 
/*     */         } 
/*     */       } 
/* 304 */     }  fireProgressChanged(this, 1.0D, 1.0D);
/*     */   }
/*     */ 
/*     */   
/*     */   private void backwardScan() {
/* 309 */     fireStatusChanged(this, "Backward scan...");
/*     */     
/* 311 */     for (int z = this.sizeZ - 1; z >= 0; z--) {
/*     */       
/* 313 */       fireProgressChanged(this, (this.sizeZ - 1 - z), this.sizeZ);
/*     */       
/* 315 */       byte[] maskSlice = this.maskSlices[z];
/* 316 */       float[] resultSlice = this.resultSlices[z];
/*     */       
/* 318 */       float[] resultSlice2 = null;
/* 319 */       if (z < this.sizeZ - 1)
/*     */       {
/* 321 */         resultSlice2 = this.resultSlices[z + 1];
/*     */       }
/*     */       
/* 324 */       for (int y = this.sizeY - 1; y >= 0; y--) {
/*     */         
/* 326 */         for (int x = this.sizeX - 1; x >= 0; x--) {
/*     */           
/* 328 */           int index = this.sizeX * y + x;
/*     */ 
/*     */           
/* 331 */           if ((maskSlice[index] & 0xFF) != 0) {
/*     */ 
/*     */ 
/*     */             
/* 335 */             double ortho = Double.MAX_VALUE;
/* 336 */             double diago = Double.MAX_VALUE;
/* 337 */             double diag3 = Double.MAX_VALUE;
/*     */ 
/*     */             
/* 340 */             if (z < this.sizeZ - 1) {
/*     */               
/* 342 */               if (y < this.sizeY - 1) {
/*     */ 
/*     */                 
/* 345 */                 if (x < this.sizeX - 1)
/*     */                 {
/* 347 */                   diag3 = Math.min(diag3, resultSlice2[this.sizeX * (y + 1) + x + 1]);
/*     */                 }
/* 349 */                 diago = Math.min(diago, resultSlice2[this.sizeX * (y + 1) + x]);
/* 350 */                 if (x > 0)
/*     */                 {
/* 352 */                   diag3 = Math.min(diag3, resultSlice2[this.sizeX * (y + 1) + x - 1]);
/*     */                 }
/*     */               } 
/*     */ 
/*     */               
/* 357 */               if (x < this.sizeX - 1)
/*     */               {
/* 359 */                 diago = Math.min(diago, resultSlice2[this.sizeX * y + x + 1]);
/*     */               }
/* 361 */               ortho = Math.min(ortho, resultSlice2[this.sizeX * y + x]);
/* 362 */               if (x > 0)
/*     */               {
/* 364 */                 diago = Math.min(diago, resultSlice2[this.sizeX * y + x - 1]);
/*     */               }
/*     */               
/* 367 */               if (y > 0) {
/*     */ 
/*     */                 
/* 370 */                 if (x < this.sizeX - 1)
/*     */                 {
/* 372 */                   diag3 = Math.min(diag3, resultSlice2[this.sizeX * (y - 1) + x + 1]);
/*     */                 }
/* 374 */                 diago = Math.min(diago, resultSlice2[this.sizeX * (y - 1) + x]);
/* 375 */                 if (x > 0)
/*     */                 {
/* 377 */                   diag3 = Math.min(diag3, resultSlice2[this.sizeX * (y - 1) + x - 1]);
/*     */                 }
/*     */               } 
/*     */             } 
/*     */ 
/*     */             
/* 383 */             if (y < this.sizeY - 1) {
/*     */               
/* 385 */               if (x < this.sizeX - 1)
/*     */               {
/* 387 */                 diago = Math.min(diago, resultSlice[this.sizeX * (y + 1) + x + 1]);
/*     */               }
/* 389 */               ortho = Math.min(ortho, resultSlice[this.sizeX * (y + 1) + x]);
/* 390 */               if (x > 0)
/*     */               {
/* 392 */                 diago = Math.min(diago, resultSlice[this.sizeX * (y + 1) + x - 1]);
/*     */               }
/*     */             } 
/*     */ 
/*     */             
/* 397 */             if (x < this.sizeX - 1)
/*     */             {
/* 399 */               ortho = Math.min(ortho, resultSlice[index + 1]);
/*     */             }
/*     */             
/* 402 */             double newVal = min3w(ortho, diago, diag3);
/* 403 */             updateIfNeeded(x, y, z, newVal);
/*     */           } 
/*     */         } 
/*     */       } 
/* 407 */     }  fireProgressChanged(this, 1.0D, 1.0D);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private double min3w(double ortho, double diago, double diag2) {
/* 416 */     return Math.min(Math.min(ortho + this.weights[0], diago + this.weights[1]), diag2 + this.weights[2]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void updateIfNeeded(int i, int j, int k, double newVal) {
/* 425 */     int index = j * this.sizeX + i;
/* 426 */     double value = this.resultSlices[k][j * this.sizeX + i];
/* 427 */     if (newVal < value)
/*     */     {
/* 429 */       this.resultSlices[k][index] = (float)newVal;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private void normalizeResultSlices() {
/* 435 */     fireStatusChanged(this, "Normalize map...");
/* 436 */     for (int z = 0; z < this.sizeZ; z++) {
/*     */       
/* 438 */       fireProgressChanged(this, z, this.sizeZ);
/*     */       
/* 440 */       byte[] maskSlice = this.maskSlices[z];
/* 441 */       float[] resultSlice = this.resultSlices[z];
/*     */       
/* 443 */       for (int y = 0; y < this.sizeY; y++) {
/*     */         
/* 445 */         for (int x = 0; x < this.sizeX; x++) {
/*     */           
/* 447 */           int index = this.sizeX * y + x;
/* 448 */           if (maskSlice[index] != 0)
/*     */           {
/* 450 */             resultSlice[index] = resultSlice[index] / this.weights[0];
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/* 455 */     fireProgressChanged(this, 1.0D, 1.0D);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/binary/distmap/DistanceTransform3DFloat.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */