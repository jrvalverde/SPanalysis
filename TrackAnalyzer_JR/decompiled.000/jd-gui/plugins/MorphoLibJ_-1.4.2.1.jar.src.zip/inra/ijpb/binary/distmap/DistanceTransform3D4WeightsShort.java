/*     */ package inra.ijpb.binary.distmap;
/*     */ 
/*     */ import ij.ImageStack;
/*     */ import inra.ijpb.algo.AlgoStub;
/*     */ import inra.ijpb.binary.ChamferWeights3D;
/*     */ import inra.ijpb.data.image.Images3D;
/*     */ import java.util.ArrayList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DistanceTransform3D4WeightsShort
/*     */   extends AlgoStub
/*     */   implements DistanceTransform3D
/*     */ {
/*     */   private short[] weights;
/*     */   private boolean normalizeMap = true;
/*     */   private int sizeX;
/*     */   private int sizeY;
/*     */   private int sizeZ;
/*     */   private byte[][] maskSlices;
/*     */   private short[][] resultSlices;
/*     */   
/*     */   public DistanceTransform3D4WeightsShort(ChamferWeights3D weights) {
/*  83 */     this(weights.getShortWeights());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DistanceTransform3D4WeightsShort(short[] weights) {
/*  92 */     this.weights = weights;
/*  93 */     if (weights.length < 4)
/*     */     {
/*  95 */       throw new IllegalArgumentException("Weights array must have length equal to 4");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DistanceTransform3D4WeightsShort(ChamferWeights3D weights, boolean normalize) {
/* 109 */     this(weights.getShortWeights(), normalize);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DistanceTransform3D4WeightsShort(short[] weights, boolean normalize) {
/* 122 */     this(weights);
/* 123 */     this.normalizeMap = normalize;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ImageStack distanceMap(ImageStack image) {
/* 144 */     this.sizeX = image.getWidth();
/* 145 */     this.sizeY = image.getHeight();
/* 146 */     this.sizeZ = image.getSize();
/*     */ 
/*     */     
/* 149 */     this.maskSlices = Images3D.getByteArrays(image);
/*     */ 
/*     */     
/* 152 */     ImageStack buffer = ImageStack.create(this.sizeX, this.sizeY, this.sizeZ, 16);
/* 153 */     this.resultSlices = Images3D.getShortArrays(buffer);
/*     */ 
/*     */     
/* 156 */     initializeResultSlices();
/*     */ 
/*     */     
/* 159 */     forwardScan();
/* 160 */     backwardScan();
/*     */ 
/*     */     
/* 163 */     if (this.normalizeMap)
/*     */     {
/* 165 */       normalizeResultSlices();
/*     */     }
/*     */     
/* 168 */     fireStatusChanged(this, "");
/* 169 */     return buffer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void initializeResultSlices() {
/* 182 */     fireStatusChanged(this, "Initialization...");
/*     */ 
/*     */     
/* 185 */     for (int z = 0; z < this.sizeZ; z++) {
/*     */       
/* 187 */       fireProgressChanged(this, z, this.sizeZ);
/*     */       
/* 189 */       byte[] maskSlice = this.maskSlices[z];
/* 190 */       short[] resultSlice = this.resultSlices[z];
/*     */       
/* 192 */       for (int y = 0; y < this.sizeY; y++) {
/*     */         
/* 194 */         for (int x = 0; x < this.sizeX; x++) {
/*     */           
/* 196 */           int index = this.sizeX * y + x;
/* 197 */           int val = maskSlice[index];
/* 198 */           resultSlice[index] = (val == 0) ? 0 : Short.MAX_VALUE;
/*     */         } 
/*     */       } 
/*     */     } 
/* 202 */     fireProgressChanged(this, 1.0D, 1.0D);
/*     */   }
/*     */ 
/*     */   
/*     */   private void forwardScan() {
/* 207 */     fireStatusChanged(this, "Forward scan...");
/*     */ 
/*     */     
/* 210 */     ArrayList<WeightedOffset> offsets = new ArrayList<WeightedOffset>();
/*     */ 
/*     */     
/* 213 */     offsets.add(new WeightedOffset(-1, -1, -2, this.weights[3]));
/* 214 */     offsets.add(new WeightedOffset(1, -1, -2, this.weights[3]));
/* 215 */     offsets.add(new WeightedOffset(-1, 1, -2, this.weights[3]));
/* 216 */     offsets.add(new WeightedOffset(1, 1, -2, this.weights[3]));
/*     */ 
/*     */     
/* 219 */     offsets.add(new WeightedOffset(-1, -1, -1, this.weights[2]));
/* 220 */     offsets.add(new WeightedOffset(0, -1, -1, this.weights[1]));
/* 221 */     offsets.add(new WeightedOffset(1, -1, -1, this.weights[2]));
/* 222 */     offsets.add(new WeightedOffset(-1, 0, -1, this.weights[1]));
/* 223 */     offsets.add(new WeightedOffset(0, 0, -1, this.weights[0]));
/* 224 */     offsets.add(new WeightedOffset(1, 0, -1, this.weights[1]));
/* 225 */     offsets.add(new WeightedOffset(-1, 1, -1, this.weights[2]));
/* 226 */     offsets.add(new WeightedOffset(0, 1, -1, this.weights[1]));
/* 227 */     offsets.add(new WeightedOffset(1, 1, -1, this.weights[2]));
/*     */     
/* 229 */     offsets.add(new WeightedOffset(-1, -2, -1, this.weights[3]));
/* 230 */     offsets.add(new WeightedOffset(1, -2, -1, this.weights[3]));
/* 231 */     offsets.add(new WeightedOffset(-2, -1, -1, this.weights[3]));
/* 232 */     offsets.add(new WeightedOffset(2, -1, -1, this.weights[3]));
/* 233 */     offsets.add(new WeightedOffset(-2, 1, -1, this.weights[3]));
/* 234 */     offsets.add(new WeightedOffset(2, 1, -1, this.weights[3]));
/* 235 */     offsets.add(new WeightedOffset(-1, 2, -1, this.weights[3]));
/* 236 */     offsets.add(new WeightedOffset(1, 2, -1, this.weights[3]));
/*     */ 
/*     */     
/* 239 */     offsets.add(new WeightedOffset(-1, -1, 0, this.weights[1]));
/* 240 */     offsets.add(new WeightedOffset(0, -1, 0, this.weights[0]));
/* 241 */     offsets.add(new WeightedOffset(1, -1, 0, this.weights[1]));
/* 242 */     offsets.add(new WeightedOffset(-1, 0, 0, this.weights[0]));
/*     */ 
/*     */     
/* 245 */     for (int z = 0; z < this.sizeZ; z++) {
/*     */       
/* 247 */       fireProgressChanged(this, z, this.sizeZ);
/*     */       
/* 249 */       byte[] maskSlice = this.maskSlices[z];
/* 250 */       short[] currentSlice = this.resultSlices[z];
/*     */       
/* 252 */       for (int y = 0; y < this.sizeY; y++) {
/*     */         
/* 254 */         for (int x = 0; x < this.sizeX; x++) {
/*     */           
/* 256 */           int index = this.sizeX * y + x;
/*     */ 
/*     */           
/* 259 */           if ((maskSlice[index] & 0xFF) != 0) {
/*     */ 
/*     */             
/* 262 */             int value = currentSlice[index];
/*     */             
/* 264 */             int newVal = 32767;
/* 265 */             for (WeightedOffset offset : offsets) {
/*     */               
/* 267 */               int x2 = x + offset.dx;
/* 268 */               int y2 = y + offset.dy;
/* 269 */               int z2 = z + offset.dz;
/*     */ 
/*     */               
/* 272 */               if (x2 >= 0 && x2 < this.sizeX && y2 >= 0 && y2 < this.sizeY && z2 >= 0 && z2 < this.sizeZ)
/*     */               {
/* 274 */                 newVal = Math.min(newVal, this.resultSlices[z2][this.sizeX * y2 + x2] + offset.weight);
/*     */               }
/*     */               
/* 277 */               if (newVal < value)
/*     */               {
/* 279 */                 currentSlice[index] = (short)newVal; } 
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/* 285 */     fireProgressChanged(this, 1.0D, 1.0D);
/*     */   }
/*     */ 
/*     */   
/*     */   private void backwardScan() {
/* 290 */     fireStatusChanged(this, "Backward scan...");
/*     */ 
/*     */     
/* 293 */     ArrayList<WeightedOffset> offsets = new ArrayList<WeightedOffset>();
/*     */ 
/*     */     
/* 296 */     offsets.add(new WeightedOffset(-1, -1, 2, this.weights[3]));
/* 297 */     offsets.add(new WeightedOffset(1, -1, 2, this.weights[3]));
/* 298 */     offsets.add(new WeightedOffset(-1, 1, 2, this.weights[3]));
/* 299 */     offsets.add(new WeightedOffset(1, 1, 2, this.weights[3]));
/*     */ 
/*     */     
/* 302 */     offsets.add(new WeightedOffset(-1, -1, 1, this.weights[2]));
/* 303 */     offsets.add(new WeightedOffset(0, -1, 1, this.weights[1]));
/* 304 */     offsets.add(new WeightedOffset(1, -1, 1, this.weights[2]));
/* 305 */     offsets.add(new WeightedOffset(-1, 0, 1, this.weights[1]));
/* 306 */     offsets.add(new WeightedOffset(0, 0, 1, this.weights[0]));
/* 307 */     offsets.add(new WeightedOffset(1, 0, 1, this.weights[1]));
/* 308 */     offsets.add(new WeightedOffset(-1, 1, 1, this.weights[2]));
/* 309 */     offsets.add(new WeightedOffset(0, 1, 1, this.weights[1]));
/* 310 */     offsets.add(new WeightedOffset(1, 1, 1, this.weights[2]));
/*     */     
/* 312 */     offsets.add(new WeightedOffset(-1, -2, 1, this.weights[3]));
/* 313 */     offsets.add(new WeightedOffset(1, -2, 1, this.weights[3]));
/* 314 */     offsets.add(new WeightedOffset(-2, -1, 1, this.weights[3]));
/* 315 */     offsets.add(new WeightedOffset(2, -1, 1, this.weights[3]));
/* 316 */     offsets.add(new WeightedOffset(-2, 1, 1, this.weights[3]));
/* 317 */     offsets.add(new WeightedOffset(2, 1, 1, this.weights[3]));
/* 318 */     offsets.add(new WeightedOffset(-1, 2, 1, this.weights[3]));
/* 319 */     offsets.add(new WeightedOffset(1, 2, 1, this.weights[3]));
/*     */ 
/*     */     
/* 322 */     offsets.add(new WeightedOffset(-1, 1, 0, this.weights[1]));
/* 323 */     offsets.add(new WeightedOffset(0, 1, 0, this.weights[0]));
/* 324 */     offsets.add(new WeightedOffset(1, 1, 0, this.weights[1]));
/* 325 */     offsets.add(new WeightedOffset(1, 0, 0, this.weights[0]));
/*     */ 
/*     */     
/* 328 */     for (int z = this.sizeZ - 1; z >= 0; z--) {
/*     */       
/* 330 */       fireProgressChanged(this, (this.sizeZ - 1 - z), this.sizeZ);
/*     */       
/* 332 */       byte[] maskSlice = this.maskSlices[z];
/* 333 */       short[] currentSlice = this.resultSlices[z];
/*     */       
/* 335 */       for (int y = this.sizeY - 1; y >= 0; y--) {
/*     */         
/* 337 */         for (int x = this.sizeX - 1; x >= 0; x--) {
/*     */           
/* 339 */           int index = this.sizeX * y + x;
/*     */ 
/*     */           
/* 342 */           if ((maskSlice[index] & 0xFF) != 0) {
/*     */ 
/*     */             
/* 345 */             int value = currentSlice[index];
/*     */             
/* 347 */             int newVal = 32767;
/* 348 */             for (WeightedOffset offset : offsets) {
/*     */               
/* 350 */               int x2 = x + offset.dx;
/* 351 */               int y2 = y + offset.dy;
/* 352 */               int z2 = z + offset.dz;
/*     */ 
/*     */               
/* 355 */               if (x2 >= 0 && x2 < this.sizeX && y2 >= 0 && y2 < this.sizeY && z2 >= 0 && z2 < this.sizeZ)
/*     */               {
/* 357 */                 newVal = Math.min(newVal, this.resultSlices[z2][this.sizeX * y2 + x2] + offset.weight);
/*     */               }
/*     */               
/* 360 */               if (newVal < value)
/*     */               {
/* 362 */                 currentSlice[index] = (short)newVal; } 
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/* 368 */     fireProgressChanged(this, 1.0D, 1.0D);
/*     */   }
/*     */ 
/*     */   
/*     */   private void normalizeResultSlices() {
/* 373 */     fireStatusChanged(this, "Normalize map...");
/* 374 */     for (int z = 0; z < this.sizeZ; z++) {
/*     */       
/* 376 */       fireProgressChanged(this, z, this.sizeZ);
/*     */       
/* 378 */       byte[] maskSlice = this.maskSlices[z];
/* 379 */       short[] resultSlice = this.resultSlices[z];
/*     */       
/* 381 */       for (int y = 0; y < this.sizeY; y++) {
/*     */         
/* 383 */         for (int x = 0; x < this.sizeX; x++) {
/*     */           
/* 385 */           int index = this.sizeX * y + x;
/* 386 */           if (maskSlice[index] != 0)
/*     */           {
/* 388 */             resultSlice[index] = (short)((resultSlice[index] & 0xFFFF) / this.weights[0]);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/* 393 */     fireProgressChanged(this, 1.0D, 1.0D);
/*     */   }
/*     */ 
/*     */   
/*     */   private class WeightedOffset
/*     */   {
/*     */     int dx;
/*     */     int dy;
/*     */     int dz;
/*     */     short weight;
/*     */     
/*     */     public WeightedOffset(int dx, int dy, int dz, short weight) {
/* 405 */       this.dx = dx;
/* 406 */       this.dy = dy;
/* 407 */       this.dz = dz;
/* 408 */       this.weight = weight;
/*     */     }
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/binary/distmap/DistanceTransform3D4WeightsShort.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */