/*     */ package inra.ijpb.binary.conncomp;
/*     */ 
/*     */ import ij.process.ByteProcessor;
/*     */ import ij.process.FloatProcessor;
/*     */ import ij.process.ImageProcessor;
/*     */ import ij.process.ShortProcessor;
/*     */ import inra.ijpb.algo.AlgoStub;
/*     */ import inra.ijpb.morphology.FloodFill;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FloodFillComponentsLabeling
/*     */   extends AlgoStub
/*     */   implements ConnectedComponentsLabeling
/*     */ {
/*  49 */   int connectivity = 4;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  55 */   int bitDepth = 16;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FloodFillComponentsLabeling() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FloodFillComponentsLabeling(int connectivity) {
/*  72 */     this.connectivity = connectivity;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FloodFillComponentsLabeling(int connectivity, int bitDepth) {
/*  86 */     this.connectivity = connectivity;
/*  87 */     this.bitDepth = bitDepth;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ImageProcessor computeLabels(ImageProcessor image) {
/*     */     int maxLabel;
/*     */     ByteProcessor byteProcessor;
/*     */     ShortProcessor shortProcessor;
/*     */     FloatProcessor floatProcessor;
/*  97 */     int width = image.getWidth();
/*  98 */     int height = image.getHeight();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 104 */     switch (this.bitDepth) {
/*     */       case 8:
/* 106 */         byteProcessor = new ByteProcessor(width, height);
/* 107 */         maxLabel = 255;
/*     */         break;
/*     */       case 16:
/* 110 */         shortProcessor = new ShortProcessor(width, height);
/* 111 */         maxLabel = 65535;
/*     */         break;
/*     */       case 32:
/* 114 */         floatProcessor = new FloatProcessor(width, height);
/* 115 */         maxLabel = 4194304;
/*     */         break;
/*     */       default:
/* 118 */         throw new IllegalArgumentException(
/* 119 */             "Bit Depth should be 8, 16 or 32.");
/*     */     } 
/*     */ 
/*     */     
/* 123 */     int nLabels = 0;
/*     */ 
/*     */     
/* 126 */     for (int y = 0; y < height; y++) {
/*     */       
/* 128 */       fireProgressChanged(this, y, height);
/* 129 */       for (int x = 0; x < width; x++) {
/*     */         
/* 131 */         if (image.get(x, y) != 0)
/*     */         {
/* 133 */           if (floatProcessor.get(x, y) <= 0) {
/*     */ 
/*     */ 
/*     */             
/* 137 */             if (nLabels == maxLabel)
/*     */             {
/* 139 */               throw new RuntimeException("Max number of label reached (" + maxLabel + ")");
/*     */             }
/*     */ 
/*     */             
/* 143 */             nLabels++;
/* 144 */             FloodFill.floodFillFloat(image, x, y, (ImageProcessor)floatProcessor, nLabels, this.connectivity);
/*     */           }  } 
/*     */       } 
/* 147 */     }  fireProgressChanged(this, 1.0D, 1.0D);
/*     */     
/* 149 */     floatProcessor.setMinAndMax(0.0D, nLabels);
/* 150 */     return (ImageProcessor)floatProcessor;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/binary/conncomp/FloodFillComponentsLabeling.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */