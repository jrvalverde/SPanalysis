package inra.ijpb.binary.geodesic;

import ij.process.ImageProcessor;
import inra.ijpb.algo.Algo;

public interface GeodesicDistanceTransform extends Algo {
  ImageProcessor geodesicDistanceMap(ImageProcessor paramImageProcessor1, ImageProcessor paramImageProcessor2);
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/binary/geodesic/GeodesicDistanceTransform.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */