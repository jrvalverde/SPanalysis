/*     */ package inra.ijpb.binary;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public enum ChamferWeights
/*     */ {
/*  52 */   CHESSBOARD(
/*  53 */     "Chessboard (1,1)", new short[] { 1, 1 }),
/*  54 */   CITY_BLOCK(
/*  55 */     "City-Block (1,2)", new short[] { 1, 2 }),
/*  56 */   QUASI_EUCLIDEAN(
/*     */ 
/*     */ 
/*     */     
/*  60 */     "Quasi-Euclidean (1,1.41)", 
/*  61 */     new short[] { 10, 14
/*  62 */     }, new float[] { 1.0F, (float)Math.sqrt(2.0D) }),
/*  63 */   BORGEFORS(
/*     */ 
/*     */ 
/*     */     
/*  67 */     "Borgefors (3,4)", new short[] { 3, 4 }),
/*  68 */   WEIGHTS_23(
/*  69 */     "Weights (2,3)", new short[] { 2, 3 }),
/*  70 */   WEIGHTS_57(
/*  71 */     "Weights (5,7)", new short[] { 5, 7 }),
/*  72 */   CHESSKNIGHT(
/*     */ 
/*     */ 
/*     */     
/*  76 */     "Chessknight (5,7,11)", new short[] { 5, 7, 11 });
/*     */   
/*     */   private final String label;
/*     */   
/*     */   private final short[] shortWeights;
/*     */   private final float[] floatWeights;
/*     */   
/*     */   ChamferWeights(String label, short[] shortWeights) {
/*  84 */     this.label = label;
/*  85 */     this.shortWeights = shortWeights;
/*  86 */     this.floatWeights = new float[shortWeights.length];
/*  87 */     for (int i = 0; i < shortWeights.length; i++) {
/*  88 */       this.floatWeights[i] = shortWeights[i];
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   ChamferWeights(String label, short[] shortWeights, float[] floatWeights) {
/*  94 */     this.label = label;
/*  95 */     this.shortWeights = shortWeights;
/*  96 */     this.floatWeights = floatWeights;
/*     */   }
/*     */ 
/*     */   
/*     */   public short[] getShortWeights() {
/* 101 */     return this.shortWeights;
/*     */   }
/*     */ 
/*     */   
/*     */   public float[] getFloatWeights() {
/* 106 */     return this.floatWeights;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 111 */     return this.label;
/*     */   }
/*     */ 
/*     */   
/*     */   public static String[] getAllLabels() {
/* 116 */     int n = (values()).length;
/* 117 */     String[] result = new String[n];
/*     */     
/* 119 */     int i = 0; byte b; int j; ChamferWeights[] arrayOfChamferWeights;
/* 120 */     for (j = (arrayOfChamferWeights = values()).length, b = 0; b < j; ) { ChamferWeights weight = arrayOfChamferWeights[b];
/* 121 */       result[i++] = weight.label; b++; }
/*     */     
/* 123 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ChamferWeights fromLabel(String label) {
/* 137 */     if (label != null)
/* 138 */       label = label.toLowerCase();  byte b; int i; ChamferWeights[] arrayOfChamferWeights;
/* 139 */     for (i = (arrayOfChamferWeights = values()).length, b = 0; b < i; ) { ChamferWeights weight = arrayOfChamferWeights[b];
/*     */       
/* 141 */       String cmp = weight.label.toLowerCase();
/* 142 */       if (cmp.equals(label))
/* 143 */         return weight;  b++; }
/*     */     
/* 145 */     throw new IllegalArgumentException(
/* 146 */         "Unable to parse ChamferWeights with label: " + label);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/binary/ChamferWeights.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */