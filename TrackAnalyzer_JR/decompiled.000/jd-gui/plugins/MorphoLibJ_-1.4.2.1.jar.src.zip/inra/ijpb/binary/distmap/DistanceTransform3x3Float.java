/*     */ package inra.ijpb.binary.distmap;
/*     */ 
/*     */ import ij.process.FloatProcessor;
/*     */ import ij.process.ImageProcessor;
/*     */ import inra.ijpb.algo.AlgoEvent;
/*     */ import inra.ijpb.algo.AlgoStub;
/*     */ import inra.ijpb.binary.ChamferWeights;
/*     */ import inra.ijpb.label.LabelValues;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DistanceTransform3x3Float
/*     */   extends AlgoStub
/*     */   implements DistanceTransform
/*     */ {
/*     */   private float[] weights;
/*     */   private boolean normalizeMap = true;
/*     */   
/*     */   public DistanceTransform3x3Float(float[] weights) {
/*  80 */     this(weights, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DistanceTransform3x3Float(ChamferWeights weights, boolean normalize) {
/*  95 */     this(weights.getFloatWeights(), normalize);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DistanceTransform3x3Float(float[] weights, boolean normalize) {
/* 108 */     this.weights = weights;
/* 109 */     this.normalizeMap = normalize;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FloatProcessor distanceMap(ImageProcessor labelImage) {
/* 132 */     FloatProcessor distMap = initializeResult(labelImage);
/*     */ 
/*     */     
/* 135 */     forwardScan(distMap, labelImage);
/* 136 */     backwardScan(distMap, labelImage);
/*     */ 
/*     */     
/* 139 */     if (this.normalizeMap)
/*     */     {
/* 141 */       normalizeResult(distMap, labelImage);
/*     */     }
/*     */ 
/*     */     
/* 145 */     double maxVal = LabelValues.maxValueWithinLabels((ImageProcessor)distMap, labelImage);
/* 146 */     distMap.setMinAndMax(0.0D, maxVal);
/*     */ 
/*     */     
/* 149 */     if (distMap.isInvertedLut()) {
/* 150 */       distMap.invertLut();
/*     */     }
/* 152 */     fireStatusChanged(new AlgoEvent(this, ""));
/*     */     
/* 154 */     return distMap;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private FloatProcessor initializeResult(ImageProcessor labelImage) {
/* 163 */     fireStatusChanged(new AlgoEvent(this, "Initialization"));
/*     */ 
/*     */     
/* 166 */     int sizeX = labelImage.getWidth();
/* 167 */     int sizeY = labelImage.getHeight();
/*     */ 
/*     */     
/* 170 */     FloatProcessor distMap = new FloatProcessor(sizeX, sizeY);
/* 171 */     distMap.setValue(0.0D);
/* 172 */     distMap.fill();
/*     */ 
/*     */     
/* 175 */     for (int y = 0; y < sizeY; y++) {
/*     */       
/* 177 */       for (int x = 0; x < sizeX; x++) {
/*     */         
/* 179 */         int label = (int)labelImage.getf(x, y);
/* 180 */         distMap.setf(x, y, (label == 0) ? 0.0F : Float.POSITIVE_INFINITY);
/*     */       } 
/*     */     } 
/*     */     
/* 184 */     return distMap;
/*     */   }
/*     */ 
/*     */   
/*     */   private void forwardScan(FloatProcessor distMap, ImageProcessor labelImage) {
/* 189 */     fireStatusChanged(new AlgoEvent(this, "Forward Scan"));
/*     */ 
/*     */     
/* 192 */     int[] dx = { -1, 1, -1 };
/* 193 */     int[] dy = { -1, -1, -1 };
/* 194 */     float[] dw = { this.weights[1], this.weights[0], this.weights[1], this.weights[0] };
/*     */ 
/*     */     
/* 197 */     int sizeX = labelImage.getWidth();
/* 198 */     int sizeY = labelImage.getHeight();
/*     */ 
/*     */     
/* 201 */     for (int y = 0; y < sizeY; y++) {
/*     */       
/* 203 */       fireProgressChanged(this, y, sizeY);
/* 204 */       for (int x = 0; x < sizeX; x++) {
/*     */ 
/*     */         
/* 207 */         int label = (int)labelImage.getf(x, y);
/*     */ 
/*     */         
/* 210 */         if (label != 0) {
/*     */ 
/*     */ 
/*     */           
/* 214 */           float currentDist = distMap.getf(x, y);
/* 215 */           float newDist = currentDist;
/*     */ 
/*     */           
/* 218 */           for (int i = 0; i < dx.length; i++) {
/*     */ 
/*     */             
/* 221 */             int x2 = x + dx[i];
/* 222 */             int y2 = y + dy[i];
/*     */ 
/*     */             
/* 225 */             if (x2 >= 0 && x2 < sizeX)
/*     */             {
/* 227 */               if (y2 >= 0 && y2 < sizeY)
/*     */               {
/*     */                 
/* 230 */                 if ((int)labelImage.getf(x2, y2) != label) {
/*     */ 
/*     */                   
/* 233 */                   newDist = Math.min(newDist, dw[i]);
/*     */                 
/*     */                 }
/*     */                 else {
/*     */                   
/* 238 */                   newDist = Math.min(newDist, distMap.getf(x2, y2) + dw[i]);
/*     */                 }  } 
/*     */             }
/*     */           } 
/* 242 */           if (newDist < currentDist)
/*     */           {
/* 244 */             distMap.setf(x, y, newDist);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/* 249 */     fireProgressChanged(this, sizeY, sizeY);
/*     */   }
/*     */ 
/*     */   
/*     */   private void backwardScan(FloatProcessor distMap, ImageProcessor labelImage) {
/* 254 */     fireStatusChanged(new AlgoEvent(this, "Backward Scan"));
/*     */ 
/*     */     
/* 257 */     int[] dx = { 1, -1, 1 };
/* 258 */     int[] dy = { 1, 1, 1 };
/* 259 */     float[] dw = { this.weights[1], this.weights[0], this.weights[1], this.weights[0] };
/*     */ 
/*     */     
/* 262 */     int sizeX = labelImage.getWidth();
/* 263 */     int sizeY = labelImage.getHeight();
/*     */ 
/*     */     
/* 266 */     for (int y = sizeY - 1; y >= 0; y--) {
/*     */       
/* 268 */       fireProgressChanged(this, (sizeY - 1 - y), sizeY);
/* 269 */       for (int x = sizeX - 1; x >= 0; x--) {
/*     */ 
/*     */         
/* 272 */         int label = (int)labelImage.getf(x, y);
/*     */ 
/*     */         
/* 275 */         if (label != 0) {
/*     */ 
/*     */ 
/*     */           
/* 279 */           float currentDist = distMap.getf(x, y);
/* 280 */           float newDist = currentDist;
/*     */ 
/*     */           
/* 283 */           for (int i = 0; i < dx.length; i++) {
/*     */ 
/*     */             
/* 286 */             int x2 = x + dx[i];
/* 287 */             int y2 = y + dy[i];
/*     */ 
/*     */             
/* 290 */             if (x2 >= 0 && x2 < sizeX)
/*     */             {
/* 292 */               if (y2 >= 0 && y2 < sizeY)
/*     */               {
/*     */                 
/* 295 */                 if ((int)labelImage.getf(x2, y2) != label) {
/*     */ 
/*     */                   
/* 298 */                   newDist = Math.min(newDist, dw[i]);
/*     */                 
/*     */                 }
/*     */                 else {
/*     */                   
/* 303 */                   newDist = Math.min(newDist, distMap.getf(x2, y2) + dw[i]);
/*     */                 }  } 
/*     */             }
/*     */           } 
/* 307 */           if (newDist < currentDist)
/*     */           {
/* 309 */             distMap.setf(x, y, newDist);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/* 314 */     fireProgressChanged(this, sizeY, sizeY);
/*     */   }
/*     */ 
/*     */   
/*     */   private void normalizeResult(FloatProcessor distMap, ImageProcessor labelImage) {
/* 319 */     fireStatusChanged(new AlgoEvent(this, "Normalization"));
/*     */ 
/*     */     
/* 322 */     int sizeX = labelImage.getWidth();
/* 323 */     int sizeY = labelImage.getHeight();
/*     */ 
/*     */     
/* 326 */     float w0 = this.weights[0];
/*     */     
/* 328 */     for (int y = 0; y < sizeY; y++) {
/*     */       
/* 330 */       for (int x = 0; x < sizeX; x++) {
/*     */         
/* 332 */         if ((int)labelImage.getf(x, y) > 0)
/*     */         {
/* 334 */           distMap.setf(x, y, distMap.getf(x, y) / w0);
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/binary/distmap/DistanceTransform3x3Float.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */