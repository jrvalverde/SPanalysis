/*     */ package inra.ijpb.binary.distmap;
/*     */ 
/*     */ import ij.process.ImageProcessor;
/*     */ import ij.process.ShortProcessor;
/*     */ import inra.ijpb.algo.AlgoEvent;
/*     */ import inra.ijpb.algo.AlgoStub;
/*     */ import inra.ijpb.binary.ChamferWeights;
/*     */ import inra.ijpb.label.LabelValues;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DistanceTransform5x5Short
/*     */   extends AlgoStub
/*     */   implements DistanceTransform
/*     */ {
/*     */   private short[] weights;
/*     */   private boolean normalizeMap = true;
/*     */   
/*     */   public DistanceTransform5x5Short() {
/*  83 */     this(new short[] { 5, 7, 11 }, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DistanceTransform5x5Short(ChamferWeights weights) {
/*  95 */     this(weights.getShortWeights(), true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DistanceTransform5x5Short(short[] weights) {
/* 104 */     this(weights, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DistanceTransform5x5Short(ChamferWeights weights, boolean normalize) {
/* 119 */     this(weights.getShortWeights(), normalize);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DistanceTransform5x5Short(short[] weights, boolean normalize) {
/* 132 */     if (weights.length < 3) {
/*     */       
/* 134 */       short[] newWeights = new short[3];
/* 135 */       newWeights[0] = weights[0];
/* 136 */       newWeights[1] = weights[1];
/* 137 */       newWeights[2] = (short)(weights[0] + weights[1]);
/* 138 */       weights = newWeights;
/*     */     } 
/* 140 */     this.weights = weights;
/* 141 */     this.normalizeMap = normalize;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ShortProcessor distanceMap(ImageProcessor labelImage) {
/* 163 */     ShortProcessor distMap = initializeResult(labelImage);
/*     */ 
/*     */     
/* 166 */     forwardScan(distMap, labelImage);
/* 167 */     backwardScan(distMap, labelImage);
/*     */ 
/*     */     
/* 170 */     if (this.normalizeMap)
/*     */     {
/* 172 */       normalizeResult(distMap, labelImage);
/*     */     }
/*     */ 
/*     */     
/* 176 */     double maxVal = LabelValues.maxValueWithinLabels((ImageProcessor)distMap, labelImage);
/* 177 */     distMap.setMinAndMax(0.0D, maxVal);
/*     */ 
/*     */     
/* 180 */     if (distMap.isInvertedLut()) {
/* 181 */       distMap.invertLut();
/*     */     }
/* 183 */     fireStatusChanged(new AlgoEvent(this, ""));
/*     */     
/* 185 */     return distMap;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ShortProcessor initializeResult(ImageProcessor labelImage) {
/* 194 */     fireStatusChanged(new AlgoEvent(this, "Initialization"));
/*     */ 
/*     */     
/* 197 */     int sizeX = labelImage.getWidth();
/* 198 */     int sizeY = labelImage.getHeight();
/*     */ 
/*     */     
/* 201 */     ShortProcessor distMap = new ShortProcessor(sizeX, sizeY);
/* 202 */     distMap.setValue(0.0D);
/* 203 */     distMap.fill();
/*     */ 
/*     */     
/* 206 */     for (int y = 0; y < sizeY; y++) {
/*     */       
/* 208 */       for (int x = 0; x < sizeX; x++) {
/*     */         
/* 210 */         int label = (int)labelImage.getf(x, y);
/* 211 */         distMap.set(x, y, (label == 0) ? 0 : 32767);
/*     */       } 
/*     */     } 
/*     */     
/* 215 */     return distMap;
/*     */   }
/*     */ 
/*     */   
/*     */   private void forwardScan(ShortProcessor distMap, ImageProcessor labelImage) {
/* 220 */     fireStatusChanged(new AlgoEvent(this, "Forward Scan"));
/*     */ 
/*     */     
/* 223 */     int[] dx = { -1, 1, -2, -1, 1, 2, -1 };
/* 224 */     int[] dy = { -2, -2, -1, -1, -1, -1, -1 };
/* 225 */     short[] dw = {
/* 226 */         this.weights[2], this.weights[2], 
/* 227 */         this.weights[2], this.weights[1], this.weights[0], this.weights[1], this.weights[2], 
/* 228 */         this.weights[0]
/*     */       };
/*     */     
/* 231 */     int sizeX = labelImage.getWidth();
/* 232 */     int sizeY = labelImage.getHeight();
/*     */ 
/*     */     
/* 235 */     for (int y = 0; y < sizeY; y++) {
/*     */       
/* 237 */       fireProgressChanged(this, y, sizeY);
/* 238 */       for (int x = 0; x < sizeX; x++) {
/*     */ 
/*     */         
/* 241 */         int label = (int)labelImage.getf(x, y);
/*     */ 
/*     */         
/* 244 */         if (label != 0) {
/*     */ 
/*     */ 
/*     */           
/* 248 */           int currentDist = distMap.get(x, y);
/* 249 */           int newDist = currentDist;
/*     */ 
/*     */           
/* 252 */           for (int i = 0; i < dx.length; i++) {
/*     */ 
/*     */             
/* 255 */             int x2 = x + dx[i];
/* 256 */             int y2 = y + dy[i];
/*     */ 
/*     */             
/* 259 */             if (x2 >= 0 && x2 < sizeX)
/*     */             {
/* 261 */               if (y2 >= 0 && y2 < sizeY)
/*     */               {
/*     */                 
/* 264 */                 if ((int)labelImage.getf(x2, y2) != label) {
/*     */ 
/*     */                   
/* 267 */                   newDist = Math.min(newDist, dw[i]);
/*     */                 
/*     */                 }
/*     */                 else {
/*     */                   
/* 272 */                   newDist = Math.min(newDist, distMap.get(x2, y2) + dw[i]);
/*     */                 }  } 
/*     */             }
/*     */           } 
/* 276 */           if (newDist < currentDist)
/*     */           {
/* 278 */             distMap.set(x, y, newDist);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/* 283 */     fireProgressChanged(this, sizeY, sizeY);
/*     */   }
/*     */ 
/*     */   
/*     */   private void backwardScan(ShortProcessor distMap, ImageProcessor labelImage) {
/* 288 */     fireStatusChanged(new AlgoEvent(this, "Backward Scan"));
/*     */ 
/*     */     
/* 291 */     int[] dx = { 1, -1, 2, 1, -1, -2, 1 };
/* 292 */     int[] dy = { 2, 2, 1, 1, 1, 1, 1 };
/* 293 */     short[] dw = {
/* 294 */         this.weights[2], this.weights[2], 
/* 295 */         this.weights[2], this.weights[1], this.weights[0], this.weights[1], this.weights[2], 
/* 296 */         this.weights[0]
/*     */       };
/*     */     
/* 299 */     int sizeX = labelImage.getWidth();
/* 300 */     int sizeY = labelImage.getHeight();
/*     */ 
/*     */     
/* 303 */     for (int y = sizeY - 1; y >= 0; y--) {
/*     */       
/* 305 */       fireProgressChanged(this, (sizeY - 1 - y), sizeY);
/* 306 */       for (int x = sizeX - 1; x >= 0; x--) {
/*     */ 
/*     */         
/* 309 */         int label = (int)labelImage.getf(x, y);
/*     */ 
/*     */         
/* 312 */         if (label != 0) {
/*     */ 
/*     */ 
/*     */           
/* 316 */           int currentDist = distMap.get(x, y);
/* 317 */           int newDist = currentDist;
/*     */ 
/*     */           
/* 320 */           for (int i = 0; i < dx.length; i++) {
/*     */ 
/*     */             
/* 323 */             int x2 = x + dx[i];
/* 324 */             int y2 = y + dy[i];
/*     */ 
/*     */             
/* 327 */             if (x2 >= 0 && x2 < sizeX)
/*     */             {
/* 329 */               if (y2 >= 0 && y2 < sizeY)
/*     */               {
/*     */                 
/* 332 */                 if ((int)labelImage.getf(x2, y2) != label) {
/*     */ 
/*     */                   
/* 335 */                   newDist = Math.min(newDist, dw[i]);
/*     */                 
/*     */                 }
/*     */                 else {
/*     */                   
/* 340 */                   newDist = Math.min(newDist, distMap.get(x2, y2) + dw[i]);
/*     */                 }  } 
/*     */             }
/*     */           } 
/* 344 */           if (newDist < currentDist)
/*     */           {
/* 346 */             distMap.set(x, y, newDist);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/* 351 */     fireProgressChanged(this, sizeY, sizeY);
/*     */   }
/*     */ 
/*     */   
/*     */   private void normalizeResult(ShortProcessor distMap, ImageProcessor labelImage) {
/* 356 */     fireStatusChanged(new AlgoEvent(this, "Normalization"));
/*     */ 
/*     */     
/* 359 */     int sizeX = labelImage.getWidth();
/* 360 */     int sizeY = labelImage.getHeight();
/*     */ 
/*     */     
/* 363 */     int w0 = this.weights[0];
/*     */     
/* 365 */     for (int y = 0; y < sizeY; y++) {
/*     */       
/* 367 */       for (int x = 0; x < sizeX; x++) {
/*     */         
/* 369 */         if ((int)labelImage.getf(x, y) > 0)
/*     */         {
/* 371 */           distMap.set(x, y, distMap.get(x, y) / w0);
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/binary/distmap/DistanceTransform5x5Short.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */