/*     */ package inra.ijpb.binary.geodesic;
/*     */ 
/*     */ import ij.process.ImageProcessor;
/*     */ import ij.process.ShortProcessor;
/*     */ import inra.ijpb.algo.AlgoStub;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GeodesicDistanceTransformShort
/*     */   extends AlgoStub
/*     */   implements GeodesicDistanceTransform
/*     */ {
/*     */   public static final short MAX_DIST = 32767;
/*  47 */   short[] weights = new short[] { 5, 7, 11 };
/*     */ 
/*     */ 
/*     */   
/*     */   boolean normalizeMap = true;
/*     */ 
/*     */ 
/*     */   
/*     */   int sizeX;
/*     */ 
/*     */ 
/*     */   
/*     */   int sizeY;
/*     */ 
/*     */   
/*     */   ImageProcessor labelImage;
/*     */ 
/*     */   
/*     */   ImageProcessor distMap;
/*     */ 
/*     */   
/*     */   boolean modif;
/*     */ 
/*     */ 
/*     */   
/*     */   public GeodesicDistanceTransformShort(short[] weights) {
/*  73 */     this.weights = weights;
/*     */   }
/*     */ 
/*     */   
/*     */   public GeodesicDistanceTransformShort(short[] weights, boolean normalizeMap) {
/*  78 */     this.weights = weights;
/*  79 */     this.normalizeMap = normalizeMap;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ImageProcessor geodesicDistanceMap(ImageProcessor marker, ImageProcessor mask) {
/* 106 */     this.sizeX = mask.getWidth();
/* 107 */     this.sizeY = mask.getHeight();
/*     */ 
/*     */     
/* 110 */     this.labelImage = mask;
/*     */ 
/*     */     
/* 113 */     fireStatusChanged(this, "Initialization...");
/* 114 */     this.distMap = (ImageProcessor)initialize(marker);
/*     */     
/* 116 */     int iter = 0;
/* 117 */     this.modif = true;
/* 118 */     while (this.modif) {
/*     */       
/* 120 */       this.modif = false;
/*     */ 
/*     */       
/* 123 */       fireStatusChanged(this, "Forward iteration " + iter);
/* 124 */       forwardIteration();
/*     */ 
/*     */       
/* 127 */       fireStatusChanged(this, "Backward iteration " + iter);
/* 128 */       backwardIteration();
/*     */ 
/*     */       
/* 131 */       iter++;
/*     */     } 
/*     */ 
/*     */     
/* 135 */     if (this.normalizeMap) {
/*     */       
/* 137 */       fireStatusChanged(this, "Normalize map");
/* 138 */       for (int j = 0; j < this.sizeY; j++) {
/*     */         
/* 140 */         for (int k = 0; k < this.sizeX; k++) {
/*     */           
/* 142 */           short val = (short)this.distMap.get(k, j);
/* 143 */           if (val != Short.MAX_VALUE)
/*     */           {
/* 145 */             this.distMap.set(k, j, val / this.weights[0]);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 152 */     fireStatusChanged(this, "Normalize display");
/* 153 */     float maxVal = 0.0F;
/* 154 */     for (int i = 0; i < this.sizeX; i++) {
/*     */       
/* 156 */       for (int j = 0; j < this.sizeY; j++) {
/*     */         
/* 158 */         short val = (short)this.distMap.get(i, j);
/* 159 */         if (val != Short.MAX_VALUE)
/*     */         {
/* 161 */           maxVal = Math.max(maxVal, val);
/*     */         }
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 168 */     this.distMap.setMinAndMax(0.0D, maxVal);
/*     */     
/* 170 */     if (this.distMap.isInvertedLut())
/*     */     {
/* 172 */       this.distMap.invertLut();
/*     */     }
/*     */     
/* 175 */     return this.distMap;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private ShortProcessor initialize(ImageProcessor marker) {
/* 181 */     this.sizeX = marker.getWidth();
/* 182 */     this.sizeY = marker.getHeight();
/*     */     
/* 184 */     ShortProcessor distMap = new ShortProcessor(this.sizeX, this.sizeY);
/* 185 */     distMap.setValue(0.0D);
/* 186 */     distMap.fill();
/*     */ 
/*     */     
/* 189 */     for (int y = 0; y < this.sizeY; y++) {
/*     */       
/* 191 */       for (int x = 0; x < this.sizeX; x++) {
/*     */         
/* 193 */         int val = marker.get(x, y) & 0xFF;
/* 194 */         distMap.set(x, y, (val == 0) ? 32767 : 0);
/*     */       } 
/*     */     } 
/*     */     
/* 198 */     return distMap;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void forwardIteration() {
/* 204 */     int[] dx = { -1, 1, -1 };
/* 205 */     int[] dy = { -1, -1, -1 };
/*     */     
/* 207 */     short[] dw = {
/* 208 */         this.weights[1], this.weights[0], this.weights[1], 
/* 209 */         this.weights[0]
/*     */       };
/*     */     
/* 212 */     for (int y = 0; y < this.sizeY; y++) {
/*     */       
/* 214 */       fireProgressChanged(this, y, this.sizeY);
/* 215 */       for (int x = 0; x < this.sizeX; x++) {
/*     */ 
/*     */         
/* 218 */         int label = (int)this.labelImage.getf(x, y);
/*     */ 
/*     */         
/* 221 */         if (label != 0) {
/*     */ 
/*     */ 
/*     */           
/* 225 */           int currentDist = this.distMap.get(x, y);
/* 226 */           int newDist = currentDist;
/*     */ 
/*     */           
/* 229 */           for (int i = 0; i < dx.length; i++) {
/*     */ 
/*     */             
/* 232 */             int x2 = x + dx[i];
/* 233 */             int y2 = y + dy[i];
/*     */ 
/*     */             
/* 236 */             if (x2 >= 0 && x2 < this.sizeX)
/*     */             {
/* 238 */               if (y2 >= 0 && y2 < this.sizeY)
/*     */               {
/*     */                 
/* 241 */                 if ((int)this.labelImage.getf(x2, y2) == label)
/*     */                 {
/*     */                   
/* 244 */                   newDist = Math.min(newDist, this.distMap.get(x2, y2) + dw[i]); } 
/*     */               }
/*     */             }
/*     */           } 
/* 248 */           if (newDist < currentDist) {
/*     */             
/* 250 */             this.distMap.set(x, y, newDist);
/* 251 */             this.modif = true;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/* 256 */     fireProgressChanged(this, this.sizeY, this.sizeY);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void backwardIteration() {
/* 262 */     int[] dx = { 1, -1, 1 };
/* 263 */     int[] dy = { 1, 1, 1 };
/*     */     
/* 265 */     short[] dw = {
/* 266 */         this.weights[1], this.weights[0], this.weights[1], 
/* 267 */         this.weights[0]
/*     */       };
/*     */     
/* 270 */     for (int y = this.sizeY - 1; y >= 0; y--) {
/*     */       
/* 272 */       fireProgressChanged(this, (this.sizeY - 1 - y), this.sizeY);
/* 273 */       for (int x = this.sizeX - 1; x >= 0; x--) {
/*     */ 
/*     */         
/* 276 */         int label = (int)this.labelImage.getf(x, y);
/*     */ 
/*     */         
/* 279 */         if (label != 0) {
/*     */ 
/*     */ 
/*     */           
/* 283 */           int currentDist = this.distMap.get(x, y);
/* 284 */           int newDist = currentDist;
/*     */ 
/*     */           
/* 287 */           for (int i = 0; i < dx.length; i++) {
/*     */ 
/*     */             
/* 290 */             int x2 = x + dx[i];
/* 291 */             int y2 = y + dy[i];
/*     */ 
/*     */             
/* 294 */             if (x2 >= 0 && x2 < this.sizeX)
/*     */             {
/* 296 */               if (y2 >= 0 && y2 < this.sizeY)
/*     */               {
/*     */                 
/* 299 */                 if ((int)this.labelImage.getf(x2, y2) == label)
/*     */                 {
/*     */                   
/* 302 */                   newDist = Math.min(newDist, this.distMap.get(x2, y2) + dw[i]); } 
/*     */               }
/*     */             }
/*     */           } 
/* 306 */           if (newDist < currentDist) {
/*     */             
/* 308 */             this.distMap.set(x, y, newDist);
/* 309 */             this.modif = true;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/* 314 */     fireProgressChanged(this, this.sizeY, this.sizeY);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/binary/geodesic/GeodesicDistanceTransformShort.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */