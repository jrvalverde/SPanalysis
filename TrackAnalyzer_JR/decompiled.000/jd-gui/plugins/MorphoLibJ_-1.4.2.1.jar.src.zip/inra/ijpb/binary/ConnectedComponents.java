/*     */ package inra.ijpb.binary;
/*     */ 
/*     */ import ij.IJ;
/*     */ import ij.ImagePlus;
/*     */ import ij.ImageStack;
/*     */ import ij.process.ByteProcessor;
/*     */ import ij.process.FloatProcessor;
/*     */ import ij.process.ImageProcessor;
/*     */ import ij.process.ShortProcessor;
/*     */ import inra.ijpb.morphology.FloodFill;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public class ConnectedComponents
/*     */ {
/*     */   @Deprecated
/*     */   public static final ImagePlus computeLabels(ImagePlus imagePlus, int conn, int bitDepth) {
/*     */     ImagePlus labelPlus;
/*     */     int nLabels;
/*  60 */     if (imagePlus.getStackSize() == 1) {
/*     */       
/*  62 */       ImageProcessor labels = computeLabels(imagePlus.getProcessor(), 
/*  63 */           conn, bitDepth);
/*  64 */       labelPlus = new ImagePlus("Labels", labels);
/*  65 */       nLabels = findMax(labels);
/*     */     } else {
/*     */       
/*  68 */       ImageStack labels = computeLabels(imagePlus.getStack(), conn, 
/*  69 */           bitDepth);
/*  70 */       labelPlus = new ImagePlus("Labels", labels);
/*  71 */       nLabels = findMax(labels);
/*     */     } 
/*     */     
/*  74 */     labelPlus.setDisplayRange(0.0D, nLabels);
/*  75 */     return labelPlus;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static final ImageProcessor computeLabels(ImageProcessor image, int conn, int bitDepth) {
/*     */     ByteProcessor byteProcessor;
/*     */     ShortProcessor shortProcessor;
/*     */     FloatProcessor floatProcessor;
/*  94 */     int width = image.getWidth();
/*  95 */     int height = image.getHeight();
/*     */ 
/*     */     
/*  98 */     switch (bitDepth) { case 8:
/*  99 */         byteProcessor = new ByteProcessor(width, height); break;
/* 100 */       case 16: shortProcessor = new ShortProcessor(width, height); break;
/* 101 */       case 32: floatProcessor = new FloatProcessor(width, height); break;
/* 102 */       default: throw new IllegalArgumentException("Bit Depth should be 8, 16 or 32."); }
/*     */ 
/*     */ 
/*     */     
/* 106 */     int nLabels = 0;
/*     */ 
/*     */     
/* 109 */     for (int y = 0; y < height; y++) {
/*     */       
/* 111 */       IJ.showProgress(y, height);
/* 112 */       for (int x = 0; x < width; x++) {
/*     */         
/* 114 */         if (image.get(x, y) != 0)
/*     */         {
/* 116 */           if (floatProcessor.get(x, y) <= 0) {
/*     */ 
/*     */             
/* 119 */             nLabels++;
/* 120 */             FloodFill.floodFillFloat(image, x, y, (ImageProcessor)floatProcessor, nLabels, conn);
/*     */           }  } 
/*     */       } 
/* 123 */     }  IJ.showProgress(1.0D);
/*     */     
/* 125 */     floatProcessor.setMinAndMax(0.0D, nLabels);
/* 126 */     return (ImageProcessor)floatProcessor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static final ImageStack computeLabels(ImageStack image, int conn, int bitDepth) {
/* 144 */     if (Thread.currentThread().isInterrupted()) {
/* 145 */       return null;
/*     */     }
/*     */     
/* 148 */     int sizeX = image.getWidth();
/* 149 */     int sizeY = image.getHeight();
/* 150 */     int sizeZ = image.getSize();
/*     */     
/* 152 */     IJ.showStatus("Allocate Memory");
/* 153 */     ImageStack labels = ImageStack.create(sizeX, sizeY, sizeZ, bitDepth);
/*     */     
/* 155 */     int nLabels = 0;
/*     */     
/* 157 */     IJ.showStatus("Compute Labels...");
/* 158 */     for (int z = 0; z < sizeZ; z++) {
/*     */       
/* 160 */       IJ.showProgress(z, sizeZ);
/* 161 */       for (int y = 0; y < sizeY; y++) {
/*     */         
/* 163 */         for (int x = 0; x < sizeX; x++) {
/*     */ 
/*     */           
/* 166 */           if (image.getVoxel(x, y, z) != 0.0D)
/*     */           {
/*     */ 
/*     */             
/* 170 */             if (labels.getVoxel(x, y, z) <= 0.0D) {
/*     */ 
/*     */ 
/*     */               
/* 174 */               nLabels++;
/* 175 */               FloodFill.floodFillFloat(image, x, y, z, labels, nLabels, conn);
/*     */             }  } 
/*     */         } 
/*     */       } 
/* 179 */     }  IJ.showProgress(1.0D);
/* 180 */     return labels;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final int findMax(ImageProcessor image) {
/* 190 */     int sizeX = image.getWidth();
/* 191 */     int sizeY = image.getHeight();
/*     */ 
/*     */     
/* 194 */     int maxVal = 0;
/* 195 */     for (int y = 0; y < sizeY; y++) {
/*     */       
/* 197 */       IJ.showProgress(y, sizeY);
/* 198 */       for (int x = 0; x < sizeX; x++)
/*     */       {
/* 200 */         maxVal = Math.max(maxVal, image.get(x, y));
/*     */       }
/*     */     } 
/* 203 */     IJ.showProgress(1.0D);
/*     */     
/* 205 */     return maxVal;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final int findMax(ImageStack image) {
/* 215 */     int sizeX = image.getWidth();
/* 216 */     int sizeY = image.getHeight();
/* 217 */     int sizeZ = image.getSize();
/*     */ 
/*     */     
/* 220 */     int maxVal = 0;
/* 221 */     for (int z = 0; z < sizeZ; z++) {
/*     */       
/* 223 */       IJ.showProgress(z, sizeZ);
/* 224 */       for (int y = 0; y < sizeY; y++) {
/*     */         
/* 226 */         for (int x = 0; x < sizeX; x++)
/*     */         {
/* 228 */           maxVal = Math.max(maxVal, (int)image.getVoxel(x, y, z));
/*     */         }
/*     */       } 
/*     */     } 
/* 232 */     IJ.showProgress(1.0D);
/*     */     
/* 234 */     return maxVal;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/binary/ConnectedComponents.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */