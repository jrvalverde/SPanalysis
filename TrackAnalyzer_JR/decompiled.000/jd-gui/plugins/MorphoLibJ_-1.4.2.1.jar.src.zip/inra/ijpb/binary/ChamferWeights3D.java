/*     */ package inra.ijpb.binary;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public enum ChamferWeights3D
/*     */ {
/*  50 */   CHESSBOARD(
/*  51 */     "Chessboard (1,1,1)", new short[] { 1, 1, 1 }),
/*  52 */   CITY_BLOCK(
/*     */ 
/*     */ 
/*     */     
/*  56 */     "City-Block (1,2,3)", new short[] { 1, 2, 3 }),
/*  57 */   QUASI_EUCLIDEAN(
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  62 */     "Quasi-Euclidean (1,1.41,1.73)", 
/*  63 */     new short[] { 10, 14, 17
/*  64 */     }, new float[] { 1.0F, (float)Math.sqrt(2.0D), (float)Math.sqrt(3.0D) }),
/*  65 */   BORGEFORS(
/*     */ 
/*     */ 
/*     */     
/*  69 */     "Borgefors (3,4,5)", new short[] { 3, 4, 5
/*     */     }),
/*  71 */   WEIGHTS_3_4_5_7(
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  76 */     "Svensson <3,4,5,7>", new short[] { 3, 4, 5, 7 });
/*     */   
/*     */   private final String label;
/*     */   
/*     */   private final short[] shortWeights;
/*     */   private final float[] floatWeights;
/*     */   
/*     */   ChamferWeights3D(String label, short[] shortWeights) {
/*  84 */     this.label = label;
/*  85 */     this.shortWeights = shortWeights;
/*  86 */     this.floatWeights = new float[shortWeights.length];
/*  87 */     for (int i = 0; i < shortWeights.length; i++) {
/*  88 */       this.floatWeights[i] = shortWeights[i];
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   ChamferWeights3D(String label, short[] shortWeights, float[] floatWeights) {
/*  94 */     this.label = label;
/*  95 */     this.shortWeights = shortWeights;
/*  96 */     this.floatWeights = floatWeights;
/*     */   }
/*     */ 
/*     */   
/*     */   public short[] getShortWeights() {
/* 101 */     return this.shortWeights;
/*     */   }
/*     */ 
/*     */   
/*     */   public float[] getFloatWeights() {
/* 106 */     return this.floatWeights;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 111 */     return this.label;
/*     */   }
/*     */ 
/*     */   
/*     */   public static String[] getAllLabels() {
/* 116 */     int n = (values()).length;
/* 117 */     String[] result = new String[n];
/*     */     
/* 119 */     int i = 0; byte b; int j; ChamferWeights3D[] arrayOfChamferWeights3D;
/* 120 */     for (j = (arrayOfChamferWeights3D = values()).length, b = 0; b < j; ) { ChamferWeights3D weight = arrayOfChamferWeights3D[b];
/* 121 */       result[i++] = weight.label; b++; }
/*     */     
/* 123 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ChamferWeights3D fromLabel(String label) {
/* 137 */     if (label != null)
/* 138 */       label = label.toLowerCase();  byte b; int i; ChamferWeights3D[] arrayOfChamferWeights3D;
/* 139 */     for (i = (arrayOfChamferWeights3D = values()).length, b = 0; b < i; ) { ChamferWeights3D weight = arrayOfChamferWeights3D[b];
/*     */       
/* 141 */       String cmp = weight.label.toLowerCase();
/* 142 */       if (cmp.equals(label))
/* 143 */         return weight;  b++; }
/*     */     
/* 145 */     throw new IllegalArgumentException(
/* 146 */         "Unable to parse ChamferWeights3D with label: " + label);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/binary/ChamferWeights3D.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */