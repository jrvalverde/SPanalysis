/*     */ package inra.ijpb.binary.distmap;
/*     */ 
/*     */ import ij.ImageStack;
/*     */ import inra.ijpb.algo.AlgoStub;
/*     */ import inra.ijpb.binary.ChamferWeights3D;
/*     */ import inra.ijpb.data.image.Images3D;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DistanceTransform3DShort
/*     */   extends AlgoStub
/*     */   implements DistanceTransform3D
/*     */ {
/*     */   private short[] weights;
/*     */   private boolean normalizeMap = true;
/*     */   private int sizeX;
/*     */   private int sizeY;
/*     */   private int sizeZ;
/*     */   private byte[][] maskSlices;
/*     */   private short[][] resultSlices;
/*     */   
/*     */   public DistanceTransform3DShort(ChamferWeights3D weights) {
/*  79 */     this(weights.getShortWeights());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DistanceTransform3DShort(short[] weights) {
/*  88 */     this.weights = weights;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DistanceTransform3DShort(ChamferWeights3D weights, boolean normalize) {
/* 101 */     this(weights.getShortWeights(), normalize);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DistanceTransform3DShort(short[] weights, boolean normalize) {
/* 114 */     this.weights = weights;
/* 115 */     this.normalizeMap = normalize;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ImageStack distanceMap(ImageStack image) {
/* 136 */     this.sizeX = image.getWidth();
/* 137 */     this.sizeY = image.getHeight();
/* 138 */     this.sizeZ = image.getSize();
/*     */ 
/*     */     
/* 141 */     this.maskSlices = Images3D.getByteArrays(image);
/*     */ 
/*     */     
/* 144 */     ImageStack buffer = ImageStack.create(this.sizeX, this.sizeY, this.sizeZ, 16);
/* 145 */     this.resultSlices = Images3D.getShortArrays(buffer);
/*     */ 
/*     */     
/* 148 */     initializeResultSlices();
/*     */ 
/*     */     
/* 151 */     forwardScan();
/* 152 */     backwardScan();
/*     */ 
/*     */     
/* 155 */     if (this.normalizeMap)
/*     */     {
/* 157 */       normalizeResultSlices();
/*     */     }
/*     */     
/* 160 */     fireStatusChanged(this, "");
/* 161 */     return buffer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void initializeResultSlices() {
/* 174 */     fireStatusChanged(this, "Initialization...");
/*     */ 
/*     */     
/* 177 */     for (int z = 0; z < this.sizeZ; z++) {
/*     */       
/* 179 */       fireProgressChanged(this, z, this.sizeZ);
/*     */       
/* 181 */       byte[] maskSlice = this.maskSlices[z];
/* 182 */       short[] resultSlice = this.resultSlices[z];
/*     */       
/* 184 */       for (int y = 0; y < this.sizeY; y++) {
/*     */         
/* 186 */         for (int x = 0; x < this.sizeX; x++) {
/*     */           
/* 188 */           int index = this.sizeX * y + x;
/* 189 */           int val = maskSlice[index];
/* 190 */           resultSlice[index] = (val == 0) ? 0 : Short.MAX_VALUE;
/*     */         } 
/*     */       } 
/*     */     } 
/* 194 */     fireProgressChanged(this, 1.0D, 1.0D);
/*     */   }
/*     */ 
/*     */   
/*     */   private void forwardScan() {
/* 199 */     fireStatusChanged(this, "Forward scan...");
/*     */     
/* 201 */     for (int z = 0; z < this.sizeZ; z++) {
/*     */       
/* 203 */       fireProgressChanged(this, z, this.sizeZ);
/*     */       
/* 205 */       byte[] maskSlice = this.maskSlices[z];
/* 206 */       short[] resultSlice = this.resultSlices[z];
/*     */       
/* 208 */       short[] resultSlice2 = null;
/* 209 */       if (z > 0)
/*     */       {
/* 211 */         resultSlice2 = this.resultSlices[z - 1];
/*     */       }
/*     */       
/* 214 */       for (int y = 0; y < this.sizeY; y++) {
/*     */         
/* 216 */         for (int x = 0; x < this.sizeX; x++) {
/*     */           
/* 218 */           int index = this.sizeX * y + x;
/*     */ 
/*     */           
/* 221 */           if ((maskSlice[index] & 0xFF) != 0) {
/*     */ 
/*     */ 
/*     */             
/* 225 */             int ortho = 32767;
/* 226 */             int diago = 32767;
/* 227 */             int diag3 = 32767;
/*     */ 
/*     */             
/* 230 */             if (z > 0) {
/*     */               
/* 232 */               if (y > 0) {
/*     */ 
/*     */                 
/* 235 */                 if (x > 0)
/*     */                 {
/* 237 */                   diag3 = Math.min(diag3, resultSlice2[this.sizeX * (y - 1) + x - 1] & 0xFFFF);
/*     */                 }
/* 239 */                 diago = Math.min(diago, resultSlice2[this.sizeX * (y - 1) + x] & 0xFFFF);
/* 240 */                 if (x < this.sizeX - 1)
/*     */                 {
/* 242 */                   diag3 = Math.min(diag3, resultSlice2[this.sizeX * (y - 1) + x + 1] & 0xFFFF);
/*     */                 }
/*     */               } 
/*     */ 
/*     */               
/* 247 */               if (x > 0)
/*     */               {
/* 249 */                 diago = Math.min(diago, resultSlice2[this.sizeX * y + x - 1] & 0xFFFF);
/*     */               }
/* 251 */               ortho = Math.min(ortho, resultSlice2[this.sizeX * y + x] & 0xFFFF);
/* 252 */               if (x < this.sizeX - 1)
/*     */               {
/* 254 */                 diago = Math.min(diago, resultSlice2[this.sizeX * y + x + 1] & 0xFFFF);
/*     */               }
/*     */               
/* 257 */               if (y < this.sizeY - 1) {
/*     */ 
/*     */                 
/* 260 */                 if (x > 0)
/*     */                 {
/* 262 */                   diag3 = Math.min(diag3, resultSlice2[this.sizeX * (y + 1) + x - 1] & 0xFFFF);
/*     */                 }
/* 264 */                 diago = Math.min(diago, resultSlice2[this.sizeX * (y + 1) + x] & 0xFFFF);
/* 265 */                 if (x < this.sizeX - 1)
/*     */                 {
/* 267 */                   diag3 = Math.min(diag3, resultSlice2[this.sizeX * (y + 1) + x + 1] & 0xFFFF);
/*     */                 }
/*     */               } 
/*     */             } 
/*     */ 
/*     */             
/* 273 */             if (y > 0) {
/*     */               
/* 275 */               if (x > 0)
/*     */               {
/* 277 */                 diago = Math.min(diago, resultSlice[this.sizeX * (y - 1) + x - 1] & 0xFFFF);
/*     */               }
/* 279 */               ortho = Math.min(ortho, resultSlice[this.sizeX * (y - 1) + x] & 0xFFFF);
/* 280 */               if (x < this.sizeX - 1)
/*     */               {
/* 282 */                 diago = Math.min(diago, resultSlice[this.sizeX * (y - 1) + x + 1] & 0xFFFF);
/*     */               }
/*     */             } 
/*     */ 
/*     */             
/* 287 */             if (x > 0)
/*     */             {
/* 289 */               ortho = Math.min(ortho, resultSlice[this.sizeX * y + x - 1] & 0xFFFF);
/*     */             }
/*     */             
/* 292 */             int newVal = min3w(ortho, diago, diag3);
/* 293 */             updateIfNeeded(x, y, z, newVal);
/*     */           } 
/*     */         } 
/*     */       } 
/* 297 */     }  fireProgressChanged(this, 1.0D, 1.0D);
/*     */   }
/*     */ 
/*     */   
/*     */   private void backwardScan() {
/* 302 */     fireStatusChanged(this, "Backward scan...");
/*     */     
/* 304 */     for (int z = this.sizeZ - 1; z >= 0; z--) {
/*     */       
/* 306 */       fireProgressChanged(this, (this.sizeZ - 1 - z), this.sizeZ);
/*     */       
/* 308 */       byte[] maskSlice = this.maskSlices[z];
/* 309 */       short[] resultSlice = this.resultSlices[z];
/*     */       
/* 311 */       short[] resultSlice2 = null;
/* 312 */       if (z < this.sizeZ - 1)
/*     */       {
/* 314 */         resultSlice2 = this.resultSlices[z + 1];
/*     */       }
/*     */       
/* 317 */       for (int y = this.sizeY - 1; y >= 0; y--) {
/*     */         
/* 319 */         for (int x = this.sizeX - 1; x >= 0; x--) {
/*     */           
/* 321 */           int index = this.sizeX * y + x;
/*     */ 
/*     */           
/* 324 */           if ((maskSlice[index] & 0xFF) != 0) {
/*     */ 
/*     */ 
/*     */             
/* 328 */             int ortho = 32767;
/* 329 */             int diago = 32767;
/* 330 */             int diag3 = 32767;
/*     */ 
/*     */             
/* 333 */             if (z < this.sizeZ - 1) {
/*     */               
/* 335 */               if (y < this.sizeY - 1) {
/*     */ 
/*     */                 
/* 338 */                 if (x < this.sizeX - 1)
/*     */                 {
/* 340 */                   diag3 = Math.min(diag3, resultSlice2[this.sizeX * (y + 1) + x + 1] & 0xFFFF);
/*     */                 }
/* 342 */                 diago = Math.min(diago, resultSlice2[this.sizeX * (y + 1) + x] & 0xFFFF);
/* 343 */                 if (x > 0)
/*     */                 {
/* 345 */                   diag3 = Math.min(diag3, resultSlice2[this.sizeX * (y + 1) + x - 1] & 0xFFFF);
/*     */                 }
/*     */               } 
/*     */ 
/*     */               
/* 350 */               if (x < this.sizeX - 1)
/*     */               {
/* 352 */                 diago = Math.min(diago, resultSlice2[this.sizeX * y + x + 1] & 0xFFFF);
/*     */               }
/* 354 */               ortho = Math.min(ortho, resultSlice2[this.sizeX * y + x] & 0xFFFF);
/* 355 */               if (x > 0)
/*     */               {
/* 357 */                 diago = Math.min(diago, resultSlice2[this.sizeX * y + x - 1] & 0xFFFF);
/*     */               }
/*     */               
/* 360 */               if (y > 0) {
/*     */ 
/*     */                 
/* 363 */                 if (x < this.sizeX - 1)
/*     */                 {
/* 365 */                   diag3 = Math.min(diag3, resultSlice2[this.sizeX * (y - 1) + x + 1] & 0xFFFF);
/*     */                 }
/* 367 */                 diago = Math.min(diago, resultSlice2[this.sizeX * (y - 1) + x] & 0xFFFF);
/* 368 */                 if (x > 0)
/*     */                 {
/* 370 */                   diag3 = Math.min(diag3, resultSlice2[this.sizeX * (y - 1) + x - 1] & 0xFFFF);
/*     */                 }
/*     */               } 
/*     */             } 
/*     */ 
/*     */             
/* 376 */             if (y < this.sizeY - 1) {
/*     */               
/* 378 */               if (x < this.sizeX - 1)
/*     */               {
/* 380 */                 diago = Math.min(diago, resultSlice[this.sizeX * (y + 1) + x + 1] & 0xFFFF);
/*     */               }
/* 382 */               ortho = Math.min(ortho, resultSlice[this.sizeX * (y + 1) + x] & 0xFFFF);
/* 383 */               if (x > 0)
/*     */               {
/* 385 */                 diago = Math.min(diago, resultSlice[this.sizeX * (y + 1) + x - 1] & 0xFFFF);
/*     */               }
/*     */             } 
/*     */ 
/*     */             
/* 390 */             if (x < this.sizeX - 1)
/*     */             {
/* 392 */               ortho = Math.min(ortho, resultSlice[this.sizeX * y + x + 1] & 0xFFFF);
/*     */             }
/*     */             
/* 395 */             int newVal = min3w(ortho, diago, diag3);
/* 396 */             updateIfNeeded(x, y, z, newVal);
/*     */           } 
/*     */         } 
/*     */       } 
/* 400 */     }  fireProgressChanged(this, 1.0D, 1.0D);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int min3w(int ortho, int diago, int diag2) {
/* 409 */     return Math.min(Math.min(ortho + this.weights[0], diago + this.weights[1]), diag2 + this.weights[2]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void updateIfNeeded(int i, int j, int k, int newVal) {
/* 418 */     int index = j * this.sizeX + i;
/* 419 */     int value = this.resultSlices[k][index] & 0xFFFF;
/* 420 */     if (newVal < value)
/*     */     {
/* 422 */       this.resultSlices[k][index] = (short)newVal;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private void normalizeResultSlices() {
/* 428 */     fireStatusChanged(this, "Normalize map...");
/* 429 */     for (int z = 0; z < this.sizeZ; z++) {
/*     */       
/* 431 */       fireProgressChanged(this, z, this.sizeZ);
/*     */       
/* 433 */       byte[] maskSlice = this.maskSlices[z];
/* 434 */       short[] resultSlice = this.resultSlices[z];
/*     */       
/* 436 */       for (int y = 0; y < this.sizeY; y++) {
/*     */         
/* 438 */         for (int x = 0; x < this.sizeX; x++) {
/*     */           
/* 440 */           int index = this.sizeX * y + x;
/* 441 */           if (maskSlice[index] != 0)
/*     */           {
/* 443 */             resultSlice[index] = (short)((resultSlice[index] & 0xFFFF) / this.weights[0]);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/* 448 */     fireProgressChanged(this, 1.0D, 1.0D);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/binary/distmap/DistanceTransform3DShort.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */