/*     */ package inra.ijpb.binary.geodesic;
/*     */ 
/*     */ import ij.process.FloatProcessor;
/*     */ import ij.process.ImageProcessor;
/*     */ import inra.ijpb.algo.AlgoStub;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GeodesicDistanceTransformFloat
/*     */   extends AlgoStub
/*     */   implements GeodesicDistanceTransform
/*     */ {
/*     */   public static final float MAX_DIST = InfinityF;
/*  43 */   float[] weights = new float[] { 5.0F, 7.0F, 11.0F };
/*     */ 
/*     */ 
/*     */   
/*     */   boolean normalizeMap = true;
/*     */ 
/*     */ 
/*     */   
/*     */   int sizeX;
/*     */ 
/*     */ 
/*     */   
/*     */   int sizeY;
/*     */ 
/*     */   
/*     */   ImageProcessor labelImage;
/*     */ 
/*     */   
/*     */   ImageProcessor distMap;
/*     */ 
/*     */   
/*     */   boolean modif;
/*     */ 
/*     */ 
/*     */   
/*     */   public GeodesicDistanceTransformFloat(float[] weights) {
/*  69 */     this.weights = weights;
/*     */   }
/*     */ 
/*     */   
/*     */   public GeodesicDistanceTransformFloat(float[] weights, boolean normalizeMap) {
/*  74 */     this.weights = weights;
/*  75 */     this.normalizeMap = normalizeMap;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ImageProcessor geodesicDistanceMap(ImageProcessor marker, ImageProcessor mask) {
/* 102 */     this.sizeX = mask.getWidth();
/* 103 */     this.sizeY = mask.getHeight();
/*     */ 
/*     */     
/* 106 */     this.labelImage = mask;
/*     */ 
/*     */     
/* 109 */     fireStatusChanged(this, "Initialization...");
/* 110 */     this.distMap = (ImageProcessor)initialize(marker);
/*     */     
/* 112 */     int iter = 0;
/* 113 */     this.modif = true;
/* 114 */     while (this.modif) {
/*     */       
/* 116 */       this.modif = false;
/*     */ 
/*     */       
/* 119 */       fireStatusChanged(this, "Forward iteration " + iter);
/* 120 */       forwardIteration();
/*     */ 
/*     */       
/* 123 */       fireStatusChanged(this, "Backward iteration " + iter);
/* 124 */       backwardIteration();
/*     */ 
/*     */       
/* 127 */       iter++;
/*     */     } 
/*     */ 
/*     */     
/* 131 */     if (this.normalizeMap) {
/*     */       
/* 133 */       fireStatusChanged(this, "Normalize map");
/* 134 */       for (int j = 0; j < this.sizeY; j++) {
/*     */         
/* 136 */         for (int k = 0; k < this.sizeX; k++) {
/*     */           
/* 138 */           float val = this.distMap.getf(k, j);
/* 139 */           if (val != Float.POSITIVE_INFINITY)
/*     */           {
/* 141 */             this.distMap.setf(k, j, val / this.weights[0]);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 148 */     fireStatusChanged(this, "Normalize display");
/* 149 */     float maxVal = 0.0F;
/* 150 */     for (int i = 0; i < this.sizeX; i++) {
/*     */       
/* 152 */       for (int j = 0; j < this.sizeY; j++) {
/*     */         
/* 154 */         float val = this.distMap.getf(i, j);
/* 155 */         if (val != Float.POSITIVE_INFINITY)
/*     */         {
/* 157 */           maxVal = Math.max(maxVal, val);
/*     */         }
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 164 */     this.distMap.setMinAndMax(0.0D, maxVal);
/*     */     
/* 166 */     if (this.distMap.isInvertedLut())
/*     */     {
/* 168 */       this.distMap.invertLut();
/*     */     }
/*     */     
/* 171 */     return this.distMap;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private FloatProcessor initialize(ImageProcessor marker) {
/* 177 */     this.sizeX = marker.getWidth();
/* 178 */     this.sizeY = marker.getHeight();
/*     */     
/* 180 */     FloatProcessor distMap = new FloatProcessor(this.sizeX, this.sizeY);
/* 181 */     distMap.setValue(0.0D);
/* 182 */     distMap.fill();
/*     */ 
/*     */     
/* 185 */     for (int y = 0; y < this.sizeY; y++) {
/*     */       
/* 187 */       for (int x = 0; x < this.sizeX; x++) {
/*     */         
/* 189 */         int val = marker.get(x, y) & 0xFF;
/* 190 */         distMap.setf(x, y, (val == 0) ? Float.POSITIVE_INFINITY : 0.0F);
/*     */       } 
/*     */     } 
/*     */     
/* 194 */     return distMap;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void forwardIteration() {
/* 200 */     int[] dx = { -1, 1, -1 };
/* 201 */     int[] dy = { -1, -1, -1 };
/*     */     
/* 203 */     float[] dw = {
/* 204 */         this.weights[1], this.weights[0], this.weights[1], 
/* 205 */         this.weights[0]
/*     */       };
/*     */     
/* 208 */     for (int y = 0; y < this.sizeY; y++) {
/*     */       
/* 210 */       fireProgressChanged(this, y, this.sizeY);
/* 211 */       for (int x = 0; x < this.sizeX; x++) {
/*     */ 
/*     */         
/* 214 */         int label = (int)this.labelImage.getf(x, y);
/*     */ 
/*     */         
/* 217 */         if (label != 0) {
/*     */ 
/*     */ 
/*     */           
/* 221 */           double currentDist = this.distMap.getf(x, y);
/* 222 */           double newDist = currentDist;
/*     */ 
/*     */           
/* 225 */           for (int i = 0; i < dx.length; i++) {
/*     */ 
/*     */             
/* 228 */             int x2 = x + dx[i];
/* 229 */             int y2 = y + dy[i];
/*     */ 
/*     */             
/* 232 */             if (x2 >= 0 && x2 < this.sizeX)
/*     */             {
/* 234 */               if (y2 >= 0 && y2 < this.sizeY)
/*     */               {
/*     */                 
/* 237 */                 if ((int)this.labelImage.getf(x2, y2) == label)
/*     */                 {
/*     */                   
/* 240 */                   newDist = Math.min(newDist, (this.distMap.getf(x2, y2) + dw[i])); } 
/*     */               }
/*     */             }
/*     */           } 
/* 244 */           if (newDist < currentDist) {
/*     */             
/* 246 */             this.distMap.setf(x, y, (float)newDist);
/* 247 */             this.modif = true;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/* 252 */     fireProgressChanged(this, this.sizeY, this.sizeY);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void backwardIteration() {
/* 258 */     int[] dx = { 1, -1, 1 };
/* 259 */     int[] dy = { 1, 1, 1 };
/*     */     
/* 261 */     float[] dw = {
/* 262 */         this.weights[1], this.weights[0], this.weights[1], 
/* 263 */         this.weights[0]
/*     */       };
/*     */     
/* 266 */     for (int y = this.sizeY - 1; y >= 0; y--) {
/*     */       
/* 268 */       fireProgressChanged(this, (this.sizeY - 1 - y), this.sizeY);
/* 269 */       for (int x = this.sizeX - 1; x >= 0; x--) {
/*     */ 
/*     */         
/* 272 */         int label = (int)this.labelImage.getf(x, y);
/*     */ 
/*     */         
/* 275 */         if (label != 0) {
/*     */ 
/*     */ 
/*     */           
/* 279 */           double currentDist = this.distMap.getf(x, y);
/* 280 */           double newDist = currentDist;
/*     */ 
/*     */           
/* 283 */           for (int i = 0; i < dx.length; i++) {
/*     */ 
/*     */             
/* 286 */             int x2 = x + dx[i];
/* 287 */             int y2 = y + dy[i];
/*     */ 
/*     */             
/* 290 */             if (x2 >= 0 && x2 < this.sizeX)
/*     */             {
/* 292 */               if (y2 >= 0 && y2 < this.sizeY)
/*     */               {
/*     */                 
/* 295 */                 if ((int)this.labelImage.getf(x2, y2) == label)
/*     */                 {
/*     */                   
/* 298 */                   newDist = Math.min(newDist, (this.distMap.getf(x2, y2) + dw[i])); } 
/*     */               }
/*     */             }
/*     */           } 
/* 302 */           if (newDist < currentDist) {
/*     */             
/* 304 */             this.distMap.setf(x, y, (float)newDist);
/* 305 */             this.modif = true;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/* 310 */     fireProgressChanged(this, this.sizeY, this.sizeY);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/binary/geodesic/GeodesicDistanceTransformFloat.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */