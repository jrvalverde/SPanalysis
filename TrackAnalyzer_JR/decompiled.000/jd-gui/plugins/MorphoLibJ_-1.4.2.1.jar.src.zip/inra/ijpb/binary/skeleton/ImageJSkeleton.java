/*     */ package inra.ijpb.binary.skeleton;
/*     */ 
/*     */ import ij.process.ImageProcessor;
/*     */ import inra.ijpb.algo.AlgoStub;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ImageJSkeleton
/*     */   extends AlgoStub
/*     */ {
/*  32 */   private static int[] table1 = new int[] {
/*     */       
/*  34 */       0, 0, 0, 0, 0, 0, 1, 3, 3, 1, 1, 1, 3, 2, 3, 3, 3, 
/*  35 */       3, 2, 3, 2, 2, 
/*     */       
/*  37 */       2, 2, 2, 3, 3, 3, 2, 
/*  38 */       3, 1, 1, 3, 1, 1, 
/*  39 */       3, 1, 2, 
/*  40 */       2, 3, 1, 3, 1, 3, 1, 
/*  41 */       2, 3, 1, 1, 3, 3, 1, 2, 2, 2
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  48 */   private static int[] table2 = new int[] {
/*     */       
/*  50 */       0, 0, 0, 1, 2, 2, 2, 
/*  51 */       2, 2, 2,
/*     */ 
/*     */       
/*  54 */       1, 2, 
/*  55 */       2, 
/*     */       
/*  57 */       1
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ImageProcessor process(ImageProcessor image) {
/*     */     int removedPixels;
/*  70 */     ImageProcessor result = image.duplicate();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     do {
/*  77 */       removedPixels = thin(result, 1, table1);
/*  78 */       removedPixels += thin(result, 2, table1);
/*  79 */     } while (removedPixels > 0);
/*     */ 
/*     */ 
/*     */     
/*     */     do {
/*  84 */       removedPixels = thin(result, 1, table2);
/*  85 */       removedPixels += thin(result, 2, table2);
/*  86 */     } while (removedPixels > 0);
/*     */     
/*  88 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int thin(ImageProcessor image, int pass, int[] table) {
/* 108 */     int sizeX = image.getWidth();
/* 109 */     int sizeY = image.getHeight();
/*     */ 
/*     */     
/* 112 */     ImageProcessor copy = image.duplicate();
/*     */ 
/*     */     
/* 115 */     int removedPixels = 0;
/*     */ 
/*     */     
/* 118 */     for (int y = 0; y < sizeY; y++) {
/*     */       
/* 120 */       for (int x = 0; x < sizeX; x++) {
/*     */ 
/*     */         
/* 123 */         int label = (int)copy.getf(x, y);
/*     */ 
/*     */         
/* 126 */         if (label != 0) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 132 */           int index = 0;
/*     */           
/* 134 */           if (y > 0) {
/*     */             
/* 136 */             if (x > 0)
/*     */             {
/* 138 */               if ((int)copy.getf(x - 1, y - 1) == label) index |= 0x1; 
/*     */             }
/* 140 */             if ((int)copy.getf(x, y - 1) == label) index |= 0x2; 
/* 141 */             if (x < sizeX - 1)
/*     */             {
/* 143 */               if ((int)copy.getf(x + 1, y - 1) == label) index |= 0x4;
/*     */             
/*     */             }
/*     */           } 
/* 147 */           if (x > 0)
/*     */           {
/* 149 */             if ((int)copy.getf(x - 1, y) == label) index |= 0x80; 
/*     */           }
/* 151 */           if (x < sizeX - 1)
/*     */           {
/* 153 */             if ((int)copy.getf(x + 1, y) == label) index |= 0x8;
/*     */           
/*     */           }
/* 156 */           if (y < sizeY - 1) {
/*     */             
/* 158 */             if (x > 0)
/*     */             {
/* 160 */               if ((int)copy.getf(x - 1, y + 1) == label) index |= 0x40; 
/*     */             }
/* 162 */             if ((int)copy.getf(x, y + 1) == label) index |= 0x20; 
/* 163 */             if (x < sizeX - 1)
/*     */             {
/* 165 */               if ((int)copy.getf(x + 1, y + 1) == label) index |= 0x10;
/*     */             
/*     */             }
/*     */           } 
/* 169 */           int code = table[index];
/* 170 */           if ((code & pass) > 0) {
/*     */             
/* 172 */             image.set(x, y, 0);
/* 173 */             removedPixels++;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/* 178 */     return removedPixels;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/binary/skeleton/ImageJSkeleton.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */