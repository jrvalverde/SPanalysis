/*     */ package inra.ijpb.binary.conncomp;
/*     */ 
/*     */ import ij.ImageStack;
/*     */ import inra.ijpb.algo.AlgoStub;
/*     */ import inra.ijpb.morphology.FloodFill3D;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FloodFillComponentsLabeling3D
/*     */   extends AlgoStub
/*     */   implements ConnectedComponentsLabeling3D
/*     */ {
/*  46 */   int connectivity = 6;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  52 */   int bitDepth = 16;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FloodFillComponentsLabeling3D() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FloodFillComponentsLabeling3D(int connectivity) {
/*  69 */     this.connectivity = connectivity;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FloodFillComponentsLabeling3D(int connectivity, int bitDepth) {
/*  83 */     this.connectivity = connectivity;
/*  84 */     this.bitDepth = bitDepth;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ImageStack computeLabels(ImageStack image) {
/*     */     int maxLabel;
/*  93 */     if (Thread.currentThread().isInterrupted()) {
/*  94 */       return null;
/*     */     }
/*     */     
/*  97 */     int sizeX = image.getWidth();
/*  98 */     int sizeY = image.getHeight();
/*  99 */     int sizeZ = image.getSize();
/*     */ 
/*     */     
/* 102 */     fireStatusChanged(this, "Allocate memory...");
/* 103 */     ImageStack labels = ImageStack.create(sizeX, sizeY, sizeZ, this.bitDepth);
/*     */ 
/*     */ 
/*     */     
/* 107 */     switch (this.bitDepth) {
/*     */       case 8:
/* 109 */         maxLabel = 255;
/*     */         break;
/*     */       case 16:
/* 112 */         maxLabel = 65535;
/*     */         break;
/*     */       case 32:
/* 115 */         maxLabel = 8388608;
/*     */         break;
/*     */       default:
/* 118 */         throw new IllegalArgumentException(
/* 119 */             "Bit Depth should be 8, 16 or 32.");
/*     */     } 
/*     */     
/* 122 */     fireStatusChanged(this, "Compute Labels...");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 128 */     int nLabels = 0;
/* 129 */     for (int z = 0; z < sizeZ; z++) {
/*     */       
/* 131 */       fireProgressChanged(this, z, sizeZ);
/* 132 */       for (int y = 0; y < sizeY; y++) {
/*     */         
/* 134 */         for (int x = 0; x < sizeX; x++) {
/*     */ 
/*     */           
/* 137 */           if (image.getVoxel(x, y, z) != 0.0D)
/*     */           {
/*     */ 
/*     */             
/* 141 */             if (labels.getVoxel(x, y, z) <= 0.0D) {
/*     */ 
/*     */ 
/*     */               
/* 145 */               if (nLabels == maxLabel)
/*     */               {
/* 147 */                 throw new RuntimeException("Max number of label reached (" + maxLabel + ")");
/*     */               }
/*     */ 
/*     */               
/* 151 */               nLabels++;
/* 152 */               fireStatusChanged(this, "Process label " + nLabels);
/* 153 */               FloodFill3D.floodFillFloat(image, x, y, z, labels, nLabels, this.connectivity);
/*     */             }  } 
/*     */         } 
/*     */       } 
/*     */     } 
/* 158 */     fireStatusChanged(this, "");
/* 159 */     fireProgressChanged(this, 1.0D, 1.0D);
/* 160 */     return labels;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/binary/conncomp/FloodFillComponentsLabeling3D.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */