/*     */ package inra.ijpb.math;
/*     */ 
/*     */ import ij.ImagePlus;
/*     */ import ij.ImageStack;
/*     */ import ij.process.ByteProcessor;
/*     */ import ij.process.ImageProcessor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ImageCalculator
/*     */ {
/*     */   public static interface Operation
/*     */   {
/*  47 */     public static final Operation PLUS = new Operation()
/*     */       {
/*     */         
/*     */         public int applyTo(int v1, int v2)
/*     */         {
/*  52 */           return v1 + v2;
/*     */         }
/*     */ 
/*     */ 
/*     */         
/*     */         public float applyTo(float v1, float v2) {
/*  58 */           return v1 + v2;
/*     */         }
/*     */       };
/*     */     
/*  62 */     public static final Operation MINUS = new Operation()
/*     */       {
/*     */         
/*     */         public int applyTo(int v1, int v2)
/*     */         {
/*  67 */           return v1 - v2;
/*     */         }
/*     */ 
/*     */ 
/*     */         
/*     */         public float applyTo(float v1, float v2) {
/*  73 */           return v1 - v2;
/*     */         }
/*     */       };
/*     */     
/*  77 */     public static final Operation ABS_DIFF = new Operation()
/*     */       {
/*     */         
/*     */         public int applyTo(int v1, int v2)
/*     */         {
/*  82 */           return Math.abs(v1 - v2);
/*     */         }
/*     */ 
/*     */ 
/*     */         
/*     */         public float applyTo(float v1, float v2) {
/*  88 */           return Math.abs(v1 + v2);
/*     */         }
/*     */       };
/*     */     
/*  92 */     public static final Operation TIMES = new Operation()
/*     */       {
/*     */         
/*     */         public int applyTo(int v1, int v2)
/*     */         {
/*  97 */           return v1 * v2;
/*     */         }
/*     */ 
/*     */ 
/*     */         
/*     */         public float applyTo(float v1, float v2) {
/* 103 */           return v1 * v2;
/*     */         }
/*     */       };
/*     */     
/* 107 */     public static final Operation DIVIDES = new Operation()
/*     */       {
/*     */         
/*     */         public int applyTo(int v1, int v2)
/*     */         {
/* 112 */           return v1 / v2;
/*     */         }
/*     */ 
/*     */ 
/*     */         
/*     */         public float applyTo(float v1, float v2) {
/* 118 */           return v1 / v2;
/*     */         }
/*     */       };
/*     */     
/* 122 */     public static final Operation MAX = new Operation()
/*     */       {
/*     */         
/*     */         public int applyTo(int v1, int v2)
/*     */         {
/* 127 */           return Math.max(v1, v2);
/*     */         }
/*     */ 
/*     */ 
/*     */         
/*     */         public float applyTo(float v1, float v2) {
/* 133 */           return Math.max(v1, v2);
/*     */         }
/*     */       };
/*     */     
/* 137 */     public static final Operation MIN = new Operation()
/*     */       {
/*     */         
/*     */         public int applyTo(int v1, int v2)
/*     */         {
/* 142 */           return Math.min(v1, v2);
/*     */         }
/*     */ 
/*     */ 
/*     */         
/*     */         public float applyTo(float v1, float v2) {
/* 148 */           return Math.min(v1, v2);
/*     */         }
/*     */       };
/*     */     
/* 152 */     public static final Operation MEAN = new Operation()
/*     */       {
/*     */         
/*     */         public int applyTo(int v1, int v2)
/*     */         {
/* 157 */           return (v1 + v2) / 2;
/*     */         }
/*     */ 
/*     */ 
/*     */         
/*     */         public float applyTo(float v1, float v2) {
/* 163 */           return (v1 + v2) / 2.0F;
/*     */         }
/*     */       };
/*     */     
/* 167 */     public static final Operation AND = new Operation()
/*     */       {
/*     */         
/*     */         public int applyTo(int v1, int v2)
/*     */         {
/* 172 */           return v1 & v2;
/*     */         }
/*     */ 
/*     */ 
/*     */         
/*     */         public float applyTo(float v1, float v2) {
/* 178 */           return ((int)v1 & (int)v2);
/*     */         }
/*     */       };
/*     */     
/* 182 */     public static final Operation OR = new Operation()
/*     */       {
/*     */         
/*     */         public int applyTo(int v1, int v2)
/*     */         {
/* 187 */           return v1 | v2;
/*     */         }
/*     */ 
/*     */ 
/*     */         
/*     */         public float applyTo(float v1, float v2) {
/* 193 */           return ((int)v1 | (int)v2);
/*     */         }
/*     */       };
/*     */     
/* 197 */     public static final Operation XOR = new Operation()
/*     */       {
/*     */         
/*     */         public int applyTo(int v1, int v2)
/*     */         {
/* 202 */           return v1 ^ v2;
/*     */         }
/*     */ 
/*     */ 
/*     */         
/*     */         public float applyTo(float v1, float v2) {
/* 208 */           return ((int)v1 ^ (int)v2);
/*     */         }
/*     */       };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     int applyTo(int param1Int1, int param1Int2);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     float applyTo(float param1Float1, float param1Float2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final ImagePlus combineImages(ImagePlus image1, ImagePlus image2, Operation op) {
/* 238 */     String newName = "result of " + image1.getShortTitle();
/* 239 */     if (image1.getStackSize() == 1) {
/*     */       
/* 241 */       ImageProcessor imageProcessor = combineImages(image1.getProcessor(), image2.getProcessor(), op);
/* 242 */       return new ImagePlus(newName, imageProcessor);
/*     */     } 
/*     */ 
/*     */     
/* 246 */     ImageStack result = combineImages(image1.getStack(), image2.getStack(), op);
/* 247 */     return new ImagePlus(newName, result);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final ImageProcessor combineImages(ImageProcessor image1, ImageProcessor image2, Operation op) {
/* 274 */     int width = image1.getWidth();
/* 275 */     int height = image1.getHeight();
/*     */     
/* 277 */     ImageProcessor result = image1.duplicate();
/*     */ 
/*     */     
/* 280 */     for (int y = 0; y < height; y++) {
/*     */       
/* 282 */       for (int x = 0; x < width; x++) {
/*     */         
/* 284 */         float v1 = image1.getf(x, y);
/* 285 */         float v2 = image2.getf(x, y);
/* 286 */         float vr = op.applyTo(v1, v2);
/* 287 */         result.setf(x, y, vr);
/*     */       } 
/*     */     } 
/*     */     
/* 291 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public static final ImageStack combineImages(ImageStack image1, ImageStack image2, Operation op) {
/* 296 */     int width = image1.getWidth();
/* 297 */     int height = image1.getHeight();
/* 298 */     int depth = image1.getSize();
/*     */     
/* 300 */     ImageStack result = image1.duplicate();
/*     */ 
/*     */     
/* 303 */     for (int z = 0; z < depth; z++) {
/*     */       
/* 305 */       for (int y = 0; y < height; y++) {
/*     */         
/* 307 */         for (int x = 0; x < width; x++) {
/*     */           
/* 309 */           float v1 = (float)image1.getVoxel(x, y, z);
/* 310 */           float v2 = (float)image2.getVoxel(x, y, z);
/* 311 */           float vr = op.applyTo(v1, v2);
/* 312 */           result.setVoxel(x, y, z, vr);
/*     */         } 
/*     */       } 
/*     */     } 
/* 316 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public static final ImagePlus not(ImagePlus image) {
/* 321 */     String newName = String.valueOf(image.getShortTitle()) + "-not";
/* 322 */     if (image.getStackSize() == 1) {
/*     */       
/* 324 */       ImageProcessor imageProcessor = not(image.getProcessor());
/* 325 */       return new ImagePlus(newName, imageProcessor);
/*     */     } 
/*     */ 
/*     */     
/* 329 */     ImageStack result = not(image.getStack());
/* 330 */     return new ImagePlus(newName, result);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static final ImageProcessor not(ImageProcessor image) {
/* 336 */     int width = image.getWidth();
/* 337 */     int height = image.getHeight();
/*     */     
/* 339 */     ImageProcessor result = image.duplicate();
/*     */     
/* 341 */     for (int y = 0; y < height; y++) {
/*     */       
/* 343 */       for (int x = 0; x < width; x++)
/*     */       {
/* 345 */         result.set(x, y, image.get(x, y) ^ 0xFFFFFFFF);
/*     */       }
/*     */     } 
/* 348 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public static final ImageStack not(ImageStack image) {
/* 353 */     int sizeX = image.getWidth();
/* 354 */     int sizeY = image.getHeight();
/* 355 */     int sizeZ = image.getHeight();
/*     */     
/* 357 */     ImageStack result = image.duplicate();
/*     */     
/* 359 */     for (int z = 0; z < sizeZ; z++) {
/*     */       
/* 361 */       for (int y = 0; y < sizeY; y++) {
/*     */         
/* 363 */         for (int x = 0; x < sizeX; x++)
/*     */         {
/* 365 */           result.setVoxel(x, y, z, ((int)image.getVoxel(x, y, z) ^ 0xFFFFFFFF));
/*     */         }
/*     */       } 
/*     */     } 
/* 369 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public static final void main(String[] args) {
/* 374 */     int width = 255;
/* 375 */     int height = 255;
/* 376 */     ByteProcessor byteProcessor1 = new ByteProcessor(width, height);
/* 377 */     ByteProcessor byteProcessor2 = new ByteProcessor(width, height);
/* 378 */     for (int i = 0; i < width; i++) {
/*     */       
/* 380 */       for (int j = 0; j < height; j++) {
/*     */         
/* 382 */         byteProcessor1.set(i, j, i);
/* 383 */         byteProcessor2.set(j, i, i);
/*     */       } 
/*     */     } 
/*     */     
/* 387 */     Operation op = Operation.MAX;
/* 388 */     ImageProcessor result = combineImages((ImageProcessor)byteProcessor1, (ImageProcessor)byteProcessor2, op);
/*     */     
/* 390 */     (new ImagePlus("result", result)).show();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/math/ImageCalculator.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */