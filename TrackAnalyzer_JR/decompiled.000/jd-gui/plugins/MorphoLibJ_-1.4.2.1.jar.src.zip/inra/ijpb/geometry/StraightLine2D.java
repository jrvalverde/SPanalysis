/*    */ package inra.ijpb.geometry;
/*    */ 
/*    */ import java.awt.geom.Point2D;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StraightLine2D
/*    */ {
/*    */   double x0;
/*    */   double y0;
/*    */   double dx;
/*    */   double dy;
/*    */   
/*    */   public StraightLine2D(Point2D origin, Vector2D direction) {
/* 22 */     this.x0 = origin.getX();
/* 23 */     this.y0 = origin.getY();
/* 24 */     this.dx = direction.getX();
/* 25 */     this.dy = direction.getY();
/*    */   }
/*    */ 
/*    */   
/*    */   public StraightLine2D(Point2D source, Point2D target) {
/* 30 */     this.x0 = source.getX();
/* 31 */     this.y0 = source.getY();
/* 32 */     this.dx = target.getX() - this.x0;
/* 33 */     this.dy = target.getY() - this.y0;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Point2D getOrigin() {
/* 39 */     return new Point2D.Double(this.x0, this.y0);
/*    */   }
/*    */ 
/*    */   
/*    */   public Vector2D getDirection() {
/* 44 */     return new Vector2D(this.dx, this.dy);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public double distance(Point2D point) {
/* 51 */     double delta = this.dx * this.dx + this.dy * this.dy;
/* 52 */     if (delta < 1.0E-12D)
/*    */     {
/* 54 */       throw new RuntimeException("Direction vector of line is too small");
/*    */     }
/*    */ 
/*    */     
/* 58 */     double xDiff = point.getX() - this.x0;
/* 59 */     double yDiff = point.getY() - this.y0;
/*    */ 
/*    */ 
/*    */     
/* 63 */     double pos = (xDiff * this.dx + yDiff * this.dy) / delta;
/*    */ 
/*    */     
/* 66 */     double dist = Math.hypot(pos * this.dx - xDiff, pos * this.dy - yDiff);
/* 67 */     return dist;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/geometry/StraightLine2D.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */