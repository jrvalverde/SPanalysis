/*     */ package inra.ijpb.geometry;
/*     */ 
/*     */ import java.awt.Point;
/*     */ import java.awt.geom.Point2D;
/*     */ import java.util.ArrayList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Polygons2D
/*     */ {
/*     */   public static final Polygon2D convexHull(ArrayList<? extends Point2D> points) {
/*  44 */     int n = points.size();
/*     */ 
/*     */     
/*  47 */     int pStart = 0;
/*  48 */     double ymin = Double.MAX_VALUE;
/*  49 */     double smallestX = Double.MAX_VALUE;
/*     */ 
/*     */     
/*  52 */     for (int i = 0; i < n; i++) {
/*     */       
/*  54 */       Point2D vertex = points.get(i);
/*  55 */       double y = vertex.getY();
/*     */ 
/*     */       
/*  58 */       if (y < ymin) {
/*     */         
/*  60 */         ymin = y;
/*  61 */         pStart = i;
/*  62 */         smallestX = vertex.getX();
/*     */       }
/*  64 */       else if (y == ymin) {
/*     */         
/*  66 */         double x = vertex.getX();
/*  67 */         if (x < smallestX) {
/*     */           
/*  69 */           smallestX = x;
/*  70 */           pStart = i;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/*  76 */     Polygon2D convHull = new Polygon2D();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  82 */     int ip1 = pStart;
/*     */ 
/*     */     
/*     */     do {
/*  86 */       Point2D p1 = points.get(ip1);
/*  87 */       double x1 = p1.getX();
/*  88 */       double y1 = p1.getY();
/*     */ 
/*     */       
/*  91 */       int ip2 = (ip1 + 1) % n;
/*  92 */       Point2D p2 = points.get(ip2);
/*  93 */       double x2 = p2.getX();
/*  94 */       double y2 = p2.getY();
/*     */ 
/*     */       
/*  97 */       int ip3 = (ip2 + 1) % n;
/*     */       
/*     */       do {
/* 100 */         Point2D p3 = points.get(ip3);
/* 101 */         double x3 = p3.getX();
/* 102 */         double y3 = p3.getY();
/*     */ 
/*     */         
/* 105 */         double det = x1 * (y2 - y3) - y1 * (x2 - x3) + y3 * x2 - y2 * x3;
/* 106 */         if (det < 0.0D)
/*     */         {
/* 108 */           if (det < -1.0E-12D) {
/*     */ 
/*     */             
/* 111 */             x2 = x3;
/* 112 */             y2 = y3;
/* 113 */             ip2 = ip3;
/*     */           
/*     */           }
/*     */           else {
/*     */ 
/*     */             
/* 119 */             double x12 = x2 - x1;
/* 120 */             double y12 = y2 - y1;
/* 121 */             double x13 = x3 - x1;
/* 122 */             double y13 = y3 - y1;
/* 123 */             if (x12 * x13 + y12 * y13 > x13 * x13 + y13 * y13) {
/*     */               
/* 125 */               x2 = x3;
/* 126 */               y2 = y3;
/* 127 */               ip2 = ip3;
/*     */             } 
/*     */           } 
/*     */         }
/* 131 */         ip3 = (ip3 + 1) % n;
/* 132 */       } while (ip3 != ip1);
/*     */       
/* 134 */       convHull.addVertex(new Point2D.Double(x1, y1));
/* 135 */       ip1 = ip2;
/* 136 */     } while (ip1 != pStart);
/*     */     
/* 138 */     return convHull;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final ArrayList<Point> convexHull_int(ArrayList<Point> points) {
/* 156 */     int n = points.size();
/* 157 */     int[] xCoords = new int[n];
/* 158 */     int[] yCoords = new int[n];
/*     */ 
/*     */     
/* 161 */     int ymin = Integer.MAX_VALUE;
/*     */ 
/*     */     
/* 164 */     int pStart = 0;
/* 165 */     int xmin = Integer.MAX_VALUE;
/*     */ 
/*     */ 
/*     */     
/* 169 */     for (int i = 0; i < n; i++) {
/*     */       
/* 171 */       Point vertex = points.get(i);
/* 172 */       xCoords[i] = vertex.x;
/* 173 */       yCoords[i] = vertex.y;
/*     */       
/* 175 */       if (vertex.y < ymin) {
/*     */         
/* 177 */         ymin = vertex.y;
/* 178 */         pStart = i;
/* 179 */         xmin = vertex.x;
/*     */       }
/* 181 */       else if (vertex.y == ymin && vertex.x < xmin) {
/*     */         
/* 183 */         xmin = vertex.x;
/* 184 */         pStart = i;
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 189 */     ArrayList<Point> hull = new ArrayList<Point>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 195 */     int p1 = pStart;
/*     */ 
/*     */     
/*     */     do {
/* 199 */       int x1 = xCoords[p1];
/* 200 */       int y1 = yCoords[p1];
/*     */ 
/*     */       
/* 203 */       int p2 = (p1 + 1) % n;
/* 204 */       int x2 = xCoords[p2];
/* 205 */       int y2 = yCoords[p2];
/*     */ 
/*     */       
/* 208 */       int p3 = (p2 + 1) % n;
/*     */       
/*     */       do {
/* 211 */         int x3 = xCoords[p3];
/* 212 */         int y3 = yCoords[p3];
/*     */ 
/*     */         
/* 215 */         int det = x1 * (y2 - y3) - y1 * (x2 - x3) + y3 * x2 - y2 * x3;
/* 216 */         if (det < 0) {
/*     */           
/* 218 */           x2 = x3;
/* 219 */           y2 = y3;
/* 220 */           p2 = p3;
/*     */         } 
/* 222 */         p3 = (p3 + 1) % n;
/* 223 */       } while (p3 != p1);
/*     */       
/* 225 */       hull.add(new Point(x1, y1));
/* 226 */       p1 = p2;
/* 227 */     } while (p1 != pStart);
/*     */     
/* 229 */     return hull;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/geometry/Polygons2D.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */