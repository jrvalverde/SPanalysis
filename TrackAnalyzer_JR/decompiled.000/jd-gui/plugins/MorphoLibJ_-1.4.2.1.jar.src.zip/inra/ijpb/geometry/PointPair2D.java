/*    */ package inra.ijpb.geometry;
/*    */ 
/*    */ import java.awt.geom.Point2D;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PointPair2D
/*    */ {
/*    */   public final Point2D p1;
/*    */   public final Point2D p2;
/*    */   
/*    */   public PointPair2D(Point2D p1, Point2D p2) {
/* 24 */     this.p1 = p1;
/* 25 */     this.p2 = p2;
/*    */   }
/*    */ 
/*    */   
/*    */   public double diameter() {
/* 30 */     double dx = this.p2.getX() - this.p1.getX();
/* 31 */     double dy = this.p2.getY() - this.p1.getY();
/* 32 */     return Math.hypot(dx, dy);
/*    */   }
/*    */ 
/*    */   
/*    */   public double angle() {
/* 37 */     double dx = this.p2.getX() - this.p1.getX();
/* 38 */     double dy = this.p2.getY() - this.p1.getY();
/* 39 */     return Math.atan2(dy, dx);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/geometry/PointPair2D.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */