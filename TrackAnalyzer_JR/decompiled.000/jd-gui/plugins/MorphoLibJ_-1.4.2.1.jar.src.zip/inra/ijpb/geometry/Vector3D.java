/*     */ package inra.ijpb.geometry;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Vector3D
/*     */ {
/*     */   private final double x;
/*     */   private final double y;
/*     */   private final double z;
/*     */   
/*     */   public Vector3D() {
/*  52 */     this.x = 0.0D;
/*  53 */     this.y = 0.0D;
/*  54 */     this.z = 0.0D;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Vector3D(double x, double y, double z) {
/*  66 */     this.x = x;
/*  67 */     this.y = y;
/*  68 */     this.z = z;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final Vector3D crossProduct(Vector3D v1, Vector3D v2) {
/*  85 */     return new Vector3D(
/*  86 */         v1.y * v2.z - v1.z * v2.y, 
/*  87 */         v1.z * v2.x - v1.x * v2.z, 
/*  88 */         v1.x * v2.y - v1.y * v2.x);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final double dotProduct(Vector3D v1, Vector3D v2) {
/* 106 */     return v1.x * v2.x + v1.y * v2.y + v1.z * v2.z;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final double angle(Vector3D v1, Vector3D v2) {
/* 122 */     double norm = crossProduct(v1, v2).getNorm();
/* 123 */     double det = dotProduct(v1, v2);
/* 124 */     return Math.atan2(norm, det);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getX() {
/* 138 */     return this.x;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getY() {
/* 148 */     return this.y;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getZ() {
/* 158 */     return this.z;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Vector3D plus(Vector3D v) {
/* 172 */     double x = this.x + v.x;
/* 173 */     double y = this.y + v.y;
/* 174 */     double z = this.z + v.z;
/* 175 */     return new Vector3D(x, y, z);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Vector3D minus(Vector3D v) {
/* 186 */     double x = this.x - v.x;
/* 187 */     double y = this.y - v.y;
/* 188 */     double z = this.z - v.z;
/* 189 */     return new Vector3D(x, y, z);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Vector3D times(double k) {
/* 201 */     double x = this.x * k;
/* 202 */     double y = this.y * k;
/* 203 */     double z = this.z * k;
/* 204 */     return new Vector3D(x, y, z);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Vector3D normalize() {
/* 214 */     double norm = getNorm();
/* 215 */     return new Vector3D(this.x / norm, this.y / norm, this.z / norm);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getNorm() {
/* 226 */     double norm = Math.hypot(this.x, this.y);
/* 227 */     norm = Math.hypot(norm, this.z);
/* 228 */     return norm;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean almostEquals(Vector3D v, double eps) {
/* 243 */     if (Math.abs(this.x - v.x) > eps) return false; 
/* 244 */     if (Math.abs(this.y - v.y) > eps) return false; 
/* 245 */     if (Math.abs(this.z - v.z) > eps) return false; 
/* 246 */     return true;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/geometry/Vector3D.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */