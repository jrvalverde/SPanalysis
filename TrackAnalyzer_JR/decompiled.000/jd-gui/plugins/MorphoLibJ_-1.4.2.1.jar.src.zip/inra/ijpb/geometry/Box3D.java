/*     */ package inra.ijpb.geometry;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Box3D
/*     */ {
/*     */   double xmin;
/*     */   double xmax;
/*     */   double ymin;
/*     */   double ymax;
/*     */   double zmin;
/*     */   double zmax;
/*     */   
/*     */   public Box3D(double xmin, double xmax, double ymin, double ymax, double zmin, double zmax) {
/*  48 */     this.xmin = xmin;
/*  49 */     this.xmax = xmax;
/*  50 */     this.ymin = ymin;
/*  51 */     this.ymax = ymax;
/*  52 */     this.zmin = zmin;
/*  53 */     this.zmax = zmax;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double volume() {
/*  66 */     return (this.xmax - this.xmin) * (this.ymax - this.ymin) * (this.zmax - this.zmin);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double width() {
/*  77 */     return this.xmax - this.xmin;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double height() {
/*  88 */     return this.ymax - this.ymin;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double depth() {
/*  99 */     return this.zmax - this.zmin;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getXMin() {
/* 108 */     return this.xmin;
/*     */   }
/*     */ 
/*     */   
/*     */   public double getXMax() {
/* 113 */     return this.xmax;
/*     */   }
/*     */ 
/*     */   
/*     */   public double getYMin() {
/* 118 */     return this.ymin;
/*     */   }
/*     */ 
/*     */   
/*     */   public double getYMax() {
/* 123 */     return this.ymax;
/*     */   }
/*     */ 
/*     */   
/*     */   public double getZMin() {
/* 128 */     return this.zmin;
/*     */   }
/*     */ 
/*     */   
/*     */   public double getZMax() {
/* 133 */     return this.zmax;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/geometry/Box3D.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */