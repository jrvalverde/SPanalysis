/*    */ package inra.ijpb.geometry;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Sphere
/*    */ {
/*    */   private final Point3D center;
/*    */   private final double radius;
/*    */   
/*    */   public Sphere(Point3D center, double radius) {
/* 37 */     this.center = center;
/* 38 */     this.radius = radius;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public double volume() {
/* 46 */     return 12.566370614359172D * this.radius * this.radius * this.radius / 3.0D;
/*    */   }
/*    */ 
/*    */   
/*    */   public double surfaceArea() {
/* 51 */     return 12.566370614359172D * this.radius * this.radius;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Point3D center() {
/* 60 */     return this.center;
/*    */   }
/*    */ 
/*    */   
/*    */   public double radius() {
/* 65 */     return this.radius;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/geometry/Sphere.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */