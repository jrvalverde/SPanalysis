/*     */ package inra.ijpb.geometry;
/*     */ 
/*     */ import java.awt.geom.Point2D;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OrientedBox2D
/*     */ {
/*     */   double xc;
/*     */   double yc;
/*     */   double length;
/*     */   double width;
/*     */   double orientation;
/*     */   
/*     */   public OrientedBox2D(Point2D center, double length, double width, double orientation) {
/*  46 */     this(center.getX(), center.getY(), length, width, orientation);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OrientedBox2D(double xc, double yc, double length, double width, double orientation) {
/*  66 */     this.xc = xc;
/*  67 */     this.yc = yc;
/*  68 */     this.length = length;
/*  69 */     this.width = width;
/*  70 */     this.orientation = orientation;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double area() {
/*  83 */     return this.length * this.width;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Point2D center() {
/*  91 */     return new Point2D.Double(this.xc, this.yc);
/*     */   }
/*     */ 
/*     */   
/*     */   public double length() {
/*  96 */     return this.length;
/*     */   }
/*     */ 
/*     */   
/*     */   public double width() {
/* 101 */     return this.width;
/*     */   }
/*     */ 
/*     */   
/*     */   public double orientation() {
/* 106 */     return this.orientation;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/geometry/OrientedBox2D.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */