/*     */ package inra.ijpb.geometry;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Box2D
/*     */ {
/*     */   double xmin;
/*     */   double xmax;
/*     */   double ymin;
/*     */   double ymax;
/*     */   
/*     */   public Box2D(double xmin, double xmax, double ymin, double ymax) {
/*  42 */     this.xmin = xmin;
/*  43 */     this.xmax = xmax;
/*  44 */     this.ymin = ymin;
/*  45 */     this.ymax = ymax;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double area() {
/*  58 */     return (this.xmax - this.xmin) * (this.ymax - this.ymin);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double width() {
/*  69 */     return this.xmax - this.xmin;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double height() {
/*  80 */     return this.ymax - this.ymin;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getXMin() {
/*  89 */     return this.xmin;
/*     */   }
/*     */ 
/*     */   
/*     */   public double getXMax() {
/*  94 */     return this.xmax;
/*     */   }
/*     */ 
/*     */   
/*     */   public double getYMin() {
/*  99 */     return this.ymin;
/*     */   }
/*     */ 
/*     */   
/*     */   public double getYMax() {
/* 104 */     return this.ymax;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/geometry/Box2D.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */