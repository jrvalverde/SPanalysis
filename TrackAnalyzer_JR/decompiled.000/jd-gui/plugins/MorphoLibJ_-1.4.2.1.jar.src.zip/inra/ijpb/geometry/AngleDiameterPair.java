/*    */ package inra.ijpb.geometry;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AngleDiameterPair
/*    */ {
/*    */   public double angle;
/*    */   public double diameter;
/*    */   
/*    */   public AngleDiameterPair(double angle, double diameter) {
/* 31 */     this.angle = angle;
/* 32 */     this.diameter = diameter;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/geometry/AngleDiameterPair.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */