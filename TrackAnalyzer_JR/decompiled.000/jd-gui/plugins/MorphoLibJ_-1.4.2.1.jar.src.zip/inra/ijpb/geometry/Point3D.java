/*    */ package inra.ijpb.geometry;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Point3D
/*    */ {
/*    */   private double x;
/*    */   private double y;
/*    */   private double z;
/*    */   
/*    */   public Point3D() {
/* 22 */     this(0.0D, 0.0D, 0.0D);
/*    */   }
/*    */ 
/*    */   
/*    */   public Point3D(double x, double y, double z) {
/* 27 */     this.x = x;
/* 28 */     this.y = y;
/* 29 */     this.z = z;
/*    */   }
/*    */ 
/*    */   
/*    */   public double distance(Point3D point) {
/* 34 */     double dx = point.x - this.x;
/* 35 */     double dy = point.y - this.y;
/* 36 */     double dz = point.z - this.z;
/* 37 */     return Math.hypot(Math.hypot(dx, dy), dz);
/*    */   }
/*    */ 
/*    */   
/*    */   public double getX() {
/* 42 */     return this.x;
/*    */   }
/*    */ 
/*    */   
/*    */   public double getY() {
/* 47 */     return this.y;
/*    */   }
/*    */ 
/*    */   
/*    */   public double getZ() {
/* 52 */     return this.z;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/geometry/Point3D.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */