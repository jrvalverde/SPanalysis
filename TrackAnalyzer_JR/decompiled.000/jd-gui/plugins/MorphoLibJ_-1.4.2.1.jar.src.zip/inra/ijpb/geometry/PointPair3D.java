/*    */ package inra.ijpb.geometry;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PointPair3D
/*    */ {
/*    */   public final Point3D p1;
/*    */   public final Point3D p2;
/*    */   
/*    */   public PointPair3D(Point3D p1, Point3D p2) {
/* 23 */     this.p1 = p1;
/* 24 */     this.p2 = p2;
/*    */   }
/*    */ 
/*    */   
/*    */   public double diameter() {
/* 29 */     double dx = this.p2.getX() - this.p1.getX();
/* 30 */     double dy = this.p2.getY() - this.p1.getY();
/* 31 */     double dz = this.p2.getZ() - this.p1.getZ();
/* 32 */     return Math.hypot(Math.hypot(dx, dy), dz);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/geometry/PointPair3D.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */