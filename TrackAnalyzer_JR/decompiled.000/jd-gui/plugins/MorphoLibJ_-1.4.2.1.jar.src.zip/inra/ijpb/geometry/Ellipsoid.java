/*     */ package inra.ijpb.geometry;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Ellipsoid
/*     */ {
/*     */   double centerX;
/*     */   double centerY;
/*     */   double centerZ;
/*     */   double radius1;
/*     */   double radius2;
/*     */   double radius3;
/*     */   double phi;
/*     */   double theta;
/*     */   double psi;
/*     */   
/*     */   public static final Point3D[] centers(Ellipsoid[] ellipsoids) {
/*  28 */     Point3D[] centroids = new Point3D[ellipsoids.length];
/*  29 */     for (int i = 0; i < ellipsoids.length; i++)
/*     */     {
/*  31 */       centroids[i] = ellipsoids[i].center();
/*     */     }
/*  33 */     return centroids;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final double[][] elongations(Ellipsoid[] ellipsoids) {
/*  55 */     int nLabels = ellipsoids.length;
/*  56 */     double[][] res = new double[nLabels][3];
/*     */     
/*  58 */     for (int i = 0; i < nLabels; i++) {
/*     */       
/*  60 */       double ra = (ellipsoids[i]).radius1;
/*  61 */       double rb = (ellipsoids[i]).radius2;
/*  62 */       double rc = (ellipsoids[i]).radius3;
/*     */       
/*  64 */       res[i][0] = ra / rb;
/*  65 */       res[i][1] = ra / rc;
/*  66 */       res[i][2] = rb / rc;
/*     */     } 
/*     */     
/*  69 */     return res;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Ellipsoid(Point3D center, double r1, double r2, double r3) {
/* 141 */     this(center, r1, r2, r3, 0.0D, 0.0D, 0.0D);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Ellipsoid(Point3D center, double r1, double r2, double r3, double phi, double theta, double psi) {
/* 164 */     this.centerX = center.getX();
/* 165 */     this.centerY = center.getY();
/* 166 */     this.centerZ = center.getZ();
/* 167 */     this.radius1 = r1;
/* 168 */     this.radius2 = r2;
/* 169 */     this.radius3 = r3;
/* 170 */     this.phi = phi;
/* 171 */     this.theta = theta;
/* 172 */     this.psi = psi;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Ellipsoid(double xc, double yc, double zc, double r1, double r2, double r3, double phi, double theta, double psi) {
/* 199 */     this.centerX = xc;
/* 200 */     this.centerY = yc;
/* 201 */     this.centerZ = zc;
/* 202 */     this.radius1 = r1;
/* 203 */     this.radius2 = r2;
/* 204 */     this.radius3 = r3;
/* 205 */     this.phi = phi;
/* 206 */     this.theta = theta;
/* 207 */     this.psi = psi;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Point3D center() {
/* 215 */     return new Point3D(this.centerX, this.centerY, this.centerZ);
/*     */   }
/*     */ 
/*     */   
/*     */   public double radius1() {
/* 220 */     return this.radius1;
/*     */   }
/*     */ 
/*     */   
/*     */   public double radius2() {
/* 225 */     return this.radius2;
/*     */   }
/*     */ 
/*     */   
/*     */   public double radius3() {
/* 230 */     return this.radius3;
/*     */   }
/*     */ 
/*     */   
/*     */   public double phi() {
/* 235 */     return this.phi;
/*     */   }
/*     */ 
/*     */   
/*     */   public double theta() {
/* 240 */     return this.theta;
/*     */   }
/*     */ 
/*     */   
/*     */   public double psi() {
/* 245 */     return this.psi;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/geometry/Ellipsoid.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */