/*     */ package inra.ijpb.geometry;
/*     */ 
/*     */ import ij.gui.PolygonRoi;
/*     */ import java.awt.geom.Point2D;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Polygon2D
/*     */   implements Iterable<Point2D>
/*     */ {
/*     */   ArrayList<Point2D> vertices;
/*     */   
/*     */   public Polygon2D() {
/*  39 */     this.vertices = new ArrayList<Point2D>(10);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Polygon2D(int n) {
/*  51 */     this.vertices = new ArrayList<Point2D>(n);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Polygon2D(double[] xCoords, double[] yCoords) {
/*  64 */     int n = xCoords.length;
/*  65 */     if (yCoords.length != n)
/*     */     {
/*  67 */       throw new IllegalArgumentException("Coordinate arrays must have same length");
/*     */     }
/*  69 */     this.vertices = new ArrayList<Point2D>(n);
/*  70 */     for (int i = 0; i < n; i++)
/*     */     {
/*  72 */       this.vertices.add(new Point2D.Double(xCoords[i], yCoords[i]));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Polygon2D(Collection<Point2D> vertices) {
/*  85 */     this.vertices = new ArrayList<Point2D>(vertices.size());
/*  86 */     this.vertices.addAll(vertices);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Box2D boundingBox() {
/* 100 */     double xmin = Double.POSITIVE_INFINITY;
/* 101 */     double xmax = Double.NEGATIVE_INFINITY;
/* 102 */     double ymin = Double.POSITIVE_INFINITY;
/* 103 */     double ymax = Double.NEGATIVE_INFINITY;
/* 104 */     for (Point2D vertex : this.vertices) {
/*     */       
/* 106 */       double x = vertex.getX();
/* 107 */       double y = vertex.getY();
/* 108 */       xmin = Math.min(xmin, x);
/* 109 */       xmax = Math.max(xmax, x);
/* 110 */       ymin = Math.min(ymin, y);
/* 111 */       ymax = Math.max(ymax, y);
/*     */     } 
/* 113 */     return new Box2D(xmin, xmax, ymin, ymax);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double area() {
/* 125 */     return Math.abs(signedArea());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double signedArea() {
/* 137 */     double area = 0.0D;
/*     */ 
/*     */     
/* 140 */     int n = this.vertices.size();
/* 141 */     for (int i = 0; i < n; i++) {
/*     */       
/* 143 */       Point2D p1 = this.vertices.get(i);
/* 144 */       Point2D p2 = this.vertices.get((i + 1) % n);
/* 145 */       double x1 = p1.getX();
/* 146 */       double y1 = p1.getY();
/* 147 */       double x2 = p2.getX();
/* 148 */       double y2 = p2.getY();
/* 149 */       area += x1 * y2 - x2 * y1;
/*     */     } 
/*     */ 
/*     */     
/* 153 */     return area / 2.0D;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Point2D centroid() {
/* 164 */     double sumC = 0.0D;
/* 165 */     double sumX = 0.0D;
/* 166 */     double sumY = 0.0D;
/*     */ 
/*     */     
/* 169 */     int n = this.vertices.size();
/* 170 */     for (int i = 1; i <= n; i++) {
/*     */       
/* 172 */       Point2D p1 = this.vertices.get(i - 1);
/* 173 */       Point2D p2 = this.vertices.get(i % n);
/* 174 */       double x1 = p1.getX();
/* 175 */       double y1 = p1.getY();
/* 176 */       double x2 = p2.getX();
/* 177 */       double y2 = p2.getY();
/* 178 */       double common = x1 * y2 - x2 * y1;
/*     */       
/* 180 */       sumX += (x1 + x2) * common;
/* 181 */       sumY += (y1 + y2) * common;
/* 182 */       sumC += common;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 188 */     sumC *= 3.0D;
/* 189 */     return new Point2D.Double(sumX / sumC, sumY / sumC);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean contains(Point2D point) {
/* 195 */     int wn = 0;
/*     */ 
/*     */     
/* 198 */     Point2D previous = this.vertices.get(this.vertices.size() - 1);
/* 199 */     double y1 = previous.getY();
/*     */ 
/*     */ 
/*     */     
/* 203 */     double y = point.getY();
/*     */ 
/*     */     
/* 206 */     for (Point2D current : this.vertices) {
/*     */ 
/*     */       
/* 209 */       double y2 = current.getY();
/*     */       
/* 211 */       if (y1 <= y) {
/*     */         
/* 213 */         if (y2 > y && 
/* 214 */           isLeft(previous, current, point) > 0) {
/* 215 */           wn++;
/*     */         
/*     */         }
/*     */       }
/* 219 */       else if (y2 <= y && 
/* 220 */         isLeft(previous, current, point) < 0) {
/* 221 */         wn--;
/*     */       } 
/*     */ 
/*     */       
/* 225 */       y1 = y2;
/* 226 */       previous = current;
/*     */     } 
/*     */     
/* 229 */     if (signedArea() > 0.0D)
/*     */     {
/* 231 */       return (wn == 1);
/*     */     }
/*     */     
/* 234 */     return (wn == 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final int isLeft(Point2D p1, Point2D p2, Point2D pt) {
/* 259 */     double x = p1.getX();
/* 260 */     double y = p1.getY();
/* 261 */     return (int)Math.signum((
/* 262 */         p2.getX() - x) * (pt.getY() - y) - (pt.getX() - x) * (p2.getY() - y));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Polygon2D invert() {
/* 275 */     int n = this.vertices.size();
/* 276 */     Polygon2D result = new Polygon2D(n);
/* 277 */     result.addVertex(getVertex(0));
/* 278 */     for (int i = n - 1; i > 0; i--)
/*     */     {
/* 280 */       result.addVertex(this.vertices.get(i));
/*     */     }
/* 282 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PolygonRoi createRoi() {
/* 296 */     int n = this.vertices.size();
/* 297 */     float[] px = new float[n];
/* 298 */     float[] py = new float[n];
/*     */ 
/*     */     
/* 301 */     for (int i = 0; i < n; i++) {
/*     */       
/* 303 */       Point2D p = this.vertices.get(i);
/* 304 */       px[i] = (float)p.getX();
/* 305 */       py[i] = (float)p.getY();
/*     */     } 
/*     */ 
/*     */     
/* 309 */     return new PolygonRoi(px, py, n, 2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int vertexNumber() {
/* 323 */     return this.vertices.size();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int addVertex(Point2D position) {
/* 335 */     int n = this.vertices.size();
/* 336 */     this.vertices.add(position);
/* 337 */     return n;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Point2D getVertex(int index) {
/* 349 */     return this.vertices.get(index);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setVertex(int i, Point2D pos) {
/* 362 */     setVertex(i, pos);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ArrayList<Point2D> vertices() {
/* 370 */     return this.vertices;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Iterator<Point2D> iterator() {
/* 379 */     return this.vertices.iterator();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/geometry/Polygon2D.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */