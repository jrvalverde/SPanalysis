/*     */ package inra.ijpb.geometry;
/*     */ 
/*     */ import java.awt.geom.Point2D;
/*     */ import java.util.ArrayList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FeretDiameters
/*     */ {
/*     */   public static final PointPair2D maxFeretDiameter(ArrayList<? extends Point2D> points) {
/*  28 */     double distMax = Double.NEGATIVE_INFINITY;
/*  29 */     PointPair2D maxDiam = null;
/*     */     
/*  31 */     int n = points.size();
/*  32 */     for (int i1 = 0; i1 < n - 1; i1++) {
/*     */       
/*  34 */       Point2D p1 = points.get(i1);
/*  35 */       for (int i2 = i1 + 1; i2 < n; i2++) {
/*     */         
/*  37 */         Point2D p2 = points.get(i2);
/*     */         
/*  39 */         double dist = p1.distance(p2);
/*  40 */         if (dist > distMax) {
/*     */           
/*  42 */           maxDiam = new PointPair2D(p1, p2);
/*  43 */           distMax = dist;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/*  48 */     return maxDiam;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final AngleDiameterPair minFeretDiameter(ArrayList<? extends Point2D> points) {
/*  67 */     int n = points.size();
/*     */ 
/*     */     
/*  70 */     double widthMin = Double.POSITIVE_INFINITY;
/*  71 */     double angleMin = 0.0D;
/*     */ 
/*     */     
/*  74 */     for (int i = 0; i < n; i++) {
/*     */       
/*  76 */       Point2D p1 = points.get(i);
/*  77 */       Point2D p2 = points.get((i + 1) % n);
/*     */ 
/*     */       
/*  80 */       if (p1.distance(p2) >= 1.0E-12D) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*  86 */         StraightLine2D line = new StraightLine2D(p1, p2);
/*  87 */         double width = 0.0D;
/*  88 */         for (Point2D p : points) {
/*     */           
/*  90 */           double dist = line.distance(p);
/*  91 */           width = Math.max(width, dist);
/*     */         } 
/*     */ 
/*     */         
/*  95 */         if (width < widthMin) {
/*     */           
/*  97 */           widthMin = width;
/*  98 */           double dx = p2.getX() - p1.getX();
/*  99 */           double dy = p2.getY() - p1.getY();
/* 100 */           angleMin = Math.atan2(dy, dx);
/*     */         } 
/*     */       } 
/*     */     } 
/* 104 */     return new AngleDiameterPair(angleMin - 1.5707963267948966D, widthMin);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/geometry/FeretDiameters.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */