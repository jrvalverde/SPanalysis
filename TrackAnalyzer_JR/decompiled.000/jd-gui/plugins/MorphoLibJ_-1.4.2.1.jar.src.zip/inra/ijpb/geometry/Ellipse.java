/*     */ package inra.ijpb.geometry;
/*     */ 
/*     */ import java.awt.geom.Point2D;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Ellipse
/*     */ {
/*     */   private final Point2D center;
/*     */   private final double radius1;
/*     */   private final double radius2;
/*     */   private final double orientation;
/*     */   
/*     */   public static final Point2D[] centers(Ellipse[] ellipses) {
/*  28 */     Point2D[] centroids = new Point2D[ellipses.length];
/*  29 */     for (int i = 0; i < ellipses.length; i++)
/*     */     {
/*  31 */       centroids[i] = ellipses[i].center();
/*     */     }
/*  33 */     return centroids;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Ellipse(Point2D center, double radius1, double radius2, double theta) {
/*  65 */     this.center = center;
/*  66 */     this.radius1 = radius1;
/*  67 */     this.radius2 = radius2;
/*  68 */     this.orientation = theta;
/*     */   }
/*     */ 
/*     */   
/*     */   public Ellipse(double xc, double yc, double radius1, double radius2, double theta) {
/*  73 */     this.center = new Point2D.Double(xc, yc);
/*  74 */     this.radius1 = radius1;
/*  75 */     this.radius2 = radius2;
/*  76 */     this.orientation = theta;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double area() {
/*  84 */     return Math.PI * this.radius1 * this.radius2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Point2D center() {
/*  93 */     return this.center;
/*     */   }
/*     */ 
/*     */   
/*     */   public double radius1() {
/*  98 */     return this.radius1;
/*     */   }
/*     */ 
/*     */   
/*     */   public double radius2() {
/* 103 */     return this.radius2;
/*     */   }
/*     */ 
/*     */   
/*     */   public double orientation() {
/* 108 */     return this.orientation;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 118 */     return String.format("Ellipse(%f,%f,%f,%f,%f)", new Object[] { Double.valueOf(this.center.getX()), Double.valueOf(this.center.getY()), Double.valueOf(this.radius1), Double.valueOf(this.radius2), Double.valueOf(this.orientation) });
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/geometry/Ellipse.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */