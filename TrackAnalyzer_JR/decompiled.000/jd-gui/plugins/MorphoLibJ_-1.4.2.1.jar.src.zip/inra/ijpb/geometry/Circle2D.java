/*    */ package inra.ijpb.geometry;
/*    */ 
/*    */ import java.awt.geom.Point2D;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Circle2D
/*    */ {
/*    */   private final Point2D center;
/*    */   private final double radius;
/*    */   
/*    */   public Circle2D(Point2D center, double radius) {
/* 39 */     this.center = center;
/* 40 */     this.radius = radius;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public double area() {
/* 48 */     return Math.PI * this.radius * this.radius;
/*    */   }
/*    */ 
/*    */   
/*    */   public double perimeter() {
/* 53 */     return 6.283185307179586D * this.radius;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Point2D getCenter() {
/* 62 */     return this.center;
/*    */   }
/*    */ 
/*    */   
/*    */   public double getRadius() {
/* 67 */     return this.radius;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/geometry/Circle2D.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */