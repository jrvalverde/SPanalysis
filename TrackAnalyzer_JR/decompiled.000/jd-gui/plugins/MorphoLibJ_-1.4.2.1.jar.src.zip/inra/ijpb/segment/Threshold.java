/*     */ package inra.ijpb.segment;
/*     */ 
/*     */ import ij.ImagePlus;
/*     */ import ij.ImageStack;
/*     */ import ij.process.ByteProcessor;
/*     */ import ij.process.ImageProcessor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Threshold
/*     */ {
/*     */   public static final ImagePlus threshold(ImagePlus image, double lower, double upper) {
/*  59 */     String newName = String.valueOf(image.getShortTitle()) + "-bin";
/*  60 */     if (image.getStackSize() == 1) {
/*     */       
/*  62 */       ImageProcessor imageProcessor = threshold(image.getProcessor(), lower, upper);
/*  63 */       return new ImagePlus(newName, imageProcessor);
/*     */     } 
/*     */ 
/*     */     
/*  67 */     ImageStack result = threshold(image.getStack(), lower, upper);
/*  68 */     return new ImagePlus(newName, result);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final ImageProcessor threshold(ImageProcessor image, double lower, double upper) {
/*  86 */     if (image instanceof ij.process.ColorProcessor)
/*     */     {
/*  88 */       throw new IllegalArgumentException("Requires a gray scale image");
/*     */     }
/*     */     
/*  91 */     int width = image.getWidth();
/*  92 */     int height = image.getHeight();
/*     */     
/*  94 */     ByteProcessor byteProcessor = new ByteProcessor(width, height);
/*  95 */     for (int y = 0; y < height; y++) {
/*     */       
/*  97 */       for (int x = 0; x < width; x++) {
/*     */         
/*  99 */         double value = image.getf(x, y);
/* 100 */         if (value >= lower && value <= upper) {
/* 101 */           byteProcessor.set(x, y, 255);
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 106 */     return (ImageProcessor)byteProcessor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final ImageStack threshold(ImageStack image, double lower, double upper) {
/* 123 */     int sizeX = image.getWidth();
/* 124 */     int sizeY = image.getHeight();
/* 125 */     int sizeZ = image.getSize();
/*     */     
/* 127 */     ImageStack result = ImageStack.create(sizeX, sizeY, sizeZ, 8);
/* 128 */     for (int z = 0; z < sizeZ; z++) {
/*     */       
/* 130 */       for (int y = 0; y < sizeY; y++) {
/*     */         
/* 132 */         for (int x = 0; x < sizeX; x++) {
/*     */           
/* 134 */           double value = image.getVoxel(x, y, z);
/* 135 */           if (value >= lower && value <= upper) {
/* 136 */             result.setVoxel(x, y, z, 255.0D);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/* 141 */     return result;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/segment/Threshold.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */