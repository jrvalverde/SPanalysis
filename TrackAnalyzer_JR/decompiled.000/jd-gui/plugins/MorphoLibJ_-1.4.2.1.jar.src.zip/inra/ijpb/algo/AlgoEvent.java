/*     */ package inra.ijpb.algo;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AlgoEvent
/*     */ {
/*     */   protected Object source;
/*     */   protected String status;
/*     */   protected double step;
/*     */   protected double total;
/*     */   
/*     */   public AlgoEvent(Object source, String status, double step, double total) {
/*  45 */     this.source = source;
/*  46 */     this.status = status;
/*  47 */     this.step = step;
/*  48 */     this.total = total;
/*     */   }
/*     */ 
/*     */   
/*     */   public AlgoEvent(Object source, String status) {
/*  53 */     this.source = source;
/*  54 */     this.status = status;
/*  55 */     this.step = 0.0D;
/*  56 */     this.total = 0.0D;
/*     */   }
/*     */ 
/*     */   
/*     */   public AlgoEvent(Object source, double step, double total) {
/*  61 */     this.source = source;
/*  62 */     this.status = "";
/*  63 */     this.step = step;
/*  64 */     this.total = total;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getSource() {
/*  72 */     return this.source;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getStatus() {
/*  80 */     return this.status;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getCurrentProgress() {
/*  88 */     return this.step;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getTotalProgress() {
/*  96 */     return this.total;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getProgressRatio() {
/* 104 */     return this.step / this.total;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/algo/AlgoEvent.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */