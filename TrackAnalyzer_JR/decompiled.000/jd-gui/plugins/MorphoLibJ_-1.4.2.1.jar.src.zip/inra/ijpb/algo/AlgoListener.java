package inra.ijpb.algo;

public interface AlgoListener {
  void algoProgressChanged(AlgoEvent paramAlgoEvent);
  
  void algoStatusChanged(AlgoEvent paramAlgoEvent);
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/algo/AlgoListener.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */