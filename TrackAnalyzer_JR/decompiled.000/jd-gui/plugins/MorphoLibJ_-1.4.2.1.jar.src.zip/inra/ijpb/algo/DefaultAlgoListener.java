/*    */ package inra.ijpb.algo;
/*    */ 
/*    */ import ij.IJ;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DefaultAlgoListener
/*    */   implements AlgoListener
/*    */ {
/*    */   public static final void monitor(Algo algo) {
/* 68 */     DefaultAlgoListener dal = new DefaultAlgoListener();
/* 69 */     algo.addAlgoListener(dal);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void algoProgressChanged(AlgoEvent evt) {
/* 78 */     IJ.showProgress(evt.getProgressRatio());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void algoStatusChanged(AlgoEvent evt) {
/* 87 */     IJ.showStatus(evt.getStatus());
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/algo/DefaultAlgoListener.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */