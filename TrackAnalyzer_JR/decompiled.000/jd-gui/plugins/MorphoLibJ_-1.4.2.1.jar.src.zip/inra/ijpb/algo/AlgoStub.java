/*    */ package inra.ijpb.algo;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AlgoStub
/*    */   implements Algo
/*    */ {
/* 36 */   private ArrayList<AlgoListener> algoListeners = new ArrayList<AlgoListener>();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void addAlgoListener(AlgoListener listener) {
/* 45 */     this.algoListeners.add(listener);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void removeAlgoListener(AlgoListener listener) {
/* 51 */     this.algoListeners.remove(listener);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected void fireProgressChanged(Object source, double step, double total) {
/* 60 */     if (!this.algoListeners.isEmpty()) {
/*    */       
/* 62 */       AlgoEvent evt = new AlgoEvent(source, step, total);
/* 63 */       for (AlgoListener listener : this.algoListeners)
/*    */       {
/* 65 */         listener.algoProgressChanged(evt);
/*    */       }
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   protected void fireProgressChanged(AlgoEvent evt) {
/* 72 */     for (AlgoListener listener : this.algoListeners)
/*    */     {
/* 74 */       listener.algoProgressChanged(evt);
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   protected void fireStatusChanged(Object source, String message) {
/* 80 */     if (!this.algoListeners.isEmpty()) {
/*    */       
/* 82 */       AlgoEvent evt = new AlgoEvent(source, message);
/* 83 */       for (AlgoListener listener : this.algoListeners)
/*    */       {
/* 85 */         listener.algoStatusChanged(evt);
/*    */       }
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   protected void fireStatusChanged(AlgoEvent evt) {
/* 92 */     for (AlgoListener listener : this.algoListeners)
/*    */     {
/* 94 */       listener.algoStatusChanged(evt);
/*    */     }
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/algo/AlgoStub.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */