/*     */ package inra.ijpb.morphology.strel;
/*     */ 
/*     */ import ij.process.ImageProcessor;
/*     */ import inra.ijpb.morphology.Strel;
/*     */ import inra.ijpb.morphology.Strel3D;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Cross3x3Strel
/*     */   extends AbstractInPlaceStrel
/*     */ {
/*     */   public int[] getSize() {
/*  41 */     return new int[] { 3, 3 };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int[][] getMask() {
/*  49 */     int[][] mask = new int[3][];
/*  50 */     (new int[3])[1] = 255; mask[0] = new int[3];
/*  51 */     (new int[3])[0] = 255; (new int[3])[1] = 255; (new int[3])[2] = 255; mask[1] = new int[3];
/*  52 */     (new int[3])[1] = 255; mask[2] = new int[3];
/*  53 */     return mask;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int[] getOffset() {
/*  61 */     return new int[] { 1, 1 };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int[][] getShifts() {
/*  69 */     int[][] shifts = {
/*  70 */         { 0, -1
/*  71 */         }, { -1
/*  72 */         }, new int[2], {
/*  73 */           1
/*  74 */         }, { 0, 1 } };
/*  75 */     return shifts;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InPlaceStrel reverse() {
/*  84 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void inPlaceDilation(ImageProcessor image) {
/*  92 */     if (image instanceof ij.process.ByteProcessor) {
/*  93 */       inPlaceDilationGray8(image);
/*     */     } else {
/*  95 */       inPlaceDilationFloat(image);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void inPlaceDilationGray8(ImageProcessor image) {
/* 100 */     int width = image.getWidth();
/* 101 */     int height = image.getHeight();
/*     */     
/* 103 */     int[][] buffer = new int[3][width];
/*     */ 
/*     */     
/* 106 */     for (int x = 0; x < width; x++) {
/* 107 */       buffer[0][x] = 0;
/* 108 */       buffer[1][x] = 0;
/* 109 */       buffer[2][x] = image.get(x, 0);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 114 */     for (int y = 0; y < height; y++) {
/* 115 */       fireProgressChanged(this, y, height);
/*     */ 
/*     */       
/* 118 */       int[] tmp = buffer[0];
/* 119 */       buffer[0] = buffer[1];
/* 120 */       buffer[1] = buffer[2];
/*     */ 
/*     */       
/* 123 */       if (y < height - 1) {
/* 124 */         for (int j = 0; j < width; j++)
/* 125 */           tmp[j] = image.get(j, y + 1); 
/*     */       } else {
/* 127 */         for (int j = 0; j < width; j++)
/* 128 */           tmp[j] = 0; 
/*     */       } 
/* 130 */       buffer[2] = tmp;
/*     */ 
/*     */       
/* 133 */       int valMax = max5(buffer[0][0], buffer[1][0], 
/* 134 */           buffer[1][1], buffer[2][0], 0);
/* 135 */       image.set(0, y, valMax);
/*     */ 
/*     */       
/* 138 */       for (int i = 1; i < width - 1; i++) {
/* 139 */         valMax = max5(buffer[0][i], buffer[1][i - 1], buffer[1][i], 
/* 140 */             buffer[1][i + 1], buffer[2][i]);
/* 141 */         image.set(i, y, valMax);
/*     */       } 
/*     */ 
/*     */       
/* 145 */       valMax = max5(buffer[0][width - 1], buffer[1][width - 2], 
/* 146 */           buffer[1][width - 1], buffer[2][width - 1], 0);
/* 147 */       image.set(width - 1, y, valMax);
/*     */     } 
/*     */ 
/*     */     
/* 151 */     fireProgressChanged(this, height, height);
/*     */   }
/*     */ 
/*     */   
/*     */   private void inPlaceDilationFloat(ImageProcessor image) {
/* 156 */     int width = image.getWidth();
/* 157 */     int height = image.getHeight();
/*     */     
/* 159 */     float[][] buffer = new float[3][width];
/*     */ 
/*     */     
/* 162 */     for (int x = 0; x < width; x++) {
/* 163 */       buffer[0][x] = Float.NEGATIVE_INFINITY;
/* 164 */       buffer[1][x] = Float.NEGATIVE_INFINITY;
/* 165 */       buffer[2][x] = image.getf(x, 0);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 170 */     for (int y = 0; y < height; y++) {
/* 171 */       fireProgressChanged(this, y, height);
/*     */ 
/*     */       
/* 174 */       float[] tmp = buffer[0];
/* 175 */       buffer[0] = buffer[1];
/* 176 */       buffer[1] = buffer[2];
/*     */ 
/*     */       
/* 179 */       if (y < height - 1) {
/* 180 */         for (int j = 0; j < width; j++)
/* 181 */           tmp[j] = image.getf(j, y + 1); 
/*     */       } else {
/* 183 */         for (int j = 0; j < width; j++)
/* 184 */           tmp[j] = Float.NEGATIVE_INFINITY; 
/*     */       } 
/* 186 */       buffer[2] = tmp;
/*     */ 
/*     */       
/* 189 */       float valMax = max5(buffer[0][0], buffer[1][0], 
/* 190 */           buffer[1][1], buffer[2][0], Float.NEGATIVE_INFINITY);
/* 191 */       image.setf(0, y, valMax);
/*     */ 
/*     */       
/* 194 */       for (int i = 1; i < width - 1; i++) {
/* 195 */         valMax = max5(buffer[0][i], buffer[1][i - 1], buffer[1][i], 
/* 196 */             buffer[1][i + 1], buffer[2][i]);
/* 197 */         image.setf(i, y, valMax);
/*     */       } 
/*     */ 
/*     */       
/* 201 */       valMax = max5(buffer[0][width - 1], buffer[1][width - 2], 
/* 202 */           buffer[1][width - 1], buffer[2][width - 1], Float.NEGATIVE_INFINITY);
/* 203 */       image.setf(width - 1, y, valMax);
/*     */     } 
/*     */ 
/*     */     
/* 207 */     fireProgressChanged(this, height, height);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final int max5(int v1, int v2, int v3, int v4, int v5) {
/* 215 */     int max1 = Math.max(v1, v2);
/* 216 */     int max2 = Math.max(v3, v4);
/* 217 */     max1 = Math.max(max1, v5);
/* 218 */     return Math.max(max1, max2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final float max5(float v1, float v2, float v3, float v4, float v5) {
/* 225 */     float max1 = Math.max(v1, v2);
/* 226 */     float max2 = Math.max(v3, v4);
/* 227 */     max1 = Math.max(max1, v5);
/* 228 */     return Math.max(max1, max2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void inPlaceErosion(ImageProcessor image) {
/* 236 */     if (image instanceof ij.process.ByteProcessor) {
/* 237 */       inPlaceErosionGray8(image);
/*     */     } else {
/* 239 */       inPlaceErosionFloat(image);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void inPlaceErosionGray8(ImageProcessor image) {
/* 244 */     int width = image.getWidth();
/* 245 */     int height = image.getHeight();
/*     */     
/* 247 */     int[][] buffer = new int[3][width];
/*     */ 
/*     */     
/* 250 */     for (int x = 0; x < width; x++) {
/* 251 */       buffer[0][x] = 255;
/* 252 */       buffer[1][x] = 255;
/* 253 */       buffer[2][x] = image.get(x, 0);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 258 */     for (int y = 0; y < height; y++) {
/* 259 */       fireProgressChanged(this, y, height);
/*     */ 
/*     */       
/* 262 */       int[] tmp = buffer[0];
/* 263 */       buffer[0] = buffer[1];
/* 264 */       buffer[1] = buffer[2];
/*     */ 
/*     */       
/* 267 */       if (y < height - 1) {
/* 268 */         for (int j = 0; j < width; j++)
/* 269 */           tmp[j] = image.get(j, y + 1); 
/*     */       } else {
/* 271 */         for (int j = 0; j < width; j++)
/* 272 */           tmp[j] = 255; 
/*     */       } 
/* 274 */       buffer[2] = tmp;
/*     */ 
/*     */       
/* 277 */       int valMin = min5(buffer[0][0], buffer[1][0], 
/* 278 */           buffer[1][1], buffer[2][0], 255);
/* 279 */       image.set(0, y, valMin);
/*     */ 
/*     */       
/* 282 */       for (int i = 1; i < width - 1; i++) {
/* 283 */         valMin = min5(buffer[0][i], buffer[1][i - 1], buffer[1][i], 
/* 284 */             buffer[1][i + 1], buffer[2][i]);
/* 285 */         image.set(i, y, valMin);
/*     */       } 
/*     */ 
/*     */       
/* 289 */       valMin = min5(buffer[0][width - 1], buffer[1][width - 2], 
/* 290 */           buffer[1][width - 1], buffer[2][width - 1], 255);
/* 291 */       image.set(width - 1, y, valMin);
/*     */     } 
/*     */ 
/*     */     
/* 295 */     fireProgressChanged(this, height, height);
/*     */   }
/*     */ 
/*     */   
/*     */   private void inPlaceErosionFloat(ImageProcessor image) {
/* 300 */     int width = image.getWidth();
/* 301 */     int height = image.getHeight();
/*     */     
/* 303 */     float[][] buffer = new float[3][width];
/*     */ 
/*     */     
/* 306 */     for (int x = 0; x < width; x++) {
/* 307 */       buffer[0][x] = Float.POSITIVE_INFINITY;
/* 308 */       buffer[1][x] = Float.POSITIVE_INFINITY;
/* 309 */       buffer[2][x] = image.getf(x, 0);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 314 */     for (int y = 0; y < height; y++) {
/* 315 */       fireProgressChanged(this, y, height);
/*     */ 
/*     */       
/* 318 */       float[] tmp = buffer[0];
/* 319 */       buffer[0] = buffer[1];
/* 320 */       buffer[1] = buffer[2];
/*     */ 
/*     */       
/* 323 */       if (y < height - 1) {
/* 324 */         for (int j = 0; j < width; j++)
/* 325 */           tmp[j] = image.get(j, y + 1); 
/*     */       } else {
/* 327 */         for (int j = 0; j < width; j++)
/* 328 */           tmp[j] = Float.POSITIVE_INFINITY; 
/*     */       } 
/* 330 */       buffer[2] = tmp;
/*     */ 
/*     */       
/* 333 */       float valMin = min5(buffer[0][0], buffer[1][0], 
/* 334 */           buffer[1][1], buffer[2][0], Float.POSITIVE_INFINITY);
/* 335 */       image.setf(0, y, valMin);
/*     */ 
/*     */       
/* 338 */       for (int i = 1; i < width - 1; i++) {
/* 339 */         valMin = min5(buffer[0][i], buffer[1][i - 1], buffer[1][i], 
/* 340 */             buffer[1][i + 1], buffer[2][i]);
/* 341 */         image.setf(i, y, valMin);
/*     */       } 
/*     */ 
/*     */       
/* 345 */       valMin = min5(buffer[0][width - 1], buffer[1][width - 2], 
/* 346 */           buffer[1][width - 1], buffer[2][width - 1], Float.POSITIVE_INFINITY);
/* 347 */       image.setf(width - 1, y, valMin);
/*     */     } 
/*     */ 
/*     */     
/* 351 */     fireProgressChanged(this, height, height);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final int min5(int v1, int v2, int v3, int v4, int v5) {
/* 358 */     int min1 = Math.min(v1, v2);
/* 359 */     int min2 = Math.min(v3, v4);
/* 360 */     min1 = Math.min(min1, v5);
/* 361 */     return Math.min(min1, min2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final float min5(float v1, float v2, float v3, float v4, float v5) {
/* 368 */     float min1 = Math.min(v1, v2);
/* 369 */     float min2 = Math.min(v3, v4);
/* 370 */     min1 = Math.min(min1, v5);
/* 371 */     return Math.min(min1, min2);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/morphology/strel/Cross3x3Strel.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */