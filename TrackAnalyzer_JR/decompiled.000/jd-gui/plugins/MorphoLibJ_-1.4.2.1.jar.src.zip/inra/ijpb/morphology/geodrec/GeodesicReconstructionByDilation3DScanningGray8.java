/*     */ package inra.ijpb.morphology.geodrec;
/*     */ 
/*     */ import ij.ImageStack;
/*     */ import inra.ijpb.data.image.Images3D;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GeodesicReconstructionByDilation3DScanningGray8
/*     */   extends GeodesicReconstruction3DAlgoStub
/*     */ {
/*     */   ImageStack marker;
/*     */   ImageStack mask;
/*     */   ImageStack result;
/*  51 */   int sizeX = 0;
/*     */   
/*  53 */   int sizeY = 0;
/*     */   
/*  55 */   int sizeZ = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean modif;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GeodesicReconstructionByDilation3DScanningGray8() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GeodesicReconstructionByDilation3DScanningGray8(int connectivity) {
/*  80 */     this.connectivity = connectivity;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ImageStack applyTo(ImageStack marker, ImageStack mask) {
/*  90 */     this.marker = marker;
/*  91 */     this.mask = mask;
/*     */ 
/*     */     
/*  94 */     if (marker.getBitDepth() != 8 || mask.getBitDepth() != 8)
/*     */     {
/*  96 */       throw new IllegalArgumentException("Marker and Mask images must be byte stacks");
/*     */     }
/*     */ 
/*     */     
/* 100 */     this.sizeX = marker.getWidth();
/* 101 */     this.sizeY = marker.getHeight();
/* 102 */     this.sizeZ = marker.getSize();
/* 103 */     if (!Images3D.isSameSize(marker, mask))
/*     */     {
/* 105 */       throw new IllegalArgumentException("Marker and Mask images must have the same size");
/*     */     }
/*     */ 
/*     */     
/* 109 */     if (this.connectivity != 6 && this.connectivity != 26)
/*     */     {
/* 111 */       throw new RuntimeException(
/* 112 */           "Connectivity for stacks must be either 6 or 26, not " + 
/* 113 */           this.connectivity);
/*     */     }
/*     */     
/* 116 */     initializeResult();
/*     */ 
/*     */     
/* 119 */     int iter = 1;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     do {
/* 125 */       this.modif = false;
/*     */ 
/*     */       
/* 128 */       trace("Forward iteration " + iter);
/* 129 */       showStatus("Geod. Rec. by Dil. Fwd " + iter);
/*     */ 
/*     */       
/* 132 */       switch (this.connectivity) {
/*     */         
/*     */         case 6:
/* 135 */           forwardDilationC6();
/*     */           break;
/*     */         case 26:
/* 138 */           forwardDilationC26();
/*     */           break;
/*     */       } 
/*     */ 
/*     */       
/* 143 */       trace("Backward iteration " + iter);
/* 144 */       showStatus("Geod. Rec. by Dil. Bwd " + iter);
/*     */ 
/*     */       
/* 147 */       switch (this.connectivity) {
/*     */         
/*     */         case 6:
/* 150 */           backwardDilationC6();
/*     */           break;
/*     */         case 26:
/* 153 */           backwardDilationC26();
/*     */           break;
/*     */       } 
/*     */       
/* 157 */       iter++;
/* 158 */     } while (this.modif);
/*     */ 
/*     */     
/* 161 */     showProgress(1.0D, 1.0D, "");
/*     */     
/* 163 */     return this.result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ImageStack applyTo(ImageStack marker, ImageStack mask, ImageStack binaryMask) {
/* 176 */     this.marker = marker;
/* 177 */     this.mask = mask;
/*     */ 
/*     */     
/* 180 */     this.sizeX = marker.getWidth();
/* 181 */     this.sizeY = marker.getHeight();
/* 182 */     this.sizeZ = marker.getSize();
/* 183 */     if (!Images3D.isSameSize(marker, mask))
/*     */     {
/* 185 */       throw new IllegalArgumentException("Marker and Mask images must have the same size");
/*     */     }
/*     */ 
/*     */     
/* 189 */     if (this.connectivity != 6 && this.connectivity != 26)
/*     */     {
/* 191 */       throw new RuntimeException(
/* 192 */           "Connectivity for stacks must be either 6 or 26, not " + 
/* 193 */           this.connectivity);
/*     */     }
/*     */     
/* 196 */     initializeResult(binaryMask);
/*     */ 
/*     */     
/* 199 */     int iter = 1;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     do {
/* 205 */       this.modif = false;
/*     */ 
/*     */       
/* 208 */       trace("Forward iteration " + iter);
/* 209 */       showStatus("Geod. Rec. by Dil. Fwd " + iter);
/*     */ 
/*     */       
/* 212 */       switch (this.connectivity) {
/*     */         
/*     */         case 6:
/* 215 */           forwardDilationC6(binaryMask);
/*     */           break;
/*     */         case 26:
/* 218 */           forwardDilationC26(binaryMask);
/*     */           break;
/*     */       } 
/*     */ 
/*     */       
/* 223 */       trace("Backward iteration " + iter);
/* 224 */       showStatus("Geod. Rec. by Dil. Bwd " + iter);
/*     */ 
/*     */       
/* 227 */       switch (this.connectivity) {
/*     */         
/*     */         case 6:
/* 230 */           backwardDilationC6(binaryMask);
/*     */           break;
/*     */         case 26:
/* 233 */           backwardDilationC26(binaryMask);
/*     */           break;
/*     */       } 
/*     */       
/* 237 */       iter++;
/* 238 */     } while (this.modif);
/*     */     
/* 240 */     return this.result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void initializeResult() {
/* 251 */     this.result = ImageStack.create(this.sizeX, this.sizeY, this.sizeZ, this.mask.getBitDepth());
/*     */     
/* 253 */     Object[] stack = this.result.getImageArray();
/* 254 */     Object[] markerStack = this.marker.getImageArray();
/* 255 */     Object[] maskStack = this.mask.getImageArray();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 262 */     for (int z = 0; z < this.sizeZ; z++) {
/*     */       
/* 264 */       byte[] slice = (byte[])stack[z];
/* 265 */       byte[] maskSlice = (byte[])maskStack[z];
/* 266 */       byte[] markerSlice = (byte[])markerStack[z];
/*     */       
/* 268 */       for (int y = 0; y < this.sizeY; y++) {
/*     */         
/* 270 */         for (int x = 0; x < this.sizeX; x++) {
/*     */           
/* 272 */           int index = y * this.sizeX + x;
/* 273 */           int value = Math.min(markerSlice[index] & 0xFF, maskSlice[index] & 0xFF);
/* 274 */           slice[index] = (byte)value;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void initializeResult(ImageStack binaryMask) {
/* 287 */     this.result = ImageStack.create(this.sizeX, this.sizeY, this.sizeZ, this.mask.getBitDepth());
/*     */     
/* 289 */     Object[] stack = this.result.getImageArray();
/* 290 */     Object[] markerStack = this.marker.getImageArray();
/* 291 */     Object[] maskStack = this.mask.getImageArray();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 298 */     for (int z = 0; z < this.sizeZ; z++) {
/*     */       
/* 300 */       byte[] slice = (byte[])stack[z];
/* 301 */       byte[] maskSlice = (byte[])maskStack[z];
/* 302 */       byte[] markerSlice = (byte[])markerStack[z];
/*     */       
/* 304 */       for (int y = 0; y < this.sizeY; y++) {
/*     */         
/* 306 */         for (int x = 0; x < this.sizeX; x++) {
/*     */           
/* 308 */           if (binaryMask.getVoxel(x, y, z) != 0.0D) {
/*     */             
/* 310 */             int index = y * this.sizeX + x;
/* 311 */             int value = Math.min(markerSlice[index] & 0xFF, maskSlice[index] & 0xFF);
/* 312 */             slice[index] = (byte)value;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void forwardDilationC6() {
/* 329 */     Object[] stack = this.result.getImageArray();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 334 */     for (int z = 0; z < this.sizeZ; z++) {
/*     */       
/* 336 */       showProgress(z, this.sizeZ, "z = " + z);
/*     */       
/* 338 */       byte[] slice = (byte[])stack[z];
/* 339 */       for (int y = 0; y < this.sizeY; y++) {
/*     */         
/* 341 */         for (int x = 0; x < this.sizeX; x++) {
/*     */           
/* 343 */           int currentValue = slice[y * this.sizeX + x] & 0xFF;
/* 344 */           int maxValue = currentValue;
/*     */ 
/*     */           
/* 347 */           if (x > 0)
/* 348 */             maxValue = Math.max(maxValue, slice[y * this.sizeX + x - 1] & 0xFF); 
/* 349 */           if (y > 0)
/* 350 */             maxValue = Math.max(maxValue, slice[(y - 1) * this.sizeX + x] & 0xFF); 
/* 351 */           if (z > 0) {
/* 352 */             byte[] slice2 = (byte[])stack[z - 1];
/* 353 */             maxValue = Math.max(maxValue, slice2[y * this.sizeX + x] & 0xFF);
/*     */           } 
/*     */ 
/*     */           
/* 357 */           maxValue = Math.min(maxValue, (int)this.mask.getVoxel(x, y, z));
/* 358 */           if (maxValue > currentValue) {
/*     */             
/* 360 */             slice[y * this.sizeX + x] = (byte)(maxValue & 0xFF);
/* 361 */             this.modif = true;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void forwardDilationC6(ImageStack binaryMask) {
/* 377 */     Object[] stack = this.result.getImageArray();
/* 378 */     Object[] binaryStack = binaryMask.getImageArray();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 384 */     for (int z = 0; z < this.sizeZ; z++) {
/*     */       
/* 386 */       showProgress(z, this.sizeZ, "z = " + z);
/*     */       
/* 388 */       byte[] slice = (byte[])stack[z];
/* 389 */       byte[] binarySlice = (byte[])binaryStack[z];
/*     */       
/* 391 */       for (int y = 0; y < this.sizeY; y++) {
/*     */         
/* 393 */         for (int x = 0; x < this.sizeX; x++) {
/*     */           
/* 395 */           if (binarySlice[y * this.sizeX + x] != 0) {
/*     */             
/* 397 */             int currentValue = slice[y * this.sizeX + x] & 0xFF;
/* 398 */             int maxValue = currentValue;
/*     */ 
/*     */             
/* 401 */             if (x > 0)
/* 402 */               maxValue = Math.max(maxValue, slice[y * this.sizeX + x - 1] & 0xFF); 
/* 403 */             if (y > 0)
/* 404 */               maxValue = Math.max(maxValue, slice[(y - 1) * this.sizeX + x] & 0xFF); 
/* 405 */             if (z > 0) {
/*     */               
/* 407 */               byte[] slice2 = (byte[])stack[z - 1];
/* 408 */               maxValue = Math.max(maxValue, slice2[y * this.sizeX + x] & 0xFF);
/*     */             } 
/*     */ 
/*     */             
/* 412 */             maxValue = Math.min(maxValue, (int)this.mask.getVoxel(x, y, z));
/* 413 */             if (maxValue > currentValue) {
/*     */               
/* 415 */               slice[y * this.sizeX + x] = (byte)(maxValue & 0xFF);
/* 416 */               this.modif = true;
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void forwardDilationC26() {
/* 434 */     Object[] stack = this.result.getImageArray();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 439 */     for (int z = 0; z < this.sizeZ; z++) {
/*     */       
/* 441 */       showProgress(z, this.sizeZ, "z = " + z);
/*     */       
/* 443 */       byte[] slice = (byte[])stack[z];
/* 444 */       for (int y = 0; y < this.sizeY; y++) {
/*     */         
/* 446 */         for (int x = 0; x < this.sizeX; x++) {
/*     */           
/* 448 */           int currentValue = slice[y * this.sizeX + x] & 0xFF;
/* 449 */           int maxValue = currentValue;
/*     */ 
/*     */           
/* 452 */           int zmax = Math.min(z + 1, this.sizeZ);
/* 453 */           for (int z2 = Math.max(z - 1, 0); z2 < zmax; z2++) {
/*     */             
/* 455 */             byte[] slice2 = (byte[])stack[z2];
/*     */             
/* 457 */             int ymax = (z2 == z) ? y : Math.min(y + 1, this.sizeY - 1);
/* 458 */             for (int y2 = Math.max(y - 1, 0); y2 <= ymax; y2++) {
/*     */               
/* 460 */               int xmax = (z2 == z && y2 == y) ? (x - 1) : Math.min(x + 1, this.sizeX - 1);
/* 461 */               for (int x2 = Math.max(x - 1, 0); x2 <= xmax; x2++) {
/*     */                 
/* 463 */                 int neighborValue = slice2[y2 * this.sizeX + x2] & 0xFF;
/* 464 */                 if (neighborValue > maxValue) {
/* 465 */                   maxValue = neighborValue;
/*     */                 }
/*     */               } 
/*     */             } 
/*     */           } 
/*     */           
/* 471 */           maxValue = Math.min(maxValue, (int)this.mask.getVoxel(x, y, z));
/* 472 */           if (maxValue > currentValue) {
/*     */             
/* 474 */             slice[y * this.sizeX + x] = (byte)(maxValue & 0xFF);
/* 475 */             this.modif = true;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void forwardDilationC26(ImageStack binaryMask) {
/* 492 */     Object[] stack = this.result.getImageArray();
/* 493 */     Object[] binaryStack = binaryMask.getImageArray();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 499 */     for (int z = 0; z < this.sizeZ; z++) {
/*     */       
/* 501 */       showProgress(z, this.sizeZ, "z = " + z);
/*     */       
/* 503 */       byte[] slice = (byte[])stack[z];
/* 504 */       byte[] binarySlice = (byte[])binaryStack[z];
/*     */       
/* 506 */       for (int y = 0; y < this.sizeY; y++) {
/*     */         
/* 508 */         for (int x = 0; x < this.sizeX; x++) {
/*     */           
/* 510 */           if (binarySlice[y * this.sizeX + x] != 0) {
/*     */             
/* 512 */             int currentValue = slice[y * this.sizeX + x] & 0xFF;
/* 513 */             int maxValue = currentValue;
/*     */ 
/*     */             
/* 516 */             int zmax = Math.min(z + 1, this.sizeZ);
/* 517 */             for (int z2 = Math.max(z - 1, 0); z2 < zmax; z2++) {
/*     */               
/* 519 */               byte[] slice2 = (byte[])stack[z2];
/*     */               
/* 521 */               int ymax = (z2 == z) ? y : Math.min(y + 1, this.sizeY - 1);
/* 522 */               for (int y2 = Math.max(y - 1, 0); y2 <= ymax; y2++) {
/*     */                 
/* 524 */                 int xmax = (z2 == z && y2 == y) ? (x - 1) : Math.min(x + 1, this.sizeX - 1);
/* 525 */                 for (int x2 = Math.max(x - 1, 0); x2 <= xmax; x2++) {
/*     */                   
/* 527 */                   int neighborValue = slice2[y2 * this.sizeX + x2] & 0xFF;
/* 528 */                   if (neighborValue > maxValue) {
/* 529 */                     maxValue = neighborValue;
/*     */                   }
/*     */                 } 
/*     */               } 
/*     */             } 
/*     */             
/* 535 */             maxValue = Math.min(maxValue, (int)this.mask.getVoxel(x, y, z));
/* 536 */             if (maxValue > currentValue) {
/*     */               
/* 538 */               slice[y * this.sizeX + x] = (byte)(maxValue & 0xFF);
/* 539 */               this.modif = true;
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void backwardDilationC6() {
/* 557 */     Object[] stack = this.result.getImageArray();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 562 */     for (int z = this.sizeZ - 1; z >= 0; z--) {
/*     */       
/* 564 */       showProgress((this.sizeZ - 1 - z), this.sizeZ, "z = " + z);
/*     */       
/* 566 */       byte[] slice = (byte[])stack[z];
/* 567 */       for (int y = this.sizeY - 1; y >= 0; y--) {
/*     */         
/* 569 */         for (int x = this.sizeX - 1; x >= 0; x--) {
/*     */           
/* 571 */           int currentValue = slice[y * this.sizeX + x] & 0xFF;
/* 572 */           int maxValue = currentValue;
/*     */ 
/*     */           
/* 575 */           if (x < this.sizeX - 1)
/* 576 */             maxValue = Math.max(maxValue, slice[y * this.sizeX + x + 1] & 0xFF); 
/* 577 */           if (y < this.sizeY - 1)
/* 578 */             maxValue = Math.max(maxValue, slice[(y + 1) * this.sizeX + x] & 0xFF); 
/* 579 */           if (z < this.sizeZ - 1) {
/*     */             
/* 581 */             byte[] slice2 = (byte[])stack[z + 1];
/* 582 */             maxValue = Math.max(maxValue, slice2[y * this.sizeX + x] & 0xFF);
/*     */           } 
/*     */ 
/*     */           
/* 586 */           maxValue = Math.min(maxValue, (int)this.mask.getVoxel(x, y, z));
/* 587 */           if (maxValue > currentValue) {
/*     */             
/* 589 */             slice[y * this.sizeX + x] = (byte)(maxValue & 0xFF);
/* 590 */             this.modif = true;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void backwardDilationC6(ImageStack binaryMask) {
/* 606 */     Object[] stack = this.result.getImageArray();
/* 607 */     Object[] binaryStack = binaryMask.getImageArray();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 613 */     for (int z = this.sizeZ - 1; z >= 0; z--) {
/*     */       
/* 615 */       showProgress((this.sizeZ - 1 - z), this.sizeZ, "z = " + z);
/*     */       
/* 617 */       byte[] slice = (byte[])stack[z];
/* 618 */       byte[] binarySlice = (byte[])binaryStack[z];
/*     */       
/* 620 */       for (int y = this.sizeY - 1; y >= 0; y--) {
/*     */         
/* 622 */         for (int x = this.sizeX - 1; x >= 0; x--) {
/*     */           
/* 624 */           if (binarySlice[y * this.sizeX + x] != 0) {
/*     */             
/* 626 */             int currentValue = slice[y * this.sizeX + x] & 0xFF;
/* 627 */             int maxValue = currentValue;
/*     */ 
/*     */             
/* 630 */             if (x < this.sizeX - 1)
/* 631 */               maxValue = Math.max(maxValue, slice[y * this.sizeX + x + 1] & 0xFF); 
/* 632 */             if (y < this.sizeY - 1)
/* 633 */               maxValue = Math.max(maxValue, slice[(y + 1) * this.sizeX + x] & 0xFF); 
/* 634 */             if (z < this.sizeZ - 1) {
/*     */               
/* 636 */               byte[] slice2 = (byte[])stack[z + 1];
/* 637 */               maxValue = Math.max(maxValue, slice2[y * this.sizeX + x] & 0xFF);
/*     */             } 
/*     */ 
/*     */             
/* 641 */             maxValue = Math.min(maxValue, (int)this.mask.getVoxel(x, y, z));
/* 642 */             if (maxValue > currentValue) {
/*     */               
/* 644 */               slice[y * this.sizeX + x] = (byte)(maxValue & 0xFF);
/* 645 */               this.modif = true;
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void backwardDilationC26(ImageStack binaryMask) {
/* 662 */     Object[] stack = this.result.getImageArray();
/* 663 */     Object[] binaryStack = binaryMask.getImageArray();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 669 */     for (int z = this.sizeZ - 1; z >= 0; z--) {
/*     */       
/* 671 */       showProgress((this.sizeZ - 1 - z), this.sizeZ, "z = " + z);
/*     */       
/* 673 */       byte[] slice = (byte[])stack[z];
/* 674 */       byte[] binarySlice = (byte[])binaryStack[z];
/*     */       
/* 676 */       for (int y = this.sizeY - 1; y >= 0; y--) {
/*     */         
/* 678 */         for (int x = this.sizeX - 1; x >= 0; x--) {
/*     */           
/* 680 */           if (binarySlice[y * this.sizeX + x] != 0) {
/*     */             
/* 682 */             int currentValue = slice[y * this.sizeX + x] & 0xFF;
/* 683 */             int maxValue = currentValue;
/*     */ 
/*     */             
/* 686 */             int zmin = Math.max(z - 1, 0);
/* 687 */             for (int z2 = Math.min(z + 1, this.sizeZ - 1); z2 >= zmin; z2--) {
/*     */               
/* 689 */               byte[] slice2 = (byte[])stack[z2];
/*     */               
/* 691 */               int ymin = (z2 == z) ? y : Math.max(y - 1, 0);
/* 692 */               for (int y2 = Math.min(y + 1, this.sizeY - 1); y2 >= ymin; y2--) {
/*     */                 
/* 694 */                 int xmin = (z2 == z && y2 == y) ? x : Math.max(x - 1, 0);
/* 695 */                 for (int x2 = Math.min(x + 1, this.sizeX - 1); x2 >= xmin; x2--) {
/*     */                   
/* 697 */                   int index = y2 * this.sizeX + x2;
/* 698 */                   int neighborValue = slice2[index] & 0xFF;
/* 699 */                   if (neighborValue > maxValue) {
/* 700 */                     maxValue = neighborValue;
/*     */                   }
/*     */                 } 
/*     */               } 
/*     */             } 
/*     */             
/* 706 */             maxValue = Math.min(maxValue, (int)this.mask.getVoxel(x, y, z));
/* 707 */             if (maxValue > currentValue) {
/*     */               
/* 709 */               slice[y * this.sizeX + x] = (byte)(maxValue & 0xFF);
/* 710 */               this.modif = true;
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void backwardDilationC26() {
/* 728 */     Object[] stack = this.result.getImageArray();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 733 */     for (int z = this.sizeZ - 1; z >= 0; z--) {
/*     */       
/* 735 */       showProgress((this.sizeZ - 1 - z), this.sizeZ, "z = " + z);
/*     */       
/* 737 */       byte[] slice = (byte[])stack[z];
/* 738 */       for (int y = this.sizeY - 1; y >= 0; y--) {
/*     */         
/* 740 */         for (int x = this.sizeX - 1; x >= 0; x--) {
/*     */           
/* 742 */           int currentValue = slice[y * this.sizeX + x] & 0xFF;
/* 743 */           int maxValue = currentValue;
/*     */ 
/*     */           
/* 746 */           int zmin = Math.max(z - 1, 0);
/* 747 */           for (int z2 = Math.min(z + 1, this.sizeZ - 1); z2 >= zmin; z2--) {
/*     */             
/* 749 */             byte[] slice2 = (byte[])stack[z2];
/*     */             
/* 751 */             int ymin = (z2 == z) ? y : Math.max(y - 1, 0);
/* 752 */             for (int y2 = Math.min(y + 1, this.sizeY - 1); y2 >= ymin; y2--) {
/*     */               
/* 754 */               int xmin = (z2 == z && y2 == y) ? x : Math.max(x - 1, 0);
/* 755 */               for (int x2 = Math.min(x + 1, this.sizeX - 1); x2 >= xmin; x2--) {
/*     */                 
/* 757 */                 int index = y2 * this.sizeX + x2;
/* 758 */                 int neighborValue = slice2[index] & 0xFF;
/* 759 */                 if (neighborValue > maxValue) {
/* 760 */                   maxValue = neighborValue;
/*     */                 }
/*     */               } 
/*     */             } 
/*     */           } 
/*     */           
/* 766 */           maxValue = Math.min(maxValue, (int)this.mask.getVoxel(x, y, z));
/* 767 */           if (maxValue > currentValue) {
/*     */             
/* 769 */             slice[y * this.sizeX + x] = (byte)(maxValue & 0xFF);
/* 770 */             this.modif = true;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/morphology/geodrec/GeodesicReconstructionByDilation3DScanningGray8.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */