/*     */ package inra.ijpb.morphology.strel;
/*     */ 
/*     */ import inra.ijpb.morphology.Strel;
/*     */ import inra.ijpb.morphology.Strel3D;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DiamondStrel
/*     */   extends AbstractSeparableStrel
/*     */ {
/*     */   int size;
/*     */   int offset;
/*     */   
/*     */   public static final DiamondStrel fromDiameter(int diam) {
/*  44 */     return new DiamondStrel(diam);
/*     */   }
/*     */   
/*     */   public static final DiamondStrel fromRadius(int radius) {
/*  48 */     return new DiamondStrel(2 * radius + 1, radius);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DiamondStrel(int size) {
/*  77 */     this(size, (size - 1) / 2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DiamondStrel(int size, int offset) {
/*  91 */     if (size < 1) {
/*  92 */       throw new IllegalArgumentException("Requires a positive size");
/*     */     }
/*  94 */     if (size % 2 != 1) {
/*  95 */       throw new IllegalArgumentException("Diamond size must be odd");
/*     */     }
/*  97 */     this.size = size;
/*     */     
/*  99 */     if (offset < 0) {
/* 100 */       throw new IllegalArgumentException("Requires a non-negative offset");
/*     */     }
/* 102 */     if (offset >= size) {
/* 103 */       throw new IllegalArgumentException("Offset can not be greater than size");
/*     */     }
/* 105 */     this.offset = offset;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int[] getSize() {
/* 117 */     return new int[] { this.size, this.size };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int[][] getMask() {
/* 125 */     int[][] mask = new int[this.size][this.size];
/*     */ 
/*     */     
/* 128 */     for (int i = 0; i < this.size; i++) {
/* 129 */       for (int k = 0; k < this.size; k++) {
/* 130 */         mask[i][k] = 255;
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 135 */     int radius = (this.size - 1) / 2;
/* 136 */     for (int j = 0; j < radius; j++) {
/* 137 */       for (int k = 0; k < radius - j; k++) {
/* 138 */         mask[j][k] = 0;
/* 139 */         mask[j][this.size - 1 - k] = 0;
/* 140 */         mask[this.size - 1 - j][k] = 0;
/* 141 */         mask[this.size - 1 - j][this.size - 1 - k] = 0;
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 146 */     return mask;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int[] getOffset() {
/* 154 */     return new int[] { this.offset, this.offset };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int[][] getShifts() {
/* 163 */     int radius = (this.size - 1) / 2;
/*     */ 
/*     */     
/* 166 */     int nShifts = radius * (radius - 1) / 2 + 2 * this.size - 1;
/* 167 */     int[][] shifts = new int[nShifts][2];
/*     */ 
/*     */     
/* 170 */     int iShift = 0;
/* 171 */     for (int i = 0; i < this.size; i++) {
/* 172 */       int i2 = Math.min(i, this.size - 1 - i);
/* 173 */       int j1 = radius - i2;
/* 174 */       int j2 = radius + i2;
/*     */       
/* 176 */       for (int j = j1; j <= j2; j++) {
/* 177 */         shifts[iShift][0] = j - this.offset;
/* 178 */         shifts[iShift][1] = i - this.offset;
/*     */       } 
/* 180 */       iShift++;
/*     */     } 
/*     */ 
/*     */     
/* 184 */     return shifts;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SeparableStrel reverse() {
/* 192 */     return new DiamondStrel(this.size, this.size - 1 - this.offset);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection<InPlaceStrel> decompose() {
/* 201 */     ArrayList<InPlaceStrel> strels = new ArrayList<InPlaceStrel>(3);
/*     */ 
/*     */     
/* 204 */     int linSize = (this.size - 1) / 2;
/* 205 */     strels.add(ShiftedCross3x3Strel.RIGHT);
/* 206 */     strels.add(new LinearDiagUpStrel(linSize));
/* 207 */     strels.add(new LinearDiagDownStrel(linSize));
/*     */     
/* 209 */     return strels;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/morphology/strel/DiamondStrel.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */