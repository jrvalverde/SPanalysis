/*     */ package inra.ijpb.morphology.strel;
/*     */ 
/*     */ import ij.ImageStack;
/*     */ import ij.plugin.Filters3D;
/*     */ import inra.ijpb.morphology.Strel3D;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BallStrel
/*     */   extends AbstractStrel3D
/*     */ {
/*     */   double radius;
/*     */   
/*     */   public static final BallStrel fromRadius(double radius) {
/*  55 */     return new BallStrel(radius);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final BallStrel fromDiameter(double diam) {
/*  67 */     return new BallStrel((diam - 1.0D) / 2.0D);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private BallStrel(double radius) {
/*  78 */     this.radius = radius;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int[] getSize() {
/*  88 */     int radiusInt = (int)Math.round(this.radius);
/*  89 */     int diam = 2 * radiusInt + 1;
/*  90 */     return new int[] { diam, diam, diam };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int[][][] getMask3D() {
/*  97 */     int intRadius = (int)Math.round(this.radius);
/*  98 */     int size = 2 * intRadius + 1;
/*  99 */     ImageStack img = ImageStack.create(size, size, size, 8);
/* 100 */     img.setVoxel(intRadius, intRadius, intRadius, 255.0D);
/*     */ 
/*     */     
/* 103 */     img = dilation(img);
/*     */ 
/*     */     
/* 106 */     int[][][] mask = new int[size][size][size];
/* 107 */     for (int z = 0; z < size; z++) {
/*     */       
/* 109 */       for (int y = 0; y < size; y++) {
/*     */         
/* 111 */         for (int x = 0; x < size; x++)
/*     */         {
/* 113 */           mask[z][y][x] = (int)img.getVoxel(x, y, z);
/*     */         }
/*     */       } 
/*     */     } 
/* 117 */     return mask;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int[] getOffset() {
/* 123 */     int intRadius = (int)Math.round(this.radius);
/* 124 */     return new int[] { intRadius, intRadius, intRadius };
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int[][] getShifts3D() {
/* 130 */     int intRadius = (int)Math.round(this.radius);
/* 131 */     int[][][] mask = getMask3D();
/* 132 */     int size = 2 * intRadius + 1;
/*     */ 
/*     */     
/* 135 */     int n = 0;
/* 136 */     for (int z = 0; z < size; z++) {
/*     */       
/* 138 */       for (int y = 0; y < size; y++) {
/*     */         
/* 140 */         for (int x = 0; x < size; x++) {
/*     */           
/* 142 */           if (mask[z][y][x] > 0) {
/* 143 */             n++;
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 149 */     int[][] offsets = new int[n][2];
/* 150 */     int i = 0;
/* 151 */     for (int j = 0; j < size; j++) {
/*     */       
/* 153 */       for (int y = 0; y < size; y++) {
/*     */         
/* 155 */         for (int x = 0; x < size; x++) {
/*     */           
/* 157 */           if (mask[j][y][x] > 0) {
/*     */             
/* 159 */             offsets[i][0] = x;
/* 160 */             offsets[i][1] = y;
/* 161 */             i++;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/* 166 */     return offsets;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Strel3D reverse() {
/* 172 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ImageStack dilation(ImageStack image) {
/* 185 */     float r = (float)this.radius;
/* 186 */     ImageStack result = Filters3D.filter(image, 13, r, r, r);
/* 187 */     result.setColorModel(image.getColorModel());
/* 188 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ImageStack erosion(ImageStack image) {
/* 201 */     float r = (float)this.radius;
/* 202 */     ImageStack result = Filters3D.filter(image, 12, r, r, r);
/* 203 */     result.setColorModel(image.getColorModel());
/* 204 */     return result;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/morphology/strel/BallStrel.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */