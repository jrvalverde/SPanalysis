/*     */ package inra.ijpb.morphology.strel;
/*     */ 
/*     */ import ij.IJ;
/*     */ import ij.ImageStack;
/*     */ import ij.process.ImageProcessor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractInPlaceStrel
/*     */   extends AbstractStrel
/*     */   implements InPlaceStrel
/*     */ {
/*     */   public ImageStack dilation(ImageStack stack) {
/*  38 */     ImageStack result = stack.duplicate();
/*  39 */     inPlaceDilation(result);
/*  40 */     return result;
/*     */   }
/*     */   
/*     */   public ImageStack erosion(ImageStack stack) {
/*  44 */     ImageStack result = stack.duplicate();
/*  45 */     inPlaceErosion(result);
/*  46 */     return result;
/*     */   }
/*     */   
/*     */   public ImageStack closing(ImageStack stack) {
/*  50 */     ImageStack result = stack.duplicate();
/*  51 */     inPlaceDilation(result);
/*  52 */     reverse().inPlaceErosion(result);
/*  53 */     return result;
/*     */   }
/*     */   
/*     */   public ImageStack opening(ImageStack stack) {
/*  57 */     ImageStack result = stack.duplicate();
/*  58 */     inPlaceErosion(result);
/*  59 */     reverse().inPlaceDilation(result);
/*  60 */     return result;
/*     */   }
/*     */   
/*     */   public void inPlaceDilation(ImageStack stack) {
/*  64 */     boolean flag = showProgress();
/*  65 */     showProgress(false);
/*     */     
/*  67 */     int nSlices = stack.getSize();
/*  68 */     for (int i = 1; i <= nSlices; i++) {
/*  69 */       if (flag) {
/*  70 */         IJ.showProgress(i - 1, nSlices);
/*     */       }
/*     */       
/*  73 */       ImageProcessor img = stack.getProcessor(i);
/*  74 */       inPlaceDilation(img);
/*  75 */       stack.setProcessor(img, i);
/*     */     } 
/*     */     
/*  78 */     if (flag) {
/*  79 */       IJ.showProgress(1.0D);
/*     */     }
/*  81 */     showProgress(flag);
/*     */   }
/*     */   
/*     */   public void inPlaceErosion(ImageStack stack) {
/*  85 */     boolean flag = showProgress();
/*  86 */     showProgress(false);
/*     */     
/*  88 */     int nSlices = stack.getSize();
/*  89 */     for (int i = 1; i <= nSlices; i++) {
/*  90 */       if (flag) {
/*  91 */         IJ.showProgress(i - 1, nSlices);
/*     */       }
/*     */       
/*  94 */       ImageProcessor img = stack.getProcessor(i);
/*  95 */       inPlaceErosion(img);
/*  96 */       stack.setProcessor(img, i);
/*     */     } 
/*     */     
/*  99 */     if (flag) {
/* 100 */       IJ.showProgress(1.0D);
/*     */     }
/* 102 */     showProgress(flag);
/*     */   }
/*     */   
/*     */   public ImageProcessor dilation(ImageProcessor image) {
/* 106 */     ImageProcessor result = image.duplicate();
/* 107 */     inPlaceDilation(result);
/* 108 */     return result;
/*     */   }
/*     */   
/*     */   public ImageProcessor erosion(ImageProcessor image) {
/* 112 */     ImageProcessor result = image.duplicate();
/* 113 */     inPlaceErosion(result);
/* 114 */     return result;
/*     */   }
/*     */   
/*     */   public ImageProcessor closing(ImageProcessor image) {
/* 118 */     ImageProcessor result = image.duplicate();
/* 119 */     inPlaceDilation(result);
/* 120 */     reverse().inPlaceErosion(result);
/* 121 */     return result;
/*     */   }
/*     */   
/*     */   public ImageProcessor opening(ImageProcessor image) {
/* 125 */     ImageProcessor result = image.duplicate();
/* 126 */     inPlaceErosion(result);
/* 127 */     reverse().inPlaceDilation(result);
/* 128 */     return result;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/morphology/strel/AbstractInPlaceStrel.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */