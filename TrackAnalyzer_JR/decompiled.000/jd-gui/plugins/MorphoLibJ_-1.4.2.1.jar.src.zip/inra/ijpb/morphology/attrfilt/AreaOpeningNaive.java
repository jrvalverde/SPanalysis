/*    */ package inra.ijpb.morphology.attrfilt;
/*    */ 
/*    */ import ij.process.ByteProcessor;
/*    */ import ij.process.ImageProcessor;
/*    */ import inra.ijpb.algo.AlgoStub;
/*    */ import inra.ijpb.binary.BinaryImages;
/*    */ import inra.ijpb.segment.Threshold;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AreaOpeningNaive
/*    */   extends AlgoStub
/*    */   implements AreaOpening
/*    */ {
/*    */   public ImageProcessor process(ImageProcessor image, int minArea) {
/* 46 */     fireStatusChanged(this, "Initialize");
/*    */     
/* 48 */     int sizeX = image.getWidth();
/* 49 */     int sizeY = image.getHeight();
/* 50 */     ByteProcessor result = new ByteProcessor(sizeX, sizeY);
/*    */     
/* 52 */     fireStatusChanged(this, "Compute thesholds");
/* 53 */     for (int level = 1; level <= 255; level++) {
/*    */       
/* 55 */       fireStatusChanged(this, "Threshold: " + level);
/* 56 */       fireProgressChanged(this, (level - 1), 255.0D);
/*    */ 
/*    */       
/* 59 */       ImageProcessor binary = Threshold.threshold(image, level, 255.0D);
/*    */ 
/*    */       
/* 62 */       binary = BinaryImages.areaOpening(binary, minArea);
/*    */       
/* 64 */       for (int y = 0; y < sizeY; y++) {
/*    */         
/* 66 */         for (int x = 0; x < sizeX; x++) {
/*    */           
/* 68 */           if (binary.get(x, y) > 0)
/*    */           {
/* 70 */             result.set(x, y, level);
/*    */           }
/*    */         } 
/*    */       } 
/*    */     } 
/*    */     
/* 76 */     fireStatusChanged(this, "");
/* 77 */     fireProgressChanged(this, 1.0D, 1.0D);
/*    */     
/* 79 */     return (ImageProcessor)result;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/morphology/attrfilt/AreaOpeningNaive.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */