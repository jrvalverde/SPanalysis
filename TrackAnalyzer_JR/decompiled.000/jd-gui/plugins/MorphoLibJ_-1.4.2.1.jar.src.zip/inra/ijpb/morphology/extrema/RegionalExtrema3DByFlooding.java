/*     */ package inra.ijpb.morphology.extrema;
/*     */ 
/*     */ import ij.ImageStack;
/*     */ import inra.ijpb.data.image.Image3D;
/*     */ import inra.ijpb.data.image.Images3D;
/*     */ import inra.ijpb.morphology.FloodFill3D;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RegionalExtrema3DByFlooding
/*     */   extends RegionalExtrema3DAlgo
/*     */ {
/*     */   public ImageStack applyTo(ImageStack image) {
/*  57 */     return regionalExtremaFloat(image);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ImageStack regionalExtremaFloat(ImageStack image) {
/*  67 */     switch (this.connectivity) {
/*     */       
/*     */       case 6:
/*  70 */         return regionalExtremaFloatC6(image);
/*     */       case 26:
/*  72 */         return regionalExtremaFloatC26(image);
/*     */     } 
/*  74 */     throw new IllegalArgumentException(
/*  75 */         "Connectivity must be either 6 or 26, not " + 
/*  76 */         this.connectivity);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ImageStack regionalExtremaFloatC6(ImageStack image) {
/*  86 */     int sizeX = image.getWidth();
/*  87 */     int sizeY = image.getHeight();
/*  88 */     int sizeZ = image.getSize();
/*     */ 
/*     */     
/*  91 */     fireStatusChanged(this, "Initialize regional extrema");
/*  92 */     ImageStack result = ImageStack.create(sizeX, sizeY, sizeZ, 8);
/*  93 */     fillStack(result, 255.0D);
/*     */     
/*  95 */     fireStatusChanged(this, "Compute regional extrema");
/*     */ 
/*     */     
/*  98 */     int sign = (this.extremaType == ExtremaType.MINIMA) ? 1 : -1;
/*     */     
/* 100 */     Image3D image2 = Images3D.createWrapper(image);
/* 101 */     Image3D result2 = Images3D.createWrapper(result);
/*     */ 
/*     */     
/* 104 */     for (int z = 0; z < sizeZ; z++) {
/*     */       
/* 106 */       fireProgressChanged(this, z, sizeZ);
/* 107 */       for (int y = 0; y < sizeY; y++) {
/*     */         
/* 109 */         for (int x = 0; x < sizeX; x++) {
/*     */ 
/*     */           
/* 112 */           if (result2.getValue(x, y, z) != 0.0D) {
/*     */ 
/*     */ 
/*     */             
/* 116 */             double currentValue = image2.getValue(x, y, z) * sign;
/*     */ 
/*     */             
/* 119 */             double value = currentValue;
/* 120 */             if (x > 0)
/* 121 */               value = Math.min(value, image2.getValue(x - 1, y, z) * sign); 
/* 122 */             if (x < sizeX - 1)
/* 123 */               value = Math.min(value, image2.getValue(x + 1, y, z) * sign); 
/* 124 */             if (y > 0)
/* 125 */               value = Math.min(value, image2.getValue(x, y - 1, z) * sign); 
/* 126 */             if (y < sizeY - 1)
/* 127 */               value = Math.min(value, image2.getValue(x, y + 1, z) * sign); 
/* 128 */             if (z > 0)
/* 129 */               value = Math.min(value, image2.getValue(x, y, z - 1) * sign); 
/* 130 */             if (z < sizeZ - 1) {
/* 131 */               value = Math.min(value, image2.getValue(x, y, z + 1) * sign);
/*     */             }
/*     */ 
/*     */ 
/*     */             
/* 136 */             if (value < currentValue)
/*     */             {
/* 138 */               FloodFill3D.floodFillFloat(image2, x, y, z, result2, 0.0F, 6);
/*     */             }
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/* 144 */     fireProgressChanged(this, 1.0D, 1.0D);
/* 145 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ImageStack regionalExtremaFloatC26(ImageStack image) {
/* 154 */     int sizeX = image.getWidth();
/* 155 */     int sizeY = image.getHeight();
/* 156 */     int sizeZ = image.getSize();
/*     */ 
/*     */     
/* 159 */     fireStatusChanged(this, "Initialize regional extrema");
/* 160 */     ImageStack result = ImageStack.create(sizeX, sizeY, sizeZ, 8);
/* 161 */     fillStack(result, 255.0D);
/*     */     
/* 163 */     fireStatusChanged(this, "Compute regional extrema");
/*     */     
/* 165 */     int sign = (this.extremaType == ExtremaType.MINIMA) ? 1 : -1;
/*     */     
/* 167 */     Image3D image2 = Images3D.createWrapper(image);
/* 168 */     Image3D result2 = Images3D.createWrapper(result);
/*     */ 
/*     */     
/* 171 */     for (int z = 0; z < sizeZ; z++) {
/*     */       
/* 173 */       fireProgressChanged(this, z, sizeZ);
/*     */       
/* 175 */       for (int y = 0; y < sizeY; y++) {
/*     */         
/* 177 */         for (int x = 0; x < sizeX; x++) {
/*     */ 
/*     */           
/* 180 */           if (result2.getValue(x, y, z) != 0.0D) {
/*     */ 
/*     */ 
/*     */             
/* 184 */             double currentValue = image2.getValue(x, y, z) * sign;
/*     */ 
/*     */             
/* 187 */             double value = currentValue;
/* 188 */             for (int z2 = Math.max(z - 1, 0); z2 <= Math.min(z + 1, sizeZ - 1); z2++) {
/*     */               
/* 190 */               for (int y2 = Math.max(y - 1, 0); y2 <= Math.min(y + 1, sizeY - 1); y2++) {
/*     */                 
/* 192 */                 for (int x2 = Math.max(x - 1, 0); x2 <= Math.min(x + 1, sizeX - 1); x2++)
/*     */                 {
/* 194 */                   value = Math.min(value, image2.getValue(x2, y2, z2) * sign);
/*     */                 }
/*     */               } 
/*     */             } 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 202 */             if (value < currentValue)
/*     */             {
/* 204 */               FloodFill3D.floodFillFloat(image2, x, y, z, result2, 0.0F, 26);
/*     */             }
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/* 210 */     fireProgressChanged(this, 1.0D, 1.0D);
/*     */     
/* 212 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ImageStack applyTo(ImageStack inputImage, ImageStack maskImage) {
/* 218 */     switch (this.connectivity) {
/*     */       
/*     */       case 6:
/* 221 */         return regionalExtremaFloatC6(inputImage, maskImage);
/*     */       case 26:
/* 223 */         return regionalExtremaFloatC26(inputImage, maskImage);
/*     */     } 
/* 225 */     throw new IllegalArgumentException(
/* 226 */         "Connectivity must be either 6 or 26, not " + 
/* 227 */         this.connectivity);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ImageStack regionalExtremaFloatC6(ImageStack image, ImageStack mask) {
/* 237 */     if (Thread.currentThread().isInterrupted()) {
/* 238 */       return null;
/*     */     }
/* 240 */     int sizeX = image.getWidth();
/* 241 */     int sizeY = image.getHeight();
/* 242 */     int sizeZ = image.getSize();
/*     */ 
/*     */     
/* 245 */     fireStatusChanged(this, "Initialize regional extrema");
/* 246 */     ImageStack result = ImageStack.create(sizeX, sizeY, sizeZ, 8);
/* 247 */     fillStack(result, 255.0D);
/*     */     
/* 249 */     fireStatusChanged(this, "Compute regional extrema");
/*     */ 
/*     */     
/* 252 */     int sign = (this.extremaType == ExtremaType.MINIMA) ? 1 : -1;
/*     */ 
/*     */     
/* 255 */     for (int z = 0; z < sizeZ; z++) {
/*     */       
/* 257 */       fireProgressChanged(this, z, sizeZ);
/* 258 */       for (int y = 0; y < sizeY; y++) {
/*     */         
/* 260 */         for (int x = 0; x < sizeX; x++) {
/*     */ 
/*     */           
/* 263 */           if (mask.getVoxel(x, y, z) != 0.0D)
/*     */           {
/*     */ 
/*     */             
/* 267 */             if (result.getVoxel(x, y, z) != 0.0D) {
/*     */ 
/*     */ 
/*     */               
/* 271 */               double currentValue = image.getVoxel(x, y, z) * sign;
/*     */ 
/*     */               
/* 274 */               double value = currentValue;
/* 275 */               if (x > 0 && mask.getVoxel(x - 1, y, z) != 0.0D) {
/* 276 */                 value = Math.min(value, image.getVoxel(x - 1, y, z) * sign);
/*     */               }
/* 278 */               if (x < sizeX - 1 && mask.getVoxel(x + 1, y, z) != 0.0D) {
/* 279 */                 value = Math.min(value, image.getVoxel(x + 1, y, z) * sign);
/*     */               }
/* 281 */               if (y > 0 && mask.getVoxel(x, y - 1, z) != 0.0D) {
/* 282 */                 value = Math.min(value, image.getVoxel(x, y - 1, z) * sign);
/*     */               }
/* 284 */               if (y < sizeY - 1 && mask.getVoxel(x, y + 1, z) != 0.0D) {
/* 285 */                 value = Math.min(value, image.getVoxel(x, y + 1, z) * sign);
/*     */               }
/* 287 */               if (z > 0 && mask.getVoxel(x, y, z - 1) != 0.0D) {
/* 288 */                 value = Math.min(value, image.getVoxel(x, y, z - 1) * sign);
/*     */               }
/* 290 */               if (z < sizeZ - 1 && mask.getVoxel(x, y, z + 1) != 0.0D) {
/* 291 */                 value = Math.min(value, image.getVoxel(x, y, z + 1) * sign);
/*     */               }
/*     */ 
/*     */ 
/*     */               
/* 296 */               if (value < currentValue)
/*     */               {
/* 298 */                 FloodFill3D.floodFillFloat(image, x, y, z, result, 0.0F, 6); } 
/*     */             } 
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/* 304 */     fireProgressChanged(this, 1.0D, 1.0D);
/* 305 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ImageStack regionalExtremaFloatC26(ImageStack image, ImageStack mask) {
/* 314 */     if (Thread.currentThread().isInterrupted()) {
/* 315 */       return null;
/*     */     }
/* 317 */     int sizeX = image.getWidth();
/* 318 */     int sizeY = image.getHeight();
/* 319 */     int sizeZ = image.getSize();
/*     */ 
/*     */     
/* 322 */     fireStatusChanged(this, "Initialize regional extrema");
/* 323 */     ImageStack result = ImageStack.create(sizeX, sizeY, sizeZ, 8);
/* 324 */     fillStack(result, 255.0D);
/*     */     
/* 326 */     fireStatusChanged(this, "Compute regional extrema");
/*     */ 
/*     */     
/* 329 */     int sign = (this.extremaType == ExtremaType.MINIMA) ? 1 : -1;
/*     */ 
/*     */     
/* 332 */     for (int z = 0; z < sizeZ; z++) {
/*     */       
/* 334 */       fireProgressChanged(this, z, sizeZ);
/* 335 */       for (int y = 0; y < sizeY; y++) {
/*     */         
/* 337 */         for (int x = 0; x < sizeX; x++) {
/*     */ 
/*     */           
/* 340 */           if (mask.getVoxel(x, y, z) != 0.0D)
/*     */           {
/*     */ 
/*     */             
/* 344 */             if (result.getVoxel(x, y, z) != 0.0D) {
/*     */ 
/*     */ 
/*     */               
/* 348 */               double currentValue = image.getVoxel(x, y, z);
/*     */ 
/*     */               
/* 351 */               double value = currentValue * sign;
/* 352 */               for (int z2 = Math.max(z - 1, 0); z2 <= Math.min(z + 1, sizeZ - 1); z2++) {
/*     */                 
/* 354 */                 for (int y2 = Math.max(y - 1, 0); y2 <= Math.min(y + 1, sizeY - 1); y2++) {
/*     */                   
/* 356 */                   for (int x2 = Math.max(x - 1, 0); x2 <= Math.min(x + 1, sizeX - 1); x2++) {
/*     */                     
/* 358 */                     if (mask.getVoxel(x2, y2, z2) != 0.0D) {
/* 359 */                       value = Math.min(value, image.getVoxel(x2, y2, z2) * sign);
/*     */                     }
/*     */                   } 
/*     */                 } 
/*     */               } 
/*     */ 
/*     */ 
/*     */               
/* 367 */               if (value < currentValue * sign)
/*     */               {
/* 369 */                 FloodFill3D.floodFillFloat(image, x, y, z, result, 0.0F, 26); } 
/*     */             } 
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/* 375 */     fireProgressChanged(this, 1.0D, 1.0D);
/* 376 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void fillStack(ImageStack image, double value) {
/* 384 */     int sizeX = image.getWidth();
/* 385 */     int sizeY = image.getHeight();
/* 386 */     int sizeZ = image.getSize();
/* 387 */     for (int z = 0; z < sizeZ; z++) {
/*     */       
/* 389 */       for (int y = 0; y < sizeY; y++) {
/*     */         
/* 391 */         for (int x = 0; x < sizeX; x++)
/*     */         {
/* 393 */           image.setVoxel(x, y, z, value);
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/morphology/extrema/RegionalExtrema3DByFlooding.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */