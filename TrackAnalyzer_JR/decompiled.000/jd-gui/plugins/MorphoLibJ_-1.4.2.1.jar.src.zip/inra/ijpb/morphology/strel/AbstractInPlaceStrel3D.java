/*    */ package inra.ijpb.morphology.strel;
/*    */ 
/*    */ import ij.ImageStack;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractInPlaceStrel3D
/*    */   extends AbstractStrel3D
/*    */   implements InPlaceStrel3D
/*    */ {
/*    */   public ImageStack dilation(ImageStack stack) {
/* 39 */     ImageStack result = stack.duplicate();
/* 40 */     inPlaceDilation(result);
/* 41 */     return result;
/*    */   }
/*    */ 
/*    */   
/*    */   public ImageStack erosion(ImageStack stack) {
/* 46 */     ImageStack result = stack.duplicate();
/* 47 */     inPlaceErosion(result);
/* 48 */     return result;
/*    */   }
/*    */ 
/*    */   
/*    */   public ImageStack closing(ImageStack stack) {
/* 53 */     ImageStack result = stack.duplicate();
/* 54 */     inPlaceDilation(result);
/* 55 */     reverse().inPlaceErosion(result);
/* 56 */     return result;
/*    */   }
/*    */ 
/*    */   
/*    */   public ImageStack opening(ImageStack stack) {
/* 61 */     ImageStack result = stack.duplicate();
/* 62 */     inPlaceErosion(result);
/* 63 */     reverse().inPlaceDilation(result);
/* 64 */     return result;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/morphology/strel/AbstractInPlaceStrel3D.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */