/*     */ package inra.ijpb.morphology.geodrec;
/*     */ 
/*     */ import ij.ImageStack;
/*     */ import inra.ijpb.data.Cursor3D;
/*     */ import inra.ijpb.data.image.Images3D;
/*     */ import java.util.ArrayDeque;
/*     */ import java.util.Deque;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GeodesicReconstruction3DHybrid0Float
/*     */   extends GeodesicReconstruction3DAlgoStub
/*     */ {
/*  58 */   GeodesicReconstructionType reconstructionType = GeodesicReconstructionType.BY_DILATION;
/*     */   
/*     */   ImageStack markerStack;
/*     */   
/*     */   ImageStack maskStack;
/*     */   
/*     */   ImageStack resultStack;
/*     */   
/*     */   float[][] markerSlices;
/*     */   float[][] maskSlices;
/*     */   float[][] resultSlices;
/*  69 */   int sizeX = 0;
/*     */   
/*  71 */   int sizeY = 0;
/*     */   
/*  73 */   int sizeZ = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Deque<Cursor3D> queue;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GeodesicReconstruction3DHybrid0Float() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GeodesicReconstruction3DHybrid0Float(GeodesicReconstructionType type) {
/*  95 */     this.reconstructionType = type;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GeodesicReconstruction3DHybrid0Float(GeodesicReconstructionType type, int connectivity) {
/* 109 */     this.reconstructionType = type;
/* 110 */     this.connectivity = connectivity;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GeodesicReconstruction3DHybrid0Float(int connectivity) {
/* 122 */     this.connectivity = connectivity;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GeodesicReconstructionType getReconstructionType() {
/* 130 */     return this.reconstructionType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setReconstructionType(GeodesicReconstructionType reconstructionType) {
/* 138 */     this.reconstructionType = reconstructionType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ImageStack applyTo(ImageStack marker, ImageStack mask) {
/* 148 */     if (marker.getBitDepth() != 32 || mask.getBitDepth() != 32)
/*     */     {
/* 150 */       throw new IllegalArgumentException("Requires both marker and mask images to have 32-bits depth");
/*     */     }
/*     */ 
/*     */     
/* 154 */     this.markerStack = marker;
/* 155 */     this.maskStack = mask;
/*     */ 
/*     */     
/* 158 */     this.markerSlices = Images3D.getFloatArrays(marker);
/* 159 */     this.maskSlices = Images3D.getFloatArrays(mask);
/*     */ 
/*     */     
/* 162 */     this.sizeX = marker.getWidth();
/* 163 */     this.sizeY = marker.getHeight();
/* 164 */     this.sizeZ = marker.getSize();
/* 165 */     if (!Images3D.isSameSize(marker, mask))
/*     */     {
/* 167 */       throw new IllegalArgumentException("Marker and Mask images must have the same size");
/*     */     }
/*     */ 
/*     */     
/* 171 */     if (this.connectivity != 6 && this.connectivity != 26)
/*     */     {
/* 173 */       throw new RuntimeException(
/* 174 */           "Connectivity for stacks must be either 6 or 26, not " + 
/* 175 */           this.connectivity);
/*     */     }
/*     */     
/* 178 */     this.queue = new ArrayDeque<Cursor3D>();
/*     */     
/* 180 */     long t0 = System.currentTimeMillis();
/* 181 */     trace("Initialize result ");
/*     */     
/* 183 */     initializeResult();
/* 184 */     if (this.verbose) {
/*     */       
/* 186 */       long t1 = System.currentTimeMillis();
/* 187 */       System.out.println(String.valueOf(t1 - t0) + " ms");
/* 188 */       t0 = t1;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 193 */     trace("Forward iteration ");
/* 194 */     showStatus("Geod. Rec. Fwd ");
/*     */     
/* 196 */     forwardScan();
/* 197 */     if (this.verbose) {
/*     */       
/* 199 */       long t1 = System.currentTimeMillis();
/* 200 */       System.out.println(String.valueOf(t1 - t0) + " ms");
/* 201 */       t0 = t1;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 206 */     trace("Backward iteration & Init Queue");
/* 207 */     showStatus("Geod. Rec. Bwd ");
/*     */     
/* 209 */     backwardScanInitQueue();
/* 210 */     if (this.verbose) {
/*     */       
/* 212 */       long t1 = System.currentTimeMillis();
/* 213 */       System.out.println(String.valueOf(t1 - t0) + " ms");
/* 214 */       t0 = t1;
/*     */     } 
/*     */ 
/*     */     
/* 218 */     trace("Process queue");
/* 219 */     showStatus("Process queue");
/*     */     
/* 221 */     processQueue();
/* 222 */     if (this.verbose) {
/*     */       
/* 224 */       long t1 = System.currentTimeMillis();
/* 225 */       System.out.println(String.valueOf(t1 - t0) + " ms");
/* 226 */       t0 = t1;
/*     */     } 
/*     */     
/* 229 */     return this.resultStack;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ImageStack applyTo(ImageStack marker, ImageStack mask, ImageStack binaryMask) {
/* 241 */     throw new RuntimeException("Method not yet implemented");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void initializeResult() {
/* 252 */     this.resultStack = ImageStack.create(this.sizeX, this.sizeY, this.sizeZ, this.maskStack.getBitDepth());
/* 253 */     this.resultSlices = Images3D.getFloatArrays(this.resultStack);
/*     */ 
/*     */ 
/*     */     
/* 257 */     if (this.reconstructionType == GeodesicReconstructionType.BY_DILATION) {
/*     */ 
/*     */       
/* 260 */       for (int z = 0; z < this.sizeZ; z++)
/*     */       {
/*     */         
/* 263 */         float[] markerSlice = this.markerSlices[z];
/* 264 */         float[] maskSlice = this.maskSlices[z];
/* 265 */         float[] resultSlice = this.resultSlices[z];
/*     */ 
/*     */         
/* 268 */         for (int i = 0; i < this.sizeX * this.sizeY; i++)
/*     */         {
/* 270 */           float v1 = markerSlice[i];
/* 271 */           float v2 = maskSlice[i];
/* 272 */           resultSlice[i] = Math.min(v1, v2);
/*     */         }
/*     */       
/*     */       }
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 280 */       for (int z = 0; z < this.sizeZ; z++) {
/*     */ 
/*     */         
/* 283 */         float[] markerSlice = this.markerSlices[z];
/* 284 */         float[] maskSlice = this.maskSlices[z];
/* 285 */         float[] resultSlice = this.resultSlices[z];
/*     */ 
/*     */         
/* 288 */         for (int i = 0; i < this.sizeX * this.sizeY; i++) {
/*     */           
/* 290 */           float v1 = markerSlice[i];
/* 291 */           float v2 = maskSlice[i];
/* 292 */           resultSlice[i] = Math.max(v1, v2);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void forwardScan() {
/* 300 */     if (this.connectivity == 6) {
/*     */       
/* 302 */       forwardScanC6();
/*     */     }
/*     */     else {
/*     */       
/* 306 */       forwardScanC26();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void forwardScanC6() {
/* 316 */     int sign = this.reconstructionType.getSign();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 324 */     for (int z = 0; z < this.sizeZ; z++) {
/*     */       
/* 326 */       showProgress(z, this.sizeZ);
/*     */ 
/*     */       
/* 329 */       float[] slice = this.resultSlices[z];
/* 330 */       float[] maskSlice = this.maskSlices[z];
/*     */ 
/*     */       
/* 333 */       for (int y = 0; y < this.sizeY; y++) {
/*     */         
/* 335 */         for (int x = 0; x < this.sizeX; x++) {
/*     */           
/* 337 */           int index = y * this.sizeX + x;
/* 338 */           float currentValue = slice[index] * sign;
/* 339 */           float maxValue = currentValue;
/*     */ 
/*     */           
/* 342 */           if (x > 0)
/* 343 */             maxValue = Math.max(maxValue, slice[index - 1] * sign); 
/* 344 */           if (y > 0)
/* 345 */             maxValue = Math.max(maxValue, slice[index - this.sizeX] * sign); 
/* 346 */           if (z > 0) {
/* 347 */             maxValue = Math.max(maxValue, this.resultSlices[z - 1][index] * sign);
/*     */           }
/*     */           
/* 350 */           maxValue = Math.min(maxValue, maskSlice[index] * sign);
/* 351 */           if (maxValue > currentValue) {
/* 352 */             slice[index] = maxValue * sign;
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 358 */     showProgress(1.0D, 1.0D);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void forwardScanC26() {
/* 367 */     int sign = this.reconstructionType.getSign();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 374 */     for (int z = 0; z < this.sizeZ; z++) {
/*     */       
/* 376 */       showProgress(z, this.sizeZ, "z = " + z);
/*     */ 
/*     */       
/* 379 */       float[] maskSlice = this.maskSlices[z];
/* 380 */       float[] slice = this.resultSlices[z];
/*     */ 
/*     */       
/* 383 */       for (int y = 0; y < this.sizeY; y++) {
/*     */         
/* 385 */         for (int x = 0; x < this.sizeX; x++) {
/*     */           
/* 387 */           int index = y * this.sizeX + x;
/* 388 */           float currentValue = slice[index] * sign;
/* 389 */           float maxValue = currentValue;
/*     */ 
/*     */           
/* 392 */           int zmax = Math.min(z + 1, this.sizeZ);
/* 393 */           for (int z2 = Math.max(z - 1, 0); z2 < zmax; z2++) {
/*     */             
/* 395 */             float[] slice2 = this.resultSlices[z2];
/* 396 */             int ymax = (z2 == z) ? y : Math.min(y + 1, this.sizeY - 1);
/* 397 */             for (int y2 = Math.max(y - 1, 0); y2 <= ymax; y2++) {
/*     */               
/* 399 */               int xmax = (z2 == z && y2 == y) ? (x - 1) : Math.min(
/* 400 */                   x + 1, this.sizeX - 1);
/* 401 */               for (int x2 = Math.max(x - 1, 0); x2 <= xmax; x2++)
/*     */               {
/* 403 */                 maxValue = Math.max(maxValue, 
/* 404 */                     slice2[y2 * this.sizeX + x2] * sign);
/*     */               }
/*     */             } 
/*     */           } 
/*     */ 
/*     */           
/* 410 */           maxValue = Math.min(maxValue, maskSlice[index] * sign);
/* 411 */           if (maxValue > currentValue)
/*     */           {
/* 413 */             slice[index] = maxValue * sign;
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 419 */     showProgress(1.0D, 1.0D);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void backwardScanInitQueue() {
/* 425 */     if (this.connectivity == 6) {
/*     */       
/* 427 */       backwardScanInitQueueC6();
/*     */     }
/*     */     else {
/*     */       
/* 431 */       backwardScanInitQueueC26();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void backwardScanInitQueueC6() {
/* 440 */     int sign = this.reconstructionType.getSign();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 447 */     for (int z = this.sizeZ - 1; z >= 0; z--) {
/*     */       
/* 449 */       showProgress((this.sizeZ - 1 - z), this.sizeZ, "z = " + z);
/*     */ 
/*     */       
/* 452 */       float[] slice = this.resultSlices[z];
/* 453 */       float[] maskSlice = this.maskSlices[z];
/*     */ 
/*     */       
/* 456 */       for (int y = this.sizeY - 1; y >= 0; y--) {
/*     */         
/* 458 */         for (int x = this.sizeX - 1; x >= 0; x--) {
/*     */           
/* 460 */           int index = y * this.sizeX + x;
/* 461 */           float currentValue = slice[index] * sign;
/* 462 */           float maxValue = currentValue;
/*     */ 
/*     */           
/* 465 */           if (x < this.sizeX - 1)
/* 466 */             maxValue = Math.max(maxValue, slice[index + 1] * sign); 
/* 467 */           if (y < this.sizeY - 1)
/* 468 */             maxValue = Math.max(maxValue, slice[index + this.sizeX] * sign); 
/* 469 */           if (z < this.sizeZ - 1) {
/* 470 */             maxValue = Math.max(maxValue, this.resultSlices[z + 1][index] * sign);
/*     */           }
/*     */           
/* 473 */           maxValue = Math.min(maxValue, maskSlice[index] * sign);
/*     */ 
/*     */           
/* 476 */           if (maxValue > currentValue) {
/*     */ 
/*     */ 
/*     */             
/* 480 */             slice[index] = maxValue * sign;
/*     */ 
/*     */             
/* 483 */             if (x < this.sizeX - 1)
/* 484 */               updateQueue(x + 1, y, z, maxValue, sign); 
/* 485 */             if (y < this.sizeY - 1)
/* 486 */               updateQueue(x, y + 1, z, maxValue, sign); 
/* 487 */             if (z < this.sizeZ - 1) {
/* 488 */               updateQueue(x, y, z + 1, maxValue, sign);
/*     */             }
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/* 494 */     showProgress(1.0D, 1.0D);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void backwardScanInitQueueC26() {
/* 503 */     int sign = this.reconstructionType.getSign();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 510 */     for (int z = this.sizeZ - 1; z >= 0; z--) {
/*     */       
/* 512 */       showProgress((this.sizeZ - 1 - z), this.sizeZ, "z = " + z);
/*     */ 
/*     */       
/* 515 */       float[] maskSlice = this.maskSlices[z];
/* 516 */       float[] slice = this.resultSlices[z];
/*     */ 
/*     */       
/* 519 */       for (int y = this.sizeY - 1; y >= 0; y--) {
/*     */         
/* 521 */         for (int x = this.sizeX - 1; x >= 0; x--) {
/*     */           
/* 523 */           int index = y * this.sizeX + x;
/* 524 */           float currentValue = slice[index] * sign;
/* 525 */           float maxValue = currentValue;
/*     */           
/*     */           int z2;
/* 528 */           for (z2 = Math.min(z + 1, this.sizeZ - 1); z2 >= z; z2--) {
/*     */ 
/*     */             
/* 531 */             float[] slice2 = this.resultSlices[z2];
/*     */             
/* 533 */             int ymin = (z2 == z) ? y : Math.max(y - 1, 0);
/* 534 */             for (int y2 = Math.min(y + 1, this.sizeY - 1); y2 >= ymin; y2--) {
/*     */               
/* 536 */               int xmin = (z2 == z && y2 == y) ? x : Math.max(x - 1, 0);
/* 537 */               for (int x2 = Math.min(x + 1, this.sizeX - 1); x2 >= xmin; x2--)
/*     */               {
/* 539 */                 maxValue = Math.max(maxValue, slice2[y2 * this.sizeX + x2] * sign);
/*     */               }
/*     */             } 
/*     */           } 
/*     */ 
/*     */           
/* 545 */           maxValue = Math.min(maxValue, maskSlice[index] * sign);
/*     */ 
/*     */           
/* 548 */           if (maxValue > currentValue) {
/*     */ 
/*     */ 
/*     */             
/* 552 */             slice[index] = maxValue * sign;
/*     */ 
/*     */             
/* 555 */             for (z2 = Math.min(z + 1, this.sizeZ - 1); z2 >= z; z2--) {
/*     */               
/* 557 */               int ymin = (z2 == z) ? y : Math.max(y - 1, 0);
/* 558 */               for (int y2 = Math.min(y + 1, this.sizeY - 1); y2 >= ymin; y2--) {
/*     */                 
/* 560 */                 int xmin = (z2 == z && y2 == y) ? x : Math.max(x - 1, 0);
/* 561 */                 for (int x2 = Math.min(x + 1, this.sizeX - 1); x2 >= xmin; x2--)
/*     */                 {
/* 563 */                   updateQueue(x2, y2, z2, maxValue, sign);
/*     */                 }
/*     */               } 
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/* 571 */     showProgress(1.0D, 1.0D);
/*     */   }
/*     */ 
/*     */   
/*     */   private void processQueue() {
/* 576 */     if (this.connectivity == 6) {
/* 577 */       processQueueC6();
/*     */     }
/*     */     else {
/*     */       
/* 581 */       processQueueC26();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void processQueueC6() {
/* 592 */     int sign = this.reconstructionType.getSign();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 597 */     while (!this.queue.isEmpty()) {
/*     */       
/* 599 */       Cursor3D p = this.queue.removeFirst();
/* 600 */       int x = p.getX();
/* 601 */       int y = p.getY();
/* 602 */       int z = p.getZ();
/* 603 */       float[] slice = this.resultSlices[z];
/* 604 */       int index = y * this.sizeX + x;
/* 605 */       float value = slice[index] * sign;
/*     */ 
/*     */       
/* 608 */       if (x > 0)
/* 609 */         value = Math.max(value, slice[index - 1] * sign); 
/* 610 */       if (x < this.sizeX - 1)
/* 611 */         value = Math.max(value, slice[index + 1] * sign); 
/* 612 */       if (y > 0)
/* 613 */         value = Math.max(value, slice[index - this.sizeX] * sign); 
/* 614 */       if (y < this.sizeY - 1)
/* 615 */         value = Math.max(value, slice[index + this.sizeX] * sign); 
/* 616 */       if (z > 0)
/* 617 */         value = Math.max(value, this.resultSlices[z - 1][index] * sign); 
/* 618 */       if (z < this.sizeZ - 1) {
/* 619 */         value = Math.max(value, this.resultSlices[z + 1][index] * sign);
/*     */       }
/*     */       
/* 622 */       value = Math.min(value, this.maskSlices[z][index] * sign);
/*     */ 
/*     */       
/* 625 */       if (value <= slice[index] * sign) {
/*     */         continue;
/*     */       }
/*     */       
/* 629 */       slice[index] = value * sign;
/*     */ 
/*     */       
/* 632 */       if (x > 0)
/* 633 */         updateQueue(x - 1, y, z, value, sign); 
/* 634 */       if (x < this.sizeX - 1)
/* 635 */         updateQueue(x + 1, y, z, value, sign); 
/* 636 */       if (y > 0)
/* 637 */         updateQueue(x, y - 1, z, value, sign); 
/* 638 */       if (y < this.sizeY - 1)
/* 639 */         updateQueue(x, y + 1, z, value, sign); 
/* 640 */       if (z > 0)
/* 641 */         updateQueue(x, y, z - 1, value, sign); 
/* 642 */       if (z < this.sizeZ - 1) {
/* 643 */         updateQueue(x, y, z + 1, value, sign);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void processQueueC26() {
/* 655 */     int sign = this.reconstructionType.getSign();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 660 */     while (!this.queue.isEmpty()) {
/*     */       
/* 662 */       Cursor3D p = this.queue.removeFirst();
/* 663 */       int x = p.getX();
/* 664 */       int y = p.getY();
/* 665 */       int z = p.getZ();
/* 666 */       float[] slice = this.resultSlices[z];
/* 667 */       int index = y * this.sizeX + x;
/* 668 */       float value = slice[index] * sign;
/*     */ 
/*     */       
/* 671 */       int xmin = Math.max(x - 1, 0);
/* 672 */       int xmax = Math.min(x + 1, this.sizeX - 1);
/* 673 */       int ymin = Math.max(y - 1, 0);
/* 674 */       int ymax = Math.min(y + 1, this.sizeY - 1);
/* 675 */       int zmin = Math.max(z - 1, 0);
/* 676 */       int zmax = Math.min(z + 1, this.sizeZ - 1);
/*     */       
/*     */       int z2;
/* 679 */       for (z2 = zmin; z2 <= zmax; z2++) {
/*     */         
/* 681 */         float[] slice2 = this.resultSlices[z2];
/* 682 */         for (int y2 = ymin; y2 <= ymax; y2++) {
/*     */           
/* 684 */           for (int x2 = xmin; x2 <= xmax; x2++)
/*     */           {
/* 686 */             value = Math.max(value, slice2[y2 * this.sizeX + x2] * sign);
/*     */           }
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 692 */       value = Math.min(value, this.maskSlices[z][index] * sign);
/*     */ 
/*     */       
/* 695 */       if (value <= slice[index] * sign) {
/*     */         continue;
/*     */       }
/*     */       
/* 699 */       slice[index] = value * sign;
/*     */ 
/*     */       
/* 702 */       for (z2 = zmin; z2 <= zmax; z2++) {
/*     */         
/* 704 */         for (int y2 = ymin; y2 <= ymax; y2++) {
/*     */           
/* 706 */           for (int x2 = xmin; x2 <= xmax; x2++)
/*     */           {
/* 708 */             updateQueue(x2, y2, z2, value, sign);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void updateQueue(int i, int j, int k, float value, int sign) {
/* 726 */     float maskValue = this.maskSlices[k][this.sizeX * j + i] * sign;
/* 727 */     value = Math.min(value, maskValue);
/*     */     
/* 729 */     float resultValue = this.resultSlices[k][this.sizeX * j + i] * sign;
/* 730 */     if (value > resultValue) {
/*     */       
/* 732 */       Cursor3D position = new Cursor3D(i, j, k);
/* 733 */       this.queue.add(position);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/morphology/geodrec/GeodesicReconstruction3DHybrid0Float.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */