/*     */ package inra.ijpb.morphology.strel;
/*     */ 
/*     */ import ij.process.ImageProcessor;
/*     */ import inra.ijpb.algo.AlgoEvent;
/*     */ import inra.ijpb.algo.AlgoListener;
/*     */ import java.util.Collection;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractSeparableStrel
/*     */   extends AbstractStrel
/*     */   implements SeparableStrel, AlgoListener
/*     */ {
/*     */   public ImageProcessor dilation(ImageProcessor image) {
/*  41 */     ImageProcessor result = image.duplicate();
/*     */ 
/*     */     
/*  44 */     Collection<InPlaceStrel> strels = decompose();
/*  45 */     int n = strels.size();
/*     */ 
/*     */ 
/*     */     
/*  49 */     int i = 1;
/*  50 */     for (InPlaceStrel strel : strels) {
/*     */       
/*  52 */       fireStatusChanged(this, createStatusMessage("Dilation", i, n));
/*  53 */       runDilation(result, strel);
/*  54 */       i++;
/*     */     } 
/*     */ 
/*     */     
/*  58 */     fireStatusChanged(this, "");
/*     */     
/*  60 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ImageProcessor erosion(ImageProcessor image) {
/*  66 */     ImageProcessor result = image.duplicate();
/*     */ 
/*     */     
/*  69 */     Collection<InPlaceStrel> strels = decompose();
/*  70 */     int n = strels.size();
/*     */ 
/*     */     
/*  73 */     int i = 1;
/*  74 */     for (InPlaceStrel strel : strels) {
/*     */       
/*  76 */       fireStatusChanged(this, createStatusMessage("Erosion", i, n));
/*  77 */       runErosion(result, strel);
/*  78 */       i++;
/*     */     } 
/*     */ 
/*     */     
/*  82 */     fireStatusChanged(this, "");
/*     */     
/*  84 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ImageProcessor closing(ImageProcessor image) {
/*  90 */     ImageProcessor result = image.duplicate();
/*     */ 
/*     */     
/*  93 */     Collection<InPlaceStrel> strels = decompose();
/*  94 */     int n = strels.size();
/*     */ 
/*     */     
/*  97 */     int i = 1;
/*  98 */     for (InPlaceStrel strel : strels) {
/*     */       
/* 100 */       fireStatusChanged(this, createStatusMessage("Dilation", i, n));
/* 101 */       runDilation(result, strel);
/* 102 */       i++;
/*     */     } 
/*     */ 
/*     */     
/* 106 */     i = 1;
/* 107 */     strels = reverse().decompose();
/* 108 */     for (InPlaceStrel strel : strels) {
/*     */       
/* 110 */       fireStatusChanged(this, createStatusMessage("Erosion", i, n));
/* 111 */       runErosion(result, strel);
/* 112 */       i++;
/*     */     } 
/*     */ 
/*     */     
/* 116 */     fireStatusChanged(this, "");
/*     */     
/* 118 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ImageProcessor opening(ImageProcessor image) {
/* 124 */     ImageProcessor result = image.duplicate();
/*     */ 
/*     */     
/* 127 */     Collection<InPlaceStrel> strels = decompose();
/* 128 */     int n = strels.size();
/*     */ 
/*     */     
/* 131 */     int i = 1;
/* 132 */     for (InPlaceStrel strel : strels) {
/*     */       
/* 134 */       fireStatusChanged(this, createStatusMessage("Erosion", i, n));
/* 135 */       runErosion(result, strel);
/* 136 */       i++;
/*     */     } 
/*     */ 
/*     */     
/* 140 */     i = 1;
/* 141 */     strels = reverse().decompose();
/* 142 */     for (InPlaceStrel strel : strels) {
/*     */       
/* 144 */       fireStatusChanged(this, createStatusMessage("Dilation", i, n));
/* 145 */       runDilation(result, strel);
/* 146 */       i++;
/*     */     } 
/*     */ 
/*     */     
/* 150 */     fireStatusChanged(this, "");
/*     */     
/* 152 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   private void runDilation(ImageProcessor image, InPlaceStrel strel) {
/* 157 */     strel.showProgress(showProgress());
/* 158 */     strel.addAlgoListener(this);
/* 159 */     strel.inPlaceDilation(image);
/* 160 */     strel.removeAlgoListener(this);
/*     */   }
/*     */ 
/*     */   
/*     */   private void runErosion(ImageProcessor image, InPlaceStrel strel) {
/* 165 */     strel.showProgress(showProgress());
/* 166 */     strel.addAlgoListener(this);
/* 167 */     strel.inPlaceErosion(image);
/* 168 */     strel.removeAlgoListener(this);
/*     */   }
/*     */ 
/*     */   
/*     */   private String createStatusMessage(String opName, int i, int n) {
/* 173 */     String channel = getChannelName();
/* 174 */     if (channel == null) {
/* 175 */       return String.valueOf(opName) + " " + i + "/" + n;
/*     */     }
/* 177 */     return String.valueOf(opName) + " " + channel + " " + i + "/" + n;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void algoProgressChanged(AlgoEvent evt) {
/* 185 */     fireProgressChanged(this, evt.getCurrentProgress(), evt.getTotalProgress());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void algoStatusChanged(AlgoEvent evt) {
/* 193 */     fireStatusChanged(this, evt.getStatus());
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/morphology/strel/AbstractSeparableStrel.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */