/*      */ package inra.ijpb.morphology.geodrec;
/*      */ 
/*      */ import ij.ImageStack;
/*      */ import inra.ijpb.data.image.Images3D;
/*      */ import java.util.LinkedList;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class GeodesicReconstructionByDilation3DGray8
/*      */   extends GeodesicReconstruction3DAlgoStub
/*      */ {
/*      */   ImageStack marker;
/*      */   ImageStack mask;
/*      */   ImageStack result;
/*   47 */   int size1 = 0;
/*      */   
/*   49 */   int size2 = 0;
/*      */   
/*   51 */   int size3 = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   LinkedList<int[]> queue;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean modif;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public GeodesicReconstructionByDilation3DGray8() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public GeodesicReconstructionByDilation3DGray8(int connectivity) {
/*   78 */     this.connectivity = connectivity;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ImageStack applyToTmp(ImageStack marker, ImageStack mask) {
/*   94 */     this.marker = marker;
/*   95 */     this.mask = mask;
/*      */ 
/*      */     
/*   98 */     this.size1 = marker.getWidth();
/*   99 */     this.size2 = marker.getHeight();
/*  100 */     this.size3 = marker.getSize();
/*  101 */     if (!Images3D.isSameSize(marker, mask))
/*      */     {
/*  103 */       throw new IllegalArgumentException(
/*  104 */           "Marker and Mask images must have the same size");
/*      */     }
/*      */ 
/*      */     
/*  108 */     if (this.connectivity != 6 && this.connectivity != 26)
/*      */     {
/*  110 */       throw new RuntimeException(
/*  111 */           "Connectivity for stacks must be either 6 or 26, not " + 
/*  112 */           this.connectivity);
/*      */     }
/*      */ 
/*      */     
/*  116 */     this.result = ImageStack.create(this.size1, this.size2, this.size3, 
/*  117 */         mask.getBitDepth());
/*      */ 
/*      */ 
/*      */     
/*  121 */     for (int z = 0; z < this.size3; z++) {
/*      */       
/*  123 */       for (int y = 0; y < this.size2; y++) {
/*      */         
/*  125 */         for (int x = 0; x < this.size1; x++)
/*      */         {
/*  127 */           this.result.setVoxel(
/*  128 */               x, 
/*  129 */               y, 
/*  130 */               z, 
/*  131 */               Math.min(this.marker.getVoxel(x, y, z), 
/*  132 */                 this.mask.getVoxel(x, y, z)));
/*      */         }
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  145 */     trace("Forward iteration");
/*  146 */     showStatus("Geod. Rec. by Dil. Fwd ");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  154 */     forwardDilationC26();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  159 */     trace("Backward iteration ");
/*  160 */     showStatus("Geod. Rec. by Dil. Bwd ");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  168 */     backwardDilationC26InitQueue();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  175 */     forwardDilationC26InitQueue();
/*      */ 
/*      */     
/*  178 */     processQueueC26();
/*      */     
/*  180 */     return this.result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ImageStack applyTo(ImageStack marker, ImageStack mask) {
/*  196 */     this.marker = marker;
/*  197 */     this.mask = mask;
/*      */ 
/*      */     
/*  200 */     this.size1 = marker.getWidth();
/*  201 */     this.size2 = marker.getHeight();
/*  202 */     this.size3 = marker.getSize();
/*  203 */     if (!Images3D.isSameSize(marker, mask))
/*      */     {
/*  205 */       throw new IllegalArgumentException("Marker and Mask images must have the same size");
/*      */     }
/*      */ 
/*      */     
/*  209 */     if (this.connectivity != 6 && this.connectivity != 26)
/*      */     {
/*  211 */       throw new RuntimeException(
/*  212 */           "Connectivity for stacks must be either 6 or 26, not " + 
/*  213 */           this.connectivity);
/*      */     }
/*      */     
/*  216 */     initializeResult();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  226 */     trace("Forward iteration");
/*  227 */     showStatus("FW Geod. Rec. by Dil.");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  235 */     forwardDilationC26();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  240 */     trace("Backward iteration ");
/*  241 */     showStatus("BW Geod. Rec. by Dil.");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  249 */     backwardDilationC26();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  257 */     trace("Forward-Init iteration ");
/*  258 */     showStatus("FW Init Geod. Rec. by Dil.");
/*      */     
/*  260 */     forwardDilationC26InitQueue();
/*      */ 
/*      */ 
/*      */     
/*  264 */     trace("Process Queue ");
/*  265 */     showStatus("Queue Geod. Rec. by Dil.");
/*  266 */     processQueueC26();
/*      */ 
/*      */     
/*  269 */     showProgress(1.0D, 1.0D, "");
/*      */     
/*  271 */     return this.result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ImageStack applyToOld(ImageStack marker, ImageStack mask) {
/*  288 */     this.marker = marker;
/*  289 */     this.mask = mask;
/*      */ 
/*      */     
/*  292 */     this.size1 = marker.getWidth();
/*  293 */     this.size2 = marker.getHeight();
/*  294 */     this.size3 = marker.getSize();
/*  295 */     if (this.size1 != mask.getWidth() || this.size2 != mask.getHeight() || 
/*  296 */       this.size3 != mask.getSize())
/*      */     {
/*  298 */       throw new IllegalArgumentException("Marker and Mask images must have the same size");
/*      */     }
/*      */ 
/*      */     
/*  302 */     if (this.connectivity != 6 && this.connectivity != 26)
/*      */     {
/*  304 */       throw new RuntimeException(
/*  305 */           "Connectivity for stacks must be either 6 or 26, not " + 
/*  306 */           this.connectivity);
/*      */     }
/*      */ 
/*      */     
/*  310 */     this.result = ImageStack.create(this.size1, this.size2, this.size3, marker.getBitDepth());
/*      */ 
/*      */ 
/*      */     
/*  314 */     for (int z = 0; z < this.size3; z++) {
/*      */       
/*  316 */       for (int y = 0; y < this.size2; y++) {
/*      */         
/*  318 */         for (int x = 0; x < this.size1; x++)
/*      */         {
/*  320 */           this.result.setVoxel(x, y, z, 
/*  321 */               Math.min(this.marker.getVoxel(x, y, z), this.mask.getVoxel(x, y, z)));
/*      */         }
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  327 */     int iter = 0;
/*      */ 
/*      */ 
/*      */     
/*      */     do {
/*  332 */       this.modif = false;
/*      */ 
/*      */       
/*  335 */       trace("Forward iteration " + iter);
/*  336 */       showStatus("FW Geod. Rec. by Dil." + (iter + 1));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  344 */       forwardDilationC26();
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  349 */       trace("Backward iteration " + iter);
/*  350 */       showStatus("BW Geod. Rec. by Dil." + (iter + 1));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  358 */       backwardDilationC26();
/*      */ 
/*      */ 
/*      */       
/*  362 */       iter++;
/*  363 */     } while (this.modif);
/*      */     
/*  365 */     return this.result;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void initializeResult() {
/*  371 */     this.result = ImageStack.create(this.size1, this.size2, this.size3, this.mask.getBitDepth());
/*      */     
/*  373 */     Object[] stack = this.result.getImageArray();
/*  374 */     Object[] markerStack = this.marker.getImageArray();
/*  375 */     Object[] maskStack = this.mask.getImageArray();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  382 */     for (int z = 0; z < this.size3; z++) {
/*      */       
/*  384 */       byte[] slice = (byte[])stack[z];
/*  385 */       byte[] maskSlice = (byte[])maskStack[z];
/*  386 */       byte[] markerSlice = (byte[])markerStack[z];
/*      */       
/*  388 */       for (int y = 0; y < this.size2; y++) {
/*      */         
/*  390 */         for (int x = 0; x < this.size1; x++) {
/*      */           
/*  392 */           int index = y * this.size1 + x;
/*  393 */           int value = Math.min(markerSlice[index] & 0xFF, 
/*  394 */               maskSlice[index] & 0xFF);
/*  395 */           slice[index] = (byte)value;
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void initializeResult(ImageStack binaryMask) {
/*  404 */     this.result = ImageStack.create(this.size1, this.size2, this.size3, this.mask.getBitDepth());
/*      */     
/*  406 */     Object[] stack = this.result.getImageArray();
/*  407 */     Object[] markerStack = this.marker.getImageArray();
/*  408 */     Object[] maskStack = this.mask.getImageArray();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  415 */     for (int z = 0; z < this.size3; z++) {
/*      */       
/*  417 */       byte[] slice = (byte[])stack[z];
/*  418 */       byte[] maskSlice = (byte[])maskStack[z];
/*  419 */       byte[] markerSlice = (byte[])markerStack[z];
/*      */       
/*  421 */       for (int y = 0; y < this.size2; y++) {
/*      */         
/*  423 */         for (int x = 0; x < this.size1; x++) {
/*      */           
/*  425 */           if (binaryMask.getVoxel(x, y, z) != 0.0D) {
/*      */             
/*  427 */             int index = y * this.size1 + x;
/*  428 */             int value = Math.min(markerSlice[index] & 0xFF, maskSlice[index] & 0xFF);
/*  429 */             slice[index] = (byte)value;
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void forwardDilationC26() {
/*  491 */     Object[] stack = this.result.getImageArray();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  496 */     for (int z = 0; z < this.size3; z++) {
/*      */       
/*  498 */       showProgress(z, this.size3, "z = " + z);
/*  499 */       byte[] slice = (byte[])stack[z];
/*  500 */       for (int y = 0; y < this.size2; y++) {
/*      */         
/*  502 */         for (int x = 0; x < this.size1; x++) {
/*      */           
/*  504 */           int currentValue = slice[y * this.size1 + x] & 0xFF;
/*      */           
/*  506 */           int maxValue = currentValue;
/*      */ 
/*      */           
/*  509 */           int zmax = Math.min(z + 1, this.size3);
/*  510 */           for (int z2 = Math.max(z - 1, 0); z2 < zmax; z2++) {
/*      */             
/*  512 */             byte[] slice2 = (byte[])stack[z2];
/*      */             
/*  514 */             int ymax = (z2 == z) ? y : Math.min(y + 2, this.size2);
/*  515 */             for (int y2 = Math.max(y - 1, 0); y2 < ymax; y2++) {
/*      */               
/*  517 */               int xmax = (z2 == z && y2 == y) ? x : Math.min(x + 2, 
/*  518 */                   this.size1);
/*  519 */               for (int x2 = Math.max(x - 1, 0); x2 < xmax; x2++) {
/*      */                 
/*  521 */                 int neighborValue = slice2[y2 * this.size1 + x2] & 0xFF;
/*  522 */                 if (neighborValue > maxValue) {
/*  523 */                   maxValue = neighborValue;
/*      */                 }
/*      */               } 
/*      */             } 
/*      */           } 
/*      */           
/*  529 */           maxValue = Math.min(maxValue, (int)this.mask.getVoxel(x, y, z));
/*  530 */           if (maxValue > currentValue)
/*      */           {
/*  532 */             slice[y * this.size1 + x] = (byte)(maxValue & 0xFF);
/*      */           }
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void forwardDilationC26(ImageStack binaryMask) {
/*  549 */     Object[] stack = this.result.getImageArray();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  554 */     for (int z = 0; z < this.size3; z++) {
/*      */       
/*  556 */       showProgress(z, this.size3, "z = " + z);
/*  557 */       byte[] slice = (byte[])stack[z];
/*  558 */       for (int y = 0; y < this.size2; y++) {
/*      */         
/*  560 */         for (int x = 0; x < this.size1; x++) {
/*      */           
/*  562 */           if (binaryMask.getVoxel(x, y, z) != 0.0D) {
/*      */             
/*  564 */             int currentValue = slice[y * this.size1 + x] & 0xFF;
/*      */             
/*  566 */             int maxValue = currentValue;
/*      */ 
/*      */             
/*  569 */             int zmax = Math.min(z + 1, this.size3);
/*  570 */             for (int z2 = Math.max(z - 1, 0); z2 < zmax; z2++) {
/*      */               
/*  572 */               byte[] slice2 = (byte[])stack[z2];
/*  573 */               int ymax = (z2 == z) ? y : Math.min(y + 2, this.size2);
/*  574 */               for (int y2 = Math.max(y - 1, 0); y2 < ymax; y2++) {
/*      */                 
/*  576 */                 int xmax = (z2 == z && y2 == y) ? x : Math.min(
/*  577 */                     x + 2, this.size1);
/*  578 */                 for (int x2 = Math.max(x - 1, 0); x2 < xmax; x2++) {
/*      */                   
/*  580 */                   int neighborValue = slice2[y2 * this.size1 + x2] & 0xFF;
/*  581 */                   if (neighborValue > maxValue) {
/*  582 */                     maxValue = neighborValue;
/*      */                   }
/*      */                 } 
/*      */               } 
/*      */             } 
/*      */             
/*  588 */             maxValue = Math.min(maxValue, (int)this.mask.getVoxel(x, y, z));
/*  589 */             if (maxValue > currentValue)
/*      */             {
/*  591 */               slice[y * this.size1 + x] = (byte)(maxValue & 0xFF);
/*      */             }
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void forwardDilationC26InitQueue() {
/*  607 */     Object[] stack = this.result.getImageArray();
/*  608 */     Object[] maskStack = this.mask.getImageArray();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  613 */     this.queue = (LinkedList)new LinkedList<int>();
/*      */ 
/*      */     
/*  616 */     for (int z = 0; z < this.size3; z++) {
/*      */       
/*  618 */       showProgress(z, this.size3, "z = " + z);
/*  619 */       byte[] slice = (byte[])stack[z];
/*  620 */       for (int y = 0; y < this.size2; y++) {
/*      */         
/*  622 */         for (int x = 0; x < this.size1; x++) {
/*      */           
/*  624 */           int currentValue = slice[y * this.size1 + x] & 0xFF;
/*  625 */           int maxValue = currentValue;
/*      */ 
/*      */           
/*  628 */           int zmax = Math.min(z + 1, this.size3); int z2;
/*  629 */           for (z2 = Math.max(z - 1, 0); z2 < zmax; z2++) {
/*      */             
/*  631 */             slice = (byte[])stack[z2];
/*      */             
/*  633 */             int ymax = (z2 == z) ? y : Math.min(y + 2, this.size2);
/*  634 */             for (int y2 = Math.max(y - 1, 0); y2 < ymax; y2++) {
/*      */               
/*  636 */               int xmax = (z2 == z && y2 == y) ? x : Math.min(x + 2, 
/*  637 */                   this.size1);
/*  638 */               for (int x2 = Math.max(x - 1, 0); x2 < xmax; x2++) {
/*      */                 
/*  640 */                 int neighborValue = slice[y2 * this.size1 + x2] & 0xFF;
/*  641 */                 if (neighborValue > maxValue) {
/*  642 */                   maxValue = neighborValue;
/*      */                 }
/*      */               } 
/*      */             } 
/*      */           } 
/*      */           
/*  648 */           byte[] maskSlice = (byte[])maskStack[z];
/*  649 */           maxValue = Math.min(maxValue, maskSlice[y * this.size1 + x] & 0xFF);
/*      */ 
/*      */           
/*  652 */           if (maxValue > currentValue) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  658 */             this.result.setVoxel(x, y, z, maxValue);
/*  659 */             slice[y * this.size1 + x] = (byte)(maxValue & 0xFF);
/*      */ 
/*      */ 
/*      */             
/*  663 */             for (z2 = Math.max(z - 1, 0); z2 < zmax; z2++) {
/*      */               
/*  665 */               byte[] slice2 = (byte[])stack[z2];
/*  666 */               maskSlice = (byte[])maskStack[z2];
/*      */               
/*  668 */               int ymax = (z2 == z) ? y : Math.min(y + 2, this.size2);
/*  669 */               for (int y2 = Math.max(y - 1, 0); y2 < ymax; y2++) {
/*      */                 
/*  671 */                 int xmax = (z2 == z && y2 == y) ? x : Math.min(x + 2, 
/*  672 */                     this.size1);
/*  673 */                 for (int x2 = Math.max(x - 1, 0); x2 < xmax; x2++) {
/*      */                   
/*  675 */                   int index = y2 * this.size1 + x2;
/*  676 */                   int neighborValue = slice2[index] & 0xFF;
/*  677 */                   int maskValue = maskSlice[index] & 0xFF;
/*  678 */                   if (neighborValue < maxValue && 
/*  679 */                     neighborValue < maskValue) {
/*      */                     
/*  681 */                     int[] pos = { x2, y2, z2 };
/*  682 */                     this.queue.addLast(pos);
/*      */                   } 
/*      */                 } 
/*      */               } 
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void backwardDilationC26() {
/*  735 */     Object[] stack = this.result.getImageArray();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  740 */     for (int z = this.size3 - 1; z >= 0; z--) {
/*      */       
/*  742 */       byte[] slice = (byte[])stack[z];
/*  743 */       showProgress((this.size3 - 1 - z), this.size3);
/*  744 */       for (int y = this.size2 - 1; y >= 0; y--) {
/*      */         
/*  746 */         for (int x = this.size1 - 1; x >= 0; x--) {
/*      */           
/*  748 */           int currentValue = slice[y * this.size1 + x] & 0xFF;
/*  749 */           int maxValue = currentValue;
/*      */ 
/*      */           
/*  752 */           int zmin = Math.max(z - 1, 0);
/*  753 */           for (int z2 = Math.min(z + 1, this.size3 - 1); z2 >= zmin; z2--) {
/*      */             
/*  755 */             byte[] slice2 = (byte[])stack[z2];
/*      */             
/*  757 */             int ymin = (z2 == z) ? y : Math.max(y - 1, 0);
/*  758 */             for (int y2 = Math.min(y + 1, this.size2 - 1); y2 >= ymin; y2--) {
/*      */               
/*  760 */               int xmin = (z2 == z && y2 == y) ? x : Math.max(x - 1, 0);
/*  761 */               for (int x2 = Math.min(x + 1, this.size1 - 1); x2 >= xmin; x2--) {
/*      */                 
/*  763 */                 int index = y2 * this.size1 + x2;
/*  764 */                 int neighborValue = slice2[index] & 0xFF;
/*  765 */                 if (neighborValue > maxValue) {
/*  766 */                   maxValue = neighborValue;
/*      */                 }
/*      */               } 
/*      */             } 
/*      */           } 
/*      */           
/*  772 */           maxValue = Math.min(maxValue, (int)this.mask.getVoxel(x, y, z));
/*  773 */           if (maxValue > currentValue)
/*      */           {
/*  775 */             slice[y * this.size1 + x] = (byte)(maxValue & 0xFF);
/*      */           }
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void backwardDilationC26(ImageStack binaryMask) {
/*  792 */     Object[] stack = this.result.getImageArray();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  797 */     for (int z = this.size3 - 1; z >= 0; z--) {
/*      */       
/*  799 */       byte[] slice = (byte[])stack[z];
/*  800 */       showProgress((this.size3 - 1 - z), this.size3);
/*  801 */       for (int y = this.size2 - 1; y >= 0; y--) {
/*      */         
/*  803 */         for (int x = this.size1 - 1; x >= 0; x--) {
/*      */           
/*  805 */           if (binaryMask.getVoxel(x, y, z) != 0.0D) {
/*      */             
/*  807 */             int currentValue = slice[y * this.size1 + x] & 0xFF;
/*  808 */             int maxValue = currentValue;
/*      */ 
/*      */             
/*  811 */             int zmin = Math.max(z - 1, 0);
/*  812 */             for (int z2 = Math.min(z + 1, this.size3 - 1); z2 >= zmin; z2--) {
/*      */               
/*  814 */               byte[] slice2 = (byte[])stack[z2];
/*      */               
/*  816 */               int ymin = (z2 == z) ? y : Math.max(y - 1, 0);
/*  817 */               for (int y2 = Math.min(y + 1, this.size2 - 1); y2 >= ymin; y2--) {
/*      */                 
/*  819 */                 int xmin = (z2 == z && y2 == y) ? x : Math.max(
/*  820 */                     x - 1, 0);
/*  821 */                 for (int x2 = Math.min(x + 1, this.size1 - 1); x2 >= xmin; x2--) {
/*      */                   
/*  823 */                   int index = y2 * this.size1 + x2;
/*  824 */                   int neighborValue = slice2[index] & 0xFF;
/*  825 */                   if (neighborValue > maxValue) {
/*  826 */                     maxValue = neighborValue;
/*      */                   }
/*      */                 } 
/*      */               } 
/*      */             } 
/*      */             
/*  832 */             maxValue = Math.min(maxValue, (int)this.mask.getVoxel(x, y, z));
/*  833 */             if (maxValue > currentValue)
/*      */             {
/*  835 */               slice[y * this.size1 + x] = (byte)(maxValue & 0xFF);
/*      */             }
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void backwardDilationC26InitQueue() {
/*  853 */     Object[] stack = this.result.getImageArray();
/*  854 */     Object[] maskStack = this.mask.getImageArray();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  859 */     this.queue = (LinkedList)new LinkedList<int>();
/*      */ 
/*      */     
/*  862 */     for (int z = this.size3 - 1; z >= 0; z--) {
/*      */       
/*  864 */       byte[] slice = (byte[])stack[z];
/*  865 */       showProgress((this.size3 - 1 - z), this.size3);
/*  866 */       for (int y = this.size2 - 1; y >= 0; y--) {
/*      */         
/*  868 */         for (int x = this.size1 - 1; x >= 0; x--) {
/*      */ 
/*      */           
/*  871 */           int currentValue = slice[y * this.size1 + x] & 0xFF;
/*  872 */           int maxValue = currentValue;
/*      */ 
/*      */           
/*  875 */           int zmin = Math.max(z - 1, 0); int z2;
/*  876 */           for (z2 = Math.min(z + 1, this.size3 - 1); z2 >= zmin; z2--) {
/*      */             
/*  878 */             byte[] slice2 = (byte[])stack[z2];
/*      */             
/*  880 */             int ymin = (z2 == z) ? y : Math.max(y - 1, 0);
/*  881 */             for (int y2 = Math.min(y + 1, this.size2 - 1); y2 >= ymin; y2--) {
/*      */               
/*  883 */               int xmin = (z2 == z && y2 == y) ? x : Math.max(x - 1, 0);
/*  884 */               for (int x2 = Math.min(x + 1, this.size1 - 1); x2 >= xmin; x2--) {
/*      */                 
/*  886 */                 int index = y2 * this.size1 + x2;
/*  887 */                 int neighborValue = slice2[index] & 0xFF;
/*  888 */                 if (neighborValue > maxValue) {
/*  889 */                   maxValue = neighborValue;
/*      */                 }
/*      */               } 
/*      */             } 
/*      */           } 
/*      */ 
/*      */           
/*  896 */           byte[] maskSlice = (byte[])maskStack[z];
/*  897 */           maxValue = Math.min(maxValue, maskSlice[y * this.size1 + x] & 0xFF);
/*      */ 
/*      */           
/*  900 */           if (maxValue > currentValue) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  906 */             this.result.setVoxel(x, y, z, maxValue);
/*  907 */             slice[y * this.size1 + x] = (byte)(maxValue & 0xFF);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  917 */             for (z2 = Math.min(z + 1, this.size3 - 1); z2 >= zmin; z2--) {
/*      */               
/*  919 */               byte[] slice2 = (byte[])stack[z2];
/*  920 */               maskSlice = (byte[])maskStack[z2];
/*      */               
/*  922 */               int ymin = (z2 == z) ? y : Math.max(y - 1, 0);
/*  923 */               for (int y2 = Math.min(y + 1, this.size2 - 1); y2 >= ymin; y2--) {
/*      */                 
/*  925 */                 int xmin = (z2 == z && y2 == y) ? x : Math.max(x - 1, 0);
/*  926 */                 for (int x2 = Math.min(x + 1, this.size1 - 1); x2 >= xmin; x2--) {
/*      */                   
/*  928 */                   int index = y2 * this.size1 + x2;
/*  929 */                   int neighborValue = slice2[index] & 0xFF;
/*  930 */                   int maskValue = maskSlice[index] & 0xFF;
/*  931 */                   if (neighborValue < maxValue && neighborValue < maskValue) {
/*      */                     
/*  933 */                     int[] pos = { x2, y2, z2 };
/*  934 */                     this.queue.addLast(pos);
/*      */                   } 
/*      */                 } 
/*      */               } 
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void processQueueC26() {
/*  947 */     Object[] stack = this.result.getImageArray();
/*  948 */     Object[] maskStack = this.mask.getImageArray();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  953 */     int total = this.queue.size();
/*  954 */     int iter = 1;
/*      */ 
/*      */     
/*  957 */     while (!this.queue.isEmpty()) {
/*      */       
/*  959 */       showProgress(iter, total);
/*  960 */       trace("iter " + iter++ + " over " + total);
/*      */       
/*  962 */       int[] p = this.queue.pollFirst();
/*  963 */       int x = p[0];
/*  964 */       int y = p[1];
/*  965 */       int z = p[2];
/*      */       
/*  967 */       byte[] slice = (byte[])stack[z];
/*  968 */       byte[] maskSlice = (byte[])maskStack[z];
/*  969 */       int index = y * this.size1 + x;
/*  970 */       int currentValue = slice[index] & 0xFF;
/*  971 */       int maskValue = maskSlice[index] & 0xFF;
/*  972 */       if (currentValue == maskValue) {
/*      */         continue;
/*      */       }
/*      */ 
/*      */       
/*  977 */       double maxValue = currentValue; int z2;
/*  978 */       for (z2 = Math.max(z - 1, 0); z2 < Math.min(z + 2, this.size3); z2++) {
/*      */         
/*  980 */         byte[] slice2 = (byte[])stack[z2];
/*  981 */         for (int y2 = Math.max(y - 1, 0); y2 < Math.min(y + 2, this.size2); y2++) {
/*      */           
/*  983 */           for (int x2 = Math.max(x - 1, 0); x2 < Math.min(x + 2, this.size1); x2++) {
/*      */             
/*  985 */             int value = slice2[y2 * this.size1 + x2] & 0xFF;
/*  986 */             if (value > maxValue) {
/*  987 */               maxValue = value;
/*      */             }
/*      */           } 
/*      */         } 
/*      */       } 
/*      */       
/*  993 */       maxValue = Math.min(maxValue, maskValue);
/*  994 */       if (maxValue <= currentValue) {
/*      */         continue;
/*      */       }
/*      */ 
/*      */       
/*  999 */       slice[index] = (byte)((int)maxValue & 0xFF);
/*      */ 
/*      */       
/* 1002 */       for (z2 = Math.max(z - 1, 0); z2 < Math.min(z + 2, this.size3); z2++) {
/*      */         
/* 1004 */         byte[] slice2 = (byte[])stack[z2];
/* 1005 */         maskSlice = (byte[])maskStack[z2];
/* 1006 */         for (int y2 = Math.max(y - 1, 0); y2 < Math.min(y + 2, this.size2); y2++) {
/*      */           
/* 1008 */           for (int x2 = Math.max(x - 1, 0); x2 < Math.min(x + 2, this.size1); x2++) {
/*      */             
/* 1010 */             index = y2 * this.size1 + x2;
/* 1011 */             int value = slice2[index] & 0xFF;
/* 1012 */             maskValue = maskSlice[index] & 0xFF;
/*      */             
/* 1014 */             if (value < maxValue && value < maskValue) {
/*      */               
/* 1016 */               int[] pos = { x2, y2, z2 };
/* 1017 */               this.queue.addLast(pos);
/* 1018 */               total++;
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } 
/*      */       
/* 1024 */       iter++;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void processQueueC26(ImageStack binaryMask) {
/* 1030 */     Object[] stack = this.result.getImageArray();
/* 1031 */     Object[] maskStack = this.mask.getImageArray();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1036 */     int total = this.queue.size();
/* 1037 */     int iter = 1;
/*      */ 
/*      */     
/* 1040 */     while (!this.queue.isEmpty()) {
/*      */       
/* 1042 */       showProgress(iter, total);
/* 1043 */       trace("iter " + iter++ + " over " + total);
/*      */       
/* 1045 */       int[] p = this.queue.pollFirst();
/* 1046 */       int x = p[0];
/* 1047 */       int y = p[1];
/* 1048 */       int z = p[2];
/*      */       
/* 1050 */       if (binaryMask.getVoxel(x, y, z) == 0.0D) {
/*      */         continue;
/*      */       }
/*      */       
/* 1054 */       byte[] slice = (byte[])stack[z];
/* 1055 */       byte[] maskSlice = (byte[])maskStack[z];
/* 1056 */       int index = y * this.size1 + x;
/* 1057 */       int currentValue = slice[index] & 0xFF;
/* 1058 */       int maskValue = maskSlice[index] & 0xFF;
/* 1059 */       if (currentValue == maskValue) {
/*      */         continue;
/*      */       }
/*      */       
/* 1063 */       double maxValue = currentValue; int z2;
/* 1064 */       for (z2 = Math.max(z - 1, 0); z2 < Math.min(z + 2, this.size3); z2++) {
/*      */         
/* 1066 */         byte[] slice2 = (byte[])stack[z2];
/* 1067 */         for (int y2 = Math.max(y - 1, 0); y2 < Math.min(y + 2, this.size2); y2++) {
/*      */           
/* 1069 */           for (int x2 = Math.max(x - 1, 0); x2 < Math.min(x + 2, this.size1); x2++) {
/*      */             
/* 1071 */             int value = slice2[y2 * this.size1 + x2] & 0xFF;
/* 1072 */             if (value > maxValue) {
/* 1073 */               maxValue = value;
/*      */             }
/*      */           } 
/*      */         } 
/*      */       } 
/*      */       
/* 1079 */       maxValue = Math.min(maxValue, maskValue);
/* 1080 */       if (maxValue <= currentValue) {
/*      */         continue;
/*      */       }
/*      */ 
/*      */       
/* 1085 */       slice[index] = (byte)((int)maxValue & 0xFF);
/*      */ 
/*      */       
/* 1088 */       for (z2 = Math.max(z - 1, 0); z2 < Math.min(z + 2, this.size3); z2++) {
/*      */         
/* 1090 */         byte[] slice2 = (byte[])stack[z2];
/* 1091 */         maskSlice = (byte[])maskStack[z2];
/* 1092 */         for (int y2 = Math.max(y - 1, 0); y2 < Math.min(y + 2, this.size2); y2++) {
/*      */           
/* 1094 */           for (int x2 = Math.max(x - 1, 0); x2 < Math.min(x + 2, this.size1); x2++) {
/*      */             
/* 1096 */             index = y2 * this.size1 + x2;
/* 1097 */             int value = slice2[index] & 0xFF;
/* 1098 */             maskValue = maskSlice[index] & 0xFF;
/*      */             
/* 1100 */             if (value < maxValue && value < maskValue) {
/*      */               
/* 1102 */               int[] pos = { x2, y2, z2 };
/* 1103 */               this.queue.addLast(pos);
/* 1104 */               total++;
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } 
/*      */       
/* 1110 */       iter++;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ImageStack applyTo(ImageStack marker, ImageStack mask, ImageStack binaryMask) {
/* 1119 */     this.marker = marker;
/* 1120 */     this.mask = mask;
/*      */ 
/*      */     
/* 1123 */     this.size1 = marker.getWidth();
/* 1124 */     this.size2 = marker.getHeight();
/* 1125 */     this.size3 = marker.getSize();
/* 1126 */     if (this.size1 != mask.getWidth() || this.size2 != mask.getHeight() || this.size3 != mask.getSize())
/*      */     {
/* 1128 */       throw new IllegalArgumentException("Marker and Mask images must have the same size");
/*      */     }
/*      */ 
/*      */     
/* 1132 */     if (this.connectivity != 6 && this.connectivity != 26)
/*      */     {
/* 1134 */       throw new RuntimeException(
/* 1135 */           "Connectivity for stacks must be either 6 or 26, not " + 
/* 1136 */           this.connectivity);
/*      */     }
/*      */     
/* 1139 */     initializeResult(binaryMask);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1149 */     trace("Forward iteration");
/* 1150 */     showStatus("FW Geod. Rec. by Dil.");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1158 */     forwardDilationC26(binaryMask);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1163 */     trace("Backward iteration ");
/* 1164 */     showStatus("BW Geod. Rec. by Dil.");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1172 */     backwardDilationC26(binaryMask);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1179 */     forwardDilationC26InitQueue();
/*      */ 
/*      */     
/* 1182 */     processQueueC26(binaryMask);
/*      */     
/* 1184 */     return this.result;
/*      */   }
/*      */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/morphology/geodrec/GeodesicReconstructionByDilation3DGray8.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */