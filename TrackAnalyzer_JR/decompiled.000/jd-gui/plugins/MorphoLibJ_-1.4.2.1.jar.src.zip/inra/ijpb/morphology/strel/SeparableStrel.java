package inra.ijpb.morphology.strel;

import inra.ijpb.morphology.Strel;
import java.util.Collection;

public interface SeparableStrel extends Strel {
  Collection<InPlaceStrel> decompose();
  
  SeparableStrel reverse();
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/morphology/strel/SeparableStrel.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */