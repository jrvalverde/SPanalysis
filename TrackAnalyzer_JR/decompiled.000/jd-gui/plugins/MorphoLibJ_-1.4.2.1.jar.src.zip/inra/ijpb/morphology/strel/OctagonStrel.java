/*     */ package inra.ijpb.morphology.strel;
/*     */ 
/*     */ import inra.ijpb.morphology.Strel;
/*     */ import inra.ijpb.morphology.Strel3D;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OctagonStrel
/*     */   extends AbstractSeparableStrel
/*     */ {
/*     */   int size;
/*     */   int offset;
/*     */   int squareSize;
/*     */   int diagSize;
/*     */   int squareOffset;
/*     */   int diagOffset;
/*     */   
/*     */   public static final OctagonStrel fromDiameter(int diam) {
/*  41 */     return new OctagonStrel(diam);
/*     */   }
/*     */   
/*     */   public static final OctagonStrel fromRadius(int radius) {
/*  45 */     return new OctagonStrel(2 * radius + 1, radius);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OctagonStrel(int size) {
/*  89 */     this(size, (int)Math.floor(((size - 1) / 2)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OctagonStrel(int size, int offset) {
/* 106 */     if (size < 1) {
/* 107 */       throw new IllegalArgumentException("Requires a positive size");
/*     */     }
/* 109 */     this.size = size;
/*     */     
/* 111 */     if (offset < 0) {
/* 112 */       throw new IllegalArgumentException("Requires a non-negative offset");
/*     */     }
/* 114 */     if (offset >= size) {
/* 115 */       throw new IllegalArgumentException("Offset can not be greater than size");
/*     */     }
/* 117 */     this.offset = offset;
/*     */ 
/*     */     
/* 120 */     this.diagSize = (int)Math.round((this.size + 2) / (2.0D + Math.sqrt(2.0D)));
/* 121 */     this.squareSize = this.size - 2 * (this.diagSize - 1);
/*     */ 
/*     */     
/* 124 */     this.squareOffset = (int)Math.floor(((this.squareSize - 1) / 2));
/* 125 */     this.diagOffset = (int)Math.floor(((this.diagSize - 1) / 2));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected OctagonStrel(int squareSize, int diagSize, int squareOffset, int diagOffset) {
/* 147 */     if (squareSize < 1) {
/* 148 */       throw new IllegalArgumentException("Requires a positive square size");
/*     */     }
/* 150 */     this.squareSize = squareSize;
/*     */     
/* 152 */     if (diagSize < 1) {
/* 153 */       throw new IllegalArgumentException("Requires a positive diagonal size");
/*     */     }
/* 155 */     this.diagSize = diagSize;
/*     */     
/* 157 */     if (squareOffset < 0) {
/* 158 */       throw new IllegalArgumentException("Requires a non-negative square offset");
/*     */     }
/* 160 */     this.squareOffset = squareOffset;
/*     */     
/* 162 */     if (diagOffset < 0) {
/* 163 */       throw new RuntimeException("Requires a non-negative diagonal offset");
/*     */     }
/* 165 */     this.diagOffset = diagOffset;
/*     */     
/* 167 */     this.size = this.squareSize + 2 * (this.diagSize - 1);
/* 168 */     this.offset = this.squareOffset + this.diagSize - 1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection<InPlaceStrel> decompose() {
/* 190 */     int horizOffset = this.squareOffset;
/* 191 */     if (this.diagSize % 2 == 0) {
/* 192 */       horizOffset = this.squareSize - 1 - this.squareOffset;
/*     */     }
/*     */     
/* 195 */     ArrayList<InPlaceStrel> strels = new ArrayList<InPlaceStrel>(4);
/*     */ 
/*     */     
/* 198 */     strels.add(new LinearHorizontalStrel(this.squareSize, horizOffset));
/* 199 */     strels.add(new LinearVerticalStrel(this.squareSize, this.squareOffset));
/* 200 */     strels.add(new LinearDiagUpStrel(this.diagSize, this.diagOffset));
/* 201 */     strels.add(new LinearDiagDownStrel(this.diagSize, this.diagOffset));
/* 202 */     return strels;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int[][] getMask() {
/* 211 */     int[][] mask = new int[this.size][this.size];
/*     */ 
/*     */     
/* 214 */     for (int y = this.diagSize; y < this.size - this.diagSize; y++) {
/* 215 */       for (int j = 0; j < this.size; j++) {
/* 216 */         mask[y][j] = 255;
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 221 */     for (int x = this.diagSize; x < this.size - this.diagSize; x++) {
/* 222 */       for (int j = 0; j < this.size; j++) {
/* 223 */         mask[j][x] = 255;
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 228 */     for (int i = 0; i < this.diagSize; i++);
/*     */ 
/*     */ 
/*     */     
/* 232 */     return mask;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int[][] getShifts() {
/* 240 */     int n = this.size * this.size;
/* 241 */     int[][] shifts = new int[n][2];
/* 242 */     int i = 0;
/*     */     
/* 244 */     for (int y = 0; y < this.size; y++) {
/* 245 */       for (int x = 0; x < this.size; x++) {
/* 246 */         shifts[i][0] = x - this.offset;
/* 247 */         shifts[i][1] = x - this.offset;
/* 248 */         i++;
/*     */       } 
/*     */     } 
/* 251 */     return shifts;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int[] getSize() {
/* 259 */     return new int[] { this.size, this.size };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int[] getOffset() {
/* 267 */     return new int[] { this.offset, this.offset };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OctagonStrel reverse() {
/* 275 */     return new OctagonStrel(this.squareSize, this.diagSize, 
/* 276 */         this.squareSize - this.squareOffset - 1, 
/* 277 */         this.diagSize - this.diagOffset - 1);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/morphology/strel/OctagonStrel.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */