/*     */ package inra.ijpb.morphology;
/*     */ 
/*     */ import ij.ImageStack;
/*     */ import inra.ijpb.algo.Algo;
/*     */ import inra.ijpb.morphology.strel.BallStrel;
/*     */ import inra.ijpb.morphology.strel.Cross3x3Strel;
/*     */ import inra.ijpb.morphology.strel.CubeStrel;
/*     */ import inra.ijpb.morphology.strel.CuboidStrel;
/*     */ import inra.ijpb.morphology.strel.DiamondStrel;
/*     */ import inra.ijpb.morphology.strel.EllipsoidStrel;
/*     */ import inra.ijpb.morphology.strel.ExtrudedStrel;
/*     */ import inra.ijpb.morphology.strel.LinearDepthStrel3D;
/*     */ import inra.ijpb.morphology.strel.LinearDiagDownStrel;
/*     */ import inra.ijpb.morphology.strel.LinearDiagUpStrel;
/*     */ import inra.ijpb.morphology.strel.LinearHorizontalStrel;
/*     */ import inra.ijpb.morphology.strel.LinearVerticalStrel;
/*     */ import inra.ijpb.morphology.strel.OctagonStrel;
/*     */ import inra.ijpb.morphology.strel.SquareStrel;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface Strel3D
/*     */   extends Algo
/*     */ {
/*     */   public static final int BACKGROUND = 0;
/*     */   public static final int FOREGROUND = 255;
/*     */   
/*     */   int[] getSize();
/*     */   
/*     */   int[][][] getMask3D();
/*     */   
/*     */   int[] getOffset();
/*     */   
/*     */   int[][] getShifts3D();
/*     */   
/*     */   Strel3D reverse();
/*     */   
/*     */   ImageStack dilation(ImageStack paramImageStack);
/*     */   
/*     */   ImageStack erosion(ImageStack paramImageStack);
/*     */   
/*     */   ImageStack closing(ImageStack paramImageStack);
/*     */   
/*     */   ImageStack opening(ImageStack paramImageStack);
/*     */   
/*     */   boolean showProgress();
/*     */   
/*     */   void showProgress(boolean paramBoolean);
/*     */   
/*     */   public enum Shape
/*     */   {
/*  64 */     BALL(
/*     */ 
/*     */ 
/*     */       
/*  68 */       "Ball"),
/*     */     
/*  70 */     CUBE(
/*     */ 
/*     */ 
/*     */       
/*  74 */       "Cube"),
/*     */     
/*  76 */     SQUARE(
/*     */ 
/*     */ 
/*     */       
/*  80 */       "Square"),
/*     */     
/*  82 */     DIAMOND(
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  87 */       "Diamond"),
/*     */     
/*  89 */     OCTAGON(
/*     */ 
/*     */ 
/*     */       
/*  93 */       "Octagon"),
/*     */     
/*  95 */     LINE_HORIZ(
/*     */ 
/*     */ 
/*     */       
/*  99 */       "Horizontal Line"),
/*     */     
/* 101 */     LINE_VERT(
/*     */ 
/*     */ 
/*     */       
/* 105 */       "Vertical Line"),
/*     */     
/* 107 */     LINE_Z(
/*     */ 
/*     */ 
/*     */       
/* 111 */       "Z-Line"),
/*     */     
/* 113 */     LINE_DIAG_UP(
/*     */ 
/*     */ 
/*     */       
/* 117 */       "Line 45 degrees"),
/*     */     
/* 119 */     LINE_DIAG_DOWN(
/*     */ 
/*     */ 
/*     */       
/* 123 */       "Line 135 degrees");
/*     */     
/*     */     private final String label;
/*     */     
/*     */     Shape(String label) {
/* 128 */       this.label = label;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String toString() {
/* 135 */       return this.label;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Strel3D fromRadius(int radius) {
/* 148 */       return fromDiameter(2 * radius + 1);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Strel3D fromRadiusList(int radiusX, int radiusY, int radiusZ) {
/* 167 */       if (this == BALL)
/* 168 */         return (Strel3D)EllipsoidStrel.fromRadiusList(radiusX, radiusY, radiusZ); 
/* 169 */       if (this == CUBE)
/* 170 */         return (Strel3D)CuboidStrel.fromRadiusList(radiusX, radiusY, radiusZ); 
/* 171 */       if (this == LINE_Z) {
/* 172 */         return (Strel3D)LinearDepthStrel3D.fromRadius(radiusZ);
/*     */       }
/* 174 */       if (radiusX != radiusY)
/*     */       {
/* 176 */         throw new IllegalArgumentException("For 2D structuring elements, radiusX and radiusY must be equal");
/*     */       }
/*     */ 
/*     */       
/* 180 */       Strel.Shape shape2d = Strel.Shape.fromLabel(this.label);
/* 181 */       Strel strel2d = shape2d.fromRadius(radiusX);
/*     */       
/* 183 */       int diamZ = 2 * radiusZ + 1;
/* 184 */       return (Strel3D)new ExtrudedStrel(strel2d, diamZ, radiusZ);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Strel3D fromDiameter(int diam) {
/* 195 */       if (this == BALL)
/* 196 */         return (Strel3D)BallStrel.fromDiameter(diam); 
/* 197 */       if (this == CUBE)
/* 198 */         return (Strel3D)CubeStrel.fromDiameter(diam); 
/* 199 */       if (this == LINE_Z)
/* 200 */         return (Strel3D)LinearDepthStrel3D.fromDiameter(diam); 
/* 201 */       if (this == SQUARE)
/* 202 */         return (Strel3D)new SquareStrel(diam); 
/* 203 */       if (this == DIAMOND) {
/* 204 */         if (diam == 3)
/* 205 */           return (Strel3D)new Cross3x3Strel(); 
/* 206 */         return (Strel3D)new DiamondStrel(diam);
/*     */       } 
/* 208 */       if (this == OCTAGON)
/* 209 */         return (Strel3D)new OctagonStrel(diam); 
/* 210 */       if (this == LINE_HORIZ)
/* 211 */         return (Strel3D)new LinearHorizontalStrel(diam); 
/* 212 */       if (this == LINE_VERT)
/* 213 */         return (Strel3D)new LinearVerticalStrel(diam); 
/* 214 */       if (this == LINE_DIAG_UP)
/* 215 */         return (Strel3D)new LinearDiagUpStrel(diam); 
/* 216 */       if (this == LINE_DIAG_DOWN) {
/* 217 */         return (Strel3D)new LinearDiagDownStrel(diam);
/*     */       }
/* 219 */       throw new IllegalArgumentException("No default method for creating element of type " + this.label);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Strel3D fromDiameterList(int diamX, int diamY, int diamZ) {
/* 236 */       if (this == BALL)
/* 237 */         return (Strel3D)EllipsoidStrel.fromDiameterList(diamX, diamY, diamZ); 
/* 238 */       if (this == CUBE)
/* 239 */         return (Strel3D)CuboidStrel.fromDiameterList(diamX, diamY, diamZ); 
/* 240 */       if (this == LINE_Z) {
/* 241 */         return (Strel3D)LinearDepthStrel3D.fromDiameter(diamZ);
/*     */       }
/* 243 */       if (diamX != diamY)
/*     */       {
/* 245 */         throw new IllegalArgumentException("For 2D structuring elements, radiusX and radiusY must be equal");
/*     */       }
/*     */ 
/*     */       
/* 249 */       Strel.Shape shape2d = Strel.Shape.fromLabel(this.label);
/* 250 */       Strel strel2d = shape2d.fromDiameter(diamX);
/*     */       
/* 252 */       return (Strel3D)new ExtrudedStrel(strel2d, diamZ, (diamZ - 1) / 2);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static String[] getAllLabels() {
/* 261 */       Shape[] values = values();
/* 262 */       int n = values.length;
/*     */ 
/*     */       
/* 265 */       String[] result = new String[n];
/* 266 */       for (int i = 0; i < n; i++) {
/* 267 */         result[i] = (values[i]).label;
/*     */       }
/* 269 */       return result;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static Shape fromLabel(String label) {
/* 283 */       if (label != null)
/* 284 */         label = label.toLowerCase();  byte b; int i; Shape[] arrayOfShape;
/* 285 */       for (i = (arrayOfShape = values()).length, b = 0; b < i; ) { Shape type = arrayOfShape[b];
/* 286 */         if (type.label.toLowerCase().equals(label))
/* 287 */           return type;  b++; }
/*     */       
/* 289 */       throw new IllegalArgumentException("Unable to parse Strel.Shape with label: " + label);
/*     */     }
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/morphology/Strel3D.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */