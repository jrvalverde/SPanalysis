/*     */ package inra.ijpb.morphology.geodrec;
/*     */ 
/*     */ import ij.ImageStack;
/*     */ import inra.ijpb.data.Cursor3D;
/*     */ import inra.ijpb.data.image.Images3D;
/*     */ import java.util.ArrayDeque;
/*     */ import java.util.Deque;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GeodesicReconstruction3DHybrid0Gray16
/*     */   extends GeodesicReconstruction3DAlgoStub
/*     */ {
/*  61 */   GeodesicReconstructionType reconstructionType = GeodesicReconstructionType.BY_DILATION;
/*     */   
/*     */   ImageStack markerStack;
/*     */   
/*     */   ImageStack maskStack;
/*     */   
/*     */   ImageStack resultStack;
/*     */   
/*     */   short[][] markerSlices;
/*     */   short[][] maskSlices;
/*     */   short[][] resultSlices;
/*  72 */   int sizeX = 0;
/*     */   
/*  74 */   int sizeY = 0;
/*     */   
/*  76 */   int sizeZ = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Deque<Cursor3D> queue;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GeodesicReconstruction3DHybrid0Gray16() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GeodesicReconstruction3DHybrid0Gray16(GeodesicReconstructionType type) {
/*  98 */     this.reconstructionType = type;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GeodesicReconstruction3DHybrid0Gray16(GeodesicReconstructionType type, int connectivity) {
/* 112 */     this.reconstructionType = type;
/* 113 */     this.connectivity = connectivity;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GeodesicReconstruction3DHybrid0Gray16(int connectivity) {
/* 125 */     this.connectivity = connectivity;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GeodesicReconstructionType getReconstructionType() {
/* 133 */     return this.reconstructionType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setReconstructionType(GeodesicReconstructionType reconstructionType) {
/* 141 */     this.reconstructionType = reconstructionType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ImageStack applyTo(ImageStack marker, ImageStack mask) {
/* 151 */     if (marker.getBitDepth() != 16 || mask.getBitDepth() != 16)
/*     */     {
/* 153 */       throw new IllegalArgumentException("Requires both marker and mask images to have 16-bits depth");
/*     */     }
/*     */ 
/*     */     
/* 157 */     this.markerStack = marker;
/* 158 */     this.maskStack = mask;
/*     */ 
/*     */     
/* 161 */     this.markerSlices = Images3D.getShortArrays(marker);
/* 162 */     this.maskSlices = Images3D.getShortArrays(mask);
/*     */ 
/*     */     
/* 165 */     this.sizeX = marker.getWidth();
/* 166 */     this.sizeY = marker.getHeight();
/* 167 */     this.sizeZ = marker.getSize();
/* 168 */     if (!Images3D.isSameSize(marker, mask))
/*     */     {
/* 170 */       throw new IllegalArgumentException("Marker and Mask images must have the same size");
/*     */     }
/*     */ 
/*     */     
/* 174 */     if (this.connectivity != 6 && this.connectivity != 26)
/*     */     {
/* 176 */       throw new RuntimeException(
/* 177 */           "Connectivity for stacks must be either 6 or 26, not " + 
/* 178 */           this.connectivity);
/*     */     }
/*     */     
/* 181 */     this.queue = new ArrayDeque<Cursor3D>();
/*     */     
/* 183 */     long t0 = System.currentTimeMillis();
/* 184 */     trace("Initialize result ");
/* 185 */     initializeResult();
/* 186 */     if (this.verbose) {
/*     */       
/* 188 */       long t1 = System.currentTimeMillis();
/* 189 */       System.out.println(String.valueOf(t1 - t0) + " ms");
/* 190 */       t0 = t1;
/*     */     } 
/*     */ 
/*     */     
/* 194 */     trace("Forward iteration ");
/* 195 */     showStatus("Geod. Rec. Fwd ");
/*     */     
/* 197 */     forwardScan();
/* 198 */     if (this.verbose) {
/*     */       
/* 200 */       long t1 = System.currentTimeMillis();
/* 201 */       System.out.println(String.valueOf(t1 - t0) + " ms");
/* 202 */       t0 = t1;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 207 */     trace("Backward iteration & Init Queue");
/* 208 */     showStatus("Geod. Rec. Bwd ");
/*     */     
/* 210 */     backwardScanInitQueue();
/* 211 */     if (this.verbose) {
/*     */       
/* 213 */       long t1 = System.currentTimeMillis();
/* 214 */       System.out.println(String.valueOf(t1 - t0) + " ms");
/* 215 */       t0 = t1;
/*     */     } 
/*     */ 
/*     */     
/* 219 */     trace("Process queue");
/* 220 */     showStatus("Process queue");
/*     */     
/* 222 */     processQueue();
/* 223 */     if (this.verbose) {
/*     */       
/* 225 */       long t1 = System.currentTimeMillis();
/* 226 */       System.out.println(String.valueOf(t1 - t0) + " ms");
/* 227 */       t0 = t1;
/*     */     } 
/*     */     
/* 230 */     return this.resultStack;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ImageStack applyTo(ImageStack marker, ImageStack mask, ImageStack binaryMask) {
/* 242 */     throw new RuntimeException("Method not yet implemented");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void initializeResult() {
/* 253 */     this.resultStack = ImageStack.create(this.sizeX, this.sizeY, this.sizeZ, this.maskStack.getBitDepth());
/* 254 */     this.resultSlices = Images3D.getShortArrays(this.resultStack);
/*     */ 
/*     */ 
/*     */     
/* 258 */     if (this.reconstructionType == GeodesicReconstructionType.BY_DILATION) {
/*     */ 
/*     */       
/* 261 */       for (int z = 0; z < this.sizeZ; z++)
/*     */       {
/*     */         
/* 264 */         short[] markerSlice = this.markerSlices[z];
/* 265 */         short[] maskSlice = this.maskSlices[z];
/* 266 */         short[] resultSlice = this.resultSlices[z];
/*     */ 
/*     */         
/* 269 */         for (int i = 0; i < this.sizeX * this.sizeY; i++)
/*     */         {
/* 271 */           int v1 = markerSlice[i] & 0xFFFF;
/* 272 */           int v2 = maskSlice[i] & 0xFFFF;
/* 273 */           resultSlice[i] = (short)Math.min(v1, v2);
/*     */         }
/*     */       
/*     */       }
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 281 */       for (int z = 0; z < this.sizeZ; z++) {
/*     */ 
/*     */         
/* 284 */         short[] markerSlice = this.markerSlices[z];
/* 285 */         short[] maskSlice = this.maskSlices[z];
/* 286 */         short[] resultSlice = this.resultSlices[z];
/*     */ 
/*     */         
/* 289 */         for (int i = 0; i < this.sizeX * this.sizeY; i++) {
/*     */           
/* 291 */           int v1 = markerSlice[i] & 0xFFFF;
/* 292 */           int v2 = maskSlice[i] & 0xFFFF;
/* 293 */           resultSlice[i] = (short)Math.max(v1, v2);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void forwardScan() {
/* 301 */     if (this.connectivity == 6) {
/*     */       
/* 303 */       forwardScanC6();
/*     */     }
/*     */     else {
/*     */       
/* 307 */       forwardScanC26();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void forwardScanC6() {
/* 317 */     int sign = this.reconstructionType.getSign();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 325 */     for (int z = 0; z < this.sizeZ; z++) {
/*     */       
/* 327 */       showProgress(z, this.sizeZ);
/*     */ 
/*     */       
/* 330 */       short[] slice = this.resultSlices[z];
/* 331 */       short[] maskSlice = this.maskSlices[z];
/*     */ 
/*     */       
/* 334 */       for (int y = 0; y < this.sizeY; y++) {
/*     */         
/* 336 */         for (int x = 0; x < this.sizeX; x++) {
/*     */           
/* 338 */           int index = y * this.sizeX + x;
/* 339 */           int currentValue = (slice[index] & 0xFFFF) * sign;
/* 340 */           int maxValue = currentValue;
/*     */ 
/*     */           
/* 343 */           if (x > 0)
/* 344 */             maxValue = Math.max(maxValue, (slice[index - 1] & 0xFFFF) * sign); 
/* 345 */           if (y > 0)
/* 346 */             maxValue = Math.max(maxValue, (slice[index - this.sizeX] & 0xFFFF) * sign); 
/* 347 */           if (z > 0) {
/* 348 */             maxValue = Math.max(maxValue, (this.resultSlices[z - 1][index] & 0xFFFF) * sign);
/*     */           }
/*     */           
/* 351 */           maxValue = Math.min(maxValue, (maskSlice[index] & 0xFFFF) * sign);
/* 352 */           if (maxValue > currentValue)
/*     */           {
/* 354 */             slice[index] = (short)(maxValue * sign);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 360 */     showProgress(1.0D, 1.0D);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void forwardScanC26() {
/* 369 */     int sign = this.reconstructionType.getSign();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 376 */     for (int z = 0; z < this.sizeZ; z++) {
/*     */       
/* 378 */       showProgress(z, this.sizeZ, "z = " + z);
/*     */ 
/*     */       
/* 381 */       short[] maskSlice = this.maskSlices[z];
/* 382 */       short[] slice = this.resultSlices[z];
/*     */ 
/*     */       
/* 385 */       for (int y = 0; y < this.sizeY; y++) {
/*     */         
/* 387 */         for (int x = 0; x < this.sizeX; x++) {
/*     */           
/* 389 */           int index = y * this.sizeX + x;
/* 390 */           int currentValue = (slice[index] & 0xFFFF) * sign;
/* 391 */           int maxValue = currentValue;
/*     */ 
/*     */           
/* 394 */           int zmax = Math.min(z + 1, this.sizeZ);
/* 395 */           for (int z2 = Math.max(z - 1, 0); z2 < zmax; z2++) {
/*     */             
/* 397 */             short[] slice2 = this.resultSlices[z2];
/* 398 */             int ymax = (z2 == z) ? y : Math.min(y + 1, this.sizeY - 1);
/* 399 */             for (int y2 = Math.max(y - 1, 0); y2 <= ymax; y2++) {
/*     */               
/* 401 */               int xmax = (z2 == z && y2 == y) ? (x - 1) : Math.min(
/* 402 */                   x + 1, this.sizeX - 1);
/* 403 */               for (int x2 = Math.max(x - 1, 0); x2 <= xmax; x2++)
/*     */               {
/* 405 */                 maxValue = Math.max(maxValue, (slice2[y2 * this.sizeX + x2] & 0xFFFF) * sign);
/*     */               }
/*     */             } 
/*     */           } 
/*     */ 
/*     */           
/* 411 */           maxValue = Math.min(maxValue, (maskSlice[index] & 0xFFFF) * sign);
/* 412 */           if (maxValue > currentValue)
/*     */           {
/* 414 */             slice[index] = (short)(maxValue * sign);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 420 */     showProgress(1.0D, 1.0D);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void backwardScanInitQueue() {
/* 426 */     if (this.connectivity == 6) {
/*     */       
/* 428 */       backwardScanInitQueueC6();
/*     */     }
/*     */     else {
/*     */       
/* 432 */       backwardScanInitQueueC26();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void backwardScanInitQueueC6() {
/* 442 */     int sign = this.reconstructionType.getSign();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 449 */     for (int z = this.sizeZ - 1; z >= 0; z--) {
/*     */       
/* 451 */       showProgress((this.sizeZ - 1 - z), this.sizeZ, "z = " + z);
/*     */ 
/*     */       
/* 454 */       short[] slice = this.resultSlices[z];
/* 455 */       short[] maskSlice = this.maskSlices[z];
/*     */ 
/*     */       
/* 458 */       for (int y = this.sizeY - 1; y >= 0; y--) {
/*     */         
/* 460 */         for (int x = this.sizeX - 1; x >= 0; x--) {
/*     */           
/* 462 */           int index = y * this.sizeX + x;
/* 463 */           int currentValue = (slice[index] & 0xFFFF) * sign;
/* 464 */           int maxValue = currentValue;
/*     */ 
/*     */           
/* 467 */           if (x < this.sizeX - 1)
/* 468 */             maxValue = Math.max(maxValue, (slice[index + 1] & 0xFFFF) * sign); 
/* 469 */           if (y < this.sizeY - 1)
/* 470 */             maxValue = Math.max(maxValue, (slice[index + this.sizeX] & 0xFFFF) * sign); 
/* 471 */           if (z < this.sizeZ - 1) {
/* 472 */             maxValue = Math.max(maxValue, (this.resultSlices[z + 1][index] & 0xFFFF) * sign);
/*     */           }
/*     */           
/* 475 */           maxValue = Math.min(maxValue, (maskSlice[index] & 0xFFFF) * sign);
/*     */ 
/*     */           
/* 478 */           if (maxValue > currentValue) {
/*     */ 
/*     */ 
/*     */             
/* 482 */             slice[index] = (short)(maxValue * sign);
/*     */ 
/*     */             
/* 485 */             if (x < this.sizeX - 1)
/* 486 */               updateQueue(x + 1, y, z, maxValue, sign); 
/* 487 */             if (y < this.sizeY - 1)
/* 488 */               updateQueue(x, y + 1, z, maxValue, sign); 
/* 489 */             if (z < this.sizeZ - 1) {
/* 490 */               updateQueue(x, y, z + 1, maxValue, sign);
/*     */             }
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/* 496 */     showProgress(1.0D, 1.0D);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void backwardScanInitQueueC26() {
/* 505 */     int sign = this.reconstructionType.getSign();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 512 */     for (int z = this.sizeZ - 1; z >= 0; z--) {
/*     */       
/* 514 */       showProgress((this.sizeZ - 1 - z), this.sizeZ, "z = " + z);
/*     */ 
/*     */       
/* 517 */       short[] maskSlice = this.maskSlices[z];
/* 518 */       short[] slice = this.resultSlices[z];
/*     */ 
/*     */       
/* 521 */       for (int y = this.sizeY - 1; y >= 0; y--) {
/*     */         
/* 523 */         for (int x = this.sizeX - 1; x >= 0; x--) {
/*     */           
/* 525 */           int index = y * this.sizeX + x;
/* 526 */           int currentValue = (slice[index] & 0xFFFF) * sign;
/* 527 */           int maxValue = currentValue;
/*     */           
/*     */           int z2;
/* 530 */           for (z2 = Math.min(z + 1, this.sizeZ - 1); z2 >= z; z2--) {
/*     */             
/* 532 */             short[] slice2 = this.resultSlices[z2];
/*     */             
/* 534 */             int ymin = (z2 == z) ? y : Math.max(y - 1, 0);
/* 535 */             for (int y2 = Math.min(y + 1, this.sizeY - 1); y2 >= ymin; y2--) {
/*     */               
/* 537 */               int xmin = (z2 == z && y2 == y) ? x : Math.max(x - 1, 0);
/* 538 */               for (int x2 = Math.min(x + 1, this.sizeX - 1); x2 >= xmin; x2--)
/*     */               {
/* 540 */                 maxValue = Math.max(maxValue, (slice2[y2 * this.sizeX + x2] & 0xFFFF) * sign);
/*     */               }
/*     */             } 
/*     */           } 
/*     */ 
/*     */           
/* 546 */           maxValue = Math.min(maxValue, (maskSlice[index] & 0xFFFF) * sign);
/*     */ 
/*     */           
/* 549 */           if (maxValue > currentValue) {
/*     */ 
/*     */ 
/*     */             
/* 553 */             slice[index] = (short)(maxValue * sign);
/*     */ 
/*     */             
/* 556 */             for (z2 = Math.min(z + 1, this.sizeZ - 1); z2 >= z; z2--) {
/*     */               
/* 558 */               int ymin = (z2 == z) ? y : Math.max(y - 1, 0);
/* 559 */               for (int y2 = Math.min(y + 1, this.sizeY - 1); y2 >= ymin; y2--) {
/*     */                 
/* 561 */                 int xmin = (z2 == z && y2 == y) ? x : Math.max(x - 1, 0);
/* 562 */                 for (int x2 = Math.min(x + 1, this.sizeX - 1); x2 >= xmin; x2--)
/*     */                 {
/* 564 */                   updateQueue(x2, y2, z2, maxValue, sign);
/*     */                 }
/*     */               } 
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/* 572 */     showProgress(1.0D, 1.0D);
/*     */   }
/*     */ 
/*     */   
/*     */   private void processQueue() {
/* 577 */     if (this.connectivity == 6) {
/*     */       
/* 579 */       processQueueC6();
/*     */     }
/*     */     else {
/*     */       
/* 583 */       processQueueC26();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void processQueueC6() {
/* 594 */     int sign = this.reconstructionType.getSign();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 599 */     while (!this.queue.isEmpty()) {
/*     */       
/* 601 */       Cursor3D p = this.queue.removeFirst();
/* 602 */       int x = p.getX();
/* 603 */       int y = p.getY();
/* 604 */       int z = p.getZ();
/* 605 */       short[] slice = this.resultSlices[z];
/* 606 */       int index = y * this.sizeX + x;
/* 607 */       int value = (slice[index] & 0xFFFF) * sign;
/*     */ 
/*     */       
/* 610 */       if (x > 0)
/* 611 */         value = Math.max(value, (slice[index - 1] & 0xFFFF) * sign); 
/* 612 */       if (x < this.sizeX - 1)
/* 613 */         value = Math.max(value, (slice[index + 1] & 0xFFFF) * sign); 
/* 614 */       if (y > 0)
/* 615 */         value = Math.max(value, (slice[index - this.sizeX] & 0xFFFF) * sign); 
/* 616 */       if (y < this.sizeY - 1)
/* 617 */         value = Math.max(value, (slice[index + this.sizeX] & 0xFFFF) * sign); 
/* 618 */       if (z > 0)
/* 619 */         value = Math.max(value, (this.resultSlices[z - 1][index] & 0xFFFF) * sign); 
/* 620 */       if (z < this.sizeZ - 1) {
/* 621 */         value = Math.max(value, (this.resultSlices[z + 1][index] & 0xFFFF) * sign);
/*     */       }
/*     */       
/* 624 */       value = Math.min(value, (this.maskSlices[z][index] & 0xFFFF) * sign);
/*     */ 
/*     */       
/* 627 */       if (value <= (slice[index] & 0xFFFF) * sign) {
/*     */         continue;
/*     */       }
/*     */       
/* 631 */       slice[index] = (short)(value * sign);
/*     */ 
/*     */       
/* 634 */       if (x > 0)
/* 635 */         updateQueue(x - 1, y, z, value, sign); 
/* 636 */       if (x < this.sizeX - 1)
/* 637 */         updateQueue(x + 1, y, z, value, sign); 
/* 638 */       if (y > 0)
/* 639 */         updateQueue(x, y - 1, z, value, sign); 
/* 640 */       if (y < this.sizeY - 1)
/* 641 */         updateQueue(x, y + 1, z, value, sign); 
/* 642 */       if (z > 0)
/* 643 */         updateQueue(x, y, z - 1, value, sign); 
/* 644 */       if (z < this.sizeZ - 1) {
/* 645 */         updateQueue(x, y, z + 1, value, sign);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void processQueueC26() {
/* 657 */     int sign = this.reconstructionType.getSign();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 662 */     while (!this.queue.isEmpty()) {
/*     */       
/* 664 */       Cursor3D p = this.queue.removeFirst();
/* 665 */       int x = p.getX();
/* 666 */       int y = p.getY();
/* 667 */       int z = p.getZ();
/* 668 */       short[] slice = this.resultSlices[z];
/* 669 */       int index = y * this.sizeX + x;
/* 670 */       int value = (slice[index] & 0xFFFF) * sign;
/*     */ 
/*     */       
/* 673 */       int xmin = Math.max(x - 1, 0);
/* 674 */       int xmax = Math.min(x + 1, this.sizeX - 1);
/* 675 */       int ymin = Math.max(y - 1, 0);
/* 676 */       int ymax = Math.min(y + 1, this.sizeY - 1);
/* 677 */       int zmin = Math.max(z - 1, 0);
/* 678 */       int zmax = Math.min(z + 1, this.sizeZ - 1);
/*     */       
/*     */       int z2;
/* 681 */       for (z2 = zmin; z2 <= zmax; z2++) {
/*     */         
/* 683 */         short[] slice2 = this.resultSlices[z2];
/* 684 */         for (int y2 = ymin; y2 <= ymax; y2++) {
/*     */           
/* 686 */           for (int x2 = xmin; x2 <= xmax; x2++) {
/* 687 */             value = Math.max(value, (slice2[y2 * this.sizeX + x2] & 0xFFFF) * sign);
/*     */           }
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 693 */       value = Math.min(value, (this.maskSlices[z][index] & 0xFFFF) * sign);
/*     */ 
/*     */       
/* 696 */       if (value <= (slice[index] & 0xFFFF) * sign) {
/*     */         continue;
/*     */       }
/*     */       
/* 700 */       slice[index] = (short)(value * sign);
/*     */ 
/*     */       
/* 703 */       for (z2 = zmin; z2 <= zmax; z2++) {
/*     */         
/* 705 */         for (int y2 = ymin; y2 <= ymax; y2++) {
/*     */           
/* 707 */           for (int x2 = xmin; x2 <= xmax; x2++)
/*     */           {
/* 709 */             updateQueue(x2, y2, z2, value, sign);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void updateQueue(int i, int j, int k, int value, int sign) {
/* 732 */     int maskValue = (this.maskSlices[k][this.sizeX * j + i] & 0xFFFF) * sign;
/* 733 */     value = Math.min(value, maskValue);
/*     */     
/* 735 */     int resultValue = (this.resultSlices[k][this.sizeX * j + i] & 0xFFFF) * sign;
/* 736 */     if (value > resultValue) {
/*     */       
/* 738 */       Cursor3D position = new Cursor3D(i, j, k);
/* 739 */       this.queue.add(position);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/morphology/geodrec/GeodesicReconstruction3DHybrid0Gray16.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */