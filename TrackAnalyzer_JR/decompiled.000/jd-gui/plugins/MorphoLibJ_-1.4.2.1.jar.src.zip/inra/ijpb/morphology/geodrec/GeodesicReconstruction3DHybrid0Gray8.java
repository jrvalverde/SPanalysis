/*     */ package inra.ijpb.morphology.geodrec;
/*     */ 
/*     */ import ij.ImageStack;
/*     */ import inra.ijpb.data.Cursor3D;
/*     */ import inra.ijpb.data.image.Images3D;
/*     */ import java.util.ArrayDeque;
/*     */ import java.util.Deque;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GeodesicReconstruction3DHybrid0Gray8
/*     */   extends GeodesicReconstruction3DAlgoStub
/*     */ {
/*  61 */   GeodesicReconstructionType reconstructionType = GeodesicReconstructionType.BY_DILATION;
/*     */   
/*     */   ImageStack markerStack;
/*     */   
/*     */   ImageStack maskStack;
/*     */   
/*     */   ImageStack resultStack;
/*     */   
/*     */   byte[][] markerSlices;
/*     */   byte[][] maskSlices;
/*     */   byte[][] resultSlices;
/*  72 */   int sizeX = 0;
/*     */   
/*  74 */   int sizeY = 0;
/*     */   
/*  76 */   int sizeZ = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Deque<Cursor3D> queue;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GeodesicReconstruction3DHybrid0Gray8() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GeodesicReconstruction3DHybrid0Gray8(GeodesicReconstructionType type) {
/*  98 */     this.reconstructionType = type;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GeodesicReconstruction3DHybrid0Gray8(GeodesicReconstructionType type, int connectivity) {
/* 112 */     this.reconstructionType = type;
/* 113 */     this.connectivity = connectivity;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GeodesicReconstruction3DHybrid0Gray8(int connectivity) {
/* 125 */     this.connectivity = connectivity;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GeodesicReconstructionType getReconstructionType() {
/* 133 */     return this.reconstructionType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setReconstructionType(GeodesicReconstructionType reconstructionType) {
/* 141 */     this.reconstructionType = reconstructionType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ImageStack applyTo(ImageStack marker, ImageStack mask) {
/* 151 */     if (marker.getBitDepth() != 8 || mask.getBitDepth() != 8)
/*     */     {
/* 153 */       throw new IllegalArgumentException("Requires both marker and mask images to have 8-bits depth");
/*     */     }
/*     */ 
/*     */     
/* 157 */     this.markerStack = marker;
/* 158 */     this.maskStack = mask;
/*     */ 
/*     */     
/* 161 */     this.markerSlices = Images3D.getByteArrays(marker);
/* 162 */     this.maskSlices = Images3D.getByteArrays(mask);
/*     */ 
/*     */     
/* 165 */     this.sizeX = marker.getWidth();
/* 166 */     this.sizeY = marker.getHeight();
/* 167 */     this.sizeZ = marker.getSize();
/* 168 */     if (!Images3D.isSameSize(marker, mask))
/*     */     {
/* 170 */       throw new IllegalArgumentException("Marker and Mask images must have the same size");
/*     */     }
/*     */ 
/*     */     
/* 174 */     if (this.connectivity != 6 && this.connectivity != 26)
/*     */     {
/* 176 */       throw new RuntimeException(
/* 177 */           "Connectivity for stacks must be either 6 or 26, not " + 
/* 178 */           this.connectivity);
/*     */     }
/*     */     
/* 181 */     this.queue = new ArrayDeque<Cursor3D>();
/*     */     
/* 183 */     long t0 = System.currentTimeMillis();
/* 184 */     trace("Initialize result ");
/* 185 */     initializeResult();
/* 186 */     if (this.verbose) {
/*     */       
/* 188 */       long t1 = System.currentTimeMillis();
/* 189 */       System.out.println(String.valueOf(t1 - t0) + " ms");
/* 190 */       t0 = t1;
/*     */     } 
/*     */ 
/*     */     
/* 194 */     trace("Forward iteration ");
/* 195 */     showStatus("Geod. Rec. Fwd ");
/*     */     
/* 197 */     forwardScan();
/* 198 */     if (this.verbose) {
/*     */       
/* 200 */       long t1 = System.currentTimeMillis();
/* 201 */       System.out.println(String.valueOf(t1 - t0) + " ms");
/* 202 */       t0 = t1;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 207 */     trace("Backward iteration & Init Queue");
/* 208 */     showStatus("Geod. Rec. Bwd ");
/*     */     
/* 210 */     backwardScanInitQueue();
/* 211 */     if (this.verbose) {
/*     */       
/* 213 */       long t1 = System.currentTimeMillis();
/* 214 */       System.out.println(String.valueOf(t1 - t0) + " ms");
/* 215 */       t0 = t1;
/*     */     } 
/*     */ 
/*     */     
/* 219 */     trace("Process queue");
/* 220 */     showStatus("Process queue");
/*     */     
/* 222 */     processQueue();
/* 223 */     if (this.verbose) {
/*     */       
/* 225 */       long t1 = System.currentTimeMillis();
/* 226 */       System.out.println(String.valueOf(t1 - t0) + " ms");
/* 227 */       t0 = t1;
/*     */     } 
/*     */     
/* 230 */     return this.resultStack;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ImageStack applyTo(ImageStack marker, ImageStack mask, ImageStack binaryMask) {
/* 242 */     throw new RuntimeException("Method not yet implemented");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void initializeResult() {
/* 253 */     this.resultStack = ImageStack.create(this.sizeX, this.sizeY, this.sizeZ, this.maskStack.getBitDepth());
/* 254 */     this.resultSlices = Images3D.getByteArrays(this.resultStack);
/*     */ 
/*     */ 
/*     */     
/* 258 */     if (this.reconstructionType == GeodesicReconstructionType.BY_DILATION) {
/*     */ 
/*     */       
/* 261 */       for (int z = 0; z < this.sizeZ; z++)
/*     */       {
/*     */         
/* 264 */         byte[] markerSlice = this.markerSlices[z];
/* 265 */         byte[] maskSlice = this.maskSlices[z];
/* 266 */         byte[] resultSlice = this.resultSlices[z];
/*     */ 
/*     */         
/* 269 */         for (int i = 0; i < this.sizeX * this.sizeY; i++)
/*     */         {
/* 271 */           int v1 = markerSlice[i] & 0xFF;
/* 272 */           int v2 = maskSlice[i] & 0xFF;
/* 273 */           resultSlice[i] = (byte)Math.min(v1, v2);
/*     */         }
/*     */       
/*     */       }
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 281 */       for (int z = 0; z < this.sizeZ; z++) {
/*     */ 
/*     */         
/* 284 */         byte[] markerSlice = this.markerSlices[z];
/* 285 */         byte[] maskSlice = this.maskSlices[z];
/* 286 */         byte[] resultSlice = this.resultSlices[z];
/*     */ 
/*     */         
/* 289 */         for (int i = 0; i < this.sizeX * this.sizeY; i++) {
/*     */           
/* 291 */           int v1 = markerSlice[i] & 0xFF;
/* 292 */           int v2 = maskSlice[i] & 0xFF;
/* 293 */           resultSlice[i] = (byte)Math.max(v1, v2);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void forwardScan() {
/* 301 */     if (this.connectivity == 6) {
/*     */       
/* 303 */       forwardScanC6();
/*     */     }
/*     */     else {
/*     */       
/* 307 */       forwardScanC26();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void forwardScanC6() {
/* 317 */     int sign = this.reconstructionType.getSign();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 325 */     for (int z = 0; z < this.sizeZ; z++) {
/*     */       
/* 327 */       showProgress(z, this.sizeZ);
/*     */ 
/*     */       
/* 330 */       byte[] slice = this.resultSlices[z];
/* 331 */       byte[] maskSlice = this.maskSlices[z];
/*     */ 
/*     */       
/* 334 */       for (int y = 0; y < this.sizeY; y++) {
/*     */         
/* 336 */         for (int x = 0; x < this.sizeX; x++) {
/*     */           
/* 338 */           int index = y * this.sizeX + x;
/* 339 */           int currentValue = (slice[index] & 0xFF) * sign;
/* 340 */           int maxValue = currentValue;
/*     */ 
/*     */           
/* 343 */           if (x > 0)
/* 344 */             maxValue = Math.max(maxValue, (slice[index - 1] & 0xFF) * sign); 
/* 345 */           if (y > 0)
/* 346 */             maxValue = Math.max(maxValue, (slice[index - this.sizeX] & 0xFF) * sign); 
/* 347 */           if (z > 0) {
/* 348 */             maxValue = Math.max(maxValue, (this.resultSlices[z - 1][index] & 0xFF) * sign);
/*     */           }
/*     */           
/* 351 */           maxValue = Math.min(maxValue, (maskSlice[index] & 0xFF) * sign);
/* 352 */           if (maxValue > currentValue)
/*     */           {
/* 354 */             slice[index] = (byte)(maxValue * sign);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 360 */     showProgress(1.0D, 1.0D);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void forwardScanC26() {
/* 369 */     int sign = this.reconstructionType.getSign();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 376 */     for (int z = 0; z < this.sizeZ; z++) {
/*     */       
/* 378 */       showProgress(z, this.sizeZ, "z = " + z);
/*     */ 
/*     */       
/* 381 */       byte[] maskSlice = this.maskSlices[z];
/* 382 */       byte[] slice = this.resultSlices[z];
/*     */ 
/*     */       
/* 385 */       for (int y = 0; y < this.sizeY; y++) {
/*     */         
/* 387 */         for (int x = 0; x < this.sizeX; x++) {
/*     */           
/* 389 */           int index = y * this.sizeX + x;
/* 390 */           int currentValue = (slice[index] & 0xFF) * sign;
/* 391 */           int maxValue = currentValue;
/*     */ 
/*     */           
/* 394 */           int zmax = Math.min(z + 1, this.sizeZ);
/* 395 */           for (int z2 = Math.max(z - 1, 0); z2 < zmax; z2++) {
/*     */             
/* 397 */             byte[] slice2 = this.resultSlices[z2];
/* 398 */             int ymax = (z2 == z) ? y : Math.min(y + 1, this.sizeY - 1);
/* 399 */             for (int y2 = Math.max(y - 1, 0); y2 <= ymax; y2++) {
/*     */               
/* 401 */               int xmax = (z2 == z && y2 == y) ? (x - 1) : Math.min(
/* 402 */                   x + 1, this.sizeX - 1);
/* 403 */               for (int x2 = Math.max(x - 1, 0); x2 <= xmax; x2++)
/*     */               {
/* 405 */                 maxValue = Math.max(maxValue, (slice2[y2 * this.sizeX + x2] & 0xFF) * sign);
/*     */               }
/*     */             } 
/*     */           } 
/*     */ 
/*     */           
/* 411 */           maxValue = Math.min(maxValue, (maskSlice[index] & 0xFF) * sign);
/* 412 */           if (maxValue > currentValue)
/*     */           {
/* 414 */             slice[index] = (byte)(maxValue * sign);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 420 */     showProgress(1.0D, 1.0D);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void backwardScanInitQueue() {
/* 426 */     if (this.connectivity == 6) {
/*     */       
/* 428 */       backwardScanInitQueueC6();
/*     */     }
/*     */     else {
/*     */       
/* 432 */       backwardScanInitQueueC26();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void backwardScanInitQueueC6() {
/* 442 */     int sign = this.reconstructionType.getSign();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 449 */     for (int z = this.sizeZ - 1; z >= 0; z--) {
/*     */       
/* 451 */       showProgress((this.sizeZ - 1 - z), this.sizeZ, "z = " + z);
/*     */ 
/*     */       
/* 454 */       byte[] slice = this.resultSlices[z];
/* 455 */       byte[] maskSlice = this.maskSlices[z];
/*     */ 
/*     */       
/* 458 */       for (int y = this.sizeY - 1; y >= 0; y--) {
/*     */         
/* 460 */         for (int x = this.sizeX - 1; x >= 0; x--) {
/*     */           
/* 462 */           int index = y * this.sizeX + x;
/* 463 */           int currentValue = (slice[index] & 0xFF) * sign;
/* 464 */           int maxValue = currentValue;
/*     */ 
/*     */           
/* 467 */           if (x < this.sizeX - 1)
/* 468 */             maxValue = Math.max(maxValue, (slice[index + 1] & 0xFF) * sign); 
/* 469 */           if (y < this.sizeY - 1)
/* 470 */             maxValue = Math.max(maxValue, (slice[index + this.sizeX] & 0xFF) * sign); 
/* 471 */           if (z < this.sizeZ - 1) {
/* 472 */             maxValue = Math.max(maxValue, (this.resultSlices[z + 1][index] & 0xFF) * sign);
/*     */           }
/*     */           
/* 475 */           maxValue = Math.min(maxValue, (maskSlice[index] & 0xFF) * sign);
/*     */ 
/*     */           
/* 478 */           if (maxValue > currentValue) {
/*     */ 
/*     */ 
/*     */             
/* 482 */             slice[index] = (byte)(maxValue * sign);
/*     */ 
/*     */             
/* 485 */             if (x < this.sizeX - 1)
/* 486 */               updateQueue(x + 1, y, z, maxValue, sign); 
/* 487 */             if (y < this.sizeY - 1)
/* 488 */               updateQueue(x, y + 1, z, maxValue, sign); 
/* 489 */             if (z < this.sizeZ - 1) {
/* 490 */               updateQueue(x, y, z + 1, maxValue, sign);
/*     */             }
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/* 496 */     showProgress(1.0D, 1.0D);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void backwardScanInitQueueC26() {
/* 505 */     int sign = this.reconstructionType.getSign();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 512 */     for (int z = this.sizeZ - 1; z >= 0; z--) {
/*     */       
/* 514 */       showProgress((this.sizeZ - 1 - z), this.sizeZ, "z = " + z);
/*     */ 
/*     */       
/* 517 */       byte[] maskSlice = this.maskSlices[z];
/* 518 */       byte[] slice = this.resultSlices[z];
/*     */ 
/*     */       
/* 521 */       for (int y = this.sizeY - 1; y >= 0; y--) {
/* 522 */         for (int x = this.sizeX - 1; x >= 0; x--) {
/* 523 */           int index = y * this.sizeX + x;
/* 524 */           int currentValue = (slice[index] & 0xFF) * sign;
/* 525 */           int maxValue = currentValue;
/*     */           
/*     */           int z2;
/* 528 */           for (z2 = Math.min(z + 1, this.sizeZ - 1); z2 >= z; z2--) {
/*     */             
/* 530 */             byte[] slice2 = this.resultSlices[z2];
/*     */             
/* 532 */             int ymin = (z2 == z) ? y : Math.max(y - 1, 0);
/* 533 */             for (int y2 = Math.min(y + 1, this.sizeY - 1); y2 >= ymin; y2--) {
/*     */               
/* 535 */               int xmin = (z2 == z && y2 == y) ? x : Math.max(x - 1, 0);
/* 536 */               for (int x2 = Math.min(x + 1, this.sizeX - 1); x2 >= xmin; x2--)
/*     */               {
/* 538 */                 maxValue = Math.max(maxValue, (slice2[y2 * this.sizeX + x2] & 0xFF) * sign);
/*     */               }
/*     */             } 
/*     */           } 
/*     */ 
/*     */           
/* 544 */           maxValue = Math.min(maxValue, (maskSlice[index] & 0xFF) * sign);
/*     */ 
/*     */           
/* 547 */           if (maxValue > currentValue) {
/*     */ 
/*     */ 
/*     */             
/* 551 */             slice[index] = (byte)(maxValue * sign);
/*     */ 
/*     */             
/* 554 */             for (z2 = Math.min(z + 1, this.sizeZ - 1); z2 >= z; z2--) {
/*     */               
/* 556 */               int ymin = (z2 == z) ? y : Math.max(y - 1, 0);
/* 557 */               for (int y2 = Math.min(y + 1, this.sizeY - 1); y2 >= ymin; y2--) {
/*     */                 
/* 559 */                 int xmin = (z2 == z && y2 == y) ? x : Math.max(x - 1, 0);
/* 560 */                 for (int x2 = Math.min(x + 1, this.sizeX - 1); x2 >= xmin; x2--)
/*     */                 {
/* 562 */                   updateQueue(x2, y2, z2, maxValue, sign);
/*     */                 }
/*     */               } 
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/* 570 */     showProgress(1.0D, 1.0D);
/*     */   }
/*     */ 
/*     */   
/*     */   private void processQueue() {
/* 575 */     if (this.connectivity == 6) {
/*     */       
/* 577 */       processQueueC6();
/*     */     }
/*     */     else {
/*     */       
/* 581 */       processQueueC26();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void processQueueC6() {
/* 592 */     int sign = this.reconstructionType.getSign();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 597 */     while (!this.queue.isEmpty()) {
/*     */       
/* 599 */       Cursor3D p = this.queue.removeFirst();
/* 600 */       int x = p.getX();
/* 601 */       int y = p.getY();
/* 602 */       int z = p.getZ();
/* 603 */       byte[] slice = this.resultSlices[z];
/* 604 */       int index = y * this.sizeX + x;
/* 605 */       int value = (slice[index] & 0xFF) * sign;
/*     */ 
/*     */       
/* 608 */       if (x > 0)
/* 609 */         value = Math.max(value, (slice[index - 1] & 0xFF) * sign); 
/* 610 */       if (x < this.sizeX - 1)
/* 611 */         value = Math.max(value, (slice[index + 1] & 0xFF) * sign); 
/* 612 */       if (y > 0)
/* 613 */         value = Math.max(value, (slice[index - this.sizeX] & 0xFF) * sign); 
/* 614 */       if (y < this.sizeY - 1)
/* 615 */         value = Math.max(value, (slice[index + this.sizeX] & 0xFF) * sign); 
/* 616 */       if (z > 0)
/* 617 */         value = Math.max(value, (this.resultSlices[z - 1][index] & 0xFF) * sign); 
/* 618 */       if (z < this.sizeZ - 1) {
/* 619 */         value = Math.max(value, (this.resultSlices[z + 1][index] & 0xFF) * sign);
/*     */       }
/*     */       
/* 622 */       value = Math.min(value, (this.maskSlices[z][index] & 0xFF) * sign);
/*     */ 
/*     */       
/* 625 */       if (value <= (slice[index] & 0xFF) * sign) {
/*     */         continue;
/*     */       }
/*     */       
/* 629 */       slice[index] = (byte)(value * sign);
/*     */ 
/*     */       
/* 632 */       if (x > 0)
/* 633 */         updateQueue(x - 1, y, z, value, sign); 
/* 634 */       if (x < this.sizeX - 1)
/* 635 */         updateQueue(x + 1, y, z, value, sign); 
/* 636 */       if (y > 0)
/* 637 */         updateQueue(x, y - 1, z, value, sign); 
/* 638 */       if (y < this.sizeY - 1)
/* 639 */         updateQueue(x, y + 1, z, value, sign); 
/* 640 */       if (z > 0)
/* 641 */         updateQueue(x, y, z - 1, value, sign); 
/* 642 */       if (z < this.sizeZ - 1) {
/* 643 */         updateQueue(x, y, z + 1, value, sign);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void processQueueC26() {
/* 655 */     int sign = this.reconstructionType.getSign();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 660 */     while (!this.queue.isEmpty()) {
/*     */       
/* 662 */       Cursor3D p = this.queue.removeFirst();
/* 663 */       int x = p.getX();
/* 664 */       int y = p.getY();
/* 665 */       int z = p.getZ();
/* 666 */       byte[] slice = this.resultSlices[z];
/* 667 */       int index = y * this.sizeX + x;
/* 668 */       int value = (slice[index] & 0xFF) * sign;
/*     */ 
/*     */       
/* 671 */       int xmin = Math.max(x - 1, 0);
/* 672 */       int xmax = Math.min(x + 1, this.sizeX - 1);
/* 673 */       int ymin = Math.max(y - 1, 0);
/* 674 */       int ymax = Math.min(y + 1, this.sizeY - 1);
/* 675 */       int zmin = Math.max(z - 1, 0);
/* 676 */       int zmax = Math.min(z + 1, this.sizeZ - 1);
/*     */       
/*     */       int z2;
/* 679 */       for (z2 = zmin; z2 <= zmax; z2++) {
/*     */         
/* 681 */         byte[] slice2 = this.resultSlices[z2];
/* 682 */         for (int y2 = ymin; y2 <= ymax; y2++) {
/*     */           
/* 684 */           for (int x2 = xmin; x2 <= xmax; x2++) {
/* 685 */             value = Math.max(value, (slice2[y2 * this.sizeX + x2] & 0xFF) * sign);
/*     */           }
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 691 */       value = Math.min(value, (this.maskSlices[z][index] & 0xFF) * sign);
/*     */ 
/*     */       
/* 694 */       if (value <= (slice[index] & 0xFF) * sign) {
/*     */         continue;
/*     */       }
/*     */       
/* 698 */       slice[index] = (byte)(value * sign);
/*     */ 
/*     */       
/* 701 */       for (z2 = zmin; z2 <= zmax; z2++) {
/*     */         
/* 703 */         for (int y2 = ymin; y2 <= ymax; y2++) {
/*     */           
/* 705 */           for (int x2 = xmin; x2 <= xmax; x2++)
/*     */           {
/* 707 */             updateQueue(x2, y2, z2, value, sign);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void updateQueue(int i, int j, int k, int value, int sign) {
/* 725 */     int maskValue = (this.maskSlices[k][this.sizeX * j + i] & 0xFF) * sign;
/* 726 */     value = Math.min(value, maskValue);
/*     */     
/* 728 */     int resultValue = (this.resultSlices[k][this.sizeX * j + i] & 0xFF) * sign;
/* 729 */     if (value > resultValue) {
/*     */       
/* 731 */       Cursor3D position = new Cursor3D(i, j, k);
/* 732 */       this.queue.add(position);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/morphology/geodrec/GeodesicReconstruction3DHybrid0Gray8.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */