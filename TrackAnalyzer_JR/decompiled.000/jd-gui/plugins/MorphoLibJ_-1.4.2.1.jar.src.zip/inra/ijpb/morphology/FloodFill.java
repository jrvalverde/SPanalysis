/*     */ package inra.ijpb.morphology;
/*     */ 
/*     */ import ij.ImageStack;
/*     */ import ij.process.ImageProcessor;
/*     */ import java.awt.Point;
/*     */ import java.util.ArrayList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FloodFill
/*     */ {
/*     */   public static final void floodFill(ImageProcessor image, int x, int y, int value, int conn) {
/*  78 */     if (conn == 4) {
/*  79 */       floodFillC4(image, x, y, value);
/*  80 */     } else if (conn == 8) {
/*  81 */       floodFillC8(image, x, y, value);
/*     */     } else {
/*  83 */       throw new IllegalArgumentException("Connectivity must be either 4 or 8, not " + conn);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final void floodFillC4(ImageProcessor image, int x, int y, int value) {
/* 103 */     int width = image.getWidth();
/* 104 */     int height = image.getHeight();
/*     */ 
/*     */     
/* 107 */     int oldValue = image.getPixel(x, y);
/*     */ 
/*     */     
/* 110 */     if (oldValue == value) {
/*     */       return;
/*     */     }
/*     */     
/* 114 */     ArrayList<Point> stack = new ArrayList<Point>();
/* 115 */     stack.add(new Point(x, y));
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 120 */     while (!stack.isEmpty()) {
/*     */ 
/*     */       
/* 123 */       Point p = stack.remove(stack.size() - 1);
/* 124 */       x = p.x;
/* 125 */       y = p.y;
/*     */ 
/*     */       
/* 128 */       if (image.get(x, y) != oldValue) {
/*     */         continue;
/*     */       }
/*     */       
/* 132 */       int x1 = x;
/* 133 */       int x2 = x;
/*     */ 
/*     */       
/* 136 */       while (x1 > 0 && image.getPixel(x1 - 1, y) == oldValue) {
/* 137 */         x1--;
/*     */       }
/*     */       
/* 140 */       while (x2 < width - 1 && image.getPixel(x2 + 1, y) == oldValue) {
/* 141 */         x2++;
/*     */       }
/*     */       
/* 144 */       fillLine(image, y, x1, x2, value);
/*     */ 
/*     */       
/* 147 */       if (y > 0) {
/*     */         
/* 149 */         boolean inScanLine = false;
/* 150 */         for (int i = x1; i <= x2; i++) {
/*     */           
/* 152 */           int val = image.get(i, y - 1);
/* 153 */           if (!inScanLine && val == oldValue) {
/*     */             
/* 155 */             stack.add(new Point(i, y - 1));
/* 156 */             inScanLine = true;
/*     */           }
/* 158 */           else if (inScanLine && val != oldValue) {
/*     */             
/* 160 */             inScanLine = false;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 166 */       if (y < height - 1) {
/*     */         
/* 168 */         boolean inScanLine = false;
/* 169 */         for (int i = x1; i <= x2; i++) {
/*     */           
/* 171 */           int val = image.getPixel(i, y + 1);
/* 172 */           if (!inScanLine && val == oldValue) {
/*     */             
/* 174 */             stack.add(new Point(i, y + 1));
/* 175 */             inScanLine = true;
/*     */           }
/* 177 */           else if (inScanLine && val != oldValue) {
/*     */             
/* 179 */             inScanLine = false;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final void floodFillC8(ImageProcessor image, int x, int y, int value) {
/* 203 */     int width = image.getWidth();
/* 204 */     int height = image.getHeight();
/*     */ 
/*     */     
/* 207 */     int oldValue = image.getPixel(x, y);
/*     */ 
/*     */     
/* 210 */     if (oldValue == value) {
/*     */       return;
/*     */     }
/*     */     
/* 214 */     ArrayList<Point> stack = new ArrayList<Point>();
/* 215 */     stack.add(new Point(x, y));
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 220 */     while (!stack.isEmpty()) {
/*     */ 
/*     */       
/* 223 */       Point p = stack.remove(stack.size() - 1);
/* 224 */       x = p.x;
/* 225 */       y = p.y;
/*     */ 
/*     */       
/* 228 */       if (image.get(x, y) != oldValue) {
/*     */         continue;
/*     */       }
/*     */       
/* 232 */       int x1 = x;
/* 233 */       int x2 = x;
/*     */ 
/*     */       
/* 236 */       while (x1 > 0 && image.getPixel(x1 - 1, y) == oldValue) {
/* 237 */         x1--;
/*     */       }
/*     */       
/* 240 */       while (x2 < width - 1 && image.getPixel(x2 + 1, y) == oldValue) {
/* 241 */         x2++;
/*     */       }
/*     */       
/* 244 */       fillLine(image, y, x1, x2, value);
/*     */ 
/*     */       
/* 247 */       if (y > 0) {
/*     */         
/* 249 */         boolean inScanLine = false;
/* 250 */         for (int i = Math.max(x1 - 1, 0); i <= Math.min(x2 + 1, width - 1); i++) {
/*     */           
/* 252 */           int val = image.get(i, y - 1);
/* 253 */           if (!inScanLine && val == oldValue) {
/*     */             
/* 255 */             stack.add(new Point(i, y - 1));
/* 256 */             inScanLine = true;
/* 257 */           } else if (inScanLine && val != oldValue) {
/* 258 */             inScanLine = false;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */       
/* 263 */       if (y < height - 1) {
/*     */         
/* 265 */         boolean inScanLine = false;
/* 266 */         for (int i = Math.max(x1 - 1, 0); i <= Math.min(x2 + 1, width - 1); i++) {
/*     */           
/* 268 */           int val = image.getPixel(i, y + 1);
/* 269 */           if (!inScanLine && val == oldValue) {
/*     */             
/* 271 */             stack.add(new Point(i, y + 1));
/* 272 */             inScanLine = true;
/*     */           }
/* 274 */           else if (inScanLine && val != oldValue) {
/*     */             
/* 276 */             inScanLine = false;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final void floodFill(ImageProcessor image, int x, int y, float value, int conn) {
/* 301 */     if (conn == 4) {
/* 302 */       floodFillC4(image, x, y, value);
/* 303 */     } else if (conn == 8) {
/* 304 */       floodFillC8(image, x, y, value);
/*     */     } else {
/* 306 */       throw new IllegalArgumentException("Connectivity must be either 4 or 8, not " + conn);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final void floodFillC4(ImageProcessor image, int x, int y, float value) {
/* 327 */     int width = image.getWidth();
/* 328 */     int height = image.getHeight();
/*     */ 
/*     */     
/* 331 */     float oldValue = image.getf(x, y);
/*     */ 
/*     */     
/* 334 */     if (oldValue == value) {
/*     */       return;
/*     */     }
/*     */     
/* 338 */     ArrayList<Point> stack = new ArrayList<Point>();
/* 339 */     stack.add(new Point(x, y));
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 344 */     while (!stack.isEmpty()) {
/*     */ 
/*     */       
/* 347 */       Point p = stack.remove(stack.size() - 1);
/* 348 */       x = p.x;
/* 349 */       y = p.y;
/*     */ 
/*     */       
/* 352 */       if (image.getf(x, y) != oldValue) {
/*     */         continue;
/*     */       }
/*     */       
/* 356 */       int x1 = x;
/* 357 */       int x2 = x;
/*     */ 
/*     */       
/* 360 */       while (x1 > 0 && image.getf(x1 - 1, y) == oldValue) {
/* 361 */         x1--;
/*     */       }
/*     */       
/* 364 */       while (x2 < width - 1 && image.getf(x2 + 1, y) == oldValue) {
/* 365 */         x2++;
/*     */       }
/*     */       
/* 368 */       fillLine(image, y, x1, x2, value);
/*     */ 
/*     */       
/* 371 */       if (y > 0) {
/*     */         
/* 373 */         boolean inScanLine = false;
/* 374 */         for (int i = x1; i <= x2; i++) {
/*     */           
/* 376 */           float val = image.getf(i, y - 1);
/* 377 */           if (!inScanLine && val == oldValue) {
/*     */             
/* 379 */             stack.add(new Point(i, y - 1));
/* 380 */             inScanLine = true;
/*     */           }
/* 382 */           else if (inScanLine && val != oldValue) {
/*     */             
/* 384 */             inScanLine = false;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 390 */       if (y < height - 1) {
/*     */         
/* 392 */         boolean inScanLine = false;
/* 393 */         for (int i = x1; i <= x2; i++) {
/*     */           
/* 395 */           float val = image.getf(i, y + 1);
/* 396 */           if (!inScanLine && val == oldValue) {
/*     */             
/* 398 */             stack.add(new Point(i, y + 1));
/* 399 */             inScanLine = true;
/*     */           }
/* 401 */           else if (inScanLine && val != oldValue) {
/*     */             
/* 403 */             inScanLine = false;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final void floodFillC8(ImageProcessor image, int x, int y, float value) {
/* 429 */     int width = image.getWidth();
/* 430 */     int height = image.getHeight();
/*     */ 
/*     */     
/* 433 */     float oldValue = image.getf(x, y);
/*     */ 
/*     */     
/* 436 */     if (oldValue == value) {
/*     */       return;
/*     */     }
/*     */     
/* 440 */     ArrayList<Point> stack = new ArrayList<Point>();
/* 441 */     stack.add(new Point(x, y));
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 446 */     while (!stack.isEmpty()) {
/*     */ 
/*     */       
/* 449 */       Point p = stack.remove(stack.size() - 1);
/* 450 */       x = p.x;
/* 451 */       y = p.y;
/*     */ 
/*     */       
/* 454 */       if (image.getf(x, y) != oldValue) {
/*     */         continue;
/*     */       }
/*     */       
/* 458 */       int x1 = x;
/* 459 */       int x2 = x;
/*     */ 
/*     */       
/* 462 */       while (x1 > 0 && image.getf(x1 - 1, y) == oldValue) {
/* 463 */         x1--;
/*     */       }
/*     */       
/* 466 */       while (x2 < width - 1 && image.getf(x2 + 1, y) == oldValue) {
/* 467 */         x2++;
/*     */       }
/*     */       
/* 470 */       fillLine(image, y, x1, x2, value);
/*     */ 
/*     */       
/* 473 */       if (y > 0) {
/*     */         
/* 475 */         boolean inScanLine = false;
/* 476 */         for (int i = Math.max(x1 - 1, 0); i <= Math.min(x2 + 1, width - 1); i++) {
/*     */           
/* 478 */           float val = image.getf(i, y - 1);
/* 479 */           if (!inScanLine && val == oldValue) {
/*     */             
/* 481 */             stack.add(new Point(i, y - 1));
/* 482 */             inScanLine = true;
/*     */           }
/* 484 */           else if (inScanLine && val != oldValue) {
/*     */             
/* 486 */             inScanLine = false;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 492 */       if (y < height - 1) {
/*     */         
/* 494 */         boolean inScanLine = false;
/* 495 */         for (int i = Math.max(x1 - 1, 0); i <= Math.min(x2 + 1, width - 1); i++) {
/*     */           
/* 497 */           float val = image.getf(i, y + 1);
/* 498 */           if (!inScanLine && val == oldValue) {
/*     */             
/* 500 */             stack.add(new Point(i, y + 1));
/* 501 */             inScanLine = true;
/*     */           }
/* 503 */           else if (inScanLine && val != oldValue) {
/*     */             
/* 505 */             inScanLine = false;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final void floodFill(ImageProcessor inputImage, int x, int y, ImageProcessor outputImage, int value, int conn) {
/* 535 */     int dx1 = 0;
/* 536 */     int dx2 = 0;
/* 537 */     if (conn == 8) {
/*     */       
/* 539 */       dx1 = -1;
/* 540 */       dx2 = 1;
/*     */     } 
/*     */ 
/*     */     
/* 544 */     int width = inputImage.getWidth();
/* 545 */     int height = inputImage.getHeight();
/*     */ 
/*     */     
/* 548 */     int oldValue = inputImage.getPixel(x, y);
/*     */ 
/*     */     
/* 551 */     ArrayList<Point> stack = new ArrayList<Point>();
/* 552 */     stack.add(new Point(x, y));
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 557 */     while (!stack.isEmpty()) {
/*     */ 
/*     */       
/* 560 */       Point p = stack.remove(stack.size() - 1);
/* 561 */       x = p.x;
/* 562 */       y = p.y;
/*     */ 
/*     */       
/* 565 */       if (inputImage.get(x, y) != oldValue) {
/*     */         continue;
/*     */       }
/*     */       
/* 569 */       int x1 = x;
/* 570 */       int x2 = x;
/*     */ 
/*     */       
/* 573 */       while (x1 > 0 && inputImage.get(x1 - 1, y) == oldValue) {
/* 574 */         x1--;
/*     */       }
/*     */       
/* 577 */       while (x2 < width - 1 && inputImage.get(x2 + 1, y) == oldValue) {
/* 578 */         x2++;
/*     */       }
/*     */       
/* 581 */       fillLine(outputImage, y, x1, x2, value);
/*     */ 
/*     */ 
/*     */       
/* 585 */       if (y > 0) {
/*     */         
/* 587 */         boolean inScanLine = false;
/* 588 */         for (int i = Math.max(x1 + dx1, 0); i <= Math.min(x2 + dx2, width - 1); i++) {
/*     */           
/* 590 */           int val = inputImage.get(i, y - 1);
/* 591 */           int lab = outputImage.get(i, y - 1);
/* 592 */           if (!inScanLine && val == oldValue && lab != value) {
/*     */             
/* 594 */             stack.add(new Point(i, y - 1));
/* 595 */             inScanLine = true;
/*     */           }
/* 597 */           else if (inScanLine && val != oldValue) {
/*     */             
/* 599 */             inScanLine = false;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 605 */       if (y < height - 1) {
/*     */         
/* 607 */         boolean inScanLine = false;
/* 608 */         for (int i = Math.max(x1 + dx1, 0); i <= Math.min(x2 + dx2, width - 1); i++) {
/*     */           
/* 610 */           int val = inputImage.getPixel(i, y + 1);
/* 611 */           int lab = outputImage.get(i, y + 1);
/* 612 */           if (!inScanLine && val == oldValue && lab != value) {
/*     */             
/* 614 */             stack.add(new Point(i, y + 1));
/* 615 */             inScanLine = true;
/*     */           }
/* 617 */           else if (inScanLine && val != oldValue) {
/*     */             
/* 619 */             inScanLine = false;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final void floodFillFloat(ImageProcessor inputImage, int x, int y, ImageProcessor outputImage, float value, int conn) {
/* 648 */     int dx1 = 0;
/* 649 */     int dx2 = 0;
/* 650 */     if (conn == 8) {
/*     */       
/* 652 */       dx1 = -1;
/* 653 */       dx2 = 1;
/*     */     } 
/*     */ 
/*     */     
/* 657 */     int width = inputImage.getWidth();
/* 658 */     int height = inputImage.getHeight();
/*     */ 
/*     */     
/* 661 */     float oldValue = inputImage.getf(x, y);
/*     */ 
/*     */     
/* 664 */     ArrayList<Point> stack = new ArrayList<Point>();
/* 665 */     stack.add(new Point(x, y));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 671 */     while (!stack.isEmpty()) {
/*     */ 
/*     */       
/* 674 */       Point p = stack.remove(stack.size() - 1);
/* 675 */       x = p.x;
/* 676 */       y = p.y;
/*     */ 
/*     */       
/* 679 */       if (inputImage.getf(x, y) != oldValue) {
/*     */         continue;
/*     */       }
/*     */       
/* 683 */       int x1 = x;
/* 684 */       int x2 = x;
/*     */ 
/*     */       
/* 687 */       while (x1 > 0 && inputImage.getf(x1 - 1, y) == oldValue) {
/* 688 */         x1--;
/*     */       }
/*     */       
/* 691 */       while (x2 < width - 1 && inputImage.getf(x2 + 1, y) == oldValue) {
/* 692 */         x2++;
/*     */       }
/*     */       
/* 695 */       fillLine(outputImage, y, x1, x2, value);
/*     */ 
/*     */       
/* 698 */       if (y > 0) {
/*     */         
/* 700 */         boolean inScanLine = false;
/* 701 */         for (int i = Math.max(x1 + dx1, 0); i <= Math.min(x2 + dx2, width - 1); i++) {
/*     */           
/* 703 */           float val = inputImage.getf(i, y - 1);
/* 704 */           float lab = outputImage.getf(i, y - 1);
/* 705 */           if (!inScanLine && val == oldValue && lab != value) {
/*     */             
/* 707 */             stack.add(new Point(i, y - 1));
/* 708 */             inScanLine = true;
/*     */           }
/* 710 */           else if (inScanLine && val != oldValue) {
/*     */             
/* 712 */             inScanLine = false;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 718 */       if (y < height - 1) {
/*     */         
/* 720 */         boolean inScanLine = false;
/* 721 */         for (int i = Math.max(x1 + dx1, 0); i <= Math.min(x2 + dx2, width - 1); i++) {
/*     */           
/* 723 */           float val = inputImage.getf(i, y + 1);
/* 724 */           float lab = outputImage.getf(i, y + 1);
/* 725 */           if (!inScanLine && val == oldValue && lab != value) {
/*     */             
/* 727 */             stack.add(new Point(i, y + 1));
/* 728 */             inScanLine = true;
/*     */           }
/* 730 */           else if (inScanLine && val != oldValue) {
/*     */             
/* 732 */             inScanLine = false;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final void fillLine(ImageProcessor ip, int y, int x1, int x2, int value) {
/* 758 */     if (x1 > x2) {
/*     */       
/* 760 */       int t = x1;
/* 761 */       x1 = x2;
/* 762 */       x2 = t;
/*     */     } 
/*     */     
/* 765 */     for (int x = x1; x <= x2; x++) {
/* 766 */       ip.set(x, y, value);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final void fillLine(ImageProcessor ip, int y, int x1, int x2, float value) {
/* 777 */     for (int x = x1; x <= x2; x++) {
/* 778 */       ip.setf(x, y, value);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static final void floodFill(ImageStack image, int x, int y, int z, int value, int conn) {
/* 804 */     FloodFill3D.floodFill(image, x, y, z, value, conn);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static final void floodFill(ImageStack image, int x, int y, int z, double value, int conn) {
/* 830 */     FloodFill3D.floodFill(image, x, y, z, value, conn);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static final void floodFill(ImageStack inputImage, int x, int y, int z, ImageStack outputImage, int value, int conn) {
/* 861 */     FloodFill3D.floodFill(inputImage, x, y, z, outputImage, value, conn);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static final void floodFillFloat(ImageStack inputImage, int x, int y, int z, ImageStack outputImage, float value, int conn) {
/* 890 */     FloodFill3D.floodFillFloat(inputImage, x, y, z, outputImage, value, conn);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/morphology/FloodFill.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */