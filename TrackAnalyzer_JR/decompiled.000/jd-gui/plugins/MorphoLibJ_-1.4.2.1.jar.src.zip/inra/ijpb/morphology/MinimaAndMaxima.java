/*     */ package inra.ijpb.morphology;
/*     */ 
/*     */ import ij.process.ByteProcessor;
/*     */ import ij.process.ImageProcessor;
/*     */ import inra.ijpb.morphology.extrema.ExtremaType;
/*     */ import inra.ijpb.morphology.extrema.RegionalExtremaByFlooding;
/*     */ import inra.ijpb.morphology.geodrec.GeodesicReconstructionHybrid;
/*     */ import inra.ijpb.morphology.geodrec.GeodesicReconstructionType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MinimaAndMaxima
/*     */ {
/*     */   private static final int DEFAULT_CONNECTIVITY = 4;
/*     */   
/*     */   public static final ImageProcessor regionalMaxima(ImageProcessor image) {
/*  83 */     return regionalMaxima(image, 4);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final ImageProcessor regionalMaxima(ImageProcessor image, int conn) {
/*  99 */     RegionalExtremaByFlooding regionalExtremaByFlooding = new RegionalExtremaByFlooding();
/* 100 */     regionalExtremaByFlooding.setConnectivity(conn);
/* 101 */     regionalExtremaByFlooding.setExtremaType(ExtremaType.MAXIMA);
/*     */     
/* 103 */     return regionalExtremaByFlooding.applyTo(image);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final ImageProcessor regionalMaximaByReconstruction(ImageProcessor image, int conn) {
/* 121 */     ImageProcessor mask = image.duplicate();
/* 122 */     mask.add(1);
/*     */ 
/*     */     
/* 125 */     GeodesicReconstructionHybrid geodesicReconstructionHybrid = new GeodesicReconstructionHybrid(
/* 126 */         GeodesicReconstructionType.BY_DILATION, conn);
/* 127 */     ImageProcessor rec = geodesicReconstructionHybrid.applyTo(image, mask);
/*     */ 
/*     */     
/* 130 */     int width = image.getWidth();
/* 131 */     int height = image.getHeight();
/* 132 */     ByteProcessor byteProcessor = new ByteProcessor(width, height);
/*     */ 
/*     */     
/* 135 */     for (int y = 0; y < height; y++) {
/* 136 */       for (int x = 0; x < width; x++) {
/* 137 */         if (mask.get(x, y) > rec.get(x, y)) {
/* 138 */           byteProcessor.set(x, y, 255);
/*     */         } else {
/* 140 */           byteProcessor.set(x, y, 0);
/*     */         } 
/*     */       } 
/*     */     } 
/* 144 */     return (ImageProcessor)byteProcessor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final ImageProcessor regionalMinima(ImageProcessor image) {
/* 157 */     return regionalMinima(image, 4);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final ImageProcessor regionalMinima(ImageProcessor image, int conn) {
/* 173 */     RegionalExtremaByFlooding regionalExtremaByFlooding = new RegionalExtremaByFlooding();
/* 174 */     regionalExtremaByFlooding.setConnectivity(conn);
/* 175 */     regionalExtremaByFlooding.setExtremaType(ExtremaType.MINIMA);
/*     */     
/* 177 */     return regionalExtremaByFlooding.applyTo(image);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final ImageProcessor regionalMinimaByReconstruction(ImageProcessor image, int conn) {
/* 193 */     ImageProcessor marker = image.duplicate();
/* 194 */     marker.add(1);
/*     */     
/* 196 */     GeodesicReconstructionHybrid geodesicReconstructionHybrid = new GeodesicReconstructionHybrid(
/* 197 */         GeodesicReconstructionType.BY_EROSION, conn);
/* 198 */     ImageProcessor rec = geodesicReconstructionHybrid.applyTo(marker, image);
/*     */     
/* 200 */     int width = image.getWidth();
/* 201 */     int height = image.getHeight();
/* 202 */     ByteProcessor byteProcessor = new ByteProcessor(width, height);
/*     */     
/* 204 */     for (int y = 0; y < height; y++) {
/*     */       
/* 206 */       for (int x = 0; x < width; x++) {
/*     */         
/* 208 */         if (marker.get(x, y) > rec.get(x, y)) {
/* 209 */           byteProcessor.set(x, y, 0);
/*     */         } else {
/* 211 */           byteProcessor.set(x, y, 255);
/*     */         } 
/*     */       } 
/*     */     } 
/* 215 */     return (ImageProcessor)byteProcessor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final ImageProcessor extendedMaxima(ImageProcessor image, double dynamic) {
/* 232 */     return extendedMaxima(image, dynamic, 4);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final ImageProcessor extendedMaxima(ImageProcessor image, double dynamic, int conn) {
/* 251 */     ImageProcessor mask = image.duplicate();
/* 252 */     mask.add(dynamic);
/*     */     
/* 254 */     GeodesicReconstructionHybrid geodesicReconstructionHybrid = new GeodesicReconstructionHybrid(
/* 255 */         GeodesicReconstructionType.BY_DILATION, conn);
/* 256 */     ImageProcessor rec = geodesicReconstructionHybrid.applyTo(image, mask);
/*     */     
/* 258 */     return regionalMaxima(rec, conn);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final ImageProcessor extendedMinima(ImageProcessor image, double dynamic) {
/* 275 */     return extendedMinima(image, dynamic, 4);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final ImageProcessor extendedMinima(ImageProcessor image, double dynamic, int conn) {
/* 294 */     ImageProcessor marker = image.duplicate();
/* 295 */     marker.add(dynamic);
/*     */     
/* 297 */     GeodesicReconstructionHybrid geodesicReconstructionHybrid = new GeodesicReconstructionHybrid(
/* 298 */         GeodesicReconstructionType.BY_EROSION, conn);
/* 299 */     ImageProcessor rec = geodesicReconstructionHybrid.applyTo(marker, image);
/*     */     
/* 301 */     return regionalMinima(rec, conn);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final ImageProcessor imposeMaxima(ImageProcessor image, ImageProcessor maxima) {
/* 317 */     return imposeMaxima(image, maxima, 4);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final ImageProcessor imposeMaxima(ImageProcessor image, ImageProcessor maxima, int conn) {
/* 335 */     ImageProcessor marker = image.duplicate();
/* 336 */     ImageProcessor mask = image.duplicate();
/*     */     
/* 338 */     int width = image.getWidth();
/* 339 */     int height = image.getHeight();
/* 340 */     for (int y = 0; y < height; y++) {
/*     */       
/* 342 */       for (int x = 0; x < width; x++) {
/*     */         
/* 344 */         if (maxima.get(x, y) > 0) {
/*     */           
/* 346 */           marker.set(x, y, 255);
/* 347 */           mask.set(x, y, 255);
/*     */         }
/*     */         else {
/*     */           
/* 351 */           marker.set(x, y, 0);
/* 352 */           mask.set(x, y, image.get(x, y) - 1);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 357 */     return Reconstruction.reconstructByDilation(marker, mask, conn);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final ImageProcessor imposeMinima(ImageProcessor image, ImageProcessor minima) {
/* 373 */     return imposeMinima(image, minima, 4);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final ImageProcessor imposeMinima(ImageProcessor image, ImageProcessor minima, int conn) {
/* 391 */     int width = image.getWidth();
/* 392 */     int height = image.getHeight();
/*     */     
/* 394 */     ImageProcessor marker = image.duplicate();
/* 395 */     ImageProcessor mask = image.duplicate();
/* 396 */     for (int y = 0; y < height; y++) {
/*     */       
/* 398 */       for (int x = 0; x < width; x++) {
/*     */         
/* 400 */         if (minima.get(x, y) > 0) {
/*     */           
/* 402 */           marker.set(x, y, 0);
/* 403 */           mask.set(x, y, 0);
/*     */         }
/*     */         else {
/*     */           
/* 407 */           marker.set(x, y, 255);
/* 408 */           mask.set(x, y, image.get(x, y) + 1);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 413 */     return Reconstruction.reconstructByErosion(marker, mask, conn);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/morphology/MinimaAndMaxima.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */