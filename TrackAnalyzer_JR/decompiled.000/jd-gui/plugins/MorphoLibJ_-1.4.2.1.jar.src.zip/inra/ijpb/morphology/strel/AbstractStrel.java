/*     */ package inra.ijpb.morphology.strel;
/*     */ 
/*     */ import ij.ImageStack;
/*     */ import ij.process.ImageProcessor;
/*     */ import inra.ijpb.morphology.Strel;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractStrel
/*     */   extends AbstractStrel3D
/*     */   implements Strel
/*     */ {
/*  40 */   private String channelName = null;
/*     */   
/*     */   public int[][][] getMask3D() {
/*  43 */     int[][][] mask3d = new int[1][][];
/*  44 */     mask3d[0] = getMask();
/*  45 */     return mask3d;
/*     */   }
/*     */   
/*     */   public int[][] getShifts3D() {
/*  49 */     int[][] shifts = getShifts();
/*  50 */     int ns = shifts.length;
/*     */     
/*  52 */     int[][] shifts3d = new int[ns][3];
/*  53 */     for (int i = 0; i < ns; i++) {
/*  54 */       (new int[3])[0] = shifts3d[i][0]; (new int[3])[1] = shifts3d[i][1]; shifts3d[i] = new int[3];
/*     */     } 
/*  56 */     return shifts3d;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setChannelName(String channelName) {
/*  64 */     this.channelName = channelName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getChannelName() {
/*  71 */     return this.channelName;
/*     */   }
/*     */   
/*     */   public ImageStack dilation(ImageStack stack) {
/*  75 */     boolean flag = showProgress();
/*  76 */     showProgress(false);
/*     */     
/*  78 */     ImageStack result = stack.duplicate();
/*     */     
/*  80 */     int nSlices = stack.getSize();
/*  81 */     for (int i = 1; i <= nSlices; i++) {
/*  82 */       showProgress(flag);
/*  83 */       fireProgressChanged(this, (i - 1), nSlices);
/*  84 */       showProgress(false);
/*     */       
/*  86 */       ImageProcessor img = stack.getProcessor(i);
/*  87 */       img = dilation(img);
/*  88 */       result.setProcessor(img, i);
/*     */     } 
/*     */ 
/*     */     
/*  92 */     showProgress(flag);
/*  93 */     fireProgressChanged(this, nSlices, nSlices);
/*     */     
/*  95 */     return result;
/*     */   }
/*     */   
/*     */   public ImageStack erosion(ImageStack stack) {
/*  99 */     boolean flag = showProgress();
/*     */     
/* 101 */     int nSlices = stack.getSize();
/* 102 */     ImageStack result = stack.duplicate();
/* 103 */     for (int i = 1; i <= nSlices; i++) {
/* 104 */       showProgress(flag);
/* 105 */       fireProgressChanged(this, (i - 1), nSlices);
/* 106 */       showProgress(false);
/*     */       
/* 108 */       ImageProcessor img = stack.getProcessor(i);
/* 109 */       img = erosion(img);
/* 110 */       result.setProcessor(img, i);
/*     */     } 
/*     */ 
/*     */     
/* 114 */     showProgress(flag);
/* 115 */     fireProgressChanged(this, nSlices, nSlices);
/*     */     
/* 117 */     return result;
/*     */   }
/*     */   
/*     */   public ImageStack closing(ImageStack stack) {
/* 121 */     boolean flag = showProgress();
/* 122 */     showProgress(false);
/*     */     
/* 124 */     int nSlices = stack.getSize();
/* 125 */     ImageStack result = stack.duplicate();
/* 126 */     for (int i = 1; i <= nSlices; i++) {
/* 127 */       showProgress(flag);
/* 128 */       fireProgressChanged(this, (i - 1), nSlices);
/* 129 */       showProgress(false);
/*     */       
/* 131 */       ImageProcessor img = stack.getProcessor(i);
/* 132 */       img = closing(img);
/* 133 */       result.setProcessor(img, i);
/*     */     } 
/*     */ 
/*     */     
/* 137 */     showProgress(flag);
/* 138 */     fireProgressChanged(this, nSlices, nSlices);
/*     */     
/* 140 */     return result;
/*     */   }
/*     */   
/*     */   public ImageStack opening(ImageStack stack) {
/* 144 */     boolean flag = showProgress();
/* 145 */     showProgress(false);
/*     */     
/* 147 */     int nSlices = stack.getSize();
/* 148 */     ImageStack result = stack.duplicate();
/* 149 */     for (int i = 1; i <= nSlices; i++) {
/* 150 */       showProgress(flag);
/* 151 */       fireProgressChanged(this, (i - 1), nSlices);
/* 152 */       showProgress(false);
/*     */       
/* 154 */       ImageProcessor img = stack.getProcessor(i);
/* 155 */       img = opening(img);
/* 156 */       result.setProcessor(img, i);
/*     */     } 
/*     */ 
/*     */     
/* 160 */     showProgress(flag);
/* 161 */     fireProgressChanged(this, nSlices, nSlices);
/*     */     
/* 163 */     return result;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/morphology/strel/AbstractStrel.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */