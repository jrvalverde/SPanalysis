/*     */ package inra.ijpb.morphology.strel;
/*     */ 
/*     */ import ij.process.ImageProcessor;
/*     */ import inra.ijpb.morphology.Strel;
/*     */ import inra.ijpb.morphology.Strel3D;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LinearHorizontalStrel
/*     */   extends AbstractInPlaceStrel
/*     */ {
/*     */   int size;
/*     */   int offset;
/*     */   
/*     */   public static final LinearHorizontalStrel fromDiameter(int diam) {
/*  44 */     return new LinearHorizontalStrel(diam);
/*     */   }
/*     */   
/*     */   public static final LinearHorizontalStrel fromRadius(int radius) {
/*  48 */     return new LinearHorizontalStrel(2 * radius + 1, radius);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LinearHorizontalStrel(int size) {
/*  75 */     if (size < 1) {
/*  76 */       throw new RuntimeException("Requires a positive size");
/*     */     }
/*  78 */     this.size = size;
/*     */     
/*  80 */     this.offset = (int)Math.floor(((this.size - 1) / 2));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LinearHorizontalStrel(int size, int offset) {
/*  90 */     if (size < 1) {
/*  91 */       throw new RuntimeException("Requires a positive size");
/*     */     }
/*  93 */     this.size = size;
/*     */     
/*  95 */     if (offset < 0) {
/*  96 */       throw new RuntimeException("Requires a non-negative offset");
/*     */     }
/*  98 */     if (offset >= size) {
/*  99 */       throw new RuntimeException("Offset can not be greater than size");
/*     */     }
/* 101 */     this.offset = offset;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void inPlaceDilation(ImageProcessor image) {
/* 114 */     if (this.size <= 1) {
/*     */       return;
/*     */     }
/*     */     
/* 118 */     if (image instanceof ij.process.ByteProcessor) {
/* 119 */       inPlaceDilationGray8(image);
/*     */     } else {
/* 121 */       inPlaceDilationFloat(image);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void inPlaceDilationGray8(ImageProcessor image) {
/* 126 */     int width = image.getWidth();
/* 127 */     int height = image.getHeight();
/*     */ 
/*     */     
/* 130 */     int shift = this.size - this.offset - 1;
/*     */ 
/*     */     
/* 133 */     LocalExtremumBufferGray8 localMax = new LocalExtremumBufferGray8(this.size, 
/* 134 */         LocalExtremum.Type.MAXIMUM);
/*     */ 
/*     */     
/* 137 */     for (int y = 0; y < height; y++) {
/* 138 */       fireProgressChanged(this, y, height);
/*     */ 
/*     */       
/* 141 */       localMax.fill(0);
/*     */       
/*     */       int x;
/* 144 */       for (x = 0; x < Math.min(shift, width); x++) {
/* 145 */         localMax.add(image.get(x, y));
/*     */       }
/*     */ 
/*     */       
/* 149 */       for (x = 0; x < width - shift; x++) {
/* 150 */         localMax.add(image.get(x + shift, y));
/* 151 */         image.set(x, y, localMax.getMax());
/*     */       } 
/*     */ 
/*     */       
/* 155 */       for (x = Math.max(0, width - shift); x < width; x++) {
/* 156 */         localMax.add(0);
/* 157 */         image.set(x, y, localMax.getMax());
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 162 */     fireProgressChanged(this, height, height);
/*     */   }
/*     */ 
/*     */   
/*     */   private void inPlaceDilationFloat(ImageProcessor image) {
/* 167 */     int width = image.getWidth();
/* 168 */     int height = image.getHeight();
/*     */ 
/*     */     
/* 171 */     int shift = this.size - this.offset - 1;
/*     */ 
/*     */     
/* 174 */     LocalExtremumBufferDouble localMax = new LocalExtremumBufferDouble(this.size, 
/* 175 */         LocalExtremum.Type.MAXIMUM);
/*     */ 
/*     */     
/* 178 */     for (int y = 0; y < height; y++) {
/* 179 */       fireProgressChanged(this, y, height);
/*     */ 
/*     */       
/* 182 */       localMax.fill(Double.NEGATIVE_INFINITY);
/*     */       
/*     */       int x;
/* 185 */       for (x = 0; x < Math.min(shift, width); x++) {
/* 186 */         localMax.add(image.getf(x, y));
/*     */       }
/*     */ 
/*     */       
/* 190 */       for (x = 0; x < width - shift; x++) {
/* 191 */         localMax.add(image.getf(x + shift, y));
/* 192 */         image.setf(x, y, (float)localMax.getMax());
/*     */       } 
/*     */ 
/*     */       
/* 196 */       for (x = Math.max(0, width - shift); x < width; x++) {
/* 197 */         localMax.add(Double.NEGATIVE_INFINITY);
/* 198 */         image.setf(x, y, (float)localMax.getMax());
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 203 */     fireProgressChanged(this, height, height);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void inPlaceErosion(ImageProcessor image) {
/* 213 */     if (this.size <= 1) {
/*     */       return;
/*     */     }
/*     */     
/* 217 */     if (image instanceof ij.process.ByteProcessor) {
/* 218 */       inPlaceErosionGray8(image);
/*     */     } else {
/* 220 */       inPlaceErosionFloat(image);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void inPlaceErosionGray8(ImageProcessor image) {
/* 225 */     int width = image.getWidth();
/* 226 */     int height = image.getHeight();
/*     */ 
/*     */     
/* 229 */     int shift = this.size - this.offset - 1;
/*     */ 
/*     */     
/* 232 */     LocalExtremumBufferGray8 localMin = new LocalExtremumBufferGray8(this.size, 
/* 233 */         LocalExtremum.Type.MINIMUM);
/*     */ 
/*     */     
/* 236 */     for (int y = 0; y < height; y++) {
/* 237 */       fireProgressChanged(this, y, height);
/*     */ 
/*     */       
/* 240 */       localMin.fill(255);
/*     */       
/*     */       int x;
/* 243 */       for (x = 0; x < Math.min(shift, width); x++) {
/* 244 */         localMin.add(image.get(x, y));
/*     */       }
/*     */ 
/*     */       
/* 248 */       for (x = 0; x < width - shift; x++) {
/* 249 */         localMin.add(image.get(x + shift, y));
/* 250 */         image.set(x, y, localMin.getMax());
/*     */       } 
/*     */ 
/*     */       
/* 254 */       for (x = Math.max(0, width - shift); x < width; x++) {
/* 255 */         localMin.add(255);
/* 256 */         image.set(x, y, localMin.getMax());
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 261 */     fireProgressChanged(this, height, height);
/*     */   }
/*     */ 
/*     */   
/*     */   private void inPlaceErosionFloat(ImageProcessor image) {
/* 266 */     int width = image.getWidth();
/* 267 */     int height = image.getHeight();
/*     */ 
/*     */     
/* 270 */     int shift = this.size - this.offset - 1;
/*     */ 
/*     */     
/* 273 */     LocalExtremumBufferDouble localMin = new LocalExtremumBufferDouble(this.size, 
/* 274 */         LocalExtremum.Type.MINIMUM);
/*     */ 
/*     */     
/* 277 */     for (int y = 0; y < height; y++) {
/* 278 */       fireProgressChanged(this, y, height);
/*     */ 
/*     */       
/* 281 */       localMin.fill(Double.POSITIVE_INFINITY);
/*     */       
/*     */       int x;
/* 284 */       for (x = 0; x < Math.min(shift, width); x++) {
/* 285 */         localMin.add(image.getf(x, y));
/*     */       }
/*     */ 
/*     */       
/* 289 */       for (x = 0; x < width - shift; x++) {
/* 290 */         localMin.add(image.getf(x + shift, y));
/* 291 */         image.setf(x, y, (float)localMin.getMax());
/*     */       } 
/*     */ 
/*     */       
/* 295 */       for (x = Math.max(0, width - shift); x < width; x++) {
/* 296 */         localMin.add(Double.POSITIVE_INFINITY);
/* 297 */         image.setf(x, y, (float)localMin.getMax());
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 302 */     fireProgressChanged(this, height, height);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int[][] getMask() {
/* 311 */     int[][] mask = new int[1][this.size];
/* 312 */     for (int i = 0; i < this.size; i++) {
/* 313 */       mask[0][i] = 255;
/*     */     }
/*     */     
/* 316 */     return mask;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int[] getOffset() {
/* 324 */     return new int[] { this.offset, this.offset };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int[][] getShifts() {
/* 332 */     int[][] shifts = new int[this.size][2];
/* 333 */     for (int i = 0; i < this.size; i++) {
/* 334 */       shifts[i][0] = i - this.offset;
/* 335 */       shifts[i][1] = 0;
/*     */     } 
/* 337 */     return shifts;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int[] getSize() {
/* 345 */     return new int[] { this.size, 1 };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LinearHorizontalStrel reverse() {
/* 354 */     return new LinearHorizontalStrel(this.size, this.size - this.offset - 1);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/morphology/strel/LinearHorizontalStrel.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */