/*     */ package inra.ijpb.morphology.geodrec;
/*     */ 
/*     */ import ij.IJ;
/*     */ import ij.process.ImageProcessor;
/*     */ import inra.ijpb.data.Cursor2D;
/*     */ import java.util.ArrayDeque;
/*     */ import java.util.Deque;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GeodesicReconstructionHybrid
/*     */   extends GeodesicReconstructionAlgoStub
/*     */ {
/*  56 */   GeodesicReconstructionType reconstructionType = GeodesicReconstructionType.BY_DILATION;
/*     */   
/*     */   ImageProcessor marker;
/*     */   
/*     */   ImageProcessor mask;
/*     */   
/*     */   ImageProcessor result;
/*     */   
/*  64 */   int sizeX = 0;
/*     */   
/*  66 */   int sizeY = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Deque<Cursor2D> queue;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GeodesicReconstructionHybrid() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GeodesicReconstructionHybrid(GeodesicReconstructionType type) {
/*  92 */     this.reconstructionType = type;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GeodesicReconstructionHybrid(int connectivity) {
/* 104 */     this.connectivity = connectivity;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GeodesicReconstructionHybrid(GeodesicReconstructionType type, int connectivity) {
/* 118 */     this.reconstructionType = type;
/* 119 */     this.connectivity = connectivity;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GeodesicReconstructionType getReconstructionType() {
/* 130 */     return this.reconstructionType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setReconstructionType(GeodesicReconstructionType reconstructionType) {
/* 138 */     this.reconstructionType = reconstructionType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ImageProcessor applyTo(ImageProcessor marker, ImageProcessor mask) {
/* 152 */     this.marker = marker;
/* 153 */     this.mask = mask;
/*     */ 
/*     */     
/* 156 */     this.sizeX = marker.getWidth();
/* 157 */     this.sizeY = marker.getHeight();
/* 158 */     if (this.sizeX != mask.getWidth() || this.sizeY != mask.getHeight())
/*     */     {
/* 160 */       throw new IllegalArgumentException("Marker and Mask images must have the same size");
/*     */     }
/*     */ 
/*     */     
/* 164 */     if (this.connectivity != 4 && this.connectivity != 8)
/*     */     {
/* 166 */       throw new RuntimeException(
/* 167 */           "Connectivity for planar images must be either 4 or 8, not " + 
/* 168 */           this.connectivity);
/*     */     }
/*     */     
/* 171 */     this.queue = new ArrayDeque<Cursor2D>();
/*     */     
/* 173 */     boolean isInteger = !(mask instanceof ij.process.FloatProcessor);
/*     */ 
/*     */ 
/*     */     
/* 177 */     if (isInteger) {
/*     */       
/* 179 */       initializeResult();
/*     */     }
/*     */     else {
/*     */       
/* 183 */       initializeResultFloat();
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 188 */     if (this.verbose)
/*     */     {
/* 190 */       System.out.println("Forward iteration");
/*     */     }
/* 192 */     if (this.showStatus)
/*     */     {
/* 194 */       IJ.showStatus("Geod. Rec. by Dil. Fwd");
/*     */     }
/*     */ 
/*     */     
/* 198 */     switch (this.connectivity) {
/*     */       
/*     */       case 4:
/* 201 */         if (isInteger) {
/* 202 */           forwardScanC4(); break;
/*     */         } 
/* 204 */         forwardScanC4Float();
/*     */         break;
/*     */       case 8:
/* 207 */         if (isInteger) {
/* 208 */           forwardScanC8(); break;
/*     */         } 
/* 210 */         forwardScanC8Float();
/*     */         break;
/*     */     } 
/*     */ 
/*     */     
/* 215 */     if (this.verbose)
/*     */     {
/* 217 */       System.out.println("Backward iteration");
/*     */     }
/* 219 */     if (this.showStatus)
/*     */     {
/* 221 */       IJ.showStatus("Geod. Rec. by Dil. Bwd");
/*     */     }
/*     */ 
/*     */     
/* 225 */     switch (this.connectivity) {
/*     */       
/*     */       case 4:
/* 228 */         if (isInteger) {
/* 229 */           backwardScanC4(); break;
/*     */         } 
/* 231 */         backwardScanC4Float();
/*     */         break;
/*     */       case 8:
/* 234 */         if (isInteger) {
/* 235 */           backwardScanC8(); break;
/*     */         } 
/* 237 */         backwardScanC8Float();
/*     */         break;
/*     */     } 
/*     */     
/* 241 */     if (this.verbose)
/*     */     {
/* 243 */       System.out.println("Process queue ");
/*     */     }
/* 245 */     if (this.showStatus)
/*     */     {
/* 247 */       IJ.showStatus("Processing Queue... ");
/*     */     }
/*     */ 
/*     */     
/* 251 */     if (this.connectivity == 4) {
/*     */       
/* 253 */       if (isInteger) {
/* 254 */         processQueueC4();
/*     */       } else {
/* 256 */         processQueueC4Float();
/*     */       } 
/* 258 */     } else if (isInteger) {
/* 259 */       processQueueC8();
/*     */     } else {
/* 261 */       processQueueC8Float();
/*     */     } 
/*     */ 
/*     */     
/* 265 */     return this.result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void initializeResult() {
/* 271 */     this.result = this.mask.createProcessor(this.sizeX, this.sizeY);
/*     */     
/* 273 */     int sign = this.reconstructionType.getSign();
/* 274 */     for (int y = 0; y < this.sizeY; y++) {
/*     */       
/* 276 */       for (int x = 0; x < this.sizeX; x++) {
/*     */         
/* 278 */         int v1 = this.marker.get(x, y) * sign;
/* 279 */         int v2 = this.mask.get(x, y) * sign;
/* 280 */         this.result.set(x, y, Math.min(v1, v2) * sign);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void initializeResultFloat() {
/* 288 */     this.result = this.mask.createProcessor(this.sizeX, this.sizeY);
/*     */     
/* 290 */     float sign = this.reconstructionType.getSign();
/* 291 */     for (int y = 0; y < this.sizeY; y++) {
/*     */       
/* 293 */       for (int x = 0; x < this.sizeX; x++) {
/*     */         
/* 295 */         float v1 = this.marker.getf(x, y) * sign;
/* 296 */         float v2 = this.mask.getf(x, y) * sign;
/* 297 */         this.result.setf(x, y, Math.min(v1, v2) * sign);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void forwardScanC4() {
/* 308 */     int sign = this.reconstructionType.getSign();
/*     */     
/* 310 */     if (this.showProgress)
/*     */     {
/* 312 */       IJ.showProgress(0, this.sizeY);
/*     */     }
/*     */ 
/*     */     
/* 316 */     for (int y = 0; y < this.sizeY; y++) {
/*     */ 
/*     */       
/* 319 */       if (this.showProgress)
/*     */       {
/* 321 */         IJ.showProgress(y, this.sizeY);
/*     */       }
/*     */ 
/*     */       
/* 325 */       for (int x = 0; x < this.sizeX; x++) {
/*     */         
/* 327 */         int currentValue = this.result.get(x, y) * sign;
/* 328 */         int maxValue = currentValue;
/*     */         
/* 330 */         if (x > 0)
/* 331 */           maxValue = Math.max(maxValue, this.result.get(x - 1, y) * sign); 
/* 332 */         if (y > 0) {
/* 333 */           maxValue = Math.max(maxValue, this.result.get(x, y - 1) * sign);
/*     */         }
/*     */         
/* 336 */         maxValue = Math.min(maxValue, this.mask.get(x, y) * sign);
/* 337 */         if (maxValue > currentValue)
/*     */         {
/* 339 */           this.result.set(x, y, maxValue * sign);
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void forwardScanC4Float() {
/* 351 */     float sign = this.reconstructionType.getSign();
/*     */     
/* 353 */     if (this.showProgress)
/*     */     {
/* 355 */       IJ.showProgress(0, this.sizeY);
/*     */     }
/*     */ 
/*     */     
/* 359 */     for (int y = 0; y < this.sizeY; y++) {
/*     */ 
/*     */       
/* 362 */       if (this.showProgress)
/*     */       {
/* 364 */         IJ.showProgress(y, this.sizeY);
/*     */       }
/*     */ 
/*     */       
/* 368 */       for (int x = 0; x < this.sizeX; x++) {
/*     */         
/* 370 */         float currentValue = this.result.getf(x, y) * sign;
/* 371 */         float maxValue = currentValue;
/*     */         
/* 373 */         if (x > 0)
/* 374 */           maxValue = Math.max(maxValue, this.result.getf(x - 1, y) * sign); 
/* 375 */         if (y > 0) {
/* 376 */           maxValue = Math.max(maxValue, this.result.getf(x, y - 1) * sign);
/*     */         }
/*     */         
/* 379 */         maxValue = Math.min(maxValue, this.mask.getf(x, y) * sign);
/* 380 */         if (maxValue > currentValue)
/*     */         {
/* 382 */           this.result.setf(x, y, maxValue * sign);
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void forwardScanC8() {
/* 394 */     int sign = this.reconstructionType.getSign();
/*     */     
/* 396 */     if (this.showProgress)
/*     */     {
/* 398 */       IJ.showProgress(0, this.sizeY);
/*     */     }
/*     */ 
/*     */     
/* 402 */     for (int y = 0; y < this.sizeY; y++) {
/*     */ 
/*     */       
/* 405 */       if (this.showProgress)
/*     */       {
/* 407 */         IJ.showProgress(y, this.sizeY);
/*     */       }
/*     */ 
/*     */       
/* 411 */       for (int x = 0; x < this.sizeX; x++) {
/*     */         
/* 413 */         int currentValue = this.result.get(x, y) * sign;
/* 414 */         int maxValue = currentValue;
/*     */         
/* 416 */         if (y > 0) {
/*     */ 
/*     */           
/* 419 */           if (x > 0)
/* 420 */             maxValue = Math.max(maxValue, this.result.get(x - 1, y - 1) * sign); 
/* 421 */           maxValue = Math.max(maxValue, this.result.get(x, y - 1) * sign);
/* 422 */           if (x < this.sizeX - 1)
/* 423 */             maxValue = Math.max(maxValue, this.result.get(x + 1, y - 1) * sign); 
/*     */         } 
/* 425 */         if (x > 0) {
/* 426 */           maxValue = Math.max(maxValue, this.result.get(x - 1, y) * sign);
/*     */         }
/*     */         
/* 429 */         maxValue = Math.min(maxValue, this.mask.get(x, y) * sign);
/* 430 */         if (maxValue > currentValue)
/*     */         {
/* 432 */           this.result.set(x, y, maxValue * sign);
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void forwardScanC8Float() {
/* 444 */     float sign = this.reconstructionType.getSign();
/*     */     
/* 446 */     if (this.showProgress)
/*     */     {
/* 448 */       IJ.showProgress(0, this.sizeY);
/*     */     }
/*     */ 
/*     */     
/* 452 */     for (int y = 0; y < this.sizeY; y++) {
/*     */ 
/*     */       
/* 455 */       if (this.showProgress)
/*     */       {
/* 457 */         IJ.showProgress(y, this.sizeY);
/*     */       }
/*     */ 
/*     */       
/* 461 */       for (int x = 0; x < this.sizeX; x++) {
/*     */         
/* 463 */         float currentValue = this.result.getf(x, y) * sign;
/* 464 */         float maxValue = currentValue;
/*     */         
/* 466 */         if (y > 0) {
/*     */ 
/*     */           
/* 469 */           if (x > 0)
/* 470 */             maxValue = Math.max(maxValue, this.result.getf(x - 1, y - 1) * sign); 
/* 471 */           maxValue = Math.max(maxValue, this.result.getf(x, y - 1) * sign);
/* 472 */           if (x < this.sizeX - 1)
/* 473 */             maxValue = Math.max(maxValue, this.result.getf(x + 1, y - 1) * sign); 
/*     */         } 
/* 475 */         if (x > 0) {
/* 476 */           maxValue = Math.max(maxValue, this.result.getf(x - 1, y) * sign);
/*     */         }
/*     */         
/* 479 */         maxValue = Math.min(maxValue, this.mask.getf(x, y) * sign);
/* 480 */         if (maxValue > currentValue)
/*     */         {
/* 482 */           this.result.setf(x, y, maxValue * sign);
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void backwardScanC4() {
/* 494 */     int sign = this.reconstructionType.getSign();
/*     */     
/* 496 */     if (this.showProgress)
/*     */     {
/* 498 */       IJ.showProgress(0, this.sizeY);
/*     */     }
/*     */ 
/*     */     
/* 502 */     for (int y = this.sizeY - 1; y >= 0; y--) {
/*     */ 
/*     */       
/* 505 */       if (this.showProgress)
/*     */       {
/* 507 */         IJ.showProgress(this.sizeY - 1 - y, this.sizeY);
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 512 */       for (int x = this.sizeX - 1; x >= 0; x--) {
/*     */ 
/*     */         
/* 515 */         int currentValue = this.result.get(x, y) * sign;
/* 516 */         int maxValue = currentValue;
/*     */         
/* 518 */         if (x < this.sizeX - 1)
/* 519 */           maxValue = Math.max(maxValue, this.result.get(x + 1, y) * sign); 
/* 520 */         if (y < this.sizeY - 1) {
/* 521 */           maxValue = Math.max(maxValue, this.result.get(x, y + 1) * sign);
/*     */         }
/*     */         
/* 524 */         maxValue = Math.min(maxValue, this.mask.get(x, y) * sign);
/*     */ 
/*     */         
/* 527 */         if (maxValue > currentValue) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 533 */           this.result.set(x, y, maxValue * sign);
/*     */ 
/*     */           
/* 536 */           if (x < this.sizeX - 1)
/* 537 */             updateQueue(x + 1, y, maxValue, sign); 
/* 538 */           if (y < this.sizeY - 1) {
/* 539 */             updateQueue(x, y + 1, maxValue, sign);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void backwardScanC4Float() {
/* 550 */     float sign = this.reconstructionType.getSign();
/*     */     
/* 552 */     if (this.showProgress)
/*     */     {
/* 554 */       IJ.showProgress(0, this.sizeY);
/*     */     }
/*     */ 
/*     */     
/* 558 */     for (int y = this.sizeY - 1; y >= 0; y--) {
/*     */ 
/*     */       
/* 561 */       if (this.showProgress)
/*     */       {
/* 563 */         IJ.showProgress(this.sizeY - 1 - y, this.sizeY);
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 568 */       for (int x = this.sizeX - 1; x >= 0; x--) {
/*     */ 
/*     */         
/* 571 */         float currentValue = this.result.getf(x, y) * sign;
/* 572 */         float maxValue = currentValue;
/*     */         
/* 574 */         if (x < this.sizeX - 1)
/* 575 */           maxValue = Math.max(maxValue, this.result.getf(x + 1, y) * sign); 
/* 576 */         if (y < this.sizeY - 1) {
/* 577 */           maxValue = Math.max(maxValue, this.result.getf(x, y + 1) * sign);
/*     */         }
/*     */         
/* 580 */         maxValue = Math.min(maxValue, this.mask.getf(x, y) * sign);
/*     */ 
/*     */         
/* 583 */         if (maxValue > currentValue) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 589 */           this.result.setf(x, y, maxValue * sign);
/*     */ 
/*     */           
/* 592 */           if (x < this.sizeX - 1)
/* 593 */             updateQueue(x + 1, y, maxValue, sign); 
/* 594 */           if (y < this.sizeY - 1) {
/* 595 */             updateQueue(x, y + 1, maxValue, sign);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void backwardScanC8() {
/* 607 */     int sign = this.reconstructionType.getSign();
/*     */     
/* 609 */     if (this.showProgress)
/*     */     {
/* 611 */       IJ.showProgress(0, this.sizeY);
/*     */     }
/*     */ 
/*     */     
/* 615 */     for (int y = this.sizeY - 1; y >= 0; y--) {
/*     */ 
/*     */       
/* 618 */       if (this.showProgress)
/*     */       {
/* 620 */         IJ.showProgress(this.sizeY - 1 - y, this.sizeY);
/*     */       }
/*     */ 
/*     */       
/* 624 */       for (int x = this.sizeX - 1; x >= 0; x--) {
/*     */         
/* 626 */         int currentValue = this.result.get(x, y) * sign;
/* 627 */         int maxValue = currentValue;
/*     */         
/* 629 */         if (y < this.sizeY - 1) {
/*     */ 
/*     */           
/* 632 */           if (x > 0)
/* 633 */             maxValue = Math.max(maxValue, this.result.get(x - 1, y + 1) * sign); 
/* 634 */           maxValue = Math.max(maxValue, this.result.get(x, y + 1) * sign);
/* 635 */           if (x < this.sizeX - 1)
/* 636 */             maxValue = Math.max(maxValue, this.result.get(x + 1, y + 1) * sign); 
/*     */         } 
/* 638 */         if (x < this.sizeX - 1) {
/* 639 */           maxValue = Math.max(maxValue, this.result.get(x + 1, y) * sign);
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 650 */         maxValue = Math.min(maxValue, this.mask.get(x, y) * sign);
/*     */ 
/*     */         
/* 653 */         if (maxValue > currentValue) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 659 */           this.result.set(x, y, maxValue * sign);
/*     */ 
/*     */           
/* 662 */           if (x < this.sizeX - 1)
/* 663 */             updateQueue(x + 1, y, maxValue, sign); 
/* 664 */           if (y < this.sizeY - 1) {
/*     */             
/* 666 */             if (x > 0)
/* 667 */               updateQueue(x - 1, y + 1, maxValue, sign); 
/* 668 */             updateQueue(x, y + 1, maxValue, sign);
/* 669 */             if (x < this.sizeX - 1) {
/* 670 */               updateQueue(x + 1, y + 1, maxValue, sign);
/*     */             }
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void backwardScanC8Float() {
/* 683 */     float sign = this.reconstructionType.getSign();
/*     */     
/* 685 */     if (this.showProgress)
/*     */     {
/* 687 */       IJ.showProgress(0, this.sizeY);
/*     */     }
/*     */ 
/*     */     
/* 691 */     for (int y = this.sizeY - 1; y >= 0; y--) {
/*     */ 
/*     */       
/* 694 */       if (this.showProgress)
/*     */       {
/* 696 */         IJ.showProgress(this.sizeY - 1 - y, this.sizeY);
/*     */       }
/*     */ 
/*     */       
/* 700 */       for (int x = this.sizeX - 1; x >= 0; x--) {
/*     */         
/* 702 */         float currentValue = this.result.getf(x, y) * sign;
/* 703 */         float maxValue = currentValue;
/*     */         
/* 705 */         if (y < this.sizeY - 1) {
/*     */ 
/*     */           
/* 708 */           if (x > 0)
/* 709 */             maxValue = Math.max(maxValue, this.result.getf(x - 1, y + 1) * sign); 
/* 710 */           maxValue = Math.max(maxValue, this.result.getf(x, y + 1) * sign);
/* 711 */           if (x < this.sizeX - 1)
/* 712 */             maxValue = Math.max(maxValue, this.result.getf(x + 1, y + 1) * sign); 
/*     */         } 
/* 714 */         if (x < this.sizeX - 1) {
/* 715 */           maxValue = Math.max(maxValue, this.result.getf(x + 1, y) * sign);
/*     */         }
/*     */         
/* 718 */         maxValue = Math.min(maxValue, this.mask.getf(x, y) * sign);
/*     */ 
/*     */         
/* 721 */         if (maxValue > currentValue) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 727 */           this.result.setf(x, y, maxValue * sign);
/*     */ 
/*     */           
/* 730 */           if (x < this.sizeX - 1)
/* 731 */             updateQueue(x + 1, y, maxValue, sign); 
/* 732 */           if (y < this.sizeY - 1) {
/*     */             
/* 734 */             if (x > 0)
/* 735 */               updateQueue(x - 1, y + 1, maxValue, sign); 
/* 736 */             updateQueue(x, y + 1, maxValue, sign);
/* 737 */             if (x < this.sizeX - 1) {
/* 738 */               updateQueue(x + 1, y + 1, maxValue, sign);
/*     */             }
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void processQueueC4() {
/* 752 */     int sign = this.reconstructionType.getSign();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 757 */     while (!this.queue.isEmpty()) {
/*     */       
/* 759 */       Cursor2D p = this.queue.removeFirst();
/* 760 */       int x = p.getX();
/* 761 */       int y = p.getY();
/* 762 */       int value = this.result.get(x, y) * sign;
/*     */ 
/*     */       
/* 765 */       if (x > 0)
/* 766 */         value = Math.max(value, this.result.get(x - 1, y) * sign); 
/* 767 */       if (x < this.sizeX - 1)
/* 768 */         value = Math.max(value, this.result.get(x + 1, y) * sign); 
/* 769 */       if (y > 0)
/* 770 */         value = Math.max(value, this.result.get(x, y - 1) * sign); 
/* 771 */       if (y < this.sizeY - 1) {
/* 772 */         value = Math.max(value, this.result.get(x, y + 1) * sign);
/*     */       }
/*     */       
/* 775 */       value = Math.min(value, this.mask.get(x, y) * sign);
/*     */ 
/*     */       
/* 778 */       if (value <= this.result.get(x, y) * sign) {
/*     */         continue;
/*     */       }
/*     */       
/* 782 */       this.result.set(x, y, value * sign);
/*     */ 
/*     */       
/* 785 */       if (x > 0)
/* 786 */         updateQueue(x - 1, y, value, sign); 
/* 787 */       if (x < this.sizeX - 1)
/* 788 */         updateQueue(x + 1, y, value, sign); 
/* 789 */       if (y > 0)
/* 790 */         updateQueue(x, y - 1, value, sign); 
/* 791 */       if (y < this.sizeY - 1) {
/* 792 */         updateQueue(x, y + 1, value, sign);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void processQueueC4Float() {
/* 803 */     float sign = this.reconstructionType.getSign();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 808 */     while (!this.queue.isEmpty()) {
/*     */       
/* 810 */       Cursor2D p = this.queue.removeFirst();
/* 811 */       int x = p.getX();
/* 812 */       int y = p.getY();
/* 813 */       float value = this.result.getf(x, y) * sign;
/*     */ 
/*     */       
/* 816 */       if (x > 0)
/* 817 */         value = Math.max(value, this.result.getf(x - 1, y) * sign); 
/* 818 */       if (x < this.sizeX - 1)
/* 819 */         value = Math.max(value, this.result.getf(x + 1, y) * sign); 
/* 820 */       if (y > 0)
/* 821 */         value = Math.max(value, this.result.getf(x, y - 1) * sign); 
/* 822 */       if (y < this.sizeY - 1) {
/* 823 */         value = Math.max(value, this.result.getf(x, y + 1) * sign);
/*     */       }
/*     */       
/* 826 */       value = Math.min(value, this.mask.getf(x, y) * sign);
/*     */ 
/*     */       
/* 829 */       if (value <= this.result.getf(x, y) * sign) {
/*     */         continue;
/*     */       }
/*     */       
/* 833 */       this.result.setf(x, y, value * sign);
/*     */ 
/*     */       
/* 836 */       if (x > 0)
/* 837 */         updateQueue(x - 1, y, value, sign); 
/* 838 */       if (x < this.sizeX - 1)
/* 839 */         updateQueue(x + 1, y, value, sign); 
/* 840 */       if (y > 0)
/* 841 */         updateQueue(x, y - 1, value, sign); 
/* 842 */       if (y < this.sizeY - 1) {
/* 843 */         updateQueue(x, y + 1, value, sign);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void processQueueC8() {
/* 854 */     int sign = this.reconstructionType.getSign();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 859 */     while (!this.queue.isEmpty()) {
/*     */ 
/*     */ 
/*     */       
/* 863 */       Cursor2D p = this.queue.removeFirst();
/* 864 */       int x = p.getX();
/* 865 */       int y = p.getY();
/* 866 */       int value = this.result.get(x, y) * sign;
/*     */ 
/*     */       
/* 869 */       int xmin = Math.max(x - 1, 0);
/* 870 */       int xmax = Math.min(x + 1, this.sizeX - 1);
/* 871 */       int ymin = Math.max(y - 1, 0);
/* 872 */       int ymax = Math.min(y + 1, this.sizeY - 1);
/*     */       
/*     */       int y2;
/* 875 */       for (y2 = ymin; y2 <= ymax; y2++) {
/*     */         
/* 877 */         for (int x2 = xmin; x2 <= xmax; x2++)
/*     */         {
/* 879 */           value = Math.max(value, this.result.get(x2, y2) * sign);
/*     */         }
/*     */       } 
/*     */ 
/*     */       
/* 884 */       value = Math.min(value, this.mask.get(x, y) * sign);
/*     */ 
/*     */       
/* 887 */       if (value <= this.result.get(x, y) * sign) {
/*     */         continue;
/*     */       }
/*     */       
/* 891 */       this.result.set(x, y, value * sign);
/*     */ 
/*     */       
/* 894 */       for (y2 = ymin; y2 <= ymax; y2++) {
/*     */         
/* 896 */         for (int x2 = xmin; x2 <= xmax; x2++)
/*     */         {
/* 898 */           updateQueue(x2, y2, value, sign);
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void processQueueC8Float() {
/* 911 */     float sign = this.reconstructionType.getSign();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 916 */     while (!this.queue.isEmpty()) {
/*     */ 
/*     */ 
/*     */       
/* 920 */       Cursor2D p = this.queue.removeFirst();
/* 921 */       int x = p.getX();
/* 922 */       int y = p.getY();
/* 923 */       float value = this.result.getf(x, y) * sign;
/*     */ 
/*     */       
/* 926 */       int xmin = Math.max(x - 1, 0);
/* 927 */       int xmax = Math.min(x + 1, this.sizeX - 1);
/* 928 */       int ymin = Math.max(y - 1, 0);
/* 929 */       int ymax = Math.min(y + 1, this.sizeY - 1);
/*     */       
/*     */       int y2;
/* 932 */       for (y2 = ymin; y2 <= ymax; y2++) {
/*     */         
/* 934 */         for (int x2 = xmin; x2 <= xmax; x2++)
/*     */         {
/* 936 */           value = Math.max(value, this.result.getf(x2, y2) * sign);
/*     */         }
/*     */       } 
/*     */ 
/*     */       
/* 941 */       value = Math.min(value, this.mask.getf(x, y) * sign);
/*     */ 
/*     */       
/* 944 */       if (value <= this.result.getf(x, y) * sign) {
/*     */         continue;
/*     */       }
/*     */       
/* 948 */       this.result.setf(x, y, value * sign);
/*     */ 
/*     */       
/* 951 */       for (y2 = ymin; y2 <= ymax; y2++) {
/*     */         
/* 953 */         for (int x2 = xmin; x2 <= xmax; x2++)
/*     */         {
/* 955 */           updateQueue(x2, y2, value, sign);
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void updateQueue(int x, int y, int value, int sign) {
/* 971 */     int maskValue = this.mask.get(x, y) * sign;
/* 972 */     value = Math.min(value, maskValue);
/*     */     
/* 974 */     int resultValue = this.result.get(x, y) * sign;
/* 975 */     if (value > resultValue) {
/* 976 */       Cursor2D position = new Cursor2D(x, y);
/* 977 */       this.queue.add(position);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void updateQueue(int x, int y, float value, float sign) {
/* 991 */     float maskValue = this.mask.getf(x, y) * sign;
/* 992 */     value = Math.min(value, maskValue);
/*     */     
/* 994 */     float resultValue = this.result.getf(x, y) * sign;
/* 995 */     if (value > resultValue) {
/* 996 */       Cursor2D position = new Cursor2D(x, y);
/* 997 */       this.queue.add(position);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/morphology/geodrec/GeodesicReconstructionHybrid.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */