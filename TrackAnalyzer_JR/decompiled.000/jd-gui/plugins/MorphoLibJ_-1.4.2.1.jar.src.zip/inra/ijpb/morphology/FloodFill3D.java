/*      */ package inra.ijpb.morphology;
/*      */ 
/*      */ import ij.ImageStack;
/*      */ import inra.ijpb.data.image.Image3D;
/*      */ import java.util.ArrayList;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class FloodFill3D
/*      */ {
/*      */   public static final void floodFill(ImageStack image, int x, int y, int z, int value, int conn) {
/*   79 */     if (conn == 6) {
/*   80 */       floodFillC6(image, x, y, z, value);
/*   81 */     } else if (conn == 26) {
/*   82 */       floodFillC26(image, x, y, z, value);
/*      */     } else {
/*   84 */       throw new IllegalArgumentException("Connectivity must be either 6 or 26, not " + conn);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final void floodFillC6(ImageStack image, int x, int y, int z, int value) {
/*  107 */     int sizeX = image.getWidth();
/*  108 */     int sizeY = image.getHeight();
/*  109 */     int sizeZ = image.getSize();
/*      */ 
/*      */     
/*  112 */     int oldValue = (int)image.getVoxel(x, y, z);
/*      */ 
/*      */     
/*  115 */     if (oldValue == value) {
/*      */       return;
/*      */     }
/*      */     
/*  119 */     ArrayList<Cursor3D> stack = new ArrayList<Cursor3D>();
/*  120 */     stack.add(new Cursor3D(x, y, z));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  126 */     while (!stack.isEmpty()) {
/*      */ 
/*      */       
/*  129 */       Cursor3D p = stack.remove(stack.size() - 1);
/*  130 */       x = p.x;
/*  131 */       y = p.y;
/*  132 */       z = p.z;
/*      */ 
/*      */       
/*  135 */       if (image.getVoxel(x, y, z) != oldValue) {
/*      */         continue;
/*      */       }
/*      */       
/*  139 */       int x1 = x;
/*  140 */       int x2 = x;
/*      */ 
/*      */       
/*  143 */       while (x1 > 0 && image.getVoxel(x1 - 1, y, z) == oldValue) {
/*  144 */         x1--;
/*      */       }
/*      */       
/*  147 */       while (x2 < sizeX - 1 && image.getVoxel(x2 + 1, y, z) == oldValue) {
/*  148 */         x2++;
/*      */       }
/*      */       
/*  151 */       fillLineInt(image, x1, x2, y, z, value);
/*      */ 
/*      */       
/*  154 */       if (y > 0) {
/*      */         
/*  156 */         boolean inScanLine = false;
/*  157 */         for (int i = x1; i <= x2; i++) {
/*      */           
/*  159 */           int val = (int)image.getVoxel(i, y - 1, z);
/*  160 */           if (!inScanLine && val == oldValue) {
/*      */             
/*  162 */             stack.add(new Cursor3D(i, y - 1, z));
/*  163 */             inScanLine = true;
/*      */           }
/*  165 */           else if (inScanLine && val != oldValue) {
/*      */             
/*  167 */             inScanLine = false;
/*      */           } 
/*      */         } 
/*      */       } 
/*      */ 
/*      */       
/*  173 */       if (y < sizeY - 1) {
/*      */         
/*  175 */         boolean inScanLine = false;
/*  176 */         for (int i = x1; i <= x2; i++) {
/*      */           
/*  178 */           int val = (int)image.getVoxel(i, y + 1, z);
/*  179 */           if (!inScanLine && val == oldValue) {
/*      */             
/*  181 */             stack.add(new Cursor3D(i, y + 1, z));
/*  182 */             inScanLine = true;
/*      */           }
/*  184 */           else if (inScanLine && val != oldValue) {
/*      */             
/*  186 */             inScanLine = false;
/*      */           } 
/*      */         } 
/*      */       } 
/*      */ 
/*      */       
/*  192 */       if (z > 0) {
/*      */         
/*  194 */         boolean inScanLine = false;
/*  195 */         for (int i = x1; i <= x2; i++) {
/*      */           
/*  197 */           int val = (int)image.getVoxel(i, y, z - 1);
/*  198 */           if (!inScanLine && val == oldValue) {
/*      */             
/*  200 */             stack.add(new Cursor3D(i, y, z - 1));
/*  201 */             inScanLine = true;
/*      */           }
/*  203 */           else if (inScanLine && val != oldValue) {
/*      */             
/*  205 */             inScanLine = false;
/*      */           } 
/*      */         } 
/*      */       } 
/*      */ 
/*      */       
/*  211 */       if (z < sizeZ - 1) {
/*      */         
/*  213 */         boolean inScanLine = false;
/*  214 */         for (int i = x1; i <= x2; i++) {
/*      */           
/*  216 */           int val = (int)image.getVoxel(i, y, z + 1);
/*  217 */           if (!inScanLine && val == oldValue) {
/*      */             
/*  219 */             stack.add(new Cursor3D(i, y, z + 1));
/*  220 */             inScanLine = true;
/*      */           }
/*  222 */           else if (inScanLine && val != oldValue) {
/*      */             
/*  224 */             inScanLine = false;
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final void floodFillC26(ImageStack image, int x, int y, int z, int value) {
/*  251 */     int sizeX = image.getWidth();
/*  252 */     int sizeY = image.getHeight();
/*  253 */     int sizeZ = image.getSize();
/*      */ 
/*      */     
/*  256 */     int oldValue = (int)image.getVoxel(x, y, z);
/*      */ 
/*      */     
/*  259 */     if (oldValue == value) {
/*      */       return;
/*      */     }
/*      */     
/*  263 */     ArrayList<Cursor3D> stack = new ArrayList<Cursor3D>();
/*  264 */     stack.add(new Cursor3D(x, y, z));
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  269 */     while (!stack.isEmpty()) {
/*      */ 
/*      */       
/*  272 */       Cursor3D p = stack.remove(stack.size() - 1);
/*  273 */       x = p.x;
/*  274 */       y = p.y;
/*  275 */       z = p.z;
/*      */ 
/*      */       
/*  278 */       if (image.getVoxel(x, y, z) != oldValue) {
/*      */         continue;
/*      */       }
/*      */       
/*  282 */       int x1 = x;
/*  283 */       int x2 = x;
/*      */ 
/*      */       
/*  286 */       while (x1 > 0 && image.getVoxel(x1 - 1, y, z) == oldValue) {
/*  287 */         x1--;
/*      */       }
/*      */       
/*  290 */       while (x2 < sizeX - 1 && image.getVoxel(x2 + 1, y, z) == oldValue) {
/*  291 */         x2++;
/*      */       }
/*      */       
/*  294 */       fillLineInt(image, x1, x2, y, z, value);
/*      */ 
/*      */       
/*  297 */       for (int z2 = Math.max(z - 1, 0); z2 <= Math.min(z + 1, sizeZ - 1); z2++) {
/*      */         
/*  299 */         for (int y2 = Math.max(y - 1, 0); y2 <= Math.min(y + 1, sizeY - 1); y2++) {
/*      */ 
/*      */           
/*  302 */           if (y2 != z || y2 != y) {
/*      */ 
/*      */             
/*  305 */             boolean inScanLine = false;
/*  306 */             for (int i = Math.max(x1 - 1, 0); i <= Math.min(x2 + 1, sizeX - 1); i++) {
/*      */               
/*  308 */               int val = (int)image.getVoxel(i, y2, z2);
/*  309 */               if (!inScanLine && val == oldValue) {
/*      */                 
/*  311 */                 stack.add(new Cursor3D(i, y2, z2));
/*  312 */                 inScanLine = true;
/*      */               }
/*  314 */               else if (inScanLine && val != oldValue) {
/*      */                 
/*  316 */                 inScanLine = false;
/*      */               } 
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final void floodFill(ImageStack image, int x, int y, int z, double value, int conn) {
/*  347 */     if (conn == 6) {
/*  348 */       floodFillC6(image, x, y, z, value);
/*  349 */     } else if (conn == 26) {
/*  350 */       floodFillC26(image, x, y, z, value);
/*      */     } else {
/*  352 */       throw new IllegalArgumentException("Connectivity must be either 6 or 26, not " + conn);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final void floodFillC6(ImageStack image, int x, int y, int z, double value) {
/*  375 */     int sizeX = image.getWidth();
/*  376 */     int sizeY = image.getHeight();
/*  377 */     int sizeZ = image.getSize();
/*      */ 
/*      */     
/*  380 */     double oldValue = image.getVoxel(x, y, z);
/*      */ 
/*      */     
/*  383 */     if (oldValue == value) {
/*      */       return;
/*      */     }
/*      */     
/*  387 */     ArrayList<Cursor3D> stack = new ArrayList<Cursor3D>();
/*  388 */     stack.add(new Cursor3D(x, y, z));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  394 */     while (!stack.isEmpty()) {
/*      */ 
/*      */       
/*  397 */       Cursor3D p = stack.remove(stack.size() - 1);
/*  398 */       x = p.x;
/*  399 */       y = p.y;
/*  400 */       z = p.z;
/*      */ 
/*      */       
/*  403 */       if (image.getVoxel(x, y, z) != oldValue) {
/*      */         continue;
/*      */       }
/*      */       
/*  407 */       int x1 = x;
/*  408 */       int x2 = x;
/*      */ 
/*      */       
/*  411 */       while (x1 > 0 && image.getVoxel(x1 - 1, y, z) == oldValue) {
/*  412 */         x1--;
/*      */       }
/*      */       
/*  415 */       while (x2 < sizeX - 1 && image.getVoxel(x2 + 1, y, z) == oldValue) {
/*  416 */         x2++;
/*      */       }
/*      */       
/*  419 */       fillLineFloat(image, x1, x2, y, z, value);
/*      */ 
/*      */       
/*  422 */       if (y > 0) {
/*      */         
/*  424 */         boolean inScanLine = false;
/*  425 */         for (int i = x1; i <= x2; i++) {
/*      */           
/*  427 */           double val = image.getVoxel(i, y - 1, z);
/*  428 */           if (!inScanLine && val == oldValue) {
/*      */             
/*  430 */             stack.add(new Cursor3D(i, y - 1, z));
/*  431 */             inScanLine = true;
/*      */           }
/*  433 */           else if (inScanLine && val != oldValue) {
/*      */             
/*  435 */             inScanLine = false;
/*      */           } 
/*      */         } 
/*      */       } 
/*      */ 
/*      */       
/*  441 */       if (y < sizeY - 1) {
/*      */         
/*  443 */         boolean inScanLine = false;
/*  444 */         for (int i = x1; i <= x2; i++) {
/*      */           
/*  446 */           double val = image.getVoxel(i, y + 1, z);
/*  447 */           if (!inScanLine && val == oldValue) {
/*      */             
/*  449 */             stack.add(new Cursor3D(i, y + 1, z));
/*  450 */             inScanLine = true;
/*      */           }
/*  452 */           else if (inScanLine && val != oldValue) {
/*      */             
/*  454 */             inScanLine = false;
/*      */           } 
/*      */         } 
/*      */       } 
/*      */ 
/*      */       
/*  460 */       if (z > 0) {
/*      */         
/*  462 */         boolean inScanLine = false;
/*  463 */         for (int i = x1; i <= x2; i++) {
/*      */           
/*  465 */           double val = image.getVoxel(i, y, z - 1);
/*  466 */           if (!inScanLine && val == oldValue) {
/*      */             
/*  468 */             stack.add(new Cursor3D(i, y, z - 1));
/*  469 */             inScanLine = true;
/*      */           }
/*  471 */           else if (inScanLine && val != oldValue) {
/*      */             
/*  473 */             inScanLine = false;
/*      */           } 
/*      */         } 
/*      */       } 
/*      */ 
/*      */       
/*  479 */       if (z < sizeZ - 1) {
/*      */         
/*  481 */         boolean inScanLine = false;
/*  482 */         for (int i = x1; i <= x2; i++) {
/*      */           
/*  484 */           double val = image.getVoxel(i, y, z + 1);
/*  485 */           if (!inScanLine && val == oldValue) {
/*      */             
/*  487 */             stack.add(new Cursor3D(i, y, z + 1));
/*  488 */             inScanLine = true;
/*      */           }
/*  490 */           else if (inScanLine && val != oldValue) {
/*      */             
/*  492 */             inScanLine = false;
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final void floodFillC26(ImageStack image, int x, int y, int z, double value) {
/*  519 */     int sizeX = image.getWidth();
/*  520 */     int sizeY = image.getHeight();
/*  521 */     int sizeZ = image.getSize();
/*      */ 
/*      */     
/*  524 */     double oldValue = image.getVoxel(x, y, z);
/*      */ 
/*      */     
/*  527 */     if (oldValue == value) {
/*      */       return;
/*      */     }
/*      */     
/*  531 */     ArrayList<Cursor3D> stack = new ArrayList<Cursor3D>();
/*  532 */     stack.add(new Cursor3D(x, y, z));
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  537 */     while (!stack.isEmpty()) {
/*      */ 
/*      */       
/*  540 */       Cursor3D p = stack.remove(stack.size() - 1);
/*  541 */       x = p.x;
/*  542 */       y = p.y;
/*  543 */       z = p.z;
/*      */ 
/*      */       
/*  546 */       if (image.getVoxel(x, y, z) != oldValue) {
/*      */         continue;
/*      */       }
/*      */       
/*  550 */       int x1 = x;
/*  551 */       int x2 = x;
/*      */ 
/*      */       
/*  554 */       while (x1 > 0 && image.getVoxel(x1 - 1, y, z) == oldValue) {
/*  555 */         x1--;
/*      */       }
/*      */       
/*  558 */       while (x2 < sizeX - 1 && image.getVoxel(x2 + 1, y, z) == oldValue) {
/*  559 */         x2++;
/*      */       }
/*      */       
/*  562 */       fillLineFloat(image, x1, x2, y, z, value);
/*      */ 
/*      */       
/*  565 */       for (int z2 = Math.max(z - 1, 0); z2 <= Math.min(z + 1, sizeZ - 1); z2++) {
/*      */         
/*  567 */         for (int y2 = Math.max(y - 1, 0); y2 <= Math.min(y + 1, sizeY - 1); y2++) {
/*      */ 
/*      */           
/*  570 */           if (y2 != z || y2 != y) {
/*      */ 
/*      */             
/*  573 */             boolean inScanLine = false;
/*  574 */             for (int i = Math.max(x1 - 1, 0); i <= Math.min(x2 + 1, sizeX - 1); i++) {
/*      */               
/*  576 */               double val = image.getVoxel(i, y2, z2);
/*  577 */               if (!inScanLine && val == oldValue) {
/*      */                 
/*  579 */                 stack.add(new Cursor3D(i, y2, z2));
/*  580 */                 inScanLine = true;
/*      */               }
/*  582 */               else if (inScanLine && val != oldValue) {
/*      */                 
/*  584 */                 inScanLine = false;
/*      */               } 
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final void floodFill(ImageStack inputImage, int x, int y, int z, ImageStack outputImage, int value, int conn) {
/*  619 */     switch (conn) {
/*      */       
/*      */       case 6:
/*  622 */         floodFillC6(inputImage, x, y, z, outputImage, value);
/*      */         return;
/*      */       case 26:
/*  625 */         floodFillC26(inputImage, x, y, z, outputImage, value);
/*      */         return;
/*      */     } 
/*  628 */     throw new IllegalArgumentException(
/*  629 */         "Connectivity must be either 6 or 26, not " + conn);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final void floodFillC6(ImageStack inputImage, int x, int y, int z, ImageStack outputImage, int value) {
/*  656 */     int sizeX = inputImage.getWidth();
/*  657 */     int sizeY = inputImage.getHeight();
/*  658 */     int sizeZ = inputImage.getSize();
/*      */ 
/*      */     
/*  661 */     int oldValue = (int)inputImage.getVoxel(x, y, z);
/*      */ 
/*      */     
/*  664 */     ArrayList<Cursor3D> stack = new ArrayList<Cursor3D>();
/*  665 */     stack.add(new Cursor3D(x, y, z));
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  670 */     while (!stack.isEmpty()) {
/*      */ 
/*      */       
/*  673 */       Cursor3D p = stack.remove(stack.size() - 1);
/*  674 */       x = p.x;
/*  675 */       y = p.y;
/*  676 */       z = p.z;
/*      */ 
/*      */       
/*  679 */       if ((int)inputImage.getVoxel(x, y, z) != oldValue) {
/*      */         continue;
/*      */       }
/*      */       
/*  683 */       int x1 = x;
/*  684 */       int x2 = x;
/*      */ 
/*      */       
/*  687 */       while (x1 > 0 && (int)inputImage.getVoxel(x1 - 1, y, z) == oldValue) {
/*  688 */         x1--;
/*      */       }
/*      */       
/*  691 */       while (x2 < sizeX - 1 && (int)inputImage.getVoxel(x2 + 1, y, z) == oldValue) {
/*  692 */         x2++;
/*      */       }
/*      */       
/*  695 */       fillLineInt(outputImage, x1, x2, y, z, value);
/*      */ 
/*      */       
/*  698 */       int x1l = Math.max(x1, 0);
/*  699 */       int x2l = Math.min(x2, sizeX - 1);
/*      */ 
/*      */       
/*  702 */       if (y > 0) {
/*      */         
/*  704 */         boolean inScanLine = false;
/*  705 */         for (int i = x1l; i <= x2l; i++) {
/*      */           
/*  707 */           int val = (int)inputImage.getVoxel(i, y - 1, z);
/*  708 */           int lab = (int)outputImage.getVoxel(i, y - 1, z);
/*      */           
/*  710 */           if (!inScanLine && val == oldValue && lab != value) {
/*      */             
/*  712 */             stack.add(new Cursor3D(i, y - 1, z));
/*  713 */             inScanLine = true;
/*      */           }
/*  715 */           else if (inScanLine && val != oldValue) {
/*      */             
/*  717 */             inScanLine = false;
/*      */           } 
/*      */         } 
/*      */       } 
/*      */ 
/*      */       
/*  723 */       if (y < sizeY - 1) {
/*      */         
/*  725 */         boolean inScanLine = false;
/*  726 */         for (int i = x1l; i <= x2l; i++) {
/*      */           
/*  728 */           int val = (int)inputImage.getVoxel(i, y + 1, z);
/*  729 */           int lab = (int)outputImage.getVoxel(i, y + 1, z);
/*      */           
/*  731 */           if (!inScanLine && val == oldValue && lab != value) {
/*      */             
/*  733 */             stack.add(new Cursor3D(i, y + 1, z));
/*  734 */             inScanLine = true;
/*      */           }
/*  736 */           else if (inScanLine && val != oldValue) {
/*      */             
/*  738 */             inScanLine = false;
/*      */           } 
/*      */         } 
/*      */       } 
/*      */ 
/*      */       
/*  744 */       if (z > 0) {
/*      */         
/*  746 */         boolean inScanLine = false;
/*  747 */         for (int i = x1l; i <= x2l; i++) {
/*      */           
/*  749 */           int val = (int)inputImage.getVoxel(i, y, z - 1);
/*  750 */           int lab = (int)outputImage.getVoxel(i, y, z - 1);
/*      */           
/*  752 */           if (!inScanLine && val == oldValue && lab != value) {
/*      */             
/*  754 */             stack.add(new Cursor3D(i, y, z - 1));
/*  755 */             inScanLine = true;
/*      */           }
/*  757 */           else if (inScanLine && val != oldValue) {
/*      */             
/*  759 */             inScanLine = false;
/*      */           } 
/*      */         } 
/*      */       } 
/*      */ 
/*      */       
/*  765 */       if (z < sizeZ - 1) {
/*      */         
/*  767 */         boolean inScanLine = false;
/*  768 */         for (int i = x1l; i <= x2l; i++) {
/*      */           
/*  770 */           int val = (int)inputImage.getVoxel(i, y, z + 1);
/*  771 */           int lab = (int)outputImage.getVoxel(i, y, z + 1);
/*      */           
/*  773 */           if (!inScanLine && val == oldValue && lab != value) {
/*      */             
/*  775 */             stack.add(new Cursor3D(i, y, z + 1));
/*  776 */             inScanLine = true;
/*      */           }
/*  778 */           else if (inScanLine && val != oldValue) {
/*      */             
/*  780 */             inScanLine = false;
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final void floodFillC26(ImageStack inputImage, int x, int y, int z, ImageStack outputImage, int value) {
/*  811 */     int sizeX = inputImage.getWidth();
/*  812 */     int sizeY = inputImage.getHeight();
/*  813 */     int sizeZ = inputImage.getSize();
/*      */ 
/*      */     
/*  816 */     int oldValue = (int)inputImage.getVoxel(x, y, z);
/*      */ 
/*      */     
/*  819 */     ArrayList<Cursor3D> stack = new ArrayList<Cursor3D>();
/*  820 */     stack.add(new Cursor3D(x, y, z));
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  825 */     while (!stack.isEmpty()) {
/*      */ 
/*      */       
/*  828 */       Cursor3D p = stack.remove(stack.size() - 1);
/*  829 */       x = p.x;
/*  830 */       y = p.y;
/*  831 */       z = p.z;
/*      */ 
/*      */       
/*  834 */       if ((int)inputImage.getVoxel(x, y, z) != oldValue) {
/*      */         continue;
/*      */       }
/*      */       
/*  838 */       int x1 = x;
/*  839 */       int x2 = x;
/*      */ 
/*      */       
/*  842 */       while (x1 > 0 && (int)inputImage.getVoxel(x1 - 1, y, z) == oldValue) {
/*  843 */         x1--;
/*      */       }
/*      */       
/*  846 */       while (x2 < sizeX - 1 && (int)inputImage.getVoxel(x2 + 1, y, z) == oldValue) {
/*  847 */         x2++;
/*      */       }
/*      */       
/*  850 */       fillLineInt(outputImage, x1, x2, y, z, value);
/*      */ 
/*      */       
/*  853 */       int x1l = Math.max(x1 - 1, 0);
/*  854 */       int x2l = Math.min(x2 + 1, sizeX - 1);
/*      */ 
/*      */       
/*  857 */       for (int z2 = Math.max(z - 1, 0); z2 <= Math.min(z + 1, sizeZ - 1); z2++) {
/*      */         
/*  859 */         for (int y2 = Math.max(y - 1, 0); y2 <= Math.min(y + 1, sizeY - 1); y2++) {
/*      */ 
/*      */           
/*  862 */           if (z2 != z || y2 != y) {
/*      */ 
/*      */             
/*  865 */             boolean inScanLine = false;
/*  866 */             for (int i = x1l; i <= x2l; i++) {
/*      */               
/*  868 */               int val = (int)inputImage.getVoxel(i, y2, z2);
/*  869 */               int lab = (int)outputImage.getVoxel(i, y2, z2);
/*      */               
/*  871 */               if (!inScanLine && val == oldValue && lab != value) {
/*      */                 
/*  873 */                 stack.add(new Cursor3D(i, y2, z2));
/*  874 */                 inScanLine = true;
/*      */               }
/*  876 */               else if (inScanLine && val != oldValue) {
/*      */                 
/*  878 */                 inScanLine = false;
/*      */               } 
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final void floodFillFloat(ImageStack inputImage, int x, int y, int z, ImageStack outputImage, float value, int conn) {
/*  911 */     switch (conn) {
/*      */       
/*      */       case 6:
/*  914 */         floodFillFloatC6(inputImage, x, y, z, outputImage, value);
/*      */         return;
/*      */       case 26:
/*  917 */         floodFillFloatC26(inputImage, x, y, z, outputImage, value);
/*      */         return;
/*      */     } 
/*  920 */     throw new IllegalArgumentException(
/*  921 */         "Connectivity must be either 6 or 26, not " + conn);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final void floodFillFloat(Image3D inputImage, int x, int y, int z, Image3D outputImage, float value, int conn) {
/*  949 */     switch (conn) {
/*      */       
/*      */       case 6:
/*  952 */         floodFillFloatC6(inputImage, x, y, z, outputImage, value);
/*      */         return;
/*      */       case 26:
/*  955 */         floodFillFloatC26(inputImage, x, y, z, outputImage, value);
/*      */         return;
/*      */     } 
/*  958 */     throw new IllegalArgumentException(
/*  959 */         "Connectivity must be either 6 or 26, not " + conn);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final void floodFillFloatC6(ImageStack inputImage, int x, int y, int z, ImageStack outputImage, float value) {
/*  985 */     int sizeX = inputImage.getWidth();
/*  986 */     int sizeY = inputImage.getHeight();
/*  987 */     int sizeZ = inputImage.getSize();
/*      */ 
/*      */     
/*  990 */     double oldValue = inputImage.getVoxel(x, y, z);
/*      */ 
/*      */     
/*  993 */     ArrayList<Cursor3D> stack = new ArrayList<Cursor3D>();
/*  994 */     stack.add(new Cursor3D(x, y, z));
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  999 */     while (!stack.isEmpty()) {
/*      */ 
/*      */       
/* 1002 */       Cursor3D p = stack.remove(stack.size() - 1);
/* 1003 */       x = p.x;
/* 1004 */       y = p.y;
/* 1005 */       z = p.z;
/*      */ 
/*      */       
/* 1008 */       if (inputImage.getVoxel(x, y, z) != oldValue) {
/*      */         continue;
/*      */       }
/*      */       
/* 1012 */       int x1 = x;
/* 1013 */       int x2 = x;
/*      */ 
/*      */       
/* 1016 */       while (x1 > 0 && inputImage.getVoxel(x1 - 1, y, z) == oldValue) {
/* 1017 */         x1--;
/*      */       }
/*      */       
/* 1020 */       while (x2 < sizeX - 1 && inputImage.getVoxel(x2 + 1, y, z) == oldValue) {
/* 1021 */         x2++;
/*      */       }
/*      */       
/* 1024 */       fillLineFloat(outputImage, x1, x2, y, z, value);
/*      */ 
/*      */       
/* 1027 */       int x1l = Math.max(x1, 0);
/* 1028 */       int x2l = Math.min(x2, sizeX - 1);
/*      */ 
/*      */       
/* 1031 */       if (y > 0) {
/*      */         
/* 1033 */         boolean inScanLine = false;
/* 1034 */         for (int i = x1l; i <= x2l; i++) {
/*      */           
/* 1036 */           double val = inputImage.getVoxel(i, y - 1, z);
/* 1037 */           double lab = outputImage.getVoxel(i, y - 1, z);
/*      */           
/* 1039 */           if (!inScanLine && val == oldValue && lab != value) {
/*      */             
/* 1041 */             stack.add(new Cursor3D(i, y - 1, z));
/* 1042 */             inScanLine = true;
/*      */           }
/* 1044 */           else if (inScanLine && val != oldValue) {
/*      */             
/* 1046 */             inScanLine = false;
/*      */           } 
/*      */         } 
/*      */       } 
/*      */ 
/*      */       
/* 1052 */       if (y < sizeY - 1) {
/*      */         
/* 1054 */         boolean inScanLine = false;
/* 1055 */         for (int i = x1l; i <= x2l; i++) {
/*      */           
/* 1057 */           double val = inputImage.getVoxel(i, y + 1, z);
/* 1058 */           double lab = outputImage.getVoxel(i, y + 1, z);
/*      */           
/* 1060 */           if (!inScanLine && val == oldValue && lab != value) {
/*      */             
/* 1062 */             stack.add(new Cursor3D(i, y + 1, z));
/* 1063 */             inScanLine = true;
/*      */           }
/* 1065 */           else if (inScanLine && val != oldValue) {
/*      */             
/* 1067 */             inScanLine = false;
/*      */           } 
/*      */         } 
/*      */       } 
/*      */ 
/*      */       
/* 1073 */       if (z > 0) {
/*      */         
/* 1075 */         boolean inScanLine = false;
/* 1076 */         for (int i = x1l; i <= x2l; i++) {
/*      */           
/* 1078 */           double val = inputImage.getVoxel(i, y, z - 1);
/* 1079 */           double lab = outputImage.getVoxel(i, y, z - 1);
/*      */           
/* 1081 */           if (!inScanLine && val == oldValue && lab != value) {
/*      */             
/* 1083 */             stack.add(new Cursor3D(i, y, z - 1));
/* 1084 */             inScanLine = true;
/*      */           }
/* 1086 */           else if (inScanLine && val != oldValue) {
/*      */             
/* 1088 */             inScanLine = false;
/*      */           } 
/*      */         } 
/*      */       } 
/*      */ 
/*      */       
/* 1094 */       if (z < sizeZ - 1) {
/*      */         
/* 1096 */         boolean inScanLine = false;
/* 1097 */         for (int i = x1l; i <= x2l; i++) {
/*      */           
/* 1099 */           double val = inputImage.getVoxel(i, y, z + 1);
/* 1100 */           double lab = outputImage.getVoxel(i, y, z + 1);
/*      */           
/* 1102 */           if (!inScanLine && val == oldValue && lab != value) {
/*      */             
/* 1104 */             stack.add(new Cursor3D(i, y, z + 1));
/* 1105 */             inScanLine = true;
/*      */           }
/* 1107 */           else if (inScanLine && val != oldValue) {
/*      */             
/* 1109 */             inScanLine = false;
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final void floodFillFloatC6(Image3D inputImage, int x, int y, int z, Image3D outputImage, float value) {
/* 1138 */     int sizeX = inputImage.getSize(0);
/* 1139 */     int sizeY = inputImage.getSize(1);
/* 1140 */     int sizeZ = inputImage.getSize(2);
/*      */ 
/*      */     
/* 1143 */     double oldValue = inputImage.getValue(x, y, z);
/*      */ 
/*      */     
/* 1146 */     ArrayList<Cursor3D> stack = new ArrayList<Cursor3D>();
/* 1147 */     stack.add(new Cursor3D(x, y, z));
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1152 */     while (!stack.isEmpty()) {
/*      */ 
/*      */       
/* 1155 */       Cursor3D p = stack.remove(stack.size() - 1);
/* 1156 */       x = p.x;
/* 1157 */       y = p.y;
/* 1158 */       z = p.z;
/*      */ 
/*      */       
/* 1161 */       if (inputImage.getValue(x, y, z) != oldValue) {
/*      */         continue;
/*      */       }
/*      */       
/* 1165 */       int x1 = x;
/* 1166 */       int x2 = x;
/*      */ 
/*      */       
/* 1169 */       while (x1 > 0 && inputImage.getValue(x1 - 1, y, z) == oldValue) {
/* 1170 */         x1--;
/*      */       }
/*      */       
/* 1173 */       while (x2 < sizeX - 1 && inputImage.getValue(x2 + 1, y, z) == oldValue) {
/* 1174 */         x2++;
/*      */       }
/*      */       
/* 1177 */       fillLineFloat(outputImage, x1, x2, y, z, value);
/*      */ 
/*      */       
/* 1180 */       int x1l = Math.max(x1, 0);
/* 1181 */       int x2l = Math.min(x2, sizeX - 1);
/*      */ 
/*      */       
/* 1184 */       if (y > 0) {
/*      */         
/* 1186 */         boolean inScanLine = false;
/* 1187 */         for (int i = x1l; i <= x2l; i++) {
/*      */           
/* 1189 */           double val = inputImage.getValue(i, y - 1, z);
/* 1190 */           double lab = outputImage.getValue(i, y - 1, z);
/*      */           
/* 1192 */           if (!inScanLine && val == oldValue && lab != value) {
/*      */             
/* 1194 */             stack.add(new Cursor3D(i, y - 1, z));
/* 1195 */             inScanLine = true;
/*      */           }
/* 1197 */           else if (inScanLine && val != oldValue) {
/*      */             
/* 1199 */             inScanLine = false;
/*      */           } 
/*      */         } 
/*      */       } 
/*      */ 
/*      */       
/* 1205 */       if (y < sizeY - 1) {
/*      */         
/* 1207 */         boolean inScanLine = false;
/* 1208 */         for (int i = x1l; i <= x2l; i++) {
/*      */           
/* 1210 */           double val = inputImage.getValue(i, y + 1, z);
/* 1211 */           double lab = outputImage.getValue(i, y + 1, z);
/*      */           
/* 1213 */           if (!inScanLine && val == oldValue && lab != value) {
/*      */             
/* 1215 */             stack.add(new Cursor3D(i, y + 1, z));
/* 1216 */             inScanLine = true;
/*      */           }
/* 1218 */           else if (inScanLine && val != oldValue) {
/*      */             
/* 1220 */             inScanLine = false;
/*      */           } 
/*      */         } 
/*      */       } 
/*      */ 
/*      */       
/* 1226 */       if (z > 0) {
/*      */         
/* 1228 */         boolean inScanLine = false;
/* 1229 */         for (int i = x1l; i <= x2l; i++) {
/*      */           
/* 1231 */           double val = inputImage.getValue(i, y, z - 1);
/* 1232 */           double lab = outputImage.getValue(i, y, z - 1);
/*      */           
/* 1234 */           if (!inScanLine && val == oldValue && lab != value) {
/*      */             
/* 1236 */             stack.add(new Cursor3D(i, y, z - 1));
/* 1237 */             inScanLine = true;
/*      */           }
/* 1239 */           else if (inScanLine && val != oldValue) {
/*      */             
/* 1241 */             inScanLine = false;
/*      */           } 
/*      */         } 
/*      */       } 
/*      */ 
/*      */       
/* 1247 */       if (z < sizeZ - 1) {
/*      */         
/* 1249 */         boolean inScanLine = false;
/* 1250 */         for (int i = x1l; i <= x2l; i++) {
/*      */           
/* 1252 */           double val = inputImage.getValue(i, y, z + 1);
/* 1253 */           double lab = outputImage.getValue(i, y, z + 1);
/*      */           
/* 1255 */           if (!inScanLine && val == oldValue && lab != value) {
/*      */             
/* 1257 */             stack.add(new Cursor3D(i, y, z + 1));
/* 1258 */             inScanLine = true;
/*      */           }
/* 1260 */           else if (inScanLine && val != oldValue) {
/*      */             
/* 1262 */             inScanLine = false;
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final void floodFillFloatC26(ImageStack inputImage, int x, int y, int z, ImageStack outputImage, float value) {
/* 1292 */     int sizeX = inputImage.getWidth();
/* 1293 */     int sizeY = inputImage.getHeight();
/* 1294 */     int sizeZ = inputImage.getSize();
/*      */ 
/*      */     
/* 1297 */     double oldValue = inputImage.getVoxel(x, y, z);
/*      */ 
/*      */     
/* 1300 */     ArrayList<Cursor3D> stack = new ArrayList<Cursor3D>();
/* 1301 */     stack.add(new Cursor3D(x, y, z));
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1306 */     while (!stack.isEmpty()) {
/*      */ 
/*      */       
/* 1309 */       Cursor3D p = stack.remove(stack.size() - 1);
/* 1310 */       x = p.x;
/* 1311 */       y = p.y;
/* 1312 */       z = p.z;
/*      */ 
/*      */       
/* 1315 */       if (inputImage.getVoxel(x, y, z) != oldValue) {
/*      */         continue;
/*      */       }
/*      */       
/* 1319 */       int x1 = x;
/* 1320 */       int x2 = x;
/*      */ 
/*      */       
/* 1323 */       while (x1 > 0 && inputImage.getVoxel(x1 - 1, y, z) == oldValue) {
/* 1324 */         x1--;
/*      */       }
/*      */       
/* 1327 */       while (x2 < sizeX - 1 && inputImage.getVoxel(x2 + 1, y, z) == oldValue) {
/* 1328 */         x2++;
/*      */       }
/*      */       
/* 1331 */       fillLineFloat(outputImage, x1, x2, y, z, value);
/*      */ 
/*      */       
/* 1334 */       int x1l = Math.max(x1 - 1, 0);
/* 1335 */       int x2l = Math.min(x2 + 1, sizeX - 1);
/*      */ 
/*      */       
/* 1338 */       for (int z2 = Math.max(z - 1, 0); z2 <= Math.min(z + 1, sizeZ - 1); z2++) {
/*      */         
/* 1340 */         for (int y2 = Math.max(y - 1, 0); y2 <= Math.min(y + 1, sizeY - 1); y2++) {
/*      */ 
/*      */           
/* 1343 */           if (z2 != z || y2 != y) {
/*      */ 
/*      */             
/* 1346 */             boolean inScanLine = false;
/* 1347 */             for (int i = x1l; i <= x2l; i++) {
/*      */               
/* 1349 */               double val = inputImage.getVoxel(i, y2, z2);
/* 1350 */               double lab = outputImage.getVoxel(i, y2, z2);
/*      */               
/* 1352 */               if (!inScanLine && val == oldValue && lab != value) {
/*      */                 
/* 1354 */                 stack.add(new Cursor3D(i, y2, z2));
/* 1355 */                 inScanLine = true;
/*      */               }
/* 1357 */               else if (inScanLine && val != oldValue) {
/*      */                 
/* 1359 */                 inScanLine = false;
/*      */               } 
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final void floodFillFloatC26(Image3D inputImage, int x, int y, int z, Image3D outputImage, float value) {
/* 1391 */     int sizeX = inputImage.getSize(0);
/* 1392 */     int sizeY = inputImage.getSize(1);
/* 1393 */     int sizeZ = inputImage.getSize(2);
/*      */ 
/*      */     
/* 1396 */     double oldValue = inputImage.getValue(x, y, z);
/*      */ 
/*      */     
/* 1399 */     ArrayList<Cursor3D> stack = new ArrayList<Cursor3D>();
/* 1400 */     stack.add(new Cursor3D(x, y, z));
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1405 */     while (!stack.isEmpty()) {
/*      */ 
/*      */       
/* 1408 */       Cursor3D p = stack.remove(stack.size() - 1);
/* 1409 */       x = p.x;
/* 1410 */       y = p.y;
/* 1411 */       z = p.z;
/*      */ 
/*      */       
/* 1414 */       if (inputImage.getValue(x, y, z) != oldValue) {
/*      */         continue;
/*      */       }
/*      */       
/* 1418 */       int x1 = x;
/* 1419 */       int x2 = x;
/*      */ 
/*      */       
/* 1422 */       while (x1 > 0 && inputImage.getValue(x1 - 1, y, z) == oldValue) {
/* 1423 */         x1--;
/*      */       }
/*      */       
/* 1426 */       while (x2 < sizeX - 1 && inputImage.getValue(x2 + 1, y, z) == oldValue) {
/* 1427 */         x2++;
/*      */       }
/*      */       
/* 1430 */       fillLineFloat(outputImage, x1, x2, y, z, value);
/*      */ 
/*      */       
/* 1433 */       int x1l = Math.max(x1 - 1, 0);
/* 1434 */       int x2l = Math.min(x2 + 1, sizeX - 1);
/*      */ 
/*      */       
/* 1437 */       for (int z2 = Math.max(z - 1, 0); z2 <= Math.min(z + 1, sizeZ - 1); z2++) {
/*      */         
/* 1439 */         for (int y2 = Math.max(y - 1, 0); y2 <= Math.min(y + 1, sizeY - 1); y2++) {
/*      */ 
/*      */           
/* 1442 */           if (z2 != z || y2 != y) {
/*      */ 
/*      */             
/* 1445 */             boolean inScanLine = false;
/* 1446 */             for (int i = x1l; i <= x2l; i++) {
/*      */               
/* 1448 */               double val = inputImage.getValue(i, y2, z2);
/* 1449 */               double lab = outputImage.getValue(i, y2, z2);
/*      */               
/* 1451 */               if (!inScanLine && val == oldValue && lab != value) {
/*      */                 
/* 1453 */                 stack.add(new Cursor3D(i, y2, z2));
/* 1454 */                 inScanLine = true;
/*      */               }
/* 1456 */               else if (inScanLine && val != oldValue) {
/*      */                 
/* 1458 */                 inScanLine = false;
/*      */               } 
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final void fillLineFloat(ImageStack image, int x1, int x2, int y, int z, double value) {
/* 1475 */     for (int x = x1; x <= x2; x++) {
/* 1476 */       image.setVoxel(x, y, z, value);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final void fillLineInt(ImageStack ip, int x1, int x2, int y, int z, int value) {
/* 1488 */     for (int x = x1; x <= x2; x++) {
/* 1489 */       ip.setVoxel(x, y, z, value);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final void fillLineFloat(Image3D image, int x1, int x2, int y, int z, double value) {
/* 1500 */     for (int x = x1; x <= x2; x++) {
/* 1501 */       image.setValue(x, y, z, value);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private static class Cursor3D
/*      */   {
/*      */     int x;
/*      */     
/*      */     int y;
/*      */     
/*      */     int z;
/*      */ 
/*      */     
/*      */     public Cursor3D(int x, int y, int z) {
/* 1516 */       this.x = x;
/* 1517 */       this.y = y;
/* 1518 */       this.z = z;
/*      */     }
/*      */   }
/*      */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/morphology/FloodFill3D.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */