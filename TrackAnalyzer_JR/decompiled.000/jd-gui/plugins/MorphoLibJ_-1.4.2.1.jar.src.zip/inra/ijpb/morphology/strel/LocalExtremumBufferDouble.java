/*     */ package inra.ijpb.morphology.strel;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LocalExtremumBufferDouble
/*     */   implements LocalExtremum
/*     */ {
/*  42 */   double maxValue = Double.NEGATIVE_INFINITY;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean updateNeeded = false;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int sign;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   double[] buffer;
/*     */ 
/*     */ 
/*     */   
/*  61 */   int bufferIndex = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LocalExtremumBufferDouble(int n) {
/*  71 */     this.buffer = new double[n];
/*  72 */     for (int i = 0; i < n; i++) {
/*  73 */       this.buffer[i] = 0.0D;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LocalExtremumBufferDouble(int n, LocalExtremum.Type type) {
/*  86 */     this(n);
/*  87 */     switch (type) {
/*     */       case MINIMUM:
/*  89 */         setMinMaxSign(-1); break;
/*  90 */       case null: setMinMaxSign(1);
/*     */         break;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LocalExtremumBufferDouble(int n, double value) {
/* 104 */     this.buffer = new double[n];
/* 105 */     for (int i = 0; i < n; i++)
/* 106 */       this.buffer[i] = value; 
/* 107 */     this.maxValue = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMinMaxSign(int sign) {
/* 118 */     this.sign = sign;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void add(double value) {
/* 130 */     addValue(value);
/* 131 */     removeValue(this.buffer[this.bufferIndex]);
/*     */ 
/*     */     
/* 134 */     this.buffer[this.bufferIndex] = value;
/* 135 */     this.bufferIndex = ++this.bufferIndex % this.buffer.length;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void addValue(double value) {
/* 147 */     if (value * this.sign > this.maxValue * this.sign)
/*     */     {
/* 149 */       this.maxValue = value;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void removeValue(double value) {
/* 162 */     if (value == this.maxValue)
/*     */     {
/* 164 */       this.updateNeeded = true;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private void updateMaxValue() {
/* 170 */     if (this.sign == 1) {
/*     */ 
/*     */       
/* 173 */       this.maxValue = Double.NEGATIVE_INFINITY;
/* 174 */       for (int i = 0; i < this.buffer.length; i++)
/*     */       {
/* 176 */         this.maxValue = Math.max(this.maxValue, this.buffer[i]);
/*     */       
/*     */       }
/*     */     }
/*     */     else {
/*     */       
/* 182 */       this.maxValue = Double.POSITIVE_INFINITY;
/* 183 */       for (int i = 0; i < this.buffer.length; i++)
/*     */       {
/* 185 */         this.maxValue = Math.min(this.maxValue, this.buffer[i]);
/*     */       }
/*     */     } 
/*     */     
/* 189 */     this.updateNeeded = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void clear() {
/* 198 */     if (this.sign == 1) {
/* 199 */       fill(Double.NEGATIVE_INFINITY);
/*     */     } else {
/* 201 */       fill(Double.POSITIVE_INFINITY);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void fill(double value) {
/* 214 */     int n = this.buffer.length;
/*     */ 
/*     */     
/* 217 */     for (int i = 0; i < n; i++) {
/* 218 */       this.buffer[i] = value;
/*     */     }
/*     */     
/* 221 */     this.maxValue = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getMax() {
/* 230 */     if (this.updateNeeded)
/*     */     {
/* 232 */       updateMaxValue();
/*     */     }
/*     */     
/* 235 */     return this.maxValue;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/morphology/strel/LocalExtremumBufferDouble.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */