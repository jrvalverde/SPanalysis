/*     */ package inra.ijpb.morphology.attrfilt;
/*     */ 
/*     */ import ij.process.ImageProcessor;
/*     */ import inra.ijpb.algo.AlgoStub;
/*     */ import inra.ijpb.morphology.FloodFill;
/*     */ import inra.ijpb.morphology.MinimaAndMaxima;
/*     */ import java.awt.Point;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Comparator;
/*     */ import java.util.PriorityQueue;
/*     */ import java.util.Queue;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AreaOpeningQueue
/*     */   extends AlgoStub
/*     */   implements AreaOpening
/*     */ {
/*     */   int conn;
/*     */   private int[] dx;
/*     */   private int[] dy;
/*     */   
/*     */   public AreaOpeningQueue() {
/*  45 */     this.conn = 4;
/*     */ 
/*     */     
/*  48 */     this.dx = new int[] { 0, -1, 1 };
/*  49 */     this.dy = new int[] { -1, 1 };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setConnectivity(int connectivity) {
/*  58 */     switch (connectivity) {
/*     */       
/*     */       case 4:
/*  61 */         this.dx = new int[] { 0, -1, 1 };
/*  62 */         this.dy = new int[] { -1, 1 };
/*     */         break;
/*     */       
/*     */       case 8:
/*  66 */         this.dx = new int[] { -1, 1, -1, 1, -1, 1 };
/*  67 */         this.dy = new int[] { -1, -1, -1, 1, 1, 1 };
/*     */         break;
/*     */       
/*     */       default:
/*  71 */         throw new IllegalArgumentException("Connectivity must be either 4 or 8, not " + connectivity);
/*     */     } 
/*     */     
/*  74 */     this.conn = connectivity;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getConnectivity() {
/*  84 */     return this.conn;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ImageProcessor process(ImageProcessor image, int minArea) {
/*  94 */     int sizeX = image.getWidth();
/*  95 */     int sizeY = image.getHeight();
/*     */     
/*  97 */     fireStatusChanged(this, "Finding maxima positions...");
/*     */     
/*  99 */     Collection<Point> maximaPositions = findMaximaPositions(image);
/*     */ 
/*     */     
/* 102 */     ImageProcessor result = image.duplicate();
/*     */     
/* 104 */     fireStatusChanged(this, "Iterating over maxima...");
/* 105 */     double iter = 0.0D;
/* 106 */     double maxIter = maximaPositions.size();
/*     */ 
/*     */     
/* 109 */     for (Point pos0 : maximaPositions) {
/*     */       
/* 111 */       iter++;
/* 112 */       fireProgressChanged(this, iter, maxIter);
/*     */ 
/*     */       
/* 115 */       ArrayList<Point> positions = new ArrayList<Point>();
/*     */ 
/*     */       
/* 118 */       Queue<Point> queue = new PriorityQueue<Point>(new PositionValueComparator(result));
/* 119 */       queue.add(pos0);
/*     */ 
/*     */       
/* 122 */       int nPixels = 0;
/* 123 */       int currentLevel = image.get(pos0.x, pos0.y);
/* 124 */       while (!queue.isEmpty()) {
/*     */ 
/*     */         
/* 127 */         Point pos = queue.remove();
/*     */ 
/*     */         
/* 130 */         int neighborValue = result.get(pos.x, pos.y);
/* 131 */         if (neighborValue > currentLevel) {
/*     */           break;
/*     */         }
/*     */ 
/*     */ 
/*     */         
/* 137 */         positions.add(pos);
/* 138 */         nPixels++;
/* 139 */         currentLevel = neighborValue;
/*     */ 
/*     */         
/* 142 */         if (nPixels >= minArea) {
/*     */           break;
/*     */         }
/*     */ 
/*     */ 
/*     */         
/* 148 */         for (int iNeigh = 0; iNeigh < this.dx.length; iNeigh++) {
/*     */           
/* 150 */           int x2 = pos.x + this.dx[iNeigh];
/* 151 */           int y2 = pos.y + this.dy[iNeigh];
/* 152 */           if (x2 >= 0 && x2 < sizeX && y2 >= 0 && y2 < sizeY) {
/*     */             
/* 154 */             Point pos2 = new Point(x2, y2);
/*     */             
/* 156 */             if (!positions.contains(pos2) && !queue.contains(pos2))
/*     */             {
/* 158 */               queue.add(pos2);
/*     */             }
/*     */           } 
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 165 */       for (Point pos : positions)
/*     */       {
/* 167 */         result.set(pos.x, pos.y, currentLevel);
/*     */       }
/*     */     } 
/* 170 */     fireProgressChanged(this, 1.0D, 1.0D);
/* 171 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private Collection<Point> findMaximaPositions(ImageProcessor image) {
/* 177 */     ImageProcessor maxima = MinimaAndMaxima.regionalMaxima(image, this.conn);
/*     */     
/* 179 */     int sizeX = image.getWidth();
/* 180 */     int sizeY = image.getHeight();
/*     */     
/* 182 */     Collection<Point> positions = new ArrayList<Point>();
/*     */     
/* 184 */     for (int y = 0; y < sizeY; y++) {
/*     */       
/* 186 */       for (int x = 0; x < sizeX; x++) {
/*     */ 
/*     */ 
/*     */         
/* 190 */         if (maxima.get(x, y) > 0) {
/*     */           
/* 192 */           positions.add(new Point(x, y));
/* 193 */           FloodFill.floodFill(maxima, x, y, 0, this.conn);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 198 */     return positions;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private class PositionValueComparator
/*     */     implements Comparator<Point>
/*     */   {
/*     */     ImageProcessor image;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     PositionValueComparator(ImageProcessor image) {
/* 214 */       this.image = image;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public int compare(Point pos1, Point pos2) {
/* 220 */       int val1 = this.image.get(pos1.x, pos1.y);
/* 221 */       int val2 = this.image.get(pos2.x, pos2.y);
/* 222 */       if (val1 > val2)
/*     */       {
/* 224 */         return -1;
/*     */       }
/* 226 */       if (val2 > val1)
/*     */       {
/* 228 */         return 1;
/*     */       }
/* 230 */       return 0;
/*     */     }
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/morphology/attrfilt/AreaOpeningQueue.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */