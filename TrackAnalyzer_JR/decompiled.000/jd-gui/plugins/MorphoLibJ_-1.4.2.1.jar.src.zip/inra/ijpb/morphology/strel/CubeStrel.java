/*     */ package inra.ijpb.morphology.strel;
/*     */ 
/*     */ import inra.ijpb.morphology.Strel3D;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CubeStrel
/*     */   extends AbstractSeparableStrel3D
/*     */ {
/*     */   int size;
/*     */   int offset;
/*     */   
/*     */   public static final CubeStrel fromDiameter(int diam) {
/*  46 */     return new CubeStrel(diam);
/*     */   }
/*     */ 
/*     */   
/*     */   public static final CubeStrel fromRadius(int radius) {
/*  51 */     return new CubeStrel(2 * radius + 1, radius);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CubeStrel(int size) {
/*  77 */     if (size < 1)
/*     */     {
/*  79 */       throw new RuntimeException("Requires a positive size");
/*     */     }
/*  81 */     this.size = size;
/*     */     
/*  83 */     this.offset = (int)Math.floor(((this.size - 1) / 2));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CubeStrel(int size, int offset) {
/*  97 */     if (size < 1)
/*     */     {
/*  99 */       throw new RuntimeException("Requires a positive size");
/*     */     }
/* 101 */     this.size = size;
/*     */     
/* 103 */     if (offset < 0)
/*     */     {
/* 105 */       throw new RuntimeException("Requires a non-negative offset");
/*     */     }
/* 107 */     if (offset >= size)
/*     */     {
/* 109 */       throw new RuntimeException("Offset can not be greater than size");
/*     */     }
/* 111 */     this.offset = offset;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection<InPlaceStrel3D> decompose() {
/* 128 */     ArrayList<InPlaceStrel3D> strels = new ArrayList<InPlaceStrel3D>(3);
/* 129 */     strels.add(new LinearHorizontalStrel(this.size, this.offset));
/* 130 */     strels.add(new LinearVerticalStrel(this.size, this.offset));
/* 131 */     strels.add(new LinearDepthStrel3D(this.size, this.offset));
/* 132 */     return strels;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int[][][] getMask3D() {
/* 141 */     int[][][] mask = new int[this.size][this.size][this.size];
/* 142 */     for (int z = 0; z < this.size; z++) {
/*     */       
/* 144 */       for (int y = 0; y < this.size; y++) {
/*     */         
/* 146 */         for (int x = 0; x < this.size; x++)
/*     */         {
/* 148 */           mask[z][y][x] = 255;
/*     */         }
/*     */       } 
/*     */     } 
/* 152 */     return mask;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int[] getOffset() {
/* 161 */     return new int[] { this.offset, this.offset, this.offset };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int[][] getShifts3D() {
/* 170 */     int n = this.size * this.size * this.size;
/* 171 */     int[][] shifts = new int[n][3];
/* 172 */     int i = 0;
/*     */     
/* 174 */     for (int z = 0; z < this.size; z++) {
/*     */       
/* 176 */       for (int y = 0; y < this.size; y++) {
/*     */         
/* 178 */         for (int x = 0; x < this.size; x++) {
/*     */           
/* 180 */           shifts[i][0] = x - this.offset;
/* 181 */           shifts[i][1] = y - this.offset;
/* 182 */           shifts[i][2] = z - this.offset;
/* 183 */           i++;
/*     */         } 
/*     */       } 
/*     */     } 
/* 187 */     return shifts;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int[] getSize() {
/* 196 */     return new int[] { this.size, this.size, this.size };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CubeStrel reverse() {
/* 205 */     return new CubeStrel(this.size, this.size - this.offset - 1);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/morphology/strel/CubeStrel.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */