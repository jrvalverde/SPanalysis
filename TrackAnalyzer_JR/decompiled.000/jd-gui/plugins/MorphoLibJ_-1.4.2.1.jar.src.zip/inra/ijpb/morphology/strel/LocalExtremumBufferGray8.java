/*     */ package inra.ijpb.morphology.strel;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LocalExtremumBufferGray8
/*     */   implements LocalExtremum
/*     */ {
/*  45 */   int maxValue = Integer.MIN_VALUE;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean updateNeeded = false;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int sign;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int[] buffer;
/*     */ 
/*     */ 
/*     */   
/*  64 */   int bufferIndex = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LocalExtremumBufferGray8(int n) {
/*  74 */     this.buffer = new int[n];
/*  75 */     for (int i = 0; i < n; i++) {
/*  76 */       this.buffer[i] = 0;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LocalExtremumBufferGray8(int n, LocalExtremum.Type type) {
/*  89 */     this(n);
/*  90 */     switch (type) {
/*     */       case MINIMUM:
/*  92 */         setMinMaxSign(-1); break;
/*  93 */       case null: setMinMaxSign(1);
/*     */         break;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LocalExtremumBufferGray8(int n, int value) {
/* 107 */     this.buffer = new int[n];
/* 108 */     for (int i = 0; i < n; i++)
/* 109 */       this.buffer[i] = value; 
/* 110 */     this.maxValue = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMinMaxSign(int sign) {
/* 121 */     this.sign = sign;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void add(int value) {
/* 135 */     addValue(value);
/* 136 */     removeValue(this.buffer[this.bufferIndex]);
/*     */ 
/*     */     
/* 139 */     this.buffer[this.bufferIndex] = value;
/* 140 */     this.bufferIndex = ++this.bufferIndex % this.buffer.length;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void addValue(int value) {
/* 152 */     if (value * this.sign > this.maxValue * this.sign)
/*     */     {
/* 154 */       this.maxValue = value;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void removeValue(int value) {
/* 167 */     if (value == this.maxValue)
/*     */     {
/* 169 */       this.updateNeeded = true;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private void updateMaxValue() {
/* 175 */     if (this.sign == 1) {
/*     */ 
/*     */       
/* 178 */       this.maxValue = Integer.MIN_VALUE;
/* 179 */       for (int i = 0; i < this.buffer.length; i++)
/*     */       {
/* 181 */         this.maxValue = Math.max(this.maxValue, this.buffer[i]);
/*     */       
/*     */       }
/*     */     }
/*     */     else {
/*     */       
/* 187 */       this.maxValue = Integer.MAX_VALUE;
/* 188 */       for (int i = 0; i < this.buffer.length; i++)
/*     */       {
/* 190 */         this.maxValue = Math.min(this.maxValue, this.buffer[i]);
/*     */       }
/*     */     } 
/*     */     
/* 194 */     this.updateNeeded = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void clear() {
/* 203 */     if (this.sign == 1) {
/* 204 */       fill(-2147483648);
/*     */     } else {
/* 206 */       fill(2147483647);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void fill(int value) {
/* 219 */     int n = this.buffer.length;
/*     */ 
/*     */     
/* 222 */     for (int i = 0; i < n; i++) {
/* 223 */       this.buffer[i] = value;
/*     */     }
/*     */     
/* 226 */     this.maxValue = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMax() {
/* 235 */     if (this.updateNeeded)
/*     */     {
/* 237 */       updateMaxValue();
/*     */     }
/*     */     
/* 240 */     return this.maxValue;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/morphology/strel/LocalExtremumBufferGray8.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */