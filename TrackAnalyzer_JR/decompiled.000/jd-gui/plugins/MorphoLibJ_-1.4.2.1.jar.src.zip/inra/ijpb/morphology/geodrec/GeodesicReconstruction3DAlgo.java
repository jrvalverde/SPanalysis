package inra.ijpb.morphology.geodrec;

import ij.ImageStack;
import inra.ijpb.algo.Algo;

public interface GeodesicReconstruction3DAlgo extends Algo {
  ImageStack applyTo(ImageStack paramImageStack1, ImageStack paramImageStack2);
  
  ImageStack applyTo(ImageStack paramImageStack1, ImageStack paramImageStack2, ImageStack paramImageStack3);
  
  int getConnectivity();
  
  void setConnectivity(int paramInt);
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/morphology/geodrec/GeodesicReconstruction3DAlgo.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */