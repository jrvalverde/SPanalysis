/*     */ package inra.ijpb.morphology;
/*     */ 
/*     */ import ij.ImageStack;
/*     */ import inra.ijpb.algo.Algo;
/*     */ import inra.ijpb.algo.DefaultAlgoListener;
/*     */ import inra.ijpb.data.image.Image3D;
/*     */ import inra.ijpb.data.image.Images3D;
/*     */ import inra.ijpb.morphology.extrema.ExtremaType;
/*     */ import inra.ijpb.morphology.extrema.RegionalExtrema3DByFlooding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MinimaAndMaxima3D
/*     */ {
/*     */   private static final int DEFAULT_CONNECTIVITY = 6;
/*     */   
/*     */   public static final ImageStack regionalMaxima(ImageStack image) {
/*  80 */     return regionalMaxima(image, 6);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final ImageStack regionalMaxima(ImageStack image, int conn) {
/*  96 */     RegionalExtrema3DByFlooding regionalExtrema3DByFlooding = new RegionalExtrema3DByFlooding();
/*  97 */     regionalExtrema3DByFlooding.setConnectivity(conn);
/*  98 */     regionalExtrema3DByFlooding.setExtremaType(ExtremaType.MAXIMA);
/*  99 */     DefaultAlgoListener.monitor((Algo)regionalExtrema3DByFlooding);
/*     */     
/* 101 */     return regionalExtrema3DByFlooding.applyTo(image);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final ImageStack regionalMaximaByReconstruction(ImageStack image, int conn) {
/* 118 */     int sizeX = image.getWidth();
/* 119 */     int sizeY = image.getHeight();
/* 120 */     int sizeZ = image.getSize();
/*     */     
/* 122 */     ImageStack mask = addValue(image, 1.0D);
/*     */     
/* 124 */     ImageStack rec = Reconstruction3D.reconstructByDilation(image, mask, conn);
/* 125 */     ImageStack result = ImageStack.create(sizeX, sizeY, sizeZ, 8);
/*     */     
/* 127 */     for (int z = 0; z < sizeZ; z++) {
/*     */       
/* 129 */       for (int y = 0; y < sizeY; y++) {
/*     */         
/* 131 */         for (int x = 0; x < sizeX; x++) {
/*     */           
/* 133 */           if (mask.getVoxel(x, y, z) > rec.getVoxel(x, y, z)) {
/* 134 */             result.setVoxel(x, y, z, 255.0D);
/*     */           } else {
/* 136 */             result.setVoxel(x, y, z, 0.0D);
/*     */           } 
/*     */         } 
/*     */       } 
/* 140 */     }  return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final ImageStack regionalMaxima(ImageStack image, int conn, ImageStack mask) {
/* 160 */     RegionalExtrema3DByFlooding regionalExtrema3DByFlooding = new RegionalExtrema3DByFlooding();
/* 161 */     regionalExtrema3DByFlooding.setConnectivity(conn);
/* 162 */     regionalExtrema3DByFlooding.setExtremaType(ExtremaType.MAXIMA);
/* 163 */     DefaultAlgoListener.monitor((Algo)regionalExtrema3DByFlooding);
/*     */     
/* 165 */     return regionalExtrema3DByFlooding.applyTo(image, mask);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final ImageStack regionalMinima(ImageStack image) {
/* 178 */     return regionalMinima(image, 6);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final ImageStack regionalMinima(ImageStack image, int conn) {
/* 194 */     if (Thread.currentThread().isInterrupted()) {
/* 195 */       return null;
/*     */     }
/* 197 */     RegionalExtrema3DByFlooding regionalExtrema3DByFlooding = new RegionalExtrema3DByFlooding();
/* 198 */     regionalExtrema3DByFlooding.setConnectivity(conn);
/* 199 */     regionalExtrema3DByFlooding.setExtremaType(ExtremaType.MINIMA);
/* 200 */     DefaultAlgoListener.monitor((Algo)regionalExtrema3DByFlooding);
/*     */     
/* 202 */     return regionalExtrema3DByFlooding.applyTo(image);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final ImageStack regionalMinimaByReconstruction(ImageStack image, int conn) {
/* 218 */     int sizeX = image.getWidth();
/* 219 */     int sizeY = image.getHeight();
/* 220 */     int sizeZ = image.getSize();
/*     */     
/* 222 */     ImageStack marker = addValue(image, 1.0D);
/*     */     
/* 224 */     ImageStack rec = Reconstruction3D.reconstructByErosion(marker, 
/* 225 */         image, conn);
/*     */     
/* 227 */     ImageStack result = ImageStack.create(sizeX, sizeY, sizeZ, 8);
/* 228 */     for (int z = 0; z < sizeZ; z++) {
/*     */       
/* 230 */       for (int y = 0; y < sizeY; y++) {
/*     */         
/* 232 */         for (int x = 0; x < sizeX; x++) {
/*     */           
/* 234 */           if (marker.getVoxel(x, y, z) > rec.getVoxel(x, y, z)) {
/* 235 */             result.setVoxel(x, y, z, 0.0D);
/*     */           } else {
/* 237 */             result.setVoxel(x, y, z, 255.0D);
/*     */           } 
/*     */         } 
/*     */       } 
/* 241 */     }  return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final ImageStack regionalMinima(ImageStack image, int conn, ImageStack mask) {
/* 261 */     RegionalExtrema3DByFlooding regionalExtrema3DByFlooding = new RegionalExtrema3DByFlooding();
/* 262 */     regionalExtrema3DByFlooding.setConnectivity(conn);
/* 263 */     regionalExtrema3DByFlooding.setExtremaType(ExtremaType.MINIMA);
/* 264 */     DefaultAlgoListener.monitor((Algo)regionalExtrema3DByFlooding);
/*     */     
/* 266 */     return regionalExtrema3DByFlooding.applyTo(image, mask);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final ImageStack extendedMaxima(ImageStack image, double dynamic) {
/* 283 */     return extendedMaxima(image, dynamic, 6);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final ImageStack extendedMaxima(ImageStack image, double dynamic, int conn) {
/* 302 */     ImageStack mask = addValue(image, dynamic);
/*     */     
/* 304 */     ImageStack rec = Reconstruction3D.reconstructByDilation(image, mask, conn);
/*     */     
/* 306 */     return regionalMaxima(rec, conn);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final ImageStack extendedMaxima(ImageStack image, double dynamic, ImageStack binaryMask) {
/* 328 */     return extendedMaxima(image, dynamic, 6, binaryMask);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final ImageStack extendedMaxima(ImageStack image, double dynamic, int conn, ImageStack binaryMask) {
/* 353 */     ImageStack mask = addValue(image, dynamic);
/*     */     
/* 355 */     ImageStack rec = Reconstruction3D.reconstructByDilation(image, mask, conn, binaryMask);
/*     */     
/* 357 */     return regionalMaxima(rec, conn);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final ImageStack extendedMinima(ImageStack image, double dynamic) {
/* 373 */     return extendedMinima(image, dynamic, 6);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final ImageStack extendedMinima(ImageStack image, double dynamic, int conn) {
/* 392 */     ImageStack marker = addValue(image, dynamic);
/*     */     
/* 394 */     ImageStack rec = Reconstruction3D.reconstructByErosion(marker, image, conn);
/*     */     
/* 396 */     if (rec == null) {
/* 397 */       return null;
/*     */     }
/* 399 */     return regionalMinima(rec, conn);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final ImageStack imposeMaxima(ImageStack image, ImageStack maxima) {
/* 415 */     return imposeMaxima(image, maxima, 6);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final ImageStack imposeMaxima(ImageStack image, ImageStack maxima, int conn) {
/* 433 */     ImageStack marker = image.duplicate();
/* 434 */     ImageStack mask = image.duplicate();
/*     */     
/* 436 */     int sizeX = image.getWidth();
/* 437 */     int sizeY = image.getHeight();
/* 438 */     int sizeZ = image.getSize();
/*     */     
/* 440 */     for (int z = 0; z < sizeZ; z++) {
/*     */       
/* 442 */       for (int y = 0; y < sizeY; y++) {
/*     */         
/* 444 */         for (int x = 0; x < sizeX; x++) {
/*     */           
/* 446 */           if (maxima.getVoxel(x, y, z) > 0.0D) {
/*     */             
/* 448 */             marker.setVoxel(x, y, z, 255.0D);
/* 449 */             mask.setVoxel(x, y, z, 255.0D);
/*     */           }
/*     */           else {
/*     */             
/* 453 */             marker.setVoxel(x, y, z, 0.0D);
/* 454 */             mask.setVoxel(x, y, z, image.getVoxel(x, y, z) - 1.0D);
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 460 */     return Reconstruction3D.reconstructByDilation(marker, mask, conn);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final ImageStack imposeMinima(ImageStack image, ImageStack minima) {
/* 476 */     return imposeMinima(image, minima, 6);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final ImageStack imposeMinima(ImageStack image, ImageStack minima, int conn) {
/* 494 */     if (Thread.currentThread().isInterrupted()) {
/* 495 */       return null;
/*     */     }
/* 497 */     ImageStack marker = image.duplicate();
/* 498 */     ImageStack mask = image.duplicate();
/*     */     
/* 500 */     int sizeX = image.getWidth();
/* 501 */     int sizeY = image.getHeight();
/* 502 */     int sizeZ = image.getSize();
/*     */     
/* 504 */     for (int z = 0; z < sizeZ; z++) {
/*     */       
/* 506 */       for (int y = 0; y < sizeY; y++) {
/*     */         
/* 508 */         for (int x = 0; x < sizeX; x++) {
/*     */           
/* 510 */           if (minima.getVoxel(x, y, z) > 0.0D) {
/*     */             
/* 512 */             marker.setVoxel(x, y, z, 0.0D);
/* 513 */             mask.setVoxel(x, y, z, 0.0D);
/*     */           }
/*     */           else {
/*     */             
/* 517 */             marker.setVoxel(x, y, z, 255.0D);
/* 518 */             mask.setVoxel(x, y, z, image.getVoxel(x, y, z) + 1.0D);
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 524 */     return Reconstruction3D.reconstructByErosion(marker, mask, conn);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final ImageStack addValue(ImageStack image, double value) {
/* 538 */     int sizeX = image.getWidth();
/* 539 */     int sizeY = image.getHeight();
/* 540 */     int sizeZ = image.getSize();
/* 541 */     ImageStack result = ImageStack.create(sizeX, sizeY, sizeZ, image.getBitDepth());
/*     */     
/* 543 */     Image3D image2 = Images3D.createWrapper(image);
/* 544 */     Image3D result2 = Images3D.createWrapper(result);
/*     */     
/* 546 */     for (int z = 0; z < sizeZ; z++) {
/*     */       
/* 548 */       for (int y = 0; y < sizeY; y++) {
/*     */         
/* 550 */         for (int x = 0; x < sizeX; x++)
/*     */         {
/* 552 */           result2.setValue(x, y, z, image2.getValue(x, y, z) + value);
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 557 */     return result;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/morphology/MinimaAndMaxima3D.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */