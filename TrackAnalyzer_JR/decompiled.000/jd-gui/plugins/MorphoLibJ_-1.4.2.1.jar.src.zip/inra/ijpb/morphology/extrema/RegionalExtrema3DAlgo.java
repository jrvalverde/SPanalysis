/*     */ package inra.ijpb.morphology.extrema;
/*     */ 
/*     */ import ij.ImageStack;
/*     */ import inra.ijpb.algo.AlgoStub;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class RegionalExtrema3DAlgo
/*     */   extends AlgoStub
/*     */ {
/*  52 */   ExtremaType extremaType = ExtremaType.MINIMA;
/*     */ 
/*     */   
/*  55 */   int connectivity = 6;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean progressVisible = true;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RegionalExtrema3DAlgo() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RegionalExtrema3DAlgo(ExtremaType extremaType, int connectivity) {
/*  82 */     this.extremaType = extremaType;
/*  83 */     this.connectivity = connectivity;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ExtremaType getExtremaType() {
/*  91 */     return this.extremaType;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setExtremaType(ExtremaType extremaType) {
/*  96 */     this.extremaType = extremaType;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getConnectivity() {
/* 101 */     return this.connectivity;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setConnectivity(int conn) {
/* 106 */     this.connectivity = conn;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isProgressVisible() {
/* 111 */     return this.progressVisible;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setProgressVisible(boolean progressVisible) {
/* 116 */     this.progressVisible = progressVisible;
/*     */   }
/*     */   
/*     */   public abstract ImageStack applyTo(ImageStack paramImageStack);
/*     */   
/*     */   public abstract ImageStack applyTo(ImageStack paramImageStack1, ImageStack paramImageStack2);
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/morphology/extrema/RegionalExtrema3DAlgo.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */