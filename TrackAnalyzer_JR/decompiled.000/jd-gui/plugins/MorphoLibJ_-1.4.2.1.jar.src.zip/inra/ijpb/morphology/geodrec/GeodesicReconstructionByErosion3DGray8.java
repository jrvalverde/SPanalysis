/*      */ package inra.ijpb.morphology.geodrec;
/*      */ 
/*      */ import ij.ImageStack;
/*      */ import inra.ijpb.data.image.Images3D;
/*      */ import java.util.LinkedList;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class GeodesicReconstructionByErosion3DGray8
/*      */   extends GeodesicReconstruction3DAlgoStub
/*      */ {
/*      */   ImageStack marker;
/*      */   ImageStack mask;
/*      */   ImageStack result;
/*   47 */   int size1 = 0;
/*      */   
/*   49 */   int size2 = 0;
/*      */   
/*   51 */   int size3 = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   LinkedList<int[]> queue;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean modif;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public GeodesicReconstructionByErosion3DGray8() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public GeodesicReconstructionByErosion3DGray8(int connectivity) {
/*   79 */     this.connectivity = connectivity;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ImageStack applyTo(ImageStack marker, ImageStack mask) {
/*  182 */     this.marker = marker;
/*  183 */     this.mask = mask;
/*      */ 
/*      */     
/*  186 */     this.size1 = marker.getWidth();
/*  187 */     this.size2 = marker.getHeight();
/*  188 */     this.size3 = marker.getSize();
/*  189 */     if (!Images3D.isSameSize(marker, mask))
/*      */     {
/*  191 */       throw new IllegalArgumentException("Marker and Mask images must have the same size");
/*      */     }
/*      */ 
/*      */     
/*  195 */     if (this.connectivity != 6 && this.connectivity != 26) {
/*  196 */       throw new RuntimeException(
/*  197 */           "Connectivity for stacks must be either 6 or 26, not " + 
/*  198 */           this.connectivity);
/*      */     }
/*      */     
/*  201 */     initializeResult();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  211 */     trace("Forward iteration");
/*  212 */     showStatus("Geod. Rec. by Ero. Fwd ");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  220 */     forwardDilationC26();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  225 */     trace("Backward iteration ");
/*  226 */     showStatus("Geod. Rec. by Dil. Bwd ");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  234 */     backwardDilationC26();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  241 */     forwardDilationC26InitQueue();
/*      */ 
/*      */     
/*  244 */     processQueueC26();
/*      */ 
/*      */     
/*  247 */     showProgress(1.0D, 1.0D, "");
/*      */     
/*  249 */     return this.result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void initializeResult() {
/*  344 */     this.result = ImageStack.create(this.size1, this.size2, this.size3, this.mask.getBitDepth());
/*      */     
/*  346 */     Object[] stack = this.result.getImageArray();
/*  347 */     Object[] markerStack = this.marker.getImageArray();
/*  348 */     Object[] maskStack = this.mask.getImageArray();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  355 */     for (int z = 0; z < this.size3; z++) {
/*      */       
/*  357 */       byte[] slice = (byte[])stack[z];
/*  358 */       byte[] maskSlice = (byte[])maskStack[z];
/*  359 */       byte[] markerSlice = (byte[])markerStack[z];
/*      */       
/*  361 */       for (int y = 0; y < this.size2; y++) {
/*      */         
/*  363 */         for (int x = 0; x < this.size1; x++) {
/*      */           
/*  365 */           int index = y * this.size1 + x;
/*  366 */           int value = Math.max(markerSlice[index] & 0xFF, maskSlice[index] & 0xFF);
/*  367 */           slice[index] = (byte)value;
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void initializeResult(ImageStack binaryMask) {
/*  376 */     this.result = ImageStack.create(this.size1, this.size2, this.size3, this.mask.getBitDepth());
/*      */     
/*  378 */     Object[] stack = this.result.getImageArray();
/*  379 */     Object[] markerStack = this.marker.getImageArray();
/*  380 */     Object[] maskStack = this.mask.getImageArray();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  387 */     for (int z = 0; z < this.size3; z++) {
/*      */       
/*  389 */       byte[] slice = (byte[])stack[z];
/*  390 */       byte[] maskSlice = (byte[])maskStack[z];
/*  391 */       byte[] markerSlice = (byte[])markerStack[z];
/*      */       
/*  393 */       for (int y = 0; y < this.size2; y++) {
/*      */         
/*  395 */         for (int x = 0; x < this.size1; x++) {
/*      */           
/*  397 */           if (binaryMask.getVoxel(x, y, z) != 0.0D) {
/*      */             
/*  399 */             int index = y * this.size1 + x;
/*  400 */             int value = Math.max(markerSlice[index] & 0xFF, maskSlice[index] & 0xFF);
/*  401 */             slice[index] = (byte)value;
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void forwardDilationC26() {
/*  463 */     Object[] stack = this.result.getImageArray();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  468 */     for (int z = 0; z < this.size3; z++) {
/*      */       
/*  470 */       showProgress(z, this.size3, "z = " + z);
/*  471 */       byte[] slice = (byte[])stack[z];
/*  472 */       for (int y = 0; y < this.size2; y++) {
/*      */         
/*  474 */         for (int x = 0; x < this.size1; x++) {
/*      */           
/*  476 */           int currentValue = slice[y * this.size1 + x] & 0xFF;
/*      */           
/*  478 */           int minValue = currentValue;
/*      */ 
/*      */           
/*  481 */           int zmax = Math.min(z + 1, this.size3);
/*  482 */           for (int z2 = Math.max(z - 1, 0); z2 < zmax; z2++) {
/*      */             
/*  484 */             byte[] slice2 = (byte[])stack[z2];
/*      */             
/*  486 */             int ymax = (z2 == z) ? y : Math.min(y + 2, this.size2);
/*  487 */             for (int y2 = Math.max(y - 1, 0); y2 < ymax; y2++) {
/*      */               
/*  489 */               int xmax = (z2 == z && y2 == y) ? x : Math.min(x + 2, this.size1);
/*  490 */               for (int x2 = Math.max(x - 1, 0); x2 < xmax; x2++) {
/*      */                 
/*  492 */                 int neighborValue = slice2[y2 * this.size1 + x2] & 0xFF;
/*  493 */                 if (neighborValue < minValue) {
/*  494 */                   minValue = neighborValue;
/*      */                 }
/*      */               } 
/*      */             } 
/*      */           } 
/*      */           
/*  500 */           minValue = Math.max(minValue, (int)this.mask.getVoxel(x, y, z));
/*  501 */           if (minValue < currentValue)
/*      */           {
/*  503 */             slice[y * this.size1 + x] = (byte)(minValue & 0xFF);
/*      */           }
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void forwardDilationC26(ImageStack binaryMask) {
/*  520 */     Object[] stack = this.result.getImageArray();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  525 */     for (int z = 0; z < this.size3; z++) {
/*      */       
/*  527 */       showProgress(z, this.size3, "z = " + z);
/*  528 */       byte[] slice = (byte[])stack[z];
/*  529 */       for (int y = 0; y < this.size2; y++) {
/*      */         
/*  531 */         for (int x = 0; x < this.size1; x++) {
/*  532 */           if (binaryMask.getVoxel(x, y, z) != 0.0D) {
/*      */             
/*  534 */             int currentValue = slice[y * this.size1 + x] & 0xFF;
/*      */             
/*  536 */             int minValue = currentValue;
/*      */ 
/*      */             
/*  539 */             int zmax = Math.min(z + 1, this.size3);
/*  540 */             for (int z2 = Math.max(z - 1, 0); z2 < zmax; z2++) {
/*      */               
/*  542 */               byte[] slice2 = (byte[])stack[z2];
/*      */               
/*  544 */               int ymax = (z2 == z) ? y : Math.min(y + 2, this.size2);
/*  545 */               for (int y2 = Math.max(y - 1, 0); y2 < ymax; y2++) {
/*      */                 
/*  547 */                 int xmax = (z2 == z && y2 == y) ? x : Math.min(x + 2, this.size1);
/*  548 */                 for (int x2 = Math.max(x - 1, 0); x2 < xmax; x2++) {
/*      */                   
/*  550 */                   int neighborValue = slice2[y2 * this.size1 + x2] & 0xFF;
/*  551 */                   if (neighborValue < minValue) {
/*  552 */                     minValue = neighborValue;
/*      */                   }
/*      */                 } 
/*      */               } 
/*      */             } 
/*      */             
/*  558 */             minValue = Math.max(minValue, (int)this.mask.getVoxel(x, y, z));
/*  559 */             if (minValue < currentValue)
/*      */             {
/*  561 */               slice[y * this.size1 + x] = (byte)(minValue & 0xFF);
/*      */             }
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void forwardDilationC26InitQueue() {
/*  577 */     Object[] stack = this.result.getImageArray();
/*  578 */     Object[] maskStack = this.mask.getImageArray();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  583 */     this.queue = (LinkedList)new LinkedList<int>();
/*      */ 
/*      */     
/*  586 */     for (int z = 0; z < this.size3; z++) {
/*      */       
/*  588 */       showProgress(z, this.size3, "z = " + z);
/*  589 */       byte[] slice = (byte[])stack[z];
/*  590 */       for (int y = 0; y < this.size2; y++) {
/*      */         
/*  592 */         for (int x = 0; x < this.size1; x++) {
/*      */           
/*  594 */           int currentValue = slice[y * this.size1 + x] & 0xFF;
/*  595 */           int minValue = currentValue;
/*      */ 
/*      */           
/*  598 */           int zmax = Math.min(z + 1, this.size3); int z2;
/*  599 */           for (z2 = Math.max(z - 1, 0); z2 < zmax; z2++) {
/*      */             
/*  601 */             slice = (byte[])stack[z2];
/*      */             
/*  603 */             int ymax = (z2 == z) ? y : Math.min(y + 2, this.size2);
/*  604 */             for (int y2 = Math.max(y - 1, 0); y2 < ymax; y2++) {
/*      */               
/*  606 */               int xmax = (z2 == z && y2 == y) ? x : Math.min(x + 2, 
/*  607 */                   this.size1);
/*  608 */               for (int x2 = Math.max(x - 1, 0); x2 < xmax; x2++) {
/*      */                 
/*  610 */                 int neighborValue = slice[y2 * this.size1 + x2] & 0xFF;
/*  611 */                 if (neighborValue < minValue) {
/*  612 */                   minValue = neighborValue;
/*      */                 }
/*      */               } 
/*      */             } 
/*      */           } 
/*      */           
/*  618 */           byte[] maskSlice = (byte[])maskStack[z];
/*  619 */           minValue = Math.max(minValue, maskSlice[y * this.size1 + x] & 0xFF);
/*      */ 
/*      */           
/*  622 */           if (minValue < currentValue) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  628 */             this.result.setVoxel(x, y, z, minValue);
/*  629 */             slice[y * this.size1 + x] = (byte)(minValue & 0xFF);
/*      */ 
/*      */ 
/*      */             
/*  633 */             for (z2 = Math.max(z - 1, 0); z2 < zmax; z2++) {
/*      */               
/*  635 */               byte[] slice2 = (byte[])stack[z2];
/*  636 */               maskSlice = (byte[])maskStack[z2];
/*      */               
/*  638 */               int ymax = (z2 == z) ? y : Math.min(y + 2, this.size2);
/*  639 */               for (int y2 = Math.max(y - 1, 0); y2 < ymax; y2++) {
/*      */                 
/*  641 */                 int xmax = (z2 == z && y2 == y) ? x : Math.min(x + 2, this.size1);
/*  642 */                 for (int x2 = Math.max(x - 1, 0); x2 < xmax; x2++) {
/*      */                   
/*  644 */                   int index = y2 * this.size1 + x2;
/*  645 */                   int neighborValue = slice2[index] & 0xFF;
/*  646 */                   int maskValue = maskSlice[index] & 0xFF;
/*  647 */                   if (neighborValue > minValue && neighborValue > maskValue) {
/*      */                     
/*  649 */                     int[] pos = { x2, y2, z2 };
/*  650 */                     this.queue.addLast(pos);
/*      */                   } 
/*      */                 } 
/*      */               } 
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void forwardDilationC26InitQueue(ImageStack binaryMask) {
/*  670 */     Object[] stack = this.result.getImageArray();
/*  671 */     Object[] maskStack = this.mask.getImageArray();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  676 */     this.queue = (LinkedList)new LinkedList<int>();
/*      */ 
/*      */     
/*  679 */     for (int z = 0; z < this.size3; z++) {
/*      */       
/*  681 */       showProgress(z, this.size3, "z = " + z);
/*  682 */       byte[] slice = (byte[])stack[z];
/*  683 */       for (int y = 0; y < this.size2; y++) {
/*      */         
/*  685 */         for (int x = 0; x < this.size1; x++) {
/*      */           
/*  687 */           if (binaryMask.getVoxel(x, y, z) != 0.0D) {
/*      */             
/*  689 */             int currentValue = slice[y * this.size1 + x] & 0xFF;
/*  690 */             int minValue = currentValue;
/*      */ 
/*      */             
/*  693 */             int zmax = Math.min(z + 1, this.size3); int z2;
/*  694 */             for (z2 = Math.max(z - 1, 0); z2 < zmax; z2++) {
/*      */               
/*  696 */               slice = (byte[])stack[z2];
/*      */               
/*  698 */               int ymax = (z2 == z) ? y : Math.min(y + 2, this.size2);
/*  699 */               for (int y2 = Math.max(y - 1, 0); y2 < ymax; y2++) {
/*      */                 
/*  701 */                 int xmax = (z2 == z && y2 == y) ? x : Math.min(x + 2, this.size1);
/*  702 */                 for (int x2 = Math.max(x - 1, 0); x2 < xmax; x2++) {
/*      */                   
/*  704 */                   int neighborValue = slice[y2 * this.size1 + x2] & 0xFF;
/*  705 */                   if (neighborValue < minValue) {
/*  706 */                     minValue = neighborValue;
/*      */                   }
/*      */                 } 
/*      */               } 
/*      */             } 
/*      */             
/*  712 */             byte[] maskSlice = (byte[])maskStack[z];
/*  713 */             minValue = Math.max(minValue, maskSlice[y * this.size1 + x] & 0xFF);
/*      */ 
/*      */             
/*  716 */             if (minValue < currentValue) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*  722 */               this.result.setVoxel(x, y, z, minValue);
/*  723 */               slice[y * this.size1 + x] = (byte)(minValue & 0xFF);
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*  728 */               for (z2 = Math.max(z - 1, 0); z2 < zmax; z2++) {
/*      */                 
/*  730 */                 byte[] slice2 = (byte[])stack[z2];
/*  731 */                 maskSlice = (byte[])maskStack[z2];
/*      */                 
/*  733 */                 int ymax = (z2 == z) ? y : Math.min(y + 2, this.size2);
/*  734 */                 for (int y2 = Math.max(y - 1, 0); y2 < ymax; y2++) {
/*      */                   
/*  736 */                   int xmax = (z2 == z && y2 == y) ? x : Math.min(x + 2, this.size1);
/*  737 */                   for (int x2 = Math.max(x - 1, 0); x2 < xmax; x2++) {
/*      */                     
/*  739 */                     int index = y2 * this.size1 + x2;
/*  740 */                     int neighborValue = slice2[index] & 0xFF;
/*  741 */                     int maskValue = maskSlice[index] & 0xFF;
/*  742 */                     if (neighborValue > minValue && neighborValue > maskValue) {
/*      */                       
/*  744 */                       int[] pos = { x2, y2, z2 };
/*  745 */                       this.queue.addLast(pos);
/*      */                     } 
/*      */                   } 
/*      */                 } 
/*      */               } 
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void backwardDilationC26() {
/*  769 */     Object[] stack = this.result.getImageArray();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  774 */     for (int z = this.size3 - 1; z >= 0; z--) {
/*      */       
/*  776 */       byte[] slice = (byte[])stack[z];
/*  777 */       showProgress((this.size3 - 1 - z), this.size3);
/*  778 */       for (int y = this.size2 - 1; y >= 0; y--) {
/*      */         
/*  780 */         for (int x = this.size1 - 1; x >= 0; x--) {
/*      */           
/*  782 */           int currentValue = slice[y * this.size1 + x] & 0xFF;
/*  783 */           int minValue = currentValue;
/*      */ 
/*      */           
/*  786 */           int zmin = Math.max(z - 1, 0);
/*  787 */           for (int z2 = Math.min(z + 1, this.size3 - 1); z2 >= zmin; z2--) {
/*      */             
/*  789 */             byte[] slice2 = (byte[])stack[z2];
/*      */             
/*  791 */             int ymin = (z2 == z) ? y : Math.max(y - 1, 0);
/*  792 */             for (int y2 = Math.min(y + 1, this.size2 - 1); y2 >= ymin; y2--) {
/*      */               
/*  794 */               int xmin = (z2 == z && y2 == y) ? x : Math.max(x - 1, 0);
/*  795 */               for (int x2 = Math.min(x + 1, this.size1 - 1); x2 >= xmin; x2--) {
/*      */                 
/*  797 */                 int index = y2 * this.size1 + x2;
/*  798 */                 int neighborValue = slice2[index] & 0xFF;
/*  799 */                 if (neighborValue < minValue) {
/*  800 */                   minValue = neighborValue;
/*      */                 }
/*      */               } 
/*      */             } 
/*      */           } 
/*      */           
/*  806 */           minValue = Math.max(minValue, (int)this.mask.getVoxel(x, y, z));
/*  807 */           if (minValue < currentValue)
/*      */           {
/*  809 */             slice[y * this.size1 + x] = (byte)(minValue & 0xFF);
/*      */           }
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void backwardDilationC26(ImageStack binaryMask) {
/*  827 */     Object[] stack = this.result.getImageArray();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  832 */     for (int z = this.size3 - 1; z >= 0; z--) {
/*      */       
/*  834 */       byte[] slice = (byte[])stack[z];
/*  835 */       showProgress((this.size3 - 1 - z), this.size3);
/*  836 */       for (int y = this.size2 - 1; y >= 0; y--) {
/*      */         
/*  838 */         for (int x = this.size1 - 1; x >= 0; x--) {
/*      */           
/*  840 */           if (binaryMask.getVoxel(x, y, z) != 0.0D) {
/*      */             
/*  842 */             int currentValue = slice[y * this.size1 + x] & 0xFF;
/*  843 */             int minValue = currentValue;
/*      */ 
/*      */             
/*  846 */             int zmin = Math.max(z - 1, 0);
/*  847 */             for (int z2 = Math.min(z + 1, this.size3 - 1); z2 >= zmin; z2--) {
/*      */               
/*  849 */               byte[] slice2 = (byte[])stack[z2];
/*      */               
/*  851 */               int ymin = (z2 == z) ? y : Math.max(y - 1, 0);
/*  852 */               for (int y2 = Math.min(y + 1, this.size2 - 1); y2 >= ymin; y2--) {
/*      */                 
/*  854 */                 int xmin = (z2 == z && y2 == y) ? x : Math.max(x - 1, 0);
/*  855 */                 for (int x2 = Math.min(x + 1, this.size1 - 1); x2 >= xmin; x2--) {
/*      */                   
/*  857 */                   int index = y2 * this.size1 + x2;
/*  858 */                   int neighborValue = slice2[index] & 0xFF;
/*  859 */                   if (neighborValue < minValue) {
/*  860 */                     minValue = neighborValue;
/*      */                   }
/*      */                 } 
/*      */               } 
/*      */             } 
/*      */             
/*  866 */             minValue = Math.max(minValue, (int)this.mask.getVoxel(x, y, z));
/*  867 */             if (minValue < currentValue)
/*      */             {
/*  869 */               slice[y * this.size1 + x] = (byte)(minValue & 0xFF);
/*      */             }
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void processQueueC26() {
/*  973 */     Object[] stack = this.result.getImageArray();
/*  974 */     Object[] maskStack = this.mask.getImageArray();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  979 */     int total = this.queue.size();
/*  980 */     int iter = 1;
/*      */ 
/*      */     
/*  983 */     while (!this.queue.isEmpty()) {
/*  984 */       showProgress(iter, total);
/*  985 */       trace("iter " + iter++ + " over " + total);
/*      */       
/*  987 */       int[] p = this.queue.pollFirst();
/*  988 */       int x = p[0];
/*  989 */       int y = p[1];
/*  990 */       int z = p[2];
/*      */       
/*  992 */       byte[] slice = (byte[])stack[z];
/*  993 */       byte[] maskSlice = (byte[])maskStack[z];
/*  994 */       int index = y * this.size1 + x;
/*  995 */       int currentValue = slice[index] & 0xFF;
/*  996 */       int maskValue = maskSlice[index] & 0xFF;
/*  997 */       if (currentValue == maskValue) {
/*      */         continue;
/*      */       }
/*      */       
/* 1001 */       double minValue = currentValue; int z2;
/* 1002 */       for (z2 = Math.max(z - 1, 0); z2 < Math.min(z + 2, this.size3); z2++) {
/*      */         
/* 1004 */         byte[] slice2 = (byte[])stack[z2];
/* 1005 */         for (int y2 = Math.max(y - 1, 0); y2 < Math.min(y + 2, this.size2); y2++) {
/*      */           
/* 1007 */           for (int x2 = Math.max(x - 1, 0); x2 < Math.min(x + 2, this.size1); x2++) {
/*      */             
/* 1009 */             int value = slice2[y2 * this.size1 + x2] & 0xFF;
/* 1010 */             if (value < minValue) {
/* 1011 */               minValue = value;
/*      */             }
/*      */           } 
/*      */         } 
/*      */       } 
/*      */       
/* 1017 */       minValue = Math.max(minValue, maskValue);
/* 1018 */       if (minValue >= currentValue) {
/*      */         continue;
/*      */       }
/*      */ 
/*      */       
/* 1023 */       slice[index] = (byte)((int)minValue & 0xFF);
/*      */ 
/*      */       
/* 1026 */       for (z2 = Math.max(z - 1, 0); z2 < Math.min(z + 2, this.size3); z2++) {
/*      */         
/* 1028 */         byte[] slice2 = (byte[])stack[z2];
/* 1029 */         maskSlice = (byte[])maskStack[z2];
/* 1030 */         for (int y2 = Math.max(y - 1, 0); y2 < Math.min(y + 2, this.size2); y2++) {
/*      */           
/* 1032 */           for (int x2 = Math.max(x - 1, 0); x2 < Math.min(x + 2, this.size1); x2++) {
/*      */             
/* 1034 */             index = y2 * this.size1 + x2;
/* 1035 */             int value = slice2[index] & 0xFF;
/* 1036 */             maskValue = maskSlice[index] & 0xFF;
/*      */             
/* 1038 */             if (value > minValue && value > maskValue) {
/*      */               
/* 1040 */               int[] pos = { x2, y2, z2 };
/* 1041 */               this.queue.addLast(pos);
/* 1042 */               total++;
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } 
/*      */       
/* 1048 */       iter++;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void processQueueC26(ImageStack binaryMask) {
/* 1054 */     Object[] stack = this.result.getImageArray();
/* 1055 */     Object[] maskStack = this.mask.getImageArray();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1060 */     int total = this.queue.size();
/* 1061 */     int iter = 1;
/*      */ 
/*      */     
/* 1064 */     while (!this.queue.isEmpty()) {
/*      */       
/* 1066 */       showProgress(iter, total);
/* 1067 */       trace("iter " + iter++ + " over " + total);
/*      */       
/* 1069 */       int[] p = this.queue.pollFirst();
/* 1070 */       int x = p[0];
/* 1071 */       int y = p[1];
/* 1072 */       int z = p[2];
/*      */       
/* 1074 */       if (binaryMask.getVoxel(x, y, z) == 0.0D) {
/*      */         continue;
/*      */       }
/* 1077 */       byte[] slice = (byte[])stack[z];
/* 1078 */       byte[] maskSlice = (byte[])maskStack[z];
/* 1079 */       int index = y * this.size1 + x;
/* 1080 */       int currentValue = slice[index] & 0xFF;
/* 1081 */       int maskValue = maskSlice[index] & 0xFF;
/* 1082 */       if (currentValue == maskValue) {
/*      */         continue;
/*      */       }
/*      */       
/* 1086 */       double minValue = currentValue; int z2;
/* 1087 */       for (z2 = Math.max(z - 1, 0); z2 < Math.min(z + 2, this.size3); z2++) {
/*      */         
/* 1089 */         byte[] slice2 = (byte[])stack[z2];
/* 1090 */         for (int y2 = Math.max(y - 1, 0); y2 < Math.min(y + 2, this.size2); y2++) {
/*      */           
/* 1092 */           for (int x2 = Math.max(x - 1, 0); x2 < Math.min(x + 2, this.size1); x2++) {
/*      */             
/* 1094 */             int value = slice2[y2 * this.size1 + x2] & 0xFF;
/* 1095 */             if (value < minValue) {
/* 1096 */               minValue = value;
/*      */             }
/*      */           } 
/*      */         } 
/*      */       } 
/*      */       
/* 1102 */       minValue = Math.max(minValue, maskValue);
/* 1103 */       if (minValue >= currentValue) {
/*      */         continue;
/*      */       }
/*      */ 
/*      */       
/* 1108 */       slice[index] = (byte)((int)minValue & 0xFF);
/*      */ 
/*      */       
/* 1111 */       for (z2 = Math.max(z - 1, 0); z2 < Math.min(z + 2, this.size3); z2++) {
/*      */         
/* 1113 */         byte[] slice2 = (byte[])stack[z2];
/* 1114 */         maskSlice = (byte[])maskStack[z2];
/* 1115 */         for (int y2 = Math.max(y - 1, 0); y2 < Math.min(y + 2, this.size2); y2++) {
/*      */           
/* 1117 */           for (int x2 = Math.max(x - 1, 0); x2 < Math.min(x + 2, this.size1); x2++) {
/*      */             
/* 1119 */             index = y2 * this.size1 + x2;
/* 1120 */             int value = slice2[index] & 0xFF;
/* 1121 */             maskValue = maskSlice[index] & 0xFF;
/*      */             
/* 1123 */             if (value > minValue && value > maskValue) {
/*      */               
/* 1125 */               int[] pos = { x2, y2, z2 };
/* 1126 */               this.queue.addLast(pos);
/* 1127 */               total++;
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } 
/*      */       
/* 1133 */       iter++;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ImageStack applyTo(ImageStack marker, ImageStack mask, ImageStack binaryMask) {
/* 1144 */     this.marker = marker;
/* 1145 */     this.mask = mask;
/*      */ 
/*      */     
/* 1148 */     this.size1 = marker.getWidth();
/* 1149 */     this.size2 = marker.getHeight();
/* 1150 */     this.size3 = marker.getSize();
/* 1151 */     if (!Images3D.isSameSize(marker, mask))
/*      */     {
/* 1153 */       throw new IllegalArgumentException("Marker and Mask images must have the same size");
/*      */     }
/*      */ 
/*      */     
/* 1157 */     if (this.connectivity != 6 && this.connectivity != 26)
/*      */     {
/* 1159 */       throw new RuntimeException(
/* 1160 */           "Connectivity for stacks must be either 6 or 26, not " + 
/* 1161 */           this.connectivity);
/*      */     }
/*      */     
/* 1164 */     initializeResult(binaryMask);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1174 */     trace("Forward iteration");
/* 1175 */     showStatus("Geod. Rec. by Ero. Fwd ");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1183 */     forwardDilationC26(binaryMask);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1188 */     trace("Backward iteration ");
/* 1189 */     showStatus("Geod. Rec. by Ero. Bwd ");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1197 */     backwardDilationC26(binaryMask);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1204 */     forwardDilationC26InitQueue(binaryMask);
/* 1205 */     trace("queue size: " + this.queue.size());
/*      */     
/* 1207 */     processQueueC26(binaryMask);
/*      */     
/* 1209 */     return this.result;
/*      */   }
/*      */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/morphology/geodrec/GeodesicReconstructionByErosion3DGray8.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */