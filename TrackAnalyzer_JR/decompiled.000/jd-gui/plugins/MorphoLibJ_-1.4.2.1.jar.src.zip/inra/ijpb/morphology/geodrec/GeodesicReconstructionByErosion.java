/*     */ package inra.ijpb.morphology.geodrec;
/*     */ 
/*     */ import ij.IJ;
/*     */ import ij.process.ImageProcessor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GeodesicReconstructionByErosion
/*     */   extends GeodesicReconstructionAlgoStub
/*     */ {
/*     */   ImageProcessor marker;
/*     */   ImageProcessor mask;
/*     */   ImageProcessor result;
/*     */   boolean modif;
/*     */   
/*     */   public GeodesicReconstructionByErosion() {}
/*     */   
/*     */   public GeodesicReconstructionByErosion(int connectivity) {
/*  75 */     this.connectivity = connectivity;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ImageProcessor applyTo(ImageProcessor marker, ImageProcessor mask) {
/*  89 */     this.marker = marker;
/*  90 */     this.mask = mask;
/*     */ 
/*     */     
/*  93 */     int width = marker.getWidth();
/*  94 */     int height = marker.getHeight();
/*  95 */     if (width != mask.getWidth() || height != mask.getHeight())
/*     */     {
/*  97 */       throw new IllegalArgumentException("Marker and Mask images must have the same size");
/*     */     }
/*     */ 
/*     */     
/* 101 */     if (this.connectivity != 4 && this.connectivity != 8)
/*     */     {
/* 103 */       throw new RuntimeException(
/* 104 */           "Connectivity for planar images must be either 4 or 8, not " + 
/* 105 */           this.connectivity);
/*     */     }
/*     */ 
/*     */     
/* 109 */     this.result = this.mask.createProcessor(width, height);
/*     */ 
/*     */     
/* 112 */     int iter = 0;
/*     */     
/* 114 */     boolean isFloat = mask instanceof ij.process.FloatProcessor;
/*     */ 
/*     */ 
/*     */     
/* 118 */     for (int y = 0; y < height; y++) {
/*     */       
/* 120 */       for (int x = 0; x < width; x++)
/*     */       {
/* 122 */         this.result.setf(x, y, 
/* 123 */             Math.max(this.marker.getf(x, y), this.mask.getf(x, y)));
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/*     */     do {
/* 130 */       this.modif = false;
/*     */ 
/*     */       
/* 133 */       if (this.verbose)
/*     */       {
/* 135 */         System.out.println("Forward iteration " + iter);
/*     */       }
/* 137 */       if (this.showStatus)
/*     */       {
/* 139 */         IJ.showStatus("Geod. Rec. by Ero. Fwd " + (iter + 1));
/*     */       }
/*     */ 
/*     */       
/* 143 */       switch (this.connectivity) {
/*     */         
/*     */         case 4:
/* 146 */           if (isFloat) {
/* 147 */             forwardErosionC4Float(); break;
/*     */           } 
/* 149 */           forwardErosionC4();
/*     */           break;
/*     */         case 8:
/* 152 */           if (isFloat) {
/* 153 */             forwardErosionC8Float(); break;
/*     */           } 
/* 155 */           forwardErosionC8();
/*     */           break;
/*     */       } 
/*     */ 
/*     */       
/* 160 */       if (this.verbose)
/*     */       {
/* 162 */         System.out.println("Backward iteration " + iter);
/*     */       }
/* 164 */       if (this.showStatus)
/*     */       {
/* 166 */         IJ.showStatus("Geod. Rec. by Ero. Bwd " + (iter + 1));
/*     */       }
/*     */ 
/*     */       
/* 170 */       switch (this.connectivity) {
/*     */         
/*     */         case 4:
/* 173 */           if (isFloat) {
/* 174 */             backwardErosionC4Float(); break;
/*     */           } 
/* 176 */           backwardErosionC4();
/*     */           break;
/*     */         case 8:
/* 179 */           if (isFloat) {
/* 180 */             backwardErosionC8Float(); break;
/*     */           } 
/* 182 */           backwardErosionC8();
/*     */           break;
/*     */       } 
/*     */       
/* 186 */       iter++;
/* 187 */     } while (this.modif);
/*     */     
/* 189 */     return this.result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void forwardErosionC4() {
/* 198 */     int width = this.marker.getWidth();
/* 199 */     int height = this.marker.getHeight();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 207 */     if (this.showProgress)
/*     */     {
/* 209 */       IJ.showProgress(0, height);
/*     */     }
/*     */ 
/*     */     
/* 213 */     for (int i = 1; i < width; i++) {
/*     */       
/* 215 */       int value = this.result.get(i - 1, 0);
/* 216 */       geodesicErosionUpdate(i, 0, value);
/*     */     } 
/*     */ 
/*     */     
/* 220 */     for (int j = 1; j < height; j++) {
/*     */ 
/*     */       
/* 223 */       if (this.showProgress)
/*     */       {
/* 225 */         IJ.showProgress(j, height);
/*     */       }
/*     */       
/* 228 */       int value = this.result.get(0, j - 1);
/* 229 */       geodesicErosionUpdate(0, j, value);
/*     */ 
/*     */       
/* 232 */       for (int k = 1; k < width; k++) {
/*     */         
/* 234 */         int v1 = this.result.get(k, j - 1);
/* 235 */         int v2 = this.result.get(k - 1, j);
/* 236 */         value = Math.min(v1, v2);
/* 237 */         geodesicErosionUpdate(k, j, value);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void forwardErosionC4Float() {
/* 248 */     int width = this.marker.getWidth();
/* 249 */     int height = this.marker.getHeight();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 257 */     if (this.showProgress)
/*     */     {
/* 259 */       IJ.showProgress(0, height);
/*     */     }
/*     */ 
/*     */     
/* 263 */     for (int i = 1; i < width; i++) {
/*     */       
/* 265 */       float value = this.result.getf(i - 1, 0);
/* 266 */       geodesicErosionUpdateFloat(i, 0, value);
/*     */     } 
/*     */ 
/*     */     
/* 270 */     for (int j = 1; j < height; j++) {
/*     */ 
/*     */       
/* 273 */       if (this.showProgress)
/*     */       {
/* 275 */         IJ.showProgress(j, height);
/*     */       }
/*     */       
/* 278 */       float value = this.result.getf(0, j - 1);
/* 279 */       geodesicErosionUpdateFloat(0, j, value);
/*     */ 
/*     */       
/* 282 */       for (int k = 1; k < width; k++) {
/*     */         
/* 284 */         float v1 = this.result.getf(k, j - 1);
/* 285 */         float v2 = this.result.getf(k - 1, j);
/* 286 */         value = Math.min(v1, v2);
/* 287 */         geodesicErosionUpdateFloat(k, j, value);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void forwardErosionC8() {
/* 298 */     int width = this.marker.getWidth();
/* 299 */     int height = this.marker.getHeight();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 307 */     if (this.showProgress)
/*     */     {
/* 309 */       IJ.showProgress(0, height);
/*     */     }
/*     */ 
/*     */     
/* 313 */     for (int i = 1; i < width; i++) {
/*     */       
/* 315 */       int value = this.result.get(i - 1, 0);
/* 316 */       geodesicErosionUpdate(i, 0, value);
/*     */     } 
/*     */ 
/*     */     
/* 320 */     for (int j = 1; j < height; j++) {
/*     */ 
/*     */       
/* 323 */       if (this.showProgress)
/*     */       {
/* 325 */         IJ.showProgress(j, height);
/*     */       }
/*     */ 
/*     */       
/* 329 */       int v1 = this.result.get(0, j - 1);
/* 330 */       int v2 = this.result.get(1, j - 1);
/* 331 */       int value = Math.min(v1, v2);
/* 332 */       geodesicErosionUpdate(0, j, value);
/*     */ 
/*     */       
/* 335 */       for (int k = 1; k < width - 1; k++) {
/*     */         
/* 337 */         v1 = this.result.get(k - 1, j - 1);
/* 338 */         v2 = this.result.get(k, j - 1);
/* 339 */         int m = this.result.get(k + 1, j - 1);
/* 340 */         int v4 = this.result.get(k - 1, j);
/* 341 */         value = Math.min(Math.min(v1, v2), Math.min(m, v4));
/* 342 */         geodesicErosionUpdate(k, j, value);
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 347 */       v1 = this.result.get(width - 2, j - 1);
/* 348 */       v2 = this.result.get(width - 1, j - 1);
/* 349 */       int v3 = this.result.get(width - 2, j);
/* 350 */       value = Math.min(Math.min(v1, v2), v3);
/* 351 */       geodesicErosionUpdate(width - 1, j, value);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void forwardErosionC8Float() {
/* 362 */     int width = this.marker.getWidth();
/* 363 */     int height = this.marker.getHeight();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 371 */     if (this.showProgress)
/*     */     {
/* 373 */       IJ.showProgress(0, height);
/*     */     }
/*     */ 
/*     */     
/* 377 */     for (int i = 1; i < width; i++) {
/*     */       
/* 379 */       float value = this.result.getf(i - 1, 0);
/* 380 */       geodesicErosionUpdateFloat(i, 0, value);
/*     */     } 
/*     */ 
/*     */     
/* 384 */     for (int j = 1; j < height; j++) {
/*     */ 
/*     */       
/* 387 */       if (this.showProgress)
/*     */       {
/* 389 */         IJ.showProgress(j, height);
/*     */       }
/*     */ 
/*     */       
/* 393 */       float v1 = this.result.getf(0, j - 1);
/* 394 */       float v2 = this.result.getf(1, j - 1);
/* 395 */       float value = Math.min(v1, v2);
/* 396 */       geodesicErosionUpdateFloat(0, j, value);
/*     */ 
/*     */       
/* 399 */       for (int k = 1; k < width - 1; k++) {
/*     */         
/* 401 */         v1 = this.result.getf(k - 1, j - 1);
/* 402 */         v2 = this.result.getf(k, j - 1);
/* 403 */         float f1 = this.result.getf(k + 1, j - 1);
/* 404 */         float v4 = this.result.getf(k - 1, j);
/* 405 */         value = Math.min(Math.min(v1, v2), Math.min(f1, v4));
/* 406 */         geodesicErosionUpdateFloat(k, j, value);
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 411 */       v1 = this.result.getf(width - 2, j - 1);
/* 412 */       v2 = this.result.getf(width - 1, j - 1);
/* 413 */       float v3 = this.result.getf(width - 2, j);
/* 414 */       value = Math.min(Math.min(v1, v2), v3);
/* 415 */       geodesicErosionUpdateFloat(width - 1, j, value);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void backwardErosionC4() {
/* 426 */     int width = this.marker.getWidth();
/* 427 */     int height = this.marker.getHeight();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 435 */     if (this.showProgress)
/*     */     {
/* 437 */       IJ.showProgress(0, height);
/*     */     }
/*     */ 
/*     */     
/* 441 */     for (int i = width - 2; i > 0; i--) {
/*     */       
/* 443 */       int value = this.result.get(i + 1, height - 1);
/* 444 */       geodesicErosionUpdate(i, height - 1, value);
/*     */     } 
/*     */ 
/*     */     
/* 448 */     for (int j = height - 2; j >= 0; j--) {
/*     */ 
/*     */       
/* 451 */       if (this.showProgress)
/*     */       {
/* 453 */         IJ.showProgress(height - 1 - j, height);
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 458 */       int value = this.result.get(width - 1, j + 1);
/* 459 */       geodesicErosionUpdate(width - 1, j, value);
/*     */ 
/*     */ 
/*     */       
/* 463 */       for (int k = width - 2; k > 0; k--) {
/*     */         
/* 465 */         int m = this.result.get(k + 1, j);
/* 466 */         int n = this.result.get(k, j + 1);
/* 467 */         value = Math.min(m, n);
/* 468 */         geodesicErosionUpdate(k, j, value);
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 473 */       int v1 = this.result.get(1, j);
/* 474 */       int v2 = this.result.get(0, j + 1);
/* 475 */       value = Math.min(v1, v2);
/* 476 */       geodesicErosionUpdate(0, j, value);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void backwardErosionC4Float() {
/* 487 */     int width = this.marker.getWidth();
/* 488 */     int height = this.marker.getHeight();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 496 */     if (this.showProgress)
/*     */     {
/* 498 */       IJ.showProgress(0, height);
/*     */     }
/*     */ 
/*     */     
/* 502 */     for (int i = width - 2; i > 0; i--) {
/*     */       
/* 504 */       float value = this.result.getf(i + 1, height - 1);
/* 505 */       geodesicErosionUpdateFloat(i, height - 1, value);
/*     */     } 
/*     */ 
/*     */     
/* 509 */     for (int j = height - 2; j >= 0; j--) {
/*     */ 
/*     */       
/* 512 */       if (this.showProgress)
/*     */       {
/* 514 */         IJ.showProgress(height - 1 - j, height);
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 519 */       float value = this.result.getf(width - 1, j + 1);
/* 520 */       geodesicErosionUpdateFloat(width - 1, j, value);
/*     */ 
/*     */ 
/*     */       
/* 524 */       for (int k = width - 2; k > 0; k--) {
/*     */         
/* 526 */         float f1 = this.result.getf(k + 1, j);
/* 527 */         float f2 = this.result.getf(k, j + 1);
/* 528 */         value = Math.min(f1, f2);
/* 529 */         geodesicErosionUpdateFloat(k, j, value);
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 534 */       float v1 = this.result.getf(1, j);
/* 535 */       float v2 = this.result.getf(0, j + 1);
/* 536 */       value = Math.min(v1, v2);
/* 537 */       geodesicErosionUpdateFloat(0, j, value);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void backwardErosionC8() {
/* 548 */     int width = this.marker.getWidth();
/* 549 */     int height = this.marker.getHeight();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 557 */     if (this.showProgress)
/*     */     {
/* 559 */       IJ.showProgress(0, height);
/*     */     }
/*     */ 
/*     */     
/* 563 */     for (int i = width - 2; i > 0; i--) {
/*     */       
/* 565 */       int value = this.result.get(i + 1, height - 1);
/* 566 */       geodesicErosionUpdate(i, height - 1, value);
/*     */     } 
/*     */ 
/*     */     
/* 570 */     for (int j = height - 2; j >= 0; j--) {
/*     */ 
/*     */       
/* 573 */       if (this.showProgress)
/*     */       {
/* 575 */         IJ.showProgress(height - 1 - j, height);
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 580 */       int v1 = this.result.get(width - 1, j + 1);
/* 581 */       int v2 = this.result.get(width - 2, j + 1);
/* 582 */       int value = Math.min(v1, v2);
/* 583 */       geodesicErosionUpdate(width - 1, j, value);
/*     */ 
/*     */       
/* 586 */       for (int k = width - 2; k > 0; k--) {
/*     */         
/* 588 */         v1 = this.result.get(k + 1, j);
/* 589 */         v2 = this.result.get(k + 1, j + 1);
/* 590 */         int m = this.result.get(k, j + 1);
/* 591 */         int v4 = this.result.get(k - 1, j + 1);
/* 592 */         value = Math.min(Math.min(v1, v2), Math.min(m, v4));
/* 593 */         geodesicErosionUpdate(k, j, value);
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 598 */       v1 = this.result.get(1, j);
/* 599 */       v2 = this.result.get(0, j + 1);
/* 600 */       int v3 = this.result.get(1, j + 1);
/* 601 */       value = Math.min(Math.min(v1, v2), v3);
/* 602 */       geodesicErosionUpdate(0, j, value);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void backwardErosionC8Float() {
/* 613 */     int width = this.marker.getWidth();
/* 614 */     int height = this.marker.getHeight();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 622 */     if (this.showProgress)
/*     */     {
/* 624 */       IJ.showProgress(0, height);
/*     */     }
/*     */ 
/*     */     
/* 628 */     for (int i = width - 2; i > 0; i--) {
/*     */       
/* 630 */       float value = this.result.getf(i + 1, height - 1);
/* 631 */       geodesicErosionUpdateFloat(i, height - 1, value);
/*     */     } 
/*     */ 
/*     */     
/* 635 */     for (int j = height - 2; j >= 0; j--) {
/*     */ 
/*     */       
/* 638 */       if (this.showProgress)
/*     */       {
/* 640 */         IJ.showProgress(height - 1 - j, height);
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 645 */       float v1 = this.result.getf(width - 1, j + 1);
/* 646 */       float v2 = this.result.getf(width - 2, j + 1);
/* 647 */       float value = Math.min(v1, v2);
/* 648 */       geodesicErosionUpdateFloat(width - 1, j, value);
/*     */ 
/*     */       
/* 651 */       for (int k = width - 2; k > 0; k--) {
/*     */         
/* 653 */         v1 = this.result.getf(k + 1, j);
/* 654 */         v2 = this.result.getf(k + 1, j + 1);
/* 655 */         float f1 = this.result.getf(k, j + 1);
/* 656 */         float v4 = this.result.getf(k - 1, j + 1);
/* 657 */         value = Math.min(Math.min(v1, v2), Math.min(f1, v4));
/* 658 */         geodesicErosionUpdateFloat(k, j, value);
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 663 */       v1 = this.result.getf(1, j);
/* 664 */       v2 = this.result.getf(0, j + 1);
/* 665 */       float v3 = this.result.getf(1, j + 1);
/* 666 */       value = Math.min(Math.min(v1, v2), v3);
/* 667 */       geodesicErosionUpdateFloat(0, j, value);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void geodesicErosionUpdate(int i, int j, int value) {
/* 681 */     value = Math.max(value, this.mask.get(i, j));
/* 682 */     if (value < this.result.get(i, j)) {
/*     */       
/* 684 */       this.modif = true;
/* 685 */       this.result.set(i, j, value);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void geodesicErosionUpdateFloat(int i, int j, float value) {
/* 698 */     value = Math.max(value, this.mask.getf(i, j));
/* 699 */     if (value < this.result.getf(i, j)) {
/*     */       
/* 701 */       this.modif = true;
/* 702 */       this.result.setf(i, j, value);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/morphology/geodrec/GeodesicReconstructionByErosion.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */