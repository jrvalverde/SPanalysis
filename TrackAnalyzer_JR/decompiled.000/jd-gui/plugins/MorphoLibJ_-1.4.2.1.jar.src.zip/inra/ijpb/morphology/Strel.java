/*     */ package inra.ijpb.morphology;
/*     */ 
/*     */ import ij.process.ImageProcessor;
/*     */ import inra.ijpb.morphology.strel.Cross3x3Strel;
/*     */ import inra.ijpb.morphology.strel.DiamondStrel;
/*     */ import inra.ijpb.morphology.strel.DiskStrel;
/*     */ import inra.ijpb.morphology.strel.LinearDiagDownStrel;
/*     */ import inra.ijpb.morphology.strel.LinearDiagUpStrel;
/*     */ import inra.ijpb.morphology.strel.LinearHorizontalStrel;
/*     */ import inra.ijpb.morphology.strel.LinearVerticalStrel;
/*     */ import inra.ijpb.morphology.strel.OctagonStrel;
/*     */ import inra.ijpb.morphology.strel.SquareStrel;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface Strel
/*     */   extends Strel3D
/*     */ {
/*     */   public static final int BACKGROUND = 0;
/*     */   public static final int FOREGROUND = 255;
/*     */   
/*     */   int[] getSize();
/*     */   
/*     */   int[][] getMask();
/*     */   
/*     */   int[] getOffset();
/*     */   
/*     */   int[][] getShifts();
/*     */   
/*     */   Strel reverse();
/*     */   
/*     */   ImageProcessor dilation(ImageProcessor paramImageProcessor);
/*     */   
/*     */   ImageProcessor erosion(ImageProcessor paramImageProcessor);
/*     */   
/*     */   ImageProcessor closing(ImageProcessor paramImageProcessor);
/*     */   
/*     */   ImageProcessor opening(ImageProcessor paramImageProcessor);
/*     */   
/*     */   void setChannelName(String paramString);
/*     */   
/*     */   String getChannelName();
/*     */   
/*     */   public enum Shape
/*     */   {
/*  71 */     DISK(
/*     */ 
/*     */ 
/*     */       
/*  75 */       "Disk"),
/*     */     
/*  77 */     SQUARE(
/*     */ 
/*     */ 
/*     */       
/*  81 */       "Square"),
/*     */     
/*  83 */     DIAMOND(
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  88 */       "Diamond"),
/*     */     
/*  90 */     OCTAGON(
/*     */ 
/*     */ 
/*     */       
/*  94 */       "Octagon"),
/*     */     
/*  96 */     LINE_HORIZ(
/*     */ 
/*     */ 
/*     */       
/* 100 */       "Horizontal Line"),
/*     */     
/* 102 */     LINE_VERT(
/*     */ 
/*     */ 
/*     */       
/* 106 */       "Vertical Line"),
/*     */     
/* 108 */     LINE_DIAG_UP(
/*     */ 
/*     */ 
/*     */       
/* 112 */       "Line 45 degrees"),
/*     */     
/* 114 */     LINE_DIAG_DOWN(
/*     */ 
/*     */ 
/*     */       
/* 118 */       "Line 135 degrees");
/*     */     
/*     */     private final String label;
/*     */ 
/*     */     
/*     */     Shape(String label) {
/* 124 */       this.label = label;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String toString() {
/* 132 */       return this.label;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Strel fromRadius(int radius) {
/* 146 */       if (this == DISK)
/* 147 */         return (Strel)DiskStrel.fromRadius(radius); 
/* 148 */       return fromDiameter(2 * radius + 1);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Strel fromDiameter(int diam) {
/* 159 */       if (this == DISK)
/* 160 */         return (Strel)DiskStrel.fromDiameter(diam); 
/* 161 */       if (this == SQUARE)
/* 162 */         return (Strel)new SquareStrel(diam); 
/* 163 */       if (this == DIAMOND) {
/* 164 */         if (diam == 3)
/* 165 */           return (Strel)new Cross3x3Strel(); 
/* 166 */         return (Strel)new DiamondStrel(diam);
/*     */       } 
/* 168 */       if (this == OCTAGON)
/* 169 */         return (Strel)new OctagonStrel(diam); 
/* 170 */       if (this == LINE_HORIZ)
/* 171 */         return (Strel)new LinearHorizontalStrel(diam); 
/* 172 */       if (this == LINE_VERT)
/* 173 */         return (Strel)new LinearVerticalStrel(diam); 
/* 174 */       if (this == LINE_DIAG_UP)
/* 175 */         return (Strel)new LinearDiagUpStrel(diam); 
/* 176 */       if (this == LINE_DIAG_DOWN) {
/* 177 */         return (Strel)new LinearDiagDownStrel(diam);
/*     */       }
/* 179 */       throw new IllegalArgumentException("No default method for creating element of type " + this.label);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static String[] getAllLabels() {
/* 190 */       Shape[] values = values();
/* 191 */       int n = values.length;
/*     */ 
/*     */       
/* 194 */       String[] result = new String[n];
/* 195 */       for (int i = 0; i < n; i++) {
/* 196 */         result[i] = (values[i]).label;
/*     */       }
/* 198 */       return result;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static Shape fromLabel(String label) {
/* 213 */       if (label != null)
/* 214 */         label = label.toLowerCase();  byte b; int i; Shape[] arrayOfShape;
/* 215 */       for (i = (arrayOfShape = values()).length, b = 0; b < i; ) { Shape type = arrayOfShape[b];
/*     */         
/* 217 */         if (type.label.toLowerCase().equals(label))
/* 218 */           return type;  b++; }
/*     */       
/* 220 */       throw new IllegalArgumentException("Unable to parse Strel.Shape with label: " + label);
/*     */     }
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/morphology/Strel.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */