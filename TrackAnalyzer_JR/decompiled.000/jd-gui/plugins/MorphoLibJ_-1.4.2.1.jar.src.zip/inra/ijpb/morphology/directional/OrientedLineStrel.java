/*     */ package inra.ijpb.morphology.directional;
/*     */ 
/*     */ import ij.process.ImageProcessor;
/*     */ import inra.ijpb.data.border.MirroringBorder;
/*     */ import inra.ijpb.morphology.Strel;
/*     */ import inra.ijpb.morphology.Strel3D;
/*     */ import inra.ijpb.morphology.strel.AbstractStrel;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OrientedLineStrel
/*     */   extends AbstractStrel
/*     */   implements Strel
/*     */ {
/*     */   double length;
/*     */   double theta;
/*     */   int[][] shifts;
/*     */   
/*     */   public OrientedLineStrel(double length, double angleInDegrees) {
/*  64 */     this.length = length;
/*  65 */     this.theta = angleInDegrees;
/*     */     
/*  67 */     computeShifts();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void computeShifts() {
/*  77 */     double thetaRads = Math.toRadians(this.theta);
/*  78 */     double dx = Math.cos(thetaRads);
/*  79 */     double dy = Math.sin(thetaRads);
/*     */ 
/*     */     
/*  82 */     double dMax = Math.max(Math.abs(dx), Math.abs(dy));
/*  83 */     double projLength = this.length * dMax;
/*     */ 
/*     */     
/*  86 */     int n2 = (int)Math.round((projLength - 1.0D) / 2.0D);
/*  87 */     int n = 2 * n2 + 1;
/*     */ 
/*     */     
/*  90 */     this.shifts = new int[n][2];
/*     */ 
/*     */     
/*  93 */     if (Math.abs(dx) >= Math.abs(dy)) {
/*     */ 
/*     */       
/*  96 */       for (int i = -n2; i <= n2; i++)
/*     */       {
/*  98 */         this.shifts[i + n2][0] = i;
/*  99 */         this.shifts[i + n2][1] = (int)Math.round(i * dy / dx);
/*     */       }
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 105 */       for (int i = -n2; i <= n2; i++) {
/*     */         
/* 107 */         this.shifts[i + n2][1] = i;
/* 108 */         this.shifts[i + n2][0] = (int)Math.round(i * dx / dy);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int[] getSize() {
/* 120 */     int n = this.shifts.length;
/* 121 */     return new int[] { n, n };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int[][] getMask() {
/* 130 */     int n = this.shifts.length;
/* 131 */     int[][] mask = new int[n][n];
/*     */ 
/*     */     
/* 134 */     int[] offsets = getOffset();
/* 135 */     int ox = offsets[0];
/* 136 */     int oy = offsets[1];
/*     */ 
/*     */     
/* 139 */     for (int i = 0; i < n; i++)
/*     */     {
/* 141 */       mask[this.shifts[i][1] + oy][this.shifts[i][0] + ox] = 255;
/*     */     }
/*     */     
/* 144 */     return mask;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int[] getOffset() {
/* 153 */     int offset = (this.shifts.length - 1) / 2;
/* 154 */     return new int[] { offset, offset };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int[][] getShifts() {
/* 163 */     return this.shifts;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ImageProcessor dilation(ImageProcessor image) {
/* 170 */     ImageProcessor result = image.duplicate();
/*     */     
/* 172 */     MirroringBorder mirroringBorder = new MirroringBorder(image);
/*     */ 
/*     */     
/* 175 */     for (int y = 0; y < image.getHeight(); y++) {
/*     */       
/* 177 */       for (int x = 0; x < image.getWidth(); x++) {
/*     */ 
/*     */         
/* 180 */         double res = Double.MIN_VALUE;
/*     */ 
/*     */         
/* 183 */         for (int i = 0; i < this.shifts.length; i++) {
/*     */           
/* 185 */           double value = mirroringBorder.getf(x + this.shifts[i][0], y + this.shifts[i][1]);
/* 186 */           res = Math.max(res, value);
/*     */         } 
/*     */ 
/*     */         
/* 190 */         result.setf(x, y, (float)res);
/*     */       } 
/*     */     } 
/*     */     
/* 194 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ImageProcessor erosion(ImageProcessor image) {
/* 201 */     ImageProcessor result = image.duplicate();
/*     */     
/* 203 */     MirroringBorder mirroringBorder = new MirroringBorder(image);
/*     */ 
/*     */     
/* 206 */     for (int y = 0; y < image.getHeight(); y++) {
/*     */       
/* 208 */       for (int x = 0; x < image.getWidth(); x++) {
/*     */ 
/*     */         
/* 211 */         double res = Double.MAX_VALUE;
/*     */ 
/*     */         
/* 214 */         for (int i = 0; i < this.shifts.length; i++) {
/*     */           
/* 216 */           double value = mirroringBorder.getf(x + this.shifts[i][0], y + this.shifts[i][1]);
/* 217 */           res = Math.min(res, value);
/*     */         } 
/*     */ 
/*     */         
/* 221 */         result.setf(x, y, (float)res);
/*     */       } 
/*     */     } 
/*     */     
/* 225 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ImageProcessor closing(ImageProcessor image) {
/* 231 */     return erosion(dilation(image));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ImageProcessor opening(ImageProcessor image) {
/* 237 */     return dilation(erosion(image));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Strel reverse() {
/* 247 */     return this;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/morphology/directional/OrientedLineStrel.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */