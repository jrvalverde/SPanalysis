/*     */ package inra.ijpb.morphology;
/*     */ 
/*     */ import ij.process.ByteProcessor;
/*     */ import ij.process.ColorProcessor;
/*     */ import ij.process.ImageProcessor;
/*     */ import inra.ijpb.data.image.ColorImages;
/*     */ import inra.ijpb.morphology.geodrec.GeodesicReconstructionAlgo;
/*     */ import inra.ijpb.morphology.geodrec.GeodesicReconstructionHybrid;
/*     */ import inra.ijpb.morphology.geodrec.GeodesicReconstructionType;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Reconstruction
/*     */ {
/*     */   public static final ImageProcessor killBorders(ImageProcessor image) {
/*  82 */     int width = image.getWidth();
/*  83 */     int height = image.getHeight();
/*     */ 
/*     */     
/*  86 */     ImageProcessor markers = image.duplicate();
/*  87 */     for (int y = 1; y < height - 1; y++) {
/*     */       
/*  89 */       for (int x = 1; x < width - 1; x++)
/*     */       {
/*  91 */         markers.setf(x, y, Float.NEGATIVE_INFINITY);
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/*  96 */     ImageProcessor result = reconstructByDilation(markers, image);
/*     */ 
/*     */     
/*  99 */     for (int i = 0; i < height; i++) {
/*     */       
/* 101 */       for (int x = 0; x < width; x++) {
/*     */         
/* 103 */         int val = image.get(x, i) - result.get(x, i);
/* 104 */         result.set(x, i, Math.max(val, 0));
/*     */       } 
/*     */     } 
/*     */     
/* 108 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final ImageProcessor fillHoles(ImageProcessor image) {
/* 124 */     int width = image.getWidth();
/* 125 */     int height = image.getHeight();
/*     */ 
/*     */     
/* 128 */     ImageProcessor markers = image.duplicate();
/* 129 */     for (int y = 1; y < height - 1; y++) {
/*     */       
/* 131 */       for (int x = 1; x < width - 1; x++)
/*     */       {
/* 133 */         markers.setf(x, y, Float.MAX_VALUE);
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 138 */     return reconstructByErosion(markers, image);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final ImageProcessor reconstructByDilation(ImageProcessor marker, ImageProcessor mask) {
/* 154 */     GeodesicReconstructionHybrid geodesicReconstructionHybrid = new GeodesicReconstructionHybrid(
/* 155 */         GeodesicReconstructionType.BY_DILATION);
/* 156 */     if (marker instanceof ColorProcessor && mask instanceof ColorProcessor)
/*     */     {
/* 158 */       return (ImageProcessor)applyAlgo((GeodesicReconstructionAlgo)geodesicReconstructionHybrid, (ColorProcessor)marker, (ColorProcessor)mask);
/*     */     }
/*     */     
/* 161 */     return geodesicReconstructionHybrid.applyTo(marker, mask);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final ImageProcessor reconstructByDilation(ImageProcessor marker, ImageProcessor mask, int connectivity) {
/* 179 */     GeodesicReconstructionHybrid geodesicReconstructionHybrid = new GeodesicReconstructionHybrid(
/* 180 */         GeodesicReconstructionType.BY_DILATION, connectivity);
/* 181 */     if (marker instanceof ColorProcessor && mask instanceof ColorProcessor)
/*     */     {
/* 183 */       return (ImageProcessor)applyAlgo((GeodesicReconstructionAlgo)geodesicReconstructionHybrid, (ColorProcessor)marker, (ColorProcessor)mask);
/*     */     }
/*     */     
/* 186 */     return geodesicReconstructionHybrid.applyTo(marker, mask);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final ImageProcessor reconstructByErosion(ImageProcessor marker, ImageProcessor mask) {
/* 202 */     GeodesicReconstructionHybrid geodesicReconstructionHybrid = new GeodesicReconstructionHybrid(
/* 203 */         GeodesicReconstructionType.BY_EROSION);
/* 204 */     if (marker instanceof ColorProcessor && mask instanceof ColorProcessor)
/*     */     {
/* 206 */       return (ImageProcessor)applyAlgo((GeodesicReconstructionAlgo)geodesicReconstructionHybrid, (ColorProcessor)marker, (ColorProcessor)mask);
/*     */     }
/*     */     
/* 209 */     return geodesicReconstructionHybrid.applyTo(marker, mask);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final ImageProcessor reconstructByErosion(ImageProcessor marker, ImageProcessor mask, int connectivity) {
/* 227 */     GeodesicReconstructionHybrid geodesicReconstructionHybrid = new GeodesicReconstructionHybrid(
/* 228 */         GeodesicReconstructionType.BY_EROSION, connectivity);
/* 229 */     if (marker instanceof ColorProcessor && mask instanceof ColorProcessor)
/*     */     {
/* 231 */       return (ImageProcessor)applyAlgo((GeodesicReconstructionAlgo)geodesicReconstructionHybrid, (ColorProcessor)marker, (ColorProcessor)mask);
/*     */     }
/*     */     
/* 234 */     return geodesicReconstructionHybrid.applyTo(marker, mask);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final ColorProcessor applyAlgo(GeodesicReconstructionAlgo algo, ColorProcessor marker, ColorProcessor mask) {
/* 255 */     Map<String, ByteProcessor> markerChannels = ColorImages.mapChannels((ImageProcessor)marker);
/* 256 */     Map<String, ByteProcessor> maskChannels = ColorImages.mapChannels((ImageProcessor)mask);
/*     */     
/* 258 */     ImageProcessor resRed = algo.applyTo((ImageProcessor)markerChannels.get("red"), (ImageProcessor)maskChannels.get("red"));
/* 259 */     ImageProcessor resGreen = algo.applyTo((ImageProcessor)markerChannels.get("green"), (ImageProcessor)maskChannels.get("green"));
/* 260 */     ImageProcessor resBlue = algo.applyTo((ImageProcessor)markerChannels.get("blue"), (ImageProcessor)maskChannels.get("blue"));
/*     */     
/* 262 */     return ColorImages.mergeChannels(resRed, resGreen, resBlue);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/morphology/Reconstruction.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */