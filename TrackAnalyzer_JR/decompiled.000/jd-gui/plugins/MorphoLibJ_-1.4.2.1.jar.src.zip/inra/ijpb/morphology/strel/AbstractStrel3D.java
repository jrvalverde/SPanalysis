/*    */ package inra.ijpb.morphology.strel;
/*    */ 
/*    */ import ij.ImageStack;
/*    */ import inra.ijpb.algo.AlgoEvent;
/*    */ import inra.ijpb.algo.AlgoStub;
/*    */ import inra.ijpb.morphology.Strel3D;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractStrel3D
/*    */   extends AlgoStub
/*    */   implements Strel3D
/*    */ {
/*    */   private boolean showProgress = true;
/*    */   
/*    */   public boolean showProgress() {
/* 52 */     return this.showProgress;
/*    */   }
/*    */ 
/*    */   
/*    */   public void showProgress(boolean b) {
/* 57 */     this.showProgress = b;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ImageStack closing(ImageStack stack) {
/* 66 */     return reverse().erosion(dilation(stack));
/*    */   }
/*    */ 
/*    */   
/*    */   public ImageStack opening(ImageStack stack) {
/* 71 */     return reverse().dilation(erosion(stack));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected void fireProgressChanged(Object source, double step, double total) {
/* 80 */     if (this.showProgress) {
/* 81 */       super.fireProgressChanged(source, step, total);
/*    */     }
/*    */   }
/*    */   
/*    */   protected void fireProgressChanged(AlgoEvent evt) {
/* 86 */     if (this.showProgress) {
/* 87 */       super.fireProgressChanged(evt);
/*    */     }
/*    */   }
/*    */   
/*    */   protected void fireStatusChanged(Object source, String message) {
/* 92 */     if (this.showProgress) {
/* 93 */       super.fireStatusChanged(source, message);
/*    */     }
/*    */   }
/*    */   
/*    */   protected void fireStatusChanged(AlgoEvent evt) {
/* 98 */     if (this.showProgress)
/* 99 */       super.fireStatusChanged(evt); 
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/morphology/strel/AbstractStrel3D.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */