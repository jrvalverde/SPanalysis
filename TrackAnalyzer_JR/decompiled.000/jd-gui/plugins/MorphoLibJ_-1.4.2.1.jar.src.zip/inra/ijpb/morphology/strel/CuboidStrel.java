/*     */ package inra.ijpb.morphology.strel;
/*     */ 
/*     */ import inra.ijpb.morphology.Strel3D;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CuboidStrel
/*     */   extends AbstractSeparableStrel3D
/*     */ {
/*     */   int sizeX;
/*     */   int sizeY;
/*     */   int sizeZ;
/*     */   int offsetX;
/*     */   int offsetY;
/*     */   int offsetZ;
/*     */   
/*     */   public static final CuboidStrel fromDiameter(int diam) {
/*  46 */     return new CuboidStrel(diam, diam, diam);
/*     */   }
/*     */ 
/*     */   
/*     */   public static final CuboidStrel fromRadius(int radius) {
/*  51 */     int diam = 2 * radius + 1;
/*  52 */     return new CuboidStrel(diam, diam, diam, radius, radius, radius);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final CuboidStrel fromRadiusList(int radiusX, int radiusY, int radiusZ) {
/*  69 */     int diamX = 2 * radiusX + 1;
/*  70 */     int diamY = 2 * radiusY + 1;
/*  71 */     int diamZ = 2 * radiusZ + 1;
/*  72 */     return new CuboidStrel(diamX, diamY, diamZ, radiusX, radiusY, radiusZ);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final CuboidStrel fromDiameterList(int diamX, int diamY, int diamZ) {
/*  89 */     int offsetX = (diamX - 1) / 2;
/*  90 */     int offsetY = (diamY - 1) / 2;
/*  91 */     int offsetZ = (diamZ - 1) / 2;
/*  92 */     return new CuboidStrel(diamX, diamY, diamZ, offsetX, offsetY, offsetZ);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private CuboidStrel(int sizeX, int sizeY, int sizeZ) {
/* 138 */     this.sizeX = sizeX;
/* 139 */     this.sizeY = sizeY;
/* 140 */     this.sizeZ = sizeZ;
/*     */     
/* 142 */     this.offsetX = (sizeX - 1) / 2;
/* 143 */     this.offsetY = (sizeY - 1) / 2;
/* 144 */     this.offsetZ = (sizeZ - 1) / 2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private CuboidStrel(int sizeX, int sizeY, int sizeZ, int offsetX, int offsetY, int offsetZ) {
/* 153 */     this.sizeX = sizeX;
/* 154 */     this.sizeY = sizeY;
/* 155 */     this.sizeZ = sizeZ;
/*     */     
/* 157 */     this.offsetX = offsetX;
/* 158 */     this.offsetY = offsetY;
/* 159 */     this.offsetZ = offsetZ;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection<InPlaceStrel3D> decompose() {
/* 177 */     ArrayList<InPlaceStrel3D> strels = new ArrayList<InPlaceStrel3D>(3);
/* 178 */     strels.add(new LinearHorizontalStrel(this.sizeX, this.offsetX));
/* 179 */     strels.add(new LinearVerticalStrel(this.sizeY, this.offsetY));
/* 180 */     strels.add(new LinearDepthStrel3D(this.sizeZ, this.offsetZ));
/* 181 */     return strels;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int[][][] getMask3D() {
/* 190 */     int[][][] mask = new int[this.sizeZ][this.sizeY][this.sizeX];
/* 191 */     for (int z = 0; z < this.sizeZ; z++) {
/*     */       
/* 193 */       for (int y = 0; y < this.sizeY; y++) {
/*     */         
/* 195 */         for (int x = 0; x < this.sizeX; x++)
/*     */         {
/* 197 */           mask[z][y][x] = 255;
/*     */         }
/*     */       } 
/*     */     } 
/* 201 */     return mask;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int[] getOffset() {
/* 210 */     return new int[] { this.offsetX, this.offsetY, this.offsetZ };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int[][] getShifts3D() {
/* 219 */     int n = this.sizeX * this.sizeY * this.sizeZ;
/* 220 */     int[][] shifts = new int[n][3];
/* 221 */     int i = 0;
/*     */     
/* 223 */     for (int z = 0; z < this.sizeZ; z++) {
/*     */       
/* 225 */       for (int y = 0; y < this.sizeY; y++) {
/*     */         
/* 227 */         for (int x = 0; x < this.sizeX; x++) {
/*     */           
/* 229 */           shifts[i][0] = x - this.offsetX;
/* 230 */           shifts[i][1] = y - this.offsetY;
/* 231 */           shifts[i][2] = z - this.offsetZ;
/* 232 */           i++;
/*     */         } 
/*     */       } 
/*     */     } 
/* 236 */     return shifts;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int[] getSize() {
/* 245 */     return new int[] { this.sizeX, this.sizeY, this.sizeY };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CuboidStrel reverse() {
/* 257 */     return new CuboidStrel(
/* 258 */         this.sizeX, this.sizeY, this.sizeZ, 
/* 259 */         this.sizeX - this.offsetX - 1, 
/* 260 */         this.sizeY - this.offsetY - 1, 
/* 261 */         this.sizeZ - this.offsetZ - 1);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/morphology/strel/CuboidStrel.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */