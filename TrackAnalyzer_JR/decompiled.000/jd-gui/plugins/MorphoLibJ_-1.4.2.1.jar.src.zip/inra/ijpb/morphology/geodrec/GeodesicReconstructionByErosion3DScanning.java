/*     */ package inra.ijpb.morphology.geodrec;
/*     */ 
/*     */ import ij.ImageStack;
/*     */ import inra.ijpb.data.image.Image3D;
/*     */ import inra.ijpb.data.image.Images3D;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GeodesicReconstructionByErosion3DScanning
/*     */   extends GeodesicReconstruction3DAlgoStub
/*     */ {
/*     */   ImageStack markerStack;
/*     */   ImageStack maskStack;
/*     */   ImageStack resultStack;
/*     */   Image3D result;
/*     */   Image3D mask;
/*     */   Image3D marker;
/*  64 */   int sizeX = 0;
/*     */   
/*  66 */   int sizeY = 0;
/*     */   
/*  68 */   int sizeZ = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean modif;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GeodesicReconstructionByErosion3DScanning() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GeodesicReconstructionByErosion3DScanning(int connectivity) {
/*  93 */     this.connectivity = connectivity;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ImageStack applyTo(ImageStack marker, ImageStack mask) {
/* 102 */     if (Thread.currentThread().isInterrupted()) {
/* 103 */       return null;
/*     */     }
/*     */     
/* 106 */     this.markerStack = marker;
/* 107 */     this.maskStack = mask;
/*     */     
/* 109 */     this.marker = Images3D.createWrapper(marker);
/* 110 */     this.mask = Images3D.createWrapper(mask);
/*     */ 
/*     */     
/* 113 */     this.sizeX = marker.getWidth();
/* 114 */     this.sizeY = marker.getHeight();
/* 115 */     this.sizeZ = marker.getSize();
/* 116 */     if (!Images3D.isSameSize(marker, mask))
/*     */     {
/* 118 */       throw new IllegalArgumentException("Marker and Mask images must have the same size");
/*     */     }
/*     */ 
/*     */     
/* 122 */     if (this.connectivity != 6 && this.connectivity != 26)
/*     */     {
/* 124 */       throw new RuntimeException(
/* 125 */           "Connectivity for stacks must be either 6 or 26, not " + 
/* 126 */           this.connectivity);
/*     */     }
/*     */     
/* 129 */     initializeResult();
/*     */     
/* 131 */     boolean integerStack = (marker.getBitDepth() != 32);
/*     */ 
/*     */     
/* 134 */     int iter = 1;
/*     */ 
/*     */ 
/*     */     
/*     */     do {
/* 139 */       this.modif = false;
/*     */ 
/*     */       
/* 142 */       trace("Forward iteration " + iter);
/* 143 */       showStatus("Geod. Rec. by Ero. Fwd " + iter);
/*     */       
/* 145 */       if (integerStack) {
/*     */         
/* 147 */         forwardErosionInt();
/*     */       } else {
/*     */         
/* 150 */         forwardErosionFloat();
/*     */       } 
/*     */ 
/*     */       
/* 154 */       trace("Backward iteration " + iter);
/* 155 */       showStatus("Geod. Rec. by Ero. Bwd " + iter);
/*     */       
/* 157 */       if (integerStack) {
/*     */         
/* 159 */         backwardErosionInt();
/*     */       } else {
/*     */         
/* 162 */         backwardErosionFloat();
/*     */       } 
/*     */       
/* 165 */       iter++;
/* 166 */     } while (this.modif);
/*     */ 
/*     */     
/* 169 */     showProgress(1.0D, 1.0D, "");
/*     */     
/* 171 */     return this.resultStack;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ImageStack applyTo(ImageStack marker, ImageStack mask, ImageStack binaryMask) {
/* 183 */     throw new RuntimeException("Method not yet implemented");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void initializeResult() {
/* 194 */     this.resultStack = ImageStack.create(this.sizeX, this.sizeY, this.sizeZ, 
/* 195 */         this.maskStack.getBitDepth());
/* 196 */     this.result = Images3D.createWrapper(this.resultStack);
/*     */ 
/*     */ 
/*     */     
/* 200 */     if (this.maskStack.getBitDepth() == 32) {
/*     */ 
/*     */       
/* 203 */       for (int z = 0; z < this.sizeZ; z++)
/*     */       {
/* 205 */         for (int y = 0; y < this.sizeY; y++)
/*     */         {
/* 207 */           for (int x = 0; x < this.sizeX; x++)
/*     */           {
/* 209 */             this.result.setValue(x, y, z, Math.max(this.marker.getValue(x, y, z), this.mask.getValue(x, y, z)));
/*     */           }
/*     */         }
/*     */       
/*     */       }
/*     */     
/*     */     } else {
/*     */       
/* 217 */       for (int z = 0; z < this.sizeZ; z++) {
/*     */         
/* 219 */         for (int y = 0; y < this.sizeY; y++) {
/*     */           
/* 221 */           for (int x = 0; x < this.sizeX; x++)
/*     */           {
/* 223 */             this.result.set(x, y, z, Math.max(this.marker.get(x, y, z), this.mask.get(x, y, z)));
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void forwardErosionInt() {
/* 232 */     if (this.connectivity == 6) {
/*     */       
/* 234 */       forwardErosionIntC6();
/*     */     } else {
/*     */       
/* 237 */       forwardErosionIntC26();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void forwardErosionIntC6() {
/* 251 */     for (int z = 0; z < this.sizeZ; z++) {
/*     */       
/* 253 */       showProgress(z, this.sizeZ);
/*     */       
/* 255 */       for (int y = 0; y < this.sizeY; y++) {
/*     */         
/* 257 */         for (int x = 0; x < this.sizeX; x++) {
/*     */           
/* 259 */           int currentValue = this.result.get(x, y, z);
/* 260 */           int minValue = currentValue;
/*     */ 
/*     */           
/* 263 */           if (x > 0)
/* 264 */             minValue = Math.min(minValue, this.result.get(x - 1, y, z)); 
/* 265 */           if (y > 0)
/* 266 */             minValue = Math.min(minValue, this.result.get(x, y - 1, z)); 
/* 267 */           if (z > 0) {
/* 268 */             minValue = Math.min(minValue, this.result.get(x, y, z - 1));
/*     */           }
/*     */ 
/*     */           
/* 272 */           minValue = Math.max(minValue, this.mask.get(x, y, z));
/* 273 */           if (minValue < currentValue) {
/*     */             
/* 275 */             this.result.set(x, y, z, minValue);
/* 276 */             this.modif = true;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void forwardErosionIntC26() {
/* 293 */     for (int z = 0; z < this.sizeZ; z++) {
/*     */       
/* 295 */       showProgress(z, this.sizeZ, "z = " + z);
/*     */       
/* 297 */       for (int y = 0; y < this.sizeY; y++) {
/*     */         
/* 299 */         for (int x = 0; x < this.sizeX; x++) {
/*     */           
/* 301 */           int currentValue = this.result.get(x, y, z);
/* 302 */           int minValue = currentValue;
/*     */ 
/*     */           
/* 305 */           int zmax = Math.min(z + 1, this.sizeZ);
/* 306 */           for (int z2 = Math.max(z - 1, 0); z2 < zmax; z2++) {
/*     */             
/* 308 */             int ymax = (z2 == z) ? y : Math.min(y + 1, this.sizeY - 1);
/* 309 */             for (int y2 = Math.max(y - 1, 0); y2 <= ymax; y2++) {
/*     */               
/* 311 */               int xmax = (z2 == z && y2 == y) ? (x - 1) : Math.min(x + 1, this.sizeX - 1);
/* 312 */               for (int x2 = Math.max(x - 1, 0); x2 <= xmax; x2++)
/*     */               {
/* 314 */                 minValue = Math.min(minValue, this.result.get(x2, y2, z2));
/*     */               }
/*     */             } 
/*     */           } 
/*     */ 
/*     */           
/* 320 */           minValue = Math.max(minValue, this.mask.get(x, y, z));
/* 321 */           if (minValue < currentValue) {
/*     */             
/* 323 */             this.result.set(x, y, z, minValue);
/* 324 */             this.modif = true;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void forwardErosionFloat() {
/* 333 */     if (this.connectivity == 6) {
/*     */       
/* 335 */       forwardErosionFloatC6();
/*     */     } else {
/*     */       
/* 338 */       forwardErosionFloatC26();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void forwardErosionFloatC6() {
/* 352 */     for (int z = 0; z < this.sizeZ; z++) {
/*     */       
/* 354 */       showProgress(z, this.sizeZ, "z = " + z);
/*     */       
/* 356 */       for (int y = 0; y < this.sizeY; y++) {
/*     */         
/* 358 */         for (int x = 0; x < this.sizeX; x++) {
/*     */           
/* 360 */           double currentValue = this.result.getValue(x, y, z);
/* 361 */           double minValue = currentValue;
/*     */ 
/*     */           
/* 364 */           if (x > 0)
/* 365 */             minValue = Math.min(minValue, this.result.getValue(x - 1, y, z)); 
/* 366 */           if (y > 0)
/* 367 */             minValue = Math.min(minValue, this.result.getValue(x, y - 1, z)); 
/* 368 */           if (z > 0) {
/* 369 */             minValue = Math.min(minValue, this.result.getValue(x, y, z - 1));
/*     */           }
/*     */ 
/*     */           
/* 373 */           minValue = Math.max(minValue, this.mask.getValue(x, y, z));
/* 374 */           if (minValue < currentValue) {
/*     */             
/* 376 */             this.result.setValue(x, y, z, minValue);
/* 377 */             this.modif = true;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void forwardErosionFloatC26() {
/* 394 */     for (int z = 0; z < this.sizeZ; z++) {
/*     */       
/* 396 */       showProgress(z, this.sizeZ, "z = " + z);
/*     */       
/* 398 */       for (int y = 0; y < this.sizeY; y++) {
/*     */         
/* 400 */         for (int x = 0; x < this.sizeX; x++) {
/*     */           
/* 402 */           double currentValue = this.result.getValue(x, y, z);
/* 403 */           double minValue = currentValue;
/*     */ 
/*     */           
/* 406 */           int zmax = Math.min(z + 1, this.sizeZ);
/* 407 */           for (int z2 = Math.max(z - 1, 0); z2 < zmax; z2++) {
/*     */             
/* 409 */             int ymax = (z2 == z) ? y : Math.min(y + 1, this.sizeY - 1);
/* 410 */             for (int y2 = Math.max(y - 1, 0); y2 <= ymax; y2++) {
/*     */               
/* 412 */               int xmax = (z2 == z && y2 == y) ? (x - 1) : Math.min(x + 1, this.sizeX - 1);
/* 413 */               for (int x2 = Math.max(x - 1, 0); x2 <= xmax; x2++) {
/* 414 */                 minValue = Math.min(minValue, this.result.getValue(x2, y2, z2));
/*     */               }
/*     */             } 
/*     */           } 
/*     */ 
/*     */           
/* 420 */           minValue = Math.max(minValue, this.mask.getValue(x, y, z));
/* 421 */           if (minValue < currentValue) {
/*     */             
/* 423 */             this.result.setValue(x, y, z, minValue);
/* 424 */             this.modif = true;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void backwardErosionInt() {
/* 433 */     if (this.connectivity == 6) {
/*     */       
/* 435 */       backwardErosionIntC6();
/*     */     } else {
/*     */       
/* 438 */       backwardErosionIntC26();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void backwardErosionIntC6() {
/* 452 */     for (int z = this.sizeZ - 1; z >= 0; z--) {
/*     */       
/* 454 */       showProgress((this.sizeZ - z), this.sizeZ, "z = " + z);
/*     */       
/* 456 */       for (int y = this.sizeY - 1; y >= 0; y--) {
/*     */         
/* 458 */         for (int x = this.sizeX - 1; x >= 0; x--) {
/*     */           
/* 460 */           int currentValue = this.result.get(x, y, z);
/* 461 */           int minValue = currentValue;
/*     */ 
/*     */           
/* 464 */           if (x < this.sizeX - 1)
/* 465 */             minValue = Math.min(minValue, this.result.get(x + 1, y, z)); 
/* 466 */           if (y < this.sizeY - 1)
/* 467 */             minValue = Math.min(minValue, this.result.get(x, y + 1, z)); 
/* 468 */           if (z < this.sizeZ - 1)
/*     */           {
/* 470 */             minValue = Math.min(minValue, this.result.get(x, y, z + 1));
/*     */           }
/*     */ 
/*     */           
/* 474 */           minValue = Math.max(minValue, this.mask.get(x, y, z));
/* 475 */           if (minValue < currentValue) {
/*     */             
/* 477 */             this.result.set(x, y, z, minValue);
/* 478 */             this.modif = true;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void backwardErosionIntC26() {
/* 495 */     for (int z = this.sizeZ - 1; z >= 0; z--) {
/*     */       
/* 497 */       showProgress((this.sizeZ - 1 - z), this.sizeZ, "z = " + z);
/*     */       
/* 499 */       for (int y = this.sizeY - 1; y >= 0; y--) {
/*     */         
/* 501 */         for (int x = this.sizeX - 1; x >= 0; x--) {
/*     */           
/* 503 */           int currentValue = this.result.get(x, y, z);
/* 504 */           int minValue = currentValue;
/*     */ 
/*     */           
/* 507 */           int zmin = Math.max(z - 1, 0);
/* 508 */           for (int z2 = Math.min(z + 1, this.sizeZ - 1); z2 >= zmin; z2--) {
/*     */ 
/*     */             
/* 511 */             int ymin = (z2 == z) ? y : Math.max(y - 1, 0);
/* 512 */             for (int y2 = Math.min(y + 1, this.sizeY - 1); y2 >= ymin; y2--) {
/*     */               
/* 514 */               int xmin = (z2 == z && y2 == y) ? x : Math.max(x - 1, 0);
/* 515 */               for (int x2 = Math.min(x + 1, this.sizeX - 1); x2 >= xmin; x2--)
/*     */               {
/* 517 */                 minValue = Math.min(minValue, this.result.get(x2, y2, z2));
/*     */               }
/*     */             } 
/*     */           } 
/*     */ 
/*     */           
/* 523 */           minValue = Math.max(minValue, this.mask.get(x, y, z));
/* 524 */           if (minValue < currentValue) {
/*     */             
/* 526 */             this.result.set(x, y, z, minValue);
/* 527 */             this.modif = true;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void backwardErosionFloat() {
/* 536 */     if (this.connectivity == 6) {
/*     */       
/* 538 */       backwardErosionFloatC6();
/*     */     } else {
/*     */       
/* 541 */       backwardErosionFloatC26();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void backwardErosionFloatC6() {
/* 555 */     for (int z = this.sizeZ - 1 - 1; z >= 0; z--) {
/*     */       
/* 557 */       showProgress((this.sizeZ - 1 - z), this.sizeZ, "z = " + z);
/*     */       
/* 559 */       for (int y = this.sizeY - 1; y >= 0; y--) {
/*     */         
/* 561 */         for (int x = this.sizeX - 1; x >= 0; x--) {
/*     */           
/* 563 */           double currentValue = this.result.getValue(x, y, z);
/* 564 */           double minValue = currentValue;
/*     */ 
/*     */           
/* 567 */           if (x < this.sizeX - 1)
/* 568 */             minValue = Math.min(minValue, this.result.getValue(x + 1, y, z)); 
/* 569 */           if (y < this.sizeY - 1)
/* 570 */             minValue = Math.min(minValue, this.result.getValue(x, y + 1, z)); 
/* 571 */           if (z < this.sizeZ - 1) {
/* 572 */             minValue = Math.min(minValue, this.result.getValue(x, y, z + 1));
/*     */           }
/*     */           
/* 575 */           minValue = Math.max(minValue, this.mask.getValue(x, y, z));
/* 576 */           if (minValue < currentValue) {
/*     */             
/* 578 */             this.result.setValue(x, y, z, minValue);
/* 579 */             this.modif = true;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void backwardErosionFloatC26() {
/* 596 */     for (int z = this.sizeZ - 1; z >= 0; z--) {
/*     */       
/* 598 */       showProgress((this.sizeZ - 1 - z), this.sizeZ, "z = " + z);
/*     */       
/* 600 */       for (int y = this.sizeY - 1; y >= 0; y--) {
/*     */         
/* 602 */         for (int x = this.sizeX - 1; x >= 0; x--) {
/*     */           
/* 604 */           double currentValue = this.result.getValue(x, y, z);
/* 605 */           double minValue = currentValue;
/*     */ 
/*     */           
/* 608 */           int zmin = Math.max(z - 1, 0);
/* 609 */           for (int z2 = Math.min(z + 1, this.sizeZ - 1); z2 >= zmin; z2--) {
/*     */             
/* 611 */             int ymin = (z2 == z) ? y : Math.max(y - 1, 0);
/* 612 */             for (int y2 = Math.min(y + 1, this.sizeY - 1); y2 >= ymin; y2--) {
/*     */               
/* 614 */               int xmin = (z2 == z && y2 == y) ? x : Math.max(x - 1, 0);
/* 615 */               for (int x2 = Math.min(x + 1, this.sizeX - 1); x2 >= xmin; x2--)
/*     */               {
/* 617 */                 minValue = Math.min(minValue, this.result.getValue(x2, y2, z2));
/*     */               }
/*     */             } 
/*     */           } 
/*     */ 
/*     */           
/* 623 */           minValue = Math.max(minValue, this.mask.getValue(x, y, z));
/* 624 */           if (minValue < currentValue) {
/*     */             
/* 626 */             this.result.setValue(x, y, z, minValue);
/* 627 */             this.modif = true;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/morphology/geodrec/GeodesicReconstructionByErosion3DScanning.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */