/*     */ package inra.ijpb.morphology.strel;
/*     */ 
/*     */ import ij.process.ImageProcessor;
/*     */ import inra.ijpb.morphology.Strel;
/*     */ import inra.ijpb.morphology.Strel3D;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LinearDiagDownStrel
/*     */   extends AbstractInPlaceStrel
/*     */ {
/*     */   int size;
/*     */   int offset;
/*     */   
/*     */   public static final LinearDiagDownStrel fromDiameter(int diam) {
/*  46 */     return new LinearDiagDownStrel(diam);
/*     */   }
/*     */   
/*     */   public static final LinearDiagDownStrel fromRadius(int radius) {
/*  50 */     return new LinearDiagDownStrel(2 * radius + 1, radius);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LinearDiagDownStrel(int size) {
/*  78 */     if (size < 1) {
/*  79 */       throw new RuntimeException("Requires a positive size");
/*     */     }
/*  81 */     this.size = size;
/*     */     
/*  83 */     this.offset = (int)Math.floor(((this.size - 1) / 2));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LinearDiagDownStrel(int size, int offset) {
/*  93 */     if (size < 1) {
/*  94 */       throw new RuntimeException("Requires a positive size");
/*     */     }
/*  96 */     this.size = size;
/*     */     
/*  98 */     if (offset < 0) {
/*  99 */       throw new RuntimeException("Requires a non-negative offset");
/*     */     }
/* 101 */     if (offset >= size) {
/* 102 */       throw new RuntimeException("Offset can not be greater than size");
/*     */     }
/* 104 */     this.offset = offset;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void inPlaceDilation(ImageProcessor image) {
/* 117 */     if (this.size <= 1) {
/*     */       return;
/*     */     }
/*     */     
/* 121 */     if (image instanceof ij.process.ByteProcessor) {
/* 122 */       inPlaceDilationGray8(image);
/*     */     } else {
/* 124 */       inPlaceDilationFloat(image);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void inPlaceDilationGray8(ImageProcessor image) {
/* 129 */     int width = image.getWidth();
/* 130 */     int height = image.getHeight();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 135 */     int dmin = -(width - 1);
/* 136 */     int dmax = height - 1;
/*     */ 
/*     */     
/* 139 */     LocalExtremumBufferGray8 localMax = new LocalExtremumBufferGray8(this.size, 
/* 140 */         LocalExtremum.Type.MAXIMUM);
/*     */ 
/*     */     
/* 143 */     for (int d = dmin; d < dmax; d++) {
/* 144 */       fireProgressChanged(this, (d - dmin), (dmax - dmin));
/*     */ 
/*     */       
/* 147 */       localMax.fill(0);
/*     */       
/* 149 */       int xmin = Math.max(0, -d);
/* 150 */       int xmax = Math.min(width, height - d);
/* 151 */       int ymin = Math.max(0, d);
/* 152 */       int ymax = Math.min(height, d - width);
/*     */       
/* 154 */       int tmin = Math.max(xmin, d - ymin);
/* 155 */       int tmax = Math.min(xmax, d - ymax);
/*     */ 
/*     */       
/* 158 */       int t = tmin;
/*     */ 
/*     */       
/* 161 */       while (t < Math.min(tmin + this.offset, tmax)) {
/* 162 */         localMax.add(image.get(t, t + d));
/* 163 */         t++;
/*     */       } 
/*     */ 
/*     */       
/* 167 */       while (t < tmax) {
/* 168 */         localMax.add(image.get(t, t + d));
/* 169 */         int t2 = t - this.offset;
/* 170 */         image.set(t2, t2 + d, localMax.getMax());
/* 171 */         t++;
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 176 */       while (t < tmax + this.offset) {
/* 177 */         localMax.add(0);
/* 178 */         int x = t - this.offset;
/* 179 */         int y = t + d - this.offset;
/* 180 */         if (x >= 0 && y >= 0 && x < width && y < height)
/* 181 */           image.set(x, y, localMax.getMax()); 
/* 182 */         t++;
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 187 */     fireProgressChanged(this, (dmax - dmin), (dmax - dmin));
/*     */   }
/*     */ 
/*     */   
/*     */   private void inPlaceDilationFloat(ImageProcessor image) {
/* 192 */     int width = image.getWidth();
/* 193 */     int height = image.getHeight();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 198 */     int dmin = -(width - 1);
/* 199 */     int dmax = height - 1;
/*     */ 
/*     */     
/* 202 */     LocalExtremumBufferDouble localMax = new LocalExtremumBufferDouble(this.size, 
/* 203 */         LocalExtremum.Type.MAXIMUM);
/*     */ 
/*     */     
/* 206 */     for (int d = dmin; d < dmax; d++) {
/* 207 */       fireProgressChanged(this, (d - dmin), (dmax - dmin));
/*     */ 
/*     */       
/* 210 */       localMax.fill(Double.NEGATIVE_INFINITY);
/*     */       
/* 212 */       int xmin = Math.max(0, -d);
/* 213 */       int xmax = Math.min(width, height - d);
/* 214 */       int ymin = Math.max(0, d);
/* 215 */       int ymax = Math.min(height, d - width);
/*     */       
/* 217 */       int tmin = Math.max(xmin, d - ymin);
/* 218 */       int tmax = Math.min(xmax, d - ymax);
/*     */ 
/*     */       
/* 221 */       int t = tmin;
/*     */ 
/*     */       
/* 224 */       while (t < Math.min(tmin + this.offset, tmax)) {
/* 225 */         localMax.add(image.getf(t, t + d));
/* 226 */         t++;
/*     */       } 
/*     */ 
/*     */       
/* 230 */       while (t < tmax) {
/* 231 */         localMax.add(image.getf(t, t + d));
/* 232 */         int t2 = t - this.offset;
/* 233 */         image.setf(t2, t2 + d, (float)localMax.getMax());
/* 234 */         t++;
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 239 */       while (t < tmax + this.offset) {
/* 240 */         localMax.add(Double.NEGATIVE_INFINITY);
/* 241 */         int x = t - this.offset;
/* 242 */         int y = t + d - this.offset;
/* 243 */         if (x >= 0 && y >= 0 && x < width && y < height)
/* 244 */           image.setf(x, y, (float)localMax.getMax()); 
/* 245 */         t++;
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 250 */     fireProgressChanged(this, (dmax - dmin), (dmax - dmin));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void inPlaceErosion(ImageProcessor image) {
/* 259 */     if (this.size <= 1) {
/*     */       return;
/*     */     }
/*     */     
/* 263 */     if (image instanceof ij.process.ByteProcessor) {
/* 264 */       inPlaceErosionGray8(image);
/*     */     } else {
/* 266 */       inPlaceErosionFloat(image);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void inPlaceErosionGray8(ImageProcessor image) {
/* 271 */     int width = image.getWidth();
/* 272 */     int height = image.getHeight();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 277 */     int dmin = -(width - 1);
/* 278 */     int dmax = height - 1;
/*     */ 
/*     */     
/* 281 */     int dt0 = this.offset;
/*     */ 
/*     */     
/* 284 */     LocalExtremumBufferGray8 localMin = new LocalExtremumBufferGray8(this.size, 
/* 285 */         LocalExtremum.Type.MINIMUM);
/*     */ 
/*     */     
/* 288 */     for (int d = dmin; d < dmax; d++) {
/* 289 */       fireProgressChanged(this, (d - dmin), (dmax - dmin));
/*     */ 
/*     */       
/* 292 */       localMin.fill(255);
/*     */       
/* 294 */       int xmin = Math.max(0, -d);
/* 295 */       int xmax = Math.min(width, height - d);
/* 296 */       int ymin = Math.max(0, d);
/* 297 */       int ymax = Math.min(height, d - width);
/*     */       
/* 299 */       int tmin = Math.max(xmin, d - ymin);
/* 300 */       int tmax = Math.min(xmax, d - ymax);
/*     */ 
/*     */       
/* 303 */       int t = tmin;
/*     */ 
/*     */       
/* 306 */       while (t < Math.min(tmin + dt0, tmax)) {
/* 307 */         localMin.add(image.get(t, t + d));
/* 308 */         t++;
/*     */       } 
/*     */ 
/*     */       
/* 312 */       while (t < tmax) {
/* 313 */         localMin.add(image.get(t, t + d));
/* 314 */         image.set(t - dt0, t + d - dt0, localMin.getMax());
/* 315 */         t++;
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 320 */       while (t < tmax + dt0) {
/* 321 */         localMin.add(255);
/* 322 */         int x = t - dt0;
/* 323 */         int y = t + d - dt0;
/* 324 */         if (x >= 0 && y >= 0 && x < width && y < height)
/* 325 */           image.set(x, y, localMin.getMax()); 
/* 326 */         t++;
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 331 */     fireProgressChanged(this, (dmax - dmin), (dmax - dmin));
/*     */   }
/*     */ 
/*     */   
/*     */   private void inPlaceErosionFloat(ImageProcessor image) {
/* 336 */     int width = image.getWidth();
/* 337 */     int height = image.getHeight();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 342 */     int dmin = -(width - 1);
/* 343 */     int dmax = height - 1;
/*     */ 
/*     */     
/* 346 */     int dt0 = this.offset;
/*     */ 
/*     */     
/* 349 */     LocalExtremumBufferDouble localMin = new LocalExtremumBufferDouble(this.size, 
/* 350 */         LocalExtremum.Type.MINIMUM);
/*     */ 
/*     */     
/* 353 */     for (int d = dmin; d < dmax; d++) {
/* 354 */       fireProgressChanged(this, (d - dmin), (dmax - dmin));
/*     */ 
/*     */       
/* 357 */       localMin.fill(Double.POSITIVE_INFINITY);
/*     */       
/* 359 */       int xmin = Math.max(0, -d);
/* 360 */       int xmax = Math.min(width, height - d);
/* 361 */       int ymin = Math.max(0, d);
/* 362 */       int ymax = Math.min(height, d - width);
/*     */       
/* 364 */       int tmin = Math.max(xmin, d - ymin);
/* 365 */       int tmax = Math.min(xmax, d - ymax);
/*     */ 
/*     */       
/* 368 */       int t = tmin;
/*     */ 
/*     */       
/* 371 */       while (t < Math.min(tmin + dt0, tmax)) {
/* 372 */         localMin.add(image.getf(t, t + d));
/* 373 */         t++;
/*     */       } 
/*     */ 
/*     */       
/* 377 */       while (t < tmax) {
/* 378 */         localMin.add(image.getf(t, t + d));
/* 379 */         image.setf(t - dt0, t + d - dt0, (float)localMin.getMax());
/* 380 */         t++;
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 385 */       while (t < tmax + dt0) {
/* 386 */         localMin.add(Double.POSITIVE_INFINITY);
/* 387 */         int x = t - dt0;
/* 388 */         int y = t + d - dt0;
/* 389 */         if (x >= 0 && y >= 0 && x < width && y < height)
/* 390 */           image.setf(x, y, (float)localMin.getMax()); 
/* 391 */         t++;
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 396 */     fireProgressChanged(this, (dmax - dmin), (dmax - dmin));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int[][] getMask() {
/* 404 */     int[][] mask = new int[this.size][this.size];
/* 405 */     for (int i = 0; i < this.size; i++) {
/* 406 */       mask[i][i] = 255;
/*     */     }
/*     */     
/* 409 */     return mask;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int[] getOffset() {
/* 417 */     return new int[] { this.offset, this.offset };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int[][] getShifts() {
/* 425 */     int[][] shifts = new int[this.size][2];
/* 426 */     for (int i = 0; i < this.size; i++) {
/* 427 */       shifts[i][0] = i - this.offset;
/* 428 */       shifts[i][1] = i - this.offset;
/*     */     } 
/* 430 */     return shifts;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int[] getSize() {
/* 438 */     return new int[] { this.size, this.size };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LinearDiagDownStrel reverse() {
/* 447 */     return new LinearDiagDownStrel(this.size, this.size - this.offset - 1);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/morphology/strel/LinearDiagDownStrel.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */