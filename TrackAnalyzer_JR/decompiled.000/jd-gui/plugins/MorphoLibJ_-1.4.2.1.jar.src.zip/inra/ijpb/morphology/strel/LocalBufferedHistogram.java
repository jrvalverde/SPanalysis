/*     */ package inra.ijpb.morphology.strel;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LocalBufferedHistogram
/*     */ {
/*  41 */   int[] counts = new int[256];
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  46 */   int minValue = Integer.MAX_VALUE;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  51 */   int maxValue = Integer.MIN_VALUE;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int[] buffer;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  61 */   int bufferIndex = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LocalBufferedHistogram(int n) {
/*  71 */     this.counts[0] = n;
/*     */     
/*  73 */     this.buffer = new int[n];
/*  74 */     for (int i = 0; i < n; i++) {
/*  75 */       this.buffer[i] = 0;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LocalBufferedHistogram(int n, int value) {
/*  88 */     this.counts[n] = value;
/*     */     
/*  90 */     this.buffer = new int[n];
/*  91 */     for (int i = 0; i < n; i++) {
/*  92 */       this.buffer[i] = value;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void add(int value) {
/* 105 */     this.counts[value] = this.counts[value] + 1;
/*     */ 
/*     */     
/* 108 */     if (value > this.maxValue) {
/*     */       
/* 110 */       this.maxValue = value;
/* 111 */     } else if (value < this.minValue) {
/*     */       
/* 113 */       this.minValue = value;
/*     */     } 
/*     */ 
/*     */     
/* 117 */     remove(this.buffer[this.bufferIndex]);
/*     */ 
/*     */     
/* 120 */     this.buffer[this.bufferIndex] = value;
/* 121 */     this.bufferIndex = ++this.bufferIndex % this.buffer.length;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void remove(int value) {
/* 133 */     if (this.counts[value] <= 0)
/*     */     {
/* 135 */       throw new IllegalArgumentException("Can not remove a value not present in histogram: " + value);
/*     */     }
/*     */ 
/*     */     
/* 139 */     this.counts[value] = this.counts[value] - 1;
/*     */ 
/*     */     
/* 142 */     if (value == this.maxValue) {
/*     */       
/* 144 */       updateMaxValue();
/* 145 */     } else if (value == this.minValue) {
/*     */       
/* 147 */       updateMinValue();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void updateMinValue() {
/* 154 */     for (int i = 0; i < 256; i++) {
/*     */       
/* 156 */       if (this.counts[i] > 0) {
/*     */         
/* 158 */         this.minValue = i;
/*     */         
/*     */         return;
/*     */       } 
/*     */     } 
/* 163 */     throw new RuntimeException("Can not find minimum value in an empty histogram");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void updateMaxValue() {
/* 169 */     for (int i = 255; i >= 0; i--) {
/*     */       
/* 171 */       if (this.counts[i] > 0) {
/*     */         
/* 173 */         this.maxValue = i;
/*     */         return;
/*     */       } 
/*     */     } 
/* 177 */     throw new RuntimeException("Can not find maximum value in an empty histogram");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void clear() {
/* 185 */     fill(0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void fill(int value) {
/* 197 */     int n = this.buffer.length;
/*     */     
/*     */     int i;
/* 200 */     for (i = 0; i < 256; i++)
/*     */     {
/* 202 */       this.counts[i] = 0;
/*     */     }
/* 204 */     this.counts[value] = n;
/*     */ 
/*     */     
/* 207 */     for (i = 0; i < n; i++) {
/* 208 */       this.buffer[i] = value;
/*     */     }
/*     */     
/* 211 */     this.minValue = value;
/* 212 */     this.maxValue = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMin() {
/* 222 */     return this.minValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMax() {
/* 232 */     return this.maxValue;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/morphology/strel/LocalBufferedHistogram.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */