/*     */ package inra.ijpb.morphology.geodrec;
/*     */ 
/*     */ import ij.IJ;
/*     */ import inra.ijpb.algo.AlgoStub;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class GeodesicReconstruction3DAlgoStub
/*     */   extends AlgoStub
/*     */   implements GeodesicReconstruction3DAlgo
/*     */ {
/*  46 */   protected int connectivity = 6;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean verbose = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean showStatus = true;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean showProgress = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getConnectivity() {
/*  70 */     return this.connectivity;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setConnectivity(int conn) {
/*  79 */     this.connectivity = conn;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void showStatus(String status) {
/*  91 */     fireStatusChanged(this, status);
/*     */     
/*  93 */     if (this.showStatus)
/*     */     {
/*  95 */       IJ.showStatus(status);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void showProgress(double current, double max) {
/* 110 */     fireProgressChanged(this, current, max);
/* 111 */     if (this.showProgress)
/*     */     {
/* 113 */       IJ.showProgress(current / max);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void showProgress(double current, double max, String msg) {
/* 130 */     fireProgressChanged(this, current, max);
/* 131 */     if (this.showProgress) {
/*     */       
/* 133 */       IJ.showProgress(current / max);
/* 134 */       if (msg != null && !msg.isEmpty())
/*     */       {
/* 136 */         trace(msg);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void trace(String traceMessage) {
/* 151 */     if (this.verbose)
/*     */     {
/* 153 */       System.out.println(traceMessage);
/*     */     }
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/morphology/geodrec/GeodesicReconstruction3DAlgoStub.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */