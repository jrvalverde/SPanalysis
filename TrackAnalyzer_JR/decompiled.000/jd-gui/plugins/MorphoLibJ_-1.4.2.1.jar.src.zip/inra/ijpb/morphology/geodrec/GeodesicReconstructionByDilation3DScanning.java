/*     */ package inra.ijpb.morphology.geodrec;
/*     */ 
/*     */ import ij.ImageStack;
/*     */ import inra.ijpb.data.image.Image3D;
/*     */ import inra.ijpb.data.image.Images3D;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GeodesicReconstructionByDilation3DScanning
/*     */   extends GeodesicReconstruction3DAlgoStub
/*     */ {
/*     */   ImageStack markerStack;
/*     */   ImageStack maskStack;
/*     */   ImageStack resultStack;
/*     */   Image3D result;
/*     */   Image3D mask;
/*     */   Image3D marker;
/*  64 */   int sizeX = 0;
/*     */   
/*  66 */   int sizeY = 0;
/*     */   
/*  68 */   int sizeZ = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean modif;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GeodesicReconstructionByDilation3DScanning() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GeodesicReconstructionByDilation3DScanning(int connectivity) {
/*  94 */     this.connectivity = connectivity;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ImageStack applyTo(ImageStack marker, ImageStack mask) {
/* 111 */     this.markerStack = marker;
/* 112 */     this.maskStack = mask;
/*     */     
/* 114 */     this.marker = Images3D.createWrapper(marker);
/* 115 */     this.mask = Images3D.createWrapper(mask);
/*     */ 
/*     */     
/* 118 */     this.sizeX = marker.getWidth();
/* 119 */     this.sizeY = marker.getHeight();
/* 120 */     this.sizeZ = marker.getSize();
/* 121 */     if (!Images3D.isSameSize(marker, mask))
/*     */     {
/* 123 */       throw new IllegalArgumentException("Marker and Mask images must have the same size");
/*     */     }
/*     */ 
/*     */     
/* 127 */     if (this.connectivity != 6 && this.connectivity != 26)
/*     */     {
/* 129 */       throw new RuntimeException(
/* 130 */           "Connectivity for stacks must be either 6 or 26, not " + 
/* 131 */           this.connectivity);
/*     */     }
/*     */     
/* 134 */     initializeResult();
/*     */     
/* 136 */     boolean integerStack = (marker.getBitDepth() != 32);
/*     */ 
/*     */     
/* 139 */     int iter = 1;
/*     */ 
/*     */ 
/*     */     
/*     */     do {
/* 144 */       this.modif = false;
/*     */ 
/*     */       
/* 147 */       trace("Forward iteration " + iter);
/* 148 */       showStatus("Geod. Rec. by Dil. Fwd " + iter);
/*     */       
/* 150 */       if (integerStack) {
/*     */         
/* 152 */         forwardDilationInt();
/*     */       }
/*     */       else {
/*     */         
/* 156 */         forwardDilationFloat();
/*     */       } 
/*     */ 
/*     */       
/* 160 */       trace("Backward iteration " + iter);
/* 161 */       showStatus("Geod. Rec. by Dil. Bwd " + iter);
/*     */       
/* 163 */       if (integerStack) {
/*     */         
/* 165 */         backwardDilationInt();
/*     */       }
/*     */       else {
/*     */         
/* 169 */         backwardDilationFloat();
/*     */       } 
/*     */       
/* 172 */       iter++;
/* 173 */     } while (this.modif);
/*     */ 
/*     */     
/* 176 */     showProgress(1.0D, 1.0D, "");
/*     */     
/* 178 */     return this.resultStack;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ImageStack applyTo(ImageStack marker, ImageStack mask, ImageStack binaryMask) {
/* 198 */     throw new RuntimeException("Method not yet implemented");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void initializeResult() {
/* 209 */     this.resultStack = ImageStack.create(this.sizeX, this.sizeY, this.sizeZ, this.maskStack.getBitDepth());
/* 210 */     this.result = Images3D.createWrapper(this.resultStack);
/*     */ 
/*     */ 
/*     */     
/* 214 */     if (this.maskStack.getBitDepth() == 32) {
/*     */ 
/*     */       
/* 217 */       for (int z = 0; z < this.sizeZ; z++)
/*     */       {
/* 219 */         for (int y = 0; y < this.sizeY; y++)
/*     */         {
/* 221 */           for (int x = 0; x < this.sizeX; x++)
/*     */           {
/* 223 */             this.result.setValue(x, y, z, Math.min(this.marker.getValue(x, y, z), this.mask.getValue(x, y, z)));
/*     */           }
/*     */         }
/*     */       
/*     */       }
/*     */     
/*     */     } else {
/*     */       
/* 231 */       for (int z = 0; z < this.sizeZ; z++) {
/*     */         
/* 233 */         for (int y = 0; y < this.sizeY; y++) {
/*     */           
/* 235 */           for (int x = 0; x < this.sizeX; x++)
/*     */           {
/* 237 */             this.result.set(x, y, z, Math.min(this.marker.get(x, y, z), this.mask.get(x, y, z)));
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void forwardDilationInt() {
/* 246 */     if (this.connectivity == 6) {
/*     */       
/* 248 */       forwardDilationIntC6();
/*     */     }
/*     */     else {
/*     */       
/* 252 */       forwardDilationIntC26();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void forwardDilationIntC6() {
/* 266 */     for (int z = 0; z < this.sizeZ; z++) {
/*     */       
/* 268 */       showProgress(z, this.sizeZ);
/*     */       
/* 270 */       for (int y = 0; y < this.sizeY; y++) {
/*     */         
/* 272 */         for (int x = 0; x < this.sizeX; x++) {
/*     */           
/* 274 */           int currentValue = this.result.get(x, y, z);
/* 275 */           int maxValue = currentValue;
/*     */ 
/*     */           
/* 278 */           if (x > 0)
/* 279 */             maxValue = Math.max(maxValue, this.result.get(x - 1, y, z)); 
/* 280 */           if (y > 0)
/* 281 */             maxValue = Math.max(maxValue, this.result.get(x, y - 1, z)); 
/* 282 */           if (z > 0) {
/* 283 */             maxValue = Math.max(maxValue, this.result.get(x, y, z - 1));
/*     */           }
/*     */ 
/*     */           
/* 287 */           maxValue = Math.min(maxValue, this.mask.get(x, y, z));
/* 288 */           if (maxValue > currentValue) {
/* 289 */             this.result.set(x, y, z, maxValue);
/* 290 */             this.modif = true;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void forwardDilationIntC26() {
/* 307 */     for (int z = 0; z < this.sizeZ; z++) {
/*     */       
/* 309 */       showProgress(z, this.sizeZ, "z = " + z);
/*     */       
/* 311 */       for (int y = 0; y < this.sizeY; y++) {
/*     */         
/* 313 */         for (int x = 0; x < this.sizeX; x++) {
/*     */           
/* 315 */           int currentValue = this.result.get(x, y, z);
/* 316 */           int maxValue = currentValue;
/*     */ 
/*     */           
/* 319 */           int zmax = Math.min(z + 1, this.sizeZ);
/* 320 */           for (int z2 = Math.max(z - 1, 0); z2 < zmax; z2++) {
/*     */             
/* 322 */             int ymax = (z2 == z) ? y : Math.min(y + 1, this.sizeY - 1);
/* 323 */             for (int y2 = Math.max(y - 1, 0); y2 <= ymax; y2++) {
/*     */               
/* 325 */               int xmax = (z2 == z && y2 == y) ? (x - 1) : Math.min(x + 1, this.sizeX - 1);
/* 326 */               for (int x2 = Math.max(x - 1, 0); x2 <= xmax; x2++) {
/* 327 */                 maxValue = Math.max(maxValue, this.result.get(x2, y2, z2));
/*     */               }
/*     */             } 
/*     */           } 
/*     */ 
/*     */           
/* 333 */           maxValue = Math.min(maxValue, this.mask.get(x, y, z));
/* 334 */           if (maxValue > currentValue) {
/* 335 */             this.result.set(x, y, z, maxValue);
/* 336 */             this.modif = true;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void forwardDilationFloat() {
/* 345 */     if (this.connectivity == 6) {
/*     */       
/* 347 */       forwardDilationFloatC6();
/*     */     }
/*     */     else {
/*     */       
/* 351 */       forwardDilationFloatC26();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void forwardDilationFloatC6() {
/* 365 */     for (int z = 0; z < this.sizeZ; z++) {
/*     */       
/* 367 */       showProgress(z, this.sizeZ, "z = " + z);
/*     */       
/* 369 */       for (int y = 0; y < this.sizeY; y++) {
/*     */         
/* 371 */         for (int x = 0; x < this.sizeX; x++) {
/*     */           
/* 373 */           double currentValue = this.result.getValue(x, y, z);
/* 374 */           double maxValue = currentValue;
/*     */ 
/*     */           
/* 377 */           if (x > 0)
/* 378 */             maxValue = Math.max(maxValue, this.result.getValue(x - 1, y, z)); 
/* 379 */           if (y > 0)
/* 380 */             maxValue = Math.max(maxValue, this.result.getValue(x, y - 1, z)); 
/* 381 */           if (z > 0) {
/* 382 */             maxValue = Math.max(maxValue, this.result.getValue(x, y, z - 1));
/*     */           }
/*     */ 
/*     */           
/* 386 */           maxValue = Math.min(maxValue, this.mask.getValue(x, y, z));
/* 387 */           if (maxValue > currentValue) {
/*     */             
/* 389 */             this.result.setValue(x, y, z, maxValue);
/* 390 */             this.modif = true;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void forwardDilationFloatC26() {
/* 407 */     for (int z = 0; z < this.sizeZ; z++) {
/*     */       
/* 409 */       showProgress((z + 1), this.sizeZ, "z = " + z);
/*     */       
/* 411 */       for (int y = 0; y < this.sizeY; y++) {
/*     */         
/* 413 */         for (int x = 0; x < this.sizeX; x++) {
/*     */           
/* 415 */           double currentValue = this.result.getValue(x, y, z);
/* 416 */           double maxValue = currentValue;
/*     */ 
/*     */           
/* 419 */           int zmax = Math.min(z + 1, this.sizeZ);
/* 420 */           for (int z2 = Math.max(z - 1, 0); z2 < zmax; z2++) {
/*     */             
/* 422 */             int ymax = (z2 == z) ? y : Math.min(y + 1, this.sizeY - 1);
/* 423 */             for (int y2 = Math.max(y - 1, 0); y2 <= ymax; y2++) {
/*     */               
/* 425 */               int xmax = (z2 == z && y2 == y) ? (x - 1) : Math.min(x + 1, this.sizeX - 1);
/* 426 */               for (int x2 = Math.max(x - 1, 0); x2 <= xmax; x2++)
/*     */               {
/* 428 */                 maxValue = Math.max(maxValue, this.result.getValue(x2, y2, z2));
/*     */               }
/*     */             } 
/*     */           } 
/*     */ 
/*     */           
/* 434 */           maxValue = Math.min(maxValue, this.mask.getValue(x, y, z));
/* 435 */           if (maxValue > currentValue) {
/* 436 */             this.result.setValue(x, y, z, maxValue);
/* 437 */             this.modif = true;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void backwardDilationInt() {
/* 446 */     if (this.connectivity == 6) {
/*     */       
/* 448 */       backwardDilationIntC6();
/*     */     }
/*     */     else {
/*     */       
/* 452 */       backwardDilationIntC26();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void backwardDilationIntC6() {
/* 466 */     for (int z = this.sizeZ - 1; z >= 0; z--) {
/*     */       
/* 468 */       showProgress((this.sizeZ - z), this.sizeZ, "z = " + z);
/*     */       
/* 470 */       for (int y = this.sizeY - 1; y >= 0; y--) {
/*     */         
/* 472 */         for (int x = this.sizeX - 1; x >= 0; x--) {
/*     */           
/* 474 */           int currentValue = this.result.get(x, y, z);
/* 475 */           int maxValue = currentValue;
/*     */ 
/*     */           
/* 478 */           if (x < this.sizeX - 1)
/* 479 */             maxValue = Math.max(maxValue, this.result.get(x + 1, y, z)); 
/* 480 */           if (y < this.sizeY - 1)
/* 481 */             maxValue = Math.max(maxValue, this.result.get(x, y + 1, z)); 
/* 482 */           if (z < this.sizeZ - 1) {
/* 483 */             maxValue = Math.max(maxValue, this.result.get(x, y, z + 1));
/*     */           }
/*     */ 
/*     */           
/* 487 */           maxValue = Math.min(maxValue, this.mask.get(x, y, z));
/* 488 */           if (maxValue > currentValue) {
/*     */             
/* 490 */             this.result.set(x, y, z, maxValue);
/* 491 */             this.modif = true;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void backwardDilationIntC26() {
/* 508 */     for (int z = this.sizeZ - 1; z >= 0; z--) {
/*     */       
/* 510 */       showProgress((this.sizeZ - z), this.sizeZ, "z = " + z);
/*     */       
/* 512 */       for (int y = this.sizeY - 1; y >= 0; y--) {
/*     */         
/* 514 */         for (int x = this.sizeX - 1; x >= 0; x--) {
/*     */           
/* 516 */           int currentValue = this.result.get(x, y, z);
/* 517 */           int maxValue = currentValue;
/*     */ 
/*     */           
/* 520 */           int zmin = Math.max(z - 1, 0);
/* 521 */           for (int z2 = Math.min(z + 1, this.sizeZ - 1); z2 >= zmin; z2--) {
/*     */ 
/*     */             
/* 524 */             int ymin = (z2 == z) ? y : Math.max(y - 1, 0);
/* 525 */             for (int y2 = Math.min(y + 1, this.sizeY - 1); y2 >= ymin; y2--) {
/*     */               
/* 527 */               int xmin = (z2 == z && y2 == y) ? x : Math.max(x - 1, 0);
/* 528 */               for (int x2 = Math.min(x + 1, this.sizeX - 1); x2 >= xmin; x2--)
/*     */               {
/* 530 */                 maxValue = Math.max(maxValue, this.result.get(x2, y2, z2));
/*     */               }
/*     */             } 
/*     */           } 
/*     */ 
/*     */           
/* 536 */           maxValue = Math.min(maxValue, this.mask.get(x, y, z));
/* 537 */           if (maxValue > currentValue) {
/*     */             
/* 539 */             this.result.set(x, y, z, maxValue);
/* 540 */             this.modif = true;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void backwardDilationFloat() {
/* 549 */     if (this.connectivity == 6) {
/*     */       
/* 551 */       backwardDilationFloatC6();
/*     */     }
/*     */     else {
/*     */       
/* 555 */       backwardDilationFloatC26();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void backwardDilationFloatC6() {
/* 569 */     for (int z = this.sizeZ - 1; z >= 0; z--) {
/*     */       
/* 571 */       showProgress((this.sizeZ - 1 - z), this.sizeZ, "z = " + z);
/*     */       
/* 573 */       for (int y = this.sizeY - 1; y >= 0; y--) {
/*     */         
/* 575 */         for (int x = this.sizeX - 1; x >= 0; x--) {
/*     */           
/* 577 */           double currentValue = this.result.getValue(x, y, z);
/* 578 */           double maxValue = currentValue;
/*     */ 
/*     */           
/* 581 */           if (x < this.sizeX - 1)
/* 582 */             maxValue = Math.max(maxValue, this.result.getValue(x + 1, y, z)); 
/* 583 */           if (y < this.sizeY - 1)
/* 584 */             maxValue = Math.max(maxValue, this.result.getValue(x, y + 1, z)); 
/* 585 */           if (z < this.sizeZ - 1) {
/* 586 */             maxValue = Math.max(maxValue, this.result.getValue(x, y, z + 1));
/*     */           }
/*     */           
/* 589 */           maxValue = Math.min(maxValue, this.mask.getValue(x, y, z));
/* 590 */           if (maxValue > currentValue) {
/*     */             
/* 592 */             this.result.setValue(x, y, z, maxValue);
/* 593 */             this.modif = true;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void backwardDilationFloatC26() {
/* 610 */     for (int z = this.sizeZ - 1; z >= 0; z--) {
/*     */       
/* 612 */       showProgress((this.sizeZ - 1 - z), this.sizeZ, "z = " + z);
/*     */       
/* 614 */       for (int y = this.sizeY - 1; y >= 0; y--) {
/*     */         
/* 616 */         for (int x = this.sizeX - 1; x >= 0; x--) {
/*     */           
/* 618 */           double currentValue = this.result.getValue(x, y, z);
/* 619 */           double maxValue = currentValue;
/*     */ 
/*     */           
/* 622 */           int zmin = Math.max(z - 1, 0);
/* 623 */           for (int z2 = Math.min(z + 1, this.sizeZ - 1); z2 >= zmin; z2--) {
/*     */ 
/*     */             
/* 626 */             int ymin = (z2 == z) ? y : Math.max(y - 1, 0);
/* 627 */             for (int y2 = Math.min(y + 1, this.sizeY - 1); y2 >= ymin; y2--) {
/*     */               
/* 629 */               int xmin = (z2 == z && y2 == y) ? x : Math.max(x - 1, 0);
/* 630 */               for (int x2 = Math.min(x + 1, this.sizeX - 1); x2 >= xmin; x2--)
/*     */               {
/* 632 */                 maxValue = Math.max(maxValue, this.result.getValue(x2, y2, z2));
/*     */               }
/*     */             } 
/*     */           } 
/*     */ 
/*     */           
/* 638 */           maxValue = Math.min(maxValue, this.mask.getValue(x, y, z));
/* 639 */           if (maxValue > currentValue) {
/*     */             
/* 641 */             this.result.setValue(x, y, z, maxValue);
/* 642 */             this.modif = true;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/morphology/geodrec/GeodesicReconstructionByDilation3DScanning.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */