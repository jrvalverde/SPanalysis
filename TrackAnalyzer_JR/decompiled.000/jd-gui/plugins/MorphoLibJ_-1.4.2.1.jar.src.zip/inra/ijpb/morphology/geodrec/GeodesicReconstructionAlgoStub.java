/*    */ package inra.ijpb.morphology.geodrec;
/*    */ 
/*    */ import inra.ijpb.algo.AlgoStub;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class GeodesicReconstructionAlgoStub
/*    */   extends AlgoStub
/*    */   implements GeodesicReconstructionAlgo
/*    */ {
/* 38 */   protected int connectivity = 4;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean verbose = false;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean showStatus = true;
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean showProgress = false;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int getConnectivity() {
/* 62 */     return this.connectivity;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setConnectivity(int conn) {
/* 71 */     this.connectivity = conn;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/morphology/geodrec/GeodesicReconstructionAlgoStub.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */