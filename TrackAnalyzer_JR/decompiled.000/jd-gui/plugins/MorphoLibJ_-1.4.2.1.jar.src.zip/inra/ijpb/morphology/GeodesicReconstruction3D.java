/*     */ package inra.ijpb.morphology;
/*     */ 
/*     */ import ij.ImageStack;
/*     */ import inra.ijpb.algo.Algo;
/*     */ import inra.ijpb.algo.DefaultAlgoListener;
/*     */ import inra.ijpb.morphology.geodrec.GeodesicReconstruction3DHybrid0Float;
/*     */ import inra.ijpb.morphology.geodrec.GeodesicReconstruction3DHybrid0Gray16;
/*     */ import inra.ijpb.morphology.geodrec.GeodesicReconstruction3DHybrid0Gray8;
/*     */ import inra.ijpb.morphology.geodrec.GeodesicReconstructionByDilation3DScanning;
/*     */ import inra.ijpb.morphology.geodrec.GeodesicReconstructionByDilation3DScanningGray8;
/*     */ import inra.ijpb.morphology.geodrec.GeodesicReconstructionByErosion3DScanning;
/*     */ import inra.ijpb.morphology.geodrec.GeodesicReconstructionType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public abstract class GeodesicReconstruction3D
/*     */ {
/*     */   public static final ImageStack killBorders(ImageStack image) {
/*  69 */     int width = image.getWidth();
/*  70 */     int height = image.getHeight();
/*  71 */     int depth = image.getSize();
/*     */ 
/*     */     
/*  74 */     ImageStack markers = image.duplicate();
/*  75 */     for (int z = 1; z < depth - 1; z++) {
/*     */       
/*  77 */       for (int y = 1; y < height - 1; y++) {
/*     */         
/*  79 */         for (int x = 1; x < width - 1; x++)
/*     */         {
/*  81 */           markers.setVoxel(x, y, z, 0.0D);
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/*  86 */     ImageStack result = reconstructByDilation(markers, image);
/*     */ 
/*     */     
/*  89 */     for (int i = 0; i < depth; i++) {
/*     */       
/*  91 */       for (int y = 0; y < height; y++) {
/*     */         
/*  93 */         for (int x = 0; x < width; x++) {
/*     */           
/*  95 */           double val = image.getVoxel(x, y, i) - result.getVoxel(x, y, i);
/*  96 */           result.setVoxel(x, y, i, Math.max(val, 0.0D));
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 101 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final ImageStack fillHoles(ImageStack image) {
/* 117 */     int width = image.getWidth();
/* 118 */     int height = image.getHeight();
/* 119 */     int depth = image.getSize();
/*     */ 
/*     */     
/* 122 */     ImageStack markers = image.duplicate();
/* 123 */     for (int z = 1; z < depth - 1; z++) {
/*     */       
/* 125 */       for (int y = 1; y < height - 1; y++) {
/*     */         
/* 127 */         for (int x = 1; x < width - 1; x++)
/*     */         {
/* 129 */           markers.setVoxel(x, y, z, 3.4028234663852886E38D);
/*     */         }
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 135 */     return reconstructByErosion(markers, image);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final ImageStack reconstructByDilation(ImageStack marker, ImageStack mask) {
/*     */     GeodesicReconstructionByDilation3DScanning geodesicReconstructionByDilation3DScanning;
/* 150 */     if (marker.getBitDepth() == 8 && mask.getBitDepth() == 8) {
/*     */       
/* 152 */       GeodesicReconstruction3DHybrid0Gray8 geodesicReconstruction3DHybrid0Gray8 = new GeodesicReconstruction3DHybrid0Gray8(
/* 153 */           GeodesicReconstructionType.BY_DILATION);
/*     */     }
/* 155 */     else if (marker.getBitDepth() == 16 && mask.getBitDepth() == 16) {
/*     */       
/* 157 */       GeodesicReconstruction3DHybrid0Gray16 geodesicReconstruction3DHybrid0Gray16 = new GeodesicReconstruction3DHybrid0Gray16(
/* 158 */           GeodesicReconstructionType.BY_DILATION);
/*     */     }
/* 160 */     else if (marker.getBitDepth() == 32 && mask.getBitDepth() == 32) {
/*     */       
/* 162 */       GeodesicReconstruction3DHybrid0Float geodesicReconstruction3DHybrid0Float = new GeodesicReconstruction3DHybrid0Float(
/* 163 */           GeodesicReconstructionType.BY_DILATION);
/*     */     }
/*     */     else {
/*     */       
/* 167 */       geodesicReconstructionByDilation3DScanning = new GeodesicReconstructionByDilation3DScanning();
/*     */     } 
/*     */     
/* 170 */     DefaultAlgoListener.monitor((Algo)geodesicReconstructionByDilation3DScanning);
/* 171 */     return geodesicReconstructionByDilation3DScanning.applyTo(marker, mask);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final ImageStack reconstructByDilation(ImageStack marker, ImageStack mask, int connectivity) {
/*     */     GeodesicReconstructionByDilation3DScanning geodesicReconstructionByDilation3DScanning;
/* 187 */     if (marker.getBitDepth() == 8 && mask.getBitDepth() == 8) {
/*     */       
/* 189 */       GeodesicReconstruction3DHybrid0Gray8 geodesicReconstruction3DHybrid0Gray8 = new GeodesicReconstruction3DHybrid0Gray8(
/* 190 */           GeodesicReconstructionType.BY_DILATION, connectivity);
/*     */     }
/* 192 */     else if (marker.getBitDepth() == 16 && mask.getBitDepth() == 16) {
/*     */       
/* 194 */       GeodesicReconstruction3DHybrid0Gray16 geodesicReconstruction3DHybrid0Gray16 = new GeodesicReconstruction3DHybrid0Gray16(
/* 195 */           GeodesicReconstructionType.BY_DILATION, connectivity);
/*     */     }
/* 197 */     else if (marker.getBitDepth() == 32 && mask.getBitDepth() == 32) {
/*     */       
/* 199 */       GeodesicReconstruction3DHybrid0Float geodesicReconstruction3DHybrid0Float = new GeodesicReconstruction3DHybrid0Float(
/* 200 */           GeodesicReconstructionType.BY_DILATION, connectivity);
/*     */     }
/*     */     else {
/*     */       
/* 204 */       geodesicReconstructionByDilation3DScanning = new GeodesicReconstructionByDilation3DScanning(connectivity);
/*     */     } 
/*     */     
/* 207 */     DefaultAlgoListener.monitor((Algo)geodesicReconstructionByDilation3DScanning);
/* 208 */     return geodesicReconstructionByDilation3DScanning.applyTo(marker, mask);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final ImageStack reconstructByDilation(ImageStack marker, ImageStack mask, int connectivity, ImageStack binaryMask) {
/* 228 */     GeodesicReconstructionByDilation3DScanningGray8 geodesicReconstructionByDilation3DScanningGray8 = new GeodesicReconstructionByDilation3DScanningGray8(
/* 229 */         connectivity);
/* 230 */     DefaultAlgoListener.monitor((Algo)geodesicReconstructionByDilation3DScanningGray8);
/* 231 */     return geodesicReconstructionByDilation3DScanningGray8.applyTo(marker, mask, binaryMask);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final ImageStack reconstructByErosion(ImageStack marker, ImageStack mask) {
/*     */     GeodesicReconstructionByErosion3DScanning geodesicReconstructionByErosion3DScanning;
/* 247 */     if (marker.getBitDepth() == 8 && mask.getBitDepth() == 8) {
/*     */       
/* 249 */       GeodesicReconstruction3DHybrid0Gray8 geodesicReconstruction3DHybrid0Gray8 = new GeodesicReconstruction3DHybrid0Gray8(
/* 250 */           GeodesicReconstructionType.BY_EROSION);
/*     */     
/*     */     }
/* 253 */     else if (marker.getBitDepth() == 16 && mask.getBitDepth() == 16) {
/*     */       
/* 255 */       GeodesicReconstruction3DHybrid0Gray16 geodesicReconstruction3DHybrid0Gray16 = new GeodesicReconstruction3DHybrid0Gray16(
/* 256 */           GeodesicReconstructionType.BY_EROSION);
/*     */     
/*     */     }
/* 259 */     else if (marker.getBitDepth() == 32 && mask.getBitDepth() == 32) {
/*     */       
/* 261 */       GeodesicReconstruction3DHybrid0Float geodesicReconstruction3DHybrid0Float = new GeodesicReconstruction3DHybrid0Float(
/* 262 */           GeodesicReconstructionType.BY_EROSION);
/*     */     }
/*     */     else {
/*     */       
/* 266 */       geodesicReconstructionByErosion3DScanning = new GeodesicReconstructionByErosion3DScanning();
/*     */     } 
/*     */     
/* 269 */     DefaultAlgoListener.monitor((Algo)geodesicReconstructionByErosion3DScanning);
/* 270 */     return geodesicReconstructionByErosion3DScanning.applyTo(marker, mask);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final ImageStack reconstructByErosion(ImageStack marker, ImageStack mask, int connectivity) {
/*     */     GeodesicReconstructionByErosion3DScanning geodesicReconstructionByErosion3DScanning;
/* 286 */     if (Thread.currentThread().isInterrupted()) {
/* 287 */       return null;
/*     */     }
/*     */     
/* 290 */     if (marker.getBitDepth() == 8 && mask.getBitDepth() == 8) {
/*     */       
/* 292 */       GeodesicReconstruction3DHybrid0Gray8 geodesicReconstruction3DHybrid0Gray8 = new GeodesicReconstruction3DHybrid0Gray8(
/* 293 */           GeodesicReconstructionType.BY_EROSION, connectivity);
/*     */     }
/* 295 */     else if (marker.getBitDepth() == 16 && mask.getBitDepth() == 16) {
/*     */       
/* 297 */       GeodesicReconstruction3DHybrid0Gray16 geodesicReconstruction3DHybrid0Gray16 = new GeodesicReconstruction3DHybrid0Gray16(
/* 298 */           GeodesicReconstructionType.BY_EROSION, connectivity);
/*     */     }
/* 300 */     else if (marker.getBitDepth() == 32 && mask.getBitDepth() == 32) {
/*     */       
/* 302 */       GeodesicReconstruction3DHybrid0Float geodesicReconstruction3DHybrid0Float = new GeodesicReconstruction3DHybrid0Float(
/* 303 */           GeodesicReconstructionType.BY_EROSION, connectivity);
/*     */     }
/*     */     else {
/*     */       
/* 307 */       geodesicReconstructionByErosion3DScanning = new GeodesicReconstructionByErosion3DScanning(connectivity);
/*     */     } 
/*     */     
/* 310 */     DefaultAlgoListener.monitor((Algo)geodesicReconstructionByErosion3DScanning);
/* 311 */     return geodesicReconstructionByErosion3DScanning.applyTo(marker, mask);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/morphology/GeodesicReconstruction3D.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */