/*     */ package inra.ijpb.morphology.strel;
/*     */ 
/*     */ import ij.plugin.filter.RankFilters;
/*     */ import ij.process.ByteProcessor;
/*     */ import ij.process.ImageProcessor;
/*     */ import inra.ijpb.morphology.Strel;
/*     */ import inra.ijpb.morphology.Strel3D;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DiskStrel
/*     */   extends AbstractInPlaceStrel
/*     */   implements InPlaceStrel
/*     */ {
/*     */   double radius;
/*     */   
/*     */   public static final DiskStrel fromRadius(int radius) {
/*  58 */     return new DiskStrel(radius);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final DiskStrel fromDiameter(int diam) {
/*  74 */     double radius = (diam - 1.0D) / 2.0D;
/*  75 */     return new DiskStrel(radius);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private DiskStrel(double radius) {
/*  86 */     this.radius = radius;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int[] getSize() {
/*  99 */     int radiusInt = (int)Math.round(this.radius);
/* 100 */     int diam = 2 * radiusInt + 1;
/* 101 */     return new int[] { diam, diam };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int[][] getMask() {
/* 111 */     int intRadius = (int)Math.round(this.radius);
/* 112 */     int size = 2 * intRadius + 1;
/* 113 */     ByteProcessor byteProcessor = new ByteProcessor(size, size);
/* 114 */     byteProcessor.set(intRadius, intRadius, 255);
/*     */ 
/*     */     
/* 117 */     inPlaceDilation((ImageProcessor)byteProcessor);
/*     */ 
/*     */     
/* 120 */     int[][] mask = new int[size][size];
/* 121 */     for (int y = 0; y < size; y++) {
/*     */       
/* 123 */       for (int x = 0; x < size; x++)
/*     */       {
/* 125 */         mask[y][x] = byteProcessor.get(x, y);
/*     */       }
/*     */     } 
/*     */     
/* 129 */     return mask;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int[] getOffset() {
/* 138 */     int intRadius = (int)Math.round(this.radius);
/* 139 */     return new int[] { intRadius, intRadius };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int[][] getShifts() {
/* 148 */     int intRadius = (int)Math.round(this.radius);
/* 149 */     int[][] mask = getMask();
/* 150 */     int size = 2 * intRadius + 1;
/*     */     
/* 152 */     int n = 0;
/* 153 */     for (int y = 0; y < size; y++) {
/*     */       
/* 155 */       for (int x = 0; x < size; x++) {
/*     */         
/* 157 */         if (mask[y][x] > 0) {
/* 158 */           n++;
/*     */         }
/*     */       } 
/*     */     } 
/* 162 */     int[][] offsets = new int[n][2];
/* 163 */     int i = 0;
/* 164 */     for (int j = 0; j < size; j++) {
/*     */       
/* 166 */       for (int x = 0; x < size; x++) {
/*     */         
/* 168 */         if (mask[j][x] > 0) {
/*     */           
/* 170 */           offsets[i][0] = x;
/* 171 */           offsets[i][1] = j;
/* 172 */           i++;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 177 */     return offsets;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DiskStrel reverse() {
/* 186 */     return new DiskStrel(this.radius);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void inPlaceDilation(ImageProcessor image) {
/* 198 */     (new RankFilters()).rank(image, this.radius, 2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void inPlaceErosion(ImageProcessor image) {
/* 210 */     (new RankFilters()).rank(image, this.radius, 1);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/morphology/strel/DiskStrel.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */