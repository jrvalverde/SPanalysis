/*     */ package inra.ijpb.morphology.strel;
/*     */ 
/*     */ import ij.process.ImageProcessor;
/*     */ import inra.ijpb.morphology.Strel;
/*     */ import inra.ijpb.morphology.Strel3D;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LinearVerticalStrel
/*     */   extends AbstractInPlaceStrel
/*     */ {
/*     */   int size;
/*     */   int offset;
/*     */   
/*     */   public static final LinearVerticalStrel fromDiameter(int diam) {
/*  44 */     return new LinearVerticalStrel(diam);
/*     */   }
/*     */   
/*     */   public static final LinearVerticalStrel fromRadius(int radius) {
/*  48 */     return new LinearVerticalStrel(2 * radius + 1, radius);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LinearVerticalStrel(int size) {
/*  75 */     if (size < 1) {
/*  76 */       throw new RuntimeException("Requires a positive size");
/*     */     }
/*  78 */     this.size = size;
/*     */     
/*  80 */     this.offset = (int)Math.floor(((this.size - 1) / 2));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LinearVerticalStrel(int size, int offset) {
/*  90 */     if (size < 1) {
/*  91 */       throw new RuntimeException("Requires a positive size");
/*     */     }
/*  93 */     this.size = size;
/*     */     
/*  95 */     if (offset < 0) {
/*  96 */       throw new RuntimeException("Requires a non-negative offset");
/*     */     }
/*  98 */     if (offset >= size) {
/*  99 */       throw new RuntimeException("Offset can not be greater than size");
/*     */     }
/* 101 */     this.offset = offset;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void inPlaceDilation(ImageProcessor image) {
/* 114 */     if (this.size <= 1) {
/*     */       return;
/*     */     }
/*     */     
/* 118 */     if (image instanceof ij.process.ByteProcessor) {
/* 119 */       inPlaceDilationGray8(image);
/*     */     } else {
/* 121 */       inPlaceDilationFloat(image);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void inPlaceDilationGray8(ImageProcessor image) {
/* 126 */     int width = image.getWidth();
/* 127 */     int height = image.getHeight();
/*     */ 
/*     */     
/* 130 */     int shift = this.size - this.offset - 1;
/*     */ 
/*     */     
/* 133 */     LocalExtremumBufferGray8 localMax = new LocalExtremumBufferGray8(this.size, 
/* 134 */         LocalExtremum.Type.MAXIMUM);
/*     */ 
/*     */     
/* 137 */     for (int x = 0; x < width; x++) {
/* 138 */       fireProgressChanged(this, x, width);
/*     */ 
/*     */       
/* 141 */       localMax.fill(0);
/*     */       
/*     */       int y;
/* 144 */       for (y = 0; y < Math.min(shift, height); y++) {
/* 145 */         localMax.add(image.get(x, y));
/*     */       }
/*     */ 
/*     */       
/* 149 */       for (y = 0; y < height - shift; y++) {
/* 150 */         localMax.add(image.get(x, y + shift));
/* 151 */         image.set(x, y, localMax.getMax());
/*     */       } 
/*     */ 
/*     */       
/* 155 */       for (y = Math.max(0, height - shift); y < height; y++) {
/* 156 */         localMax.add(0);
/* 157 */         image.set(x, y, localMax.getMax());
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 162 */     fireProgressChanged(this, width, width);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void inPlaceDilationFloat(ImageProcessor image) {
/* 168 */     int width = image.getWidth();
/* 169 */     int height = image.getHeight();
/*     */ 
/*     */     
/* 172 */     int shift = this.size - this.offset - 1;
/*     */ 
/*     */     
/* 175 */     LocalExtremumBufferDouble localMax = new LocalExtremumBufferDouble(this.size, 
/* 176 */         LocalExtremum.Type.MAXIMUM);
/*     */ 
/*     */     
/* 179 */     for (int x = 0; x < width; x++) {
/* 180 */       fireProgressChanged(this, x, width);
/*     */ 
/*     */       
/* 183 */       localMax.fill(Double.NEGATIVE_INFINITY);
/*     */       
/*     */       int y;
/* 186 */       for (y = 0; y < Math.min(shift, height); y++) {
/* 187 */         localMax.add(image.getf(x, y));
/*     */       }
/*     */ 
/*     */       
/* 191 */       for (y = 0; y < height - shift; y++) {
/* 192 */         localMax.add(image.getf(x, y + shift));
/* 193 */         image.setf(x, y, (float)localMax.getMax());
/*     */       } 
/*     */ 
/*     */       
/* 197 */       for (y = Math.max(0, height - shift); y < height; y++) {
/* 198 */         localMax.add(Double.NEGATIVE_INFINITY);
/* 199 */         image.setf(x, y, (float)localMax.getMax());
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 204 */     fireProgressChanged(this, width, width);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void inPlaceErosion(ImageProcessor image) {
/* 213 */     if (this.size <= 1) {
/*     */       return;
/*     */     }
/*     */     
/* 217 */     if (image instanceof ij.process.ByteProcessor) {
/* 218 */       inPlaceErosionGray8(image);
/*     */     } else {
/* 220 */       inPlaceErosionFloat(image);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void inPlaceErosionGray8(ImageProcessor image) {
/* 225 */     int width = image.getWidth();
/* 226 */     int height = image.getHeight();
/*     */ 
/*     */     
/* 229 */     int shift = this.size - this.offset - 1;
/*     */ 
/*     */     
/* 232 */     LocalExtremumBufferGray8 localMin = new LocalExtremumBufferGray8(this.size, 
/* 233 */         LocalExtremum.Type.MINIMUM);
/*     */ 
/*     */ 
/*     */     
/* 237 */     for (int x = 0; x < width; x++) {
/* 238 */       fireProgressChanged(this, x, width);
/*     */ 
/*     */       
/* 241 */       localMin.fill(255);
/*     */       
/*     */       int y;
/* 244 */       for (y = 0; y < Math.min(shift, height); y++) {
/* 245 */         localMin.add(image.get(x, y));
/*     */       }
/*     */ 
/*     */       
/* 249 */       for (y = 0; y < height - shift; y++) {
/* 250 */         localMin.add(image.get(x, y + shift));
/* 251 */         image.set(x, y, localMin.getMax());
/*     */       } 
/*     */ 
/*     */       
/* 255 */       for (y = Math.max(0, height - shift); y < height; y++) {
/* 256 */         localMin.add(255);
/* 257 */         image.set(x, y, localMin.getMax());
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 262 */     fireProgressChanged(this, width, width);
/*     */   }
/*     */ 
/*     */   
/*     */   private void inPlaceErosionFloat(ImageProcessor image) {
/* 267 */     int width = image.getWidth();
/* 268 */     int height = image.getHeight();
/*     */ 
/*     */     
/* 271 */     int shift = this.size - this.offset - 1;
/*     */ 
/*     */     
/* 274 */     LocalExtremumBufferDouble localMin = new LocalExtremumBufferDouble(this.size, 
/* 275 */         LocalExtremum.Type.MINIMUM);
/*     */ 
/*     */ 
/*     */     
/* 279 */     for (int x = 0; x < width; x++) {
/* 280 */       fireProgressChanged(this, x, width);
/*     */ 
/*     */       
/* 283 */       localMin.fill(Double.POSITIVE_INFINITY);
/*     */       
/*     */       int y;
/* 286 */       for (y = 0; y < Math.min(shift, height); y++) {
/* 287 */         localMin.add(image.getf(x, y));
/*     */       }
/*     */ 
/*     */       
/* 291 */       for (y = 0; y < height - shift; y++) {
/* 292 */         localMin.add(image.getf(x, y + shift));
/* 293 */         image.setf(x, y, (float)localMin.getMax());
/*     */       } 
/*     */ 
/*     */       
/* 297 */       for (y = Math.max(0, height - shift); y < height; y++) {
/* 298 */         localMin.add(Double.POSITIVE_INFINITY);
/* 299 */         image.setf(x, y, (float)localMin.getMax());
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 304 */     fireProgressChanged(this, width, width);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int[][] getMask() {
/* 313 */     int[][] mask = new int[this.size][1];
/* 314 */     for (int i = 0; i < this.size; i++) {
/* 315 */       mask[i][0] = 255;
/*     */     }
/*     */     
/* 318 */     return mask;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int[] getOffset() {
/* 326 */     return new int[] { this.offset, this.offset };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int[][] getShifts() {
/* 334 */     int[][] shifts = new int[this.size][2];
/* 335 */     for (int i = 0; i < this.size; i++) {
/* 336 */       shifts[i][0] = 0;
/* 337 */       shifts[i][1] = i - this.offset;
/*     */     } 
/* 339 */     return shifts;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int[] getSize() {
/* 347 */     return new int[] { 1, this.size };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LinearVerticalStrel reverse() {
/* 356 */     return new LinearVerticalStrel(this.size, this.size - this.offset - 1);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/morphology/strel/LinearVerticalStrel.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */