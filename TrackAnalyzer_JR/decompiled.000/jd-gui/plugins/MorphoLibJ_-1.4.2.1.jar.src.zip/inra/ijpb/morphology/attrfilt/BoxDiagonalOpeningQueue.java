/*     */ package inra.ijpb.morphology.attrfilt;
/*     */ 
/*     */ import ij.process.ImageProcessor;
/*     */ import inra.ijpb.algo.AlgoStub;
/*     */ import inra.ijpb.morphology.FloodFill;
/*     */ import inra.ijpb.morphology.MinimaAndMaxima;
/*     */ import java.awt.Point;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Comparator;
/*     */ import java.util.PriorityQueue;
/*     */ import java.util.Queue;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BoxDiagonalOpeningQueue
/*     */   extends AlgoStub
/*     */   implements AreaOpening
/*     */ {
/*     */   int conn;
/*     */   private int[] dx;
/*     */   private int[] dy;
/*     */   
/*     */   public BoxDiagonalOpeningQueue() {
/*  45 */     this.conn = 4;
/*     */ 
/*     */     
/*  48 */     this.dx = new int[] { 0, -1, 1 };
/*  49 */     this.dy = new int[] { -1, 1 };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setConnectivity(int connectivity) {
/*  58 */     switch (connectivity) {
/*     */       
/*     */       case 4:
/*  61 */         this.dx = new int[] { 0, -1, 1 };
/*  62 */         this.dy = new int[] { -1, 1 };
/*     */         break;
/*     */       
/*     */       case 8:
/*  66 */         this.dx = new int[] { -1, 1, -1, 1, -1, 1 };
/*  67 */         this.dy = new int[] { -1, -1, -1, 1, 1, 1 };
/*     */         break;
/*     */       
/*     */       default:
/*  71 */         throw new IllegalArgumentException("Connectivity must be either 4 or 8, not " + connectivity);
/*     */     } 
/*     */     
/*  74 */     this.conn = connectivity;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getConnectivity() {
/*  84 */     return this.conn;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ImageProcessor process(ImageProcessor image, int minDiagonal) {
/*  94 */     int sizeX = image.getWidth();
/*  95 */     int sizeY = image.getHeight();
/*     */ 
/*     */     
/*  98 */     Collection<Point> maximaPositions = findMaximaPositions(image);
/*     */ 
/*     */     
/* 101 */     ImageProcessor result = image.duplicate();
/*     */ 
/*     */     
/* 104 */     for (Point pos0 : maximaPositions) {
/*     */ 
/*     */       
/* 107 */       ArrayList<Point> positions = new ArrayList<Point>();
/*     */ 
/*     */       
/* 110 */       BoxDiagonal attribute = new BoxDiagonal(null);
/*     */ 
/*     */       
/* 113 */       Queue<Point> queue = new PriorityQueue<Point>(new PositionValueComparator(result));
/* 114 */       queue.add(pos0);
/*     */ 
/*     */       
/* 117 */       int currentLevel = image.get(pos0.x, pos0.y);
/* 118 */       while (!queue.isEmpty()) {
/*     */ 
/*     */         
/* 121 */         Point pos = queue.remove();
/*     */ 
/*     */         
/* 124 */         int neighborValue = result.get(pos.x, pos.y);
/* 125 */         if (neighborValue > currentLevel) {
/*     */           break;
/*     */         }
/*     */ 
/*     */ 
/*     */         
/* 131 */         positions.add(pos);
/* 132 */         currentLevel = neighborValue;
/*     */ 
/*     */         
/* 135 */         attribute.add(pos);
/* 136 */         if (attribute.getValue() >= minDiagonal) {
/*     */           break;
/*     */         }
/*     */ 
/*     */ 
/*     */         
/* 142 */         for (int iNeigh = 0; iNeigh < this.dx.length; iNeigh++) {
/*     */           
/* 144 */           int x2 = pos.x + this.dx[iNeigh];
/* 145 */           int y2 = pos.y + this.dy[iNeigh];
/* 146 */           if (x2 >= 0 && x2 < sizeX && y2 >= 0 && y2 < sizeY) {
/*     */             
/* 148 */             Point pos2 = new Point(x2, y2);
/*     */             
/* 150 */             if (!positions.contains(pos2) && !queue.contains(pos2))
/*     */             {
/* 152 */               queue.add(pos2);
/*     */             }
/*     */           } 
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 159 */       for (Point pos : positions)
/*     */       {
/* 161 */         result.set(pos.x, pos.y, currentLevel);
/*     */       }
/*     */     } 
/*     */     
/* 165 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private Collection<Point> findMaximaPositions(ImageProcessor image) {
/* 171 */     ImageProcessor maxima = MinimaAndMaxima.regionalMaxima(image, this.conn);
/*     */     
/* 173 */     int sizeX = image.getWidth();
/* 174 */     int sizeY = image.getHeight();
/*     */     
/* 176 */     Collection<Point> positions = new ArrayList<Point>();
/*     */     
/* 178 */     for (int y = 0; y < sizeY; y++) {
/*     */       
/* 180 */       for (int x = 0; x < sizeX; x++) {
/*     */ 
/*     */ 
/*     */         
/* 184 */         if (maxima.get(x, y) > 0) {
/*     */           
/* 186 */           positions.add(new Point(x, y));
/* 187 */           FloodFill.floodFill(maxima, x, y, 0, this.conn);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 192 */     return positions;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private class PositionValueComparator
/*     */     implements Comparator<Point>
/*     */   {
/*     */     ImageProcessor image;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     PositionValueComparator(ImageProcessor image) {
/* 208 */       this.image = image;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public int compare(Point pos1, Point pos2) {
/* 214 */       int val1 = this.image.get(pos1.x, pos1.y);
/* 215 */       int val2 = this.image.get(pos2.x, pos2.y);
/* 216 */       if (val1 > val2)
/*     */       {
/* 218 */         return -1;
/*     */       }
/* 220 */       if (val2 > val1)
/*     */       {
/* 222 */         return 1;
/*     */       }
/* 224 */       return 0;
/*     */     }
/*     */   }
/*     */   
/*     */   private class BoxDiagonal
/*     */   {
/* 230 */     int xmin = Integer.MAX_VALUE;
/* 231 */     int ymin = Integer.MAX_VALUE;
/* 232 */     int xmax = Integer.MIN_VALUE;
/* 233 */     int ymax = Integer.MIN_VALUE;
/*     */ 
/*     */     
/*     */     public void add(Point point) {
/* 237 */       int x = point.x;
/* 238 */       this.xmin = Math.min(this.xmin, x);
/* 239 */       this.xmax = Math.max(this.xmax, x);
/* 240 */       int y = point.y;
/* 241 */       this.ymin = Math.min(this.ymin, y);
/* 242 */       this.ymax = Math.max(this.ymax, y);
/*     */     }
/*     */ 
/*     */     
/*     */     public double getValue() {
/* 247 */       return Math.hypot((this.xmax - this.xmin), (this.ymax - this.ymin));
/*     */     }
/*     */     
/*     */     private BoxDiagonal() {}
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/morphology/attrfilt/BoxDiagonalOpeningQueue.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */