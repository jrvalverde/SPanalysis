/*     */ package inra.ijpb.morphology.strel;
/*     */ 
/*     */ import ij.ImageStack;
/*     */ import inra.ijpb.morphology.Strel;
/*     */ import inra.ijpb.morphology.Strel3D;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ExtrudedStrel
/*     */   extends AbstractStrel3D
/*     */ {
/*     */   Strel strel2d;
/*     */   int sizeZ;
/*     */   int offsetZ;
/*     */   
/*     */   public ExtrudedStrel(Strel strel2d, int nSlices) {
/*  43 */     this.strel2d = strel2d;
/*  44 */     if (nSlices < 1)
/*     */     {
/*  46 */       throw new IllegalArgumentException("Requires at least one slice for creating extruded structuring element");
/*     */     }
/*  48 */     this.sizeZ = nSlices;
/*  49 */     this.offsetZ = (nSlices - 1) / 2;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ExtrudedStrel(Strel strel2d, int nSlices, int offset) {
/*  55 */     this.strel2d = strel2d;
/*  56 */     if (nSlices < 1)
/*     */     {
/*  58 */       throw new IllegalArgumentException("Requires at least one slice for creating extruded structuring element");
/*     */     }
/*  60 */     this.sizeZ = nSlices;
/*  61 */     this.offsetZ = offset;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int[] getSize() {
/*  71 */     int[] sizes2d = this.strel2d.getSize();
/*  72 */     int[] sizes = new int[3];
/*  73 */     sizes[0] = sizes2d[0];
/*  74 */     sizes[1] = sizes2d[1];
/*  75 */     sizes[2] = this.sizeZ;
/*  76 */     return sizes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int[][][] getMask3D() {
/*  86 */     int[][] mask2d = this.strel2d.getMask();
/*  87 */     int[] size2d = this.strel2d.getSize();
/*     */ 
/*     */     
/*  90 */     int[][][] mask = new int[this.sizeZ][size2d[1]][size2d[0]];
/*     */ 
/*     */     
/*  93 */     for (int z = 0; z < this.sizeZ; z++) {
/*     */       
/*  95 */       for (int y = 0; y < size2d[1]; y++) {
/*     */         
/*  97 */         for (int x = 0; x < size2d[0]; x++)
/*     */         {
/*  99 */           mask[z][y][x] = mask2d[y][x];
/*     */         }
/*     */       } 
/*     */     } 
/* 103 */     return mask;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int[] getOffset() {
/* 112 */     int[] offset2d = this.strel2d.getOffset();
/* 113 */     int[] offset = new int[3];
/* 114 */     offset[0] = offset2d[0];
/* 115 */     offset[1] = offset2d[1];
/* 116 */     offset[2] = this.offsetZ;
/* 117 */     return offset;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int[][] getShifts3D() {
/* 126 */     int[][] shifts2d = this.strel2d.getShifts();
/* 127 */     int nShifts2d = shifts2d.length;
/*     */     
/* 129 */     int nShifts = nShifts2d * this.sizeZ;
/* 130 */     int[][] shifts = new int[nShifts][3];
/* 131 */     int s = 0;
/* 132 */     for (int z = 0; z < this.sizeZ; z++) {
/*     */       
/* 134 */       for (int s2 = 0; s2 < nShifts2d; s2++) {
/*     */         
/* 136 */         shifts[s][0] = shifts2d[s2][0];
/* 137 */         shifts[s][1] = shifts2d[s2][1];
/* 138 */         shifts[s][2] = z - this.offsetZ;
/*     */       } 
/*     */     } 
/* 141 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ImageStack dilation(ImageStack image) {
/* 150 */     ImageStack result = this.strel2d.dilation(image);
/* 151 */     if (this.sizeZ > 1) {
/*     */       
/* 153 */       Strel3D zStrel = new LinearDepthStrel3D(this.sizeZ, this.offsetZ);
/* 154 */       result = zStrel.dilation(result);
/*     */     } 
/* 156 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ImageStack erosion(ImageStack image) {
/* 165 */     ImageStack result = this.strel2d.erosion(image);
/* 166 */     if (this.sizeZ > 1) {
/*     */       
/* 168 */       Strel3D zStrel = new LinearDepthStrel3D(this.sizeZ, this.offsetZ);
/* 169 */       result = zStrel.erosion(result);
/*     */     } 
/* 171 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Strel3D reverse() {
/* 180 */     return new ExtrudedStrel(this.strel2d.reverse(), this.sizeZ, this.sizeZ - this.offsetZ - 1);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/morphology/strel/ExtrudedStrel.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */