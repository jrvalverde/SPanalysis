/*      */ package inra.ijpb.morphology.geodrec;
/*      */ 
/*      */ import ij.ImageStack;
/*      */ import inra.ijpb.data.image.Images3D;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class GeodesicReconstructionByDilation3D
/*      */   extends GeodesicReconstruction3DAlgoStub
/*      */ {
/*      */   ImageStack marker;
/*      */   ImageStack mask;
/*      */   ImageStack result;
/*   45 */   int size1 = 0;
/*      */   
/*   47 */   int size2 = 0;
/*      */   
/*   49 */   int size3 = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean modif;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public GeodesicReconstructionByDilation3D() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public GeodesicReconstructionByDilation3D(int connectivity) {
/*   74 */     this.connectivity = connectivity;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ImageStack applyTo(ImageStack marker, ImageStack mask) {
/*   84 */     this.marker = marker;
/*   85 */     this.mask = mask;
/*      */ 
/*      */     
/*   88 */     this.size1 = marker.getWidth();
/*   89 */     this.size2 = marker.getHeight();
/*   90 */     this.size3 = marker.getSize();
/*   91 */     if (!Images3D.isSameSize(marker, mask))
/*      */     {
/*   93 */       throw new IllegalArgumentException("Marker and Mask images must have the same size");
/*      */     }
/*      */ 
/*      */     
/*   97 */     if (this.connectivity != 6 && this.connectivity != 26)
/*      */     {
/*   99 */       throw new RuntimeException(
/*  100 */           "Connectivity for stacks must be either 6 or 26, not " + 
/*  101 */           this.connectivity);
/*      */     }
/*      */ 
/*      */     
/*  105 */     this.result = ImageStack.create(this.size1, this.size2, this.size3, mask.getBitDepth());
/*      */ 
/*      */ 
/*      */     
/*  109 */     for (int z = 0; z < this.size3; z++) {
/*      */       
/*  111 */       for (int y = 0; y < this.size2; y++) {
/*      */         
/*  113 */         for (int x = 0; x < this.size1; x++)
/*      */         {
/*  115 */           this.result.setVoxel(x, y, z, 
/*  116 */               Math.min(this.marker.getVoxel(x, y, z), 
/*  117 */                 this.mask.getVoxel(x, y, z)));
/*      */         }
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  123 */     int iter = 0;
/*      */ 
/*      */ 
/*      */     
/*      */     do {
/*  128 */       this.modif = false;
/*      */ 
/*      */       
/*  131 */       trace("Forward iteration " + iter);
/*  132 */       showStatus("Geod. Rec. by Dil. Fwd " + (iter + 1));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  140 */       forwardDilationC26();
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  145 */       trace("Backward iteration " + iter);
/*  146 */       showStatus("Geod. Rec. by Dil. Bwd " + (iter + 1));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  154 */       backwardDilationC26();
/*      */ 
/*      */ 
/*      */       
/*  158 */       iter++;
/*  159 */     } while (this.modif);
/*      */ 
/*      */     
/*  162 */     showProgress(1.0D, 1.0D, "");
/*      */     
/*  164 */     return this.result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void forwardDilationC26() {
/*  273 */     switch (this.result.getBitDepth()) {
/*      */       
/*      */       case 8:
/*  276 */         forwardDilationC26Gray8();
/*      */         break;
/*      */       case 16:
/*  279 */         forwardDilationC26Gray16();
/*      */         break;
/*      */       case 32:
/*  282 */         forwardDilationC26Float();
/*      */         break;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void forwardDilationC26(ImageStack binaryMask) {
/*  293 */     switch (this.result.getBitDepth()) {
/*      */       
/*      */       case 8:
/*  296 */         forwardDilationC26Gray8(binaryMask);
/*      */         break;
/*      */       case 16:
/*  299 */         forwardDilationC26Gray16(binaryMask);
/*      */         break;
/*      */       case 32:
/*  302 */         forwardDilationC26Float(binaryMask);
/*      */         break;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void forwardDilationC26Gray8() {
/*  317 */     Object[] stack = this.result.getImageArray();
/*      */ 
/*      */ 
/*      */     
/*  321 */     for (int z = 0; z < this.size3; z++) {
/*      */       
/*  323 */       showProgress(z, this.size3, "z = " + z);
/*      */       
/*  325 */       for (int y = 0; y < this.size2; y++) {
/*      */         
/*  327 */         for (int x = 0; x < this.size1; x++) {
/*      */           
/*  329 */           int maxValue = (int)this.result.getVoxel(x, y, z);
/*      */ 
/*      */           
/*  332 */           int zmax = Math.min(z + 1, this.size3);
/*  333 */           for (int z2 = Math.max(z - 1, 0); z2 < zmax; z2++) {
/*      */             
/*  335 */             byte[] slice = (byte[])stack[z2];
/*      */             
/*  337 */             int ymax = (z2 == z) ? y : Math.min(y + 2, this.size2);
/*  338 */             for (int y2 = Math.max(y - 1, 0); y2 < ymax; y2++) {
/*      */               
/*  340 */               int xmax = (z2 == z && y2 == y) ? x : Math.min(x + 2, this.size1);
/*  341 */               for (int x2 = Math.max(x - 1, 0); x2 < xmax; x2++) {
/*      */                 
/*  343 */                 int neighborValue = slice[y2 * this.size1 + x2] & 0xFF;
/*  344 */                 if (neighborValue > maxValue) {
/*  345 */                   maxValue = neighborValue;
/*      */                 }
/*      */               } 
/*      */             } 
/*      */           } 
/*  350 */           geodesicDilationUpdate(x, y, z, maxValue);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void forwardDilationC26Gray8(ImageStack binaryMask) {
/*  365 */     Object[] stack = this.result.getImageArray();
/*      */ 
/*      */ 
/*      */     
/*  369 */     for (int z = 0; z < this.size3; z++) {
/*      */       
/*  371 */       showProgress(z, this.size3, "z = " + z);
/*  372 */       for (int y = 0; y < this.size2; y++) {
/*      */         
/*  374 */         for (int x = 0; x < this.size1; x++) {
/*      */ 
/*      */           
/*  377 */           if (binaryMask.getVoxel(x, y, z) != 0.0D) {
/*      */             
/*  379 */             int maxValue = (int)this.result.getVoxel(x, y, z);
/*      */ 
/*      */             
/*  382 */             int zmax = Math.min(z + 1, this.size3);
/*  383 */             for (int z2 = Math.max(z - 1, 0); z2 < zmax; z2++) {
/*      */               
/*  385 */               byte[] slice = (byte[])stack[z2];
/*      */               
/*  387 */               int ymax = (z2 == z) ? y : Math.min(y + 2, this.size2);
/*  388 */               for (int y2 = Math.max(y - 1, 0); y2 < ymax; y2++) {
/*      */                 
/*  390 */                 int xmax = (z2 == z && y2 == y) ? x : Math.min(x + 2, this.size1);
/*  391 */                 for (int x2 = Math.max(x - 1, 0); x2 < xmax; x2++) {
/*      */                   
/*  393 */                   int neighborValue = slice[y2 * this.size1 + x2] & 0xFF;
/*  394 */                   if (neighborValue > maxValue) {
/*  395 */                     maxValue = neighborValue;
/*      */                   }
/*      */                 } 
/*      */               } 
/*      */             } 
/*  400 */             geodesicDilationUpdate(x, y, z, maxValue);
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void forwardDilationC26Gray16(ImageStack binaryMask) {
/*  465 */     Object[] stack = this.result.getImageArray();
/*      */ 
/*      */ 
/*      */     
/*  469 */     for (int z = 0; z < this.size3; z++) {
/*      */       
/*  471 */       showProgress(z, this.size3, "z = " + z);
/*  472 */       for (int y = 0; y < this.size2; y++) {
/*      */         
/*  474 */         for (int x = 0; x < this.size1; x++) {
/*      */           
/*  476 */           if (binaryMask.getVoxel(x, y, z) != 0.0D) {
/*      */             
/*  478 */             double maxValue = this.result.getVoxel(x, y, z);
/*      */ 
/*      */             
/*  481 */             int zmax = Math.min(z + 1, this.size3);
/*  482 */             for (int z2 = Math.max(z - 1, 0); z2 < zmax; z2++) {
/*      */               
/*  484 */               short[] slice = (short[])stack[z2];
/*      */               
/*  486 */               int ymax = (z2 == z) ? y : Math.min(y + 2, this.size2);
/*  487 */               for (int y2 = Math.max(y - 1, 0); y2 < ymax; y2++) {
/*      */                 
/*  489 */                 int xmax = (z2 == z && y2 == y) ? x : Math.min(x + 2, this.size1);
/*  490 */                 for (int x2 = Math.max(x - 1, 0); x2 < xmax; x2++) {
/*      */                   
/*  492 */                   double neighborValue = (slice[y2 * this.size1 + x2] & 0xFFFF);
/*  493 */                   if (neighborValue > maxValue) {
/*  494 */                     maxValue = neighborValue;
/*      */                   }
/*      */                 } 
/*      */               } 
/*      */             } 
/*  499 */             geodesicDilationUpdate(x, y, z, maxValue);
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void forwardDilationC26Gray16() {
/*  515 */     Object[] stack = this.result.getImageArray();
/*      */ 
/*      */ 
/*      */     
/*  519 */     for (int z = 0; z < this.size3; z++) {
/*      */       
/*  521 */       showProgress(z, this.size3, "z = " + z);
/*  522 */       for (int y = 0; y < this.size2; y++) {
/*      */         
/*  524 */         for (int x = 0; x < this.size1; x++) {
/*      */           
/*  526 */           double maxValue = this.result.getVoxel(x, y, z);
/*      */ 
/*      */           
/*  529 */           int zmax = Math.min(z + 1, this.size3);
/*  530 */           for (int z2 = Math.max(z - 1, 0); z2 < zmax; z2++) {
/*      */             
/*  532 */             short[] slice = (short[])stack[z2];
/*      */             
/*  534 */             int ymax = (z2 == z) ? y : Math.min(y + 2, this.size2);
/*  535 */             for (int y2 = Math.max(y - 1, 0); y2 < ymax; y2++) {
/*      */               
/*  537 */               int xmax = (z2 == z && y2 == y) ? x : Math.min(x + 2, this.size1);
/*  538 */               for (int x2 = Math.max(x - 1, 0); x2 < xmax; x2++) {
/*      */                 
/*  540 */                 double neighborValue = (slice[y2 * this.size1 + x2] & 0xFFFF);
/*  541 */                 if (neighborValue > maxValue) {
/*  542 */                   maxValue = neighborValue;
/*      */                 }
/*      */               } 
/*      */             } 
/*      */           } 
/*  547 */           geodesicDilationUpdate(x, y, z, maxValue);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void forwardDilationC26Float() {
/*  562 */     Object[] stack = this.result.getImageArray();
/*      */ 
/*      */ 
/*      */     
/*  566 */     for (int z = 0; z < this.size3; z++) {
/*      */       
/*  568 */       showProgress(z, this.size3, "z = " + z);
/*  569 */       for (int y = 0; y < this.size2; y++) {
/*      */         
/*  571 */         for (int x = 0; x < this.size1; x++) {
/*      */           
/*  573 */           double maxValue = this.result.getVoxel(x, y, z);
/*      */ 
/*      */           
/*  576 */           for (int z2 = Math.max(z - 1, 0); z2 <= z; z2++) {
/*      */             
/*  578 */             float[] slice = (float[])stack[z2];
/*      */             
/*  580 */             int ymax = (z2 == z) ? y : Math.min(y + 2, this.size2);
/*  581 */             for (int y2 = Math.max(y - 1, 0); y2 < ymax; y2++) {
/*      */               
/*  583 */               int xmax = (z2 == z && y2 == y) ? x : Math.min(x + 2, this.size1);
/*  584 */               for (int x2 = Math.max(x - 1, 0); x2 < xmax; x2++) {
/*      */                 
/*  586 */                 double neighborValue = slice[y2 * this.size1 + x2];
/*  587 */                 if (neighborValue > maxValue) {
/*  588 */                   maxValue = neighborValue;
/*      */                 }
/*      */               } 
/*      */             } 
/*      */           } 
/*  593 */           geodesicDilationUpdate(x, y, z, maxValue);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void forwardDilationC26Float(ImageStack binaryMask) {
/*  608 */     Object[] stack = this.result.getImageArray();
/*      */ 
/*      */ 
/*      */     
/*  612 */     for (int z = 0; z < this.size3; z++) {
/*      */       
/*  614 */       showProgress(z, this.size3, "z = " + z);
/*  615 */       for (int y = 0; y < this.size2; y++) {
/*      */         
/*  617 */         for (int x = 0; x < this.size1; x++) {
/*      */           
/*  619 */           if (binaryMask.getVoxel(x, y, z) != 0.0D) {
/*      */             
/*  621 */             double maxValue = this.result.getVoxel(x, y, z);
/*      */ 
/*      */             
/*  624 */             for (int z2 = Math.max(z - 1, 0); z2 <= z; z2++) {
/*      */               
/*  626 */               float[] slice = (float[])stack[z2];
/*      */               
/*  628 */               int ymax = (z2 == z) ? y : Math.min(y + 2, this.size2);
/*  629 */               for (int y2 = Math.max(y - 1, 0); y2 < ymax; y2++) {
/*      */                 
/*  631 */                 int xmax = (z2 == z && y2 == y) ? x : Math.min(x + 2, this.size1);
/*  632 */                 for (int x2 = Math.max(x - 1, 0); x2 < xmax; x2++) {
/*      */                   
/*  634 */                   double neighborValue = slice[y2 * this.size1 + x2];
/*  635 */                   if (neighborValue > maxValue) {
/*  636 */                     maxValue = neighborValue;
/*      */                   }
/*      */                 } 
/*      */               } 
/*      */             } 
/*  641 */             geodesicDilationUpdate(x, y, z, maxValue);
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void backwardDilationC26() {
/*  751 */     switch (this.result.getBitDepth()) {
/*      */       case 8:
/*  753 */         backwardDilationC26Gray8(); return;
/*  754 */     }  backwardDilationC26Generic();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void backwardDilationC26(ImageStack binaryMask) {
/*  764 */     switch (this.result.getBitDepth()) {
/*      */       
/*      */       case 8:
/*  767 */         backwardDilationC26Gray8(binaryMask);
/*      */         return;
/*      */     } 
/*  770 */     backwardDilationC26Generic(binaryMask);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void backwardDilationC26Gray8() {
/*  784 */     Object[] stack = this.result.getImageArray();
/*      */ 
/*      */ 
/*      */     
/*  788 */     for (int z = this.size3 - 1; z >= 0; z--) {
/*      */       
/*  790 */       showProgress((this.size3 - 1 - z), this.size3);
/*  791 */       for (int y = this.size2 - 1; y >= 0; y--) {
/*      */         
/*  793 */         for (int x = this.size1 - 1; x >= 0; x--) {
/*      */           
/*  795 */           int maxValue = (int)this.result.getVoxel(x, y, z);
/*      */ 
/*      */           
/*  798 */           int zmin = Math.max(z - 1, 0);
/*  799 */           for (int z2 = Math.min(z + 1, this.size3 - 1); z2 >= zmin; z2--) {
/*      */             
/*  801 */             byte[] slice = (byte[])stack[z2];
/*      */             
/*  803 */             int ymin = (z2 == z) ? y : Math.max(y - 1, 0);
/*  804 */             for (int y2 = Math.min(y + 1, this.size2 - 1); y2 >= ymin; y2--) {
/*      */               
/*  806 */               int xmin = (z2 == z && y2 == y) ? x : Math.max(x - 1, 0);
/*  807 */               for (int x2 = Math.min(x + 1, this.size1 - 1); x2 >= xmin; x2--) {
/*      */                 
/*  809 */                 int neighborValue = slice[y2 * this.size1 + x2] & 0xFF;
/*  810 */                 if (neighborValue > maxValue) {
/*  811 */                   maxValue = neighborValue;
/*      */                 }
/*      */               } 
/*      */             } 
/*      */           } 
/*  816 */           geodesicDilationUpdate(x, y, z, maxValue);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void backwardDilationC26Gray8(ImageStack binaryMask) {
/*  832 */     Object[] stack = this.result.getImageArray();
/*      */ 
/*      */ 
/*      */     
/*  836 */     for (int z = this.size3 - 1; z >= 0; z--) {
/*      */       
/*  838 */       showProgress((this.size3 - 1 - z), this.size3);
/*  839 */       for (int y = this.size2 - 1; y >= 0; y--) {
/*      */         
/*  841 */         for (int x = this.size1 - 1; x >= 0; x--) {
/*      */           
/*  843 */           if (binaryMask.getVoxel(x, y, z) != 0.0D) {
/*      */             
/*  845 */             int maxValue = (int)this.result.getVoxel(x, y, z);
/*      */ 
/*      */             
/*  848 */             int zmin = Math.max(z - 1, 0);
/*  849 */             for (int z2 = Math.min(z + 1, this.size3 - 1); z2 >= zmin; z2--) {
/*      */               
/*  851 */               byte[] slice = (byte[])stack[z2];
/*      */               
/*  853 */               int ymin = (z2 == z) ? y : Math.max(y - 1, 0);
/*  854 */               for (int y2 = Math.min(y + 1, this.size2 - 1); y2 >= ymin; y2--) {
/*      */                 
/*  856 */                 int xmin = (z2 == z && y2 == y) ? x : Math.max(x - 1, 0);
/*  857 */                 for (int x2 = Math.min(x + 1, this.size1 - 1); x2 >= xmin; x2--) {
/*      */                   
/*  859 */                   int neighborValue = slice[y2 * this.size1 + x2] & 0xFF;
/*  860 */                   if (neighborValue > maxValue) {
/*  861 */                     maxValue = neighborValue;
/*      */                   }
/*      */                 } 
/*      */               } 
/*      */             } 
/*  866 */             geodesicDilationUpdate(x, y, z, maxValue);
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void backwardDilationC26Generic() {
/*  883 */     for (int k = this.size3 - 1; k >= 0; k--) {
/*      */       
/*  885 */       showProgress((this.size3 - 1 - k), this.size3);
/*      */       
/*  887 */       for (int j = this.size2 - 1; j >= 0; j--) {
/*      */         
/*  889 */         for (int i = this.size1 - 1; i >= 0; i--) {
/*      */           
/*  891 */           double value = getMaxValueBackward(i, j, k);
/*  892 */           geodesicDilationUpdate(i, j, k, value);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void backwardDilationC26Generic(ImageStack binaryMask) {
/*  907 */     for (int k = this.size3 - 1; k >= 0; k--) {
/*  908 */       showProgress((this.size3 - 1 - k), this.size3);
/*      */       
/*  910 */       for (int j = this.size2 - 1; j >= 0; j--) {
/*  911 */         for (int i = this.size1 - 1; i >= 0; i--) {
/*      */           
/*  913 */           if (binaryMask.getVoxel(i, j, k) != 0.0D) {
/*      */             
/*  915 */             double value = getMaxValueBackward(i, j, k);
/*  916 */             geodesicDilationUpdate(i, j, k, value);
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private double getMaxValueBackward(int x, int y, int z) {
/*  928 */     double max = this.result.getVoxel(x, y, z);
/*      */     
/*  930 */     for (int w = -1; w <= 1; w++) {
/*      */       
/*  932 */       for (int v = 0; v <= 1; v++) {
/*      */         
/*  934 */         int minX = (v > 0) ? -1 : ((w > 0) ? 0 : 1);
/*      */         
/*  936 */         for (int u = minX; u <= 1; u++) {
/*      */           
/*  938 */           int x2 = x + u;
/*  939 */           int y2 = y + v;
/*  940 */           int z2 = z + w;
/*      */           
/*  942 */           if (x2 >= 0 && x2 < this.size1 && y2 >= 0 && y2 < this.size2 && 
/*  943 */             z2 >= 0 && z2 < this.size3) {
/*      */             
/*  945 */             double neighborValue = this.result.getVoxel(x2, y2, z2);
/*  946 */             if (neighborValue > max) {
/*  947 */               max = neighborValue;
/*      */             }
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/*  954 */     return max;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void geodesicDilationUpdate(int i, int j, int k, double value) {
/*  966 */     value = Math.min(value, this.mask.getVoxel(i, j, k));
/*  967 */     if (value > this.result.getVoxel(i, j, k)) {
/*      */       
/*  969 */       this.modif = true;
/*  970 */       this.result.setVoxel(i, j, k, value);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ImageStack applyTo(ImageStack marker, ImageStack mask, ImageStack binaryMask) {
/*  981 */     this.marker = marker;
/*  982 */     this.mask = mask;
/*      */ 
/*      */     
/*  985 */     this.size1 = marker.getWidth();
/*  986 */     this.size2 = marker.getHeight();
/*  987 */     this.size3 = marker.getSize();
/*  988 */     if (this.size1 != mask.getWidth() || this.size2 != mask.getHeight() || this.size3 != mask.getSize())
/*      */     {
/*  990 */       throw new IllegalArgumentException("Marker and Mask images must have the same size");
/*      */     }
/*      */ 
/*      */     
/*  994 */     if (this.connectivity != 6 && this.connectivity != 26)
/*      */     {
/*  996 */       throw new RuntimeException(
/*  997 */           "Connectivity for stacks must be either 6 or 26, not " + 
/*  998 */           this.connectivity);
/*      */     }
/*      */ 
/*      */     
/* 1002 */     this.result = ImageStack.create(this.size1, this.size2, this.size3, mask.getBitDepth());
/*      */ 
/*      */ 
/*      */     
/* 1006 */     for (int z = 0; z < this.size3; z++) {
/*      */       
/* 1008 */       for (int y = 0; y < this.size2; y++) {
/*      */         
/* 1010 */         for (int x = 0; x < this.size1; x++) {
/*      */           
/* 1012 */           if (binaryMask.getVoxel(x, y, z) != 0.0D) {
/* 1013 */             this.result.setVoxel(x, y, z, 
/* 1014 */                 Math.min(this.marker.getVoxel(x, y, z), 
/* 1015 */                   this.mask.getVoxel(x, y, z)));
/*      */           }
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/* 1021 */     int iter = 0;
/*      */ 
/*      */ 
/*      */     
/*      */     do {
/* 1026 */       this.modif = false;
/*      */ 
/*      */       
/* 1029 */       trace("Forward iteration " + iter);
/* 1030 */       showStatus("Geod. Rec. by Dil. Fwd " + (iter + 1));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1038 */       forwardDilationC26(binaryMask);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1043 */       trace("Backward iteration " + iter);
/* 1044 */       showStatus("Geod. Rec. by Dil. Bwd " + (iter + 1));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1052 */       backwardDilationC26(binaryMask);
/*      */ 
/*      */ 
/*      */       
/* 1056 */       iter++;
/* 1057 */     } while (this.modif);
/*      */     
/* 1059 */     return this.result;
/*      */   }
/*      */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/morphology/geodrec/GeodesicReconstructionByDilation3D.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */