/*     */ package inra.ijpb.morphology.strel;
/*     */ 
/*     */ import ij.ImageStack;
/*     */ import inra.ijpb.morphology.Strel3D;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LinearDepthStrel3D
/*     */   extends AbstractInPlaceStrel3D
/*     */ {
/*     */   int length;
/*     */   int offset;
/*     */   
/*     */   public static final LinearDepthStrel3D fromDiameter(int diam) {
/*  43 */     return new LinearDepthStrel3D(diam);
/*     */   }
/*     */   
/*     */   public static final LinearDepthStrel3D fromRadius(int radius) {
/*  47 */     return new LinearDepthStrel3D(2 * radius + 1, radius);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LinearDepthStrel3D(int size) {
/*  74 */     if (size < 1) {
/*  75 */       throw new RuntimeException("Requires a positive size");
/*     */     }
/*  77 */     this.length = size;
/*     */     
/*  79 */     this.offset = (int)Math.floor(((this.length - 1) / 2));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LinearDepthStrel3D(int size, int offset) {
/*  89 */     if (size < 1) {
/*  90 */       throw new RuntimeException("Requires a positive size");
/*     */     }
/*  92 */     this.length = size;
/*     */     
/*  94 */     if (offset < 0) {
/*  95 */       throw new RuntimeException("Requires a non-negative offset");
/*     */     }
/*  97 */     if (offset >= size) {
/*  98 */       throw new RuntimeException("Offset can not be greater than size");
/*     */     }
/* 100 */     this.offset = offset;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void inPlaceDilation(ImageStack stack) {
/* 113 */     if (this.length <= 1) {
/*     */       return;
/*     */     }
/*     */     
/* 117 */     if (stack.getBitDepth() == 8) {
/* 118 */       inPlaceDilationGray8(stack);
/*     */     } else {
/* 120 */       inPlaceDilationFloat(stack);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void inPlaceDilationGray8(ImageStack stack) {
/* 128 */     int width = stack.getWidth();
/* 129 */     int height = stack.getHeight();
/* 130 */     int depth = stack.getSize();
/*     */ 
/*     */     
/* 133 */     int shift = this.length - this.offset - 1;
/*     */ 
/*     */     
/* 136 */     LocalExtremumBufferGray8 localMax = new LocalExtremumBufferGray8(
/* 137 */         this.length, LocalExtremum.Type.MAXIMUM);
/*     */ 
/*     */     
/* 140 */     for (int y = 0; y < height; y++) {
/* 141 */       fireProgressChanged(this, y, height);
/* 142 */       for (int x = 0; x < width; x++) {
/*     */ 
/*     */         
/* 145 */         localMax.fill(0);
/*     */         
/*     */         int z;
/* 148 */         for (z = 0; z < Math.min(shift, depth); z++) {
/* 149 */           localMax.add((int)stack.getVoxel(x, y, z));
/*     */         }
/*     */ 
/*     */         
/* 153 */         for (z = 0; z < depth - shift; z++) {
/* 154 */           localMax.add((int)stack.getVoxel(x, y, z + shift));
/* 155 */           stack.setVoxel(x, y, z, localMax.getMax());
/*     */         } 
/*     */ 
/*     */         
/* 159 */         for (z = Math.max(0, depth - shift); z < depth; z++) {
/* 160 */           localMax.add(0);
/* 161 */           stack.setVoxel(x, y, z, localMax.getMax());
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 167 */     fireProgressChanged(this, height, height);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void inPlaceDilationFloat(ImageStack stack) {
/* 175 */     int width = stack.getWidth();
/* 176 */     int height = stack.getHeight();
/* 177 */     int depth = stack.getSize();
/*     */ 
/*     */     
/* 180 */     int shift = this.length - this.offset - 1;
/*     */ 
/*     */     
/* 183 */     LocalExtremumBufferDouble localMax = new LocalExtremumBufferDouble(
/* 184 */         this.length, LocalExtremum.Type.MAXIMUM);
/*     */ 
/*     */     
/* 187 */     for (int y = 0; y < height; y++) {
/* 188 */       fireProgressChanged(this, y, height);
/* 189 */       for (int x = 0; x < width; x++) {
/*     */ 
/*     */         
/* 192 */         localMax.fill(Double.NEGATIVE_INFINITY);
/*     */         
/*     */         int z;
/* 195 */         for (z = 0; z < Math.min(shift, depth); z++) {
/* 196 */           localMax.add((float)stack.getVoxel(x, y, z));
/*     */         }
/*     */ 
/*     */         
/* 200 */         for (z = 0; z < depth - shift; z++) {
/* 201 */           localMax.add((float)stack.getVoxel(x, y, z + shift));
/* 202 */           stack.setVoxel(x, y, z, localMax.getMax());
/*     */         } 
/*     */ 
/*     */         
/* 206 */         for (z = Math.max(0, depth - shift); z < depth; z++) {
/* 207 */           localMax.add(Double.NEGATIVE_INFINITY);
/* 208 */           stack.setVoxel(x, y, z, localMax.getMax());
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 214 */     fireProgressChanged(this, height, height);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void inPlaceErosion(ImageStack stack) {
/* 223 */     if (this.length <= 1) {
/*     */       return;
/*     */     }
/*     */     
/* 227 */     if (stack.getBitDepth() == 8) {
/* 228 */       inPlaceErosionGray8(stack);
/*     */     } else {
/* 230 */       inPlaceErosionFloat(stack);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void inPlaceErosionGray8(ImageStack stack) {
/* 239 */     int width = stack.getWidth();
/* 240 */     int height = stack.getHeight();
/* 241 */     int depth = stack.getSize();
/*     */ 
/*     */     
/* 244 */     int shift = this.length - this.offset - 1;
/*     */ 
/*     */     
/* 247 */     LocalExtremumBufferDouble localMin = new LocalExtremumBufferDouble(this.length, 
/* 248 */         LocalExtremum.Type.MINIMUM);
/*     */ 
/*     */ 
/*     */     
/* 252 */     for (int y = 0; y < height; y++) {
/* 253 */       fireProgressChanged(this, y, height);
/* 254 */       for (int x = 0; x < width; x++) {
/*     */ 
/*     */         
/* 257 */         localMin.fill(255.0D);
/*     */         
/*     */         int z;
/* 260 */         for (z = 0; z < Math.min(shift, depth); z++) {
/* 261 */           localMin.add((int)stack.getVoxel(x, y, z));
/*     */         }
/*     */ 
/*     */         
/* 265 */         for (z = 0; z < depth - shift; z++) {
/* 266 */           localMin.add((int)stack.getVoxel(x, y, z + shift));
/* 267 */           stack.setVoxel(x, y, z, localMin.getMax());
/*     */         } 
/*     */ 
/*     */         
/* 271 */         for (z = Math.max(0, depth - shift); z < depth; z++) {
/* 272 */           localMin.add(255.0D);
/* 273 */           stack.setVoxel(x, y, z, localMin.getMax());
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 279 */     fireProgressChanged(this, height, height);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void inPlaceErosionFloat(ImageStack stack) {
/* 287 */     int width = stack.getWidth();
/* 288 */     int height = stack.getHeight();
/* 289 */     int depth = stack.getSize();
/*     */ 
/*     */     
/* 292 */     int shift = this.length - this.offset - 1;
/*     */ 
/*     */     
/* 295 */     LocalExtremumBufferDouble localMin = new LocalExtremumBufferDouble(
/* 296 */         this.length, LocalExtremum.Type.MINIMUM);
/*     */ 
/*     */     
/* 299 */     for (int y = 0; y < height; y++) {
/* 300 */       fireProgressChanged(this, y, height);
/* 301 */       for (int x = 0; x < width; x++) {
/*     */ 
/*     */         
/* 304 */         localMin.fill(Double.POSITIVE_INFINITY);
/*     */         
/*     */         int z;
/* 307 */         for (z = 0; z < Math.min(shift, depth); z++) {
/* 308 */           localMin.add((float)stack.getVoxel(x, y, z));
/*     */         }
/*     */ 
/*     */         
/* 312 */         for (z = 0; z < depth - shift; z++) {
/* 313 */           localMin.add((float)stack.getVoxel(x, y, z + shift));
/* 314 */           stack.setVoxel(x, y, z, localMin.getMax());
/*     */         } 
/*     */ 
/*     */         
/* 318 */         for (z = Math.max(0, depth - shift); z < depth; z++) {
/* 319 */           localMin.add(Double.POSITIVE_INFINITY);
/* 320 */           stack.setVoxel(x, y, z, localMin.getMax());
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 326 */     fireProgressChanged(this, height, height);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int[][][] getMask3D() {
/* 334 */     int[][][] mask = new int[this.length][1][1];
/* 335 */     for (int i = 0; i < this.length; i++) {
/* 336 */       mask[i][0][0] = 255;
/*     */     }
/*     */     
/* 339 */     return mask;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int[] getOffset() {
/* 347 */     return new int[] { 0, 0, this.offset };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int[][] getShifts3D() {
/* 355 */     int[][] shifts = new int[this.length][3];
/* 356 */     for (int i = 0; i < this.length; i++) {
/* 357 */       shifts[i][0] = 0;
/* 358 */       shifts[i][1] = 0;
/* 359 */       shifts[i][2] = i - this.offset;
/*     */     } 
/* 361 */     return shifts;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int[] getSize() {
/* 369 */     return new int[] { 1, 1, this.length };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LinearDepthStrel3D reverse() {
/* 378 */     return new LinearDepthStrel3D(this.length, this.length - this.offset - 1);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/morphology/strel/LinearDepthStrel3D.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */