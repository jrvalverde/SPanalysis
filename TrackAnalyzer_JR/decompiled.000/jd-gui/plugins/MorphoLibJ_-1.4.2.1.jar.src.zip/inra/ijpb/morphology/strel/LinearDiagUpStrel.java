/*     */ package inra.ijpb.morphology.strel;
/*     */ 
/*     */ import ij.IJ;
/*     */ import ij.process.ImageProcessor;
/*     */ import inra.ijpb.morphology.Strel;
/*     */ import inra.ijpb.morphology.Strel3D;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LinearDiagUpStrel
/*     */   extends AbstractInPlaceStrel
/*     */ {
/*     */   int size;
/*     */   int offset;
/*     */   
/*     */   public static final LinearDiagUpStrel fromDiameter(int diam) {
/*  46 */     return new LinearDiagUpStrel(diam);
/*     */   }
/*     */   
/*     */   public static final LinearDiagUpStrel fromRadius(int radius) {
/*  50 */     return new LinearDiagUpStrel(2 * radius + 1, radius);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LinearDiagUpStrel(int size) {
/*  77 */     if (size < 1) {
/*  78 */       throw new RuntimeException("Requires a positive size");
/*     */     }
/*  80 */     this.size = size;
/*     */     
/*  82 */     this.offset = (int)Math.floor(((this.size - 1) / 2));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LinearDiagUpStrel(int size, int offset) {
/*  96 */     if (size < 1) {
/*  97 */       throw new RuntimeException("Requires a positive size");
/*     */     }
/*  99 */     this.size = size;
/*     */     
/* 101 */     if (offset < 0) {
/* 102 */       throw new RuntimeException("Requires a non-negative offset");
/*     */     }
/* 104 */     if (offset >= size) {
/* 105 */       throw new RuntimeException("Offset can not be greater than size");
/*     */     }
/* 107 */     this.offset = offset;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void inPlaceDilation(ImageProcessor image) {
/* 116 */     if (this.size <= 1) {
/*     */       return;
/*     */     }
/*     */     
/* 120 */     if (image instanceof ij.process.ByteProcessor) {
/* 121 */       inPlaceDilationGray8(image);
/*     */     } else {
/* 123 */       inPlaceDilationFloat(image);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void inPlaceDilationGray8(ImageProcessor image) {
/* 128 */     int width = image.getWidth();
/* 129 */     int height = image.getHeight();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 134 */     int dmin = 0;
/* 135 */     int dmax = width + height - 1;
/*     */ 
/*     */     
/* 138 */     LocalExtremumBufferGray8 localMax = new LocalExtremumBufferGray8(this.size, 
/* 139 */         LocalExtremum.Type.MAXIMUM);
/*     */ 
/*     */     
/* 142 */     for (int d = dmin; d < dmax; d++) {
/* 143 */       if (showProgress()) {
/* 144 */         IJ.showProgress(d, dmax - dmin);
/*     */       }
/* 146 */       fireProgressChanged(this, (d - dmin), (dmax - dmin));
/*     */ 
/*     */       
/* 149 */       localMax.fill(0);
/*     */       
/* 151 */       int xmin = Math.max(0, d + 1 - height);
/* 152 */       int xmax = Math.min(width, d + 1);
/* 153 */       int ymin = Math.max(0, d + 1 - width);
/* 154 */       int ymax = Math.min(height, d + 1);
/*     */       
/* 156 */       int tmin = Math.max(xmin, d + 1 - ymax);
/* 157 */       int tmax = Math.min(xmax, d + 1 - ymin);
/*     */ 
/*     */       
/* 160 */       int t = tmin;
/*     */ 
/*     */       
/* 163 */       while (t < Math.min(tmin + this.offset, tmax)) {
/* 164 */         localMax.add(image.get(t, d - t));
/* 165 */         t++;
/*     */       } 
/*     */ 
/*     */       
/* 169 */       while (t < tmax) {
/* 170 */         localMax.add(image.get(t, d - t));
/* 171 */         int t2 = t - this.offset;
/* 172 */         image.set(t2, d - t2, localMax.getMax());
/* 173 */         t++;
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 178 */       while (t < tmax + this.offset) {
/* 179 */         localMax.add(0);
/* 180 */         int t2 = t - this.offset;
/* 181 */         int x = t2;
/* 182 */         int y = d - t2;
/* 183 */         if (x >= 0 && y >= 0 && x < width && y < height)
/* 184 */           image.set(x, y, localMax.getMax()); 
/* 185 */         t++;
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 190 */     if (showProgress()) {
/* 191 */       IJ.showProgress(1.0D);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private void inPlaceDilationFloat(ImageProcessor image) {
/* 197 */     int width = image.getWidth();
/* 198 */     int height = image.getHeight();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 203 */     int dmin = 0;
/* 204 */     int dmax = width + height - 1;
/*     */ 
/*     */     
/* 207 */     LocalExtremumBufferDouble localMax = new LocalExtremumBufferDouble(this.size, 
/* 208 */         LocalExtremum.Type.MAXIMUM);
/*     */ 
/*     */     
/* 211 */     for (int d = dmin; d < dmax; d++) {
/* 212 */       if (showProgress()) {
/* 213 */         IJ.showProgress(d, dmax - dmin);
/*     */       }
/* 215 */       fireProgressChanged(this, (d - dmin), (dmax - dmin));
/*     */ 
/*     */       
/* 218 */       localMax.fill(Double.NEGATIVE_INFINITY);
/*     */       
/* 220 */       int xmin = Math.max(0, d + 1 - height);
/* 221 */       int xmax = Math.min(width, d + 1);
/* 222 */       int ymin = Math.max(0, d + 1 - width);
/* 223 */       int ymax = Math.min(height, d + 1);
/*     */       
/* 225 */       int tmin = Math.max(xmin, d + 1 - ymax);
/* 226 */       int tmax = Math.min(xmax, d + 1 - ymin);
/*     */ 
/*     */       
/* 229 */       int t = tmin;
/*     */ 
/*     */       
/* 232 */       while (t < Math.min(tmin + this.offset, tmax)) {
/* 233 */         localMax.add(image.getf(t, d - t));
/* 234 */         t++;
/*     */       } 
/*     */ 
/*     */       
/* 238 */       while (t < tmax) {
/* 239 */         localMax.add(image.getf(t, d - t));
/* 240 */         int t2 = t - this.offset;
/* 241 */         image.setf(t2, d - t2, (float)localMax.getMax());
/* 242 */         t++;
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 247 */       while (t < tmax + this.offset) {
/* 248 */         localMax.add(Double.NEGATIVE_INFINITY);
/* 249 */         int t2 = t - this.offset;
/* 250 */         int x = t2;
/* 251 */         int y = d - t2;
/* 252 */         if (x >= 0 && y >= 0 && x < width && y < height)
/* 253 */           image.setf(x, y, (float)localMax.getMax()); 
/* 254 */         t++;
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 259 */     if (showProgress()) {
/* 260 */       IJ.showProgress(1.0D);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void inPlaceErosion(ImageProcessor image) {
/* 270 */     if (this.size <= 1) {
/*     */       return;
/*     */     }
/*     */     
/* 274 */     if (image instanceof ij.process.ByteProcessor) {
/* 275 */       inPlaceErosionGray8(image);
/*     */     } else {
/* 277 */       inPlaceErosionFloat(image);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void inPlaceErosionGray8(ImageProcessor image) {
/* 282 */     int width = image.getWidth();
/* 283 */     int height = image.getHeight();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 288 */     int dmin = 0;
/* 289 */     int dmax = width + height - 1;
/*     */ 
/*     */     
/* 292 */     LocalExtremumBufferGray8 localMin = new LocalExtremumBufferGray8(this.size, 
/* 293 */         LocalExtremum.Type.MINIMUM);
/*     */ 
/*     */     
/* 296 */     for (int d = dmin; d < dmax; d++) {
/* 297 */       if (showProgress()) {
/* 298 */         IJ.showProgress(d, dmax - dmin);
/*     */       }
/* 300 */       fireProgressChanged(this, (d - dmin), (dmax - dmin));
/*     */ 
/*     */       
/* 303 */       localMin.fill(255);
/*     */       
/* 305 */       int xmin = Math.max(0, d - height - 1);
/* 306 */       int xmax = Math.min(width, d + 1);
/* 307 */       int ymin = Math.max(0, d - width - 1);
/* 308 */       int ymax = Math.min(height, d + 1);
/*     */       
/* 310 */       int tmin = Math.max(xmin, d - ymax + 1);
/* 311 */       int tmax = Math.min(xmax, d - ymin + 1);
/*     */ 
/*     */       
/* 314 */       int t = tmin;
/*     */ 
/*     */       
/* 317 */       while (t < Math.min(tmin + this.offset, tmax)) {
/* 318 */         localMin.add(image.get(t, d - t));
/* 319 */         t++;
/*     */       } 
/*     */ 
/*     */       
/* 323 */       while (t < tmax) {
/* 324 */         localMin.add(image.get(t, d - t));
/* 325 */         int t2 = t - this.offset;
/* 326 */         image.set(t2, d - t2, localMin.getMax());
/* 327 */         t++;
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 332 */       while (t < tmax + this.offset) {
/* 333 */         localMin.add(255);
/* 334 */         int t2 = t - this.offset;
/* 335 */         int x = t2;
/* 336 */         int y = d - t2;
/* 337 */         if (x >= 0 && y >= 0 && x < width && y < height)
/* 338 */           image.set(x, y, localMin.getMax()); 
/* 339 */         t++;
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 344 */     if (showProgress()) {
/* 345 */       IJ.showProgress(1.0D);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private void inPlaceErosionFloat(ImageProcessor image) {
/* 351 */     int width = image.getWidth();
/* 352 */     int height = image.getHeight();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 357 */     int dmin = 0;
/* 358 */     int dmax = width + height - 1;
/*     */ 
/*     */     
/* 361 */     LocalExtremumBufferDouble localMin = new LocalExtremumBufferDouble(this.size, 
/* 362 */         LocalExtremum.Type.MINIMUM);
/*     */ 
/*     */     
/* 365 */     for (int d = dmin; d < dmax; d++) {
/* 366 */       if (showProgress()) {
/* 367 */         IJ.showProgress(d, dmax - dmin);
/*     */       }
/* 369 */       fireProgressChanged(this, (d - dmin), (dmax - dmin));
/*     */ 
/*     */       
/* 372 */       localMin.fill(Double.POSITIVE_INFINITY);
/*     */       
/* 374 */       int xmin = Math.max(0, d - height - 1);
/* 375 */       int xmax = Math.min(width, d + 1);
/* 376 */       int ymin = Math.max(0, d - width - 1);
/* 377 */       int ymax = Math.min(height, d + 1);
/*     */       
/* 379 */       int tmin = Math.max(xmin, d - ymax + 1);
/* 380 */       int tmax = Math.min(xmax, d - ymin + 1);
/*     */ 
/*     */       
/* 383 */       int t = tmin;
/*     */ 
/*     */       
/* 386 */       while (t < Math.min(tmin + this.offset, tmax)) {
/* 387 */         localMin.add(image.getf(t, d - t));
/* 388 */         t++;
/*     */       } 
/*     */ 
/*     */       
/* 392 */       while (t < tmax) {
/* 393 */         localMin.add(image.getf(t, d - t));
/* 394 */         int t2 = t - this.offset;
/* 395 */         image.setf(t2, d - t2, (float)localMin.getMax());
/* 396 */         t++;
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 401 */       while (t < tmax + this.offset) {
/* 402 */         localMin.add(Double.POSITIVE_INFINITY);
/* 403 */         int t2 = t - this.offset;
/* 404 */         int x = t2;
/* 405 */         int y = d - t2;
/* 406 */         if (x >= 0 && y >= 0 && x < width && y < height)
/* 407 */           image.setf(x, y, (float)localMin.getMax()); 
/* 408 */         t++;
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 413 */     if (showProgress()) {
/* 414 */       IJ.showProgress(1.0D);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int[][] getMask() {
/* 423 */     int[][] mask = new int[this.size][this.size];
/* 424 */     for (int i = 0; i < this.size; i++) {
/* 425 */       mask[i][i] = 255;
/*     */     }
/*     */     
/* 428 */     return mask;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int[] getOffset() {
/* 436 */     return new int[] { this.offset, this.offset };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int[][] getShifts() {
/* 444 */     int[][] shifts = new int[this.size][2];
/* 445 */     for (int i = 0; i < this.size; i++) {
/* 446 */       shifts[i][0] = i - this.offset;
/* 447 */       shifts[i][1] = i - this.offset;
/*     */     } 
/* 449 */     return shifts;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int[] getSize() {
/* 457 */     return new int[] { this.size, this.size };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LinearDiagUpStrel reverse() {
/* 466 */     return new LinearDiagUpStrel(this.size, this.size - this.offset - 1);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/morphology/strel/LinearDiagUpStrel.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */