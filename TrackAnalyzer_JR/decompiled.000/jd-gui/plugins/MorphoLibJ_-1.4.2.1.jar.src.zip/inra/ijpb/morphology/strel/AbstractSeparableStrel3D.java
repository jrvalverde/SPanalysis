/*     */ package inra.ijpb.morphology.strel;
/*     */ 
/*     */ import ij.ImageStack;
/*     */ import inra.ijpb.algo.AlgoEvent;
/*     */ import inra.ijpb.algo.AlgoListener;
/*     */ import java.util.Collection;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractSeparableStrel3D
/*     */   extends AbstractStrel3D
/*     */   implements SeparableStrel3D, AlgoListener
/*     */ {
/*     */   public ImageStack dilation(ImageStack stack) {
/*  42 */     ImageStack result = stack.duplicate();
/*     */ 
/*     */     
/*  45 */     Collection<InPlaceStrel3D> strels = decompose();
/*  46 */     int n = strels.size();
/*     */ 
/*     */     
/*  49 */     int i = 1;
/*  50 */     for (InPlaceStrel3D strel : strels) {
/*     */       
/*  52 */       fireStatusChanged(this, "Dilation " + i++ + "/" + n);
/*  53 */       runDilation(result, strel);
/*     */     } 
/*     */ 
/*     */     
/*  57 */     fireStatusChanged(this, "");
/*     */     
/*  59 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ImageStack erosion(ImageStack stack) {
/*  65 */     ImageStack result = stack.duplicate();
/*     */ 
/*     */     
/*  68 */     Collection<InPlaceStrel3D> strels = decompose();
/*  69 */     int n = strels.size();
/*     */ 
/*     */     
/*  72 */     int i = 1;
/*  73 */     for (InPlaceStrel3D strel : strels) {
/*     */       
/*  75 */       fireStatusChanged(this, "Erosion " + i++ + "/" + n);
/*  76 */       runErosion(result, strel);
/*     */     } 
/*     */ 
/*     */     
/*  80 */     fireStatusChanged(this, "");
/*     */     
/*  82 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ImageStack closing(ImageStack stack) {
/*  88 */     ImageStack result = stack.duplicate();
/*     */ 
/*     */     
/*  91 */     Collection<InPlaceStrel3D> strels = decompose();
/*  92 */     int n = strels.size();
/*     */ 
/*     */     
/*  95 */     int i = 1;
/*  96 */     for (InPlaceStrel3D strel : strels) {
/*     */       
/*  98 */       fireStatusChanged(this, "Dilation " + i++ + "/" + n);
/*  99 */       runDilation(result, strel);
/*     */     } 
/*     */ 
/*     */     
/* 103 */     i = 1;
/* 104 */     strels = reverse().decompose();
/* 105 */     for (InPlaceStrel3D strel : strels) {
/*     */       
/* 107 */       fireStatusChanged(this, "Erosion " + i++ + "/" + n);
/* 108 */       runErosion(result, strel);
/*     */     } 
/*     */ 
/*     */     
/* 112 */     fireStatusChanged(this, "");
/*     */     
/* 114 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ImageStack opening(ImageStack stack) {
/* 120 */     ImageStack result = stack.duplicate();
/*     */ 
/*     */     
/* 123 */     Collection<InPlaceStrel3D> strels = decompose();
/* 124 */     int n = strels.size();
/*     */ 
/*     */     
/* 127 */     int i = 1;
/* 128 */     for (InPlaceStrel3D strel : strels) {
/*     */       
/* 130 */       fireStatusChanged(this, "Erosion " + i++ + "/" + n);
/* 131 */       runErosion(result, strel);
/*     */     } 
/*     */ 
/*     */     
/* 135 */     i = 1;
/* 136 */     strels = reverse().decompose();
/* 137 */     for (InPlaceStrel3D strel : strels) {
/*     */       
/* 139 */       fireStatusChanged(this, "Dilation " + i++ + "/" + n);
/* 140 */       runDilation(result, strel);
/*     */     } 
/*     */ 
/*     */     
/* 144 */     fireStatusChanged(this, "");
/*     */     
/* 146 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   private void runDilation(ImageStack image, InPlaceStrel3D strel) {
/* 151 */     strel.showProgress(showProgress());
/* 152 */     strel.addAlgoListener(this);
/* 153 */     strel.inPlaceDilation(image);
/* 154 */     strel.removeAlgoListener(this);
/*     */   }
/*     */ 
/*     */   
/*     */   private void runErosion(ImageStack image, InPlaceStrel3D strel) {
/* 159 */     strel.showProgress(showProgress());
/* 160 */     strel.addAlgoListener(this);
/* 161 */     strel.inPlaceErosion(image);
/* 162 */     strel.removeAlgoListener(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void algoProgressChanged(AlgoEvent evt) {
/* 170 */     fireProgressChanged(this, evt.getCurrentProgress(), evt.getTotalProgress());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void algoStatusChanged(AlgoEvent evt) {
/* 178 */     fireStatusChanged(this, evt.getStatus());
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/morphology/strel/AbstractSeparableStrel3D.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */