/*    */ package inra.ijpb.morphology.geodrec;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum GeodesicReconstructionType
/*    */ {
/* 31 */   BY_DILATION,
/* 32 */   BY_EROSION;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int getSign() {
/* 45 */     switch (this) {
/*    */       
/*    */       case null:
/* 48 */         return 1;
/*    */       case BY_EROSION:
/* 50 */         return -1;
/*    */     } 
/* 52 */     throw new RuntimeException("Unknown case: " + toString());
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/morphology/geodrec/GeodesicReconstructionType.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */