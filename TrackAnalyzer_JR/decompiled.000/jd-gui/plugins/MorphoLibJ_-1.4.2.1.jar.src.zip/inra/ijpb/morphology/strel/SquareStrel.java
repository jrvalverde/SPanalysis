/*     */ package inra.ijpb.morphology.strel;
/*     */ 
/*     */ import inra.ijpb.morphology.Strel;
/*     */ import inra.ijpb.morphology.Strel3D;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SquareStrel
/*     */   extends AbstractSeparableStrel
/*     */ {
/*     */   int size;
/*     */   int offset;
/*     */   
/*     */   public static final SquareStrel fromDiameter(int diam) {
/*  43 */     return new SquareStrel(diam);
/*     */   }
/*     */   
/*     */   public static final SquareStrel fromRadius(int radius) {
/*  47 */     return new SquareStrel(2 * radius + 1, radius);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SquareStrel(int size) {
/*  72 */     if (size < 1) {
/*  73 */       throw new RuntimeException("Requires a positive size");
/*     */     }
/*  75 */     this.size = size;
/*     */     
/*  77 */     this.offset = (int)Math.floor(((this.size - 1) / 2));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SquareStrel(int size, int offset) {
/*  87 */     if (size < 1) {
/*  88 */       throw new RuntimeException("Requires a positive size");
/*     */     }
/*  90 */     this.size = size;
/*     */     
/*  92 */     if (offset < 0) {
/*  93 */       throw new RuntimeException("Requires a non-negative offset");
/*     */     }
/*  95 */     if (offset >= size) {
/*  96 */       throw new RuntimeException("Offset can not be greater than size");
/*     */     }
/*  98 */     this.offset = offset;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection<InPlaceStrel> decompose() {
/* 110 */     ArrayList<InPlaceStrel> strels = new ArrayList<InPlaceStrel>(2);
/* 111 */     strels.add(new LinearHorizontalStrel(this.size, this.offset));
/* 112 */     strels.add(new LinearVerticalStrel(this.size, this.offset));
/* 113 */     return strels;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int[][] getMask() {
/* 121 */     int[][] mask = new int[this.size][this.size];
/* 122 */     for (int y = 0; y < this.size; y++) {
/* 123 */       for (int x = 0; x < this.size; x++) {
/* 124 */         mask[y][x] = 255;
/*     */       }
/*     */     } 
/*     */     
/* 128 */     return mask;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int[] getOffset() {
/* 136 */     return new int[] { this.offset, this.offset };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int[][] getShifts() {
/* 144 */     int n = this.size * this.size;
/* 145 */     int[][] shifts = new int[n][2];
/* 146 */     int i = 0;
/*     */     
/* 148 */     for (int y = 0; y < this.size; y++) {
/* 149 */       for (int x = 0; x < this.size; x++) {
/* 150 */         shifts[i][0] = x - this.offset;
/* 151 */         shifts[i][1] = y - this.offset;
/* 152 */         i++;
/*     */       } 
/*     */     } 
/* 155 */     return shifts;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int[] getSize() {
/* 163 */     return new int[] { this.size, this.size };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SquareStrel reverse() {
/* 171 */     return new SquareStrel(this.size, this.size - this.offset - 1);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/morphology/strel/SquareStrel.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */