/*    */ package inra.ijpb.morphology.directional;
/*    */ 
/*    */ import inra.ijpb.morphology.Strel;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class OrientedLineStrelFactory
/*    */   implements OrientedStrelFactory
/*    */ {
/*    */   double length;
/*    */   
/*    */   public OrientedLineStrelFactory(double length) {
/* 46 */     this.length = length;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public OrientedLineStrel createStrel(double theta) {
/* 58 */     return new OrientedLineStrel(this.length, theta);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/morphology/directional/OrientedLineStrelFactory.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */