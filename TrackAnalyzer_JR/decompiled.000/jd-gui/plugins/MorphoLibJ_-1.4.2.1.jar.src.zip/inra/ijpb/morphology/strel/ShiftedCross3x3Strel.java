/*     */ package inra.ijpb.morphology.strel;
/*     */ 
/*     */ import ij.process.ImageProcessor;
/*     */ import inra.ijpb.morphology.Strel;
/*     */ import inra.ijpb.morphology.Strel3D;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ShiftedCross3x3Strel
/*     */ {
/*  52 */   public static final InPlaceStrel LEFT = new Left();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  68 */   public static final InPlaceStrel RIGHT = new Right();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class Left
/*     */     extends AbstractInPlaceStrel
/*     */   {
/*     */     public int[] getSize() {
/*  97 */       return new int[] { 3, 3 };
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int[][] getMask() {
/* 105 */       int[][] mask = new int[3][];
/* 106 */       (new int[3])[1] = 255; mask[0] = new int[3];
/* 107 */       (new int[3])[0] = 255; (new int[3])[1] = 255; (new int[3])[2] = 255; mask[1] = new int[3];
/* 108 */       (new int[3])[1] = 255; mask[2] = new int[3];
/* 109 */       return mask;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int[] getOffset() {
/* 117 */       return new int[] { 2, 1 };
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int[][] getShifts() {
/* 125 */       int[][] shifts = {
/* 126 */           { -1, -1
/* 127 */           }, { -2
/* 128 */           }, { -1
/* 129 */           }, new int[2], {
/* 130 */             -1, 1 } };
/* 131 */       return shifts;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public InPlaceStrel reverse() {
/* 140 */       return ShiftedCross3x3Strel.RIGHT;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void inPlaceDilation(ImageProcessor image) {
/* 148 */       if (image instanceof ij.process.ByteProcessor) {
/* 149 */         inPlaceDilationGray8(image);
/*     */       } else {
/* 151 */         inPlaceDilationFloat(image);
/*     */       } 
/*     */     }
/*     */     
/*     */     private void inPlaceDilationGray8(ImageProcessor image) {
/* 156 */       int width = image.getWidth();
/* 157 */       int height = image.getHeight();
/*     */       
/* 159 */       int[][] buffer = new int[3][width];
/*     */ 
/*     */       
/* 162 */       for (int x = 0; x < width; x++) {
/* 163 */         buffer[0][x] = 0;
/* 164 */         buffer[1][x] = 0;
/* 165 */         buffer[2][x] = image.get(x, 0);
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 170 */       for (int y = 0; y < height; y++) {
/* 171 */         fireProgressChanged(this, y, height);
/*     */ 
/*     */         
/* 174 */         int[] tmp = buffer[0];
/* 175 */         buffer[0] = buffer[1];
/* 176 */         buffer[1] = buffer[2];
/*     */ 
/*     */         
/* 179 */         if (y < height - 1) {
/* 180 */           for (int j = 0; j < width; j++)
/* 181 */             tmp[j] = image.get(j, y + 1); 
/*     */         } else {
/* 183 */           for (int j = 0; j < width; j++)
/* 184 */             tmp[j] = 0; 
/*     */         } 
/* 186 */         buffer[2] = tmp;
/*     */ 
/*     */         
/* 189 */         int valMax = Math.max(buffer[1][0], 0);
/* 190 */         image.set(0, y, valMax);
/* 191 */         valMax = ShiftedCross3x3Strel.max5(buffer[0][0], buffer[1][0], 
/* 192 */             buffer[1][1], buffer[2][0], 0);
/* 193 */         image.set(1, y, valMax);
/*     */ 
/*     */         
/* 196 */         for (int i = 2; i < width; i++) {
/* 197 */           valMax = ShiftedCross3x3Strel.max5(buffer[0][i - 1], buffer[1][i - 2], buffer[1][i - 1], 
/* 198 */               buffer[1][i], buffer[2][i - 1]);
/* 199 */           image.set(i, y, valMax);
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 204 */       fireProgressChanged(this, height, height);
/*     */     }
/*     */ 
/*     */     
/*     */     private void inPlaceDilationFloat(ImageProcessor image) {
/* 209 */       int width = image.getWidth();
/* 210 */       int height = image.getHeight();
/*     */       
/* 212 */       float[][] buffer = new float[3][width];
/*     */ 
/*     */       
/* 215 */       for (int x = 0; x < width; x++) {
/* 216 */         buffer[0][x] = Float.NEGATIVE_INFINITY;
/* 217 */         buffer[1][x] = Float.NEGATIVE_INFINITY;
/* 218 */         buffer[2][x] = image.getf(x, 0);
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 223 */       for (int y = 0; y < height; y++) {
/* 224 */         fireProgressChanged(this, y, height);
/*     */ 
/*     */         
/* 227 */         float[] tmp = buffer[0];
/* 228 */         buffer[0] = buffer[1];
/* 229 */         buffer[1] = buffer[2];
/*     */ 
/*     */         
/* 232 */         if (y < height - 1) {
/* 233 */           for (int j = 0; j < width; j++)
/* 234 */             tmp[j] = image.getf(j, y + 1); 
/*     */         } else {
/* 236 */           for (int j = 0; j < width; j++)
/* 237 */             tmp[j] = Float.NEGATIVE_INFINITY; 
/*     */         } 
/* 239 */         buffer[2] = tmp;
/*     */ 
/*     */         
/* 242 */         float valMax = Math.max(buffer[1][0], Float.NEGATIVE_INFINITY);
/* 243 */         image.setf(0, y, valMax);
/* 244 */         valMax = ShiftedCross3x3Strel.max5(buffer[0][0], buffer[1][0], 
/* 245 */             buffer[1][1], buffer[2][0], Float.NEGATIVE_INFINITY);
/* 246 */         image.setf(1, y, valMax);
/*     */ 
/*     */         
/* 249 */         for (int i = 2; i < width; i++) {
/* 250 */           valMax = ShiftedCross3x3Strel.max5(buffer[0][i - 1], buffer[1][i - 2], buffer[1][i - 1], 
/* 251 */               buffer[1][i], buffer[2][i - 1]);
/* 252 */           image.setf(i, y, valMax);
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 257 */       fireProgressChanged(this, height, height);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void inPlaceErosion(ImageProcessor image) {
/* 265 */       if (image instanceof ij.process.ByteProcessor) {
/* 266 */         inPlaceErosionGray8(image);
/*     */       } else {
/* 268 */         inPlaceErosionFloat(image);
/*     */       } 
/*     */     }
/*     */     
/*     */     private void inPlaceErosionGray8(ImageProcessor image) {
/* 273 */       int width = image.getWidth();
/* 274 */       int height = image.getHeight();
/*     */       
/* 276 */       int[][] buffer = new int[3][width];
/*     */ 
/*     */       
/* 279 */       for (int x = 0; x < width; x++) {
/* 280 */         buffer[0][x] = 255;
/* 281 */         buffer[1][x] = 255;
/* 282 */         buffer[2][x] = image.get(x, 0);
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 287 */       for (int y = 0; y < height; y++) {
/* 288 */         fireProgressChanged(this, y, height);
/*     */ 
/*     */         
/* 291 */         int[] tmp = buffer[0];
/* 292 */         buffer[0] = buffer[1];
/* 293 */         buffer[1] = buffer[2];
/*     */ 
/*     */         
/* 296 */         if (y < height - 1) {
/* 297 */           for (int j = 0; j < width; j++)
/* 298 */             tmp[j] = image.get(j, y + 1); 
/*     */         } else {
/* 300 */           for (int j = 0; j < width; j++)
/* 301 */             tmp[j] = 255; 
/*     */         } 
/* 303 */         buffer[2] = tmp;
/*     */ 
/*     */         
/* 306 */         int valMin = Math.min(buffer[1][0], 255);
/* 307 */         image.set(0, y, valMin);
/* 308 */         valMin = ShiftedCross3x3Strel.min5(buffer[0][0], buffer[1][0], 
/* 309 */             buffer[1][1], buffer[2][0], 255);
/* 310 */         image.set(1, y, valMin);
/*     */ 
/*     */         
/* 313 */         for (int i = 2; i < width; i++) {
/* 314 */           valMin = ShiftedCross3x3Strel.min5(buffer[0][i - 1], buffer[1][i - 2], buffer[1][i - 1], 
/* 315 */               buffer[1][i], buffer[2][i - 1]);
/* 316 */           image.set(i, y, valMin);
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 321 */       fireProgressChanged(this, height, height);
/*     */     }
/*     */ 
/*     */     
/*     */     private void inPlaceErosionFloat(ImageProcessor image) {
/* 326 */       int width = image.getWidth();
/* 327 */       int height = image.getHeight();
/*     */       
/* 329 */       float[][] buffer = new float[3][width];
/*     */ 
/*     */       
/* 332 */       for (int x = 0; x < width; x++) {
/* 333 */         buffer[0][x] = Float.POSITIVE_INFINITY;
/* 334 */         buffer[1][x] = Float.POSITIVE_INFINITY;
/* 335 */         buffer[2][x] = image.getf(x, 0);
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 340 */       for (int y = 0; y < height; y++) {
/* 341 */         fireProgressChanged(this, y, height);
/*     */ 
/*     */         
/* 344 */         float[] tmp = buffer[0];
/* 345 */         buffer[0] = buffer[1];
/* 346 */         buffer[1] = buffer[2];
/*     */ 
/*     */         
/* 349 */         if (y < height - 1) {
/* 350 */           for (int j = 0; j < width; j++)
/* 351 */             tmp[j] = image.getf(j, y + 1); 
/*     */         } else {
/* 353 */           for (int j = 0; j < width; j++)
/* 354 */             tmp[j] = Float.POSITIVE_INFINITY; 
/*     */         } 
/* 356 */         buffer[2] = tmp;
/*     */ 
/*     */         
/* 359 */         float valMin = Math.min(buffer[1][0], Float.POSITIVE_INFINITY);
/* 360 */         image.setf(0, y, valMin);
/* 361 */         valMin = ShiftedCross3x3Strel.min5(buffer[0][0], buffer[1][0], 
/* 362 */             buffer[1][1], buffer[2][0], Float.POSITIVE_INFINITY);
/* 363 */         image.setf(1, y, valMin);
/*     */ 
/*     */         
/* 366 */         for (int i = 2; i < width; i++) {
/* 367 */           valMin = ShiftedCross3x3Strel.min5(buffer[0][i - 1], buffer[1][i - 2], buffer[1][i - 1], 
/* 368 */               buffer[1][i], buffer[2][i - 1]);
/* 369 */           image.setf(i, y, valMin);
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 374 */       fireProgressChanged(this, height, height);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class Right
/*     */     extends AbstractInPlaceStrel
/*     */   {
/*     */     public int[] getSize() {
/* 405 */       return new int[] { 3, 3 };
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int[][] getMask() {
/* 413 */       int[][] mask = new int[3][];
/* 414 */       (new int[3])[1] = 255; mask[0] = new int[3];
/* 415 */       (new int[3])[0] = 255; (new int[3])[1] = 255; (new int[3])[2] = 255; mask[1] = new int[3];
/* 416 */       (new int[3])[1] = 255; mask[2] = new int[3];
/* 417 */       return mask;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int[] getOffset() {
/* 425 */       return new int[] { 0, 1 };
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int[][] getShifts() {
/* 433 */       int[][] shifts = {
/* 434 */           { 1, -1
/* 435 */           }, new int[2], {
/* 436 */             1
/* 437 */           }, { 2
/* 438 */           }, { 1, 1 } };
/* 439 */       return shifts;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public InPlaceStrel reverse() {
/* 448 */       return ShiftedCross3x3Strel.LEFT;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void inPlaceDilation(ImageProcessor image) {
/* 456 */       if (image instanceof ij.process.ByteProcessor) {
/* 457 */         inPlaceDilationGray8(image);
/*     */       } else {
/* 459 */         inPlaceDilationFloat(image);
/*     */       } 
/*     */     }
/*     */     
/*     */     private void inPlaceDilationGray8(ImageProcessor image) {
/* 464 */       int width = image.getWidth();
/* 465 */       int height = image.getHeight();
/*     */       
/* 467 */       int[][] buffer = new int[3][width];
/*     */ 
/*     */       
/* 470 */       for (int x = 0; x < width; x++) {
/* 471 */         buffer[0][x] = 0;
/* 472 */         buffer[1][x] = 0;
/* 473 */         buffer[2][x] = image.get(x, 0);
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 478 */       for (int y = 0; y < height; y++) {
/* 479 */         fireProgressChanged(this, y, height);
/*     */ 
/*     */         
/* 482 */         int[] tmp = buffer[0];
/* 483 */         buffer[0] = buffer[1];
/* 484 */         buffer[1] = buffer[2];
/*     */ 
/*     */         
/* 487 */         if (y < height - 1) {
/* 488 */           for (int j = 0; j < width; j++)
/* 489 */             tmp[j] = image.get(j, y + 1); 
/*     */         } else {
/* 491 */           for (int j = 0; j < width; j++)
/* 492 */             tmp[j] = 0; 
/*     */         } 
/* 494 */         buffer[2] = tmp;
/*     */ 
/*     */         
/* 497 */         for (int i = 0; i < width - 2; i++) {
/* 498 */           int j = ShiftedCross3x3Strel.max5(buffer[0][i + 1], buffer[1][i], buffer[1][i + 1], 
/* 499 */               buffer[1][i + 2], buffer[2][i + 1]);
/* 500 */           image.set(i, y, j);
/*     */         } 
/*     */ 
/*     */         
/* 504 */         int valMax = ShiftedCross3x3Strel.max5(buffer[0][width - 1], buffer[1][width - 2], 
/* 505 */             buffer[1][width - 1], buffer[2][width - 1], 0);
/* 506 */         image.set(width - 2, y, valMax);
/* 507 */         valMax = Math.max(buffer[1][width - 1], 0);
/* 508 */         image.set(width - 1, y, valMax);
/*     */       } 
/*     */ 
/*     */       
/* 512 */       fireProgressChanged(this, height, height);
/*     */     }
/*     */ 
/*     */     
/*     */     private void inPlaceDilationFloat(ImageProcessor image) {
/* 517 */       int width = image.getWidth();
/* 518 */       int height = image.getHeight();
/*     */       
/* 520 */       float[][] buffer = new float[3][width];
/*     */ 
/*     */       
/* 523 */       for (int x = 0; x < width; x++) {
/* 524 */         buffer[0][x] = Float.NEGATIVE_INFINITY;
/* 525 */         buffer[1][x] = Float.NEGATIVE_INFINITY;
/* 526 */         buffer[2][x] = image.getf(x, 0);
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 531 */       for (int y = 0; y < height; y++) {
/* 532 */         fireProgressChanged(this, y, height);
/*     */ 
/*     */         
/* 535 */         float[] tmp = buffer[0];
/* 536 */         buffer[0] = buffer[1];
/* 537 */         buffer[1] = buffer[2];
/*     */ 
/*     */         
/* 540 */         if (y < height - 1) {
/* 541 */           for (int j = 0; j < width; j++)
/* 542 */             tmp[j] = image.getf(j, y + 1); 
/*     */         } else {
/* 544 */           for (int j = 0; j < width; j++)
/* 545 */             tmp[j] = Float.NEGATIVE_INFINITY; 
/*     */         } 
/* 547 */         buffer[2] = tmp;
/*     */ 
/*     */         
/* 550 */         for (int i = 0; i < width - 2; i++) {
/* 551 */           float f = ShiftedCross3x3Strel.max5(buffer[0][i + 1], buffer[1][i], buffer[1][i + 1], 
/* 552 */               buffer[1][i + 2], buffer[2][i + 1]);
/* 553 */           image.setf(i, y, f);
/*     */         } 
/*     */ 
/*     */         
/* 557 */         float valMax = ShiftedCross3x3Strel.max5(buffer[0][width - 1], buffer[1][width - 2], 
/* 558 */             buffer[1][width - 1], buffer[2][width - 1], Float.NEGATIVE_INFINITY);
/* 559 */         image.setf(width - 2, y, valMax);
/* 560 */         valMax = Math.max(buffer[1][width - 1], Float.NEGATIVE_INFINITY);
/* 561 */         image.setf(width - 1, y, valMax);
/*     */       } 
/*     */ 
/*     */       
/* 565 */       fireProgressChanged(this, height, height);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void inPlaceErosion(ImageProcessor image) {
/* 573 */       if (image instanceof ij.process.ByteProcessor) {
/* 574 */         inPlaceErosionGray8(image);
/*     */       } else {
/* 576 */         inPlaceErosionFloat(image);
/*     */       } 
/*     */     }
/*     */     
/*     */     private void inPlaceErosionGray8(ImageProcessor image) {
/* 581 */       int width = image.getWidth();
/* 582 */       int height = image.getHeight();
/*     */       
/* 584 */       int[][] buffer = new int[3][width];
/*     */ 
/*     */       
/* 587 */       for (int x = 0; x < width; x++) {
/* 588 */         buffer[0][x] = 255;
/* 589 */         buffer[1][x] = 255;
/* 590 */         buffer[2][x] = image.get(x, 0);
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 595 */       for (int y = 0; y < height; y++) {
/* 596 */         fireProgressChanged(this, y, height);
/*     */ 
/*     */         
/* 599 */         int[] tmp = buffer[0];
/* 600 */         buffer[0] = buffer[1];
/* 601 */         buffer[1] = buffer[2];
/*     */ 
/*     */         
/* 604 */         if (y < height - 1) {
/* 605 */           for (int j = 0; j < width; j++)
/* 606 */             tmp[j] = image.get(j, y + 1); 
/*     */         } else {
/* 608 */           for (int j = 0; j < width; j++)
/* 609 */             tmp[j] = 255; 
/*     */         } 
/* 611 */         buffer[2] = tmp;
/*     */ 
/*     */         
/* 614 */         for (int i = 0; i < width - 2; i++) {
/* 615 */           int j = ShiftedCross3x3Strel.min5(buffer[0][i + 1], buffer[1][i], buffer[1][i + 1], 
/* 616 */               buffer[1][i + 2], buffer[2][i + 1]);
/* 617 */           image.set(i, y, j);
/*     */         } 
/*     */ 
/*     */         
/* 621 */         int valMin = ShiftedCross3x3Strel.min5(buffer[0][width - 1], buffer[1][width - 2], 
/* 622 */             buffer[1][width - 1], buffer[2][width - 1], 255);
/* 623 */         image.set(width - 2, y, valMin);
/* 624 */         valMin = Math.min(buffer[1][width - 1], 255);
/* 625 */         image.set(width - 1, y, valMin);
/*     */       } 
/*     */ 
/*     */       
/* 629 */       fireProgressChanged(this, height, height);
/*     */     }
/*     */ 
/*     */     
/*     */     private void inPlaceErosionFloat(ImageProcessor image) {
/* 634 */       int width = image.getWidth();
/* 635 */       int height = image.getHeight();
/*     */       
/* 637 */       float[][] buffer = new float[3][width];
/*     */ 
/*     */       
/* 640 */       for (int x = 0; x < width; x++) {
/* 641 */         buffer[0][x] = Float.POSITIVE_INFINITY;
/* 642 */         buffer[1][x] = Float.POSITIVE_INFINITY;
/* 643 */         buffer[2][x] = image.getf(x, 0);
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 648 */       for (int y = 0; y < height; y++) {
/* 649 */         fireProgressChanged(this, y, height);
/*     */ 
/*     */         
/* 652 */         float[] tmp = buffer[0];
/* 653 */         buffer[0] = buffer[1];
/* 654 */         buffer[1] = buffer[2];
/*     */ 
/*     */         
/* 657 */         if (y < height - 1) {
/* 658 */           for (int j = 0; j < width; j++)
/* 659 */             tmp[j] = image.getf(j, y + 1); 
/*     */         } else {
/* 661 */           for (int j = 0; j < width; j++)
/* 662 */             tmp[j] = Float.POSITIVE_INFINITY; 
/*     */         } 
/* 664 */         buffer[2] = tmp;
/*     */ 
/*     */         
/* 667 */         for (int i = 0; i < width - 2; i++) {
/* 668 */           float f = ShiftedCross3x3Strel.min5(buffer[0][i + 1], buffer[1][i], buffer[1][i + 1], 
/* 669 */               buffer[1][i + 2], buffer[2][i + 1]);
/* 670 */           image.setf(i, y, f);
/*     */         } 
/*     */ 
/*     */         
/* 674 */         float valMin = ShiftedCross3x3Strel.min5(buffer[0][width - 1], buffer[1][width - 2], 
/* 675 */             buffer[1][width - 1], buffer[2][width - 1], Float.POSITIVE_INFINITY);
/* 676 */         image.setf(width - 2, y, valMin);
/* 677 */         valMin = Math.min(buffer[1][width - 1], Float.POSITIVE_INFINITY);
/* 678 */         image.setf(width - 1, y, valMin);
/*     */       } 
/*     */ 
/*     */       
/* 682 */       fireProgressChanged(this, height, height);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final int min5(int v1, int v2, int v3, int v4, int v5) {
/* 697 */     int min1 = Math.min(v1, v2);
/* 698 */     int min2 = Math.min(v3, v4);
/* 699 */     min1 = Math.min(min1, v5);
/* 700 */     return Math.min(min1, min2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final float min5(float v1, float v2, float v3, float v4, float v5) {
/* 707 */     float min1 = Math.min(v1, v2);
/* 708 */     float min2 = Math.min(v3, v4);
/* 709 */     min1 = Math.min(min1, v5);
/* 710 */     return Math.min(min1, min2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final int max5(int v1, int v2, int v3, int v4, int v5) {
/* 717 */     int max1 = Math.max(v1, v2);
/* 718 */     int max2 = Math.max(v3, v4);
/* 719 */     max1 = Math.max(max1, v5);
/* 720 */     return Math.max(max1, max2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final float max5(float v1, float v2, float v3, float v4, float v5) {
/* 727 */     float max1 = Math.max(v1, v2);
/* 728 */     float max2 = Math.max(v3, v4);
/* 729 */     max1 = Math.max(max1, v5);
/* 730 */     return Math.max(max1, max2);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/morphology/strel/ShiftedCross3x3Strel.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */