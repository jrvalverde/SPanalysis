/*     */ package inra.ijpb.morphology.attrfilt;
/*     */ 
/*     */ import ij.ImageStack;
/*     */ import inra.ijpb.algo.AlgoStub;
/*     */ import inra.ijpb.data.Cursor3D;
/*     */ import inra.ijpb.data.Neighborhood3DC26;
/*     */ import inra.ijpb.data.Neighborhood3DC6;
/*     */ import inra.ijpb.data.image.Image3D;
/*     */ import inra.ijpb.data.image.Images3D;
/*     */ import inra.ijpb.morphology.FloodFill3D;
/*     */ import inra.ijpb.morphology.MinimaAndMaxima3D;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Comparator;
/*     */ import java.util.PriorityQueue;
/*     */ import java.util.Queue;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SizeOpening3DQueue
/*     */   extends AlgoStub
/*     */   implements SizeOpening3D
/*     */ {
/*     */   int conn;
/*     */   
/*     */   public SizeOpening3DQueue() {
/*  51 */     this.conn = 6;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setConnectivity(int connectivity) {
/*  60 */     if (this.conn != 6 && this.conn != 26)
/*     */     {
/*  62 */       throw new IllegalArgumentException("Connectivity must be either 6 or 26, not " + connectivity);
/*     */     }
/*     */     
/*  65 */     this.conn = connectivity;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getConnectivity() {
/*  75 */     return this.conn;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ImageStack process(ImageStack image, int minVolume) {
/*     */     Neighborhood3DC6 neighborhood3DC6;
/*     */     Neighborhood3DC26 neighborhood3DC26;
/*  85 */     int sizeX = image.getWidth();
/*  86 */     int sizeY = image.getHeight();
/*  87 */     int sizeZ = image.getSize();
/*     */ 
/*     */     
/*  90 */     switch (this.conn) {
/*     */       
/*     */       case 6:
/*  93 */         neighborhood3DC6 = new Neighborhood3DC6();
/*     */         break;
/*     */       case 26:
/*  96 */         neighborhood3DC26 = new Neighborhood3DC26();
/*     */         break;
/*     */       default:
/*  99 */         throw new RuntimeException("Unknown connectivity: " + this.conn);
/*     */     } 
/*     */ 
/*     */     
/* 103 */     fireStatusChanged(this, "Finding maxima positions...");
/* 104 */     Collection<Cursor3D> maximaPositions = findMaximaPositions(image);
/*     */ 
/*     */     
/* 107 */     ImageStack result = image.duplicate();
/* 108 */     Image3D result2 = Images3D.createWrapper(result);
/*     */     
/* 110 */     fireStatusChanged(this, "Iterating over maxima...");
/* 111 */     double iter = 0.0D;
/* 112 */     double maxIter = maximaPositions.size();
/*     */     
/* 114 */     for (Cursor3D pos0 : maximaPositions) {
/*     */       
/* 116 */       iter++;
/* 117 */       fireProgressChanged(this, iter, maxIter);
/*     */       
/* 119 */       ArrayList<Cursor3D> positions = new ArrayList<Cursor3D>();
/*     */ 
/*     */       
/* 122 */       Queue<Cursor3D> queue = new PriorityQueue<Cursor3D>(new Position3DValueComparator(result));
/* 123 */       queue.add(pos0);
/*     */ 
/*     */       
/* 126 */       int nPixels = 0;
/* 127 */       double currentLevel = result2.getValue(pos0.getX(), pos0.getY(), pos0.getZ());
/* 128 */       while (!queue.isEmpty()) {
/*     */ 
/*     */         
/* 131 */         Cursor3D pos = queue.remove();
/*     */ 
/*     */         
/* 134 */         double neighborValue = result2.getValue(pos.getX(), pos.getY(), pos.getZ());
/* 135 */         if (neighborValue > currentLevel) {
/*     */           break;
/*     */         }
/*     */ 
/*     */ 
/*     */         
/* 141 */         positions.add(pos);
/* 142 */         nPixels++;
/* 143 */         currentLevel = neighborValue;
/*     */ 
/*     */         
/* 146 */         if (nPixels >= minVolume) {
/*     */           break;
/*     */         }
/*     */ 
/*     */ 
/*     */         
/* 152 */         neighborhood3DC26.setCursor(pos);
/* 153 */         for (Cursor3D pos2 : neighborhood3DC26.getNeighbors()) {
/*     */           
/* 155 */           int x2 = pos2.getX();
/* 156 */           int y2 = pos2.getY();
/* 157 */           int z2 = pos2.getZ();
/* 158 */           if (x2 >= 0 && x2 < sizeX && y2 >= 0 && y2 < sizeY && z2 >= 0 && z2 < sizeZ)
/*     */           {
/*     */             
/* 161 */             if (!positions.contains(pos2) && !queue.contains(pos2))
/*     */             {
/* 163 */               queue.add(pos2);
/*     */             }
/*     */           }
/*     */         } 
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 171 */       for (Cursor3D pos : positions)
/*     */       {
/* 173 */         result2.setValue(pos.getX(), pos.getY(), pos.getZ(), currentLevel);
/*     */       }
/*     */     } 
/* 176 */     fireProgressChanged(this, 1.0D, 1.0D);
/* 177 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private Collection<Cursor3D> findMaximaPositions(ImageStack image) {
/* 183 */     ImageStack maxima = MinimaAndMaxima3D.regionalMaxima(image, this.conn);
/* 184 */     Image3D maxima2 = Images3D.createWrapper(maxima);
/*     */     
/* 186 */     int sizeX = image.getWidth();
/* 187 */     int sizeY = image.getHeight();
/* 188 */     int sizeZ = image.getSize();
/*     */     
/* 190 */     Collection<Cursor3D> positions = new ArrayList<Cursor3D>();
/*     */     
/* 192 */     for (int z = 0; z < sizeZ; z++) {
/*     */       
/* 194 */       for (int y = 0; y < sizeY; y++) {
/*     */         
/* 196 */         for (int x = 0; x < sizeX; x++) {
/*     */ 
/*     */ 
/*     */           
/* 200 */           if (maxima2.getValue(x, y, z) > 0.0D) {
/*     */             
/* 202 */             positions.add(new Cursor3D(x, y, z));
/* 203 */             FloodFill3D.floodFill(maxima, x, y, z, 0, this.conn);
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/* 208 */     return positions;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   class Position3DValueComparator
/*     */     implements Comparator<Cursor3D>
/*     */   {
/*     */     Image3D image;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     Position3DValueComparator(ImageStack image) {
/* 225 */       this.image = Images3D.createWrapper(image);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public int compare(Cursor3D pos1, Cursor3D pos2) {
/* 231 */       int val1 = this.image.get(pos1.getX(), pos1.getY(), pos1.getZ());
/* 232 */       int val2 = this.image.get(pos2.getX(), pos2.getY(), pos2.getZ());
/* 233 */       if (val1 > val2)
/*     */       {
/* 235 */         return -1;
/*     */       }
/* 237 */       if (val2 > val1)
/*     */       {
/* 239 */         return 1;
/*     */       }
/* 241 */       return 0;
/*     */     }
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/morphology/attrfilt/SizeOpening3DQueue.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */