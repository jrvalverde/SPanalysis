package inra.ijpb.morphology.strel;

import ij.ImageStack;
import inra.ijpb.morphology.Strel3D;

public interface InPlaceStrel3D extends Strel3D {
  void inPlaceDilation(ImageStack paramImageStack);
  
  void inPlaceErosion(ImageStack paramImageStack);
  
  InPlaceStrel3D reverse();
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/morphology/strel/InPlaceStrel3D.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */