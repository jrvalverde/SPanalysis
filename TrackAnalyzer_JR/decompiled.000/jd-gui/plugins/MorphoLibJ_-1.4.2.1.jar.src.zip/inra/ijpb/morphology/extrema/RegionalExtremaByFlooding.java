/*     */ package inra.ijpb.morphology.extrema;
/*     */ 
/*     */ import ij.process.ByteProcessor;
/*     */ import ij.process.ImageProcessor;
/*     */ import inra.ijpb.morphology.FloodFill;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RegionalExtremaByFlooding
/*     */   extends RegionalExtremaAlgo
/*     */ {
/*     */   public ImageProcessor applyTo(ImageProcessor inputImage) {
/*  54 */     if (this.connectivity == 4)
/*     */     {
/*  56 */       return regionalExtremaC4(inputImage);
/*     */     }
/*  58 */     if (this.connectivity == 8)
/*     */     {
/*  60 */       return regionalExtremaC8(inputImage);
/*     */     }
/*     */ 
/*     */     
/*  64 */     throw new IllegalArgumentException("Connectivity must be either 4 or 8, not " + this.connectivity);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ImageProcessor regionalExtremaC4(ImageProcessor image) {
/*  76 */     int sizeX = image.getWidth();
/*  77 */     int sizeY = image.getHeight();
/*     */ 
/*     */     
/*  80 */     ByteProcessor byteProcessor = new ByteProcessor(sizeX, sizeY);
/*  81 */     byteProcessor.setValue(255.0D);
/*  82 */     byteProcessor.fill();
/*     */ 
/*     */     
/*  85 */     int sign = 1;
/*  86 */     if (this.extremaType == ExtremaType.MAXIMA)
/*     */     {
/*  88 */       sign = -1;
/*     */     }
/*     */ 
/*     */     
/*  92 */     for (int y = 0; y < sizeY; y++) {
/*     */       
/*  94 */       for (int x = 0; x < sizeX; x++) {
/*     */ 
/*     */         
/*  97 */         if (byteProcessor.getf(x, y) != 0.0F) {
/*     */ 
/*     */ 
/*     */           
/* 101 */           float currentValue = image.getf(x, y);
/*     */ 
/*     */ 
/*     */           
/* 105 */           float value = currentValue * sign;
/* 106 */           if (x > 0)
/* 107 */             value = Math.min(value, image.getf(x - 1, y) * sign); 
/* 108 */           if (y > 0)
/* 109 */             value = Math.min(value, image.getf(x, y - 1) * sign); 
/* 110 */           if (x < sizeX - 1)
/* 111 */             value = Math.min(value, image.getf(x + 1, y) * sign); 
/* 112 */           if (y < sizeY - 1) {
/* 113 */             value = Math.min(value, image.getf(x, y + 1) * sign);
/*     */           }
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 119 */           if (value < currentValue * sign)
/*     */           {
/* 121 */             FloodFill.floodFillFloat(image, x, y, (ImageProcessor)byteProcessor, 0.0F, 4);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/* 126 */     return (ImageProcessor)byteProcessor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ImageProcessor regionalExtremaC8(ImageProcessor image) {
/* 137 */     int sizeX = image.getWidth();
/* 138 */     int sizeY = image.getHeight();
/*     */ 
/*     */     
/* 141 */     ByteProcessor byteProcessor = new ByteProcessor(sizeX, sizeY);
/* 142 */     byteProcessor.setValue(255.0D);
/* 143 */     byteProcessor.fill();
/*     */ 
/*     */     
/* 146 */     int sign = 1;
/* 147 */     if (this.extremaType == ExtremaType.MAXIMA)
/*     */     {
/* 149 */       sign = -1;
/*     */     }
/*     */ 
/*     */     
/* 153 */     for (int y = 0; y < sizeY; y++) {
/*     */       
/* 155 */       for (int x = 0; x < sizeX; x++) {
/*     */ 
/*     */         
/* 158 */         if (byteProcessor.getf(x, y) != 0.0F) {
/*     */ 
/*     */ 
/*     */           
/* 162 */           float currentValue = image.getf(x, y);
/*     */ 
/*     */ 
/*     */           
/* 166 */           float value = currentValue * sign;
/* 167 */           for (int y2 = Math.max(y - 1, 0); y2 <= Math.min(y + 1, sizeY - 1); y2++) {
/*     */             
/* 169 */             for (int x2 = Math.max(x - 1, 0); x2 <= Math.min(x + 1, sizeX - 1); x2++)
/*     */             {
/* 171 */               value = Math.min(value, image.getf(x2, y2) * sign);
/*     */             }
/*     */           } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 179 */           if (value < currentValue * sign)
/*     */           {
/* 181 */             FloodFill.floodFillFloat(image, x, y, (ImageProcessor)byteProcessor, 0.0F, 8);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/* 186 */     return (ImageProcessor)byteProcessor;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/morphology/extrema/RegionalExtremaByFlooding.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */