/*     */ package inra.ijpb.morphology.extrema;
/*     */ 
/*     */ import ij.process.ImageProcessor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class RegionalExtremaAlgo
/*     */ {
/*  49 */   ExtremaType extremaType = ExtremaType.MINIMA;
/*     */ 
/*     */   
/*  52 */   int connectivity = 4;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean progressVisible = true;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RegionalExtremaAlgo() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RegionalExtremaAlgo(ExtremaType extremaType, int connectivity) {
/*  78 */     this.extremaType = extremaType;
/*  79 */     this.connectivity = connectivity;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getConnectivity() {
/*  88 */     return this.connectivity;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setConnectivity(int conn) {
/*  93 */     this.connectivity = conn;
/*     */   }
/*     */ 
/*     */   
/*     */   public ExtremaType getExtremaType() {
/*  98 */     return this.extremaType;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setExtremaType(ExtremaType extremaType) {
/* 103 */     this.extremaType = extremaType;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isProgressVisible() {
/* 108 */     return this.progressVisible;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setProgressVisible(boolean progressVisible) {
/* 113 */     this.progressVisible = progressVisible;
/*     */   }
/*     */   
/*     */   public abstract ImageProcessor applyTo(ImageProcessor paramImageProcessor);
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/morphology/extrema/RegionalExtremaAlgo.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */