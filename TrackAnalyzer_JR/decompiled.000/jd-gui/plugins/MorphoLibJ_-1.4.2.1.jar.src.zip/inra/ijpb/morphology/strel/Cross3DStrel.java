/*     */ package inra.ijpb.morphology.strel;
/*     */ 
/*     */ import ij.ImageStack;
/*     */ import inra.ijpb.morphology.Strel3D;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Cross3DStrel
/*     */   extends AbstractStrel3D
/*     */ {
/*     */   public int[] getSize() {
/*  45 */     return new int[] { 3, 3, 3 };
/*     */   }
/*     */ 
/*     */   
/*     */   public int[][][] getMask3D() {
/*  50 */     int[][][] mask = new int[3][3][3];
/*  51 */     mask[1][1][1] = 255;
/*  52 */     mask[1][1][0] = 255;
/*  53 */     mask[1][1][2] = 255;
/*  54 */     mask[1][0][1] = 255;
/*  55 */     mask[1][2][1] = 255;
/*  56 */     mask[0][1][1] = 255;
/*  57 */     mask[2][1][1] = 255;
/*  58 */     return mask;
/*     */   }
/*     */ 
/*     */   
/*     */   public int[] getOffset() {
/*  63 */     return new int[] { 1, 1, 1 };
/*     */   }
/*     */ 
/*     */   
/*     */   public int[][] getShifts3D() {
/*  68 */     return new int[][] {
/*  69 */         new int[3], {
/*  70 */           -1
/*  71 */         }, { 1
/*  72 */         }, { 0, -1
/*  73 */         }, { 0, 1
/*  74 */         }, { 0, 0, -1
/*  75 */         }, { 0, 0, 1 }
/*     */       };
/*     */   }
/*     */ 
/*     */   
/*     */   public Strel3D reverse() {
/*  81 */     return new Cross3DStrel();
/*     */   }
/*     */ 
/*     */   
/*     */   public ImageStack dilation(ImageStack image) {
/*  86 */     int sizeX = image.getWidth();
/*  87 */     int sizeY = image.getHeight();
/*  88 */     int sizeZ = image.getSize();
/*     */     
/*  90 */     ImageStack result = image.duplicate();
/*     */     
/*  92 */     for (int z = 0; z < sizeZ; z++) {
/*  93 */       for (int y = 0; y < sizeY; y++) {
/*  94 */         for (int x = 0; x < sizeX; x++) {
/*  95 */           double value = image.getVoxel(x, y, z);
/*  96 */           double maxValue = value;
/*     */ 
/*     */           
/*  99 */           if (x > 0)
/* 100 */             maxValue = Math.max(maxValue, image.getVoxel(x - 1, y, z)); 
/* 101 */           if (x < sizeX - 1)
/* 102 */             maxValue = Math.max(maxValue, image.getVoxel(x + 1, y, z)); 
/* 103 */           if (y > 0)
/* 104 */             maxValue = Math.max(maxValue, image.getVoxel(x, y - 1, z)); 
/* 105 */           if (y < sizeY - 1)
/* 106 */             maxValue = Math.max(maxValue, image.getVoxel(x, y + 1, z)); 
/* 107 */           if (z > 0)
/* 108 */             maxValue = Math.max(maxValue, image.getVoxel(x, y, z - 1)); 
/* 109 */           if (z < sizeZ - 1)
/* 110 */             maxValue = Math.max(maxValue, image.getVoxel(x, y, z + 1)); 
/* 111 */           result.setVoxel(x, y, z, maxValue);
/*     */         } 
/*     */       } 
/*     */     } 
/* 115 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public ImageStack erosion(ImageStack image) {
/* 120 */     int sizeX = image.getWidth();
/* 121 */     int sizeY = image.getHeight();
/* 122 */     int sizeZ = image.getSize();
/*     */     
/* 124 */     ImageStack result = image.duplicate();
/*     */     
/* 126 */     for (int z = 0; z < sizeZ; z++) {
/* 127 */       for (int y = 0; y < sizeY; y++) {
/* 128 */         for (int x = 0; x < sizeX; x++) {
/* 129 */           double value = image.getVoxel(x, y, z);
/* 130 */           double minValue = value;
/*     */ 
/*     */           
/* 133 */           if (x > 0)
/* 134 */             minValue = Math.min(minValue, image.getVoxel(x - 1, y, z)); 
/* 135 */           if (x < sizeX - 1)
/* 136 */             minValue = Math.min(minValue, image.getVoxel(x + 1, y, z)); 
/* 137 */           if (y > 0)
/* 138 */             minValue = Math.min(minValue, image.getVoxel(x, y - 1, z)); 
/* 139 */           if (y < sizeY - 1)
/* 140 */             minValue = Math.min(minValue, image.getVoxel(x, y + 1, z)); 
/* 141 */           if (z > 0)
/* 142 */             minValue = Math.min(minValue, image.getVoxel(x, y, z - 1)); 
/* 143 */           if (z < sizeZ - 1)
/* 144 */             minValue = Math.min(minValue, image.getVoxel(x, y, z + 1)); 
/* 145 */           result.setVoxel(x, y, z, minValue);
/*     */         } 
/*     */       } 
/*     */     } 
/* 149 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public ImageStack closing(ImageStack image) {
/* 154 */     return erosion(dilation(image));
/*     */   }
/*     */ 
/*     */   
/*     */   public ImageStack opening(ImageStack image) {
/* 159 */     return dilation(erosion(image));
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/morphology/strel/Cross3DStrel.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */