/*     */ package inra.ijpb.morphology.directional;
/*     */ 
/*     */ import ij.process.ImageProcessor;
/*     */ import inra.ijpb.algo.AlgoStub;
/*     */ import inra.ijpb.data.border.MirroringBorder;
/*     */ import inra.ijpb.morphology.Strel;
/*     */ import java.util.Arrays;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DirectionalFilter
/*     */   extends AlgoStub
/*     */ {
/*     */   public enum Type
/*     */   {
/*  60 */     MIN(
/*  61 */       "Min"),
/*  62 */     MAX(
/*  63 */       "Max");
/*     */     
/*     */     private final String label;
/*     */ 
/*     */     
/*     */     Type(String label) {
/*  69 */       this.label = label;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/*  74 */       return this.label;
/*     */     }
/*     */ 
/*     */     
/*     */     public static String[] getAllLabels() {
/*  79 */       int n = (values()).length;
/*  80 */       String[] result = new String[n];
/*     */       
/*  82 */       int i = 0; byte b; int j; Type[] arrayOfType;
/*  83 */       for (j = (arrayOfType = values()).length, b = 0; b < j; ) { Type op = arrayOfType[b];
/*  84 */         result[i++] = op.label; b++; }
/*     */       
/*  86 */       return result;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static Type fromLabel(String typeLabel) {
/*  97 */       if (typeLabel != null)
/*  98 */         typeLabel = typeLabel.toLowerCase();  byte b; int i; Type[] arrayOfType;
/*  99 */       for (i = (arrayOfType = values()).length, b = 0; b < i; ) { Type type = arrayOfType[b];
/*     */         
/* 101 */         String cmp = type.label.toLowerCase();
/* 102 */         if (cmp.equals(typeLabel))
/* 103 */           return type;  b++; }
/*     */       
/* 105 */       throw new IllegalArgumentException("Unable to parse Operation with label: " + typeLabel);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum Operation
/*     */   {
/* 114 */     EROSION("Erosion"),
/* 115 */     DILATION("Dilation"),
/* 116 */     OPENING("Opening"),
/* 117 */     CLOSING("Closing"),
/* 118 */     MEAN("Mean"),
/* 119 */     MEDIAN("Median");
/*     */     
/*     */     private final String label;
/*     */ 
/*     */     
/*     */     Operation(String label) {
/* 125 */       this.label = label;
/*     */     }
/*     */ 
/*     */     
/*     */     public ImageProcessor apply(ImageProcessor image, Strel strel) {
/* 130 */       if (this == DILATION)
/* 131 */         return strel.dilation(image); 
/* 132 */       if (this == EROSION)
/* 133 */         return strel.erosion(image); 
/* 134 */       if (this == CLOSING)
/* 135 */         return strel.closing(image); 
/* 136 */       if (this == OPENING)
/* 137 */         return strel.opening(image); 
/* 138 */       if (this == MEAN)
/* 139 */         return DirectionalFilter.mean(image, strel); 
/* 140 */       if (this == MEDIAN) {
/* 141 */         return DirectionalFilter.median(image, strel);
/*     */       }
/* 143 */       throw new RuntimeException("Unable to process the " + this + 
/* 144 */           " filter operation");
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 149 */       return this.label;
/*     */     }
/*     */ 
/*     */     
/*     */     public static String[] getAllLabels() {
/* 154 */       int n = (values()).length;
/* 155 */       String[] result = new String[n];
/*     */       
/* 157 */       int i = 0; byte b; int j; Operation[] arrayOfOperation;
/* 158 */       for (j = (arrayOfOperation = values()).length, b = 0; b < j; ) { Operation op = arrayOfOperation[b];
/* 159 */         result[i++] = op.label; b++; }
/*     */       
/* 161 */       return result;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static Operation fromLabel(String opLabel) {
/* 174 */       if (opLabel != null)
/* 175 */         opLabel = opLabel.toLowerCase();  byte b; int i; Operation[] arrayOfOperation;
/* 176 */       for (i = (arrayOfOperation = values()).length, b = 0; b < i; ) { Operation op = arrayOfOperation[b];
/*     */         
/* 178 */         String cmp = op.label.toLowerCase();
/* 179 */         if (cmp.equals(opLabel))
/* 180 */           return op;  b++; }
/*     */       
/* 182 */       throw new IllegalArgumentException(
/* 183 */           "Unable to parse Operation with label: " + opLabel);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 194 */   Type type = Type.MAX;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 200 */   Operation operation = Operation.OPENING;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   OrientedStrelFactory strelFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int nDirections;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DirectionalFilter(Type type, Operation op, int lineLength, int nTheta) {
/* 240 */     this.type = type;
/* 241 */     this.operation = op;
/* 242 */     this.strelFactory = new OrientedLineStrelFactory(lineLength);
/* 243 */     this.nDirections = nTheta;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DirectionalFilter(Type type, Operation op, OrientedStrelFactory factory, int nTheta) {
/* 262 */     this.type = type;
/* 263 */     this.operation = op;
/* 264 */     this.strelFactory = factory;
/* 265 */     this.nDirections = nTheta;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ImageProcessor process(ImageProcessor image) {
/* 282 */     int sign = (this.type == Type.MAX) ? 1 : -1;
/*     */ 
/*     */     
/* 285 */     ImageProcessor result = image.duplicate();
/* 286 */     if (this.type == Type.MAX) {
/*     */       
/* 288 */       result.setValue(0.0D);
/*     */     }
/*     */     else {
/*     */       
/* 292 */       result.setValue(2.147483647E9D);
/*     */     } 
/* 294 */     result.fill();
/*     */     
/* 296 */     int sizeX = image.getWidth();
/* 297 */     int sizeY = image.getHeight();
/*     */     
/* 299 */     fireStatusChanged(this, "Directional Filter...");
/*     */ 
/*     */     
/* 302 */     for (int i = 0; i < this.nDirections; i++) {
/*     */       
/* 304 */       fireProgressChanged(this, i, this.nDirections);
/*     */ 
/*     */       
/* 307 */       double theta = i * 180.0D / this.nDirections;
/* 308 */       Strel strel = this.strelFactory.createStrel(theta);
/*     */ 
/*     */       
/* 311 */       ImageProcessor oriented = this.operation.apply(image, strel);
/*     */ 
/*     */       
/* 314 */       for (int y = 0; y < sizeY; y++) {
/*     */         
/* 316 */         for (int x = 0; x < sizeX; x++) {
/*     */           
/* 318 */           float value = oriented.getf(x, y);
/* 319 */           if (value * sign > result.getf(x, y) * sign)
/*     */           {
/* 321 */             result.setf(x, y, value);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 327 */     fireProgressChanged(this, 1.0D, 1.0D);
/*     */ 
/*     */     
/* 330 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImageProcessor mean(ImageProcessor image, Strel strel) {
/* 345 */     ImageProcessor result = image.duplicate();
/*     */     
/* 347 */     MirroringBorder mirroringBorder = new MirroringBorder(image);
/*     */     
/* 349 */     int[][] shifts = strel.getShifts();
/*     */ 
/*     */ 
/*     */     
/* 353 */     for (int y = 0; y < image.getHeight(); y++) {
/* 354 */       for (int x = 0; x < image.getWidth(); x++) {
/*     */         
/* 356 */         double accum = 0.0D;
/*     */ 
/*     */         
/* 359 */         for (int i = 0; i < shifts.length; i++) {
/* 360 */           accum += mirroringBorder.getf(x + shifts[i][0], y + shifts[i][1]);
/*     */         }
/*     */ 
/*     */         
/* 364 */         double res = accum / shifts.length;
/* 365 */         result.setf(x, y, (float)res);
/*     */       } 
/*     */     } 
/*     */     
/* 369 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImageProcessor median(ImageProcessor image, Strel strel) {
/* 381 */     ImageProcessor result = image.duplicate();
/*     */     
/* 383 */     MirroringBorder mirroringBorder = new MirroringBorder(image);
/*     */     
/* 385 */     int[][] shifts = strel.getShifts();
/* 386 */     int n = shifts.length;
/* 387 */     double[] buffer = new double[n];
/*     */ 
/*     */     
/* 390 */     for (int y = 0; y < image.getHeight(); y++) {
/*     */       
/* 392 */       for (int x = 0; x < image.getWidth(); x++) {
/*     */ 
/*     */         
/* 395 */         for (int i = 0; i < shifts.length; i++)
/*     */         {
/* 397 */           buffer[i] = mirroringBorder.getf(x + shifts[i][0], y + shifts[i][1]);
/*     */         }
/*     */ 
/*     */         
/* 401 */         double res = median(buffer);
/* 402 */         result.setf(x, y, (float)res);
/*     */       } 
/*     */     } 
/*     */     
/* 406 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static double median(double[] values) {
/* 416 */     Arrays.sort(values);
/* 417 */     return medianSorted(values);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static double medianSorted(double[] values) {
/* 428 */     int middle = values.length / 2;
/*     */ 
/*     */     
/* 431 */     if (values.length % 2 == 1)
/*     */     {
/*     */       
/* 434 */       return values[middle];
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 439 */     return (values[middle - 1] + values[middle]) / 2.0D;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/morphology/directional/DirectionalFilter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */