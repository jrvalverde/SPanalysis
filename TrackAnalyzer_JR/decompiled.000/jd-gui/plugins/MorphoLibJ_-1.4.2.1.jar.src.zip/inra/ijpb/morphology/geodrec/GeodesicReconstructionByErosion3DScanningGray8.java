/*     */ package inra.ijpb.morphology.geodrec;
/*     */ 
/*     */ import ij.ImageStack;
/*     */ import inra.ijpb.data.image.Images3D;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GeodesicReconstructionByErosion3DScanningGray8
/*     */   extends GeodesicReconstruction3DAlgoStub
/*     */ {
/*     */   ImageStack marker;
/*     */   ImageStack mask;
/*     */   ImageStack result;
/*  45 */   int sizeX = 0;
/*     */   
/*  47 */   int sizeY = 0;
/*     */   
/*  49 */   int sizeZ = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean modif;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GeodesicReconstructionByErosion3DScanningGray8() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GeodesicReconstructionByErosion3DScanningGray8(int connectivity) {
/*  74 */     this.connectivity = connectivity;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ImageStack applyTo(ImageStack marker, ImageStack mask) {
/*  84 */     if (Thread.currentThread().isInterrupted()) {
/*  85 */       return null;
/*     */     }
/*     */     
/*  88 */     this.marker = marker;
/*  89 */     this.mask = mask;
/*     */ 
/*     */     
/*  92 */     if (marker.getBitDepth() != 8 || mask.getBitDepth() != 8)
/*     */     {
/*  94 */       throw new IllegalArgumentException("Marker and Mask images must be byte stacks");
/*     */     }
/*     */ 
/*     */     
/*  98 */     this.sizeX = marker.getWidth();
/*  99 */     this.sizeY = marker.getHeight();
/* 100 */     this.sizeZ = marker.getSize();
/* 101 */     if (!Images3D.isSameSize(marker, mask))
/*     */     {
/* 103 */       throw new IllegalArgumentException("Marker and Mask images must have the same size");
/*     */     }
/*     */ 
/*     */     
/* 107 */     if (this.connectivity != 6 && this.connectivity != 26)
/*     */     {
/* 109 */       throw new RuntimeException(
/* 110 */           "Connectivity for stacks must be either 6 or 26, not " + 
/* 111 */           this.connectivity);
/*     */     }
/*     */ 
/*     */     
/* 115 */     this.result = ImageStack.create(this.sizeX, this.sizeY, this.sizeZ, marker.getBitDepth());
/*     */ 
/*     */ 
/*     */     
/* 119 */     initializeResult();
/*     */ 
/*     */     
/* 122 */     int iter = 1;
/*     */ 
/*     */ 
/*     */     
/*     */     do {
/* 127 */       if (Thread.currentThread().isInterrupted()) {
/* 128 */         return null;
/*     */       }
/* 130 */       this.modif = false;
/*     */ 
/*     */       
/* 133 */       trace("Forward iteration " + iter);
/* 134 */       showStatus("Geod. Rec. by Ero. Fwd " + iter);
/*     */ 
/*     */       
/* 137 */       switch (this.connectivity) {
/*     */         
/*     */         case 6:
/* 140 */           forwardErosionC6();
/*     */           break;
/*     */         case 26:
/* 143 */           forwardErosionC26();
/*     */           break;
/*     */       } 
/*     */ 
/*     */       
/* 148 */       trace("Backward iteration " + iter);
/* 149 */       showStatus("Geod. Rec. by Ero. Bwd " + iter);
/*     */ 
/*     */       
/* 152 */       switch (this.connectivity) {
/*     */         
/*     */         case 6:
/* 155 */           backwardErosionC6();
/*     */           break;
/*     */         case 26:
/* 158 */           backwardErosionC26();
/*     */           break;
/*     */       } 
/*     */       
/* 162 */       iter++;
/* 163 */     } while (this.modif);
/*     */ 
/*     */     
/* 166 */     showProgress(1.0D, 1.0D, "");
/*     */     
/* 168 */     return this.result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void initializeResult() {
/* 178 */     this.result = ImageStack.create(this.sizeX, this.sizeY, this.sizeZ, this.mask.getBitDepth());
/*     */ 
/*     */     
/* 181 */     Object[] stack = this.result.getImageArray();
/* 182 */     Object[] markerStack = this.marker.getImageArray();
/* 183 */     Object[] maskStack = this.mask.getImageArray();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 189 */     for (int z = 0; z < this.sizeZ; z++) {
/*     */       
/* 191 */       byte[] slice = (byte[])stack[z];
/* 192 */       byte[] maskSlice = (byte[])maskStack[z];
/* 193 */       byte[] markerSlice = (byte[])markerStack[z];
/*     */       
/* 195 */       for (int y = 0; y < this.sizeY; y++) {
/*     */         
/* 197 */         for (int x = 0; x < this.sizeX; x++) {
/*     */           
/* 199 */           int index = y * this.sizeX + x;
/* 200 */           int value = Math.max(markerSlice[index] & 0xFF, maskSlice[index] & 0xFF);
/* 201 */           slice[index] = (byte)value;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void initializeResult(ImageStack binaryMask) {
/* 214 */     this.result = ImageStack.create(this.sizeX, this.sizeY, this.sizeZ, this.mask.getBitDepth());
/*     */ 
/*     */     
/* 217 */     Object[] stack = this.result.getImageArray();
/* 218 */     Object[] markerStack = this.marker.getImageArray();
/* 219 */     Object[] maskStack = this.mask.getImageArray();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 225 */     for (int z = 0; z < this.sizeZ; z++) {
/*     */       
/* 227 */       byte[] slice = (byte[])stack[z];
/* 228 */       byte[] maskSlice = (byte[])maskStack[z];
/* 229 */       byte[] markerSlice = (byte[])markerStack[z];
/*     */       
/* 231 */       for (int y = 0; y < this.sizeY; y++) {
/*     */         
/* 233 */         for (int x = 0; x < this.sizeX; x++) {
/*     */           
/* 235 */           if (binaryMask.getVoxel(x, y, z) != 0.0D) {
/*     */             
/* 237 */             int index = y * this.sizeX + x;
/* 238 */             int value = Math.max(markerSlice[index] & 0xFF, maskSlice[index] & 0xFF);
/* 239 */             slice[index] = (byte)value;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void forwardErosionC6() {
/* 255 */     Object[] stack = this.result.getImageArray();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 260 */     for (int z = 0; z < this.sizeZ; z++) {
/*     */       
/* 262 */       showProgress(z, this.sizeZ, "z = " + z);
/*     */       
/* 264 */       byte[] slice = (byte[])stack[z];
/* 265 */       for (int y = 0; y < this.sizeY; y++) {
/*     */         
/* 267 */         for (int x = 0; x < this.sizeX; x++) {
/*     */           
/* 269 */           int currentValue = slice[y * this.sizeX + x] & 0xFF;
/* 270 */           int minValue = currentValue;
/*     */ 
/*     */           
/* 273 */           if (x > 0)
/* 274 */             minValue = Math.min(minValue, 
/* 275 */                 slice[y * this.sizeX + x - 1] & 0xFF); 
/* 276 */           if (y > 0)
/* 277 */             minValue = Math.min(minValue, 
/* 278 */                 slice[(y - 1) * this.sizeX + x] & 0xFF); 
/* 279 */           if (z > 0) {
/*     */             
/* 281 */             byte[] slice2 = (byte[])stack[z - 1];
/* 282 */             minValue = Math.min(minValue, slice2[y * this.sizeX + x] & 0xFF);
/*     */           } 
/*     */ 
/*     */           
/* 286 */           minValue = Math.max(minValue, (int)this.mask.getVoxel(x, y, z));
/* 287 */           if (minValue < currentValue) {
/* 288 */             slice[y * this.sizeX + x] = (byte)(minValue & 0xFF);
/* 289 */             this.modif = true;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void forwardErosionC26() {
/* 305 */     Object[] stack = this.result.getImageArray();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 310 */     for (int z = 0; z < this.sizeZ; z++) {
/*     */       
/* 312 */       showProgress(z, this.sizeZ, "z = " + z);
/* 313 */       byte[] slice = (byte[])stack[z];
/* 314 */       for (int y = 0; y < this.sizeY; y++) {
/*     */         
/* 316 */         for (int x = 0; x < this.sizeX; x++) {
/*     */           
/* 318 */           int currentValue = slice[y * this.sizeX + x] & 0xFF;
/* 319 */           int minValue = currentValue;
/*     */ 
/*     */           
/* 322 */           int zmax = Math.min(z, this.sizeZ - 1);
/* 323 */           for (int z2 = Math.max(z - 1, 0); z2 <= zmax; z2++) {
/*     */             
/* 325 */             byte[] slice2 = (byte[])stack[z2];
/*     */             
/* 327 */             int ymax = (z2 == z) ? y : Math.min(y + 1, this.sizeY - 1);
/* 328 */             for (int y2 = Math.max(y - 1, 0); y2 <= ymax; y2++) {
/*     */               
/* 330 */               int xmax = (z2 == z && y2 == y) ? (x - 1) : Math.min(x + 1, this.sizeX - 1);
/* 331 */               for (int x2 = Math.max(x - 1, 0); x2 <= xmax; x2++) {
/*     */                 
/* 333 */                 int neighborValue = slice2[y2 * this.sizeX + x2] & 0xFF;
/* 334 */                 if (neighborValue < minValue) {
/* 335 */                   minValue = neighborValue;
/*     */                 }
/*     */               } 
/*     */             } 
/*     */           } 
/* 340 */           minValue = Math.max(minValue, (int)this.mask.getVoxel(x, y, z));
/* 341 */           if (minValue < currentValue) {
/*     */             
/* 343 */             slice[y * this.sizeX + x] = (byte)(minValue & 0xFF);
/* 344 */             this.modif = true;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void forwardErosionC6(ImageStack binaryMask) {
/* 360 */     Object[] stack = this.result.getImageArray();
/* 361 */     Object[] binaryStack = binaryMask.getImageArray();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 367 */     for (int z = 0; z < this.sizeZ; z++) {
/*     */       
/* 369 */       showProgress(z, this.sizeZ, "z = " + z);
/*     */       
/* 371 */       byte[] slice = (byte[])stack[z];
/* 372 */       byte[] binarySlice = (byte[])binaryStack[z];
/*     */       
/* 374 */       for (int y = 0; y < this.sizeY; y++) {
/*     */         
/* 376 */         for (int x = 0; x < this.sizeX; x++) {
/*     */           
/* 378 */           if (binarySlice[y * this.sizeX + x] != 0) {
/*     */             
/* 380 */             int currentValue = slice[y * this.sizeX + x] & 0xFF;
/* 381 */             int minValue = currentValue;
/*     */ 
/*     */             
/* 384 */             if (x > 0)
/* 385 */               minValue = Math.min(minValue, slice[y * this.sizeX + x - 1] & 0xFF); 
/* 386 */             if (y > 0)
/* 387 */               minValue = Math.min(minValue, slice[(y - 1) * this.sizeX + x] & 0xFF); 
/* 388 */             if (z > 0) {
/* 389 */               byte[] slice2 = (byte[])stack[z - 1];
/* 390 */               minValue = Math.min(minValue, slice2[y * this.sizeX + x] & 0xFF);
/*     */             } 
/*     */ 
/*     */             
/* 394 */             minValue = Math.max(minValue, (int)this.mask.getVoxel(x, y, z));
/* 395 */             if (minValue < currentValue) {
/*     */               
/* 397 */               slice[y * this.sizeX + x] = (byte)(minValue & 0xFF);
/* 398 */               this.modif = true;
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void forwardErosionC26(ImageStack binaryMask) {
/* 415 */     Object[] stack = this.result.getImageArray();
/* 416 */     Object[] binaryStack = binaryMask.getImageArray();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 422 */     for (int z = 0; z < this.sizeZ; z++) {
/*     */       
/* 424 */       showProgress(z, this.sizeZ, "z = " + z);
/* 425 */       byte[] slice = (byte[])stack[z];
/* 426 */       byte[] binarySlice = (byte[])binaryStack[z];
/*     */       
/* 428 */       for (int y = 0; y < this.sizeY; y++) {
/*     */         
/* 430 */         for (int x = 0; x < this.sizeX; x++) {
/*     */           
/* 432 */           if (binarySlice[y * this.sizeX + x] != 0) {
/*     */             
/* 434 */             int currentValue = slice[y * this.sizeX + x] & 0xFF;
/* 435 */             int minValue = currentValue;
/*     */ 
/*     */             
/* 438 */             int zmax = Math.min(z, this.sizeZ - 1);
/* 439 */             for (int z2 = Math.max(z - 1, 0); z2 <= zmax; z2++) {
/*     */               
/* 441 */               byte[] slice2 = (byte[])stack[z2];
/*     */               
/* 443 */               int ymax = (z2 == z) ? y : Math.min(y + 1, this.sizeY - 1);
/* 444 */               for (int y2 = Math.max(y - 1, 0); y2 <= ymax; y2++) {
/*     */                 
/* 446 */                 int xmax = (z2 == z && y2 == y) ? (x - 1) : Math.min(x + 1, this.sizeX - 1);
/* 447 */                 for (int x2 = Math.max(x - 1, 0); x2 <= xmax; x2++) {
/*     */                   
/* 449 */                   int neighborValue = slice2[y2 * this.sizeX + x2] & 0xFF;
/* 450 */                   if (neighborValue < minValue) {
/* 451 */                     minValue = neighborValue;
/*     */                   }
/*     */                 } 
/*     */               } 
/*     */             } 
/* 456 */             minValue = Math.max(minValue, (int)this.mask.getVoxel(x, y, z));
/* 457 */             if (minValue < currentValue) {
/*     */               
/* 459 */               slice[y * this.sizeX + x] = (byte)(minValue & 0xFF);
/* 460 */               this.modif = true;
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void backwardErosionC6() {
/* 478 */     Object[] stack = this.result.getImageArray();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 483 */     for (int z = this.sizeZ - 1; z >= 0; z--) {
/*     */       
/* 485 */       showProgress((this.sizeZ - 1 - z), this.sizeZ, "z = " + z);
/*     */       
/* 487 */       byte[] slice = (byte[])stack[z];
/* 488 */       for (int y = this.sizeY - 1; y >= 0; y--) {
/*     */         
/* 490 */         for (int x = this.sizeX - 1; x >= 0; x--) {
/*     */           
/* 492 */           int currentValue = slice[y * this.sizeX + x] & 0xFF;
/* 493 */           int minValue = currentValue;
/*     */ 
/*     */           
/* 496 */           if (x < this.sizeX - 1)
/* 497 */             minValue = Math.min(minValue, slice[y * this.sizeX + x + 1] & 0xFF); 
/* 498 */           if (y < this.sizeY - 1)
/* 499 */             minValue = Math.min(minValue, slice[(y + 1) * this.sizeX + x] & 0xFF); 
/* 500 */           if (z < this.sizeZ - 1) {
/*     */             
/* 502 */             byte[] slice2 = (byte[])stack[z + 1];
/* 503 */             minValue = Math.min(minValue, slice2[y * this.sizeX + x] & 0xFF);
/*     */           } 
/*     */ 
/*     */           
/* 507 */           minValue = Math.max(minValue, (int)this.mask.getVoxel(x, y, z));
/* 508 */           if (minValue < currentValue) {
/*     */             
/* 510 */             slice[y * this.sizeX + x] = (byte)(minValue & 0xFF);
/* 511 */             this.modif = true;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void backwardErosionC26() {
/* 527 */     Object[] stack = this.result.getImageArray();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 532 */     for (int z = this.sizeZ - 1; z >= 0; z--) {
/*     */       
/* 534 */       byte[] slice = (byte[])stack[z];
/* 535 */       showProgress((this.sizeZ - 1 - z), this.sizeZ);
/* 536 */       for (int y = this.sizeY - 1; y >= 0; y--) {
/*     */         
/* 538 */         for (int x = this.sizeX - 1; x >= 0; x--) {
/*     */           
/* 540 */           int currentValue = slice[y * this.sizeX + x] & 0xFF;
/* 541 */           int minValue = currentValue;
/*     */ 
/*     */           
/* 544 */           int zmin = Math.max(z - 1, 0);
/* 545 */           for (int z2 = Math.min(z + 1, this.sizeZ - 1); z2 >= zmin; z2--) {
/*     */             
/* 547 */             byte[] slice2 = (byte[])stack[z2];
/*     */             
/* 549 */             int ymin = (z2 == z) ? y : Math.max(y - 1, 0);
/* 550 */             for (int y2 = Math.min(y + 1, this.sizeY - 1); y2 >= ymin; y2--) {
/*     */               
/* 552 */               int xmin = (z2 == z && y2 == y) ? x : Math.max(x - 1, 0);
/* 553 */               for (int x2 = Math.min(x + 1, this.sizeX - 1); x2 >= xmin; x2--) {
/*     */                 
/* 555 */                 int index = y2 * this.sizeX + x2;
/* 556 */                 int neighborValue = slice2[index] & 0xFF;
/* 557 */                 if (neighborValue < minValue) {
/* 558 */                   minValue = neighborValue;
/*     */                 }
/*     */               } 
/*     */             } 
/*     */           } 
/*     */           
/* 564 */           minValue = Math.max(minValue, (int)this.mask.getVoxel(x, y, z));
/* 565 */           if (minValue < currentValue) {
/*     */             
/* 567 */             slice[y * this.sizeX + x] = (byte)(minValue & 0xFF);
/* 568 */             this.modif = true;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void backwardErosionC6(ImageStack binaryMask) {
/* 585 */     Object[] stack = this.result.getImageArray();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 592 */     for (int z = this.sizeZ - 1; z >= 0; z--) {
/*     */       
/* 594 */       showProgress((this.sizeZ - 1 - z), this.sizeZ, "z = " + z);
/*     */       
/* 596 */       byte[] slice = (byte[])stack[z];
/*     */ 
/*     */       
/* 599 */       for (int y = this.sizeY - 1; y >= 0; y--) {
/*     */         
/* 601 */         for (int x = this.sizeX - 1; x >= 0; x--) {
/*     */           
/* 603 */           int currentValue = slice[y * this.sizeX + x] & 0xFF;
/* 604 */           int minValue = currentValue;
/*     */ 
/*     */           
/* 607 */           if (x < this.sizeX - 1)
/* 608 */             minValue = Math.min(minValue, slice[y * this.sizeX + x + 1] & 0xFF); 
/* 609 */           if (y < this.sizeY - 1)
/* 610 */             minValue = Math.min(minValue, slice[(y + 1) * this.sizeX + x] & 0xFF); 
/* 611 */           if (z < this.sizeZ - 1) {
/* 612 */             byte[] slice2 = (byte[])stack[z + 1];
/* 613 */             minValue = Math.min(minValue, slice2[y * this.sizeX + x] & 0xFF);
/*     */           } 
/*     */ 
/*     */           
/* 617 */           minValue = Math.max(minValue, (int)this.mask.getVoxel(x, y, z));
/* 618 */           if (minValue < currentValue) {
/*     */             
/* 620 */             slice[y * this.sizeX + x] = (byte)(minValue & 0xFF);
/* 621 */             this.modif = true;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void backwardErosionC26(ImageStack binaryMask) {
/* 637 */     Object[] stack = this.result.getImageArray();
/* 638 */     Object[] binaryStack = binaryMask.getImageArray();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 644 */     for (int z = this.sizeZ - 1; z >= 0; z--) {
/*     */       
/* 646 */       byte[] slice = (byte[])stack[z];
/* 647 */       byte[] binarySlice = (byte[])binaryStack[z];
/*     */       
/* 649 */       showProgress((this.sizeZ - 1 - z), this.sizeZ);
/* 650 */       for (int y = this.sizeY - 1; y >= 0; y--) {
/*     */         
/* 652 */         for (int x = this.sizeX - 1; x >= 0; x--) {
/*     */           
/* 654 */           if (binarySlice[y * this.sizeX + x] != 0) {
/*     */             
/* 656 */             int currentValue = slice[y * this.sizeX + x] & 0xFF;
/* 657 */             int minValue = currentValue;
/*     */ 
/*     */             
/* 660 */             int zmin = Math.max(z - 1, 0);
/* 661 */             for (int z2 = Math.min(z + 1, this.sizeZ - 1); z2 >= zmin; z2--) {
/*     */               
/* 663 */               byte[] slice2 = (byte[])stack[z2];
/*     */               
/* 665 */               int ymin = (z2 == z) ? y : Math.max(y - 1, 0);
/* 666 */               for (int y2 = Math.min(y + 1, this.sizeY - 1); y2 >= ymin; y2--) {
/*     */                 
/* 668 */                 int xmin = (z2 == z && y2 == y) ? x : Math.max(
/* 669 */                     x - 1, 0);
/* 670 */                 for (int x2 = Math.min(x + 1, this.sizeX - 1); x2 >= xmin; x2--) {
/*     */                   
/* 672 */                   int index = y2 * this.sizeX + x2;
/* 673 */                   int neighborValue = slice2[index] & 0xFF;
/* 674 */                   if (neighborValue < minValue) {
/* 675 */                     minValue = neighborValue;
/*     */                   }
/*     */                 } 
/*     */               } 
/*     */             } 
/*     */             
/* 681 */             minValue = Math.max(minValue, (int)this.mask.getVoxel(x, y, z));
/* 682 */             if (minValue < currentValue) {
/*     */               
/* 684 */               slice[y * this.sizeX + x] = (byte)(minValue & 0xFF);
/* 685 */               this.modif = true;
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ImageStack applyTo(ImageStack marker, ImageStack mask, ImageStack binaryMask) {
/* 702 */     this.marker = marker;
/* 703 */     this.mask = mask;
/*     */ 
/*     */     
/* 706 */     this.sizeX = marker.getWidth();
/* 707 */     this.sizeY = marker.getHeight();
/* 708 */     this.sizeZ = marker.getSize();
/* 709 */     if (!Images3D.isSameSize(marker, mask))
/*     */     {
/* 711 */       throw new IllegalArgumentException("Marker and Mask images must have the same size");
/*     */     }
/*     */ 
/*     */     
/* 715 */     if (this.connectivity != 6 && this.connectivity != 26)
/*     */     {
/* 717 */       throw new RuntimeException(
/* 718 */           "Connectivity for stacks must be either 6 or 26, not " + 
/* 719 */           this.connectivity);
/*     */     }
/*     */ 
/*     */     
/* 723 */     this.result = ImageStack.create(this.sizeX, this.sizeY, this.sizeZ, marker.getBitDepth());
/*     */ 
/*     */ 
/*     */     
/* 727 */     initializeResult(binaryMask);
/*     */ 
/*     */     
/* 730 */     int iter = 1;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     do {
/* 736 */       this.modif = false;
/*     */ 
/*     */       
/* 739 */       trace("Forward iteration " + iter);
/* 740 */       showStatus("Geod. Rec. by Ero. Fwd " + iter);
/*     */ 
/*     */       
/* 743 */       switch (this.connectivity) {
/*     */         
/*     */         case 6:
/* 746 */           forwardErosionC6(binaryMask);
/*     */           break;
/*     */         case 26:
/* 749 */           forwardErosionC26(binaryMask);
/*     */           break;
/*     */       } 
/*     */ 
/*     */       
/* 754 */       trace("Backward iteration " + iter);
/* 755 */       showStatus("Geod. Rec. by Ero. Bwd " + iter);
/*     */ 
/*     */       
/* 758 */       switch (this.connectivity) {
/*     */         
/*     */         case 6:
/* 761 */           backwardErosionC6(binaryMask);
/*     */           break;
/*     */         case 26:
/* 764 */           backwardErosionC26(binaryMask);
/*     */           break;
/*     */       } 
/*     */       
/* 768 */       iter++;
/* 769 */     } while (this.modif);
/*     */     
/* 771 */     return this.result;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/morphology/geodrec/GeodesicReconstructionByErosion3DScanningGray8.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */