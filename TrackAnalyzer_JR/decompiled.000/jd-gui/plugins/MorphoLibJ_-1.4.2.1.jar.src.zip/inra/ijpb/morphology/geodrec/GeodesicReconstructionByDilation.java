/*     */ package inra.ijpb.morphology.geodrec;
/*     */ 
/*     */ import ij.IJ;
/*     */ import ij.process.ImageProcessor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GeodesicReconstructionByDilation
/*     */   extends GeodesicReconstructionAlgoStub
/*     */ {
/*     */   ImageProcessor marker;
/*     */   ImageProcessor mask;
/*     */   ImageProcessor result;
/*     */   boolean modif;
/*     */   
/*     */   public GeodesicReconstructionByDilation() {}
/*     */   
/*     */   public GeodesicReconstructionByDilation(int connectivity) {
/*  82 */     this.connectivity = connectivity;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ImageProcessor applyTo(ImageProcessor marker, ImageProcessor mask) {
/*  96 */     this.marker = marker;
/*  97 */     this.mask = mask;
/*     */ 
/*     */     
/* 100 */     int width = marker.getWidth();
/* 101 */     int height = marker.getHeight();
/* 102 */     if (width != mask.getWidth() || height != mask.getHeight())
/*     */     {
/* 104 */       throw new IllegalArgumentException("Marker and Mask images must have the same size");
/*     */     }
/*     */ 
/*     */     
/* 108 */     if (this.connectivity != 4 && this.connectivity != 8)
/*     */     {
/* 110 */       throw new RuntimeException(
/* 111 */           "Connectivity for planar images must be either 4 or 8, not " + 
/* 112 */           this.connectivity);
/*     */     }
/*     */ 
/*     */     
/* 116 */     this.result = this.mask.createProcessor(width, height);
/*     */ 
/*     */ 
/*     */     
/* 120 */     for (int y = 0; y < height; y++) {
/*     */       
/* 122 */       for (int x = 0; x < width; x++)
/*     */       {
/* 124 */         this.result.set(x, y, 
/* 125 */             Math.min(this.marker.get(x, y), this.mask.get(x, y)));
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 130 */     int iter = 0;
/*     */     
/* 132 */     boolean isFloat = mask instanceof ij.process.FloatProcessor;
/*     */ 
/*     */     
/*     */     do {
/* 136 */       this.modif = false;
/*     */ 
/*     */       
/* 139 */       if (this.verbose)
/*     */       {
/* 141 */         System.out.println("Forward iteration " + iter);
/*     */       }
/* 143 */       if (this.showStatus)
/*     */       {
/* 145 */         IJ.showStatus("Geod. Rec. by Dil. Fwd " + (iter + 1));
/*     */       }
/*     */ 
/*     */       
/* 149 */       switch (this.connectivity) {
/*     */         
/*     */         case 4:
/* 152 */           if (isFloat) {
/* 153 */             forwardDilationC4Float(); break;
/*     */           } 
/* 155 */           forwardDilationC4();
/*     */           break;
/*     */         case 8:
/* 158 */           if (isFloat) {
/* 159 */             forwardDilationC8Float(); break;
/*     */           } 
/* 161 */           forwardDilationC8();
/*     */           break;
/*     */       } 
/*     */ 
/*     */       
/* 166 */       if (this.verbose)
/*     */       {
/* 168 */         System.out.println("Backward iteration " + iter);
/*     */       }
/* 170 */       if (this.showStatus)
/*     */       {
/* 172 */         IJ.showStatus("Geod. Rec. by Dil. Bwd " + (iter + 1));
/*     */       }
/*     */ 
/*     */       
/* 176 */       switch (this.connectivity) {
/*     */         
/*     */         case 4:
/* 179 */           if (isFloat) {
/* 180 */             backwardDilationC4Float(); break;
/*     */           } 
/* 182 */           backwardDilationC4();
/*     */           break;
/*     */         case 8:
/* 185 */           if (isFloat) {
/* 186 */             backwardDilationC8Float(); break;
/*     */           } 
/* 188 */           backwardDilationC8();
/*     */           break;
/*     */       } 
/*     */       
/* 192 */       iter++;
/* 193 */     } while (this.modif);
/*     */     
/* 195 */     return this.result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void forwardDilationC4() {
/* 204 */     int width = this.marker.getWidth();
/* 205 */     int height = this.marker.getHeight();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 213 */     if (this.showProgress)
/*     */     {
/* 215 */       IJ.showProgress(0, height);
/*     */     }
/*     */ 
/*     */     
/* 219 */     for (int i = 1; i < width; i++) {
/*     */       
/* 221 */       int value = this.result.get(i - 1, 0);
/* 222 */       geodesicDilationUpdate(i, 0, value);
/*     */     } 
/*     */ 
/*     */     
/* 226 */     for (int j = 1; j < height; j++) {
/*     */ 
/*     */       
/* 229 */       if (this.showProgress)
/*     */       {
/* 231 */         IJ.showProgress(j, height);
/*     */       }
/*     */       
/* 234 */       int value = this.result.get(0, j - 1);
/* 235 */       geodesicDilationUpdate(0, j, value);
/*     */ 
/*     */       
/* 238 */       for (int k = 1; k < width; k++) {
/*     */         
/* 240 */         int v1 = this.result.get(k, j - 1);
/* 241 */         int v2 = this.result.get(k - 1, j);
/* 242 */         value = Math.max(v1, v2);
/* 243 */         geodesicDilationUpdate(k, j, value);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void forwardDilationC4Float() {
/* 254 */     int width = this.marker.getWidth();
/* 255 */     int height = this.marker.getHeight();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 263 */     if (this.showProgress)
/*     */     {
/* 265 */       IJ.showProgress(0, height);
/*     */     }
/*     */ 
/*     */     
/* 269 */     for (int i = 1; i < width; i++) {
/*     */       
/* 271 */       float value = this.result.getf(i - 1, 0);
/* 272 */       geodesicDilationUpdateFloat(i, 0, value);
/*     */     } 
/*     */ 
/*     */     
/* 276 */     for (int j = 1; j < height; j++) {
/*     */ 
/*     */       
/* 279 */       if (this.showProgress)
/*     */       {
/* 281 */         IJ.showProgress(j, height);
/*     */       }
/*     */       
/* 284 */       float value = this.result.getf(0, j - 1);
/* 285 */       geodesicDilationUpdateFloat(0, j, value);
/*     */ 
/*     */       
/* 288 */       for (int k = 1; k < width; k++) {
/*     */         
/* 290 */         float v1 = this.result.getf(k, j - 1);
/* 291 */         float v2 = this.result.getf(k - 1, j);
/* 292 */         value = Math.max(v1, v2);
/* 293 */         geodesicDilationUpdateFloat(k, j, value);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void forwardDilationC8() {
/* 304 */     int width = this.marker.getWidth();
/* 305 */     int height = this.marker.getHeight();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 313 */     if (this.showProgress)
/*     */     {
/* 315 */       IJ.showProgress(0, height);
/*     */     }
/*     */ 
/*     */     
/* 319 */     for (int i = 1; i < width; i++) {
/*     */       
/* 321 */       int value = this.result.get(i - 1, 0);
/* 322 */       geodesicDilationUpdate(i, 0, value);
/*     */     } 
/*     */ 
/*     */     
/* 326 */     for (int j = 1; j < height; j++) {
/*     */ 
/*     */       
/* 329 */       if (this.showProgress)
/*     */       {
/* 331 */         IJ.showProgress(j, height);
/*     */       }
/*     */ 
/*     */       
/* 335 */       int v1 = this.result.get(0, j - 1);
/* 336 */       int v2 = this.result.get(1, j - 1);
/* 337 */       int value = Math.max(v1, v2);
/* 338 */       geodesicDilationUpdate(0, j, value);
/*     */ 
/*     */       
/* 341 */       for (int k = 1; k < width - 1; k++) {
/*     */         
/* 343 */         v1 = this.result.get(k - 1, j - 1);
/* 344 */         v2 = this.result.get(k, j - 1);
/* 345 */         int m = this.result.get(k + 1, j - 1);
/* 346 */         int v4 = this.result.get(k - 1, j);
/* 347 */         value = Math.max(Math.max(v1, v2), Math.max(m, v4));
/* 348 */         geodesicDilationUpdate(k, j, value);
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 353 */       v1 = this.result.get(width - 2, j - 1);
/* 354 */       v2 = this.result.get(width - 1, j - 1);
/* 355 */       int v3 = this.result.get(width - 2, j);
/* 356 */       value = Math.max(Math.max(v1, v2), v3);
/* 357 */       geodesicDilationUpdate(width - 1, j, value);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void forwardDilationC8Float() {
/* 368 */     int width = this.marker.getWidth();
/* 369 */     int height = this.marker.getHeight();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 377 */     if (this.showProgress)
/*     */     {
/* 379 */       IJ.showProgress(0, height);
/*     */     }
/*     */ 
/*     */     
/* 383 */     for (int i = 1; i < width; i++) {
/* 384 */       float value = this.result.getf(i - 1, 0);
/* 385 */       geodesicDilationUpdateFloat(i, 0, value);
/*     */     } 
/*     */ 
/*     */     
/* 389 */     for (int j = 1; j < height; j++) {
/*     */ 
/*     */       
/* 392 */       if (this.showProgress)
/*     */       {
/* 394 */         IJ.showProgress(j, height);
/*     */       }
/*     */ 
/*     */       
/* 398 */       float v1 = this.result.getf(0, j - 1);
/* 399 */       float v2 = this.result.getf(1, j - 1);
/* 400 */       float value = Math.max(v1, v2);
/* 401 */       geodesicDilationUpdateFloat(0, j, value);
/*     */ 
/*     */       
/* 404 */       for (int k = 1; k < width - 1; k++) {
/*     */         
/* 406 */         v1 = this.result.getf(k - 1, j - 1);
/* 407 */         v2 = this.result.getf(k, j - 1);
/* 408 */         float f1 = this.result.getf(k + 1, j - 1);
/* 409 */         float v4 = this.result.getf(k - 1, j);
/* 410 */         value = Math.max(Math.max(v1, v2), Math.max(f1, v4));
/* 411 */         geodesicDilationUpdateFloat(k, j, value);
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 416 */       v1 = this.result.getf(width - 2, j - 1);
/* 417 */       v2 = this.result.getf(width - 1, j - 1);
/* 418 */       float v3 = this.result.getf(width - 2, j);
/* 419 */       value = Math.max(Math.max(v1, v2), v3);
/* 420 */       geodesicDilationUpdateFloat(width - 1, j, value);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void backwardDilationC4() {
/* 431 */     int width = this.marker.getWidth();
/* 432 */     int height = this.marker.getHeight();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 440 */     if (this.showProgress)
/*     */     {
/* 442 */       IJ.showProgress(0, height);
/*     */     }
/*     */ 
/*     */     
/* 446 */     for (int i = width - 2; i > 0; i--) {
/*     */       
/* 448 */       int value = this.result.get(i + 1, height - 1);
/* 449 */       geodesicDilationUpdate(i, height - 1, value);
/*     */     } 
/*     */ 
/*     */     
/* 453 */     for (int j = height - 2; j >= 0; j--) {
/*     */ 
/*     */       
/* 456 */       if (this.showProgress)
/*     */       {
/* 458 */         IJ.showProgress(height - 1 - j, height);
/*     */       }
/*     */ 
/*     */       
/* 462 */       int value = this.result.get(width - 1, j + 1);
/* 463 */       geodesicDilationUpdate(width - 1, j, value);
/*     */ 
/*     */ 
/*     */       
/* 467 */       for (int k = width - 2; k > 0; k--) {
/*     */         
/* 469 */         int m = this.result.get(k + 1, j);
/* 470 */         int n = this.result.get(k, j + 1);
/* 471 */         value = Math.max(m, n);
/* 472 */         geodesicDilationUpdate(k, j, value);
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 477 */       int v1 = this.result.get(1, j);
/* 478 */       int v2 = this.result.get(0, j + 1);
/* 479 */       value = Math.max(v1, v2);
/* 480 */       geodesicDilationUpdate(0, j, value);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void backwardDilationC4Float() {
/* 491 */     int width = this.marker.getWidth();
/* 492 */     int height = this.marker.getHeight();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 500 */     if (this.showProgress)
/*     */     {
/* 502 */       IJ.showProgress(0, height);
/*     */     }
/*     */ 
/*     */     
/* 506 */     for (int i = width - 2; i > 0; i--) {
/*     */       
/* 508 */       float value = this.result.getf(i + 1, height - 1);
/* 509 */       geodesicDilationUpdateFloat(i, height - 1, value);
/*     */     } 
/*     */ 
/*     */     
/* 513 */     for (int j = height - 2; j >= 0; j--) {
/*     */ 
/*     */       
/* 516 */       if (this.showProgress)
/*     */       {
/* 518 */         IJ.showProgress(height - 1 - j, height);
/*     */       }
/*     */ 
/*     */       
/* 522 */       float value = this.result.get(width - 1, j + 1);
/* 523 */       geodesicDilationUpdateFloat(width - 1, j, value);
/*     */ 
/*     */ 
/*     */       
/* 527 */       for (int k = width - 2; k > 0; k--) {
/*     */         
/* 529 */         float f1 = this.result.getf(k + 1, j);
/* 530 */         float f2 = this.result.getf(k, j + 1);
/* 531 */         value = Math.max(f1, f2);
/* 532 */         geodesicDilationUpdateFloat(k, j, value);
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 537 */       float v1 = this.result.getf(1, j);
/* 538 */       float v2 = this.result.getf(0, j + 1);
/* 539 */       value = Math.max(v1, v2);
/* 540 */       geodesicDilationUpdateFloat(0, j, value);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void backwardDilationC8() {
/* 551 */     int width = this.marker.getWidth();
/* 552 */     int height = this.marker.getHeight();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 560 */     if (this.showProgress)
/*     */     {
/* 562 */       IJ.showProgress(0, height);
/*     */     }
/*     */ 
/*     */     
/* 566 */     for (int i = width - 2; i > 0; i--) {
/*     */       
/* 568 */       int value = this.result.get(i + 1, height - 1);
/* 569 */       geodesicDilationUpdate(i, height - 1, value);
/*     */     } 
/*     */ 
/*     */     
/* 573 */     for (int j = height - 2; j >= 0; j--) {
/*     */ 
/*     */       
/* 576 */       if (this.showProgress) {
/* 577 */         IJ.showProgress(height - 1 - j, height);
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 582 */       int v1 = this.result.get(width - 1, j + 1);
/* 583 */       int v2 = this.result.get(width - 2, j + 1);
/* 584 */       int value = Math.max(v1, v2);
/* 585 */       geodesicDilationUpdate(width - 1, j, value);
/*     */ 
/*     */       
/* 588 */       for (int k = width - 2; k > 0; k--) {
/*     */         
/* 590 */         v1 = this.result.get(k + 1, j);
/* 591 */         v2 = this.result.get(k + 1, j + 1);
/* 592 */         int m = this.result.get(k, j + 1);
/* 593 */         int v4 = this.result.get(k - 1, j + 1);
/* 594 */         value = Math.max(Math.max(v1, v2), Math.max(m, v4));
/* 595 */         geodesicDilationUpdate(k, j, value);
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 600 */       v1 = this.result.get(1, j);
/* 601 */       v2 = this.result.get(0, j + 1);
/* 602 */       int v3 = this.result.get(1, j + 1);
/* 603 */       value = Math.max(Math.max(v1, v2), v3);
/* 604 */       geodesicDilationUpdate(0, j, value);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void backwardDilationC8Float() {
/* 615 */     int width = this.marker.getWidth();
/* 616 */     int height = this.marker.getHeight();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 624 */     if (this.showProgress)
/*     */     {
/* 626 */       IJ.showProgress(0, height);
/*     */     }
/*     */ 
/*     */     
/* 630 */     for (int i = width - 2; i > 0; i--) {
/*     */       
/* 632 */       float value = this.result.getf(i + 1, height - 1);
/* 633 */       geodesicDilationUpdateFloat(i, height - 1, value);
/*     */     } 
/*     */ 
/*     */     
/* 637 */     for (int j = height - 2; j >= 0; j--) {
/*     */ 
/*     */       
/* 640 */       if (this.showProgress)
/*     */       {
/* 642 */         IJ.showProgress(height - 1 - j, height);
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 647 */       float v1 = this.result.getf(width - 1, j + 1);
/* 648 */       float v2 = this.result.getf(width - 2, j + 1);
/* 649 */       float value = Math.max(v1, v2);
/* 650 */       geodesicDilationUpdateFloat(width - 1, j, value);
/*     */ 
/*     */       
/* 653 */       for (int k = width - 2; k > 0; k--) {
/*     */         
/* 655 */         v1 = this.result.getf(k + 1, j);
/* 656 */         v2 = this.result.getf(k + 1, j + 1);
/* 657 */         float f1 = this.result.getf(k, j + 1);
/* 658 */         float v4 = this.result.getf(k - 1, j + 1);
/* 659 */         value = Math.max(Math.max(v1, v2), Math.max(f1, v4));
/* 660 */         geodesicDilationUpdateFloat(k, j, value);
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 665 */       v1 = this.result.getf(1, j);
/* 666 */       v2 = this.result.getf(0, j + 1);
/* 667 */       float v3 = this.result.getf(1, j + 1);
/* 668 */       value = Math.max(Math.max(v1, v2), v3);
/* 669 */       geodesicDilationUpdateFloat(0, j, value);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void geodesicDilationUpdate(int i, int j, int value) {
/* 683 */     value = Math.min(value, this.mask.get(i, j));
/* 684 */     if (value > this.result.get(i, j)) {
/*     */       
/* 686 */       this.modif = true;
/* 687 */       this.result.set(i, j, value);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void geodesicDilationUpdateFloat(int i, int j, float value) {
/* 700 */     value = Math.min(value, this.mask.getf(i, j));
/* 701 */     if (value > this.result.getf(i, j)) {
/*     */       
/* 703 */       this.modif = true;
/* 704 */       this.result.setf(i, j, value);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/morphology/geodrec/GeodesicReconstructionByDilation.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */