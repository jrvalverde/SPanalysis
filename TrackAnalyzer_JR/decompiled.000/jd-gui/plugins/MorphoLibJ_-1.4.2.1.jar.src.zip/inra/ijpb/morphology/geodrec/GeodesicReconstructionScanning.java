/*     */ package inra.ijpb.morphology.geodrec;
/*     */ 
/*     */ import ij.IJ;
/*     */ import ij.process.ImageProcessor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GeodesicReconstructionScanning
/*     */   extends GeodesicReconstructionAlgoStub
/*     */ {
/*  44 */   GeodesicReconstructionType reconstructionType = GeodesicReconstructionType.BY_DILATION;
/*     */   
/*     */   ImageProcessor marker;
/*     */   
/*     */   ImageProcessor mask;
/*     */   
/*     */   ImageProcessor result;
/*     */   
/*  52 */   int sizeX = 0;
/*     */ 
/*     */   
/*  55 */   int sizeY = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean modif;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GeodesicReconstructionScanning() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GeodesicReconstructionScanning(GeodesicReconstructionType type) {
/*  84 */     this.reconstructionType = type;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GeodesicReconstructionScanning(int connectivity) {
/*  96 */     this.connectivity = connectivity;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GeodesicReconstructionScanning(GeodesicReconstructionType type, int connectivity) {
/* 110 */     this.reconstructionType = type;
/* 111 */     this.connectivity = connectivity;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GeodesicReconstructionType getReconstructionType() {
/* 123 */     return this.reconstructionType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setReconstructionType(GeodesicReconstructionType reconstructionType) {
/* 131 */     this.reconstructionType = reconstructionType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ImageProcessor applyTo(ImageProcessor marker, ImageProcessor mask) {
/* 145 */     this.marker = marker;
/* 146 */     this.mask = mask;
/*     */ 
/*     */     
/* 149 */     this.sizeX = marker.getWidth();
/* 150 */     this.sizeY = marker.getHeight();
/* 151 */     if (this.sizeX != mask.getWidth() || this.sizeY != mask.getHeight())
/*     */     {
/* 153 */       throw new IllegalArgumentException("Marker and Mask images must have the same size");
/*     */     }
/*     */ 
/*     */     
/* 157 */     if (this.connectivity != 4 && this.connectivity != 8)
/*     */     {
/* 159 */       throw new RuntimeException(
/* 160 */           "Connectivity for planar images must be either 4 or 8, not " + 
/* 161 */           this.connectivity);
/*     */     }
/*     */ 
/*     */     
/* 165 */     this.result = this.mask.createProcessor(this.sizeX, this.sizeY);
/*     */ 
/*     */ 
/*     */     
/* 169 */     for (int y = 0; y < this.sizeY; y++) {
/*     */       
/* 171 */       for (int x = 0; x < this.sizeX; x++)
/*     */       {
/* 173 */         this.result.set(x, y, 
/* 174 */             Math.min(this.marker.get(x, y), this.mask.get(x, y)));
/*     */       }
/*     */     } 
/*     */     
/* 178 */     boolean isInteger = !(mask instanceof ij.process.FloatProcessor);
/*     */ 
/*     */     
/* 181 */     if (isInteger) {
/*     */       
/* 183 */       initializeResult();
/*     */     }
/*     */     else {
/*     */       
/* 187 */       initializeResultFloat();
/*     */     } 
/*     */ 
/*     */     
/* 191 */     int iter = 0;
/*     */ 
/*     */     
/*     */     do {
/* 195 */       this.modif = false;
/*     */ 
/*     */       
/* 198 */       if (this.verbose)
/*     */       {
/* 200 */         System.out.println("Forward iteration " + iter);
/*     */       }
/* 202 */       if (this.showStatus)
/*     */       {
/* 204 */         IJ.showStatus("Geod. Rec. Fwd " + (iter + 1));
/*     */       }
/*     */ 
/*     */       
/* 208 */       switch (this.connectivity) {
/*     */         
/*     */         case 4:
/* 211 */           if (isInteger) {
/* 212 */             forwardScanC4(); break;
/*     */           } 
/* 214 */           forwardScanC4Float();
/*     */           break;
/*     */         case 8:
/* 217 */           if (isInteger) {
/* 218 */             forwardScanC8(); break;
/*     */           } 
/* 220 */           forwardScanC8Float();
/*     */           break;
/*     */       } 
/*     */ 
/*     */       
/* 225 */       if (this.verbose)
/*     */       {
/* 227 */         System.out.println("Backward iteration " + iter);
/*     */       }
/* 229 */       if (this.showStatus)
/*     */       {
/* 231 */         IJ.showStatus("Geod. Rec. Bwd " + (iter + 1));
/*     */       }
/*     */ 
/*     */       
/* 235 */       switch (this.connectivity) {
/*     */         
/*     */         case 4:
/* 238 */           if (isInteger) {
/* 239 */             backwardScanC4(); break;
/*     */           } 
/* 241 */           backwardScanC4Float();
/*     */           break;
/*     */         case 8:
/* 244 */           if (isInteger) {
/* 245 */             backwardScanC8(); break;
/*     */           } 
/* 247 */           backwardScanC8Float();
/*     */           break;
/*     */       } 
/*     */       
/* 251 */       iter++;
/* 252 */     } while (this.modif);
/*     */     
/* 254 */     return this.result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void initializeResult() {
/* 260 */     this.result = this.mask.createProcessor(this.sizeX, this.sizeY);
/*     */     
/* 262 */     int sign = this.reconstructionType.getSign();
/* 263 */     for (int y = 0; y < this.sizeY; y++) {
/*     */       
/* 265 */       for (int x = 0; x < this.sizeX; x++) {
/*     */         
/* 267 */         int v1 = this.marker.get(x, y) * sign;
/* 268 */         int v2 = this.mask.get(x, y) * sign;
/* 269 */         this.result.set(x, y, Math.min(v1, v2) * sign);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void initializeResultFloat() {
/* 277 */     this.result = this.marker.createProcessor(this.sizeX, this.sizeY);
/*     */     
/* 279 */     float sign = this.reconstructionType.getSign();
/* 280 */     for (int y = 0; y < this.sizeY; y++) {
/*     */       
/* 282 */       for (int x = 0; x < this.sizeX; x++) {
/*     */         
/* 284 */         float v1 = this.marker.getf(x, y) * sign;
/* 285 */         float v2 = this.mask.getf(x, y) * sign;
/* 286 */         this.result.setf(x, y, Math.min(v1, v2) * sign);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void forwardScanC4() {
/* 297 */     int sign = this.reconstructionType.getSign();
/*     */     
/* 299 */     if (this.showProgress)
/*     */     {
/* 301 */       IJ.showProgress(0, this.sizeY);
/*     */     }
/*     */ 
/*     */     
/* 305 */     for (int y = 0; y < this.sizeY; y++) {
/*     */ 
/*     */       
/* 308 */       if (this.showProgress)
/*     */       {
/* 310 */         IJ.showProgress(y, this.sizeY);
/*     */       }
/*     */ 
/*     */       
/* 314 */       for (int x = 0; x < this.sizeX; x++) {
/*     */         
/* 316 */         int currentValue = this.result.get(x, y) * sign;
/* 317 */         int maxValue = currentValue;
/*     */         
/* 319 */         if (x > 0)
/* 320 */           maxValue = Math.max(maxValue, this.result.get(x - 1, y) * sign); 
/* 321 */         if (y > 0) {
/* 322 */           maxValue = Math.max(maxValue, this.result.get(x, y - 1) * sign);
/*     */         }
/*     */         
/* 325 */         maxValue = Math.min(maxValue, this.mask.get(x, y) * sign);
/* 326 */         if (maxValue > currentValue) {
/*     */           
/* 328 */           this.result.set(x, y, maxValue * sign);
/* 329 */           this.modif = true;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void forwardScanC4Float() {
/* 341 */     float sign = this.reconstructionType.getSign();
/*     */     
/* 343 */     if (this.showProgress)
/*     */     {
/* 345 */       IJ.showProgress(0, this.sizeY);
/*     */     }
/*     */ 
/*     */     
/* 349 */     for (int y = 0; y < this.sizeY; y++) {
/*     */ 
/*     */       
/* 352 */       if (this.showProgress)
/*     */       {
/* 354 */         IJ.showProgress(y, this.sizeY);
/*     */       }
/*     */ 
/*     */       
/* 358 */       for (int x = 0; x < this.sizeX; x++) {
/*     */         
/* 360 */         float currentValue = this.result.getf(x, y) * sign;
/* 361 */         float maxValue = currentValue;
/*     */         
/* 363 */         if (x > 0)
/* 364 */           maxValue = Math.max(maxValue, this.result.getf(x - 1, y) * sign); 
/* 365 */         if (y > 0) {
/* 366 */           maxValue = Math.max(maxValue, this.result.getf(x, y - 1) * sign);
/*     */         }
/*     */         
/* 369 */         maxValue = Math.min(maxValue, this.mask.getf(x, y) * sign);
/* 370 */         if (maxValue > currentValue) {
/*     */           
/* 372 */           this.result.setf(x, y, maxValue * sign);
/* 373 */           this.modif = true;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void forwardScanC8() {
/* 385 */     int sign = this.reconstructionType.getSign();
/*     */     
/* 387 */     if (this.showProgress)
/*     */     {
/* 389 */       IJ.showProgress(0, this.sizeY);
/*     */     }
/*     */ 
/*     */     
/* 393 */     for (int y = 0; y < this.sizeY; y++) {
/*     */ 
/*     */       
/* 396 */       if (this.showProgress)
/*     */       {
/* 398 */         IJ.showProgress(y, this.sizeY);
/*     */       }
/*     */ 
/*     */       
/* 402 */       for (int x = 0; x < this.sizeX; x++) {
/*     */         
/* 404 */         int currentValue = this.result.get(x, y) * sign;
/* 405 */         int maxValue = currentValue;
/*     */         
/* 407 */         if (y > 0) {
/*     */ 
/*     */           
/* 410 */           if (x > 0)
/* 411 */             maxValue = Math.max(maxValue, this.result.get(x - 1, y - 1) * sign); 
/* 412 */           maxValue = Math.max(maxValue, this.result.get(x, y - 1) * sign);
/* 413 */           if (x < this.sizeX - 1)
/* 414 */             maxValue = Math.max(maxValue, this.result.get(x + 1, y - 1) * sign); 
/*     */         } 
/* 416 */         if (x > 0) {
/* 417 */           maxValue = Math.max(maxValue, this.result.get(x - 1, y) * sign);
/*     */         }
/*     */         
/* 420 */         maxValue = Math.min(maxValue, this.mask.get(x, y) * sign);
/* 421 */         if (maxValue > currentValue) {
/*     */           
/* 423 */           this.result.set(x, y, maxValue * sign);
/* 424 */           this.modif = true;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void forwardScanC8Float() {
/* 436 */     float sign = this.reconstructionType.getSign();
/*     */     
/* 438 */     if (this.showProgress)
/*     */     {
/* 440 */       IJ.showProgress(0, this.sizeY);
/*     */     }
/*     */ 
/*     */     
/* 444 */     for (int y = 0; y < this.sizeY; y++) {
/*     */ 
/*     */       
/* 447 */       if (this.showProgress)
/*     */       {
/* 449 */         IJ.showProgress(y, this.sizeY);
/*     */       }
/*     */ 
/*     */       
/* 453 */       for (int x = 0; x < this.sizeX; x++) {
/*     */         
/* 455 */         float currentValue = this.result.getf(x, y) * sign;
/* 456 */         float maxValue = currentValue;
/*     */         
/* 458 */         if (y > 0) {
/*     */ 
/*     */           
/* 461 */           if (x > 0)
/* 462 */             maxValue = Math.max(maxValue, this.result.getf(x - 1, y - 1) * sign); 
/* 463 */           maxValue = Math.max(maxValue, this.result.getf(x, y - 1) * sign);
/* 464 */           if (x < this.sizeX - 1)
/* 465 */             maxValue = Math.max(maxValue, this.result.getf(x + 1, y - 1) * sign); 
/*     */         } 
/* 467 */         if (x > 0) {
/* 468 */           maxValue = Math.max(maxValue, this.result.getf(x - 1, y) * sign);
/*     */         }
/*     */         
/* 471 */         maxValue = Math.min(maxValue, this.mask.getf(x, y) * sign);
/* 472 */         if (maxValue > currentValue) {
/*     */           
/* 474 */           this.result.setf(x, y, maxValue * sign);
/* 475 */           this.modif = true;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void backwardScanC4() {
/* 487 */     int sign = this.reconstructionType.getSign();
/*     */     
/* 489 */     if (this.showProgress)
/*     */     {
/* 491 */       IJ.showProgress(0, this.sizeY);
/*     */     }
/*     */ 
/*     */     
/* 495 */     for (int y = this.sizeY - 1; y >= 0; y--) {
/*     */ 
/*     */       
/* 498 */       if (this.showProgress)
/*     */       {
/* 500 */         IJ.showProgress(this.sizeY - 1 - y, this.sizeY);
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 505 */       for (int x = this.sizeX - 1; x >= 0; x--) {
/*     */ 
/*     */         
/* 508 */         int currentValue = this.result.get(x, y) * sign;
/* 509 */         int maxValue = currentValue;
/*     */         
/* 511 */         if (x < this.sizeX - 1)
/* 512 */           maxValue = Math.max(maxValue, this.result.get(x + 1, y) * sign); 
/* 513 */         if (y < this.sizeY - 1) {
/* 514 */           maxValue = Math.max(maxValue, this.result.get(x, y + 1) * sign);
/*     */         }
/*     */         
/* 517 */         maxValue = Math.min(maxValue, this.mask.get(x, y) * sign);
/* 518 */         if (maxValue > currentValue) {
/*     */           
/* 520 */           this.result.set(x, y, maxValue * sign);
/* 521 */           this.modif = true;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void backwardScanC4Float() {
/* 533 */     float sign = this.reconstructionType.getSign();
/*     */     
/* 535 */     if (this.showProgress)
/*     */     {
/* 537 */       IJ.showProgress(0, this.sizeY);
/*     */     }
/*     */ 
/*     */     
/* 541 */     for (int y = this.sizeY - 1; y >= 0; y--) {
/*     */ 
/*     */       
/* 544 */       if (this.showProgress)
/*     */       {
/* 546 */         IJ.showProgress(this.sizeY - 1 - y, this.sizeY);
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 551 */       for (int x = this.sizeX - 1; x >= 0; x--) {
/*     */ 
/*     */         
/* 554 */         float currentValue = this.result.getf(x, y) * sign;
/* 555 */         float maxValue = currentValue;
/*     */         
/* 557 */         if (x < this.sizeX - 1)
/* 558 */           maxValue = Math.max(maxValue, this.result.getf(x + 1, y) * sign); 
/* 559 */         if (y < this.sizeY - 1) {
/* 560 */           maxValue = Math.max(maxValue, this.result.getf(x, y + 1) * sign);
/*     */         }
/*     */         
/* 563 */         maxValue = Math.min(maxValue, this.mask.getf(x, y) * sign);
/* 564 */         if (maxValue > currentValue) {
/*     */           
/* 566 */           this.result.setf(x, y, maxValue * sign);
/* 567 */           this.modif = true;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void backwardScanC8() {
/* 579 */     int sign = this.reconstructionType.getSign();
/*     */     
/* 581 */     if (this.showProgress)
/*     */     {
/* 583 */       IJ.showProgress(0, this.sizeY);
/*     */     }
/*     */ 
/*     */     
/* 587 */     for (int y = this.sizeY - 1; y >= 0; y--) {
/*     */ 
/*     */       
/* 590 */       if (this.showProgress)
/*     */       {
/* 592 */         IJ.showProgress(this.sizeY - 1 - y, this.sizeY);
/*     */       }
/*     */ 
/*     */       
/* 596 */       for (int x = this.sizeX - 1; x >= 0; x--) {
/*     */         
/* 598 */         int currentValue = this.result.get(x, y) * sign;
/* 599 */         int maxValue = currentValue;
/*     */         
/* 601 */         if (y < this.sizeY - 1) {
/*     */ 
/*     */           
/* 604 */           if (x > 0)
/* 605 */             maxValue = Math.max(maxValue, this.result.get(x - 1, y + 1) * sign); 
/* 606 */           maxValue = Math.max(maxValue, this.result.get(x, y + 1) * sign);
/* 607 */           if (x < this.sizeX - 1)
/* 608 */             maxValue = Math.max(maxValue, this.result.get(x + 1, y + 1) * sign); 
/*     */         } 
/* 610 */         if (x < this.sizeX - 1) {
/* 611 */           maxValue = Math.max(maxValue, this.result.get(x + 1, y) * sign);
/*     */         }
/*     */         
/* 614 */         maxValue = Math.min(maxValue, this.mask.get(x, y) * sign);
/* 615 */         if (maxValue > currentValue) {
/*     */           
/* 617 */           this.result.set(x, y, maxValue * sign);
/* 618 */           this.modif = true;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void backwardScanC8Float() {
/* 630 */     float sign = this.reconstructionType.getSign();
/*     */     
/* 632 */     if (this.showProgress)
/*     */     {
/* 634 */       IJ.showProgress(0, this.sizeY);
/*     */     }
/*     */ 
/*     */     
/* 638 */     for (int y = this.sizeY - 1; y >= 0; y--) {
/*     */ 
/*     */       
/* 641 */       if (this.showProgress)
/*     */       {
/* 643 */         IJ.showProgress(this.sizeY - 1 - y, this.sizeY);
/*     */       }
/*     */ 
/*     */       
/* 647 */       for (int x = this.sizeX - 1; x >= 0; x--) {
/*     */         
/* 649 */         float currentValue = this.result.getf(x, y) * sign;
/* 650 */         float maxValue = currentValue;
/*     */         
/* 652 */         if (y < this.sizeY - 1) {
/*     */ 
/*     */           
/* 655 */           if (x > 0)
/* 656 */             maxValue = Math.max(maxValue, this.result.getf(x - 1, y + 1) * sign); 
/* 657 */           maxValue = Math.max(maxValue, this.result.getf(x, y + 1) * sign);
/* 658 */           if (x < this.sizeX - 1)
/* 659 */             maxValue = Math.max(maxValue, this.result.getf(x + 1, y + 1) * sign); 
/*     */         } 
/* 661 */         if (x < this.sizeX - 1) {
/* 662 */           maxValue = Math.max(maxValue, this.result.getf(x + 1, y) * sign);
/*     */         }
/*     */         
/* 665 */         maxValue = Math.min(maxValue, this.mask.getf(x, y) * sign);
/* 666 */         if (maxValue > currentValue) {
/*     */           
/* 668 */           this.result.setf(x, y, maxValue * sign);
/* 669 */           this.modif = true;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/morphology/geodrec/GeodesicReconstructionScanning.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */