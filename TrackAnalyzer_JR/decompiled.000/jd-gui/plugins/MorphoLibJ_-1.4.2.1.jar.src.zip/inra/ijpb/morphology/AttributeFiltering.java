/*     */ package inra.ijpb.morphology;
/*     */ 
/*     */ import ij.ImagePlus;
/*     */ import ij.ImageStack;
/*     */ import ij.process.ImageProcessor;
/*     */ import inra.ijpb.algo.Algo;
/*     */ import inra.ijpb.algo.DefaultAlgoListener;
/*     */ import inra.ijpb.morphology.attrfilt.AreaOpeningQueue;
/*     */ import inra.ijpb.morphology.attrfilt.SizeOpening3DQueue;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AttributeFiltering
/*     */ {
/*     */   public static final ImagePlus sizeOpening(ImagePlus imagePlus, int minSize) {
/*     */     ImagePlus resultPlus;
/*  56 */     if (imagePlus.getStackSize() == 1) {
/*     */       
/*  58 */       ImageProcessor image = imagePlus.getProcessor();
/*  59 */       ImageProcessor result = areaOpening(image, minSize);
/*  60 */       String newName = String.valueOf(imagePlus.getShortTitle()) + "-areaOpen";
/*  61 */       resultPlus = new ImagePlus(newName, result);
/*     */     }
/*     */     else {
/*     */       
/*  65 */       ImageStack image = imagePlus.getStack();
/*  66 */       ImageStack result = volumeOpening(image, minSize);
/*  67 */       String newName = String.valueOf(imagePlus.getShortTitle()) + "-sizeOpen";
/*  68 */       resultPlus = new ImagePlus(newName, result);
/*     */     } 
/*     */ 
/*     */     
/*  72 */     if (imagePlus.getStackSize() > 1)
/*     */     {
/*  74 */       resultPlus.setSlice(imagePlus.getCurrentSlice());
/*     */     }
/*  76 */     return resultPlus;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final ImageProcessor areaOpening(ImageProcessor image, int minArea) {
/*  91 */     AreaOpeningQueue areaOpeningQueue = new AreaOpeningQueue();
/*  92 */     DefaultAlgoListener.monitor((Algo)areaOpeningQueue);
/*  93 */     return areaOpeningQueue.process(image, minArea);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final ImageStack volumeOpening(ImageStack image, int minVolume) {
/* 108 */     SizeOpening3DQueue sizeOpening3DQueue = new SizeOpening3DQueue();
/* 109 */     DefaultAlgoListener.monitor((Algo)sizeOpening3DQueue);
/* 110 */     return sizeOpening3DQueue.process(image, minVolume);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final ImageStack volumeOpening(ImageStack image, int minVolume, int connectivity) {
/* 128 */     SizeOpening3DQueue algo = new SizeOpening3DQueue();
/* 129 */     algo.setConnectivity(connectivity);
/* 130 */     DefaultAlgoListener.monitor((Algo)algo);
/* 131 */     return algo.process(image, minVolume);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/morphology/AttributeFiltering.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */