/*      */ package inra.ijpb.morphology;
/*      */ 
/*      */ import ij.ImageStack;
/*      */ import ij.process.ByteProcessor;
/*      */ import ij.process.ImageProcessor;
/*      */ import inra.ijpb.data.image.ColorImages;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.Map;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class Morphology
/*      */ {
/*      */   public enum Operation
/*      */   {
/*   86 */     EROSION(
/*   87 */       "Erosion"),
/*   88 */     DILATION(
/*   89 */       "Dilation"),
/*   90 */     OPENING(
/*   91 */       "Opening"),
/*   92 */     CLOSING(
/*   93 */       "Closing"),
/*   94 */     TOPHAT(
/*   95 */       "White Top Hat"),
/*   96 */     BOTTOMHAT(
/*   97 */       "Black Top Hat"),
/*   98 */     GRADIENT(
/*   99 */       "Gradient"),
/*  100 */     LAPLACIAN(
/*  101 */       "Laplacian"),
/*  102 */     INTERNAL_GRADIENT(
/*  103 */       "Internal Gradient"),
/*  104 */     EXTERNAL_GRADIENT(
/*  105 */       "External Gradient");
/*      */     
/*      */     private final String label;
/*      */ 
/*      */     
/*      */     Operation(String label) {
/*  111 */       this.label = label;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ImageProcessor apply(ImageProcessor image, Strel strel) {
/*  125 */       if (this == DILATION)
/*  126 */         return Morphology.dilation(image, strel); 
/*  127 */       if (this == EROSION)
/*  128 */         return Morphology.erosion(image, strel); 
/*  129 */       if (this == CLOSING)
/*  130 */         return Morphology.closing(image, strel); 
/*  131 */       if (this == OPENING)
/*  132 */         return Morphology.opening(image, strel); 
/*  133 */       if (this == TOPHAT)
/*  134 */         return Morphology.whiteTopHat(image, strel); 
/*  135 */       if (this == BOTTOMHAT)
/*  136 */         return Morphology.blackTopHat(image, strel); 
/*  137 */       if (this == GRADIENT)
/*  138 */         return Morphology.gradient(image, strel); 
/*  139 */       if (this == LAPLACIAN)
/*  140 */         return Morphology.laplacian(image, strel); 
/*  141 */       if (this == INTERNAL_GRADIENT)
/*  142 */         return Morphology.internalGradient(image, strel); 
/*  143 */       if (this == EXTERNAL_GRADIENT) {
/*  144 */         return Morphology.externalGradient(image, strel);
/*      */       }
/*  146 */       throw new RuntimeException(
/*  147 */           "Unable to process the " + this + " morphological operation");
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ImageStack apply(ImageStack image, Strel3D strel) {
/*  161 */       if (this == DILATION)
/*  162 */         return Morphology.dilation(image, strel); 
/*  163 */       if (this == EROSION)
/*  164 */         return Morphology.erosion(image, strel); 
/*  165 */       if (this == CLOSING)
/*  166 */         return Morphology.closing(image, strel); 
/*  167 */       if (this == OPENING)
/*  168 */         return Morphology.opening(image, strel); 
/*  169 */       if (this == TOPHAT)
/*  170 */         return Morphology.whiteTopHat(image, strel); 
/*  171 */       if (this == BOTTOMHAT)
/*  172 */         return Morphology.blackTopHat(image, strel); 
/*  173 */       if (this == GRADIENT)
/*  174 */         return Morphology.gradient(image, strel); 
/*  175 */       if (this == LAPLACIAN)
/*  176 */         return Morphology.laplacian(image, strel); 
/*  177 */       if (this == INTERNAL_GRADIENT)
/*  178 */         return Morphology.internalGradient(image, strel); 
/*  179 */       if (this == EXTERNAL_GRADIENT) {
/*  180 */         return Morphology.externalGradient(image, strel);
/*      */       }
/*  182 */       throw new RuntimeException(
/*  183 */           "Unable to process the " + this + " morphological operation");
/*      */     }
/*      */ 
/*      */     
/*      */     public String toString() {
/*  188 */       return this.label;
/*      */     }
/*      */ 
/*      */     
/*      */     public static String[] getAllLabels() {
/*  193 */       int n = (values()).length;
/*  194 */       String[] result = new String[n];
/*      */       
/*  196 */       int i = 0; byte b; int j; Operation[] arrayOfOperation;
/*  197 */       for (j = (arrayOfOperation = values()).length, b = 0; b < j; ) { Operation op = arrayOfOperation[b];
/*  198 */         result[i++] = op.label; b++; }
/*      */       
/*  200 */       return result;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static Operation fromLabel(String opLabel) {
/*  214 */       if (opLabel != null)
/*  215 */         opLabel = opLabel.toLowerCase();  byte b; int i; Operation[] arrayOfOperation;
/*  216 */       for (i = (arrayOfOperation = values()).length, b = 0; b < i; ) { Operation op = arrayOfOperation[b];
/*      */         
/*  218 */         String cmp = op.label.toLowerCase();
/*  219 */         if (cmp.equals(opLabel))
/*  220 */           return op;  b++; }
/*      */       
/*  222 */       throw new IllegalArgumentException("Unable to parse Operation with label: " + opLabel);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImageProcessor dilation(ImageProcessor image, Strel strel) {
/*  257 */     checkImageType(image);
/*  258 */     if (image instanceof ij.process.ColorProcessor) {
/*  259 */       return dilationRGB(image, strel);
/*      */     }
/*  261 */     return strel.dilation(image);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static ImageProcessor dilationRGB(ImageProcessor image, Strel strel) {
/*  277 */     Map<String, ByteProcessor> channels = ColorImages.mapChannels(image);
/*  278 */     Collection<ImageProcessor> res = new ArrayList<ImageProcessor>(channels.size()); byte b;
/*      */     int i;
/*      */     String[] arrayOfString;
/*  281 */     for (i = (arrayOfString = new String[] { "red", "green", "blue" }, ).length, b = 0; b < i; ) { String name = arrayOfString[b];
/*      */       
/*  283 */       strel.setChannelName(name);
/*  284 */       res.add(strel.dilation((ImageProcessor)channels.get(name)));
/*      */       b++; }
/*      */     
/*  287 */     return (ImageProcessor)ColorImages.mergeChannels(res);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImageStack dilation(ImageStack image, Strel3D strel) {
/*  304 */     checkImageType(image);
/*  305 */     return strel.dilation(image);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImageProcessor erosion(ImageProcessor image, Strel strel) {
/*  327 */     checkImageType(image);
/*  328 */     if (image instanceof ij.process.ColorProcessor) {
/*  329 */       return erosionRGB(image, strel);
/*      */     }
/*  331 */     return strel.erosion(image);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static ImageProcessor erosionRGB(ImageProcessor image, Strel strel) {
/*  347 */     Map<String, ByteProcessor> channels = ColorImages.mapChannels(image);
/*  348 */     Collection<ImageProcessor> res = new ArrayList<ImageProcessor>(channels.size()); byte b;
/*      */     int i;
/*      */     String[] arrayOfString;
/*  351 */     for (i = (arrayOfString = new String[] { "red", "green", "blue" }, ).length, b = 0; b < i; ) { String name = arrayOfString[b];
/*      */       
/*  353 */       strel.setChannelName(name);
/*  354 */       res.add(strel.erosion((ImageProcessor)channels.get(name)));
/*      */       b++; }
/*      */     
/*  357 */     return (ImageProcessor)ColorImages.mergeChannels(res);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImageStack erosion(ImageStack image, Strel3D strel) {
/*  374 */     checkImageType(image);
/*  375 */     return strel.erosion(image);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImageProcessor opening(ImageProcessor image, Strel strel) {
/*  397 */     checkImageType(image);
/*  398 */     if (image instanceof ij.process.ColorProcessor) {
/*  399 */       return openingRGB(image, strel);
/*      */     }
/*  401 */     return strel.opening(image);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static ImageProcessor openingRGB(ImageProcessor image, Strel strel) {
/*  411 */     Map<String, ByteProcessor> channels = ColorImages.mapChannels(image);
/*  412 */     Collection<ImageProcessor> res = new ArrayList<ImageProcessor>(channels.size()); byte b;
/*      */     int i;
/*      */     String[] arrayOfString;
/*  415 */     for (i = (arrayOfString = new String[] { "red", "green", "blue" }, ).length, b = 0; b < i; ) { String name = arrayOfString[b];
/*      */       
/*  417 */       strel.setChannelName(name);
/*  418 */       res.add(strel.opening((ImageProcessor)channels.get(name)));
/*      */       b++; }
/*      */     
/*  421 */     return (ImageProcessor)ColorImages.mergeChannels(res);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImageStack opening(ImageStack image, Strel3D strel) {
/*  441 */     checkImageType(image);
/*  442 */     return strel.opening(image);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImageProcessor closing(ImageProcessor image, Strel strel) {
/*  463 */     checkImageType(image);
/*  464 */     if (image instanceof ij.process.ColorProcessor) {
/*  465 */       return closingRGB(image, strel);
/*      */     }
/*  467 */     return strel.closing(image);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static ImageProcessor closingRGB(ImageProcessor image, Strel strel) {
/*  477 */     Map<String, ByteProcessor> channels = ColorImages.mapChannels(image);
/*  478 */     Collection<ImageProcessor> res = new ArrayList<ImageProcessor>(channels.size()); byte b;
/*      */     int i;
/*      */     String[] arrayOfString;
/*  481 */     for (i = (arrayOfString = new String[] { "red", "green", "blue" }, ).length, b = 0; b < i; ) { String name = arrayOfString[b];
/*      */       
/*  483 */       strel.setChannelName(name);
/*  484 */       res.add(strel.closing((ImageProcessor)channels.get(name)));
/*      */       b++; }
/*      */     
/*  487 */     return (ImageProcessor)ColorImages.mergeChannels(res);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImageStack closing(ImageStack image, Strel3D strel) {
/*  507 */     checkImageType(image);
/*  508 */     return strel.closing(image);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImageProcessor whiteTopHat(ImageProcessor image, Strel strel) {
/*  530 */     checkImageType(image);
/*  531 */     if (image instanceof ij.process.ColorProcessor) {
/*  532 */       return whiteTopHatRGB(image, strel);
/*      */     }
/*      */     
/*  535 */     ImageProcessor result = strel.opening(image);
/*      */ 
/*      */     
/*  538 */     int count = image.getPixelCount();
/*  539 */     if (image instanceof ByteProcessor) {
/*      */       
/*  541 */       for (int i = 0; i < count; i++)
/*      */       {
/*      */ 
/*      */         
/*  545 */         int v1 = image.get(i);
/*  546 */         int v2 = result.get(i);
/*  547 */         result.set(i, clamp(v1 - v2, 0, 255));
/*      */       }
/*      */     
/*      */     } else {
/*      */       
/*  552 */       for (int i = 0; i < count; i++) {
/*      */         
/*  554 */         float v1 = image.getf(i);
/*  555 */         float v2 = result.getf(i);
/*  556 */         result.setf(i, v1 - v2);
/*      */       } 
/*      */     } 
/*      */     
/*  560 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static ImageProcessor whiteTopHatRGB(ImageProcessor image, Strel strel) {
/*  570 */     Map<String, ByteProcessor> channels = ColorImages.mapChannels(image);
/*  571 */     Collection<ImageProcessor> res = new ArrayList<ImageProcessor>(channels.size()); byte b;
/*      */     int i;
/*      */     String[] arrayOfString;
/*  574 */     for (i = (arrayOfString = new String[] { "red", "green", "blue" }, ).length, b = 0; b < i; ) { String name = arrayOfString[b];
/*      */       
/*  576 */       strel.setChannelName(name);
/*  577 */       res.add(whiteTopHat((ImageProcessor)channels.get(name), strel));
/*      */       
/*      */       b++; }
/*      */     
/*  581 */     return (ImageProcessor)ColorImages.mergeChannels(res);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImageStack whiteTopHat(ImageStack image, Strel3D strel) {
/*  603 */     checkImageType(image);
/*      */ 
/*      */     
/*  606 */     ImageStack result = strel.opening(image);
/*      */ 
/*      */     
/*  609 */     double maxVal = getMaxPossibleValue(image);
/*      */ 
/*      */     
/*  612 */     int nx = image.getWidth();
/*  613 */     int ny = image.getHeight();
/*  614 */     int nz = image.getSize();
/*  615 */     for (int z = 0; z < nz; z++) {
/*      */       
/*  617 */       for (int y = 0; y < ny; y++) {
/*      */         
/*  619 */         for (int x = 0; x < nx; x++) {
/*      */           
/*  621 */           double v1 = image.getVoxel(x, y, z);
/*  622 */           double v2 = result.getVoxel(x, y, z);
/*  623 */           result.setVoxel(x, y, z, Math.min(Math.max(v1 - v2, 0.0D), maxVal));
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/*  628 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImageProcessor blackTopHat(ImageProcessor image, Strel strel) {
/*  651 */     checkImageType(image);
/*  652 */     if (image instanceof ij.process.ColorProcessor) {
/*  653 */       return blackTopHatRGB(image, strel);
/*      */     }
/*      */     
/*  656 */     ImageProcessor result = strel.closing(image);
/*      */ 
/*      */     
/*  659 */     int count = image.getPixelCount();
/*  660 */     if (image instanceof ByteProcessor) {
/*      */       
/*  662 */       for (int i = 0; i < count; i++)
/*      */       {
/*      */ 
/*      */         
/*  666 */         int v1 = result.get(i);
/*  667 */         int v2 = image.get(i);
/*  668 */         result.set(i, clamp(v1 - v2, 0, 255));
/*      */       }
/*      */     
/*      */     } else {
/*      */       
/*  673 */       for (int i = 0; i < count; i++) {
/*      */         
/*  675 */         float v1 = result.getf(i);
/*  676 */         float v2 = image.getf(i);
/*  677 */         result.setf(i, v1 - v2);
/*      */       } 
/*      */     } 
/*  680 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static ImageProcessor blackTopHatRGB(ImageProcessor image, Strel strel) {
/*  690 */     Map<String, ByteProcessor> channels = ColorImages.mapChannels(image);
/*  691 */     Collection<ImageProcessor> res = new ArrayList<ImageProcessor>(channels.size()); byte b;
/*      */     int i;
/*      */     String[] arrayOfString;
/*  694 */     for (i = (arrayOfString = new String[] { "red", "green", "blue" }, ).length, b = 0; b < i; ) { String name = arrayOfString[b];
/*      */       
/*  696 */       strel.setChannelName(name);
/*  697 */       res.add(blackTopHat((ImageProcessor)channels.get(name), strel));
/*      */       b++; }
/*      */     
/*  700 */     return (ImageProcessor)ColorImages.mergeChannels(res);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImageStack blackTopHat(ImageStack image, Strel3D strel) {
/*  721 */     checkImageType(image);
/*      */ 
/*      */     
/*  724 */     ImageStack result = strel.closing(image);
/*      */ 
/*      */     
/*  727 */     int nx = image.getWidth();
/*  728 */     int ny = image.getHeight();
/*  729 */     int nz = image.getSize();
/*  730 */     for (int z = 0; z < nz; z++) {
/*  731 */       for (int y = 0; y < ny; y++) {
/*  732 */         for (int x = 0; x < nx; x++) {
/*  733 */           double v1 = result.getVoxel(x, y, z);
/*  734 */           double v2 = image.getVoxel(x, y, z);
/*  735 */           result.setVoxel(x, y, z, Math.min(Math.max(v1 - v2, 0.0D), 255.0D));
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/*  740 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImageProcessor gradient(ImageProcessor image, Strel strel) {
/*  760 */     checkImageType(image);
/*  761 */     if (image instanceof ij.process.ColorProcessor) {
/*  762 */       return gradientRGB(image, strel);
/*      */     }
/*      */     
/*  765 */     ImageProcessor result = strel.dilation(image);
/*  766 */     ImageProcessor eroded = strel.erosion(image);
/*      */ 
/*      */     
/*  769 */     int count = image.getPixelCount();
/*  770 */     if (image instanceof ByteProcessor) {
/*      */       
/*  772 */       for (int i = 0; i < count; i++)
/*      */       {
/*      */ 
/*      */         
/*  776 */         int v1 = result.get(i);
/*  777 */         int v2 = eroded.get(i);
/*  778 */         result.set(i, clamp(v1 - v2, 0, 255));
/*      */       }
/*      */     
/*      */     } else {
/*      */       
/*  783 */       for (int i = 0; i < count; i++) {
/*      */         
/*  785 */         float v1 = result.getf(i);
/*  786 */         float v2 = eroded.getf(i);
/*  787 */         result.setf(i, v1 - v2);
/*      */       } 
/*      */     } 
/*      */     
/*  791 */     eroded = null;
/*      */ 
/*      */     
/*  794 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static ImageProcessor gradientRGB(ImageProcessor image, Strel strel) {
/*  804 */     Map<String, ByteProcessor> channels = ColorImages.mapChannels(image);
/*  805 */     Collection<ImageProcessor> res = new ArrayList<ImageProcessor>(channels.size()); byte b;
/*      */     int i;
/*      */     String[] arrayOfString;
/*  808 */     for (i = (arrayOfString = new String[] { "red", "green", "blue" }, ).length, b = 0; b < i; ) { String name = arrayOfString[b];
/*      */       
/*  810 */       strel.setChannelName(name);
/*  811 */       res.add(gradient((ImageProcessor)channels.get(name), strel));
/*      */       b++; }
/*      */     
/*  814 */     return (ImageProcessor)ColorImages.mergeChannels(res);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImageStack gradient(ImageStack image, Strel3D strel) {
/*  833 */     checkImageType(image);
/*      */ 
/*      */     
/*  836 */     ImageStack result = strel.dilation(image);
/*  837 */     ImageStack eroded = strel.erosion(image);
/*      */ 
/*      */     
/*  840 */     double maxVal = getMaxPossibleValue(image);
/*      */ 
/*      */     
/*  843 */     int nx = image.getWidth();
/*  844 */     int ny = image.getHeight();
/*  845 */     int nz = image.getSize();
/*  846 */     for (int z = 0; z < nz; z++) {
/*      */       
/*  848 */       for (int y = 0; y < ny; y++) {
/*      */         
/*  850 */         for (int x = 0; x < nx; x++) {
/*      */           
/*  852 */           double v1 = result.getVoxel(x, y, z);
/*  853 */           double v2 = eroded.getVoxel(x, y, z);
/*  854 */           result.setVoxel(x, y, z, Math.min(Math.max(v1 - v2, 0.0D), maxVal));
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/*  859 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImageProcessor laplacian(ImageProcessor image, Strel strel) {
/*  882 */     checkImageType(image);
/*  883 */     if (image instanceof ij.process.ColorProcessor) {
/*  884 */       return laplacianRGB(image, strel);
/*      */     }
/*      */     
/*  887 */     ImageProcessor outer = externalGradient(image, strel);
/*  888 */     ImageProcessor inner = internalGradient(image, strel);
/*      */ 
/*      */     
/*  891 */     ImageProcessor result = image.duplicate();
/*  892 */     int count = image.getPixelCount();
/*  893 */     if (image instanceof ByteProcessor) {
/*      */       
/*  895 */       for (int i = 0; i < count; i++)
/*      */       {
/*      */ 
/*      */         
/*  899 */         int v1 = outer.get(i);
/*  900 */         int v2 = inner.get(i);
/*  901 */         result.set(i, clamp(v1 - v2 + 128, 0, 255));
/*      */       }
/*      */     
/*      */     } else {
/*      */       
/*  906 */       for (int i = 0; i < count; i++) {
/*      */         
/*  908 */         float v1 = outer.getf(i);
/*  909 */         float v2 = inner.getf(i);
/*  910 */         result.setf(i, v1 - v2);
/*      */       } 
/*      */     } 
/*      */     
/*  914 */     outer = null;
/*  915 */     inner = null;
/*      */ 
/*      */     
/*  918 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static ImageProcessor laplacianRGB(ImageProcessor image, Strel strel) {
/*  930 */     Map<String, ByteProcessor> channels = ColorImages.mapChannels(image);
/*  931 */     Collection<ImageProcessor> res = new ArrayList<ImageProcessor>(channels.size()); byte b;
/*      */     int i;
/*      */     String[] arrayOfString;
/*  934 */     for (i = (arrayOfString = new String[] { "red", "green", "blue" }, ).length, b = 0; b < i; ) { String name = arrayOfString[b];
/*      */       
/*  936 */       strel.setChannelName(name);
/*  937 */       res.add(laplacian((ImageProcessor)channels.get(name), strel));
/*      */       b++; }
/*      */     
/*  940 */     return (ImageProcessor)ColorImages.mergeChannels(res);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImageStack laplacian(ImageStack image, Strel3D strel) {
/*  962 */     checkImageType(image);
/*      */ 
/*      */     
/*  965 */     ImageStack outer = externalGradient(image, strel);
/*  966 */     ImageStack inner = internalGradient(image, strel);
/*      */ 
/*      */     
/*  969 */     double maxVal = getMaxPossibleValue(image);
/*  970 */     double midVal = maxVal / 2.0D;
/*      */ 
/*      */     
/*  973 */     int nx = image.getWidth();
/*  974 */     int ny = image.getHeight();
/*  975 */     int nz = image.getSize();
/*  976 */     for (int z = 0; z < nz; z++) {
/*      */       
/*  978 */       for (int y = 0; y < ny; y++) {
/*      */         
/*  980 */         for (int x = 0; x < nx; x++) {
/*      */           
/*  982 */           double v1 = outer.getVoxel(x, y, z);
/*  983 */           double v2 = inner.getVoxel(x, y, z);
/*  984 */           outer.setVoxel(x, y, z, Math.min(Math.max(v1 - v2 + midVal, 0.0D), maxVal));
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/*  989 */     return outer;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImageProcessor internalGradient(ImageProcessor image, Strel strel) {
/* 1009 */     checkImageType(image);
/* 1010 */     if (image instanceof ij.process.ColorProcessor) {
/* 1011 */       return internalGradientRGB(image, strel);
/*      */     }
/*      */     
/* 1014 */     ImageProcessor result = strel.erosion(image);
/*      */ 
/*      */     
/* 1017 */     int count = image.getPixelCount();
/* 1018 */     if (image instanceof ByteProcessor) {
/*      */       
/* 1020 */       for (int i = 0; i < count; i++)
/*      */       {
/*      */ 
/*      */         
/* 1024 */         int v1 = image.get(i);
/* 1025 */         int v2 = result.get(i);
/* 1026 */         result.set(i, clamp(v1 - v2, 0, 255));
/*      */       }
/*      */     
/*      */     } else {
/*      */       
/* 1031 */       for (int i = 0; i < count; i++) {
/*      */         
/* 1033 */         float v1 = image.getf(i);
/* 1034 */         float v2 = result.getf(i);
/* 1035 */         result.setf(i, v1 - v2);
/*      */       } 
/*      */     } 
/*      */     
/* 1039 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static ImageProcessor internalGradientRGB(ImageProcessor image, Strel strel) {
/* 1045 */     Map<String, ByteProcessor> channels = ColorImages.mapChannels(image);
/* 1046 */     Collection<ImageProcessor> res = new ArrayList<ImageProcessor>(channels.size()); byte b;
/*      */     int i;
/*      */     String[] arrayOfString;
/* 1049 */     for (i = (arrayOfString = new String[] { "red", "green", "blue" }, ).length, b = 0; b < i; ) { String name = arrayOfString[b];
/*      */       
/* 1051 */       strel.setChannelName(name);
/* 1052 */       res.add(internalGradient((ImageProcessor)channels.get(name), strel));
/*      */       b++; }
/*      */     
/* 1055 */     return (ImageProcessor)ColorImages.mergeChannels(res);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImageStack internalGradient(ImageStack image, Strel3D strel) {
/* 1075 */     checkImageType(image);
/*      */ 
/*      */     
/* 1078 */     ImageStack result = strel.erosion(image);
/*      */ 
/*      */     
/* 1081 */     double maxVal = getMaxPossibleValue(image);
/*      */ 
/*      */     
/* 1084 */     int nx = image.getWidth();
/* 1085 */     int ny = image.getHeight();
/* 1086 */     int nz = image.getSize();
/* 1087 */     for (int z = 0; z < nz; z++) {
/*      */       
/* 1089 */       for (int y = 0; y < ny; y++) {
/*      */         
/* 1091 */         for (int x = 0; x < nx; x++) {
/*      */           
/* 1093 */           double v1 = image.getVoxel(x, y, z);
/* 1094 */           double v2 = result.getVoxel(x, y, z);
/* 1095 */           result.setVoxel(x, y, z, Math.min(Math.max(v1 - v2, 0.0D), maxVal));
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/* 1100 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImageProcessor externalGradient(ImageProcessor image, Strel strel) {
/* 1118 */     checkImageType(image);
/* 1119 */     if (image instanceof ij.process.ColorProcessor) {
/* 1120 */       return externalGradientRGB(image, strel);
/*      */     }
/*      */     
/* 1123 */     ImageProcessor result = strel.dilation(image);
/*      */ 
/*      */     
/* 1126 */     int count = image.getPixelCount();
/* 1127 */     if (image instanceof ByteProcessor) {
/*      */       
/* 1129 */       for (int i = 0; i < count; i++)
/*      */       {
/*      */ 
/*      */         
/* 1133 */         int v1 = result.get(i);
/* 1134 */         int v2 = image.get(i);
/* 1135 */         result.set(i, clamp(v1 - v2, 0, 255));
/*      */       }
/*      */     
/*      */     } else {
/*      */       
/* 1140 */       for (int i = 0; i < count; i++) {
/*      */         
/* 1142 */         float v1 = result.getf(i);
/* 1143 */         float v2 = image.getf(i);
/* 1144 */         result.setf(i, v1 - v2);
/*      */       } 
/*      */     } 
/*      */     
/* 1148 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static ImageProcessor externalGradientRGB(ImageProcessor image, Strel strel) {
/* 1154 */     Map<String, ByteProcessor> channels = ColorImages.mapChannels(image);
/* 1155 */     Collection<ImageProcessor> res = new ArrayList<ImageProcessor>(channels.size()); byte b;
/*      */     int i;
/*      */     String[] arrayOfString;
/* 1158 */     for (i = (arrayOfString = new String[] { "red", "green", "blue" }, ).length, b = 0; b < i; ) { String name = arrayOfString[b];
/*      */       
/* 1160 */       strel.setChannelName(name);
/* 1161 */       res.add(externalGradient((ImageProcessor)channels.get(name), strel));
/*      */       b++; }
/*      */     
/* 1164 */     return (ImageProcessor)ColorImages.mergeChannels(res);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImageStack externalGradient(ImageStack image, Strel3D strel) {
/* 1183 */     checkImageType(image);
/*      */ 
/*      */     
/* 1186 */     ImageStack result = strel.dilation(image);
/*      */ 
/*      */     
/* 1189 */     double maxVal = getMaxPossibleValue(image);
/*      */ 
/*      */     
/* 1192 */     int nx = image.getWidth();
/* 1193 */     int ny = image.getHeight();
/* 1194 */     int nz = image.getSize();
/* 1195 */     for (int z = 0; z < nz; z++) {
/*      */       
/* 1197 */       for (int y = 0; y < ny; y++) {
/*      */         
/* 1199 */         for (int x = 0; x < nx; x++) {
/*      */           
/* 1201 */           double v1 = result.getVoxel(x, y, z);
/* 1202 */           double v2 = image.getVoxel(x, y, z);
/* 1203 */           result.setVoxel(x, y, z, Math.min(Math.max(v1 - v2, 0.0D), maxVal));
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/* 1208 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final void checkImageType(ImageProcessor image) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final void checkImageType(ImageStack stack) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final double getMaxPossibleValue(ImageStack stack) {
/* 1250 */     double maxVal = 255.0D;
/* 1251 */     int bitDepth = stack.getBitDepth();
/* 1252 */     if (bitDepth == 16) {
/*      */       
/* 1254 */       maxVal = 65535.0D;
/*      */     }
/* 1256 */     else if (bitDepth == 32) {
/*      */       
/* 1258 */       maxVal = 3.4028234663852886E38D;
/*      */     } 
/* 1260 */     return maxVal;
/*      */   }
/*      */ 
/*      */   
/*      */   private static final int clamp(int value, int min, int max) {
/* 1265 */     return Math.min(Math.max(value, min), max);
/*      */   }
/*      */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/morphology/Morphology.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */