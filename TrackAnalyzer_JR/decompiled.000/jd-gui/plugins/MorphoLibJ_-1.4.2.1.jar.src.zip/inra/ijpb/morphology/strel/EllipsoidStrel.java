/*     */ package inra.ijpb.morphology.strel;
/*     */ 
/*     */ import ij.ImageStack;
/*     */ import ij.plugin.Filters3D;
/*     */ import inra.ijpb.morphology.Strel3D;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EllipsoidStrel
/*     */   extends AbstractStrel3D
/*     */ {
/*     */   double xRadius;
/*     */   double yRadius;
/*     */   double zRadius;
/*     */   
/*     */   public static final EllipsoidStrel fromRadius(double radius) {
/*  57 */     return new EllipsoidStrel(radius);
/*     */   }
/*     */ 
/*     */   
/*     */   public static final EllipsoidStrel fromRadiusList(double radiusX, double radiusY, double radiusZ) {
/*  62 */     return new EllipsoidStrel(radiusX, radiusY, radiusZ);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final EllipsoidStrel fromDiameter(double diam) {
/*  74 */     return new EllipsoidStrel((diam - 1.0D) / 2.0D);
/*     */   }
/*     */ 
/*     */   
/*     */   public static final EllipsoidStrel fromDiameterList(double diamX, double diamY, double diamZ) {
/*  79 */     double radiusX = (diamX - 1.0D) / 2.0D;
/*  80 */     double radiusY = (diamY - 1.0D) / 2.0D;
/*  81 */     double radiusZ = (diamZ - 1.0D) / 2.0D;
/*  82 */     return new EllipsoidStrel(radiusX, radiusY, radiusZ);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private EllipsoidStrel(double radius) {
/*  93 */     this.xRadius = radius;
/*  94 */     this.yRadius = radius;
/*  95 */     this.zRadius = radius;
/*     */   }
/*     */ 
/*     */   
/*     */   private EllipsoidStrel(double xRadius, double yRadius, double zRadius) {
/* 100 */     this.xRadius = xRadius;
/* 101 */     this.yRadius = yRadius;
/* 102 */     this.zRadius = zRadius;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int[] getSize() {
/* 112 */     int diamX = 2 * (int)Math.round(this.xRadius) + 1;
/* 113 */     int diamY = 2 * (int)Math.round(this.yRadius) + 1;
/* 114 */     int diamZ = 2 * (int)Math.round(this.zRadius) + 1;
/* 115 */     return new int[] { diamX, diamY, diamZ };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int[][][] getMask3D() {
/* 122 */     int sizeX = 2 * (int)Math.round(this.xRadius) + 1;
/* 123 */     int sizeY = 2 * (int)Math.round(this.yRadius) + 1;
/* 124 */     int sizeZ = 2 * (int)Math.round(this.zRadius) + 1;
/* 125 */     ImageStack img = ImageStack.create(sizeX, sizeY, sizeZ, 8);
/* 126 */     img.setVoxel((int)Math.round(this.xRadius), (int)Math.round(this.yRadius), (int)Math.round(this.zRadius), 255.0D);
/*     */ 
/*     */     
/* 129 */     img = dilation(img);
/*     */ 
/*     */     
/* 132 */     int[][][] mask = new int[sizeZ][sizeY][sizeX];
/* 133 */     for (int z = 0; z < sizeZ; z++) {
/*     */       
/* 135 */       for (int y = 0; y < sizeY; y++) {
/*     */         
/* 137 */         for (int x = 0; x < sizeX; x++)
/*     */         {
/* 139 */           mask[z][y][x] = (int)img.getVoxel(x, y, z);
/*     */         }
/*     */       } 
/*     */     } 
/* 143 */     return mask;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int[] getOffset() {
/* 149 */     int intRadius = (int)Math.round(this.xRadius);
/* 150 */     return new int[] { intRadius, intRadius, intRadius };
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int[][] getShifts3D() {
/* 156 */     int[][][] mask = getMask3D();
/* 157 */     int sizeX = 2 * (int)Math.round(this.xRadius) + 1;
/* 158 */     int sizeY = 2 * (int)Math.round(this.yRadius) + 1;
/* 159 */     int sizeZ = 2 * (int)Math.round(this.zRadius) + 1;
/*     */ 
/*     */     
/* 162 */     int n = 0;
/* 163 */     for (int z = 0; z < sizeZ; z++) {
/*     */       
/* 165 */       for (int y = 0; y < sizeY; y++) {
/*     */         
/* 167 */         for (int x = 0; x < sizeX; x++) {
/*     */           
/* 169 */           if (mask[z][y][x] > 0) {
/* 170 */             n++;
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 176 */     int[][] offsets = new int[n][2];
/* 177 */     int i = 0;
/* 178 */     for (int j = 0; j < sizeZ; j++) {
/*     */       
/* 180 */       for (int y = 0; y < sizeY; y++) {
/*     */         
/* 182 */         for (int x = 0; x < sizeX; x++) {
/*     */           
/* 184 */           if (mask[j][y][x] > 0) {
/*     */             
/* 186 */             offsets[i][0] = x;
/* 187 */             offsets[i][1] = y;
/* 188 */             i++;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/* 193 */     return offsets;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Strel3D reverse() {
/* 204 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ImageStack dilation(ImageStack image) {
/* 218 */     float rx = (float)this.xRadius;
/* 219 */     float ry = (float)this.yRadius;
/* 220 */     float rz = (float)this.zRadius;
/* 221 */     ImageStack result = Filters3D.filter(image, 13, rx, ry, rz);
/* 222 */     result.setColorModel(image.getColorModel());
/* 223 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ImageStack erosion(ImageStack image) {
/* 237 */     float rx = (float)this.xRadius;
/* 238 */     float ry = (float)this.yRadius;
/* 239 */     float rz = (float)this.zRadius;
/* 240 */     ImageStack result = Filters3D.filter(image, 12, rx, ry, rz);
/* 241 */     result.setColorModel(image.getColorModel());
/* 242 */     return result;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/morphology/strel/EllipsoidStrel.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */