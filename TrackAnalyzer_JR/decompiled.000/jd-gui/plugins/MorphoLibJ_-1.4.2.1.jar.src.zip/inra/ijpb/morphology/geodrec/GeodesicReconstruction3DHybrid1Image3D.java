/*     */ package inra.ijpb.morphology.geodrec;
/*     */ 
/*     */ import ij.ImageStack;
/*     */ import inra.ijpb.data.Cursor3D;
/*     */ import inra.ijpb.data.image.Image3D;
/*     */ import inra.ijpb.data.image.Images3D;
/*     */ import java.util.ArrayDeque;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GeodesicReconstruction3DHybrid1Image3D
/*     */   extends GeodesicReconstruction3DAlgoStub
/*     */ {
/*  58 */   GeodesicReconstructionType reconstructionType = GeodesicReconstructionType.BY_DILATION;
/*     */   
/*     */   ImageStack markerStack;
/*     */   
/*     */   ImageStack maskStack;
/*     */   
/*     */   ImageStack resultStack;
/*     */   
/*     */   Image3D result;
/*     */   Image3D mask;
/*     */   Image3D marker;
/*  69 */   int sizeX = 0;
/*     */   
/*  71 */   int sizeY = 0;
/*     */   
/*  73 */   int sizeZ = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ArrayDeque<Cursor3D> queue;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GeodesicReconstruction3DHybrid1Image3D() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GeodesicReconstruction3DHybrid1Image3D(GeodesicReconstructionType type) {
/*  95 */     this.reconstructionType = type;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GeodesicReconstruction3DHybrid1Image3D(GeodesicReconstructionType type, int connectivity) {
/* 110 */     this.reconstructionType = type;
/* 111 */     this.connectivity = connectivity;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GeodesicReconstruction3DHybrid1Image3D(int connectivity) {
/* 123 */     this.connectivity = connectivity;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GeodesicReconstructionType getReconstructionType() {
/* 131 */     return this.reconstructionType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setReconstructionType(GeodesicReconstructionType reconstructionType) {
/* 140 */     this.reconstructionType = reconstructionType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ImageStack applyTo(ImageStack marker, ImageStack mask) {
/* 150 */     this.markerStack = marker;
/* 151 */     this.maskStack = mask;
/*     */     
/* 153 */     this.marker = Images3D.createWrapper(marker);
/* 154 */     this.mask = Images3D.createWrapper(mask);
/*     */ 
/*     */     
/* 157 */     this.sizeX = marker.getWidth();
/* 158 */     this.sizeY = marker.getHeight();
/* 159 */     this.sizeZ = marker.getSize();
/* 160 */     if (!Images3D.isSameSize(marker, mask))
/*     */     {
/* 162 */       throw new IllegalArgumentException("Marker and Mask images must have the same size");
/*     */     }
/*     */ 
/*     */     
/* 166 */     if (this.connectivity != 6 && this.connectivity != 26)
/*     */     {
/* 168 */       throw new RuntimeException(
/* 169 */           "Connectivity for stacks must be either 6 or 26, not " + 
/* 170 */           this.connectivity);
/*     */     }
/*     */     
/* 173 */     long t0 = System.currentTimeMillis();
/* 174 */     trace("Initialize result ");
/*     */     
/* 176 */     initializeResult();
/* 177 */     if (this.verbose) {
/*     */       
/* 179 */       long t1 = System.currentTimeMillis();
/* 180 */       System.out.println(String.valueOf(t1 - t0) + " ms");
/* 181 */       t0 = t1;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 186 */     trace("Forward iteration ");
/* 187 */     showStatus("Geod. Rec. Fwd ");
/*     */     
/* 189 */     forwardScan();
/* 190 */     if (this.verbose) {
/*     */       
/* 192 */       long t1 = System.currentTimeMillis();
/* 193 */       System.out.println(String.valueOf(t1 - t0) + " ms");
/* 194 */       t0 = t1;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 199 */     trace("Backward iteration ");
/* 200 */     showStatus("Geod. Rec. Bwd ");
/*     */     
/* 202 */     backwardScan();
/* 203 */     if (this.verbose) {
/*     */       
/* 205 */       long t1 = System.currentTimeMillis();
/* 206 */       System.out.println(String.valueOf(t1 - t0) + " ms");
/* 207 */       t0 = t1;
/*     */     } 
/*     */ 
/*     */     
/* 211 */     trace("Init queue ");
/* 212 */     showStatus("Init queue");
/*     */     
/* 214 */     initQueue();
/* 215 */     if (this.verbose) {
/*     */       
/* 217 */       long t1 = System.currentTimeMillis();
/* 218 */       System.out.println(String.valueOf(t1 - t0) + " ms");
/* 219 */       t0 = t1;
/*     */     } 
/*     */ 
/*     */     
/* 223 */     trace("Process queue");
/* 224 */     showStatus("Process queue");
/*     */     
/* 226 */     processQueue();
/* 227 */     if (this.verbose) {
/*     */       
/* 229 */       long t1 = System.currentTimeMillis();
/* 230 */       System.out.println(String.valueOf(t1 - t0) + " ms");
/* 231 */       t0 = t1;
/*     */     } 
/*     */     
/* 234 */     return this.resultStack;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ImageStack applyTo(ImageStack marker, ImageStack mask, ImageStack binaryMask) {
/* 246 */     throw new RuntimeException("Method not yet implemented");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void initializeResult() {
/* 257 */     this.resultStack = ImageStack.create(this.sizeX, this.sizeY, this.sizeZ, this.maskStack.getBitDepth());
/* 258 */     this.result = Images3D.createWrapper(this.resultStack);
/*     */     
/* 260 */     if (this.reconstructionType == GeodesicReconstructionType.BY_DILATION) {
/*     */ 
/*     */ 
/*     */       
/* 264 */       if (this.maskStack.getBitDepth() == 32) {
/*     */ 
/*     */         
/* 267 */         for (int z = 0; z < this.sizeZ; z++)
/*     */         {
/* 269 */           for (int y = 0; y < this.sizeY; y++)
/*     */           {
/* 271 */             for (int x = 0; x < this.sizeX; x++)
/*     */             {
/* 273 */               this.result.setValue(x, y, z, Math.min(this.marker.getValue(x, y, z), this.mask.getValue(x, y, z)));
/*     */             }
/*     */           }
/*     */         
/*     */         }
/*     */       
/*     */       } else {
/*     */         
/* 281 */         for (int z = 0; z < this.sizeZ; z++)
/*     */         {
/* 283 */           for (int y = 0; y < this.sizeY; y++)
/*     */           {
/* 285 */             for (int x = 0; x < this.sizeX; x++)
/*     */             {
/* 287 */               this.result.setValue(x, y, z, Math.min(this.marker.getValue(x, y, z), this.mask.getValue(x, y, z)));
/*     */             
/*     */             }
/*     */           }
/*     */         
/*     */         }
/*     */       
/*     */       }
/*     */     
/*     */     }
/* 297 */     else if (this.maskStack.getBitDepth() == 32) {
/*     */ 
/*     */       
/* 300 */       for (int z = 0; z < this.sizeZ; z++)
/*     */       {
/* 302 */         for (int y = 0; y < this.sizeY; y++)
/*     */         {
/* 304 */           for (int x = 0; x < this.sizeX; x++)
/*     */           {
/* 306 */             this.result.setValue(x, y, z, Math.max(this.marker.getValue(x, y, z), this.mask.getValue(x, y, z)));
/*     */           }
/*     */         }
/*     */       
/*     */       }
/*     */     
/*     */     } else {
/*     */       
/* 314 */       for (int z = 0; z < this.sizeZ; z++) {
/*     */         
/* 316 */         for (int y = 0; y < this.sizeY; y++) {
/*     */           
/* 318 */           for (int x = 0; x < this.sizeX; x++)
/*     */           {
/* 320 */             this.result.setValue(x, y, z, Math.max(this.marker.getValue(x, y, z), this.mask.getValue(x, y, z)));
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void forwardScan() {
/* 330 */     if (this.connectivity == 6) {
/*     */       
/* 332 */       forwardScanC6();
/*     */     }
/*     */     else {
/*     */       
/* 336 */       forwardScanC26();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void forwardScanC6() {
/* 346 */     int sign = this.reconstructionType.getSign();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 352 */     for (int z = 0; z < this.sizeZ; z++) {
/*     */       
/* 354 */       showProgress(z, this.sizeZ);
/*     */       
/* 356 */       for (int y = 0; y < this.sizeY; y++) {
/*     */         
/* 358 */         for (int x = 0; x < this.sizeX; x++) {
/*     */           
/* 360 */           double currentValue = this.result.getValue(x, y, z) * sign;
/* 361 */           double maxValue = currentValue;
/*     */ 
/*     */           
/* 364 */           if (x > 0)
/* 365 */             maxValue = Math.max(maxValue, this.result.getValue(x - 1, y, z) * sign); 
/* 366 */           if (y > 0)
/* 367 */             maxValue = Math.max(maxValue, this.result.getValue(x, y - 1, z) * sign); 
/* 368 */           if (z > 0) {
/* 369 */             maxValue = Math.max(maxValue, this.result.getValue(x, y, z - 1) * sign);
/*     */           }
/*     */ 
/*     */           
/* 373 */           maxValue = Math.min(maxValue, this.mask.getValue(x, y, z) * sign);
/* 374 */           if (maxValue > currentValue) {
/* 375 */             this.result.setValue(x, y, z, maxValue * sign);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 382 */     showProgress(1.0D, 1.0D, "");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void forwardScanC26() {
/* 391 */     int sign = this.reconstructionType.getSign();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 396 */     for (int z = 0; z < this.sizeZ; z++) {
/*     */       
/* 398 */       showProgress(z, this.sizeZ, "z = " + z);
/*     */       
/* 400 */       for (int y = 0; y < this.sizeY; y++) {
/*     */         
/* 402 */         for (int x = 0; x < this.sizeX; x++) {
/*     */           
/* 404 */           double currentValue = this.result.getValue(x, y, z) * sign;
/* 405 */           double maxValue = currentValue;
/*     */ 
/*     */           
/* 408 */           int zmax = Math.min(z + 1, this.sizeZ);
/* 409 */           for (int z2 = Math.max(z - 1, 0); z2 < zmax; z2++) {
/*     */             
/* 411 */             int ymax = (z2 == z) ? y : Math.min(y + 1, this.sizeY - 1);
/* 412 */             for (int y2 = Math.max(y - 1, 0); y2 <= ymax; y2++) {
/*     */               
/* 414 */               int xmax = (z2 == z && y2 == y) ? (x - 1) : Math.min(x + 1, this.sizeX - 1);
/* 415 */               for (int x2 = Math.max(x - 1, 0); x2 <= xmax; x2++)
/*     */               {
/* 417 */                 maxValue = Math.max(maxValue, this.result.getValue(x2, y2, z2) * sign);
/*     */               }
/*     */             } 
/*     */           } 
/*     */ 
/*     */           
/* 423 */           maxValue = Math.min(maxValue, this.mask.getValue(x, y, z) * sign);
/* 424 */           if (maxValue > currentValue)
/*     */           {
/* 426 */             this.result.setValue(x, y, z, maxValue * sign);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 433 */     showProgress(1.0D, 1.0D, "");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void backwardScan() {
/* 439 */     if (this.connectivity == 6) {
/*     */       
/* 441 */       backwardScanC6();
/*     */     }
/*     */     else {
/*     */       
/* 445 */       backwardScanC26();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void backwardScanC6() {
/* 454 */     int sign = this.reconstructionType.getSign();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 459 */     for (int z = this.sizeZ - 1; z >= 0; z--) {
/*     */       
/* 461 */       showProgress((this.sizeZ - 1 - z), this.sizeZ, "z = " + z);
/*     */       
/* 463 */       for (int y = this.sizeY - 1; y >= 0; y--) {
/*     */         
/* 465 */         for (int x = this.sizeX - 1; x >= 0; x--) {
/*     */           
/* 467 */           double currentValue = this.result.getValue(x, y, z) * sign;
/* 468 */           double maxValue = currentValue;
/*     */ 
/*     */           
/* 471 */           if (x < this.sizeX - 1)
/* 472 */             maxValue = Math.max(maxValue, this.result.getValue(x + 1, y, z) * sign); 
/* 473 */           if (y < this.sizeY - 1)
/* 474 */             maxValue = Math.max(maxValue, this.result.getValue(x, y + 1, z) * sign); 
/* 475 */           if (z < this.sizeZ - 1) {
/* 476 */             maxValue = Math.max(maxValue, this.result.getValue(x, y, z + 1) * sign);
/*     */           }
/*     */ 
/*     */           
/* 480 */           maxValue = Math.min(maxValue, this.mask.getValue(x, y, z) * sign);
/* 481 */           if (maxValue > currentValue)
/*     */           {
/* 483 */             this.result.setValue(x, y, z, maxValue * sign);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 490 */     showProgress(1.0D, 1.0D, "");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void backwardScanC26() {
/* 499 */     int sign = this.reconstructionType.getSign();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 504 */     for (int z = this.sizeZ - 1; z >= 0; z--) {
/*     */       
/* 506 */       showProgress((this.sizeZ - 1 - z), this.sizeZ, "z = " + z);
/*     */       
/* 508 */       for (int y = this.sizeY - 1; y >= 0; y--) {
/*     */         
/* 510 */         for (int x = this.sizeX - 1; x >= 0; x--) {
/*     */           
/* 512 */           double currentValue = this.result.getValue(x, y, z) * sign;
/* 513 */           double maxValue = currentValue;
/*     */ 
/*     */           
/* 516 */           int zmin = Math.max(z - 1, 0);
/* 517 */           for (int z2 = Math.min(z + 1, this.sizeZ - 1); z2 >= zmin; z2--) {
/*     */ 
/*     */             
/* 520 */             int ymin = (z2 == z) ? y : Math.max(y - 1, 0);
/* 521 */             for (int y2 = Math.min(y + 1, this.sizeY - 1); y2 >= ymin; y2--) {
/*     */               
/* 523 */               int xmin = (z2 == z && y2 == y) ? x : Math.max(x - 1, 0);
/* 524 */               for (int x2 = Math.min(x + 1, this.sizeX - 1); x2 >= xmin; x2--)
/*     */               {
/* 526 */                 maxValue = Math.max(maxValue, this.result.getValue(x2, y2, z2) * sign);
/*     */               }
/*     */             } 
/*     */           } 
/*     */ 
/*     */           
/* 532 */           maxValue = Math.min(maxValue, this.mask.getValue(x, y, z) * sign);
/* 533 */           if (maxValue > currentValue)
/*     */           {
/* 535 */             this.result.setValue(x, y, z, maxValue * sign);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 542 */     showProgress(1.0D, 1.0D, "");
/*     */   }
/*     */ 
/*     */   
/*     */   private void initQueue() {
/* 547 */     if (this.connectivity == 6) {
/*     */       
/* 549 */       initQueueC6();
/*     */     }
/*     */     else {
/*     */       
/* 553 */       initQueueC26();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void initQueueC6() {
/* 564 */     int sign = this.reconstructionType.getSign();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 569 */     this.queue = new ArrayDeque<Cursor3D>();
/*     */ 
/*     */     
/* 572 */     for (int z = 0; z < this.sizeZ; z++) {
/*     */       
/* 574 */       showProgress((z + 1), this.sizeZ);
/*     */       
/* 576 */       for (int y = 0; y < this.sizeY; y++) {
/*     */         
/* 578 */         for (int x = 0; x < this.sizeX; x++) {
/*     */           
/* 580 */           double currentValue = this.result.getValue(x, y, z) * sign;
/* 581 */           double maxValue = currentValue;
/*     */ 
/*     */           
/* 584 */           if (x > 0)
/* 585 */             maxValue = Math.max(maxValue, this.result.getValue(x - 1, y, z) * sign); 
/* 586 */           if (y > 0)
/* 587 */             maxValue = Math.max(maxValue, this.result.getValue(x, y - 1, z) * sign); 
/* 588 */           if (z > 0) {
/* 589 */             maxValue = Math.max(maxValue, this.result.getValue(x, y, z - 1) * sign);
/*     */           }
/* 591 */           if (maxValue > currentValue) {
/* 592 */             updateQueue(x, y, z, maxValue, sign);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void initQueueC26() {
/* 606 */     int sign = this.reconstructionType.getSign();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 611 */     this.queue = new ArrayDeque<Cursor3D>();
/*     */ 
/*     */     
/* 614 */     for (int z = 0; z < this.sizeZ; z++) {
/*     */       
/* 616 */       showProgress((z + 1), this.sizeZ);
/*     */       
/* 618 */       for (int y = 0; y < this.sizeY; y++) {
/*     */         
/* 620 */         for (int x = 0; x < this.sizeX; x++) {
/*     */           
/* 622 */           double currentValue = this.result.getValue(x, y, z) * sign;
/* 623 */           double maxValue = currentValue;
/*     */ 
/*     */           
/* 626 */           int zmax = Math.min(z + 1, this.sizeZ);
/* 627 */           for (int z2 = Math.max(z - 1, 0); z2 < zmax; z2++) {
/*     */             
/* 629 */             int ymax = (z2 == z) ? y : Math.min(y + 1, this.sizeY - 1);
/* 630 */             for (int y2 = Math.max(y - 1, 0); y2 <= ymax; y2++) {
/*     */               
/* 632 */               int xmax = (z2 == z && y2 == y) ? (x - 1) : Math.min(x + 1, this.sizeX - 1);
/* 633 */               for (int x2 = Math.max(x - 1, 0); x2 <= xmax; x2++)
/*     */               {
/* 635 */                 maxValue = Math.max(maxValue, this.result.getValue(x2, y2, z2) * sign);
/*     */               }
/*     */             } 
/*     */           } 
/*     */           
/* 640 */           if (maxValue > currentValue) {
/* 641 */             updateQueue(x, y, z, maxValue, sign);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void processQueue() {
/* 650 */     if (this.connectivity == 6) {
/*     */       
/* 652 */       processQueueC6();
/*     */     }
/*     */     else {
/*     */       
/* 656 */       processQueueC26();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void processQueueC6() {
/* 667 */     int sign = this.reconstructionType.getSign();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 672 */     while (!this.queue.isEmpty()) {
/*     */       
/* 674 */       Cursor3D p = this.queue.removeFirst();
/* 675 */       int x = p.getX();
/* 676 */       int y = p.getY();
/* 677 */       int z = p.getZ();
/* 678 */       double value = this.result.getValue(x, y, z) * sign;
/*     */ 
/*     */       
/* 681 */       if (x > 0)
/* 682 */         value = Math.max(value, this.result.getValue(x - 1, y, z) * sign); 
/* 683 */       if (x < this.sizeX - 1)
/* 684 */         value = Math.max(value, this.result.getValue(x + 1, y, z) * sign); 
/* 685 */       if (y > 0)
/* 686 */         value = Math.max(value, this.result.getValue(x, y - 1, z) * sign); 
/* 687 */       if (y < this.sizeY - 1)
/* 688 */         value = Math.max(value, this.result.getValue(x, y + 1, z) * sign); 
/* 689 */       if (z > 0)
/* 690 */         value = Math.max(value, this.result.getValue(x, y, z - 1) * sign); 
/* 691 */       if (z < this.sizeZ - 1) {
/* 692 */         value = Math.max(value, this.result.getValue(x, y, z + 1) * sign);
/*     */       }
/*     */       
/* 695 */       value = Math.min(value, this.mask.getValue(x, y, z) * sign);
/*     */ 
/*     */       
/* 698 */       if (value <= this.result.getValue(x, y, z) * sign) {
/*     */         continue;
/*     */       }
/*     */       
/* 702 */       this.result.setValue(x, y, z, value * sign);
/*     */ 
/*     */       
/* 705 */       if (x > 0)
/* 706 */         updateQueue(x - 1, y, z, value, sign); 
/* 707 */       if (x < this.sizeX - 1)
/* 708 */         updateQueue(x + 1, y, z, value, sign); 
/* 709 */       if (y > 0)
/* 710 */         updateQueue(x, y - 1, z, value, sign); 
/* 711 */       if (y < this.sizeY - 1)
/* 712 */         updateQueue(x, y + 1, z, value, sign); 
/* 713 */       if (z > 0)
/* 714 */         updateQueue(x, y, z - 1, value, sign); 
/* 715 */       if (z < this.sizeZ - 1) {
/* 716 */         updateQueue(x, y, z + 1, value, sign);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void processQueueC26() {
/* 728 */     int sign = this.reconstructionType.getSign();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 733 */     while (!this.queue.isEmpty()) {
/*     */       
/* 735 */       Cursor3D p = this.queue.removeFirst();
/* 736 */       int x = p.getX();
/* 737 */       int y = p.getY();
/* 738 */       int z = p.getZ();
/* 739 */       double value = this.result.getValue(x, y, z) * sign;
/*     */ 
/*     */       
/* 742 */       int xmin = Math.max(x - 1, 0);
/* 743 */       int xmax = Math.min(x + 1, this.sizeX - 1);
/* 744 */       int ymin = Math.max(y - 1, 0);
/* 745 */       int ymax = Math.min(y + 1, this.sizeY - 1);
/* 746 */       int zmin = Math.max(z - 1, 0);
/* 747 */       int zmax = Math.min(z + 1, this.sizeZ - 1);
/*     */       
/*     */       int z2;
/* 750 */       for (z2 = zmin; z2 <= zmax; z2++) {
/*     */         
/* 752 */         for (int y2 = ymin; y2 <= ymax; y2++) {
/*     */           
/* 754 */           for (int x2 = xmin; x2 <= xmax; x2++)
/*     */           {
/* 756 */             value = Math.max(value, this.result.getValue(x2, y2, z2) * sign);
/*     */           }
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 762 */       value = Math.min(value, this.mask.getValue(x, y, z) * sign);
/*     */ 
/*     */       
/* 765 */       if (value <= this.result.getValue(x, y, z) * sign) {
/*     */         continue;
/*     */       }
/*     */       
/* 769 */       this.result.setValue(x, y, z, value * sign);
/*     */ 
/*     */       
/* 772 */       for (z2 = zmin; z2 <= zmax; z2++) {
/*     */         
/* 774 */         for (int y2 = ymin; y2 <= ymax; y2++) {
/*     */           
/* 776 */           for (int x2 = xmin; x2 <= xmax; x2++)
/*     */           {
/* 778 */             updateQueue(x2, y2, z2, value, sign);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void updateQueue(int i, int j, int k, double value, double sign) {
/* 796 */     value = Math.min(value, this.mask.getValue(i, j, k) * sign);
/* 797 */     if (value > this.result.getValue(i, j, k) * sign) {
/*     */       
/* 799 */       Cursor3D position = new Cursor3D(i, j, k);
/* 800 */       this.queue.add(position);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/morphology/geodrec/GeodesicReconstruction3DHybrid1Image3D.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */