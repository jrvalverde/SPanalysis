/*     */ package inra.ijpb.morphology;
/*     */ 
/*     */ import ij.ImageStack;
/*     */ import inra.ijpb.algo.Algo;
/*     */ import inra.ijpb.algo.DefaultAlgoListener;
/*     */ import inra.ijpb.data.image.ColorImages;
/*     */ import inra.ijpb.morphology.geodrec.GeodesicReconstruction3DAlgo;
/*     */ import inra.ijpb.morphology.geodrec.GeodesicReconstruction3DHybrid0Float;
/*     */ import inra.ijpb.morphology.geodrec.GeodesicReconstruction3DHybrid0Gray16;
/*     */ import inra.ijpb.morphology.geodrec.GeodesicReconstruction3DHybrid0Gray8;
/*     */ import inra.ijpb.morphology.geodrec.GeodesicReconstructionByDilation3DScanning;
/*     */ import inra.ijpb.morphology.geodrec.GeodesicReconstructionByDilation3DScanningGray8;
/*     */ import inra.ijpb.morphology.geodrec.GeodesicReconstructionByErosion3DScanning;
/*     */ import inra.ijpb.morphology.geodrec.GeodesicReconstructionType;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Reconstruction3D
/*     */ {
/*     */   public static final ImageStack killBorders(ImageStack image) {
/*  88 */     int width = image.getWidth();
/*  89 */     int height = image.getHeight();
/*  90 */     int depth = image.getSize();
/*     */ 
/*     */     
/*  93 */     ImageStack markers = image.duplicate();
/*  94 */     for (int z = 1; z < depth - 1; z++) {
/*     */       
/*  96 */       for (int y = 1; y < height - 1; y++) {
/*     */         
/*  98 */         for (int x = 1; x < width - 1; x++)
/*     */         {
/* 100 */           markers.setVoxel(x, y, z, 0.0D);
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 105 */     ImageStack result = reconstructByDilation(markers, image);
/*     */ 
/*     */     
/* 108 */     for (int i = 0; i < depth; i++) {
/*     */       
/* 110 */       for (int y = 0; y < height; y++) {
/*     */         
/* 112 */         for (int x = 0; x < width; x++) {
/*     */           
/* 114 */           double val = image.getVoxel(x, y, i) - result.getVoxel(x, y, i);
/* 115 */           result.setVoxel(x, y, i, Math.max(val, 0.0D));
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 120 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final ImageStack fillHoles(ImageStack image) {
/* 137 */     int width = image.getWidth();
/* 138 */     int height = image.getHeight();
/* 139 */     int depth = image.getSize();
/*     */ 
/*     */     
/* 142 */     ImageStack markers = image.duplicate();
/* 143 */     for (int z = 1; z < depth - 1; z++) {
/*     */       
/* 145 */       for (int y = 1; y < height - 1; y++) {
/*     */         
/* 147 */         for (int x = 1; x < width - 1; x++)
/*     */         {
/* 149 */           markers.setVoxel(x, y, z, 3.4028234663852886E38D);
/*     */         }
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 155 */     return reconstructByErosion(markers, image);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final ImageStack reconstructByDilation(ImageStack marker, ImageStack mask) {
/*     */     GeodesicReconstructionByDilation3DScanning geodesicReconstructionByDilation3DScanning;
/* 172 */     if (marker.getBitDepth() == 8 && mask.getBitDepth() == 8) {
/*     */       
/* 174 */       GeodesicReconstruction3DHybrid0Gray8 geodesicReconstruction3DHybrid0Gray8 = new GeodesicReconstruction3DHybrid0Gray8(
/* 175 */           GeodesicReconstructionType.BY_DILATION);
/*     */     }
/* 177 */     else if (marker.getBitDepth() == 16 && mask.getBitDepth() == 16) {
/*     */       
/* 179 */       GeodesicReconstruction3DHybrid0Gray16 geodesicReconstruction3DHybrid0Gray16 = new GeodesicReconstruction3DHybrid0Gray16(
/* 180 */           GeodesicReconstructionType.BY_DILATION);
/*     */     }
/* 182 */     else if (marker.getBitDepth() == 32 && mask.getBitDepth() == 32) {
/*     */       
/* 184 */       GeodesicReconstruction3DHybrid0Float geodesicReconstruction3DHybrid0Float = new GeodesicReconstruction3DHybrid0Float(
/* 185 */           GeodesicReconstructionType.BY_DILATION);
/*     */     }
/*     */     else {
/*     */       
/* 189 */       geodesicReconstructionByDilation3DScanning = new GeodesicReconstructionByDilation3DScanning();
/*     */     } 
/*     */     
/* 192 */     DefaultAlgoListener.monitor((Algo)geodesicReconstructionByDilation3DScanning);
/*     */     
/* 194 */     if (marker.getBitDepth() == 24 && mask.getBitDepth() == 24)
/*     */     {
/* 196 */       return applyAlgoToRGB((GeodesicReconstruction3DAlgo)geodesicReconstructionByDilation3DScanning, marker, mask);
/*     */     }
/*     */     
/* 199 */     return geodesicReconstructionByDilation3DScanning.applyTo(marker, mask);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final ImageStack reconstructByDilation(ImageStack marker, ImageStack mask, int connectivity) {
/*     */     GeodesicReconstructionByDilation3DScanning geodesicReconstructionByDilation3DScanning;
/* 218 */     if (marker.getBitDepth() == 8 && mask.getBitDepth() == 8) {
/*     */       
/* 220 */       GeodesicReconstruction3DHybrid0Gray8 geodesicReconstruction3DHybrid0Gray8 = new GeodesicReconstruction3DHybrid0Gray8(
/* 221 */           GeodesicReconstructionType.BY_DILATION, connectivity);
/*     */     }
/* 223 */     else if (marker.getBitDepth() == 16 && mask.getBitDepth() == 16) {
/*     */       
/* 225 */       GeodesicReconstruction3DHybrid0Gray16 geodesicReconstruction3DHybrid0Gray16 = new GeodesicReconstruction3DHybrid0Gray16(
/* 226 */           GeodesicReconstructionType.BY_DILATION, connectivity);
/*     */     }
/* 228 */     else if (marker.getBitDepth() == 32 && mask.getBitDepth() == 32) {
/*     */       
/* 230 */       GeodesicReconstruction3DHybrid0Float geodesicReconstruction3DHybrid0Float = new GeodesicReconstruction3DHybrid0Float(
/* 231 */           GeodesicReconstructionType.BY_DILATION, connectivity);
/*     */     }
/*     */     else {
/*     */       
/* 235 */       geodesicReconstructionByDilation3DScanning = new GeodesicReconstructionByDilation3DScanning(connectivity);
/*     */     } 
/*     */     
/* 238 */     DefaultAlgoListener.monitor((Algo)geodesicReconstructionByDilation3DScanning);
/*     */     
/* 240 */     if (marker.getBitDepth() == 24 && mask.getBitDepth() == 24)
/*     */     {
/* 242 */       return applyAlgoToRGB((GeodesicReconstruction3DAlgo)geodesicReconstructionByDilation3DScanning, marker, mask);
/*     */     }
/*     */     
/* 245 */     return geodesicReconstructionByDilation3DScanning.applyTo(marker, mask);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final ImageStack reconstructByDilation(ImageStack marker, ImageStack mask, int connectivity, ImageStack binaryMask) {
/* 269 */     GeodesicReconstructionByDilation3DScanningGray8 geodesicReconstructionByDilation3DScanningGray8 = new GeodesicReconstructionByDilation3DScanningGray8(
/* 270 */         connectivity);
/* 271 */     DefaultAlgoListener.monitor((Algo)geodesicReconstructionByDilation3DScanningGray8);
/*     */     
/* 273 */     if (marker.getBitDepth() == 24 && mask.getBitDepth() == 24)
/*     */     {
/* 275 */       return applyAlgoToRGB((GeodesicReconstruction3DAlgo)geodesicReconstructionByDilation3DScanningGray8, marker, mask);
/*     */     }
/*     */     
/* 278 */     return geodesicReconstructionByDilation3DScanningGray8.applyTo(marker, mask, binaryMask);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final ImageStack reconstructByErosion(ImageStack marker, ImageStack mask) {
/*     */     GeodesicReconstructionByErosion3DScanning geodesicReconstructionByErosion3DScanning;
/* 296 */     if (marker.getBitDepth() == 8 && mask.getBitDepth() == 8) {
/*     */       
/* 298 */       GeodesicReconstruction3DHybrid0Gray8 geodesicReconstruction3DHybrid0Gray8 = new GeodesicReconstruction3DHybrid0Gray8(
/* 299 */           GeodesicReconstructionType.BY_EROSION);
/*     */     
/*     */     }
/* 302 */     else if (marker.getBitDepth() == 16 && mask.getBitDepth() == 16) {
/*     */       
/* 304 */       GeodesicReconstruction3DHybrid0Gray16 geodesicReconstruction3DHybrid0Gray16 = new GeodesicReconstruction3DHybrid0Gray16(
/* 305 */           GeodesicReconstructionType.BY_EROSION);
/*     */     
/*     */     }
/* 308 */     else if (marker.getBitDepth() == 32 && mask.getBitDepth() == 32) {
/*     */       
/* 310 */       GeodesicReconstruction3DHybrid0Float geodesicReconstruction3DHybrid0Float = new GeodesicReconstruction3DHybrid0Float(
/* 311 */           GeodesicReconstructionType.BY_EROSION);
/*     */     }
/*     */     else {
/*     */       
/* 315 */       geodesicReconstructionByErosion3DScanning = new GeodesicReconstructionByErosion3DScanning();
/*     */     } 
/*     */     
/* 318 */     DefaultAlgoListener.monitor((Algo)geodesicReconstructionByErosion3DScanning);
/*     */     
/* 320 */     if (marker.getBitDepth() == 24 && mask.getBitDepth() == 24)
/*     */     {
/* 322 */       return applyAlgoToRGB((GeodesicReconstruction3DAlgo)geodesicReconstructionByErosion3DScanning, marker, mask);
/*     */     }
/*     */     
/* 325 */     return geodesicReconstructionByErosion3DScanning.applyTo(marker, mask);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final ImageStack reconstructByErosion(ImageStack marker, ImageStack mask, int connectivity) {
/*     */     GeodesicReconstructionByErosion3DScanning geodesicReconstructionByErosion3DScanning;
/* 344 */     if (Thread.currentThread().isInterrupted()) {
/* 345 */       return null;
/*     */     }
/*     */     
/* 348 */     if (marker.getBitDepth() == 8 && mask.getBitDepth() == 8) {
/*     */       
/* 350 */       GeodesicReconstruction3DHybrid0Gray8 geodesicReconstruction3DHybrid0Gray8 = new GeodesicReconstruction3DHybrid0Gray8(
/* 351 */           GeodesicReconstructionType.BY_EROSION, connectivity);
/*     */     }
/* 353 */     else if (marker.getBitDepth() == 16 && mask.getBitDepth() == 16) {
/*     */       
/* 355 */       GeodesicReconstruction3DHybrid0Gray16 geodesicReconstruction3DHybrid0Gray16 = new GeodesicReconstruction3DHybrid0Gray16(
/* 356 */           GeodesicReconstructionType.BY_EROSION, connectivity);
/*     */     }
/* 358 */     else if (marker.getBitDepth() == 32 && mask.getBitDepth() == 32) {
/*     */       
/* 360 */       GeodesicReconstruction3DHybrid0Float geodesicReconstruction3DHybrid0Float = new GeodesicReconstruction3DHybrid0Float(
/* 361 */           GeodesicReconstructionType.BY_EROSION, connectivity);
/*     */     }
/*     */     else {
/*     */       
/* 365 */       geodesicReconstructionByErosion3DScanning = new GeodesicReconstructionByErosion3DScanning(connectivity);
/*     */     } 
/*     */     
/* 368 */     DefaultAlgoListener.monitor((Algo)geodesicReconstructionByErosion3DScanning);
/*     */     
/* 370 */     if (marker.getBitDepth() == 24 && mask.getBitDepth() == 24)
/*     */     {
/* 372 */       return applyAlgoToRGB((GeodesicReconstruction3DAlgo)geodesicReconstructionByErosion3DScanning, marker, mask);
/*     */     }
/*     */     
/* 375 */     return geodesicReconstructionByErosion3DScanning.applyTo(marker, mask);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final ImageStack applyAlgoToRGB(GeodesicReconstruction3DAlgo algo, ImageStack marker, ImageStack mask) {
/* 396 */     Map<String, ImageStack> markerChannels = ColorImages.mapChannels(marker);
/* 397 */     Map<String, ImageStack> maskChannels = ColorImages.mapChannels(mask);
/*     */     
/* 399 */     ImageStack resRed = algo.applyTo(markerChannels.get("red"), maskChannels.get("red"));
/* 400 */     ImageStack resGreen = algo.applyTo(markerChannels.get("green"), maskChannels.get("green"));
/* 401 */     ImageStack resBlue = algo.applyTo(markerChannels.get("blue"), maskChannels.get("blue"));
/*     */     
/* 403 */     return ColorImages.mergeChannels(resRed, resGreen, resBlue);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/morphology/Reconstruction3D.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */