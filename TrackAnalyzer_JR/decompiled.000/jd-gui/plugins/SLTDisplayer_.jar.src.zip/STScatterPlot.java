/*     */ import java.awt.BasicStroke;
/*     */ import java.awt.Color;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Font;
/*     */ import java.awt.Paint;
/*     */ import java.awt.Shape;
/*     */ import java.awt.geom.Ellipse2D;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import javax.swing.JLabel;
/*     */ import org.jfree.chart.ChartFactory;
/*     */ import org.jfree.chart.ChartPanel;
/*     */ import org.jfree.chart.JFreeChart;
/*     */ import org.jfree.chart.annotations.XYAnnotation;
/*     */ import org.jfree.chart.annotations.XYTitleAnnotation;
/*     */ import org.jfree.chart.axis.NumberAxis;
/*     */ import org.jfree.chart.block.BlockBorder;
/*     */ import org.jfree.chart.block.BlockFrame;
/*     */ import org.jfree.chart.plot.DefaultDrawingSupplier;
/*     */ import org.jfree.chart.plot.DrawingSupplier;
/*     */ import org.jfree.chart.plot.IntervalMarker;
/*     */ import org.jfree.chart.plot.Marker;
/*     */ import org.jfree.chart.plot.PlotOrientation;
/*     */ import org.jfree.chart.plot.XYPlot;
/*     */ import org.jfree.chart.renderer.xy.XYItemRenderer;
/*     */ import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
/*     */ import org.jfree.chart.title.TextTitle;
/*     */ import org.jfree.chart.title.Title;
/*     */ import org.jfree.chart.ui.HorizontalAlignment;
/*     */ import org.jfree.chart.ui.RectangleAnchor;
/*     */ import org.jfree.chart.ui.RectangleEdge;
/*     */ import org.jfree.data.function.Function2D;
/*     */ import org.jfree.data.function.LineFunction2D;
/*     */ import org.jfree.data.function.PowerFunction2D;
/*     */ import org.jfree.data.general.DatasetUtils;
/*     */ import org.jfree.data.statistics.Regression;
/*     */ import org.jfree.data.xy.XYDataset;
/*     */ import org.jfree.data.xy.XYSeries;
/*     */ import org.jfree.data.xy.XYSeriesCollection;
/*     */ import org.jfree.ui.ApplicationFrame;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class STScatterPlot
/*     */   extends ApplicationFrame
/*     */ {
/*     */   private XYDataset data1;
/*     */   List<Double> valuesDomain;
/*     */   List<Double> valuesRange;
/*     */   IntervalMarker markerRange;
/*     */   IntervalMarker markerDomain;
/*     */   String domainValue;
/*     */   String rangeValue;
/*     */   String domainName;
/*     */   String rangeName;
/*     */   Object[][] data;
/*     */   Color[] classColor;
/*     */   String label1;
/*     */   String label2;
/*     */   XYSeriesCollection dataset;
/*     */   XYPlot plot;
/*     */   ChartPanel panel;
/*     */   XYSeries series1;
/*     */   XYLineAndShapeRenderer renderer;
/*     */   double maxDomain;
/*     */   int filterOrder;
/*     */   
/*     */   public STScatterPlot(String title) {
/*  71 */     super(title);
/*     */   }
/*     */ 
/*     */   
/*     */   public ChartPanel createChartPanelPolynomial() {
/*  76 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ChartPanel createScatterChartPanelInitial(String label1, String label2, List<Double> valuesDomain, List<Double> valuesRange, IntervalMarker markerRange, IntervalMarker markerDomain, Object[][] dataCh2, Double[][] dataCh3) {
/*  88 */     this.label1 = label1;
/*  89 */     this.label2 = label2;
/*  90 */     this.valuesDomain = valuesDomain;
/*  91 */     this.valuesRange = valuesRange;
/*  92 */     this.markerRange = markerRange;
/*  93 */     this.markerDomain = markerDomain;
/*     */     
/*  95 */     this.dataset = new XYSeriesCollection();
/*  96 */     XYSeries series1 = new XYSeries("");
/*  97 */     for (int i = 0; i < valuesDomain.size(); i++)
/*  98 */       series1.add(valuesDomain.get(i), valuesRange.get(i)); 
/*  99 */     this.dataset.addSeries(series1);
/*     */ 
/*     */     
/* 102 */     JFreeChart chart = ChartFactory.createScatterPlot("", "", "", (XYDataset)this.dataset);
/*     */ 
/*     */     
/* 105 */     this.plot = (XYPlot)chart.getPlot();
/* 106 */     Paint[] paintArray = { new Color(-2130771968, true), new Color(-2147418368, true), new Color(-2147483393, true) };
/* 107 */     this.plot.setDrawingSupplier((DrawingSupplier)new DefaultDrawingSupplier(paintArray, 
/* 108 */           DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE, 
/* 109 */           DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE, DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE, 
/* 110 */           DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE, DefaultDrawingSupplier.DEFAULT_SHAPE_SEQUENCE));
/* 111 */     this.panel = new ChartPanel(chart, false);
/* 112 */     this.panel.setMaximumDrawWidth(4000);
/* 113 */     this.panel.setPreferredSize(new Dimension(450, 300));
/* 114 */     chart.setBackgroundPaint(new Color(255, 255, 255, 0));
/* 115 */     this.plot.setBackgroundPaint(new Color(255, 255, 255, 0));
/* 116 */     chart.getLegend().setBackgroundPaint(new Color(255, 255, 255, 0));
/* 117 */     chart.getLegend().setVisible(false);
/* 118 */     this.panel.setMouseWheelEnabled(true);
/* 119 */     this.plot.addRangeMarker((Marker)markerRange);
/* 120 */     this.plot.addDomainMarker((Marker)markerDomain);
/*     */     
/* 122 */     Font font3 = new Font("Dialog", 2, 9);
/* 123 */     this.plot.getDomainAxis().setLabelFont(font3);
/* 124 */     this.plot.getRangeAxis().setLabelFont(font3);
/* 125 */     this.plot.getRangeAxis().setTickLabelFont(font3);
/* 126 */     this.plot.getDomainAxis().setTickLabelFont(font3);
/* 127 */     return this.panel;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addScatterPlotSeriesLinear(String domainName, String rangeName, List<Double> valuesDomain, List<Double> valuesRange, IntervalMarker markerRange, IntervalMarker markerDomain, String domainValue, String rangeValue, Object[][] data, final Color[] classColor) {
/* 134 */     this.valuesDomain = valuesDomain;
/* 135 */     this.rangeName = rangeName;
/* 136 */     this.domainName = domainName;
/* 137 */     this.valuesRange = valuesRange;
/* 138 */     this.markerRange = markerRange;
/* 139 */     this.markerDomain = markerDomain;
/* 140 */     this.domainValue = domainValue;
/* 141 */     this.rangeValue = rangeValue;
/* 142 */     this.classColor = classColor;
/*     */     
/* 144 */     this.panel.removeAll();
/* 145 */     this.dataset = new XYSeriesCollection();
/* 146 */     this.series1 = new XYSeries("");
/* 147 */     for (int i = 0; i < valuesDomain.size(); i++)
/* 148 */       this.series1.add(valuesDomain.get(i), valuesRange.get(i)); 
/* 149 */     this.dataset.addSeries(this.series1);
/* 150 */     double minDomain = ((Double)Collections.<Double>min(valuesDomain)).doubleValue();
/* 151 */     double maxDomain = ((Double)Collections.<Double>max(valuesDomain)).doubleValue();
/* 152 */     double[] coefficients = Regression.getOLSRegression((XYDataset)this.dataset, 0);
/* 153 */     LineFunction2D lineFunction2D = new LineFunction2D(coefficients[0], coefficients[1]);
/* 154 */     XYDataset regressionData = DatasetUtils.sampleFunction2D((Function2D)lineFunction2D, minDomain, maxDomain, valuesDomain.size(), 
/* 155 */         "Fitted Regression Line");
/*     */     
/* 157 */     JFreeChart chart = ChartFactory.createScatterPlot("", domainName, rangeName, (XYDataset)this.dataset, PlotOrientation.VERTICAL, 
/* 158 */         true, true, false);
/*     */     
/* 160 */     this.plot = (XYPlot)chart.getPlot();
/* 161 */     XYLineAndShapeRenderer renderer1 = new XYLineAndShapeRenderer(false, true);
/* 162 */     this.plot.setRenderer((XYItemRenderer)renderer1);
/* 163 */     this.plot.setBackgroundPaint(new Color(255, 228, 196));
/* 164 */     Paint[] paintArray = { new Color(-2130771968, true), new Color(-2147418368, true), new Color(-2147483393, true) };
/* 165 */     this.plot.setDrawingSupplier((DrawingSupplier)new DefaultDrawingSupplier(paintArray, 
/* 166 */           DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE, 
/* 167 */           DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE, DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE, 
/* 168 */           DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE, DefaultDrawingSupplier.DEFAULT_SHAPE_SEQUENCE));
/* 169 */     this.plot.setDataset(1, regressionData);
/* 170 */     XYLineAndShapeRenderer renderer2 = new XYLineAndShapeRenderer(true, false);
/* 171 */     renderer2.setSeriesPaint(0, Color.RED);
/* 172 */     this.plot.setRenderer(1, (XYItemRenderer)renderer2);
/* 173 */     Shape cross = new Ellipse2D.Double(0.0D, 0.0D, 5.0D, 5.0D);
/* 174 */     List<String[]> featureLists = (List)new ArrayList<>();
/* 175 */     for (int j = 0; j < ColorEditorSpot.tableC.getModel().getRowCount(); j++) {
/* 176 */       featureLists.add(((JLabel)ColorEditorSpot.tableC.getModel().getValueAt(j, 
/* 177 */             ColorEditorSpot.tableC.convertColumnIndexToModel(2))).getText().replace("<html>", "")
/* 178 */           .split("<br>"));
/*     */     }
/* 180 */     this.renderer = new XYLineAndShapeRenderer()
/*     */       {
/*     */         public Paint getItemPaint(int row, int col) {
/* 183 */           Paint cpaint = getItemColor(row, col);
/* 184 */           if (cpaint == null) {
/* 185 */             cpaint = super.getItemPaint(row, col);
/*     */           }
/* 187 */           return cpaint;
/*     */         }
/*     */         
/*     */         public Color getItemColor(int row, int col) {
/* 191 */           double x = STScatterPlot.this.dataset.getXValue(row, col);
/* 192 */           double y = STScatterPlot.this.dataset.getYValue(row, col);
/*     */           
/*     */           try {
/* 195 */             return classColor[col];
/* 196 */           } catch (Exception exception) {
/*     */ 
/*     */ 
/*     */             
/* 200 */             return null;
/*     */           } 
/*     */         }
/*     */       };
/*     */     
/* 205 */     this.plot.setRenderer((XYItemRenderer)this.renderer);
/* 206 */     this.renderer.setUseOutlinePaint(true);
/* 207 */     this.renderer.setSeriesShape(0, cross);
/* 208 */     this.renderer.setSeriesOutlinePaint(0, Color.black);
/* 209 */     this.renderer.setSeriesOutlineStroke(0, new BasicStroke(1.0F));
/* 210 */     this.renderer.setSeriesLinesVisible(0, false);
/* 211 */     this.renderer.setSeriesPaint(0, Color.LIGHT_GRAY);
/* 212 */     this.plot.getRangeCrosshairValue();
/* 213 */     this.plot.getDomainCrosshairValue();
/*     */ 
/*     */     
/* 216 */     this.panel.setChart(chart);
/* 217 */     this.panel.setMaximumDrawWidth(6000);
/* 218 */     this.panel.setPreferredSize(new Dimension(450, 300));
/* 219 */     this.panel.setMouseWheelEnabled(true);
/* 220 */     chart.setBackgroundPaint(new Color(255, 255, 255, 0));
/* 221 */     this.plot.setBackgroundPaint(new Color(255, 255, 255, 0));
/* 222 */     chart.getLegend().setBackgroundPaint(new Color(255, 255, 255, 0));
/* 223 */     this.panel.setMouseWheelEnabled(true);
/* 224 */     chart.getLegend().setVisible(true);
/* 225 */     this.plot.addRangeMarker((Marker)markerRange);
/* 226 */     this.plot.addDomainMarker((Marker)markerDomain);
/* 227 */     markerRange.setLabel("Low-High");
/* 228 */     markerRange.setLabelFont(new Font("SansSerif", 0, 15));
/* 229 */     markerRange.setLabelPaint(new Color(0, 102, 0));
/*     */     
/* 231 */     Font font3 = new Font("Dialog", 1, 12);
/* 232 */     this.plot.getDomainAxis().setLabelFont(font3);
/* 233 */     this.plot.getRangeAxis().setLabelFont(font3);
/* 234 */     this.plot.getRangeAxis().setTickLabelFont(font3);
/* 235 */     this.plot.getDomainAxis().setTickLabelFont(font3);
/*     */     
/* 237 */     NumberAxis domain = (NumberAxis)this.plot.getDomainAxis();
/*     */     
/* 239 */     NumberAxis range = (NumberAxis)this.plot.getRangeAxis();
/*     */     
/* 241 */     domain.setAutoRange(true);
/* 242 */     range.setAutoRange(true);
/* 243 */     computeLinearCoefficients(chart, this.plot, this.dataset);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addScatterPlotSeriesPower(String domainName, String rangeName, List<Double> valuesDomain, List<Double> valuesRange, IntervalMarker markerRange, IntervalMarker markerDomain, String domainValue, String rangeValue, Object[][] data, final Color[] classColor) {
/* 251 */     this.valuesDomain = valuesDomain;
/* 252 */     this.rangeName = rangeName;
/* 253 */     this.domainName = domainName;
/* 254 */     this.valuesRange = valuesRange;
/* 255 */     this.markerRange = markerRange;
/* 256 */     this.markerDomain = markerDomain;
/* 257 */     this.domainValue = domainValue;
/* 258 */     this.rangeValue = rangeValue;
/* 259 */     this.classColor = classColor;
/* 260 */     this.panel.removeAll();
/* 261 */     this.dataset = new XYSeriesCollection();
/* 262 */     this.series1 = new XYSeries("");
/* 263 */     for (int i = 0; i < valuesDomain.size(); i++)
/* 264 */       this.series1.add(valuesDomain.get(i), valuesRange.get(i)); 
/* 265 */     this.dataset.addSeries(this.series1);
/*     */     
/* 267 */     double minDomain = ((Double)Collections.<Double>min(valuesDomain)).doubleValue();
/* 268 */     double maxDomain = ((Double)Collections.<Double>max(valuesDomain)).doubleValue();
/* 269 */     double[] coefficients = Regression.getPowerRegression((XYDataset)this.dataset, 0);
/* 270 */     PowerFunction2D powerFunction2D = new PowerFunction2D(coefficients[0], coefficients[1]);
/* 271 */     XYDataset regressionData = DatasetUtils.sampleFunction2D((Function2D)powerFunction2D, minDomain, maxDomain, valuesDomain.size(), 
/* 272 */         "Fitted Regression Line");
/*     */ 
/*     */     
/* 275 */     JFreeChart chart = ChartFactory.createScatterPlot("", domainName, rangeName, (XYDataset)this.dataset, PlotOrientation.VERTICAL, 
/* 276 */         true, true, false);
/*     */     
/* 278 */     this.plot = (XYPlot)chart.getPlot();
/* 279 */     XYLineAndShapeRenderer renderer1 = new XYLineAndShapeRenderer(false, true);
/* 280 */     this.plot.setRenderer((XYItemRenderer)renderer1);
/* 281 */     this.plot.setBackgroundPaint(new Color(255, 228, 196));
/* 282 */     Paint[] paintArray = { new Color(-2130771968, true), new Color(-2147418368, true), new Color(-2147483393, true) };
/* 283 */     this.plot.setDrawingSupplier((DrawingSupplier)new DefaultDrawingSupplier(paintArray, 
/* 284 */           DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE, 
/* 285 */           DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE, DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE, 
/* 286 */           DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE, DefaultDrawingSupplier.DEFAULT_SHAPE_SEQUENCE));
/* 287 */     this.plot.setDataset(1, regressionData);
/* 288 */     XYLineAndShapeRenderer renderer2 = new XYLineAndShapeRenderer(true, false);
/* 289 */     renderer2.setSeriesPaint(0, Color.RED);
/* 290 */     this.plot.setRenderer(1, (XYItemRenderer)renderer2);
/* 291 */     Shape cross = new Ellipse2D.Double(0.0D, 0.0D, 5.0D, 5.0D);
/* 292 */     List<String[]> featureLists = (List)new ArrayList<>();
/* 293 */     for (int j = 0; j < ColorEditorSpot.tableC.getModel().getRowCount(); j++) {
/* 294 */       featureLists.add(((JLabel)ColorEditorSpot.tableC.getModel().getValueAt(j, 
/* 295 */             ColorEditorSpot.tableC.convertColumnIndexToModel(2))).getText().replace("<html>", "")
/* 296 */           .split("<br>"));
/*     */     }
/* 298 */     this.renderer = new XYLineAndShapeRenderer()
/*     */       {
/*     */         public Paint getItemPaint(int row, int col) {
/* 301 */           Paint cpaint = getItemColor(row, col);
/* 302 */           if (cpaint == null) {
/* 303 */             cpaint = super.getItemPaint(row, col);
/*     */           }
/* 305 */           return cpaint;
/*     */         }
/*     */         
/*     */         public Color getItemColor(int row, int col) {
/* 309 */           double x = STScatterPlot.this.dataset.getXValue(row, col);
/* 310 */           double y = STScatterPlot.this.dataset.getYValue(row, col);
/*     */           
/*     */           try {
/* 313 */             return classColor[col];
/* 314 */           } catch (Exception exception) {
/*     */ 
/*     */ 
/*     */             
/* 318 */             return null;
/*     */           } 
/*     */         }
/*     */       };
/*     */     
/* 323 */     this.plot.setRenderer((XYItemRenderer)this.renderer);
/* 324 */     this.renderer.setUseOutlinePaint(true);
/* 325 */     this.renderer.setSeriesShape(0, cross);
/* 326 */     this.renderer.setSeriesOutlinePaint(0, Color.black);
/* 327 */     this.renderer.setSeriesOutlineStroke(0, new BasicStroke(1.0F));
/* 328 */     this.renderer.setSeriesLinesVisible(0, false);
/* 329 */     this.renderer.setSeriesPaint(0, Color.LIGHT_GRAY);
/* 330 */     this.plot.getRangeCrosshairValue();
/* 331 */     this.plot.getDomainCrosshairValue();
/*     */ 
/*     */     
/* 334 */     this.panel.setChart(chart);
/* 335 */     this.panel.setMaximumDrawWidth(6000);
/* 336 */     this.panel.setPreferredSize(new Dimension(450, 300));
/* 337 */     chart.setBackgroundPaint(new Color(255, 255, 255, 0));
/* 338 */     this.plot.setBackgroundPaint(new Color(255, 255, 255, 0));
/* 339 */     chart.getLegend().setBackgroundPaint(new Color(255, 255, 255, 0));
/* 340 */     this.panel.setMouseWheelEnabled(true);
/* 341 */     chart.getLegend().setVisible(true);
/* 342 */     this.plot.addRangeMarker((Marker)markerRange);
/* 343 */     this.plot.addDomainMarker((Marker)markerDomain);
/* 344 */     markerRange.setLabel("Low-High");
/* 345 */     markerRange.setLabelFont(new Font("SansSerif", 0, 15));
/* 346 */     markerRange.setLabelPaint(new Color(0, 102, 0));
/*     */     
/* 348 */     Font font3 = new Font("Dialog", 1, 12);
/* 349 */     this.plot.getDomainAxis().setLabelFont(font3);
/* 350 */     this.plot.getRangeAxis().setLabelFont(font3);
/* 351 */     this.plot.getRangeAxis().setTickLabelFont(font3);
/* 352 */     this.plot.getDomainAxis().setTickLabelFont(font3);
/*     */     
/* 354 */     NumberAxis domain = (NumberAxis)this.plot.getDomainAxis();
/*     */     
/* 356 */     NumberAxis range = (NumberAxis)this.plot.getRangeAxis();
/*     */     
/* 358 */     domain.setAutoRange(true);
/* 359 */     range.setAutoRange(true);
/* 360 */     computePowerCoefficients(chart, this.plot, this.dataset);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addScatterPlotSeriesPolynomial(String domainName, String rangeName, List<Double> valuesDomain, List<Double> valuesRange, IntervalMarker markerRange, IntervalMarker markerDomain, String domainValue, String rangeValue, Object[][] data, final Color[] classColor, int filterOrder) {
/* 368 */     this.valuesDomain = valuesDomain;
/* 369 */     this.rangeName = rangeName;
/* 370 */     this.domainName = domainName;
/* 371 */     this.valuesRange = valuesRange;
/* 372 */     this.markerRange = markerRange;
/* 373 */     this.markerDomain = markerDomain;
/* 374 */     this.domainValue = domainValue;
/* 375 */     this.rangeValue = rangeValue;
/* 376 */     this.classColor = classColor;
/* 377 */     this.filterOrder = filterOrder;
/*     */     
/* 379 */     this.panel.removeAll();
/* 380 */     this.dataset = new XYSeriesCollection();
/* 381 */     this.series1 = new XYSeries("");
/* 382 */     for (int i = 0; i < valuesDomain.size(); i++)
/* 383 */       this.series1.add(valuesDomain.get(i), valuesRange.get(i)); 
/* 384 */     this.dataset.addSeries(this.series1);
/* 385 */     double minDomain = ((Double)Collections.<Double>min(valuesDomain)).doubleValue();
/* 386 */     double maxDomain = ((Double)Collections.<Double>max(valuesDomain)).doubleValue();
/*     */     
/* 388 */     double[] coefficients = Regression.getPolynomialRegression((XYDataset)this.dataset, 0, filterOrder);
/* 389 */     PowerFunction2D powerFunction2D = new PowerFunction2D(coefficients[0], coefficients[1]);
/* 390 */     XYDataset regressionData = DatasetUtils.sampleFunction2D((Function2D)powerFunction2D, minDomain, maxDomain, valuesDomain.size(), 
/* 391 */         "Fitted Regression Line");
/*     */     
/* 393 */     JFreeChart chart = ChartFactory.createScatterPlot("", domainName, rangeName, (XYDataset)this.dataset, PlotOrientation.VERTICAL, 
/* 394 */         true, true, false);
/*     */     
/* 396 */     this.plot = (XYPlot)chart.getPlot();
/* 397 */     XYLineAndShapeRenderer renderer1 = new XYLineAndShapeRenderer(false, true);
/* 398 */     this.plot.setRenderer((XYItemRenderer)renderer1);
/* 399 */     this.plot.setBackgroundPaint(new Color(255, 228, 196));
/* 400 */     Paint[] paintArray = { new Color(-2130771968, true), new Color(-2147418368, true), new Color(-2147483393, true) };
/* 401 */     this.plot.setDrawingSupplier((DrawingSupplier)new DefaultDrawingSupplier(paintArray, 
/* 402 */           DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE, 
/* 403 */           DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE, DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE, 
/* 404 */           DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE, DefaultDrawingSupplier.DEFAULT_SHAPE_SEQUENCE));
/* 405 */     this.plot.setDataset(1, regressionData);
/* 406 */     XYLineAndShapeRenderer renderer2 = new XYLineAndShapeRenderer(true, false);
/* 407 */     renderer2.setSeriesPaint(0, Color.RED);
/* 408 */     this.plot.setRenderer(1, (XYItemRenderer)renderer2);
/* 409 */     Shape cross = new Ellipse2D.Double(0.0D, 0.0D, 5.0D, 5.0D);
/* 410 */     List<String[]> featureLists = (List)new ArrayList<>();
/* 411 */     for (int j = 0; j < ColorEditorSpot.tableC.getModel().getRowCount(); j++) {
/* 412 */       featureLists.add(((JLabel)ColorEditorSpot.tableC.getModel().getValueAt(j, 
/* 413 */             ColorEditorSpot.tableC.convertColumnIndexToModel(2))).getText().replace("<html>", "")
/* 414 */           .split("<br>"));
/*     */     }
/* 416 */     this.renderer = new XYLineAndShapeRenderer()
/*     */       {
/*     */         public Paint getItemPaint(int row, int col) {
/* 419 */           Paint cpaint = getItemColor(row, col);
/* 420 */           if (cpaint == null) {
/* 421 */             cpaint = super.getItemPaint(row, col);
/*     */           }
/* 423 */           return cpaint;
/*     */         }
/*     */         
/*     */         public Color getItemColor(int row, int col) {
/* 427 */           double x = STScatterPlot.this.dataset.getXValue(row, col);
/* 428 */           double y = STScatterPlot.this.dataset.getYValue(row, col);
/*     */           
/*     */           try {
/* 431 */             return classColor[col];
/* 432 */           } catch (Exception exception) {
/*     */ 
/*     */ 
/*     */             
/* 436 */             return null;
/*     */           } 
/*     */         }
/*     */       };
/*     */     
/* 441 */     this.plot.setRenderer((XYItemRenderer)this.renderer);
/* 442 */     this.renderer.setUseOutlinePaint(true);
/* 443 */     this.renderer.setSeriesShape(0, cross);
/* 444 */     this.renderer.setSeriesOutlinePaint(0, Color.black);
/* 445 */     this.renderer.setSeriesOutlineStroke(0, new BasicStroke(1.0F));
/* 446 */     this.renderer.setSeriesLinesVisible(0, false);
/* 447 */     this.renderer.setSeriesPaint(0, Color.LIGHT_GRAY);
/* 448 */     this.plot.getRangeCrosshairValue();
/* 449 */     this.plot.getDomainCrosshairValue();
/*     */ 
/*     */     
/* 452 */     this.panel.setChart(chart);
/* 453 */     this.panel.setMaximumDrawWidth(6000);
/* 454 */     this.panel.setPreferredSize(new Dimension(450, 300));
/* 455 */     chart.setBackgroundPaint(new Color(255, 255, 255, 0));
/* 456 */     this.plot.setBackgroundPaint(new Color(255, 255, 255, 0));
/* 457 */     chart.getLegend().setBackgroundPaint(new Color(255, 255, 255, 0));
/* 458 */     this.panel.setMouseWheelEnabled(true);
/* 459 */     chart.getLegend().setVisible(true);
/* 460 */     this.plot.addRangeMarker((Marker)markerRange);
/* 461 */     this.plot.addDomainMarker((Marker)markerDomain);
/* 462 */     markerRange.setLabel("Low-High");
/* 463 */     markerRange.setLabelFont(new Font("SansSerif", 0, 15));
/* 464 */     markerRange.setLabelPaint(new Color(0, 102, 0));
/*     */     
/* 466 */     Font font3 = new Font("Dialog", 1, 12);
/* 467 */     this.plot.getDomainAxis().setLabelFont(font3);
/* 468 */     this.plot.getRangeAxis().setLabelFont(font3);
/* 469 */     this.plot.getRangeAxis().setTickLabelFont(font3);
/* 470 */     this.plot.getDomainAxis().setTickLabelFont(font3);
/*     */     
/* 472 */     NumberAxis domain = (NumberAxis)this.plot.getDomainAxis();
/*     */     
/* 474 */     NumberAxis range = (NumberAxis)this.plot.getRangeAxis();
/*     */     
/* 476 */     domain.setAutoRange(true);
/* 477 */     range.setAutoRange(true);
/* 478 */     computePolynomialCoefficients(chart, this.plot, this.dataset, filterOrder);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addScatterPlotSeriesLogarithmic(String domainName, String rangeName, List<Double> valuesDomain, List<Double> valuesRange, IntervalMarker markerRange, IntervalMarker markerDomain, String domainValue, String rangeValue, Object[][] data, final Color[] classColor) {
/* 486 */     this.valuesDomain = valuesDomain;
/* 487 */     this.rangeName = rangeName;
/* 488 */     this.domainName = domainName;
/* 489 */     this.valuesRange = valuesRange;
/* 490 */     this.markerRange = markerRange;
/* 491 */     this.markerDomain = markerDomain;
/* 492 */     this.domainValue = domainValue;
/* 493 */     this.rangeValue = rangeValue;
/* 494 */     this.classColor = classColor;
/* 495 */     this.filterOrder = this.filterOrder;
/*     */     
/* 497 */     this.panel.removeAll();
/* 498 */     this.dataset = new XYSeriesCollection();
/* 499 */     this.series1 = new XYSeries("");
/* 500 */     for (int i = 0; i < valuesDomain.size(); i++)
/* 501 */       this.series1.add(valuesDomain.get(i), valuesRange.get(i)); 
/* 502 */     this.dataset.addSeries(this.series1);
/* 503 */     double minDomain = ((Double)Collections.<Double>min(valuesDomain)).doubleValue();
/* 504 */     double maxDomain = ((Double)Collections.<Double>max(valuesDomain)).doubleValue();
/* 505 */     double[] coefficients = RegressionLE_.getLogarithmicRegression((XYDataset)this.dataset, 0);
/* 506 */     Function2D curve = new LogarithmicFunction2D(coefficients[0], coefficients[1]);
/* 507 */     XYDataset regressionData = DatasetUtils.sampleFunction2D(curve, minDomain, maxDomain, valuesDomain.size(), 
/* 508 */         "Fitted Regression Line");
/*     */ 
/*     */     
/* 511 */     JFreeChart chart = ChartFactory.createScatterPlot("", domainName, rangeName, (XYDataset)this.dataset, PlotOrientation.VERTICAL, 
/* 512 */         true, true, false);
/*     */     
/* 514 */     this.plot = (XYPlot)chart.getPlot();
/* 515 */     XYLineAndShapeRenderer renderer1 = new XYLineAndShapeRenderer(false, true);
/* 516 */     this.plot.setRenderer((XYItemRenderer)renderer1);
/* 517 */     this.plot.setBackgroundPaint(new Color(255, 228, 196));
/* 518 */     Paint[] paintArray = { new Color(-2130771968, true), new Color(-2147418368, true), new Color(-2147483393, true) };
/* 519 */     this.plot.setDrawingSupplier((DrawingSupplier)new DefaultDrawingSupplier(paintArray, 
/* 520 */           DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE, 
/* 521 */           DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE, DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE, 
/* 522 */           DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE, DefaultDrawingSupplier.DEFAULT_SHAPE_SEQUENCE));
/* 523 */     this.plot.setDataset(1, regressionData);
/* 524 */     XYLineAndShapeRenderer renderer2 = new XYLineAndShapeRenderer(true, false);
/* 525 */     renderer2.setSeriesPaint(0, Color.RED);
/* 526 */     this.plot.setRenderer(1, (XYItemRenderer)renderer2);
/* 527 */     Shape cross = new Ellipse2D.Double(0.0D, 0.0D, 5.0D, 5.0D);
/* 528 */     List<String[]> featureLists = (List)new ArrayList<>();
/* 529 */     for (int j = 0; j < ColorEditorSpot.tableC.getModel().getRowCount(); j++) {
/* 530 */       featureLists.add(((JLabel)ColorEditorSpot.tableC.getModel().getValueAt(j, 
/* 531 */             ColorEditorSpot.tableC.convertColumnIndexToModel(2))).getText().replace("<html>", "")
/* 532 */           .split("<br>"));
/*     */     }
/* 534 */     this.renderer = new XYLineAndShapeRenderer()
/*     */       {
/*     */         public Paint getItemPaint(int row, int col) {
/* 537 */           Paint cpaint = getItemColor(row, col);
/* 538 */           if (cpaint == null) {
/* 539 */             cpaint = super.getItemPaint(row, col);
/*     */           }
/* 541 */           return cpaint;
/*     */         }
/*     */         
/*     */         public Color getItemColor(int row, int col) {
/* 545 */           double x = STScatterPlot.this.dataset.getXValue(row, col);
/* 546 */           double y = STScatterPlot.this.dataset.getYValue(row, col);
/*     */           
/*     */           try {
/* 549 */             return classColor[col];
/* 550 */           } catch (Exception exception) {
/*     */ 
/*     */ 
/*     */             
/* 554 */             return null;
/*     */           } 
/*     */         }
/*     */       };
/*     */     
/* 559 */     this.plot.setRenderer((XYItemRenderer)this.renderer);
/* 560 */     this.renderer.setUseOutlinePaint(true);
/* 561 */     this.renderer.setSeriesShape(0, cross);
/* 562 */     this.renderer.setSeriesOutlinePaint(0, Color.black);
/* 563 */     this.renderer.setSeriesOutlineStroke(0, new BasicStroke(1.0F));
/* 564 */     this.renderer.setSeriesLinesVisible(0, false);
/* 565 */     this.renderer.setSeriesPaint(0, Color.LIGHT_GRAY);
/* 566 */     this.plot.getRangeCrosshairValue();
/* 567 */     this.plot.getDomainCrosshairValue();
/*     */ 
/*     */     
/* 570 */     this.panel.setChart(chart);
/* 571 */     this.panel.setMaximumDrawWidth(6000);
/* 572 */     this.panel.setPreferredSize(new Dimension(450, 300));
/* 573 */     chart.setBackgroundPaint(new Color(255, 255, 255, 0));
/* 574 */     this.plot.setBackgroundPaint(new Color(255, 255, 255, 0));
/* 575 */     chart.getLegend().setBackgroundPaint(new Color(255, 255, 255, 0));
/* 576 */     this.panel.setMouseWheelEnabled(true);
/* 577 */     chart.getLegend().setVisible(true);
/* 578 */     this.plot.addRangeMarker((Marker)markerRange);
/* 579 */     this.plot.addDomainMarker((Marker)markerDomain);
/* 580 */     markerRange.setLabel("Low-High");
/* 581 */     markerRange.setLabelFont(new Font("SansSerif", 0, 15));
/* 582 */     markerRange.setLabelPaint(new Color(0, 102, 0));
/*     */     
/* 584 */     Font font3 = new Font("Dialog", 1, 12);
/* 585 */     this.plot.getDomainAxis().setLabelFont(font3);
/* 586 */     this.plot.getRangeAxis().setLabelFont(font3);
/* 587 */     this.plot.getRangeAxis().setTickLabelFont(font3);
/* 588 */     this.plot.getDomainAxis().setTickLabelFont(font3);
/*     */     
/* 590 */     NumberAxis domain = (NumberAxis)this.plot.getDomainAxis();
/*     */     
/* 592 */     NumberAxis range = (NumberAxis)this.plot.getRangeAxis();
/*     */     
/* 594 */     domain.setAutoRange(true);
/* 595 */     range.setAutoRange(true);
/* 596 */     computeLogarithmicCoefficients(chart, this.plot, this.dataset, this.filterOrder);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addScatterPlotSeriesExponential(String domainName, String rangeName, List<Double> valuesDomain, List<Double> valuesRange, IntervalMarker markerRange, IntervalMarker markerDomain, String domainValue, String rangeValue, Object[][] data, final Color[] classColor) {
/* 604 */     this.valuesDomain = valuesDomain;
/* 605 */     this.rangeName = rangeName;
/* 606 */     this.domainName = domainName;
/* 607 */     this.valuesRange = valuesRange;
/* 608 */     this.markerRange = markerRange;
/* 609 */     this.markerDomain = markerDomain;
/* 610 */     this.domainValue = domainValue;
/* 611 */     this.rangeValue = rangeValue;
/* 612 */     this.classColor = classColor;
/* 613 */     this.filterOrder = this.filterOrder;
/*     */     
/* 615 */     this.panel.removeAll();
/* 616 */     this.dataset = new XYSeriesCollection();
/* 617 */     this.series1 = new XYSeries("");
/* 618 */     for (int i = 0; i < valuesDomain.size(); i++)
/* 619 */       this.series1.add(valuesDomain.get(i), valuesRange.get(i)); 
/* 620 */     this.dataset.addSeries(this.series1);
/*     */     
/* 622 */     double minDomain = ((Double)Collections.<Double>min(valuesDomain)).doubleValue();
/* 623 */     double maxDomain = ((Double)Collections.<Double>max(valuesDomain)).doubleValue();
/* 624 */     double[] coefficients = RegressionLE_.getExponentialRegression((XYDataset)this.dataset, 0);
/* 625 */     Function2D curve = new ExponentialFunction2D(coefficients[0], coefficients[1]);
/* 626 */     XYDataset regressionData = DatasetUtils.sampleFunction2D(curve, minDomain, maxDomain, valuesDomain.size(), 
/* 627 */         "Fitted Regression Line");
/*     */ 
/*     */     
/* 630 */     JFreeChart chart = ChartFactory.createScatterPlot("", domainName, rangeName, (XYDataset)this.dataset, PlotOrientation.VERTICAL, 
/* 631 */         true, true, false);
/*     */     
/* 633 */     this.plot = (XYPlot)chart.getPlot();
/* 634 */     XYLineAndShapeRenderer renderer1 = new XYLineAndShapeRenderer(false, true);
/* 635 */     this.plot.setRenderer((XYItemRenderer)renderer1);
/* 636 */     this.plot.setBackgroundPaint(new Color(255, 228, 196));
/* 637 */     Paint[] paintArray = { new Color(-2130771968, true), new Color(-2147418368, true), new Color(-2147483393, true) };
/* 638 */     this.plot.setDrawingSupplier((DrawingSupplier)new DefaultDrawingSupplier(paintArray, 
/* 639 */           DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE, 
/* 640 */           DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE, DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE, 
/* 641 */           DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE, DefaultDrawingSupplier.DEFAULT_SHAPE_SEQUENCE));
/* 642 */     this.plot.setDataset(1, regressionData);
/* 643 */     XYLineAndShapeRenderer renderer2 = new XYLineAndShapeRenderer(true, false);
/* 644 */     renderer2.setSeriesPaint(0, Color.RED);
/* 645 */     this.plot.setRenderer(1, (XYItemRenderer)renderer2);
/* 646 */     Shape cross = new Ellipse2D.Double(0.0D, 0.0D, 5.0D, 5.0D);
/* 647 */     List<String[]> featureLists = (List)new ArrayList<>();
/* 648 */     for (int j = 0; j < ColorEditorSpot.tableC.getModel().getRowCount(); j++) {
/* 649 */       featureLists.add(((JLabel)ColorEditorSpot.tableC.getModel().getValueAt(j, 
/* 650 */             ColorEditorSpot.tableC.convertColumnIndexToModel(2))).getText().replace("<html>", "")
/* 651 */           .split("<br>"));
/*     */     }
/* 653 */     this.renderer = new XYLineAndShapeRenderer()
/*     */       {
/*     */         public Paint getItemPaint(int row, int col) {
/* 656 */           Paint cpaint = getItemColor(row, col);
/* 657 */           if (cpaint == null) {
/* 658 */             cpaint = super.getItemPaint(row, col);
/*     */           }
/* 660 */           return cpaint;
/*     */         }
/*     */         
/*     */         public Color getItemColor(int row, int col) {
/* 664 */           double x = STScatterPlot.this.dataset.getXValue(row, col);
/* 665 */           double y = STScatterPlot.this.dataset.getYValue(row, col);
/*     */           
/*     */           try {
/* 668 */             return classColor[col];
/* 669 */           } catch (Exception exception) {
/*     */ 
/*     */ 
/*     */             
/* 673 */             return null;
/*     */           } 
/*     */         }
/*     */       };
/*     */     
/* 678 */     this.plot.setRenderer((XYItemRenderer)this.renderer);
/* 679 */     this.renderer.setUseOutlinePaint(true);
/* 680 */     this.renderer.setSeriesShape(0, cross);
/* 681 */     this.renderer.setSeriesOutlinePaint(0, Color.black);
/* 682 */     this.renderer.setSeriesOutlineStroke(0, new BasicStroke(1.0F));
/* 683 */     this.renderer.setSeriesLinesVisible(0, false);
/* 684 */     this.renderer.setSeriesPaint(0, Color.LIGHT_GRAY);
/* 685 */     this.plot.getRangeCrosshairValue();
/* 686 */     this.plot.getDomainCrosshairValue();
/*     */ 
/*     */     
/* 689 */     this.panel.setChart(chart);
/* 690 */     this.panel.setMaximumDrawWidth(6000);
/* 691 */     this.panel.setPreferredSize(new Dimension(450, 300));
/* 692 */     chart.setBackgroundPaint(new Color(255, 255, 255, 0));
/* 693 */     this.plot.setBackgroundPaint(new Color(255, 255, 255, 0));
/* 694 */     chart.getLegend().setBackgroundPaint(new Color(255, 255, 255, 0));
/* 695 */     this.panel.setMouseWheelEnabled(true);
/* 696 */     chart.getLegend().setVisible(true);
/* 697 */     this.plot.addRangeMarker((Marker)markerRange);
/* 698 */     this.plot.addDomainMarker((Marker)markerDomain);
/* 699 */     markerRange.setLabel("Low-High");
/* 700 */     markerRange.setLabelFont(new Font("SansSerif", 0, 15));
/* 701 */     markerRange.setLabelPaint(new Color(0, 102, 0));
/*     */     
/* 703 */     Font font3 = new Font("Dialog", 1, 12);
/* 704 */     this.plot.getDomainAxis().setLabelFont(font3);
/* 705 */     this.plot.getRangeAxis().setLabelFont(font3);
/* 706 */     this.plot.getRangeAxis().setTickLabelFont(font3);
/* 707 */     this.plot.getDomainAxis().setTickLabelFont(font3);
/*     */     
/* 709 */     NumberAxis domain = (NumberAxis)this.plot.getDomainAxis();
/*     */     
/* 711 */     NumberAxis range = (NumberAxis)this.plot.getRangeAxis();
/*     */     
/* 713 */     domain.setAutoRange(true);
/* 714 */     range.setAutoRange(true);
/* 715 */     computeExponentialCoefficients(chart, this.plot, this.dataset, this.filterOrder);
/*     */   }
/*     */   
/*     */   private void computeLinearCoefficients(JFreeChart chart, XYPlot plot, XYSeriesCollection dataset) {
/*     */     String linearEquation;
/* 720 */     Function2D retVal = null;
/* 721 */     double r2 = 0.0D;
/* 722 */     double[] coefficients = null;
/*     */ 
/*     */     
/*     */     try {
/* 726 */       coefficients = RegressionLE_.getOLSRegression((XYDataset)dataset, 0);
/* 727 */       LineFunction2D lineFunction2D = new LineFunction2D(coefficients[0], coefficients[1]);
/* 728 */       r2 = coefficients[2];
/* 729 */     } catch (Exception e) {
/* 730 */       System.err.println(e.getMessage());
/*     */     } 
/* 732 */     double intercept = coefficients[0];
/* 733 */     double slope = coefficients[1];
/*     */     
/* 735 */     if (intercept >= 0.0D) {
/* 736 */       linearEquation = "y = " + String.format("%.2f", new Object[] { Double.valueOf(slope) }) + "x + " + String.format("%.2f", new Object[] { Double.valueOf(intercept) });
/*     */     } else {
/* 738 */       linearEquation = "y = " + String.format("%.2f", new Object[] { Double.valueOf(slope) }) + "x - " + Math.abs(intercept);
/*     */     } 
/*     */     
/* 741 */     TextTitle tt = new TextTitle(String.valueOf(linearEquation) + "\nR² = " + String.format("%.2f", new Object[] { Double.valueOf(r2) }));
/* 742 */     tt.setTextAlignment(HorizontalAlignment.RIGHT);
/* 743 */     tt.setFont(chart.getLegend().getItemFont());
/* 744 */     tt.setBackgroundPaint(new Color(200, 200, 255, 100));
/* 745 */     tt.setFrame((BlockFrame)new BlockBorder(Color.white));
/* 746 */     tt.setPosition(RectangleEdge.BOTTOM);
/*     */     
/* 748 */     XYTitleAnnotation r2Annotation = new XYTitleAnnotation(0.98D, 0.02D, (Title)tt, RectangleAnchor.BOTTOM_RIGHT);
/* 749 */     r2Annotation.setMaxWidth(0.48D);
/* 750 */     plot.addAnnotation((XYAnnotation)r2Annotation);
/*     */   }
/*     */   private void computePowerCoefficients(JFreeChart chart, XYPlot plot, XYSeriesCollection dataset) {
/*     */     String linearEquation;
/* 754 */     Function2D retVal = null;
/* 755 */     double r2 = 0.0D;
/* 756 */     double[] coefficients = null;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 762 */       coefficients = RegressionLE_.getPowerRegression((XYDataset)dataset, 0);
/* 763 */       if (coefficients[2] > r2) {
/* 764 */         PowerFunction2D powerFunction2D = new PowerFunction2D(coefficients[0], coefficients[1]);
/* 765 */         r2 = coefficients[2];
/*     */       } 
/* 767 */     } catch (Exception e) {
/* 768 */       System.err.println(e.getMessage());
/*     */     } 
/* 770 */     double intercept = coefficients[0];
/* 771 */     double slope = coefficients[1];
/*     */     
/* 773 */     if (intercept >= 0.0D) {
/* 774 */       linearEquation = "y = " + String.format("%.2f", new Object[] { Double.valueOf(slope) }) + "x^ " + String.format("%.2f", new Object[] { Double.valueOf(intercept) });
/*     */     } else {
/* 776 */       linearEquation = "y = " + String.format("%.2f", new Object[] { Double.valueOf(slope) }) + "x^ -" + Math.abs(intercept);
/*     */     } 
/*     */     
/* 779 */     TextTitle tt = new TextTitle(String.valueOf(linearEquation) + "\nR² = " + String.format("%.2f", new Object[] { Double.valueOf(r2) }));
/* 780 */     tt.setTextAlignment(HorizontalAlignment.RIGHT);
/* 781 */     tt.setFont(chart.getLegend().getItemFont());
/* 782 */     tt.setBackgroundPaint(new Color(200, 200, 255, 100));
/* 783 */     tt.setFrame((BlockFrame)new BlockBorder(Color.white));
/* 784 */     tt.setPosition(RectangleEdge.BOTTOM);
/*     */     
/* 786 */     XYTitleAnnotation r2Annotation = new XYTitleAnnotation(0.98D, 0.02D, (Title)tt, RectangleAnchor.BOTTOM_RIGHT);
/* 787 */     r2Annotation.setMaxWidth(0.48D);
/* 788 */     plot.addAnnotation((XYAnnotation)r2Annotation);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void computePolynomialCoefficients(JFreeChart chart, XYPlot plot, XYSeriesCollection dataset, int filterOrder) {
/* 794 */     double[] coefficients = Regression.getPolynomialRegression((XYDataset)dataset, 0, filterOrder);
/* 795 */     double r2 = coefficients[coefficients.length - 1];
/* 796 */     String polynomialEquation = "";
/* 797 */     for (int i = coefficients.length - 1; i >= 0; i--) {
/* 798 */       if (i == 0) {
/* 799 */         polynomialEquation = String.valueOf(polynomialEquation) + String.format("%.2f", new Object[] { Double.valueOf(coefficients[i]) });
/*     */       }
/* 801 */       else if (i == 1) {
/* 802 */         polynomialEquation = String.valueOf(polynomialEquation) + String.format("%.2f", new Object[] { Double.valueOf(coefficients[i]) }) + "*x+";
/* 803 */       } else if (i > 1) {
/* 804 */         polynomialEquation = String.valueOf(polynomialEquation) + String.format("%.2f", new Object[] { Double.valueOf(coefficients[i]) }) + "*x^" + i + "+";
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 809 */     TextTitle tt = new TextTitle("y = " + polynomialEquation + "\nR² = " + String.format("%.2f", new Object[] { Double.valueOf(r2) }));
/* 810 */     tt.setTextAlignment(HorizontalAlignment.RIGHT);
/* 811 */     tt.setFont(chart.getLegend().getItemFont());
/* 812 */     tt.setBackgroundPaint(new Color(200, 200, 255, 100));
/* 813 */     tt.setFrame((BlockFrame)new BlockBorder(Color.white));
/* 814 */     tt.setPosition(RectangleEdge.BOTTOM);
/*     */     
/* 816 */     XYTitleAnnotation r2Annotation = new XYTitleAnnotation(0.98D, 0.02D, (Title)tt, RectangleAnchor.BOTTOM_RIGHT);
/* 817 */     r2Annotation.setMaxWidth(0.48D);
/* 818 */     plot.addAnnotation((XYAnnotation)r2Annotation);
/*     */   }
/*     */ 
/*     */   
/*     */   private void computeLogarithmicCoefficients(JFreeChart chart, XYPlot plot, XYSeriesCollection dataset, int filterOrder) {
/* 823 */     Function2D retVal = null;
/* 824 */     double r2 = 0.0D;
/* 825 */     double[] coefficients = null;
/*     */     
/*     */     try {
/* 828 */       coefficients = RegressionLE_.getLogarithmicRegression((XYDataset)dataset, 0);
/* 829 */       if (coefficients[2] > r2) {
/* 830 */         retVal = new LogarithmicFunction2D(coefficients[0], coefficients[1]);
/* 831 */         r2 = coefficients[2];
/*     */       } 
/* 833 */     } catch (Exception e) {
/* 834 */       System.err.println(e.getMessage());
/*     */     } 
/* 836 */     String logarithmicEquation = "y = " + String.format("%.2f", new Object[] { Double.valueOf(coefficients[0]) }) + " + " + "( " + 
/* 837 */       String.format("%.2f", new Object[] { Double.valueOf(coefficients[1]) }) + " * ln(x) ) ";
/*     */     
/* 839 */     TextTitle tt = new TextTitle("y = " + logarithmicEquation + "\nR² = " + String.format("%.2f", new Object[] { Double.valueOf(r2) }));
/* 840 */     tt.setTextAlignment(HorizontalAlignment.RIGHT);
/* 841 */     tt.setFont(chart.getLegend().getItemFont());
/* 842 */     tt.setBackgroundPaint(new Color(200, 200, 255, 100));
/* 843 */     tt.setFrame((BlockFrame)new BlockBorder(Color.white));
/* 844 */     tt.setPosition(RectangleEdge.BOTTOM);
/*     */     
/* 846 */     XYTitleAnnotation r2Annotation = new XYTitleAnnotation(0.98D, 0.02D, (Title)tt, RectangleAnchor.BOTTOM_RIGHT);
/* 847 */     r2Annotation.setMaxWidth(0.48D);
/* 848 */     plot.addAnnotation((XYAnnotation)r2Annotation);
/*     */   }
/*     */   
/*     */   private void computeExponentialCoefficients(JFreeChart chart, XYPlot plot, XYSeriesCollection dataset, int filterOrder) {
/* 852 */     Function2D retVal = null;
/* 853 */     double r2 = 0.0D;
/* 854 */     double[] coefficients = null;
/*     */     
/*     */     try {
/* 857 */       coefficients = RegressionLE_.getExponentialRegression((XYDataset)dataset, 0);
/* 858 */       if (coefficients[2] > r2) {
/* 859 */         retVal = new LogarithmicFunction2D(coefficients[0], coefficients[1]);
/* 860 */         r2 = coefficients[2];
/*     */       } 
/* 862 */     } catch (Exception e) {
/* 863 */       System.err.println(e.getMessage());
/*     */     } 
/* 865 */     String exponentialEquation = "y = " + String.format("%.2f", new Object[] { Double.valueOf(coefficients[0]) }) + " * " + "( e^(" + 
/* 866 */       String.format("%.2f", new Object[] { Double.valueOf(coefficients[1]) }) + " * x) ) ";
/*     */     
/* 868 */     TextTitle tt = new TextTitle("y = " + exponentialEquation + "\nR² = " + String.format("%.2f", new Object[] { Double.valueOf(r2) }));
/* 869 */     tt.setTextAlignment(HorizontalAlignment.RIGHT);
/* 870 */     tt.setFont(chart.getLegend().getItemFont());
/* 871 */     tt.setBackgroundPaint(new Color(200, 200, 255, 100));
/* 872 */     tt.setFrame((BlockFrame)new BlockBorder(Color.white));
/* 873 */     tt.setPosition(RectangleEdge.BOTTOM);
/*     */     
/* 875 */     XYTitleAnnotation r2Annotation = new XYTitleAnnotation(0.98D, 0.02D, (Title)tt, RectangleAnchor.BOTTOM_RIGHT);
/* 876 */     r2Annotation.setMaxWidth(0.48D);
/* 877 */     plot.addAnnotation((XYAnnotation)r2Annotation);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/SLTDisplayer_.jar!/STScatterPlot.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */