/*     */ import ij.measure.Measurements;
/*     */ import ij.plugin.PlugIn;
/*     */ import java.awt.Component;
/*     */ import java.awt.FlowLayout;
/*     */ import java.awt.Font;
/*     */ import java.awt.Panel;
/*     */ import java.awt.TextField;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.event.WindowEvent;
/*     */ import java.net.URL;
/*     */ import java.util.prefs.Preferences;
/*     */ import javax.swing.BoxLayout;
/*     */ import javax.swing.Icon;
/*     */ import javax.swing.ImageIcon;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JFrame;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.UIManager;
/*     */ import javax.swing.UnsupportedLookAndFeelException;
/*     */ import jwizardcomponent.JWizardPanel;
/*     */ import jwizardcomponent.Utilities;
/*     */ import jwizardcomponent.frame.JWizardFrame;
/*     */ 
/*     */ public class SLTDisplayer_ implements PlugIn, Measurements {
/*     */   static String SLTDISPLAYER_XML_PATH;
/*     */   static String SLTDISPLAYER_IMAGES_PATH;
/*     */   static String xmlPath;
/*     */   static String imagesPath;
/*     */   Preferences prefXml;
/*     */   Preferences prefImages;
/*     */   JPanel panelInitial;
/*     */   JFrame frame;
/*     */   JWizardFrame wizard;
/*     */   JWizardPanel panel;
/*     */   public static final int PANEL_FIRST = 0;
/*     */   public static final int PANEL_CHOOSER = 1;
/*     */   public static final int PANEL_OPTION_A = 2;
/*     */   public static final int PANEL_OPTION_B = 3;
/*     */   public static final int PANEL_LAST = 4;
/*     */   public static TextField textXml;
/*     */   public static TextField textImages;
/*     */   
/*     */   public void run(String arg0) {
/*  46 */     JFrame.setDefaultLookAndFeelDecorated(true); try {
/*     */       byte b; int i; UIManager.LookAndFeelInfo[] arrayOfLookAndFeelInfo;
/*  48 */       for (i = (arrayOfLookAndFeelInfo = UIManager.getInstalledLookAndFeels()).length, b = 0; b < i; ) { UIManager.LookAndFeelInfo info = arrayOfLookAndFeelInfo[b];
/*  49 */         if ("Nimbus".equals(info.getName())) {
/*  50 */           UIManager.setLookAndFeel(info.getClassName()); break;
/*     */         } 
/*     */         b++; }
/*     */     
/*  54 */     } catch (UnsupportedLookAndFeelException unsupportedLookAndFeelException) {
/*     */     
/*  56 */     } catch (ClassNotFoundException classNotFoundException) {
/*     */     
/*  58 */     } catch (InstantiationException instantiationException) {
/*     */     
/*  60 */     } catch (IllegalAccessException illegalAccessException) {}
/*     */ 
/*     */ 
/*     */     
/*  64 */     this.prefXml = Preferences.userRoot();
/*  65 */     this.prefImages = Preferences.userRoot();
/*  66 */     SLTDISPLAYER_XML_PATH = "xml_path";
/*  67 */     SLTDISPLAYER_IMAGES_PATH = "images_path";
/*     */     
/*  69 */     JButton buttonBrowse1 = new JButton("");
/*  70 */     JButton buttonBrowse2 = new JButton("");
/*  71 */     ImageIcon iconBrowse = createImageIcon("images/browse.png");
/*  72 */     Icon iconBrowseCell = new ImageIcon(iconBrowse.getImage().getScaledInstance(15, 15, 4));
/*  73 */     buttonBrowse1.setIcon(iconBrowseCell);
/*  74 */     this.panelInitial = new JPanel();
/*  75 */     this.panelInitial.setLayout(new BoxLayout(this.panelInitial, 1));
/*     */     
/*  77 */     textXml = new TextField(20);
/*  78 */     textXml.setText(this.prefXml.get(SLTDISPLAYER_XML_PATH, ""));
/*  79 */     textImages = new TextField(20);
/*  80 */     textImages.setText(this.prefImages.get(SLTDISPLAYER_IMAGES_PATH, ""));
/*  81 */     JLabel labelXml = new JLabel("⊳  Load TrackMate .XML file: ");
/*  82 */     labelXml.setFont(new Font("Verdana", 1, 12));
/*  83 */     JLabel labelImages = new JLabel("⊳  Load movies to be analyzed:   ");
/*  84 */     labelImages.setFont(new Font("Verdana", 1, 12));
/*  85 */     DirectoryListener listenerXml = new DirectoryListener("Browse for TrackMate XML file...  ", textXml, 
/*  86 */         2);
/*  87 */     DirectoryListener listenerImages = new DirectoryListener("Browse for movies...  ", textImages, 
/*  88 */         2);
/*  89 */     buttonBrowse2.setIcon(iconBrowseCell);
/*  90 */     buttonBrowse1.addActionListener(listenerXml);
/*  91 */     buttonBrowse2.addActionListener(listenerImages);
/*     */     
/*  93 */     Panel panelXml = new Panel();
/*  94 */     panelXml.setLayout(new FlowLayout(0));
/*  95 */     panelXml.add(labelXml);
/*  96 */     panelXml.add(textXml);
/*  97 */     panelXml.add(buttonBrowse1);
/*  98 */     Panel panelImages = new Panel();
/*  99 */     panelImages.setLayout(new FlowLayout(0));
/* 100 */     panelImages.add(labelImages);
/* 101 */     panelImages.add(textImages);
/* 102 */     panelImages.add(buttonBrowse2);
/* 103 */     JButton okButton = new JButton("SPT-Viewer");
/* 104 */     ImageIcon iconOk = createImageIcon("images/viewer.png");
/* 105 */     Icon iconOkCell = new ImageIcon(iconOk.getImage().getScaledInstance(15, 15, 4));
/* 106 */     okButton.setIcon(iconOkCell);
/* 107 */     JButton cancelButton = new JButton("SPT-Batch");
/* 108 */     ImageIcon iconCancel = createImageIcon("images/batch.png");
/* 109 */     Icon iconCancelCell = new ImageIcon(iconCancel.getImage().getScaledInstance(15, 15, 4));
/* 110 */     cancelButton.setIcon(iconCancelCell);
/* 111 */     Panel panelOkCancel = new Panel();
/* 112 */     panelOkCancel.setLayout(new FlowLayout(1));
/* 113 */     panelOkCancel.add(okButton);
/* 114 */     panelOkCancel.add(cancelButton);
/* 115 */     this.panelInitial.add(panelXml);
/* 116 */     this.panelInitial.add(panelImages);
/* 117 */     this.panelInitial.add(panelOkCancel);
/* 118 */     createFrame();
/* 119 */     okButton.addActionListener(new ActionListener()
/*     */         {
/*     */           public void actionPerformed(ActionEvent event) {
/* 122 */             SLTDisplayer_.xmlPath = SLTDisplayer_.textXml.getText();
/* 123 */             SLTDisplayer_.imagesPath = SLTDisplayer_.textImages.getText();
/* 124 */             SLTDisplayer_.this.prefXml.put(SLTDisplayer_.SLTDISPLAYER_XML_PATH, SLTDisplayer_.textXml.getText());
/* 125 */             SLTDisplayer_.this.prefImages.put(SLTDisplayer_.SLTDISPLAYER_IMAGES_PATH, SLTDisplayer_.textImages.getText());
/* 126 */             SLTDisplayer_.this.frame.dispatchEvent(new WindowEvent(SLTDisplayer_.this.frame, 201));
/* 127 */             SLTDisplayer_.this.wizard = new JWizardFrame();
/* 128 */             SLTDisplayer_.this.wizard.setTitle("SLT Viewer: ANALYSIS");
/*     */             
/* 130 */             SLTDisplayer_.this.panel = new FirstWizardPanel(SLTDisplayer_.this.wizard.getWizardComponents());
/* 131 */             SLTDisplayer_.this.wizard.getWizardComponents().addWizardPanel(0, SLTDisplayer_.this.panel);
/*     */             
/* 133 */             SLTDisplayer_.this.panel = new ChooserWizardPanel(SLTDisplayer_.this.wizard.getWizardComponents());
/* 134 */             SLTDisplayer_.this.wizard.getWizardComponents().addWizardPanel(1, SLTDisplayer_.this.panel);
/*     */             
/* 136 */             SLTDisplayer_.this.panel = new OptionWizardPanel(SLTDisplayer_.this.wizard.getWizardComponents(), "A");
/* 137 */             SLTDisplayer_.this.wizard.getWizardComponents().addWizardPanel(2, SLTDisplayer_.this.panel);
/*     */             
/* 139 */             SLTDisplayer_.this.panel = new OptionWizardPanel(SLTDisplayer_.this.wizard.getWizardComponents(), "B");
/* 140 */             SLTDisplayer_.this.wizard.getWizardComponents().addWizardPanel(3, SLTDisplayer_.this.panel);
/*     */             
/* 142 */             SLTDisplayer_.this.panel = new LastWizardPanel(SLTDisplayer_.this.wizard.getWizardComponents());
/* 143 */             SLTDisplayer_.this.wizard.getWizardComponents().addWizardPanel(4, SLTDisplayer_.this.panel);
/*     */             
/* 145 */             JButton backButton = SLTDisplayer_.this.wizard.getWizardComponents().getBackButton();
/* 146 */             backButton.setText("");
/* 147 */             ImageIcon iconBack = SLTDisplayer_.this.createImageIcon("images/next.png");
/* 148 */             Icon backCell = new ImageIcon(iconBack.getImage().getScaledInstance(20, 22, 4));
/* 149 */             backButton.setIcon(backCell);
/* 150 */             backButton.setToolTipText("Click this button to back on wizard.");
/* 151 */             JButton nextButton = SLTDisplayer_.this.wizard.getWizardComponents().getNextButton();
/* 152 */             nextButton.setText("");
/* 153 */             ImageIcon iconNext = SLTDisplayer_.this.createImageIcon("images/back.png");
/* 154 */             Icon nextCell = new ImageIcon(iconNext.getImage().getScaledInstance(20, 22, 4));
/* 155 */             nextButton.setIcon(nextCell);
/* 156 */             nextButton.setToolTipText("Click this button to switch wizard.");
/* 157 */             JButton finishButton = SLTDisplayer_.this.wizard.getWizardComponents().getFinishButton();
/* 158 */             finishButton.setText("");
/* 159 */             ImageIcon iconFinish = SLTDisplayer_.this.createImageIcon("images/finish.png");
/* 160 */             Icon finishCell = new ImageIcon(iconFinish.getImage().getScaledInstance(20, 22, 4));
/* 161 */             finishButton.setIcon(finishCell);
/* 162 */             finishButton.setToolTipText("Click this button to finish the process.");
/* 163 */             JButton cancelButton = SLTDisplayer_.this.wizard.getWizardComponents().getCancelButton();
/* 164 */             cancelButton.setText("");
/* 165 */             ImageIcon iconCancel = SLTDisplayer_.this.createImageIcon("images/cancel.png");
/* 166 */             Icon cancelCell = new ImageIcon(iconCancel.getImage().getScaledInstance(20, 22, 4));
/* 167 */             cancelButton.setIcon(cancelCell);
/* 168 */             cancelButton.setToolTipText("Click this button to cancel the process.");
/* 169 */             SLTDisplayer_.this.wizard.setSize(630, 1000);
/* 170 */             Utilities.centerComponentOnScreen((Component)SLTDisplayer_.this.wizard);
/*     */             
/* 172 */             SLTDisplayer_.this.wizard.setVisible(true);
/*     */           }
/*     */         });
/*     */ 
/*     */     
/* 177 */     cancelButton.addActionListener(new ActionListener()
/*     */         {
/*     */           public void actionPerformed(ActionEvent event) {
/* 180 */             SPTBatch_ sptBatch = new SPTBatch_();
/* 181 */             sptBatch.run("");
/*     */             
/* 183 */             SLTDisplayer_.this.frame.dispatchEvent(new WindowEvent(SLTDisplayer_.this.frame, 201));
/*     */           }
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void createFrame() {
/* 192 */     this.frame = new JFrame("Single Particle Tracking Analysis- TrackMate based Toolbox");
/* 193 */     this.frame.setDefaultCloseOperation(2);
/* 194 */     this.frame.setSize(400, 500);
/* 195 */     this.frame.setResizable(false);
/* 196 */     this.frame.getContentPane().add(this.panelInitial);
/* 197 */     this.frame.pack();
/* 198 */     this.frame.setVisible(true);
/*     */   }
/*     */ 
/*     */   
/*     */   protected ImageIcon createImageIcon(String path) {
/* 203 */     URL img = SLTDisplayer_.class.getResource(path);
/* 204 */     if (img != null) {
/* 205 */       return new ImageIcon(img);
/*     */     }
/* 207 */     System.err.println("Couldn't find file: " + path);
/* 208 */     return null;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/SLTDisplayer_.jar!/SLTDisplayer_.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */