/*    */ import java.awt.Color;
/*    */ import java.awt.Component;
/*    */ import javax.swing.JButton;
/*    */ import javax.swing.JLabel;
/*    */ import javax.swing.JScrollPane;
/*    */ import javax.swing.JTable;
/*    */ import javax.swing.table.DefaultTableCellRenderer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ResultRendererC
/*    */   extends DefaultTableCellRenderer
/*    */ {
/*    */   public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
/* 18 */     Component comp = null;
/*    */     
/* 20 */     if (value instanceof JLabel)
/* 21 */       comp = (JLabel)value; 
/* 22 */     if (value instanceof JTable)
/* 23 */       comp = (JTable)value; 
/* 24 */     if (value instanceof JScrollPane)
/* 25 */       comp = (JScrollPane)value; 
/* 26 */     if (value instanceof JButton)
/* 27 */       comp = (JButton)value; 
/* 28 */     if (value instanceof JScrollPane) {
/* 29 */       comp = (JScrollPane)value;
/*    */     }
/* 31 */     if (isSelected) {
/* 32 */       comp.setForeground(Color.BLUE);
/*    */     } else {
/*    */       
/* 35 */       comp.setForeground(Color.BLACK);
/*    */     } 
/*    */ 
/*    */     
/* 39 */     return comp;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/SLTDisplayer_.jar!/ResultRendererC.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */