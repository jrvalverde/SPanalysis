/*    */ import org.jfree.data.function.Function2D;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LogarithmicFunction2D
/*    */   implements Function2D
/*    */ {
/*    */   private double a;
/*    */   private double b;
/*    */   
/*    */   public LogarithmicFunction2D(double a, double b) {
/* 18 */     this.a = a;
/* 19 */     this.b = b;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public double getValue(double x) {
/* 30 */     return this.a + this.b * Math.log(x);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/SLTDisplayer_.jar!/LogarithmicFunction2D.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */