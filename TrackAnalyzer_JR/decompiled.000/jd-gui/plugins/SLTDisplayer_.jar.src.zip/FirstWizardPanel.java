/*     */ import fiji.plugin.trackmate.Spot;
/*     */ import fiji.plugin.trackmate.SpotCollection;
/*     */ import ij.IJ;
/*     */ import ij.ImagePlus;
/*     */ import ij.ImageStack;
/*     */ import ij.gui.Roi;
/*     */ import ij.io.FileInfo;
/*     */ import java.awt.BasicStroke;
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.FlowLayout;
/*     */ import java.awt.Font;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.Image;
/*     */ import java.awt.RenderingHints;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.event.ItemEvent;
/*     */ import java.awt.event.ItemListener;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.io.File;
/*     */ import java.net.URL;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import javax.swing.BorderFactory;
/*     */ import javax.swing.Box;
/*     */ import javax.swing.BoxLayout;
/*     */ import javax.swing.DefaultListModel;
/*     */ import javax.swing.Icon;
/*     */ import javax.swing.ImageIcon;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JCheckBox;
/*     */ import javax.swing.JComboBox;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JList;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JScrollPane;
/*     */ import javax.swing.JSeparator;
/*     */ import javax.swing.JSlider;
/*     */ import javax.swing.JSpinner;
/*     */ import javax.swing.JTabbedPane;
/*     */ import javax.swing.JTable;
/*     */ import javax.swing.JToggleButton;
/*     */ import javax.swing.ListSelectionModel;
/*     */ import javax.swing.SpinnerNumberModel;
/*     */ import javax.swing.event.ChangeEvent;
/*     */ import javax.swing.event.ChangeListener;
/*     */ import javax.swing.table.DefaultTableCellRenderer;
/*     */ import javax.swing.table.DefaultTableModel;
/*     */ import jwizardcomponent.JWizardComponents;
/*     */ import org.jfree.chart.ChartPanel;
/*     */ import org.jfree.chart.plot.IntervalMarker;
/*     */ 
/*     */ 
/*     */ public class FirstWizardPanel
/*     */   extends LabelWizardPanel
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   static JTable tableImages;
/*     */   static JTable tableSpot;
/*     */   static DefaultTableModel modelImages;
/*     */   static DefaultTableModel modelSpot;
/*     */   static ImagePlus[] imps;
/*     */   static ImagePlus[] impsPZ;
/*     */   ImageIcon[] icons;
/*     */   Thread mainProcess;
/*     */   ImagePlus impAnal;
/*  70 */   static String command = ""; static String spotEnable = ""; List<Spot> removedSpots; List<Spot> spots;
/*     */   JSpinner filterMin;
/*     */   JSpinner filterMax;
/*     */   ChartPanel histogram;
/*  74 */   HistogramFilterVersion hs2 = new HistogramFilterVersion();
/*     */   
/*     */   IntervalMarker intervalMarker;
/*     */   JCheckBox checkRPicker;
/*     */   static JList<String> classList;
/*     */   static JList<String> featureList;
/*     */   static DefaultListModel<String> modelListClass;
/*     */   static DefaultListModel<String> modelListFeature;
/*     */   static JComboBox<String> comboFilters;
/*     */   static JLabel labelReset;
/*     */   List<Integer> indexesToReset;
/*     */   
/*     */   public FirstWizardPanel(JWizardComponents wizardComponents) {
/*  87 */     super(wizardComponents, "");
/*     */ 
/*     */     
/*  90 */     File imageFolder = new File(SLTDisplayer_.textImages.getText());
/*  91 */     File[] listOfFiles = imageFolder.listFiles();
/*  92 */     String[] imageTitles = new String[listOfFiles.length];
/*  93 */     File[] filesXML = new File[listOfFiles.length];
/*     */     
/*  95 */     for (int u = 0; u < filesXML.length; u++) {
/*  96 */       filesXML[u] = new File(SLTDisplayer_.textXml.getText());
/*     */     }
/*  98 */     impsPZ = new ImagePlus[imageTitles.length];
/*  99 */     imps = new ImagePlus[imageTitles.length];
/* 100 */     this.icons = new ImageIcon[imps.length];
/* 101 */     for (int i = 0; i < listOfFiles.length; i++) {
/* 102 */       if (listOfFiles[i].isFile())
/* 103 */         imageTitles[i] = listOfFiles[i].getName(); 
/* 104 */       imps[i] = IJ.openImage(String.valueOf(SLTDisplayer_.textImages.getText()) + "/" + imageTitles[i]);
/* 105 */       impsPZ[i] = extractTFrame(imps[i], 1);
/*     */       
/* 107 */       this.icons[i] = new ImageIcon(getScaledImage(impsPZ[i].getImage(), 90, 95));
/*     */     } 
/*     */     
/* 110 */     tableImages = new JTable();
/*     */     
/* 112 */     tableSpot = new JTable();
/* 113 */     modelImages = new DefaultTableModel();
/* 114 */     modelSpot = new DefaultTableModel();
/* 115 */     Object[] columnNames = { "Movie", "Title", "Extension" };
/* 116 */     columnNamesSpot = new Object[] { "ID", "TRACK_ID", "QUALITY", "POSITION_X", "POSITION_Y", "POSITION_Z", 
/* 117 */         "POSITION_T", "FRAME", "RADIUS", "VISIBILITY", "MEAN_INTENSITY", "MEDIAN_INTENSITY", "MIN_INTENSITY", 
/* 118 */         "MAX_INTENSITY", "TOTAL_INTENSITY", "STANDARD_DEVIATION", "CONTRAST", "SNR", "ESTIMATED_DIAMETER", 
/* 119 */         "MORPHOLOGY", "ELLIPSOIDFIT_SEMIAXISLENGTH_C", "ELLIPSOIDFIT_SEMIAXISLENGTH_B", 
/* 120 */         "ELLIPSOIDFIT_SEMIAXISLENGTH_A", "ELLIPSOIDFIT_AXISPHI_C", "ELLIPSOIDFIT_AXISPHI_B", 
/* 121 */         "ELLIPSOIDFIT_AXISPHI_A", "ELLIPSOIDFIT_AXISTHETA_C", "ELLIPSOIDFIT_AXISTHETA_B", 
/* 122 */         "ELLIPSOIDFIT_AXISTHETA_A", "MANUAL_COLOR" };
/* 123 */     Object[][] data = new Object[imps.length][columnNames.length];
/* 124 */     for (int j = 0; j < data.length; j++) {
/* 125 */       for (int m = 0; m < (data[j]).length; m++)
/* 126 */         data[j][m] = ""; 
/*     */     } 
/* 128 */     modelSpot = new DefaultTableModel();
/* 129 */     modelImages = new DefaultTableModel(data, columnNames)
/*     */       {
/*     */         public Class<?> getColumnClass(int column)
/*     */         {
/* 133 */           if (getRowCount() > 0) {
/* 134 */             Object value = getValueAt(0, column);
/* 135 */             if (value != null) {
/* 136 */               return getValueAt(0, column).getClass();
/*     */             }
/*     */           } 
/*     */           
/* 140 */           return super.getColumnClass(column);
/*     */         }
/*     */       };
/*     */     
/* 144 */     tableImages.setModel(modelImages);
/* 145 */     tableSpot.setModel(modelSpot);
/* 146 */     tableSpot.setSelectionMode(1);
/* 147 */     tableImages.getColumnModel().getColumn(0).setPreferredWidth(90);
/* 148 */     tableImages.getColumnModel().getColumn(1).setPreferredWidth(460);
/* 149 */     tableImages.getColumnModel().getColumn(2).setPreferredWidth(80);
/* 150 */     jScrollPaneImages = new JScrollPane(tableImages);
/* 151 */     jScrollPaneSpot = new JScrollPane(tableSpot);
/* 152 */     jScrollPaneImages.setPreferredSize(new Dimension(590, 240));
/* 153 */     jScrollPaneSpot.setPreferredSize(new Dimension(590, 240));
/* 154 */     JPanel mainPanel = new JPanel();
/* 155 */     mainPanel.setLayout(new BoxLayout(mainPanel, 1));
/* 156 */     jScrollPaneImages.setBorder(BorderFactory.createTitledBorder(""));
/* 157 */     jScrollPaneSpot.setBorder(BorderFactory.createTitledBorder(""));
/* 158 */     JTabbedPane tabbedPaneSpot = new JTabbedPane(1);
/* 159 */     ImageIcon iconSpot = createImageIcon("images/spot.png");
/* 160 */     iconSpotCell = new ImageIcon(iconSpot.getImage().getScaledInstance(18, 20, 4));
/* 161 */     tabbedPaneSpot.addTab("SPOTS             ", iconSpotCell, mainPanel, "Display Spot Analysis");
/* 162 */     tabbedPaneSpot.setTabLayoutPolicy(1);
/* 163 */     JButton refreshButton = new JButton();
/* 164 */     ImageIcon iconRefresh = createImageIcon("images/refresh.png");
/* 165 */     refreshCell = new ImageIcon(iconRefresh.getImage().getScaledInstance(18, 20, 4));
/* 166 */     refreshButton.setIcon(refreshCell);
/* 167 */     refreshButton.setToolTipText("Click this button to get spot analysis");
/* 168 */     JToggleButton paintButton = new JToggleButton();
/* 169 */     ImageIcon iconPaint = createImageIcon("images/paint.png");
/* 170 */     Icon paintCell = new ImageIcon(iconPaint.getImage().getScaledInstance(18, 20, 4));
/* 171 */     paintButton.setIcon(paintCell);
/* 172 */     paintButton.setToolTipText("Click this button to display labeled-spots");
/* 173 */     JToggleButton tInsideButton = new JToggleButton();
/* 174 */     ImageIcon iconTI = createImageIcon("images/tinside.png");
/* 175 */     Icon TICell = new ImageIcon(iconTI.getImage().getScaledInstance(18, 20, 4));
/* 176 */     tInsideButton.setIcon(TICell);
/* 177 */     tInsideButton.setToolTipText("Click this button to toggle inside spots.");
/* 178 */     JToggleButton tOutsideButton = new JToggleButton();
/* 179 */     ImageIcon iconTO = createImageIcon("images/toutside.png");
/* 180 */     Icon TOCell = new ImageIcon(iconTO.getImage().getScaledInstance(18, 20, 4));
/* 181 */     tOutsideButton.setIcon(TOCell);
/* 182 */     tOutsideButton.setToolTipText("Click this button to toggle outside spots.");
/* 183 */     JButton enableButton = new JButton();
/* 184 */     ImageIcon iconEnable = createImageIcon("images/enable.png");
/* 185 */     Icon enableCell = new ImageIcon(iconEnable.getImage().getScaledInstance(18, 20, 4));
/* 186 */     enableButton.setIcon(enableCell);
/* 187 */     enableButton.setToolTipText("Click this button to enable your selection");
/* 188 */     JButton disableButton = new JButton();
/* 189 */     ImageIcon iconDisable = createImageIcon("images/disable.png");
/* 190 */     Icon disableCell = new ImageIcon(iconDisable.getImage().getScaledInstance(18, 20, 4));
/* 191 */     disableButton.setIcon(disableCell);
/* 192 */     disableButton.setToolTipText("Click this button to disable your selection");
/* 193 */     JPanel buttonPanel = new JPanel(new FlowLayout(2));
/* 194 */     JSeparator separator1 = new JSeparator(1);
/* 195 */     JSeparator separator2 = new JSeparator(1);
/* 196 */     Dimension dime = separator1.getPreferredSize();
/* 197 */     dime.height = (refreshButton.getPreferredSize()).height;
/* 198 */     separator1.setPreferredSize(dime);
/* 199 */     separator2.setPreferredSize(dime);
/* 200 */     this.checkRPicker = new JCheckBox(" Spot Picker");
/* 201 */     JLabel filterLabel = new JLabel("  ➠ Spot Analysis : ");
/* 202 */     filterLabel.setFont(new Font("Dialog", 1, 13));
/* 203 */     filterLabel.setBorder(BorderFactory.createRaisedBevelBorder());
/* 204 */     JPanel filterPanel = new JPanel(new FlowLayout(0));
/* 205 */     filterPanel.add(filterLabel);
/* 206 */     filterPanel.add(this.checkRPicker);
/* 207 */     filterPanel.add(Box.createHorizontalStrut(20));
/* 208 */     JPanel filterMain = new JPanel(new FlowLayout(0));
/* 209 */     filterMain.add(filterPanel);
/* 210 */     buttonPanel.add(refreshButton);
/* 211 */     buttonPanel.add(paintButton);
/* 212 */     buttonPanel.add(separator1);
/* 213 */     buttonPanel.add(enableButton);
/* 214 */     buttonPanel.add(disableButton);
/* 215 */     buttonPanel.add(separator2);
/* 216 */     buttonPanel.add(tInsideButton);
/* 217 */     buttonPanel.add(tOutsideButton);
/* 218 */     filterMain.add(buttonPanel);
/* 219 */     mainPanel.add(jScrollPaneImages);
/* 220 */     mainPanel.add(Box.createVerticalStrut(5));
/* 221 */     mainPanel.add(filterMain);
/* 222 */     mainPanel.add(jScrollPaneSpot);
/* 223 */     JLabel settingsLabel = new JLabel("  ➠ Settings for Filters/Classes : ");
/* 224 */     settingsLabel.setFont(new Font("Dialog", 1, 13));
/* 225 */     settingsLabel.setBorder(BorderFactory.createRaisedBevelBorder());
/* 226 */     JPanel settingsPanel = new JPanel(new FlowLayout(0));
/* 227 */     settingsPanel.add(settingsLabel);
/* 228 */     mainPanel.add(settingsPanel);
/* 229 */     JPanel filtersMin = new JPanel(new FlowLayout(0));
/* 230 */     this.filterMin = new JSpinner(new SpinnerNumberModel(30, 0, 5000, 1));
/* 231 */     this.filterMin.setPreferredSize(new Dimension(60, 20));
/* 232 */     final JSlider sliderMin = new JSlider(0, 300, 50);
/* 233 */     sliderMin.setPreferredSize(new Dimension(150, 15));
/* 234 */     JLabel filterMinLabel = new JLabel("              Min :  ");
/* 235 */     filtersMin.add(filterMinLabel);
/* 236 */     filtersMin.add(sliderMin);
/* 237 */     filtersMin.add(Box.createHorizontalStrut(2));
/* 238 */     filtersMin.add(this.filterMin);
/* 239 */     JPanel filtersMax = new JPanel(new FlowLayout(0));
/* 240 */     this.filterMax = new JSpinner(new SpinnerNumberModel(200, 0, 5000, 1));
/* 241 */     this.filterMax.setPreferredSize(new Dimension(60, 20));
/* 242 */     final JSlider sliderMax = new JSlider(0, 300, 150);
/* 243 */     sliderMax.setPreferredSize(new Dimension(150, 15));
/* 244 */     JLabel filterMaxLabel = new JLabel("              Max :  ");
/* 245 */     filtersMax.add(filterMaxLabel);
/* 246 */     filtersMax.add(sliderMax);
/* 247 */     filtersMax.add(Box.createHorizontalStrut(2));
/* 248 */     filtersMax.add(this.filterMax);
/* 249 */     JPanel boxPanel2 = new JPanel();
/* 250 */     boxPanel2.setLayout(new BoxLayout(boxPanel2, 1));
/* 251 */     final IntervalMarker intervalMarker = new IntervalMarker(0.0D, 0.0D, new Color(229, 255, 204), new BasicStroke(), 
/* 252 */         new Color(0, 102, 0), new BasicStroke(1.5F), 0.5F);
/* 253 */     this.histogram = this.hs2.createChartPanel("", new double[] { 0.0D, 0.0D, 0.0D }, 100, intervalMarker);
/*     */     
/* 255 */     JPanel chartPanel2 = new JPanel(new BorderLayout());
/* 256 */     chartPanel2.setPreferredSize(new Dimension(390, 180));
/* 257 */     chartPanel2.add((Component)this.histogram);
/* 258 */     boxPanel2.add(chartPanel2);
/* 259 */     JPanel controlPanel2 = this.hs2.createControlPanel();
/* 260 */     boxPanel2.add(controlPanel2);
/* 261 */     JPanel filtersMain2 = new JPanel();
/* 262 */     filtersMain2.setLayout(new BoxLayout(filtersMain2, 1));
/* 263 */     filtersMain2.add(boxPanel2);
/* 264 */     filtersMain2.add(filtersMin);
/* 265 */     filtersMain2.add(filtersMax);
/* 266 */     JLabel featureSpot = new JLabel(" » Spot-Features :  ");
/* 267 */     featureSpot.setFont(new Font("Dialog", 1, 13));
/* 268 */     comboFilters = new JComboBox<>();
/* 269 */     for (int k = 0; k < columnNamesSpot.length; k++)
/* 270 */       comboFilters.addItem((String)columnNamesSpot[k]); 
/* 271 */     comboFilters.setPreferredSize(new Dimension(130, 25));
/* 272 */     comboFilters.setSelectedIndex(0);
/* 273 */     comboFilters.setOpaque(true);
/* 274 */     JPanel panelFilters = new JPanel(new FlowLayout(0));
/* 275 */     JSeparator separator3 = new JSeparator(1);
/* 276 */     Dimension dime2 = separator3.getPreferredSize();
/* 277 */     dime2.height = (filtersMain2.getPreferredSize()).height;
/* 278 */     separator3.setPreferredSize(dime2);
/* 279 */     panelFilters.add(filtersMain2);
/* 280 */     panelFilters.add(separator3);
/* 281 */     modelListClass = new DefaultListModel<>();
/* 282 */     classList = new JList<>(modelListClass);
/* 283 */     modelListFeature = new DefaultListModel<>();
/* 284 */     featureList = new JList<>(modelListFeature);
/* 285 */     final ColorEditorSpot colorEditor = new ColorEditorSpot(featureList);
/* 286 */     JScrollPane scrollListFilter = new JScrollPane(featureList);
/* 287 */     JScrollPane scrollListClass = new JScrollPane(classList);
/* 288 */     Dimension d = featureList.getPreferredSize();
/* 289 */     d.width = 150;
/* 290 */     d.height = 90;
/* 291 */     scrollListFilter.setPreferredSize(d);
/* 292 */     scrollListClass.setPreferredSize(d);
/* 293 */     JPanel filterPanelButtons = new JPanel(new FlowLayout(0));
/* 294 */     JPanel classPanelButtons = new JPanel();
/* 295 */     classPanelButtons.setLayout(new BoxLayout(classPanelButtons, 1));
/* 296 */     filterPanelButtons.add(scrollListFilter);
/* 297 */     JPanel fButtonsPanel = new JPanel();
/* 298 */     fButtonsPanel.setLayout(new BoxLayout(fButtonsPanel, 1));
/* 299 */     JButton addButton = new JButton();
/* 300 */     ImageIcon iconAdd = createImageIcon("images/add.png");
/* 301 */     Icon addCell = new ImageIcon(iconAdd.getImage().getScaledInstance(14, 16, 4));
/* 302 */     addButton.setIcon(addCell);
/* 303 */     addButton.setToolTipText("Click this button to add features");
/* 304 */     JButton remButton = new JButton();
/* 305 */     ImageIcon iconRem = createImageIcon("images/remove.png");
/* 306 */     Icon remCell = new ImageIcon(iconRem.getImage().getScaledInstance(14, 16, 4));
/* 307 */     remButton.setIcon(remCell);
/* 308 */     remButton.setToolTipText("Click this button to remove features");
/* 309 */     JButton classButton = new JButton();
/* 310 */     ImageIcon iconClass = createImageIcon("images/classes.png");
/* 311 */     Icon classCell = new ImageIcon(iconClass.getImage().getScaledInstance(14, 16, 4));
/* 312 */     classButton.setIcon(classCell);
/* 313 */     classButton.setToolTipText("Click this button to create a class.");
/* 314 */     JButton remClassButton = new JButton();
/* 315 */     remClassButton.setIcon(remCell);
/* 316 */     remClassButton.setToolTipText("Click this button to remove a class.");
/* 317 */     fButtonsPanel.add(addButton);
/* 318 */     fButtonsPanel.add(remButton);
/* 319 */     filterPanelButtons.add(fButtonsPanel);
/* 320 */     classPanelButtons.add(classButton);
/* 321 */     classPanelButtons.add(remClassButton);
/* 322 */     JPanel classPanel = new JPanel(new FlowLayout(0));
/* 323 */     classPanel.add(scrollListClass);
/* 324 */     classPanel.add(classPanelButtons);
/* 325 */     JPanel boxPanel = new JPanel();
/* 326 */     boxPanel.setLayout(new BoxLayout(boxPanel, 1));
/* 327 */     boxPanel.add(comboFilters);
/* 328 */     boxPanel.add(Box.createHorizontalStrut(5));
/* 329 */     boxPanel.add(filterPanelButtons);
/* 330 */     boxPanel.add(Box.createHorizontalStrut(5));
/* 331 */     boxPanel.add(classPanel);
/* 332 */     panelFilters.add(boxPanel);
/* 333 */     mainPanel.add(panelFilters);
/* 334 */     add(tabbedPaneSpot);
/* 335 */     createMovieTable();
/*     */     
/* 337 */     refreshButton.addActionListener(new ActionListener()
/*     */         {
/*     */           public void actionPerformed(ActionEvent e) {
/* 340 */             FirstWizardPanel.spotEnable = "spotEnable";
/* 341 */             ProcessTrackMateXml.tracksVisible = false;
/* 342 */             ProcessTrackMateXml.spotsVisible = true;
/* 343 */             ProcessTrackMateXml ptx = new ProcessTrackMateXml();
/* 344 */             ptx.processTrackMateXml();
/*     */           }
/*     */         });
/*     */     
/* 348 */     paintButton.addItemListener(new ItemListener() {
/*     */           public void itemStateChanged(ItemEvent ev) {
/* 350 */             if (ev.getStateChange() == 1) {
/* 351 */               FirstWizardPanel.this.paintAndDisableAction();
/* 352 */             } else if (ev.getStateChange() == 2) {
/* 353 */               FirstWizardPanel.this.resetAndEnableAction();
/*     */             } 
/*     */           }
/*     */         });
/* 357 */     tInsideButton.addItemListener(new ItemListener() {
/*     */           public void itemStateChanged(ItemEvent ev) {
/* 359 */             if (ev.getStateChange() == 1) {
/* 360 */               FirstWizardPanel.this.toggleInsideAction();
/* 361 */             } else if (ev.getStateChange() == 2) {
/* 362 */               FirstWizardPanel.this.resetToggleInsideAction();
/*     */             } 
/*     */           }
/*     */         });
/* 366 */     tOutsideButton.addItemListener(new ItemListener() {
/*     */           public void itemStateChanged(ItemEvent ev) {
/* 368 */             if (ev.getStateChange() == 1) {
/* 369 */               FirstWizardPanel.this.toggleOutsideAction();
/* 370 */             } else if (ev.getStateChange() == 2) {
/* 371 */               FirstWizardPanel.this.resetToggleOutsideAction();
/*     */             } 
/*     */           }
/*     */         });
/* 375 */     enableButton.addActionListener(new ActionListener()
/*     */         {
/*     */           public void actionPerformed(ActionEvent e) {
/* 378 */             FirstWizardPanel.this.enableSpots();
/*     */           }
/*     */         });
/*     */     
/* 382 */     disableButton.addActionListener(new ActionListener()
/*     */         {
/*     */           public void actionPerformed(ActionEvent e) {
/* 385 */             FirstWizardPanel.this.disableSpots();
/*     */           }
/*     */         });
/*     */     
/* 389 */     sliderMin.addChangeListener(new ChangeListener()
/*     */         {
/*     */           public void stateChanged(ChangeEvent e)
/*     */           {
/* 393 */             FirstWizardPanel.this.filterMin.setValue(Integer.valueOf(sliderMin.getValue()));
/* 394 */             intervalMarker.setStartValue(sliderMin.getValue());
/*     */           }
/*     */         });
/*     */ 
/*     */     
/* 399 */     this.filterMin.addChangeListener(new ChangeListener()
/*     */         {
/*     */           public void stateChanged(ChangeEvent e) {
/* 402 */             sliderMin.setValue(((Integer)FirstWizardPanel.this.filterMin.getValue()).intValue());
/* 403 */             intervalMarker.setStartValue(((Integer)FirstWizardPanel.this.filterMin.getValue()).intValue());
/*     */           }
/*     */         });
/*     */ 
/*     */     
/* 408 */     sliderMax.addChangeListener(new ChangeListener()
/*     */         {
/*     */           public void stateChanged(ChangeEvent e) {
/* 411 */             FirstWizardPanel.this.filterMax.setValue(Integer.valueOf(sliderMax.getValue()));
/* 412 */             intervalMarker.setEndValue(sliderMax.getValue());
/*     */           }
/*     */         });
/*     */     
/* 416 */     this.filterMax.addChangeListener(new ChangeListener()
/*     */         {
/*     */           public void stateChanged(ChangeEvent e) {
/* 419 */             sliderMax.setValue(((Integer)FirstWizardPanel.this.filterMax.getValue()).intValue());
/* 420 */             intervalMarker.setEndValue(((Integer)FirstWizardPanel.this.filterMax.getValue()).intValue());
/*     */           }
/*     */         });
/*     */     
/* 424 */     comboFilters.addActionListener(new ActionListener() {
/*     */           public void actionPerformed(ActionEvent e) {
/* 426 */             String selectedName = (String)FirstWizardPanel.comboFilters.getSelectedItem();
/* 427 */             int selectedIndex = FirstWizardPanel.comboFilters.getSelectedIndex();
/* 428 */             double[] values = null;
/*     */ 
/*     */             
/* 431 */             values = new double[FirstWizardPanel.tableSpot.getRowCount()];
/* 432 */             for (int r = 0; r < FirstWizardPanel.tableSpot.getRowCount(); r++) {
/* 433 */               for (int c = 0; c < FirstWizardPanel.tableSpot.getColumnCount(); c++)
/* 434 */                 values[r] = Double.parseDouble((String)FirstWizardPanel.tableSpot.getValueAt(r, selectedIndex + 2)); 
/*     */             } 
/* 436 */             double max = values[0];
/* 437 */             for (int i = 1; i < values.length; i++) {
/* 438 */               if (values[i] > max)
/* 439 */                 max = values[i]; 
/*     */             } 
/* 441 */             sliderMin.setMinimum(0);
/* 442 */             sliderMin.setMaximum((int)max);
/* 443 */             sliderMax.setMinimum(0);
/* 444 */             sliderMax.setMaximum((int)max);
/*     */             
/* 446 */             FirstWizardPanel.this.hs2.addHistogramSeries(selectedName, values, (int)max, intervalMarker);
/*     */           }
/*     */         });
/*     */     
/* 450 */     this.checkRPicker.addItemListener(new ItemListener()
/*     */         {
/*     */           public void itemStateChanged(ItemEvent e)
/*     */           {
/* 454 */             if (e.getStateChange() == 1)
/* 455 */               FirstWizardPanel.command = "enable"; 
/* 456 */             if (e.getStateChange() == 2) {
/* 457 */               FirstWizardPanel.command = null;
/* 458 */               ProcessTrackMateXml.selectionModel.clearSpotSelection();
/* 459 */               ProcessTrackMateXml.selectionModel.clearSelection();
/*     */               
/*     */               return;
/*     */             } 
/*     */           }
/*     */         });
/* 465 */     classButton.addActionListener(new ActionListener()
/*     */         {
/*     */           public void actionPerformed(ActionEvent e) {
/* 468 */             ColorEditorSpot.myFrame.setVisible(true);
/* 469 */             colorEditor.setClassAction();
/*     */           }
/*     */         });
/*     */     
/* 473 */     remClassButton.addActionListener(new ActionListener()
/*     */         {
/*     */           public void actionPerformed(ActionEvent e)
/*     */           {
/* 477 */             String classSelectedValue = FirstWizardPanel.classList.getSelectedValue();
/* 478 */             int[] classSelectedIndex = FirstWizardPanel.classList.getSelectedIndices(); int i;
/* 479 */             for (i = 0; i < FirstWizardPanel.modelSpot.getRowCount(); i++) {
/* 480 */               if (((JLabel)FirstWizardPanel.modelSpot.getValueAt(i, FirstWizardPanel.tableSpot.convertColumnIndexToModel(1))).getText()
/* 481 */                 .equals(classSelectedValue))
/* 482 */                 FirstWizardPanel.modelSpot.setValueAt(FirstWizardPanel.labelReset, i, FirstWizardPanel.tableSpot.convertColumnIndexToModel(1)); 
/*     */             } 
/* 484 */             for (i = 0; i < classSelectedIndex.length; i++) {
/* 485 */               FirstWizardPanel.modelListClass.removeElementAt(classSelectedIndex[i]);
/*     */             }
/*     */           }
/*     */         });
/*     */     
/* 490 */     addButton.addActionListener(new ActionListener()
/*     */         {
/*     */           public void actionPerformed(ActionEvent e)
/*     */           {
/* 494 */             List<String> listFilters = new ArrayList<>();
/*     */             
/* 496 */             if (FirstWizardPanel.featureList.getModel().getSize() < 1) {
/* 497 */               FirstWizardPanel.modelListFeature.addElement(String.valueOf(FirstWizardPanel.comboFilters.getSelectedItem()) + ":  [" + FirstWizardPanel.this.filterMin.getValue() + 
/* 498 */                   "," + FirstWizardPanel.this.filterMax.getValue() + "]");
/*     */             }
/* 500 */             if (FirstWizardPanel.featureList.getModel().getSize() >= 1) {
/* 501 */               for (int i = 0; i < FirstWizardPanel.featureList.getModel().getSize(); i++) {
/* 502 */                 listFilters.add(String.valueOf(((String)FirstWizardPanel.featureList.getModel().getElementAt(i)).substring(0, (
/* 503 */                         (String)FirstWizardPanel.featureList.getModel().getElementAt(i)).lastIndexOf(":"))));
/*     */               }
/* 505 */               if (!listFilters.contains(FirstWizardPanel.comboFilters.getSelectedItem().toString())) {
/* 506 */                 FirstWizardPanel.modelListFeature.addElement(String.valueOf(FirstWizardPanel.comboFilters.getSelectedItem()) + ":  [" + 
/* 507 */                     FirstWizardPanel.this.filterMin.getValue() + "," + FirstWizardPanel.this.filterMax.getValue() + "]");
/*     */               }
/* 509 */               if (listFilters.contains(FirstWizardPanel.comboFilters.getSelectedItem().toString())) {
/*     */                 return;
/*     */               }
/*     */             } 
/*     */           }
/*     */         });
/*     */ 
/*     */     
/* 517 */     remButton.addActionListener(new ActionListener()
/*     */         {
/*     */           public void actionPerformed(ActionEvent e)
/*     */           {
/*     */             try {
/* 522 */               int[] indexes = FirstWizardPanel.featureList.getSelectedIndices();
/* 523 */               for (int i = 0; i < indexes.length; i++)
/* 524 */                 FirstWizardPanel.modelListFeature.remove(indexes[i]); 
/* 525 */             } catch (Exception e1) {
/* 526 */               e1.printStackTrace();
/*     */             } 
/*     */           }
/*     */         });
/*     */   }
/*     */   List<Integer> spotID; List<Integer> spotIDTI; List<Integer> spotIDTO; List<Integer> indexesTI; List<Integer> indexesTO; static JScrollPane jScrollPaneImages; static JScrollPane jScrollPaneSpot; static Icon iconSpotCell; static Icon refreshCell;
/*     */   static Object[] columnNamesSpot;
/*     */   
/*     */   public void toggleOutsideAction() {
/* 535 */     Roi mainRoi = null;
/* 536 */     if (IJ.getImage().getRoi().getType() == 0)
/* 537 */       mainRoi = IJ.getImage().getRoi(); 
/* 538 */     this.indexesTO = new ArrayList<>();
/* 539 */     for (int i = 0; i < modelSpot.getRowCount(); i++) {
/* 540 */       if (mainRoi
/* 541 */         .contains(
/*     */           
/* 543 */           (int)IJ.getImage().getCalibration().getRawX(
/* 544 */             Double.parseDouble(
/* 545 */               modelSpot.getValueAt(i, tableSpot.convertColumnIndexToModel(5))
/* 546 */               .toString())), 
/* 547 */           (int)IJ.getImage().getCalibration().getRawY(
/* 548 */             Double.parseDouble(modelSpot.getValueAt(i, tableSpot.convertColumnIndexToModel(6))
/* 549 */               .toString()))) == Boolean.FALSE.booleanValue()) {
/* 550 */         this.indexesTO.add(Integer.valueOf(i));
/* 551 */         modelSpot.setValueAt(Boolean.valueOf(false), i, tableSpot.convertColumnIndexToModel(0));
/* 552 */         int spotID = Integer.parseInt((String)tableSpot.getValueAt(i, 2));
/* 553 */         Spot spot = ProcessTrackMateXml.model.getSpots().search(spotID);
/*     */         
/* 555 */         if (spot != null) {
/* 556 */           spot.putFeature("VISIBILITY", SpotCollection.ZERO);
/* 557 */           ProcessTrackMateXml.model.endUpdate();
/* 558 */           ProcessTrackMateXml.displayer.refresh();
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void resetToggleOutsideAction() {
/* 567 */     for (int row = 0; row < modelSpot.getRowCount(); row++) {
/* 568 */       modelSpot.setValueAt(Boolean.valueOf(true), tableSpot.convertRowIndexToModel(row), tableSpot.convertColumnIndexToModel(0));
/* 569 */       int spotID = Integer.parseInt((String)tableSpot.getValueAt(row, 2));
/* 570 */       Spot spot = ProcessTrackMateXml.model.getSpots().search(spotID);
/* 571 */       if (spot != null) {
/* 572 */         spot.putFeature("VISIBILITY", SpotCollection.ONE);
/* 573 */         ProcessTrackMateXml.model.endUpdate();
/* 574 */         ProcessTrackMateXml.displayer.refresh();
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void toggleInsideAction() {
/* 583 */     Roi mainRoi = null;
/* 584 */     if (IJ.getImage().getRoi().getType() == 0)
/* 585 */       mainRoi = IJ.getImage().getRoi(); 
/* 586 */     this.indexesTI = new ArrayList<>();
/* 587 */     for (int i = 0; i < modelSpot.getRowCount(); i++) {
/* 588 */       if (mainRoi
/* 589 */         .contains(
/*     */           
/* 591 */           (int)IJ.getImage().getCalibration().getRawX(
/* 592 */             Double.parseDouble(
/* 593 */               modelSpot.getValueAt(i, tableSpot.convertColumnIndexToModel(5))
/* 594 */               .toString())), 
/* 595 */           (int)IJ.getImage().getCalibration().getRawY(
/* 596 */             Double.parseDouble(modelSpot.getValueAt(i, tableSpot.convertColumnIndexToModel(6))
/* 597 */               .toString()))) == Boolean.TRUE.booleanValue()) {
/* 598 */         this.indexesTI.add(Integer.valueOf(i));
/* 599 */         modelSpot.setValueAt(Boolean.valueOf(false), i, tableSpot.convertColumnIndexToModel(0));
/* 600 */         int spotID = Integer.parseInt((String)tableSpot.getValueAt(i, 2));
/* 601 */         Spot spot = ProcessTrackMateXml.model.getSpots().search(spotID);
/*     */         
/* 603 */         if (spot != null) {
/* 604 */           spot.putFeature("VISIBILITY", SpotCollection.ZERO);
/* 605 */           ProcessTrackMateXml.model.endUpdate();
/* 606 */           ProcessTrackMateXml.displayer.refresh();
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void resetToggleInsideAction() {
/* 616 */     for (int row = 0; row < modelSpot.getRowCount(); row++) {
/* 617 */       modelSpot.setValueAt(Boolean.valueOf(true), tableSpot.convertRowIndexToModel(row), tableSpot.convertColumnIndexToModel(0));
/* 618 */       int spotID = Integer.parseInt((String)tableSpot.getValueAt(row, 2));
/* 619 */       Spot spot = ProcessTrackMateXml.model.getSpots().search(spotID);
/* 620 */       if (spot != null) {
/* 621 */         spot.putFeature("VISIBILITY", SpotCollection.ONE);
/* 622 */         ProcessTrackMateXml.model.endUpdate();
/* 623 */         ProcessTrackMateXml.displayer.refresh();
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void paintAndDisableAction() {
/* 631 */     this.indexesToReset = new ArrayList<>();
/* 632 */     this.spotID = new ArrayList<>();
/* 633 */     this.spots = new ArrayList<>();
/* 634 */     for (int i = 0; i < modelSpot.getRowCount(); i++) {
/* 635 */       if (((JLabel)modelSpot.getValueAt(i, tableSpot.convertColumnIndexToModel(1))).getBackground()
/* 636 */         .equals(new Color(214, 217, 223)) == Boolean.TRUE.booleanValue()) {
/* 637 */         this.indexesToReset.add(Integer.valueOf(i));
/* 638 */         modelSpot.setValueAt(Boolean.valueOf(false), i, tableSpot.convertColumnIndexToModel(0));
/* 639 */         this.spotID.add(Integer.valueOf(Integer.parseInt((String)tableSpot.getValueAt(i, 2))));
/*     */       } 
/* 641 */     }  for (int row = 0; row < this.indexesToReset.size(); row++) {
/* 642 */       int spotID = Integer.parseInt((String)tableSpot.getValueAt(((Integer)this.indexesToReset.get(row)).intValue(), 2));
/* 643 */       Spot spot = ProcessTrackMateXml.model.getSpots().search(spotID);
/* 644 */       if (spot != null) {
/* 645 */         spot.putFeature("VISIBILITY", SpotCollection.ZERO);
/* 646 */         ProcessTrackMateXml.model.endUpdate();
/* 647 */         ProcessTrackMateXml.displayer.refresh();
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void resetAndEnableAction() {
/* 655 */     for (int i = 0; i < this.indexesToReset.size(); i++)
/* 656 */       modelSpot.setValueAt(Boolean.valueOf(true), tableSpot.convertRowIndexToModel(((Integer)this.indexesToReset.get(i)).intValue()), 
/* 657 */           tableSpot.convertColumnIndexToModel(0)); 
/* 658 */     for (int row = 0; row < this.indexesToReset.size(); row++) {
/* 659 */       int spotID = Integer.parseInt((String)tableSpot.getValueAt(((Integer)this.indexesToReset.get(row)).intValue(), 2));
/* 660 */       Spot spot = ProcessTrackMateXml.model.getSpots().search(spotID);
/* 661 */       if (spot != null) {
/* 662 */         spot.putFeature("VISIBILITY", SpotCollection.ONE);
/* 663 */         ProcessTrackMateXml.model.endUpdate();
/* 664 */         ProcessTrackMateXml.displayer.refresh();
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void enableSpots() {
/* 673 */     ListSelectionModel lsm = tableSpot.getSelectionModel();
/* 674 */     int[] selectedIndices = tableSpot.getSelectedRows();
/* 675 */     for (int i = 0; i < selectedIndices.length; i++)
/* 676 */       tableSpot.setValueAt(Boolean.valueOf(true), selectedIndices[i], 0); 
/* 677 */     int selStart = lsm.getMinSelectionIndex();
/* 678 */     int selEnd = lsm.getMaxSelectionIndex();
/* 679 */     if (selStart < 0 || selEnd < 0) {
/*     */       return;
/*     */     }
/* 682 */     int minLine = Math.min(selStart, selEnd);
/* 683 */     int maxLine = Math.max(selStart, selEnd);
/* 684 */     for (int row = minLine; row <= maxLine; row++) {
/* 685 */       int spotIDEnable = Integer.parseInt((String)tableSpot.getValueAt(row, 2));
/* 686 */       Spot spotEnable = ProcessTrackMateXml.model.getSpots().search(spotIDEnable);
/* 687 */       if (spotEnable != null) {
/* 688 */         spotEnable.putFeature("VISIBILITY", SpotCollection.ONE);
/* 689 */         ProcessTrackMateXml.model.endUpdate();
/* 690 */         ProcessTrackMateXml.displayer.refresh();
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void disableSpots() {
/* 698 */     ListSelectionModel lsm = tableSpot.getSelectionModel();
/* 699 */     int selStart = lsm.getMinSelectionIndex();
/* 700 */     int selEnd = lsm.getMaxSelectionIndex();
/* 701 */     if (selStart < 0 || selEnd < 0) {
/*     */       return;
/*     */     }
/* 704 */     int minLine = Math.min(selStart, selEnd);
/* 705 */     int maxLine = Math.max(selStart, selEnd);
/* 706 */     for (int row = minLine; row <= maxLine; row++) {
/* 707 */       int spotID = Integer.parseInt((String)tableSpot.getValueAt(row, 2));
/* 708 */       Spot spot = ProcessTrackMateXml.model.getSpots().search(spotID);
/* 709 */       if (spot != null) {
/* 710 */         spot.putFeature("VISIBILITY", SpotCollection.ZERO);
/* 711 */         ProcessTrackMateXml.model.endUpdate();
/* 712 */         ProcessTrackMateXml.displayer.refresh();
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 717 */     int[] selectedIndices = tableSpot.getSelectedRows();
/* 718 */     for (int i = 0; i < selectedIndices.length; i++) {
/* 719 */       tableSpot.setValueAt(Boolean.valueOf(false), selectedIndices[i], 0);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void createSpotTable() {
/* 727 */     modelSpot = new DefaultTableModel((Object[][])ProcessTrackMateXml.dataSpot, (Object[])ProcessTrackMateXml.columnHeadersSpot)
/*     */       {
/*     */         public Class<?> getColumnClass(int column)
/*     */         {
/* 731 */           if (getRowCount() > 0) {
/* 732 */             Object value = getValueAt(0, column);
/* 733 */             if (value != null) {
/* 734 */               return getValueAt(0, column).getClass();
/*     */             }
/*     */           } 
/*     */           
/* 738 */           return super.getColumnClass(column);
/*     */         }
/*     */       };
/*     */     
/* 742 */     modelSpot.addColumn("Enable");
/* 743 */     tableSpot.setModel(modelSpot);
/* 744 */     tableSpot.moveColumn(tableSpot.getColumnCount() - 1, 0);
/* 745 */     tableSpot.setSelectionBackground(new Color(229, 255, 204));
/* 746 */     tableSpot.setSelectionForeground(new Color(0, 102, 0));
/* 747 */     DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
/* 748 */     centerRenderer.setHorizontalAlignment(0);
/* 749 */     tableSpot.setDefaultRenderer(String.class, centerRenderer);
/* 750 */     tableSpot.setAutoResizeMode(0);
/* 751 */     tableSpot.setRowHeight(45);
/* 752 */     tableSpot.setAutoCreateRowSorter(true);
/* 753 */     tableSpot.getTableHeader().setDefaultRenderer(new SimpleHeaderRenderer()); int u;
/* 754 */     for (u = 0; u < tableSpot.getColumnCount(); u++)
/* 755 */       tableSpot.getColumnModel().getColumn(u).setPreferredWidth(90); 
/* 756 */     for (u = 16; u < tableSpot.getColumnCount(); u++)
/* 757 */       tableSpot.getColumnModel().getColumn(u).setPreferredWidth(150); 
/*     */     int i;
/* 759 */     for (i = 0; i < tableSpot.getRowCount(); i++)
/* 760 */       tableSpot.setValueAt(Boolean.valueOf(true), i, 0); 
/* 761 */     tableSpot.getColumnModel().getColumn(1).setCellRenderer(new Renderer());
/* 762 */     labelReset = new JLabel();
/* 763 */     labelReset.setText("");
/* 764 */     labelReset.setOpaque(true);
/* 765 */     labelReset.setBackground(new Color(214, 217, 223));
/* 766 */     for (i = 0; i < modelSpot.getRowCount(); i++) {
/* 767 */       modelSpot.setValueAt(labelReset, i, tableSpot.convertColumnIndexToModel(1));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void createMovieTable() {
/* 794 */     tableImages.setSelectionBackground(new Color(229, 255, 204));
/* 795 */     tableImages.setSelectionForeground(new Color(0, 102, 0));
/* 796 */     DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
/* 797 */     centerRenderer.setHorizontalAlignment(0);
/* 798 */     tableImages.setDefaultRenderer(String.class, centerRenderer);
/* 799 */     tableImages.setAutoResizeMode(0);
/* 800 */     tableImages.setRowHeight(95);
/* 801 */     tableImages.setAutoCreateRowSorter(true);
/* 802 */     tableImages.getTableHeader().setDefaultRenderer(new SimpleHeaderRenderer());
/*     */     
/* 804 */     for (int i = 0; i < modelImages.getRowCount(); i++) {
/* 805 */       modelImages.setValueAt(this.icons[i], i, tableImages.convertColumnIndexToModel(0));
/* 806 */       modelImages.setValueAt(imps[i].getShortTitle(), i, tableImages.convertColumnIndexToModel(1));
/* 807 */       modelImages.setValueAt(imps[i].getTitle().substring(imps[i].getTitle().lastIndexOf(".")), i, 
/* 808 */           tableImages.convertColumnIndexToModel(2));
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static Image getScaledImage(Image srcImg, int w, int h) {
/* 814 */     BufferedImage resizedImg = new BufferedImage(w, h, 1);
/* 815 */     Graphics2D g2 = resizedImg.createGraphics();
/* 816 */     g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
/* 817 */     g2.drawImage(srcImg, 0, 0, w, h, null);
/* 818 */     g2.dispose();
/* 819 */     return resizedImg;
/*     */   }
/*     */   
/*     */   public static ImageIcon createImageIcon(String path) {
/* 823 */     URL imgURL = FirstWizardPanel.class.getResource(path);
/* 824 */     if (imgURL != null) {
/* 825 */       return new ImageIcon(imgURL);
/*     */     }
/* 827 */     System.err.println("Couldn't find file: " + path);
/* 828 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public ImagePlus extractTFrame(ImagePlus imp, int frame) {
/* 833 */     int width = imp.getWidth();
/* 834 */     int height = imp.getHeight();
/* 835 */     int channels = imp.getNChannels();
/* 836 */     int zslices = imp.getNSlices();
/* 837 */     FileInfo fileInfo = imp.getOriginalFileInfo();
/* 838 */     ImageStack stack2 = new ImageStack(width, height);
/* 839 */     ImagePlus imp2 = new ImagePlus();
/* 840 */     imp2.setTitle("T" + frame + "-" + imp.getTitle());
/*     */     
/* 842 */     for (int z = 1; z <= zslices; z++) {
/* 843 */       for (int c = 1; c <= channels; c++) {
/* 844 */         int sliceSix = imp.getStackIndex(c, z, frame);
/* 845 */         stack2.addSlice("", imp.getStack().getProcessor(sliceSix));
/*     */       } 
/* 847 */     }  imp2.setStack(stack2);
/* 848 */     imp2.setDimensions(channels, zslices, 1);
/* 849 */     if (channels * zslices > 1)
/* 850 */       imp2.setOpenAsHyperStack(true); 
/* 851 */     imp2.setFileInfo(fileInfo);
/* 852 */     return imp2;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/SLTDisplayer_.jar!/FirstWizardPanel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */