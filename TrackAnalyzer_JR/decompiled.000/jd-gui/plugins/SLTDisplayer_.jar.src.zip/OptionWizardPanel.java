/*     */ import java.awt.BasicStroke;
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Container;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.FlowLayout;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import javax.swing.BorderFactory;
/*     */ import javax.swing.Box;
/*     */ import javax.swing.BoxLayout;
/*     */ import javax.swing.Icon;
/*     */ import javax.swing.ImageIcon;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JComboBox;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JSlider;
/*     */ import javax.swing.JSpinner;
/*     */ import javax.swing.JTabbedPane;
/*     */ import javax.swing.SpinnerNumberModel;
/*     */ import jwizardcomponent.JWizardComponents;
/*     */ import org.jfree.chart.ChartPanel;
/*     */ import org.jfree.chart.plot.IntervalMarker;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OptionWizardPanel
/*     */   extends LabelWizardPanel
/*     */ {
/*     */   public double maxDomainSpot;
/*     */   public double maxRangeSpot;
/*     */   public double maxDomainTrack;
/*     */   public double maxRangeTrack;
/*     */   public IntervalMarker markerRangeSpot;
/*     */   public IntervalMarker markerDomainSpot;
/*     */   public IntervalMarker markerRangeTrack;
/*     */   public IntervalMarker markerDomainTrack;
/*     */   private JSpinner filterRangeSpot;
/*     */   private JSpinner filterDomainSpot;
/*     */   private JSpinner filterRangeTrack;
/*     */   private JSpinner filterDomainTrack;
/*     */   private JSpinner filterOrderSpot;
/*     */   public JSlider sliderDomainSpot;
/*     */   public JSlider sliderRangeSpot;
/*     */   public JSlider sliderDomainTrack;
/*     */   public JSlider sliderRangeTrack;
/*     */   static int selectedIndexCh2;
/*     */   static int selectedIndexCh3;
/*     */   static int numCh2Positive;
/*     */   static int numCh3Positive;
/*     */   static int countSenescentNumber;
/*     */   static int lhCountAll;
/*     */   static int hhCountAll;
/*     */   static int llCountAll;
/*     */   static int hlCountAll;
/*     */   static int lhCountNID;
/*     */   static int hhCountNID;
/*     */   
/*     */   public OptionWizardPanel(JWizardComponents wizardComponents, String option) {
/*  73 */     super(wizardComponents, "");
/*  74 */     setPanelTitle("");
/*  75 */     setLayout(new BoxLayout((Container)this, 1));
/*     */     
/*  77 */     JPanel chartPanel2Spot = new JPanel();
/*  78 */     this.markerRangeSpot = new IntervalMarker(0.0D, 0.0D, new Color(229, 255, 204), new BasicStroke(), new Color(0, 102, 0), 
/*  79 */         new BasicStroke(1.5F), 0.6F);
/*  80 */     this.markerDomainSpot = new IntervalMarker(0.0D, 0.0D, new Color(229, 255, 204), new BasicStroke(), new Color(0, 102, 0), 
/*  81 */         new BasicStroke(1.5F), 0.5F);
/*  82 */     this.markerRangeTrack = new IntervalMarker(0.0D, 0.0D, new Color(229, 255, 204), new BasicStroke(), new Color(0, 102, 0), 
/*  83 */         new BasicStroke(1.5F), 0.6F);
/*  84 */     this.markerDomainTrack = new IntervalMarker(0.0D, 0.0D, new Color(229, 255, 204), new BasicStroke(), new Color(0, 102, 0), 
/*  85 */         new BasicStroke(1.5F), 0.5F);
/*  86 */     this.sp2Spot = new STScatterPlot("");
/*  87 */     this.scatterPlotSpot = this.sp2Spot.createScatterChartPanelInitial("", "", new ArrayList<>(Arrays.asList(new Double[] { Double.valueOf(0.0D), Double.valueOf(0.0D), Double.valueOf(0.0D)
/*  88 */             }, )), new ArrayList<>(Arrays.asList(new Double[] { Double.valueOf(0.0D), Double.valueOf(0.0D), Double.valueOf(0.0D) }, )), this.markerRangeSpot, this.markerDomainSpot, 
/*  89 */         (Object[][])new Double[][] { { Double.valueOf(0.0D) }, , { Double.valueOf(0.0D) },  }, new Double[][] { { Double.valueOf(0.0D) }, { Double.valueOf(0.0D) } });
/*  90 */     this.refreshButtonSpot = new JButton("");
/*  91 */     this.refreshButtonSpot.setIcon(FirstWizardPanel.refreshCell);
/*  92 */     this.refreshButtonSpot.setToolTipText("Click this button to refresh scatter-plot.");
/*  93 */     this.zoomInSpot = new JButton("");
/*  94 */     ImageIcon iconZoomIn = FirstWizardPanel.createImageIcon("images/zoomin.png");
/*  95 */     Icon zoomInCell = new ImageIcon(iconZoomIn.getImage().getScaledInstance(18, 20, 4));
/*  96 */     this.zoomInSpot.setIcon(zoomInCell);
/*  97 */     this.zoomInSpot.setToolTipText("Click this button to zoom in Chart");
/*  98 */     this.zoomOutSpot = new JButton("");
/*  99 */     ImageIcon iconZoomOut = FirstWizardPanel.createImageIcon("images/zoomout.png");
/* 100 */     Icon zoomOutCell = new ImageIcon(iconZoomOut.getImage().getScaledInstance(18, 20, 4));
/* 101 */     this.zoomOutSpot.setIcon(zoomOutCell);
/* 102 */     this.zoomOutSpot.setToolTipText("Click this button to zoom out Chart");
/* 103 */     this.itemFiltersSpot = new ArrayList<>();
/* 104 */     this.itemFiltersTrack = new ArrayList<>(); int i;
/* 105 */     for (i = 2; i < FirstWizardPanel.columnNamesSpot.length; i++)
/* 106 */       this.itemFiltersSpot.add(FirstWizardPanel.columnNamesSpot[i].toString()); 
/* 107 */     for (i = 0; i < ChooserWizardPanel.columnNamesTrack.length; i++)
/* 108 */       this.itemFiltersTrack.add(ChooserWizardPanel.columnNamesTrack[i].toString()); 
/* 109 */     this.comboFeatureDomainSpot = new JComboBox<>();
/* 110 */     this.comboFeatureDomainSpot.setPreferredSize(new Dimension(90, 20));
/* 111 */     for (i = 0; i < this.itemFiltersSpot.size(); i++)
/* 112 */       this.comboFeatureDomainSpot.addItem(this.itemFiltersSpot.get(i)); 
/* 113 */     this.comboFeatureDomainSpot.setOpaque(true);
/* 114 */     this.scatterPlot = new STScatterPlot("holaa");
/* 115 */     chartPanel2Spot.add((Component)this.scatterPlotSpot);
/* 116 */     this.filterOrderSpot = new JSpinner(new SpinnerNumberModel(1, 0, 1000, 1));
/* 117 */     this.filterOrderSpot.setPreferredSize(new Dimension(40, 20));
/* 118 */     this.filterOrderSpot.setEnabled(false);
/* 119 */     this.filterRangeSpot = new JSpinner(new SpinnerNumberModel(30, 0, 100000000, 1));
/* 120 */     this.filterRangeSpot.setPreferredSize(new Dimension(40, 20));
/* 121 */     this.sliderRangeSpot = new JSlider(1, 0, 100000000, 50);
/* 122 */     JPanel filtersMaxSpot = new JPanel(new FlowLayout(1));
/* 123 */     this.filterDomainSpot = new JSpinner(new SpinnerNumberModel(50, 0, 100000000, 1));
/* 124 */     this.filterDomainSpot.setPreferredSize(new Dimension(60, 20));
/* 125 */     this.sliderDomainSpot = new JSlider(0, 0, 100000000, 150);
/* 126 */     filtersMaxSpot.add(this.sliderDomainSpot);
/* 127 */     filtersMaxSpot.add(Box.createHorizontalStrut(2));
/* 128 */     filtersMaxSpot.add(this.filterDomainSpot);
/* 129 */     filtersMaxSpot.add(this.comboFeatureDomainSpot);
/*     */     
/* 131 */     this.comboFeatureRangeSpot = new JComboBox<>();
/* 132 */     this.comboFeatureRangeSpot.setPreferredSize(new Dimension(90, 20));
/* 133 */     for (int j = 0; j < this.itemFiltersSpot.size(); j++)
/* 134 */       this.comboFeatureRangeSpot.addItem(this.itemFiltersSpot.get(j)); 
/* 135 */     this.comboFeatureRangeSpot.setOpaque(true);
/* 136 */     JPanel rangePanelFSpot = new JPanel(new FlowLayout(0));
/* 137 */     JPanel rangePanelBoxSpot = new JPanel();
/* 138 */     rangePanelBoxSpot.setLayout(new BoxLayout(rangePanelBoxSpot, 1));
/* 139 */     rangePanelBoxSpot.add(this.sliderRangeSpot);
/* 140 */     rangePanelBoxSpot.add(Box.createVerticalStrut(2));
/* 141 */     rangePanelBoxSpot.add(this.filterRangeSpot);
/* 142 */     rangePanelBoxSpot.add(this.comboFeatureRangeSpot);
/* 143 */     JPanel chartDomainPanelBoxSpot = new JPanel();
/* 144 */     chartDomainPanelBoxSpot.setLayout(new BoxLayout(chartDomainPanelBoxSpot, 1));
/* 145 */     chartDomainPanelBoxSpot.add(Box.createVerticalStrut(10));
/* 146 */     chartDomainPanelBoxSpot.add(chartPanel2Spot);
/* 147 */     chartDomainPanelBoxSpot.add(filtersMaxSpot);
/*     */ 
/*     */     
/* 150 */     rangePanelFSpot.add(rangePanelBoxSpot);
/* 151 */     rangePanelFSpot.add(chartDomainPanelBoxSpot);
/* 152 */     JPanel buttonBox = new JPanel();
/* 153 */     buttonBox.setLayout(new BoxLayout(buttonBox, 1));
/* 154 */     JPanel refreshButtonPanelSpot = new JPanel(new FlowLayout(0));
/* 155 */     refreshButtonPanelSpot.add(this.refreshButtonSpot);
/* 156 */     JPanel zoomOutButtonPanelSpot = new JPanel(new FlowLayout(0));
/* 157 */     zoomOutButtonPanelSpot.add(this.zoomOutSpot);
/* 158 */     JPanel zoomInButtonPanelSpot = new JPanel(new FlowLayout(0));
/* 159 */     zoomInButtonPanelSpot.add(this.zoomInSpot);
/* 160 */     buttonBox.add(zoomInButtonPanelSpot);
/* 161 */     buttonBox.add(zoomOutButtonPanelSpot);
/* 162 */     buttonBox.add(refreshButtonPanelSpot);
/* 163 */     this.comboRegressionSpot = new JComboBox<>();
/* 164 */     this.comboRegressionSpot.setPreferredSize(new Dimension(90, 20));
/* 165 */     this.comboRegressionSpot.addItem("Linear");
/* 166 */     this.comboRegressionSpot.addItem("Polynomial");
/* 167 */     this.comboRegressionSpot.addItem("Power");
/* 168 */     this.comboRegressionSpot.addItem("Logarithmic");
/* 169 */     this.comboRegressionSpot.addItem("Exponential");
/*     */     
/* 171 */     this.comboRegressionSpot.setSelectedIndex(0);
/* 172 */     this.comboRegressionSpot.setOpaque(true);
/* 173 */     JPanel regreOrderPanel = new JPanel(new FlowLayout(0));
/* 174 */     regreOrderPanel.add(this.comboRegressionSpot);
/* 175 */     JPanel filterOrderPanel = new JPanel(new FlowLayout(0));
/* 176 */     filterOrderPanel.add(this.filterOrderSpot);
/* 177 */     buttonBox.add(regreOrderPanel);
/* 178 */     buttonBox.add(filterOrderPanel);
/* 179 */     regressionPanel = new JPanel();
/* 180 */     regressionPanel.setBorder(BorderFactory.createTitledBorder("Reg.Params"));
/* 181 */     regressionPanel.setPreferredSize(new Dimension(this.comboRegressionSpot.getWidth() + 10, 35));
/* 182 */     rangePanelFSpot.add(buttonBox);
/* 183 */     JPanel spotPanel = new JPanel();
/* 184 */     spotPanel.add(rangePanelFSpot);
/* 185 */     spotPanel.setBorder(BorderFactory.createTitledBorder(""));
/* 186 */     spotPanel.setPreferredSize(new Dimension(590, 280));
/* 187 */     JPanel trackPanel = new JPanel();
/* 188 */     trackPanel.setBorder(BorderFactory.createTitledBorder(""));
/* 189 */     trackPanel.setPreferredSize(new Dimension(590, 280));
/* 190 */     JTabbedPane maintabbedPane = new JTabbedPane(1);
/* 191 */     maintabbedPane.addTab("SPOTS             ", FirstWizardPanel.iconSpotCell, spotPanel, "Scatter-Plot for spots");
/* 192 */     maintabbedPane.addTab("TRACKS             ", ChooserWizardPanel.iconTrackCell, trackPanel, 
/* 193 */         "Scatter-Plot for spots");
/*     */     
/* 195 */     maintabbedPane.setTabLayoutPolicy(1);
/* 196 */     add(maintabbedPane, "Center");
/*     */     
/* 198 */     this.refreshButtonSpot.addActionListener(new ActionListener()
/*     */         {
/*     */           public void actionPerformed(ActionEvent e) {
/* 201 */             OptionWizardPanel.this.refreshActionSpot();
/*     */           }
/*     */         });
/* 204 */     this.zoomInSpot.addActionListener(new ActionListener()
/*     */         {
/*     */           public void actionPerformed(ActionEvent e) {
/* 207 */             OptionWizardPanel.this.zoomInSpot.setActionCommand("ZOOM_IN_BOTH");
/* 208 */             OptionWizardPanel.this.zoomInSpot.addActionListener((ActionListener)OptionWizardPanel.this.scatterPlotSpot);
/*     */           }
/*     */         });
/* 211 */     this.zoomOutSpot.addActionListener(new ActionListener()
/*     */         {
/*     */           public void actionPerformed(ActionEvent e) {
/* 214 */             OptionWizardPanel.this.zoomOutSpot.setActionCommand("ZOOM_OUT_BOTH");
/* 215 */             OptionWizardPanel.this.zoomOutSpot.addActionListener((ActionListener)OptionWizardPanel.this.scatterPlotSpot);
/*     */           }
/*     */         });
/*     */     
/* 219 */     this.comboRegressionSpot.addActionListener(new ActionListener()
/*     */         {
/*     */           public void actionPerformed(ActionEvent e) {
/* 222 */             if (OptionWizardPanel.this.comboRegressionSpot.getSelectedIndex() == 1)
/* 223 */               OptionWizardPanel.this.filterOrderSpot.setEnabled(true); 
/* 224 */             if (OptionWizardPanel.this.comboRegressionSpot.getSelectedIndex() != 1)
/* 225 */               OptionWizardPanel.this.filterOrderSpot.setEnabled(false); 
/*     */           }
/*     */         });
/*     */   }
/*     */   static int llCountNID; static int hlCountNID; static int lhCountClass; static int hhCountClass; static int llCountClass; static int hlCountClass; static int selectedIndexDomainSpot; static int selectedIndexRangeSpot; static JLabel scatLabel; static JLabel sumLabel; JComboBox<String> comboFeatureDomainSpot; JComboBox<String> comboFeatureRangeSpot; JComboBox<String> comboFeatureDomainTrack; JComboBox<String> comboFeatureRangeTrack; JComboBox<String> comboClass; JComboBox<String> comboRegressionSpot; JComboBox<String> comboRegressionTrack; List<String> itemFiltersSpot; List<String> itemFiltersTrack; STScatterPlot scatterPlot; JButton refreshButtonSpot; JButton zoomInSpot; JButton zoomOutSpot; STScatterPlot sp2Spot; STScatterPlot sp2Track; ChartPanel scatterPlotSpot; ChartPanel scatterPlotTrack;
/*     */   static JPanel regressionPanel;
/*     */   
/*     */   public void refreshActionSpot() {
/* 233 */     int rowCount = FirstWizardPanel.tableSpot.getRowCount();
/* 234 */     int columnCount = FirstWizardPanel.tableSpot.getColumnCount();
/* 235 */     selectedIndexDomainSpot = this.comboFeatureDomainSpot.getSelectedIndex();
/* 236 */     selectedIndexRangeSpot = this.comboFeatureRangeSpot.getSelectedIndex();
/* 237 */     List<Double> valuesDomainSpot = new ArrayList<>();
/* 238 */     List<Double> valuesRangeSpot = new ArrayList<>();
/* 239 */     Object[][] dataSpot = new Object[rowCount][columnCount];
/* 240 */     for (int i = 0; i < rowCount; i++) {
/* 241 */       for (int k = 0; k < columnCount; k++) {
/* 242 */         dataSpot[i][k] = FirstWizardPanel.tableSpot.getValueAt(i, k);
/*     */       }
/*     */       
/* 245 */       valuesDomainSpot.add(Double.valueOf(Double.parseDouble(dataSpot[i][selectedIndexDomainSpot + 4].toString())));
/* 246 */       valuesRangeSpot.add(Double.valueOf(Double.parseDouble(dataSpot[i][selectedIndexRangeSpot + 4].toString())));
/*     */     } 
/*     */     
/* 249 */     this.maxDomainSpot = ((Double)Collections.<Double>max(valuesDomainSpot)).doubleValue();
/* 250 */     this.maxRangeSpot = ((Double)Collections.<Double>max(valuesRangeSpot)).doubleValue();
/* 251 */     this.sliderDomainSpot.setMinimum(0);
/* 252 */     this.sliderDomainSpot.setMaximum((int)this.maxDomainSpot);
/* 253 */     this.sliderRangeSpot.setMinimum(0);
/* 254 */     this.sliderRangeSpot.setMaximum((int)this.maxRangeSpot);
/*     */     
/* 256 */     List<Color> listColorSpot = new ArrayList<>();
/* 257 */     for (int j = 0; j < FirstWizardPanel.modelSpot.getRowCount(); j++)
/* 258 */       listColorSpot.add(((JLabel)FirstWizardPanel.modelSpot.getValueAt(j, 
/* 259 */             FirstWizardPanel.tableSpot.convertColumnIndexToModel(1))).getBackground()); 
/* 260 */     Color[] classColorSpot = new Color[listColorSpot.size()];
/* 261 */     listColorSpot.toArray(classColorSpot);
/* 262 */     if (this.comboRegressionSpot.getSelectedIndex() == 0)
/* 263 */       this.sp2Spot.addScatterPlotSeriesLinear(this.comboFeatureDomainSpot.getSelectedItem().toString(), 
/* 264 */           this.comboFeatureRangeSpot.getSelectedItem().toString(), valuesDomainSpot, valuesRangeSpot, 
/* 265 */           this.markerRangeSpot, this.markerDomainSpot, this.filterDomainSpot.getValue().toString(), 
/* 266 */           this.filterRangeSpot.getValue().toString(), dataSpot, classColorSpot); 
/* 267 */     if (this.comboRegressionSpot.getSelectedIndex() == 1)
/* 268 */       this.sp2Spot.addScatterPlotSeriesPolynomial(this.comboFeatureDomainSpot.getSelectedItem().toString(), 
/* 269 */           this.comboFeatureRangeSpot.getSelectedItem().toString(), valuesDomainSpot, valuesRangeSpot, 
/* 270 */           this.markerRangeSpot, this.markerDomainSpot, this.filterDomainSpot.getValue().toString(), 
/* 271 */           this.filterRangeSpot.getValue().toString(), dataSpot, classColorSpot, ((Integer)this.filterOrderSpot.getValue()).intValue()); 
/* 272 */     if (this.comboRegressionSpot.getSelectedIndex() == 2)
/* 273 */       this.sp2Spot.addScatterPlotSeriesPower(this.comboFeatureDomainSpot.getSelectedItem().toString(), 
/* 274 */           this.comboFeatureRangeSpot.getSelectedItem().toString(), valuesDomainSpot, valuesRangeSpot, 
/* 275 */           this.markerRangeSpot, this.markerDomainSpot, this.filterDomainSpot.getValue().toString(), 
/* 276 */           this.filterRangeSpot.getValue().toString(), dataSpot, classColorSpot); 
/* 277 */     if (this.comboRegressionSpot.getSelectedIndex() == 3)
/* 278 */       this.sp2Spot.addScatterPlotSeriesLogarithmic(this.comboFeatureDomainSpot.getSelectedItem().toString(), 
/* 279 */           this.comboFeatureRangeSpot.getSelectedItem().toString(), valuesDomainSpot, valuesRangeSpot, 
/* 280 */           this.markerRangeSpot, this.markerDomainSpot, this.filterDomainSpot.getValue().toString(), 
/* 281 */           this.filterRangeSpot.getValue().toString(), dataSpot, classColorSpot); 
/* 282 */     if (this.comboRegressionSpot.getSelectedIndex() == 4)
/* 283 */       this.sp2Spot.addScatterPlotSeriesExponential(this.comboFeatureDomainSpot.getSelectedItem().toString(), 
/* 284 */           this.comboFeatureRangeSpot.getSelectedItem().toString(), valuesDomainSpot, valuesRangeSpot, 
/* 285 */           this.markerRangeSpot, this.markerDomainSpot, this.filterDomainSpot.getValue().toString(), 
/* 286 */           this.filterRangeSpot.getValue().toString(), dataSpot, classColorSpot); 
/*     */   }
/*     */   
/*     */   public void update1() {
/* 290 */     setNextButtonEnabled(true);
/* 291 */     setFinishButtonEnabled(true);
/* 292 */     setBackButtonEnabled(true);
/*     */   }
/*     */ 
/*     */   
/*     */   public void next() {
/* 297 */     switchPanel(4);
/*     */   }
/*     */   
/*     */   public void back() {
/* 301 */     switchPanel(1);
/*     */   }
/*     */ 
/*     */   
/*     */   public void finish() {
/* 306 */     switchPanel(2);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/SLTDisplayer_.jar!/OptionWizardPanel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */