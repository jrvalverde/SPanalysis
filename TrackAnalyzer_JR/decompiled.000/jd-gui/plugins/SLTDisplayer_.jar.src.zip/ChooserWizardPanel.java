/*     */ import ij.IJ;
/*     */ import ij.gui.Roi;
/*     */ import java.awt.BasicStroke;
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.FlowLayout;
/*     */ import java.awt.Font;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.event.ItemEvent;
/*     */ import java.awt.event.ItemListener;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import javax.swing.BorderFactory;
/*     */ import javax.swing.Box;
/*     */ import javax.swing.BoxLayout;
/*     */ import javax.swing.DefaultListModel;
/*     */ import javax.swing.Icon;
/*     */ import javax.swing.ImageIcon;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JCheckBox;
/*     */ import javax.swing.JComboBox;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JList;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JScrollPane;
/*     */ import javax.swing.JSeparator;
/*     */ import javax.swing.JSlider;
/*     */ import javax.swing.JSpinner;
/*     */ import javax.swing.JTabbedPane;
/*     */ import javax.swing.JTable;
/*     */ import javax.swing.JToggleButton;
/*     */ import javax.swing.SpinnerNumberModel;
/*     */ import javax.swing.event.ChangeEvent;
/*     */ import javax.swing.event.ChangeListener;
/*     */ import javax.swing.table.DefaultTableCellRenderer;
/*     */ import javax.swing.table.DefaultTableModel;
/*     */ import jwizardcomponent.JWizardComponents;
/*     */ import jwizardcomponent.JWizardPanel;
/*     */ import org.jfree.chart.ChartPanel;
/*     */ import org.jfree.chart.plot.IntervalMarker;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ChooserWizardPanel
/*     */   extends JWizardPanel
/*     */ {
/*     */   JCheckBox checkRPicker;
/*     */   static JTable tableTrack;
/*     */   static JTable tableImages;
/*     */   static DefaultTableModel modelTrack;
/*     */   JScrollPane jScrollPaneTrack;
/*     */   JScrollPane jScrollPaneImages;
/*     */   JSpinner filterMin;
/*     */   JSpinner filterMax;
/*  78 */   HistogramFilterVersion hs2 = new HistogramFilterVersion(); ChartPanel histogram; JComboBox<String> comboFilters;
/*     */   static DefaultListModel<String> modelListClass;
/*     */   static DefaultListModel<String> modelListFeature;
/*     */   static JList<String> classList;
/*     */   static JList<String> featureList;
/*     */   static JLabel labelReset;
/*  84 */   static String trackEnable = ""; static String command;
/*     */   List<Integer> indexesToReset;
/*     */   List<Integer> indexesToReset1;
/*     */   List<Integer> tracksID;
/*     */   
/*     */   public ChooserWizardPanel(JWizardComponents wizardComponents) {
/*  90 */     super(wizardComponents, "");
/*     */     
/*  92 */     tableTrack = new JTable();
/*  93 */     tableImages = new JTable();
/*  94 */     tableImages.setModel(FirstWizardPanel.modelImages);
/*  95 */     tableImages.getColumnModel().getColumn(0).setPreferredWidth(90);
/*  96 */     tableImages.getColumnModel().getColumn(1).setPreferredWidth(460);
/*  97 */     tableImages.getColumnModel().getColumn(2).setPreferredWidth(80);
/*  98 */     modelTrack = new DefaultTableModel();
/*  99 */     columnNamesTrack = new Object[] { "Label", "TRACK_ID", "TRACK_DURATION", "TRACK_START", "TRACK_STOP", 
/* 100 */         "TRACK_DISPLACEMENT", "TRACK_MEAN_SPEED", "TRACK_MAX_SPEED", "TRACK_MIN_SPEED", "TRACK_MEDIAN_SPEED", 
/* 101 */         "TRACK_STD_SPEED", "TRACK_INDEX", "TRACK_X_LOCATION", "TRACK_Y_LOCATION", "TRACK_Z_LOCATION", 
/* 102 */         "NUMBER_SPOTS", "NUMBER_GAPS", "LONGEST_GAP", "NUMBER_SPLITS", "NUMBER_MERGES", "NUMBER_COMPLEX", 
/* 103 */         "TRACK_MEAN_QUALITY", "TRACK_MAX_QUALITY", "TRACK_MIN_QUALITY", "TRACK_MEDIAN_QUALITY", 
/* 104 */         "TRACK_STD_QUALITY", "TOTAL_DISTANCE_TRAVELED", "MAX_DISTANCE_TRAVELED", "MEAN_STRAIGHT_LINE_SPEED", 
/* 105 */         "LINEARITY_OF_FORWARD_PROGRESSION", "TOTAL_ABSOLUTE_ANGLE_XY", "TOTAL_ABSOLUTE_ANGLE_YZ", 
/* 106 */         "TOTAL_ABSOLUTE_ANGLE_ZX", "CONFINMENT_RATIO", "TRACK_CLASSIFICATION" };
/*     */     
/* 108 */     tableTrack.setModel(modelTrack);
/* 109 */     tableTrack.setSelectionMode(1);
/* 110 */     this.jScrollPaneTrack = new JScrollPane(tableTrack);
/* 111 */     this.jScrollPaneTrack.setPreferredSize(new Dimension(590, 240));
/* 112 */     this.jScrollPaneTrack.setBorder(BorderFactory.createTitledBorder(""));
/* 113 */     this.jScrollPaneImages = new JScrollPane(tableImages);
/* 114 */     this.jScrollPaneImages.setPreferredSize(new Dimension(590, 240));
/* 115 */     this.jScrollPaneImages.setBorder(BorderFactory.createTitledBorder(""));
/* 116 */     JPanel mainPanel = new JPanel();
/* 117 */     mainPanel.setLayout(new BoxLayout(mainPanel, 1));
/* 118 */     JTabbedPane tabbedPaneTrack = new JTabbedPane(1);
/* 119 */     ImageIcon iconTrack = FirstWizardPanel.createImageIcon("images/track.jpg");
/* 120 */     iconTrackCell = new ImageIcon(iconTrack.getImage().getScaledInstance(18, 20, 4));
/* 121 */     tabbedPaneTrack.addTab("TRACKS             ", iconTrackCell, mainPanel, "Display Track Analysis");
/* 122 */     tabbedPaneTrack.setTabLayoutPolicy(1);
/* 123 */     JButton refreshButton = new JButton();
/* 124 */     ImageIcon iconRefresh = FirstWizardPanel.createImageIcon("images/refresh.png");
/* 125 */     Icon refreshCell = new ImageIcon(iconRefresh.getImage().getScaledInstance(18, 20, 4));
/* 126 */     refreshButton.setIcon(refreshCell);
/* 127 */     refreshButton.setToolTipText("Click this button to get Track analysis");
/* 128 */     JToggleButton paintButton = new JToggleButton();
/* 129 */     ImageIcon iconPaint = FirstWizardPanel.createImageIcon("images/paint.png");
/* 130 */     Icon paintCell = new ImageIcon(iconPaint.getImage().getScaledInstance(18, 20, 4));
/* 131 */     paintButton.setIcon(paintCell);
/* 132 */     paintButton.setToolTipText("Click this button to display labeled-Tracks");
/* 133 */     JToggleButton tInsideButton = new JToggleButton();
/* 134 */     ImageIcon iconTI = FirstWizardPanel.createImageIcon("images/tinside.png");
/* 135 */     Icon TICell = new ImageIcon(iconTI.getImage().getScaledInstance(18, 20, 4));
/* 136 */     tInsideButton.setIcon(TICell);
/* 137 */     tInsideButton.setToolTipText("Click this button to toggle inside Tracks.");
/* 138 */     JToggleButton tOutsideButton = new JToggleButton();
/* 139 */     ImageIcon iconTO = FirstWizardPanel.createImageIcon("images/toutside.png");
/* 140 */     Icon TOCell = new ImageIcon(iconTO.getImage().getScaledInstance(18, 20, 4));
/* 141 */     tOutsideButton.setIcon(TOCell);
/* 142 */     tOutsideButton.setToolTipText("Click this button to toggle outside Tracks.");
/* 143 */     JButton enableButton = new JButton();
/* 144 */     ImageIcon iconEnable = FirstWizardPanel.createImageIcon("images/enable.png");
/* 145 */     Icon enableCell = new ImageIcon(iconEnable.getImage().getScaledInstance(18, 20, 4));
/* 146 */     enableButton.setIcon(enableCell);
/* 147 */     enableButton.setToolTipText("Click this button to enable your selection");
/* 148 */     JButton disableButton = new JButton();
/* 149 */     ImageIcon iconDisable = FirstWizardPanel.createImageIcon("images/disable.png");
/* 150 */     Icon disableCell = new ImageIcon(iconDisable.getImage().getScaledInstance(18, 20, 4));
/* 151 */     disableButton.setIcon(disableCell);
/* 152 */     disableButton.setToolTipText("Click this button to disable your selection");
/* 153 */     JPanel buttonPanel = new JPanel(new FlowLayout(2));
/* 154 */     JSeparator separator1 = new JSeparator(1);
/* 155 */     JSeparator separator2 = new JSeparator(1);
/* 156 */     Dimension dime = separator1.getPreferredSize();
/* 157 */     dime.height = (refreshButton.getPreferredSize()).height;
/* 158 */     separator1.setPreferredSize(dime);
/* 159 */     separator2.setPreferredSize(dime);
/* 160 */     this.checkRPicker = new JCheckBox(" Track Picker");
/* 161 */     JLabel filterLabel = new JLabel("  ➠ Track Analysis : ");
/* 162 */     filterLabel.setFont(new Font("Dialog", 1, 13));
/* 163 */     filterLabel.setBorder(BorderFactory.createRaisedBevelBorder());
/* 164 */     JPanel filterPanel = new JPanel(new FlowLayout(0));
/* 165 */     filterPanel.add(filterLabel);
/* 166 */     filterPanel.add(this.checkRPicker);
/* 167 */     filterPanel.add(Box.createHorizontalStrut(20));
/* 168 */     JPanel filterMain = new JPanel(new FlowLayout(0));
/* 169 */     filterMain.add(filterPanel);
/* 170 */     buttonPanel.add(refreshButton);
/* 171 */     buttonPanel.add(paintButton);
/* 172 */     buttonPanel.add(separator1);
/* 173 */     buttonPanel.add(enableButton);
/* 174 */     buttonPanel.add(disableButton);
/* 175 */     buttonPanel.add(separator2);
/* 176 */     buttonPanel.add(tInsideButton);
/* 177 */     buttonPanel.add(tOutsideButton);
/* 178 */     filterMain.add(buttonPanel);
/* 179 */     mainPanel.add(this.jScrollPaneImages);
/* 180 */     mainPanel.add(Box.createVerticalStrut(5));
/* 181 */     mainPanel.add(filterMain);
/* 182 */     mainPanel.add(this.jScrollPaneTrack);
/* 183 */     JLabel settingsLabel = new JLabel("  ➠ Settings for Filters/Classes : ");
/* 184 */     settingsLabel.setFont(new Font("Dialog", 1, 13));
/* 185 */     settingsLabel.setBorder(BorderFactory.createRaisedBevelBorder());
/* 186 */     JPanel settingsPanel = new JPanel(new FlowLayout(0));
/* 187 */     settingsPanel.add(settingsLabel);
/* 188 */     mainPanel.add(settingsPanel);
/* 189 */     JPanel filtersMin = new JPanel(new FlowLayout(0));
/* 190 */     this.filterMin = new JSpinner(new SpinnerNumberModel(30, 0, 5000, 1));
/* 191 */     this.filterMin.setPreferredSize(new Dimension(60, 20));
/* 192 */     final JSlider sliderMin = new JSlider(0, 300, 50);
/* 193 */     sliderMin.setPreferredSize(new Dimension(150, 15));
/* 194 */     JLabel filterMinLabel = new JLabel("              Min :  ");
/* 195 */     filtersMin.add(filterMinLabel);
/* 196 */     filtersMin.add(sliderMin);
/* 197 */     filtersMin.add(Box.createHorizontalStrut(2));
/* 198 */     filtersMin.add(this.filterMin);
/* 199 */     JPanel filtersMax = new JPanel(new FlowLayout(0));
/* 200 */     this.filterMax = new JSpinner(new SpinnerNumberModel(200, 0, 5000, 1));
/* 201 */     this.filterMax.setPreferredSize(new Dimension(60, 20));
/* 202 */     final JSlider sliderMax = new JSlider(0, 300, 150);
/* 203 */     sliderMax.setPreferredSize(new Dimension(150, 15));
/* 204 */     JLabel filterMaxLabel = new JLabel("              Max :  ");
/* 205 */     filtersMax.add(filterMaxLabel);
/* 206 */     filtersMax.add(sliderMax);
/* 207 */     filtersMax.add(Box.createHorizontalStrut(2));
/* 208 */     filtersMax.add(this.filterMax);
/* 209 */     JPanel boxPanel2 = new JPanel();
/* 210 */     boxPanel2.setLayout(new BoxLayout(boxPanel2, 1));
/* 211 */     final IntervalMarker intervalMarker = new IntervalMarker(0.0D, 0.0D, new Color(229, 255, 204), new BasicStroke(), 
/* 212 */         new Color(0, 102, 0), new BasicStroke(1.5F), 0.5F);
/* 213 */     this.histogram = this.hs2.createChartPanel("", new double[] { 0.0D, 0.0D, 0.0D }, 100, intervalMarker);
/*     */     
/* 215 */     JPanel chartPanel2 = new JPanel(new BorderLayout());
/* 216 */     chartPanel2.setPreferredSize(new Dimension(390, 180));
/* 217 */     chartPanel2.add((Component)this.histogram);
/* 218 */     boxPanel2.add(chartPanel2);
/* 219 */     JPanel controlPanel2 = this.hs2.createControlPanel();
/* 220 */     boxPanel2.add(controlPanel2);
/* 221 */     JPanel filtersMain2 = new JPanel();
/* 222 */     filtersMain2.setLayout(new BoxLayout(filtersMain2, 1));
/* 223 */     filtersMain2.add(boxPanel2);
/* 224 */     filtersMain2.add(filtersMin);
/* 225 */     filtersMain2.add(filtersMax);
/* 226 */     JLabel featureTrack = new JLabel(" » Track-Features :  ");
/* 227 */     featureTrack.setFont(new Font("Dialog", 1, 13));
/* 228 */     this.comboFilters = new JComboBox<>();
/* 229 */     for (int i = 1; i < columnNamesTrack.length; i++)
/* 230 */       this.comboFilters.addItem((String)columnNamesTrack[i]); 
/* 231 */     this.comboFilters.setPreferredSize(new Dimension(130, 25));
/* 232 */     this.comboFilters.setSelectedIndex(0);
/* 233 */     this.comboFilters.setOpaque(true);
/* 234 */     JPanel panelFilters = new JPanel(new FlowLayout(0));
/* 235 */     JSeparator separator3 = new JSeparator(1);
/* 236 */     Dimension dime2 = separator3.getPreferredSize();
/* 237 */     dime2.height = (filtersMain2.getPreferredSize()).height;
/* 238 */     separator3.setPreferredSize(dime2);
/* 239 */     panelFilters.add(filtersMain2);
/* 240 */     panelFilters.add(separator3);
/* 241 */     modelListClass = new DefaultListModel<>();
/* 242 */     classList = new JList<>(modelListClass);
/* 243 */     modelListFeature = new DefaultListModel<>();
/* 244 */     featureList = new JList<>(modelListFeature);
/* 245 */     final ColorEditorTrack colorEditor = new ColorEditorTrack(featureList);
/* 246 */     JScrollPane scrollListFilter = new JScrollPane(featureList);
/* 247 */     JScrollPane scrollListClass = new JScrollPane(classList);
/* 248 */     Dimension d = featureList.getPreferredSize();
/* 249 */     d.width = 150;
/* 250 */     d.height = 90;
/* 251 */     scrollListFilter.setPreferredSize(d);
/* 252 */     scrollListClass.setPreferredSize(d);
/* 253 */     JPanel filterPanelButtons = new JPanel(new FlowLayout(0));
/* 254 */     JPanel classPanelButtons = new JPanel();
/* 255 */     classPanelButtons.setLayout(new BoxLayout(classPanelButtons, 1));
/* 256 */     filterPanelButtons.add(scrollListFilter);
/* 257 */     JPanel fButtonsPanel = new JPanel();
/* 258 */     fButtonsPanel.setLayout(new BoxLayout(fButtonsPanel, 1));
/* 259 */     JButton addButton = new JButton();
/* 260 */     ImageIcon iconAdd = FirstWizardPanel.createImageIcon("images/add.png");
/* 261 */     Icon addCell = new ImageIcon(iconAdd.getImage().getScaledInstance(14, 16, 4));
/* 262 */     addButton.setIcon(addCell);
/* 263 */     addButton.setToolTipText("Click this button to add features");
/* 264 */     JButton remButton = new JButton();
/* 265 */     ImageIcon iconRem = FirstWizardPanel.createImageIcon("images/remove.png");
/* 266 */     Icon remCell = new ImageIcon(iconRem.getImage().getScaledInstance(14, 16, 4));
/* 267 */     remButton.setIcon(remCell);
/* 268 */     remButton.setToolTipText("Click this button to remove features");
/* 269 */     JButton classButton = new JButton();
/* 270 */     ImageIcon iconClass = FirstWizardPanel.createImageIcon("images/classes.png");
/* 271 */     Icon classCell = new ImageIcon(iconClass.getImage().getScaledInstance(14, 16, 4));
/* 272 */     classButton.setIcon(classCell);
/* 273 */     classButton.setToolTipText("Click this button to create a class.");
/* 274 */     JButton remClassButton = new JButton();
/* 275 */     remClassButton.setIcon(remCell);
/* 276 */     remClassButton.setToolTipText("Click this button to remove a class.");
/* 277 */     fButtonsPanel.add(addButton);
/* 278 */     fButtonsPanel.add(remButton);
/* 279 */     filterPanelButtons.add(fButtonsPanel);
/* 280 */     classPanelButtons.add(classButton);
/* 281 */     classPanelButtons.add(remClassButton);
/* 282 */     JPanel classPanel = new JPanel(new FlowLayout(0));
/* 283 */     classPanel.add(scrollListClass);
/* 284 */     classPanel.add(classPanelButtons);
/* 285 */     JPanel boxPanel = new JPanel();
/* 286 */     boxPanel.setLayout(new BoxLayout(boxPanel, 1));
/* 287 */     boxPanel.add(this.comboFilters);
/* 288 */     boxPanel.add(Box.createHorizontalStrut(5));
/* 289 */     boxPanel.add(filterPanelButtons);
/* 290 */     boxPanel.add(Box.createHorizontalStrut(5));
/* 291 */     boxPanel.add(classPanel);
/* 292 */     panelFilters.add(boxPanel);
/* 293 */     mainPanel.add(panelFilters);
/* 294 */     add(tabbedPaneTrack);
/* 295 */     createMovieTable();
/*     */     
/* 297 */     paintButton.addItemListener(new ItemListener() {
/*     */           public void itemStateChanged(ItemEvent ev) {
/* 299 */             if (ev.getStateChange() == 1) {
/* 300 */               ChooserWizardPanel.this.paintAndDisableAction();
/* 301 */             } else if (ev.getStateChange() == 2) {
/* 302 */               ChooserWizardPanel.this.resetAndEnableAction();
/*     */             } 
/*     */           }
/*     */         });
/*     */     
/* 307 */     refreshButton.addActionListener(new ActionListener()
/*     */         {
/*     */           public void actionPerformed(ActionEvent e)
/*     */           {
/* 311 */             ChooserWizardPanel.trackEnable = "trackEnable";
/* 312 */             ProcessTrackMateXml.tracksVisible = true;
/* 313 */             ProcessTrackMateXml.spotsVisible = false;
/* 314 */             ProcessTrackMateXml ptx = new ProcessTrackMateXml();
/* 315 */             ptx.processTrackMateXml();
/*     */           }
/*     */         });
/*     */     
/* 319 */     enableButton.addActionListener(new ActionListener()
/*     */         {
/*     */           public void actionPerformed(ActionEvent e) {
/* 322 */             ChooserWizardPanel.this.enableTracks();
/*     */           }
/*     */         });
/*     */     
/* 326 */     disableButton.addActionListener(new ActionListener()
/*     */         {
/*     */           public void actionPerformed(ActionEvent e) {
/* 329 */             ChooserWizardPanel.this.disableTracks();
/*     */           }
/*     */         });
/*     */     
/* 333 */     this.checkRPicker.addItemListener(new ItemListener()
/*     */         {
/*     */           public void itemStateChanged(ItemEvent e)
/*     */           {
/* 337 */             if (e.getStateChange() == 1)
/* 338 */               ChooserWizardPanel.command = "enable"; 
/* 339 */             if (e.getStateChange() == 2) {
/* 340 */               ChooserWizardPanel.command = null;
/* 341 */               ProcessTrackMateXml.selectionModel.clearSpotSelection();
/* 342 */               ProcessTrackMateXml.selectionModel.clearSelection();
/*     */               
/*     */               return;
/*     */             } 
/*     */           }
/*     */         });
/* 348 */     sliderMin.addChangeListener(new ChangeListener()
/*     */         {
/*     */           public void stateChanged(ChangeEvent e)
/*     */           {
/* 352 */             ChooserWizardPanel.this.filterMin.setValue(Integer.valueOf(sliderMin.getValue()));
/* 353 */             intervalMarker.setStartValue(sliderMin.getValue());
/*     */           }
/*     */         });
/*     */ 
/*     */     
/* 358 */     this.filterMin.addChangeListener(new ChangeListener()
/*     */         {
/*     */           public void stateChanged(ChangeEvent e) {
/* 361 */             sliderMin.setValue(((Integer)ChooserWizardPanel.this.filterMin.getValue()).intValue());
/* 362 */             intervalMarker.setStartValue(((Integer)ChooserWizardPanel.this.filterMin.getValue()).intValue());
/*     */           }
/*     */         });
/*     */ 
/*     */     
/* 367 */     sliderMax.addChangeListener(new ChangeListener()
/*     */         {
/*     */           public void stateChanged(ChangeEvent e) {
/* 370 */             ChooserWizardPanel.this.filterMax.setValue(Integer.valueOf(sliderMax.getValue()));
/* 371 */             intervalMarker.setEndValue(sliderMax.getValue());
/*     */           }
/*     */         });
/*     */     
/* 375 */     this.filterMax.addChangeListener(new ChangeListener()
/*     */         {
/*     */           public void stateChanged(ChangeEvent e) {
/* 378 */             sliderMax.setValue(((Integer)ChooserWizardPanel.this.filterMax.getValue()).intValue());
/* 379 */             intervalMarker.setEndValue(((Integer)ChooserWizardPanel.this.filterMax.getValue()).intValue());
/*     */           }
/*     */         });
/*     */     
/* 383 */     tInsideButton.addItemListener(new ItemListener() {
/*     */           public void itemStateChanged(ItemEvent ev) {
/* 385 */             if (ev.getStateChange() == 1) {
/* 386 */               ChooserWizardPanel.this.toggleInsideAction();
/* 387 */             } else if (ev.getStateChange() == 2) {
/* 388 */               ChooserWizardPanel.this.resetToggleInsideAction();
/*     */             } 
/*     */           }
/*     */         });
/* 392 */     this.comboFilters.addActionListener(new ActionListener() {
/*     */           public void actionPerformed(ActionEvent e) {
/* 394 */             String selectedName = (String)ChooserWizardPanel.this.comboFilters.getSelectedItem();
/* 395 */             int selectedIndex = ChooserWizardPanel.this.comboFilters.getSelectedIndex();
/* 396 */             double[] values = null;
/*     */ 
/*     */             
/* 399 */             values = new double[ChooserWizardPanel.tableTrack.getRowCount()];
/* 400 */             for (int r = 0; r < ChooserWizardPanel.tableTrack.getRowCount(); r++) {
/* 401 */               for (int c = 0; c < ChooserWizardPanel.tableTrack.getColumnCount(); c++)
/* 402 */                 values[r] = Double.parseDouble((String)ChooserWizardPanel.tableTrack.getValueAt(r, selectedIndex + 2)); 
/*     */             } 
/* 404 */             double max = values[0];
/* 405 */             for (int i = 1; i < values.length; i++) {
/* 406 */               if (values[i] > max)
/* 407 */                 max = values[i]; 
/*     */             } 
/* 409 */             sliderMin.setMinimum(0);
/* 410 */             sliderMin.setMaximum((int)max);
/* 411 */             sliderMax.setMinimum(0);
/* 412 */             sliderMax.setMaximum((int)max);
/*     */             
/* 414 */             ChooserWizardPanel.this.hs2.addHistogramSeries(selectedName, values, (int)max, intervalMarker);
/*     */           }
/*     */         });
/*     */     
/* 418 */     classButton.addActionListener(new ActionListener()
/*     */         {
/*     */           public void actionPerformed(ActionEvent e) {
/* 421 */             ColorEditorTrack.myFrame.setVisible(true);
/* 422 */             colorEditor.setClassAction();
/*     */           }
/*     */         });
/*     */     
/* 426 */     remClassButton.addActionListener(new ActionListener()
/*     */         {
/*     */           public void actionPerformed(ActionEvent e)
/*     */           {
/* 430 */             String classSelectedValue = ChooserWizardPanel.classList.getSelectedValue();
/* 431 */             int[] classSelectedIndex = ChooserWizardPanel.classList.getSelectedIndices(); int i;
/* 432 */             for (i = 0; i < ChooserWizardPanel.modelTrack.getRowCount(); i++) {
/* 433 */               if (((JLabel)ChooserWizardPanel.modelTrack.getValueAt(i, ChooserWizardPanel.tableTrack.convertColumnIndexToModel(1))).getText()
/* 434 */                 .equals(classSelectedValue))
/* 435 */                 ChooserWizardPanel.modelTrack.setValueAt(ChooserWizardPanel.labelReset, i, ChooserWizardPanel.tableTrack.convertColumnIndexToModel(1)); 
/*     */             } 
/* 437 */             for (i = 0; i < classSelectedIndex.length; i++) {
/* 438 */               ChooserWizardPanel.modelListClass.removeElementAt(classSelectedIndex[i]);
/*     */             }
/*     */           }
/*     */         });
/*     */     
/* 443 */     addButton.addActionListener(new ActionListener()
/*     */         {
/*     */           public void actionPerformed(ActionEvent e)
/*     */           {
/* 447 */             List<String> listFilters = new ArrayList<>();
/*     */             
/* 449 */             if (ChooserWizardPanel.featureList.getModel().getSize() < 1) {
/* 450 */               ChooserWizardPanel.modelListFeature.addElement(String.valueOf(ChooserWizardPanel.this.comboFilters.getSelectedItem()) + ":  [" + ChooserWizardPanel.this.filterMin.getValue() + 
/* 451 */                   "," + ChooserWizardPanel.this.filterMax.getValue() + "]");
/*     */             }
/* 453 */             if (ChooserWizardPanel.featureList.getModel().getSize() >= 1) {
/* 454 */               for (int i = 0; i < ChooserWizardPanel.featureList.getModel().getSize(); i++) {
/* 455 */                 listFilters.add(String.valueOf(((String)ChooserWizardPanel.featureList.getModel().getElementAt(i)).substring(0, (
/* 456 */                         (String)ChooserWizardPanel.featureList.getModel().getElementAt(i)).lastIndexOf(":"))));
/*     */               }
/* 458 */               if (!listFilters.contains(ChooserWizardPanel.this.comboFilters.getSelectedItem().toString())) {
/* 459 */                 ChooserWizardPanel.modelListFeature.addElement(String.valueOf(ChooserWizardPanel.this.comboFilters.getSelectedItem()) + ":  [" + 
/* 460 */                     ChooserWizardPanel.this.filterMin.getValue() + "," + ChooserWizardPanel.this.filterMax.getValue() + "]");
/*     */               }
/* 462 */               if (listFilters.contains(ChooserWizardPanel.this.comboFilters.getSelectedItem().toString())) {
/*     */                 return;
/*     */               }
/*     */             } 
/*     */           }
/*     */         });
/*     */ 
/*     */     
/* 470 */     remButton.addActionListener(new ActionListener()
/*     */         {
/*     */           public void actionPerformed(ActionEvent e)
/*     */           {
/*     */             try {
/* 475 */               int[] indexes = ChooserWizardPanel.featureList.getSelectedIndices();
/* 476 */               for (int i = 0; i < indexes.length; i++)
/* 477 */                 ChooserWizardPanel.modelListFeature.remove(indexes[i]); 
/* 478 */             } catch (Exception e1) {
/* 479 */               e1.printStackTrace();
/*     */             } 
/*     */           }
/*     */         });
/*     */     
/* 484 */     tOutsideButton.addItemListener(new ItemListener() {
/*     */           public void itemStateChanged(ItemEvent ev) {
/* 486 */             if (ev.getStateChange() == 1) {
/* 487 */               ChooserWizardPanel.this.toggleOutsideAction();
/* 488 */             } else if (ev.getStateChange() == 2) {
/* 489 */               ChooserWizardPanel.this.resetToggleInsideAction();
/*     */             } 
/*     */           }
/*     */         });
/*     */   }
/*     */   List<Integer> tracksID1; List<Integer> indexesTI; static Icon iconTrackCell; static Object[] columnNamesTrack;
/*     */   public void toggleOutsideAction() {
/* 496 */     Roi mainRoi = null;
/* 497 */     if (IJ.getImage().getRoi().getType() == 0)
/* 498 */       mainRoi = IJ.getImage().getRoi(); 
/* 499 */     this.indexesTI = new ArrayList<>();
/*     */     
/* 501 */     for (int i = 0; i < modelTrack.getRowCount(); i++) {
/*     */       
/* 503 */       if (mainRoi
/* 504 */         .contains(
/*     */           
/* 506 */           (int)IJ.getImage().getCalibration().getRawX(Double.parseDouble(modelTrack
/* 507 */               .getValueAt(i, tableTrack.convertColumnIndexToModel(13)).toString())), 
/*     */           
/* 509 */           (int)IJ.getImage().getCalibration().getRawY(Double.parseDouble(
/* 510 */               modelTrack.getValueAt(i, tableTrack.convertColumnIndexToModel(14))
/* 511 */               .toString()))) == Boolean.FALSE.booleanValue()) {
/* 512 */         this.indexesTI.add(Integer.valueOf(i));
/* 513 */         modelTrack.setValueAt(Boolean.valueOf(false), i, tableTrack.convertColumnIndexToModel(0));
/*     */         
/* 515 */         int trackID = Integer.parseInt((String)tableTrack.getValueAt(i, 2));
/* 516 */         ProcessTrackMateXml.model.beginUpdate();
/*     */         try {
/* 518 */           ProcessTrackMateXml.model.setTrackVisibility(Integer.valueOf(trackID), false);
/*     */         } finally {
/* 520 */           ProcessTrackMateXml.model.endUpdate();
/*     */         } 
/*     */         
/* 523 */         ProcessTrackMateXml.displayer.refresh();
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void toggleInsideAction() {
/* 531 */     Roi mainRoi = null;
/* 532 */     if (IJ.getImage().getRoi().getType() == 0)
/* 533 */       mainRoi = IJ.getImage().getRoi(); 
/* 534 */     this.indexesTI = new ArrayList<>();
/*     */     
/* 536 */     for (int i = 0; i < modelTrack.getRowCount(); i++) {
/*     */       
/* 538 */       if (mainRoi
/* 539 */         .contains(
/*     */           
/* 541 */           (int)IJ.getImage().getCalibration().getRawX(Double.parseDouble(modelTrack
/* 542 */               .getValueAt(i, tableTrack.convertColumnIndexToModel(13)).toString())), 
/*     */           
/* 544 */           (int)IJ.getImage().getCalibration().getRawY(Double.parseDouble(
/* 545 */               modelTrack.getValueAt(i, tableTrack.convertColumnIndexToModel(14))
/* 546 */               .toString()))) == Boolean.TRUE.booleanValue()) {
/* 547 */         this.indexesTI.add(Integer.valueOf(i));
/* 548 */         modelTrack.setValueAt(Boolean.valueOf(false), i, tableTrack.convertColumnIndexToModel(0));
/*     */         
/* 550 */         int trackID = Integer.parseInt((String)tableTrack.getValueAt(i, 2));
/* 551 */         ProcessTrackMateXml.model.beginUpdate();
/*     */         try {
/* 553 */           ProcessTrackMateXml.model.setTrackVisibility(Integer.valueOf(trackID), false);
/*     */         } finally {
/* 555 */           ProcessTrackMateXml.model.endUpdate();
/*     */         } 
/*     */         
/* 558 */         ProcessTrackMateXml.displayer.refresh();
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void resetToggleInsideAction() {
/* 567 */     for (int row = 0; row < modelTrack.getRowCount(); row++) {
/* 568 */       modelTrack.setValueAt(Boolean.valueOf(true), tableTrack.convertRowIndexToModel(row), 
/* 569 */           tableTrack.convertColumnIndexToModel(0));
/* 570 */       int trackID = Integer.parseInt((String)tableTrack.getValueAt(row, 2));
/* 571 */       ProcessTrackMateXml.model.beginUpdate();
/*     */       try {
/* 573 */         ProcessTrackMateXml.model.setTrackVisibility(Integer.valueOf(trackID), true);
/*     */       } finally {
/* 575 */         ProcessTrackMateXml.model.endUpdate();
/*     */       } 
/*     */       
/* 578 */       ProcessTrackMateXml.displayer.refresh();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void createTrackTable() {
/* 586 */     modelTrack = new DefaultTableModel((Object[][])ProcessTrackMateXml.dataTrack, (Object[])ProcessTrackMateXml.columnHeadersTrack)
/*     */       {
/*     */         public Class<?> getColumnClass(int column)
/*     */         {
/* 590 */           if (getRowCount() > 0) {
/* 591 */             Object value = getValueAt(0, column);
/* 592 */             if (value != null) {
/* 593 */               return getValueAt(0, column).getClass();
/*     */             }
/*     */           } 
/*     */           
/* 597 */           return super.getColumnClass(column);
/*     */         }
/*     */       };
/*     */     
/* 601 */     modelTrack.addColumn("Enable");
/* 602 */     tableTrack.setModel(modelTrack);
/* 603 */     tableTrack.moveColumn(tableTrack.getColumnCount() - 1, 0);
/* 604 */     tableTrack.setSelectionBackground(new Color(229, 255, 204));
/* 605 */     tableTrack.setSelectionForeground(new Color(0, 102, 0));
/* 606 */     DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
/* 607 */     centerRenderer.setHorizontalAlignment(0);
/* 608 */     tableTrack.setDefaultRenderer(String.class, centerRenderer);
/* 609 */     tableTrack.setAutoResizeMode(0);
/* 610 */     tableTrack.setRowHeight(45);
/* 611 */     tableTrack.setAutoCreateRowSorter(true);
/* 612 */     tableTrack.getTableHeader().setDefaultRenderer(new SimpleHeaderRenderer()); int u;
/* 613 */     for (u = 0; u < tableTrack.getColumnCount(); u++)
/* 614 */       tableTrack.getColumnModel().getColumn(u).setPreferredWidth(90); 
/* 615 */     for (u = 3; u < tableTrack.getColumnCount(); u++)
/* 616 */       tableTrack.getColumnModel().getColumn(u).setPreferredWidth(130); 
/*     */     int i;
/* 618 */     for (i = 0; i < tableTrack.getRowCount(); i++)
/* 619 */       tableTrack.setValueAt(Boolean.valueOf(true), i, 0); 
/* 620 */     tableTrack.getColumnModel().getColumn(1).setCellRenderer(new Renderer());
/* 621 */     labelReset = new JLabel();
/* 622 */     labelReset.setText("");
/* 623 */     labelReset.setOpaque(true);
/* 624 */     labelReset.setBackground(new Color(214, 217, 223));
/* 625 */     for (i = 0; i < modelTrack.getRowCount(); i++) {
/* 626 */       modelTrack.setValueAt(labelReset, i, tableTrack.convertColumnIndexToModel(1));
/*     */     }
/*     */   }
/*     */   
/*     */   public void enableTracks() {
/* 631 */     this.indexesToReset1 = new ArrayList<>();
/* 632 */     this.tracksID1 = new ArrayList<>();
/* 633 */     int[] selectedRows = tableTrack.getSelectedRows();
/* 634 */     for (int i = 0; i < selectedRows.length; i++) {
/* 635 */       this.indexesToReset1.add(Integer.valueOf(selectedRows[i]));
/* 636 */       modelTrack.setValueAt(Boolean.valueOf(true), selectedRows[i], tableTrack.convertColumnIndexToModel(0));
/* 637 */       this.tracksID1.add(Integer.valueOf(Integer.parseInt((String)tableTrack.getValueAt(selectedRows[i], 2))));
/*     */     } 
/*     */     
/* 640 */     for (int row = 0; row < this.tracksID1.size(); row++) {
/*     */       
/* 642 */       ProcessTrackMateXml.model.beginUpdate();
/*     */       try {
/* 644 */         ProcessTrackMateXml.model.setTrackVisibility(this.tracksID1.get(row), true);
/*     */       } finally {
/* 646 */         ProcessTrackMateXml.model.endUpdate();
/*     */       } 
/*     */ 
/*     */       
/* 650 */       ProcessTrackMateXml.displayer.refresh();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void disableTracks() {
/* 657 */     this.indexesToReset1 = new ArrayList<>();
/* 658 */     this.tracksID1 = new ArrayList<>();
/* 659 */     int[] selectedRows = tableTrack.getSelectedRows();
/* 660 */     for (int i = 0; i < selectedRows.length; i++) {
/* 661 */       this.indexesToReset1.add(Integer.valueOf(selectedRows[i]));
/* 662 */       modelTrack.setValueAt(Boolean.valueOf(false), selectedRows[i], tableTrack.convertColumnIndexToModel(0));
/* 663 */       this.tracksID1.add(Integer.valueOf(Integer.parseInt((String)tableTrack.getValueAt(selectedRows[i], 2))));
/*     */     } 
/*     */     
/* 666 */     for (int row = 0; row < this.tracksID1.size(); row++) {
/*     */       
/* 668 */       ProcessTrackMateXml.model.beginUpdate();
/*     */       try {
/* 670 */         ProcessTrackMateXml.model.setTrackVisibility(this.tracksID1.get(row), false);
/*     */       } finally {
/* 672 */         ProcessTrackMateXml.model.endUpdate();
/*     */       } 
/*     */ 
/*     */       
/* 676 */       ProcessTrackMateXml.displayer.refresh();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void createMovieTable() {
/* 684 */     tableImages.setSelectionBackground(new Color(229, 255, 204));
/* 685 */     tableImages.setSelectionForeground(new Color(0, 102, 0));
/* 686 */     DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
/* 687 */     centerRenderer.setHorizontalAlignment(0);
/* 688 */     tableImages.setDefaultRenderer(String.class, centerRenderer);
/* 689 */     tableImages.setAutoResizeMode(0);
/* 690 */     tableImages.setRowHeight(95);
/* 691 */     tableImages.setAutoCreateRowSorter(true);
/* 692 */     tableImages.getTableHeader().setDefaultRenderer(new SimpleHeaderRenderer());
/* 693 */     tableImages.setModel(FirstWizardPanel.modelImages);
/*     */   }
/*     */ 
/*     */   
/*     */   public void paintAndDisableAction() {
/* 698 */     this.indexesToReset = new ArrayList<>();
/* 699 */     this.tracksID = new ArrayList<>();
/*     */     
/* 701 */     for (int i = 0; i < modelTrack.getRowCount(); i++) {
/* 702 */       if (((JLabel)modelTrack.getValueAt(i, tableTrack.convertColumnIndexToModel(1))).getBackground()
/* 703 */         .equals(new Color(214, 217, 223)) == Boolean.TRUE.booleanValue()) {
/* 704 */         this.indexesToReset.add(Integer.valueOf(i));
/* 705 */         modelTrack.setValueAt(Boolean.valueOf(false), i, tableTrack.convertColumnIndexToModel(0));
/* 706 */         this.tracksID.add(Integer.valueOf(Integer.parseInt((String)tableTrack.getValueAt(i, 2))));
/*     */       } 
/* 708 */     }  for (int row = 0; row < this.tracksID.size(); row++) {
/*     */       
/* 710 */       ProcessTrackMateXml.model.beginUpdate();
/*     */       try {
/* 712 */         ProcessTrackMateXml.model.setTrackVisibility(this.tracksID.get(row), false);
/*     */       } finally {
/* 714 */         ProcessTrackMateXml.model.endUpdate();
/*     */       } 
/*     */ 
/*     */       
/* 718 */       ProcessTrackMateXml.displayer.refresh();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void resetAndEnableAction() {
/* 724 */     for (int i = 0; i < this.indexesToReset.size(); i++)
/* 725 */       modelTrack.setValueAt(Boolean.valueOf(true), tableTrack.convertRowIndexToModel(((Integer)this.indexesToReset.get(i)).intValue()), 
/* 726 */           tableTrack.convertColumnIndexToModel(0)); 
/* 727 */     for (int row = 0; row < this.tracksID.size(); row++) {
/* 728 */       ProcessTrackMateXml.model.beginUpdate();
/*     */       try {
/* 730 */         ProcessTrackMateXml.model.setTrackVisibility(this.tracksID.get(row), true);
/*     */       } finally {
/* 732 */         ProcessTrackMateXml.model.endUpdate();
/*     */       } 
/*     */     } 
/* 735 */     ProcessTrackMateXml.displayer.refresh();
/*     */   }
/*     */   
/*     */   public void update() {
/* 739 */     setNextButtonEnabled(true);
/* 740 */     setFinishButtonEnabled(true);
/* 741 */     setBackButtonEnabled(true);
/*     */   }
/*     */   
/*     */   public void next() {
/* 745 */     switchPanel(2);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void back() {
/* 751 */     switchPanel(0);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/SLTDisplayer_.jar!/ChooserWizardPanel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */