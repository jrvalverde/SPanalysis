/*     */ import fiji.plugin.trackmate.Dimension;
/*     */ import fiji.plugin.trackmate.FeatureModel;
/*     */ import fiji.plugin.trackmate.Model;
/*     */ import fiji.plugin.trackmate.SelectionModel;
/*     */ import fiji.plugin.trackmate.Settings;
/*     */ import fiji.plugin.trackmate.Spot;
/*     */ import fiji.plugin.trackmate.TrackMate;
/*     */ import fiji.plugin.trackmate.detection.DogDetectorFactory;
/*     */ import fiji.plugin.trackmate.detection.LogDetectorFactory;
/*     */ import fiji.plugin.trackmate.detection.ManualDetectorFactory;
/*     */ import fiji.plugin.trackmate.detection.SpotDetectorFactoryBase;
/*     */ import fiji.plugin.trackmate.features.FeatureFilter;
/*     */ import fiji.plugin.trackmate.gui.displaysettings.DisplaySettings;
/*     */ import fiji.plugin.trackmate.gui.displaysettings.DisplaySettingsIO;
/*     */ import fiji.plugin.trackmate.io.TmXmlReader;
/*     */ import fiji.plugin.trackmate.tracking.LAPUtils;
/*     */ import fiji.plugin.trackmate.tracking.ManualTrackerFactory;
/*     */ import fiji.plugin.trackmate.tracking.SpotTrackerFactory;
/*     */ import fiji.plugin.trackmate.tracking.kalman.KalmanTrackerFactory;
/*     */ import fiji.plugin.trackmate.tracking.sparselap.SimpleSparseLAPTrackerFactory;
/*     */ import fiji.plugin.trackmate.tracking.sparselap.SparseLAPTrackerFactory;
/*     */ import fiji.plugin.trackmate.visualization.hyperstack.HyperStackDisplayer;
/*     */ import ij.ImagePlus;
/*     */ import ij.ImageStack;
/*     */ import ij.WindowManager;
/*     */ import ij.measure.Calibration;
/*     */ import ij.measure.ResultsTable;
/*     */ import ij.process.ColorProcessor;
/*     */ import ij.process.ImageProcessor;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.event.MouseAdapter;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.stream.Collectors;
/*     */ import java.util.stream.Stream;
/*     */ import javax.swing.ListSelectionModel;
/*     */ import javax.xml.parsers.DocumentBuilder;
/*     */ import javax.xml.parsers.DocumentBuilderFactory;
/*     */ import javax.xml.parsers.ParserConfigurationException;
/*     */ import javax.xml.xpath.XPath;
/*     */ import javax.xml.xpath.XPathConstants;
/*     */ import javax.xml.xpath.XPathExpression;
/*     */ import javax.xml.xpath.XPathExpressionException;
/*     */ import javax.xml.xpath.XPathFactory;
/*     */ import net.imglib2.RealLocalizable;
/*     */ import org.jgrapht.graph.DefaultWeightedEdge;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ import org.xml.sax.SAXException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class null
/*     */   implements Runnable
/*     */ {
/*     */   public void run() {
/* 172 */     File fileXML = new File(SLTDisplayer_.xmlPath);
/* 173 */     List<ImagePlus> impAnalClose = new ArrayList<>();
/* 174 */     int[] IDs = WindowManager.getIDList();
/* 175 */     if (IDs != null)
/* 176 */       for (int i1 = 0; i1 < IDs.length; i1++) {
/* 177 */         impAnalClose.add(WindowManager.getImage(IDs[i1]));
/*     */       } 
/* 179 */     if (FirstWizardPanel.spotEnable.equals("spotEnable") == Boolean.TRUE.booleanValue() && 
/* 180 */       FirstWizardPanel.tableImages.getSelectedRow() != -1) {
/* 181 */       if (IDs != null)
/* 182 */         for (int i1 = 0; i1 < IDs.length; i1++)
/* 183 */           ((ImagePlus)impAnalClose.get(i1)).hide();  
/* 184 */       ProcessTrackMateXml.this.impAnal = ProcessTrackMateXml.this.imps[FirstWizardPanel.tableImages.getSelectedRow()];
/*     */     } 
/* 186 */     if (FirstWizardPanel.spotEnable.equals("spotEnable") == Boolean.TRUE.booleanValue() && 
/* 187 */       FirstWizardPanel.tableImages.getSelectedRow() == -1)
/* 188 */       ProcessTrackMateXml.this.impAnal = ProcessTrackMateXml.this.imps[ChooserWizardPanel.tableImages.getSelectedRow()]; 
/* 189 */     if (ChooserWizardPanel.trackEnable.equals("trackEnable") == Boolean.TRUE.booleanValue() && 
/* 190 */       ChooserWizardPanel.tableImages.getSelectedRow() != -1) {
/* 191 */       if (IDs != null)
/* 192 */         for (int i1 = 0; i1 < IDs.length; i1++) {
/* 193 */           ((ImagePlus)impAnalClose.get(i1)).hide();
/*     */         } 
/* 195 */       ProcessTrackMateXml.this.impAnal = ProcessTrackMateXml.this.imps[ChooserWizardPanel.tableImages.getSelectedRow()];
/*     */     } 
/* 197 */     if (ChooserWizardPanel.trackEnable.equals("trackEnable") == Boolean.TRUE.booleanValue() && 
/* 198 */       ChooserWizardPanel.tableImages.getSelectedRow() == -1) {
/* 199 */       ProcessTrackMateXml.this.impAnal = ProcessTrackMateXml.this.imps[FirstWizardPanel.tableImages.getSelectedRow()];
/*     */     }
/* 201 */     ProcessTrackMateXml.this.impAnal.show();
/* 202 */     int[] dims = ProcessTrackMateXml.this.impAnal.getDimensions();
/*     */     
/* 204 */     if (dims[4] == 1 && dims[3] > 1) {
/*     */       
/* 206 */       ProcessTrackMateXml.this.impAnal.setDimensions(dims[2], dims[4], dims[3]);
/* 207 */       Calibration calibration = ProcessTrackMateXml.this.impAnal.getCalibration();
/* 208 */       calibration.frameInterval = 1.0D;
/*     */     } 
/*     */ 
/*     */     
/* 212 */     TmXmlReader reader = new TmXmlReader(fileXML);
/* 213 */     DocumentBuilderFactory domFactory = DocumentBuilderFactory.newInstance();
/* 214 */     DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
/* 215 */     DocumentBuilder builder = null;
/*     */     try {
/* 217 */       builder = factory.newDocumentBuilder();
/* 218 */     } catch (ParserConfigurationException e) {
/*     */       
/* 220 */       e.printStackTrace();
/*     */     } 
/* 222 */     Document doc = null;
/*     */     try {
/* 224 */       doc = builder.parse(SLTDisplayer_.xmlPath);
/* 225 */     } catch (SAXException e) {
/*     */       
/* 227 */       e.printStackTrace();
/* 228 */     } catch (IOException e) {
/*     */       
/* 230 */       e.printStackTrace();
/*     */     } 
/* 232 */     XPathFactory xPathfactory = XPathFactory.newInstance();
/* 233 */     XPath xpath = xPathfactory.newXPath();
/*     */     
/* 235 */     XPathExpression exprBasicSettings = null;
/* 236 */     XPathExpression exprDetectorSettings = null;
/* 237 */     XPathExpression exprInitialSpotFilter = null;
/* 238 */     XPathExpression exprFilter = null;
/* 239 */     XPathExpression exprTrackerSettings = null;
/* 240 */     XPathExpression exprLinking = null;
/* 241 */     XPathExpression exprGapClosing = null;
/* 242 */     XPathExpression exprSplitting = null;
/* 243 */     XPathExpression exprMerging = null;
/* 244 */     XPathExpression exprTrackFilter = null;
/* 245 */     XPathExpression exprLinkingP = null;
/*     */ 
/*     */     
/*     */     try {
/* 249 */       exprBasicSettings = xpath.compile("//Settings/BasicSettings[@zstart]");
/* 250 */     } catch (XPathExpressionException e) {
/*     */       
/* 252 */       e.printStackTrace();
/*     */     } 
/*     */     
/*     */     try {
/* 256 */       exprLinkingP = xpath.compile("//Linking/FeaturePenalties[@MEAN_INTENSITY]");
/* 257 */     } catch (XPathExpressionException e) {
/*     */       
/* 259 */       e.printStackTrace();
/*     */     } 
/*     */     
/*     */     try {
/* 263 */       exprDetectorSettings = xpath.compile("//Settings/DetectorSettings[@RADIUS]");
/* 264 */     } catch (XPathExpressionException e) {
/*     */       
/* 266 */       e.printStackTrace();
/*     */     } 
/*     */     
/*     */     try {
/* 270 */       exprInitialSpotFilter = xpath.compile("//Settings/InitialSpotFilter[@feature]");
/* 271 */     } catch (XPathExpressionException e) {
/*     */       
/* 273 */       e.printStackTrace();
/*     */     } 
/*     */     
/*     */     try {
/* 277 */       exprFilter = xpath.compile("//SpotFilterCollection/Filter[@feature]");
/* 278 */     } catch (XPathExpressionException e) {
/*     */       
/* 280 */       e.printStackTrace();
/*     */     } 
/*     */ 
/*     */     
/*     */     try {
/* 285 */       exprTrackerSettings = xpath.compile("//Settings/TrackerSettings[@TRACKER_NAME]");
/* 286 */     } catch (XPathExpressionException e) {
/*     */       
/* 288 */       e.printStackTrace();
/*     */     } 
/*     */     
/*     */     try {
/* 292 */       exprLinking = xpath.compile("//TrackerSettings/Linking[@LINKING_MAX_DISTANCE]");
/* 293 */     } catch (XPathExpressionException e) {
/*     */       
/* 295 */       e.printStackTrace();
/*     */     } 
/*     */     
/*     */     try {
/* 299 */       exprGapClosing = xpath.compile("//TrackerSettings/GapClosing[@MAX_FRAME_GAP]");
/* 300 */     } catch (XPathExpressionException e) {
/*     */       
/* 302 */       e.printStackTrace();
/*     */     } 
/*     */     
/*     */     try {
/* 306 */       exprSplitting = xpath
/* 307 */         .compile("//TrackerSettings/TrackSplitting[@SPLITTING_MAX_DISTANCE]");
/* 308 */     } catch (XPathExpressionException e) {
/*     */       
/* 310 */       e.printStackTrace();
/*     */     } 
/*     */     
/*     */     try {
/* 314 */       exprMerging = xpath
/* 315 */         .compile("//TrackerSettings/TrackMerging[@MERGING_MAX_DISTANCE]");
/* 316 */     } catch (XPathExpressionException e) {
/*     */       
/* 318 */       e.printStackTrace();
/*     */     } 
/*     */     
/*     */     try {
/* 322 */       exprTrackFilter = xpath.compile("//TrackFilterCollection/Filter[@feature]");
/* 323 */     } catch (XPathExpressionException e) {
/*     */       
/* 325 */       e.printStackTrace();
/*     */     } 
/*     */     
/* 328 */     NodeList nlBasicSettings = null;
/* 329 */     NodeList nlDetectorSettings = null;
/* 330 */     NodeList nlInitialSpotFilter = null;
/* 331 */     NodeList nlFilter = null;
/* 332 */     NodeList nlTrackerSettings = null;
/* 333 */     NodeList nlLinking = null;
/* 334 */     NodeList nlGapClosing = null;
/* 335 */     NodeList nlSplitting = null;
/* 336 */     NodeList nlMerging = null;
/* 337 */     NodeList nlTrackFilter = null;
/* 338 */     NodeList nlLinkingP = null;
/*     */     
/*     */     try {
/* 341 */       nlBasicSettings = (NodeList)exprBasicSettings.evaluate(doc, XPathConstants.NODESET);
/* 342 */       nlDetectorSettings = (NodeList)exprDetectorSettings.evaluate(doc, XPathConstants.NODESET);
/* 343 */       nlInitialSpotFilter = (NodeList)exprInitialSpotFilter.evaluate(doc, XPathConstants.NODESET);
/* 344 */       nlFilter = (NodeList)exprFilter.evaluate(doc, XPathConstants.NODESET);
/* 345 */       nlTrackerSettings = (NodeList)exprTrackerSettings.evaluate(doc, XPathConstants.NODESET);
/* 346 */       nlLinking = (NodeList)exprLinking.evaluate(doc, XPathConstants.NODESET);
/* 347 */       nlGapClosing = (NodeList)exprGapClosing.evaluate(doc, XPathConstants.NODESET);
/* 348 */       nlSplitting = (NodeList)exprSplitting.evaluate(doc, XPathConstants.NODESET);
/* 349 */       nlMerging = (NodeList)exprMerging.evaluate(doc, XPathConstants.NODESET);
/* 350 */       nlTrackFilter = (NodeList)exprTrackFilter.evaluate(doc, XPathConstants.NODESET);
/* 351 */       nlLinkingP = (NodeList)exprLinkingP.evaluate(doc, XPathConstants.NODESET);
/*     */     }
/* 353 */     catch (XPathExpressionException e) {
/*     */       
/* 355 */       e.printStackTrace();
/*     */     } 
/*     */     
/* 358 */     for (int i = 0; i < nlBasicSettings.getLength(); i++) {
/* 359 */       Node node = nlBasicSettings.item(i);
/* 360 */       ProcessTrackMateXml.this.zstart = node.getAttributes().getNamedItem("zstart").getNodeValue();
/* 361 */       ProcessTrackMateXml.this.zend = node.getAttributes().getNamedItem("zend").getNodeValue();
/* 362 */       ProcessTrackMateXml.this.ystart = node.getAttributes().getNamedItem("ystart").getNodeValue();
/* 363 */       ProcessTrackMateXml.this.yend = node.getAttributes().getNamedItem("yend").getNodeValue();
/* 364 */       ProcessTrackMateXml.this.xstart = node.getAttributes().getNamedItem("xstart").getNodeValue();
/* 365 */       ProcessTrackMateXml.this.xend = node.getAttributes().getNamedItem("xend").getNodeValue();
/* 366 */       ProcessTrackMateXml.this.tstart = node.getAttributes().getNamedItem("tstart").getNodeValue();
/* 367 */       ProcessTrackMateXml.this.tend = node.getAttributes().getNamedItem("tend").getNodeValue();
/*     */     } 
/* 369 */     Node currentItem = null;
/* 370 */     for (int j = 0; j < nlDetectorSettings.getLength(); j++) {
/* 371 */       currentItem = nlDetectorSettings.item(j);
/* 372 */       ProcessTrackMateXml.this.RADIUS = currentItem.getAttributes().getNamedItem("RADIUS").getNodeValue();
/* 373 */       ProcessTrackMateXml.this.THRESHOLD = currentItem.getAttributes().getNamedItem("THRESHOLD").getNodeValue();
/* 374 */       ProcessTrackMateXml.this.TARGET_CHANNEL = currentItem.getAttributes().getNamedItem("TARGET_CHANNEL").getNodeValue();
/* 375 */       ProcessTrackMateXml.this.DO_SUBPIXEL_LOCALIZATION = currentItem.getAttributes().getNamedItem("DO_SUBPIXEL_LOCALIZATION")
/* 376 */         .getNodeValue();
/* 377 */       ProcessTrackMateXml.this.DO_MEDIAN_FILTERING = currentItem.getAttributes().getNamedItem("DO_MEDIAN_FILTERING")
/* 378 */         .getNodeValue();
/* 379 */       ProcessTrackMateXml.this.DETECTOR_NAME = currentItem.getAttributes().getNamedItem("DETECTOR_NAME").getNodeValue();
/* 380 */       if (ProcessTrackMateXml.this.DETECTOR_NAME.equals("BLOCK_LOG_DETECTOR"))
/* 381 */         ProcessTrackMateXml.this.NSPLIT = currentItem.getAttributes().getNamedItem("NSPLIT").getNodeValue(); 
/* 382 */       if (ProcessTrackMateXml.this.DETECTOR_NAME.equals("DOWNSAMLE_LOG_DETECTOR")) {
/* 383 */         ProcessTrackMateXml.this.DOWNSAMPLE_FACTOR = currentItem.getAttributes().getNamedItem("DOWNSAMPLE_FACTOR")
/* 384 */           .getNodeValue();
/*     */       }
/*     */     } 
/*     */     
/* 388 */     String linkingNames = null;
/* 389 */     String linkingValues = null; int k;
/* 390 */     for (k = 0; k < nlLinkingP.getLength(); k++) {
/* 391 */       linkingNames = nlLinkingP.item(k).getAttributes().item(k).getNodeName();
/* 392 */       linkingValues = nlLinkingP.item(k).getAttributes().item(k).getNodeValue();
/*     */     } 
/* 394 */     for (k = 0; k < nlInitialSpotFilter.getLength(); k++) {
/* 395 */       currentItem = nlInitialSpotFilter.item(k);
/* 396 */       ProcessTrackMateXml.this.initialSpotFilter = currentItem.getAttributes().getNamedItem("value").getNodeValue();
/*     */     } 
/*     */     
/* 399 */     String initialFilterFeature = null;
/* 400 */     String initialFilterValue = null;
/* 401 */     String initialFilterAbove = null;
/* 402 */     for (int m = 0; m < nlFilter.getLength(); m++) {
/* 403 */       currentItem = nlFilter.item(m);
/* 404 */       initialFilterFeature = currentItem.getAttributes().getNamedItem("feature").getNodeValue();
/* 405 */       initialFilterValue = currentItem.getAttributes().getNamedItem("value").getNodeValue();
/* 406 */       initialFilterAbove = currentItem.getAttributes().getNamedItem("isabove").getNodeValue();
/*     */     } 
/*     */ 
/*     */     
/* 410 */     String initialTrackFilterFeature = null;
/* 411 */     String initialTrackFilterValue = null;
/* 412 */     String initialTrackFilterAbove = null;
/*     */     int n;
/* 414 */     for (n = 0; n < nlTrackerSettings.getLength(); n++) {
/* 415 */       currentItem = nlTrackerSettings.item(n);
/* 416 */       ProcessTrackMateXml.this.TRACKER_NAME = currentItem.getAttributes().getNamedItem("TRACKER_NAME").getNodeValue();
/* 417 */       ProcessTrackMateXml.this.CUTOFF_PERCENTILE = currentItem.getAttributes().getNamedItem("CUTOFF_PERCENTILE").getNodeValue();
/* 418 */       ProcessTrackMateXml.this.BLOCKING_VALUE = currentItem.getAttributes().getNamedItem("BLOCKING_VALUE").getNodeValue();
/* 419 */       ProcessTrackMateXml.this.ALTERNATIVE_LINKING_COST_FACTOR = currentItem.getAttributes()
/* 420 */         .getNamedItem("ALTERNATIVE_LINKING_COST_FACTOR").getNodeValue();
/*     */     } 
/* 422 */     for (n = 0; n < nlLinking.getLength(); n++) {
/* 423 */       currentItem = nlLinking.item(n);
/* 424 */       ProcessTrackMateXml.this.LINKING_MAX_DISTANCE = currentItem.getAttributes().getNamedItem("LINKING_MAX_DISTANCE")
/* 425 */         .getNodeValue();
/*     */     } 
/* 427 */     for (n = 0; n < nlGapClosing.getLength(); n++) {
/* 428 */       currentItem = nlGapClosing.item(n);
/* 429 */       ProcessTrackMateXml.this.MAX_FRAME_GAP = currentItem.getAttributes().getNamedItem("MAX_FRAME_GAP").getNodeValue();
/* 430 */       ProcessTrackMateXml.this.MAX_DISTANCE = currentItem.getAttributes().getNamedItem("GAP_CLOSING_MAX_DISTANCE").getNodeValue();
/* 431 */       ProcessTrackMateXml.this.ALLOW_GAP_CLOSING = currentItem.getAttributes().getNamedItem("ALLOW_GAP_CLOSING").getNodeValue();
/*     */     } 
/*     */     
/* 434 */     for (n = 0; n < nlSplitting.getLength(); n++) {
/* 435 */       currentItem = nlSplitting.item(n);
/* 436 */       ProcessTrackMateXml.this.SPLITTING_MAX_DISTANCE = currentItem.getAttributes().getNamedItem("SPLITTING_MAX_DISTANCE")
/* 437 */         .getNodeValue();
/* 438 */       ProcessTrackMateXml.this.ALLOW_TRACK_SPLITTING = currentItem.getAttributes().getNamedItem("ALLOW_TRACK_SPLITTING")
/* 439 */         .getNodeValue();
/*     */     } 
/* 441 */     for (n = 0; n < nlMerging.getLength(); n++) {
/* 442 */       currentItem = nlMerging.item(n);
/* 443 */       ProcessTrackMateXml.this.MERGING_MAX_DISTANCE = currentItem.getAttributes().getNamedItem("MERGING_MAX_DISTANCE")
/* 444 */         .getNodeValue();
/* 445 */       ProcessTrackMateXml.this.ALLOW_TRACK_MERGING = currentItem.getAttributes().getNamedItem("ALLOW_TRACK_MERGING")
/* 446 */         .getNodeValue();
/*     */     } 
/*     */     
/* 449 */     ProcessTrackMateXml.settings = new Settings(ProcessTrackMateXml.this.impAnal);
/*     */     
/* 451 */     ProcessTrackMateXml.settings.dt = 0.05D;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 469 */     if (ProcessTrackMateXml.this.DETECTOR_NAME.equals("LOG_DETECTOR")) {
/*     */       
/* 471 */       ProcessTrackMateXml.settings.detectorFactory = (SpotDetectorFactoryBase)new LogDetectorFactory();
/* 472 */       ProcessTrackMateXml.settings.detectorSettings = ProcessTrackMateXml.settings.detectorFactory.getDefaultSettings();
/* 473 */       ProcessTrackMateXml.settings.detectorSettings.put("DO_SUBPIXEL_LOCALIZATION", 
/* 474 */           Boolean.valueOf(Boolean.parseBoolean(ProcessTrackMateXml.this.DO_SUBPIXEL_LOCALIZATION)));
/* 475 */       ProcessTrackMateXml.settings.detectorSettings.put("RADIUS", Double.valueOf(Double.parseDouble(ProcessTrackMateXml.this.RADIUS)));
/* 476 */       ProcessTrackMateXml.settings.detectorSettings.put("TARGET_CHANNEL", Integer.valueOf(Integer.parseInt(ProcessTrackMateXml.this.TARGET_CHANNEL)));
/* 477 */       ProcessTrackMateXml.settings.detectorSettings.put("THRESHOLD", Double.valueOf(Double.parseDouble(ProcessTrackMateXml.this.THRESHOLD)));
/* 478 */       ProcessTrackMateXml.settings.detectorSettings.put("DO_MEDIAN_FILTERING", 
/* 479 */           Boolean.valueOf(Boolean.parseBoolean(ProcessTrackMateXml.this.DO_MEDIAN_FILTERING)));
/* 480 */       if (ProcessTrackMateXml.this.initialSpotFilter != null) {
/* 481 */         ProcessTrackMateXml.settings.initialSpotFilterValue = Double.valueOf(Double.parseDouble(ProcessTrackMateXml.this.initialSpotFilter));
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 496 */       if (ProcessTrackMateXml.this.DETECTOR_NAME.equals("MANUAL_DETECTOR")) {
/*     */         
/* 498 */         ProcessTrackMateXml.settings.detectorFactory = (SpotDetectorFactoryBase)new ManualDetectorFactory();
/* 499 */         ProcessTrackMateXml.settings.detectorSettings.put("RADIUS", Double.valueOf(Double.parseDouble(ProcessTrackMateXml.this.RADIUS)));
/* 500 */         if (ProcessTrackMateXml.this.initialSpotFilter != null) {
/* 501 */           ProcessTrackMateXml.settings.initialSpotFilterValue = Double.valueOf(Double.parseDouble(ProcessTrackMateXml.this.initialSpotFilter));
/*     */         }
/*     */       } 
/*     */       
/* 505 */       if (ProcessTrackMateXml.this.DETECTOR_NAME.equals("DOG_DETECTOR")) {
/* 506 */         ProcessTrackMateXml.settings.detectorFactory = (SpotDetectorFactoryBase)new DogDetectorFactory();
/* 507 */         ProcessTrackMateXml.settings.detectorSettings.put("DO_SUBPIXEL_LOCALIZATION", 
/* 508 */             Boolean.valueOf(Boolean.parseBoolean(ProcessTrackMateXml.this.DO_SUBPIXEL_LOCALIZATION)));
/* 509 */         ProcessTrackMateXml.settings.detectorSettings.put("RADIUS", Double.valueOf(Double.parseDouble(ProcessTrackMateXml.this.RADIUS)));
/* 510 */         ProcessTrackMateXml.settings.detectorSettings.put("TARGET_CHANNEL", 
/* 511 */             Integer.valueOf(Integer.parseInt(ProcessTrackMateXml.this.TARGET_CHANNEL)));
/* 512 */         ProcessTrackMateXml.settings.detectorSettings.put("THRESHOLD", Double.valueOf(Double.parseDouble(ProcessTrackMateXml.this.THRESHOLD)));
/* 513 */         ProcessTrackMateXml.settings.detectorSettings.put("DO_MEDIAN_FILTERING", 
/* 514 */             Double.valueOf(Double.parseDouble(ProcessTrackMateXml.this.DO_MEDIAN_FILTERING)));
/* 515 */         if (ProcessTrackMateXml.this.initialSpotFilter != null) {
/* 516 */           ProcessTrackMateXml.settings.initialSpotFilterValue = Double.valueOf(Double.parseDouble(ProcessTrackMateXml.this.initialSpotFilter));
/*     */         }
/*     */       } 
/*     */       
/* 520 */       if (initialFilterFeature != null) {
/*     */         
/* 522 */         FeatureFilter filter1 = new FeatureFilter(initialFilterFeature, 
/* 523 */             Double.parseDouble(initialFilterValue), Boolean.parseBoolean(initialFilterAbove));
/*     */         
/* 525 */         ProcessTrackMateXml.settings.addSpotFilter(filter1);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 530 */     if (ProcessTrackMateXml.this.TRACKER_NAME.equals("MANUAL_TRACKER")) {
/*     */       
/* 532 */       ProcessTrackMateXml.settings.trackerFactory = (SpotTrackerFactory)new ManualTrackerFactory();
/* 533 */       ProcessTrackMateXml.settings.trackerSettings = LAPUtils.getDefaultLAPSettingsMap();
/*     */     } 
/*     */     
/* 536 */     if (ProcessTrackMateXml.this.TRACKER_NAME.equals("MANUAL_TRACKER")) {
/* 537 */       ProcessTrackMateXml.settings.trackerFactory = (SpotTrackerFactory)new ManualTrackerFactory();
/* 538 */       ProcessTrackMateXml.settings.trackerSettings = LAPUtils.getDefaultLAPSettingsMap();
/*     */     } 
/*     */ 
/*     */     
/* 542 */     if (ProcessTrackMateXml.this.TRACKER_NAME.equals("KALMAN_TRACKER")) {
/*     */       
/* 544 */       ProcessTrackMateXml.settings.trackerFactory = (SpotTrackerFactory)new KalmanTrackerFactory();
/* 545 */       ProcessTrackMateXml.settings.trackerSettings = LAPUtils.getDefaultLAPSettingsMap();
/* 546 */       ProcessTrackMateXml.settings.trackerSettings.put("KALMAN_SEARCH_RADIUS", 
/* 547 */           Double.valueOf(Double.parseDouble(ProcessTrackMateXml.this.RADIUS)));
/*     */     } 
/*     */ 
/*     */     
/* 551 */     if (ProcessTrackMateXml.this.TRACKER_NAME.equals("SIMPLE_SPARSE_LAP_TRACKER")) {
/*     */       
/* 553 */       ProcessTrackMateXml.settings.trackerFactory = (SpotTrackerFactory)new SimpleSparseLAPTrackerFactory();
/* 554 */       ProcessTrackMateXml.settings.trackerSettings = LAPUtils.getDefaultLAPSettingsMap();
/* 555 */       ProcessTrackMateXml.settings.trackerSettings.put("LINKING_MAX_DISTANCE", 
/* 556 */           Double.valueOf(Double.parseDouble(ProcessTrackMateXml.this.LINKING_MAX_DISTANCE)));
/* 557 */       ProcessTrackMateXml.settings.trackerSettings.put("GAP_CLOSING_MAX_DISTANCE", 
/* 558 */           Double.valueOf(Double.parseDouble(ProcessTrackMateXml.this.MAX_DISTANCE)));
/* 559 */       ProcessTrackMateXml.settings.trackerSettings.put("MAX_FRAME_GAP", 
/* 560 */           Double.valueOf(Double.parseDouble(ProcessTrackMateXml.this.MAX_FRAME_GAP)));
/*     */     } 
/*     */ 
/*     */     
/* 564 */     if (ProcessTrackMateXml.this.TRACKER_NAME.equals("SPARSE_LAP_TRACKER")) {
/*     */       
/* 566 */       ProcessTrackMateXml.settings.trackerFactory = (SpotTrackerFactory)new SparseLAPTrackerFactory();
/* 567 */       ProcessTrackMateXml.settings.trackerSettings = LAPUtils.getDefaultLAPSettingsMap();
/* 568 */       ProcessTrackMateXml.settings.trackerSettings.put("LINKING_MAX_DISTANCE", 
/* 569 */           Double.valueOf(Double.parseDouble(ProcessTrackMateXml.this.LINKING_MAX_DISTANCE)));
/* 570 */       Map<String, Double> linkingPenalty = 
/* 571 */         (Map<String, Double>)Stream.<Object[]>of(new Object[][] { { "MEAN_INTENSITY", Double.valueOf(1.0D) }, { "QUALITY", Double.valueOf(1.0D)
/*     */             }
/* 573 */           }).collect(Collectors.toMap(data -> (String)data[0], data -> (Double)data[1]));
/*     */       
/* 575 */       ProcessTrackMateXml.settings.trackerSettings.put("ALLOW_GAP_CLOSING", 
/* 576 */           Boolean.valueOf(Boolean.parseBoolean(ProcessTrackMateXml.this.ALLOW_GAP_CLOSING)));
/* 577 */       if (Boolean.parseBoolean(ProcessTrackMateXml.this.ALLOW_GAP_CLOSING)) {
/* 578 */         ProcessTrackMateXml.settings.trackerSettings.put("MAX_FRAME_GAP", 
/* 579 */             Integer.valueOf(Integer.parseInt(ProcessTrackMateXml.this.MAX_FRAME_GAP)));
/* 580 */         ProcessTrackMateXml.settings.trackerSettings.put("GAP_CLOSING_MAX_DISTANCE", 
/* 581 */             Double.valueOf(Double.parseDouble(ProcessTrackMateXml.this.MAX_DISTANCE)));
/*     */         
/* 583 */         Map map = 
/* 584 */           (Map)Stream.<Object[]>of(new Object[][] { { "MEAN_INTENSITY", Double.valueOf(1.0D) }, { "QUALITY", Double.valueOf(1.0D)
/* 585 */               } }).collect(Collectors.toMap(data -> (String)data[0], data -> (Double)data[1]));
/*     */       } 
/*     */ 
/*     */       
/* 589 */       ProcessTrackMateXml.settings.trackerSettings.put("ALLOW_TRACK_SPLITTING", 
/* 590 */           Boolean.valueOf(Boolean.parseBoolean(ProcessTrackMateXml.this.ALLOW_TRACK_SPLITTING)));
/* 591 */       if (Boolean.parseBoolean(ProcessTrackMateXml.this.ALLOW_TRACK_SPLITTING)) {
/* 592 */         ProcessTrackMateXml.settings.trackerSettings.put("SPLITTING_MAX_DISTANCE", 
/* 593 */             Double.valueOf(Double.parseDouble(ProcessTrackMateXml.this.SPLITTING_MAX_DISTANCE)));
/* 594 */         Map map = 
/* 595 */           (Map)Stream.<Object[]>of(new Object[][] { { "MEAN_INTENSITY", Double.valueOf(1.0D) }, { "QUALITY", Double.valueOf(1.0D)
/* 596 */               } }).collect(Collectors.toMap(data -> (String)data[0], data -> (Double)data[1]));
/*     */       } 
/*     */ 
/*     */       
/* 600 */       ProcessTrackMateXml.settings.trackerSettings.put("ALLOW_TRACK_MERGING", 
/* 601 */           Boolean.valueOf(Boolean.parseBoolean(ProcessTrackMateXml.this.ALLOW_TRACK_MERGING)));
/* 602 */       if (Boolean.parseBoolean(ProcessTrackMateXml.this.ALLOW_TRACK_MERGING)) {
/* 603 */         ProcessTrackMateXml.settings.trackerSettings.put("MERGING_MAX_DISTANCE", 
/* 604 */             Double.valueOf(Double.parseDouble(ProcessTrackMateXml.this.MERGING_MAX_DISTANCE)));
/* 605 */         Map map = 
/* 606 */           (Map)Stream.<Object[]>of(new Object[][] { { "MEAN_INTENSITY", Double.valueOf(1.0D) }, { "QUALITY", Double.valueOf(1.0D)
/* 607 */               } }).collect(Collectors.toMap(data -> (String)data[0], data -> (Double)data[1]));
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 613 */     ProcessTrackMateXml.settings.addAllAnalyzers();
/*     */     
/* 615 */     ProcessTrackMateXml.model = new Model();
/* 616 */     ProcessTrackMateXml.trackmate = new TrackMate(ProcessTrackMateXml.model, ProcessTrackMateXml.settings);
/*     */     
/* 618 */     Boolean ok = null;
/*     */     
/* 620 */     ok = Boolean.valueOf(ProcessTrackMateXml.trackmate.checkInput());
/* 621 */     ok = Boolean.valueOf(ProcessTrackMateXml.trackmate.process());
/*     */     
/* 623 */     FeatureModel fm = ProcessTrackMateXml.model.getFeatureModel();
/* 624 */     Set<Integer> trackIDs = ProcessTrackMateXml.model.getTrackModel().trackIDs(true);
/* 625 */     Set<Spot> track = null;
/* 626 */     for (int id = 0; id < trackIDs.size(); id++) {
/* 627 */       Double v = fm.getTrackFeature(Integer.valueOf(id), "TRACK_MEAN_SPEED");
/* 628 */       track = ProcessTrackMateXml.model.getTrackModel().trackSpots(Integer.valueOf(id));
/*     */     } 
/*     */     
/* 631 */     for (Spot spot : track) {
/* 632 */       int sid = spot.ID();
/* 633 */       Double x = spot.getFeature("POSITION_X");
/* 634 */       Double y = spot.getFeature("POSITION_Y");
/* 635 */       Double t = spot.getFeature("FRAME");
/* 636 */       Double q = spot.getFeature("QUALITY");
/* 637 */       Double snr = spot.getFeature("SNR");
/* 638 */       Double double_1 = spot.getFeature("MEAN_INTENSITY");
/*     */     } 
/* 640 */     ProcessTrackMateXml.this.totalSpots = ProcessTrackMateXml.model.getSpots();
/* 641 */     ProcessTrackMateXml.displayer = null;
/* 642 */     ProcessTrackMateXml.selectionModel = new SelectionModel(ProcessTrackMateXml.model);
/* 643 */     DisplaySettings ds = DisplaySettingsIO.readUserDefault();
/* 644 */     ds.setSpotShowName(true);
/* 645 */     ds.setSpotVisible(true);
/* 646 */     ds.setSpotColorBy(DisplaySettings.TrackMateObject.TRACKS, "TRACK_INDEX");
/* 647 */     ds.setTrackVisible(true);
/* 648 */     ds.setTrackColorBy(DisplaySettings.TrackMateObject.TRACKS, "TRACK_INDEX");
/* 649 */     ds.setTrackDisplayMode(DisplaySettings.TrackDisplayMode.FULL);
/* 650 */     ProcessTrackMateXml.displayer = new HyperStackDisplayer(ProcessTrackMateXml.model, ProcessTrackMateXml.selectionModel, ProcessTrackMateXml.this.impAnal, ds);
/* 651 */     ProcessTrackMateXml.displayer.render();
/* 652 */     ProcessTrackMateXml.displayer.refresh();
/*     */     
/* 654 */     Rectangle bounds = null;
/* 655 */     Integer firstFrame = null;
/* 656 */     Integer lastFrame = null;
/* 657 */     Integer width = null;
/* 658 */     Integer height = null;
/* 659 */     Integer nCaptures = null;
/* 660 */     ImageStack stack = null;
/* 661 */     Integer channel = null;
/* 662 */     Integer slice = null;
/* 663 */     BufferedImage bi = null;
/* 664 */     ColorProcessor cp = null;
/* 665 */     Integer index = null;
/* 666 */     ImagePlus capture = null;
/*     */     
/* 668 */     if (ProcessTrackMateXml.this.impAnal.getNFrames() > 1) {
/* 669 */       firstFrame = Integer.valueOf(Math.max(1, Math.min(ProcessTrackMateXml.this.impAnal.getNFrames(), 1)));
/* 670 */       lastFrame = Integer.valueOf(Math.min(ProcessTrackMateXml.this.impAnal.getNFrames(), Math.max(ProcessTrackMateXml.this.impAnal.getNFrames(), 1)));
/*     */     } 
/* 672 */     if (ProcessTrackMateXml.this.impAnal.getNSlices() > 1) {
/* 673 */       firstFrame = Integer.valueOf(Math.max(1, Math.min(ProcessTrackMateXml.this.impAnal.getNSlices(), 1)));
/* 674 */       lastFrame = Integer.valueOf(Math.min(ProcessTrackMateXml.this.impAnal.getNSlices(), Math.max(ProcessTrackMateXml.this.impAnal.getNSlices(), 1)));
/*     */     } 
/* 676 */     bounds = ProcessTrackMateXml.displayer.getImp().getCanvas().getBounds();
/* 677 */     width = Integer.valueOf(bounds.width);
/* 678 */     height = Integer.valueOf(bounds.height);
/* 679 */     nCaptures = Integer.valueOf(lastFrame.intValue() - firstFrame.intValue() + 1);
/* 680 */     stack = new ImageStack(width.intValue(), height.intValue());
/*     */     
/* 682 */     channel = Integer.valueOf(ProcessTrackMateXml.displayer.getImp().getChannel());
/* 683 */     slice = Integer.valueOf(ProcessTrackMateXml.displayer.getImp().getSlice());
/* 684 */     ProcessTrackMateXml.displayer.getImp().getCanvas().hideZoomIndicator(true);
/* 685 */     for (int frame = firstFrame.intValue(); frame <= lastFrame.intValue(); frame++) {
/* 686 */       ProcessTrackMateXml.displayer.getImp().setPositionWithoutUpdate(channel.intValue(), slice.intValue(), frame);
/* 687 */       bi = new BufferedImage(width.intValue(), height.intValue(), 2);
/* 688 */       ProcessTrackMateXml.displayer.getImp().getCanvas().paint(bi.getGraphics());
/* 689 */       cp = new ColorProcessor(bi);
/* 690 */       index = Integer.valueOf(ProcessTrackMateXml.displayer.getImp().getStackIndex(channel.intValue(), slice.intValue(), frame));
/* 691 */       stack.addSlice(ProcessTrackMateXml.displayer.getImp().getImageStack().getSliceLabel(index.intValue()), (ImageProcessor)cp);
/*     */     } 
/* 693 */     ProcessTrackMateXml.displayer.getImp().getCanvas().hideZoomIndicator(false);
/* 694 */     capture = new ImagePlus("TrackMate capture of " + ProcessTrackMateXml.displayer.getImp().getShortTitle(), stack);
/* 695 */     ProcessTrackMateXml.access$0(ProcessTrackMateXml.displayer.getImp(), capture);
/*     */     
/* 697 */     if (FirstWizardPanel.spotEnable.equals("spotEnable") == Boolean.TRUE.booleanValue()) {
/*     */ 
/*     */       
/* 700 */       final Model model = ProcessTrackMateXml.trackmate.getModel();
/* 701 */       FeatureModel fm1 = model.getFeatureModel();
/*     */ 
/*     */ 
/*     */       
/* 705 */       Set<Integer> trackIDs1 = model.getTrackModel().trackIDs(true);
/* 706 */       Collection<String> spotFeatures = ProcessTrackMateXml.trackmate.getModel().getFeatureModel().getSpotFeatures();
/*     */       
/* 708 */       ResultsTable spotTable = new ResultsTable();
/*     */ 
/*     */       
/* 711 */       for (Integer trackID : trackIDs1) {
/* 712 */         Set<Spot> track1 = model.getTrackModel().trackSpots(trackID);
/*     */         
/* 714 */         List<Spot> sortedTrack = new ArrayList<>(track1);
/* 715 */         Collections.sort(sortedTrack, Spot.frameComparator);
/*     */         
/* 717 */         for (Spot spot : sortedTrack) {
/* 718 */           spotTable.incrementCounter();
/* 719 */           spotTable.addLabel(spot.getName());
/* 720 */           spotTable.addValue("ID", spot.ID());
/* 721 */           spotTable.addValue("TRACK_ID", trackID.intValue());
/* 722 */           for (String feature : spotFeatures) {
/* 723 */             Double val = spot.getFeature(feature);
/* 724 */             if (val == null) {
/* 725 */               spotTable.addValue(feature, "None"); continue;
/*     */             } 
/* 727 */             if (((Boolean)fm1.getSpotFeatureIsInt().get(feature)).booleanValue()) {
/* 728 */               spotTable.addValue(feature, val.intValue()); continue;
/*     */             } 
/* 730 */             spotTable.addValue(feature, val.doubleValue());
/*     */           } 
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 736 */       ProcessTrackMateXml.columnHeadersSpot = spotTable.getHeadings();
/* 737 */       int rowsSpot = spotTable.size();
/* 738 */       List<List<String>> dataListSpot = new ArrayList<>();
/* 739 */       for (int r = 0; r < rowsSpot; r++) {
/* 740 */         List<String> stringsSpot = new ArrayList<>();
/* 741 */         for (int c = 0; c < ProcessTrackMateXml.columnHeadersSpot.length; c++) {
/* 742 */           String valuesSpot = spotTable.getStringValue(ProcessTrackMateXml.columnHeadersSpot[c], r);
/* 743 */           stringsSpot.add(valuesSpot);
/*     */         } 
/*     */         
/* 746 */         dataListSpot.add(stringsSpot);
/*     */       } 
/* 748 */       ProcessTrackMateXml.dataSpot = new String[dataListSpot.size()][]; int i1;
/* 749 */       for (i1 = 0; i1 < ProcessTrackMateXml.dataSpot.length; i1++) {
/* 750 */         ProcessTrackMateXml.dataSpot[i1] = new String[((List)dataListSpot.get(i1)).size()];
/*     */       }
/* 752 */       for (i1 = 0; i1 < dataListSpot.size(); i1++) {
/* 753 */         for (int u = 1; u < ((List)dataListSpot.get(i1)).size(); u++)
/* 754 */           ProcessTrackMateXml.dataSpot[i1][u] = ((List<String>)dataListSpot.get(i1)).get(u); 
/*     */       } 
/* 756 */       FirstWizardPanel.createSpotTable();
/*     */       
/* 758 */       FirstWizardPanel.tableSpot.addMouseListener(new MouseAdapter()
/*     */           {
/*     */             public void mouseReleased(MouseEvent e)
/*     */             {
/* 762 */               if (ProcessTrackMateXml.selectionModel != null && FirstWizardPanel.command == "enable" && 
/* 763 */                 FirstWizardPanel.command != null) {
/* 764 */                 ListSelectionModel lsm = FirstWizardPanel.tableSpot.getSelectionModel();
/* 765 */                 int selStart = lsm.getMinSelectionIndex();
/* 766 */                 int selEnd = lsm.getMaxSelectionIndex();
/* 767 */                 if (selStart < 0 || selEnd < 0) {
/*     */                   return;
/*     */                 }
/* 770 */                 int minLine = Math.min(selStart, selEnd);
/* 771 */                 int maxLine = Math.max(selStart, selEnd);
/* 772 */                 Set<Spot> spots = new HashSet<>();
/* 773 */                 for (int row = minLine; row <= maxLine; row++) {
/* 774 */                   int spotID = 
/* 775 */                     Integer.parseInt((String)FirstWizardPanel.tableSpot.getValueAt(row, 2));
/* 776 */                   Spot spot = (ProcessTrackMateXml.null.access$8(ProcessTrackMateXml.null.this)).totalSpots.search(spotID);
/* 777 */                   if (spot != null)
/* 778 */                     spots.add(spot); 
/*     */                 } 
/* 780 */                 ProcessTrackMateXml.selectionModel.clearSelection();
/* 781 */                 ProcessTrackMateXml.selectionModel.addSpotToSelection(spots);
/*     */               } 
/*     */             }
/*     */           });
/*     */     } 
/*     */ 
/*     */     
/* 788 */     if (ChooserWizardPanel.trackEnable.equals("trackEnable") == Boolean.TRUE.booleanValue()) {
/*     */       
/* 790 */       ProcessTrackMateXml.FEATURES.add("TOTAL_DISTANCE_TRAVELED");
/* 791 */       ProcessTrackMateXml.FEATURES.add("MAX_DISTANCE_TRAVELED");
/* 792 */       ProcessTrackMateXml.FEATURES.add("CONFINMENT_RATIO");
/* 793 */       ProcessTrackMateXml.FEATURES.add("MEAN_STRAIGHT_LINE_SPEED");
/* 794 */       ProcessTrackMateXml.FEATURES.add("LINEARITY_OF_FORWARD_PROGRESSION");
/*     */       
/* 796 */       ProcessTrackMateXml.FEATURES.add("TOTAL_ABSOLUTE_ANGLE_XY");
/* 797 */       ProcessTrackMateXml.FEATURES.add("TOTAL_ABSOLUTE_ANGLE_YZ");
/* 798 */       ProcessTrackMateXml.FEATURES.add("TOTAL_ABSOLUTE_ANGLE_ZX");
/*     */       
/* 800 */       ProcessTrackMateXml.FEATURE_NAMES.put("TOTAL_DISTANCE_TRAVELED", "Total distance traveled");
/* 801 */       ProcessTrackMateXml.FEATURE_NAMES.put("MAX_DISTANCE_TRAVELED", "Max distance traveled");
/* 802 */       ProcessTrackMateXml.FEATURE_NAMES.put("CONFINMENT_RATIO", "Confinment ratio");
/* 803 */       ProcessTrackMateXml.FEATURE_NAMES.put("MEAN_STRAIGHT_LINE_SPEED", "Mean straight line speed");
/* 804 */       ProcessTrackMateXml.FEATURE_NAMES.put("LINEARITY_OF_FORWARD_PROGRESSION", "Linearity of forward progression");
/*     */ 
/*     */       
/* 807 */       ProcessTrackMateXml.FEATURE_NAMES.put("TOTAL_ABSOLUTE_ANGLE_XY", "Absolute angle in xy plane");
/* 808 */       ProcessTrackMateXml.FEATURE_NAMES.put("TOTAL_ABSOLUTE_ANGLE_YZ", "Absolute angle in yz plane");
/* 809 */       ProcessTrackMateXml.FEATURE_NAMES.put("TOTAL_ABSOLUTE_ANGLE_ZX", "Absolute angle in zx plane");
/*     */       
/* 811 */       ProcessTrackMateXml.FEATURE_SHORT_NAMES.put("TOTAL_DISTANCE_TRAVELED", "Total dist.");
/* 812 */       ProcessTrackMateXml.FEATURE_SHORT_NAMES.put("MAX_DISTANCE_TRAVELED", "Max dist.");
/* 813 */       ProcessTrackMateXml.FEATURE_SHORT_NAMES.put("CONFINMENT_RATIO", "Cnfnmnt ratio");
/* 814 */       ProcessTrackMateXml.FEATURE_SHORT_NAMES.put("MEAN_STRAIGHT_LINE_SPEED", "Mean v. line");
/* 815 */       ProcessTrackMateXml.FEATURE_SHORT_NAMES.put("LINEARITY_OF_FORWARD_PROGRESSION", "Lin. fwd. progr.");
/*     */ 
/*     */       
/* 818 */       ProcessTrackMateXml.FEATURE_SHORT_NAMES.put("TOTAL_ABSOLUTE_ANGLE_XY", "Abs. angle xy");
/* 819 */       ProcessTrackMateXml.FEATURE_SHORT_NAMES.put("TOTAL_ABSOLUTE_ANGLE_YZ", "Abs. angle yz");
/* 820 */       ProcessTrackMateXml.FEATURE_SHORT_NAMES.put("TOTAL_ABSOLUTE_ANGLE_ZX", "Abs. angle zx");
/*     */       
/* 822 */       ProcessTrackMateXml.FEATURE_DIMENSIONS.put("TOTAL_DISTANCE_TRAVELED", Dimension.LENGTH);
/* 823 */       ProcessTrackMateXml.FEATURE_DIMENSIONS.put("MAX_DISTANCE_TRAVELED", Dimension.LENGTH);
/* 824 */       ProcessTrackMateXml.FEATURE_DIMENSIONS.put("CONFINMENT_RATIO", Dimension.NONE);
/* 825 */       ProcessTrackMateXml.FEATURE_DIMENSIONS.put("MEAN_STRAIGHT_LINE_SPEED", Dimension.VELOCITY);
/* 826 */       ProcessTrackMateXml.FEATURE_DIMENSIONS.put("LINEARITY_OF_FORWARD_PROGRESSION", Dimension.NONE);
/*     */       
/* 828 */       ProcessTrackMateXml.FEATURE_DIMENSIONS.put("TOTAL_ABSOLUTE_ANGLE_XY", Dimension.ANGLE);
/* 829 */       ProcessTrackMateXml.FEATURE_DIMENSIONS.put("TOTAL_ABSOLUTE_ANGLE_YZ", Dimension.ANGLE);
/* 830 */       ProcessTrackMateXml.FEATURE_DIMENSIONS.put("TOTAL_ABSOLUTE_ANGLE_ZX", Dimension.ANGLE);
/*     */       
/* 832 */       ProcessTrackMateXml.IS_INT.put("TOTAL_DISTANCE_TRAVELED", Boolean.FALSE);
/* 833 */       ProcessTrackMateXml.IS_INT.put("MAX_DISTANCE_TRAVELED", Boolean.FALSE);
/* 834 */       ProcessTrackMateXml.IS_INT.put("CONFINMENT_RATIO", Boolean.FALSE);
/* 835 */       ProcessTrackMateXml.IS_INT.put("MEAN_STRAIGHT_LINE_SPEED", Boolean.FALSE);
/* 836 */       ProcessTrackMateXml.IS_INT.put("LINEARITY_OF_FORWARD_PROGRESSION", Boolean.FALSE);
/*     */       
/* 838 */       ProcessTrackMateXml.IS_INT.put("TOTAL_ABSOLUTE_ANGLE_XY", Boolean.FALSE);
/* 839 */       ProcessTrackMateXml.IS_INT.put("TOTAL_ABSOLUTE_ANGLE_YZ", Boolean.FALSE);
/* 840 */       ProcessTrackMateXml.IS_INT.put("TOTAL_ABSOLUTE_ANGLE_ZX", Boolean.FALSE);
/*     */ 
/*     */       
/* 843 */       final Model model = ProcessTrackMateXml.trackmate.getModel();
/* 844 */       FeatureModel fm1 = model.getFeatureModel();
/*     */ 
/*     */       
/* 847 */       Set<Integer> trackIDs1 = model.getTrackModel().trackIDs(true);
/*     */ 
/*     */       
/* 850 */       ProcessTrackMateXml.access$1(ProcessTrackMateXml.this, new ResultsTable());
/*     */ 
/*     */       
/* 853 */       for (Integer trackID : trackIDs1) {
/*     */         
/* 855 */         List<Spot> spots = new ArrayList<>(model.getTrackModel().trackSpots(trackID));
/* 856 */         Collections.sort(spots, Spot.frameComparator);
/* 857 */         Spot first = spots.get(0);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 863 */         Set<DefaultWeightedEdge> edges = model.getTrackModel().trackEdges(trackID);
/*     */         
/* 865 */         double totalDistance = 0.0D;
/* 866 */         double maxDistanceSq = Double.NEGATIVE_INFINITY;
/* 867 */         double maxDistance = 0.0D;
/* 868 */         double dx = 0.0D;
/* 869 */         double dy = 0.0D;
/* 870 */         double dz = 0.0D;
/*     */         
/* 872 */         for (DefaultWeightedEdge edge : edges) {
/*     */           
/* 874 */           Spot source = model.getTrackModel().getEdgeSource(edge);
/* 875 */           Spot target = model.getTrackModel().getEdgeTarget(edge);
/* 876 */           double d = Math.sqrt(source.squareDistanceTo((RealLocalizable)target));
/* 877 */           totalDistance += d;
/*     */ 
/*     */           
/* 880 */           double dToFirstSq = first.squareDistanceTo((RealLocalizable)target);
/* 881 */           if (dToFirstSq > maxDistanceSq) {
/* 882 */             maxDistanceSq = dToFirstSq;
/* 883 */             maxDistance = Math.sqrt(maxDistanceSq);
/*     */           } 
/*     */           
/* 886 */           dx += target.getDoublePosition(0) - source.getDoublePosition(0);
/* 887 */           dy += target.getDoublePosition(1) - source.getDoublePosition(1);
/* 888 */           dz += target.getDoublePosition(2) - source.getDoublePosition(2);
/*     */         } 
/*     */ 
/*     */         
/* 892 */         double netDistance = fm1.getTrackFeature(trackID, 
/* 893 */             "TRACK_DISPLACEMENT").doubleValue();
/* 894 */         double tTotal = fm1.getTrackFeature(trackID, "TRACK_DURATION").doubleValue();
/* 895 */         double vMean = fm1.getTrackFeature(trackID, 
/* 896 */             "TRACK_MEAN_SPEED").doubleValue();
/*     */ 
/*     */         
/* 899 */         double confinmentRatio = netDistance / totalDistance;
/* 900 */         double meanStraightLineSpeed = netDistance / tTotal;
/* 901 */         double linearityForwardProgression = meanStraightLineSpeed / vMean;
/*     */ 
/*     */ 
/*     */         
/* 905 */         double angleXY = Math.atan2(dy, dx);
/* 906 */         double angleYZ = Math.atan2(dz, dy);
/* 907 */         double angleZX = Math.atan2(dx, dz);
/* 908 */         Collection<String> trackFeatures = fm1.getTrackFeatures();
/* 909 */         ProcessTrackMateXml.access$2(ProcessTrackMateXml.this).incrementCounter();
/* 910 */         ProcessTrackMateXml.access$2(ProcessTrackMateXml.this).addLabel(model.getTrackModel().name(trackID));
/* 911 */         ProcessTrackMateXml.access$2(ProcessTrackMateXml.this).addValue("TRACK_ID", trackID.intValue());
/*     */         
/* 913 */         for (String feature : trackFeatures) {
/* 914 */           Double val = fm1.getTrackFeature(trackID, feature);
/* 915 */           if (val == null) {
/* 916 */             ProcessTrackMateXml.access$2(ProcessTrackMateXml.this).addValue(feature, "None"); continue;
/*     */           } 
/* 918 */           if (((Boolean)fm1.getTrackFeatureIsInt().get(feature)).booleanValue()) {
/* 919 */             ProcessTrackMateXml.access$2(ProcessTrackMateXml.this).addValue(feature, val.intValue()); continue;
/*     */           } 
/* 921 */           ProcessTrackMateXml.access$2(ProcessTrackMateXml.this).addValue(feature, val.doubleValue());
/*     */         } 
/*     */ 
/*     */ 
/*     */         
/* 926 */         ProcessTrackMateXml.access$2(ProcessTrackMateXml.this).addValue("TOTAL_DISTANCE_TRAVELED", 
/* 927 */             Math.round(totalDistance * 1000.0D) / 1000.0D);
/* 928 */         ProcessTrackMateXml.access$2(ProcessTrackMateXml.this).addValue("MAX_DISTANCE_TRAVELED", 
/* 929 */             Math.round(maxDistance * 1000.0D) / 1000.0D);
/* 930 */         ProcessTrackMateXml.access$2(ProcessTrackMateXml.this).addValue("MEAN_STRAIGHT_LINE_SPEED", 
/* 931 */             Math.round(meanStraightLineSpeed * 1000.0D) / 1000.0D);
/* 932 */         ProcessTrackMateXml.access$2(ProcessTrackMateXml.this).addValue("LINEARITY_OF_FORWARD_PROGRESSION", 
/* 933 */             Math.round(linearityForwardProgression * 1000.0D) / 1000.0D);
/* 934 */         ProcessTrackMateXml.access$2(ProcessTrackMateXml.this).addValue("TOTAL_ABSOLUTE_ANGLE_XY", Math.round(angleXY * 1000.0D) / 1000.0D);
/* 935 */         ProcessTrackMateXml.access$2(ProcessTrackMateXml.this).addValue("TOTAL_ABSOLUTE_ANGLE_YZ", Math.round(angleYZ * 1000.0D) / 1000.0D);
/* 936 */         ProcessTrackMateXml.access$2(ProcessTrackMateXml.this).addValue("TOTAL_ABSOLUTE_ANGLE_ZX", Math.round(angleZX * 1000.0D) / 1000.0D);
/* 937 */         ProcessTrackMateXml.access$2(ProcessTrackMateXml.this).addValue("CONFINMENT_RATIO", 
/* 938 */             Math.round(confinmentRatio * 1000.0D) / 1000.0D);
/* 939 */         ProcessTrackMateXml.access$2(ProcessTrackMateXml.this).addValue("TRACK_CLASSIFICATION", "");
/*     */         
/* 941 */         if (confinmentRatio == 0.0D)
/* 942 */           ProcessTrackMateXml.access$2(ProcessTrackMateXml.this).addValue("TRACK_CLASSIFICATION", "Total-Confined Track"); 
/* 943 */         if (confinmentRatio == 1.0D)
/* 944 */           ProcessTrackMateXml.access$2(ProcessTrackMateXml.this).addValue("TRACK_CLASSIFICATION", "Perfectly Straight Track"); 
/* 945 */         if (confinmentRatio > 0.0D && confinmentRatio <= 0.5D)
/* 946 */           ProcessTrackMateXml.access$2(ProcessTrackMateXml.this).addValue("TRACK_CLASSIFICATION", "Strongly Confined Track"); 
/* 947 */         if (confinmentRatio > 0.05D && confinmentRatio <= 0.25D)
/* 948 */           ProcessTrackMateXml.access$2(ProcessTrackMateXml.this).addValue("TRACK_CLASSIFICATION", "Purely Random Track"); 
/* 949 */         if (confinmentRatio > 0.25D && confinmentRatio < 1.0D) {
/* 950 */           ProcessTrackMateXml.access$2(ProcessTrackMateXml.this).addValue("TRACK_CLASSIFICATION", "Fairly Straight Track");
/*     */         }
/*     */       } 
/* 953 */       ProcessTrackMateXml.columnHeadersTrack = ProcessTrackMateXml.access$2(ProcessTrackMateXml.this).getHeadings();
/* 954 */       int rowsTrack = ProcessTrackMateXml.access$2(ProcessTrackMateXml.this).size();
/* 955 */       List<List<String>> dataListTrack = new ArrayList<>();
/* 956 */       for (int r = 0; r < rowsTrack; r++) {
/* 957 */         List<String> stringsTrack = new ArrayList<>();
/* 958 */         for (int c = 0; c < ProcessTrackMateXml.columnHeadersTrack.length; c++) {
/* 959 */           String valuesTrack = ProcessTrackMateXml.access$2(ProcessTrackMateXml.this).getStringValue(ProcessTrackMateXml.columnHeadersTrack[c], r);
/* 960 */           stringsTrack.add(valuesTrack);
/*     */         } 
/*     */         
/* 963 */         dataListTrack.add(stringsTrack);
/*     */       } 
/* 965 */       ProcessTrackMateXml.dataTrack = new String[dataListTrack.size()][]; int i1;
/* 966 */       for (i1 = 0; i1 < ProcessTrackMateXml.dataTrack.length; i1++) {
/* 967 */         ProcessTrackMateXml.dataTrack[i1] = new String[((List)dataListTrack.get(i1)).size()];
/*     */       }
/* 969 */       for (i1 = 0; i1 < dataListTrack.size(); i1++) {
/* 970 */         for (int u = 1; u < ((List)dataListTrack.get(i1)).size(); u++)
/* 971 */           ProcessTrackMateXml.dataTrack[i1][u] = ((List<String>)dataListTrack.get(i1)).get(u); 
/*     */       } 
/* 973 */       ChooserWizardPanel.createTrackTable();
/* 974 */       ChooserWizardPanel.tableTrack.addMouseListener(new MouseAdapter()
/*     */           {
/*     */             public void mouseReleased(MouseEvent e)
/*     */             {
/* 978 */               if (ProcessTrackMateXml.selectionModel != null && ChooserWizardPanel.command == "enable" && 
/* 979 */                 ChooserWizardPanel.command != null) {
/* 980 */                 ListSelectionModel lsm = ChooserWizardPanel.tableTrack.getSelectionModel();
/* 981 */                 int selStart = lsm.getMinSelectionIndex();
/* 982 */                 int selEnd = lsm.getMaxSelectionIndex();
/* 983 */                 if (selStart < 0 || selEnd < 0) {
/*     */                   return;
/*     */                 }
/* 986 */                 int minLine = Math.min(selStart, selEnd);
/* 987 */                 int maxLine = Math.max(selStart, selEnd);
/* 988 */                 Set<DefaultWeightedEdge> edges = new HashSet<>();
/* 989 */                 Set<Spot> spots = new HashSet<>();
/* 990 */                 for (int row = minLine; row <= maxLine; row++) {
/* 991 */                   int trackID = 
/* 992 */                     Integer.parseInt((String)ChooserWizardPanel.tableTrack.getValueAt(row, 2));
/* 993 */                   spots.addAll(model.getTrackModel().trackSpots(Integer.valueOf(trackID)));
/* 994 */                   edges.addAll(model.getTrackModel().trackEdges(Integer.valueOf(trackID)));
/*     */                 } 
/* 996 */                 ProcessTrackMateXml.selectionModel.clearSelection();
/* 997 */                 ProcessTrackMateXml.selectionModel.addSpotToSelection(spots);
/* 998 */                 ProcessTrackMateXml.selectionModel.addEdgeToSelection(edges);
/*     */               } 
/*     */             }
/*     */           });
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/SLTDisplayer_.jar!/ProcessTrackMateXml$1.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */