/*     */ import java.awt.Component;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.event.WindowEvent;
/*     */ import javax.swing.Icon;
/*     */ import javax.swing.ImageIcon;
/*     */ import javax.swing.JButton;
/*     */ import jwizardcomponent.Utilities;
/*     */ import jwizardcomponent.frame.JWizardFrame;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class null
/*     */   implements ActionListener
/*     */ {
/*     */   public void actionPerformed(ActionEvent event) {
/* 122 */     SLTDisplayer_.xmlPath = SLTDisplayer_.textXml.getText();
/* 123 */     SLTDisplayer_.imagesPath = SLTDisplayer_.textImages.getText();
/* 124 */     SLTDisplayer_.this.prefXml.put(SLTDisplayer_.SLTDISPLAYER_XML_PATH, SLTDisplayer_.textXml.getText());
/* 125 */     SLTDisplayer_.this.prefImages.put(SLTDisplayer_.SLTDISPLAYER_IMAGES_PATH, SLTDisplayer_.textImages.getText());
/* 126 */     SLTDisplayer_.this.frame.dispatchEvent(new WindowEvent(SLTDisplayer_.this.frame, 201));
/* 127 */     SLTDisplayer_.this.wizard = new JWizardFrame();
/* 128 */     SLTDisplayer_.this.wizard.setTitle("SLT Viewer: ANALYSIS");
/*     */     
/* 130 */     SLTDisplayer_.this.panel = new FirstWizardPanel(SLTDisplayer_.this.wizard.getWizardComponents());
/* 131 */     SLTDisplayer_.this.wizard.getWizardComponents().addWizardPanel(0, SLTDisplayer_.this.panel);
/*     */     
/* 133 */     SLTDisplayer_.this.panel = new ChooserWizardPanel(SLTDisplayer_.this.wizard.getWizardComponents());
/* 134 */     SLTDisplayer_.this.wizard.getWizardComponents().addWizardPanel(1, SLTDisplayer_.this.panel);
/*     */     
/* 136 */     SLTDisplayer_.this.panel = new OptionWizardPanel(SLTDisplayer_.this.wizard.getWizardComponents(), "A");
/* 137 */     SLTDisplayer_.this.wizard.getWizardComponents().addWizardPanel(2, SLTDisplayer_.this.panel);
/*     */     
/* 139 */     SLTDisplayer_.this.panel = new OptionWizardPanel(SLTDisplayer_.this.wizard.getWizardComponents(), "B");
/* 140 */     SLTDisplayer_.this.wizard.getWizardComponents().addWizardPanel(3, SLTDisplayer_.this.panel);
/*     */     
/* 142 */     SLTDisplayer_.this.panel = new LastWizardPanel(SLTDisplayer_.this.wizard.getWizardComponents());
/* 143 */     SLTDisplayer_.this.wizard.getWizardComponents().addWizardPanel(4, SLTDisplayer_.this.panel);
/*     */     
/* 145 */     JButton backButton = SLTDisplayer_.this.wizard.getWizardComponents().getBackButton();
/* 146 */     backButton.setText("");
/* 147 */     ImageIcon iconBack = SLTDisplayer_.this.createImageIcon("images/next.png");
/* 148 */     Icon backCell = new ImageIcon(iconBack.getImage().getScaledInstance(20, 22, 4));
/* 149 */     backButton.setIcon(backCell);
/* 150 */     backButton.setToolTipText("Click this button to back on wizard.");
/* 151 */     JButton nextButton = SLTDisplayer_.this.wizard.getWizardComponents().getNextButton();
/* 152 */     nextButton.setText("");
/* 153 */     ImageIcon iconNext = SLTDisplayer_.this.createImageIcon("images/back.png");
/* 154 */     Icon nextCell = new ImageIcon(iconNext.getImage().getScaledInstance(20, 22, 4));
/* 155 */     nextButton.setIcon(nextCell);
/* 156 */     nextButton.setToolTipText("Click this button to switch wizard.");
/* 157 */     JButton finishButton = SLTDisplayer_.this.wizard.getWizardComponents().getFinishButton();
/* 158 */     finishButton.setText("");
/* 159 */     ImageIcon iconFinish = SLTDisplayer_.this.createImageIcon("images/finish.png");
/* 160 */     Icon finishCell = new ImageIcon(iconFinish.getImage().getScaledInstance(20, 22, 4));
/* 161 */     finishButton.setIcon(finishCell);
/* 162 */     finishButton.setToolTipText("Click this button to finish the process.");
/* 163 */     JButton cancelButton = SLTDisplayer_.this.wizard.getWizardComponents().getCancelButton();
/* 164 */     cancelButton.setText("");
/* 165 */     ImageIcon iconCancel = SLTDisplayer_.this.createImageIcon("images/cancel.png");
/* 166 */     Icon cancelCell = new ImageIcon(iconCancel.getImage().getScaledInstance(20, 22, 4));
/* 167 */     cancelButton.setIcon(cancelCell);
/* 168 */     cancelButton.setToolTipText("Click this button to cancel the process.");
/* 169 */     SLTDisplayer_.this.wizard.setSize(630, 1000);
/* 170 */     Utilities.centerComponentOnScreen((Component)SLTDisplayer_.this.wizard);
/*     */     
/* 172 */     SLTDisplayer_.this.wizard.setVisible(true);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/SLTDisplayer_.jar!/SLTDisplayer_$1.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */