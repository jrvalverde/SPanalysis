/*     */ package net.imglib2.algorithm.componenttree;
/*     */ 
/*     */ import java.util.ArrayDeque;
/*     */ import java.util.Comparator;
/*     */ import java.util.PriorityQueue;
/*     */ import net.imglib2.Localizable;
/*     */ import net.imglib2.Point;
/*     */ import net.imglib2.Positionable;
/*     */ import net.imglib2.RandomAccess;
/*     */ import net.imglib2.RandomAccessible;
/*     */ import net.imglib2.RandomAccessibleInterval;
/*     */ import net.imglib2.img.array.ArrayImgFactory;
/*     */ import net.imglib2.type.Type;
/*     */ import net.imglib2.type.logic.BitType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class BuildComponentTree<T extends Type<T>, C extends PartialComponent<T, C>>
/*     */ {
/*     */   private final ArrayDeque<BoundaryPixel> reusableBoundaryPixels;
/*     */   private final PartialComponent.Generator<T, C> componentGenerator;
/*     */   private final PartialComponent.Handler<C> componentOutput;
/*     */   private final Neighborhood neighborhood;
/*     */   private final RandomAccessible<BitType> visited;
/*     */   private final RandomAccess<BitType> visitedRandomAccess;
/*     */   private final PriorityQueue<BoundaryPixel> boundaryPixels;
/*     */   private final ArrayDeque<C> componentStack;
/*     */   private final Comparator<T> comparator;
/*     */   
/*     */   public static <T extends Type<T>, C extends PartialComponent<T, C>> void buildComponentTree(RandomAccessibleInterval<T> input, PartialComponent.Generator<T, C> componentGenerator, PartialComponent.Handler<C> componentHandler, Comparator<T> comparator) {
/* 104 */     new BuildComponentTree<>(input, componentGenerator, componentHandler, comparator);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends Type<T> & Comparable<T>, C extends PartialComponent<T, C>> void buildComponentTree(RandomAccessibleInterval<T> input, PartialComponent.Generator<T, C> componentGenerator, PartialComponent.Handler<C> componentHandler, boolean darkToBright) {
/* 134 */     new BuildComponentTree<>(input, componentGenerator, componentHandler, darkToBright ? new DarkToBright<>() : new BrightToDark<>());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final class DarkToBright<T extends Comparable<T>>
/*     */     implements Comparator<T>
/*     */   {
/*     */     public int compare(T o1, T o2) {
/* 146 */       return o1.compareTo(o2);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final class BrightToDark<T extends Comparable<T>>
/*     */     implements Comparator<T>
/*     */   {
/*     */     public int compare(T o1, T o2) {
/* 159 */       return o2.compareTo(o1);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class Neighborhood
/*     */   {
/*     */     private int n;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final int nBound;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     final long[] dimensions;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Neighborhood(long[] dim) {
/* 186 */       this.n = 0;
/* 187 */       this.nBound = dim.length * 2;
/* 188 */       this.dimensions = dim;
/*     */     }
/*     */ 
/*     */     
/*     */     public int getNextNeighborIndex() {
/* 193 */       return this.n;
/*     */     }
/*     */ 
/*     */     
/*     */     public void setNextNeighborIndex(int n) {
/* 198 */       this.n = n;
/*     */     }
/*     */ 
/*     */     
/*     */     public void reset() {
/* 203 */       this.n = 0;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean hasNext() {
/* 208 */       return (this.n < this.nBound);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean next(Localizable current, Positionable neighbor, Positionable neighbor2) {
/* 225 */       int d = this.n / 2;
/* 226 */       boolean bck = (this.n == 2 * d);
/* 227 */       this.n++;
/* 228 */       if (bck) {
/*     */         
/* 230 */         if (d > 0) {
/*     */           
/* 232 */           neighbor.setPosition(current.getLongPosition(d - 1), d - 1);
/* 233 */           neighbor2.setPosition(current.getLongPosition(d - 1), d - 1);
/*     */         } 
/* 235 */         long l = current.getLongPosition(d) - 1L;
/* 236 */         neighbor.setPosition(l, d);
/* 237 */         neighbor2.setPosition(l, d);
/* 238 */         return (l >= 0L);
/*     */       } 
/*     */ 
/*     */       
/* 242 */       long dpos = current.getLongPosition(d) + 1L;
/* 243 */       neighbor.setPosition(dpos, d);
/* 244 */       neighbor2.setPosition(dpos, d);
/* 245 */       return (dpos < this.dimensions[d]);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private final class BoundaryPixel
/*     */     extends Point
/*     */     implements Comparable<BoundaryPixel>
/*     */   {
/*     */     private final T value;
/*     */ 
/*     */     
/*     */     private int nextNeighborIndex;
/*     */ 
/*     */ 
/*     */     
/*     */     public BoundaryPixel(Localizable position, T value, int nextNeighborIndex) {
/* 263 */       super(position);
/* 264 */       this.nextNeighborIndex = nextNeighborIndex;
/* 265 */       this.value = (T)value.copy();
/*     */     }
/*     */ 
/*     */     
/*     */     public int getNextNeighborIndex() {
/* 270 */       return this.nextNeighborIndex;
/*     */     }
/*     */ 
/*     */     
/*     */     public T get() {
/* 275 */       return this.value;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public int compareTo(BoundaryPixel o) {
/* 281 */       return BuildComponentTree.this.comparator.compare(this.value, o.value);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private BoundaryPixel createBoundaryPixel(Localizable position, T value, int nextNeighborIndex) {
/* 289 */     if (this.reusableBoundaryPixels.isEmpty()) {
/* 290 */       return new BoundaryPixel(position, value, nextNeighborIndex);
/*     */     }
/*     */     
/* 293 */     BoundaryPixel p = this.reusableBoundaryPixels.pop();
/* 294 */     p.setPosition(position);
/* 295 */     p.value.set((Type)value);
/* 296 */     p.nextNeighborIndex = nextNeighborIndex;
/* 297 */     return p;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void freeBoundaryPixel(BoundaryPixel p) {
/* 303 */     this.reusableBoundaryPixels.push(p);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private BuildComponentTree(RandomAccessibleInterval<T> input, PartialComponent.Generator<T, C> componentGenerator, PartialComponent.Handler<C> componentOutput, Comparator<T> comparator) {
/* 337 */     this.reusableBoundaryPixels = new ArrayDeque<>();
/* 338 */     this.componentGenerator = componentGenerator;
/* 339 */     this.componentOutput = componentOutput;
/*     */     
/* 341 */     long[] dimensions = new long[input.numDimensions()];
/* 342 */     input.dimensions(dimensions);
/*     */     
/* 344 */     ArrayImgFactory arrayImgFactory = new ArrayImgFactory();
/* 345 */     this.visited = (RandomAccessible<BitType>)arrayImgFactory.create(dimensions, new BitType());
/* 346 */     this.visitedRandomAccess = this.visited.randomAccess();
/*     */     
/* 348 */     this.neighborhood = new Neighborhood(dimensions);
/*     */     
/* 350 */     this.boundaryPixels = new PriorityQueue<>();
/*     */     
/* 352 */     this.componentStack = new ArrayDeque<>();
/* 353 */     this.componentStack.push(componentGenerator.createMaxComponent());
/*     */     
/* 355 */     this.comparator = comparator;
/*     */     
/* 357 */     run(input);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void run(RandomAccessibleInterval<T> input) {
/* 369 */     RandomAccess<T> current = input.randomAccess();
/* 370 */     RandomAccess<T> neighbor = input.randomAccess();
/* 371 */     input.min((Positionable)current);
/* 372 */     neighbor.setPosition((Localizable)current);
/* 373 */     this.visitedRandomAccess.setPosition((Localizable)current);
/* 374 */     Type type1 = ((Type)current.get()).createVariable();
/* 375 */     Type type2 = ((Type)current.get()).createVariable();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 381 */     ((BitType)this.visitedRandomAccess.get()).set(true);
/* 382 */     type1.set((Type)current.get());
/*     */ 
/*     */     
/* 385 */     this.componentStack.push(this.componentGenerator.createComponent((T)type1));
/*     */ 
/*     */ 
/*     */     
/*     */     while (true) {
/* 390 */       while (this.neighborhood.hasNext()) {
/*     */         
/* 392 */         if (!this.neighborhood.next((Localizable)current, (Positionable)neighbor, (Positionable)this.visitedRandomAccess))
/*     */           continue; 
/* 394 */         if (!((BitType)this.visitedRandomAccess.get()).get()) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 402 */           ((BitType)this.visitedRandomAccess.get()).set(true);
/*     */           
/* 404 */           type2.set((Type)neighbor.get());
/* 405 */           if (this.comparator.compare((T)type2, (T)type1) >= 0) {
/*     */             
/* 407 */             this.boundaryPixels.add(createBoundaryPixel((Localizable)neighbor, (T)type2, 0));
/*     */             
/*     */             continue;
/*     */           } 
/* 411 */           this.boundaryPixels.add(createBoundaryPixel((Localizable)current, (T)type1, this.neighborhood.getNextNeighborIndex()));
/* 412 */           current.setPosition((Localizable)neighbor);
/* 413 */           type1.set(type2);
/*     */ 
/*     */           
/* 416 */           this.componentStack.push(this.componentGenerator.createComponent((T)type1));
/* 417 */           this.neighborhood.reset();
/*     */         } 
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 423 */       PartialComponent partialComponent = (PartialComponent)this.componentStack.peek();
/* 424 */       partialComponent.addPosition((Localizable)current);
/*     */ 
/*     */       
/* 427 */       if (this.boundaryPixels.isEmpty()) {
/*     */         
/* 429 */         processStack((T)type1);
/*     */         
/*     */         return;
/*     */       } 
/* 433 */       BoundaryPixel p = this.boundaryPixels.poll();
/* 434 */       if (this.comparator.compare(p.get(), (T)type1) != 0)
/*     */       {
/*     */         
/* 437 */         processStack(p.get());
/*     */       }
/* 439 */       current.setPosition((Localizable)p);
/* 440 */       neighbor.setPosition((Localizable)current);
/* 441 */       this.visitedRandomAccess.setPosition((Localizable)current);
/* 442 */       type1.set((Type)p.get());
/* 443 */       this.neighborhood.setNextNeighborIndex(p.getNextNeighborIndex());
/* 444 */       freeBoundaryPixel(p);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void processStack(T value) {
/*     */     while (true) {
/* 458 */       PartialComponent partialComponent1 = (PartialComponent)this.componentStack.pop();
/* 459 */       this.componentOutput.emit((C)partialComponent1);
/*     */ 
/*     */       
/* 462 */       PartialComponent partialComponent2 = (PartialComponent)this.componentStack.peek();
/*     */       
/*     */       try {
/* 465 */         int c = this.comparator.compare(value, (T)partialComponent2.getValue());
/* 466 */         if (c < 0) {
/*     */           
/* 468 */           partialComponent1.setValue(value);
/* 469 */           this.componentStack.push((C)partialComponent1);
/*     */         }
/*     */         else {
/*     */           
/* 473 */           partialComponent2.merge(partialComponent1);
/* 474 */           if (c > 0) {
/*     */             continue;
/*     */           }
/*     */         } 
/*     */         return;
/* 479 */       } catch (NullPointerException e) {
/*     */         
/* 481 */         this.componentStack.push((C)partialComponent1);
/*     */         break;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/imglib2-algorithm-0.6.2.jar!/net/imglib2/algorithm/componenttree/BuildComponentTree.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */