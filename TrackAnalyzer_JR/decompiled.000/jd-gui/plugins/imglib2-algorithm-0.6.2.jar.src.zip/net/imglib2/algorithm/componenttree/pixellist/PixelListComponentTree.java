/*     */ package net.imglib2.algorithm.componenttree.pixellist;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.Iterator;
/*     */ import java.util.Set;
/*     */ import net.imglib2.Dimensions;
/*     */ import net.imglib2.RandomAccessibleInterval;
/*     */ import net.imglib2.algorithm.componenttree.BuildComponentTree;
/*     */ import net.imglib2.algorithm.componenttree.Component;
/*     */ import net.imglib2.algorithm.componenttree.ComponentTree;
/*     */ import net.imglib2.algorithm.componenttree.PartialComponent;
/*     */ import net.imglib2.img.ImgFactory;
/*     */ import net.imglib2.type.NativeType;
/*     */ import net.imglib2.type.Type;
/*     */ import net.imglib2.type.numeric.RealType;
/*     */ import net.imglib2.type.numeric.integer.LongType;
/*     */ import net.imglib2.util.Util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class PixelListComponentTree<T extends Type<T>>
/*     */   implements ComponentTree<PixelListComponent<T>>, Iterable<PixelListComponent<T>>, PartialComponent.Handler<PixelListPartialComponent<T>>
/*     */ {
/*     */   private PixelListComponent<T> root;
/*     */   private final ArrayList<PixelListComponent<T>> nodes;
/*     */   
/*     */   public static <T extends RealType<T>> PixelListComponentTree<T> buildComponentTree(RandomAccessibleInterval<T> input, T type, boolean darkToBright) {
/*  88 */     ImgFactory<LongType> factory = Util.getArrayOrCellImgFactory((Dimensions)input, (NativeType)new LongType());
/*  89 */     return buildComponentTree(input, type, factory, darkToBright);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends RealType<T>> PixelListComponentTree<T> buildComponentTree(RandomAccessibleInterval<T> input, T type, ImgFactory<LongType> imgFactory, boolean darkToBright) {
/* 109 */     RealType realType = (RealType)type.createVariable();
/* 110 */     realType.setReal(darkToBright ? type.getMaxValue() : type.getMinValue());
/* 111 */     PixelListPartialComponentGenerator<T> generator = (PixelListPartialComponentGenerator)new PixelListPartialComponentGenerator<>(realType, input, imgFactory);
/* 112 */     PixelListComponentTree<T> tree = (PixelListComponentTree)new PixelListComponentTree<>();
/* 113 */     BuildComponentTree.buildComponentTree(input, generator, tree, darkToBright);
/* 114 */     return tree;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends Type<T>> PixelListComponentTree<T> buildComponentTree(RandomAccessibleInterval<T> input, T maxValue, Comparator<T> comparator) {
/* 134 */     ImgFactory<LongType> factory = Util.getArrayOrCellImgFactory((Dimensions)input, (NativeType)new LongType());
/* 135 */     return buildComponentTree(input, maxValue, comparator, factory);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends Type<T>> PixelListComponentTree<T> buildComponentTree(RandomAccessibleInterval<T> input, T maxValue, Comparator<T> comparator, ImgFactory<LongType> imgFactory) {
/* 155 */     PixelListPartialComponentGenerator<T> generator = new PixelListPartialComponentGenerator<>(maxValue, input, imgFactory);
/* 156 */     PixelListComponentTree<T> tree = new PixelListComponentTree<>();
/* 157 */     BuildComponentTree.buildComponentTree(input, generator, tree, comparator);
/* 158 */     return tree;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private PixelListComponentTree() {
/* 167 */     this.root = null;
/* 168 */     this.nodes = new ArrayList<>();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void emit(PixelListPartialComponent<T> partialComponent) {
/* 174 */     PixelListComponent<T> component = new PixelListComponent<>(partialComponent);
/* 175 */     this.root = component;
/* 176 */     this.nodes.add(component);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Iterator<PixelListComponent<T>> iterator() {
/* 187 */     return this.nodes.iterator();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PixelListComponent<T> root() {
/* 198 */     return this.root;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<PixelListComponent<T>> roots() {
/* 209 */     return Collections.singleton(this.root);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/imglib2-algorithm-0.6.2.jar!/net/imglib2/algorithm/componenttree/pixellist/PixelListComponentTree.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */