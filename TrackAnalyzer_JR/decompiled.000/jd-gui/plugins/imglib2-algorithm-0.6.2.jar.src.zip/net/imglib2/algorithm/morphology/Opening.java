/*     */ package net.imglib2.algorithm.morphology;
/*     */ 
/*     */ import java.util.List;
/*     */ import net.imglib2.Dimensions;
/*     */ import net.imglib2.Interval;
/*     */ import net.imglib2.IterableInterval;
/*     */ import net.imglib2.RandomAccessible;
/*     */ import net.imglib2.RandomAccessibleInterval;
/*     */ import net.imglib2.algorithm.neighborhood.Shape;
/*     */ import net.imglib2.img.Img;
/*     */ import net.imglib2.img.ImgFactory;
/*     */ import net.imglib2.type.Type;
/*     */ import net.imglib2.type.numeric.RealType;
/*     */ import net.imglib2.view.ExtendedRandomAccessibleInterval;
/*     */ import net.imglib2.view.IntervalView;
/*     */ import net.imglib2.view.Views;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Opening
/*     */ {
/*     */   public static final <T extends RealType<T>> Img<T> open(Img<T> source, List<Shape> strels, int numThreads) {
/*  88 */     Img<T> eroded = Erosion.erode(source, strels, numThreads);
/*  89 */     Img<T> dilated = Dilation.dilate(eroded, strels, numThreads);
/*  90 */     return dilated;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final <T extends Type<T> & Comparable<T>> Img<T> open(Img<T> source, List<Shape> strels, T minVal, T maxVal, int numThreads) {
/* 136 */     Img<T> eroded = Erosion.erode(source, strels, maxVal, numThreads);
/* 137 */     Img<T> dilated = Dilation.dilate(eroded, strels, minVal, numThreads);
/* 138 */     return dilated;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final <T extends RealType<T>> Img<T> open(Img<T> source, Shape strel, int numThreads) {
/* 163 */     Img<T> eroded = Erosion.erode(source, strel, numThreads);
/* 164 */     Img<T> dilated = Dilation.dilate(eroded, strel, numThreads);
/* 165 */     return dilated;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final <T extends Type<T> & Comparable<T>> Img<T> open(Img<T> source, Shape strel, T minVal, T maxVal, int numThreads) {
/* 206 */     Img<T> eroded = Erosion.erode(source, strel, maxVal, numThreads);
/* 207 */     Img<T> dilated = Dilation.dilate(eroded, strel, minVal, numThreads);
/* 208 */     return dilated;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends RealType<T>> void open(RandomAccessible<T> source, IterableInterval<T> target, List<Shape> strels, int numThreads) {
/* 252 */     RealType realType1 = MorphologyUtils.<RealType>createVariable(source, (Interval)target);
/* 253 */     realType1.setReal(realType1.getMaxValue());
/* 254 */     RealType realType2 = MorphologyUtils.<RealType>createVariable(source, (Interval)target);
/* 255 */     realType2.setReal(realType2.getMinValue());
/* 256 */     open(source, target, strels, realType2, realType1, numThreads);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends Type<T> & Comparable<T>> void open(RandomAccessible<T> source, IterableInterval<T> target, List<Shape> strels, T minVal, T maxVal, int numThreads) {
/* 315 */     ImgFactory<T> factory = MorphologyUtils.getSuitableFactory((Dimensions)target, maxVal);
/* 316 */     Img<T> img = factory.create((Dimensions)target, maxVal);
/* 317 */     long[] min = new long[target.numDimensions()];
/* 318 */     target.min(min);
/*     */     
/* 320 */     IntervalView<T> translated = Views.translate((RandomAccessibleInterval)img, min);
/* 321 */     Erosion.erode(source, (IterableInterval<T>)translated, strels, maxVal, numThreads);
/*     */     
/* 323 */     ExtendedRandomAccessibleInterval<T, IntervalView<T>> extended = Views.extendValue((RandomAccessibleInterval)translated, (Type)minVal);
/* 324 */     Dilation.dilate((RandomAccessible)extended, target, strels, minVal, numThreads);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends RealType<T>> void open(RandomAccessible<T> source, IterableInterval<T> target, Shape strel, int numThreads) {
/* 363 */     RealType realType1 = MorphologyUtils.<RealType>createVariable(source, (Interval)target);
/* 364 */     realType1.setReal(realType1.getMaxValue());
/* 365 */     RealType realType2 = MorphologyUtils.<RealType>createVariable(source, (Interval)target);
/* 366 */     realType2.setReal(realType2.getMinValue());
/* 367 */     open(source, target, strel, realType2, realType1, numThreads);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends Type<T> & Comparable<T>> void open(RandomAccessible<T> source, IterableInterval<T> target, Shape strel, T minVal, T maxVal, int numThreads) {
/* 421 */     ImgFactory<T> factory = MorphologyUtils.getSuitableFactory((Dimensions)target, maxVal);
/* 422 */     Img<T> img = factory.create((Dimensions)target, maxVal);
/* 423 */     long[] min = new long[target.numDimensions()];
/* 424 */     target.min(min);
/*     */     
/* 426 */     IntervalView<T> translated = Views.translate((RandomAccessibleInterval)img, min);
/* 427 */     Erosion.erode(source, (IterableInterval<T>)translated, strel, maxVal, numThreads);
/*     */     
/* 429 */     ExtendedRandomAccessibleInterval<T, IntervalView<T>> extended = Views.extendValue((RandomAccessibleInterval)translated, (Type)minVal);
/* 430 */     Dilation.dilate((RandomAccessible)extended, target, strel, minVal, numThreads);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends RealType<T>> void openInPlace(RandomAccessibleInterval<T> source, Interval interval, List<Shape> strels, int numThreads) {
/* 469 */     RealType realType1 = MorphologyUtils.<RealType>createVariable((RandomAccessible<RealType>)source, interval);
/* 470 */     realType1.setReal(realType1.getMaxValue());
/* 471 */     RealType realType2 = MorphologyUtils.<RealType>createVariable((RandomAccessible<RealType>)source, interval);
/* 472 */     realType2.setReal(realType2.getMinValue());
/*     */     
/* 474 */     openInPlace(source, interval, strels, realType2, realType1, numThreads);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends Type<T> & Comparable<T>> void openInPlace(RandomAccessibleInterval<T> source, Interval interval, List<Shape> strels, T minVal, T maxVal, int numThreads) {
/* 527 */     for (Shape strel : strels)
/*     */     {
/* 529 */       openInPlace(source, interval, strel, minVal, maxVal, numThreads);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends RealType<T>> void openInPlace(RandomAccessibleInterval<T> source, Interval interval, Shape strel, int numThreads) {
/* 564 */     RealType realType1 = MorphologyUtils.<RealType>createVariable((RandomAccessible<RealType>)source, interval);
/* 565 */     realType1.setReal(realType1.getMaxValue());
/* 566 */     RealType realType2 = MorphologyUtils.<RealType>createVariable((RandomAccessible<RealType>)source, interval);
/* 567 */     realType2.setReal(realType2.getMinValue());
/*     */     
/* 569 */     openInPlace(source, interval, strel, realType2, realType1, numThreads);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends Type<T> & Comparable<T>> void openInPlace(RandomAccessibleInterval<T> source, Interval interval, Shape strel, T minVal, T maxVal, int numThreads) {
/* 617 */     ExtendedRandomAccessibleInterval<T, RandomAccessibleInterval<T>> extended = Views.extendValue(source, (Type)maxVal);
/*     */     
/* 619 */     ImgFactory<T> factory = MorphologyUtils.getSuitableFactory((Dimensions)interval, maxVal);
/* 620 */     Img<T> img = factory.create((Dimensions)interval, maxVal);
/* 621 */     long[] min = new long[interval.numDimensions()];
/* 622 */     interval.min(min);
/* 623 */     IntervalView<T> translated = Views.translate((RandomAccessibleInterval)img, min);
/*     */     
/* 625 */     open((RandomAccessible)extended, (IterableInterval<T>)translated, strel, minVal, maxVal, numThreads);
/* 626 */     MorphologyUtils.copy((IterableInterval<T>)translated, (RandomAccessible)extended, numThreads);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/imglib2-algorithm-0.6.2.jar!/net/imglib2/algorithm/morphology/Opening.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */