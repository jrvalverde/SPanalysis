/*     */ package net.imglib2.algorithm.binary;
/*     */ 
/*     */ import java.util.Vector;
/*     */ import net.imglib2.Cursor;
/*     */ import net.imglib2.Dimensions;
/*     */ import net.imglib2.Interval;
/*     */ import net.imglib2.Localizable;
/*     */ import net.imglib2.RandomAccess;
/*     */ import net.imglib2.converter.Converter;
/*     */ import net.imglib2.exception.IncompatibleTypeException;
/*     */ import net.imglib2.img.Img;
/*     */ import net.imglib2.img.ImgFactory;
/*     */ import net.imglib2.multithreading.Chunk;
/*     */ import net.imglib2.multithreading.SimpleMultiThreading;
/*     */ import net.imglib2.type.Type;
/*     */ import net.imglib2.type.logic.BitType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Thresholder
/*     */ {
/*     */   public static final <T extends Type<T> & Comparable<T>> Img<BitType> threshold(final Img<T> source, final T threshold, boolean above, int numThreads) {
/*  76 */     ImgFactory<T> factory = source.factory();
/*     */     try {
/*     */       final Converter<T, BitType> converter;
/*  79 */       ImgFactory<BitType> bitFactory = factory.imgFactory(new BitType());
/*  80 */       final Img<BitType> target = bitFactory.create((Dimensions)source, new BitType());
/*     */ 
/*     */       
/*  83 */       if (above) {
/*     */         
/*  85 */         converter = new Converter<T, BitType>()
/*     */           {
/*     */             
/*     */             public void convert(T input, BitType output)
/*     */             {
/*  90 */               output.set((((Comparable<Type>)input).compareTo(threshold) > 0));
/*     */             }
/*     */           };
/*     */       }
/*     */       else {
/*     */         
/*  96 */         converter = new Converter<T, BitType>()
/*     */           {
/*     */             
/*     */             public void convert(T input, BitType output)
/*     */             {
/* 101 */               output.set((((Comparable<Type>)input).compareTo(threshold) < 0));
/*     */             }
/*     */           };
/*     */       } 
/*     */       
/* 106 */       Vector<Chunk> chunks = SimpleMultiThreading.divideIntoChunks(target.size(), numThreads);
/* 107 */       Thread[] threads = SimpleMultiThreading.newThreads(numThreads);
/*     */       
/* 109 */       if (target.iterationOrder().equals(source.iterationOrder())) {
/*     */         
/* 111 */         for (int i = 0; i < threads.length; i++) {
/*     */           
/* 113 */           final Chunk chunk = chunks.get(i);
/* 114 */           threads[i] = new Thread("Thresholder thread " + i)
/*     */             {
/*     */               
/*     */               public void run()
/*     */               {
/* 119 */                 Cursor<BitType> cursorTarget = target.cursor();
/* 120 */                 cursorTarget.jumpFwd(chunk.getStartPosition());
/* 121 */                 Cursor<T> cursorSource = source.cursor();
/* 122 */                 cursorSource.jumpFwd(chunk.getStartPosition());
/* 123 */                 for (long steps = 0L; steps < chunk.getLoopSize(); steps++)
/*     */                 {
/* 125 */                   cursorTarget.fwd();
/* 126 */                   cursorSource.fwd();
/* 127 */                   converter.convert(cursorSource.get(), cursorTarget.get());
/*     */                 }
/*     */               
/*     */               }
/*     */             };
/*     */         } 
/*     */       } else {
/*     */         
/* 135 */         for (int i = 0; i < threads.length; i++) {
/*     */           
/* 137 */           final Chunk chunk = chunks.get(i);
/* 138 */           threads[i] = new Thread("Thresholder thread " + i)
/*     */             {
/*     */               
/*     */               public void run()
/*     */               {
/* 143 */                 Cursor<BitType> cursorTarget = target.cursor();
/* 144 */                 cursorTarget.jumpFwd(chunk.getStartPosition());
/* 145 */                 RandomAccess<T> ra = source.randomAccess((Interval)target);
/* 146 */                 for (long steps = 0L; steps < chunk.getLoopSize(); steps++) {
/*     */                   
/* 148 */                   cursorTarget.fwd();
/* 149 */                   ra.setPosition((Localizable)cursorTarget);
/* 150 */                   converter.convert(ra.get(), cursorTarget.get());
/*     */                 } 
/*     */               }
/*     */             };
/*     */         } 
/*     */       } 
/*     */       
/* 157 */       SimpleMultiThreading.startAndJoin(threads);
/* 158 */       return target;
/*     */     }
/* 160 */     catch (IncompatibleTypeException e) {
/*     */       
/* 162 */       e.printStackTrace();
/* 163 */       return null;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/imglib2-algorithm-0.6.2.jar!/net/imglib2/algorithm/binary/Thresholder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */