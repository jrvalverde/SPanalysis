/*    */ package net.imglib2.algorithm.neighborhood;
/*    */ 
/*    */ import net.imglib2.Cursor;
/*    */ import net.imglib2.RandomAccess;
/*    */ import net.imglib2.RealCursor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DiamondNeighborhoodUnsafe<T>
/*    */   extends DiamondNeighborhood<T>
/*    */ {
/*    */   private final DiamondNeighborhood<T>.LocalCursor theCursor;
/*    */   private final DiamondNeighborhood<T>.LocalCursor firstElementCursor;
/*    */   
/*    */   public static <T> DiamondNeighborhoodFactory<T> factory() {
/* 42 */     return new DiamondNeighborhoodFactory<T>()
/*    */       {
/*    */         
/*    */         public Neighborhood<T> create(long[] position, long radius, RandomAccess<T> sourceRandomAccess)
/*    */         {
/* 47 */           return new DiamondNeighborhoodUnsafe<>(position, radius, sourceRandomAccess);
/*    */         }
/*    */       };
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   DiamondNeighborhoodUnsafe(long[] position, long radius, RandomAccess<T> sourceRandomAccess) {
/* 58 */     super(position, radius, sourceRandomAccess);
/* 59 */     this.theCursor = super.cursor();
/* 60 */     this.firstElementCursor = super.cursor();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public T firstElement() {
/* 66 */     this.firstElementCursor.reset();
/* 67 */     return this.firstElementCursor.next();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public DiamondNeighborhood<T>.LocalCursor cursor() {
/* 73 */     this.theCursor.reset();
/* 74 */     return this.theCursor;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/imglib2-algorithm-0.6.2.jar!/net/imglib2/algorithm/neighborhood/DiamondNeighborhoodUnsafe.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */