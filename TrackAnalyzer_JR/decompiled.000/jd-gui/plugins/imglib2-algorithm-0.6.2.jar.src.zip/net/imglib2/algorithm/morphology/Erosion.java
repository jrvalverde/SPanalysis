/*     */ package net.imglib2.algorithm.morphology;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.Vector;
/*     */ import net.imglib2.Cursor;
/*     */ import net.imglib2.Dimensions;
/*     */ import net.imglib2.EuclideanSpace;
/*     */ import net.imglib2.Interval;
/*     */ import net.imglib2.IterableInterval;
/*     */ import net.imglib2.Localizable;
/*     */ import net.imglib2.RandomAccess;
/*     */ import net.imglib2.RandomAccessible;
/*     */ import net.imglib2.RandomAccessibleInterval;
/*     */ import net.imglib2.algorithm.neighborhood.Neighborhood;
/*     */ import net.imglib2.algorithm.neighborhood.Shape;
/*     */ import net.imglib2.img.Img;
/*     */ import net.imglib2.img.ImgFactory;
/*     */ import net.imglib2.multithreading.Chunk;
/*     */ import net.imglib2.multithreading.SimpleMultiThreading;
/*     */ import net.imglib2.type.Type;
/*     */ import net.imglib2.type.logic.BitType;
/*     */ import net.imglib2.type.numeric.RealType;
/*     */ import net.imglib2.view.ExtendedRandomAccessibleInterval;
/*     */ import net.imglib2.view.IntervalView;
/*     */ import net.imglib2.view.Views;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Erosion
/*     */ {
/*     */   public static <T extends RealType<T>> Img<T> erode(Img<T> source, List<Shape> strels, int numThreads) {
/*  90 */     Img<T> target = source;
/*  91 */     for (Shape strel : strels)
/*     */     {
/*  93 */       target = erodeFull(target, strel, numThreads);
/*     */     }
/*  95 */     return (Img)MorphologyUtils.copyCropped((Img)target, (Interval)source, numThreads);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends Type<T> & Comparable<T>> Img<T> erode(Img<T> source, List<Shape> strels, T maxVal, int numThreads) {
/* 142 */     Img<T> target = source;
/* 143 */     for (Shape strel : strels)
/*     */     {
/* 145 */       target = erodeFull(target, strel, maxVal, numThreads);
/*     */     }
/* 147 */     return (Img)MorphologyUtils.copyCropped(target, (Interval)source, numThreads);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends RealType<T>> Img<T> erode(Img<T> source, Shape strel, int numThreads) {
/* 175 */     Img<T> target = source.factory().create((Dimensions)source, ((RealType)source.firstElement()).copy());
/* 176 */     RealType realType = (RealType)((RealType)source.firstElement()).createVariable();
/* 177 */     realType.setReal(realType.getMaxValue());
/* 178 */     ExtendedRandomAccessibleInterval<T, Img<T>> extended = Views.extendValue((RandomAccessibleInterval)source, (Type)realType);
/* 179 */     erode((RandomAccessible)extended, (IterableInterval<T>)target, strel, numThreads);
/* 180 */     return target;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends Type<T> & Comparable<T>> Img<T> erode(Img<T> source, Shape strel, T maxVal, int numThreads) {
/* 222 */     Img<T> target = source.factory().create((Dimensions)source, ((Type)source.firstElement()).copy());
/* 223 */     ExtendedRandomAccessibleInterval<T, Img<T>> extended = Views.extendValue((RandomAccessibleInterval)source, (Type)maxVal);
/* 224 */     erode((RandomAccessible)extended, (IterableInterval<T>)target, strel, maxVal, numThreads);
/* 225 */     return target;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends RealType<T>> void erode(RandomAccessible<T> source, IterableInterval<T> target, List<Shape> strels, int numThreads) {
/* 265 */     RealType realType = MorphologyUtils.<RealType>createVariable(source, (Interval)target);
/* 266 */     realType.setReal(realType.getMaxValue());
/* 267 */     erode(source, target, strels, realType, numThreads);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends Type<T> & Comparable<T>> void erode(RandomAccessible<T> source, IterableInterval<T> target, List<Shape> strels, T maxVal, int numThreads) {
/* 323 */     if (strels.isEmpty())
/* 324 */       return;  if (strels.size() == 1) {
/*     */       
/* 326 */       erode(source, target, strels.get(0), maxVal, numThreads);
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 331 */     long[] targetDims = new long[target.numDimensions()];
/* 332 */     long[] translation = new long[target.numDimensions()];
/* 333 */     for (int d = 0; d < targetDims.length; d++) {
/*     */       
/* 335 */       targetDims[d] = target.dimension(d);
/* 336 */       translation[d] = target.min(d);
/*     */     } 
/* 338 */     for (Shape strel : strels) {
/*     */       
/* 340 */       Neighborhood<BitType> nh = MorphologyUtils.getNeighborhood(strel, (EuclideanSpace)target);
/* 341 */       for (int k = 0; k < translation.length; k++) {
/*     */         
/* 343 */         translation[k] = translation[k] - nh.dimension(k) / 2L;
/* 344 */         targetDims[k] = targetDims[k] + nh.dimension(k) - 1L;
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 349 */     ImgFactory<T> factory = MorphologyUtils.getSuitableFactory(targetDims, maxVal);
/* 350 */     Img<T> temp = factory.create(targetDims, maxVal);
/* 351 */     IntervalView<T> translated = Views.translate((RandomAccessibleInterval)temp, translation);
/* 352 */     erode(source, (IterableInterval<T>)translated, strels.get(0), maxVal, numThreads);
/*     */ 
/*     */     
/* 355 */     for (int i = 1; i < strels.size(); i++)
/*     */     {
/* 357 */       temp = erode(temp, strels.get(i), maxVal, numThreads);
/*     */     }
/*     */ 
/*     */     
/* 361 */     long[] offset = new long[target.numDimensions()];
/* 362 */     for (int j = 0; j < offset.length; j++)
/*     */     {
/* 364 */       offset[j] = target.min(j) - (temp.dimension(j) - target.dimension(j)) / 2L;
/*     */     }
/* 366 */     MorphologyUtils.copy2((RandomAccessible<Type>)Views.translate((RandomAccessibleInterval)temp, offset), target, numThreads);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends RealType<T>> void erode(RandomAccessible<T> source, IterableInterval<T> target, Shape strel, int numThreads) {
/* 401 */     RealType realType = MorphologyUtils.<RealType>createVariable(source, (Interval)target);
/* 402 */     realType.setReal(realType.getMaxValue());
/* 403 */     erode(source, target, strel, realType, numThreads);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends Type<T> & Comparable<T>> void erode(final RandomAccessible<T> source, final IterableInterval<T> target, Shape strel, final T maxVal, int numThreads) {
/* 454 */     numThreads = Math.max(1, numThreads);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 460 */     final RandomAccessible<Neighborhood<T>> accessible = strel.neighborhoodsRandomAccessible(source);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 466 */     Vector<Chunk> chunks = SimpleMultiThreading.divideIntoChunks(target.size(), numThreads);
/* 467 */     Thread[] threads = SimpleMultiThreading.newThreads(numThreads);
/*     */     
/* 469 */     Object tmp = maxVal;
/* 470 */     if (tmp instanceof BitType) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 476 */       for (int i = 0; i < threads.length; i++) {
/*     */         
/* 478 */         final Chunk chunk = chunks.get(i);
/* 479 */         threads[i] = new Thread("Morphology erode thread " + i)
/*     */           {
/*     */             
/*     */             public void run()
/*     */             {
/* 484 */               RandomAccess<Neighborhood<T>> randomAccess = accessible.randomAccess((Interval)target);
/* 485 */               Object tmp2 = target.cursor();
/*     */               
/* 487 */               Cursor<BitType> cursorTarget = (Cursor<BitType>)tmp2;
/* 488 */               cursorTarget.jumpFwd(chunk.getStartPosition());
/*     */               long steps;
/* 490 */               for (steps = 0L; steps < chunk.getLoopSize(); steps++) {
/*     */                 
/* 492 */                 cursorTarget.fwd();
/* 493 */                 randomAccess.setPosition((Localizable)cursorTarget);
/* 494 */                 Object tmp3 = randomAccess.get();
/*     */                 
/* 496 */                 Neighborhood<BitType> neighborhood = (Neighborhood<BitType>)tmp3;
/* 497 */                 Cursor<BitType> nc = neighborhood.cursor();
/*     */                 
/* 499 */                 ((BitType)cursorTarget.get()).set(true);
/* 500 */                 while (nc.hasNext()) {
/*     */                   
/* 502 */                   nc.fwd();
/* 503 */                   BitType val = (BitType)nc.get();
/* 504 */                   if (!val.get()) {
/*     */                     
/* 506 */                     ((BitType)cursorTarget.get()).set(false);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */                     
/*     */                     break;
/*     */                   } 
/*     */                 } 
/*     */               } 
/*     */             }
/*     */           };
/*     */       } 
/*     */     } else {
/* 522 */       for (int i = 0; i < threads.length; i++) {
/*     */         
/* 524 */         final Chunk chunk = chunks.get(i);
/* 525 */         threads[i] = new Thread("Morphology erode thread " + i)
/*     */           {
/*     */             
/*     */             public void run()
/*     */             {
/* 530 */               RandomAccess<Neighborhood<T>> randomAccess = accessible.randomAccess((Interval)target);
/* 531 */               Cursor<T> cursorTarget = target.cursor();
/* 532 */               cursorTarget.jumpFwd(chunk.getStartPosition());
/*     */               
/* 534 */               T max = (T)MorphologyUtils.createVariable(source, (Interval)target); long steps;
/* 535 */               for (steps = 0L; steps < chunk.getLoopSize(); steps++) {
/*     */                 
/* 537 */                 cursorTarget.fwd();
/* 538 */                 randomAccess.setPosition((Localizable)cursorTarget);
/* 539 */                 Neighborhood<T> neighborhood = (Neighborhood<T>)randomAccess.get();
/* 540 */                 Cursor<T> nc = neighborhood.cursor();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */                 
/* 546 */                 max.set(maxVal);
/* 547 */                 while (nc.hasNext()) {
/*     */                   
/* 549 */                   nc.fwd();
/* 550 */                   Type type = (Type)nc.get();
/*     */                   
/* 552 */                   if (((Comparable<T>)type).compareTo(max) < 0)
/*     */                   {
/* 554 */                     max.set(type);
/*     */                   }
/*     */                 } 
/* 557 */                 ((Type)cursorTarget.get()).set((Type)max);
/*     */               } 
/*     */             }
/*     */           };
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 569 */     SimpleMultiThreading.startAndJoin(threads);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends RealType<T>> Img<T> erodeFull(Img<T> source, List<Shape> strels, int numThreads) {
/* 615 */     Img<T> target = source;
/* 616 */     for (Shape strel : strels)
/*     */     {
/* 618 */       target = erodeFull(target, strel, numThreads);
/*     */     }
/* 620 */     return target;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends Type<T> & Comparable<T>> Img<T> erodeFull(Img<T> source, List<Shape> strels, T maxVal, int numThreads) {
/* 680 */     Img<T> target = source;
/* 681 */     for (Shape strel : strels)
/*     */     {
/* 683 */       target = erodeFull(target, strel, maxVal, numThreads);
/*     */     }
/* 685 */     return target;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends RealType<T>> Img<T> erodeFull(Img<T> source, Shape strel, int numThreads) {
/* 726 */     long[][] dimensionsAndOffset = MorphologyUtils.computeTargetImageDimensionsAndOffset((Interval)source, strel);
/*     */     
/* 728 */     long[] targetDims = dimensionsAndOffset[0];
/* 729 */     long[] offset = dimensionsAndOffset[1];
/*     */     
/* 731 */     Img<T> target = source.factory().create(targetDims, ((RealType)source.firstElement()).copy());
/* 732 */     IntervalView<T> offsetTarget = Views.offset((RandomAccessibleInterval)target, offset);
/* 733 */     RealType realType = MorphologyUtils.<RealType>createVariable((RandomAccessible<RealType>)source, (Interval)source);
/* 734 */     realType.setReal(realType.getMaxValue());
/* 735 */     ExtendedRandomAccessibleInterval<T, Img<T>> extended = Views.extendValue((RandomAccessibleInterval)source, (Type)realType);
/*     */     
/* 737 */     erode((RandomAccessible)extended, (IterableInterval<T>)offsetTarget, strel, numThreads);
/* 738 */     return target;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends Type<T> & Comparable<T>> Img<T> erodeFull(Img<T> source, Shape strel, T maxVal, int numThreads) {
/* 794 */     long[][] dimensionsAndOffset = MorphologyUtils.computeTargetImageDimensionsAndOffset((Interval)source, strel);
/* 795 */     long[] targetDims = dimensionsAndOffset[0];
/* 796 */     long[] offset = dimensionsAndOffset[1];
/*     */     
/* 798 */     Img<T> target = source.factory().create(targetDims, ((Type)source.firstElement()).copy());
/* 799 */     IntervalView<T> offsetTarget = Views.offset((RandomAccessibleInterval)target, offset);
/* 800 */     ExtendedRandomAccessibleInterval<T, Img<T>> extended = Views.extendValue((RandomAccessibleInterval)source, (Type)maxVal);
/*     */     
/* 802 */     erode((RandomAccessible)extended, (IterableInterval<T>)offsetTarget, strel, maxVal, numThreads);
/* 803 */     return target;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends RealType<T>> void erodeInPlace(RandomAccessible<T> source, Interval interval, List<Shape> strels, int numThreads) {
/* 842 */     for (Shape strel : strels)
/*     */     {
/* 844 */       erodeInPlace(source, interval, strel, numThreads);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends Type<T> & Comparable<T>> void erodeInPlace(RandomAccessibleInterval<T> source, Interval interval, List<Shape> strels, T maxVal, int numThreads) {
/* 896 */     for (Shape strel : strels)
/*     */     {
/* 898 */       erodeInPlace(source, interval, strel, maxVal, numThreads);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends RealType<T>> void erodeInPlace(RandomAccessible<T> source, Interval interval, Shape strel, int numThreads) {
/* 934 */     RealType realType = MorphologyUtils.<RealType>createVariable(source, interval);
/* 935 */     ImgFactory<T> factory = MorphologyUtils.getSuitableFactory((Dimensions)interval, (T)realType);
/* 936 */     Img<T> img = factory.create((Dimensions)interval, realType);
/* 937 */     long[] min = new long[interval.numDimensions()];
/* 938 */     interval.min(min);
/* 939 */     IntervalView<T> translated = Views.translate((RandomAccessibleInterval)img, min);
/*     */     
/* 941 */     erode(source, (IterableInterval<T>)translated, strel, numThreads);
/* 942 */     MorphologyUtils.copy((IterableInterval)translated, (RandomAccessible)source, numThreads);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends Type<T> & Comparable<T>> void erodeInPlace(RandomAccessibleInterval<T> source, Interval interval, Shape strel, T maxVal, int numThreads) {
/* 989 */     ExtendedRandomAccessibleInterval<T, RandomAccessibleInterval<T>> extended = Views.extendValue(source, (Type)maxVal);
/*     */     
/* 991 */     ImgFactory<T> factory = MorphologyUtils.getSuitableFactory((Dimensions)interval, maxVal);
/* 992 */     Img<T> img = factory.create((Dimensions)interval, maxVal);
/* 993 */     long[] min = new long[interval.numDimensions()];
/* 994 */     interval.min(min);
/* 995 */     IntervalView<T> translated = Views.translate((RandomAccessibleInterval)img, min);
/*     */     
/* 997 */     erode((RandomAccessible)extended, (IterableInterval<T>)translated, strel, maxVal, numThreads);
/* 998 */     MorphologyUtils.copy((IterableInterval<T>)translated, (RandomAccessible)extended, numThreads);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/imglib2-algorithm-0.6.2.jar!/net/imglib2/algorithm/morphology/Erosion.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */