package net.imglib2.algorithm;

public interface Algorithm {
  boolean checkInput();
  
  boolean process();
  
  String getErrorMessage();
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/imglib2-algorithm-0.6.2.jar!/net/imglib2/algorithm/Algorithm.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */