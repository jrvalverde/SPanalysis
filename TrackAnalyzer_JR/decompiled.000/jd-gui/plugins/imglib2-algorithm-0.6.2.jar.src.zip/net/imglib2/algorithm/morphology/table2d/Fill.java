/*    */ package net.imglib2.algorithm.morphology.table2d;
/*    */ 
/*    */ import net.imglib2.IterableInterval;
/*    */ import net.imglib2.RandomAccessible;
/*    */ import net.imglib2.img.Img;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Fill
/*    */   extends Abstract3x3TableOperation
/*    */ {
/*    */   protected boolean[] getTable() {
/* 59 */     return table;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected boolean getExtendedValue() {
/* 65 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public static <T extends net.imglib2.type.BooleanType<T>> Img<T> fill(Img<T> source) {
/* 70 */     return (new Fill()).calculate(source);
/*    */   }
/*    */ 
/*    */   
/*    */   public static <T extends net.imglib2.type.BooleanType<T>> void fill(RandomAccessible<T> source, IterableInterval<T> target) {
/* 75 */     (new Fill()).calculate(source, target);
/*    */   }
/*    */   
/* 78 */   private static final boolean[] table = new boolean[] { 
/*    */       false, false, false, false, false, false, false, false, false, false, 
/*    */       false, false, false, false, false, false, true, true, true, true, 
/*    */       true, true, true, true, true, true, true, true, true, true, 
/*    */       true, true, false, false, false, false, false, false, false, false, 
/*    */       false, false, false, false, false, false, false, false, true, true, 
/*    */       true, true, true, true, true, true, true, true, true, true, 
/*    */       true, true, true, true, false, false, false, false, false, false, 
/*    */       false, false, false, false, false, false, false, false, false, false, 
/*    */       true, true, true, true, true, true, true, true, true, true, 
/*    */       true, true, true, true, true, true, false, false, false, false, 
/*    */       false, false, false, false, false, false, false, false, false, false, 
/*    */       false, false, true, true, true, true, true, true, true, true, 
/*    */       true, true, true, true, true, true, true, true, false, false, 
/*    */       false, false, false, false, false, false, false, false, false, false, 
/*    */       false, false, false, false, true, true, true, true, true, true, 
/*    */       true, true, true, true, true, true, true, true, true, true, 
/*    */       false, false, false, false, false, false, false, false, false, false, 
/*    */       false, false, false, false, false, false, true, true, true, true, 
/*    */       true, true, true, true, true, true, true, true, true, true, 
/*    */       true, true, false, false, false, false, false, false, false, false, 
/*    */       false, false, false, false, false, false, false, false, true, true, 
/*    */       true, true, true, true, true, true, true, true, true, true, 
/*    */       true, true, true, true, false, false, false, false, false, false, 
/*    */       false, false, false, false, false, false, false, false, false, false, 
/*    */       true, true, true, true, true, true, true, true, true, true, 
/*    */       true, true, true, true, true, true, false, false, false, false, 
/*    */       false, false, false, false, false, false, false, false, false, false, 
/*    */       false, false, true, true, true, true, true, true, true, true, 
/*    */       true, true, true, true, true, true, true, true, false, false, 
/*    */       false, false, false, false, false, false, false, false, false, false, 
/*    */       false, false, false, false, true, true, true, true, true, true, 
/*    */       true, true, true, true, true, true, true, true, true, true, 
/*    */       false, false, false, false, false, false, false, false, false, false, 
/*    */       false, false, false, false, false, false, true, true, true, true, 
/*    */       true, true, true, true, true, true, true, true, true, true, 
/*    */       true, true, false, false, false, false, false, false, false, false, 
/*    */       false, false, false, false, false, false, false, false, true, true, 
/*    */       true, true, true, true, true, true, true, true, true, true, 
/*    */       true, true, true, true, false, false, false, false, false, false, 
/*    */       false, false, false, false, false, false, false, false, false, false, 
/*    */       true, true, true, true, true, true, true, true, true, true, 
/*    */       true, true, true, true, true, true, false, false, false, false, 
/*    */       false, false, false, false, false, false, false, false, false, false, 
/*    */       false, false, true, true, true, true, true, true, true, true, 
/*    */       true, true, true, true, true, true, true, true, false, false, 
/*    */       false, false, false, false, false, false, false, false, false, false, 
/*    */       false, false, false, false, true, true, true, true, true, true, 
/*    */       true, true, true, true, true, true, true, true, true, true, 
/*    */       false, false, false, false, false, false, false, false, false, false, 
/*    */       false, false, false, false, false, true, true, true, true, true, 
/*    */       true, true, true, true, true, true, true, true, true, true, 
/*    */       true, true };
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/imglib2-algorithm-0.6.2.jar!/net/imglib2/algorithm/morphology/table2d/Fill.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */