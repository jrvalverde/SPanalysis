/*    */ package net.imglib2.algorithm.morphology.table2d;
/*    */ 
/*    */ import net.imglib2.IterableInterval;
/*    */ import net.imglib2.RandomAccessible;
/*    */ import net.imglib2.img.Img;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Endpoints
/*    */   extends Abstract3x3TableOperation
/*    */ {
/*    */   protected boolean[] getTable() {
/* 61 */     return table;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected boolean getExtendedValue() {
/* 67 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public static <T extends net.imglib2.type.BooleanType<T>> Img<T> endpoints(Img<T> source) {
/* 72 */     return (new Endpoints()).calculate(source);
/*    */   }
/*    */ 
/*    */   
/*    */   public static <T extends net.imglib2.type.BooleanType<T>> void endpoints(RandomAccessible<T> source, IterableInterval<T> target) {
/* 77 */     (new Endpoints()).calculate(source, target);
/*    */   }
/*    */   
/* 80 */   private static final boolean[] table = new boolean[] { 
/*    */       false, false, false, false, false, false, false, false, false, false, 
/*    */       false, false, false, false, false, false, true, true, true, false, 
/*    */       true, false, false, false, true, false, false, false, false, false, 
/*    */       false, false, false, false, false, false, false, false, false, false, 
/*    */       false, false, false, false, false, false, false, false, true, false, 
/*    */       false, false, false, false, false, false, false, false, false, false, 
/*    */       false, false, false, false, false, false, false, false, false, false, 
/*    */       false, false, false, false, false, false, false, false, false, false, 
/*    */       true, false, false, false, false, false, false, false, false, false, 
/*    */       false, false, false, false, false, false, false, false, false, false, 
/*    */       false, false, false, false, false, false, false, false, false, false, 
/*    */       false, false, false, false, false, false, false, false, false, false, 
/*    */       false, false, false, false, false, false, false, false, false, false, 
/*    */       false, false, false, false, false, false, false, false, false, false, 
/*    */       false, false, false, false, true, false, false, false, false, false, 
/*    */       false, false, false, false, false, false, false, false, false, false, 
/*    */       false, false, false, false, false, false, false, false, false, false, 
/*    */       false, false, false, false, false, false, false, false, false, false, 
/*    */       false, false, false, false, false, false, false, false, false, false, 
/*    */       false, false, false, false, false, false, false, false, false, false, 
/*    */       false, false, false, false, false, false, false, false, false, false, 
/*    */       false, false, false, false, false, false, false, false, false, false, 
/*    */       false, false, false, false, false, false, false, false, false, false, 
/*    */       false, false, false, false, false, false, false, false, false, false, 
/*    */       false, false, false, false, false, false, false, false, false, false, 
/*    */       false, false, false, false, false, false, false, false, false, false, 
/*    */       false, false, false, false, false, false, false, false, false, false, 
/*    */       false, false, true, false, false, false, false, false, false, false, 
/*    */       false, false, false, false, false, false, false, false, false, false, 
/*    */       false, false, false, false, false, false, false, false, false, false, 
/*    */       false, false, false, false, false, false, false, false, false, false, 
/*    */       false, false, false, false, false, false, false, false, false, false, 
/*    */       false, false, false, false, false, false, false, false, false, false, 
/*    */       false, false, false, false, false, false, false, false, false, false, 
/*    */       false, false, false, false, false, false, false, false, false, false, 
/*    */       false, false, false, false, false, false, false, false, false, false, 
/*    */       false, false, false, false, false, false, false, false, false, false, 
/*    */       false, false, false, false, false, false, false, false, false, false, 
/*    */       false, false, false, false, false, false, false, false, false, false, 
/*    */       false, false, false, false, false, false, false, false, false, false, 
/*    */       false, false, false, false, false, false, false, false, false, false, 
/*    */       false, false, false, false, false, false, false, false, false, false, 
/*    */       false, false, false, false, false, false, false, false, false, false, 
/*    */       false, false, false, false, false, false, false, false, false, false, 
/*    */       false, false, false, false, false, false, false, false, false, false, 
/*    */       false, false, false, false, false, false, false, false, false, false, 
/*    */       false, false, false, false, false, false, false, false, false, false, 
/*    */       false, false, false, false, false, false, false, false, false, false, 
/*    */       false, false, false, false, false, false, false, false, false, false, 
/*    */       false, false, false, false, false, false, false, false, false, false, 
/*    */       false, false, false, false, false, false, false, false, false, false, 
/*    */       false, false };
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/imglib2-algorithm-0.6.2.jar!/net/imglib2/algorithm/morphology/table2d/Endpoints.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */