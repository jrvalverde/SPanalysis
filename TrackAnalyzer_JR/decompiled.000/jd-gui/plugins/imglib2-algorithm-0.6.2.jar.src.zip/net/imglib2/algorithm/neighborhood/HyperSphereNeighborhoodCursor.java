/*     */ package net.imglib2.algorithm.neighborhood;
/*     */ 
/*     */ import net.imglib2.Cursor;
/*     */ import net.imglib2.Interval;
/*     */ import net.imglib2.RandomAccessible;
/*     */ import net.imglib2.RandomAccessibleInterval;
/*     */ import net.imglib2.RealCursor;
/*     */ import net.imglib2.Sampler;
/*     */ import net.imglib2.util.IntervalIndexer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class HyperSphereNeighborhoodCursor<T>
/*     */   extends HypersphereNeighborhoodLocalizableSampler<T>
/*     */   implements Cursor<Neighborhood<T>>
/*     */ {
/*     */   private final long[] dimensions;
/*     */   private final long[] min;
/*     */   private final long[] max;
/*     */   private long index;
/*     */   private final long maxIndex;
/*     */   private long maxIndexOnLine;
/*     */   
/*     */   public HyperSphereNeighborhoodCursor(RandomAccessibleInterval<T> source, long radius, HyperSphereNeighborhoodFactory<T> factory) {
/*  57 */     super((RandomAccessible<T>)source, radius, factory, (Interval)source);
/*     */     
/*  59 */     this.dimensions = new long[this.n];
/*  60 */     this.min = new long[this.n];
/*  61 */     this.max = new long[this.n];
/*  62 */     source.dimensions(this.dimensions);
/*  63 */     source.min(this.min);
/*  64 */     source.max(this.max);
/*  65 */     long size = this.dimensions[0];
/*  66 */     for (int d = 1; d < this.n; d++)
/*  67 */       size *= this.dimensions[d]; 
/*  68 */     this.maxIndex = size - 1L;
/*  69 */     reset();
/*     */   }
/*     */ 
/*     */   
/*     */   private HyperSphereNeighborhoodCursor(HyperSphereNeighborhoodCursor<T> c) {
/*  74 */     super(c);
/*  75 */     this.dimensions = (long[])c.dimensions.clone();
/*  76 */     this.min = (long[])c.min.clone();
/*  77 */     this.max = (long[])c.max.clone();
/*  78 */     this.maxIndex = c.maxIndex;
/*  79 */     this.index = c.index;
/*  80 */     this.maxIndexOnLine = c.maxIndexOnLine;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void fwd() {
/*  86 */     this.currentPos[0] = this.currentPos[0] + 1L;
/*  87 */     if (++this.index > this.maxIndexOnLine) {
/*  88 */       nextLine();
/*     */     }
/*     */   }
/*     */   
/*     */   private void nextLine() {
/*  93 */     this.currentPos[0] = this.min[0];
/*  94 */     this.maxIndexOnLine += this.dimensions[0];
/*  95 */     for (int d = 1; d < this.n; ) {
/*     */       
/*  97 */       this.currentPos[d] = this.currentPos[d] + 1L;
/*  98 */       if (this.currentPos[d] > this.max[d]) {
/*     */         
/* 100 */         this.currentPos[d] = this.min[d];
/*     */         d++;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void reset() {
/* 110 */     this.index = -1L;
/* 111 */     this.maxIndexOnLine = -1L;
/* 112 */     System.arraycopy(this.max, 0, this.currentPos, 0, this.n);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasNext() {
/* 118 */     return (this.index < this.maxIndex);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void jumpFwd(long steps) {
/* 124 */     this.index += steps;
/* 125 */     if (this.index < 0L) {
/*     */       
/* 127 */       this.maxIndexOnLine = (1L + this.index) / this.dimensions[0] * this.dimensions[0] - 1L;
/* 128 */       long size = this.maxIndex + 1L;
/* 129 */       IntervalIndexer.indexToPositionWithOffset(size - -this.index % size, this.dimensions, this.min, this.currentPos);
/*     */     }
/*     */     else {
/*     */       
/* 133 */       this.maxIndexOnLine = (1L + this.index / this.dimensions[0]) * this.dimensions[0] - 1L;
/* 134 */       IntervalIndexer.indexToPositionWithOffset(this.index, this.dimensions, this.min, this.currentPos);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Neighborhood<T> next() {
/* 141 */     fwd();
/* 142 */     return get();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void remove() {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HyperSphereNeighborhoodCursor<T> copy() {
/* 154 */     return new HyperSphereNeighborhoodCursor(this);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public HyperSphereNeighborhoodCursor<T> copyCursor() {
/* 160 */     return copy();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/imglib2-algorithm-0.6.2.jar!/net/imglib2/algorithm/neighborhood/HyperSphereNeighborhoodCursor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */