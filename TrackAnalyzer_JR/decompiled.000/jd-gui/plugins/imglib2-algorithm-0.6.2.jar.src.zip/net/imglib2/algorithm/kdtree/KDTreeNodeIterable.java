/*     */ package net.imglib2.algorithm.kdtree;
/*     */ 
/*     */ import java.util.ArrayDeque;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import net.imglib2.KDTreeNode;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class KDTreeNodeIterable<T>
/*     */   implements Iterable<KDTreeNode<T>>
/*     */ {
/*     */   private final ArrayList<KDTreeNode<T>> singleNodes;
/*     */   private final ArrayList<KDTreeNode<T>> subtrees;
/*     */   
/*     */   public KDTreeNodeIterable(ArrayList<KDTreeNode<T>> singleNodes, ArrayList<KDTreeNode<T>> subtrees) {
/*  51 */     this.singleNodes = singleNodes;
/*  52 */     this.subtrees = subtrees;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Iterator<KDTreeNode<T>> iterator() {
/*  59 */     return new Iter<>(this.singleNodes, this.subtrees);
/*     */   }
/*     */ 
/*     */   
/*     */   private static class Iter<T>
/*     */     implements Iterator<KDTreeNode<T>>
/*     */   {
/*     */     private final ArrayList<KDTreeNode<T>> nodes;
/*     */     
/*     */     private int nextNodeIndex;
/*     */     
/*     */     private final ArrayList<KDTreeNode<T>> subtrees;
/*     */     
/*     */     private int nextSubtreeIndex;
/*     */     private final ArrayDeque<KDTreeNode<T>> stack;
/*     */     
/*     */     private Iter(ArrayList<KDTreeNode<T>> nodes, ArrayList<KDTreeNode<T>> subtrees) {
/*  76 */       this.nodes = nodes;
/*  77 */       this.subtrees = subtrees;
/*  78 */       this.nextNodeIndex = 0;
/*  79 */       this.nextSubtreeIndex = 0;
/*  80 */       this.stack = new ArrayDeque<>();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean hasNext() {
/*  86 */       return (!this.stack.isEmpty() || this.nextSubtreeIndex < this.subtrees.size() || this.nextNodeIndex < this.nodes.size());
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public KDTreeNode<T> next() {
/*  92 */       if (!this.stack.isEmpty()) {
/*     */         
/*  94 */         KDTreeNode<T> current = this.stack.pop();
/*  95 */         if (current.left != null)
/*  96 */           this.stack.push(current.left); 
/*  97 */         if (current.right != null)
/*  98 */           this.stack.push(current.right); 
/*  99 */         return current;
/*     */       } 
/* 101 */       if (this.nextSubtreeIndex < this.subtrees.size()) {
/*     */         
/* 103 */         KDTreeNode<T> current = this.subtrees.get(this.nextSubtreeIndex++);
/* 104 */         if (current.left != null)
/* 105 */           this.stack.push(current.left); 
/* 106 */         if (current.right != null)
/* 107 */           this.stack.push(current.right); 
/* 108 */         return current;
/*     */       } 
/* 110 */       if (this.nextNodeIndex < this.nodes.size())
/*     */       {
/* 112 */         return this.nodes.get(this.nextNodeIndex++);
/*     */       }
/*     */       
/* 115 */       return null;
/*     */     }
/*     */     
/*     */     public void remove() {}
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/imglib2-algorithm-0.6.2.jar!/net/imglib2/algorithm/kdtree/KDTreeNodeIterable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */