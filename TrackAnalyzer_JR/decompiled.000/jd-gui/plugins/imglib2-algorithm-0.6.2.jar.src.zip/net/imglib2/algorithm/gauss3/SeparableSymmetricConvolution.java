/*     */ package net.imglib2.algorithm.gauss3;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.concurrent.Callable;
/*     */ import java.util.concurrent.ExecutionException;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.Future;
/*     */ import net.imglib2.Dimensions;
/*     */ import net.imglib2.FinalInterval;
/*     */ import net.imglib2.Interval;
/*     */ import net.imglib2.Positionable;
/*     */ import net.imglib2.RandomAccess;
/*     */ import net.imglib2.RandomAccessible;
/*     */ import net.imglib2.RandomAccessibleInterval;
/*     */ import net.imglib2.exception.IncompatibleTypeException;
/*     */ import net.imglib2.img.Img;
/*     */ import net.imglib2.img.ImgFactory;
/*     */ import net.imglib2.img.array.ArrayImgFactory;
/*     */ import net.imglib2.img.cell.CellImgFactory;
/*     */ import net.imglib2.img.list.ListImgFactory;
/*     */ import net.imglib2.type.NativeType;
/*     */ import net.imglib2.type.numeric.NumericType;
/*     */ import net.imglib2.type.numeric.real.DoubleType;
/*     */ import net.imglib2.type.numeric.real.FloatType;
/*     */ import net.imglib2.util.IntervalIndexer;
/*     */ import net.imglib2.util.Util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SeparableSymmetricConvolution
/*     */ {
/*     */   public static <S extends NumericType<S>, T extends NumericType<T>> void convolve(double[][] halfkernels, RandomAccessible<S> source, RandomAccessibleInterval<T> target, ExecutorService service) throws IncompatibleTypeException {
/* 106 */     NumericType numericType = (NumericType)Util.getTypeFromInterval((Interval)target);
/* 107 */     S sourceType = getType(source, (Interval)target);
/* 108 */     if (numericType instanceof net.imglib2.type.numeric.RealType) {
/*     */       
/* 110 */       if (!(sourceType instanceof net.imglib2.type.numeric.RealType)) {
/* 111 */         throw new IncompatibleTypeException(sourceType, "RealType source required for convolving into a RealType target");
/*     */       }
/*     */ 
/*     */       
/* 115 */       Object oTargetType = numericType;
/* 116 */       if (oTargetType instanceof DoubleType) {
/* 117 */         convolveRealTypeDouble(halfkernels, (RandomAccessible)source, (RandomAccessibleInterval)target, service);
/*     */       } else {
/* 119 */         convolveRealTypeFloat(halfkernels, (RandomAccessible)source, (RandomAccessibleInterval)target, service);
/*     */       } 
/*     */     } else {
/*     */       
/* 123 */       if (!numericType.getClass().isInstance(sourceType))
/* 124 */         throw new IncompatibleTypeException(sourceType, numericType.getClass().getCanonicalName() + " source required for convolving into a " + numericType.getClass().getCanonicalName() + " target"); 
/* 125 */       if (numericType instanceof NativeType) {
/* 126 */         convolveNativeType(halfkernels, source, target, service);
/*     */       } else {
/* 128 */         convolveNumericType(halfkernels, source, target, service);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static <S extends net.imglib2.type.numeric.RealType<S>, T extends net.imglib2.type.numeric.RealType<T>> void convolveRealTypeFloat(double[][] halfkernels, RandomAccessible<S> source, RandomAccessibleInterval<T> target, ExecutorService service) {
/* 135 */     FloatType type = new FloatType();
/* 136 */     ImgFactory<FloatType> imgfac = getImgFactory((Dimensions)target, halfkernels, type);
/* 137 */     if (canUseBufferedConvolver((Dimensions)target, halfkernels)) {
/* 138 */       convolve(halfkernels, source, target, 
/* 139 */           FloatConvolverRealTypeBuffered.factory(), 
/* 140 */           FloatConvolverRealTypeBuffered.factory(), 
/* 141 */           FloatConvolverRealTypeBuffered.factory(), 
/* 142 */           FloatConvolverRealTypeBuffered.factory(), imgfac, type, service);
/*     */     } else {
/* 144 */       convolve(halfkernels, source, target, 
/* 145 */           FloatConvolverRealType.factory(), 
/* 146 */           FloatConvolverRealType.factory(), 
/* 147 */           FloatConvolverRealType.factory(), 
/* 148 */           FloatConvolverRealType.factory(), imgfac, type, service);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static <S extends net.imglib2.type.numeric.RealType<S>, T extends net.imglib2.type.numeric.RealType<T>> void convolveRealTypeDouble(double[][] halfkernels, RandomAccessible<S> source, RandomAccessibleInterval<T> target, ExecutorService service) {
/* 154 */     DoubleType type = new DoubleType();
/* 155 */     ImgFactory<DoubleType> imgfac = getImgFactory((Dimensions)target, halfkernels, type);
/* 156 */     if (canUseBufferedConvolver((Dimensions)target, halfkernels)) {
/* 157 */       convolve(halfkernels, source, target, 
/* 158 */           DoubleConvolverRealTypeBuffered.factory(), 
/* 159 */           DoubleConvolverRealTypeBuffered.factory(), 
/* 160 */           DoubleConvolverRealTypeBuffered.factory(), 
/* 161 */           DoubleConvolverRealTypeBuffered.factory(), imgfac, type, service);
/*     */     } else {
/* 163 */       convolve(halfkernels, source, target, 
/* 164 */           DoubleConvolverRealType.factory(), 
/* 165 */           DoubleConvolverRealType.factory(), 
/* 166 */           DoubleConvolverRealType.factory(), 
/* 167 */           DoubleConvolverRealType.factory(), imgfac, type, service);
/*     */     } 
/*     */   }
/*     */   
/*     */   private static <T extends NumericType<T> & NativeType<T>> void convolveNativeType(double[][] halfkernels, RandomAccessible<T> source, RandomAccessibleInterval<T> target, ExecutorService service) {
/*     */     ConvolverFactory<T, T> convfac;
/* 173 */     NumericType numericType = (NumericType)Util.getTypeFromInterval((Interval)target);
/*     */     
/* 175 */     if (canUseBufferedConvolver((Dimensions)target, halfkernels)) {
/* 176 */       convfac = ConvolverNativeTypeBuffered.factory((T)numericType);
/*     */     } else {
/* 178 */       convfac = ConvolverNativeType.factory((T)numericType);
/* 179 */     }  ImgFactory<T> imgfac = (ImgFactory)getImgFactory((Dimensions)target, halfkernels, (NativeType)numericType);
/* 180 */     convolve(halfkernels, source, target, convfac, convfac, convfac, convfac, imgfac, (T)numericType, service);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static <T extends NumericType<T>> void convolveNumericType(double[][] halfkernels, RandomAccessible<T> source, RandomAccessibleInterval<T> target, ExecutorService service) {
/* 186 */     NumericType numericType = (NumericType)Util.getTypeFromInterval((Interval)target);
/* 187 */     ConvolverFactory<T, T> convfac = ConvolverNumericType.factory((T)numericType);
/* 188 */     convolve(halfkernels, source, target, convfac, convfac, convfac, convfac, (ImgFactory<T>)new ListImgFactory(), (T)numericType, service);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static <T extends NumericType<T>> T getType(RandomAccessible<T> accessible, Interval interval) {
/* 201 */     RandomAccess<T> a = accessible.randomAccess();
/* 202 */     interval.min((Positionable)a);
/* 203 */     return (T)a.get();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <S, T> void convolve1d(double[] halfkernel, RandomAccessible<S> source, RandomAccessibleInterval<T> target, ConvolverFactory<S, T> convolverFactoryST, ExecutorService service) {
/* 211 */     long[] sourceOffset = { (1 - halfkernel.length) };
/* 212 */     convolveOffset(halfkernel, source, sourceOffset, (RandomAccessible<T>)target, (Interval)target, 0, convolverFactoryST, service, 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <S, I, T> void convolve(double[][] halfkernels, RandomAccessible<S> source, RandomAccessibleInterval<T> target, ConvolverFactory<S, I> convolverFactorySI, ConvolverFactory<I, I> convolverFactoryII, ConvolverFactory<I, T> convolverFactoryIT, ConvolverFactory<S, T> convolverFactoryST, ImgFactory<I> imgFactory, I type, ExecutorService service) {
/* 260 */     int n = source.numDimensions();
/* 261 */     if (n == 1) {
/*     */       
/* 263 */       convolve1d(halfkernels[0], source, target, convolverFactoryST, service);
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 268 */       int numThreads = Runtime.getRuntime().availableProcessors();
/* 269 */       int numTasks = (numThreads > 1) ? (numThreads * 4) : 1;
/* 270 */       long[] sourceOffset = new long[n];
/* 271 */       long[] targetOffset = new long[n];
/* 272 */       target.min(sourceOffset);
/* 273 */       for (int d = 0; d < n; d++) {
/*     */         
/* 275 */         targetOffset[d] = -sourceOffset[d];
/* 276 */         sourceOffset[d] = sourceOffset[d] + (1 - (halfkernels[d]).length);
/*     */       } 
/*     */       
/* 279 */       long[][] tmpdims = getTempImageDimensions((Dimensions)target, halfkernels);
/* 280 */       Img<I> tmp1 = imgFactory.create(tmpdims[0], type);
/* 281 */       if (n == 2) {
/*     */         
/* 283 */         convolveOffset(halfkernels[0], source, sourceOffset, (RandomAccessible<I>)tmp1, (Interval)tmp1, 0, convolverFactorySI, service, numTasks);
/* 284 */         convolveOffset(halfkernels[1], (RandomAccessible<I>)tmp1, targetOffset, (RandomAccessible<T>)target, (Interval)target, 1, convolverFactoryIT, service, numTasks);
/*     */       }
/*     */       else {
/*     */         
/* 288 */         Img<I> tmp2 = imgFactory.create(tmpdims[1], type);
/* 289 */         long[] zeroOffset = new long[n];
/* 290 */         convolveOffset(halfkernels[0], source, sourceOffset, (RandomAccessible<I>)tmp1, (Interval)new FinalInterval(tmpdims[0]), 0, convolverFactorySI, service, numTasks);
/* 291 */         for (int i = 1; i < n - 1; i++) {
/*     */           
/* 293 */           convolveOffset(halfkernels[i], (RandomAccessible<I>)tmp1, zeroOffset, (RandomAccessible<I>)tmp2, (Interval)new FinalInterval(tmpdims[i]), i, convolverFactoryII, service, numTasks);
/* 294 */           Img<I> tmp = tmp2;
/* 295 */           tmp2 = tmp1;
/* 296 */           tmp1 = tmp;
/*     */         } 
/* 298 */         convolveOffset(halfkernels[n - 1], (RandomAccessible<I>)tmp1, targetOffset, (RandomAccessible<T>)target, (Interval)target, n - 1, convolverFactoryIT, service, numTasks);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static <S, T> void convolveOffset(final double[] halfkernel, final RandomAccessible<S> source, long[] sourceOffset, final RandomAccessible<T> target, final Interval targetInterval, final int d, final ConvolverFactory<S, T> factory, ExecutorService service, int numTasks) {
/* 308 */     final int n = source.numDimensions();
/* 309 */     int k1 = halfkernel.length - 1;
/* 310 */     long tmp = 1L;
/* 311 */     for (int i = 0; i < n; i++) {
/* 312 */       if (i != d)
/* 313 */         tmp *= targetInterval.dimension(i); 
/* 314 */     }  long endIndex = tmp;
/* 315 */     long taskSize = tmp / numTasks;
/*     */     
/* 317 */     final long[] min = new long[n];
/* 318 */     final long[] max = new long[n];
/* 319 */     final long[] dim = new long[n];
/* 320 */     targetInterval.min(min);
/* 321 */     targetInterval.max(max);
/* 322 */     targetInterval.dimensions(dim);
/* 323 */     dim[d] = 1L;
/*     */     
/* 325 */     final long[] srcmin = new long[n];
/* 326 */     final long[] srcmax = new long[n];
/* 327 */     for (int j = 0; j < n; j++) {
/*     */       
/* 329 */       srcmin[j] = min[j] + sourceOffset[j];
/* 330 */       srcmax[j] = max[j] + sourceOffset[j];
/*     */     } 
/* 332 */     srcmax[d] = srcmax[d] + (2 * k1);
/*     */     
/* 334 */     ArrayList<Future<Void>> futures = new ArrayList<>();
/*     */     
/* 336 */     for (int taskNum = 0; taskNum < numTasks; taskNum++) {
/*     */       
/* 338 */       final long myStartIndex = taskNum * taskSize;
/* 339 */       final long myEndIndex = (taskNum == numTasks - 1) ? endIndex : (myStartIndex + taskSize);
/*     */ 
/*     */       
/* 342 */       Callable<Void> r = new Callable<Void>()
/*     */         {
/*     */           
/*     */           public Void call()
/*     */           {
/* 347 */             RandomAccess<S> in = source.randomAccess((Interval)new FinalInterval(srcmin, srcmax));
/* 348 */             RandomAccess<T> out = target.randomAccess(targetInterval);
/* 349 */             Runnable convolver = factory.create(halfkernel, in, out, d, targetInterval.dimension(d));
/*     */             
/* 351 */             out.setPosition(min);
/* 352 */             in.setPosition(srcmin);
/*     */             
/* 354 */             long[] moveToStart = new long[n];
/* 355 */             IntervalIndexer.indexToPosition(myStartIndex, dim, moveToStart);
/* 356 */             out.move(moveToStart);
/* 357 */             in.move(moveToStart);
/*     */             long index;
/* 359 */             for (index = myStartIndex; index < myEndIndex; index++) {
/*     */               
/* 361 */               convolver.run();
/* 362 */               out.setPosition(min[d], d);
/* 363 */               in.setPosition(srcmin[d], d);
/* 364 */               for (int i = 0; i < n; i++) {
/*     */                 
/* 366 */                 if (i != d) {
/*     */                   
/* 368 */                   out.fwd(i);
/* 369 */                   if (out.getLongPosition(i) > max[i]) {
/*     */                     
/* 371 */                     out.setPosition(min[i], i);
/* 372 */                     in.setPosition(srcmin[i], i);
/*     */                   }
/*     */                   else {
/*     */                     
/* 376 */                     in.fwd(i);
/*     */                     break;
/*     */                   } 
/*     */                 } 
/*     */               } 
/*     */             } 
/* 382 */             return null;
/*     */           }
/*     */         };
/* 385 */       futures.add(service.submit(r));
/*     */     } 
/* 387 */     for (Future<Void> future : futures) {
/*     */ 
/*     */       
/*     */       try {
/* 391 */         future.get();
/*     */       }
/* 393 */       catch (InterruptedException e) {
/*     */         
/* 395 */         e.printStackTrace();
/*     */       }
/* 397 */       catch (ExecutionException e) {
/*     */         
/* 399 */         e.printStackTrace();
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   static long[][] getTempImageDimensions(Dimensions targetsize, double[][] halfkernels) {
/* 406 */     int n = targetsize.numDimensions();
/* 407 */     long[][] tmpdims = new long[n][];
/* 408 */     tmpdims[n - 1] = new long[n];
/* 409 */     targetsize.dimensions(tmpdims[n - 1]);
/* 410 */     for (int d = n - 2; d >= 0; d--) {
/*     */       
/* 412 */       tmpdims[d] = (long[])tmpdims[d + 1].clone();
/* 413 */       tmpdims[d][d + 1] = tmpdims[d][d + 1] + (2 * (halfkernels[d + 1]).length - 2);
/*     */     } 
/* 415 */     return tmpdims;
/*     */   }
/*     */ 
/*     */   
/*     */   static boolean canUseBufferedConvolver(Dimensions targetsize, double[][] halfkernels) {
/* 420 */     int n = targetsize.numDimensions();
/* 421 */     for (int d = 0; d < n; d++) {
/* 422 */       if (targetsize.dimension(d) + (4 * (halfkernels[d]).length) - 4L > 2147483647L)
/* 423 */         return false; 
/* 424 */     }  return true;
/*     */   }
/*     */ 
/*     */   
/*     */   static boolean canUseArrayImgFactory(Dimensions targetsize, double[][] halfkernels) {
/* 429 */     int n = targetsize.numDimensions();
/* 430 */     long size = targetsize.dimension(0);
/* 431 */     for (int d = 1; d < n; d++)
/* 432 */       size *= targetsize.dimension(d) + (2 * (halfkernels[d]).length); 
/* 433 */     return (size <= 2147483647L);
/*     */   }
/*     */ 
/*     */   
/*     */   static <T extends NativeType<T>> ImgFactory<T> getImgFactory(Dimensions targetsize, double[][] halfkernels, T type) {
/* 438 */     if (canUseArrayImgFactory(targetsize, halfkernels))
/* 439 */       return (ImgFactory<T>)new ArrayImgFactory(); 
/* 440 */     int cellSize = (int)Math.pow(2.147483647E9D / type.getEntitiesPerPixel().getRatio(), 1.0D / targetsize.numDimensions());
/* 441 */     return (ImgFactory<T>)new CellImgFactory(cellSize);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/imglib2-algorithm-0.6.2.jar!/net/imglib2/algorithm/gauss3/SeparableSymmetricConvolution.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */