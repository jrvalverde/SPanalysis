package net.imglib2.algorithm.neighborhood;

import net.imglib2.RandomAccess;

public interface HorizontalLineNeighborhoodFactory<T> {
  Neighborhood<T> create(long[] paramArrayOflong, long paramLong, int paramInt, boolean paramBoolean, RandomAccess<T> paramRandomAccess);
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/imglib2-algorithm-0.6.2.jar!/net/imglib2/algorithm/neighborhood/HorizontalLineNeighborhoodFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */