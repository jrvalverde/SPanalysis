package net.imglib2.algorithm.componenttree;

import net.imglib2.Localizable;

public interface PartialComponent<T, C extends PartialComponent<T, C>> {
  void setValue(T paramT);
  
  T getValue();
  
  void addPosition(Localizable paramLocalizable);
  
  void merge(C paramC);
  
  public static interface Handler<C> {
    void emit(C param1C);
  }
  
  public static interface Generator<T, C extends PartialComponent<T, C>> {
    C createComponent(T param1T);
    
    C createMaxComponent();
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/imglib2-algorithm-0.6.2.jar!/net/imglib2/algorithm/componenttree/PartialComponent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */