/*     */ package net.imglib2.algorithm.componenttree.mser;
/*     */ 
/*     */ import net.imglib2.RandomAccessibleInterval;
/*     */ import net.imglib2.algorithm.componenttree.PartialComponent;
/*     */ import net.imglib2.img.Img;
/*     */ import net.imglib2.img.ImgFactory;
/*     */ import net.imglib2.type.Type;
/*     */ import net.imglib2.type.numeric.integer.LongType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class MserPartialComponentGenerator<T extends Type<T>>
/*     */   implements PartialComponent.Generator<T, MserPartialComponent<T>>
/*     */ {
/*     */   final T maxValue;
/*     */   final long[] dimensions;
/*     */   final Img<LongType> linkedList;
/*     */   
/*     */   public MserPartialComponentGenerator(T maxValue, RandomAccessibleInterval<T> input, ImgFactory<LongType> imgFactory) {
/*  87 */     this.maxValue = maxValue;
/*  88 */     this.dimensions = new long[input.numDimensions()];
/*  89 */     input.dimensions(this.dimensions);
/*  90 */     this.linkedList = imgFactory.create(this.dimensions, new LongType());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public MserPartialComponent<T> createComponent(T value) {
/*  96 */     return new MserPartialComponent<>(value, this);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public MserPartialComponent<T> createMaxComponent() {
/* 102 */     return new MserPartialComponent<>(this.maxValue, this);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/imglib2-algorithm-0.6.2.jar!/net/imglib2/algorithm/componenttree/mser/MserPartialComponentGenerator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */