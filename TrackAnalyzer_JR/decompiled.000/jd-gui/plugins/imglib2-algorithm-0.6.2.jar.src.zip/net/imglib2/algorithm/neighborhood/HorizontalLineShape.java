/*     */ package net.imglib2.algorithm.neighborhood;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import net.imglib2.AbstractEuclideanSpace;
/*     */ import net.imglib2.AbstractInterval;
/*     */ import net.imglib2.Cursor;
/*     */ import net.imglib2.FlatIterationOrder;
/*     */ import net.imglib2.Interval;
/*     */ import net.imglib2.IterableInterval;
/*     */ import net.imglib2.RandomAccess;
/*     */ import net.imglib2.RandomAccessible;
/*     */ import net.imglib2.RandomAccessibleInterval;
/*     */ import net.imglib2.RealCursor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HorizontalLineShape
/*     */   implements Shape
/*     */ {
/*     */   private final long span;
/*     */   private final boolean skipCenter;
/*     */   private final int dim;
/*     */   
/*     */   public HorizontalLineShape(long span, int dim, boolean skipCenter) {
/*  77 */     this.span = span;
/*  78 */     this.dim = dim;
/*  79 */     this.skipCenter = skipCenter;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> NeighborhoodsIterableInterval<T> neighborhoods(RandomAccessibleInterval<T> source) {
/*  85 */     return new NeighborhoodsIterableInterval<>(source, this.span, this.dim, this.skipCenter, HorizontalLineNeighborhoodUnsafe.factory());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> NeighborhoodsAccessible<T> neighborhoodsRandomAccessible(RandomAccessible<T> source) {
/*  91 */     HorizontalLineNeighborhoodFactory<T> f = HorizontalLineNeighborhoodUnsafe.factory();
/*  92 */     return new NeighborhoodsAccessible<>(source, this.span, this.dim, this.skipCenter, f);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> IterableInterval<Neighborhood<T>> neighborhoodsSafe(RandomAccessibleInterval<T> source) {
/*  98 */     return new NeighborhoodsIterableInterval<>(source, this.span, this.dim, this.skipCenter, HorizontalLineNeighborhood.factory());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> NeighborhoodsAccessible<T> neighborhoodsRandomAccessibleSafe(RandomAccessible<T> source) {
/* 104 */     HorizontalLineNeighborhoodFactory<T> f = HorizontalLineNeighborhood.factory();
/* 105 */     return new NeighborhoodsAccessible<>(source, this.span, this.dim, this.skipCenter, f);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSkippingCenter() {
/* 115 */     return this.skipCenter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getSpan() {
/* 123 */     return this.span;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getLineDimension() {
/* 131 */     return this.dim;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 137 */     return "HorizontalLineShape, span = " + this.span + " in dim " + this.dim + ", skipCenter = " + this.skipCenter;
/*     */   }
/*     */ 
/*     */   
/*     */   public static final class NeighborhoodsIterableInterval<T>
/*     */     extends AbstractInterval
/*     */     implements IterableInterval<Neighborhood<T>>
/*     */   {
/*     */     final RandomAccessibleInterval<T> source;
/*     */     
/*     */     final long span;
/*     */     
/*     */     final HorizontalLineNeighborhoodFactory<T> factory;
/*     */     
/*     */     final long size;
/*     */     final int dim;
/*     */     final boolean skipCenter;
/*     */     
/*     */     public NeighborhoodsIterableInterval(RandomAccessibleInterval<T> source, long span, int dim, boolean skipCenter, HorizontalLineNeighborhoodFactory<T> factory) {
/* 156 */       super((Interval)source);
/* 157 */       this.source = source;
/* 158 */       this.span = span;
/* 159 */       this.dim = dim;
/* 160 */       this.skipCenter = skipCenter;
/* 161 */       this.factory = factory;
/* 162 */       long s = source.dimension(0);
/* 163 */       for (int d = 1; d < this.n; d++)
/* 164 */         s *= source.dimension(d); 
/* 165 */       this.size = s;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Cursor<Neighborhood<T>> cursor() {
/* 171 */       return new HorizontalLineNeighborhoodCursor<>(this.source, this.span, this.dim, this.skipCenter, this.factory);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public long size() {
/* 177 */       return this.size;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Neighborhood<T> firstElement() {
/* 183 */       return (Neighborhood<T>)cursor().next();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Object iterationOrder() {
/* 189 */       return new FlatIterationOrder((Interval)this);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Iterator<Neighborhood<T>> iterator() {
/* 195 */       return (Iterator<Neighborhood<T>>)cursor();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Cursor<Neighborhood<T>> localizingCursor() {
/* 201 */       return cursor();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static final class NeighborhoodsAccessible<T>
/*     */     extends AbstractEuclideanSpace
/*     */     implements RandomAccessible<Neighborhood<T>>
/*     */   {
/*     */     final RandomAccessible<T> source;
/*     */     
/*     */     final HorizontalLineNeighborhoodFactory<T> factory;
/*     */     
/*     */     private final long span;
/*     */     private final int dim;
/*     */     private final boolean skipCenter;
/*     */     
/*     */     public NeighborhoodsAccessible(RandomAccessible<T> source, long span, int dim, boolean skipCenter, HorizontalLineNeighborhoodFactory<T> factory) {
/* 219 */       super(source.numDimensions());
/* 220 */       this.source = source;
/* 221 */       this.span = span;
/* 222 */       this.dim = dim;
/* 223 */       this.skipCenter = skipCenter;
/* 224 */       this.factory = factory;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public RandomAccess<Neighborhood<T>> randomAccess() {
/* 230 */       return new HorizontalLineNeighborhoodRandomAccess<>(this.source, this.span, this.dim, this.skipCenter, this.factory);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public RandomAccess<Neighborhood<T>> randomAccess(Interval interval) {
/* 236 */       return randomAccess();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public int numDimensions() {
/* 242 */       return this.source.numDimensions();
/*     */     }
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/imglib2-algorithm-0.6.2.jar!/net/imglib2/algorithm/neighborhood/HorizontalLineShape.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */