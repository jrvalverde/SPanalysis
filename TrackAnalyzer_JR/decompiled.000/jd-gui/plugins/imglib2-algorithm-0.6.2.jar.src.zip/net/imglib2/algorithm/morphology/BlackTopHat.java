/*     */ package net.imglib2.algorithm.morphology;
/*     */ 
/*     */ import java.util.List;
/*     */ import net.imglib2.Dimensions;
/*     */ import net.imglib2.Interval;
/*     */ import net.imglib2.IterableInterval;
/*     */ import net.imglib2.RandomAccessible;
/*     */ import net.imglib2.RandomAccessibleInterval;
/*     */ import net.imglib2.algorithm.neighborhood.Shape;
/*     */ import net.imglib2.img.Img;
/*     */ import net.imglib2.img.ImgFactory;
/*     */ import net.imglib2.type.Type;
/*     */ import net.imglib2.type.numeric.RealType;
/*     */ import net.imglib2.type.operators.Sub;
/*     */ import net.imglib2.view.IntervalView;
/*     */ import net.imglib2.view.Views;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BlackTopHat
/*     */ {
/*     */   public static <T extends RealType<T>> Img<T> blackTopHat(Img<T> source, List<Shape> strels, int numThreads) {
/*  93 */     Img<T> closed = Closing.close(source, strels, numThreads);
/*  94 */     MorphologyUtils.subAAB((RandomAccessible)closed, (IterableInterval)source, numThreads);
/*  95 */     return closed;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends Type<T> & Comparable<T> & Sub<T>> Img<T> blackTopHat(Img<T> source, List<Shape> strels, T minVal, T maxVal, int numThreads) {
/* 144 */     Img<T> closed = (Img)Closing.close(source, strels, (Type)minVal, (Type)maxVal, numThreads);
/* 145 */     MorphologyUtils.subAAB((RandomAccessible<Sub>)closed, (IterableInterval<Sub>)source, numThreads);
/* 146 */     return closed;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends RealType<T>> Img<T> blackTopHat(Img<T> source, Shape strel, int numThreads) {
/* 175 */     Img<T> closed = Closing.close(source, strel, numThreads);
/* 176 */     MorphologyUtils.subAAB((RandomAccessible)closed, (IterableInterval)source, numThreads);
/* 177 */     return closed;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends Type<T> & Comparable<T> & Sub<T>> Img<T> blackTopHat(Img<T> source, Shape strel, T minVal, T maxVal, int numThreads) {
/* 221 */     Img<T> closed = (Img)Closing.close(source, strel, (Type)minVal, (Type)maxVal, numThreads);
/* 222 */     MorphologyUtils.subAAB((RandomAccessible<Sub>)closed, (IterableInterval<Sub>)source, numThreads);
/* 223 */     return closed;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends RealType<T>> void blackTopHat(RandomAccessible<T> source, IterableInterval<T> target, List<Shape> strels, int numThreads) {
/* 267 */     Closing.close(source, target, strels, numThreads);
/* 268 */     MorphologyUtils.subAAB2((IterableInterval)target, (RandomAccessible)source, numThreads);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends Type<T> & Comparable<T> & Sub<T>> void blackTopHat(RandomAccessible<T> source, IterableInterval<T> target, List<Shape> strels, T minVal, T maxVal, int numThreads) {
/* 328 */     Closing.close(source, target, strels, (Type)minVal, (Type)maxVal, numThreads);
/* 329 */     MorphologyUtils.subAAB2(target, source, numThreads);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends RealType<T>> void blackTopHat(RandomAccessible<T> source, IterableInterval<T> target, Shape strel, int numThreads) {
/* 367 */     Closing.close(source, target, strel, numThreads);
/* 368 */     MorphologyUtils.subAAB2((IterableInterval)target, (RandomAccessible)source, numThreads);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends Type<T> & Comparable<T> & Sub<T>> void blackTopHat(RandomAccessible<T> source, IterableInterval<T> target, Shape strel, T minVal, T maxVal, int numThreads) {
/* 422 */     Closing.close(source, target, strel, (Type)minVal, (Type)maxVal, numThreads);
/* 423 */     MorphologyUtils.subAAB2(target, source, numThreads);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends RealType<T>> void blackTopHatInPlace(RandomAccessible<T> source, Interval interval, List<Shape> strels, int numThreads) {
/* 463 */     RealType realType = MorphologyUtils.<RealType>createVariable(source, interval);
/* 464 */     ImgFactory<T> factory = MorphologyUtils.getSuitableFactory((Dimensions)interval, (T)realType);
/* 465 */     Img<T> img = factory.create((Dimensions)interval, realType);
/* 466 */     long[] min = new long[interval.numDimensions()];
/* 467 */     interval.min(min);
/* 468 */     IntervalView<T> translated = Views.translate((RandomAccessibleInterval)img, min);
/*     */     
/* 470 */     Closing.close(source, (IterableInterval<T>)translated, strels, numThreads);
/* 471 */     MorphologyUtils.subABA((RandomAccessible)source, (IterableInterval)translated, numThreads);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends Type<T> & Comparable<T> & Sub<T>> void blackTopHatInPlace(RandomAccessible<T> source, Interval interval, List<Shape> strels, T minVal, T maxVal, int numThreads) {
/* 526 */     ImgFactory<T> factory = MorphologyUtils.getSuitableFactory((Dimensions)interval, minVal);
/* 527 */     Img<T> img = factory.create((Dimensions)interval, minVal);
/* 528 */     long[] min = new long[interval.numDimensions()];
/* 529 */     interval.min(min);
/* 530 */     IntervalView<T> translated = Views.translate((RandomAccessibleInterval)img, min);
/*     */     
/* 532 */     Closing.close(source, (IterableInterval<Type>)translated, strels, (Type)minVal, (Type)maxVal, numThreads);
/* 533 */     MorphologyUtils.subABA(source, (IterableInterval<Sub>)translated, numThreads);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends RealType<T>> void blackTopHatInPlace(RandomAccessible<T> source, Interval interval, Shape strel, int numThreads) {
/* 568 */     RealType realType = MorphologyUtils.<RealType>createVariable(source, interval);
/* 569 */     ImgFactory<T> factory = MorphologyUtils.getSuitableFactory((Dimensions)interval, (T)realType);
/* 570 */     Img<T> img = factory.create((Dimensions)interval, realType);
/* 571 */     long[] min = new long[interval.numDimensions()];
/* 572 */     interval.min(min);
/* 573 */     IntervalView<T> translated = Views.translate((RandomAccessibleInterval)img, min);
/*     */     
/* 575 */     Closing.close(source, (IterableInterval<T>)translated, strel, numThreads);
/* 576 */     MorphologyUtils.subABA((RandomAccessible)source, (IterableInterval)translated, numThreads);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends Type<T> & Comparable<T> & Sub<T>> void blackTopHatInPlace(RandomAccessible<T> source, Interval interval, Shape strel, T minVal, T maxVal, int numThreads) {
/* 626 */     ImgFactory<T> factory = MorphologyUtils.getSuitableFactory((Dimensions)interval, minVal);
/* 627 */     Img<T> img = factory.create((Dimensions)interval, minVal);
/* 628 */     long[] min = new long[interval.numDimensions()];
/* 629 */     interval.min(min);
/* 630 */     IntervalView<T> translated = Views.translate((RandomAccessibleInterval)img, min);
/*     */     
/* 632 */     Closing.close(source, (IterableInterval<Type>)translated, strel, (Type)minVal, (Type)maxVal, numThreads);
/* 633 */     MorphologyUtils.subABA(source, (IterableInterval<Sub>)translated, numThreads);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/imglib2-algorithm-0.6.2.jar!/net/imglib2/algorithm/morphology/BlackTopHat.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */