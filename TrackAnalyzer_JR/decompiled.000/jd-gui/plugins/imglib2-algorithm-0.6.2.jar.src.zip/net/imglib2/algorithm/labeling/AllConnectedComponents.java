/*     */ package net.imglib2.algorithm.labeling;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.NoSuchElementException;
/*     */ import net.imglib2.Cursor;
/*     */ import net.imglib2.RandomAccess;
/*     */ import net.imglib2.RandomAccessibleInterval;
/*     */ import net.imglib2.labeling.Labeling;
/*     */ import net.imglib2.labeling.LabelingOutOfBoundsRandomAccessFactory;
/*     */ import net.imglib2.labeling.LabelingType;
/*     */ import net.imglib2.outofbounds.OutOfBounds;
/*     */ import net.imglib2.type.logic.BitType;
/*     */ import net.imglib2.view.Views;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public class AllConnectedComponents
/*     */ {
/*     */   protected static class PositionStack
/*     */   {
/*     */     private final int dimensions;
/*     */     private long[] storage;
/*  67 */     private int position = 0;
/*     */ 
/*     */     
/*     */     public PositionStack(int dimensions) {
/*  71 */       this.dimensions = dimensions;
/*  72 */       this.storage = new long[100 * dimensions];
/*     */     }
/*     */ 
/*     */     
/*     */     public void push(long[] position) {
/*  77 */       int insertPoint = this.position * this.dimensions;
/*  78 */       if (this.storage.length == insertPoint) {
/*     */         
/*  80 */         long[] newStorage = new long[this.position * 3 / 2 * this.dimensions];
/*  81 */         System.arraycopy(this.storage, 0, newStorage, 0, this.storage.length);
/*  82 */         this.storage = newStorage;
/*     */       } 
/*  84 */       System.arraycopy(position, 0, this.storage, insertPoint, this.dimensions);
/*  85 */       this.position++;
/*     */     }
/*     */ 
/*     */     
/*     */     public void pop(long[] position) {
/*  90 */       this.position--;
/*  91 */       System.arraycopy(this.storage, this.position * this.dimensions, position, 0, this.dimensions);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isEmpty() {
/*  96 */       return (this.position == 0);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends Comparable<T>> void labelAllConnectedComponents(Labeling<T> labeling, RandomAccessibleInterval<BitType> img, Iterator<T> names) throws NoSuchElementException {
/* 118 */     long[][] offsets = getStructuringElement(img.numDimensions());
/* 119 */     labelAllConnectedComponents(labeling, img, names, offsets);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends Comparable<T>> void labelAllConnectedComponents(Labeling<T> labeling, RandomAccessibleInterval<BitType> img, Iterator<T> names, long[][] structuringElement) throws NoSuchElementException {
/* 143 */     Cursor<BitType> c = Views.iterable(img).localizingCursor();
/* 144 */     RandomAccess<BitType> raSrc = img.randomAccess();
/* 145 */     LabelingOutOfBoundsRandomAccessFactory labelingOutOfBoundsRandomAccessFactory = new LabelingOutOfBoundsRandomAccessFactory();
/* 146 */     OutOfBounds<LabelingType<T>> raDest = labelingOutOfBoundsRandomAccessFactory.create(labeling);
/* 147 */     long[] srcPosition = new long[img.numDimensions()];
/* 148 */     long[] destPosition = new long[labeling.numDimensions()];
/* 149 */     long[] dimensions = new long[labeling.numDimensions()];
/* 150 */     labeling.dimensions(dimensions);
/* 151 */     PositionStack toDoList = new PositionStack(img.numDimensions());
/* 152 */     while (c.hasNext()) {
/*     */       
/* 154 */       BitType t = (BitType)c.next();
/* 155 */       if (t.get()) {
/*     */         
/* 157 */         c.localize(srcPosition);
/* 158 */         boolean outOfBounds = false;
/* 159 */         for (int i = 0; i < dimensions.length; i++) {
/*     */           
/* 161 */           if (srcPosition[i] >= dimensions[i]) {
/*     */             
/* 163 */             outOfBounds = true;
/*     */             break;
/*     */           } 
/*     */         } 
/* 167 */         if (outOfBounds) {
/*     */           continue;
/*     */         }
/* 170 */         raDest.setPosition(srcPosition);
/*     */ 
/*     */ 
/*     */         
/* 174 */         LabelingType<T> label = (LabelingType<T>)raDest.get();
/* 175 */         if (label.getLabeling().isEmpty()) {
/*     */           
/* 177 */           List<T> currentLabel = label.intern((Comparable)names.next());
/* 178 */           label.setLabeling(currentLabel);
/* 179 */           toDoList.push(srcPosition);
/* 180 */           while (!toDoList.isEmpty()) {
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 185 */             toDoList.pop(srcPosition);
/* 186 */             for (long[] offset : structuringElement) {
/*     */               
/* 188 */               outOfBounds = false;
/* 189 */               for (int j = 0; j < offset.length; j++) {
/*     */                 
/* 191 */                 destPosition[j] = srcPosition[j] + offset[j];
/* 192 */                 if (destPosition[j] < 0L || destPosition[j] >= dimensions[j]) {
/*     */                   
/* 194 */                   outOfBounds = true;
/*     */                   break;
/*     */                 } 
/*     */               } 
/* 198 */               if (!outOfBounds) {
/*     */                 
/* 200 */                 raSrc.setPosition(destPosition);
/* 201 */                 if (((BitType)raSrc.get()).get()) {
/*     */                   
/* 203 */                   raDest.setPosition(destPosition);
/* 204 */                   label = (LabelingType<T>)raDest.get();
/* 205 */                   if (label.getLabeling().isEmpty()) {
/*     */                     
/* 207 */                     label.setLabeling(currentLabel);
/* 208 */                     toDoList.push(destPosition);
/*     */                   } 
/*     */                 } 
/*     */               } 
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static long[][] getStructuringElement(int dimensions) {
/* 228 */     int nElements = 1;
/* 229 */     for (int i = 0; i < dimensions; i++)
/* 230 */       nElements *= 3; 
/* 231 */     nElements--;
/* 232 */     long[][] result = new long[nElements][dimensions];
/* 233 */     long[] position = new long[dimensions];
/* 234 */     Arrays.fill(position, -1L);
/* 235 */     for (int j = 0; j < nElements; j++) {
/*     */       
/* 237 */       System.arraycopy(position, 0, result[j], 0, dimensions);
/*     */ 
/*     */ 
/*     */       
/* 241 */       if (j == nElements / 2 - 1) {
/*     */         
/* 243 */         position[0] = position[0] + 2L;
/*     */       }
/*     */       else {
/*     */         
/* 247 */         for (int k = 0; k < dimensions; k++) {
/*     */           
/* 249 */           if (position[k] == 1L) {
/*     */             
/* 251 */             position[k] = -1L;
/*     */           }
/*     */           else {
/*     */             
/* 255 */             position[k] = position[k] + 1L;
/*     */             break;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/* 261 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Iterator<Integer> getIntegerNames(final int start) {
/* 273 */     return new Iterator<Integer>()
/*     */       {
/* 275 */         int current = start;
/*     */ 
/*     */ 
/*     */         
/*     */         public boolean hasNext() {
/* 280 */           return true;
/*     */         }
/*     */ 
/*     */ 
/*     */         
/*     */         public Integer next() {
/* 286 */           return Integer.valueOf(this.current++);
/*     */         }
/*     */         
/*     */         public void remove() {}
/*     */       };
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/imglib2-algorithm-0.6.2.jar!/net/imglib2/algorithm/labeling/AllConnectedComponents.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */