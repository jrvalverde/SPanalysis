/*     */ package net.imglib2.algorithm.neighborhood;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import net.imglib2.AbstractEuclideanSpace;
/*     */ import net.imglib2.AbstractLocalizable;
/*     */ import net.imglib2.Cursor;
/*     */ import net.imglib2.Interval;
/*     */ import net.imglib2.Positionable;
/*     */ import net.imglib2.RandomAccess;
/*     */ import net.imglib2.RealCursor;
/*     */ import net.imglib2.RealPositionable;
/*     */ import net.imglib2.Sampler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RectangleNeighborhood<T>
/*     */   extends AbstractLocalizable
/*     */   implements Neighborhood<T>
/*     */ {
/*     */   private final long[] currentMin;
/*     */   private final long[] currentMax;
/*     */   private final long[] dimensions;
/*     */   private final RandomAccess<T> sourceRandomAccess;
/*     */   private final Interval structuringElementBoundingBox;
/*     */   private final long maxIndex;
/*     */   
/*     */   public static <T> RectangleNeighborhoodFactory<T> factory() {
/*  51 */     return new RectangleNeighborhoodFactory<T>()
/*     */       {
/*     */         
/*     */         public Neighborhood<T> create(long[] position, long[] currentMin, long[] currentMax, Interval span, RandomAccess<T> sourceRandomAccess)
/*     */         {
/*  56 */           return new RectangleNeighborhood<>(position, currentMin, currentMax, span, sourceRandomAccess);
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   RectangleNeighborhood(long[] position, long[] currentMin, long[] currentMax, Interval span, RandomAccess<T> sourceRandomAccess) {
/*  75 */     super(position);
/*  76 */     this.currentMin = currentMin;
/*  77 */     this.currentMax = currentMax;
/*  78 */     this.dimensions = new long[this.n];
/*  79 */     span.dimensions(this.dimensions);
/*     */     
/*  81 */     long mi = this.dimensions[0];
/*  82 */     for (int d = 1; d < this.n; d++)
/*  83 */       mi *= this.dimensions[d]; 
/*  84 */     this.maxIndex = mi;
/*     */     
/*  86 */     this.sourceRandomAccess = sourceRandomAccess;
/*  87 */     this.structuringElementBoundingBox = span;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Interval getStructuringElementBoundingBox() {
/*  93 */     return this.structuringElementBoundingBox;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RandomAccess<T> getSourceRandomAccess() {
/* 101 */     return this.sourceRandomAccess;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public long size() {
/* 107 */     return this.maxIndex;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public T firstElement() {
/* 113 */     return cursor().next();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object iterationOrder() {
/* 119 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public double realMin(int d) {
/* 125 */     return this.currentMin[d];
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void realMin(double[] min) {
/* 131 */     for (int d = 0; d < this.n; d++) {
/* 132 */       min[d] = this.currentMin[d];
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void realMin(RealPositionable min) {
/* 138 */     for (int d = 0; d < this.n; d++) {
/* 139 */       min.setPosition(this.currentMin[d], d);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public double realMax(int d) {
/* 145 */     return this.currentMax[d];
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void realMax(double[] max) {
/* 151 */     for (int d = 0; d < this.n; d++) {
/* 152 */       max[d] = this.currentMax[d];
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void realMax(RealPositionable max) {
/* 158 */     for (int d = 0; d < this.n; d++) {
/* 159 */       max.setPosition(this.currentMax[d], d);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public Iterator<T> iterator() {
/* 165 */     return (Iterator<T>)cursor();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public long min(int d) {
/* 171 */     return this.currentMin[d];
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void min(long[] min) {
/* 177 */     for (int d = 0; d < this.n; d++) {
/* 178 */       min[d] = this.currentMin[d];
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void min(Positionable min) {
/* 184 */     for (int d = 0; d < this.n; d++) {
/* 185 */       min.setPosition(this.currentMin[d], d);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public long max(int d) {
/* 191 */     return this.currentMax[d];
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void max(long[] max) {
/* 197 */     for (int d = 0; d < this.n; d++) {
/* 198 */       max[d] = this.currentMax[d];
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void max(Positionable max) {
/* 204 */     for (int d = 0; d < this.n; d++) {
/* 205 */       max.setPosition(this.currentMax[d], d);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void dimensions(long[] dimensions) {
/* 211 */     for (int d = 0; d < this.n; d++) {
/* 212 */       dimensions[d] = this.dimensions[d];
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public long dimension(int d) {
/* 218 */     return this.dimensions[d];
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public LocalCursor cursor() {
/* 224 */     return new LocalCursor(this.sourceRandomAccess.copyRandomAccess());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public LocalCursor localizingCursor() {
/* 230 */     return cursor();
/*     */   }
/*     */ 
/*     */   
/*     */   public final class LocalCursor
/*     */     extends AbstractEuclideanSpace
/*     */     implements Cursor<T>
/*     */   {
/*     */     private final RandomAccess<T> source;
/*     */     private long index;
/*     */     private long maxIndexOnLine;
/*     */     
/*     */     public LocalCursor(RandomAccess<T> source) {
/* 243 */       super(source.numDimensions());
/* 244 */       this.source = source;
/* 245 */       reset();
/*     */     }
/*     */ 
/*     */     
/*     */     protected LocalCursor(LocalCursor c) {
/* 250 */       super(c.numDimensions());
/* 251 */       this.source = c.source.copyRandomAccess();
/* 252 */       this.index = c.index;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public T get() {
/* 258 */       return (T)this.source.get();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void fwd() {
/* 264 */       this.source.fwd(0);
/* 265 */       if (++this.index > this.maxIndexOnLine) {
/* 266 */         nextLine();
/*     */       }
/*     */     }
/*     */     
/*     */     private void nextLine() {
/* 271 */       this.source.setPosition(RectangleNeighborhood.this.currentMin[0], 0);
/* 272 */       this.maxIndexOnLine += RectangleNeighborhood.this.dimensions[0];
/* 273 */       for (int d = 1; d < this.n; ) {
/*     */         
/* 275 */         this.source.fwd(d);
/* 276 */         if (this.source.getLongPosition(d) > RectangleNeighborhood.this.currentMax[d]) {
/* 277 */           this.source.setPosition(RectangleNeighborhood.this.currentMin[d], d);
/*     */           d++;
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void jumpFwd(long steps) {
/* 286 */       for (long i = 0L; i < steps; i++) {
/* 287 */         fwd();
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public T next() {
/* 293 */       fwd();
/* 294 */       return get();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void remove() {}
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void reset() {
/* 306 */       this.source.setPosition(RectangleNeighborhood.this.currentMin);
/* 307 */       this.source.bck(0);
/* 308 */       this.index = 0L;
/* 309 */       this.maxIndexOnLine = RectangleNeighborhood.this.dimensions[0];
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean hasNext() {
/* 315 */       return (this.index < RectangleNeighborhood.this.maxIndex);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public float getFloatPosition(int d) {
/* 321 */       return this.source.getFloatPosition(d);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public double getDoublePosition(int d) {
/* 327 */       return this.source.getDoublePosition(d);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public int getIntPosition(int d) {
/* 333 */       return this.source.getIntPosition(d);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public long getLongPosition(int d) {
/* 339 */       return this.source.getLongPosition(d);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void localize(long[] position) {
/* 345 */       this.source.localize(position);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void localize(float[] position) {
/* 351 */       this.source.localize(position);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void localize(double[] position) {
/* 357 */       this.source.localize(position);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void localize(int[] position) {
/* 363 */       this.source.localize(position);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public LocalCursor copy() {
/* 369 */       return new LocalCursor(this);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public LocalCursor copyCursor() {
/* 375 */       return copy();
/*     */     }
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/imglib2-algorithm-0.6.2.jar!/net/imglib2/algorithm/neighborhood/RectangleNeighborhood.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */