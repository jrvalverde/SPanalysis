/*    */ package net.imglib2.algorithm.function;
/*    */ 
/*    */ import net.imglib2.converter.Converter;
/*    */ import net.imglib2.type.numeric.RealType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NormMinMax<A extends RealType<A>>
/*    */   implements Converter<A, A>
/*    */ {
/*    */   final double min;
/*    */   final double tmp;
/*    */   
/*    */   public NormMinMax(double min, double max) {
/* 51 */     this.min = min;
/* 52 */     this.tmp = max - min;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void convert(A input, A output) {
/* 58 */     output.setReal((input.getRealDouble() - this.min) / this.tmp);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/imglib2-algorithm-0.6.2.jar!/net/imglib2/algorithm/function/NormMinMax.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */