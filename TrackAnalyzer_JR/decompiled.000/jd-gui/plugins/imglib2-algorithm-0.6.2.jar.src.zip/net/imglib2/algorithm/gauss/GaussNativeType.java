/*     */ package net.imglib2.algorithm.gauss;
/*     */ 
/*     */ import net.imglib2.Dimensions;
/*     */ import net.imglib2.Interval;
/*     */ import net.imglib2.Localizable;
/*     */ import net.imglib2.Point;
/*     */ import net.imglib2.RandomAccessible;
/*     */ import net.imglib2.RandomAccessibleInterval;
/*     */ import net.imglib2.img.Img;
/*     */ import net.imglib2.img.ImgFactory;
/*     */ import net.imglib2.img.array.ArrayImg;
/*     */ import net.imglib2.img.array.ArrayImgFactory;
/*     */ import net.imglib2.img.array.ArrayRandomAccess;
/*     */ import net.imglib2.img.cell.CellImg;
/*     */ import net.imglib2.img.cell.CellImgFactory;
/*     */ import net.imglib2.outofbounds.OutOfBoundsFactory;
/*     */ import net.imglib2.outofbounds.OutOfBoundsMirrorFactory;
/*     */ import net.imglib2.type.NativeType;
/*     */ import net.imglib2.type.Type;
/*     */ import net.imglib2.type.numeric.NumericType;
/*     */ import net.imglib2.view.Views;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public class GaussNativeType<T extends NumericType<T> & NativeType<T>>
/*     */   extends AbstractGauss<T>
/*     */ {
/*     */   protected boolean isArray;
/*     */   
/*     */   public GaussNativeType(double[] sigma, RandomAccessible<T> input, Interval interval, ImgFactory<T> factory, T type) {
/*  83 */     super(sigma, input, interval, (RandomAccessible<T>)factory.create((Dimensions)interval, type), (Localizable)new Point(sigma.length), factory, type);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GaussNativeType(double[] sigma, RandomAccessible<T> input, Interval interval, RandomAccessible<T> output, Localizable outputOffset, ImgFactory<T> factory, T type) {
/* 108 */     super(sigma, input, interval, output, outputOffset, factory, type);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GaussNativeType(double[] sigma, Img<T> input) {
/* 123 */     this(sigma, (RandomAccessible<T>)Views.extend((RandomAccessibleInterval)input, (OutOfBoundsFactory)new OutOfBoundsMirrorFactory(OutOfBoundsMirrorFactory.Boundary.SINGLE)), (Interval)input, input.factory(), (T)((NumericType)input.firstElement()).createVariable());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GaussNativeType(double[] sigma, Img<T> input, OutOfBoundsFactory<T, Img<T>> outOfBounds) {
/* 138 */     this(sigma, (RandomAccessible<T>)Views.extend((RandomAccessibleInterval)input, outOfBounds), (Interval)input, input.factory(), (T)((NumericType)input.firstElement()).createVariable());
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean isArray() {
/* 143 */     return this.isArray;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Img<T> getProcessingLine(long sizeProcessLine) {
/*     */     CellImg cellImg;
/* 152 */     if (sizeProcessLine <= 2147483647L) {
/*     */       
/* 154 */       this.isArray = true;
/* 155 */       ArrayImg arrayImg = (new ArrayImgFactory()).create(new long[] { sizeProcessLine }, (NativeType)getProcessingType());
/*     */     }
/*     */     else {
/*     */       
/* 159 */       this.isArray = false;
/* 160 */       cellImg = (new CellImgFactory(134217727)).create(new long[] { sizeProcessLine }, (NativeType)getProcessingType());
/*     */     } 
/*     */     
/* 163 */     return (Img<T>)cellImg;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void processLine(SamplingLineIterator<T> input, double[] kernel) {
/* 180 */     if (!isArray()) {
/*     */       
/* 182 */       super.processLine(input, kernel);
/*     */       
/*     */       return;
/*     */     } 
/* 186 */     int kernelSize = kernel.length;
/* 187 */     int kernelSizeMinus1 = kernelSize - 1;
/* 188 */     int kernelSizeHalf = kernelSize / 2;
/* 189 */     int kernelSizeHalfMinus1 = kernelSizeHalf - 1;
/*     */     
/* 191 */     ArrayRandomAccess<T> randomAccessLeft = (ArrayRandomAccess<T>)input.randomAccessLeft;
/* 192 */     ArrayRandomAccess<T> randomAccessRight = (ArrayRandomAccess<T>)input.randomAccessRight;
/* 193 */     NumericType numericType1 = (NumericType)input.copy;
/* 194 */     NumericType numericType2 = (NumericType)input.tmp;
/*     */     
/* 196 */     long imgSize = input.getProcessLine().size();
/*     */     
/* 198 */     if (imgSize >= kernelSize) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 208 */       numericType1.set((Type)input.get());
/*     */ 
/*     */ 
/*     */       
/* 212 */       randomAccessLeft.setPositionDim0(0);
/*     */ 
/*     */       
/* 215 */       numericType1.mul(kernel[0]);
/* 216 */       ((NumericType)randomAccessLeft.get()).add(numericType1);
/*     */       
/* 218 */       for (int i = 1; i < kernelSizeMinus1; i++) {
/*     */         
/* 220 */         input.fwd();
/*     */ 
/*     */ 
/*     */         
/* 224 */         numericType1.set((Type)input.get());
/*     */ 
/*     */ 
/*     */         
/* 228 */         randomAccessLeft.setPositionDim0(-1);
/*     */ 
/*     */         
/* 231 */         for (int o = 0; o <= i; o++) {
/*     */           
/* 233 */           randomAccessLeft.fwdDim0();
/*     */           
/* 235 */           numericType2.set((Type)numericType1);
/* 236 */           numericType2.mul(kernel[i - o]);
/*     */           
/* 238 */           ((NumericType)randomAccessLeft.get()).add(numericType2);
/*     */         } 
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 244 */       long length = imgSize - kernelSizeMinus1; long n;
/* 245 */       for (n = 0L; n < length; n++) {
/*     */         
/* 247 */         input.fwd();
/*     */ 
/*     */ 
/*     */         
/* 251 */         numericType1.set((Type)input.get());
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 256 */         randomAccessLeft.setPositionDim0(n);
/* 257 */         randomAccessRight.setPositionDim0(n + kernelSizeMinus1);
/*     */ 
/*     */         
/* 260 */         for (int k = 0; k < kernelSizeHalfMinus1; k++) {
/*     */           
/* 262 */           numericType2.set((Type)numericType1);
/* 263 */           numericType2.mul(kernel[k]);
/*     */           
/* 265 */           ((NumericType)randomAccessLeft.get()).add(numericType2);
/* 266 */           ((NumericType)randomAccessRight.get()).add(numericType2);
/*     */           
/* 268 */           randomAccessLeft.fwdDim0();
/* 269 */           randomAccessRight.bckDim0();
/*     */         } 
/*     */ 
/*     */ 
/*     */         
/* 274 */         numericType2.set((Type)numericType1);
/* 275 */         numericType2.mul(kernel[kernelSizeHalfMinus1]);
/*     */         
/* 277 */         ((NumericType)randomAccessLeft.get()).add(numericType2);
/* 278 */         ((NumericType)randomAccessRight.get()).add(numericType2);
/*     */         
/* 280 */         randomAccessLeft.fwdDim0();
/*     */ 
/*     */         
/* 283 */         numericType2.set((Type)numericType1);
/* 284 */         numericType2.mul(kernel[kernelSizeHalf]);
/*     */         
/* 286 */         ((NumericType)randomAccessLeft.get()).add(numericType2);
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 291 */       long endLength = imgSize + kernelSizeMinus1; long l1;
/* 292 */       for (l1 = imgSize; l1 < endLength; l1++)
/*     */       {
/*     */ 
/*     */         
/* 296 */         input.fwd();
/*     */ 
/*     */ 
/*     */         
/* 300 */         numericType1.set((Type)input.get());
/*     */ 
/*     */ 
/*     */         
/* 304 */         randomAccessLeft.setPositionDim0(l1 - kernelSize);
/*     */ 
/*     */         
/* 307 */         int k = 0; long o;
/* 308 */         for (o = l1 - kernelSize + 1L; o < imgSize; o++)
/*     */         {
/* 310 */           randomAccessLeft.fwdDim0();
/*     */           
/* 312 */           numericType2.set((Type)numericType1);
/* 313 */           numericType2.mul(kernel[k++]);
/*     */           
/* 315 */           ((NumericType)randomAccessLeft.get()).add(numericType2);
/*     */ 
/*     */         
/*     */         }
/*     */ 
/*     */ 
/*     */       
/*     */       }
/*     */ 
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */       
/* 329 */       numericType1.set((Type)input.get());
/*     */ 
/*     */ 
/*     */       
/* 333 */       randomAccessLeft.setPositionDim0(0);
/*     */ 
/*     */       
/* 336 */       numericType1.mul(kernel[0]);
/* 337 */       ((NumericType)randomAccessLeft.get()).add(numericType1);
/*     */       
/* 339 */       for (int j = 1; j < imgSize; j++) {
/*     */         
/* 341 */         input.fwd();
/*     */ 
/*     */ 
/*     */         
/* 345 */         numericType1.set((Type)input.get());
/*     */ 
/*     */ 
/*     */         
/* 349 */         randomAccessLeft.setPositionDim0(-1);
/*     */ 
/*     */         
/* 352 */         for (int o = 0; o <= j; o++) {
/*     */           
/* 354 */           randomAccessLeft.fwdDim0();
/*     */           
/* 356 */           numericType2.set((Type)numericType1);
/* 357 */           numericType2.mul(kernel[j - o]);
/*     */           
/* 359 */           ((NumericType)randomAccessLeft.get()).add(numericType2);
/*     */         } 
/*     */       } 
/*     */       
/*     */       long i;
/*     */       
/* 365 */       for (i = imgSize; i < imgSize + kernelSizeMinus1; i++) {
/*     */ 
/*     */ 
/*     */         
/* 369 */         input.fwd();
/*     */ 
/*     */ 
/*     */         
/* 373 */         numericType1.set((Type)input.get());
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 378 */         long o = i - kernelSize + 1L;
/* 379 */         int k = 0;
/*     */         
/* 381 */         if (o < 0L) {
/*     */           
/* 383 */           k = -((int)o);
/* 384 */           o = 0L;
/*     */         } 
/*     */         
/* 387 */         randomAccessLeft.setPositionDim0(o - 1L);
/*     */ 
/*     */         
/* 390 */         for (; o < imgSize; o++) {
/*     */           
/* 392 */           randomAccessLeft.fwdDim0();
/*     */           
/* 394 */           numericType2.set((Type)numericType1);
/* 395 */           numericType2.mul(kernel[k++]);
/*     */           
/* 397 */           ((NumericType)randomAccessLeft.get()).add(numericType2);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/imglib2-algorithm-0.6.2.jar!/net/imglib2/algorithm/gauss/GaussNativeType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */