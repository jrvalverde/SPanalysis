/*     */ package net.imglib2.algorithm.gauss3;
/*     */ 
/*     */ import java.lang.reflect.Array;
/*     */ import net.imglib2.RandomAccess;
/*     */ import net.imglib2.type.Type;
/*     */ import net.imglib2.type.numeric.NumericType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConvolverNumericType<T extends NumericType<T>>
/*     */   implements Runnable
/*     */ {
/*     */   private final double[] kernel;
/*     */   private final RandomAccess<T> in;
/*     */   private final RandomAccess<T> out;
/*     */   private final int d;
/*     */   private final int k;
/*     */   private final int k1;
/*     */   private final int k1k1;
/*     */   private final long linelen;
/*     */   final T[] buf;
/*     */   final T tmp;
/*     */   
/*     */   public static <T extends NumericType<T>> ConvolverNumericTypeFactory<T> factory(T type) {
/*  60 */     return new ConvolverNumericTypeFactory<>(type);
/*     */   }
/*     */   
/*     */   public static final class ConvolverNumericTypeFactory<T extends NumericType<T>>
/*     */     implements ConvolverFactory<T, T>
/*     */   {
/*     */     private final T type;
/*     */     
/*     */     public ConvolverNumericTypeFactory(T type) {
/*  69 */       this.type = type;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Runnable create(double[] halfkernel, RandomAccess<T> in, RandomAccess<T> out, int d, long lineLength) {
/*  75 */       return new ConvolverNumericType<>(halfkernel, in, out, d, lineLength, (NumericType)this.type);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ConvolverNumericType(double[] kernel, RandomAccess<T> in, RandomAccess<T> out, int d, long lineLength, T type) {
/* 102 */     this.kernel = kernel;
/* 103 */     this.in = in;
/* 104 */     this.out = out;
/* 105 */     this.d = d;
/*     */     
/* 107 */     this.k = kernel.length;
/* 108 */     this.k1 = this.k - 1;
/* 109 */     this.k1k1 = this.k1 + this.k1;
/* 110 */     this.linelen = lineLength;
/*     */     
/* 112 */     int buflen = 2 * this.k - 1;
/* 113 */     this.buf = (T[])Array.newInstance(type.getClass(), buflen);
/* 114 */     for (int i = 0; i < buflen; i++) {
/* 115 */       this.buf[i] = (T)type.createVariable();
/*     */     }
/* 117 */     this.tmp = (T)type.createVariable();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void next() {
/* 123 */     T first = this.buf[0];
/* 124 */     for (int i = 0; i < this.k1k1; i++)
/* 125 */       this.buf[i] = this.buf[i + 1]; 
/* 126 */     this.buf[this.k1k1] = first;
/*     */ 
/*     */     
/* 129 */     NumericType numericType = (NumericType)this.in.get();
/*     */ 
/*     */     
/* 132 */     this.tmp.set((Type)numericType);
/* 133 */     this.tmp.mul(this.kernel[0]);
/* 134 */     this.buf[this.k1].add(this.tmp);
/*     */ 
/*     */     
/* 137 */     for (int j = 1; j < this.k1; j++) {
/*     */       
/* 139 */       this.tmp.set((Type)numericType);
/* 140 */       this.tmp.mul(this.kernel[j]);
/* 141 */       this.buf[this.k1 + j].add(this.tmp);
/* 142 */       this.buf[this.k1 - j].add(this.tmp);
/*     */     } 
/*     */ 
/*     */     
/* 146 */     this.tmp.set((Type)numericType);
/* 147 */     this.tmp.mul(this.kernel[this.k1]);
/* 148 */     this.buf[this.k1k1].set((Type)this.tmp);
/*     */     
/* 150 */     this.in.fwd(this.d);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void run() {
/* 156 */     for (int j = 0; j < this.k1k1; j++)
/* 157 */       next(); 
/* 158 */     for (long i = 0L; i < this.linelen; i++) {
/*     */       
/* 160 */       next();
/* 161 */       this.tmp.add(this.buf[0]);
/* 162 */       ((NumericType)this.out.get()).set((Type)this.tmp);
/* 163 */       this.out.fwd(this.d);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/imglib2-algorithm-0.6.2.jar!/net/imglib2/algorithm/gauss3/ConvolverNumericType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */