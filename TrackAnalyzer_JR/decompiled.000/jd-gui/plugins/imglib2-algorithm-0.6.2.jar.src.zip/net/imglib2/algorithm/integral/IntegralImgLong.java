/*    */ package net.imglib2.algorithm.integral;
/*    */ 
/*    */ import net.imglib2.RandomAccess;
/*    */ import net.imglib2.RandomAccessibleInterval;
/*    */ import net.imglib2.converter.Converter;
/*    */ import net.imglib2.type.numeric.NumericType;
/*    */ import net.imglib2.type.numeric.integer.GenericLongType;
/*    */ import net.imglib2.type.numeric.integer.LongType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IntegralImgLong<R extends NumericType<R>>
/*    */   extends IntegralImg<R, LongType>
/*    */ {
/*    */   public IntegralImgLong(RandomAccessibleInterval<R> img, LongType type, Converter<R, LongType> converter) {
/* 55 */     super(img, type, converter);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected void integrateLineDim0(Converter<R, LongType> converter, RandomAccess<R> cursorIn, RandomAccess<LongType> cursorOut, LongType sum, LongType tmpVar, long size) {
/* 62 */     converter.convert(cursorIn.get(), sum);
/* 63 */     ((LongType)cursorOut.get()).set((GenericLongType)sum);
/*    */     
/* 65 */     long sum2 = sum.get();
/*    */     
/* 67 */     for (int i = 2; i < size; i++) {
/*    */       
/* 69 */       cursorIn.fwd(0);
/* 70 */       cursorOut.fwd(0);
/*    */       
/* 72 */       converter.convert(cursorIn.get(), tmpVar);
/* 73 */       sum2 += tmpVar.get();
/* 74 */       ((LongType)cursorOut.get()).set(sum2);
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected void integrateLine(int d, RandomAccess<LongType> cursor, LongType sum, long size) {
/* 82 */     long sum2 = ((LongType)cursor.get()).get();
/*    */     
/* 84 */     for (int i = 2; i < size; i++) {
/*    */       
/* 86 */       cursor.fwd(d);
/*    */       
/* 88 */       sum2 += ((LongType)cursor.get()).get();
/* 89 */       ((LongType)cursor.get()).set(sum2);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/imglib2-algorithm-0.6.2.jar!/net/imglib2/algorithm/integral/IntegralImgLong.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */