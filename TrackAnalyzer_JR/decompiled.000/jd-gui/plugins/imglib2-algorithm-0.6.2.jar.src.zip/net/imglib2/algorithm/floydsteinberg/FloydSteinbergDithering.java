/*     */ package net.imglib2.algorithm.floydsteinberg;
/*     */ 
/*     */ import java.util.Random;
/*     */ import net.imglib2.Cursor;
/*     */ import net.imglib2.Dimensions;
/*     */ import net.imglib2.RandomAccess;
/*     */ import net.imglib2.RandomAccessibleInterval;
/*     */ import net.imglib2.algorithm.Benchmark;
/*     */ import net.imglib2.algorithm.OutputAlgorithm;
/*     */ import net.imglib2.img.Img;
/*     */ import net.imglib2.img.array.ArrayImg;
/*     */ import net.imglib2.img.array.ArrayImgFactory;
/*     */ import net.imglib2.type.NativeType;
/*     */ import net.imglib2.type.logic.BitType;
/*     */ import net.imglib2.type.numeric.RealType;
/*     */ import net.imglib2.type.numeric.real.FloatType;
/*     */ import net.imglib2.util.Intervals;
/*     */ import net.imglib2.util.Util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FloydSteinbergDithering<T extends RealType<T>>
/*     */   implements OutputAlgorithm<Img<BitType>>, Benchmark
/*     */ {
/*     */   Img<BitType> result;
/*     */   final RandomAccessibleInterval<T> img;
/*     */   final Img<FloatType> errorDiffusionKernel;
/*     */   final long[] dim;
/*     */   final long[] tmp1;
/*     */   final long[] tmp2;
/*     */   final float ditheringThreshold;
/*     */   long processingTime;
/*  71 */   String errorMessage = "";
/*     */ 
/*     */   
/*     */   public FloydSteinbergDithering(RandomAccessibleInterval<T> img, float ditheringThreshold) {
/*  75 */     this.img = img;
/*  76 */     this.dim = Intervals.dimensionsAsLongArray((Dimensions)img);
/*  77 */     this.tmp1 = new long[img.numDimensions()];
/*  78 */     this.tmp2 = new long[img.numDimensions()];
/*     */     
/*  80 */     this.errorDiffusionKernel = createErrorDiffusionKernel(img.numDimensions());
/*     */     
/*  82 */     this.ditheringThreshold = ditheringThreshold;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public FloydSteinbergDithering(RandomAccessibleInterval<T> img) {
/*  88 */     this(img, Float.NEGATIVE_INFINITY);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean process() {
/*  94 */     long startTime = System.currentTimeMillis();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 156 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public long getProcessingTime() {
/* 162 */     return this.processingTime;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Img<BitType> getResult() {
/* 168 */     return this.result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean checkInput() {
/* 174 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getErrorMessage() {
/* 180 */     return this.errorMessage;
/*     */   }
/*     */ 
/*     */   
/*     */   public Img<FloatType> createErrorDiffusionKernel(int numDimensions) {
/* 185 */     ArrayImgFactory<FloatType> factory = new ArrayImgFactory();
/*     */ 
/*     */     
/* 188 */     if (numDimensions == 2) {
/*     */       
/* 190 */       ArrayImg arrayImg1 = factory.create(new long[] { 3L, 3L }, (NativeType)new FloatType());
/*     */       
/* 192 */       RandomAccess<FloatType> randomAccess = arrayImg1.randomAccess();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 200 */       randomAccess.setPosition(2, 0);
/* 201 */       randomAccess.setPosition(1, 1);
/* 202 */       ((FloatType)randomAccess.get()).setReal(0.4375F);
/*     */       
/* 204 */       randomAccess.move(1, 1);
/* 205 */       ((FloatType)randomAccess.get()).setReal(0.0625F);
/*     */       
/* 207 */       randomAccess.move(-1, 0);
/* 208 */       ((FloatType)randomAccess.get()).setReal(0.3125F);
/*     */       
/* 210 */       randomAccess.move(-1, 0);
/* 211 */       ((FloatType)randomAccess.get()).setReal(0.1875F);
/*     */       
/* 213 */       return (Img<FloatType>)arrayImg1;
/*     */     } 
/* 215 */     ArrayImg arrayImg = factory.create(Util.getArrayFromValue(3L, numDimensions), (NativeType)new FloatType());
/* 216 */     Cursor<FloatType> cursor = arrayImg.cursor();
/*     */     
/* 218 */     int numValues = (int)(arrayImg.size() / 2L);
/* 219 */     float[] rndValues = new float[numValues];
/* 220 */     float sum = 0.0F;
/* 221 */     Random rnd = new Random(435345L);
/*     */     int i;
/* 223 */     for (i = 0; i < numValues; i++) {
/*     */       
/* 225 */       rndValues[i] = rnd.nextFloat();
/* 226 */       sum += rndValues[i];
/*     */     } 
/*     */     
/* 229 */     for (i = 0; i < numValues; i++) {
/* 230 */       rndValues[i] = rndValues[i] / sum;
/*     */     }
/* 232 */     int count = 0;
/* 233 */     while (cursor.hasNext()) {
/*     */       
/* 235 */       cursor.fwd();
/*     */       
/* 237 */       if (count > numValues) {
/* 238 */         ((FloatType)cursor.get()).setReal(rndValues[count - numValues - 1]);
/*     */       }
/* 240 */       count++;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 246 */     for (int j = 0; j < 100; j++) {
/* 247 */       for (int d = 0; d < numDimensions; d++) {
/*     */         
/* 249 */         cursor.reset();
/*     */         
/* 251 */         float sumD = 0.0F;
/*     */         
/* 253 */         while (cursor.hasNext()) {
/*     */           
/* 255 */           cursor.fwd();
/* 256 */           if (cursor.getIntPosition(d) != 1) {
/* 257 */             sumD += ((FloatType)cursor.get()).get();
/*     */           }
/*     */         } 
/* 260 */         cursor.reset();
/* 261 */         while (cursor.hasNext()) {
/*     */           
/* 263 */           cursor.fwd();
/*     */           
/* 265 */           if (cursor.getIntPosition(d) != 1)
/* 266 */             ((FloatType)cursor.get()).set(((FloatType)cursor.get()).get() / sumD); 
/*     */         } 
/*     */       } 
/*     */     } 
/* 270 */     sum = 0.0F;
/*     */     
/* 272 */     cursor.reset();
/* 273 */     while (cursor.hasNext()) {
/*     */       
/* 275 */       cursor.fwd();
/* 276 */       sum += ((FloatType)cursor.get()).get();
/*     */     } 
/*     */     
/* 279 */     cursor.reset();
/* 280 */     while (cursor.hasNext()) {
/*     */       
/* 282 */       cursor.fwd();
/* 283 */       ((FloatType)cursor.get()).set(((FloatType)cursor.get()).get() / sum);
/*     */     } 
/* 285 */     return (Img<FloatType>)arrayImg;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/imglib2-algorithm-0.6.2.jar!/net/imglib2/algorithm/floydsteinberg/FloydSteinbergDithering.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */