/*     */ package net.imglib2.algorithm.neighborhood;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import net.imglib2.AbstractEuclideanSpace;
/*     */ import net.imglib2.AbstractInterval;
/*     */ import net.imglib2.Cursor;
/*     */ import net.imglib2.FlatIterationOrder;
/*     */ import net.imglib2.Interval;
/*     */ import net.imglib2.IterableInterval;
/*     */ import net.imglib2.RandomAccess;
/*     */ import net.imglib2.RandomAccessible;
/*     */ import net.imglib2.RandomAccessibleInterval;
/*     */ import net.imglib2.RealCursor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HyperSphereShape
/*     */   implements Shape
/*     */ {
/*     */   final long radius;
/*     */   
/*     */   public HyperSphereShape(long radius) {
/*  61 */     this.radius = radius;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> NeighborhoodsIterableInterval<T> neighborhoods(RandomAccessibleInterval<T> source) {
/*  67 */     return new NeighborhoodsIterableInterval<>(source, this.radius, HyperSphereNeighborhoodUnsafe.factory());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> NeighborhoodsAccessible<T> neighborhoodsRandomAccessible(RandomAccessible<T> source) {
/*  73 */     return new NeighborhoodsAccessible<>(source, this.radius, HyperSphereNeighborhoodUnsafe.factory());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> NeighborhoodsIterableInterval<T> neighborhoodsSafe(RandomAccessibleInterval<T> source) {
/*  79 */     return new NeighborhoodsIterableInterval<>(source, this.radius, HyperSphereNeighborhood.factory());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> NeighborhoodsAccessible<T> neighborhoodsRandomAccessibleSafe(RandomAccessible<T> source) {
/*  85 */     return new NeighborhoodsAccessible<>(source, this.radius, HyperSphereNeighborhood.factory());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getRadius() {
/*  93 */     return this.radius;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/*  99 */     return "HyperSphereShape, radius = " + this.radius;
/*     */   }
/*     */ 
/*     */   
/*     */   public static final class NeighborhoodsIterableInterval<T>
/*     */     extends AbstractInterval
/*     */     implements IterableInterval<Neighborhood<T>>
/*     */   {
/*     */     final RandomAccessibleInterval<T> source;
/*     */     
/*     */     final long radius;
/*     */     final long size;
/*     */     final HyperSphereNeighborhoodFactory<T> factory;
/*     */     
/*     */     public NeighborhoodsIterableInterval(RandomAccessibleInterval<T> source, long radius, HyperSphereNeighborhoodFactory<T> factory) {
/* 114 */       super((Interval)source);
/* 115 */       this.source = source;
/* 116 */       this.radius = radius;
/* 117 */       this.factory = factory;
/*     */       
/* 119 */       long s = source.dimension(0);
/* 120 */       for (int d = 1; d < this.n; d++)
/* 121 */         s *= source.dimension(d); 
/* 122 */       this.size = s;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public long size() {
/* 128 */       return this.size;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Neighborhood<T> firstElement() {
/* 134 */       return (Neighborhood<T>)cursor().next();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Object iterationOrder() {
/* 140 */       return new FlatIterationOrder((Interval)this);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Iterator<Neighborhood<T>> iterator() {
/* 146 */       return (Iterator<Neighborhood<T>>)cursor();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Cursor<Neighborhood<T>> cursor() {
/* 152 */       return new HyperSphereNeighborhoodCursor<>(this.source, this.radius, this.factory);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Cursor<Neighborhood<T>> localizingCursor() {
/* 158 */       return cursor();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static final class NeighborhoodsAccessible<T>
/*     */     extends AbstractEuclideanSpace
/*     */     implements RandomAccessible<Neighborhood<T>>
/*     */   {
/*     */     final RandomAccessible<T> source;
/*     */     final long radius;
/*     */     final HyperSphereNeighborhoodFactory<T> factory;
/*     */     
/*     */     public NeighborhoodsAccessible(RandomAccessible<T> source, long radius, HyperSphereNeighborhoodFactory<T> factory) {
/* 172 */       super(source.numDimensions());
/* 173 */       this.source = source;
/* 174 */       this.radius = radius;
/* 175 */       this.factory = factory;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public RandomAccess<Neighborhood<T>> randomAccess() {
/* 181 */       return new HyperSphereNeighborhoodRandomAccess<>(this.source, this.radius, this.factory);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public RandomAccess<Neighborhood<T>> randomAccess(Interval interval) {
/* 187 */       return new HyperSphereNeighborhoodRandomAccess<>(this.source, this.radius, this.factory, interval);
/*     */     }
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/imglib2-algorithm-0.6.2.jar!/net/imglib2/algorithm/neighborhood/HyperSphereShape.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */