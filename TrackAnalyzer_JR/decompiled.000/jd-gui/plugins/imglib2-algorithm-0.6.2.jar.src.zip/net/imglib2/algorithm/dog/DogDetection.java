/*     */ package net.imglib2.algorithm.dog;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.Executors;
/*     */ import net.imagej.axis.LinearAxis;
/*     */ import net.imagej.space.LinearSpace;
/*     */ import net.imglib2.Dimensions;
/*     */ import net.imglib2.Interval;
/*     */ import net.imglib2.Point;
/*     */ import net.imglib2.RandomAccessible;
/*     */ import net.imglib2.RandomAccessibleInterval;
/*     */ import net.imglib2.algorithm.localextrema.LocalExtrema;
/*     */ import net.imglib2.algorithm.localextrema.RefinedPeak;
/*     */ import net.imglib2.algorithm.localextrema.SubpixelLocalization;
/*     */ import net.imglib2.type.NativeType;
/*     */ import net.imglib2.type.numeric.RealType;
/*     */ import net.imglib2.type.numeric.real.DoubleType;
/*     */ import net.imglib2.type.numeric.real.FloatType;
/*     */ import net.imglib2.util.Util;
/*     */ import net.imglib2.view.Views;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DogDetection<T extends RealType<T> & NativeType<T>>
/*     */ {
/*     */   private ExecutorService executorService;
/*     */   protected final RandomAccessible<T> input;
/*     */   protected final Interval interval;
/*     */   protected final double sigmaSmaller;
/*     */   protected final double sigmaLarger;
/*     */   protected final double[] pixelSize;
/*     */   protected final TypedDogDetection<?> typedDogDetection;
/*     */   protected double imageSigma;
/*     */   protected double minf;
/*     */   protected ExtremaType extremaType;
/*     */   protected double minPeakValue;
/*     */   protected boolean normalizeMinPeakValue;
/*     */   protected boolean keepDoGImg;
/*     */   protected int numThreads;
/*     */   
/*     */   public enum ExtremaType
/*     */   {
/*  67 */     MINIMA,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  72 */     MAXIMA;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <I extends RandomAccessibleInterval<T> & LinearSpace<?>> DogDetection(I input, double sigmaSmaller, double sigmaLarger, ExtremaType extremaType, double minPeakValue) {
/*  88 */     this((RandomAccessible<T>)Views.extendMirrorSingle((RandomAccessibleInterval)input), (Interval)input, getcalib((LinearSpace)input), sigmaSmaller, sigmaLarger, extremaType, minPeakValue, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DogDetection(RandomAccessibleInterval<T> input, double[] calibration, double sigmaSmaller, double sigmaLarger, ExtremaType extremaType, double minPeakValue, boolean normalizeMinPeakValue) {
/* 100 */     this((RandomAccessible<T>)Views.extendMirrorSingle(input), (Interval)input, calibration, sigmaSmaller, sigmaLarger, extremaType, minPeakValue, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DogDetection(RandomAccessible<T> input, Interval interval, double[] calibration, double sigmaSmaller, double sigmaLarger, ExtremaType extremaType, double minPeakValue, boolean normalizeMinPeakValue) {
/* 148 */     this(input, interval, calibration, sigmaSmaller, sigmaLarger, extremaType, minPeakValue, normalizeMinPeakValue, (new DogComputationType<>(input, interval)).getType());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <F extends RealType<F> & NativeType<F>> DogDetection(RandomAccessible<T> input, Interval interval, double[] calibration, double sigmaSmaller, double sigmaLarger, ExtremaType extremaType, double minPeakValue, boolean normalizeMinPeakValue, F computationType) {
/* 197 */     this.input = input;
/* 198 */     this.interval = interval;
/* 199 */     this.sigmaSmaller = sigmaSmaller;
/* 200 */     this.sigmaLarger = sigmaLarger;
/* 201 */     this.pixelSize = calibration;
/* 202 */     this.typedDogDetection = new TypedDogDetection(computationType);
/* 203 */     this.imageSigma = 0.5D;
/* 204 */     this.minf = 2.0D;
/* 205 */     this.extremaType = extremaType;
/* 206 */     this.minPeakValue = minPeakValue;
/* 207 */     this.normalizeMinPeakValue = normalizeMinPeakValue;
/* 208 */     this.keepDoGImg = true;
/* 209 */     this.numThreads = Runtime.getRuntime().availableProcessors();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ArrayList<Point> getPeaks() {
/* 218 */     return this.typedDogDetection.getPeaks();
/*     */   }
/*     */ 
/*     */   
/*     */   public ArrayList<RefinedPeak<Point>> getSubpixelPeaks() {
/* 223 */     return this.typedDogDetection.getSubpixelPeaks();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setImageSigma(double imageSigma) {
/* 254 */     this.imageSigma = imageSigma;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setMinf(double minf) {
/* 259 */     this.minf = minf;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setMinPeakValue(double minPeakValue) {
/* 264 */     this.minPeakValue = minPeakValue;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setNormalizeMinPeakValue(boolean normalizeMinPeakValue) {
/* 269 */     this.normalizeMinPeakValue = normalizeMinPeakValue;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setKeepDoGImg(boolean keepDoGImg) {
/* 274 */     this.keepDoGImg = keepDoGImg;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setNumThreads(int numThreads) {
/* 279 */     this.numThreads = numThreads;
/*     */   }
/*     */ 
/*     */   
/*     */   public double getImageSigma() {
/* 284 */     return this.imageSigma;
/*     */   }
/*     */ 
/*     */   
/*     */   public double getMinf() {
/* 289 */     return this.minf;
/*     */   }
/*     */ 
/*     */   
/*     */   public double getMinPeakValue() {
/* 294 */     return this.minPeakValue;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean getNormalizeMinPeakValue() {
/* 299 */     return this.normalizeMinPeakValue;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean getKeepDoGImg() {
/* 304 */     return this.keepDoGImg;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getNumThreads() {
/* 309 */     return this.numThreads;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setExecutorService(ExecutorService service) {
/* 314 */     this.executorService = service;
/*     */   }
/*     */ 
/*     */   
/*     */   private static double[] getcalib(LinearSpace<?> calib) {
/* 319 */     double[] c = new double[calib.numDimensions()];
/* 320 */     for (int d = 0; d < c.length; d++)
/* 321 */       c[d] = ((LinearAxis)calib.axis(d)).scale(); 
/* 322 */     return c;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class DogComputationType<F extends RealType<F> & NativeType<F>>
/*     */   {
/*     */     private final F type;
/*     */ 
/*     */ 
/*     */     
/*     */     public DogComputationType(RandomAccessible<?> input, Interval interval) {
/* 334 */       Object t = Util.getTypeFromInterval((Interval)Views.interval(input, interval));
/* 335 */       if (t instanceof DoubleType) {
/* 336 */         this.type = (F)new DoubleType();
/*     */       } else {
/* 338 */         this.type = (F)new FloatType();
/*     */       } 
/*     */     }
/*     */     
/*     */     public F getType() {
/* 343 */       return this.type;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected class TypedDogDetection<F extends RealType<F> & NativeType<F>>
/*     */   {
/*     */     protected final F type;
/*     */     
/*     */     protected RandomAccessibleInterval<F> dogImg;
/*     */     
/*     */     public TypedDogDetection(F type) {
/* 355 */       this.type = type;
/*     */     }
/*     */     public ArrayList<Point> getPeaks() {
/*     */       ExecutorService service;
/*     */       LocalExtrema.MinimumCheck minimumCheck;
/*     */       LocalExtrema.MaximumCheck maximumCheck;
/* 361 */       if (DogDetection.this.executorService == null) {
/* 362 */         service = Executors.newFixedThreadPool(DogDetection.this.numThreads);
/*     */       } else {
/* 364 */         service = DogDetection.this.executorService;
/*     */       } 
/* 366 */       this.dogImg = (RandomAccessibleInterval<F>)Util.getArrayOrCellImgFactory((Dimensions)DogDetection.this.interval, (NativeType)this.type).create((Dimensions)DogDetection.this.interval, this.type);
/* 367 */       long[] translation = new long[DogDetection.this.interval.numDimensions()];
/* 368 */       DogDetection.this.interval.min(translation);
/* 369 */       this.dogImg = (RandomAccessibleInterval<F>)Views.translate(this.dogImg, translation);
/*     */       
/* 371 */       double[][] sigmas = DifferenceOfGaussian.computeSigmas(DogDetection.this.imageSigma, DogDetection.this.minf, DogDetection.this.pixelSize, DogDetection.this.sigmaSmaller, DogDetection.this.sigmaLarger);
/* 372 */       DifferenceOfGaussian.DoG(sigmas[0], sigmas[1], DogDetection.this.input, this.dogImg, service);
/* 373 */       RealType realType = (RealType)this.type.createVariable();
/* 374 */       double minValueT = this.type.getMinValue();
/* 375 */       double maxValueT = this.type.getMaxValue();
/*     */       
/* 377 */       double normalization = DogDetection.this.normalizeMinPeakValue ? (DogDetection.this.sigmaLarger / DogDetection.this.sigmaSmaller - 1.0D) : 1.0D;
/* 378 */       switch (DogDetection.this.extremaType) {
/*     */         
/*     */         case MINIMA:
/* 381 */           realType.setReal(Math.max(Math.min(-DogDetection.this.minPeakValue * normalization, maxValueT), minValueT));
/* 382 */           minimumCheck = new LocalExtrema.MinimumCheck((Comparable)realType);
/*     */           break;
/*     */         
/*     */         default:
/* 386 */           realType.setReal(Math.max(Math.min(DogDetection.this.minPeakValue * normalization, maxValueT), minValueT));
/* 387 */           maximumCheck = new LocalExtrema.MaximumCheck((Comparable)realType); break;
/*     */       } 
/* 389 */       ArrayList<Point> peaks = LocalExtrema.findLocalExtrema(this.dogImg, (LocalExtrema.LocalNeighborhoodCheck)maximumCheck, service);
/* 390 */       if (!DogDetection.this.keepDoGImg) {
/* 391 */         this.dogImg = null;
/*     */       }
/* 393 */       if (DogDetection.this.executorService == null) {
/* 394 */         service.shutdown();
/*     */       }
/* 396 */       return peaks;
/*     */     }
/*     */ 
/*     */     
/*     */     public ArrayList<RefinedPeak<Point>> getSubpixelPeaks() {
/* 401 */       boolean savedKeepDoGImg = DogDetection.this.keepDoGImg;
/* 402 */       DogDetection.this.keepDoGImg = true;
/* 403 */       ArrayList<Point> peaks = getPeaks();
/* 404 */       SubpixelLocalization<Point, F> spl = new SubpixelLocalization(this.dogImg.numDimensions());
/* 405 */       spl.setAllowMaximaTolerance(true);
/* 406 */       spl.setMaxNumMoves(10);
/* 407 */       ArrayList<RefinedPeak<Point>> refined = spl.process(peaks, (RandomAccessible)this.dogImg, (Interval)this.dogImg);
/* 408 */       DogDetection.this.keepDoGImg = savedKeepDoGImg;
/* 409 */       if (!DogDetection.this.keepDoGImg)
/* 410 */         this.dogImg = null; 
/* 411 */       return refined;
/*     */     }
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/imglib2-algorithm-0.6.2.jar!/net/imglib2/algorithm/dog/DogDetection.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */