/*     */ package net.imglib2.algorithm.gradient;
/*     */ 
/*     */ import net.imglib2.Cursor;
/*     */ import net.imglib2.Interval;
/*     */ import net.imglib2.RandomAccess;
/*     */ import net.imglib2.RandomAccessible;
/*     */ import net.imglib2.RandomAccessibleInterval;
/*     */ import net.imglib2.type.Type;
/*     */ import net.imglib2.type.numeric.NumericType;
/*     */ import net.imglib2.util.Intervals;
/*     */ import net.imglib2.view.Views;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PartialDerivative
/*     */ {
/*     */   public static <T extends NumericType<T>> void gradientCentralDifference2(RandomAccessible<T> source, RandomAccessibleInterval<T> gradient, int dimension) {
/*  61 */     Cursor<T> front = Views.flatIterable((RandomAccessibleInterval)Views.interval(source, (Interval)Intervals.translate((Interval)gradient, 1L, dimension))).cursor();
/*  62 */     Cursor<T> back = Views.flatIterable((RandomAccessibleInterval)Views.interval(source, (Interval)Intervals.translate((Interval)gradient, -1L, dimension))).cursor();
/*     */     
/*  64 */     for (NumericType numericType : Views.flatIterable(gradient)) {
/*     */       
/*  66 */       numericType.set((Type)front.next());
/*  67 */       numericType.sub(back.next());
/*  68 */       numericType.mul(0.5D);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends NumericType<T>> void gradientCentralDifference(RandomAccessible<T> source, RandomAccessibleInterval<T> gradient, int dimension) {
/*  86 */     int n = gradient.numDimensions();
/*     */     
/*  88 */     long[] min = new long[n];
/*  89 */     gradient.min(min);
/*  90 */     long[] max = new long[n];
/*  91 */     gradient.max(max);
/*  92 */     long[] shiftback = new long[n];
/*  93 */     for (int d = 0; d < n; d++) {
/*  94 */       shiftback[d] = min[d] - max[d];
/*     */     }
/*  96 */     RandomAccess<T> result = gradient.randomAccess();
/*  97 */     RandomAccess<T> back = source.randomAccess((Interval)Intervals.translate((Interval)gradient, 1L, dimension));
/*  98 */     RandomAccess<T> front = source.randomAccess((Interval)Intervals.translate((Interval)gradient, -1L, dimension));
/*     */     
/* 100 */     result.setPosition(min);
/* 101 */     back.setPosition(min);
/* 102 */     back.bck(dimension);
/* 103 */     front.setPosition(min);
/* 104 */     front.fwd(dimension);
/*     */     
/* 106 */     long max0 = max[0];
/*     */ 
/*     */     
/*     */     while (true) {
/* 110 */       NumericType numericType = (NumericType)result.get();
/* 111 */       numericType.set((Type)front.get());
/* 112 */       numericType.sub(back.get());
/* 113 */       numericType.mul(0.5D);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 118 */       if (result.getLongPosition(0) == max0) {
/*     */         
/* 120 */         if (n == 1)
/*     */           return; 
/* 122 */         result.move(shiftback[0], 0);
/* 123 */         back.move(shiftback[0], 0);
/* 124 */         front.move(shiftback[0], 0);
/*     */         
/* 126 */         for (int i = 1; i < n; i++) {
/* 127 */           if (result.getLongPosition(i) == max[i]) {
/*     */             
/* 129 */             result.move(shiftback[i], i);
/* 130 */             back.move(shiftback[i], i);
/* 131 */             front.move(shiftback[i], i);
/* 132 */             if (i == n - 1) {
/*     */               return;
/*     */             }
/*     */           } else {
/*     */             
/* 137 */             result.fwd(i);
/* 138 */             back.fwd(i);
/* 139 */             front.fwd(i);
/*     */             break;
/*     */           } 
/*     */         } 
/*     */         continue;
/*     */       } 
/* 145 */       result.fwd(0);
/* 146 */       back.fwd(0);
/* 147 */       front.fwd(0);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/imglib2-algorithm-0.6.2.jar!/net/imglib2/algorithm/gradient/PartialDerivative.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */