/*    */ package net.imglib2.algorithm.function;
/*    */ 
/*    */ import net.imglib2.type.Type;
/*    */ import net.imglib2.type.numeric.NumericType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SubtractNorm<A extends NumericType<A>>
/*    */   implements Function<A, A, A>
/*    */ {
/*    */   final A normalizationFactor;
/*    */   
/*    */   public SubtractNorm(A normalizationFactor) {
/* 50 */     this.normalizationFactor = normalizationFactor;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void compute(A input1, A input2, A output) {
/* 56 */     output.set((Type)input1);
/* 57 */     output.sub(input2);
/* 58 */     output.mul(this.normalizationFactor);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/imglib2-algorithm-0.6.2.jar!/net/imglib2/algorithm/function/SubtractNorm.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */