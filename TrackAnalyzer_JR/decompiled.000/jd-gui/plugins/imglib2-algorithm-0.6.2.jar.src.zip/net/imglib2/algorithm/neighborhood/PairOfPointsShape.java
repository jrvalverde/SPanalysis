/*     */ package net.imglib2.algorithm.neighborhood;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import net.imglib2.AbstractEuclideanSpace;
/*     */ import net.imglib2.AbstractInterval;
/*     */ import net.imglib2.Cursor;
/*     */ import net.imglib2.FlatIterationOrder;
/*     */ import net.imglib2.Interval;
/*     */ import net.imglib2.IterableInterval;
/*     */ import net.imglib2.RandomAccess;
/*     */ import net.imglib2.RandomAccessible;
/*     */ import net.imglib2.RandomAccessibleInterval;
/*     */ import net.imglib2.RealCursor;
/*     */ import net.imglib2.util.Util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PairOfPointsShape
/*     */   implements Shape
/*     */ {
/*     */   private final long[] offset;
/*     */   
/*     */   public PairOfPointsShape(long[] offset) {
/*  71 */     this.offset = offset;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> NeighborhoodsIterableInterval<T> neighborhoods(RandomAccessibleInterval<T> source) {
/*  77 */     PairOfPointsNeighborhoodFactory<T> f = PairOfPointsNeighborhoodUnsafe.factory();
/*  78 */     return new NeighborhoodsIterableInterval<>(source, this.offset, f);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> NeighborhoodsAccessible<T> neighborhoodsRandomAccessible(RandomAccessible<T> source) {
/*  84 */     PairOfPointsNeighborhoodFactory<T> f = PairOfPointsNeighborhoodUnsafe.factory();
/*  85 */     return new NeighborhoodsAccessible<>(source, this.offset, f);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> IterableInterval<Neighborhood<T>> neighborhoodsSafe(RandomAccessibleInterval<T> source) {
/*  91 */     PairOfPointsNeighborhoodFactory<T> f = PairOfPointsNeighborhood.factory();
/*  92 */     return new NeighborhoodsIterableInterval<>(source, this.offset, f);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> NeighborhoodsAccessible<T> neighborhoodsRandomAccessibleSafe(RandomAccessible<T> source) {
/*  98 */     PairOfPointsNeighborhoodFactory<T> f = PairOfPointsNeighborhood.factory();
/*  99 */     return new NeighborhoodsAccessible<>(source, this.offset, f);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long[] getOffset() {
/* 107 */     return (long[])this.offset.clone();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 113 */     return "PairOfPointsShape, offset = " + Util.printCoordinates(this.offset);
/*     */   }
/*     */ 
/*     */   
/*     */   public static final class NeighborhoodsIterableInterval<T>
/*     */     extends AbstractInterval
/*     */     implements IterableInterval<Neighborhood<T>>
/*     */   {
/*     */     final RandomAccessibleInterval<T> source;
/*     */     final PairOfPointsNeighborhoodFactory<T> factory;
/*     */     final long[] offset;
/*     */     
/*     */     public NeighborhoodsIterableInterval(RandomAccessibleInterval<T> source, long[] offset, PairOfPointsNeighborhoodFactory<T> factory) {
/* 126 */       super((Interval)source);
/* 127 */       this.source = source;
/* 128 */       this.offset = offset;
/* 129 */       this.factory = factory;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Cursor<Neighborhood<T>> cursor() {
/* 135 */       return new PairOfPointsNeighborhoodCursor<>(this.source, this.offset, this.factory);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public long size() {
/* 141 */       return 2L;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Neighborhood<T> firstElement() {
/* 147 */       return (Neighborhood<T>)cursor().next();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Object iterationOrder() {
/* 153 */       return new FlatIterationOrder((Interval)this);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Iterator<Neighborhood<T>> iterator() {
/* 159 */       return (Iterator<Neighborhood<T>>)cursor();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Cursor<Neighborhood<T>> localizingCursor() {
/* 165 */       return cursor();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static final class NeighborhoodsAccessible<T>
/*     */     extends AbstractEuclideanSpace
/*     */     implements RandomAccessible<Neighborhood<T>>
/*     */   {
/*     */     final RandomAccessible<T> source;
/*     */     final PairOfPointsNeighborhoodFactory<T> factory;
/*     */     private final long[] offset;
/*     */     
/*     */     public NeighborhoodsAccessible(RandomAccessible<T> source, long[] offset, PairOfPointsNeighborhoodFactory<T> factory) {
/* 179 */       super(source.numDimensions());
/* 180 */       this.source = source;
/* 181 */       this.offset = offset;
/* 182 */       this.factory = factory;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public RandomAccess<Neighborhood<T>> randomAccess() {
/* 188 */       return new PairOfPointsNeighborhoodRandomAccess<>(this.source, this.offset, this.factory);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public RandomAccess<Neighborhood<T>> randomAccess(Interval interval) {
/* 194 */       return randomAccess();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public int numDimensions() {
/* 200 */       return this.source.numDimensions();
/*     */     }
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/imglib2-algorithm-0.6.2.jar!/net/imglib2/algorithm/neighborhood/PairOfPointsShape.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */