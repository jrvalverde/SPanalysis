/*     */ package net.imglib2.algorithm.kdtree;
/*     */ 
/*     */ import net.imglib2.AbstractEuclideanSpace;
/*     */ import net.imglib2.realtransform.AffineGet;
/*     */ import net.imglib2.util.LinAlgHelpers;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HyperPlane
/*     */   extends AbstractEuclideanSpace
/*     */ {
/*     */   private final double[] normal;
/*     */   private final double distance;
/*     */   
/*     */   public HyperPlane(double[] normal, double distance) {
/*  49 */     super(normal.length);
/*  50 */     this.normal = (double[])normal.clone();
/*  51 */     this.distance = distance;
/*  52 */     LinAlgHelpers.normalize(this.normal);
/*     */   }
/*     */ 
/*     */   
/*     */   public HyperPlane(double... normalAndDistance) {
/*  57 */     super(normalAndDistance.length - 1);
/*  58 */     this.normal = new double[this.n];
/*  59 */     System.arraycopy(normalAndDistance, 0, this.normal, 0, this.n);
/*  60 */     this.distance = normalAndDistance[this.n];
/*  61 */     LinAlgHelpers.normalize(this.normal);
/*     */   }
/*     */ 
/*     */   
/*     */   public double[] getNormal() {
/*  66 */     return this.normal;
/*     */   }
/*     */ 
/*     */   
/*     */   public double getDistance() {
/*  71 */     return this.distance;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static HyperPlane transform(HyperPlane plane, AffineGet transform) {
/*  85 */     assert plane.numDimensions() == transform.numDimensions();
/*     */     
/*  87 */     int n = transform.numDimensions();
/*     */     
/*  89 */     double[] O = new double[n];
/*  90 */     double[] tO = new double[n];
/*  91 */     LinAlgHelpers.scale(plane.getNormal(), plane.getDistance(), O);
/*  92 */     transform.apply(O, tO);
/*     */     
/*  94 */     double[][] m = new double[n][n];
/*  95 */     for (int r = 0; r < n; r++) {
/*  96 */       for (int c = 0; c < n; c++)
/*  97 */         m[r][c] = transform.inverse().get(c, r); 
/*  98 */     }  double[] tN = new double[n];
/*  99 */     LinAlgHelpers.mult(m, plane.getNormal(), tN);
/* 100 */     LinAlgHelpers.normalize(tN);
/* 101 */     double td = LinAlgHelpers.dot(tN, tO);
/*     */     
/* 103 */     return new HyperPlane(tN, td);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/imglib2-algorithm-0.6.2.jar!/net/imglib2/algorithm/kdtree/HyperPlane.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */