/*    */ package net.imglib2.algorithm.localextrema;
/*    */ 
/*    */ import net.imglib2.Localizable;
/*    */ import net.imglib2.RealLocalizable;
/*    */ import net.imglib2.RealPoint;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RefinedPeak<P extends Localizable>
/*    */   extends RealPoint
/*    */ {
/*    */   protected final P originalPeak;
/*    */   protected final double value;
/*    */   protected final boolean valid;
/*    */   
/*    */   public RefinedPeak(P originalPeak, RealLocalizable refinedLocation, double refinedValue, boolean valid) {
/* 59 */     super(refinedLocation);
/* 60 */     this.originalPeak = originalPeak;
/* 61 */     this.value = refinedValue;
/* 62 */     this.valid = valid;
/*    */   }
/*    */ 
/*    */   
/*    */   public P getOriginalPeak() {
/* 67 */     return this.originalPeak;
/*    */   }
/*    */ 
/*    */   
/*    */   public double getValue() {
/* 72 */     return this.value;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isValid() {
/* 77 */     return this.valid;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/imglib2-algorithm-0.6.2.jar!/net/imglib2/algorithm/localextrema/RefinedPeak.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */