/*     */ package net.imglib2.algorithm.neighborhood;
/*     */ 
/*     */ import net.imglib2.Cursor;
/*     */ import net.imglib2.Interval;
/*     */ import net.imglib2.RandomAccessible;
/*     */ import net.imglib2.RandomAccessibleInterval;
/*     */ import net.imglib2.RealCursor;
/*     */ import net.imglib2.Sampler;
/*     */ import net.imglib2.util.IntervalIndexer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PairOfPointsNeighborhoodCursor<T>
/*     */   extends PairOfPointsNeighborhoodLocalizableSampler<T>
/*     */   implements Cursor<Neighborhood<T>>
/*     */ {
/*     */   private final long[] dimensions;
/*     */   private long index;
/*     */   private final long maxIndex;
/*     */   private long maxIndexOnLine;
/*     */   private long[] min;
/*     */   private long[] max;
/*     */   
/*     */   public PairOfPointsNeighborhoodCursor(RandomAccessibleInterval<T> source, long[] offset, PairOfPointsNeighborhoodFactory<T> factory) {
/*  56 */     super((RandomAccessible<T>)source, offset, factory, (Interval)source);
/*     */     
/*  58 */     this.dimensions = new long[this.n];
/*  59 */     this.min = new long[this.n];
/*  60 */     this.max = new long[this.n];
/*  61 */     source.dimensions(this.dimensions);
/*  62 */     source.min(this.min);
/*  63 */     source.max(this.max);
/*     */     
/*  65 */     long size = this.dimensions[0];
/*  66 */     for (int d = 1; d < this.n; d++)
/*  67 */       size *= this.dimensions[d]; 
/*  68 */     this.maxIndex = size - 1L;
/*  69 */     reset();
/*     */   }
/*     */ 
/*     */   
/*     */   private PairOfPointsNeighborhoodCursor(PairOfPointsNeighborhoodCursor<T> c) {
/*  74 */     super(c);
/*  75 */     this.dimensions = (long[])c.dimensions.clone();
/*  76 */     this.maxIndex = c.maxIndex;
/*  77 */     this.index = c.index;
/*  78 */     this.maxIndexOnLine = c.maxIndexOnLine;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void fwd() {
/*  84 */     this.currentPos[0] = this.currentPos[0] + 1L;
/*  85 */     if (++this.index > this.maxIndexOnLine) {
/*  86 */       nextLine();
/*     */     }
/*     */   }
/*     */   
/*     */   private void nextLine() {
/*  91 */     this.currentPos[0] = this.min[0];
/*  92 */     this.maxIndexOnLine += this.dimensions[0];
/*  93 */     for (int d = 1; d < this.n; ) {
/*     */       
/*  95 */       this.currentPos[d] = this.currentPos[d] + 1L;
/*  96 */       if (this.currentPos[d] > this.max[d]) {
/*     */         
/*  98 */         this.currentPos[d] = this.min[d];
/*     */         d++;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void reset() {
/* 108 */     this.index = -1L;
/* 109 */     this.maxIndexOnLine = -1L;
/* 110 */     System.arraycopy(this.max, 0, this.currentPos, 0, this.n);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasNext() {
/* 116 */     return (this.index < this.maxIndex);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void jumpFwd(long steps) {
/* 122 */     this.index += steps;
/* 123 */     if (this.index < 0L) {
/*     */       
/* 125 */       this.maxIndexOnLine = (1L + this.index) / this.dimensions[0] * this.dimensions[0] - 1L;
/* 126 */       long size = this.maxIndex + 1L;
/* 127 */       IntervalIndexer.indexToPositionWithOffset(size - -this.index % size, this.dimensions, this.min, this.currentPos);
/*     */     }
/*     */     else {
/*     */       
/* 131 */       this.maxIndexOnLine = (1L + this.index / this.dimensions[0]) * this.dimensions[0] - 1L;
/* 132 */       IntervalIndexer.indexToPositionWithOffset(this.index, this.dimensions, this.min, this.currentPos);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Neighborhood<T> next() {
/* 139 */     fwd();
/* 140 */     return get();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void remove() {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PairOfPointsNeighborhoodCursor<T> copy() {
/* 152 */     return new PairOfPointsNeighborhoodCursor(this);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public PairOfPointsNeighborhoodCursor<T> copyCursor() {
/* 158 */     return copy();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/imglib2-algorithm-0.6.2.jar!/net/imglib2/algorithm/neighborhood/PairOfPointsNeighborhoodCursor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */