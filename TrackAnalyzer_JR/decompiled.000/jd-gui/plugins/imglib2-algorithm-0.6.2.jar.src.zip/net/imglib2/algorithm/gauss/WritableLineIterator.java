/*    */ package net.imglib2.algorithm.gauss;
/*    */ 
/*    */ import net.imglib2.Localizable;
/*    */ import net.imglib2.Positionable;
/*    */ import net.imglib2.RandomAccess;
/*    */ import net.imglib2.type.Type;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ public class WritableLineIterator<T extends Type<T>>
/*    */   extends AbstractLineIterator
/*    */ {
/*    */   final RandomAccess<T> randomAccess;
/*    */   
/*    */   public WritableLineIterator(int dim, long size, RandomAccess<T> randomAccess) {
/* 65 */     super(dim, size, (Localizable)randomAccess, (Positionable)randomAccess);
/*    */     
/* 67 */     this.randomAccess = randomAccess;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void set(T type) {
/* 78 */     ((Type)this.randomAccess.get()).set((Type)type);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/imglib2-algorithm-0.6.2.jar!/net/imglib2/algorithm/gauss/WritableLineIterator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */