/*     */ package net.imglib2.algorithm.componenttree.pixellist;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import net.imglib2.Localizable;
/*     */ import net.imglib2.algorithm.componenttree.PartialComponent;
/*     */ import net.imglib2.type.Type;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class PixelListPartialComponent<T extends Type<T>>
/*     */   implements PartialComponent<T, PixelListPartialComponent<T>>
/*     */ {
/*     */   private final T value;
/*     */   final PixelList pixelList;
/*     */   final ArrayList<PixelListPartialComponent<T>> children;
/*     */   PixelListComponent<T> emittedComponent;
/*     */   
/*     */   PixelListPartialComponent(T value, PixelListPartialComponentGenerator<T> generator) {
/*  87 */     this.pixelList = new PixelList(generator.linkedList.randomAccess(), generator.dimensions);
/*  88 */     this.value = (T)value.copy();
/*  89 */     this.children = new ArrayList<>();
/*  90 */     this.emittedComponent = null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void addPosition(Localizable position) {
/*  96 */     this.pixelList.addPosition(position);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public T getValue() {
/* 102 */     return this.value;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setValue(T value) {
/* 108 */     this.value.set((Type)value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void merge(PixelListPartialComponent<T> component) {
/* 114 */     this.pixelList.merge(component.pixelList);
/* 115 */     this.children.add(component);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 121 */     String s = "{" + this.value.toString() + " : ";
/* 122 */     boolean first = true;
/* 123 */     for (Localizable l : this.pixelList) {
/*     */       
/* 125 */       if (first) {
/*     */         
/* 127 */         first = false;
/*     */       }
/*     */       else {
/*     */         
/* 131 */         s = s + ", ";
/*     */       } 
/* 133 */       s = s + l.toString();
/*     */     } 
/* 135 */     return s + "}";
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/imglib2-algorithm-0.6.2.jar!/net/imglib2/algorithm/componenttree/pixellist/PixelListPartialComponent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */