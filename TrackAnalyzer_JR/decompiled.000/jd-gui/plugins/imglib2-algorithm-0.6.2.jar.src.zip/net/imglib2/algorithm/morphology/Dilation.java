/*      */ package net.imglib2.algorithm.morphology;
/*      */ 
/*      */ import java.util.List;
/*      */ import java.util.Vector;
/*      */ import net.imglib2.Cursor;
/*      */ import net.imglib2.Dimensions;
/*      */ import net.imglib2.EuclideanSpace;
/*      */ import net.imglib2.Interval;
/*      */ import net.imglib2.IterableInterval;
/*      */ import net.imglib2.Localizable;
/*      */ import net.imglib2.RandomAccess;
/*      */ import net.imglib2.RandomAccessible;
/*      */ import net.imglib2.RandomAccessibleInterval;
/*      */ import net.imglib2.algorithm.neighborhood.Neighborhood;
/*      */ import net.imglib2.algorithm.neighborhood.Shape;
/*      */ import net.imglib2.img.Img;
/*      */ import net.imglib2.img.ImgFactory;
/*      */ import net.imglib2.multithreading.Chunk;
/*      */ import net.imglib2.multithreading.SimpleMultiThreading;
/*      */ import net.imglib2.type.Type;
/*      */ import net.imglib2.type.logic.BitType;
/*      */ import net.imglib2.type.numeric.RealType;
/*      */ import net.imglib2.view.ExtendedRandomAccessibleInterval;
/*      */ import net.imglib2.view.IntervalView;
/*      */ import net.imglib2.view.Views;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class Dilation
/*      */ {
/*      */   public static <T extends RealType<T>> Img<T> dilate(Img<T> source, List<Shape> strels, int numThreads) {
/*   90 */     Img<T> target = source;
/*   91 */     for (Shape strel : strels)
/*      */     {
/*   93 */       target = dilateFull(target, strel, numThreads);
/*      */     }
/*   95 */     return (Img)MorphologyUtils.copyCropped((Img)target, (Interval)source, numThreads);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends Type<T> & Comparable<T>> Img<T> dilate(Img<T> source, List<Shape> strels, T minVal, int numThreads) {
/*  142 */     Img<T> target = source;
/*  143 */     for (Shape strel : strels)
/*      */     {
/*  145 */       target = dilateFull(target, strel, minVal, numThreads);
/*      */     }
/*  147 */     return (Img)MorphologyUtils.copyCropped(target, (Interval)source, numThreads);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends RealType<T>> Img<T> dilate(Img<T> source, Shape strel, int numThreads) {
/*  175 */     Img<T> target = source.factory().create((Dimensions)source, ((RealType)source.firstElement()).copy());
/*  176 */     RealType realType = (RealType)((RealType)source.firstElement()).createVariable();
/*  177 */     realType.setReal(realType.getMinValue());
/*  178 */     ExtendedRandomAccessibleInterval<T, Img<T>> extended = Views.extendValue((RandomAccessibleInterval)source, (Type)realType);
/*  179 */     dilate((RandomAccessible)extended, (IterableInterval<T>)target, strel, numThreads);
/*  180 */     return target;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends Type<T> & Comparable<T>> Img<T> dilate(Img<T> source, Shape strel, T minVal, int numThreads) {
/*  222 */     Img<T> target = source.factory().create((Dimensions)source, ((Type)source.firstElement()).copy());
/*  223 */     ExtendedRandomAccessibleInterval<T, Img<T>> extended = Views.extendValue((RandomAccessibleInterval)source, (Type)minVal);
/*  224 */     dilate((RandomAccessible)extended, (IterableInterval<T>)target, strel, minVal, numThreads);
/*  225 */     return target;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends RealType<T>> void dilate(RandomAccessible<T> source, IterableInterval<T> target, List<Shape> strels, int numThreads) {
/*  265 */     RealType realType = MorphologyUtils.<RealType>createVariable(source, (Interval)target);
/*  266 */     realType.setReal(realType.getMinValue());
/*  267 */     dilate(source, target, strels, realType, numThreads);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends Type<T> & Comparable<T>> void dilate(RandomAccessible<T> source, IterableInterval<T> target, List<Shape> strels, T minVal, int numThreads) {
/*  323 */     if (strels.isEmpty())
/*  324 */       return;  if (strels.size() == 1) {
/*      */       
/*  326 */       dilate(source, target, strels.get(0), minVal, numThreads);
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/*  331 */     long[] targetDims = new long[target.numDimensions()];
/*  332 */     long[] translation = new long[target.numDimensions()];
/*  333 */     for (int d = 0; d < targetDims.length; d++) {
/*      */       
/*  335 */       targetDims[d] = target.dimension(d);
/*  336 */       translation[d] = target.min(d);
/*      */     } 
/*  338 */     for (Shape strel : strels) {
/*      */       
/*  340 */       Neighborhood<BitType> nh = MorphologyUtils.getNeighborhood(strel, (EuclideanSpace)target);
/*  341 */       for (int k = 0; k < translation.length; k++) {
/*      */         
/*  343 */         translation[k] = translation[k] - nh.dimension(k) / 2L;
/*  344 */         targetDims[k] = targetDims[k] + nh.dimension(k) - 1L;
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  349 */     ImgFactory<T> factory = MorphologyUtils.getSuitableFactory(targetDims, minVal);
/*  350 */     Img<T> temp = factory.create(targetDims, minVal);
/*  351 */     IntervalView<T> translated = Views.translate((RandomAccessibleInterval)temp, translation);
/*  352 */     dilate(source, (IterableInterval<T>)translated, strels.get(0), minVal, numThreads);
/*      */ 
/*      */     
/*  355 */     for (int i = 1; i < strels.size(); i++)
/*      */     {
/*  357 */       temp = dilate(temp, strels.get(i), minVal, numThreads);
/*      */     }
/*      */ 
/*      */     
/*  361 */     long[] offset = new long[target.numDimensions()];
/*  362 */     for (int j = 0; j < offset.length; j++)
/*      */     {
/*  364 */       offset[j] = target.min(j) - (temp.dimension(j) - target.dimension(j)) / 2L;
/*      */     }
/*  366 */     MorphologyUtils.copy2((RandomAccessible<Type>)Views.translate((RandomAccessibleInterval)temp, offset), target, numThreads);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends RealType<T>> void dilate(RandomAccessible<T> source, IterableInterval<T> target, Shape strel, int numThreads) {
/*  401 */     RealType realType = MorphologyUtils.<RealType>createVariable(source, (Interval)target);
/*  402 */     realType.setReal(realType.getMinValue());
/*  403 */     dilate(source, target, strel, realType, numThreads);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends Type<T> & Comparable<T>> void dilate(final RandomAccessible<T> source, final IterableInterval<T> target, Shape strel, final T minVal, int numThreads) {
/*  454 */     numThreads = Math.max(1, numThreads);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  460 */     final RandomAccessible<Neighborhood<T>> accessible = strel.neighborhoodsRandomAccessible(source);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  466 */     Vector<Chunk> chunks = SimpleMultiThreading.divideIntoChunks(target.size(), numThreads);
/*  467 */     Thread[] threads = SimpleMultiThreading.newThreads(numThreads);
/*      */ 
/*      */     
/*  470 */     Object tmp = minVal;
/*  471 */     if (tmp instanceof BitType) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  477 */       for (int i = 0; i < threads.length; i++) {
/*      */         
/*  479 */         final Chunk chunk = chunks.get(i);
/*  480 */         threads[i] = new Thread("Morphology dilate thread " + i)
/*      */           {
/*      */             
/*      */             public void run()
/*      */             {
/*  485 */               RandomAccess<Neighborhood<T>> randomAccess = accessible.randomAccess((Interval)target);
/*  486 */               Object tmp2 = target.cursor();
/*      */               
/*  488 */               Cursor<BitType> cursorDilated = (Cursor<BitType>)tmp2;
/*  489 */               cursorDilated.jumpFwd(chunk.getStartPosition());
/*      */               long steps;
/*  491 */               for (steps = 0L; steps < chunk.getLoopSize(); steps++) {
/*      */                 
/*  493 */                 cursorDilated.fwd();
/*  494 */                 randomAccess.setPosition((Localizable)cursorDilated);
/*  495 */                 Neighborhood<T> neighborhood = (Neighborhood<T>)randomAccess.get();
/*  496 */                 Object tmp3 = neighborhood.cursor();
/*      */                 
/*  498 */                 Cursor<BitType> nc = (Cursor<BitType>)tmp3;
/*      */                 
/*  500 */                 while (nc.hasNext()) {
/*      */                   
/*  502 */                   nc.fwd();
/*  503 */                   BitType val = (BitType)nc.get();
/*  504 */                   if (val.get()) {
/*      */                     
/*  506 */                     ((BitType)cursorDilated.get()).set(true);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */                     
/*      */                     break;
/*      */                   } 
/*      */                 } 
/*      */               } 
/*      */             }
/*      */           };
/*      */       } 
/*      */     } else {
/*  522 */       for (int i = 0; i < threads.length; i++) {
/*      */         
/*  524 */         final Chunk chunk = chunks.get(i);
/*  525 */         threads[i] = new Thread("Morphology dilate thread " + i)
/*      */           {
/*      */             
/*      */             public void run()
/*      */             {
/*  530 */               RandomAccess<Neighborhood<T>> randomAccess = accessible.randomAccess((Interval)target);
/*  531 */               Cursor<T> cursorDilated = target.cursor();
/*  532 */               cursorDilated.jumpFwd(chunk.getStartPosition());
/*      */               
/*  534 */               T max = (T)MorphologyUtils.createVariable(source, (Interval)target); long steps;
/*  535 */               for (steps = 0L; steps < chunk.getLoopSize(); steps++) {
/*      */                 
/*  537 */                 cursorDilated.fwd();
/*  538 */                 randomAccess.setPosition((Localizable)cursorDilated);
/*  539 */                 Neighborhood<T> neighborhood = (Neighborhood<T>)randomAccess.get();
/*  540 */                 Cursor<T> nc = neighborhood.cursor();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */                 
/*  546 */                 max.set(minVal);
/*  547 */                 while (nc.hasNext()) {
/*      */                   
/*  549 */                   nc.fwd();
/*  550 */                   Type type = (Type)nc.get();
/*      */                   
/*  552 */                   if (((Comparable<T>)type).compareTo(max) > 0)
/*      */                   {
/*  554 */                     max.set(type);
/*      */                   }
/*      */                 } 
/*  557 */                 ((Type)cursorDilated.get()).set((Type)max);
/*      */               } 
/*      */             }
/*      */           };
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  569 */     SimpleMultiThreading.startAndJoin(threads);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends RealType<T>> Img<T> dilateFull(Img<T> source, List<Shape> strels, int numThreads) {
/*  615 */     Img<T> target = source;
/*  616 */     for (Shape strel : strels)
/*      */     {
/*  618 */       target = dilateFull(target, strel, numThreads);
/*      */     }
/*  620 */     return target;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends Type<T> & Comparable<T>> Img<T> dilateFull(Img<T> source, List<Shape> strels, T minVal, int numThreads) {
/*  680 */     Img<T> target = source;
/*  681 */     for (Shape strel : strels)
/*      */     {
/*  683 */       target = dilateFull(target, strel, minVal, numThreads);
/*      */     }
/*  685 */     return target;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends RealType<T>> Img<T> dilateFull(Img<T> source, Shape strel, int numThreads) {
/*  726 */     long[][] dimensionsAndOffset = MorphologyUtils.computeTargetImageDimensionsAndOffset((Interval)source, strel);
/*      */     
/*  728 */     long[] targetDims = dimensionsAndOffset[0];
/*  729 */     long[] offset = dimensionsAndOffset[1];
/*      */     
/*  731 */     Img<T> target = source.factory().create(targetDims, ((RealType)source.firstElement()).copy());
/*  732 */     IntervalView<T> offsetTarget = Views.offset((RandomAccessibleInterval)target, offset);
/*  733 */     RealType realType = MorphologyUtils.<RealType>createVariable((RandomAccessible<RealType>)source, (Interval)source);
/*  734 */     realType.setReal(realType.getMinValue());
/*  735 */     ExtendedRandomAccessibleInterval<T, Img<T>> extended = Views.extendValue((RandomAccessibleInterval)source, (Type)realType);
/*      */     
/*  737 */     dilate((RandomAccessible)extended, (IterableInterval<T>)offsetTarget, strel, numThreads);
/*  738 */     return target;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends Type<T> & Comparable<T>> Img<T> dilateFull(Img<T> source, Shape strel, T minVal, int numThreads) {
/*  794 */     long[][] dimensionsAndOffset = MorphologyUtils.computeTargetImageDimensionsAndOffset((Interval)source, strel);
/*  795 */     long[] targetDims = dimensionsAndOffset[0];
/*  796 */     long[] offset = dimensionsAndOffset[1];
/*      */     
/*  798 */     Img<T> target = source.factory().create(targetDims, ((Type)source.firstElement()).copy());
/*  799 */     IntervalView<T> offsetTarget = Views.offset((RandomAccessibleInterval)target, offset);
/*  800 */     ExtendedRandomAccessibleInterval<T, Img<T>> extended = Views.extendValue((RandomAccessibleInterval)source, (Type)minVal);
/*      */     
/*  802 */     dilate((RandomAccessible)extended, (IterableInterval<T>)offsetTarget, strel, minVal, numThreads);
/*  803 */     return target;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends RealType<T>> void dilateInPlace(RandomAccessibleInterval<T> source, Interval interval, List<Shape> strels, int numThreads) {
/*  842 */     for (Shape strel : strels)
/*      */     {
/*  844 */       dilateInPlace(source, interval, strel, numThreads);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends Type<T> & Comparable<T>> void dilateInPlace(RandomAccessibleInterval<T> source, Interval interval, List<Shape> strels, T minVal, int numThreads) {
/*  896 */     for (Shape strel : strels)
/*      */     {
/*  898 */       dilateInPlace(source, interval, strel, minVal, numThreads);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends RealType<T>> void dilateInPlace(RandomAccessibleInterval<T> source, Interval interval, Shape strel, int numThreads) {
/*  934 */     RealType realType = MorphologyUtils.<RealType>createVariable((RandomAccessible<RealType>)source, interval);
/*  935 */     realType.setReal(realType.getMinValue());
/*  936 */     ExtendedRandomAccessibleInterval<T, RandomAccessibleInterval<T>> extended = Views.extendValue(source, (Type)realType);
/*      */     
/*  938 */     ImgFactory<T> factory = MorphologyUtils.getSuitableFactory((Dimensions)interval, (T)realType);
/*  939 */     Img<T> img = factory.create((Dimensions)interval, realType);
/*  940 */     long[] min = new long[interval.numDimensions()];
/*  941 */     interval.min(min);
/*  942 */     IntervalView<T> translated = Views.translate((RandomAccessibleInterval)img, min);
/*      */     
/*  944 */     dilate((RandomAccessible)extended, (IterableInterval<T>)translated, strel, numThreads);
/*  945 */     MorphologyUtils.copy((IterableInterval<T>)translated, (RandomAccessible)extended, numThreads);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends Type<T> & Comparable<T>> void dilateInPlace(RandomAccessibleInterval<T> source, Interval interval, Shape strel, T minVal, int numThreads) {
/* 1001 */     ExtendedRandomAccessibleInterval<T, RandomAccessibleInterval<T>> extended = Views.extendValue(source, (Type)minVal);
/*      */     
/* 1003 */     ImgFactory<T> factory = MorphologyUtils.getSuitableFactory((Dimensions)interval, minVal);
/* 1004 */     Img<T> img = factory.create((Dimensions)interval, minVal);
/* 1005 */     long[] min = new long[interval.numDimensions()];
/* 1006 */     interval.min(min);
/* 1007 */     IntervalView<T> translated = Views.translate((RandomAccessibleInterval)img, min);
/*      */     
/* 1009 */     dilate((RandomAccessible)extended, (IterableInterval<T>)translated, strel, minVal, numThreads);
/* 1010 */     MorphologyUtils.copy((IterableInterval<T>)translated, (RandomAccessible)extended, numThreads);
/*      */   }
/*      */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/imglib2-algorithm-0.6.2.jar!/net/imglib2/algorithm/morphology/Dilation.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */