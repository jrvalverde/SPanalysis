/*     */ package net.imglib2.algorithm.labeling;
/*     */ 
/*     */ import gnu.trove.list.array.TIntArrayList;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ExecutionException;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.Executors;
/*     */ import java.util.concurrent.Future;
/*     */ import net.imglib2.Cursor;
/*     */ import net.imglib2.FinalInterval;
/*     */ import net.imglib2.Interval;
/*     */ import net.imglib2.Localizable;
/*     */ import net.imglib2.RandomAccess;
/*     */ import net.imglib2.RandomAccessible;
/*     */ import net.imglib2.RandomAccessibleInterval;
/*     */ import net.imglib2.roi.labeling.ImgLabeling;
/*     */ import net.imglib2.roi.labeling.LabelingMapping;
/*     */ import net.imglib2.type.numeric.IntegerType;
/*     */ import net.imglib2.view.Views;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ConnectedComponents
/*     */ {
/*     */   public enum StructuringElement
/*     */   {
/*  69 */     FOUR_CONNECTED((String)ConnectedComponents.Collect4NeighborLabels.factory),
/*  70 */     EIGHT_CONNECTED((String)ConnectedComponents.Collect8NeighborLabels.factory);
/*     */     
/*     */     private final ConnectedComponents.CollectNeighborLabelsFactory factory;
/*     */ 
/*     */     
/*     */     StructuringElement(ConnectedComponents.CollectNeighborLabelsFactory factory) {
/*  76 */       this.factory = factory;
/*     */     }
/*     */ 
/*     */     
/*     */     public ConnectedComponents.CollectNeighborLabelsFactory getFactory() {
/*  81 */       return this.factory;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends IntegerType<T>, L, I extends IntegerType<I>> void labelAllConnectedComponents(RandomAccessible<T> input, ImgLabeling<L, I> labeling, Iterator<L> labelGenerator, StructuringElement se) {
/* 110 */     int numThreads = Runtime.getRuntime().availableProcessors();
/* 111 */     ExecutorService service = Executors.newFixedThreadPool(numThreads);
/* 112 */     labelAllConnectedComponents(input, labeling, labelGenerator, se, service);
/* 113 */     service.shutdown();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends IntegerType<T>, L, I extends IntegerType<I>> void labelAllConnectedComponents(RandomAccessible<T> input, ImgLabeling<L, I> labeling, Iterator<L> labelGenerator, StructuringElement se, ExecutorService service) {
/* 144 */     RandomAccessibleInterval<I> output = labeling.getIndexImg();
/* 145 */     for (IntegerType integerType : Views.iterable(output)) {
/* 146 */       integerType.setZero();
/*     */     }
/* 148 */     int numLabels = labelAllConnectedComponents(input, output, se) + 1;
/*     */     
/* 150 */     final ArrayList<Set<L>> labelSets = new ArrayList<>();
/* 151 */     labelSets.add(new HashSet<>());
/* 152 */     for (int i = 1; i < numLabels; i++) {
/*     */       
/* 154 */       HashSet<L> set = new HashSet<>();
/* 155 */       set.add(labelGenerator.next());
/* 156 */       labelSets.add(set);
/*     */     } 
/* 158 */     new LabelingMapping.SerialisationAccess<L>(labeling.getMapping())
/*     */       {
/*     */       
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends IntegerType<T>, L extends IntegerType<L>> int labelAllConnectedComponents(RandomAccessible<T> input, RandomAccessibleInterval<L> output, StructuringElement se) {
/* 189 */     int numThreads = Runtime.getRuntime().availableProcessors();
/* 190 */     ExecutorService service = Executors.newFixedThreadPool(numThreads);
/* 191 */     int result = labelAllConnectedComponents(input, output, se, service);
/* 192 */     service.shutdown();
/* 193 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends IntegerType<T>, L extends IntegerType<L>> int labelAllConnectedComponents(RandomAccessible<T> input, RandomAccessibleInterval<L> output, StructuringElement se, ExecutorService service) {
/* 222 */     int n = output.numDimensions();
/* 223 */     int splitDim = n - 1;
/* 224 */     long[] min = new long[n];
/* 225 */     long[] max = new long[n];
/* 226 */     output.min(min);
/* 227 */     output.max(max);
/* 228 */     long splitDimMax = max[splitDim];
/*     */     
/* 230 */     int numThreads = Runtime.getRuntime().availableProcessors();
/* 231 */     int numTasks = (numThreads > 1) ? (numThreads * 2) : 1;
/* 232 */     numTasks = (int)Math.max(1L, Math.min(numTasks, output.dimension(splitDim) / 4L));
/* 233 */     long taskSize = output.dimension(splitDim) / numTasks;
/*     */ 
/*     */     
/* 236 */     Fragment[] arrayOfFragment = new Fragment[numTasks];
/* 237 */     CollectNeighborLabels<L> collectNeighborLabels = se.getFactory().newInstance(n);
/* 238 */     for (int i = 0; i < numTasks; i++) {
/*     */       
/* 240 */       max[splitDim] = (i == numTasks - 1) ? splitDimMax : (min[splitDim] + taskSize - 1L);
/* 241 */       arrayOfFragment[i] = new Fragment<>(input, (RandomAccessibleInterval<L>)Views.interval((RandomAccessible)output, min, max), collectNeighborLabels);
/* 242 */       min[splitDim] = min[splitDim] + taskSize;
/*     */     } 
/*     */     
/* 245 */     ArrayList<Future<?>> futures = new ArrayList<>();
/* 246 */     for (Fragment<T, L> fragment : arrayOfFragment) {
/*     */       
/* 248 */       futures.add(service.submit(new Runnable()
/*     */             {
/*     */               
/*     */               public void run()
/*     */               {
/* 253 */                 fragment.mark();
/*     */               }
/*     */             }));
/*     */     } 
/* 257 */     getAllFutures(futures);
/*     */     
/* 259 */     TIntArrayList merged = mergeCanonicalLists((Fragment<IntegerType, IntegerType>[])arrayOfFragment);
/* 260 */     for (int j = 1; j < numTasks; j++)
/* 261 */       arrayOfFragment[j].linkToPreviousFragment(arrayOfFragment[j - 1], merged); 
/* 262 */     int numComponents = splitCanonicalLists((Fragment<IntegerType, IntegerType>[])arrayOfFragment, merged);
/*     */     
/* 264 */     for (Fragment<T, L> fragment : arrayOfFragment) {
/*     */       
/* 266 */       futures.add(service.submit(new Runnable()
/*     */             {
/*     */               
/*     */               public void run()
/*     */               {
/* 271 */                 fragment.relabel();
/*     */               }
/*     */             }));
/*     */     } 
/* 275 */     getAllFutures(futures);
/*     */     
/* 277 */     return numComponents;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class Fragment<T extends IntegerType<T>, L extends IntegerType<L>>
/*     */   {
/*     */     private final int n;
/*     */ 
/*     */     
/*     */     private final TIntArrayList canonicalLabels;
/*     */     
/*     */     private final RandomAccessible<T> input;
/*     */     
/*     */     private final RandomAccessibleInterval<L> output;
/*     */     
/*     */     private final ConnectedComponents.CollectNeighborLabels<L> collectNeighborLabels;
/*     */     
/*     */     private int offset;
/*     */ 
/*     */     
/*     */     public Fragment(RandomAccessible<T> input, RandomAccessibleInterval<L> output, ConnectedComponents.CollectNeighborLabels<L> collectNeighborLabels) {
/* 299 */       this.n = output.numDimensions();
/* 300 */       this.input = input;
/* 301 */       this.output = output;
/* 302 */       this.collectNeighborLabels = collectNeighborLabels;
/* 303 */       this.canonicalLabels = new TIntArrayList(1000);
/* 304 */       this.canonicalLabels.add(0);
/*     */     }
/*     */ 
/*     */     
/*     */     public void mark() {
/* 309 */       long[] min = new long[this.n];
/* 310 */       long[] max = new long[this.n];
/* 311 */       this.output.min(min);
/* 312 */       this.output.max(max);
/*     */ 
/*     */       
/* 315 */       TIntArrayList neighborLabels = new TIntArrayList(this.n);
/*     */       
/* 317 */       TIntArrayList updateLabels = new TIntArrayList(10);
/*     */       
/* 319 */       Cursor<T> in = Views.flatIterable((RandomAccessibleInterval)Views.interval(this.input, (Interval)this.output)).localizingCursor();
/* 320 */       RandomAccess<L> la = this.output.randomAccess();
/*     */       
/* 322 */       while (in.hasNext()) {
/*     */         
/* 324 */         if (((IntegerType)in.next()).getInteger() > 0) {
/*     */           
/* 326 */           la.setPosition((Localizable)in);
/* 327 */           this.collectNeighborLabels.collect(la, neighborLabels, min, max);
/* 328 */           int numLabeledNeighbors = neighborLabels.size();
/* 329 */           if (numLabeledNeighbors == 0) {
/*     */ 
/*     */             
/* 332 */             int label = this.canonicalLabels.size();
/* 333 */             this.canonicalLabels.add(label);
/* 334 */             ((IntegerType)la.get()).setInteger(label); continue;
/*     */           } 
/* 336 */           if (numLabeledNeighbors == 1) {
/*     */             
/* 338 */             ((IntegerType)la.get()).setInteger(this.canonicalLabels.get(neighborLabels.get(0)));
/*     */             
/*     */             continue;
/*     */           } 
/*     */           
/* 343 */           int canonical = this.canonicalLabels.get(neighborLabels.get(0));
/* 344 */           boolean makeCanonical = false; int i;
/* 345 */           for (i = 1; i < neighborLabels.size(); i++) {
/*     */             
/* 347 */             if (this.canonicalLabels.get(neighborLabels.get(i)) != canonical) {
/*     */               
/* 349 */               makeCanonical = true;
/*     */               break;
/*     */             } 
/*     */           } 
/* 353 */           if (makeCanonical) {
/*     */             
/* 355 */             updateLabels.clear();
/* 356 */             canonical = Integer.MAX_VALUE;
/* 357 */             for (i = 0; i < neighborLabels.size(); i++) {
/*     */               
/* 359 */               int label = neighborLabels.get(i);
/* 360 */               while (this.canonicalLabels.get(label) != label) {
/*     */                 
/* 362 */                 updateLabels.add(label);
/* 363 */                 canonical = Math.min(canonical, label);
/* 364 */                 label = this.canonicalLabels.get(label);
/*     */               } 
/* 366 */               updateLabels.add(label);
/* 367 */               canonical = Math.min(canonical, label);
/*     */             } 
/* 369 */             for (i = 0; i < updateLabels.size(); i++)
/* 370 */               this.canonicalLabels.set(updateLabels.get(i), canonical); 
/*     */           } 
/* 372 */           ((IntegerType)la.get()).setInteger(canonical);
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void linkToPreviousFragment(Fragment<T, L> previous, TIntArrayList merged) {
/* 380 */       int previousOffset = previous.offset;
/* 381 */       int splitDim = this.n - 1;
/* 382 */       long[] min = new long[this.n];
/* 383 */       long[] max = new long[this.n];
/* 384 */       this.output.min(min);
/* 385 */       this.output.max(max);
/* 386 */       max[splitDim] = min[splitDim];
/*     */ 
/*     */       
/* 389 */       TIntArrayList neighborLabels = new TIntArrayList(this.n);
/*     */       
/* 391 */       TIntArrayList updateLabels = new TIntArrayList(10);
/*     */       
/* 393 */       Cursor<L> in = Views.iterable((RandomAccessibleInterval)Views.interval((RandomAccessible)this.output, min, max)).localizingCursor();
/* 394 */       min[splitDim] = min[splitDim] - 1L;
/* 395 */       RandomAccess<L> la = this.output.randomAccess((Interval)new FinalInterval(min, max));
/*     */       
/* 397 */       while (in.hasNext()) {
/*     */         
/* 399 */         int label = ((IntegerType)in.next()).getInteger();
/* 400 */         if (label != 0) {
/*     */           
/* 402 */           label += this.offset;
/* 403 */           la.setPosition((Localizable)in);
/* 404 */           this.collectNeighborLabels.collectAtPreviousFragmentBorder(la, neighborLabels, min, max);
/* 405 */           int numLabeledNeighbors = neighborLabels.size();
/* 406 */           if (numLabeledNeighbors != 0) {
/*     */             
/* 408 */             for (int i = 0; i < numLabeledNeighbors; i++)
/* 409 */               neighborLabels.set(i, neighborLabels.get(i) + previousOffset); 
/* 410 */             int canonical = merged.get(label);
/* 411 */             boolean makeCanonical = false; int j;
/* 412 */             for (j = 0; j < neighborLabels.size(); j++) {
/*     */               
/* 414 */               if (merged.get(neighborLabels.get(j)) != canonical) {
/*     */                 
/* 416 */                 neighborLabels.add(label);
/* 417 */                 makeCanonical = true;
/*     */                 break;
/*     */               } 
/*     */             } 
/* 421 */             if (makeCanonical) {
/*     */               
/* 423 */               updateLabels.clear();
/* 424 */               canonical = Integer.MAX_VALUE;
/* 425 */               for (j = 0; j < neighborLabels.size(); j++) {
/*     */                 
/* 427 */                 label = neighborLabels.get(j);
/* 428 */                 while (merged.get(label) != label) {
/*     */                   
/* 430 */                   updateLabels.add(label);
/* 431 */                   canonical = Math.min(canonical, label);
/* 432 */                   label = merged.get(label);
/*     */                 } 
/* 434 */                 updateLabels.add(label);
/* 435 */                 canonical = Math.min(canonical, label);
/*     */               } 
/* 437 */               for (j = 0; j < updateLabels.size(); j++) {
/* 438 */                 merged.set(updateLabels.get(j), canonical);
/*     */               }
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     }
/*     */     
/*     */     public void relabel() {
/* 447 */       for (IntegerType integerType : Views.iterable(this.output)) {
/* 448 */         integerType.setInteger(this.canonicalLabels.get(integerType.getInteger()));
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private static <T extends IntegerType<T>, L extends IntegerType<L>> TIntArrayList mergeCanonicalLists(Fragment<T, L>[] fragments) {
/* 454 */     int size = 0;
/* 455 */     for (Fragment<T, L> fragment : fragments) {
/*     */       
/* 457 */       fragment.offset = size;
/* 458 */       size += fragment.canonicalLabels.size() - 1;
/*     */     } 
/* 460 */     TIntArrayList merged = new TIntArrayList(size + 1);
/* 461 */     merged.add(0);
/* 462 */     for (Fragment<T, L> fragment : fragments) {
/*     */       
/* 464 */       TIntArrayList fl = fragment.canonicalLabels;
/* 465 */       int o = fragment.offset;
/* 466 */       for (int i = 1; i < fl.size(); i++)
/* 467 */         merged.add(fl.get(i) + o); 
/*     */     } 
/* 469 */     return merged;
/*     */   }
/*     */ 
/*     */   
/*     */   private static <T extends IntegerType<T>, L extends IntegerType<L>> int splitCanonicalLists(Fragment<T, L>[] fragments, TIntArrayList merged) {
/* 474 */     int nextLabel = 1;
/* 475 */     for (int i = 1; i < merged.size(); i++) {
/* 476 */       if (merged.get(i) == i) {
/* 477 */         merged.set(i, nextLabel++);
/*     */       } else {
/* 479 */         merged.set(i, merged.get(merged.get(i)));
/*     */       } 
/* 481 */     }  for (Fragment<T, L> fragment : fragments) {
/*     */       
/* 483 */       TIntArrayList fl = fragment.canonicalLabels;
/* 484 */       int o = fragment.offset;
/* 485 */       for (int j = 1; j < fl.size(); j++) {
/* 486 */         fl.set(j, merged.get(j + o));
/*     */       }
/*     */     } 
/* 489 */     return nextLabel - 1;
/*     */   }
/*     */ 
/*     */   
/*     */   private static void getAllFutures(List<Future<?>> futures) {
/* 494 */     for (Future<?> future : futures) {
/*     */ 
/*     */       
/*     */       try {
/* 498 */         future.get();
/*     */       }
/* 500 */       catch (InterruptedException e) {
/*     */         
/* 502 */         e.printStackTrace();
/*     */       }
/* 504 */       catch (ExecutionException e) {
/*     */         
/* 506 */         e.printStackTrace();
/*     */       } 
/*     */     } 
/* 509 */     futures.clear();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class Collect4NeighborLabels<L extends IntegerType<L>>
/*     */     implements CollectNeighborLabels<L>
/*     */   {
/*     */     private final int n;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private Collect4NeighborLabels(int n) {
/* 530 */       this.n = n;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void collect(RandomAccess<L> la, TIntArrayList neighborLabels, long[] labelsMin, long[] labelsMax) {
/* 536 */       neighborLabels.clear();
/* 537 */       for (int d = 0; d < this.n; d++) {
/*     */         
/* 539 */         if (la.getLongPosition(d) > labelsMin[d]) {
/*     */           
/* 541 */           la.bck(d);
/* 542 */           int l = ((IntegerType)la.get()).getInteger();
/* 543 */           if (l != 0)
/* 544 */             neighborLabels.add(l); 
/* 545 */           la.fwd(d);
/*     */         } 
/*     */       } 
/*     */     }
/*     */     
/* 550 */     private static final ConnectedComponents.CollectNeighborLabelsFactory factory = new ConnectedComponents.CollectNeighborLabelsFactory()
/*     */       {
/*     */         
/*     */         public <L extends IntegerType<L>> ConnectedComponents.CollectNeighborLabels<L> newInstance(int n)
/*     */         {
/* 555 */           return new ConnectedComponents.Collect4NeighborLabels<>(n);
/*     */         }
/*     */       };
/*     */ 
/*     */ 
/*     */     
/*     */     public void collectAtPreviousFragmentBorder(RandomAccess<L> la, TIntArrayList neighborLabels, long[] labelsMin, long[] labelsMax) {
/* 562 */       neighborLabels.clear();
/* 563 */       la.bck(this.n - 1);
/* 564 */       int l = ((IntegerType)la.get()).getInteger();
/* 565 */       if (l != 0)
/* 566 */         neighborLabels.add(l); 
/* 567 */       la.fwd(this.n - 1);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class Collect8NeighborLabels<L extends IntegerType<L>>
/*     */     implements CollectNeighborLabels<L>
/*     */   {
/*     */     private final int n;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final long[][] offsets;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final long[] pos;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final long[] previousFragmentPos;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final int numPreviousFragmentOffsets;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private Collect8NeighborLabels(int n) {
/*     */       // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: invokespecial <init> : ()V
/*     */       //   4: aload_0
/*     */       //   5: iload_1
/*     */       //   6: putfield n : I
/*     */       //   9: iconst_0
/*     */       //   10: istore_2
/*     */       //   11: iconst_0
/*     */       //   12: istore_3
/*     */       //   13: iload_3
/*     */       //   14: iload_1
/*     */       //   15: if_icmpge -> 30
/*     */       //   18: iconst_3
/*     */       //   19: iload_2
/*     */       //   20: imul
/*     */       //   21: iconst_1
/*     */       //   22: iadd
/*     */       //   23: istore_2
/*     */       //   24: iinc #3, 1
/*     */       //   27: goto -> 13
/*     */       //   30: aload_0
/*     */       //   31: ldc2_w 3.0
/*     */       //   34: iload_1
/*     */       //   35: iconst_1
/*     */       //   36: isub
/*     */       //   37: i2d
/*     */       //   38: invokestatic pow : (DD)D
/*     */       //   41: d2i
/*     */       //   42: putfield numPreviousFragmentOffsets : I
/*     */       //   45: aload_0
/*     */       //   46: iload_2
/*     */       //   47: anewarray [J
/*     */       //   50: putfield offsets : [[J
/*     */       //   53: aload_0
/*     */       //   54: iload_1
/*     */       //   55: newarray long
/*     */       //   57: putfield pos : [J
/*     */       //   60: aload_0
/*     */       //   61: iload_1
/*     */       //   62: newarray long
/*     */       //   64: putfield previousFragmentPos : [J
/*     */       //   67: iload_1
/*     */       //   68: newarray long
/*     */       //   70: astore_3
/*     */       //   71: aload_3
/*     */       //   72: ldc2_w -1
/*     */       //   75: invokestatic fill : ([JJ)V
/*     */       //   78: iload_1
/*     */       //   79: newarray long
/*     */       //   81: astore #4
/*     */       //   83: aload #4
/*     */       //   85: lconst_1
/*     */       //   86: invokestatic fill : ([JJ)V
/*     */       //   89: new net/imglib2/iterator/IntervalIterator
/*     */       //   92: dup
/*     */       //   93: new net/imglib2/FinalInterval
/*     */       //   96: dup
/*     */       //   97: aload_3
/*     */       //   98: aload #4
/*     */       //   100: invokespecial <init> : ([J[J)V
/*     */       //   103: invokespecial <init> : (Lnet/imglib2/Interval;)V
/*     */       //   106: astore #5
/*     */       //   108: iconst_0
/*     */       //   109: istore #6
/*     */       //   111: iload #6
/*     */       //   113: aload_0
/*     */       //   114: getfield offsets : [[J
/*     */       //   117: arraylength
/*     */       //   118: if_icmpge -> 287
/*     */       //   121: aload_0
/*     */       //   122: getfield offsets : [[J
/*     */       //   125: iload #6
/*     */       //   127: iload_1
/*     */       //   128: newarray long
/*     */       //   130: aastore
/*     */       //   131: aload #5
/*     */       //   133: invokevirtual fwd : ()V
/*     */       //   136: aload #5
/*     */       //   138: aload_0
/*     */       //   139: getfield offsets : [[J
/*     */       //   142: iload #6
/*     */       //   144: aaload
/*     */       //   145: invokevirtual localize : ([J)V
/*     */       //   148: iload_1
/*     */       //   149: iconst_1
/*     */       //   150: isub
/*     */       //   151: istore #7
/*     */       //   153: iload #7
/*     */       //   155: iflt -> 182
/*     */       //   158: aload_0
/*     */       //   159: getfield offsets : [[J
/*     */       //   162: iload #6
/*     */       //   164: aaload
/*     */       //   165: iload #7
/*     */       //   167: laload
/*     */       //   168: lconst_0
/*     */       //   169: lcmp
/*     */       //   170: ifge -> 176
/*     */       //   173: goto -> 185
/*     */       //   176: iinc #7, -1
/*     */       //   179: goto -> 153
/*     */       //   182: goto -> 131
/*     */       //   185: iconst_0
/*     */       //   186: istore #7
/*     */       //   188: iload #7
/*     */       //   190: iload_1
/*     */       //   191: if_icmpge -> 240
/*     */       //   194: aload_0
/*     */       //   195: getfield offsets : [[J
/*     */       //   198: iload #6
/*     */       //   200: aaload
/*     */       //   201: iload #7
/*     */       //   203: dup2
/*     */       //   204: laload
/*     */       //   205: aload_0
/*     */       //   206: getfield pos : [J
/*     */       //   209: iload #7
/*     */       //   211: laload
/*     */       //   212: lsub
/*     */       //   213: lastore
/*     */       //   214: aload_0
/*     */       //   215: getfield pos : [J
/*     */       //   218: iload #7
/*     */       //   220: dup2
/*     */       //   221: laload
/*     */       //   222: aload_0
/*     */       //   223: getfield offsets : [[J
/*     */       //   226: iload #6
/*     */       //   228: aaload
/*     */       //   229: iload #7
/*     */       //   231: laload
/*     */       //   232: ladd
/*     */       //   233: lastore
/*     */       //   234: iinc #7, 1
/*     */       //   237: goto -> 188
/*     */       //   240: iload #6
/*     */       //   242: aload_0
/*     */       //   243: getfield numPreviousFragmentOffsets : I
/*     */       //   246: iconst_1
/*     */       //   247: isub
/*     */       //   248: if_icmpne -> 281
/*     */       //   251: iconst_0
/*     */       //   252: istore #7
/*     */       //   254: iload #7
/*     */       //   256: iload_1
/*     */       //   257: if_icmpge -> 281
/*     */       //   260: aload_0
/*     */       //   261: getfield previousFragmentPos : [J
/*     */       //   264: iload #7
/*     */       //   266: aload_0
/*     */       //   267: getfield pos : [J
/*     */       //   270: iload #7
/*     */       //   272: laload
/*     */       //   273: lneg
/*     */       //   274: lastore
/*     */       //   275: iinc #7, 1
/*     */       //   278: goto -> 254
/*     */       //   281: iinc #6, 1
/*     */       //   284: goto -> 111
/*     */       //   287: iconst_0
/*     */       //   288: istore #6
/*     */       //   290: iload #6
/*     */       //   292: iload_1
/*     */       //   293: if_icmpge -> 317
/*     */       //   296: aload_0
/*     */       //   297: getfield pos : [J
/*     */       //   300: iload #6
/*     */       //   302: aload_0
/*     */       //   303: getfield pos : [J
/*     */       //   306: iload #6
/*     */       //   308: laload
/*     */       //   309: lneg
/*     */       //   310: lastore
/*     */       //   311: iinc #6, 1
/*     */       //   314: goto -> 290
/*     */       //   317: return
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #584	-> 0
/*     */       //   #585	-> 4
/*     */       //   #586	-> 9
/*     */       //   #587	-> 11
/*     */       //   #588	-> 18
/*     */       //   #587	-> 24
/*     */       //   #589	-> 30
/*     */       //   #590	-> 45
/*     */       //   #591	-> 53
/*     */       //   #592	-> 60
/*     */       //   #593	-> 67
/*     */       //   #594	-> 71
/*     */       //   #595	-> 78
/*     */       //   #596	-> 83
/*     */       //   #597	-> 89
/*     */       //   #598	-> 108
/*     */       //   #600	-> 121
/*     */       //   #603	-> 131
/*     */       //   #604	-> 136
/*     */       //   #605	-> 148
/*     */       //   #606	-> 158
/*     */       //   #607	-> 173
/*     */       //   #605	-> 176
/*     */       //   #609	-> 185
/*     */       //   #611	-> 194
/*     */       //   #612	-> 214
/*     */       //   #609	-> 234
/*     */       //   #614	-> 240
/*     */       //   #615	-> 251
/*     */       //   #616	-> 260
/*     */       //   #615	-> 275
/*     */       //   #598	-> 281
/*     */       //   #618	-> 287
/*     */       //   #619	-> 296
/*     */       //   #618	-> 311
/*     */       //   #620	-> 317
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   13	17	3	d	I
/*     */       //   153	29	7	d	I
/*     */       //   188	52	7	d	I
/*     */       //   254	27	7	d	I
/*     */       //   111	176	6	i	I
/*     */       //   290	27	6	d	I
/*     */       //   0	318	0	this	Lnet/imglib2/algorithm/labeling/ConnectedComponents$Collect8NeighborLabels;
/*     */       //   0	318	1	n	I
/*     */       //   11	307	2	nOffsets	I
/*     */       //   71	247	3	min	[J
/*     */       //   83	235	4	max	[J
/*     */       //   108	210	5	idx	Lnet/imglib2/iterator/IntervalIterator;
/*     */       // Local variable type table:
/*     */       //   start	length	slot	name	signature
/*     */       //   0	318	0	this	Lnet/imglib2/algorithm/labeling/ConnectedComponents$Collect8NeighborLabels<TL;>;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void collect(RandomAccess<L> la, TIntArrayList neighborLabels, long[] labelsMin, long[] labelsMax) {
/* 625 */       for (int d = 0; d < this.n; d++) {
/* 626 */         if (la.getLongPosition(d) <= labelsMin[d] || la.getLongPosition(d) >= labelsMax[d]) {
/*     */           
/* 628 */           collectChecked(la, neighborLabels, labelsMin, labelsMax); return;
/*     */         } 
/*     */       } 
/* 631 */       collectUnchecked(la, neighborLabels);
/*     */     }
/*     */ 
/*     */     
/*     */     private void collectChecked(RandomAccess<L> la, TIntArrayList neighborLabels, long[] labelsMin, long[] labelsMax) {
/* 636 */       neighborLabels.clear(); int i;
/* 637 */       label20: for (i = 0; i < this.offsets.length; i++) {
/*     */         
/* 639 */         la.move(this.offsets[i]);
/* 640 */         for (int d = 0; d < this.n; ) {
/* 641 */           if (la.getLongPosition(d) >= labelsMin[d]) { if (la.getLongPosition(d) > labelsMax[d])
/*     */               continue label20;  d++; }  continue label20;
/* 643 */         }  int l = ((IntegerType)la.get()).getInteger();
/* 644 */         if (l != 0)
/* 645 */           neighborLabels.add(l); 
/*     */       } 
/* 647 */       la.move(this.pos);
/*     */     }
/*     */ 
/*     */     
/*     */     private void collectUnchecked(RandomAccess<L> la, TIntArrayList neighborLabels) {
/* 652 */       neighborLabels.clear();
/* 653 */       for (int i = 0; i < this.offsets.length; i++) {
/*     */         
/* 655 */         la.move(this.offsets[i]);
/* 656 */         int l = ((IntegerType)la.get()).getInteger();
/* 657 */         if (l != 0)
/* 658 */           neighborLabels.add(l); 
/*     */       } 
/* 660 */       la.move(this.pos);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void collectAtPreviousFragmentBorder(RandomAccess<L> la, TIntArrayList neighborLabels, long[] labelsMin, long[] labelsMax) {
/* 666 */       for (int d = 0; d < this.n - 1; d++) {
/* 667 */         if (la.getLongPosition(d) <= labelsMin[d] || la.getLongPosition(d) >= labelsMax[d]) {
/*     */           
/* 669 */           collectAtPreviousFragmentBorderChecked(la, neighborLabels, labelsMin, labelsMax); return;
/*     */         } 
/*     */       } 
/* 672 */       collectAtPreviousFragmentBorderUnchecked(la, neighborLabels);
/*     */     }
/*     */ 
/*     */     
/*     */     private void collectAtPreviousFragmentBorderChecked(RandomAccess<L> la, TIntArrayList neighborLabels, long[] labelsMin, long[] labelsMax) {
/* 677 */       neighborLabels.clear(); int i;
/* 678 */       label20: for (i = 0; i < this.numPreviousFragmentOffsets; i++) {
/*     */         
/* 680 */         la.move(this.offsets[i]);
/* 681 */         for (int d = 0; d < this.n - 1; ) {
/* 682 */           if (la.getLongPosition(d) >= labelsMin[d]) { if (la.getLongPosition(d) > labelsMax[d])
/*     */               continue label20;  d++; }  continue label20;
/* 684 */         }  int l = ((IntegerType)la.get()).getInteger();
/* 685 */         if (l != 0)
/* 686 */           neighborLabels.add(l); 
/*     */       } 
/* 688 */       la.move(this.previousFragmentPos);
/*     */     }
/*     */ 
/*     */     
/*     */     private void collectAtPreviousFragmentBorderUnchecked(RandomAccess<L> la, TIntArrayList neighborLabels) {
/* 693 */       neighborLabels.clear();
/* 694 */       for (int i = 0; i < this.numPreviousFragmentOffsets; i++) {
/*     */         
/* 696 */         la.move(this.offsets[i]);
/* 697 */         int l = ((IntegerType)la.get()).getInteger();
/* 698 */         if (l != 0)
/* 699 */           neighborLabels.add(l); 
/*     */       } 
/* 701 */       la.move(this.previousFragmentPos);
/*     */     }
/*     */     
/* 704 */     private static final ConnectedComponents.CollectNeighborLabelsFactory factory = new ConnectedComponents.CollectNeighborLabelsFactory()
/*     */       {
/*     */         
/*     */         public <L extends IntegerType<L>> ConnectedComponents.CollectNeighborLabels<L> newInstance(int n)
/*     */         {
/* 709 */           return new ConnectedComponents.Collect8NeighborLabels<>(n);
/*     */         }
/*     */       };
/*     */   }
/*     */   
/*     */   private static interface CollectNeighborLabelsFactory {
/*     */     <L extends IntegerType<L>> ConnectedComponents.CollectNeighborLabels<L> newInstance(int param1Int);
/*     */   }
/*     */   
/*     */   private static interface CollectNeighborLabels<L extends IntegerType<L>> {
/*     */     void collect(RandomAccess<L> param1RandomAccess, TIntArrayList param1TIntArrayList, long[] param1ArrayOflong1, long[] param1ArrayOflong2);
/*     */     
/*     */     void collectAtPreviousFragmentBorder(RandomAccess<L> param1RandomAccess, TIntArrayList param1TIntArrayList, long[] param1ArrayOflong1, long[] param1ArrayOflong2);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/imglib2-algorithm-0.6.2.jar!/net/imglib2/algorithm/labeling/ConnectedComponents.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */