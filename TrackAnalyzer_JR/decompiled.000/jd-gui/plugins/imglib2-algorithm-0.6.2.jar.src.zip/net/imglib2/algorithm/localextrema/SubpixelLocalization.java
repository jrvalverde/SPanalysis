/*     */ package net.imglib2.algorithm.localextrema;
/*     */ 
/*     */ import Jama.LUDecomposition;
/*     */ import Jama.Matrix;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.Executors;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import net.imglib2.FinalInterval;
/*     */ import net.imglib2.Interval;
/*     */ import net.imglib2.Localizable;
/*     */ import net.imglib2.Point;
/*     */ import net.imglib2.RandomAccess;
/*     */ import net.imglib2.RandomAccessible;
/*     */ import net.imglib2.RealLocalizable;
/*     */ import net.imglib2.RealPoint;
/*     */ import net.imglib2.RealPositionable;
/*     */ import net.imglib2.type.numeric.RealType;
/*     */ import net.imglib2.util.Intervals;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SubpixelLocalization<P extends Localizable, T extends RealType<T>>
/*     */ {
/*  77 */   protected int maxNumMoves = 4;
/*     */   
/*     */   protected boolean allowMaximaTolerance = false;
/*     */   
/*     */   protected boolean canMoveOutside = false;
/*     */   
/*  83 */   protected float maximaTolerance = 0.01F;
/*     */ 
/*     */   
/*     */   protected boolean[] allowedToMoveInDim;
/*     */   
/*     */   protected boolean returnInvalidPeaks = false;
/*     */   
/*     */   protected int numThreads;
/*     */ 
/*     */   
/*     */   public SubpixelLocalization(int numDimensions) {
/*  94 */     this.allowedToMoveInDim = new boolean[numDimensions];
/*  95 */     Arrays.fill(this.allowedToMoveInDim, true);
/*     */     
/*  97 */     this.numThreads = Runtime.getRuntime().availableProcessors();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAllowMaximaTolerance(boolean allowMaximaTolerance) {
/* 102 */     this.allowMaximaTolerance = allowMaximaTolerance;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setCanMoveOutside(boolean canMoveOutside) {
/* 107 */     this.canMoveOutside = canMoveOutside;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setMaximaTolerance(float maximaTolerance) {
/* 112 */     this.maximaTolerance = maximaTolerance;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setMaxNumMoves(int maxNumMoves) {
/* 117 */     this.maxNumMoves = maxNumMoves;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAllowedToMoveInDim(boolean[] allowedToMoveInDim) {
/* 122 */     this.allowedToMoveInDim = (boolean[])allowedToMoveInDim.clone();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setReturnInvalidPeaks(boolean returnInvalidPeaks) {
/* 127 */     this.returnInvalidPeaks = returnInvalidPeaks;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setNumThreads(int numThreads) {
/* 132 */     this.numThreads = numThreads;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean getAllowMaximaTolerance() {
/* 137 */     return this.allowMaximaTolerance;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean getCanMoveOutside() {
/* 142 */     return this.canMoveOutside;
/*     */   }
/*     */ 
/*     */   
/*     */   public float getMaximaTolerance() {
/* 147 */     return this.maximaTolerance;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getMaxNumMoves() {
/* 152 */     return this.maxNumMoves;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean[] getAllowedToMoveInDim() {
/* 157 */     return (boolean[])this.allowedToMoveInDim.clone();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean getReturnInvalidPeaks() {
/* 162 */     return this.returnInvalidPeaks;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getNumThreads() {
/* 167 */     return this.numThreads;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ArrayList<RefinedPeak<P>> process(List<P> peaks, RandomAccessible<T> img, Interval validInterval) {
/* 187 */     return refinePeaks(peaks, img, validInterval, this.returnInvalidPeaks, this.maxNumMoves, this.allowMaximaTolerance, this.maximaTolerance, this.allowedToMoveInDim, this.numThreads);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends RealType<T>, P extends Localizable> ArrayList<RefinedPeak<P>> refinePeaks(final List<P> peaks, final RandomAccessible<T> img, final Interval validInterval, final boolean returnInvalidPeaks, final int maxNumMoves, final boolean allowMaximaTolerance, final float maximaTolerance, final boolean[] allowedToMoveInDim, int numThreads) {
/* 234 */     int numPeaks = peaks.size();
/* 235 */     ArrayList<RefinedPeak<P>> allRefinedPeaks = new ArrayList<>(numPeaks);
/*     */     
/* 237 */     if (numPeaks == 0) {
/* 238 */       return allRefinedPeaks;
/*     */     }
/* 240 */     int numTasks = (numThreads <= 1) ? 1 : Math.min(numPeaks, numThreads * 20);
/* 241 */     int taskSize = numPeaks / numTasks;
/*     */     
/* 243 */     ExecutorService ex = Executors.newFixedThreadPool(numThreads);
/* 244 */     final List<RefinedPeak<P>> synchronizedAllRefinedPeaks = Collections.synchronizedList(allRefinedPeaks);
/* 245 */     for (int taskNum = 0; taskNum < numTasks; taskNum++) {
/*     */       
/* 247 */       final int fromIndex = taskNum * taskSize;
/* 248 */       final int toIndex = (taskNum == numTasks - 1) ? numPeaks : (fromIndex + taskSize);
/* 249 */       Runnable r = new Runnable()
/*     */         {
/*     */           
/*     */           public void run()
/*     */           {
/* 254 */             ArrayList<RefinedPeak<P>> refinedPeaks = (ArrayList)SubpixelLocalization.refinePeaks(peaks
/* 255 */                 .subList(fromIndex, toIndex), img, validInterval, returnInvalidPeaks, maxNumMoves, allowMaximaTolerance, maximaTolerance, allowedToMoveInDim);
/*     */             
/* 257 */             synchronizedAllRefinedPeaks.addAll(refinedPeaks);
/*     */           }
/*     */         };
/* 260 */       ex.execute(r);
/*     */     } 
/* 262 */     ex.shutdown();
/*     */     
/*     */     try {
/* 265 */       ex.awaitTermination(1000L, TimeUnit.DAYS);
/*     */     }
/* 267 */     catch (InterruptedException e) {
/*     */       
/* 269 */       e.printStackTrace();
/*     */     } 
/*     */     
/* 272 */     return allRefinedPeaks;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends RealType<T>, P extends Localizable> ArrayList<RefinedPeak<P>> refinePeaks(List<P> peaks, RandomAccessible<T> img, Interval validInterval, boolean returnInvalidPeaks, int maxNumMoves, boolean allowMaximaTolerance, float maximaTolerance, boolean[] allowedToMoveInDim) {
/* 316 */     ArrayList<RefinedPeak<P>> refinedPeaks = new ArrayList<>();
/*     */     
/* 318 */     int n = img.numDimensions();
/*     */ 
/*     */     
/* 321 */     Point currentPosition = new Point(n);
/*     */ 
/*     */     
/* 324 */     Matrix g = new Matrix(n, 1);
/* 325 */     Matrix H = new Matrix(n, n);
/*     */ 
/*     */     
/* 328 */     RealPoint subpixelOffset = new RealPoint(n);
/*     */ 
/*     */     
/* 331 */     boolean canMoveOutside = (validInterval == null);
/* 332 */     FinalInterval finalInterval = canMoveOutside ? null : Intervals.expand(validInterval, -1L);
/*     */ 
/*     */     
/* 335 */     RandomAccess<T> access = canMoveOutside ? img.randomAccess() : img.randomAccess(validInterval);
/*     */     
/* 337 */     for (Localizable localizable : peaks) {
/*     */       
/* 339 */       currentPosition.setPosition(localizable);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 348 */       boolean foundStableMaxima = false;
/* 349 */       for (int numMoves = 0; numMoves < maxNumMoves; numMoves++) {
/*     */ 
/*     */         
/* 352 */         if (!canMoveOutside && !Intervals.contains((Interval)finalInterval, (Localizable)currentPosition)) {
/*     */           break;
/*     */         }
/*     */ 
/*     */         
/* 357 */         quadraticFitOffset((Localizable)currentPosition, access, g, H, (RealPositionable)subpixelOffset);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 374 */         foundStableMaxima = true;
/* 375 */         double threshold = allowMaximaTolerance ? (0.5D + (numMoves * maximaTolerance)) : 0.5D;
/* 376 */         for (int d = 0; d < n; d++) {
/*     */           
/* 378 */           double diff = subpixelOffset.getDoublePosition(d);
/* 379 */           if (Math.abs(diff) > threshold)
/*     */           {
/* 381 */             if (allowedToMoveInDim[d]) {
/*     */ 
/*     */               
/* 384 */               currentPosition.move((diff > 0.0D) ? 1 : -1, d);
/* 385 */               foundStableMaxima = false;
/*     */             } 
/*     */           }
/*     */         } 
/* 389 */         if (foundStableMaxima) {
/*     */           break;
/*     */         }
/*     */       } 
/*     */ 
/*     */       
/* 395 */       if (foundStableMaxima) {
/*     */ 
/*     */         
/* 398 */         double value = 0.0D;
/* 399 */         for (int d = 0; d < n; d++)
/*     */         {
/* 401 */           value += g.get(d, 0) * subpixelOffset.getDoublePosition(d);
/*     */         }
/* 403 */         value *= 0.5D;
/* 404 */         access.setPosition((Localizable)currentPosition);
/* 405 */         value += ((RealType)access.get()).getRealDouble();
/*     */ 
/*     */         
/* 408 */         subpixelOffset.move((Localizable)currentPosition);
/* 409 */         refinedPeaks.add(new RefinedPeak<>((P)localizable, (RealLocalizable)subpixelOffset, value, true)); continue;
/*     */       } 
/* 411 */       if (returnInvalidPeaks)
/*     */       {
/* 413 */         refinedPeaks.add(new RefinedPeak<>((P)localizable, (RealLocalizable)localizable, 0.0D, false));
/*     */       }
/*     */     } 
/*     */     
/* 417 */     return refinedPeaks;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static <T extends RealType<T>> void quadraticFitOffset(Localizable p, RandomAccess<T> access, Matrix g, Matrix H, RealPositionable offset) {
/* 442 */     int n = p.numDimensions();
/*     */     
/* 444 */     access.setPosition(p);
/* 445 */     double a1 = ((RealType)access.get()).getRealDouble();
/* 446 */     for (int d = 0; d < n; d++) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 460 */       access.bck(d);
/* 461 */       double a0 = ((RealType)access.get()).getRealDouble();
/* 462 */       access.move(2, d);
/* 463 */       double a2 = ((RealType)access.get()).getRealDouble();
/* 464 */       g.set(d, 0, (a2 - a0) * 0.5D);
/*     */ 
/*     */       
/* 467 */       access.bck(d);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 482 */       H.set(d, d, a2 - 2.0D * a1 + a0);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 497 */       for (int e = d + 1; e < n; e++) {
/*     */ 
/*     */         
/* 500 */         access.fwd(d);
/* 501 */         access.fwd(e);
/* 502 */         double a2b2 = ((RealType)access.get()).getRealDouble();
/* 503 */         access.move(-2, d);
/* 504 */         double a0b2 = ((RealType)access.get()).getRealDouble();
/* 505 */         access.move(-2, e);
/* 506 */         double a0b0 = ((RealType)access.get()).getRealDouble();
/* 507 */         access.move(2, d);
/* 508 */         double a2b0 = ((RealType)access.get()).getRealDouble();
/*     */         
/* 510 */         access.bck(d);
/* 511 */         access.fwd(e);
/* 512 */         double v = (a2b2 - a0b2 - a2b0 + a0b0) * 0.25D;
/* 513 */         H.set(d, e, v);
/* 514 */         H.set(e, d, v);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 519 */     LUDecomposition decomp = new LUDecomposition(H);
/* 520 */     if (decomp.isNonsingular()) {
/*     */       
/* 522 */       Matrix minusOffset = decomp.solve(g);
/* 523 */       for (int i = 0; i < n; i++)
/*     */       {
/* 525 */         offset.setPosition(-minusOffset.get(i, 0), i);
/*     */       }
/*     */     }
/*     */     else {
/*     */       
/* 530 */       for (int i = 0; i < n; i++)
/*     */       {
/* 532 */         offset.setPosition(0L, i);
/*     */       }
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/imglib2-algorithm-0.6.2.jar!/net/imglib2/algorithm/localextrema/SubpixelLocalization.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */