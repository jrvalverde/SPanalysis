/*     */ package net.imglib2.algorithm.gauss;
/*     */ 
/*     */ import net.imglib2.Iterator;
/*     */ import net.imglib2.Localizable;
/*     */ import net.imglib2.Point;
/*     */ import net.imglib2.Positionable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public abstract class AbstractLineIterator
/*     */   implements Iterator
/*     */ {
/*     */   long i;
/*     */   final int d;
/*     */   final long size;
/*     */   final Positionable positionable;
/*     */   final Localizable offset;
/*     */   
/*     */   public <A extends Localizable & Positionable> AbstractLineIterator(int dim, long size, A randomAccess) {
/*  74 */     this(dim, size, (Localizable)randomAccess, (Positionable)randomAccess);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AbstractLineIterator(int dim, long size, Localizable offset, Positionable positionable) {
/*  92 */     this.d = dim;
/*  93 */     this.size = size;
/*  94 */     this.positionable = positionable;
/*     */ 
/*     */     
/*  97 */     if (positionable == offset) {
/*  98 */       this.offset = (Localizable)new Point(offset);
/*     */     } else {
/* 100 */       this.offset = offset;
/*     */     } 
/* 102 */     positionable.setPosition(offset);
/*     */     
/* 104 */     reset();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Localizable getOffset() {
/* 117 */     return this.offset;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Positionable getPositionable() {
/* 130 */     return this.positionable;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void jumpFwd(long steps) {
/* 136 */     this.i += steps;
/* 137 */     this.positionable.move(steps, this.d);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void fwd() {
/* 143 */     this.i++;
/* 144 */     this.positionable.fwd(this.d);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void reset() {
/* 150 */     this.i = -1L;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasNext() {
/* 156 */     return (this.i < this.size);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/imglib2-algorithm-0.6.2.jar!/net/imglib2/algorithm/gauss/AbstractLineIterator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */