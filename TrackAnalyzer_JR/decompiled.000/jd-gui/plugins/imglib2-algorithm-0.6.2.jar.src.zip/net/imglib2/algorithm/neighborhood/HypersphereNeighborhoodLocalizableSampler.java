/*     */ package net.imglib2.algorithm.neighborhood;
/*     */ 
/*     */ import net.imglib2.AbstractEuclideanSpace;
/*     */ import net.imglib2.FinalInterval;
/*     */ import net.imglib2.Interval;
/*     */ import net.imglib2.Localizable;
/*     */ import net.imglib2.RandomAccessible;
/*     */ import net.imglib2.Sampler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class HypersphereNeighborhoodLocalizableSampler<T>
/*     */   extends AbstractEuclideanSpace
/*     */   implements Localizable, Sampler<Neighborhood<T>>
/*     */ {
/*     */   protected final RandomAccessible<T> source;
/*     */   protected final long radius;
/*     */   protected final Interval sourceInterval;
/*     */   protected final HyperSphereNeighborhoodFactory<T> neighborhoodFactory;
/*     */   protected final Neighborhood<T> currentNeighborhood;
/*     */   protected final long[] currentPos;
/*     */   
/*     */   public HypersphereNeighborhoodLocalizableSampler(RandomAccessible<T> source, long radius, HyperSphereNeighborhoodFactory<T> factory, Interval accessInterval) {
/*  60 */     super(source.numDimensions());
/*  61 */     this.source = source;
/*  62 */     this.radius = radius;
/*  63 */     this.neighborhoodFactory = factory;
/*  64 */     this.currentPos = new long[this.n];
/*  65 */     if (accessInterval == null) {
/*  66 */       this.sourceInterval = null;
/*     */     } else {
/*     */       
/*  69 */       long[] accessMin = new long[this.n];
/*  70 */       long[] accessMax = new long[this.n];
/*  71 */       accessInterval.min(accessMin);
/*  72 */       accessInterval.max(accessMax);
/*  73 */       for (int d = 0; d < this.n; d++) {
/*     */         
/*  75 */         accessMin[d] = accessMin[d] - radius;
/*  76 */         accessMax[d] = accessMax[d] + radius;
/*     */       } 
/*  78 */       this.sourceInterval = (Interval)new FinalInterval(accessMin, accessMax);
/*     */     } 
/*  80 */     this.currentNeighborhood = this.neighborhoodFactory.create(this.currentPos, radius, (this.sourceInterval == null) ? source
/*  81 */         .randomAccess() : source.randomAccess(this.sourceInterval));
/*     */   }
/*     */ 
/*     */   
/*     */   protected HypersphereNeighborhoodLocalizableSampler(HypersphereNeighborhoodLocalizableSampler<T> c) {
/*  86 */     super(c.n);
/*  87 */     this.source = c.source;
/*  88 */     this.radius = c.radius;
/*  89 */     this.sourceInterval = c.sourceInterval;
/*  90 */     this.neighborhoodFactory = c.neighborhoodFactory;
/*  91 */     this.currentPos = (long[])c.currentPos.clone();
/*  92 */     this.currentNeighborhood = this.neighborhoodFactory.create(this.currentPos, this.radius, (this.sourceInterval == null) ? this.source
/*  93 */         .randomAccess() : this.source.randomAccess(this.sourceInterval));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Neighborhood<T> get() {
/*  99 */     return this.currentNeighborhood;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void localize(int[] position) {
/* 105 */     this.currentNeighborhood.localize(position);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void localize(long[] position) {
/* 111 */     this.currentNeighborhood.localize(position);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getIntPosition(int d) {
/* 117 */     return this.currentNeighborhood.getIntPosition(d);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public long getLongPosition(int d) {
/* 123 */     return this.currentNeighborhood.getLongPosition(d);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void localize(float[] position) {
/* 129 */     this.currentNeighborhood.localize(position);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void localize(double[] position) {
/* 135 */     this.currentNeighborhood.localize(position);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public float getFloatPosition(int d) {
/* 141 */     return this.currentNeighborhood.getFloatPosition(d);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public double getDoublePosition(int d) {
/* 147 */     return this.currentNeighborhood.getDoublePosition(d);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/imglib2-algorithm-0.6.2.jar!/net/imglib2/algorithm/neighborhood/HypersphereNeighborhoodLocalizableSampler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */