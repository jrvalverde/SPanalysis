/*     */ package net.imglib2.algorithm.morphology;
/*     */ 
/*     */ import java.util.List;
/*     */ import net.imglib2.Dimensions;
/*     */ import net.imglib2.Interval;
/*     */ import net.imglib2.IterableInterval;
/*     */ import net.imglib2.RandomAccessible;
/*     */ import net.imglib2.RandomAccessibleInterval;
/*     */ import net.imglib2.algorithm.neighborhood.Shape;
/*     */ import net.imglib2.img.Img;
/*     */ import net.imglib2.img.ImgFactory;
/*     */ import net.imglib2.type.Type;
/*     */ import net.imglib2.type.numeric.RealType;
/*     */ import net.imglib2.type.operators.Sub;
/*     */ import net.imglib2.view.IntervalView;
/*     */ import net.imglib2.view.Views;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TopHat
/*     */ {
/*     */   public static <T extends RealType<T>> Img<T> topHat(Img<T> source, List<Shape> strels, int numThreads) {
/*  94 */     if (strels.isEmpty()) return source; 
/*  95 */     Img<T> opened = Opening.open(source, strels, numThreads);
/*  96 */     MorphologyUtils.subABA((RandomAccessible)opened, (IterableInterval)source, numThreads);
/*  97 */     return opened;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends Type<T> & Comparable<T> & Sub<T>> Img<T> topHat(Img<T> source, List<Shape> strels, T minVal, T maxVal, int numThreads) {
/* 146 */     Img<T> opened = (Img)Opening.open(source, strels, (Type)minVal, (Type)maxVal, numThreads);
/* 147 */     MorphologyUtils.subABA((RandomAccessible<Sub>)opened, (IterableInterval<Sub>)source, numThreads);
/* 148 */     return opened;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends RealType<T>> Img<T> topHat(Img<T> source, Shape strel, int numThreads) {
/* 177 */     Img<T> opened = Opening.open(source, strel, numThreads);
/* 178 */     MorphologyUtils.subABA((RandomAccessible)opened, (IterableInterval)source, numThreads);
/* 179 */     return opened;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends Type<T> & Comparable<T> & Sub<T>> Img<T> topHat(Img<T> source, Shape strel, T minVal, T maxVal, int numThreads) {
/* 223 */     Img<T> opened = (Img)Opening.open(source, strel, (Type)minVal, (Type)maxVal, numThreads);
/* 224 */     MorphologyUtils.subABA((RandomAccessible<Sub>)opened, (IterableInterval<Sub>)source, numThreads);
/* 225 */     return opened;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends RealType<T>> void topHat(RandomAccessible<T> source, IterableInterval<T> target, List<Shape> strels, int numThreads) {
/* 269 */     Opening.open(source, target, strels, numThreads);
/* 270 */     MorphologyUtils.subBAB((RandomAccessible)source, (IterableInterval)target, numThreads);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends Type<T> & Comparable<T> & Sub<T>> void topHat(RandomAccessible<T> source, IterableInterval<T> target, List<Shape> strels, T minVal, T maxVal, int numThreads) {
/* 330 */     Opening.open(source, target, strels, (Type)minVal, (Type)maxVal, numThreads);
/* 331 */     MorphologyUtils.subBAB(source, target, numThreads);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends RealType<T>> void topHat(RandomAccessible<T> source, IterableInterval<T> target, Shape strel, int numThreads) {
/* 369 */     Opening.open(source, target, strel, numThreads);
/* 370 */     MorphologyUtils.subBAB((RandomAccessible)source, (IterableInterval)target, numThreads);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends Type<T> & Comparable<T> & Sub<T>> void topHat(RandomAccessible<T> source, IterableInterval<T> target, Shape strel, T minVal, T maxVal, int numThreads) {
/* 424 */     Opening.open(source, target, strel, (Type)minVal, (Type)maxVal, numThreads);
/* 425 */     MorphologyUtils.subBAB(source, target, numThreads);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends RealType<T>> void topHatInPlace(RandomAccessible<T> source, Interval interval, List<Shape> strels, int numThreads) {
/* 465 */     RealType realType = MorphologyUtils.<RealType>createVariable(source, interval);
/* 466 */     ImgFactory<T> factory = MorphologyUtils.getSuitableFactory((Dimensions)interval, (T)realType);
/* 467 */     Img<T> img = factory.create((Dimensions)interval, realType);
/* 468 */     long[] min = new long[interval.numDimensions()];
/* 469 */     interval.min(min);
/* 470 */     IntervalView<T> translated = Views.translate((RandomAccessibleInterval)img, min);
/*     */     
/* 472 */     Opening.open(source, (IterableInterval<T>)translated, strels, numThreads);
/* 473 */     MorphologyUtils.subABA2((RandomAccessibleInterval)translated, (RandomAccessible)source, numThreads);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends Type<T> & Comparable<T> & Sub<T>> void topHatInPlace(RandomAccessible<T> source, Interval interval, List<Shape> strels, T minVal, T maxVal, int numThreads) {
/* 528 */     ImgFactory<T> factory = MorphologyUtils.getSuitableFactory((Dimensions)interval, minVal);
/* 529 */     Img<T> img = factory.create((Dimensions)interval, minVal);
/* 530 */     long[] min = new long[interval.numDimensions()];
/* 531 */     interval.min(min);
/* 532 */     IntervalView<T> translated = Views.translate((RandomAccessibleInterval)img, min);
/*     */     
/* 534 */     Opening.open(source, (IterableInterval<Type>)translated, strels, (Type)minVal, (Type)maxVal, numThreads);
/* 535 */     MorphologyUtils.subABA2((RandomAccessibleInterval<Sub>)translated, source, numThreads);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends RealType<T>> void topHatInPlace(RandomAccessible<T> source, Interval interval, Shape strel, int numThreads) {
/* 570 */     RealType realType = MorphologyUtils.<RealType>createVariable(source, interval);
/* 571 */     ImgFactory<T> factory = MorphologyUtils.getSuitableFactory((Dimensions)interval, (T)realType);
/* 572 */     Img<T> img = factory.create((Dimensions)interval, realType);
/* 573 */     long[] min = new long[interval.numDimensions()];
/* 574 */     interval.min(min);
/* 575 */     IntervalView<T> translated = Views.translate((RandomAccessibleInterval)img, min);
/*     */     
/* 577 */     Opening.open(source, (IterableInterval<T>)translated, strel, numThreads);
/* 578 */     MorphologyUtils.subABA2((RandomAccessibleInterval)translated, (RandomAccessible)source, numThreads);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends Type<T> & Comparable<T> & Sub<T>> void topHatInPlace(RandomAccessible<T> source, Interval interval, Shape strel, T minVal, T maxVal, int numThreads) {
/* 628 */     ImgFactory<T> factory = MorphologyUtils.getSuitableFactory((Dimensions)interval, minVal);
/* 629 */     Img<T> img = factory.create((Dimensions)interval, minVal);
/* 630 */     long[] min = new long[interval.numDimensions()];
/* 631 */     interval.min(min);
/* 632 */     IntervalView<T> translated = Views.translate((RandomAccessibleInterval)img, min);
/*     */     
/* 634 */     Opening.open(source, (IterableInterval<Type>)translated, strel, (Type)minVal, (Type)maxVal, numThreads);
/* 635 */     MorphologyUtils.subABA2((RandomAccessibleInterval<Sub>)translated, source, numThreads);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/imglib2-algorithm-0.6.2.jar!/net/imglib2/algorithm/morphology/TopHat.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */