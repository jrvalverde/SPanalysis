/*     */ package net.imglib2.algorithm.gauss3;
/*     */ 
/*     */ import net.imglib2.RandomAccess;
/*     */ import net.imglib2.img.array.ArrayImg;
/*     */ import net.imglib2.img.array.ArrayImgFactory;
/*     */ import net.imglib2.type.NativeType;
/*     */ import net.imglib2.type.Type;
/*     */ import net.imglib2.type.numeric.NumericType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ConvolverNativeType<T extends NumericType<T> & NativeType<T>>
/*     */   implements Runnable
/*     */ {
/*     */   private final double[] kernel;
/*     */   private final RandomAccess<T> in;
/*     */   private final RandomAccess<T> out;
/*     */   private final int d;
/*     */   private final int k;
/*     */   private final int k1;
/*     */   private final int k1k1;
/*     */   private final long linelen;
/*     */   final T b1;
/*     */   final T b2;
/*     */   final T tmp;
/*     */   
/*     */   public static <T extends NumericType<T> & NativeType<T>> ConvolverFactoryNativeType<T> factory(T type) {
/*  64 */     return new ConvolverFactoryNativeType<>(type);
/*     */   }
/*     */   
/*     */   public static final class ConvolverFactoryNativeType<T extends NumericType<T> & NativeType<T>>
/*     */     implements ConvolverFactory<T, T>
/*     */   {
/*     */     private final T type;
/*     */     
/*     */     public ConvolverFactoryNativeType(T type) {
/*  73 */       this.type = type;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Runnable create(double[] halfkernel, RandomAccess<T> in, RandomAccess<T> out, int d, long lineLength) {
/*  79 */       return new ConvolverNativeType<>(halfkernel, in, out, d, lineLength, (NumericType)this.type);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ConvolverNativeType(double[] kernel, RandomAccess<T> in, RandomAccess<T> out, int d, long lineLength, T type) {
/* 107 */     this.kernel = kernel;
/* 108 */     this.in = in;
/* 109 */     this.out = out;
/* 110 */     this.d = d;
/*     */     
/* 112 */     this.k = kernel.length;
/* 113 */     this.k1 = this.k - 1;
/* 114 */     this.k1k1 = this.k1 + this.k1;
/* 115 */     this.linelen = lineLength;
/*     */     
/* 117 */     int buflen = 2 * this.k - 1;
/* 118 */     ArrayImg<T, ?> buf = (new ArrayImgFactory()).create(new long[] { buflen }, (NativeType)type);
/* 119 */     this.b1 = (T)buf.randomAccess().get();
/* 120 */     this.b2 = (T)buf.randomAccess().get();
/*     */     
/* 122 */     this.tmp = (T)type.createVariable();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void next() {
/* 128 */     for (int i = 0; i < this.k1k1; i++) {
/*     */       
/* 130 */       ((NativeType)this.b2).updateIndex(i + 1);
/* 131 */       ((NativeType)this.b1).updateIndex(i);
/* 132 */       this.b1.set((Type)this.b2);
/*     */     } 
/*     */ 
/*     */     
/* 136 */     NumericType numericType = (NumericType)this.in.get();
/*     */ 
/*     */     
/* 139 */     this.tmp.set((Type)numericType);
/* 140 */     this.tmp.mul(this.kernel[0]);
/* 141 */     ((NativeType)this.b1).updateIndex(this.k1);
/* 142 */     this.b1.add(this.tmp);
/*     */ 
/*     */     
/* 145 */     for (int j = 1; j < this.k1; j++) {
/*     */       
/* 147 */       this.tmp.set((Type)numericType);
/* 148 */       this.tmp.mul(this.kernel[j]);
/* 149 */       ((NativeType)this.b1).updateIndex(this.k1 + j);
/* 150 */       this.b1.add(this.tmp);
/* 151 */       ((NativeType)this.b1).updateIndex(this.k1 - j);
/* 152 */       this.b1.add(this.tmp);
/*     */     } 
/*     */ 
/*     */     
/* 156 */     this.tmp.set((Type)numericType);
/* 157 */     this.tmp.mul(this.kernel[this.k1]);
/* 158 */     ((NativeType)this.b1).updateIndex(this.k1k1);
/* 159 */     this.b1.set((Type)this.tmp);
/*     */     
/* 161 */     this.in.fwd(this.d);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void run() {
/* 167 */     for (int j = 0; j < this.k1k1; j++)
/* 168 */       next(); 
/* 169 */     for (long i = 0L; i < this.linelen; i++) {
/*     */       
/* 171 */       next();
/* 172 */       ((NativeType)this.b1).updateIndex(0);
/* 173 */       this.b1.add(this.tmp);
/* 174 */       ((NumericType)this.out.get()).set((Type)this.b1);
/* 175 */       this.out.fwd(this.d);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/imglib2-algorithm-0.6.2.jar!/net/imglib2/algorithm/gauss3/ConvolverNativeType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */