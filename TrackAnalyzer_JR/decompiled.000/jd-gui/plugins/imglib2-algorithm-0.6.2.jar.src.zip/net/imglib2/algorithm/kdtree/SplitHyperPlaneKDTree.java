/*     */ package net.imglib2.algorithm.kdtree;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import net.imglib2.KDTree;
/*     */ import net.imglib2.KDTreeNode;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SplitHyperPlaneKDTree<T>
/*     */ {
/*     */   private final KDTree<T> tree;
/*     */   private final int n;
/*     */   private final double[] normal;
/*     */   private double m;
/*     */   private final double[] xmin;
/*     */   private final double[] xmax;
/*     */   private final ArrayList<KDTreeNode<T>> aboveNodes;
/*     */   private final ArrayList<KDTreeNode<T>> aboveSubtrees;
/*     */   private final ArrayList<KDTreeNode<T>> belowNodes;
/*     */   private final ArrayList<KDTreeNode<T>> belowSubtrees;
/*     */   
/*     */   public SplitHyperPlaneKDTree(KDTree<T> tree) {
/*  85 */     this.n = tree.numDimensions();
/*  86 */     this.xmin = new double[this.n];
/*  87 */     this.xmax = new double[this.n];
/*  88 */     this.normal = new double[this.n];
/*  89 */     this.tree = tree;
/*  90 */     this.aboveNodes = new ArrayList<>();
/*  91 */     this.aboveSubtrees = new ArrayList<>();
/*  92 */     this.belowNodes = new ArrayList<>();
/*  93 */     this.belowSubtrees = new ArrayList<>();
/*     */   }
/*     */ 
/*     */   
/*     */   public int numDimensions() {
/*  98 */     return this.n;
/*     */   }
/*     */ 
/*     */   
/*     */   public void split(HyperPlane plane) {
/* 103 */     initNewSearch();
/* 104 */     System.arraycopy(plane.getNormal(), 0, this.normal, 0, this.n);
/* 105 */     this.m = plane.getDistance();
/* 106 */     split(this.tree.getRoot());
/*     */   }
/*     */ 
/*     */   
/*     */   public void split(double[] plane) {
/* 111 */     initNewSearch();
/* 112 */     System.arraycopy(plane, 0, this.normal, 0, this.n);
/* 113 */     this.m = plane[this.n];
/* 114 */     split(this.tree.getRoot());
/*     */   }
/*     */ 
/*     */   
/*     */   private void initNewSearch() {
/* 119 */     this.aboveNodes.clear();
/* 120 */     this.aboveSubtrees.clear();
/* 121 */     this.belowNodes.clear();
/* 122 */     this.belowSubtrees.clear();
/* 123 */     this.tree.realMin(this.xmin);
/* 124 */     this.tree.realMax(this.xmax);
/*     */   }
/*     */ 
/*     */   
/*     */   public Iterable<KDTreeNode<T>> getAboveNodes() {
/* 129 */     return new KDTreeNodeIterable<>(this.aboveNodes, this.aboveSubtrees);
/*     */   }
/*     */ 
/*     */   
/*     */   public Iterable<KDTreeNode<T>> getBelowNodes() {
/* 134 */     return new KDTreeNodeIterable<>(this.belowNodes, this.belowSubtrees);
/*     */   }
/*     */ 
/*     */   
/*     */   private static <T> void addAll(KDTreeNode<T> node, ArrayList<KDTreeNode<T>> list) {
/* 139 */     list.add(node);
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean allAbove() {
/* 144 */     double dot = 0.0D;
/* 145 */     for (int d = 0; d < this.n; d++)
/* 146 */       dot += this.normal[d] * ((this.normal[d] >= 0.0D) ? this.xmin[d] : this.xmax[d]); 
/* 147 */     return (dot >= this.m);
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean allBelow() {
/* 152 */     double dot = 0.0D;
/* 153 */     for (int d = 0; d < this.n; d++)
/* 154 */       dot += this.normal[d] * ((this.normal[d] < 0.0D) ? this.xmin[d] : this.xmax[d]); 
/* 155 */     return (dot < this.m);
/*     */   }
/*     */ 
/*     */   
/*     */   private void splitSubtree(KDTreeNode<T> current, boolean p, boolean q) {
/* 160 */     if (p && q && allAbove()) {
/* 161 */       addAll(current, this.aboveSubtrees);
/* 162 */     } else if (!p && !q && allBelow()) {
/* 163 */       addAll(current, this.belowSubtrees);
/*     */     } else {
/* 165 */       split(current);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void split(KDTreeNode<T> current) {
/* 170 */     int sd = current.getSplitDimension();
/* 171 */     double sc = current.getSplitCoordinate();
/*     */     
/* 173 */     double dot = 0.0D;
/* 174 */     for (int d = 0; d < this.n; d++)
/* 175 */       dot += current.getDoublePosition(d) * this.normal[d]; 
/* 176 */     boolean p = (dot >= this.m);
/*     */ 
/*     */     
/* 179 */     if (p) {
/* 180 */       this.aboveNodes.add(current);
/*     */     } else {
/* 182 */       this.belowNodes.add(current);
/*     */     } 
/*     */     
/* 185 */     if (current.left != null) {
/*     */       
/* 187 */       double max = this.xmax[sd];
/* 188 */       this.xmax[sd] = sc;
/* 189 */       splitSubtree(current.left, p, (this.normal[sd] < 0.0D));
/* 190 */       this.xmax[sd] = max;
/*     */     } 
/*     */ 
/*     */     
/* 194 */     if (current.right != null) {
/*     */       
/* 196 */       double min = this.xmin[sd];
/* 197 */       this.xmin[sd] = sc;
/* 198 */       splitSubtree(current.right, p, (this.normal[sd] >= 0.0D));
/* 199 */       this.xmin[sd] = min;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/imglib2-algorithm-0.6.2.jar!/net/imglib2/algorithm/kdtree/SplitHyperPlaneKDTree.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */