/*     */ package net.imglib2.algorithm.stats;
/*     */ 
/*     */ import java.util.Vector;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ import net.imglib2.Cursor;
/*     */ import net.imglib2.IterableInterval;
/*     */ import net.imglib2.RandomAccessibleInterval;
/*     */ import net.imglib2.algorithm.Algorithm;
/*     */ import net.imglib2.algorithm.Benchmark;
/*     */ import net.imglib2.algorithm.MultiThreaded;
/*     */ import net.imglib2.multithreading.Chunk;
/*     */ import net.imglib2.multithreading.SimpleMultiThreading;
/*     */ import net.imglib2.type.Type;
/*     */ import net.imglib2.util.Util;
/*     */ import net.imglib2.view.Views;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ComputeMinMax<T extends Type<T> & Comparable<T>>
/*     */   implements Algorithm, MultiThreaded, Benchmark
/*     */ {
/*     */   final IterableInterval<T> image;
/*     */   final T min;
/*     */   final T max;
/*     */   
/*     */   public static final <T extends Comparable<T> & Type<T>> void computeMinMax(RandomAccessibleInterval<T> interval, T min, T max) {
/*  68 */     ComputeMinMax<T> c = (ComputeMinMax)new ComputeMinMax<>(Views.iterable(interval), (Type)min, (Type)max);
/*  69 */     c.process();
/*     */     
/*  71 */     ((Type)min).set((Type)c.getMin());
/*  72 */     ((Type)max).set((Type)c.getMax());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  79 */   String errorMessage = "";
/*     */   
/*     */   int numThreads;
/*     */   
/*     */   long processingTime;
/*     */ 
/*     */   
/*     */   public ComputeMinMax(IterableInterval<T> interval, T min, T max) {
/*  87 */     setNumThreads();
/*     */     
/*  89 */     this.image = interval;
/*     */     
/*  91 */     this.min = min;
/*  92 */     this.max = max;
/*     */   }
/*     */ 
/*     */   
/*     */   public T getMin() {
/*  97 */     return this.min;
/*     */   }
/*     */ 
/*     */   
/*     */   public T getMax() {
/* 102 */     return this.max;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean process() {
/* 108 */     long startTime = System.currentTimeMillis();
/*     */     
/* 110 */     long imageSize = this.image.size();
/*     */     
/* 112 */     final AtomicInteger ai = new AtomicInteger(0);
/* 113 */     Thread[] threads = SimpleMultiThreading.newThreads(getNumThreads());
/*     */     
/* 115 */     final Vector<Chunk> threadChunks = SimpleMultiThreading.divideIntoChunks(imageSize, this.numThreads);
/* 116 */     final Vector<T> minValues = new Vector<>();
/* 117 */     final Vector<T> maxValues = new Vector<>();
/*     */     
/* 119 */     for (int ithread = 0; ithread < threads.length; ithread++) {
/*     */       
/* 121 */       minValues.add((T)((Type)this.image.firstElement()).createVariable());
/* 122 */       maxValues.add((T)((Type)this.image.firstElement()).createVariable());
/*     */       
/* 124 */       threads[ithread] = new Thread(new Runnable()
/*     */           {
/*     */ 
/*     */             
/*     */             public void run()
/*     */             {
/* 130 */               int myNumber = ai.getAndIncrement();
/*     */ 
/*     */               
/* 133 */               Chunk myChunk = threadChunks.get(myNumber);
/*     */ 
/*     */               
/* 136 */               ComputeMinMax.this.compute(myChunk.getStartPosition(), myChunk.getLoopSize(), minValues.get(myNumber), maxValues.get(myNumber));
/*     */             }
/*     */           });
/*     */     } 
/*     */ 
/*     */     
/* 142 */     SimpleMultiThreading.startAndJoin(threads);
/*     */ 
/*     */     
/* 145 */     this.min.set((Type)minValues.get(0));
/* 146 */     this.max.set((Type)maxValues.get(0));
/*     */     
/* 148 */     for (int i = 0; i < threads.length; i++) {
/*     */       
/* 150 */       Type type = (Type)minValues.get(i);
/* 151 */       if (Util.min((Type)this.min, type) == type) {
/* 152 */         this.min.set(type);
/*     */       }
/* 154 */       type = (Type)maxValues.get(i);
/* 155 */       if (Util.max((Type)this.max, type) == type) {
/* 156 */         this.max.set(type);
/*     */       }
/*     */     } 
/* 159 */     this.processingTime = System.currentTimeMillis() - startTime;
/*     */     
/* 161 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void compute(long startPos, long loopSize, T min, T max) {
/* 166 */     Cursor<T> cursor = this.image.cursor();
/*     */ 
/*     */     
/* 169 */     cursor.fwd();
/*     */     
/* 171 */     min.set((Type)cursor.get());
/* 172 */     max.set((Type)cursor.get());
/*     */     
/* 174 */     cursor.reset();
/*     */ 
/*     */     
/* 177 */     cursor.jumpFwd(startPos);
/*     */     
/*     */     long j;
/* 180 */     for (j = 0L; j < loopSize; j++) {
/*     */       
/* 182 */       cursor.fwd();
/*     */       
/* 184 */       Type type = (Type)cursor.get();
/*     */       
/* 186 */       if (Util.min((Type)min, type) == type) {
/* 187 */         min.set(type);
/*     */       }
/* 189 */       if (Util.max((Type)max, type) == type) {
/* 190 */         max.set(type);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean checkInput() {
/* 197 */     if (this.errorMessage.length() > 0)
/*     */     {
/* 199 */       return false;
/*     */     }
/* 201 */     if (this.image == null) {
/*     */       
/* 203 */       this.errorMessage = "ScaleSpace: [Image<A> img] is null.";
/* 204 */       return false;
/*     */     } 
/*     */     
/* 207 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public long getProcessingTime() {
/* 213 */     return this.processingTime;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setNumThreads() {
/* 219 */     this.numThreads = Runtime.getRuntime().availableProcessors();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setNumThreads(int numThreads) {
/* 225 */     this.numThreads = numThreads;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getNumThreads() {
/* 231 */     return this.numThreads;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getErrorMessage() {
/* 237 */     return this.errorMessage;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/imglib2-algorithm-0.6.2.jar!/net/imglib2/algorithm/stats/ComputeMinMax.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */