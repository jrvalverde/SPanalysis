/*     */ package net.imglib2.algorithm.neighborhood;
/*     */ 
/*     */ import net.imglib2.AbstractEuclideanSpace;
/*     */ import net.imglib2.FinalInterval;
/*     */ import net.imglib2.Interval;
/*     */ import net.imglib2.Localizable;
/*     */ import net.imglib2.RandomAccessible;
/*     */ import net.imglib2.Sampler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class RectangleNeighborhoodLocalizableSampler<T>
/*     */   extends AbstractEuclideanSpace
/*     */   implements Localizable, Sampler<Neighborhood<T>>
/*     */ {
/*     */   protected final RandomAccessible<T> source;
/*     */   protected final Interval span;
/*     */   protected final Interval sourceInterval;
/*     */   protected final RectangleNeighborhoodFactory<T> neighborhoodFactory;
/*     */   protected final Neighborhood<T> currentNeighborhood;
/*     */   protected final long[] currentPos;
/*     */   protected final long[] currentMin;
/*     */   protected final long[] currentMax;
/*     */   
/*     */   public RectangleNeighborhoodLocalizableSampler(RandomAccessible<T> source, Interval span, RectangleNeighborhoodFactory<T> factory, Interval accessInterval) {
/*  64 */     super(source.numDimensions());
/*  65 */     this.source = source;
/*  66 */     this.span = span;
/*  67 */     this.neighborhoodFactory = factory;
/*  68 */     this.currentPos = new long[this.n];
/*  69 */     this.currentMin = new long[this.n];
/*  70 */     this.currentMax = new long[this.n];
/*  71 */     if (accessInterval == null) {
/*  72 */       this.sourceInterval = null;
/*     */     } else {
/*     */       
/*  75 */       long[] accessMin = new long[this.n];
/*  76 */       long[] accessMax = new long[this.n];
/*  77 */       accessInterval.min(accessMin);
/*  78 */       accessInterval.max(accessMax);
/*  79 */       for (int d = 0; d < this.n; d++) {
/*     */         
/*  81 */         accessMin[d] = accessMin[d] + span.min(d);
/*  82 */         accessMax[d] = accessMax[d] + span.max(d);
/*     */       } 
/*  84 */       this.sourceInterval = (Interval)new FinalInterval(accessMin, accessMax);
/*     */     } 
/*  86 */     this.currentNeighborhood = this.neighborhoodFactory.create(this.currentPos, this.currentMin, this.currentMax, span, (this.sourceInterval == null) ? source
/*  87 */         .randomAccess() : source.randomAccess(this.sourceInterval));
/*     */   }
/*     */ 
/*     */   
/*     */   protected RectangleNeighborhoodLocalizableSampler(RectangleNeighborhoodLocalizableSampler<T> c) {
/*  92 */     super(c.n);
/*  93 */     this.source = c.source;
/*  94 */     this.span = c.span;
/*  95 */     this.sourceInterval = c.sourceInterval;
/*  96 */     this.neighborhoodFactory = c.neighborhoodFactory;
/*  97 */     this.currentPos = (long[])c.currentPos.clone();
/*  98 */     this.currentMin = (long[])c.currentMin.clone();
/*  99 */     this.currentMax = (long[])c.currentMax.clone();
/* 100 */     this.currentNeighborhood = this.neighborhoodFactory.create(this.currentPos, this.currentMin, this.currentMax, this.span, (this.sourceInterval == null) ? this.source
/* 101 */         .randomAccess() : this.source.randomAccess(this.sourceInterval));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Neighborhood<T> get() {
/* 107 */     return this.currentNeighborhood;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void localize(int[] position) {
/* 113 */     this.currentNeighborhood.localize(position);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void localize(long[] position) {
/* 119 */     this.currentNeighborhood.localize(position);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getIntPosition(int d) {
/* 125 */     return this.currentNeighborhood.getIntPosition(d);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public long getLongPosition(int d) {
/* 131 */     return this.currentNeighborhood.getLongPosition(d);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void localize(float[] position) {
/* 137 */     this.currentNeighborhood.localize(position);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void localize(double[] position) {
/* 143 */     this.currentNeighborhood.localize(position);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public float getFloatPosition(int d) {
/* 149 */     return this.currentNeighborhood.getFloatPosition(d);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public double getDoublePosition(int d) {
/* 155 */     return this.currentNeighborhood.getDoublePosition(d);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/imglib2-algorithm-0.6.2.jar!/net/imglib2/algorithm/neighborhood/RectangleNeighborhoodLocalizableSampler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */