/*    */ package net.imglib2.algorithm.morphology.table2d;
/*    */ 
/*    */ import net.imglib2.IterableInterval;
/*    */ import net.imglib2.RandomAccessible;
/*    */ import net.imglib2.img.Img;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Remove
/*    */   extends Abstract3x3TableOperation
/*    */ {
/*    */   protected boolean[] getTable() {
/* 60 */     return table;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected boolean getExtendedValue() {
/* 66 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public static <T extends net.imglib2.type.BooleanType<T>> Img<T> remove(Img<T> source) {
/* 71 */     return (new Remove()).calculate(source);
/*    */   }
/*    */ 
/*    */   
/*    */   public static <T extends net.imglib2.type.BooleanType<T>> void remove(RandomAccessible<T> source, IterableInterval<T> target) {
/* 76 */     (new Remove()).calculate(source, target);
/*    */   }
/*    */   
/* 79 */   private static final boolean[] table = new boolean[] { 
/*    */       false, false, false, false, false, false, false, false, false, false, 
/*    */       false, false, false, false, false, false, true, true, true, true, 
/*    */       true, true, true, true, true, true, true, true, true, true, 
/*    */       true, true, false, false, false, false, false, false, false, false, 
/*    */       false, false, false, false, false, false, false, false, true, true, 
/*    */       true, true, true, true, true, true, true, true, true, true, 
/*    */       true, true, true, true, false, false, false, false, false, false, 
/*    */       false, false, false, false, false, false, false, false, false, false, 
/*    */       true, true, true, true, true, true, true, true, true, true, 
/*    */       true, true, true, true, true, true, false, false, false, false, 
/*    */       false, false, false, false, false, false, false, false, false, false, 
/*    */       false, false, true, true, true, true, true, true, true, true, 
/*    */       true, true, true, true, true, true, true, true, false, false, 
/*    */       false, false, false, false, false, false, false, false, false, false, 
/*    */       false, false, false, false, true, true, true, true, true, true, 
/*    */       true, true, true, true, true, true, true, true, true, true, 
/*    */       false, false, false, false, false, false, false, false, false, false, 
/*    */       false, false, false, false, false, false, true, true, true, true, 
/*    */       true, true, true, true, true, true, false, false, true, true, 
/*    */       false, false, false, false, false, false, false, false, false, false, 
/*    */       false, false, false, false, false, false, false, false, true, true, 
/*    */       true, true, true, true, true, true, true, true, true, true, 
/*    */       true, true, true, true, false, false, false, false, false, false, 
/*    */       false, false, false, false, false, false, false, false, false, false, 
/*    */       true, true, true, true, true, true, true, true, true, true, 
/*    */       false, false, true, true, false, false, false, false, false, false, 
/*    */       false, false, false, false, false, false, false, false, false, false, 
/*    */       false, false, true, true, true, true, true, true, true, true, 
/*    */       true, true, true, true, true, true, true, true, false, false, 
/*    */       false, false, false, false, false, false, false, false, false, false, 
/*    */       false, false, false, false, true, true, true, true, true, true, 
/*    */       true, true, true, true, true, true, true, true, true, true, 
/*    */       false, false, false, false, false, false, false, false, false, false, 
/*    */       false, false, false, false, false, false, true, true, true, true, 
/*    */       true, true, true, true, true, true, true, true, true, true, 
/*    */       true, true, false, false, false, false, false, false, false, false, 
/*    */       false, false, false, false, false, false, false, false, true, true, 
/*    */       true, true, true, true, true, true, true, true, true, true, 
/*    */       true, true, true, true, false, false, false, false, false, false, 
/*    */       false, false, false, false, false, false, false, false, false, false, 
/*    */       true, true, true, true, true, true, true, true, true, true, 
/*    */       true, true, true, true, true, true, false, false, false, false, 
/*    */       false, false, false, false, false, false, false, false, false, false, 
/*    */       false, false, true, true, true, true, true, true, true, true, 
/*    */       true, true, false, false, true, true, false, false, false, false, 
/*    */       false, false, false, false, false, false, false, false, false, false, 
/*    */       false, false, false, false, true, true, true, true, true, true, 
/*    */       true, true, true, true, true, true, true, true, true, true, 
/*    */       false, false, false, false, false, false, false, false, false, false, 
/*    */       false, false, false, false, false, false, true, true, true, true, 
/*    */       true, true, true, true, true, true, false, false, true, true, 
/*    */       false, false };
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/imglib2-algorithm-0.6.2.jar!/net/imglib2/algorithm/morphology/table2d/Remove.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */