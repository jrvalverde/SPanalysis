/*    */ package net.imglib2.algorithm.stats;
/*    */ 
/*    */ import net.imglib2.Cursor;
/*    */ import net.imglib2.IterableInterval;
/*    */ import net.imglib2.type.Type;
/*    */ import net.imglib2.type.numeric.NumericType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Normalize
/*    */ {
/*    */   public static <T extends NumericType<T> & Comparable<T>> void normalize(IterableInterval<T> iterable, T min, T max) {
/* 55 */     Cursor<T> cursor = iterable.cursor();
/* 56 */     NumericType numericType1 = (NumericType)((NumericType)cursor.next()).copy();
/* 57 */     NumericType numericType2 = (NumericType)numericType1.copy();
/* 58 */     for (NumericType numericType : iterable) {
/* 59 */       if (((Comparable<NumericType>)numericType).compareTo(numericType1) > 0) {
/* 60 */         numericType1.set((Type)numericType); continue;
/* 61 */       }  if (((Comparable<NumericType>)numericType).compareTo(numericType2) < 0)
/* 62 */         numericType2.set((Type)numericType); 
/*    */     } 
/* 64 */     NumericType numericType3 = (NumericType)max.copy();
/* 65 */     numericType3.sub(min);
/* 66 */     NumericType numericType4 = numericType1;
/*    */     
/* 68 */     numericType4.sub(numericType2);
/*    */     
/* 70 */     for (NumericType numericType : iterable) {
/*    */       
/* 72 */       numericType.sub(numericType2);
/* 73 */       numericType.mul(numericType3);
/* 74 */       numericType.div(numericType4);
/* 75 */       numericType.add(min);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/imglib2-algorithm-0.6.2.jar!/net/imglib2/algorithm/stats/Normalize.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */