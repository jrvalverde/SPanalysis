/*     */ package net.imglib2.algorithm.morphology;
/*     */ 
/*     */ import java.util.List;
/*     */ import net.imglib2.Dimensions;
/*     */ import net.imglib2.Interval;
/*     */ import net.imglib2.IterableInterval;
/*     */ import net.imglib2.RandomAccessible;
/*     */ import net.imglib2.RandomAccessibleInterval;
/*     */ import net.imglib2.algorithm.neighborhood.Shape;
/*     */ import net.imglib2.img.Img;
/*     */ import net.imglib2.img.ImgFactory;
/*     */ import net.imglib2.type.Type;
/*     */ import net.imglib2.type.numeric.RealType;
/*     */ import net.imglib2.view.ExtendedRandomAccessibleInterval;
/*     */ import net.imglib2.view.IntervalView;
/*     */ import net.imglib2.view.Views;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Closing
/*     */ {
/*     */   public static final <T extends RealType<T>> Img<T> close(Img<T> source, List<Shape> strels, int numThreads) {
/*  81 */     Img<T> dilated = Dilation.dilate(source, strels, numThreads);
/*  82 */     Img<T> eroded = Erosion.erode(dilated, strels, numThreads);
/*  83 */     return eroded;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final <T extends Type<T> & Comparable<T>> Img<T> close(Img<T> source, List<Shape> strels, T minVal, T maxVal, int numThreads) {
/* 129 */     Img<T> dilated = Dilation.dilate(source, strels, minVal, numThreads);
/* 130 */     Img<T> eroded = Erosion.erode(dilated, strels, maxVal, numThreads);
/* 131 */     return eroded;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final <T extends RealType<T>> Img<T> close(Img<T> source, Shape strel, int numThreads) {
/* 156 */     Img<T> dilated = Dilation.dilate(source, strel, numThreads);
/* 157 */     Img<T> eroded = Erosion.erode(dilated, strel, numThreads);
/* 158 */     return eroded;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final <T extends Type<T> & Comparable<T>> Img<T> close(Img<T> source, Shape strel, T minVal, T maxVal, int numThreads) {
/* 199 */     Img<T> dilated = Dilation.dilate(source, strel, minVal, numThreads);
/* 200 */     Img<T> eroded = Erosion.erode(dilated, strel, maxVal, numThreads);
/* 201 */     return eroded;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends RealType<T>> void close(RandomAccessible<T> source, IterableInterval<T> target, List<Shape> strels, int numThreads) {
/* 245 */     RealType realType1 = MorphologyUtils.<RealType>createVariable(source, (Interval)target);
/* 246 */     realType1.setReal(realType1.getMaxValue());
/* 247 */     RealType realType2 = MorphologyUtils.<RealType>createVariable(source, (Interval)target);
/* 248 */     realType2.setReal(realType2.getMinValue());
/* 249 */     close(source, target, strels, realType2, realType1, numThreads);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends Type<T> & Comparable<T>> void close(RandomAccessible<T> source, IterableInterval<T> target, List<Shape> strels, T minVal, T maxVal, int numThreads) {
/* 308 */     ImgFactory<T> factory = MorphologyUtils.getSuitableFactory((Dimensions)target, maxVal);
/* 309 */     Img<T> img = factory.create((Dimensions)target, maxVal);
/* 310 */     long[] min = new long[target.numDimensions()];
/* 311 */     target.min(min);
/*     */     
/* 313 */     IntervalView<T> translated = Views.translate((RandomAccessibleInterval)img, min);
/* 314 */     Dilation.dilate(source, (IterableInterval<T>)translated, strels, minVal, numThreads);
/*     */     
/* 316 */     ExtendedRandomAccessibleInterval<T, IntervalView<T>> extended = Views.extendValue((RandomAccessibleInterval)translated, (Type)maxVal);
/* 317 */     Erosion.erode((RandomAccessible)extended, target, strels, maxVal, numThreads);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends RealType<T>> void close(RandomAccessible<T> source, IterableInterval<T> target, Shape strel, int numThreads) {
/* 356 */     RealType realType1 = MorphologyUtils.<RealType>createVariable(source, (Interval)target);
/* 357 */     realType1.setReal(realType1.getMaxValue());
/* 358 */     RealType realType2 = MorphologyUtils.<RealType>createVariable(source, (Interval)target);
/* 359 */     realType2.setReal(realType2.getMinValue());
/* 360 */     close(source, target, strel, realType2, realType1, numThreads);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends Type<T> & Comparable<T>> void close(RandomAccessible<T> source, IterableInterval<T> target, Shape strel, T minVal, T maxVal, int numThreads) {
/* 414 */     ImgFactory<T> factory = MorphologyUtils.getSuitableFactory((Dimensions)target, minVal);
/* 415 */     Img<T> img = factory.create((Dimensions)target, minVal);
/* 416 */     long[] min = new long[target.numDimensions()];
/* 417 */     target.min(min);
/*     */     
/* 419 */     IntervalView<T> translated = Views.translate((RandomAccessibleInterval)img, min);
/* 420 */     Dilation.dilate(source, (IterableInterval<T>)translated, strel, minVal, numThreads);
/*     */     
/* 422 */     ExtendedRandomAccessibleInterval<T, IntervalView<T>> extended = Views.extendValue((RandomAccessibleInterval)translated, (Type)maxVal);
/* 423 */     Erosion.erode((RandomAccessible)extended, target, strel, maxVal, numThreads);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends RealType<T>> void closeInPlace(RandomAccessibleInterval<T> source, Interval interval, List<Shape> strels, int numThreads) {
/* 462 */     RealType realType1 = MorphologyUtils.<RealType>createVariable((RandomAccessible<RealType>)source, interval);
/* 463 */     realType1.setReal(realType1.getMaxValue());
/* 464 */     RealType realType2 = MorphologyUtils.<RealType>createVariable((RandomAccessible<RealType>)source, interval);
/* 465 */     realType2.setReal(realType2.getMinValue());
/*     */     
/* 467 */     closeInPlace(source, interval, strels, realType2, realType1, numThreads);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends Type<T> & Comparable<T>> void closeInPlace(RandomAccessibleInterval<T> source, Interval interval, List<Shape> strels, T minVal, T maxVal, int numThreads) {
/* 520 */     for (Shape strel : strels)
/*     */     {
/* 522 */       closeInPlace(source, interval, strel, minVal, maxVal, numThreads);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends RealType<T>> void closeInPlace(RandomAccessibleInterval<T> source, Interval interval, Shape strel, int numThreads) {
/* 565 */     RealType realType1 = MorphologyUtils.<RealType>createVariable((RandomAccessible<RealType>)source, interval);
/* 566 */     realType1.setReal(realType1.getMaxValue());
/* 567 */     RealType realType2 = MorphologyUtils.<RealType>createVariable((RandomAccessible<RealType>)source, interval);
/* 568 */     realType2.setReal(realType2.getMinValue());
/*     */     
/* 570 */     closeInPlace(source, interval, strel, realType2, realType1, numThreads);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends Type<T> & Comparable<T>> void closeInPlace(RandomAccessibleInterval<T> source, Interval interval, Shape strel, T minVal, T maxVal, int numThreads) {
/* 623 */     ExtendedRandomAccessibleInterval<T, RandomAccessibleInterval<T>> extended = Views.extendValue(source, (Type)maxVal);
/*     */     
/* 625 */     ImgFactory<T> factory = MorphologyUtils.getSuitableFactory((Dimensions)interval, maxVal);
/* 626 */     Img<T> img = factory.create((Dimensions)interval, maxVal);
/* 627 */     long[] min = new long[interval.numDimensions()];
/* 628 */     interval.min(min);
/* 629 */     IntervalView<T> translated = Views.translate((RandomAccessibleInterval)img, min);
/*     */     
/* 631 */     close((RandomAccessible)extended, (IterableInterval<T>)translated, strel, minVal, maxVal, numThreads);
/* 632 */     MorphologyUtils.copy((IterableInterval<T>)translated, (RandomAccessible)extended, numThreads);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/imglib2-algorithm-0.6.2.jar!/net/imglib2/algorithm/morphology/Closing.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */