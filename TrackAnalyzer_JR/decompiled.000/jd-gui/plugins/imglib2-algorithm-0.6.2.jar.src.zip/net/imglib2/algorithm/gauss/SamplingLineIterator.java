/*     */ package net.imglib2.algorithm.gauss;
/*     */ 
/*     */ import net.imglib2.Cursor;
/*     */ import net.imglib2.Localizable;
/*     */ import net.imglib2.Positionable;
/*     */ import net.imglib2.RandomAccess;
/*     */ import net.imglib2.Sampler;
/*     */ import net.imglib2.img.Img;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public class SamplingLineIterator<T>
/*     */   extends AbstractLineIterator
/*     */   implements Sampler<T>
/*     */ {
/*     */   final Img<T> processLine;
/*     */   final RandomAccess<T> randomAccess;
/*     */   final Cursor<T> resultCursor;
/*     */   final RandomAccess<T> randomAccessLeft;
/*     */   final RandomAccess<T> randomAccessRight;
/*     */   final T copy;
/*     */   final T tmp;
/*     */   
/*     */   public SamplingLineIterator(int dim, long size, RandomAccess<T> randomAccess, Img<T> processLine, T copy, T tmp) {
/*  80 */     super(dim, size, (Localizable)randomAccess, (Positionable)randomAccess);
/*     */     
/*  82 */     this.processLine = processLine;
/*  83 */     this.randomAccess = randomAccess;
/*     */     
/*  85 */     this.randomAccessLeft = processLine.randomAccess();
/*  86 */     this.randomAccessRight = processLine.randomAccess();
/*  87 */     this.copy = copy;
/*  88 */     this.tmp = tmp;
/*     */     
/*  90 */     this.resultCursor = processLine.cursor();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Img<T> getProcessLine() {
/*  99 */     return this.processLine;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public T get() {
/* 105 */     return (T)this.randomAccess.get();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SamplingLineIterator<T> copy() {
/* 112 */     SamplingLineIterator<T> c = new SamplingLineIterator(this.d, this.size, this.randomAccess, getProcessLine(), this.copy, this.tmp);
/*     */ 
/*     */     
/* 115 */     c.i = this.i;
/*     */     
/* 117 */     return c;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/imglib2-algorithm-0.6.2.jar!/net/imglib2/algorithm/gauss/SamplingLineIterator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */