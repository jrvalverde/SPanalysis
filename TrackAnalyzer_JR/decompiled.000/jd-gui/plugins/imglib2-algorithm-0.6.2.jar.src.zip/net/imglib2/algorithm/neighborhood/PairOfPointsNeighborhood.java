/*     */ package net.imglib2.algorithm.neighborhood;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import net.imglib2.AbstractEuclideanSpace;
/*     */ import net.imglib2.AbstractLocalizable;
/*     */ import net.imglib2.Cursor;
/*     */ import net.imglib2.Interval;
/*     */ import net.imglib2.Positionable;
/*     */ import net.imglib2.RandomAccess;
/*     */ import net.imglib2.RealCursor;
/*     */ import net.imglib2.RealPositionable;
/*     */ import net.imglib2.Sampler;
/*     */ import net.imglib2.util.Intervals;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PairOfPointsNeighborhood<T>
/*     */   extends AbstractLocalizable
/*     */   implements Neighborhood<T>
/*     */ {
/*     */   private final long[] offset;
/*     */   private final int ndims;
/*     */   private final RandomAccess<T> ra;
/*     */   
/*     */   public static <T> PairOfPointsNeighborhoodFactory<T> factory() {
/*  51 */     return new PairOfPointsNeighborhoodFactory<T>()
/*     */       {
/*     */         
/*     */         public Neighborhood<T> create(long[] position, long[] offset, RandomAccess<T> sourceRandomAccess)
/*     */         {
/*  56 */           return new PairOfPointsNeighborhood<>(position, offset, sourceRandomAccess);
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   PairOfPointsNeighborhood(long[] position, long[] offset, RandomAccess<T> sourceRandomAccess) {
/*  69 */     super(position);
/*  70 */     this.ra = sourceRandomAccess.copyRandomAccess();
/*  71 */     this.offset = offset;
/*  72 */     this.ndims = sourceRandomAccess.numDimensions();
/*     */   }
/*     */ 
/*     */   
/*     */   public class LocalCursor
/*     */     extends AbstractEuclideanSpace
/*     */     implements Cursor<T>
/*     */   {
/*     */     private int index;
/*     */     private RandomAccess<T> source;
/*     */     
/*     */     private LocalCursor(RandomAccess<T> source) {
/*  84 */       super(source.numDimensions());
/*  85 */       this.source = source;
/*  86 */       reset();
/*     */     }
/*     */ 
/*     */     
/*     */     private LocalCursor(LocalCursor c) {
/*  91 */       this(c.source.copyRandomAccess());
/*  92 */       this.index = c.index;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public T get() {
/*  98 */       return (T)this.source.get();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void fwd() {
/* 104 */       this.index++;
/* 105 */       if (this.index == 1)
/*     */       {
/* 107 */         for (int d = 0; d < PairOfPointsNeighborhood.this.offset.length; d++)
/*     */         {
/* 109 */           this.source.move(PairOfPointsNeighborhood.this.offset[d], d);
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void jumpFwd(long steps) {
/* 117 */       for (long i = 0L; i < steps; i++)
/*     */       {
/* 119 */         fwd();
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public T next() {
/* 126 */       fwd();
/* 127 */       return get();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void remove() {}
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void reset() {
/* 139 */       this.index = -1;
/* 140 */       this.source.setPosition(PairOfPointsNeighborhood.this.position);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean hasNext() {
/* 146 */       return (this.index < 1);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public float getFloatPosition(int d) {
/* 152 */       return this.source.getFloatPosition(d);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public double getDoublePosition(int d) {
/* 158 */       return this.source.getDoublePosition(d);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int getIntPosition(int d) {
/* 165 */       return this.source.getIntPosition(d);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public long getLongPosition(int d) {
/* 171 */       return this.source.getLongPosition(d);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void localize(long[] position) {
/* 177 */       for (int d = 0; d < position.length; d++)
/*     */       {
/* 179 */         position[d] = this.source.getLongPosition(d);
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void localize(float[] position) {
/* 186 */       for (int d = 0; d < position.length; d++)
/*     */       {
/* 188 */         position[d] = this.source.getFloatPosition(d);
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void localize(double[] position) {
/* 195 */       for (int d = 0; d < position.length; d++)
/*     */       {
/* 197 */         position[d] = this.source.getDoublePosition(d);
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void localize(int[] position) {
/* 204 */       for (int d = 0; d < position.length; d++)
/*     */       {
/* 206 */         position[d] = this.source.getIntPosition(d);
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public LocalCursor copy() {
/* 213 */       return new LocalCursor(this);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public LocalCursor copyCursor() {
/* 219 */       return copy();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Interval getStructuringElementBoundingBox() {
/* 226 */     long[] minmax = new long[this.ndims * 2]; int d;
/* 227 */     for (d = 0; d < this.ndims; d++)
/*     */     {
/* 229 */       minmax[d] = Math.min(this.position[d], this.position[d] + this.offset[d]);
/*     */     }
/* 231 */     for (d = this.ndims; d < 2 * this.ndims; d++) {
/*     */       
/* 233 */       int sd = d - this.ndims;
/* 234 */       minmax[d] = Math.max(this.position[sd], this.position[sd] + this.offset[sd]);
/*     */     } 
/* 236 */     return (Interval)Intervals.createMinMax(minmax);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public long size() {
/* 242 */     return 2L;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public T firstElement() {
/* 248 */     return cursor().next();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object iterationOrder() {
/* 254 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public double realMin(int d) {
/* 260 */     return Math.min(this.position[d], this.position[d] + this.offset[d]);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void realMin(double[] min) {
/* 266 */     for (int d = 0; d < min.length; d++)
/*     */     {
/* 268 */       min[d] = Math.min(this.position[d], this.position[d] + this.offset[d]);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void realMin(RealPositionable min) {
/* 275 */     for (int d = 0; d < min.numDimensions(); d++)
/*     */     {
/* 277 */       min.setPosition(Math.min(this.position[d], this.position[d] + this.offset[d]), d);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public double realMax(int d) {
/* 284 */     return Math.max(this.position[d], this.position[d] + this.offset[d]);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void realMax(double[] max) {
/* 290 */     for (int d = 0; d < max.length; d++)
/*     */     {
/* 292 */       max[d] = Math.max(this.position[d], this.position[d] + this.offset[d]);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void realMax(RealPositionable max) {
/* 299 */     for (int d = 0; d < max.numDimensions(); d++)
/*     */     {
/* 301 */       max.setPosition(Math.max(this.position[d], this.position[d] + this.offset[d]), d);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Iterator<T> iterator() {
/* 308 */     return (Iterator<T>)cursor();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public long min(int d) {
/* 314 */     return Math.min(this.position[d], this.position[d] + this.offset[d]);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void min(long[] min) {
/* 320 */     for (int d = 0; d < min.length; d++)
/*     */     {
/* 322 */       min[d] = Math.min(this.position[d], this.position[d] + this.offset[d]);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void min(Positionable min) {
/* 329 */     for (int d = 0; d < min.numDimensions(); d++)
/*     */     {
/* 331 */       min.setPosition(Math.min(this.position[d], this.position[d] + this.offset[d]), d);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public long max(int d) {
/* 338 */     return Math.max(this.position[d], this.position[d] + this.offset[d]);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void max(long[] max) {
/* 344 */     for (int d = 0; d < max.length; d++)
/*     */     {
/* 346 */       max[d] = Math.max(this.position[d], this.position[d] + this.offset[d]);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void max(Positionable max) {
/* 353 */     for (int d = 0; d < max.numDimensions(); d++)
/*     */     {
/* 355 */       max.setPosition(Math.max(this.position[d], this.position[d] + this.offset[d]), d);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void dimensions(long[] dimensions) {
/* 362 */     for (int d = 0; d < dimensions.length; d++)
/*     */     {
/* 364 */       dimensions[d] = Math.abs(this.offset[d]) + 1L;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public long dimension(int d) {
/* 371 */     return Math.abs(this.offset[d]) + 1L;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public LocalCursor cursor() {
/* 377 */     return new LocalCursor(this.ra.copyRandomAccess());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public LocalCursor localizingCursor() {
/* 383 */     return cursor();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/imglib2-algorithm-0.6.2.jar!/net/imglib2/algorithm/neighborhood/PairOfPointsNeighborhood.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */