package net.imglib2.algorithm.neighborhood;

import net.imglib2.IterableInterval;
import net.imglib2.RandomAccessible;
import net.imglib2.RandomAccessibleInterval;

public interface Shape {
  <T> IterableInterval<Neighborhood<T>> neighborhoods(RandomAccessibleInterval<T> paramRandomAccessibleInterval);
  
  <T> RandomAccessible<Neighborhood<T>> neighborhoodsRandomAccessible(RandomAccessible<T> paramRandomAccessible);
  
  <T> IterableInterval<Neighborhood<T>> neighborhoodsSafe(RandomAccessibleInterval<T> paramRandomAccessibleInterval);
  
  <T> RandomAccessible<Neighborhood<T>> neighborhoodsRandomAccessibleSafe(RandomAccessible<T> paramRandomAccessible);
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/imglib2-algorithm-0.6.2.jar!/net/imglib2/algorithm/neighborhood/Shape.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */