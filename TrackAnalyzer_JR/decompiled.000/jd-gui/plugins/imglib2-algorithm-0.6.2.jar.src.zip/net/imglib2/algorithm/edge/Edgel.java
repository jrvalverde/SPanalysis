/*    */ package net.imglib2.algorithm.edge;
/*    */ 
/*    */ import net.imglib2.AbstractRealLocalizable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Edgel
/*    */   extends AbstractRealLocalizable
/*    */ {
/*    */   private final double[] gradient;
/*    */   private final double magnitude;
/*    */   
/*    */   public Edgel(double[] position, double[] gradient, double magnitude) {
/* 65 */     super((double[])position.clone());
/* 66 */     this.gradient = (double[])gradient.clone();
/* 67 */     this.magnitude = magnitude;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public double[] getGradient() {
/* 78 */     return this.gradient;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public double getMagnitude() {
/* 88 */     return this.magnitude;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 93 */     return String.format("Edgel: pos (%.2f,%.2f,%.2f) grad (%.2f,%.2f,%.2f) mag (%.2f)", new Object[] {
/* 94 */           Double.valueOf(this.position[0]), Double.valueOf(this.position[1]), Double.valueOf(this.position[2]), 
/* 95 */           Double.valueOf(this.gradient[0]), Double.valueOf(this.gradient[1]), Double.valueOf(this.gradient[2]), 
/* 96 */           Double.valueOf(this.magnitude)
/*    */         });
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/imglib2-algorithm-0.6.2.jar!/net/imglib2/algorithm/edge/Edgel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */