package net.imglib2.algorithm.componenttree;

public interface ComponentTree<C extends Component<?, C>> extends ComponentForest<C> {
  C root();
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/imglib2-algorithm-0.6.2.jar!/net/imglib2/algorithm/componenttree/ComponentTree.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */