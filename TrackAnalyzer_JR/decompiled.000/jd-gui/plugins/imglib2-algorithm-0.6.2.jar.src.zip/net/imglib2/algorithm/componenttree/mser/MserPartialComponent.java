/*     */ package net.imglib2.algorithm.componenttree.mser;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import net.imglib2.Localizable;
/*     */ import net.imglib2.algorithm.componenttree.PartialComponent;
/*     */ import net.imglib2.algorithm.componenttree.pixellist.PixelList;
/*     */ import net.imglib2.type.Type;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class MserPartialComponent<T extends Type<T>>
/*     */   implements PartialComponent<T, MserPartialComponent<T>>
/*     */ {
/*     */   private final T value;
/*     */   final PixelList pixelList;
/*     */   final int n;
/*     */   final double[] sumPos;
/*     */   final double[] sumSquPos;
/*     */   private final long[] tmp;
/*     */   ArrayList<MserPartialComponent<T>> children;
/*     */   MserEvaluationNode<T> evaluationNode;
/*     */   
/*     */   MserPartialComponent(T value, MserPartialComponentGenerator<T> generator) {
/* 109 */     this.pixelList = new PixelList(generator.linkedList.randomAccess(), generator.dimensions);
/* 110 */     this.n = generator.dimensions.length;
/* 111 */     this.sumPos = new double[this.n];
/* 112 */     this.sumSquPos = new double[this.n * (this.n + 1) / 2];
/* 113 */     this.value = (T)value.copy();
/* 114 */     this.children = new ArrayList<>();
/* 115 */     this.evaluationNode = null;
/* 116 */     this.tmp = new long[this.n];
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void addPosition(Localizable position) {
/* 122 */     this.pixelList.addPosition(position);
/* 123 */     position.localize(this.tmp);
/* 124 */     int k = 0;
/* 125 */     for (int i = 0; i < this.n; i++) {
/*     */       
/* 127 */       this.sumPos[i] = this.sumPos[i] + this.tmp[i];
/* 128 */       for (int j = i; j < this.n; j++) {
/* 129 */         this.sumSquPos[k++] = this.sumSquPos[k++] + (this.tmp[i] * this.tmp[j]);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public T getValue() {
/* 136 */     return this.value;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setValue(T value) {
/* 142 */     this.value.set((Type)value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void merge(MserPartialComponent<T> component) {
/* 148 */     this.pixelList.merge(component.pixelList); int i;
/* 149 */     for (i = 0; i < this.sumPos.length; i++)
/* 150 */       this.sumPos[i] = this.sumPos[i] + component.sumPos[i]; 
/* 151 */     for (i = 0; i < this.sumSquPos.length; i++)
/* 152 */       this.sumSquPos[i] = this.sumSquPos[i] + component.sumSquPos[i]; 
/* 153 */     this.children.add(component);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 159 */     String s = "{" + this.value.toString() + " : ";
/* 160 */     boolean first = true;
/* 161 */     for (Localizable l : this.pixelList) {
/*     */       
/* 163 */       if (first) {
/*     */         
/* 165 */         first = false;
/*     */       }
/*     */       else {
/*     */         
/* 169 */         s = s + ", ";
/*     */       } 
/* 171 */       s = s + l.toString();
/*     */     } 
/* 173 */     return s + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   long size() {
/* 183 */     return this.pixelList.size();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   MserEvaluationNode<T> getEvaluationNode() {
/* 194 */     return this.evaluationNode;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setEvaluationNode(MserEvaluationNode<T> node) {
/* 203 */     this.evaluationNode = node;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/imglib2-algorithm-0.6.2.jar!/net/imglib2/algorithm/componenttree/mser/MserPartialComponent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */