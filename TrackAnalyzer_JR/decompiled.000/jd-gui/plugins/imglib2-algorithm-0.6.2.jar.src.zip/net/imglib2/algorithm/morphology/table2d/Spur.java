/*    */ package net.imglib2.algorithm.morphology.table2d;
/*    */ 
/*    */ import net.imglib2.Dimensions;
/*    */ import net.imglib2.IterableInterval;
/*    */ import net.imglib2.RandomAccessible;
/*    */ import net.imglib2.img.Img;
/*    */ import net.imglib2.img.ImgFactory;
/*    */ import net.imglib2.img.list.ListImgFactory;
/*    */ import net.imglib2.type.BooleanType;
/*    */ import net.imglib2.type.NativeType;
/*    */ import net.imglib2.util.Util;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Spur
/*    */ {
/*    */   public static <T extends BooleanType<T>> Img<T> spur(Img<T> source) {
/* 64 */     return (new Spur2()).calculate((new Spur1()).calculate(source));
/*    */   }
/*    */ 
/*    */   
/*    */   public static <T extends BooleanType<T>> void spur(RandomAccessible<T> source, IterableInterval<T> target) {
/*    */     ListImgFactory listImgFactory;
/* 70 */     long[] targetDims = { target.dimension(0), target.dimension(1) };
/* 71 */     BooleanType booleanType = (BooleanType)((BooleanType)target.firstElement()).createVariable();
/* 72 */     booleanType.set(false);
/*    */ 
/*    */     
/* 75 */     if (booleanType instanceof NativeType) {
/* 76 */       ImgFactory<T> factory = Util.getArrayOrCellImgFactory((Dimensions)target, (NativeType)booleanType);
/*    */     } else {
/* 78 */       listImgFactory = new ListImgFactory();
/* 79 */     }  Img<T> temp = listImgFactory.create(targetDims, booleanType);
/*    */     
/* 81 */     (new Spur1()).calculate(source, (IterableInterval<T>)temp);
/* 82 */     (new Spur2()).calculate((RandomAccessible<T>)temp, target);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/imglib2-algorithm-0.6.2.jar!/net/imglib2/algorithm/morphology/table2d/Spur.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */