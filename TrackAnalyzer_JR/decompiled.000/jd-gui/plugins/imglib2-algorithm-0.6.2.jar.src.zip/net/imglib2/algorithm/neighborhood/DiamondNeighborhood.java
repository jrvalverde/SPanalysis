/*     */ package net.imglib2.algorithm.neighborhood;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import net.imglib2.AbstractEuclideanSpace;
/*     */ import net.imglib2.AbstractLocalizable;
/*     */ import net.imglib2.Cursor;
/*     */ import net.imglib2.FinalInterval;
/*     */ import net.imglib2.Interval;
/*     */ import net.imglib2.Positionable;
/*     */ import net.imglib2.RandomAccess;
/*     */ import net.imglib2.RealCursor;
/*     */ import net.imglib2.RealPositionable;
/*     */ import net.imglib2.Sampler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DiamondNeighborhood<T>
/*     */   extends AbstractLocalizable
/*     */   implements Neighborhood<T>
/*     */ {
/*     */   private final RandomAccess<T> sourceRandomAccess;
/*     */   private final long radius;
/*     */   private final int maxDim;
/*     */   private final FinalInterval structuringElementBoundingBox;
/*     */   
/*     */   public static <T> DiamondNeighborhoodFactory<T> factory() {
/*  51 */     return new DiamondNeighborhoodFactory<T>()
/*     */       {
/*     */         
/*     */         public Neighborhood<T> create(long[] position, long radius, RandomAccess<T> sourceRandomAccess)
/*     */         {
/*  56 */           return new DiamondNeighborhood<>(position, radius, sourceRandomAccess);
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   DiamondNeighborhood(long[] position, long radius, RandomAccess<T> sourceRandomAccess) {
/*  73 */     super(position);
/*  74 */     this.sourceRandomAccess = sourceRandomAccess;
/*  75 */     this.radius = radius;
/*  76 */     this.maxDim = this.n - 1;
/*     */ 
/*     */     
/*  79 */     long[] min = new long[this.n];
/*  80 */     long[] max = new long[this.n];
/*     */     
/*  82 */     for (int d = 0; d < this.n; d++) {
/*     */       
/*  84 */       min[d] = -radius;
/*  85 */       max[d] = radius;
/*     */     } 
/*  87 */     this.structuringElementBoundingBox = new FinalInterval(min, max);
/*     */   }
/*     */ 
/*     */   
/*     */   public class LocalCursor
/*     */     extends AbstractEuclideanSpace
/*     */     implements Cursor<T>
/*     */   {
/*     */     protected final RandomAccess<T> source;
/*     */     
/*     */     protected final long[] ri;
/*     */     
/*     */     protected final long[] s;
/*     */     
/*     */     public LocalCursor(RandomAccess<T> source) {
/* 102 */       super(source.numDimensions());
/* 103 */       this.source = source;
/* 104 */       this.ri = new long[this.n];
/* 105 */       this.s = new long[this.n];
/* 106 */       reset();
/*     */     }
/*     */ 
/*     */     
/*     */     protected LocalCursor(LocalCursor c) {
/* 111 */       super(c.numDimensions());
/* 112 */       this.source = c.source.copyRandomAccess();
/* 113 */       this.ri = (long[])c.ri.clone();
/* 114 */       this.s = (long[])c.s.clone();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public T get() {
/* 120 */       return (T)this.source.get();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void fwd() {
/* 126 */       this.s[0] = this.s[0] - 1L; if (this.s[0] - 1L >= 0L) {
/*     */         
/* 128 */         this.source.fwd(0);
/*     */       }
/*     */       else {
/*     */         
/* 132 */         int d = 1;
/* 133 */         for (; d < this.n; d++) {
/*     */           
/* 135 */           this.s[d] = this.s[d] - 1L; if (this.s[d] - 1L >= 0L) {
/*     */             
/* 137 */             this.source.fwd(d);
/*     */             
/*     */             break;
/*     */           } 
/*     */         } 
/* 142 */         for (; d > 0; d--) {
/*     */           
/* 144 */           int e = d - 1;
/* 145 */           long pd = Math.abs(this.s[d] - this.ri[d]);
/* 146 */           long rad = this.ri[d] - pd;
/* 147 */           this.ri[e] = rad;
/* 148 */           this.s[e] = 2L * rad;
/*     */           
/* 150 */           this.source.setPosition(DiamondNeighborhood.this.position[e] - rad, e);
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void jumpFwd(long steps) {
/* 158 */       for (long i = 0L; i < steps; i++)
/*     */       {
/* 160 */         fwd();
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public T next() {
/* 167 */       fwd();
/* 168 */       return get();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void remove() {}
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void reset() {
/* 180 */       for (int d = 0; d < DiamondNeighborhood.this.maxDim; d++) {
/*     */         
/* 182 */         this.s[d] = 0L; this.ri[d] = 0L;
/* 183 */         this.source.setPosition(DiamondNeighborhood.this.position[d], d);
/*     */       } 
/* 185 */       this.source.setPosition(DiamondNeighborhood.this.position[DiamondNeighborhood.this.maxDim] - DiamondNeighborhood.this.radius - 1L, DiamondNeighborhood.this.maxDim);
/* 186 */       this.ri[DiamondNeighborhood.this.maxDim] = DiamondNeighborhood.this.radius;
/* 187 */       this.s[DiamondNeighborhood.this.maxDim] = 1L + 2L * DiamondNeighborhood.this.radius;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean hasNext() {
/* 193 */       return (this.s[DiamondNeighborhood.this.maxDim] > 0L);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public float getFloatPosition(int d) {
/* 199 */       return this.source.getFloatPosition(d);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public double getDoublePosition(int d) {
/* 205 */       return this.source.getDoublePosition(d);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public int getIntPosition(int d) {
/* 211 */       return this.source.getIntPosition(d);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public long getLongPosition(int d) {
/* 217 */       return this.source.getLongPosition(d);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void localize(long[] position) {
/* 223 */       this.source.localize(position);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void localize(float[] position) {
/* 229 */       this.source.localize(position);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void localize(double[] position) {
/* 235 */       this.source.localize(position);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void localize(int[] position) {
/* 241 */       this.source.localize(position);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public LocalCursor copy() {
/* 247 */       return new LocalCursor(this);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public LocalCursor copyCursor() {
/* 253 */       return copy();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Interval getStructuringElementBoundingBox() {
/* 260 */     return (Interval)this.structuringElementBoundingBox;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public long size() {
/* 266 */     if (this.n < 1)
/*     */     {
/* 268 */       return 1L;
/*     */     }
/* 270 */     if (this.n < 2)
/*     */     {
/* 272 */       return 2L * this.radius + 1L;
/*     */     }
/* 274 */     if (this.n < 3)
/*     */     {
/* 276 */       return this.radius * this.radius + (this.radius + 1L) * (this.radius + 1L);
/*     */     }
/*     */ 
/*     */     
/* 280 */     return diamondSize(this.radius, this.n);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static final long diamondSize(long rad, int dim) {
/* 286 */     if (dim == 2)
/*     */     {
/* 288 */       return rad * rad + (rad + 1L) * (rad + 1L);
/*     */     }
/*     */ 
/*     */     
/* 292 */     long size = 0L;
/* 293 */     for (int r = 0; r < rad; r++)
/*     */     {
/* 295 */       size += 2L * diamondSize(r, dim - 1);
/*     */     }
/* 297 */     size += diamondSize(rad, dim - 1);
/* 298 */     return size;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T firstElement() {
/* 306 */     return cursor().next();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object iterationOrder() {
/* 312 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public double realMin(int d) {
/* 318 */     return (this.position[d] - this.radius);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void realMin(double[] min) {
/* 324 */     for (int d = 0; d < min.length; d++)
/*     */     {
/* 326 */       min[d] = (this.position[d] - this.radius);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void realMin(RealPositionable min) {
/* 333 */     for (int d = 0; d < min.numDimensions(); d++)
/*     */     {
/* 335 */       min.setPosition(this.position[d] - this.radius, d);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public double realMax(int d) {
/* 342 */     return (this.position[d] + this.radius);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void realMax(double[] max) {
/* 348 */     for (int d = 0; d < max.length; d++)
/*     */     {
/* 350 */       max[d] = (this.position[d] + this.radius);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void realMax(RealPositionable max) {
/* 357 */     for (int d = 0; d < max.numDimensions(); d++)
/*     */     {
/* 359 */       max.setPosition(this.position[d] + this.radius, d);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Iterator<T> iterator() {
/* 366 */     return (Iterator<T>)cursor();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public long min(int d) {
/* 372 */     return this.position[d] - this.radius;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void min(long[] min) {
/* 378 */     for (int d = 0; d < min.length; d++)
/*     */     {
/* 380 */       min[d] = this.position[d] - this.radius;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void min(Positionable min) {
/* 387 */     for (int d = 0; d < min.numDimensions(); d++)
/*     */     {
/* 389 */       min.setPosition(this.position[d] - this.radius, d);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public long max(int d) {
/* 396 */     return this.position[d] + this.radius;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void max(long[] max) {
/* 402 */     for (int d = 0; d < max.length; d++)
/*     */     {
/* 404 */       max[d] = this.position[d] + this.radius;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void max(Positionable max) {
/* 411 */     for (int d = 0; d < max.numDimensions(); d++)
/*     */     {
/* 413 */       max.setPosition(this.position[d] + this.radius, d);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void dimensions(long[] dimensions) {
/* 420 */     for (int d = 0; d < dimensions.length; d++)
/*     */     {
/* 422 */       dimensions[d] = 2L * this.radius + 1L;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public long dimension(int d) {
/* 429 */     return 2L * this.radius + 1L;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public LocalCursor cursor() {
/* 435 */     return new LocalCursor(this.sourceRandomAccess.copyRandomAccess());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public LocalCursor localizingCursor() {
/* 441 */     return cursor();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/imglib2-algorithm-0.6.2.jar!/net/imglib2/algorithm/neighborhood/DiamondNeighborhood.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */