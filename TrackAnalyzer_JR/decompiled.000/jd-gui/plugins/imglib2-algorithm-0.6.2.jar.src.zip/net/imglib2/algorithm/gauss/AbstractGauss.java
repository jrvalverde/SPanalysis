/*     */ package net.imglib2.algorithm.gauss;
/*     */ 
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ import net.imglib2.Cursor;
/*     */ import net.imglib2.Dimensions;
/*     */ import net.imglib2.FinalInterval;
/*     */ import net.imglib2.Interval;
/*     */ import net.imglib2.Localizable;
/*     */ import net.imglib2.Positionable;
/*     */ import net.imglib2.RandomAccess;
/*     */ import net.imglib2.RandomAccessible;
/*     */ import net.imglib2.img.Img;
/*     */ import net.imglib2.img.ImgFactory;
/*     */ import net.imglib2.iterator.LocalizingZeroMinIntervalIterator;
/*     */ import net.imglib2.multithreading.SimpleMultiThreading;
/*     */ import net.imglib2.type.Type;
/*     */ import net.imglib2.type.numeric.NumericType;
/*     */ import net.imglib2.util.Intervals;
/*     */ import net.imglib2.util.Util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractGauss<T extends NumericType<T>>
/*     */ {
/*     */   final Interval inputInterval;
/*     */   final Localizable outputOffset;
/*     */   RandomAccessible<T> input;
/*     */   RandomAccessible<T> output;
/*     */   final ImgFactory<T> factory;
/*     */   final Img<T> tmp1;
/*     */   final Img<T> tmp2;
/*     */   final T type;
/*     */   final int numDimensions;
/*     */   final double[] sigma;
/*     */   final double[][] kernel;
/*     */   int numThreads;
/*     */   
/*     */   public AbstractGauss(double[] sigma, RandomAccessible<T> input, Interval inputInterval, RandomAccessible<T> output, Localizable outputOffset, ImgFactory<T> factory, T type) {
/*  92 */     this.numThreads = Runtime.getRuntime().availableProcessors();
/*  93 */     this.numDimensions = sigma.length;
/*  94 */     this.input = input;
/*  95 */     this.output = output;
/*  96 */     this.factory = factory;
/*  97 */     this.type = type;
/*     */     
/*  99 */     this.sigma = sigma;
/* 100 */     this.kernel = new double[this.numDimensions][];
/* 101 */     this.inputInterval = inputInterval;
/* 102 */     this.outputOffset = outputOffset;
/*     */     
/* 104 */     computeKernel();
/*     */ 
/*     */     
/* 107 */     Interval intervalTmp = getTemporaryImgSize();
/*     */     
/* 109 */     if (this.numDimensions > 1) {
/* 110 */       this.tmp1 = factory.create((Dimensions)intervalTmp, getProcessingType());
/*     */     } else {
/* 112 */       this.tmp1 = null;
/*     */     } 
/* 114 */     if (this.numDimensions > 2) {
/* 115 */       this.tmp2 = factory.create((Dimensions)intervalTmp, getProcessingType());
/*     */     } else {
/* 117 */       this.tmp2 = null;
/*     */     } 
/*     */   }
/*     */   
/*     */   public double[] getSigma() {
/* 122 */     return this.sigma;
/*     */   }
/*     */ 
/*     */   
/*     */   public double[][] getKernel() {
/* 127 */     return this.kernel;
/*     */   }
/*     */ 
/*     */   
/*     */   public int numDimensions() {
/* 132 */     return this.numDimensions;
/*     */   }
/*     */ 
/*     */   
/*     */   public RandomAccessible<T> getInput() {
/* 137 */     return this.input;
/*     */   }
/*     */ 
/*     */   
/*     */   public RandomAccessible<T> getOutput() {
/* 142 */     return this.output;
/*     */   }
/*     */ 
/*     */   
/*     */   public ImgFactory<T> getFactory() {
/* 147 */     return this.factory;
/*     */   }
/*     */ 
/*     */   
/*     */   public Interval getInputInterval() {
/* 152 */     return this.inputInterval;
/*     */   }
/*     */ 
/*     */   
/*     */   public Localizable getOutputOffset() {
/* 157 */     return this.outputOffset;
/*     */   }
/*     */ 
/*     */   
/*     */   public T type() {
/* 162 */     return this.type;
/*     */   }
/*     */ 
/*     */   
/*     */   public Img<T> getTmp1() {
/* 167 */     return this.tmp1;
/*     */   }
/*     */ 
/*     */   
/*     */   public Img<T> getTmp2() {
/* 172 */     return this.tmp2;
/*     */   }
/*     */ 
/*     */   
/*     */   protected T getProcessingType() {
/* 177 */     return (T)this.type.createVariable();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract Img<T> getProcessingLine(long paramLong);
/*     */ 
/*     */ 
/*     */   
/*     */   public RandomAccessible<T> getResult() {
/* 187 */     return this.output;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Interval getRange(int dim) {
/* 204 */     if (this.numDimensions == 1) {
/* 205 */       return this.inputInterval;
/*     */     }
/* 207 */     long[] min = new long[this.numDimensions];
/* 208 */     long[] max = new long[this.numDimensions];
/*     */ 
/*     */ 
/*     */     
/* 212 */     if (dim == 0) {
/*     */       
/* 214 */       min[0] = this.inputInterval.min(0);
/* 215 */       max[0] = this.inputInterval.max(0);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 222 */       for (int d = 1; d < this.numDimensions; d++)
/*     */       {
/* 224 */         min[d] = this.inputInterval.min(d) - ((this.kernel[d]).length / 2);
/* 225 */         max[d] = this.inputInterval.max(d) + ((this.kernel[d]).length / 2);
/*     */       
/*     */       }
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 232 */       for (int d = 0; d < this.numDimensions; d++) {
/*     */ 
/*     */ 
/*     */         
/* 236 */         if (d < dim) {
/*     */           
/* 238 */           min[d] = 0L;
/* 239 */           max[d] = this.inputInterval.dimension(d) - 1L;
/*     */         }
/* 241 */         else if (d == dim) {
/*     */ 
/*     */ 
/*     */           
/* 245 */           min[d] = ((this.kernel[d]).length / 2);
/* 246 */           max[d] = this.inputInterval.dimension(d) - 1L + ((this.kernel[d]).length / 2);
/*     */         
/*     */         }
/*     */         else {
/*     */ 
/*     */           
/* 252 */           min[d] = 0L;
/* 253 */           max[d] = this.inputInterval.dimension(d) - 1L + (this.kernel[d]).length - 1L;
/*     */         } 
/*     */       } 
/*     */     } 
/* 257 */     return (Interval)new FinalInterval(min, max);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected SamplingLineIterator<T> createInputLineSampler(int dim, Interval range) {
/*     */     RandomAccess<T> randomAccess;
/* 275 */     if (dim == 0) {
/* 276 */       randomAccess = this.input.randomAccess((Interval)Intervals.expand(range, ((this.kernel[dim]).length / 2), dim));
/* 277 */     } else if (dim % 2 == 1) {
/* 278 */       randomAccess = this.tmp1.randomAccess();
/*     */     } else {
/* 280 */       randomAccess = this.tmp2.randomAccess();
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 286 */     long sizeProcessLine = range.dimension(dim);
/*     */ 
/*     */ 
/*     */     
/* 290 */     long sizeInputData = sizeProcessLine + (this.kernel[dim]).length - 1L;
/*     */ 
/*     */     
/* 293 */     if (dim == 0) {
/*     */ 
/*     */ 
/*     */       
/* 297 */       range.min((Positionable)randomAccess);
/*     */ 
/*     */ 
/*     */       
/* 301 */       randomAccess.move(-((this.kernel[0]).length / 2), 0);
/*     */ 
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */       
/* 308 */       range.min((Positionable)randomAccess);
/*     */ 
/*     */ 
/*     */       
/* 312 */       randomAccess.move(-((this.kernel[dim]).length / 2), dim);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 320 */     return new SamplingLineIterator<>(dim, sizeInputData, randomAccess, getProcessingLine(sizeProcessLine), getProcessingType(), getProcessingType());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected WritableLineIterator<T> createOutputLineWriter(int dim, Interval range, SamplingLineIterator<T> inputLineSampler) {
/*     */     RandomAccess<T> randomAccess;
/* 340 */     if (dim == this.numDimensions - 1) {
/* 341 */       randomAccess = this.output.randomAccess();
/* 342 */     } else if (dim % 2 == 0) {
/* 343 */       randomAccess = this.tmp1.randomAccess();
/*     */     } else {
/* 345 */       randomAccess = this.tmp2.randomAccess();
/*     */     } 
/*     */     
/* 348 */     long sizeProcessLine = inputLineSampler.getProcessLine().size();
/*     */     
/* 350 */     if (dim == this.numDimensions - 1) {
/*     */ 
/*     */ 
/*     */       
/* 354 */       randomAccess.setPosition(this.outputOffset);
/*     */ 
/*     */     
/*     */     }
/* 358 */     else if (dim % 2 == 0) {
/* 359 */       this.tmp1.min((Positionable)randomAccess);
/*     */     } else {
/* 361 */       this.tmp2.min((Positionable)randomAccess);
/*     */     } 
/*     */     
/* 364 */     return (WritableLineIterator)new WritableLineIterator<>(dim, sizeProcessLine, (RandomAccess)randomAccess);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void processLine(SamplingLineIterator<T> input, double[] kernel) {
/* 380 */     int kernelSize = kernel.length;
/* 381 */     int kernelSizeMinus1 = kernelSize - 1;
/* 382 */     int kernelSizeHalf = kernelSize / 2;
/* 383 */     int kernelSizeHalfMinus1 = kernelSizeHalf - 1;
/*     */ 
/*     */     
/* 386 */     RandomAccess<T> randomAccessLeft = input.randomAccessLeft;
/* 387 */     RandomAccess<T> randomAccessRight = input.randomAccessRight;
/* 388 */     NumericType numericType1 = (NumericType)input.copy;
/* 389 */     NumericType numericType2 = (NumericType)input.tmp;
/*     */     
/* 391 */     long imgSize = input.getProcessLine().size();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 399 */     if (imgSize >= kernelSize) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 460 */       numericType1.set((Type)input.get());
/*     */ 
/*     */ 
/*     */       
/* 464 */       randomAccessLeft.setPosition(0, 0);
/*     */ 
/*     */       
/* 467 */       numericType1.mul(kernel[0]);
/* 468 */       ((NumericType)randomAccessLeft.get()).add(numericType1);
/*     */       
/* 470 */       for (int i = 1; i < kernelSizeMinus1; i++) {
/*     */         
/* 472 */         input.fwd();
/*     */ 
/*     */ 
/*     */         
/* 476 */         numericType1.set((Type)input.get());
/*     */ 
/*     */ 
/*     */         
/* 480 */         randomAccessLeft.setPosition(-1, 0);
/*     */ 
/*     */         
/* 483 */         for (int o = 0; o <= i; o++) {
/*     */           
/* 485 */           randomAccessLeft.fwd(0);
/*     */           
/* 487 */           numericType2.set((Type)numericType1);
/* 488 */           numericType2.mul(kernel[i - o]);
/*     */           
/* 490 */           ((NumericType)randomAccessLeft.get()).add(numericType2);
/*     */         } 
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 507 */       long length = imgSize - kernelSizeMinus1; long n;
/* 508 */       for (n = 0L; n < length; n++) {
/*     */         
/* 510 */         input.fwd();
/*     */ 
/*     */ 
/*     */         
/* 514 */         numericType1.set((Type)input.get());
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 519 */         randomAccessLeft.setPosition(n, 0);
/* 520 */         randomAccessRight.setPosition(n + kernelSizeMinus1, 0);
/*     */ 
/*     */         
/* 523 */         for (int k = 0; k < kernelSizeHalfMinus1; k++) {
/*     */           
/* 525 */           numericType2.set((Type)numericType1);
/* 526 */           numericType2.mul(kernel[k]);
/*     */           
/* 528 */           ((NumericType)randomAccessLeft.get()).add(numericType2);
/* 529 */           ((NumericType)randomAccessRight.get()).add(numericType2);
/*     */           
/* 531 */           randomAccessLeft.fwd(0);
/* 532 */           randomAccessRight.bck(0);
/*     */         } 
/*     */ 
/*     */ 
/*     */         
/* 537 */         numericType2.set((Type)numericType1);
/* 538 */         numericType2.mul(kernel[kernelSizeHalfMinus1]);
/*     */         
/* 540 */         ((NumericType)randomAccessLeft.get()).add(numericType2);
/* 541 */         ((NumericType)randomAccessRight.get()).add(numericType2);
/*     */         
/* 543 */         randomAccessLeft.fwd(0);
/*     */ 
/*     */         
/* 546 */         numericType2.set((Type)numericType1);
/* 547 */         numericType2.mul(kernel[kernelSizeHalf]);
/*     */         
/* 549 */         ((NumericType)randomAccessLeft.get()).add(numericType2);
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 566 */       long endLength = imgSize + kernelSizeMinus1; long l1;
/* 567 */       for (l1 = imgSize; l1 < endLength; l1++)
/*     */       {
/*     */ 
/*     */         
/* 571 */         input.fwd();
/*     */ 
/*     */ 
/*     */         
/* 575 */         numericType1.set((Type)input.get());
/*     */ 
/*     */ 
/*     */         
/* 579 */         randomAccessLeft.setPosition(l1 - kernelSize, 0);
/*     */ 
/*     */         
/* 582 */         int k = 0; long o;
/* 583 */         for (o = l1 - kernelSize + 1L; o < imgSize; o++)
/*     */         {
/* 585 */           randomAccessLeft.fwd(0);
/*     */           
/* 587 */           numericType2.set((Type)numericType1);
/* 588 */           numericType2.mul(kernel[k++]);
/*     */           
/* 590 */           ((NumericType)randomAccessLeft.get()).add(numericType2);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 620 */       numericType1.set((Type)input.get());
/*     */ 
/*     */ 
/*     */       
/* 624 */       randomAccessLeft.setPosition(0, 0);
/*     */ 
/*     */       
/* 627 */       numericType1.mul(kernel[0]);
/* 628 */       ((NumericType)randomAccessLeft.get()).add(numericType1);
/*     */       
/* 630 */       for (int j = 1; j < imgSize; j++) {
/*     */         
/* 632 */         input.fwd();
/*     */ 
/*     */ 
/*     */         
/* 636 */         numericType1.set((Type)input.get());
/*     */ 
/*     */ 
/*     */         
/* 640 */         randomAccessLeft.setPosition(-1, 0);
/*     */ 
/*     */         
/* 643 */         for (int o = 0; o <= j; o++) {
/*     */           
/* 645 */           randomAccessLeft.fwd(0);
/*     */           
/* 647 */           numericType2.set((Type)numericType1);
/* 648 */           numericType2.mul(kernel[j - o]);
/*     */           
/* 650 */           ((NumericType)randomAccessLeft.get()).add(numericType2);
/*     */         } 
/*     */       } 
/*     */       
/*     */       long i;
/*     */       
/* 656 */       for (i = imgSize; i < imgSize + kernelSizeMinus1; i++) {
/*     */ 
/*     */ 
/*     */         
/* 660 */         input.fwd();
/*     */ 
/*     */ 
/*     */         
/* 664 */         numericType1.set((Type)input.get());
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 669 */         long o = i - kernelSize + 1L;
/* 670 */         int k = 0;
/*     */         
/* 672 */         if (o < 0L) {
/*     */           
/* 674 */           k = -((int)o);
/* 675 */           o = 0L;
/*     */         } 
/*     */         
/* 678 */         randomAccessLeft.setPosition(o - 1L, 0);
/*     */ 
/*     */         
/* 681 */         for (; o < imgSize; o++) {
/*     */           
/* 683 */           randomAccessLeft.fwd(0);
/*     */           
/* 685 */           numericType2.set((Type)numericType1);
/* 686 */           numericType2.mul(kernel[k++]);
/*     */           
/* 688 */           ((NumericType)randomAccessLeft.get()).add(numericType2);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void writeLine(WritableLineIterator<T> a, SamplingLineIterator<T> inputLineSampler) {
/* 706 */     Cursor<T> resultCursor = inputLineSampler.resultCursor;
/* 707 */     resultCursor.reset();
/*     */ 
/*     */ 
/*     */     
/* 711 */     if (resultCursor.hasNext()) {
/*     */       
/* 713 */       resultCursor.fwd();
/* 714 */       a.set((T)resultCursor.get());
/*     */     } 
/*     */     
/* 717 */     while (resultCursor.hasNext()) {
/*     */       
/* 719 */       resultCursor.fwd();
/* 720 */       a.fwd();
/*     */       
/* 722 */       a.set((T)resultCursor.get());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void updateInputLineSampler(SamplingLineIterator<T> a, Interval range, long[] offset, Localizable originalLocation) {
/* 743 */     Positionable positionable = a.getPositionable();
/*     */     
/* 745 */     for (int d = 0; d < this.numDimensions; d++) {
/* 746 */       positionable.setPosition(originalLocation.getLongPosition(d) + offset[d], d);
/*     */     }
/*     */     
/* 749 */     for (NumericType numericType : a.getProcessLine()) {
/* 750 */       numericType.setZero();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void updateOutputLineWriter(WritableLineIterator<T> a, Interval range, long[] offset, Localizable originalLocation) {
/* 769 */     Positionable positionable = a.getPositionable();
/*     */     
/* 771 */     for (int d = 0; d < this.numDimensions; d++) {
/* 772 */       positionable.setPosition(originalLocation.getLongPosition(d) + offset[d], d);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void computeKernel() {
/* 780 */     for (int d = 0; d < this.numDimensions; d++) {
/* 781 */       this.kernel[d] = Util.createGaussianKernel1DDouble(this.sigma[d], true);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Interval getTemporaryImgSize() {
/* 789 */     return getRange(0);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getNumThreads() {
/* 794 */     return this.numThreads;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setNumThreads(int numThreads) {
/* 799 */     this.numThreads = Math.max(1, numThreads);
/*     */   }
/*     */ 
/*     */   
/*     */   public void call() {
/* 804 */     if (this.numDimensions > 1) {
/*     */       
/* 806 */       for (int d = 0; d < this.numDimensions; d++)
/*     */       {
/* 808 */         final int dim = d;
/* 809 */         final int numThreads = getNumThreads();
/*     */         
/* 811 */         final AtomicInteger ai = new AtomicInteger();
/* 812 */         Thread[] threads = SimpleMultiThreading.newThreads(numThreads);
/*     */         
/* 814 */         for (int ithread = 0; ithread < threads.length; ithread++) {
/* 815 */           threads[ithread] = new Thread(new Runnable()
/*     */               {
/*     */                 
/*     */                 public void run()
/*     */                 {
/* 820 */                   int myNumber = ai.getAndIncrement();
/*     */                   
/* 822 */                   Interval range = AbstractGauss.this.getRange(dim);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */                   
/* 830 */                   long[] fakeSize = new long[AbstractGauss.this.numDimensions - 1];
/* 831 */                   long[] tmp = new long[AbstractGauss.this.numDimensions];
/*     */ 
/*     */ 
/*     */                   
/* 835 */                   int countDim = 0;
/* 836 */                   for (int d = 0; d < AbstractGauss.this.numDimensions; d++) {
/* 837 */                     if (d != dim) {
/* 838 */                       fakeSize[countDim++] = range.dimension(d);
/*     */                     }
/*     */                   } 
/*     */                   
/* 842 */                   SamplingLineIterator<T> inputLineIterator = AbstractGauss.this.createInputLineSampler(dim, range);
/* 843 */                   Localizable offsetInput = inputLineIterator.getOffset();
/*     */ 
/*     */ 
/*     */                   
/* 847 */                   WritableLineIterator<T> outputLineIterator = AbstractGauss.this.createOutputLineWriter(dim, range, inputLineIterator);
/* 848 */                   Localizable offsetOutput = outputLineIterator.getOffset();
/*     */                   
/* 850 */                   LocalizingZeroMinIntervalIterator cursorDim = new LocalizingZeroMinIntervalIterator(fakeSize);
/*     */ 
/*     */ 
/*     */                   
/* 854 */                   while (cursorDim.hasNext()) {
/*     */                     
/* 856 */                     cursorDim.fwd();
/*     */                     
/* 858 */                     if (numThreads == 1 || cursorDim.getIntPosition(0) % numThreads == myNumber) {
/*     */ 
/*     */ 
/*     */                       
/* 862 */                       cursorDim.localize(fakeSize);
/*     */                       
/* 864 */                       tmp[dim] = 0L;
/* 865 */                       countDim = 0;
/* 866 */                       for (int i = 0; i < AbstractGauss.this.numDimensions; i++) {
/* 867 */                         if (i != dim) {
/* 868 */                           tmp[i] = fakeSize[countDim++];
/*     */                         }
/*     */                       } 
/*     */                       
/* 872 */                       AbstractGauss.this.updateInputLineSampler(inputLineIterator, range, tmp, offsetInput);
/*     */ 
/*     */                       
/* 875 */                       AbstractGauss.this.processLine(inputLineIterator, AbstractGauss.this.kernel[dim]);
/*     */ 
/*     */ 
/*     */                       
/* 879 */                       AbstractGauss.this.updateOutputLineWriter(outputLineIterator, range, tmp, offsetOutput);
/*     */ 
/*     */ 
/*     */                       
/* 883 */                       AbstractGauss.this.writeLine(outputLineIterator, inputLineIterator);
/*     */                     } 
/*     */                   } 
/*     */                 }
/*     */               });
/*     */         } 
/* 889 */         SimpleMultiThreading.startAndJoin(threads);
/*     */       }
/*     */     
/*     */     } else {
/*     */       
/* 894 */       Interval range = getRange(0);
/*     */ 
/*     */       
/* 897 */       SamplingLineIterator<T> inputLineIterator = createInputLineSampler(0, range);
/*     */ 
/*     */ 
/*     */       
/* 901 */       WritableLineIterator<T> outputLineIterator = createOutputLineWriter(0, range, inputLineIterator);
/*     */ 
/*     */       
/* 904 */       processLine(inputLineIterator, this.kernel[0]);
/*     */ 
/*     */       
/* 907 */       writeLine(outputLineIterator, inputLineIterator);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/imglib2-algorithm-0.6.2.jar!/net/imglib2/algorithm/gauss/AbstractGauss.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */