/*     */ package net.imglib2.algorithm.neighborhood;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import net.imglib2.AbstractEuclideanSpace;
/*     */ import net.imglib2.AbstractLocalizable;
/*     */ import net.imglib2.Cursor;
/*     */ import net.imglib2.Interval;
/*     */ import net.imglib2.Positionable;
/*     */ import net.imglib2.RandomAccess;
/*     */ import net.imglib2.RealCursor;
/*     */ import net.imglib2.RealPositionable;
/*     */ import net.imglib2.Sampler;
/*     */ import net.imglib2.util.Intervals;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PeriodicLineNeighborhood<T>
/*     */   extends AbstractLocalizable
/*     */   implements Neighborhood<T>
/*     */ {
/*     */   private final long span;
/*     */   private final int[] increments;
/*     */   private final RandomAccess<T> sourceRandomAccess;
/*     */   private final Interval structuringElementBoundingBox;
/*     */   private final long maxIndex;
/*     */   
/*     */   public static <T> PeriodicLineNeighborhoodFactory<T> factory() {
/*  63 */     return new PeriodicLineNeighborhoodFactory<T>()
/*     */       {
/*     */         
/*     */         public Neighborhood<T> create(long[] position, long span, int[] increments, RandomAccess<T> sourceRandomAccess)
/*     */         {
/*  68 */           return new PeriodicLineNeighborhood<>(position, span, increments, sourceRandomAccess);
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   PeriodicLineNeighborhood(long[] position, long span, int[] increments, RandomAccess<T> sourceRandomAccess) {
/* 133 */     super(position);
/* 134 */     this.increments = increments;
/* 135 */     this.span = span;
/* 136 */     this.maxIndex = 2L * span + 1L;
/* 137 */     this.sourceRandomAccess = sourceRandomAccess;
/* 138 */     this.structuringElementBoundingBox = createInterval();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Interval getStructuringElementBoundingBox() {
/* 144 */     return this.structuringElementBoundingBox;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public long size() {
/* 150 */     return this.maxIndex;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public T firstElement() {
/* 156 */     return cursor().next();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object iterationOrder() {
/* 162 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public double realMin(int d) {
/* 168 */     return this.structuringElementBoundingBox.realMin(d);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void realMin(double[] min) {
/* 174 */     for (int d = 0; d < this.n; d++) {
/* 175 */       min[d] = this.structuringElementBoundingBox.realMin(d);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void realMin(RealPositionable min) {
/* 181 */     for (int d = 0; d < this.n; d++) {
/* 182 */       min.setPosition(this.structuringElementBoundingBox.realMin(d), d);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public double realMax(int d) {
/* 188 */     return this.structuringElementBoundingBox.realMax(d);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void realMax(double[] max) {
/* 194 */     for (int d = 0; d < this.n; d++) {
/* 195 */       max[d] = this.structuringElementBoundingBox.realMax(d);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void realMax(RealPositionable max) {
/* 201 */     for (int d = 0; d < this.n; d++) {
/* 202 */       max.setPosition(this.structuringElementBoundingBox.realMax(d), d);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public Iterator<T> iterator() {
/* 208 */     return (Iterator<T>)cursor();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public long min(int d) {
/* 214 */     return this.structuringElementBoundingBox.min(d);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void min(long[] min) {
/* 220 */     for (int d = 0; d < this.n; d++) {
/* 221 */       min[d] = this.structuringElementBoundingBox.min(d);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void min(Positionable min) {
/* 227 */     for (int d = 0; d < this.n; d++) {
/* 228 */       min.setPosition(this.structuringElementBoundingBox.min(d), d);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public long max(int d) {
/* 234 */     return this.structuringElementBoundingBox.max(d);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void max(long[] max) {
/* 240 */     for (int d = 0; d < this.n; d++) {
/* 241 */       max[d] = this.structuringElementBoundingBox.max(d);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void max(Positionable max) {
/* 247 */     for (int d = 0; d < this.n; d++) {
/* 248 */       max.setPosition(this.structuringElementBoundingBox.max(d), d);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void dimensions(long[] dimensions) {
/* 254 */     for (int d = 0; d < this.n; d++) {
/* 255 */       dimensions[d] = dimension(d);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public long dimension(int d) {
/* 261 */     return 1L + 2L * this.span * Math.abs(this.increments[d]);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public LocalCursor cursor() {
/* 267 */     return new LocalCursor(this.sourceRandomAccess.copyRandomAccess());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public LocalCursor localizingCursor() {
/* 273 */     return cursor();
/*     */   }
/*     */   
/*     */   public final class LocalCursor
/*     */     extends AbstractEuclideanSpace
/*     */     implements Cursor<T>
/*     */   {
/*     */     private final RandomAccess<T> source;
/*     */     private long index;
/*     */     
/*     */     private LocalCursor(RandomAccess<T> source) {
/* 284 */       super(source.numDimensions());
/* 285 */       this.source = source;
/* 286 */       reset();
/*     */     }
/*     */ 
/*     */     
/*     */     private LocalCursor(LocalCursor c) {
/* 291 */       super(c.numDimensions());
/* 292 */       this.source = c.source.copyRandomAccess();
/* 293 */       this.index = c.index;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public T get() {
/* 299 */       return (T)this.source.get();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void fwd() {
/* 305 */       this.source.move(PeriodicLineNeighborhood.this.increments);
/* 306 */       this.index++;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void jumpFwd(long steps) {
/* 312 */       for (int i = 0; i < steps; i++)
/*     */       {
/* 314 */         fwd();
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public T next() {
/* 321 */       fwd();
/* 322 */       return get();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void remove() {}
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void reset() {
/* 334 */       this.source.setPosition(PeriodicLineNeighborhood.this.position);
/* 335 */       int[] minusIncrements = new int[PeriodicLineNeighborhood.this.increments.length]; int i;
/* 336 */       for (i = 0; i < minusIncrements.length; i++)
/*     */       {
/* 338 */         minusIncrements[i] = -PeriodicLineNeighborhood.this.increments[i];
/*     */       }
/*     */       
/* 341 */       for (i = 0; i <= PeriodicLineNeighborhood.this.span; i++)
/*     */       {
/* 343 */         this.source.move(minusIncrements);
/*     */       }
/* 345 */       this.index = 0L;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean hasNext() {
/* 351 */       return (this.index < PeriodicLineNeighborhood.this.maxIndex);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public float getFloatPosition(int d) {
/* 357 */       return this.source.getFloatPosition(d);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public double getDoublePosition(int d) {
/* 363 */       return this.source.getDoublePosition(d);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public int getIntPosition(int d) {
/* 369 */       return this.source.getIntPosition(d);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public long getLongPosition(int d) {
/* 375 */       return this.source.getLongPosition(d);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void localize(long[] position) {
/* 381 */       this.source.localize(position);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void localize(float[] position) {
/* 387 */       this.source.localize(position);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void localize(double[] position) {
/* 393 */       this.source.localize(position);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void localize(int[] position) {
/* 399 */       this.source.localize(position);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public LocalCursor copy() {
/* 405 */       return new LocalCursor(this);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public LocalCursor copyCursor() {
/* 411 */       return copy();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private Interval createInterval() {
/* 417 */     long[] minmax = new long[2 * this.position.length]; int i;
/* 418 */     for (i = 0; i < this.position.length; i++)
/*     */     {
/* 420 */       minmax[i] = this.position[i] - this.span * Math.abs(this.increments[i]);
/*     */     }
/* 422 */     for (i = this.position.length; i < minmax.length; i++)
/*     */     {
/* 424 */       minmax[i] = this.position[i - this.position.length] + this.span * Math.abs(this.increments[i - this.position.length]);
/*     */     }
/* 426 */     return (Interval)Intervals.createMinMax(minmax);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/imglib2-algorithm-0.6.2.jar!/net/imglib2/algorithm/neighborhood/PeriodicLineNeighborhood.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */