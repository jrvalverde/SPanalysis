package net.imglib2.algorithm.componenttree;

import java.util.List;
import net.imglib2.Localizable;

public interface Component<T, C extends Component<T, C>> extends Iterable<Localizable> {
  long size();
  
  T value();
  
  C getParent();
  
  List<C> getChildren();
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/imglib2-algorithm-0.6.2.jar!/net/imglib2/algorithm/componenttree/Component.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */