/*     */ package net.imglib2.algorithm.region.localneighborhood.old;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import net.imglib2.Cursor;
/*     */ import net.imglib2.IterableInterval;
/*     */ import net.imglib2.Localizable;
/*     */ import net.imglib2.Positionable;
/*     */ import net.imglib2.RandomAccessible;
/*     */ import net.imglib2.RealCursor;
/*     */ import net.imglib2.RealPositionable;
/*     */ import net.imglib2.util.Util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public class LocalNeighborhood2<T>
/*     */   implements IterableInterval<T>
/*     */ {
/*     */   final int numDimensions;
/*     */   final long size;
/*     */   final long[] center;
/*     */   final RandomAccessible<T> source;
/*     */   
/*     */   public LocalNeighborhood2(RandomAccessible<T> source, Localizable center) {
/*  63 */     this.numDimensions = source.numDimensions();
/*  64 */     this.center = new long[this.numDimensions];
/*  65 */     center.localize(this.center);
/*     */     
/*  67 */     this.size = (Util.pow(3, this.numDimensions) - 1);
/*     */     
/*  69 */     this.source = source;
/*     */   }
/*     */ 
/*     */   
/*     */   public void updateCenter(long[] center) {
/*  74 */     for (int d = 0; d < this.numDimensions; d++) {
/*  75 */       this.center[d] = center[d];
/*     */     }
/*     */   }
/*     */   
/*     */   public void updateCenter(Localizable center) {
/*  80 */     for (int d = 0; d < this.numDimensions; d++) {
/*  81 */       this.center[d] = center.getLongPosition(d);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public long size() {
/*  87 */     return this.size;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public T firstElement() {
/*  93 */     return (T)cursor().next();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object iterationOrder() {
/*  99 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public double realMin(int d) {
/* 105 */     return (this.center[d] - 1L);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void realMin(double[] min) {
/* 111 */     for (int d = 0; d < this.numDimensions; d++) {
/* 112 */       min[d] = (this.center[d] - 1L);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void realMin(RealPositionable min) {
/* 118 */     for (int d = 0; d < this.numDimensions; d++) {
/* 119 */       min.setPosition(this.center[d] - 1L, d);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public double realMax(int d) {
/* 125 */     return (this.center[d] + 1L);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void realMax(double[] max) {
/* 131 */     for (int d = 0; d < this.numDimensions; d++) {
/* 132 */       max[d] = (this.center[d] + 1L);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void realMax(RealPositionable max) {
/* 138 */     for (int d = 0; d < this.numDimensions; d++) {
/* 139 */       max.setPosition(this.center[d] + 1L, d);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public int numDimensions() {
/* 145 */     return this.numDimensions;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Iterator<T> iterator() {
/* 151 */     return (Iterator<T>)cursor();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public long min(int d) {
/* 157 */     return this.center[d] - 1L;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void min(long[] min) {
/* 163 */     for (int d = 0; d < this.numDimensions; d++) {
/* 164 */       min[d] = this.center[d] - 1L;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void min(Positionable min) {
/* 170 */     for (int d = 0; d < this.numDimensions; d++) {
/* 171 */       min.setPosition(this.center[d] - 1L, d);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public long max(int d) {
/* 177 */     return this.center[d] + 1L;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void max(long[] max) {
/* 183 */     for (int d = 0; d < this.numDimensions; d++) {
/* 184 */       max[d] = this.center[d] + 1L;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void max(Positionable max) {
/* 190 */     for (int d = 0; d < this.numDimensions; d++) {
/* 191 */       max.setPosition(this.center[d] - 1L, d);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void dimensions(long[] dimensions) {
/* 197 */     for (int d = 0; d < this.numDimensions; d++) {
/* 198 */       dimensions[d] = 3L;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public long dimension(int d) {
/* 204 */     return 3L;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public LocalNeighborhoodCursor2<T> cursor() {
/* 210 */     return new LocalNeighborhoodCursor2<>(this.source.randomAccess(), this.center);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public LocalNeighborhoodCursor2<T> localizingCursor() {
/* 216 */     return cursor();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/imglib2-algorithm-0.6.2.jar!/net/imglib2/algorithm/region/localneighborhood/old/LocalNeighborhood2.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */