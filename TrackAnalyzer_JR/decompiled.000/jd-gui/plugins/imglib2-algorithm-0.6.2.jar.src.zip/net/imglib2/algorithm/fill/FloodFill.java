/*     */ package net.imglib2.algorithm.fill;
/*     */ 
/*     */ import gnu.trove.list.TLongList;
/*     */ import gnu.trove.list.array.TLongArrayList;
/*     */ import net.imglib2.Cursor;
/*     */ import net.imglib2.Localizable;
/*     */ import net.imglib2.RandomAccess;
/*     */ import net.imglib2.RandomAccessible;
/*     */ import net.imglib2.algorithm.neighborhood.Neighborhood;
/*     */ import net.imglib2.algorithm.neighborhood.Shape;
/*     */ import net.imglib2.type.Type;
/*     */ import net.imglib2.util.Pair;
/*     */ import net.imglib2.util.ValuePair;
/*     */ import net.imglib2.view.Views;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FloodFill
/*     */ {
/*     */   private static final int CLEANUP_THRESHOLD = 100000;
/*     */   
/*     */   public static <T extends Type<T>, U extends Type<U>> void fill(RandomAccessible<T> source, RandomAccessible<U> target, Localizable seed, U fillLabel, Shape shape, Filter<Pair<T, U>, Pair<T, U>> filter) {
/*  93 */     RandomAccess<T> access = source.randomAccess();
/*  94 */     access.setPosition(seed);
/*  95 */     fill(source, target, seed, (T)((Type)access.get()).copy(), fillLabel, shape, filter);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T, U extends Type<U>> void fill(RandomAccessible<T> source, RandomAccessible<U> target, Localizable seed, T seedLabel, U fillLabel, Shape shape, Filter<Pair<T, U>, Pair<T, U>> filter) {
/* 132 */     fill(source, target, seed, seedLabel, fillLabel, shape, filter, new TypeWriter<>());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T, U> void fill(RandomAccessible<T> source, RandomAccessible<U> target, Localizable seed, T seedLabel, U fillLabel, Shape shape, Filter<Pair<T, U>, Pair<T, U>> filter, Writer<U> writer) {
/* 175 */     int n = source.numDimensions();
/*     */     
/* 177 */     ValuePair<T, U> reference = new ValuePair(seedLabel, fillLabel);
/*     */     
/* 179 */     RandomAccessible<Pair<T, U>> paired = Views.pair(source, target);
/*     */     
/* 181 */     TLongList[] coordinates = new TLongList[n];
/* 182 */     for (int d = 0; d < n; d++) {
/*     */       
/* 184 */       coordinates[d] = (TLongList)new TLongArrayList();
/* 185 */       coordinates[d].add(seed.getLongPosition(d));
/*     */     } 
/*     */     
/* 188 */     RandomAccessible<Neighborhood<Pair<T, U>>> neighborhood = shape.neighborhoodsRandomAccessible(paired);
/* 189 */     RandomAccess<Neighborhood<Pair<T, U>>> neighborhoodAccess = neighborhood.randomAccess();
/*     */     
/* 191 */     RandomAccess<U> targetAccess = target.randomAccess();
/* 192 */     targetAccess.setPosition(seed);
/* 193 */     writer.write(fillLabel, (U)targetAccess.get());
/*     */     
/* 195 */     for (int i = 0; i < coordinates[0].size(); i++) {
/*     */       
/* 197 */       for (int j = 0; j < n; j++) {
/* 198 */         neighborhoodAccess.setPosition(coordinates[j].get(i), j);
/*     */       }
/* 200 */       Cursor<Pair<T, U>> neighborhoodCursor = ((Neighborhood)neighborhoodAccess.get()).cursor();
/*     */       
/* 202 */       while (neighborhoodCursor.hasNext()) {
/*     */         
/* 204 */         Pair<T, U> p = (Pair<T, U>)neighborhoodCursor.next();
/* 205 */         if (filter.accept(p, reference)) {
/*     */           
/* 207 */           writer.write(fillLabel, (U)p.getB());
/* 208 */           for (int k = 0; k < n; k++) {
/* 209 */             coordinates[k].add(neighborhoodCursor.getLongPosition(k));
/*     */           }
/*     */         } 
/*     */       } 
/* 213 */       if (i > 100000) {
/*     */         
/* 215 */         for (int k = 0; k < coordinates.length; k++) {
/*     */           
/* 217 */           TLongList c = coordinates[k];
/* 218 */           coordinates[k] = c.subList(i, c.size());
/*     */         } 
/* 220 */         i = 0;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/imglib2-algorithm-0.6.2.jar!/net/imglib2/algorithm/fill/FloodFill.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */