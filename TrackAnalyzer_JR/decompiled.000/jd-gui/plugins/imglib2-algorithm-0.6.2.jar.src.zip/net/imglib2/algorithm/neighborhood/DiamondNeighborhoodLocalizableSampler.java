/*     */ package net.imglib2.algorithm.neighborhood;
/*     */ 
/*     */ import net.imglib2.AbstractEuclideanSpace;
/*     */ import net.imglib2.FinalInterval;
/*     */ import net.imglib2.Interval;
/*     */ import net.imglib2.Localizable;
/*     */ import net.imglib2.RandomAccessible;
/*     */ import net.imglib2.Sampler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class DiamondNeighborhoodLocalizableSampler<T>
/*     */   extends AbstractEuclideanSpace
/*     */   implements Localizable, Sampler<Neighborhood<T>>
/*     */ {
/*     */   protected final RandomAccessible<T> source;
/*     */   protected final Interval sourceInterval;
/*     */   protected final long radius;
/*     */   protected final DiamondNeighborhoodFactory<T> factory;
/*     */   protected final long[] currentPos;
/*     */   protected final Neighborhood<T> currentNeighborhood;
/*     */   
/*     */   public DiamondNeighborhoodLocalizableSampler(RandomAccessible<T> source, long radius, DiamondNeighborhoodFactory<T> factory, Interval accessInterval) {
/*  59 */     super(source.numDimensions());
/*  60 */     this.source = source;
/*  61 */     this.radius = radius;
/*  62 */     this.factory = factory;
/*  63 */     this.currentPos = new long[this.n];
/*     */     
/*  65 */     if (accessInterval == null) {
/*     */       
/*  67 */       this.sourceInterval = null;
/*     */     }
/*     */     else {
/*     */       
/*  71 */       long[] accessMin = new long[this.n];
/*  72 */       long[] accessMax = new long[this.n];
/*  73 */       accessInterval.min(accessMin);
/*  74 */       accessInterval.max(accessMax);
/*  75 */       for (int d = 0; d < this.n; d++) {
/*     */         
/*  77 */         accessMin[d] = this.currentPos[d] - radius;
/*  78 */         accessMax[d] = this.currentPos[d] + radius;
/*     */       } 
/*  80 */       this.sourceInterval = (Interval)new FinalInterval(accessMin, accessMax);
/*     */     } 
/*     */     
/*  83 */     this.currentNeighborhood = factory.create(this.currentPos, radius, (this.sourceInterval == null) ? source.randomAccess() : source.randomAccess(this.sourceInterval));
/*     */   }
/*     */ 
/*     */   
/*     */   protected DiamondNeighborhoodLocalizableSampler(DiamondNeighborhoodLocalizableSampler<T> c) {
/*  88 */     super(c.n);
/*  89 */     this.source = c.source;
/*  90 */     this.sourceInterval = c.sourceInterval;
/*  91 */     this.radius = c.radius;
/*  92 */     this.factory = c.factory;
/*  93 */     this.currentPos = (long[])c.currentPos.clone();
/*  94 */     this.currentNeighborhood = this.factory.create(this.currentPos, this.radius, (this.sourceInterval == null) ? this.source.randomAccess() : this.source.randomAccess(this.sourceInterval));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void localize(float[] position) {
/* 100 */     this.currentNeighborhood.localize(position);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void localize(double[] position) {
/* 106 */     this.currentNeighborhood.localize(position);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public float getFloatPosition(int d) {
/* 112 */     return this.currentNeighborhood.getFloatPosition(d);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public double getDoublePosition(int d) {
/* 118 */     return this.currentNeighborhood.getDoublePosition(d);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Neighborhood<T> get() {
/* 124 */     return this.currentNeighborhood;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void localize(int[] position) {
/* 130 */     this.currentNeighborhood.localize(position);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void localize(long[] position) {
/* 136 */     this.currentNeighborhood.localize(position);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getIntPosition(int d) {
/* 142 */     return this.currentNeighborhood.getIntPosition(d);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public long getLongPosition(int d) {
/* 148 */     return this.currentNeighborhood.getLongPosition(d);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/imglib2-algorithm-0.6.2.jar!/net/imglib2/algorithm/neighborhood/DiamondNeighborhoodLocalizableSampler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */