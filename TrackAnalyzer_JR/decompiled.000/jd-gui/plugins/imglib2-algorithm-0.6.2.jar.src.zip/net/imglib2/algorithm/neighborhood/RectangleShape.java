/*     */ package net.imglib2.algorithm.neighborhood;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import net.imglib2.AbstractEuclideanSpace;
/*     */ import net.imglib2.AbstractInterval;
/*     */ import net.imglib2.Cursor;
/*     */ import net.imglib2.FinalInterval;
/*     */ import net.imglib2.FlatIterationOrder;
/*     */ import net.imglib2.Interval;
/*     */ import net.imglib2.IterableInterval;
/*     */ import net.imglib2.RandomAccess;
/*     */ import net.imglib2.RandomAccessible;
/*     */ import net.imglib2.RandomAccessibleInterval;
/*     */ import net.imglib2.RealCursor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RectangleShape
/*     */   implements Shape
/*     */ {
/*     */   final int span;
/*     */   final boolean skipCenter;
/*     */   
/*     */   public RectangleShape(int span, boolean skipCenter) {
/*  68 */     this.span = span;
/*  69 */     this.skipCenter = skipCenter;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> NeighborhoodsIterableInterval<T> neighborhoods(RandomAccessibleInterval<T> source) {
/*  75 */     RectangleNeighborhoodFactory<T> f = this.skipCenter ? RectangleNeighborhoodSkipCenterUnsafe.<T>factory() : RectangleNeighborhoodUnsafe.<T>factory();
/*  76 */     Interval spanInterval = createSpan(source.numDimensions());
/*  77 */     return new NeighborhoodsIterableInterval<>(source, spanInterval, f);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> NeighborhoodsAccessible<T> neighborhoodsRandomAccessible(RandomAccessible<T> source) {
/*  83 */     RectangleNeighborhoodFactory<T> f = this.skipCenter ? RectangleNeighborhoodSkipCenterUnsafe.<T>factory() : RectangleNeighborhoodUnsafe.<T>factory();
/*  84 */     Interval spanInterval = createSpan(source.numDimensions());
/*  85 */     return new NeighborhoodsAccessible<>(source, spanInterval, f);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> NeighborhoodsIterableInterval<T> neighborhoodsSafe(RandomAccessibleInterval<T> source) {
/*  91 */     RectangleNeighborhoodFactory<T> f = this.skipCenter ? RectangleNeighborhoodSkipCenter.<T>factory() : RectangleNeighborhood.<T>factory();
/*  92 */     Interval spanInterval = createSpan(source.numDimensions());
/*  93 */     return new NeighborhoodsIterableInterval<>(source, spanInterval, f);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> NeighborhoodsAccessible<T> neighborhoodsRandomAccessibleSafe(RandomAccessible<T> source) {
/*  99 */     RectangleNeighborhoodFactory<T> f = this.skipCenter ? RectangleNeighborhoodSkipCenter.<T>factory() : RectangleNeighborhood.<T>factory();
/* 100 */     Interval spanInterval = createSpan(source.numDimensions());
/* 101 */     return new NeighborhoodsAccessible<>(source, spanInterval, f);
/*     */   }
/*     */ 
/*     */   
/*     */   private Interval createSpan(int n) {
/* 106 */     long[] min = new long[n];
/* 107 */     long[] max = new long[n];
/* 108 */     for (int d = 0; d < n; d++) {
/*     */       
/* 110 */       min[d] = -this.span;
/* 111 */       max[d] = this.span;
/*     */     } 
/* 113 */     return (Interval)new FinalInterval(min, max);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSkippingCenter() {
/* 123 */     return this.skipCenter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getSpan() {
/* 131 */     return this.span;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 137 */     return "RectangleShape, span = " + this.span;
/*     */   }
/*     */ 
/*     */   
/*     */   public static final class NeighborhoodsIterableInterval<T>
/*     */     extends AbstractInterval
/*     */     implements IterableInterval<Neighborhood<T>>
/*     */   {
/*     */     final RandomAccessibleInterval<T> source;
/*     */     
/*     */     final Interval span;
/*     */     final RectangleNeighborhoodFactory<T> factory;
/*     */     final long size;
/*     */     
/*     */     public NeighborhoodsIterableInterval(RandomAccessibleInterval<T> source, Interval span, RectangleNeighborhoodFactory<T> factory) {
/* 152 */       super((Interval)source);
/* 153 */       this.source = source;
/* 154 */       this.span = span;
/* 155 */       this.factory = factory;
/* 156 */       long s = source.dimension(0);
/* 157 */       for (int d = 1; d < this.n; d++)
/* 158 */         s *= source.dimension(d); 
/* 159 */       this.size = s;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Cursor<Neighborhood<T>> cursor() {
/* 165 */       return new RectangleNeighborhoodCursor<>(this.source, this.span, this.factory);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public long size() {
/* 171 */       return this.size;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Neighborhood<T> firstElement() {
/* 177 */       return (Neighborhood<T>)cursor().next();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Object iterationOrder() {
/* 183 */       return new FlatIterationOrder((Interval)this);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Iterator<Neighborhood<T>> iterator() {
/* 189 */       return (Iterator<Neighborhood<T>>)cursor();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Cursor<Neighborhood<T>> localizingCursor() {
/* 195 */       return cursor();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static final class NeighborhoodsAccessible<T>
/*     */     extends AbstractEuclideanSpace
/*     */     implements RandomAccessible<Neighborhood<T>>
/*     */   {
/*     */     final RandomAccessible<T> source;
/*     */     final Interval span;
/*     */     final RectangleNeighborhoodFactory<T> factory;
/*     */     
/*     */     public NeighborhoodsAccessible(RandomAccessible<T> source, Interval span, RectangleNeighborhoodFactory<T> factory) {
/* 209 */       super(source.numDimensions());
/* 210 */       this.source = source;
/* 211 */       this.span = span;
/* 212 */       this.factory = factory;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public RandomAccess<Neighborhood<T>> randomAccess() {
/* 218 */       return new RectangleNeighborhoodRandomAccess<>(this.source, this.span, this.factory);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public RandomAccess<Neighborhood<T>> randomAccess(Interval interval) {
/* 224 */       return new RectangleNeighborhoodRandomAccess<>(this.source, this.span, this.factory, interval);
/*     */     }
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/imglib2-algorithm-0.6.2.jar!/net/imglib2/algorithm/neighborhood/RectangleShape.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */