/*     */ package net.imglib2.algorithm.neighborhood;
/*     */ 
/*     */ import net.imglib2.Cursor;
/*     */ import net.imglib2.Interval;
/*     */ import net.imglib2.RandomAccessible;
/*     */ import net.imglib2.RandomAccessibleInterval;
/*     */ import net.imglib2.RealCursor;
/*     */ import net.imglib2.Sampler;
/*     */ import net.imglib2.util.IntervalIndexer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HorizontalLineNeighborhoodCursor<T>
/*     */   extends HorizontalLineNeighborhoodLocalizableSampler<T>
/*     */   implements Cursor<Neighborhood<T>>
/*     */ {
/*     */   private final long[] dimensions;
/*     */   private long index;
/*     */   private final long maxIndex;
/*     */   private long maxIndexOnLine;
/*     */   private long[] min;
/*     */   private long[] max;
/*     */   
/*     */   public HorizontalLineNeighborhoodCursor(RandomAccessibleInterval<T> source, long span, int dim, boolean skipCenter, HorizontalLineNeighborhoodFactory<T> factory) {
/*  56 */     super((RandomAccessible<T>)source, span, dim, skipCenter, factory, (Interval)source);
/*     */     
/*  58 */     this.dimensions = new long[this.n];
/*     */     
/*  60 */     this.min = new long[this.n];
/*  61 */     this.max = new long[this.n];
/*  62 */     source.dimensions(this.dimensions);
/*  63 */     source.min(this.min);
/*  64 */     source.max(this.max);
/*     */     
/*  66 */     long size = this.dimensions[0];
/*  67 */     for (int d = 1; d < this.n; d++)
/*  68 */       size *= this.dimensions[d]; 
/*  69 */     this.maxIndex = size - 1L;
/*  70 */     reset();
/*     */   }
/*     */ 
/*     */   
/*     */   private HorizontalLineNeighborhoodCursor(HorizontalLineNeighborhoodCursor<T> c) {
/*  75 */     super(c);
/*  76 */     this.dimensions = (long[])c.dimensions.clone();
/*  77 */     this.maxIndex = c.maxIndex;
/*  78 */     this.index = c.index;
/*  79 */     this.maxIndexOnLine = c.maxIndexOnLine;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void fwd() {
/*  85 */     this.currentPos[0] = this.currentPos[0] + 1L;
/*  86 */     if (++this.index > this.maxIndexOnLine) {
/*  87 */       nextLine();
/*     */     }
/*     */   }
/*     */   
/*     */   private void nextLine() {
/*  92 */     this.currentPos[0] = this.min[0];
/*  93 */     this.maxIndexOnLine += this.dimensions[0];
/*  94 */     for (int d = 1; d < this.n; ) {
/*     */       
/*  96 */       this.currentPos[d] = this.currentPos[d] + 1L;
/*  97 */       if (this.currentPos[d] > this.max[d]) {
/*     */         
/*  99 */         this.currentPos[d] = this.min[d];
/*     */         d++;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void reset() {
/* 109 */     this.index = -1L;
/* 110 */     this.maxIndexOnLine = -1L;
/* 111 */     System.arraycopy(this.max, 0, this.currentPos, 0, this.n);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasNext() {
/* 117 */     return (this.index < this.maxIndex);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void jumpFwd(long steps) {
/* 123 */     this.index += steps;
/* 124 */     if (this.index < 0L) {
/*     */       
/* 126 */       this.maxIndexOnLine = (1L + this.index) / this.dimensions[0] * this.dimensions[0] - 1L;
/* 127 */       long size = this.maxIndex + 1L;
/* 128 */       IntervalIndexer.indexToPositionWithOffset(size - -this.index % size, this.dimensions, this.min, this.currentPos);
/*     */     }
/*     */     else {
/*     */       
/* 132 */       this.maxIndexOnLine = (1L + this.index / this.dimensions[0]) * this.dimensions[0] - 1L;
/* 133 */       IntervalIndexer.indexToPositionWithOffset(this.index, this.dimensions, this.min, this.currentPos);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Neighborhood<T> next() {
/* 140 */     fwd();
/* 141 */     return get();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void remove() {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HorizontalLineNeighborhoodCursor<T> copy() {
/* 153 */     return new HorizontalLineNeighborhoodCursor(this);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public HorizontalLineNeighborhoodCursor<T> copyCursor() {
/* 159 */     return copy();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/imglib2-algorithm-0.6.2.jar!/net/imglib2/algorithm/neighborhood/HorizontalLineNeighborhoodCursor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */