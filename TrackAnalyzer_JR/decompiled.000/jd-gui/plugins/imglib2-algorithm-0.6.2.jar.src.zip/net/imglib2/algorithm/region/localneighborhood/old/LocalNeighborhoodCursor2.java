/*     */ package net.imglib2.algorithm.region.localneighborhood.old;
/*     */ 
/*     */ import net.imglib2.AbstractCursor;
/*     */ import net.imglib2.Cursor;
/*     */ import net.imglib2.RandomAccess;
/*     */ import net.imglib2.RealCursor;
/*     */ import net.imglib2.Sampler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public class LocalNeighborhoodCursor2<T>
/*     */   extends AbstractCursor<T>
/*     */ {
/*     */   final RandomAccess<T> source;
/*     */   private final long[] center;
/*     */   private final long[] min;
/*     */   private final long[] max;
/*     */   private final long span;
/*     */   private final long maxCount;
/*     */   private final long midCount;
/*     */   private long count;
/*     */   
/*     */   public LocalNeighborhoodCursor2(RandomAccess<T> source, long[] center, long span) {
/*  72 */     super(source.numDimensions());
/*  73 */     this.source = source;
/*  74 */     this.center = center;
/*  75 */     this.max = new long[this.n];
/*  76 */     this.min = new long[this.n];
/*  77 */     this.span = span;
/*  78 */     this.maxCount = (long)Math.pow((span + 1L + span), this.n);
/*  79 */     this.midCount = this.maxCount / 2L + 1L;
/*  80 */     reset();
/*     */   }
/*     */ 
/*     */   
/*     */   public LocalNeighborhoodCursor2(RandomAccess<T> source, long[] center) {
/*  85 */     this(source, center, 1L);
/*     */   }
/*     */ 
/*     */   
/*     */   protected LocalNeighborhoodCursor2(LocalNeighborhoodCursor2<T> c) {
/*  90 */     super(c.numDimensions());
/*  91 */     this.source = c.source.copyRandomAccess();
/*  92 */     this.center = c.center;
/*  93 */     this.max = (long[])c.max.clone();
/*  94 */     this.min = (long[])c.min.clone();
/*  95 */     this.span = c.span;
/*  96 */     this.maxCount = c.maxCount;
/*  97 */     this.midCount = c.midCount;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public T get() {
/* 103 */     return (T)this.source.get();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void fwd() {
/* 109 */     this.source.fwd(0);
/* 110 */     if (this.source.getLongPosition(0) > this.max[0]) {
/*     */       
/* 112 */       this.source.setPosition(this.min[0], 0);
/* 113 */       for (int d = 1; d < this.n; ) {
/*     */         
/* 115 */         this.source.fwd(d);
/* 116 */         if (this.source.getLongPosition(d) > this.max[d]) {
/* 117 */           this.source.setPosition(this.min[d], d);
/*     */           d++;
/*     */         } 
/*     */       } 
/*     */     } 
/* 122 */     if (++this.count == this.midCount) {
/* 123 */       fwd();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void reset() {
/* 129 */     for (int d = 0; d < this.n; d++) {
/*     */       
/* 131 */       this.min[d] = this.center[d] - this.span;
/* 132 */       this.max[d] = this.center[d] + this.span;
/*     */     } 
/* 134 */     this.source.setPosition(this.min);
/* 135 */     this.source.bck(0);
/* 136 */     this.count = 0L;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasNext() {
/* 142 */     return (this.count < this.maxCount);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public float getFloatPosition(int d) {
/* 148 */     return this.source.getFloatPosition(d);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public double getDoublePosition(int d) {
/* 154 */     return this.source.getDoublePosition(d);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getIntPosition(int d) {
/* 160 */     return this.source.getIntPosition(d);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public long getLongPosition(int d) {
/* 166 */     return this.source.getLongPosition(d);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void localize(long[] position) {
/* 172 */     this.source.localize(position);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void localize(float[] position) {
/* 178 */     this.source.localize(position);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void localize(double[] position) {
/* 184 */     this.source.localize(position);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void localize(int[] position) {
/* 190 */     this.source.localize(position);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public LocalNeighborhoodCursor2<T> copy() {
/* 196 */     return new LocalNeighborhoodCursor2(this);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public LocalNeighborhoodCursor2<T> copyCursor() {
/* 202 */     return copy();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/imglib2-algorithm-0.6.2.jar!/net/imglib2/algorithm/region/localneighborhood/old/LocalNeighborhoodCursor2.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */