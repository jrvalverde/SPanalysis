/*    */ package net.imglib2.algorithm.function;
/*    */ 
/*    */ import net.imglib2.type.Type;
/*    */ import net.imglib2.type.numeric.RealType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SubtractNormReal<A extends RealType<A>, B extends RealType<B>, C extends RealType<C>>
/*    */   implements Function<A, B, C>
/*    */ {
/*    */   final double normalizationFactor;
/*    */   
/*    */   public SubtractNormReal(double normalizationFactor) {
/* 50 */     this.normalizationFactor = normalizationFactor;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void compute(A input1, B input2, C output) {
/* 56 */     output.setReal((input1.getRealDouble() - input2.getRealDouble()) * this.normalizationFactor);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/imglib2-algorithm-0.6.2.jar!/net/imglib2/algorithm/function/SubtractNormReal.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */