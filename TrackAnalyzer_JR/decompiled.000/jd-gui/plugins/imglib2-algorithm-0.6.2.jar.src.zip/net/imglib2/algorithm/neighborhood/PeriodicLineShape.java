/*     */ package net.imglib2.algorithm.neighborhood;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import net.imglib2.AbstractEuclideanSpace;
/*     */ import net.imglib2.AbstractInterval;
/*     */ import net.imglib2.Cursor;
/*     */ import net.imglib2.FlatIterationOrder;
/*     */ import net.imglib2.Interval;
/*     */ import net.imglib2.IterableInterval;
/*     */ import net.imglib2.RandomAccess;
/*     */ import net.imglib2.RandomAccessible;
/*     */ import net.imglib2.RandomAccessibleInterval;
/*     */ import net.imglib2.RealCursor;
/*     */ import net.imglib2.util.Util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PeriodicLineShape
/*     */   implements Shape
/*     */ {
/*     */   private final long span;
/*     */   private final int[] increments;
/*     */   
/*     */   public PeriodicLineShape(long span, int[] increments) {
/*  91 */     if (span < 0L) throw new IllegalArgumentException("Span cannot be negative."); 
/*  92 */     this.span = span;
/*  93 */     this.increments = increments;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> NeighborhoodsIterableInterval<T> neighborhoods(RandomAccessibleInterval<T> source) {
/*  99 */     PeriodicLineNeighborhoodFactory<T> f = PeriodicLineNeighborhoodUnsafe.factory();
/* 100 */     return new NeighborhoodsIterableInterval<>(source, this.span, this.increments, f);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> NeighborhoodsAccessible<T> neighborhoodsRandomAccessible(RandomAccessible<T> source) {
/* 106 */     PeriodicLineNeighborhoodFactory<T> f = PeriodicLineNeighborhoodUnsafe.factory();
/* 107 */     return new NeighborhoodsAccessible<>(source, this.span, this.increments, f);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> IterableInterval<Neighborhood<T>> neighborhoodsSafe(RandomAccessibleInterval<T> source) {
/* 113 */     PeriodicLineNeighborhoodFactory<T> f = PeriodicLineNeighborhood.factory();
/* 114 */     return new NeighborhoodsIterableInterval<>(source, this.span, this.increments, f);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> NeighborhoodsAccessible<T> neighborhoodsRandomAccessibleSafe(RandomAccessible<T> source) {
/* 120 */     PeriodicLineNeighborhoodFactory<T> f = PeriodicLineNeighborhood.factory();
/* 121 */     return new NeighborhoodsAccessible<>(source, this.span, this.increments, f);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getSpan() {
/* 129 */     return this.span;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int[] getIncrements() {
/* 137 */     return (int[])this.increments.clone();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 143 */     return "PeriodicLineShape, span = " + this.span + ", increments = " + Util.printCoordinates(this.increments);
/*     */   }
/*     */ 
/*     */   
/*     */   public static final class NeighborhoodsIterableInterval<T>
/*     */     extends AbstractInterval
/*     */     implements IterableInterval<Neighborhood<T>>
/*     */   {
/*     */     final RandomAccessibleInterval<T> source;
/*     */     
/*     */     final long span;
/*     */     
/*     */     final PeriodicLineNeighborhoodFactory<T> factory;
/*     */     final long size;
/*     */     final int[] increments;
/*     */     
/*     */     public NeighborhoodsIterableInterval(RandomAccessibleInterval<T> source, long span, int[] increments, PeriodicLineNeighborhoodFactory<T> factory) {
/* 160 */       super((Interval)source);
/* 161 */       this.source = source;
/* 162 */       this.span = span;
/* 163 */       this.increments = increments;
/* 164 */       this.factory = factory;
/* 165 */       long s = source.dimension(0);
/* 166 */       for (int d = 1; d < this.n; d++)
/* 167 */         s *= source.dimension(d); 
/* 168 */       this.size = s;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Cursor<Neighborhood<T>> cursor() {
/* 174 */       return new PeriodicLineNeighborhoodCursor<>(this.source, this.span, this.increments, this.factory);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public long size() {
/* 180 */       return this.size;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Neighborhood<T> firstElement() {
/* 186 */       return (Neighborhood<T>)cursor().next();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Object iterationOrder() {
/* 192 */       return new FlatIterationOrder((Interval)this);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Iterator<Neighborhood<T>> iterator() {
/* 198 */       return (Iterator<Neighborhood<T>>)cursor();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Cursor<Neighborhood<T>> localizingCursor() {
/* 204 */       return cursor();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static final class NeighborhoodsAccessible<T>
/*     */     extends AbstractEuclideanSpace
/*     */     implements RandomAccessible<Neighborhood<T>>
/*     */   {
/*     */     final RandomAccessible<T> source;
/*     */     
/*     */     final PeriodicLineNeighborhoodFactory<T> factory;
/*     */     private final long span;
/*     */     private final int[] increments;
/*     */     
/*     */     public NeighborhoodsAccessible(RandomAccessible<T> source, long span, int[] increments, PeriodicLineNeighborhoodFactory<T> factory) {
/* 220 */       super(source.numDimensions());
/* 221 */       this.source = source;
/* 222 */       this.span = span;
/* 223 */       this.increments = increments;
/* 224 */       this.factory = factory;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public RandomAccess<Neighborhood<T>> randomAccess() {
/* 230 */       return new PeriodicLineNeighborhoodRandomAccess<>(this.source, this.span, this.increments, this.factory);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public RandomAccess<Neighborhood<T>> randomAccess(Interval interval) {
/* 236 */       return randomAccess();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public int numDimensions() {
/* 242 */       return this.source.numDimensions();
/*     */     }
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/imglib2-algorithm-0.6.2.jar!/net/imglib2/algorithm/neighborhood/PeriodicLineShape.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */