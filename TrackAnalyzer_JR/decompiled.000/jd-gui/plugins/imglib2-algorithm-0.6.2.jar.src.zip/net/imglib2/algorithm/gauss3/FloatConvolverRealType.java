/*     */ package net.imglib2.algorithm.gauss3;
/*     */ 
/*     */ import net.imglib2.RandomAccess;
/*     */ import net.imglib2.type.numeric.RealType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class FloatConvolverRealType<S extends RealType<S>, T extends RealType<T>>
/*     */   implements Runnable
/*     */ {
/*     */   private final float[] kernel;
/*     */   private final RandomAccess<S> in;
/*     */   private final RandomAccess<T> out;
/*     */   private final int d;
/*     */   private final int k;
/*     */   private final int k1;
/*     */   private final int k1k1;
/*     */   private final int k1k;
/*     */   private final long fill2;
/*     */   private final boolean fillAdditional;
/*     */   private final float[] buf1;
/*     */   private final float[] buf2;
/*     */   
/*     */   public static <S extends RealType<S>, T extends RealType<T>> ConvolverFactory<S, T> factory() {
/*  63 */     return new ConvolverFactory<S, T>()
/*     */       {
/*     */         
/*     */         public Runnable create(double[] halfkernel, RandomAccess<S> in, RandomAccess<T> out, int d, long lineLength)
/*     */         {
/*  68 */           return new FloatConvolverRealType<>(halfkernel, in, out, d, lineLength);
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private FloatConvolverRealType(double[] kernel, RandomAccess<S> in, RandomAccess<T> out, int d, long lineLength) {
/*  99 */     this.kernel = new float[kernel.length];
/* 100 */     for (int i = 0; i < kernel.length; i++)
/* 101 */       this.kernel[i] = (float)kernel[i]; 
/* 102 */     this.in = in;
/* 103 */     this.out = out;
/* 104 */     this.d = d;
/*     */     
/* 106 */     this.k = this.kernel.length;
/* 107 */     this.k1 = this.k - 1;
/* 108 */     this.k1k1 = this.k1 + this.k1;
/* 109 */     this.k1k = this.k1 + this.k;
/* 110 */     this.fill2 = lineLength / 2L;
/* 111 */     this.fillAdditional = (lineLength % 2L == 1L);
/*     */     
/* 113 */     int l = 2 * this.k;
/* 114 */     this.buf1 = new float[l];
/* 115 */     this.buf2 = new float[l];
/*     */   }
/*     */ 
/*     */   
/*     */   private void prefill1() {
/* 120 */     float w = ((RealType)this.in.get()).getRealFloat();
/* 121 */     this.buf1[this.k1] = w * this.kernel[0] + this.buf2[this.k];
/* 122 */     for (int i = 1; i < this.k1; i++) {
/*     */       
/* 124 */       float wk = w * this.kernel[i];
/* 125 */       this.buf1[this.k1 + i] = wk + this.buf2[this.k + i];
/* 126 */       this.buf1[this.k1 - i] = wk + this.buf2[this.k - i];
/*     */     } 
/* 128 */     this.buf1[this.k1k1] = w * this.kernel[this.k1] + this.buf2[this.k1k];
/* 129 */     this.in.fwd(this.d);
/*     */   }
/*     */ 
/*     */   
/*     */   private void prefill2() {
/* 134 */     float w = ((RealType)this.in.get()).getRealFloat();
/* 135 */     this.buf2[this.k1] = w * this.kernel[0] + this.buf1[this.k];
/* 136 */     for (int i = 1; i < this.k1; i++) {
/*     */       
/* 138 */       float wk = w * this.kernel[i];
/* 139 */       this.buf2[this.k1 + i] = wk + this.buf1[this.k + i];
/* 140 */       this.buf2[this.k1 - i] = wk + this.buf1[this.k - i];
/*     */     } 
/* 142 */     this.buf2[this.k1k1] = w * this.kernel[this.k1] + this.buf1[this.k1k];
/* 143 */     this.in.fwd(this.d);
/*     */   }
/*     */ 
/*     */   
/*     */   private void next2() {
/* 148 */     float w = ((RealType)this.in.get()).getRealFloat();
/* 149 */     this.buf2[this.k1] = w * this.kernel[0] + this.buf1[this.k];
/* 150 */     for (int i = 1; i < this.k1; i++) {
/*     */       
/* 152 */       float f = w * this.kernel[i];
/* 153 */       this.buf2[this.k1 + i] = f + this.buf1[this.k + i];
/* 154 */       this.buf2[this.k1 - i] = f + this.buf1[this.k - i];
/*     */     } 
/* 156 */     float wk = w * this.kernel[this.k1];
/* 157 */     this.buf2[this.k1k1] = wk + this.buf1[this.k1k];
/* 158 */     ((RealType)this.out.get()).setReal(wk + this.buf1[1]);
/* 159 */     this.in.fwd(this.d);
/* 160 */     this.out.fwd(this.d);
/*     */   }
/*     */ 
/*     */   
/*     */   private void next1() {
/* 165 */     float w = ((RealType)this.in.get()).getRealFloat();
/* 166 */     this.buf1[this.k1] = w * this.kernel[0] + this.buf2[this.k];
/* 167 */     for (int i = 1; i < this.k1; i++) {
/*     */       
/* 169 */       float f = w * this.kernel[i];
/* 170 */       this.buf1[this.k1 + i] = f + this.buf2[this.k + i];
/* 171 */       this.buf1[this.k1 - i] = f + this.buf2[this.k - i];
/*     */     } 
/* 173 */     float wk = w * this.kernel[this.k1];
/* 174 */     this.buf1[this.k1k1] = wk + this.buf2[this.k1k];
/* 175 */     ((RealType)this.out.get()).setReal(wk + this.buf2[1]);
/* 176 */     this.in.fwd(this.d);
/* 177 */     this.out.fwd(this.d);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void run() {
/* 183 */     for (int j = 0; j < this.k1; j++) {
/*     */       
/* 185 */       prefill1();
/* 186 */       prefill2();
/*     */     } 
/* 188 */     for (long i = 0L; i < this.fill2; i++) {
/*     */       
/* 190 */       next1();
/* 191 */       next2();
/*     */     } 
/* 193 */     if (this.fillAdditional)
/* 194 */       next1(); 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/imglib2-algorithm-0.6.2.jar!/net/imglib2/algorithm/gauss3/FloatConvolverRealType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */