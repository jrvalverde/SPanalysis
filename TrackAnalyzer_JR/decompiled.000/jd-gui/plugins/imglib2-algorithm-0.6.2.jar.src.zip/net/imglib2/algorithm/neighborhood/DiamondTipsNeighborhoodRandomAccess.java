/*     */ package net.imglib2.algorithm.neighborhood;
/*     */ 
/*     */ import net.imglib2.Interval;
/*     */ import net.imglib2.Localizable;
/*     */ import net.imglib2.RandomAccess;
/*     */ import net.imglib2.RandomAccessible;
/*     */ import net.imglib2.Sampler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DiamondTipsNeighborhoodRandomAccess<T>
/*     */   extends DiamondTipsNeighborhoodLocalizableSampler<T>
/*     */   implements RandomAccess<Neighborhood<T>>
/*     */ {
/*     */   protected DiamondTipsNeighborhoodRandomAccess(RandomAccessible<T> source, long radius, DiamondTipsNeighborhoodFactory<T> factory) {
/*  46 */     super(source, radius, factory, (Interval)null);
/*     */   }
/*     */ 
/*     */   
/*     */   protected DiamondTipsNeighborhoodRandomAccess(RandomAccessible<T> source, long radius, DiamondTipsNeighborhoodFactory<T> factory, Interval interval) {
/*  51 */     super(source, radius, factory, interval);
/*     */   }
/*     */ 
/*     */   
/*     */   private DiamondTipsNeighborhoodRandomAccess(DiamondTipsNeighborhoodRandomAccess<T> c) {
/*  56 */     super(c);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void fwd(int d) {
/*  62 */     this.currentPos[d] = this.currentPos[d] + 1L;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void bck(int d) {
/*  68 */     this.currentPos[d] = this.currentPos[d] - 1L;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void move(int distance, int d) {
/*  74 */     this.currentPos[d] = this.currentPos[d] + distance;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void move(long distance, int d) {
/*  80 */     this.currentPos[d] = this.currentPos[d] + distance;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void move(Localizable localizable) {
/*  86 */     for (int d = 0; d < this.n; d++) {
/*     */       
/*  88 */       long distance = localizable.getLongPosition(d);
/*  89 */       this.currentPos[d] = this.currentPos[d] + distance;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void move(int[] distance) {
/*  96 */     for (int d = 0; d < this.n; d++)
/*     */     {
/*  98 */       this.currentPos[d] = this.currentPos[d] + distance[d];
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void move(long[] distance) {
/* 105 */     for (int d = 0; d < this.n; d++)
/*     */     {
/* 107 */       this.currentPos[d] = this.currentPos[d] + distance[d];
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPosition(Localizable localizable) {
/* 114 */     for (int d = 0; d < this.n; d++) {
/*     */       
/* 116 */       long position = localizable.getLongPosition(d);
/* 117 */       this.currentPos[d] = position;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPosition(int[] position) {
/* 124 */     for (int d = 0; d < this.n; d++)
/*     */     {
/* 126 */       this.currentPos[d] = position[d];
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPosition(long[] position) {
/* 133 */     for (int d = 0; d < this.n; d++)
/*     */     {
/* 135 */       this.currentPos[d] = position[d];
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPosition(int position, int d) {
/* 142 */     this.currentPos[d] = position;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPosition(long position, int d) {
/* 148 */     this.currentPos[d] = position;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public DiamondTipsNeighborhoodRandomAccess<T> copy() {
/* 154 */     return new DiamondTipsNeighborhoodRandomAccess(this);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public DiamondTipsNeighborhoodRandomAccess<T> copyRandomAccess() {
/* 160 */     return copy();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/imglib2-algorithm-0.6.2.jar!/net/imglib2/algorithm/neighborhood/DiamondTipsNeighborhoodRandomAccess.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */