/*     */ package net.imglib2.algorithm.integral;
/*     */ 
/*     */ import net.imglib2.RandomAccess;
/*     */ import net.imglib2.RandomAccessibleInterval;
/*     */ import net.imglib2.algorithm.OutputAlgorithm;
/*     */ import net.imglib2.converter.Converter;
/*     */ import net.imglib2.img.Img;
/*     */ import net.imglib2.img.array.ArrayImg;
/*     */ import net.imglib2.img.array.ArrayImgFactory;
/*     */ import net.imglib2.iterator.LocalizingZeroMinIntervalIterator;
/*     */ import net.imglib2.type.NativeType;
/*     */ import net.imglib2.type.Type;
/*     */ import net.imglib2.type.numeric.NumericType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IntegralImg<R extends NumericType<R>, T extends NumericType<T> & NativeType<T>>
/*     */   implements OutputAlgorithm<Img<T>>
/*     */ {
/*     */   protected final RandomAccessibleInterval<R> img;
/*     */   protected final T type;
/*     */   protected Img<T> integral;
/*     */   protected final Converter<R, T> converter;
/*     */   protected final int order;
/*     */   
/*     */   public IntegralImg(RandomAccessibleInterval<R> img, T type, Converter<R, T> converter) {
/*  83 */     this(img, type, converter, 1);
/*     */   }
/*     */ 
/*     */   
/*     */   public IntegralImg(RandomAccessibleInterval<R> img, T type, Converter<R, T> converter, int order) {
/*  88 */     this.img = img;
/*  89 */     this.type = type;
/*  90 */     this.converter = converter;
/*  91 */     this.order = order;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean process() {
/*  97 */     int numDimensions = this.img.numDimensions();
/*  98 */     long[] integralSize = new long[numDimensions];
/*     */ 
/*     */     
/* 101 */     for (int d = 0; d < numDimensions; d++) {
/* 102 */       integralSize[d] = ((int)this.img.dimension(d) + 1);
/*     */     }
/* 104 */     ArrayImg arrayImg = (new ArrayImgFactory()).create(integralSize, (NativeType)this.type.createVariable());
/*     */ 
/*     */     
/* 107 */     if (arrayImg == null)
/* 108 */       return false; 
/* 109 */     this.integral = (Img<T>)arrayImg;
/*     */     
/* 111 */     if (numDimensions > 1) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 117 */       long[] fakeSize = new long[numDimensions - 1];
/*     */ 
/*     */       
/* 120 */       long[] tmpIn = new long[numDimensions];
/*     */ 
/*     */       
/* 123 */       long[] tmpOut = new long[numDimensions];
/*     */ 
/*     */       
/* 126 */       long size = integralSize[0];
/*     */       
/* 128 */       for (int j = 1; j < numDimensions; j++) {
/* 129 */         fakeSize[j - 1] = integralSize[j];
/*     */       }
/* 131 */       LocalizingZeroMinIntervalIterator cursorDim = new LocalizingZeroMinIntervalIterator(fakeSize);
/*     */       
/* 133 */       RandomAccess<R> cursorIn = this.img.randomAccess();
/* 134 */       RandomAccess<T> cursorOut = arrayImg.randomAccess();
/*     */       
/* 136 */       NumericType numericType1 = (NumericType)this.type.createVariable();
/* 137 */       NumericType numericType2 = (NumericType)this.type.createVariable();
/*     */ 
/*     */ 
/*     */       
/* 141 */       label62: while (cursorDim.hasNext())
/*     */       {
/* 143 */         cursorDim.fwd();
/*     */ 
/*     */ 
/*     */         
/* 147 */         cursorDim.localize(fakeSize);
/*     */         
/* 149 */         tmpIn[0] = 0L;
/* 150 */         tmpOut[0] = 1L;
/*     */         
/* 152 */         for (int k = 1; k < numDimensions; k++) {
/*     */           
/* 154 */           tmpIn[k] = fakeSize[k - 1] - 1L;
/* 155 */           tmpOut[k] = fakeSize[k - 1];
/*     */ 
/*     */           
/* 158 */           if (tmpOut[k] == 0L) {
/*     */             continue label62;
/*     */           }
/*     */         } 
/*     */         
/* 163 */         cursorIn.setPosition(tmpIn);
/*     */ 
/*     */         
/* 166 */         cursorOut.setPosition(tmpOut);
/*     */ 
/*     */         
/* 169 */         integrateLineDim0(this.converter, cursorIn, cursorOut, (T)numericType2, (T)numericType1, size);
/*     */ 
/*     */ 
/*     */       
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 184 */       NumericType numericType1 = (NumericType)this.type.createVariable();
/* 185 */       NumericType numericType2 = (NumericType)this.type.createVariable();
/*     */ 
/*     */       
/* 188 */       long size = integralSize[0];
/*     */       
/* 190 */       RandomAccess<R> cursorIn = this.img.randomAccess();
/* 191 */       RandomAccess<T> cursorOut = arrayImg.randomAccess();
/*     */       
/* 193 */       cursorIn.setPosition(0, 0);
/* 194 */       cursorOut.setPosition(1, 0);
/*     */ 
/*     */       
/* 197 */       this.converter.convert(cursorIn.get(), numericType2);
/* 198 */       ((NumericType)cursorOut.get()).set((Type)numericType2);
/*     */       
/* 200 */       for (int j = 2; j < size; j++) {
/*     */         
/* 202 */         cursorIn.fwd(0);
/* 203 */         cursorOut.fwd(0);
/*     */         
/* 205 */         this.converter.convert(cursorIn.get(), numericType1);
/* 206 */         numericType2.add(numericType1);
/* 207 */         ((NumericType)cursorOut.get()).set((Type)numericType2);
/*     */       } 
/*     */       
/* 210 */       return true;
/*     */     } 
/*     */     
/* 213 */     for (int i = 1; i < numDimensions; i++) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 219 */       long[] fakeSize = new long[numDimensions - 1];
/* 220 */       long[] tmp = new long[numDimensions];
/*     */ 
/*     */       
/* 223 */       long size = integralSize[i];
/*     */ 
/*     */ 
/*     */       
/* 227 */       int countDim = 0;
/* 228 */       for (int e = 0; e < numDimensions; e++) {
/* 229 */         if (e != i)
/* 230 */           fakeSize[countDim++] = integralSize[e]; 
/*     */       } 
/* 232 */       LocalizingZeroMinIntervalIterator cursorDim = new LocalizingZeroMinIntervalIterator(fakeSize);
/*     */       
/* 234 */       RandomAccess<T> cursor = arrayImg.randomAccess();
/* 235 */       NumericType numericType = (NumericType)this.type.createVariable();
/*     */       
/* 237 */       while (cursorDim.hasNext()) {
/*     */         
/* 239 */         cursorDim.fwd();
/*     */ 
/*     */ 
/*     */         
/* 243 */         cursorDim.localize(fakeSize);
/*     */         
/* 245 */         tmp[i] = 1L;
/* 246 */         countDim = 0;
/* 247 */         for (int j = 0; j < numDimensions; j++) {
/* 248 */           if (j != i) {
/* 249 */             tmp[j] = fakeSize[countDim++];
/*     */           }
/*     */         } 
/*     */         
/* 253 */         cursor.setPosition(tmp);
/*     */ 
/*     */         
/* 256 */         integrateLine(i, cursor, (T)numericType, size);
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 268 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void integrateLineDim0(Converter<R, T> converter, RandomAccess<R> cursorIn, RandomAccess<T> cursorOut, T sum, T tmpVar, long size) {
/* 274 */     converter.convert(cursorIn.get(), sum);
/*     */     
/* 276 */     for (int j = 0; j < this.order - 1; j++)
/*     */     {
/* 278 */       sum.mul(sum);
/*     */     }
/*     */     
/* 281 */     ((NumericType)cursorOut.get()).set((Type)sum);
/*     */     
/* 283 */     for (int i = 2; i < size; i++) {
/*     */       
/* 285 */       cursorIn.fwd(0);
/* 286 */       cursorOut.fwd(0);
/*     */       
/* 288 */       converter.convert(cursorIn.get(), tmpVar);
/*     */ 
/*     */       
/* 291 */       for (int k = 0; k < this.order - 1; k++)
/*     */       {
/* 293 */         tmpVar.mul(tmpVar);
/*     */       }
/*     */       
/* 296 */       sum.add(tmpVar);
/* 297 */       ((NumericType)cursorOut.get()).set((Type)sum);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void integrateLine(int d, RandomAccess<T> cursor, T sum, long size) {
/* 304 */     sum.set((Type)cursor.get());
/*     */     
/* 306 */     for (int i = 2; i < size; i++) {
/*     */       
/* 308 */       cursor.fwd(d);
/*     */       
/* 310 */       sum.add(cursor.get());
/* 311 */       ((NumericType)cursor.get()).set((Type)sum);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean checkInput() {
/* 318 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getErrorMessage() {
/* 324 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Img<T> getResult() {
/* 330 */     return this.integral;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/imglib2-algorithm-0.6.2.jar!/net/imglib2/algorithm/integral/IntegralImg.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */