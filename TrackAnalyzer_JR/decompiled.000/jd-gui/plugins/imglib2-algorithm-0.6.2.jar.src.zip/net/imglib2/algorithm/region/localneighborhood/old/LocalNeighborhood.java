/*     */ package net.imglib2.algorithm.region.localneighborhood.old;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import net.imglib2.Cursor;
/*     */ import net.imglib2.IterableInterval;
/*     */ import net.imglib2.Localizable;
/*     */ import net.imglib2.Positionable;
/*     */ import net.imglib2.RandomAccessible;
/*     */ import net.imglib2.RealCursor;
/*     */ import net.imglib2.RealPositionable;
/*     */ import net.imglib2.util.Util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public class LocalNeighborhood<T>
/*     */   implements IterableInterval<T>
/*     */ {
/*     */   final int numDimensions;
/*     */   final long size;
/*     */   final long[] center;
/*     */   final RandomAccessible<T> source;
/*     */   
/*     */   public LocalNeighborhood(RandomAccessible<T> source, Localizable center) {
/*  63 */     this.numDimensions = source.numDimensions();
/*  64 */     this.center = new long[this.numDimensions];
/*  65 */     center.localize(this.center);
/*     */     
/*  67 */     this.size = (Util.pow(3, this.numDimensions) - 1);
/*     */     
/*  69 */     this.source = source;
/*     */   }
/*     */ 
/*     */   
/*     */   public void updateCenter(long[] center) {
/*  74 */     for (int d = 0; d < this.numDimensions; d++) {
/*  75 */       this.center[d] = center[d];
/*     */     }
/*     */   }
/*     */   
/*     */   public void updateCenter(Localizable center) {
/*  80 */     for (int d = 0; d < this.numDimensions; d++) {
/*  81 */       this.center[d] = center.getLongPosition(d);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public long size() {
/*  87 */     return this.size;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public T firstElement() {
/*  93 */     LocalNeighborhoodCursor<T> cursor = new LocalNeighborhoodCursor<>(this.source, this.center);
/*  94 */     cursor.fwd();
/*  95 */     return cursor.get();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object iterationOrder() {
/* 101 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public double realMin(int d) {
/* 107 */     return (this.center[d] - 1L);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void realMin(double[] min) {
/* 113 */     for (int d = 0; d < this.numDimensions; d++) {
/* 114 */       min[d] = (this.center[d] - 1L);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void realMin(RealPositionable min) {
/* 120 */     for (int d = 0; d < this.numDimensions; d++) {
/* 121 */       min.setPosition(this.center[d] - 1L, d);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public double realMax(int d) {
/* 127 */     return (this.center[d] + 1L);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void realMax(double[] max) {
/* 133 */     for (int d = 0; d < this.numDimensions; d++) {
/* 134 */       max[d] = (this.center[d] + 1L);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void realMax(RealPositionable max) {
/* 140 */     for (int d = 0; d < this.numDimensions; d++) {
/* 141 */       max.setPosition(this.center[d] + 1L, d);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public int numDimensions() {
/* 147 */     return this.numDimensions;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Iterator<T> iterator() {
/* 153 */     return (Iterator<T>)cursor();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public long min(int d) {
/* 159 */     return this.center[d] - 1L;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void min(long[] min) {
/* 165 */     for (int d = 0; d < this.numDimensions; d++) {
/* 166 */       min[d] = this.center[d] - 1L;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void min(Positionable min) {
/* 172 */     for (int d = 0; d < this.numDimensions; d++) {
/* 173 */       min.setPosition(this.center[d] - 1L, d);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public long max(int d) {
/* 179 */     return this.center[d] + 1L;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void max(long[] max) {
/* 185 */     for (int d = 0; d < this.numDimensions; d++) {
/* 186 */       max[d] = this.center[d] + 1L;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void max(Positionable max) {
/* 192 */     for (int d = 0; d < this.numDimensions; d++) {
/* 193 */       max.setPosition(this.center[d] - 1L, d);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void dimensions(long[] dimensions) {
/* 199 */     for (int d = 0; d < this.numDimensions; d++) {
/* 200 */       dimensions[d] = 3L;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public long dimension(int d) {
/* 206 */     return 3L;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public LocalNeighborhoodCursor<T> cursor() {
/* 212 */     return new LocalNeighborhoodCursor<>(this.source, this.center);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public LocalNeighborhoodCursor<T> localizingCursor() {
/* 218 */     return cursor();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/imglib2-algorithm-0.6.2.jar!/net/imglib2/algorithm/region/localneighborhood/old/LocalNeighborhood.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */