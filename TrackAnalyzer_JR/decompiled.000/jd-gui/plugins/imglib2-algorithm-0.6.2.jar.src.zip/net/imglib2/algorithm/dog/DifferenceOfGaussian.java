/*     */ package net.imglib2.algorithm.dog;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.concurrent.Callable;
/*     */ import java.util.concurrent.ExecutionException;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.Future;
/*     */ import net.imglib2.Cursor;
/*     */ import net.imglib2.Dimensions;
/*     */ import net.imglib2.Interval;
/*     */ import net.imglib2.IterableInterval;
/*     */ import net.imglib2.Localizable;
/*     */ import net.imglib2.RandomAccess;
/*     */ import net.imglib2.RandomAccessible;
/*     */ import net.imglib2.RandomAccessibleInterval;
/*     */ import net.imglib2.algorithm.gauss3.Gauss3;
/*     */ import net.imglib2.exception.IncompatibleTypeException;
/*     */ import net.imglib2.img.Img;
/*     */ import net.imglib2.type.NativeType;
/*     */ import net.imglib2.type.numeric.NumericType;
/*     */ import net.imglib2.util.Util;
/*     */ import net.imglib2.view.IntervalView;
/*     */ import net.imglib2.view.Views;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DifferenceOfGaussian
/*     */ {
/*     */   public static <I extends NumericType<I>, T extends NumericType<T> & NativeType<T>> void DoG(double[] sigmaSmaller, double[] sigmaLarger, RandomAccessible<I> input, RandomAccessibleInterval<T> dog, ExecutorService service) {
/*  92 */     NumericType numericType = (NumericType)Util.getTypeFromInterval((Interval)dog);
/*  93 */     Img<T> g1 = Util.getArrayOrCellImgFactory((Dimensions)dog, (NativeType)numericType).create((Dimensions)dog, numericType);
/*  94 */     long[] translation = new long[dog.numDimensions()];
/*  95 */     dog.min(translation);
/*  96 */     DoG(sigmaSmaller, sigmaLarger, input, (RandomAccessible<T>)Views.translate((RandomAccessibleInterval)g1, translation), dog, service);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <I extends NumericType<I>, T extends NumericType<T> & NativeType<T>> void DoG(double[] sigmaSmaller, double[] sigmaLarger, RandomAccessible<I> input, RandomAccessible<T> tmp, RandomAccessibleInterval<T> dog, ExecutorService service) {
/* 128 */     final IntervalView<T> tmpInterval = Views.interval(tmp, (Interval)dog);
/*     */     
/*     */     try {
/* 131 */       Gauss3.gauss(sigmaSmaller, input, (RandomAccessibleInterval)tmpInterval, service);
/* 132 */       Gauss3.gauss(sigmaLarger, input, dog, service);
/*     */     }
/* 134 */     catch (IncompatibleTypeException e) {
/*     */       
/* 136 */       e.printStackTrace();
/*     */     } 
/* 138 */     final IterableInterval<T> dogIterable = Views.iterable(dog);
/* 139 */     final IterableInterval<T> tmpIterable = Views.iterable((RandomAccessibleInterval)tmpInterval);
/* 140 */     long size = dogIterable.size();
/*     */     
/* 142 */     int numThreads = Runtime.getRuntime().availableProcessors();
/* 143 */     int numTasks = (numThreads <= 1) ? 1 : (numThreads * 20);
/* 144 */     long taskSize = size / numTasks;
/* 145 */     ArrayList<Future<Void>> futures = new ArrayList<>();
/* 146 */     for (int taskNum = 0; taskNum < numTasks; taskNum++) {
/*     */       
/* 148 */       final long fromIndex = taskNum * taskSize;
/* 149 */       final long thisTaskSize = (taskNum == numTasks - 1) ? (size - fromIndex) : taskSize;
/* 150 */       if (dogIterable.iterationOrder().equals(tmpIterable.iterationOrder())) {
/* 151 */         futures.add(service.submit(new Callable<Void>()
/*     */               {
/*     */                 
/*     */                 public Void call()
/*     */                 {
/* 156 */                   Cursor<T> dogCursor = dogIterable.cursor();
/* 157 */                   Cursor<T> tmpCursor = tmpIterable.cursor();
/* 158 */                   dogCursor.jumpFwd(fromIndex);
/* 159 */                   tmpCursor.jumpFwd(fromIndex);
/* 160 */                   for (int i = 0; i < thisTaskSize; i++)
/* 161 */                     ((NumericType)dogCursor.next()).sub(tmpCursor.next()); 
/* 162 */                   return null;
/*     */                 }
/*     */               }));
/*     */       } else {
/* 166 */         futures.add(service.submit(new Callable<Void>()
/*     */               {
/*     */                 
/*     */                 public Void call()
/*     */                 {
/* 171 */                   Cursor<T> dogCursor = dogIterable.localizingCursor();
/* 172 */                   RandomAccess<T> tmpAccess = tmpInterval.randomAccess();
/* 173 */                   dogCursor.jumpFwd(fromIndex);
/* 174 */                   for (int i = 0; i < thisTaskSize; i++) {
/*     */                     
/* 176 */                     NumericType numericType = (NumericType)dogCursor.next();
/* 177 */                     tmpAccess.setPosition((Localizable)dogCursor);
/* 178 */                     numericType.sub(tmpAccess.get());
/*     */                   } 
/* 180 */                   return null; }
/*     */               }));
/*     */       } 
/*     */     } 
/* 184 */     for (Future<Void> f : futures) {
/*     */ 
/*     */       
/*     */       try {
/* 188 */         f.get();
/*     */       }
/* 190 */       catch (InterruptedException e) {
/*     */         
/* 192 */         e.printStackTrace();
/*     */       }
/* 194 */       catch (ExecutionException e) {
/*     */         
/* 196 */         e.printStackTrace();
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static double[][] computeSigmas(double imageSigma, double minf, double[] pixelSize, double sigma1, double sigma2) {
/* 225 */     int n = pixelSize.length;
/* 226 */     double k = sigma2 / sigma1;
/* 227 */     double[] sigmas1 = new double[n];
/* 228 */     double[] sigmas2 = new double[n];
/* 229 */     for (int d = 0; d < n; d++) {
/*     */       
/* 231 */       double s1 = Math.max(minf * imageSigma, sigma1 / pixelSize[d]);
/* 232 */       double s2 = k * s1;
/* 233 */       sigmas1[d] = Math.sqrt(s1 * s1 - imageSigma * imageSigma);
/* 234 */       sigmas2[d] = Math.sqrt(s2 * s2 - imageSigma * imageSigma);
/*     */     } 
/* 236 */     return new double[][] { sigmas1, sigmas2 };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static double computeMinIsotropicSigma(double imageSigma, double minf, double[] pixelSize) {
/* 246 */     int n = pixelSize.length;
/* 247 */     double s = pixelSize[0];
/* 248 */     for (int d = 1; d < n; d++)
/* 249 */       s = Math.max(s, pixelSize[d]); 
/* 250 */     return minf * imageSigma * s;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/imglib2-algorithm-0.6.2.jar!/net/imglib2/algorithm/dog/DifferenceOfGaussian.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */