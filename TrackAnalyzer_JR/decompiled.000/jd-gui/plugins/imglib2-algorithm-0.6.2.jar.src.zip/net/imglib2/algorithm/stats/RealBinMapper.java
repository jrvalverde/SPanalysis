/*     */ package net.imglib2.algorithm.stats;
/*     */ 
/*     */ import net.imglib2.type.numeric.RealType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RealBinMapper<T extends RealType<T>>
/*     */   implements HistogramBinMapper<T>
/*     */ {
/*     */   private final int numBins;
/*     */   private final T minBin;
/*     */   private final T maxBin;
/*     */   private final double binWidth;
/*     */   private final double halfBinWidth;
/*     */   private final double minVal;
/*     */   
/*     */   public RealBinMapper(T minBin, T maxBin, int numBins) {
/*  74 */     this.numBins = numBins;
/*  75 */     this.minBin = minBin;
/*  76 */     this.maxBin = maxBin;
/*     */ 
/*     */     
/*  79 */     this.binWidth = (1.0D + maxBin.getRealDouble() - minBin.getRealDouble()) / numBins;
/*     */     
/*  81 */     this.halfBinWidth = this.binWidth / 2.0D;
/*     */     
/*  83 */     this.minVal = minBin.getRealDouble();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public T getMaxBin() {
/*  89 */     return this.maxBin;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public T getMinBin() {
/*  95 */     return this.minBin;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getNumBins() {
/* 101 */     return this.numBins;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public T invMap(int i) {
/* 107 */     RealType realType = (RealType)this.minBin.createVariable();
/* 108 */     double t = i;
/*     */     
/* 110 */     t *= this.binWidth;
/* 111 */     t += this.minVal;
/* 112 */     realType.setReal(t);
/* 113 */     return (T)realType;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int map(T type) {
/* 119 */     double tVal = type.getRealDouble();
/* 120 */     tVal -= this.minVal;
/* 121 */     tVal += this.halfBinWidth;
/* 122 */     tVal /= this.binWidth;
/*     */     
/* 124 */     return (int)tVal;
/*     */   }
/*     */ 
/*     */   
/*     */   public double getBinWidth() {
/* 129 */     return this.binWidth;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/imglib2-algorithm-0.6.2.jar!/net/imglib2/algorithm/stats/RealBinMapper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */