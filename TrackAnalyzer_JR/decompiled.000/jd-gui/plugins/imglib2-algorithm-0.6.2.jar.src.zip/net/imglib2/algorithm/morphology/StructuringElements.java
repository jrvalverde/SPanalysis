/*     */ package net.imglib2.algorithm.morphology;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import net.imglib2.algorithm.neighborhood.CenteredRectangleShape;
/*     */ import net.imglib2.algorithm.neighborhood.DiamondShape;
/*     */ import net.imglib2.algorithm.neighborhood.DiamondTipsShape;
/*     */ import net.imglib2.algorithm.neighborhood.HorizontalLineShape;
/*     */ import net.imglib2.algorithm.neighborhood.HyperSphereShape;
/*     */ import net.imglib2.algorithm.neighborhood.PeriodicLineShape;
/*     */ import net.imglib2.algorithm.neighborhood.RectangleShape;
/*     */ import net.imglib2.algorithm.neighborhood.Shape;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StructuringElements
/*     */ {
/*     */   private static final int HEURISTICS_DIAMOND_RADIUS_2D = 4;
/*     */   private static final int HEURISTICS_DIAMOND_RADIUS_OTHERSD = 2;
/*     */   
/*     */   public static final List<Shape> disk(long radius, int dimensionality) {
/*     */     int decomposition;
/* 106 */     if (dimensionality == 2) {
/*     */       
/* 108 */       if (radius < 4L)
/*     */       {
/* 110 */         decomposition = 0;
/*     */       }
/* 112 */       else if (radius < 9L)
/*     */       {
/* 114 */         decomposition = 4;
/*     */       }
/* 116 */       else if (radius < 12L)
/*     */       {
/* 118 */         decomposition = 6;
/*     */       }
/* 120 */       else if (radius < 17L)
/*     */       {
/* 122 */         decomposition = 8;
/*     */       }
/*     */       else
/*     */       {
/* 126 */         decomposition = 6;
/*     */       }
/*     */     
/*     */     } else {
/*     */       
/* 131 */       decomposition = 0;
/*     */     } 
/* 133 */     return disk(radius, dimensionality, decomposition);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final List<Shape> disk(long radius, int dimensionality, int decomposition) {
/* 170 */     if (dimensionality == 2) {
/*     */ 
/*     */       
/* 173 */       if (decomposition == 0) {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 178 */         List<Shape> list = new ArrayList<>(1);
/* 179 */         list.add(new HyperSphereShape(radius));
/* 180 */         return list;
/*     */       } 
/* 182 */       if (decomposition == 8 || decomposition == 4 || decomposition == 6) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 190 */         List<int[]> vectors = (List)new ArrayList<>(decomposition);
/* 191 */         switch (decomposition) {
/*     */ 
/*     */           
/*     */           case 4:
/* 195 */             vectors.add(new int[] { 1, 0 });
/* 196 */             vectors.add(new int[] { 1, 1 });
/* 197 */             vectors.add(new int[] { 0, 1 });
/* 198 */             vectors.add(new int[] { -1, 1 });
/*     */             break;
/*     */ 
/*     */           
/*     */           case 6:
/* 203 */             vectors.add(new int[] { 1, 0 });
/* 204 */             vectors.add(new int[] { 2, 1 });
/* 205 */             vectors.add(new int[] { 1, 2 });
/* 206 */             vectors.add(new int[] { 0, 1 });
/* 207 */             vectors.add(new int[] { -1, 2 });
/* 208 */             vectors.add(new int[] { -2, 1 });
/*     */             break;
/*     */ 
/*     */           
/*     */           case 8:
/* 213 */             vectors.add(new int[] { 1, 0 });
/* 214 */             vectors.add(new int[] { 2, 1 });
/* 215 */             vectors.add(new int[] { 1, 1 });
/* 216 */             vectors.add(new int[] { 1, 2 });
/* 217 */             vectors.add(new int[] { 0, 1 });
/* 218 */             vectors.add(new int[] { -1, 2 });
/* 219 */             vectors.add(new int[] { -1, 1 });
/* 220 */             vectors.add(new int[] { -2, 1 });
/*     */             break;
/*     */           
/*     */           default:
/* 224 */             throw new IllegalArgumentException("The decomposition number must be 0, 4, 6 or 8. Got " + decomposition + ".");
/*     */         } 
/*     */         
/* 227 */         double theta = Math.PI / (2 * decomposition);
/* 228 */         double radialExtent = (2L * radius) / (1.0D / Math.tan(theta) + 1.0D / Math.sin(theta));
/* 229 */         List<Shape> lines = new ArrayList<>(decomposition + 2);
/*     */         
/* 231 */         long actualRadius = 0L;
/* 232 */         for (int[] vector : vectors) {
/*     */           
/* 234 */           double norm = Math.sqrt((vector[0] * vector[0] + vector[1] * vector[1]));
/* 235 */           long span = (long)Math.floor(radialExtent / norm);
/* 236 */           lines.add(new PeriodicLineShape(span, vector));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 242 */           actualRadius += span * Math.abs(vector[0]);
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 248 */         if (actualRadius < radius) {
/*     */           
/* 250 */           long dif = radius - actualRadius;
/* 251 */           lines.add(new HorizontalLineShape(dif, 0, false));
/* 252 */           lines.add(new HorizontalLineShape(dif, 1, false));
/*     */         } 
/*     */         
/* 255 */         return lines;
/*     */       } 
/*     */ 
/*     */       
/* 259 */       throw new IllegalArgumentException("The decomposition number must be 0, 4, 6 or 8. Got " + decomposition + ".");
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 268 */     List<Shape> strel = new ArrayList<>(1);
/* 269 */     strel.add(new HyperSphereShape(radius));
/* 270 */     return strel;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final List<Shape> square(int radius, int dimensionality, boolean decompose) {
/* 304 */     if (decompose) {
/*     */       
/* 306 */       List<Shape> strels = new ArrayList<>(dimensionality);
/* 307 */       for (int d = 0; d < dimensionality; d++)
/*     */       {
/* 309 */         strels.add(new HorizontalLineShape(radius, d, false));
/*     */       }
/* 311 */       return strels;
/*     */     } 
/*     */ 
/*     */     
/* 315 */     List<Shape> strel = new ArrayList<>(1);
/* 316 */     strel.add(new RectangleShape(radius, false));
/* 317 */     return strel;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final List<Shape> square(int radius, int dimensionality) {
/* 356 */     long decomposedNNeighbohoods = (dimensionality * (2 * radius + 1));
/* 357 */     long fullNNeighbohoods = (long)Math.pow((2 * radius + 1), dimensionality);
/* 358 */     boolean decompose = (decomposedNNeighbohoods < fullNNeighbohoods / 2L);
/* 359 */     return square(radius, dimensionality, decompose);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final List<Shape> rectangle(int[] halfSpans, boolean decompose) {
/*     */     List<Shape> strels;
/* 388 */     if (decompose) {
/*     */       
/* 390 */       strels = new ArrayList<>(halfSpans.length);
/* 391 */       for (int d = 0; d < halfSpans.length; d++) {
/*     */         
/* 393 */         int r = halfSpans[d];
/* 394 */         r = Math.max(0, r);
/* 395 */         if (r != 0)
/*     */         {
/*     */ 
/*     */           
/* 399 */           HorizontalLineShape line = new HorizontalLineShape(r, d, false);
/* 400 */           strels.add(line);
/*     */         }
/*     */       
/*     */       } 
/*     */     } else {
/*     */       
/* 406 */       strels = new ArrayList<>(1);
/* 407 */       CenteredRectangleShape square = new CenteredRectangleShape(halfSpans, false);
/* 408 */       strels.add(square);
/*     */     } 
/*     */     
/* 411 */     return strels;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final List<Shape> rectangle(int[] halfSpans) {
/* 441 */     long decomposedNNeighbohoods = 0L;
/* 442 */     long fullNNeighbohoods = 1L;
/* 443 */     for (int i = 0; i < halfSpans.length; i++) {
/*     */       
/* 445 */       int l = 2 * halfSpans[i] + 1;
/* 446 */       decomposedNNeighbohoods += l;
/* 447 */       fullNNeighbohoods *= l;
/*     */     } 
/*     */     
/* 450 */     if (decomposedNNeighbohoods > fullNNeighbohoods / 2L)
/*     */     {
/*     */       
/* 453 */       return rectangle(halfSpans, false);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 458 */     return rectangle(halfSpans, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final List<Shape> diamond(int radius, int dimensionality) {
/*     */     boolean decompose;
/* 500 */     if (dimensionality <= 2) {
/*     */       
/* 502 */       decompose = (radius > 4);
/*     */     }
/*     */     else {
/*     */       
/* 506 */       decompose = (radius > 2);
/*     */     } 
/* 508 */     return diamond(radius, dimensionality, decompose);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final List<Shape> diamond(int radius, int dimensionality, boolean decompose) {
/* 551 */     if (decompose && radius > 1) {
/*     */       
/* 553 */       if (dimensionality <= 2) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 561 */         int ndecomp = (int)Math.floor(Math.log(radius) / Math.log(2.0D));
/* 562 */         List<Shape> list = new ArrayList<>(ndecomp);
/*     */ 
/*     */         
/* 565 */         DiamondShape shapeBase = new DiamondShape(1L);
/* 566 */         list.add(shapeBase);
/*     */ 
/*     */         
/* 569 */         for (int i = 0; i < ndecomp; i++) {
/*     */           
/* 571 */           int p = 1 << i;
/* 572 */           DiamondTipsShape diamondTipsShape = new DiamondTipsShape(p);
/* 573 */           list.add(diamondTipsShape);
/*     */         } 
/*     */ 
/*     */         
/* 577 */         int q = radius - (1 << ndecomp);
/* 578 */         if (q > 0) {
/*     */           
/* 580 */           DiamondTipsShape diamondTipsShape = new DiamondTipsShape(q);
/* 581 */           list.add(diamondTipsShape);
/*     */         } 
/* 583 */         return list;
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 589 */       List<Shape> shapes = new ArrayList<>(radius);
/* 590 */       shapes.add(new DiamondShape(1L));
/* 591 */       for (int k = 0; k < radius - 1; k++)
/*     */       {
/* 593 */         shapes.add(new DiamondTipsShape(1L));
/*     */       }
/* 595 */       return shapes;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 600 */     List<Shape> shape = new ArrayList<>(1);
/* 601 */     shape.add(new DiamondShape(radius));
/* 602 */     return shape;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final Shape periodicLine(long span, int[] increments) {
/* 638 */     return (Shape)new PeriodicLineShape(span, increments);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/imglib2-algorithm-0.6.2.jar!/net/imglib2/algorithm/morphology/StructuringElements.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */