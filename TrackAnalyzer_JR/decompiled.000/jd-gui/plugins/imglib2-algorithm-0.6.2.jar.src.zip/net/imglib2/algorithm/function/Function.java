package net.imglib2.algorithm.function;

public interface Function<S extends net.imglib2.type.Type<S>, T extends net.imglib2.type.Type<T>, U extends net.imglib2.type.Type<U>> {
  void compute(S paramS, T paramT, U paramU);
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/imglib2-algorithm-0.6.2.jar!/net/imglib2/algorithm/function/Function.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */