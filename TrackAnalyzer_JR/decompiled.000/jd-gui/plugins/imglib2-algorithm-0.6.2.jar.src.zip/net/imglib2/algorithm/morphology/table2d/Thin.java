/*    */ package net.imglib2.algorithm.morphology.table2d;
/*    */ 
/*    */ import net.imglib2.Dimensions;
/*    */ import net.imglib2.IterableInterval;
/*    */ import net.imglib2.RandomAccessible;
/*    */ import net.imglib2.img.Img;
/*    */ import net.imglib2.img.ImgFactory;
/*    */ import net.imglib2.img.list.ListImgFactory;
/*    */ import net.imglib2.type.BooleanType;
/*    */ import net.imglib2.type.NativeType;
/*    */ import net.imglib2.util.Util;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Thin
/*    */ {
/*    */   public static <T extends BooleanType<T>> Img<T> thin(Img<T> source) {
/* 78 */     return (new Thin2()).calculate((new Thin1()).calculate(source));
/*    */   }
/*    */ 
/*    */   
/*    */   public static <T extends BooleanType<T>> void thin(RandomAccessible<T> source, IterableInterval<T> target) {
/*    */     ListImgFactory listImgFactory;
/* 84 */     long[] targetDims = { target.dimension(0), target.dimension(1) };
/* 85 */     BooleanType booleanType = (BooleanType)((BooleanType)target.firstElement()).createVariable();
/* 86 */     booleanType.set(false);
/*    */ 
/*    */     
/* 89 */     if (booleanType instanceof NativeType) {
/* 90 */       ImgFactory<T> factory = Util.getArrayOrCellImgFactory((Dimensions)target, (NativeType)booleanType);
/*    */     } else {
/* 92 */       listImgFactory = new ListImgFactory();
/* 93 */     }  Img<T> temp = listImgFactory.create(targetDims, booleanType);
/*    */     
/* 95 */     (new Thin1()).calculate(source, (IterableInterval<T>)temp);
/* 96 */     (new Thin2()).calculate((RandomAccessible<T>)temp, target);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/imglib2-algorithm-0.6.2.jar!/net/imglib2/algorithm/morphology/table2d/Thin.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */