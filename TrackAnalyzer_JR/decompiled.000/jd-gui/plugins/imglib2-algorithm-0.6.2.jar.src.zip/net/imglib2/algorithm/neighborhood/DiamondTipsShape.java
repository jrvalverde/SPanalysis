/*     */ package net.imglib2.algorithm.neighborhood;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import net.imglib2.AbstractEuclideanSpace;
/*     */ import net.imglib2.AbstractInterval;
/*     */ import net.imglib2.Cursor;
/*     */ import net.imglib2.FlatIterationOrder;
/*     */ import net.imglib2.Interval;
/*     */ import net.imglib2.IterableInterval;
/*     */ import net.imglib2.RandomAccess;
/*     */ import net.imglib2.RandomAccessible;
/*     */ import net.imglib2.RandomAccessibleInterval;
/*     */ import net.imglib2.RealCursor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DiamondTipsShape
/*     */   implements Shape
/*     */ {
/*     */   private final long radius;
/*     */   
/*     */   public DiamondTipsShape(long radius) {
/*  68 */     this.radius = radius;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> NeighborhoodsIterableInterval<T> neighborhoods(RandomAccessibleInterval<T> source) {
/*  74 */     return new NeighborhoodsIterableInterval<>(source, this.radius, DiamondTipsNeighborhoodUnsafe.factory());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> NeighborhoodsAccessible<T> neighborhoodsRandomAccessible(RandomAccessible<T> source) {
/*  80 */     DiamondTipsNeighborhoodFactory<T> f = DiamondTipsNeighborhoodUnsafe.factory();
/*  81 */     return new NeighborhoodsAccessible<>(source, this.radius, f);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> NeighborhoodsIterableInterval<T> neighborhoodsSafe(RandomAccessibleInterval<T> source) {
/*  87 */     return new NeighborhoodsIterableInterval<>(source, this.radius, DiamondTipsNeighborhood.factory());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> NeighborhoodsAccessible<T> neighborhoodsRandomAccessibleSafe(RandomAccessible<T> source) {
/*  93 */     DiamondTipsNeighborhoodFactory<T> f = DiamondTipsNeighborhood.factory();
/*  94 */     return new NeighborhoodsAccessible<>(source, this.radius, f);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getRadius() {
/* 103 */     return this.radius;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 109 */     return "DiamondTipsShape, radius = " + this.radius;
/*     */   }
/*     */ 
/*     */   
/*     */   public static final class NeighborhoodsIterableInterval<T>
/*     */     extends AbstractInterval
/*     */     implements IterableInterval<Neighborhood<T>>
/*     */   {
/*     */     final RandomAccessibleInterval<T> source;
/*     */     
/*     */     final DiamondTipsNeighborhoodFactory<T> factory;
/*     */     final long size;
/*     */     private final long radius;
/*     */     
/*     */     public NeighborhoodsIterableInterval(RandomAccessibleInterval<T> source, long radius, DiamondTipsNeighborhoodFactory<T> factory) {
/* 124 */       super((Interval)source);
/* 125 */       this.source = source;
/* 126 */       this.radius = radius;
/* 127 */       this.factory = factory;
/* 128 */       long s = source.dimension(0);
/* 129 */       for (int d = 1; d < this.n; d++)
/*     */       {
/* 131 */         s *= source.dimension(d);
/*     */       }
/* 133 */       this.size = s;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Cursor<Neighborhood<T>> cursor() {
/* 139 */       return new DiamondTipsNeighborhoodCursor<>(this.source, this.radius, this.factory);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public long size() {
/* 145 */       return this.size;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Neighborhood<T> firstElement() {
/* 151 */       return (Neighborhood<T>)cursor().next();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Object iterationOrder() {
/* 157 */       return new FlatIterationOrder((Interval)this);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Iterator<Neighborhood<T>> iterator() {
/* 163 */       return (Iterator<Neighborhood<T>>)cursor();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Cursor<Neighborhood<T>> localizingCursor() {
/* 169 */       return cursor();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static final class NeighborhoodsAccessible<T>
/*     */     extends AbstractEuclideanSpace
/*     */     implements RandomAccessible<Neighborhood<T>>
/*     */   {
/*     */     final RandomAccessible<T> source;
/*     */     final DiamondTipsNeighborhoodFactory<T> factory;
/*     */     private final long radius;
/*     */     
/*     */     public NeighborhoodsAccessible(RandomAccessible<T> source, long radius, DiamondTipsNeighborhoodFactory<T> factory) {
/* 183 */       super(source.numDimensions());
/* 184 */       this.source = source;
/* 185 */       this.radius = radius;
/* 186 */       this.factory = factory;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public RandomAccess<Neighborhood<T>> randomAccess() {
/* 192 */       return new DiamondTipsNeighborhoodRandomAccess<>(this.source, this.radius, this.factory);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public RandomAccess<Neighborhood<T>> randomAccess(Interval interval) {
/* 198 */       return randomAccess();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public int numDimensions() {
/* 204 */       return this.source.numDimensions();
/*     */     }
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/imglib2-algorithm-0.6.2.jar!/net/imglib2/algorithm/neighborhood/DiamondTipsShape.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */