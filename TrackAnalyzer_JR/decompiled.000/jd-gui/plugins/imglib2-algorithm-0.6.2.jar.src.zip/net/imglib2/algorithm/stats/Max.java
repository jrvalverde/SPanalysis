/*    */ package net.imglib2.algorithm.stats;
/*    */ 
/*    */ import net.imglib2.Cursor;
/*    */ import net.imglib2.IterableInterval;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Max
/*    */ {
/*    */   public static <T extends Comparable<T>> Cursor<T> findMax(IterableInterval<T> iterable) {
/* 57 */     Cursor<T> cursor = iterable.cursor();
/* 58 */     cursor.fwd();
/* 59 */     Cursor<T> max = cursor.copyCursor();
/* 60 */     while (cursor.hasNext()) {
/* 61 */       if (((Comparable<Object>)cursor.next()).compareTo(max.get()) > 0)
/* 62 */         max = cursor.copyCursor(); 
/* 63 */     }  return max;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/imglib2-algorithm-0.6.2.jar!/net/imglib2/algorithm/stats/Max.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */