/*     */ package net.imglib2.algorithm.neighborhood;
/*     */ 
/*     */ import net.imglib2.Interval;
/*     */ import net.imglib2.Localizable;
/*     */ import net.imglib2.RandomAccess;
/*     */ import net.imglib2.RandomAccessible;
/*     */ import net.imglib2.Sampler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class RectangleNeighborhoodRandomAccess<T>
/*     */   extends RectangleNeighborhoodLocalizableSampler<T>
/*     */   implements RandomAccess<Neighborhood<T>>
/*     */ {
/*     */   public RectangleNeighborhoodRandomAccess(RandomAccessible<T> source, Interval span, RectangleNeighborhoodFactory<T> factory) {
/*  46 */     super(source, span, factory, (Interval)null);
/*     */   }
/*     */ 
/*     */   
/*     */   public RectangleNeighborhoodRandomAccess(RandomAccessible<T> source, Interval span, RectangleNeighborhoodFactory<T> factory, Interval interval) {
/*  51 */     super(source, span, factory, interval);
/*     */   }
/*     */ 
/*     */   
/*     */   private RectangleNeighborhoodRandomAccess(RectangleNeighborhoodRandomAccess<T> c) {
/*  56 */     super(c);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void fwd(int d) {
/*  62 */     this.currentPos[d] = this.currentPos[d] + 1L;
/*  63 */     this.currentMin[d] = this.currentMin[d] + 1L;
/*  64 */     this.currentMax[d] = this.currentMax[d] + 1L;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void bck(int d) {
/*  70 */     this.currentPos[d] = this.currentPos[d] - 1L;
/*  71 */     this.currentMin[d] = this.currentMin[d] - 1L;
/*  72 */     this.currentMax[d] = this.currentMax[d] - 1L;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void move(int distance, int d) {
/*  78 */     this.currentPos[d] = this.currentPos[d] + distance;
/*  79 */     this.currentMin[d] = this.currentMin[d] + distance;
/*  80 */     this.currentMax[d] = this.currentMax[d] + distance;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void move(long distance, int d) {
/*  86 */     this.currentPos[d] = this.currentPos[d] + distance;
/*  87 */     this.currentMin[d] = this.currentMin[d] + distance;
/*  88 */     this.currentMax[d] = this.currentMax[d] + distance;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void move(Localizable localizable) {
/*  94 */     for (int d = 0; d < this.n; d++) {
/*     */       
/*  96 */       long distance = localizable.getLongPosition(d);
/*  97 */       this.currentPos[d] = this.currentPos[d] + distance;
/*  98 */       this.currentMin[d] = this.currentMin[d] + distance;
/*  99 */       this.currentMax[d] = this.currentMax[d] + distance;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void move(int[] distance) {
/* 106 */     for (int d = 0; d < this.n; d++) {
/*     */       
/* 108 */       this.currentPos[d] = this.currentPos[d] + distance[d];
/* 109 */       this.currentMin[d] = this.currentMin[d] + distance[d];
/* 110 */       this.currentMax[d] = this.currentMax[d] + distance[d];
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void move(long[] distance) {
/* 117 */     for (int d = 0; d < this.n; d++) {
/*     */       
/* 119 */       this.currentPos[d] = this.currentPos[d] + distance[d];
/* 120 */       this.currentMin[d] = this.currentMin[d] + distance[d];
/* 121 */       this.currentMax[d] = this.currentMax[d] + distance[d];
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPosition(Localizable localizable) {
/* 128 */     for (int d = 0; d < this.n; d++) {
/*     */       
/* 130 */       long position = localizable.getLongPosition(d);
/* 131 */       this.currentPos[d] = position;
/* 132 */       this.currentMin[d] = position + this.span.min(d);
/* 133 */       this.currentMax[d] = position + this.span.max(d);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPosition(int[] position) {
/* 140 */     for (int d = 0; d < this.n; d++) {
/*     */       
/* 142 */       this.currentPos[d] = position[d];
/* 143 */       this.currentMin[d] = position[d] + this.span.min(d);
/* 144 */       this.currentMax[d] = position[d] + this.span.max(d);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPosition(long[] position) {
/* 151 */     for (int d = 0; d < this.n; d++) {
/*     */       
/* 153 */       this.currentPos[d] = position[d];
/* 154 */       this.currentMin[d] = position[d] + this.span.min(d);
/* 155 */       this.currentMax[d] = position[d] + this.span.max(d);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPosition(int position, int d) {
/* 162 */     this.currentPos[d] = position;
/* 163 */     this.currentMin[d] = position + this.span.min(d);
/* 164 */     this.currentMax[d] = position + this.span.max(d);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPosition(long position, int d) {
/* 170 */     this.currentPos[d] = position;
/* 171 */     this.currentMin[d] = position + this.span.min(d);
/* 172 */     this.currentMax[d] = position + this.span.max(d);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public RectangleNeighborhoodRandomAccess<T> copy() {
/* 178 */     return new RectangleNeighborhoodRandomAccess(this);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public RectangleNeighborhoodRandomAccess<T> copyRandomAccess() {
/* 184 */     return copy();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/imglib2-algorithm-0.6.2.jar!/net/imglib2/algorithm/neighborhood/RectangleNeighborhoodRandomAccess.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */