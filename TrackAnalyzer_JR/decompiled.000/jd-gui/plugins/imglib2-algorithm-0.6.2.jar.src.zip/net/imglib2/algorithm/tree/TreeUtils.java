/*    */ package net.imglib2.algorithm.tree;
/*    */ 
/*    */ import java.util.ArrayDeque;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TreeUtils
/*    */ {
/*    */   public static <T extends TreeNode<T>> ArrayList<T> getLeafs(Forest<T> forest) {
/* 51 */     ArrayList<T> leafs = new ArrayList<>();
/* 52 */     ArrayDeque<T> nodes = new ArrayDeque<>(forest.roots());
/* 53 */     while (!nodes.isEmpty()) {
/*    */       
/* 55 */       TreeNode<T> treeNode = (TreeNode)nodes.remove();
/* 56 */       List<T> children = treeNode.getChildren();
/* 57 */       if (children.isEmpty()) {
/* 58 */         leafs.add((T)treeNode); continue;
/*    */       } 
/* 60 */       nodes.addAll(children);
/*    */     } 
/* 62 */     return leafs;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static <T extends TreeNode<T>> void forEach(Forest<T> forest, Consumer<T> op) {
/* 80 */     ArrayDeque<T> nodes = new ArrayDeque<>(forest.roots());
/* 81 */     while (!nodes.isEmpty()) {
/*    */       
/* 83 */       TreeNode<T> treeNode = (TreeNode)nodes.remove();
/* 84 */       op.accept((T)treeNode);
/* 85 */       List<T> children = treeNode.getChildren();
/* 86 */       if (!children.isEmpty())
/* 87 */         nodes.addAll(children); 
/*    */     } 
/*    */   }
/*    */   
/*    */   public static interface Consumer<T> {
/*    */     void accept(T param1T);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/imglib2-algorithm-0.6.2.jar!/net/imglib2/algorithm/tree/TreeUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */