/*     */ package net.imglib2.algorithm.edge;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import net.imglib2.FinalInterval;
/*     */ import net.imglib2.Interval;
/*     */ import net.imglib2.RandomAccess;
/*     */ import net.imglib2.RandomAccessible;
/*     */ import net.imglib2.RandomAccessibleInterval;
/*     */ import net.imglib2.RealRandomAccess;
/*     */ import net.imglib2.algorithm.gradient.PartialDerivative;
/*     */ import net.imglib2.img.Img;
/*     */ import net.imglib2.img.ImgFactory;
/*     */ import net.imglib2.interpolation.randomaccess.NLinearInterpolatorFactory;
/*     */ import net.imglib2.type.numeric.RealType;
/*     */ import net.imglib2.util.Intervals;
/*     */ import net.imglib2.view.Views;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SubpixelEdgelDetection
/*     */ {
/*     */   public static <T extends RealType<T>> ArrayList<Edgel> getEdgels(RandomAccessibleInterval<T> input, ImgFactory<T> factory, double minGradientMagnitude) {
/*  92 */     ArrayList<Edgel> edgels = new ArrayList<>();
/*     */ 
/*     */     
/*  95 */     int n = input.numDimensions();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 102 */     for (int d = 0; d < n; d++) {
/* 103 */       if (input.dimension(d) < 5L) {
/* 104 */         return edgels;
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 110 */     long[] dim = new long[n + 1];
/* 111 */     for (int i = 0; i < n; i++)
/* 112 */       dim[i] = input.dimension(i); 
/* 113 */     dim[n] = n;
/* 114 */     Img<T> gradients = factory.create(dim, input.randomAccess().get());
/*     */ 
/*     */ 
/*     */     
/* 118 */     FinalInterval finalInterval1 = Intervals.expand((Interval)input, -1L);
/* 119 */     for (int j = 0; j < n; j++) {
/* 120 */       PartialDerivative.gradientCentralDifference((RandomAccessible)input, (RandomAccessibleInterval)Views.interval((RandomAccessible)Views.hyperSlice((RandomAccessibleInterval)gradients, n, j), (Interval)finalInterval1), j);
/*     */     }
/*     */ 
/*     */     
/* 124 */     FinalInterval finalInterval2 = Intervals.expand((Interval)input, -2L);
/*     */     
/* 126 */     long[] min = new long[n];
/* 127 */     finalInterval2.min(min);
/* 128 */     long[] max = new long[n];
/* 129 */     finalInterval2.max(max);
/* 130 */     long[] shiftback = new long[n];
/* 131 */     for (int k = 0; k < n; k++) {
/* 132 */       shiftback[k] = min[k] - max[k];
/*     */     }
/* 134 */     NLinearInterpolatorFactory<T> interpolatorFactory = new NLinearInterpolatorFactory();
/*     */     
/* 136 */     RealRandomAccess[] arrayOfRealRandomAccess = new RealRandomAccess[n];
/* 137 */     for (int m = 0; m < n; m++) {
/* 138 */       arrayOfRealRandomAccess[m] = (RealRandomAccess)interpolatorFactory.create((RandomAccessible)Views.hyperSlice((RandomAccessibleInterval)gradients, n, m));
/*     */     }
/* 140 */     RandomAccess<T> src = gradients.randomAccess();
/*     */     
/* 142 */     for (int i1 = 0; i1 < n; i1++)
/* 143 */       src.setPosition(min[i1], i1); 
/* 144 */     src.setPosition(0, n);
/*     */     
/* 146 */     double[] g = new double[n];
/* 147 */     double[] doublePos = new double[n];
/*     */     
/* 149 */     double minMagnitudeSquared = minGradientMagnitude * minGradientMagnitude;
/* 150 */     long max0 = max[0];
/*     */ 
/*     */ 
/*     */     
/*     */     while (true) {
/* 155 */       double len = 0.0D; int i2;
/* 156 */       for (i2 = 0; i2 < n; i2++) {
/*     */         
/* 158 */         double gg = ((RealType)src.get()).getRealDouble();
/* 159 */         len += gg * gg;
/* 160 */         g[i2] = gg;
/* 161 */         src.fwd(n);
/*     */       } 
/* 163 */       src.setPosition(0, n);
/* 164 */       if (len >= minMagnitudeSquared) {
/*     */         
/* 166 */         len = Math.sqrt(len);
/*     */         
/* 168 */         for (i2 = 0; i2 < n; i2++) {
/*     */           
/* 170 */           g[i2] = g[i2] / len;
/* 171 */           doublePos[i2] = src.getDoublePosition(i2) + g[i2];
/*     */         } 
/* 173 */         double lighterMag = gradientMagnitudeInDirection(doublePos, g, (RealRandomAccess<RealType>[])arrayOfRealRandomAccess);
/* 174 */         if (len >= lighterMag) {
/*     */           
/* 176 */           for (int i3 = 0; i3 < n; i3++) {
/* 177 */             doublePos[i3] = src.getDoublePosition(i3) - g[i3];
/*     */           }
/* 179 */           double darkerMag = gradientMagnitudeInDirection(doublePos, g, (RealRandomAccess<RealType>[])arrayOfRealRandomAccess);
/*     */           
/* 181 */           if (len >= darkerMag) {
/*     */ 
/*     */             
/* 184 */             double d1 = (darkerMag - lighterMag) / 2.0D * (darkerMag - 2.0D * len + lighterMag);
/* 185 */             for (int i4 = 0; i4 < n; i4++)
/* 186 */               doublePos[i4] = src.getDoublePosition(i4) + d1 * g[i4]; 
/* 187 */             edgels.add(new Edgel(doublePos, g, len));
/*     */           } 
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 193 */       if (src.getLongPosition(0) == max0) {
/*     */         
/* 195 */         src.move(shiftback[0], 0);
/* 196 */         if (n == 1)
/* 197 */           return edgels; 
/* 198 */         for (i2 = 1; i2 < n; i2++) {
/*     */           
/* 200 */           if (src.getLongPosition(i2) == max[i2]) {
/*     */             
/* 202 */             src.move(shiftback[i2], i2);
/* 203 */             if (i2 == n - 1) {
/* 204 */               return edgels;
/*     */             }
/*     */           } else {
/*     */             
/* 208 */             src.fwd(i2);
/*     */             break;
/*     */           } 
/*     */         } 
/*     */         continue;
/*     */       } 
/* 214 */       src.fwd(0);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static <T extends RealType<T>> double gradientMagnitudeInDirection(double[] position, double[] direction, RealRandomAccess<T>[] gradientAccess) {
/* 220 */     double len = 0.0D;
/* 221 */     for (int d = 0; d < gradientAccess.length; d++) {
/*     */       
/* 223 */       gradientAccess[d].setPosition(position);
/* 224 */       len += ((RealType)gradientAccess[d].get()).getRealDouble() * direction[d];
/*     */     } 
/* 226 */     return len;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/imglib2-algorithm-0.6.2.jar!/net/imglib2/algorithm/edge/SubpixelEdgelDetection.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */