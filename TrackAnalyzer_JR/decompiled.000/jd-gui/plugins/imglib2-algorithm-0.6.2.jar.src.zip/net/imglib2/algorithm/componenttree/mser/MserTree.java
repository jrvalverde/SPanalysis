/*     */ package net.imglib2.algorithm.componenttree.mser;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Comparator;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.Set;
/*     */ import net.imglib2.Dimensions;
/*     */ import net.imglib2.Positionable;
/*     */ import net.imglib2.RandomAccess;
/*     */ import net.imglib2.RandomAccessibleInterval;
/*     */ import net.imglib2.algorithm.componenttree.BuildComponentTree;
/*     */ import net.imglib2.algorithm.componenttree.ComponentForest;
/*     */ import net.imglib2.algorithm.componenttree.PartialComponent;
/*     */ import net.imglib2.img.ImgFactory;
/*     */ import net.imglib2.type.NativeType;
/*     */ import net.imglib2.type.Type;
/*     */ import net.imglib2.type.numeric.NumericType;
/*     */ import net.imglib2.type.numeric.RealType;
/*     */ import net.imglib2.type.numeric.integer.LongType;
/*     */ import net.imglib2.util.Util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class MserTree<T extends Type<T>>
/*     */   implements ComponentForest<Mser<T>>, Iterable<Mser<T>>, PartialComponent.Handler<MserPartialComponent<T>>
/*     */ {
/*     */   private final HashSet<Mser<T>> roots;
/*     */   private final ArrayList<Mser<T>> nodes;
/*     */   private final Comparator<T> comparator;
/*     */   private final ComputeDelta<T> delta;
/*     */   private final long minSize;
/*     */   private final long maxSize;
/*     */   private final double maxVar;
/*     */   private final double minDiversity;
/*     */   private int minimaFoundSinceLastPrune;
/*     */   private static final int pruneAfterNMinima = 1000;
/*     */   
/*     */   public static <T extends RealType<T>> MserTree<T> buildMserTree(RandomAccessibleInterval<T> input, double delta, long minSize, long maxSize, double maxVar, double minDiversity, boolean darkToBright) {
/* 151 */     return buildMserTree(input, getDeltaVariable(input, delta), minSize, maxSize, maxVar, minDiversity, darkToBright);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends RealType<T>> MserTree<T> buildMserTree(RandomAccessibleInterval<T> input, T delta, long minSize, long maxSize, double maxVar, double minDiversity, boolean darkToBright) {
/* 179 */     ImgFactory<LongType> factory = Util.getArrayOrCellImgFactory((Dimensions)input, (NativeType)new LongType());
/* 180 */     return buildMserTree(input, delta, minSize, maxSize, maxVar, minDiversity, factory, darkToBright);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends RealType<T>> MserTree<T> buildMserTree(RandomAccessibleInterval<T> input, T delta, long minSize, long maxSize, double maxVar, double minDiversity, ImgFactory<LongType> imgFactory, boolean darkToBright) {
/* 208 */     RealType realType = (RealType)delta.createVariable();
/* 209 */     realType.setReal(darkToBright ? delta.getMaxValue() : delta.getMinValue());
/* 210 */     MserPartialComponentGenerator<T> generator = (MserPartialComponentGenerator)new MserPartialComponentGenerator<>(realType, input, imgFactory);
/* 211 */     Comparator<T> comparator = darkToBright ? (Comparator<T>)new BuildComponentTree.DarkToBright() : (Comparator<T>)new BuildComponentTree.BrightToDark();
/* 212 */     ComputeDelta<T> computeDelta = darkToBright ? (ComputeDelta)new ComputeDeltaDarkToBright<>((NumericType)delta) : (ComputeDelta)new ComputeDeltaBrightToDark<>((NumericType)delta);
/* 213 */     MserTree<T> tree = (MserTree)new MserTree<>((Comparator)comparator, (ComputeDelta)computeDelta, minSize, maxSize, maxVar, minDiversity);
/* 214 */     BuildComponentTree.buildComponentTree(input, generator, tree, comparator);
/* 215 */     tree.pruneDuplicates();
/* 216 */     return tree;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends Type<T>> MserTree<T> buildMserTree(RandomAccessibleInterval<T> input, ComputeDelta<T> computeDelta, long minSize, long maxSize, double maxVar, double minDiversity, T maxValue, Comparator<T> comparator) {
/* 246 */     ImgFactory<LongType> factory = Util.getArrayOrCellImgFactory((Dimensions)input, (NativeType)new LongType());
/* 247 */     return buildMserTree(input, computeDelta, minSize, maxSize, maxVar, minDiversity, factory, maxValue, comparator);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends Type<T>> MserTree<T> buildMserTree(RandomAccessibleInterval<T> input, ComputeDelta<T> computeDelta, long minSize, long maxSize, double maxVar, double minDiversity, ImgFactory<LongType> imgFactory, T maxValue, Comparator<T> comparator) {
/* 277 */     MserPartialComponentGenerator<T> generator = new MserPartialComponentGenerator<>(maxValue, input, imgFactory);
/* 278 */     MserTree<T> tree = new MserTree<>(comparator, computeDelta, minSize, maxSize, maxVar, minDiversity);
/* 279 */     BuildComponentTree.buildComponentTree(input, generator, tree, comparator);
/* 280 */     tree.pruneDuplicates();
/* 281 */     return tree;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static <T extends RealType<T>> T getDeltaVariable(RandomAccessibleInterval<T> input, double delta) {
/* 290 */     RandomAccess<T> a = input.randomAccess();
/* 291 */     input.min((Positionable)a);
/* 292 */     RealType realType = (RealType)((RealType)a.get()).createVariable();
/* 293 */     realType.setReal(delta);
/* 294 */     return (T)realType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MserTree(Comparator<T> comparator, ComputeDelta<T> delta, long minSize, long maxSize, double maxVar, double minDiversity) {
/* 336 */     this.roots = new HashSet<>();
/* 337 */     this.nodes = new ArrayList<>();
/* 338 */     this.comparator = comparator;
/* 339 */     this.delta = delta;
/* 340 */     this.minSize = minSize;
/* 341 */     this.maxSize = maxSize;
/* 342 */     this.maxVar = maxVar;
/* 343 */     this.minDiversity = minDiversity;
/* 344 */     this.minimaFoundSinceLastPrune = 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void pruneDuplicates() {
/* 354 */     this.nodes.clear();
/* 355 */     for (Mser<T> mser : this.roots)
/* 356 */       pruneChildren(mser); 
/* 357 */     this.nodes.addAll(this.roots);
/*     */   }
/*     */ 
/*     */   
/*     */   private void pruneChildren(Mser<T> mser) {
/* 362 */     ArrayList<Mser<T>> validChildren = new ArrayList<>();
/* 363 */     for (int i = 0; i < mser.children.size(); i++) {
/*     */       
/* 365 */       Mser<T> m = mser.children.get(i);
/* 366 */       double div = (mser.size() - m.size()) / mser.size();
/* 367 */       if (div > this.minDiversity) {
/*     */         
/* 369 */         validChildren.add(m);
/* 370 */         pruneChildren(m);
/*     */       }
/*     */       else {
/*     */         
/* 374 */         mser.children.addAll(m.children);
/* 375 */         for (Mser<T> m2 : m.children)
/* 376 */           m2.parent = mser; 
/*     */       } 
/*     */     } 
/* 379 */     mser.children.clear();
/* 380 */     mser.children.addAll(validChildren);
/* 381 */     this.nodes.addAll(validChildren);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void emit(MserPartialComponent<T> component) {
/* 387 */     new MserEvaluationNode<>(component, this.comparator, this.delta, this);
/* 388 */     component.children.clear();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void foundNewMinimum(MserEvaluationNode<T> node) {
/* 400 */     if (node.size >= this.minSize && node.size <= this.maxSize && node.score <= this.maxVar) {
/*     */       
/* 402 */       Mser<T> mser = new Mser<>(node);
/* 403 */       for (Mser<T> m : node.mserThisOrChildren)
/* 404 */         mser.children.add(m); 
/* 405 */       node.mserThisOrChildren.clear();
/* 406 */       node.mserThisOrChildren.add(mser);
/*     */       
/* 408 */       for (Mser<T> m : mser.children)
/* 409 */         this.roots.remove(m); 
/* 410 */       this.roots.add(mser);
/* 411 */       this.nodes.add(mser);
/* 412 */       if (++this.minimaFoundSinceLastPrune == 1000) {
/*     */         
/* 414 */         this.minimaFoundSinceLastPrune = 0;
/* 415 */         pruneDuplicates();
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int size() {
/* 427 */     return this.nodes.size();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Iterator<Mser<T>> iterator() {
/* 438 */     return this.nodes.iterator();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HashSet<Mser<T>> roots() {
/* 449 */     return this.roots;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/imglib2-algorithm-0.6.2.jar!/net/imglib2/algorithm/componenttree/mser/MserTree.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */