/*     */ package net.imglib2.algorithm.neighborhood;
/*     */ 
/*     */ import net.imglib2.FinalInterval;
/*     */ import net.imglib2.Interval;
/*     */ import net.imglib2.IterableInterval;
/*     */ import net.imglib2.RandomAccessible;
/*     */ import net.imglib2.RandomAccessibleInterval;
/*     */ import net.imglib2.util.Util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CenteredRectangleShape
/*     */   implements Shape
/*     */ {
/*     */   final int[] span;
/*     */   final boolean skipCenter;
/*     */   
/*     */   public CenteredRectangleShape(int[] span, boolean skipCenter) {
/*  84 */     this.span = span;
/*  85 */     this.skipCenter = skipCenter;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> RectangleShape.NeighborhoodsIterableInterval<T> neighborhoods(RandomAccessibleInterval<T> source) {
/*  91 */     RectangleNeighborhoodFactory<T> f = this.skipCenter ? RectangleNeighborhoodSkipCenterUnsafe.<T>factory() : RectangleNeighborhoodUnsafe.<T>factory();
/*  92 */     Interval spanInterval = createSpan();
/*  93 */     return new RectangleShape.NeighborhoodsIterableInterval<>(source, spanInterval, f);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> RectangleShape.NeighborhoodsAccessible<T> neighborhoodsRandomAccessible(RandomAccessible<T> source) {
/*  99 */     RectangleNeighborhoodFactory<T> f = this.skipCenter ? RectangleNeighborhoodSkipCenterUnsafe.<T>factory() : RectangleNeighborhoodUnsafe.<T>factory();
/* 100 */     Interval spanInterval = createSpan();
/* 101 */     return new RectangleShape.NeighborhoodsAccessible<>(source, spanInterval, f);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> RectangleShape.NeighborhoodsIterableInterval<T> neighborhoodsSafe(RandomAccessibleInterval<T> source) {
/* 107 */     RectangleNeighborhoodFactory<T> f = this.skipCenter ? RectangleNeighborhoodSkipCenter.<T>factory() : RectangleNeighborhood.<T>factory();
/* 108 */     Interval spanInterval = createSpan();
/* 109 */     return new RectangleShape.NeighborhoodsIterableInterval<>(source, spanInterval, f);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> RectangleShape.NeighborhoodsAccessible<T> neighborhoodsRandomAccessibleSafe(RandomAccessible<T> source) {
/* 115 */     RectangleNeighborhoodFactory<T> f = this.skipCenter ? RectangleNeighborhoodSkipCenter.<T>factory() : RectangleNeighborhood.<T>factory();
/* 116 */     Interval spanInterval = createSpan();
/* 117 */     return new RectangleShape.NeighborhoodsAccessible<>(source, spanInterval, f);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSkippingCenter() {
/* 127 */     return this.skipCenter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int[] getSpan() {
/* 135 */     return (int[])this.span.clone();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 141 */     return "CenteredRectangleShape, span = " + Util.printCoordinates(this.span);
/*     */   }
/*     */ 
/*     */   
/*     */   private Interval createSpan() {
/* 146 */     long[] min = new long[this.span.length];
/* 147 */     long[] max = new long[this.span.length];
/* 148 */     for (int d = 0; d < this.span.length; d++) {
/*     */       
/* 150 */       min[d] = -this.span[d];
/* 151 */       max[d] = this.span[d];
/*     */     } 
/* 153 */     return (Interval)new FinalInterval(min, max);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/imglib2-algorithm-0.6.2.jar!/net/imglib2/algorithm/neighborhood/CenteredRectangleShape.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */