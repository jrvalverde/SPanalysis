/*    */ package net.imglib2.algorithm.neighborhood;
/*    */ 
/*    */ import net.imglib2.Cursor;
/*    */ import net.imglib2.Interval;
/*    */ import net.imglib2.RandomAccess;
/*    */ import net.imglib2.RealCursor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class RectangleNeighborhoodSkipCenterUnsafe<T>
/*    */   extends RectangleNeighborhoodSkipCenter<T>
/*    */ {
/*    */   private final RectangleNeighborhoodSkipCenter<T>.LocalCursor theCursor;
/*    */   private final RectangleNeighborhoodSkipCenter<T>.LocalCursor firstElementCursor;
/*    */   
/*    */   public static <T> RectangleNeighborhoodFactory<T> factory() {
/* 44 */     return new RectangleNeighborhoodFactory<T>()
/*    */       {
/*    */         
/*    */         public Neighborhood<T> create(long[] position, long[] currentMin, long[] currentMax, Interval span, RandomAccess<T> sourceRandomAccess)
/*    */         {
/* 49 */           return new RectangleNeighborhoodSkipCenterUnsafe<>(position, currentMin, currentMax, span, sourceRandomAccess);
/*    */         }
/*    */       };
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   RectangleNeighborhoodSkipCenterUnsafe(long[] position, long[] currentMin, long[] currentMax, Interval span, RandomAccess<T> sourceRandomAccess) {
/* 60 */     super(position, currentMin, currentMax, span, sourceRandomAccess);
/* 61 */     this.theCursor = super.cursor();
/* 62 */     this.firstElementCursor = super.cursor();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public T firstElement() {
/* 68 */     this.firstElementCursor.reset();
/* 69 */     return this.firstElementCursor.next();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public RectangleNeighborhoodSkipCenter<T>.LocalCursor cursor() {
/* 75 */     this.theCursor.reset();
/* 76 */     return this.theCursor;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/imglib2-algorithm-0.6.2.jar!/net/imglib2/algorithm/neighborhood/RectangleNeighborhoodSkipCenterUnsafe.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */