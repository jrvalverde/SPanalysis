/*     */ package net.imglib2.algorithm.gauss3;
/*     */ 
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.Executors;
/*     */ import net.imglib2.RandomAccessible;
/*     */ import net.imglib2.RandomAccessibleInterval;
/*     */ import net.imglib2.exception.IncompatibleTypeException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Gauss3
/*     */ {
/*     */   public static <S extends net.imglib2.type.numeric.NumericType<S>, T extends net.imglib2.type.numeric.NumericType<T>> void gauss(double sigma, RandomAccessible<S> source, RandomAccessibleInterval<T> target) throws IncompatibleTypeException {
/*  85 */     int n = source.numDimensions();
/*  86 */     double[] s = new double[n];
/*  87 */     for (int d = 0; d < n; d++)
/*  88 */       s[d] = sigma; 
/*  89 */     gauss(s, source, target);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <S extends net.imglib2.type.numeric.NumericType<S>, T extends net.imglib2.type.numeric.NumericType<T>> void gauss(double[] sigma, RandomAccessible<S> source, RandomAccessibleInterval<T> target) throws IncompatibleTypeException {
/* 126 */     int numthreads = Runtime.getRuntime().availableProcessors();
/* 127 */     ExecutorService service = Executors.newFixedThreadPool(numthreads);
/* 128 */     gauss(sigma, source, target, service);
/* 129 */     service.shutdown();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <S extends net.imglib2.type.numeric.NumericType<S>, T extends net.imglib2.type.numeric.NumericType<T>> void gauss(double[] sigma, RandomAccessible<S> source, RandomAccessibleInterval<T> target, int numThreads) throws IncompatibleTypeException {
/* 164 */     double[][] halfkernels = halfkernels(sigma);
/* 165 */     ExecutorService service = Executors.newFixedThreadPool(numThreads);
/* 166 */     SeparableSymmetricConvolution.convolve(halfkernels, source, target, service);
/* 167 */     service.shutdown();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <S extends net.imglib2.type.numeric.NumericType<S>, T extends net.imglib2.type.numeric.NumericType<T>> void gauss(double[] sigma, RandomAccessible<S> source, RandomAccessibleInterval<T> target, ExecutorService service) throws IncompatibleTypeException {
/* 202 */     double[][] halfkernels = halfkernels(sigma);
/* 203 */     SeparableSymmetricConvolution.convolve(halfkernels, source, target, service);
/*     */   }
/*     */ 
/*     */   
/*     */   public static double[][] halfkernels(double[] sigma) {
/* 208 */     int n = sigma.length;
/* 209 */     double[][] halfkernels = new double[n][];
/* 210 */     int[] size = halfkernelsizes(sigma);
/* 211 */     for (int i = 0; i < n; i++)
/* 212 */       halfkernels[i] = halfkernel(sigma[i], size[i], true); 
/* 213 */     return halfkernels;
/*     */   }
/*     */ 
/*     */   
/*     */   public static int[] halfkernelsizes(double[] sigma) {
/* 218 */     int n = sigma.length;
/* 219 */     int[] size = new int[n];
/* 220 */     for (int i = 0; i < n; i++)
/* 221 */       size[i] = Math.max(2, (int)(3.0D * sigma[i] + 0.5D) + 1); 
/* 222 */     return size;
/*     */   }
/*     */ 
/*     */   
/*     */   public static double[] halfkernel(double sigma, int size, boolean normalize) {
/* 227 */     double two_sq_sigma = 2.0D * sigma * sigma;
/* 228 */     double[] kernel = new double[size];
/*     */     
/* 230 */     kernel[0] = 1.0D;
/* 231 */     for (int x = 1; x < size; x++) {
/* 232 */       kernel[x] = Math.exp(-(x * x) / two_sq_sigma);
/*     */     }
/* 234 */     if (normalize) {
/*     */       
/* 236 */       double sum = 0.5D; int i;
/* 237 */       for (i = 1; i < size; i++)
/* 238 */         sum += kernel[i]; 
/* 239 */       sum *= 2.0D;
/*     */       
/* 241 */       for (i = 0; i < size; i++) {
/* 242 */         kernel[i] = kernel[i] / sum;
/*     */       }
/*     */     } 
/* 245 */     return kernel;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/imglib2-algorithm-0.6.2.jar!/net/imglib2/algorithm/gauss3/Gauss3.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */