/*     */ package net.imglib2.algorithm.neighborhood;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import net.imglib2.AbstractEuclideanSpace;
/*     */ import net.imglib2.AbstractLocalizable;
/*     */ import net.imglib2.Cursor;
/*     */ import net.imglib2.FinalInterval;
/*     */ import net.imglib2.Interval;
/*     */ import net.imglib2.Positionable;
/*     */ import net.imglib2.RandomAccess;
/*     */ import net.imglib2.RealCursor;
/*     */ import net.imglib2.RealPositionable;
/*     */ import net.imglib2.Sampler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HyperSphereNeighborhood<T>
/*     */   extends AbstractLocalizable
/*     */   implements Neighborhood<T>
/*     */ {
/*     */   private final RandomAccess<T> sourceRandomAccess;
/*     */   private final long radius;
/*     */   private final int maxDim;
/*     */   private final long size;
/*     */   private final Interval structuringElementBoundingBox;
/*     */   
/*     */   public static <T> HyperSphereNeighborhoodFactory<T> factory() {
/*  59 */     return new HyperSphereNeighborhoodFactory<T>()
/*     */       {
/*     */         
/*     */         public Neighborhood<T> create(long[] position, long radius, RandomAccess<T> sourceRandomAccess)
/*     */         {
/*  64 */           return new HyperSphereNeighborhood<>(position, radius, sourceRandomAccess);
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   HyperSphereNeighborhood(long[] position, long radius, RandomAccess<T> sourceRandomAccess) {
/*  81 */     super(position);
/*  82 */     this.sourceRandomAccess = sourceRandomAccess;
/*  83 */     this.radius = radius;
/*  84 */     this.maxDim = this.n - 1;
/*  85 */     this.size = computeSize();
/*     */     
/*  87 */     long[] min = new long[this.n];
/*  88 */     long[] max = new long[this.n];
/*     */     
/*  90 */     for (int d = 0; d < this.n; d++) {
/*     */       
/*  92 */       min[d] = -radius;
/*  93 */       max[d] = radius;
/*     */     } 
/*     */     
/*  96 */     this.structuringElementBoundingBox = (Interval)new FinalInterval(min, max);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected long computeSize() {
/* 104 */     LocalCursor cursor = new LocalCursor(this.sourceRandomAccess);
/*     */ 
/*     */     
/* 107 */     long size = 0L;
/* 108 */     while (cursor.hasNext()) {
/*     */       
/* 110 */       cursor.fwd();
/* 111 */       size++;
/*     */     } 
/*     */     
/* 114 */     return size;
/*     */   }
/*     */ 
/*     */   
/*     */   public final class LocalCursor
/*     */     extends AbstractEuclideanSpace
/*     */     implements Cursor<T>
/*     */   {
/*     */     private final RandomAccess<T> source;
/*     */     
/*     */     private final double[] r;
/*     */     
/*     */     private final long[] ri;
/*     */     
/*     */     private final long[] s;
/*     */ 
/*     */     
/*     */     public LocalCursor(RandomAccess<T> source) {
/* 132 */       super(source.numDimensions());
/* 133 */       this.source = source;
/* 134 */       this.r = new double[this.n];
/* 135 */       this.ri = new long[this.n];
/* 136 */       this.s = new long[this.n];
/* 137 */       reset();
/*     */     }
/*     */ 
/*     */     
/*     */     protected LocalCursor(LocalCursor c) {
/* 142 */       super(c.numDimensions());
/* 143 */       this.source = c.source.copyRandomAccess();
/* 144 */       this.r = (double[])c.r.clone();
/* 145 */       this.ri = (long[])c.ri.clone();
/* 146 */       this.s = (long[])c.s.clone();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public T get() {
/* 152 */       return (T)this.source.get();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void fwd() {
/* 159 */       this.s[0] = this.s[0] - 1L; if (this.s[0] - 1L >= 0L) {
/* 160 */         this.source.fwd(0);
/*     */       } else {
/*     */         
/* 163 */         int d = 1;
/* 164 */         for (; d < this.n; d++) {
/*     */           
/* 166 */           this.s[d] = this.s[d] - 1L; if (this.s[d] - 1L >= 0L) {
/*     */             
/* 168 */             this.source.fwd(d);
/*     */             
/*     */             break;
/*     */           } 
/*     */         } 
/* 173 */         for (; d > 0; d--) {
/*     */           
/* 175 */           int e = d - 1;
/* 176 */           double rd = this.r[d];
/* 177 */           long pd = this.s[d] - this.ri[d];
/*     */           
/* 179 */           double rad = Math.sqrt(rd * rd - (pd * pd));
/* 180 */           long radi = (long)rad;
/* 181 */           this.r[e] = rad;
/* 182 */           this.ri[e] = radi;
/* 183 */           this.s[e] = 2L * radi;
/*     */           
/* 185 */           this.source.setPosition(HyperSphereNeighborhood.this.position[e] - radi, e);
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void jumpFwd(long steps) {
/* 193 */       for (long i = 0L; i < steps; i++) {
/* 194 */         fwd();
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public T next() {
/* 200 */       fwd();
/* 201 */       return get();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void remove() {}
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void reset() {
/* 213 */       for (int d = 0; d < HyperSphereNeighborhood.this.maxDim; d++) {
/*     */         
/* 215 */         this.s[d] = 0L; this.ri[d] = 0L; this.r[d] = 0L;
/* 216 */         this.source.setPosition(HyperSphereNeighborhood.this.position[d], d);
/*     */       } 
/*     */       
/* 219 */       this.source.setPosition(HyperSphereNeighborhood.this.position[HyperSphereNeighborhood.this.maxDim] - HyperSphereNeighborhood.this.radius - 1L, HyperSphereNeighborhood.this.maxDim);
/*     */       
/* 221 */       this.r[HyperSphereNeighborhood.this.maxDim] = HyperSphereNeighborhood.this.radius;
/* 222 */       this.ri[HyperSphereNeighborhood.this.maxDim] = HyperSphereNeighborhood.this.radius;
/* 223 */       this.s[HyperSphereNeighborhood.this.maxDim] = 1L + 2L * HyperSphereNeighborhood.this.radius;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean hasNext() {
/* 229 */       return (this.s[HyperSphereNeighborhood.this.maxDim] > 0L);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public float getFloatPosition(int d) {
/* 235 */       return this.source.getFloatPosition(d);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public double getDoublePosition(int d) {
/* 241 */       return this.source.getDoublePosition(d);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public int getIntPosition(int d) {
/* 247 */       return this.source.getIntPosition(d);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public long getLongPosition(int d) {
/* 253 */       return this.source.getLongPosition(d);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void localize(long[] position) {
/* 259 */       this.source.localize(position);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void localize(float[] position) {
/* 265 */       this.source.localize(position);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void localize(double[] position) {
/* 271 */       this.source.localize(position);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void localize(int[] position) {
/* 277 */       this.source.localize(position);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public LocalCursor copy() {
/* 283 */       return new LocalCursor(this);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public LocalCursor copyCursor() {
/* 289 */       return copy();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Interval getStructuringElementBoundingBox() {
/* 296 */     return this.structuringElementBoundingBox;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public long size() {
/* 302 */     return this.size;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public T firstElement() {
/* 308 */     return cursor().next();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object iterationOrder() {
/* 314 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public double realMin(int d) {
/* 320 */     return (this.position[d] - this.radius);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void realMin(double[] min) {
/* 326 */     for (int d = 0; d < min.length; d++)
/*     */     {
/* 328 */       min[d] = (this.position[d] - this.radius);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void realMin(RealPositionable min) {
/* 335 */     for (int d = 0; d < min.numDimensions(); d++)
/*     */     {
/* 337 */       min.setPosition(this.position[d] - this.radius, d);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public double realMax(int d) {
/* 344 */     return (this.position[d] + this.radius);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void realMax(double[] max) {
/* 350 */     for (int d = 0; d < max.length; d++)
/*     */     {
/* 352 */       max[d] = (this.position[d] + this.radius);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void realMax(RealPositionable max) {
/* 359 */     for (int d = 0; d < max.numDimensions(); d++)
/*     */     {
/* 361 */       max.setPosition(this.position[d] + this.radius, d);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Iterator<T> iterator() {
/* 368 */     return (Iterator<T>)cursor();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public long min(int d) {
/* 374 */     return this.position[d] - this.radius;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void min(long[] min) {
/* 380 */     for (int d = 0; d < min.length; d++)
/*     */     {
/* 382 */       min[d] = this.position[d] - this.radius;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void min(Positionable min) {
/* 389 */     for (int d = 0; d < min.numDimensions(); d++)
/*     */     {
/* 391 */       min.setPosition(this.position[d] - this.radius, d);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public long max(int d) {
/* 398 */     return this.position[d] + this.radius;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void max(long[] max) {
/* 404 */     for (int d = 0; d < max.length; d++)
/*     */     {
/* 406 */       max[d] = this.position[d] + this.radius;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void max(Positionable max) {
/* 413 */     for (int d = 0; d < max.numDimensions(); d++)
/*     */     {
/* 415 */       max.setPosition(this.position[d] + this.radius, d);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void dimensions(long[] dimensions) {
/* 422 */     for (int d = 0; d < dimensions.length; d++)
/*     */     {
/* 424 */       dimensions[d] = 2L * this.radius + 1L;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public long dimension(int d) {
/* 431 */     return 2L * this.radius + 1L;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public LocalCursor cursor() {
/* 437 */     return new LocalCursor(this.sourceRandomAccess.copyRandomAccess());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public LocalCursor localizingCursor() {
/* 443 */     return cursor();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/imglib2-algorithm-0.6.2.jar!/net/imglib2/algorithm/neighborhood/HyperSphereNeighborhood.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */