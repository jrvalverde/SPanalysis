/*     */ package net.imglib2.algorithm.morphology;
/*     */ 
/*     */ import java.util.Vector;
/*     */ import net.imglib2.Cursor;
/*     */ import net.imglib2.Dimensions;
/*     */ import net.imglib2.EuclideanSpace;
/*     */ import net.imglib2.FinalDimensions;
/*     */ import net.imglib2.Interval;
/*     */ import net.imglib2.IterableInterval;
/*     */ import net.imglib2.Localizable;
/*     */ import net.imglib2.Positionable;
/*     */ import net.imglib2.RandomAccess;
/*     */ import net.imglib2.RandomAccessible;
/*     */ import net.imglib2.RandomAccessibleInterval;
/*     */ import net.imglib2.algorithm.neighborhood.Neighborhood;
/*     */ import net.imglib2.algorithm.neighborhood.Shape;
/*     */ import net.imglib2.img.Img;
/*     */ import net.imglib2.img.ImgFactory;
/*     */ import net.imglib2.img.array.ArrayImg;
/*     */ import net.imglib2.img.array.ArrayImgFactory;
/*     */ import net.imglib2.img.array.ArrayImgs;
/*     */ import net.imglib2.img.array.ArrayRandomAccess;
/*     */ import net.imglib2.img.basictypeaccess.array.LongArray;
/*     */ import net.imglib2.img.cell.CellImgFactory;
/*     */ import net.imglib2.img.list.ListImgFactory;
/*     */ import net.imglib2.multithreading.Chunk;
/*     */ import net.imglib2.multithreading.SimpleMultiThreading;
/*     */ import net.imglib2.type.NativeType;
/*     */ import net.imglib2.type.Type;
/*     */ import net.imglib2.type.logic.BitType;
/*     */ import net.imglib2.type.operators.Sub;
/*     */ import net.imglib2.util.Intervals;
/*     */ import net.imglib2.util.Util;
/*     */ import net.imglib2.view.IntervalView;
/*     */ import net.imglib2.view.Views;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MorphologyUtils
/*     */ {
/*     */   public static final <T> long[][] computeTargetImageDimensionsAndOffset(Interval source, Shape strel) {
/* 105 */     Neighborhood<BitType> sampleNeighborhood = getNeighborhood(strel, (EuclideanSpace)source);
/* 106 */     int ndims = sampleNeighborhood.numDimensions();
/* 107 */     ndims = Math.max(ndims, source.numDimensions());
/* 108 */     long[] targetDims = new long[ndims];
/* 109 */     for (int d = 0; d < ndims; d++) {
/*     */       long d1, d2;
/*     */       
/* 112 */       if (d < source.numDimensions()) {
/*     */         
/* 114 */         d1 = source.dimension(d);
/*     */       }
/*     */       else {
/*     */         
/* 118 */         d1 = 1L;
/*     */       } 
/*     */ 
/*     */       
/* 122 */       if (d < sampleNeighborhood.numDimensions()) {
/*     */         
/* 124 */         d2 = sampleNeighborhood.dimension(d);
/*     */       }
/*     */       else {
/*     */         
/* 128 */         d2 = 1L;
/*     */       } 
/*     */       
/* 131 */       targetDims[d] = d1 + d2 - 1L;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 136 */     long[] offset = new long[source.numDimensions()];
/* 137 */     for (int i = 0; i < offset.length; i++) {
/*     */       
/* 139 */       if (i < sampleNeighborhood.numDimensions()) {
/*     */         
/* 141 */         offset[i] = -sampleNeighborhood.min(i);
/*     */       }
/*     */       else {
/*     */         
/* 145 */         offset[i] = 0L;
/*     */       } 
/*     */     } 
/*     */     
/* 149 */     return new long[][] { targetDims, offset };
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static final void appendLine(RandomAccess<BitType> ra, long maxX, StringBuilder str) {
/* 155 */     str.append('┌'); long x;
/* 156 */     for (x = 0L; x < maxX; x++)
/*     */     {
/* 158 */       str.append('─');
/*     */     }
/* 160 */     str.append("┐\n");
/*     */     
/* 162 */     str.append('│');
/* 163 */     for (x = 0L; x < maxX; x++) {
/*     */       
/* 165 */       ra.setPosition(x, 0);
/* 166 */       if (((BitType)ra.get()).get()) {
/*     */         
/* 168 */         str.append('█');
/*     */       }
/*     */       else {
/*     */         
/* 172 */         str.append(' ');
/*     */       } 
/*     */     } 
/* 175 */     str.append("│\n");
/*     */     
/* 177 */     str.append('└');
/* 178 */     for (x = 0L; x < maxX; x++)
/*     */     {
/* 180 */       str.append('─');
/*     */     }
/* 182 */     str.append("┘\n");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static final void appendManySlice(RandomAccess<BitType> ra, long maxX, long maxY, long maxZ, StringBuilder str) {
/* 188 */     long width = Math.max(maxX + 3L, 9L); int i;
/* 189 */     for (i = 0; i < maxZ; i++) {
/*     */       
/* 191 */       String sample = "Z = " + i + ":";
/* 192 */       str.append(sample);
/* 193 */       for (int j = 0; j < width - sample.length(); j++)
/*     */       {
/* 195 */         str.append(' ');
/*     */       }
/*     */     } 
/* 198 */     str.append('\n');
/*     */ 
/*     */     
/* 201 */     for (i = 0; i < maxZ; i++) {
/*     */       
/* 203 */       str.append('┌'); long x;
/* 204 */       for (x = 0L; x < maxX; x++)
/*     */       {
/* 206 */         str.append('─');
/*     */       }
/* 208 */       str.append("┐ ");
/* 209 */       for (int j = 0; j < width - maxX - 3L; j++)
/*     */       {
/* 211 */         str.append(' ');
/*     */       }
/*     */     } 
/* 214 */     str.append('\n');
/*     */     
/*     */     long y;
/* 217 */     for (y = 0L; y < maxY; y++) {
/*     */       
/* 219 */       ra.setPosition(y, 1);
/*     */       
/* 221 */       for (int j = 0; j < maxZ; j++) {
/*     */         
/* 223 */         ra.setPosition(j, 2);
/* 224 */         str.append('│'); long x;
/* 225 */         for (x = 0L; x < maxX; x++) {
/*     */           
/* 227 */           ra.setPosition(x, 0);
/* 228 */           if (((BitType)ra.get()).get()) {
/*     */             
/* 230 */             str.append('█');
/*     */           }
/*     */           else {
/*     */             
/* 234 */             str.append(' ');
/*     */           } 
/*     */         } 
/* 237 */         str.append('│');
/* 238 */         for (int k = 0; k < width - maxX - 2L; k++)
/*     */         {
/* 240 */           str.append(' ');
/*     */         }
/*     */       } 
/* 243 */       str.append('\n');
/*     */     } 
/*     */ 
/*     */     
/* 247 */     for (int z = 0; z < maxZ; z++) {
/*     */       
/* 249 */       str.append('└'); long x;
/* 250 */       for (x = 0L; x < maxX; x++)
/*     */       {
/* 252 */         str.append('─');
/*     */       }
/* 254 */       str.append("┘ ");
/* 255 */       for (int j = 0; j < width - maxX - 3L; j++)
/*     */       {
/* 257 */         str.append(' ');
/*     */       }
/*     */     } 
/* 260 */     str.append('\n');
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static final void appendSingleSlice(RandomAccess<BitType> ra, long maxX, long maxY, StringBuilder str) {
/* 266 */     str.append('┌'); long l1;
/* 267 */     for (l1 = 0L; l1 < maxX; l1++)
/*     */     {
/* 269 */       str.append('─');
/*     */     }
/* 271 */     str.append("┐\n"); long y;
/* 272 */     for (y = 0L; y < maxY; y++) {
/*     */       
/* 274 */       str.append('│');
/* 275 */       ra.setPosition(y, 1); long l;
/* 276 */       for (l = 0L; l < maxX; l++) {
/*     */         
/* 278 */         ra.setPosition(l, 0);
/* 279 */         if (((BitType)ra.get()).get()) {
/*     */           
/* 281 */           str.append('█');
/*     */         }
/*     */         else {
/*     */           
/* 285 */           str.append(' ');
/*     */         } 
/*     */       } 
/* 288 */       str.append("│\n");
/*     */     } 
/*     */     
/* 291 */     str.append('└'); long x;
/* 292 */     for (x = 0L; x < maxX; x++)
/*     */     {
/* 294 */       str.append('─');
/*     */     }
/* 296 */     str.append("┘\n");
/*     */   }
/*     */ 
/*     */   
/*     */   static <T extends Type<T>> void copy(final IterableInterval<T> source, final RandomAccessible<T> target, int numThreads) {
/* 301 */     Vector<Chunk> chunks = SimpleMultiThreading.divideIntoChunks(source.size(), numThreads);
/* 302 */     Thread[] threads = SimpleMultiThreading.newThreads(numThreads);
/* 303 */     for (int i = 0; i < threads.length; i++) {
/*     */       
/* 305 */       final Chunk chunk = chunks.get(i);
/* 306 */       threads[i] = new Thread("Morphology copy thread " + i)
/*     */         {
/*     */           
/*     */           public void run()
/*     */           {
/* 311 */             Cursor<T> sourceCursor = source.localizingCursor();
/* 312 */             sourceCursor.jumpFwd(chunk.getStartPosition());
/* 313 */             RandomAccess<T> targetRandomAccess = target.randomAccess();
/*     */             
/* 315 */             for (long step = 0L; step < chunk.getLoopSize(); step++) {
/*     */               
/* 317 */               sourceCursor.fwd();
/* 318 */               targetRandomAccess.setPosition((Localizable)sourceCursor);
/* 319 */               ((Type)targetRandomAccess.get()).set((Type)sourceCursor.get());
/*     */             } 
/*     */           }
/*     */         };
/*     */     } 
/*     */     
/* 325 */     SimpleMultiThreading.startAndJoin(threads);
/*     */   }
/*     */ 
/*     */   
/*     */   static <T extends Type<T>> void copy2(final RandomAccessible<T> source, final IterableInterval<T> target, int numThreads) {
/* 330 */     Vector<Chunk> chunks = SimpleMultiThreading.divideIntoChunks(target.size(), numThreads);
/* 331 */     Thread[] threads = SimpleMultiThreading.newThreads(numThreads);
/* 332 */     for (int i = 0; i < threads.length; i++) {
/*     */       
/* 334 */       final Chunk chunk = chunks.get(i);
/* 335 */       threads[i] = new Thread("Morphology copy2 thread " + i)
/*     */         {
/*     */           
/*     */           public void run()
/*     */           {
/* 340 */             Cursor<T> targetCursor = target.localizingCursor();
/* 341 */             targetCursor.jumpFwd(chunk.getStartPosition());
/* 342 */             RandomAccess<T> sourceRandomAccess = source.randomAccess();
/*     */ 
/*     */             
/* 345 */             for (long step = 0L; step < chunk.getLoopSize(); step++) {
/*     */               
/* 347 */               targetCursor.fwd();
/* 348 */               sourceRandomAccess.setPosition((Localizable)targetCursor);
/* 349 */               ((Type)targetCursor.get()).set((Type)sourceRandomAccess.get());
/*     */             } 
/*     */           }
/*     */         };
/*     */     } 
/*     */     
/* 355 */     SimpleMultiThreading.startAndJoin(threads);
/*     */   }
/*     */ 
/*     */   
/*     */   static <T extends Type<T>> Img<T> copyCropped(final Img<T> largeSource, Interval interval, int numThreads) {
/* 360 */     final long[] offset = new long[largeSource.numDimensions()];
/* 361 */     for (int d = 0; d < offset.length; d++)
/*     */     {
/* 363 */       offset[d] = (largeSource.dimension(d) - interval.dimension(d)) / 2L;
/*     */     }
/* 365 */     final Img<T> create = largeSource.factory().create((Dimensions)interval, ((Type)largeSource.firstElement()).copy());
/*     */     
/* 367 */     Vector<Chunk> chunks = SimpleMultiThreading.divideIntoChunks(create.size(), numThreads);
/* 368 */     Thread[] threads = SimpleMultiThreading.newThreads(numThreads);
/* 369 */     for (int i = 0; i < threads.length; i++) {
/*     */       
/* 371 */       final Chunk chunk = chunks.get(i);
/* 372 */       threads[i] = new Thread("Morphology copyCropped thread " + i)
/*     */         {
/*     */           
/*     */           public void run()
/*     */           {
/* 377 */             IntervalView<T> intervalView = Views.offset((RandomAccessibleInterval)largeSource, offset);
/* 378 */             Cursor<T> cursor = create.cursor();
/* 379 */             cursor.jumpFwd(chunk.getStartPosition());
/* 380 */             RandomAccess<T> randomAccess = intervalView.randomAccess(); long step;
/* 381 */             for (step = 0L; step < chunk.getLoopSize(); step++) {
/*     */               
/* 383 */               cursor.fwd();
/* 384 */               randomAccess.setPosition((Localizable)cursor);
/* 385 */               ((Type)cursor.get()).set((Type)randomAccess.get());
/*     */             } 
/*     */           }
/*     */         };
/*     */     } 
/*     */     
/* 391 */     SimpleMultiThreading.startAndJoin(threads);
/* 392 */     return create;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static <T extends Type<T>> T createVariable(RandomAccessible<T> accessible, Interval interval) {
/* 405 */     RandomAccess<T> a = accessible.randomAccess();
/* 406 */     interval.min((Positionable)a);
/* 407 */     return (T)((Type)a.get()).createVariable();
/*     */   }
/*     */ 
/*     */   
/*     */   public static final Neighborhood<BitType> getNeighborhood(Shape shape, EuclideanSpace space) {
/* 412 */     int numDims = space.numDimensions();
/* 413 */     long[] dimensions = Util.getArrayFromValue(1L, numDims);
/* 414 */     ArrayImg<BitType, LongArray> img = ArrayImgs.bits(dimensions);
/* 415 */     IterableInterval<Neighborhood<BitType>> neighborhoods = shape.neighborhoods((RandomAccessibleInterval)img);
/* 416 */     Neighborhood<BitType> neighborhood = (Neighborhood<BitType>)neighborhoods.cursor().next();
/* 417 */     return neighborhood;
/*     */   }
/*     */ 
/*     */   
/*     */   static <T> ImgFactory<T> getSuitableFactory(long[] targetSize, T type) {
/* 422 */     FinalDimensions dim = FinalDimensions.wrap(targetSize);
/* 423 */     return getSuitableFactory((Dimensions)dim, type);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static <T> ImgFactory<T> getSuitableFactory(Dimensions targetSize, T type) {
/* 429 */     if (type instanceof NativeType) {
/*     */       
/* 431 */       NativeType nt = (NativeType)type;
/* 432 */       if (Intervals.numElements(targetSize) <= 2147483647L) {
/* 433 */         return (ImgFactory<T>)new ArrayImgFactory();
/*     */       }
/* 435 */       int cellSize = (int)Math.pow(2.147483647E9D / nt.getEntitiesPerPixel().getRatio(), 1.0D / targetSize.numDimensions());
/* 436 */       return (ImgFactory<T>)new CellImgFactory(cellSize);
/*     */     } 
/*     */ 
/*     */     
/* 440 */     return (ImgFactory<T>)new ListImgFactory();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String printNeighborhood(Shape shape, int dimensionality) {
/* 464 */     long[] dimensions = Util.getArrayFromValue(1L, dimensionality);
/*     */     
/* 466 */     ArrayImg<BitType, LongArray> img = ArrayImgs.bits(dimensions);
/* 467 */     ArrayRandomAccess<BitType> arrayRandomAccess = img.randomAccess();
/* 468 */     arrayRandomAccess.setPosition(Util.getArrayFromValue(0, dimensions.length));
/* 469 */     ((BitType)arrayRandomAccess.get()).set(true);
/* 470 */     Img<BitType> neighborhood = Dilation.dilateFull((Img)img, shape, 1);
/*     */ 
/*     */     
/* 473 */     StringBuilder str = new StringBuilder();
/* 474 */     for (int d = 3; d < neighborhood.numDimensions(); d++) {
/*     */       
/* 476 */       if (neighborhood.dimension(d) > 1L) {
/*     */         
/* 478 */         str.append("Cannot print structuring elements with n dimensions > 3.\nSkipping dimensions beyond 3.\n\n");
/*     */         
/*     */         break;
/*     */       } 
/*     */     } 
/* 483 */     RandomAccess<BitType> randomAccess = neighborhood.randomAccess();
/* 484 */     if (neighborhood.numDimensions() > 2) {
/*     */       
/* 486 */       appendManySlice(randomAccess, neighborhood.dimension(0), neighborhood.dimension(1), neighborhood.dimension(2), str);
/*     */     }
/* 488 */     else if (neighborhood.numDimensions() > 1) {
/*     */       
/* 490 */       appendSingleSlice(randomAccess, neighborhood.dimension(0), neighborhood.dimension(1), str);
/*     */     }
/* 492 */     else if (neighborhood.numDimensions() > 0) {
/*     */       
/* 494 */       appendLine(randomAccess, neighborhood.dimension(0), str);
/*     */     }
/*     */     else {
/*     */       
/* 498 */       str.append("Void structuring element.\n");
/*     */     } 
/*     */     
/* 501 */     return str.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static <T extends Sub<T>> void subAAB(final RandomAccessible<T> A, final IterableInterval<T> B, int numThreads) {
/* 515 */     Vector<Chunk> chunks = SimpleMultiThreading.divideIntoChunks(B.size(), numThreads);
/* 516 */     Thread[] threads = SimpleMultiThreading.newThreads(numThreads);
/*     */     
/* 518 */     for (int i = 0; i < threads.length; i++) {
/*     */       
/* 520 */       final Chunk chunk = chunks.get(i);
/* 521 */       threads[i] = new Thread("Morphology subAAB thread " + i)
/*     */         {
/*     */           
/*     */           public void run()
/*     */           {
/* 526 */             Cursor<T> Bcursor = B.localizingCursor();
/* 527 */             Bcursor.jumpFwd(chunk.getStartPosition());
/* 528 */             RandomAccess<T> Ara = A.randomAccess();
/*     */             
/* 530 */             for (long step = 0L; step < chunk.getLoopSize(); step++) {
/*     */               
/* 532 */               Bcursor.fwd();
/* 533 */               Ara.setPosition((Localizable)Bcursor);
/* 534 */               ((Sub)Ara.get()).sub(Bcursor.get());
/*     */             } 
/*     */           }
/*     */         };
/*     */     } 
/*     */     
/* 540 */     SimpleMultiThreading.startAndJoin(threads);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static <T extends Sub<T>> void subAAB2(final IterableInterval<T> A, final RandomAccessible<T> B, int numThreads) {
/* 555 */     Vector<Chunk> chunks = SimpleMultiThreading.divideIntoChunks(A.size(), numThreads);
/* 556 */     Thread[] threads = SimpleMultiThreading.newThreads(numThreads);
/*     */     
/* 558 */     for (int i = 0; i < threads.length; i++) {
/*     */       
/* 560 */       final Chunk chunk = chunks.get(i);
/* 561 */       threads[i] = new Thread("Morphology subAAB2 thread " + i)
/*     */         {
/*     */           
/*     */           public void run()
/*     */           {
/* 566 */             Cursor<T> Acursor = A.localizingCursor();
/* 567 */             Acursor.jumpFwd(chunk.getStartPosition());
/* 568 */             RandomAccess<T> Bra = B.randomAccess();
/*     */             
/* 570 */             for (long step = 0L; step < chunk.getLoopSize(); step++) {
/*     */               
/* 572 */               Acursor.fwd();
/* 573 */               Bra.setPosition((Localizable)Acursor);
/* 574 */               ((Sub)Acursor.get()).sub(Bra.get());
/*     */             } 
/*     */           }
/*     */         };
/*     */     } 
/*     */     
/* 580 */     SimpleMultiThreading.startAndJoin(threads);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static <T extends Sub<T> & Type<T>> void subABA(final RandomAccessible<T> source, final IterableInterval<T> target, int numThreads) {
/* 595 */     Vector<Chunk> chunks = SimpleMultiThreading.divideIntoChunks(target.size(), numThreads);
/* 596 */     Thread[] threads = SimpleMultiThreading.newThreads(numThreads);
/*     */     
/* 598 */     for (int i = 0; i < threads.length; i++) {
/*     */       
/* 600 */       final Chunk chunk = chunks.get(i);
/* 601 */       threads[i] = new Thread("Morphology subABA thread " + i)
/*     */         {
/*     */           
/*     */           public void run()
/*     */           {
/* 606 */             Sub sub = MorphologyUtils.<Sub>createVariable(source, (Interval)target);
/* 607 */             Cursor<T> targetCursor = target.localizingCursor();
/* 608 */             targetCursor.jumpFwd(chunk.getStartPosition());
/* 609 */             RandomAccess<T> sourceRandomAccess = source.randomAccess();
/*     */             long step;
/* 611 */             for (step = 0L; step < chunk.getLoopSize(); step++) {
/*     */               
/* 613 */               targetCursor.fwd();
/* 614 */               sourceRandomAccess.setPosition((Localizable)targetCursor);
/*     */               
/* 616 */               ((Type)sub).set((Type)targetCursor.get());
/* 617 */               sub.sub(sourceRandomAccess.get());
/*     */               
/* 619 */               ((Type)sourceRandomAccess.get()).set((Type)sub);
/*     */             } 
/*     */           }
/*     */         };
/*     */     } 
/*     */     
/* 625 */     SimpleMultiThreading.startAndJoin(threads);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static <T extends Sub<T> & Type<T>> void subABA2(final RandomAccessibleInterval<T> source, final RandomAccessible<T> target, int numThreads) {
/* 639 */     long size = Intervals.numElements((Dimensions)source);
/* 640 */     Vector<Chunk> chunks = SimpleMultiThreading.divideIntoChunks(size, numThreads);
/* 641 */     Thread[] threads = SimpleMultiThreading.newThreads(numThreads);
/*     */     
/* 643 */     for (int i = 0; i < threads.length; i++) {
/*     */       
/* 645 */       final Chunk chunk = chunks.get(i);
/* 646 */       threads[i] = new Thread("Morphology subABA2 thread " + i)
/*     */         {
/*     */           
/*     */           public void run()
/*     */           {
/* 651 */             Sub sub = MorphologyUtils.<Sub>createVariable(target, (Interval)source);
/* 652 */             Cursor<T> sourceCursor = Views.iterable(source).localizingCursor();
/* 653 */             sourceCursor.jumpFwd(chunk.getStartPosition());
/* 654 */             RandomAccess<T> targetRandomAccess = target.randomAccess((Interval)source);
/*     */             long step;
/* 656 */             for (step = 0L; step < chunk.getLoopSize(); step++);
/*     */ 
/*     */ 
/*     */             
/* 660 */             while (sourceCursor.hasNext()) {
/*     */               
/* 662 */               sourceCursor.fwd();
/* 663 */               targetRandomAccess.setPosition((Localizable)sourceCursor);
/*     */               
/* 665 */               ((Type)sub).set((Type)targetRandomAccess.get());
/* 666 */               sub.sub(sourceCursor.get());
/*     */               
/* 668 */               ((Type)targetRandomAccess.get()).set((Type)sub);
/*     */             } 
/*     */           }
/*     */         };
/*     */     } 
/*     */     
/* 674 */     SimpleMultiThreading.startAndJoin(threads);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static <T extends Type<T> & Sub<T>> void subBAB(final RandomAccessible<T> A, final IterableInterval<T> B, int numThreads) {
/* 688 */     long size = Intervals.numElements((Dimensions)B);
/* 689 */     Vector<Chunk> chunks = SimpleMultiThreading.divideIntoChunks(size, numThreads);
/* 690 */     Thread[] threads = SimpleMultiThreading.newThreads(numThreads);
/*     */     
/* 692 */     for (int i = 0; i < threads.length; i++) {
/*     */       
/* 694 */       final Chunk chunk = chunks.get(i);
/* 695 */       threads[i] = new Thread("Morphology subBAB thread " + i)
/*     */         {
/*     */           
/*     */           public void run()
/*     */           {
/* 700 */             T tmp = (T)MorphologyUtils.createVariable(A, (Interval)B);
/* 701 */             Cursor<T> BCursor = B.localizingCursor();
/* 702 */             BCursor.jumpFwd(chunk.getStartPosition());
/* 703 */             RandomAccess<T> Ara = A.randomAccess();
/*     */             long step;
/* 705 */             for (step = 0L; step < chunk.getLoopSize(); step++) {
/*     */               
/* 707 */               BCursor.fwd();
/* 708 */               Ara.setPosition((Localizable)BCursor);
/*     */               
/* 710 */               tmp.set((Type)Ara.get());
/* 711 */               ((Sub)tmp).sub(BCursor.get());
/*     */               
/* 713 */               ((Type)BCursor.get()).set((Type)tmp);
/*     */             } 
/*     */           }
/*     */         };
/*     */     } 
/*     */     
/* 719 */     SimpleMultiThreading.startAndJoin(threads);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/imglib2-algorithm-0.6.2.jar!/net/imglib2/algorithm/morphology/MorphologyUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */