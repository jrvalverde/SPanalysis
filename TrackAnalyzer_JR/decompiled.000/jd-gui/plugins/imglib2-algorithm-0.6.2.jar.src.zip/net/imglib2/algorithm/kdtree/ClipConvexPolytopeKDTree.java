/*     */ package net.imglib2.algorithm.kdtree;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import net.imglib2.KDTree;
/*     */ import net.imglib2.KDTreeNode;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ClipConvexPolytopeKDTree<T>
/*     */ {
/*     */   private final KDTree<T> tree;
/*     */   private final int n;
/*     */   private int nPlanes;
/*     */   private double[][] normals;
/*     */   private double[] ms;
/*     */   private final double[] xmin;
/*     */   private final double[] xmax;
/*     */   private boolean[] qR;
/*     */   private boolean[] qL;
/*     */   private final ArrayList<boolean[]> activeStack;
/*     */   private final ArrayList<boolean[]> psStack;
/*     */   private final ArrayList<KDTreeNode<T>> inNodes;
/*     */   private final ArrayList<KDTreeNode<T>> inSubtrees;
/*     */   private final ArrayList<KDTreeNode<T>> outNodes;
/*     */   private final ArrayList<KDTreeNode<T>> outSubtrees;
/*     */   
/*     */   public ClipConvexPolytopeKDTree(KDTree<T> tree) {
/*  97 */     this.tree = tree;
/*  98 */     this.n = tree.numDimensions();
/*  99 */     this.xmin = new double[this.n];
/* 100 */     this.xmax = new double[this.n];
/* 101 */     this.activeStack = (ArrayList)new ArrayList<>();
/* 102 */     this.psStack = (ArrayList)new ArrayList<>();
/* 103 */     this.inNodes = new ArrayList<>();
/* 104 */     this.inSubtrees = new ArrayList<>();
/* 105 */     this.outNodes = new ArrayList<>();
/* 106 */     this.outSubtrees = new ArrayList<>();
/*     */   }
/*     */ 
/*     */   
/*     */   public int numDimensions() {
/* 111 */     return this.n;
/*     */   }
/*     */ 
/*     */   
/*     */   public void clip(ConvexPolytope polytope) {
/* 116 */     Collection<? extends HyperPlane> planes = polytope.getHyperplanes();
/* 117 */     initNewSearch(planes.size());
/* 118 */     int i = 0;
/* 119 */     for (HyperPlane plane : planes) {
/*     */       
/* 121 */       double[] normal = this.normals[i];
/* 122 */       System.arraycopy(plane.getNormal(), 0, normal, 0, this.n);
/* 123 */       this.ms[i] = plane.getDistance();
/* 124 */       for (int d = 0; d < this.n; d++) {
/*     */         
/* 126 */         this.qL[d * this.nPlanes + i] = (normal[d] < 0.0D);
/* 127 */         this.qR[d * this.nPlanes + i] = (normal[d] >= 0.0D);
/*     */       } 
/* 129 */       i++;
/*     */     } 
/* 131 */     clip(this.tree.getRoot(), 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public void clip(double[][] planes) {
/* 136 */     initNewSearch(planes.length);
/* 137 */     for (int i = 0; i < this.nPlanes; i++) {
/*     */       
/* 139 */       double[] normal = this.normals[i];
/* 140 */       System.arraycopy(planes[i], 0, normal, 0, this.n);
/* 141 */       this.ms[i] = planes[i][this.n];
/* 142 */       for (int d = 0; d < this.n; d++) {
/*     */         
/* 144 */         this.qL[d * this.nPlanes + i] = (normal[d] < 0.0D);
/* 145 */         this.qR[d * this.nPlanes + i] = (normal[d] >= 0.0D);
/*     */       } 
/*     */     } 
/* 148 */     clip(this.tree.getRoot(), 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public Iterable<KDTreeNode<T>> getInsideNodes() {
/* 153 */     return new KDTreeNodeIterable<>(this.inNodes, this.inSubtrees);
/*     */   }
/*     */ 
/*     */   
/*     */   public Iterable<KDTreeNode<T>> getOutsideNodes() {
/* 158 */     return new KDTreeNodeIterable<>(this.outNodes, this.outSubtrees);
/*     */   }
/*     */ 
/*     */   
/*     */   private void initNewSearch(int nPlanes) {
/* 163 */     this.nPlanes = nPlanes;
/* 164 */     this.normals = new double[nPlanes][];
/* 165 */     for (int i = 0; i < nPlanes; i++)
/* 166 */       this.normals[i] = new double[this.n]; 
/* 167 */     this.ms = new double[nPlanes];
/* 168 */     this.qR = new boolean[this.n * nPlanes];
/* 169 */     this.qL = new boolean[this.n * nPlanes];
/* 170 */     this.inNodes.clear();
/* 171 */     this.inSubtrees.clear();
/* 172 */     this.outNodes.clear();
/* 173 */     this.outSubtrees.clear();
/* 174 */     this.activeStack.clear();
/* 175 */     this.psStack.clear();
/* 176 */     this.tree.realMin(this.xmin);
/* 177 */     this.tree.realMax(this.xmax);
/* 178 */     Arrays.fill(getActiveArray(0), true);
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean[] getActiveArray(int i) {
/* 183 */     if (i >= this.activeStack.size()) {
/*     */       
/* 185 */       this.activeStack.add(new boolean[this.nPlanes]);
/* 186 */       this.psStack.add(new boolean[this.nPlanes]);
/*     */     } 
/* 188 */     return this.activeStack.get(i);
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean[] getPsArray(int i) {
/* 193 */     return this.psStack.get(i);
/*     */   }
/*     */ 
/*     */   
/*     */   private void addAll(KDTreeNode<T> node, ArrayList<KDTreeNode<T>> list) {
/* 198 */     list.add(node);
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean allAbove(int i) {
/* 203 */     double[] normal = this.normals[i];
/* 204 */     double dot = 0.0D;
/* 205 */     for (int d = 0; d < this.n; d++)
/* 206 */       dot += normal[d] * ((normal[d] >= 0.0D) ? this.xmin[d] : this.xmax[d]); 
/* 207 */     return (dot >= this.ms[i]);
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean allBelow(int i) {
/* 212 */     double[] normal = this.normals[i];
/* 213 */     double dot = 0.0D;
/* 214 */     for (int d = 0; d < this.n; d++)
/* 215 */       dot += normal[d] * ((normal[d] < 0.0D) ? this.xmin[d] : this.xmax[d]); 
/* 216 */     return (dot < this.ms[i]);
/*     */   }
/*     */ 
/*     */   
/*     */   private void clipSubtree(KDTreeNode<T> current, boolean[] ps, boolean[] qs, int qoff, int recursionDepth) {
/* 221 */     boolean[] active = getActiveArray(recursionDepth);
/* 222 */     boolean[] stillActive = getActiveArray(recursionDepth + 1);
/* 223 */     System.arraycopy(active, 0, stillActive, 0, this.nPlanes);
/* 224 */     boolean noneActive = true;
/* 225 */     for (int i = 0; i < this.nPlanes; i++) {
/*     */       
/* 227 */       if (active[i])
/*     */       {
/* 229 */         if (ps[i] && qs[qoff + i] && allAbove(i)) {
/* 230 */           stillActive[i] = false;
/*     */         } else {
/*     */           
/* 233 */           noneActive = false;
/* 234 */           if (!ps[i] && !qs[qoff + i] && allBelow(i)) {
/*     */             
/* 236 */             addAll(current, this.outSubtrees);
/*     */             return;
/*     */           } 
/*     */         } 
/*     */       }
/*     */     } 
/* 242 */     if (noneActive) {
/* 243 */       addAll(current, this.inSubtrees);
/*     */     } else {
/* 245 */       clip(current, recursionDepth + 1);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void clip(KDTreeNode<T> current, int recursionDepth) {
/* 250 */     int sd = current.getSplitDimension();
/* 251 */     double sc = current.getSplitCoordinate();
/*     */     
/* 253 */     boolean[] active = getActiveArray(recursionDepth);
/* 254 */     boolean[] ps = getPsArray(recursionDepth);
/*     */     
/* 256 */     boolean p = true;
/* 257 */     for (int i = 0; i < this.nPlanes; i++) {
/*     */       
/* 259 */       if (active[i]) {
/*     */         
/* 261 */         double[] normal = this.normals[i];
/* 262 */         double dot = 0.0D;
/* 263 */         for (int d = 0; d < this.n; d++)
/* 264 */           dot += current.getDoublePosition(d) * normal[d]; 
/* 265 */         ps[i] = (dot >= this.ms[i]);
/* 266 */         p &= ps[i];
/*     */       } 
/*     */     } 
/*     */     
/* 270 */     if (p) {
/* 271 */       this.inNodes.add(current);
/*     */     } else {
/* 273 */       this.outNodes.add(current);
/*     */     } 
/* 275 */     int qoff = sd * this.nPlanes;
/* 276 */     if (current.left != null) {
/*     */       
/* 278 */       double max = this.xmax[sd];
/* 279 */       this.xmax[sd] = sc;
/* 280 */       clipSubtree(current.left, ps, this.qL, qoff, recursionDepth);
/* 281 */       this.xmax[sd] = max;
/*     */     } 
/*     */     
/* 284 */     if (current.right != null) {
/*     */       
/* 286 */       double min = this.xmin[sd];
/* 287 */       this.xmin[sd] = sc;
/* 288 */       clipSubtree(current.right, ps, this.qR, qoff, recursionDepth);
/* 289 */       this.xmin[sd] = min;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/imglib2-algorithm-0.6.2.jar!/net/imglib2/algorithm/kdtree/ClipConvexPolytopeKDTree.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */