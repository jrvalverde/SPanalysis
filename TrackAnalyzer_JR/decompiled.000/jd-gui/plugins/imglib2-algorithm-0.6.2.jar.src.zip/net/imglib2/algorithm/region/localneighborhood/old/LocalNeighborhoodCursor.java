/*     */ package net.imglib2.algorithm.region.localneighborhood.old;
/*     */ 
/*     */ import net.imglib2.Cursor;
/*     */ import net.imglib2.Localizable;
/*     */ import net.imglib2.RandomAccess;
/*     */ import net.imglib2.RandomAccessible;
/*     */ import net.imglib2.RealCursor;
/*     */ import net.imglib2.Sampler;
/*     */ import net.imglib2.iterator.LocalizingZeroMinIntervalIterator;
/*     */ import net.imglib2.util.IntervalIndexer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public class LocalNeighborhoodCursor<T>
/*     */   implements Cursor<T>
/*     */ {
/*     */   final RandomAccessible<T> source;
/*     */   protected final RandomAccess<T> randomAccess;
/*     */   final LocalizingZeroMinIntervalIterator driver;
/*     */   final long[] positionMinus1;
/*     */   final long[] tmp;
/*     */   final int numDimensions;
/*     */   final int centralPositionIndex;
/*     */   
/*     */   public LocalNeighborhoodCursor(RandomAccessible<T> source, long[] center) {
/*  81 */     this.source = source;
/*  82 */     this.randomAccess = source.randomAccess();
/*     */     
/*  84 */     this.numDimensions = source.numDimensions();
/*  85 */     this.tmp = new long[this.numDimensions];
/*  86 */     this.positionMinus1 = new long[this.numDimensions];
/*     */     
/*  88 */     int[] dim = new int[this.numDimensions];
/*  89 */     int[] dim2 = new int[this.numDimensions];
/*     */     
/*  91 */     for (int d = 0; d < this.numDimensions; d++) {
/*     */       
/*  93 */       dim[d] = 3;
/*  94 */       dim2[d] = 1;
/*  95 */       this.positionMinus1[d] = center[d] - 1L;
/*     */     } 
/*     */     
/*  98 */     this.driver = new LocalizingZeroMinIntervalIterator(dim);
/*  99 */     this.centralPositionIndex = IntervalIndexer.positionToIndex(dim2, dim);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LocalNeighborhoodCursor(RandomAccessible<T> source, Localizable center) {
/* 117 */     this.source = source;
/* 118 */     this.randomAccess = source.randomAccess();
/*     */     
/* 120 */     this.numDimensions = source.numDimensions();
/* 121 */     this.tmp = new long[this.numDimensions];
/* 122 */     this.positionMinus1 = new long[this.numDimensions];
/*     */     
/* 124 */     int[] dim = new int[this.numDimensions];
/* 125 */     int[] dim2 = new int[this.numDimensions];
/*     */     
/* 127 */     for (int d = 0; d < this.numDimensions; d++) {
/*     */       
/* 129 */       dim[d] = 3;
/* 130 */       dim2[d] = 1;
/* 131 */       this.positionMinus1[d] = center.getLongPosition(d) - 1L;
/*     */     } 
/*     */     
/* 134 */     this.driver = new LocalizingZeroMinIntervalIterator(dim);
/* 135 */     this.centralPositionIndex = IntervalIndexer.positionToIndex(dim2, dim);
/*     */   }
/*     */ 
/*     */   
/*     */   public LocalNeighborhoodCursor(LocalNeighborhoodCursor<T> cursor) {
/* 140 */     this.source = cursor.source;
/* 141 */     this.randomAccess = this.source.randomAccess();
/* 142 */     this.randomAccess.setPosition((Localizable)cursor.randomAccess);
/*     */     
/* 144 */     this.numDimensions = cursor.numDimensions();
/* 145 */     this.tmp = (long[])cursor.tmp.clone();
/* 146 */     this.positionMinus1 = (long[])cursor.positionMinus1.clone();
/*     */     
/* 148 */     int[] dim = new int[this.numDimensions];
/* 149 */     for (int d = 0; d < this.numDimensions; d++) {
/* 150 */       dim[d] = 3;
/*     */     }
/* 152 */     this.driver = new LocalizingZeroMinIntervalIterator(dim);
/* 153 */     this.driver.jumpFwd(cursor.driver.getIndex());
/*     */     
/* 155 */     this.centralPositionIndex = cursor.centralPositionIndex;
/*     */   }
/*     */ 
/*     */   
/*     */   public void updateCenter(long[] center) {
/* 160 */     for (int d = 0; d < this.numDimensions; d++) {
/* 161 */       this.positionMinus1[d] = center[d] - 1L;
/*     */     }
/* 163 */     reset();
/*     */   }
/*     */ 
/*     */   
/*     */   public void updateCenter(Localizable center) {
/* 168 */     for (int d = 0; d < this.numDimensions; d++) {
/* 169 */       this.positionMinus1[d] = center.getLongPosition(d) - 1L;
/*     */     }
/* 171 */     reset();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasNext() {
/* 177 */     return this.driver.hasNext();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void fwd() {
/* 183 */     this.driver.fwd();
/*     */     
/* 185 */     if (this.driver.getIndex() == this.centralPositionIndex) {
/* 186 */       this.driver.fwd();
/*     */     }
/* 188 */     for (int d = 0; d < this.numDimensions; d++) {
/* 189 */       this.randomAccess.setPosition(this.positionMinus1[d] + this.driver.getLongPosition(d), d);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void jumpFwd(long steps) {
/* 195 */     for (long j = 0L; j < steps; j++) {
/* 196 */       fwd();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void reset() {
/* 202 */     this.driver.reset();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void localize(float[] position) {
/* 208 */     this.randomAccess.localize(position);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void localize(double[] position) {
/* 214 */     this.randomAccess.localize(position);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public float getFloatPosition(int d) {
/* 220 */     return this.randomAccess.getFloatPosition(d);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public double getDoublePosition(int d) {
/* 226 */     return this.randomAccess.getDoublePosition(d);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int numDimensions() {
/* 232 */     return this.numDimensions;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public T get() {
/* 238 */     return (T)this.randomAccess.get();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public T next() {
/* 244 */     fwd();
/* 245 */     return get();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void remove() {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void localize(int[] position) {
/* 255 */     this.randomAccess.localize(position);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void localize(long[] position) {
/* 261 */     this.randomAccess.localize(position);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getIntPosition(int d) {
/* 267 */     return this.randomAccess.getIntPosition(d);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public long getLongPosition(int d) {
/* 273 */     return this.randomAccess.getLongPosition(d);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public LocalNeighborhoodCursor<T> copyCursor() {
/* 279 */     return new LocalNeighborhoodCursor(this);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public LocalNeighborhoodCursor<T> copy() {
/* 285 */     return copyCursor();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/imglib2-algorithm-0.6.2.jar!/net/imglib2/algorithm/region/localneighborhood/old/LocalNeighborhoodCursor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */