/*     */ package net.imglib2.algorithm.componenttree.mser;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Comparator;
/*     */ import net.imglib2.algorithm.componenttree.pixellist.PixelList;
/*     */ import net.imglib2.type.Type;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class MserEvaluationNode<T extends Type<T>>
/*     */ {
/*     */   final T value;
/*     */   final long size;
/*     */   final PixelList pixelList;
/*     */   private final MserEvaluationNode<T> historyChild;
/*     */   private MserEvaluationNode<T> parent;
/*     */   double score;
/*     */   private final boolean isScoreValid;
/*     */   final int n;
/*     */   final double[] mean;
/*     */   final double[] cov;
/*     */   final ArrayList<Mser<T>> mserThisOrChildren;
/*     */   
/*     */   MserEvaluationNode(MserPartialComponent<T> component, Comparator<T> comparator, ComputeDelta<T> delta, MserTree<T> tree) {
/* 132 */     this.value = (T)component.getValue().copy();
/* 133 */     this.pixelList = new PixelList(component.pixelList);
/* 134 */     this.size = this.pixelList.size();
/*     */     
/* 136 */     ArrayList<MserEvaluationNode<T>> children = new ArrayList<>();
/* 137 */     MserEvaluationNode<T> node = component.getEvaluationNode();
/* 138 */     long historySize = 0L;
/* 139 */     if (node != null) {
/*     */       
/* 141 */       historySize = node.size;
/*     */       
/* 143 */       node = new MserEvaluationNode(node, this.value, comparator, delta);
/* 144 */       children.add(node);
/* 145 */       node.setParent(this);
/*     */     } 
/*     */     
/* 148 */     MserEvaluationNode<T> historyWinner = node;
/* 149 */     for (MserPartialComponent<T> c : component.children) {
/*     */ 
/*     */       
/* 152 */       node = new MserEvaluationNode(c.getEvaluationNode(), this.value, comparator, delta);
/* 153 */       children.add(node);
/* 154 */       node.setParent(this);
/* 155 */       if (c.size() > historySize) {
/*     */         
/* 157 */         historyWinner = node;
/* 158 */         historySize = c.size();
/*     */       } 
/*     */     } 
/*     */     
/* 162 */     this.historyChild = historyWinner;
/*     */     
/* 164 */     this.n = component.n;
/* 165 */     this.mean = new double[this.n];
/* 166 */     this.cov = new double[this.n * (this.n + 1) / 2];
/* 167 */     for (int i = 0; i < this.n; i++)
/* 168 */       this.mean[i] = component.sumPos[i] / this.size; 
/* 169 */     int k = 0;
/* 170 */     for (int j = 0; j < this.n; j++) {
/* 171 */       for (int m = j; m < this.n; m++) {
/*     */         
/* 173 */         this.cov[k] = component.sumSquPos[k] / this.size - this.mean[j] * this.mean[m];
/* 174 */         k++;
/*     */       } 
/*     */     } 
/* 177 */     component.setEvaluationNode(this);
/* 178 */     this.isScoreValid = computeMserScore(delta, comparator, false);
/* 179 */     if (this.isScoreValid)
/* 180 */       for (MserEvaluationNode<T> a : children) {
/* 181 */         a.evaluateLocalMinimum(tree, delta, comparator);
/*     */       } 
/* 183 */     if (children.size() == 1) {
/* 184 */       this.mserThisOrChildren = ((MserEvaluationNode)children.get(0)).mserThisOrChildren;
/*     */     } else {
/*     */       
/* 187 */       this.mserThisOrChildren = new ArrayList<>();
/* 188 */       for (MserEvaluationNode<T> a : children) {
/* 189 */         this.mserThisOrChildren.addAll(a.mserThisOrChildren);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private MserEvaluationNode(MserEvaluationNode<T> child, T value, Comparator<T> comparator, ComputeDelta<T> delta) {
/* 195 */     child.setParent(this);
/*     */     
/* 197 */     this.historyChild = child;
/* 198 */     this.size = child.size;
/* 199 */     this.pixelList = child.pixelList;
/* 200 */     this.value = value;
/* 201 */     this.n = child.n;
/* 202 */     this.mean = child.mean;
/* 203 */     this.cov = child.cov;
/*     */     
/* 205 */     this.isScoreValid = computeMserScore(delta, comparator, true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 212 */     this.mserThisOrChildren = child.mserThisOrChildren;
/*     */   }
/*     */ 
/*     */   
/*     */   private void setParent(MserEvaluationNode<T> node) {
/* 217 */     this.parent = node;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean computeMserScore(ComputeDelta<T> delta, Comparator<T> comparator, boolean isIntermediate) {
/* 242 */     Type type = (Type)delta.valueMinusDelta(this.value);
/*     */ 
/*     */     
/* 245 */     MserEvaluationNode<T> node = this.historyChild;
/* 246 */     while (node != null && comparator.compare(node.value, (T)type) > 0)
/* 247 */       node = node.historyChild; 
/* 248 */     if (node == null)
/*     */     {
/* 250 */       return false; } 
/* 251 */     if (isIntermediate && comparator.compare(node.value, (T)type) == 0 && node.historyChild != null)
/* 252 */       node = node.historyChild; 
/* 253 */     this.score = (this.size - node.size) / this.size;
/* 254 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void evaluateLocalMinimum(MserTree<T> tree, ComputeDelta<T> delta, Comparator<T> comparator) {
/* 266 */     if (this.isScoreValid) {
/*     */       
/* 268 */       MserEvaluationNode<T> below = this.historyChild;
/* 269 */       while (below.isScoreValid && below.size == this.size)
/* 270 */         below = below.historyChild; 
/* 271 */       if (below.isScoreValid) {
/*     */         
/* 273 */         below = below.historyChild;
/* 274 */         if (this.score <= below.score && this.score < this.parent.score) {
/* 275 */           tree.foundNewMinimum(this);
/*     */         }
/*     */       } else {
/*     */         
/* 279 */         Type type = (Type)delta.valueMinusDelta(this.value);
/* 280 */         if (comparator.compare((T)type, below.value) > 0)
/*     */         {
/*     */ 
/*     */           
/* 284 */           tree.foundNewMinimum(this);
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 292 */     String s = "SimpleMserEvaluationNode";
/* 293 */     s = s + ", size = " + this.size;
/* 294 */     s = s + ", history = [";
/* 295 */     MserEvaluationNode<T> node = this.historyChild;
/* 296 */     boolean first = true;
/* 297 */     while (node != null) {
/*     */       
/* 299 */       if (first) {
/* 300 */         first = false;
/*     */       } else {
/* 302 */         s = s + ", ";
/* 303 */       }  s = s + "(" + node.value + "; " + node.size;
/* 304 */       if (node.isScoreValid) {
/* 305 */         s = s + " s " + node.score + ")";
/*     */       } else {
/* 307 */         s = s + " s --)";
/* 308 */       }  node = node.historyChild;
/*     */     } 
/* 310 */     s = s + "]";
/* 311 */     return s;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/imglib2-algorithm-0.6.2.jar!/net/imglib2/algorithm/componenttree/mser/MserEvaluationNode.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */