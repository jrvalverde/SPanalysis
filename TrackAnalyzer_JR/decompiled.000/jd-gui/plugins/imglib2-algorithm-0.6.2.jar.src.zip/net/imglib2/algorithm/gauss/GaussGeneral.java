/*     */ package net.imglib2.algorithm.gauss;
/*     */ 
/*     */ import net.imglib2.Dimensions;
/*     */ import net.imglib2.Interval;
/*     */ import net.imglib2.Localizable;
/*     */ import net.imglib2.Point;
/*     */ import net.imglib2.RandomAccessible;
/*     */ import net.imglib2.RandomAccessibleInterval;
/*     */ import net.imglib2.img.Img;
/*     */ import net.imglib2.img.ImgFactory;
/*     */ import net.imglib2.img.list.ListImg;
/*     */ import net.imglib2.img.list.ListImgFactory;
/*     */ import net.imglib2.outofbounds.OutOfBoundsFactory;
/*     */ import net.imglib2.outofbounds.OutOfBoundsMirrorFactory;
/*     */ import net.imglib2.type.numeric.NumericType;
/*     */ import net.imglib2.view.Views;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public class GaussGeneral<T extends NumericType<T>>
/*     */   extends AbstractGauss<T>
/*     */ {
/*     */   public GaussGeneral(double[] sigma, RandomAccessible<T> input, Interval interval, ImgFactory<T> factory, T type) {
/*  79 */     super(sigma, input, interval, (RandomAccessible<T>)factory.create((Dimensions)interval, type), (Localizable)new Point(sigma.length), factory, type);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GaussGeneral(double[] sigma, RandomAccessible<T> input, Interval interval, RandomAccessible<T> output, Localizable outputOffset, ImgFactory<T> factory, T type) {
/* 108 */     super(sigma, input, interval, output, outputOffset, factory, type);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GaussGeneral(double[] sigma, Img<T> input) {
/* 127 */     this(sigma, (RandomAccessible<T>)Views.extend((RandomAccessibleInterval)input, (OutOfBoundsFactory)new OutOfBoundsMirrorFactory(OutOfBoundsMirrorFactory.Boundary.SINGLE)), (Interval)input, input.factory(), (T)((NumericType)input.firstElement()).createVariable());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GaussGeneral(double[] sigma, Img<T> input, OutOfBoundsFactory<T, Img<T>> outOfBounds) {
/* 146 */     this(sigma, (RandomAccessible<T>)Views.extend((RandomAccessibleInterval)input, outOfBounds), (Interval)input, input.factory(), (T)((NumericType)input.firstElement()).createVariable());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Img<T> getProcessingLine(long sizeProcessLine) {
/*     */     Img<T> processLine;
/* 155 */     if (sizeProcessLine <= 2147483647L) {
/*     */       
/* 157 */       ListImg listImg = (new ListImgFactory()).create(new long[] { sizeProcessLine }, getProcessingType());
/*     */     }
/*     */     else {
/*     */       
/* 161 */       System.out.println("Individual dimension size is too large for ListImg, sorry. We need a CellListImg...");
/* 162 */       processLine = null;
/*     */     } 
/*     */     
/* 165 */     return processLine;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/imglib2-algorithm-0.6.2.jar!/net/imglib2/algorithm/gauss/GaussGeneral.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */