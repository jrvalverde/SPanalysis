/*     */ package net.imglib2.algorithm.componenttree.mser;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import net.imglib2.Localizable;
/*     */ import net.imglib2.algorithm.componenttree.Component;
/*     */ import net.imglib2.algorithm.componenttree.pixellist.PixelList;
/*     */ import net.imglib2.type.Type;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Mser<T extends Type<T>>
/*     */   implements Component<T, Mser<T>>
/*     */ {
/*     */   final ArrayList<Mser<T>> children;
/*     */   Mser<T> parent;
/*     */   private final T value;
/*     */   private final PixelList pixelList;
/*     */   private final double score;
/*     */   private final double[] mean;
/*     */   private final double[] cov;
/*     */   
/*     */   Mser(MserEvaluationNode<T> node) {
/*  97 */     this.children = new ArrayList<>();
/*  98 */     this.parent = null;
/*     */     
/* 100 */     this.value = node.value;
/* 101 */     this.score = node.score;
/* 102 */     this.pixelList = node.pixelList;
/* 103 */     this.mean = node.mean;
/* 104 */     this.cov = node.cov;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T value() {
/* 115 */     return this.value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long size() {
/* 126 */     return this.pixelList.size();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double score() {
/* 136 */     return this.score;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double[] mean() {
/* 147 */     return this.mean;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double[] cov() {
/* 159 */     return this.cov;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Iterator<Localizable> iterator() {
/* 171 */     return this.pixelList.iterator();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ArrayList<Mser<T>> getChildren() {
/* 182 */     return this.children;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mser<T> getParent() {
/* 193 */     return this.parent;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/imglib2-algorithm-0.6.2.jar!/net/imglib2/algorithm/componenttree/mser/Mser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */