/*     */ package net.imglib2.algorithm.neighborhood;
/*     */ 
/*     */ import net.imglib2.Interval;
/*     */ import net.imglib2.Localizable;
/*     */ import net.imglib2.RandomAccess;
/*     */ import net.imglib2.RandomAccessible;
/*     */ import net.imglib2.Sampler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PairOfPointsNeighborhoodRandomAccess<T>
/*     */   extends PairOfPointsNeighborhoodLocalizableSampler<T>
/*     */   implements RandomAccess<Neighborhood<T>>
/*     */ {
/*     */   public PairOfPointsNeighborhoodRandomAccess(RandomAccessible<T> source, long[] offset, PairOfPointsNeighborhoodFactory<T> factory, Interval interval) {
/*  45 */     super(source, offset, factory, interval);
/*     */   }
/*     */ 
/*     */   
/*     */   public PairOfPointsNeighborhoodRandomAccess(RandomAccessible<T> source, long[] offset, PairOfPointsNeighborhoodFactory<T> factory) {
/*  50 */     super(source, offset, factory, (Interval)null);
/*     */   }
/*     */ 
/*     */   
/*     */   private PairOfPointsNeighborhoodRandomAccess(PairOfPointsNeighborhoodRandomAccess<T> c) {
/*  55 */     super(c);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void fwd(int d) {
/*  61 */     this.currentPos[d] = this.currentPos[d] + 1L;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void bck(int d) {
/*  67 */     this.currentPos[d] = this.currentPos[d] - 1L;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void move(int distance, int d) {
/*  73 */     this.currentPos[d] = this.currentPos[d] + distance;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void move(long distance, int d) {
/*  79 */     this.currentPos[d] = this.currentPos[d] + distance;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void move(Localizable localizable) {
/*  85 */     for (int d = 0; d < this.n; d++) {
/*     */       
/*  87 */       long distance = localizable.getLongPosition(d);
/*  88 */       this.currentPos[d] = this.currentPos[d] + distance;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void move(int[] distance) {
/*  95 */     for (int d = 0; d < this.n; d++)
/*     */     {
/*  97 */       this.currentPos[d] = this.currentPos[d] + distance[d];
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void move(long[] distance) {
/* 104 */     for (int d = 0; d < this.n; d++)
/*     */     {
/* 106 */       this.currentPos[d] = this.currentPos[d] + distance[d];
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPosition(Localizable localizable) {
/* 113 */     for (int d = 0; d < this.n; d++) {
/*     */       
/* 115 */       long position = localizable.getLongPosition(d);
/* 116 */       this.currentPos[d] = position;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPosition(int[] position) {
/* 123 */     for (int d = 0; d < this.n; d++)
/*     */     {
/* 125 */       this.currentPos[d] = position[d];
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPosition(long[] position) {
/* 132 */     for (int d = 0; d < this.n; d++)
/*     */     {
/* 134 */       this.currentPos[d] = position[d];
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPosition(int position, int d) {
/* 141 */     this.currentPos[d] = position;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPosition(long position, int d) {
/* 147 */     this.currentPos[d] = position;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public PairOfPointsNeighborhoodRandomAccess<T> copy() {
/* 153 */     return new PairOfPointsNeighborhoodRandomAccess(this);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public PairOfPointsNeighborhoodRandomAccess<T> copyRandomAccess() {
/* 159 */     return copy();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/imglib2-algorithm-0.6.2.jar!/net/imglib2/algorithm/neighborhood/PairOfPointsNeighborhoodRandomAccess.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */