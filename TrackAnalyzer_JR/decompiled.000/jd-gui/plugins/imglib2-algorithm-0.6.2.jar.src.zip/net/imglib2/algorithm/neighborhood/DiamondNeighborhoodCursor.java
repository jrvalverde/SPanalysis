/*     */ package net.imglib2.algorithm.neighborhood;
/*     */ 
/*     */ import net.imglib2.Cursor;
/*     */ import net.imglib2.Interval;
/*     */ import net.imglib2.RandomAccessible;
/*     */ import net.imglib2.RandomAccessibleInterval;
/*     */ import net.imglib2.RealCursor;
/*     */ import net.imglib2.Sampler;
/*     */ import net.imglib2.util.IntervalIndexer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DiamondNeighborhoodCursor<T>
/*     */   extends DiamondNeighborhoodLocalizableSampler<T>
/*     */   implements Cursor<Neighborhood<T>>
/*     */ {
/*     */   private final long[] dimensions;
/*     */   private final long maxIndex;
/*     */   private long maxIndexOnLine;
/*     */   private long index;
/*     */   private long[] min;
/*     */   private long[] max;
/*     */   
/*     */   public DiamondNeighborhoodCursor(RandomAccessibleInterval<T> source, long radius, DiamondNeighborhoodFactory<T> factory) {
/*  57 */     super((RandomAccessible<T>)source, radius, factory, (Interval)source);
/*  58 */     this.dimensions = new long[this.n];
/*     */     
/*  60 */     this.min = new long[this.n];
/*  61 */     this.max = new long[this.n];
/*  62 */     source.dimensions(this.dimensions);
/*  63 */     source.min(this.min);
/*  64 */     source.max(this.max);
/*     */     
/*  66 */     long size = this.dimensions[0];
/*  67 */     for (int d = 1; d < this.n; d++)
/*     */     {
/*  69 */       size *= this.dimensions[d];
/*     */     }
/*  71 */     this.maxIndex = size - 1L;
/*  72 */     reset();
/*     */   }
/*     */ 
/*     */   
/*     */   public DiamondNeighborhoodCursor(DiamondNeighborhoodCursor<T> c) {
/*  77 */     super(c);
/*  78 */     this.dimensions = (long[])c.dimensions.clone();
/*  79 */     this.maxIndex = c.maxIndex;
/*  80 */     this.index = c.index;
/*  81 */     this.maxIndexOnLine = c.maxIndexOnLine;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void fwd() {
/*  87 */     this.currentPos[0] = this.currentPos[0] + 1L;
/*  88 */     if (++this.index > this.maxIndexOnLine)
/*     */     {
/*  90 */       nextLine();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private void nextLine() {
/*  96 */     this.currentPos[0] = this.min[0];
/*  97 */     this.maxIndexOnLine += this.dimensions[0];
/*  98 */     for (int d = 1; d < this.n; ) {
/*     */       
/* 100 */       this.currentPos[d] = this.currentPos[d] + 1L;
/* 101 */       if (this.currentPos[d] > this.max[d]) {
/*     */         
/* 103 */         this.currentPos[d] = this.min[d];
/*     */         d++;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void reset() {
/* 115 */     this.index = -1L;
/* 116 */     this.maxIndexOnLine = -1L;
/* 117 */     System.arraycopy(this.max, 0, this.currentPos, 0, this.n);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasNext() {
/* 123 */     return (this.index < this.maxIndex);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void jumpFwd(long steps) {
/* 129 */     this.index += steps;
/* 130 */     if (this.index < 0L) {
/*     */       
/* 132 */       this.maxIndexOnLine = (1L + this.index) / this.dimensions[0] * this.dimensions[0] - 1L;
/* 133 */       long size = this.maxIndex + 1L;
/* 134 */       IntervalIndexer.indexToPositionWithOffset(size - -this.index % size, this.dimensions, this.min, this.currentPos);
/*     */     }
/*     */     else {
/*     */       
/* 138 */       this.maxIndexOnLine = (1L + this.index / this.dimensions[0]) * this.dimensions[0] - 1L;
/* 139 */       IntervalIndexer.indexToPositionWithOffset(this.index, this.dimensions, this.min, this.currentPos);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void remove() {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DiamondNeighborhoodCursor<T> copy() {
/* 152 */     return new DiamondNeighborhoodCursor(this);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Neighborhood<T> next() {
/* 158 */     fwd();
/* 159 */     return get();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public DiamondNeighborhoodCursor<T> copyCursor() {
/* 165 */     return copy();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/imglib2-algorithm-0.6.2.jar!/net/imglib2/algorithm/neighborhood/DiamondNeighborhoodCursor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */