/*     */ package net.imglib2.algorithm.componenttree.pixellist;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import net.imglib2.Localizable;
/*     */ import net.imglib2.Point;
/*     */ import net.imglib2.RandomAccess;
/*     */ import net.imglib2.type.numeric.integer.LongType;
/*     */ import net.imglib2.util.IntervalIndexer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class PixelList
/*     */   implements Iterable<Localizable>
/*     */ {
/*     */   private final RandomAccess<LongType> locationsAccess;
/*     */   private final long[] dimensions;
/*     */   private long headIndex;
/*     */   private final long[] tailPos;
/*     */   private long size;
/*     */   
/*     */   public PixelList(RandomAccess<LongType> locationsAccess, long[] dimensions) {
/*  89 */     this.locationsAccess = locationsAccess;
/*  90 */     this.dimensions = dimensions;
/*  91 */     this.headIndex = 0L;
/*  92 */     this.tailPos = new long[dimensions.length];
/*  93 */     this.size = 0L;
/*     */   }
/*     */ 
/*     */   
/*     */   public PixelList(PixelList l) {
/*  98 */     this.locationsAccess = l.locationsAccess;
/*  99 */     this.dimensions = l.dimensions;
/* 100 */     this.headIndex = l.headIndex;
/* 101 */     this.tailPos = null;
/* 102 */     this.size = l.size;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addPosition(Localizable position) {
/* 110 */     if (this.size == 0L) {
/*     */       
/* 112 */       position.localize(this.tailPos);
/* 113 */       long i = IntervalIndexer.positionToIndex(this.tailPos, this.dimensions);
/* 114 */       this.headIndex = i;
/*     */     }
/*     */     else {
/*     */       
/* 118 */       this.locationsAccess.setPosition(this.tailPos);
/* 119 */       position.localize(this.tailPos);
/* 120 */       long i = IntervalIndexer.positionToIndex(this.tailPos, this.dimensions);
/* 121 */       ((LongType)this.locationsAccess.get()).set(i);
/*     */     } 
/* 123 */     this.size++;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void merge(PixelList l) {
/* 131 */     if (this.size == 0L) {
/*     */       
/* 133 */       this.headIndex = l.headIndex;
/* 134 */       for (int i = 0; i < this.tailPos.length; i++) {
/* 135 */         this.tailPos[i] = l.tailPos[i];
/*     */       }
/*     */     } else {
/*     */       
/* 139 */       this.locationsAccess.setPosition(this.tailPos);
/* 140 */       ((LongType)this.locationsAccess.get()).set(l.headIndex);
/* 141 */       for (int i = 0; i < this.tailPos.length; i++)
/* 142 */         this.tailPos[i] = l.tailPos[i]; 
/*     */     } 
/* 144 */     this.size += l.size;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public class PixelListIterator
/*     */     implements Iterator<Localizable>
/*     */   {
/* 159 */     private long i = 0L;
/* 160 */     private long nextIndex = PixelList.this.headIndex;
/* 161 */     private final long[] tmp = new long[PixelList.this.dimensions.length];
/* 162 */     private final Point pos = new Point(PixelList.this.dimensions.length);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean hasNext() {
/* 168 */       return (this.i < PixelList.this.size);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Localizable next() {
/* 174 */       this.i++;
/* 175 */       IntervalIndexer.indexToPosition(this.nextIndex, PixelList.this.dimensions, this.tmp);
/* 176 */       this.pos.setPosition(this.tmp);
/* 177 */       PixelList.this.locationsAccess.setPosition(this.tmp);
/* 178 */       this.nextIndex = ((LongType)PixelList.this.locationsAccess.get()).get();
/* 179 */       return (Localizable)this.pos;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void remove() {}
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Iterator<Localizable> iterator() {
/* 190 */     return new PixelListIterator();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long size() {
/* 200 */     return this.size;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void clear() {
/* 208 */     this.size = 0L;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/imglib2-algorithm-0.6.2.jar!/net/imglib2/algorithm/componenttree/pixellist/PixelList.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */