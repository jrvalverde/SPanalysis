package net.imglib2.algorithm.gauss3;

import net.imglib2.RandomAccess;

public interface ConvolverFactory<S, T> {
  Runnable create(double[] paramArrayOfdouble, RandomAccess<S> paramRandomAccess, RandomAccess<T> paramRandomAccess1, int paramInt, long paramLong);
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/imglib2-algorithm-0.6.2.jar!/net/imglib2/algorithm/gauss3/ConvolverFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */