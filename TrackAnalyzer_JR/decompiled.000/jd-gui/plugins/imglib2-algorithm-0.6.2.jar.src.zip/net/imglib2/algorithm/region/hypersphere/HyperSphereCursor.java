/*     */ package net.imglib2.algorithm.region.hypersphere;
/*     */ 
/*     */ import net.imglib2.Cursor;
/*     */ import net.imglib2.Localizable;
/*     */ import net.imglib2.RandomAccess;
/*     */ import net.imglib2.RandomAccessible;
/*     */ import net.imglib2.RealCursor;
/*     */ import net.imglib2.Sampler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HyperSphereCursor<T>
/*     */   implements Cursor<T>
/*     */ {
/*     */   final RandomAccessible<T> source;
/*     */   protected final long[] center;
/*     */   protected final RandomAccess<T> randomAccess;
/*     */   protected final long radius;
/*     */   final int numDimensions;
/*     */   final int maxDim;
/*     */   final double[] r;
/*     */   final long[] ri;
/*     */   final long[] s;
/*     */   
/*     */   public HyperSphereCursor(RandomAccessible<T> source, long[] center, long radius) {
/*  76 */     this.source = source;
/*  77 */     this.center = (long[])center.clone();
/*  78 */     this.radius = radius;
/*  79 */     this.numDimensions = source.numDimensions();
/*  80 */     this.maxDim = this.numDimensions - 1;
/*  81 */     this.r = new double[this.numDimensions];
/*  82 */     this.ri = new long[this.numDimensions];
/*  83 */     this.s = new long[this.numDimensions];
/*  84 */     this.randomAccess = source.randomAccess();
/*     */     
/*  86 */     reset();
/*     */   }
/*     */ 
/*     */   
/*     */   public HyperSphereCursor(HyperSphereCursor<T> cursor) {
/*  91 */     this.source = cursor.source;
/*  92 */     this.center = (long[])cursor.center.clone();
/*  93 */     this.radius = cursor.radius;
/*  94 */     this.numDimensions = cursor.numDimensions();
/*  95 */     this.maxDim = cursor.maxDim;
/*     */     
/*  97 */     this.r = (double[])cursor.r.clone();
/*  98 */     this.ri = (long[])cursor.ri.clone();
/*  99 */     this.s = (long[])cursor.s.clone();
/*     */     
/* 101 */     this.randomAccess = this.source.randomAccess();
/* 102 */     this.randomAccess.setPosition((Localizable)cursor.randomAccess);
/*     */   }
/*     */ 
/*     */   
/*     */   public void updateCenter(long[] center) {
/* 107 */     for (int d = 0; d < this.numDimensions; d++) {
/* 108 */       this.center[d] = center[d];
/*     */     }
/* 110 */     reset();
/*     */   }
/*     */ 
/*     */   
/*     */   public void updateCenter(Localizable center) {
/* 115 */     for (int d = 0; d < this.numDimensions; d++) {
/* 116 */       this.center[d] = center.getLongPosition(d);
/*     */     }
/* 118 */     reset();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasNext() {
/* 124 */     return (this.s[this.maxDim] > 0L);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void fwd() {
/* 130 */     this.s[0] = this.s[0] - 1L; if (this.s[0] - 1L >= 0L) {
/* 131 */       this.randomAccess.fwd(0);
/*     */     } else {
/*     */       
/* 134 */       int d = 1;
/* 135 */       for (; d < this.numDimensions; d++) {
/*     */         
/* 137 */         this.s[d] = this.s[d] - 1L; if (this.s[d] - 1L >= 0L) {
/*     */           
/* 139 */           this.randomAccess.fwd(d);
/*     */           
/*     */           break;
/*     */         } 
/*     */       } 
/* 144 */       for (; d > 0; d--) {
/*     */         
/* 146 */         int e = d - 1;
/* 147 */         double rd = this.r[d];
/* 148 */         long pd = this.s[d] - this.ri[d];
/*     */         
/* 150 */         double rad = Math.sqrt(rd * rd - (pd * pd));
/* 151 */         this.r[e] = rad;
/* 152 */         this.ri[e] = (long)rad;
/* 153 */         this.s[e] = 2L * (long)rad;
/*     */         
/* 155 */         this.randomAccess.setPosition(this.center[e] - this.ri[e], e);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void reset() {
/* 163 */     for (int d = 0; d < this.maxDim; d++) {
/*     */       
/* 165 */       this.s[d] = 0L; this.ri[d] = 0L; this.r[d] = 0L;
/* 166 */       this.randomAccess.setPosition(this.center[d], d);
/*     */     } 
/*     */     
/* 169 */     this.randomAccess.setPosition(this.center[this.maxDim] - this.radius - 1L, this.maxDim);
/*     */     
/* 171 */     this.r[this.maxDim] = this.radius;
/* 172 */     this.ri[this.maxDim] = this.radius;
/* 173 */     this.s[this.maxDim] = 1L + 2L * this.radius;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void jumpFwd(long steps) {
/* 179 */     for (long j = 0L; j < steps; j++) {
/* 180 */       fwd();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void localize(float[] position) {
/* 186 */     this.randomAccess.localize(position);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void localize(double[] position) {
/* 192 */     this.randomAccess.localize(position);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public float getFloatPosition(int d) {
/* 198 */     return this.randomAccess.getFloatPosition(d);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public double getDoublePosition(int d) {
/* 204 */     return this.randomAccess.getDoublePosition(d);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int numDimensions() {
/* 210 */     return this.numDimensions;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public T get() {
/* 216 */     return (T)this.randomAccess.get();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public T next() {
/* 222 */     fwd();
/* 223 */     return get();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void remove() {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void localize(int[] position) {
/* 233 */     this.randomAccess.localize(position);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void localize(long[] position) {
/* 239 */     this.randomAccess.localize(position);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getIntPosition(int d) {
/* 245 */     return this.randomAccess.getIntPosition(d);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public long getLongPosition(int d) {
/* 251 */     return this.randomAccess.getLongPosition(d);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public HyperSphereCursor<T> copyCursor() {
/* 257 */     return new HyperSphereCursor(this);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public HyperSphereCursor<T> copy() {
/* 263 */     return copyCursor();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/imglib2-algorithm-0.6.2.jar!/net/imglib2/algorithm/region/hypersphere/HyperSphereCursor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */