/*     */ package net.imglib2.algorithm.neighborhood;
/*     */ 
/*     */ import net.imglib2.AbstractEuclideanSpace;
/*     */ import net.imglib2.FinalInterval;
/*     */ import net.imglib2.Interval;
/*     */ import net.imglib2.Localizable;
/*     */ import net.imglib2.RandomAccessible;
/*     */ import net.imglib2.Sampler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class PairOfPointsNeighborhoodLocalizableSampler<T>
/*     */   extends AbstractEuclideanSpace
/*     */   implements Localizable, Sampler<Neighborhood<T>>
/*     */ {
/*     */   protected final RandomAccessible<T> source;
/*     */   protected final Interval sourceInterval;
/*     */   protected final long[] offset;
/*     */   protected final long[] currentPos;
/*     */   protected final PairOfPointsNeighborhoodFactory<T> neighborhoodFactory;
/*     */   protected final Neighborhood<T> currentNeighborhood;
/*     */   
/*     */   public PairOfPointsNeighborhoodLocalizableSampler(RandomAccessible<T> source, long[] offset, PairOfPointsNeighborhoodFactory<T> factory, Interval accessInterval) {
/*  59 */     super(source.numDimensions());
/*  60 */     this.source = source;
/*  61 */     this.offset = offset;
/*  62 */     this.currentPos = new long[this.n];
/*  63 */     this.neighborhoodFactory = factory;
/*     */     
/*  65 */     if (accessInterval == null) {
/*     */       
/*  67 */       this.sourceInterval = null;
/*     */     }
/*     */     else {
/*     */       
/*  71 */       long[] accessMin = new long[this.n];
/*  72 */       long[] accessMax = new long[this.n];
/*  73 */       accessInterval.min(accessMin);
/*  74 */       accessInterval.max(accessMax);
/*  75 */       for (int d = 0; d < this.n; d++) {
/*     */         
/*  77 */         accessMin[d] = Math.min(this.currentPos[d], this.currentPos[d] + offset[d]);
/*  78 */         accessMax[d] = Math.max(this.currentPos[d], this.currentPos[d] + offset[d]);
/*     */       } 
/*  80 */       this.sourceInterval = (Interval)new FinalInterval(accessMin, accessMax);
/*     */     } 
/*     */     
/*  83 */     this.currentNeighborhood = this.neighborhoodFactory.create(this.currentPos, offset, (this.sourceInterval == null) ? source.randomAccess() : source.randomAccess(this.sourceInterval));
/*     */   }
/*     */ 
/*     */   
/*     */   protected PairOfPointsNeighborhoodLocalizableSampler(PairOfPointsNeighborhoodLocalizableSampler<T> c) {
/*  88 */     super(c.n);
/*  89 */     this.source = c.source;
/*  90 */     this.sourceInterval = c.sourceInterval;
/*  91 */     this.offset = (long[])c.offset.clone();
/*  92 */     this.neighborhoodFactory = c.neighborhoodFactory;
/*  93 */     this.currentPos = (long[])c.currentPos.clone();
/*  94 */     this.currentNeighborhood = this.neighborhoodFactory.create(this.currentPos, this.offset, this.source.randomAccess());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Neighborhood<T> get() {
/* 100 */     return this.currentNeighborhood;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void localize(int[] position) {
/* 106 */     this.currentNeighborhood.localize(position);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void localize(long[] position) {
/* 112 */     this.currentNeighborhood.localize(position);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getIntPosition(int d) {
/* 118 */     return this.currentNeighborhood.getIntPosition(d);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public long getLongPosition(int d) {
/* 124 */     return this.currentNeighborhood.getLongPosition(d);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void localize(float[] position) {
/* 130 */     this.currentNeighborhood.localize(position);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void localize(double[] position) {
/* 136 */     this.currentNeighborhood.localize(position);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public float getFloatPosition(int d) {
/* 142 */     return this.currentNeighborhood.getFloatPosition(d);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public double getDoublePosition(int d) {
/* 148 */     return this.currentNeighborhood.getDoublePosition(d);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/imglib2-algorithm-0.6.2.jar!/net/imglib2/algorithm/neighborhood/PairOfPointsNeighborhoodLocalizableSampler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */