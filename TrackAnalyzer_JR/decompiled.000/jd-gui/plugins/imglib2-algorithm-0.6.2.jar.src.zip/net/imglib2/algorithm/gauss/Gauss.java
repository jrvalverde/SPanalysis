/*     */ package net.imglib2.algorithm.gauss;
/*     */ 
/*     */ import net.imglib2.Dimensions;
/*     */ import net.imglib2.EuclideanSpace;
/*     */ import net.imglib2.Interval;
/*     */ import net.imglib2.Localizable;
/*     */ import net.imglib2.Point;
/*     */ import net.imglib2.RandomAccess;
/*     */ import net.imglib2.RandomAccessible;
/*     */ import net.imglib2.RandomAccessibleInterval;
/*     */ import net.imglib2.converter.readwrite.RealDoubleSamplerConverter;
/*     */ import net.imglib2.converter.readwrite.RealFloatSamplerConverter;
/*     */ import net.imglib2.converter.readwrite.SamplerConverter;
/*     */ import net.imglib2.converter.readwrite.WriteConvertedIterableRandomAccessibleInterval;
/*     */ import net.imglib2.converter.readwrite.WriteConvertedRandomAccessible;
/*     */ import net.imglib2.converter.readwrite.WriteConvertedRandomAccessibleInterval;
/*     */ import net.imglib2.exception.IncompatibleTypeException;
/*     */ import net.imglib2.img.Img;
/*     */ import net.imglib2.img.ImgFactory;
/*     */ import net.imglib2.outofbounds.OutOfBoundsFactory;
/*     */ import net.imglib2.outofbounds.OutOfBoundsMirrorFactory;
/*     */ import net.imglib2.type.NativeType;
/*     */ import net.imglib2.type.Type;
/*     */ import net.imglib2.type.numeric.RealType;
/*     */ import net.imglib2.type.numeric.real.DoubleType;
/*     */ import net.imglib2.type.numeric.real.FloatType;
/*     */ import net.imglib2.view.ExtendedRandomAccessibleInterval;
/*     */ import net.imglib2.view.Views;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public class Gauss
/*     */ {
/*     */   public static <T extends RealType<T>> Img<FloatType> toFloat(double sigma, Img<T> img) {
/*  83 */     return toFloat(getSigmaDim(sigma, (EuclideanSpace)img), img);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends RealType<T>> Img<FloatType> toFloat(double[] sigma, Img<T> img) {
/*  99 */     return toFloat(sigma, img, (OutOfBoundsFactory<FloatType, RandomAccessibleInterval<FloatType>>)new OutOfBoundsMirrorFactory(OutOfBoundsMirrorFactory.Boundary.SINGLE));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends RealType<T>> Img<FloatType> toFloat(double sigma, Img<T> img, OutOfBoundsFactory<FloatType, RandomAccessibleInterval<FloatType>> outofbounds) {
/* 117 */     return toFloat(getSigmaDim(sigma, (EuclideanSpace)img), img, outofbounds);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends RealType<T>> Img<FloatType> toFloat(double[] sigma, Img<T> img, OutOfBoundsFactory<FloatType, RandomAccessibleInterval<FloatType>> outofbounds) {
/* 135 */     GaussFloat gauss = null;
/*     */     
/*     */     try {
/* 138 */       if (FloatType.class.isInstance(img.firstElement()))
/*     */       {
/*     */         
/* 141 */         Img<FloatType> img2 = (Img)img;
/* 142 */         gauss = new GaussFloat(sigma, img2);
/*     */       }
/*     */       else
/*     */       {
/* 146 */         WriteConvertedIterableRandomAccessibleInterval writeConvertedIterableRandomAccessibleInterval = new WriteConvertedIterableRandomAccessibleInterval((RandomAccessible)img, (SamplerConverter)new RealFloatSamplerConverter());
/* 147 */         gauss = new GaussFloat(sigma, (RandomAccessible<FloatType>)Views.extend((RandomAccessibleInterval)writeConvertedIterableRandomAccessibleInterval, outofbounds), (Interval)img, img.factory().imgFactory(new FloatType()));
/*     */       }
/*     */     
/* 150 */     } catch (IncompatibleTypeException e) {
/*     */       
/* 152 */       return null;
/*     */     } 
/*     */     
/* 155 */     gauss.call();
/*     */     
/* 157 */     return (Img<FloatType>)gauss.getResult();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends RealType<T>> Img<T> inFloat(double sigma, Img<T> img) {
/* 173 */     return inFloat(getSigmaDim(sigma, (EuclideanSpace)img), img);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends RealType<T>> Img<T> inFloat(double[] sigma, Img<T> img) {
/* 189 */     return inFloat(sigma, img, (OutOfBoundsFactory<FloatType, RandomAccessibleInterval<FloatType>>)new OutOfBoundsMirrorFactory(OutOfBoundsMirrorFactory.Boundary.SINGLE));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends RealType<T>> Img<T> inFloat(double sigma, Img<T> img, OutOfBoundsFactory<FloatType, RandomAccessibleInterval<FloatType>> outofbounds) {
/* 207 */     return inFloat(getSigmaDim(sigma, (EuclideanSpace)img), img, outofbounds);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends RealType<T>> Img<T> inFloat(double[] sigma, Img<T> img, OutOfBoundsFactory<FloatType, RandomAccessibleInterval<FloatType>> outofbounds) {
/*     */     try {
/* 228 */       if (FloatType.class.isInstance(img.firstElement())) return (Img)toFloat(sigma, img, outofbounds); 
/* 229 */       Img<T> output = img.factory().create((Dimensions)img, img.firstElement());
/*     */       
/* 231 */       ExtendedRandomAccessibleInterval extendedRandomAccessibleInterval = Views.extend((RandomAccessibleInterval)new WriteConvertedRandomAccessibleInterval((RandomAccessibleInterval)img, (SamplerConverter)new RealFloatSamplerConverter()), outofbounds);
/* 232 */       WriteConvertedRandomAccessible writeConvertedRandomAccessible = new WriteConvertedRandomAccessible((RandomAccessible)output, (SamplerConverter)new RealFloatSamplerConverter());
/*     */       
/* 234 */       inFloat(sigma, (RandomAccessible<RealType>)extendedRandomAccessibleInterval, (Interval)img, (RandomAccessible<RealType>)writeConvertedRandomAccessible, (Localizable)new Point(sigma.length), img.factory().imgFactory(new FloatType()));
/*     */       
/* 236 */       return output;
/*     */     }
/* 238 */     catch (IncompatibleTypeException e) {
/*     */       
/* 240 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends RealType<T>> void inFloatInPlace(double sigma, Img<T> img) {
/* 256 */     inFloatInPlace(getSigmaDim(sigma, (EuclideanSpace)img), img);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends RealType<T>> void inFloatInPlace(double[] sigma, Img<T> img) {
/* 271 */     inFloatInPlace(sigma, img, (OutOfBoundsFactory<FloatType, RandomAccessibleInterval<FloatType>>)new OutOfBoundsMirrorFactory(OutOfBoundsMirrorFactory.Boundary.SINGLE));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends RealType<T>> void inFloatInPlace(double sigma, Img<T> img, OutOfBoundsFactory<FloatType, RandomAccessibleInterval<FloatType>> outofbounds) {
/* 286 */     inFloatInPlace(getSigmaDim(sigma, (EuclideanSpace)img), img, outofbounds);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends RealType<T>> void inFloatInPlace(double[] sigma, Img<T> img, OutOfBoundsFactory<FloatType, RandomAccessibleInterval<FloatType>> outofbounds) {
/* 301 */     GaussFloat gauss = null;
/*     */     
/*     */     try {
/* 304 */       if (FloatType.class.isInstance(img.firstElement()))
/*     */       {
/*     */         
/* 307 */         Img<FloatType> img2 = (Img)img;
/* 308 */         gauss = new GaussFloat(sigma, (RandomAccessible<FloatType>)Views.extend((RandomAccessibleInterval)img2, outofbounds), (Interval)img2, (RandomAccessible<FloatType>)img2, (Localizable)new Point(sigma.length), img2.factory().imgFactory(new FloatType()));
/*     */       }
/*     */       else
/*     */       {
/* 312 */         WriteConvertedIterableRandomAccessibleInterval writeConvertedIterableRandomAccessibleInterval = new WriteConvertedIterableRandomAccessibleInterval((RandomAccessible)img, (SamplerConverter)new RealFloatSamplerConverter());
/* 313 */         gauss = new GaussFloat(sigma, (RandomAccessible<FloatType>)Views.extend((RandomAccessibleInterval)writeConvertedIterableRandomAccessibleInterval, outofbounds), (Interval)img, (RandomAccessible<FloatType>)writeConvertedIterableRandomAccessibleInterval, (Localizable)new Point(sigma.length), img.factory().imgFactory(new FloatType()));
/*     */       }
/*     */     
/* 316 */     } catch (IncompatibleTypeException e) {
/*     */       
/* 318 */       System.out.println(e);
/*     */       
/*     */       return;
/*     */     } 
/* 322 */     gauss.call();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends RealType<T>> void inFloat(double sigma, RandomAccessible<T> img, Interval interval, RandomAccessible<T> output, Localizable origin, ImgFactory<FloatType> imgFactory) {
/* 348 */     inFloat(getSigmaDim(sigma, (EuclideanSpace)img), img, interval, output, origin, imgFactory);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends RealType<T>> void inFloat(double[] sigma, RandomAccessible<T> img, Interval interval, RandomAccessible<T> output, Localizable origin, ImgFactory<FloatType> imgFactory) {
/* 377 */     long[] tmpCoordinate = new long[img.numDimensions()];
/* 378 */     interval.min(tmpCoordinate);
/* 379 */     RandomAccess<T> tmp = img.randomAccess();
/* 380 */     tmp.setPosition(tmpCoordinate);
/*     */     
/* 382 */     if (FloatType.class.isInstance(tmp.get())) {
/*     */ 
/*     */       
/* 385 */       RandomAccessible<FloatType> rIn = (RandomAccessible)img;
/*     */       
/* 387 */       RandomAccessible<FloatType> rOut = (RandomAccessible)output;
/*     */       
/* 389 */       (new GaussFloat(sigma, rIn, interval, rOut, origin, imgFactory)).call();
/*     */     }
/*     */     else {
/*     */       
/* 393 */       WriteConvertedRandomAccessible writeConvertedRandomAccessible1 = new WriteConvertedRandomAccessible(img, (SamplerConverter)new RealFloatSamplerConverter());
/* 394 */       WriteConvertedRandomAccessible writeConvertedRandomAccessible2 = new WriteConvertedRandomAccessible(output, (SamplerConverter)new RealFloatSamplerConverter());
/*     */       
/* 396 */       (new GaussFloat(sigma, (RandomAccessible<FloatType>)writeConvertedRandomAccessible1, interval, (RandomAccessible<FloatType>)writeConvertedRandomAccessible2, origin, imgFactory)).call();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends RealType<T>> Img<DoubleType> toDouble(double sigma, Img<T> img) {
/* 413 */     return toDouble(getSigmaDim(sigma, (EuclideanSpace)img), img);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends RealType<T>> Img<DoubleType> toDouble(double[] sigma, Img<T> img) {
/* 429 */     return toDouble(sigma, img, (OutOfBoundsFactory<DoubleType, RandomAccessibleInterval<DoubleType>>)new OutOfBoundsMirrorFactory(OutOfBoundsMirrorFactory.Boundary.SINGLE));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends RealType<T>> Img<DoubleType> toDouble(double sigma, Img<T> img, OutOfBoundsFactory<DoubleType, RandomAccessibleInterval<DoubleType>> outofbounds) {
/* 447 */     return toDouble(getSigmaDim(sigma, (EuclideanSpace)img), img, outofbounds);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends RealType<T>> Img<DoubleType> toDouble(double[] sigma, Img<T> img, OutOfBoundsFactory<DoubleType, RandomAccessibleInterval<DoubleType>> outofbounds) {
/* 465 */     GaussDouble gauss = null;
/*     */     
/*     */     try {
/* 468 */       if (DoubleType.class.isInstance(img.firstElement()))
/*     */       {
/*     */         
/* 471 */         Img<DoubleType> img2 = (Img)img;
/* 472 */         gauss = new GaussDouble(sigma, img2);
/*     */       }
/*     */       else
/*     */       {
/* 476 */         WriteConvertedIterableRandomAccessibleInterval writeConvertedIterableRandomAccessibleInterval = new WriteConvertedIterableRandomAccessibleInterval((RandomAccessible)img, (SamplerConverter)new RealDoubleSamplerConverter());
/* 477 */         gauss = new GaussDouble(sigma, (RandomAccessible<DoubleType>)Views.extend((RandomAccessibleInterval)writeConvertedIterableRandomAccessibleInterval, outofbounds), (Interval)img, img.factory().imgFactory(new DoubleType()));
/*     */       }
/*     */     
/* 480 */     } catch (IncompatibleTypeException e) {
/*     */       
/* 482 */       return null;
/*     */     } 
/*     */     
/* 485 */     gauss.call();
/*     */     
/* 487 */     return (Img<DoubleType>)gauss.getResult();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends RealType<T>> Img<T> inDouble(double sigma, Img<T> img) {
/* 503 */     return inDouble(getSigmaDim(sigma, (EuclideanSpace)img), img);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends RealType<T>> Img<T> inDouble(double[] sigma, Img<T> img) {
/* 519 */     return inDouble(sigma, img, (OutOfBoundsFactory<DoubleType, RandomAccessibleInterval<DoubleType>>)new OutOfBoundsMirrorFactory(OutOfBoundsMirrorFactory.Boundary.SINGLE));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends RealType<T>> Img<T> inDouble(double sigma, Img<T> img, OutOfBoundsFactory<DoubleType, RandomAccessibleInterval<DoubleType>> outofbounds) {
/* 537 */     return inDouble(getSigmaDim(sigma, (EuclideanSpace)img), img, outofbounds);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends RealType<T>> Img<T> inDouble(double[] sigma, Img<T> img, OutOfBoundsFactory<DoubleType, RandomAccessibleInterval<DoubleType>> outofbounds) {
/*     */     try {
/* 558 */       if (DoubleType.class.isInstance(img.firstElement())) return (Img)toDouble(sigma, img, outofbounds); 
/* 559 */       Img<T> output = img.factory().create((Dimensions)img, img.firstElement());
/*     */       
/* 561 */       ExtendedRandomAccessibleInterval extendedRandomAccessibleInterval = Views.extend((RandomAccessibleInterval)new WriteConvertedRandomAccessibleInterval((RandomAccessibleInterval)img, (SamplerConverter)new RealDoubleSamplerConverter()), outofbounds);
/* 562 */       WriteConvertedRandomAccessible writeConvertedRandomAccessible = new WriteConvertedRandomAccessible((RandomAccessible)output, (SamplerConverter)new RealDoubleSamplerConverter());
/*     */       
/* 564 */       inDouble(sigma, (RandomAccessible<RealType>)extendedRandomAccessibleInterval, (Interval)img, (RandomAccessible<RealType>)writeConvertedRandomAccessible, (Localizable)new Point(sigma.length), img.factory().imgFactory(new DoubleType()));
/*     */       
/* 566 */       return output;
/*     */     }
/* 568 */     catch (IncompatibleTypeException e) {
/*     */       
/* 570 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends RealType<T>> void inDoubleInPlace(double sigma, Img<T> img) {
/* 586 */     inDoubleInPlace(getSigmaDim(sigma, (EuclideanSpace)img), img);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends RealType<T>> void inDoubleInPlace(double[] sigma, Img<T> img) {
/* 601 */     inDoubleInPlace(sigma, img, (OutOfBoundsFactory<DoubleType, RandomAccessibleInterval<DoubleType>>)new OutOfBoundsMirrorFactory(OutOfBoundsMirrorFactory.Boundary.SINGLE));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends RealType<T>> void inDoubleInPlace(double sigma, Img<T> img, OutOfBoundsFactory<DoubleType, RandomAccessibleInterval<DoubleType>> outofbounds) {
/* 616 */     inDoubleInPlace(getSigmaDim(sigma, (EuclideanSpace)img), img, outofbounds);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends RealType<T>> void inDoubleInPlace(double[] sigma, Img<T> img, OutOfBoundsFactory<DoubleType, RandomAccessibleInterval<DoubleType>> outofbounds) {
/* 631 */     GaussDouble gauss = null;
/*     */     
/*     */     try {
/* 634 */       if (DoubleType.class.isInstance(img.firstElement()))
/*     */       {
/*     */         
/* 637 */         Img<DoubleType> img2 = (Img)img;
/* 638 */         gauss = new GaussDouble(sigma, (RandomAccessible<DoubleType>)Views.extend((RandomAccessibleInterval)img2, outofbounds), (Interval)img2, (RandomAccessible<DoubleType>)img2, (Localizable)new Point(sigma.length), img2.factory().imgFactory(new DoubleType()));
/*     */       }
/*     */       else
/*     */       {
/* 642 */         WriteConvertedIterableRandomAccessibleInterval writeConvertedIterableRandomAccessibleInterval = new WriteConvertedIterableRandomAccessibleInterval((RandomAccessible)img, (SamplerConverter)new RealDoubleSamplerConverter());
/* 643 */         gauss = new GaussDouble(sigma, (RandomAccessible<DoubleType>)Views.extend((RandomAccessibleInterval)writeConvertedIterableRandomAccessibleInterval, outofbounds), (Interval)img, (RandomAccessible<DoubleType>)writeConvertedIterableRandomAccessibleInterval, (Localizable)new Point(sigma.length), img.factory().imgFactory(new DoubleType()));
/*     */       }
/*     */     
/* 646 */     } catch (IncompatibleTypeException e) {
/*     */       return;
/*     */     } 
/*     */ 
/*     */     
/* 651 */     gauss.call();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends RealType<T>> void inDouble(double sigma, RandomAccessible<T> img, Interval interval, RandomAccessible<T> output, Localizable origin, ImgFactory<DoubleType> imgFactory) {
/* 677 */     inDouble(getSigmaDim(sigma, (EuclideanSpace)img), img, interval, output, origin, imgFactory);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends RealType<T>> void inDouble(double[] sigma, RandomAccessible<T> img, Interval interval, RandomAccessible<T> output, Localizable origin, ImgFactory<DoubleType> imgFactory) {
/* 706 */     long[] tmpCoordinate = new long[img.numDimensions()];
/* 707 */     interval.min(tmpCoordinate);
/* 708 */     RandomAccess<T> tmp = img.randomAccess();
/* 709 */     tmp.setPosition(tmpCoordinate);
/*     */     
/* 711 */     if (DoubleType.class.isInstance(tmp.get())) {
/*     */ 
/*     */       
/* 714 */       RandomAccessible<DoubleType> rIn = (RandomAccessible)img;
/*     */       
/* 716 */       RandomAccessible<DoubleType> rOut = (RandomAccessible)output;
/*     */       
/* 718 */       (new GaussDouble(sigma, rIn, interval, rOut, origin, imgFactory)).call();
/*     */     }
/*     */     else {
/*     */       
/* 722 */       WriteConvertedRandomAccessible writeConvertedRandomAccessible1 = new WriteConvertedRandomAccessible(img, (SamplerConverter)new RealDoubleSamplerConverter());
/* 723 */       WriteConvertedRandomAccessible writeConvertedRandomAccessible2 = new WriteConvertedRandomAccessible(output, (SamplerConverter)new RealDoubleSamplerConverter());
/*     */       
/* 725 */       (new GaussDouble(sigma, (RandomAccessible<DoubleType>)writeConvertedRandomAccessible1, interval, (RandomAccessible<DoubleType>)writeConvertedRandomAccessible2, origin, imgFactory)).call();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends net.imglib2.type.numeric.NumericType<T>> Img<T> inNumericType(double sigma, Img<T> img) {
/* 742 */     return inNumericType(getSigmaDim(sigma, (EuclideanSpace)img), img);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends net.imglib2.type.numeric.NumericType<T>> Img<T> inNumericType(double[] sigma, Img<T> img) {
/* 758 */     return inNumericType(sigma, img, (OutOfBoundsFactory<T, RandomAccessibleInterval<T>>)new OutOfBoundsMirrorFactory(OutOfBoundsMirrorFactory.Boundary.SINGLE));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends net.imglib2.type.numeric.NumericType<T>> Img<T> inNumericType(double sigma, Img<T> img, OutOfBoundsFactory<T, RandomAccessibleInterval<T>> outofbounds) {
/* 776 */     return inNumericType(getSigmaDim(sigma, (EuclideanSpace)img), img, outofbounds);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends net.imglib2.type.numeric.NumericType<T>> Img<T> inNumericType(double[] sigma, Img<T> img, OutOfBoundsFactory<T, RandomAccessibleInterval<T>> outofbounds) {
/* 794 */     Img<T> output = img.factory().create((Dimensions)img, img.firstElement());
/* 795 */     inNumericType(sigma, (RandomAccessible<T>)Views.extend((RandomAccessibleInterval)img, outofbounds), (Interval)img, (RandomAccessible<T>)output, (Localizable)new Point(sigma.length), img.factory());
/* 796 */     return output;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends net.imglib2.type.numeric.NumericType<T>> void inNumericTypeInPlace(double sigma, Img<T> img) {
/* 811 */     inNumericTypeInPlace(getSigmaDim(sigma, (EuclideanSpace)img), img);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends net.imglib2.type.numeric.NumericType<T>> void inNumericTypeInPlace(double[] sigma, Img<T> img) {
/* 826 */     inNumericTypeInPlace(sigma, img, (OutOfBoundsFactory<T, RandomAccessibleInterval<T>>)new OutOfBoundsMirrorFactory(OutOfBoundsMirrorFactory.Boundary.SINGLE));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends net.imglib2.type.numeric.NumericType<T>> void inNumericTypeInPlace(double sigma, Img<T> img, OutOfBoundsFactory<T, RandomAccessibleInterval<T>> outofbounds) {
/* 841 */     inNumericTypeInPlace(getSigmaDim(sigma, (EuclideanSpace)img), img, outofbounds);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends net.imglib2.type.numeric.NumericType<T>> void inNumericTypeInPlace(double[] sigma, Img<T> img, OutOfBoundsFactory<T, RandomAccessibleInterval<T>> outofbounds) {
/* 856 */     inNumericType(sigma, (RandomAccessible<T>)Views.extend((RandomAccessibleInterval)img, outofbounds), (Interval)img, (RandomAccessible<T>)img, (Localizable)new Point(sigma.length), img.factory());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends net.imglib2.type.numeric.NumericType<T>> void inNumericType(double sigma, RandomAccessible<T> img, Interval interval, RandomAccessible<T> output, Localizable origin, ImgFactory<T> imgFactory) {
/* 882 */     inNumericType(getSigmaDim(sigma, (EuclideanSpace)img), img, interval, output, origin, imgFactory);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends net.imglib2.type.numeric.NumericType<T>> void inNumericType(double[] sigma, RandomAccessible<T> img, Interval interval, RandomAccessible<T> output, Localizable origin, ImgFactory<T> imgFactory) {
/* 913 */     long[] tmpCoordinate = new long[img.numDimensions()];
/* 914 */     interval.min(tmpCoordinate);
/* 915 */     RandomAccess<T> tmp = img.randomAccess();
/* 916 */     tmp.setPosition(tmpCoordinate);
/*     */     
/* 918 */     if (NativeType.class.isInstance(tmp.get())) {
/*     */ 
/*     */ 
/*     */       
/* 922 */       computeInNativeType(sigma, img, interval, output, origin, imgFactory, (Type)tmp.get());
/*     */     }
/*     */     else {
/*     */       
/* 926 */       GaussGeneral<T> gauss = new GaussGeneral<>(sigma, img, interval, output, origin, imgFactory, (T)tmp.get());
/* 927 */       gauss.call();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final <T extends net.imglib2.type.numeric.NumericType<T> & NativeType<T>> void computeInNativeType(double[] sigma, RandomAccessible<T> img, Interval interval, RandomAccessible<T> output, Localizable origin, ImgFactory<T> imgFactory, Type type) {
/* 935 */     GaussNativeType<T> gauss = new GaussNativeType<>(sigma, img, interval, output, origin, imgFactory, (T)type);
/* 936 */     gauss.call();
/*     */   }
/*     */ 
/*     */   
/*     */   private static final double[] getSigmaDim(double sigma, EuclideanSpace img) {
/* 941 */     double[] s = new double[img.numDimensions()];
/*     */     
/* 943 */     for (int d = 0; d < img.numDimensions(); d++) {
/* 944 */       s[d] = sigma;
/*     */     }
/* 946 */     return s;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/imglib2-algorithm-0.6.2.jar!/net/imglib2/algorithm/gauss/Gauss.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */