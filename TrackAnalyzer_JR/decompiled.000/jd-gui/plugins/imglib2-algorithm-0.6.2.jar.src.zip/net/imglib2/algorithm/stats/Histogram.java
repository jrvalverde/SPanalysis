/*     */ package net.imglib2.algorithm.stats;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import net.imglib2.RealCursor;
/*     */ import net.imglib2.algorithm.Algorithm;
/*     */ import net.imglib2.algorithm.Benchmark;
/*     */ import net.imglib2.img.Img;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Histogram<T>
/*     */   implements Algorithm, Benchmark
/*     */ {
/*  57 */   private long pTime = 0L;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final int[] histogram;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final RealCursor<T> cursor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final HistogramBinMapper<T> binMapper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Histogram(HistogramBinMapper<T> mapper, RealCursor<T> c) {
/*  89 */     this.cursor = c;
/*  90 */     this.binMapper = mapper;
/*  91 */     this.histogram = new int[this.binMapper.getNumBins()];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Histogram(HistogramBinMapper<T> mapper, Img<T> image) {
/* 108 */     this(mapper, (RealCursor<T>)image.cursor());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void reset() {
/* 116 */     Arrays.fill(this.histogram, 0);
/* 117 */     this.cursor.reset();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getBin(T t) {
/* 129 */     return getHistogram()[this.binMapper.map(t)];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getBin(int i) {
/* 141 */     return getHistogram()[i];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HistogramBinMapper<T> getBinMapper() {
/* 151 */     return this.binMapper;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int[] getHistogram() {
/* 161 */     return this.histogram;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T getBinCenter(int i) {
/* 174 */     return getBinMapper().invMap(i);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ArrayList<T> getBinCenters() {
/* 186 */     ArrayList<T> binCenters = new ArrayList<>(this.histogram.length);
/* 187 */     for (int i = 0; i < this.histogram.length; i++)
/*     */     {
/* 189 */       binCenters.add(i, getBinMapper().invMap(i));
/*     */     }
/*     */     
/* 192 */     return binCenters;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getNumBins() {
/* 203 */     return getBinMapper().getNumBins();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean checkInput() {
/* 209 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getErrorMessage() {
/* 215 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean process() {
/* 221 */     long startTime = System.currentTimeMillis();
/*     */ 
/*     */     
/* 224 */     while (this.cursor.hasNext()) {
/*     */       
/* 226 */       this.cursor.fwd();
/* 227 */       int index = this.binMapper.map((T)this.cursor.get());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 235 */       if (index >= 0 && index < this.histogram.length)
/*     */       {
/* 237 */         this.histogram[index] = this.histogram[index] + 1;
/*     */       }
/*     */     } 
/*     */     
/* 241 */     this.pTime = System.currentTimeMillis() - startTime;
/* 242 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public long getProcessingTime() {
/* 248 */     return this.pTime;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/imglib2-algorithm-0.6.2.jar!/net/imglib2/algorithm/stats/Histogram.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */