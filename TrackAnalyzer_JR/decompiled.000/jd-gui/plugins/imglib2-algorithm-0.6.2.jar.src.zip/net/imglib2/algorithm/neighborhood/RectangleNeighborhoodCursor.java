/*     */ package net.imglib2.algorithm.neighborhood;
/*     */ 
/*     */ import net.imglib2.Cursor;
/*     */ import net.imglib2.Interval;
/*     */ import net.imglib2.RandomAccessible;
/*     */ import net.imglib2.RandomAccessibleInterval;
/*     */ import net.imglib2.RealCursor;
/*     */ import net.imglib2.Sampler;
/*     */ import net.imglib2.util.IntervalIndexer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class RectangleNeighborhoodCursor<T>
/*     */   extends RectangleNeighborhoodLocalizableSampler<T>
/*     */   implements Cursor<Neighborhood<T>>
/*     */ {
/*     */   private final long[] dimensions;
/*     */   private final long[] min;
/*     */   private final long[] max;
/*     */   private long index;
/*     */   private final long maxIndex;
/*     */   private long maxIndexOnLine;
/*     */   
/*     */   public RectangleNeighborhoodCursor(RandomAccessibleInterval<T> source, Interval span, RectangleNeighborhoodFactory<T> factory) {
/*  58 */     super((RandomAccessible<T>)source, span, factory, (Interval)source);
/*     */     
/*  60 */     this.dimensions = new long[this.n];
/*  61 */     this.min = new long[this.n];
/*  62 */     this.max = new long[this.n];
/*  63 */     source.dimensions(this.dimensions);
/*  64 */     source.min(this.min);
/*  65 */     source.max(this.max);
/*  66 */     long size = this.dimensions[0];
/*  67 */     for (int d = 1; d < this.n; d++)
/*  68 */       size *= this.dimensions[d]; 
/*  69 */     this.maxIndex = size - 1L;
/*  70 */     reset();
/*     */   }
/*     */ 
/*     */   
/*     */   private RectangleNeighborhoodCursor(RectangleNeighborhoodCursor<T> c) {
/*  75 */     super(c);
/*  76 */     this.dimensions = (long[])c.dimensions.clone();
/*  77 */     this.min = (long[])c.min.clone();
/*  78 */     this.max = (long[])c.max.clone();
/*  79 */     this.maxIndex = c.maxIndex;
/*  80 */     this.index = c.index;
/*  81 */     this.maxIndexOnLine = c.maxIndexOnLine;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void fwd() {
/*  87 */     this.currentPos[0] = this.currentPos[0] + 1L;
/*  88 */     this.currentMin[0] = this.currentMin[0] + 1L;
/*  89 */     this.currentMax[0] = this.currentMax[0] + 1L;
/*  90 */     if (++this.index > this.maxIndexOnLine) {
/*  91 */       nextLine();
/*     */     }
/*     */   }
/*     */   
/*     */   private void nextLine() {
/*  96 */     this.currentPos[0] = this.min[0];
/*  97 */     this.currentMin[0] = this.currentMin[0] - this.dimensions[0];
/*  98 */     this.currentMax[0] = this.currentMax[0] - this.dimensions[0];
/*  99 */     this.maxIndexOnLine += this.dimensions[0];
/* 100 */     for (int d = 1; d < this.n; ) {
/*     */       
/* 102 */       this.currentPos[d] = this.currentPos[d] + 1L;
/* 103 */       this.currentMin[d] = this.currentMin[d] + 1L;
/* 104 */       this.currentMax[d] = this.currentMax[d] + 1L;
/* 105 */       if (this.currentPos[d] > this.max[d]) {
/*     */         
/* 107 */         this.currentPos[d] = this.min[d];
/* 108 */         this.currentMin[d] = this.currentMin[d] - this.dimensions[d];
/* 109 */         this.currentMax[d] = this.currentMax[d] - this.dimensions[d];
/*     */         d++;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void reset() {
/* 119 */     this.index = -1L;
/* 120 */     this.maxIndexOnLine = -1L;
/* 121 */     for (int d = 0; d < this.n; d++) {
/*     */       
/* 123 */       this.currentPos[d] = this.max[d];
/* 124 */       this.currentMin[d] = this.currentPos[d] + this.span.min(d);
/* 125 */       this.currentMax[d] = this.currentPos[d] + this.span.max(d);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasNext() {
/* 132 */     return (this.index < this.maxIndex);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void jumpFwd(long steps) {
/* 138 */     this.index += steps;
/* 139 */     if (this.index < 0L) {
/*     */       
/* 141 */       this.maxIndexOnLine = (1L + this.index) / this.dimensions[0] * this.dimensions[0] - 1L;
/* 142 */       long size = this.maxIndex + 1L;
/* 143 */       IntervalIndexer.indexToPositionWithOffset(size - -this.index % size, this.dimensions, this.min, this.currentPos);
/*     */     }
/*     */     else {
/*     */       
/* 147 */       this.maxIndexOnLine = (1L + this.index / this.dimensions[0]) * this.dimensions[0] - 1L;
/* 148 */       IntervalIndexer.indexToPositionWithOffset(this.index, this.dimensions, this.min, this.currentPos);
/*     */     } 
/* 150 */     for (int d = 0; d < this.n; d++) {
/*     */       
/* 152 */       this.currentMin[d] = this.currentPos[d] + this.span.min(d);
/* 153 */       this.currentMax[d] = this.currentPos[d] + this.span.max(d);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Neighborhood<T> next() {
/* 160 */     fwd();
/* 161 */     return get();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void remove() {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RectangleNeighborhoodCursor<T> copy() {
/* 173 */     return new RectangleNeighborhoodCursor(this);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public RectangleNeighborhoodCursor<T> copyCursor() {
/* 179 */     return copy();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/imglib2-algorithm-0.6.2.jar!/net/imglib2/algorithm/neighborhood/RectangleNeighborhoodCursor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */