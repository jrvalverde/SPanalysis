/*    */ package net.imglib2.algorithm.componenttree.mser;
/*    */ 
/*    */ import net.imglib2.type.numeric.NumericType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ComputeDeltaDarkToBright<T extends NumericType<T>>
/*    */   implements ComputeDelta<T>
/*    */ {
/*    */   private final T delta;
/*    */   
/*    */   ComputeDeltaDarkToBright(T delta) {
/* 55 */     this.delta = delta;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public T valueMinusDelta(T value) {
/* 61 */     NumericType numericType = (NumericType)value.copy();
/* 62 */     numericType.sub(this.delta);
/* 63 */     return (T)numericType;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/imglib2-algorithm-0.6.2.jar!/net/imglib2/algorithm/componenttree/mser/ComputeDeltaDarkToBright.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */