/*     */ package net.imglib2.algorithm.gauss;
/*     */ 
/*     */ import net.imglib2.Dimensions;
/*     */ import net.imglib2.Interval;
/*     */ import net.imglib2.Localizable;
/*     */ import net.imglib2.Point;
/*     */ import net.imglib2.RandomAccessible;
/*     */ import net.imglib2.RandomAccessibleInterval;
/*     */ import net.imglib2.img.Img;
/*     */ import net.imglib2.img.ImgFactory;
/*     */ import net.imglib2.img.NativeImg;
/*     */ import net.imglib2.img.array.ArrayImg;
/*     */ import net.imglib2.img.array.ArrayImgFactory;
/*     */ import net.imglib2.img.basictypeaccess.array.DoubleArray;
/*     */ import net.imglib2.img.cell.CellImg;
/*     */ import net.imglib2.img.cell.CellImgFactory;
/*     */ import net.imglib2.outofbounds.OutOfBoundsFactory;
/*     */ import net.imglib2.outofbounds.OutOfBoundsMirrorFactory;
/*     */ import net.imglib2.type.NativeType;
/*     */ import net.imglib2.type.numeric.real.DoubleType;
/*     */ import net.imglib2.view.Views;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public final class GaussDouble
/*     */   extends AbstractGauss<DoubleType>
/*     */ {
/*     */   protected boolean isArray;
/*     */   
/*     */   public GaussDouble(double[] sigma, RandomAccessible<DoubleType> input, Interval interval, ImgFactory<DoubleType> factory) {
/*  84 */     super(sigma, input, interval, (RandomAccessible<DoubleType>)factory.create((Dimensions)interval, new DoubleType()), (Localizable)new Point(sigma.length), factory, new DoubleType());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GaussDouble(double[] sigma, RandomAccessible<DoubleType> input, Interval interval, RandomAccessible<DoubleType> output, Localizable outputOffset, ImgFactory<DoubleType> factory) {
/* 110 */     super(sigma, input, interval, output, outputOffset, factory, new DoubleType());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GaussDouble(double[] sigma, Img<DoubleType> input) {
/* 125 */     this(sigma, (RandomAccessible<DoubleType>)Views.extend((RandomAccessibleInterval)input, (OutOfBoundsFactory)new OutOfBoundsMirrorFactory(OutOfBoundsMirrorFactory.Boundary.SINGLE)), (Interval)input, input.factory());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GaussDouble(double[] sigma, Img<DoubleType> input, OutOfBoundsFactory<DoubleType, Img<DoubleType>> outOfBounds) {
/* 141 */     this(sigma, (RandomAccessible<DoubleType>)Views.extend((RandomAccessibleInterval)input, outOfBounds), (Interval)input, input.factory());
/*     */   }
/*     */ 
/*     */   
/*     */   public static Img<DoubleType> gauss(double[] sigma, Img<DoubleType> input) {
/* 146 */     GaussDouble gauss = new GaussDouble(sigma, input);
/* 147 */     gauss.call();
/* 148 */     return (Img<DoubleType>)gauss.getResult();
/*     */   }
/*     */ 
/*     */   
/*     */   public static Img<DoubleType> gauss(double[] sigma, Img<DoubleType> input, OutOfBoundsFactory<DoubleType, Img<DoubleType>> outOfBounds) {
/* 153 */     GaussDouble gauss = new GaussDouble(sigma, input, outOfBounds);
/* 154 */     gauss.call();
/* 155 */     return (Img<DoubleType>)gauss.getResult();
/*     */   }
/*     */ 
/*     */   
/*     */   public static Img<DoubleType> gauss(double[] sigma, RandomAccessible<DoubleType> input, Interval interval, ImgFactory<DoubleType> factory) {
/* 160 */     GaussDouble gauss = new GaussDouble(sigma, input, interval, factory);
/* 161 */     gauss.call();
/* 162 */     return (Img<DoubleType>)gauss.getResult();
/*     */   }
/*     */ 
/*     */   
/*     */   public static void gauss(double[] sigma, RandomAccessible<DoubleType> input, Interval interval, RandomAccessible<DoubleType> output, Localizable outputOffset, ImgFactory<DoubleType> factory) {
/* 167 */     GaussDouble gauss = new GaussDouble(sigma, input, interval, output, outputOffset, factory);
/* 168 */     gauss.call();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Img<DoubleType> getProcessingLine(long sizeProcessLine) {
/*     */     CellImg cellImg;
/* 177 */     if (sizeProcessLine <= 2147483647L) {
/*     */       
/* 179 */       this.isArray = true;
/* 180 */       ArrayImg arrayImg = (new ArrayImgFactory()).create(new long[] { sizeProcessLine }, (NativeType)new DoubleType());
/*     */     }
/*     */     else {
/*     */       
/* 184 */       this.isArray = false;
/* 185 */       cellImg = (new CellImgFactory(134217727)).create(new long[] { sizeProcessLine }, (NativeType)new DoubleType());
/*     */     } 
/*     */     
/* 188 */     return (Img<DoubleType>)cellImg;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void processLine(SamplingLineIterator<DoubleType> input, double[] kernel) {
/* 205 */     if (!isArray()) {
/*     */       
/* 207 */       super.processLine(input, kernel);
/*     */       
/*     */       return;
/*     */     } 
/* 211 */     int kernelSize = kernel.length;
/* 212 */     int kernelSizeMinus1 = kernelSize - 1;
/* 213 */     int kernelSizeHalf = kernelSize / 2;
/* 214 */     int kernelSizeHalfMinus1 = kernelSizeHalf - 1;
/*     */     
/* 216 */     double[] v = ((DoubleArray)((NativeImg)input.getProcessLine()).update(null)).getCurrentStorageArray();
/*     */     
/* 218 */     int imgSize = v.length;
/*     */     
/* 220 */     int indexLeft = 0;
/* 221 */     int indexRight = 0;
/*     */     
/* 223 */     if (imgSize >= kernelSize) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 231 */       v[0] = v[0] + ((DoubleType)input.get()).get() * kernel[0];
/*     */       
/* 233 */       for (int i = 1; i < kernelSizeMinus1; i++) {
/*     */         
/* 235 */         input.fwd();
/*     */ 
/*     */ 
/*     */         
/* 239 */         double copy = ((DoubleType)input.get()).get();
/*     */ 
/*     */ 
/*     */         
/* 243 */         indexLeft = -1;
/*     */ 
/*     */         
/* 246 */         for (int o = 0; o <= i; o++) {
/* 247 */           v[++indexLeft] = v[++indexLeft] + copy * kernel[i - o];
/*     */         }
/*     */       } 
/*     */ 
/*     */       
/* 252 */       int length = imgSize - kernelSizeMinus1;
/* 253 */       for (int n = 0; n < length; n++) {
/*     */         
/* 255 */         input.fwd();
/*     */ 
/*     */ 
/*     */         
/* 259 */         double copy = ((DoubleType)input.get()).get();
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 264 */         indexLeft = n;
/* 265 */         indexRight = n + kernelSizeMinus1;
/*     */ 
/*     */         
/* 268 */         for (int k = 0; k < kernelSizeHalfMinus1; k++) {
/*     */           
/* 270 */           double d = copy * kernel[k];
/*     */           
/* 272 */           v[indexLeft++] = v[indexLeft++] + d;
/* 273 */           v[indexRight--] = v[indexRight--] + d;
/*     */         } 
/*     */ 
/*     */ 
/*     */         
/* 278 */         double tmp = copy * kernel[kernelSizeHalfMinus1];
/*     */         
/* 280 */         v[indexLeft++] = v[indexLeft++] + tmp;
/* 281 */         v[indexRight] = v[indexRight] + tmp;
/*     */ 
/*     */         
/* 284 */         v[indexLeft] = v[indexLeft] + copy * kernel[kernelSizeHalf];
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 289 */       int endLength = imgSize + kernelSizeMinus1;
/* 290 */       for (int j = imgSize; j < endLength; j++)
/*     */       {
/*     */ 
/*     */         
/* 294 */         input.fwd();
/*     */ 
/*     */ 
/*     */         
/* 298 */         double copy = ((DoubleType)input.get()).get();
/*     */ 
/*     */ 
/*     */         
/* 302 */         indexLeft = j - kernelSize;
/*     */ 
/*     */         
/* 305 */         int k = 0; long o;
/* 306 */         for (o = (j - kernelSize + 1); o < imgSize; o++) {
/* 307 */           v[++indexLeft] = v[++indexLeft] + copy * kernel[k++];
/*     */         
/*     */         }
/*     */       
/*     */       }
/*     */ 
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */       
/* 318 */       v[0] = v[0] + ((DoubleType)input.get()).get() * kernel[0];
/*     */       int i;
/* 320 */       for (i = 1; i < imgSize; i++) {
/*     */         
/* 322 */         input.fwd();
/*     */ 
/*     */ 
/*     */         
/* 326 */         double copy = ((DoubleType)input.get()).get();
/*     */ 
/*     */ 
/*     */         
/* 330 */         indexLeft = -1;
/*     */ 
/*     */         
/* 333 */         for (int o = 0; o <= i; o++) {
/* 334 */           v[++indexLeft] = v[++indexLeft] + copy * kernel[i - o];
/*     */         }
/*     */       } 
/*     */ 
/*     */       
/* 339 */       for (i = imgSize; i < imgSize + kernelSizeMinus1; i++) {
/*     */ 
/*     */ 
/*     */         
/* 343 */         input.fwd();
/*     */ 
/*     */ 
/*     */         
/* 347 */         double copy = ((DoubleType)input.get()).get();
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 352 */         int o = i - kernelSize + 1;
/* 353 */         int k = 0;
/*     */         
/* 355 */         if (o < 0) {
/*     */           
/* 357 */           k = -o;
/* 358 */           o = 0;
/*     */         } 
/*     */         
/* 361 */         for (; o < imgSize; o++) {
/* 362 */           v[o] = v[o] + copy * kernel[k++];
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   protected boolean isArray() {
/* 369 */     return this.isArray;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/imglib2-algorithm-0.6.2.jar!/net/imglib2/algorithm/gauss/GaussDouble.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */