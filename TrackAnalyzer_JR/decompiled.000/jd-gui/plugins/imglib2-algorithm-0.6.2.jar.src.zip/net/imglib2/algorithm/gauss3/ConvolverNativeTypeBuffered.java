/*     */ package net.imglib2.algorithm.gauss3;
/*     */ 
/*     */ import net.imglib2.RandomAccess;
/*     */ import net.imglib2.img.array.ArrayImg;
/*     */ import net.imglib2.img.array.ArrayImgFactory;
/*     */ import net.imglib2.type.NativeType;
/*     */ import net.imglib2.type.Type;
/*     */ import net.imglib2.type.numeric.NumericType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ConvolverNativeTypeBuffered<T extends NumericType<T> & NativeType<T>>
/*     */   implements Runnable
/*     */ {
/*     */   private final double[] kernel;
/*     */   private final RandomAccess<T> in;
/*     */   private final RandomAccess<T> out;
/*     */   private final int d;
/*     */   private final int k;
/*     */   private final int k1;
/*     */   private final int k1k1;
/*     */   private final int buflen;
/*     */   final T b1;
/*     */   final T tmp;
/*     */   
/*     */   public static <T extends NumericType<T> & NativeType<T>> ConvolverFactoryNativeTypeBuffered<T> factory(T type) {
/*  65 */     return new ConvolverFactoryNativeTypeBuffered<>(type);
/*     */   }
/*     */   
/*     */   public static final class ConvolverFactoryNativeTypeBuffered<T extends NumericType<T> & NativeType<T>>
/*     */     implements ConvolverFactory<T, T>
/*     */   {
/*     */     private final T type;
/*     */     
/*     */     public ConvolverFactoryNativeTypeBuffered(T type) {
/*  74 */       this.type = type;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Runnable create(double[] halfkernel, RandomAccess<T> in, RandomAccess<T> out, int d, long lineLength) {
/*  80 */       return new ConvolverNativeTypeBuffered<>(halfkernel, in, out, d, lineLength, (NumericType)this.type);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ConvolverNativeTypeBuffered(double[] kernel, RandomAccess<T> in, RandomAccess<T> out, int d, long lineLength, T type) {
/* 106 */     this.kernel = kernel;
/* 107 */     this.in = in;
/* 108 */     this.out = out;
/* 109 */     this.d = d;
/*     */     
/* 111 */     this.k = kernel.length;
/* 112 */     this.k1 = this.k - 1;
/* 113 */     this.k1k1 = this.k1 + this.k1;
/*     */     
/* 115 */     this.buflen = (int)lineLength + 2 * this.k1k1;
/* 116 */     ArrayImg<T, ?> buf = (new ArrayImgFactory()).create(new long[] { this.buflen }, (NativeType)type);
/* 117 */     this.b1 = (T)buf.randomAccess().get();
/*     */     
/* 119 */     this.tmp = (T)type.createVariable();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void run() {
/* 125 */     int max = this.buflen - this.k1;
/* 126 */     for (int i = this.k1; i < max; i++) {
/*     */       
/* 128 */       NumericType numericType = (NumericType)this.in.get();
/*     */ 
/*     */       
/* 131 */       this.tmp.set((Type)numericType);
/* 132 */       this.tmp.mul(this.kernel[0]);
/* 133 */       ((NativeType)this.b1).updateIndex(i);
/* 134 */       this.b1.add(this.tmp);
/*     */ 
/*     */       
/* 137 */       for (int j = 1; j < this.k1; j++) {
/*     */         
/* 139 */         this.tmp.set((Type)numericType);
/* 140 */         this.tmp.mul(this.kernel[j]);
/* 141 */         ((NativeType)this.b1).updateIndex(i + j);
/* 142 */         this.b1.add(this.tmp);
/* 143 */         ((NativeType)this.b1).updateIndex(i - j);
/* 144 */         this.b1.add(this.tmp);
/*     */       } 
/*     */ 
/*     */       
/* 148 */       this.tmp.set((Type)numericType);
/* 149 */       this.tmp.mul(this.kernel[this.k1]);
/* 150 */       ((NativeType)this.b1).updateIndex(i - this.k1);
/* 151 */       this.b1.add(this.tmp);
/* 152 */       ((NativeType)this.b1).updateIndex(i + this.k1);
/* 153 */       this.b1.set((Type)this.tmp);
/*     */       
/* 155 */       this.in.fwd(this.d);
/*     */     } 
/*     */     
/* 158 */     writeLine();
/*     */   }
/*     */ 
/*     */   
/*     */   private void writeLine() {
/* 163 */     int max = this.buflen - this.k1k1;
/* 164 */     for (int i = this.k1k1; i < max; i++) {
/*     */       
/* 166 */       ((NativeType)this.b1).updateIndex(i);
/* 167 */       ((NumericType)this.out.get()).set((Type)this.b1);
/* 168 */       this.out.fwd(this.d);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/imglib2-algorithm-0.6.2.jar!/net/imglib2/algorithm/gauss3/ConvolverNativeTypeBuffered.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */