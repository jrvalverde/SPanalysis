/*     */ package net.imglib2.algorithm.componenttree.pixellist;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import net.imglib2.Localizable;
/*     */ import net.imglib2.algorithm.componenttree.Component;
/*     */ import net.imglib2.type.Type;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class PixelListComponent<T extends Type<T>>
/*     */   implements Component<T, PixelListComponent<T>>
/*     */ {
/*     */   private final ArrayList<PixelListComponent<T>> children;
/*     */   private PixelListComponent<T> parent;
/*     */   private final T value;
/*     */   private final PixelList pixelList;
/*     */   
/*     */   PixelListComponent(PixelListPartialComponent<T> intermediate) {
/*  80 */     this.children = new ArrayList<>();
/*  81 */     this.parent = null;
/*  82 */     this.value = (T)intermediate.getValue().copy();
/*  83 */     this.pixelList = new PixelList(intermediate.pixelList);
/*  84 */     if (intermediate.emittedComponent != null)
/*  85 */       this.children.add(intermediate.emittedComponent); 
/*  86 */     for (PixelListPartialComponent<T> c : intermediate.children) {
/*     */       
/*  88 */       this.children.add(c.emittedComponent);
/*  89 */       c.emittedComponent.parent = this;
/*     */     } 
/*  91 */     intermediate.emittedComponent = this;
/*  92 */     intermediate.children.clear();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T value() {
/* 103 */     return this.value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long size() {
/* 114 */     return this.pixelList.size();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Iterator<Localizable> iterator() {
/* 126 */     return this.pixelList.iterator();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ArrayList<PixelListComponent<T>> getChildren() {
/* 137 */     return this.children;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PixelListComponent<T> getParent() {
/* 148 */     return this.parent;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/imglib2-algorithm-0.6.2.jar!/net/imglib2/algorithm/componenttree/pixellist/PixelListComponent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */