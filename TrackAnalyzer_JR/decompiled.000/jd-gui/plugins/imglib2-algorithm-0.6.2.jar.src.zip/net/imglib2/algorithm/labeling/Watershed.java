/*     */ package net.imglib2.algorithm.labeling;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.PriorityQueue;
/*     */ import net.imglib2.Cursor;
/*     */ import net.imglib2.RandomAccessibleInterval;
/*     */ import net.imglib2.algorithm.OutputAlgorithm;
/*     */ import net.imglib2.img.Img;
/*     */ import net.imglib2.img.array.ArrayImgFactory;
/*     */ import net.imglib2.labeling.Labeling;
/*     */ import net.imglib2.labeling.LabelingOutOfBoundsRandomAccessFactory;
/*     */ import net.imglib2.labeling.LabelingType;
/*     */ import net.imglib2.labeling.NativeImgLabeling;
/*     */ import net.imglib2.outofbounds.OutOfBounds;
/*     */ import net.imglib2.outofbounds.OutOfBoundsConstantValueFactory;
/*     */ import net.imglib2.type.NativeType;
/*     */ import net.imglib2.type.Type;
/*     */ import net.imglib2.type.numeric.RealType;
/*     */ import net.imglib2.type.numeric.integer.IntType;
/*     */ import net.imglib2.view.Views;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Watershed<T extends RealType<T>, L extends Comparable<L>>
/*     */   implements OutputAlgorithm<Labeling<L>>
/*     */ {
/*     */   protected RandomAccessibleInterval<T> image;
/*     */   protected Labeling<L> seeds;
/*     */   long[][] structuringElement;
/*     */   protected Labeling<L> output;
/*     */   String errorMessage;
/*     */   
/*     */   protected static class PixelIntensity<U extends Comparable<U>>
/*     */     implements Comparable<PixelIntensity<U>>
/*     */   {
/*     */     protected final long index;
/*     */     protected final long age;
/*     */     protected final double intensity;
/*     */     protected final List<U> labeling;
/*     */     
/*     */     public PixelIntensity(long[] position, long[] dimensions, double intensity, long age, List<U> labeling) {
/*  88 */       long index = position[0];
/*  89 */       long multiplier = dimensions[0];
/*  90 */       for (int i = 1; i < dimensions.length; i++) {
/*     */         
/*  92 */         index += position[i] * multiplier;
/*  93 */         multiplier *= dimensions[i];
/*     */       } 
/*     */       
/*  96 */       this.index = index;
/*  97 */       this.intensity = intensity;
/*  98 */       this.labeling = labeling;
/*  99 */       this.age = age;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public int compareTo(PixelIntensity<U> other) {
/* 105 */       int result = Double.compare(this.intensity, other.intensity);
/* 106 */       if (result == 0)
/* 107 */         result = Double.compare(this.age, other.age); 
/* 108 */       return result;
/*     */     }
/*     */ 
/*     */     
/*     */     void getPosition(long[] position, long[] dimensions) {
/* 113 */       long idx = this.index;
/* 114 */       for (int i = 0; i < dimensions.length; i++) {
/*     */         
/* 116 */         position[i] = (int)(idx % dimensions[i]);
/* 117 */         idx /= dimensions[i];
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     List<U> getLabeling() {
/* 123 */       return this.labeling;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setIntensityImage(RandomAccessibleInterval<T> image) {
/* 146 */     this.image = image;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSeeds(Labeling<L> seeds) {
/* 159 */     this.seeds = seeds;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setStructuringElement(long[][] structuringElement) {
/* 174 */     this.structuringElement = structuringElement;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setOutputLabeling(Labeling<L> outputLabeling) {
/* 185 */     this.output = outputLabeling;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean process() {
/* 201 */     if (!checkInput()) {
/* 202 */       return false;
/*     */     }
/* 204 */     if (this.output == null) {
/*     */       
/* 206 */       long[] arrayOfLong = new long[this.seeds.numDimensions()];
/* 207 */       this.seeds.dimensions(arrayOfLong);
/* 208 */       NativeImgLabeling<L, IntType> o = new NativeImgLabeling((Img)(new ArrayImgFactory()).create(arrayOfLong, (NativeType)new IntType()));
/* 209 */       this.output = (Labeling)o;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 217 */     LabelingOutOfBoundsRandomAccessFactory labelingOutOfBoundsRandomAccessFactory = new LabelingOutOfBoundsRandomAccessFactory();
/* 218 */     OutOfBounds<LabelingType<L>> outputAccess = labelingOutOfBoundsRandomAccessFactory.create(this.output);
/*     */     
/* 220 */     RealType realType = (RealType)((RealType)Views.iterable(this.image).firstElement()).createVariable();
/* 221 */     realType.setReal(realType.getMaxValue());
/* 222 */     OutOfBoundsConstantValueFactory outOfBoundsConstantValueFactory = new OutOfBoundsConstantValueFactory((Type)realType);
/* 223 */     OutOfBounds<T> imageAccess = outOfBoundsConstantValueFactory.create(this.image);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 228 */     PriorityQueue<PixelIntensity<L>> pq = new PriorityQueue<>();
/* 229 */     Cursor<LabelingType<L>> c = this.seeds.localizingCursor();
/*     */     
/* 231 */     long[] dimensions = new long[this.image.numDimensions()];
/* 232 */     this.output.dimensions(dimensions);
/* 233 */     long[] position = new long[this.image.numDimensions()];
/* 234 */     long[] destPosition = new long[this.image.numDimensions()];
/* 235 */     long age = 0L;
/*     */     
/* 237 */     while (c.hasNext()) {
/*     */       
/* 239 */       LabelingType<L> tSrc = (LabelingType<L>)c.next();
/* 240 */       List<L> l = tSrc.getLabeling();
/* 241 */       if (l.isEmpty()) {
/*     */         continue;
/*     */       }
/* 244 */       c.localize(position);
/* 245 */       imageAccess.setPosition(position);
/* 246 */       if (imageAccess.isOutOfBounds())
/*     */         continue; 
/* 248 */       outputAccess.setPosition(position);
/* 249 */       if (outputAccess.isOutOfBounds())
/*     */         continue; 
/* 251 */       LabelingType<L> tDest = (LabelingType<L>)outputAccess.get();
/* 252 */       l = tDest.intern(l);
/* 253 */       tDest.setLabeling(l);
/* 254 */       double intensity = ((RealType)imageAccess.get()).getRealDouble();
/* 255 */       pq.add(new PixelIntensity<>(position, dimensions, intensity, age++, l));
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 261 */     long[][] strelMoves = new long[this.structuringElement.length][];
/* 262 */     long[] currentOffset = new long[this.image.numDimensions()];
/* 263 */     for (int i = 0; i < this.structuringElement.length; i++) {
/*     */       
/* 265 */       strelMoves[i] = new long[this.image.numDimensions()];
/* 266 */       for (int j = 0; j < this.image.numDimensions(); j++) {
/*     */         
/* 268 */         strelMoves[i][j] = this.structuringElement[i][j] - currentOffset[j];
/* 269 */         if (i > 0) {
/* 270 */           currentOffset[j] = currentOffset[j] + this.structuringElement[i][j] - this.structuringElement[i - 1][j];
/*     */         } else {
/* 272 */           currentOffset[j] = currentOffset[j] + this.structuringElement[i][j];
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 279 */     while (!pq.isEmpty()) {
/*     */       
/* 281 */       PixelIntensity<L> currentPI = pq.remove();
/* 282 */       List<L> l = currentPI.getLabeling();
/* 283 */       currentPI.getPosition(position, dimensions);
/* 284 */       outputAccess.setPosition(position);
/* 285 */       imageAccess.setPosition(position);
/* 286 */       for (long[] offset : strelMoves) {
/*     */         
/* 288 */         outputAccess.move(offset);
/* 289 */         imageAccess.move(offset);
/* 290 */         if (!outputAccess.isOutOfBounds())
/*     */         {
/* 292 */           if (!imageAccess.isOutOfBounds()) {
/*     */             
/* 294 */             LabelingType<L> outputLabelingType = (LabelingType<L>)outputAccess.get();
/* 295 */             if (outputLabelingType.getLabeling().isEmpty())
/*     */             
/* 297 */             { outputLabelingType.setLabeling(l);
/* 298 */               double intensity = ((RealType)imageAccess.get()).getRealDouble();
/* 299 */               outputAccess.localize(destPosition);
/* 300 */               pq.add(new PixelIntensity<>(destPosition, dimensions, intensity, age++, l)); } 
/*     */           }  } 
/*     */       } 
/* 303 */     }  return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean checkInput() {
/* 309 */     if (this.seeds == null) {
/*     */       
/* 311 */       this.errorMessage = "The seed labeling was not provided. Call \"setSeeds\" to do this";
/* 312 */       return false;
/*     */     } 
/* 314 */     if (this.image == null) {
/*     */       
/* 316 */       this.errorMessage = "The intensity image was not provided. Call \"setIntensityImage\" to do this";
/* 317 */       return false;
/*     */     } 
/* 319 */     if (this.seeds.numDimensions() != this.image.numDimensions()) {
/*     */       
/* 321 */       this.errorMessage = String.format("The dimensionality of the seed labeling (%dD) does not match that of the intensity image (%dD)", new Object[] { Integer.valueOf(this.seeds.numDimensions()), Integer.valueOf(this.image.numDimensions()) });
/* 322 */       return false;
/*     */     } 
/* 324 */     if (this.output != null && this.seeds.numDimensions() != this.output.numDimensions()) {
/*     */       
/* 326 */       this.errorMessage = String.format("The dimensionality of the seed labeling (%dD) does not match that of the output labeling (%dD)", new Object[] { Integer.valueOf(this.seeds.numDimensions()), Integer.valueOf(this.output.numDimensions()) });
/* 327 */       return false;
/*     */     } 
/* 329 */     if (this.structuringElement == null)
/* 330 */       this.structuringElement = AllConnectedComponents.getStructuringElement(this.image.numDimensions()); 
/* 331 */     for (int i = 0; i < this.structuringElement.length; i++) {
/*     */       
/* 333 */       if ((this.structuringElement[i]).length != this.seeds.numDimensions()) {
/*     */         
/* 335 */         this.errorMessage = "Some or all of the structuring element offsets do not have the same number of dimensions as the image";
/* 336 */         return false;
/*     */       } 
/*     */     } 
/* 339 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getErrorMessage() {
/* 345 */     return this.errorMessage;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Labeling<L> getResult() {
/* 351 */     return this.output;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/imglib2-algorithm-0.6.2.jar!/net/imglib2/algorithm/labeling/Watershed.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */