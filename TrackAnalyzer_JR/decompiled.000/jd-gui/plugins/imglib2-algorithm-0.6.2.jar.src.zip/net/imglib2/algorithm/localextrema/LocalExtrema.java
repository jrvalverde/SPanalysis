/*     */ package net.imglib2.algorithm.localextrema;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.Callable;
/*     */ import java.util.concurrent.ExecutionException;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.Future;
/*     */ import net.imglib2.Cursor;
/*     */ import net.imglib2.FinalInterval;
/*     */ import net.imglib2.Interval;
/*     */ import net.imglib2.Localizable;
/*     */ import net.imglib2.Point;
/*     */ import net.imglib2.RandomAccessible;
/*     */ import net.imglib2.RandomAccessibleInterval;
/*     */ import net.imglib2.Sampler;
/*     */ import net.imglib2.algorithm.neighborhood.Neighborhood;
/*     */ import net.imglib2.algorithm.neighborhood.RectangleShape;
/*     */ import net.imglib2.util.Intervals;
/*     */ import net.imglib2.view.IntervalView;
/*     */ import net.imglib2.view.Views;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LocalExtrema
/*     */ {
/*     */   public static <P, T extends Comparable<T>> ArrayList<P> findLocalExtrema(RandomAccessibleInterval<T> img, final LocalNeighborhoodCheck<P, T> localNeighborhoodCheck, ExecutorService service) {
/* 108 */     ArrayList<P> allExtrema = new ArrayList<>();
/*     */     
/* 110 */     FinalInterval finalInterval = Intervals.expand((Interval)img, -1L);
/* 111 */     int n = img.numDimensions();
/* 112 */     int splitd = n - 1;
/*     */     
/* 114 */     int numThreads = Runtime.getRuntime().availableProcessors();
/* 115 */     int numTasks = Math.max(Math.min((int)finalInterval.dimension(splitd), numThreads * 20), 1);
/* 116 */     long dsize = finalInterval.dimension(splitd) / numTasks;
/* 117 */     long[] min = new long[n];
/* 118 */     long[] max = new long[n];
/* 119 */     finalInterval.min(min);
/* 120 */     finalInterval.max(max);
/*     */     
/* 122 */     final RectangleShape shape = new RectangleShape(1, true);
/*     */     
/* 124 */     ArrayList<Future<Void>> futures = new ArrayList<>();
/* 125 */     final List<P> synchronizedAllExtrema = Collections.synchronizedList(allExtrema);
/* 126 */     for (int taskNum = 0; taskNum < numTasks; taskNum++) {
/*     */       
/* 128 */       min[splitd] = finalInterval.min(splitd) + taskNum * dsize;
/* 129 */       max[splitd] = (taskNum == numTasks - 1) ? finalInterval.max(splitd) : (min[splitd] + dsize - 1L);
/* 130 */       final IntervalView source = Views.interval((RandomAccessible)img, (Interval)new FinalInterval(min, max));
/* 131 */       final ArrayList<P> extrema = new ArrayList<>(128);
/* 132 */       Callable<Void> r = new Callable<Void>()
/*     */         {
/*     */           
/*     */           public Void call()
/*     */           {
/* 137 */             Cursor<T> center = Views.flatIterable(source).cursor();
/* 138 */             for (Neighborhood<T> neighborhood : (Iterable<Neighborhood<T>>)shape.neighborhoods(source)) {
/*     */               
/* 140 */               center.fwd();
/* 141 */               P p = (P)localNeighborhoodCheck.check(center, neighborhood);
/* 142 */               if (p != null)
/* 143 */                 extrema.add(p); 
/*     */             } 
/* 145 */             synchronizedAllExtrema.addAll(extrema);
/* 146 */             return null;
/*     */           }
/*     */         };
/* 149 */       futures.add(service.submit(r));
/*     */     } 
/* 151 */     for (Future<Void> f : futures) {
/*     */ 
/*     */       
/*     */       try {
/* 155 */         f.get();
/*     */       }
/* 157 */       catch (InterruptedException e) {
/*     */         
/* 159 */         e.printStackTrace();
/*     */       }
/* 161 */       catch (ExecutionException e) {
/*     */         
/* 163 */         e.printStackTrace();
/*     */       } 
/*     */     } 
/*     */     
/* 167 */     return allExtrema;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static interface LocalNeighborhoodCheck<P, T extends Comparable<T>>
/*     */   {
/*     */     <C extends Localizable & Sampler<T>> P check(C param1C, Neighborhood<T> param1Neighborhood);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static class MaximumCheck<T extends Comparable<T>>
/*     */     implements LocalNeighborhoodCheck<Point, T>
/*     */   {
/*     */     final T minPeakValue;
/*     */ 
/*     */ 
/*     */     
/*     */     public MaximumCheck(T minPeakValue) {
/* 188 */       this.minPeakValue = minPeakValue;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public <C extends Localizable & Sampler<T>> Point check(C center, Neighborhood<T> neighborhood) {
/* 194 */       Comparable comparable = (Comparable)((Sampler)center).get();
/* 195 */       if (this.minPeakValue.compareTo(comparable) > 0) {
/* 196 */         return null;
/*     */       }
/* 198 */       for (Comparable<Comparable> comparable1 : neighborhood) {
/* 199 */         if (comparable1.compareTo(comparable) > 0)
/* 200 */           return null; 
/*     */       } 
/* 202 */       return new Point((Localizable)center);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class MinimumCheck<T extends Comparable<T>>
/*     */     implements LocalNeighborhoodCheck<Point, T>
/*     */   {
/*     */     final T maxPeakValue;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public MinimumCheck(T maxPeakValue) {
/* 224 */       this.maxPeakValue = maxPeakValue;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public <C extends Localizable & Sampler<T>> Point check(C center, Neighborhood<T> neighborhood) {
/* 230 */       Comparable comparable = (Comparable)((Sampler)center).get();
/* 231 */       if (this.maxPeakValue.compareTo(comparable) < 0) {
/* 232 */         return null;
/*     */       }
/* 234 */       for (Comparable<Comparable> comparable1 : neighborhood) {
/* 235 */         if (comparable1.compareTo(comparable) < 0)
/* 236 */           return null; 
/*     */       } 
/* 238 */       return new Point((Localizable)center);
/*     */     }
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/imglib2-algorithm-0.6.2.jar!/net/imglib2/algorithm/localextrema/LocalExtrema.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */