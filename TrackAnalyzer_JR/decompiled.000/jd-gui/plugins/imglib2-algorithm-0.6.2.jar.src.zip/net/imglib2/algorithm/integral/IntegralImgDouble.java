/*    */ package net.imglib2.algorithm.integral;
/*    */ 
/*    */ import net.imglib2.RandomAccess;
/*    */ import net.imglib2.RandomAccessibleInterval;
/*    */ import net.imglib2.converter.Converter;
/*    */ import net.imglib2.type.numeric.NumericType;
/*    */ import net.imglib2.type.numeric.real.AbstractRealType;
/*    */ import net.imglib2.type.numeric.real.DoubleType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IntegralImgDouble<R extends NumericType<R>>
/*    */   extends IntegralImg<R, DoubleType>
/*    */ {
/*    */   public IntegralImgDouble(RandomAccessibleInterval<R> img, DoubleType type, Converter<R, DoubleType> converter) {
/* 55 */     super(img, type, converter);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected void integrateLineDim0(Converter<R, DoubleType> converter, RandomAccess<R> cursorIn, RandomAccess<DoubleType> cursorOut, DoubleType sum, DoubleType tmpVar, long size) {
/* 62 */     converter.convert(cursorIn.get(), sum);
/* 63 */     ((DoubleType)cursorOut.get()).set((AbstractRealType)sum);
/*    */     
/* 65 */     double sum2 = sum.get();
/*    */     
/* 67 */     for (int i = 2; i < size; i++) {
/*    */       
/* 69 */       cursorIn.fwd(0);
/* 70 */       cursorOut.fwd(0);
/*    */       
/* 72 */       converter.convert(cursorIn.get(), tmpVar);
/* 73 */       sum2 += tmpVar.get();
/* 74 */       ((DoubleType)cursorOut.get()).set(sum2);
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected void integrateLine(int d, RandomAccess<DoubleType> cursor, DoubleType sum, long size) {
/* 82 */     double sum2 = ((DoubleType)cursor.get()).get();
/*    */     
/* 84 */     for (int i = 2; i < size; i++) {
/*    */       
/* 86 */       cursor.fwd(d);
/*    */       
/* 88 */       sum2 += ((DoubleType)cursor.get()).get();
/* 89 */       ((DoubleType)cursor.get()).set(sum2);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/imglib2-algorithm-0.6.2.jar!/net/imglib2/algorithm/integral/IntegralImgDouble.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */