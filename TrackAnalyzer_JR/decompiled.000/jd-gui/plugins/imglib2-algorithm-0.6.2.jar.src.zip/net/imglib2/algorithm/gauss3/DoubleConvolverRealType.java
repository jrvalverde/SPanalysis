/*     */ package net.imglib2.algorithm.gauss3;
/*     */ 
/*     */ import net.imglib2.RandomAccess;
/*     */ import net.imglib2.type.numeric.RealType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class DoubleConvolverRealType<S extends RealType<S>, T extends RealType<T>>
/*     */   implements Runnable
/*     */ {
/*     */   private final double[] kernel;
/*     */   private final RandomAccess<S> in;
/*     */   private final RandomAccess<T> out;
/*     */   private final int d;
/*     */   private final int k;
/*     */   private final int k1;
/*     */   private final int k1k1;
/*     */   private final int k1k;
/*     */   private final long fill2;
/*     */   private final boolean fillAdditional;
/*     */   private final double[] buf1;
/*     */   private final double[] buf2;
/*     */   
/*     */   public static <S extends RealType<S>, T extends RealType<T>> ConvolverFactory<S, T> factory() {
/*  63 */     return new ConvolverFactory<S, T>()
/*     */       {
/*     */         
/*     */         public Runnable create(double[] halfkernel, RandomAccess<S> in, RandomAccess<T> out, int d, long lineLength)
/*     */         {
/*  68 */           return new DoubleConvolverRealType<>(halfkernel, in, out, d, lineLength);
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private DoubleConvolverRealType(double[] kernel, RandomAccess<S> in, RandomAccess<T> out, int d, long lineLength) {
/*  99 */     this.kernel = kernel;
/* 100 */     this.in = in;
/* 101 */     this.out = out;
/* 102 */     this.d = d;
/*     */     
/* 104 */     this.k = this.kernel.length;
/* 105 */     this.k1 = this.k - 1;
/* 106 */     this.k1k1 = this.k1 + this.k1;
/* 107 */     this.k1k = this.k1 + this.k;
/* 108 */     this.fill2 = lineLength / 2L;
/* 109 */     this.fillAdditional = (lineLength % 2L == 1L);
/*     */     
/* 111 */     int l = 2 * this.k;
/* 112 */     this.buf1 = new double[l];
/* 113 */     this.buf2 = new double[l];
/*     */   }
/*     */ 
/*     */   
/*     */   private void prefill1() {
/* 118 */     double w = ((RealType)this.in.get()).getRealDouble();
/* 119 */     this.buf1[this.k1] = w * this.kernel[0] + this.buf2[this.k];
/* 120 */     for (int i = 1; i < this.k1; i++) {
/*     */       
/* 122 */       double wk = w * this.kernel[i];
/* 123 */       this.buf1[this.k1 + i] = wk + this.buf2[this.k + i];
/* 124 */       this.buf1[this.k1 - i] = wk + this.buf2[this.k - i];
/*     */     } 
/* 126 */     this.buf1[this.k1k1] = w * this.kernel[this.k1] + this.buf2[this.k1k];
/* 127 */     this.in.fwd(this.d);
/*     */   }
/*     */ 
/*     */   
/*     */   private void prefill2() {
/* 132 */     double w = ((RealType)this.in.get()).getRealDouble();
/* 133 */     this.buf2[this.k1] = w * this.kernel[0] + this.buf1[this.k];
/* 134 */     for (int i = 1; i < this.k1; i++) {
/*     */       
/* 136 */       double wk = w * this.kernel[i];
/* 137 */       this.buf2[this.k1 + i] = wk + this.buf1[this.k + i];
/* 138 */       this.buf2[this.k1 - i] = wk + this.buf1[this.k - i];
/*     */     } 
/* 140 */     this.buf2[this.k1k1] = w * this.kernel[this.k1] + this.buf1[this.k1k];
/* 141 */     this.in.fwd(this.d);
/*     */   }
/*     */ 
/*     */   
/*     */   private void next2() {
/* 146 */     double w = ((RealType)this.in.get()).getRealDouble();
/* 147 */     this.buf2[this.k1] = w * this.kernel[0] + this.buf1[this.k];
/* 148 */     for (int i = 1; i < this.k1; i++) {
/*     */       
/* 150 */       double d = w * this.kernel[i];
/* 151 */       this.buf2[this.k1 + i] = d + this.buf1[this.k + i];
/* 152 */       this.buf2[this.k1 - i] = d + this.buf1[this.k - i];
/*     */     } 
/* 154 */     double wk = w * this.kernel[this.k1];
/* 155 */     this.buf2[this.k1k1] = wk + this.buf1[this.k1k];
/* 156 */     ((RealType)this.out.get()).setReal(wk + this.buf1[1]);
/* 157 */     this.in.fwd(this.d);
/* 158 */     this.out.fwd(this.d);
/*     */   }
/*     */ 
/*     */   
/*     */   private void next1() {
/* 163 */     double w = ((RealType)this.in.get()).getRealDouble();
/* 164 */     this.buf1[this.k1] = w * this.kernel[0] + this.buf2[this.k];
/* 165 */     for (int i = 1; i < this.k1; i++) {
/*     */       
/* 167 */       double d = w * this.kernel[i];
/* 168 */       this.buf1[this.k1 + i] = d + this.buf2[this.k + i];
/* 169 */       this.buf1[this.k1 - i] = d + this.buf2[this.k - i];
/*     */     } 
/* 171 */     double wk = w * this.kernel[this.k1];
/* 172 */     this.buf1[this.k1k1] = wk + this.buf2[this.k1k];
/* 173 */     ((RealType)this.out.get()).setReal(wk + this.buf2[1]);
/* 174 */     this.in.fwd(this.d);
/* 175 */     this.out.fwd(this.d);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void run() {
/* 181 */     for (int j = 0; j < this.k1; j++) {
/*     */       
/* 183 */       prefill1();
/* 184 */       prefill2();
/*     */     } 
/* 186 */     for (long i = 0L; i < this.fill2; i++) {
/*     */       
/* 188 */       next1();
/* 189 */       next2();
/*     */     } 
/* 191 */     if (this.fillAdditional)
/* 192 */       next1(); 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/imglib2-algorithm-0.6.2.jar!/net/imglib2/algorithm/gauss3/DoubleConvolverRealType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */