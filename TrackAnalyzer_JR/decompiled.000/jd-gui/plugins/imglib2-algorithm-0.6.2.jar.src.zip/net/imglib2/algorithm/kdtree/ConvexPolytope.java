/*    */ package net.imglib2.algorithm.kdtree;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Arrays;
/*    */ import java.util.Collection;
/*    */ import net.imglib2.AbstractEuclideanSpace;
/*    */ import net.imglib2.realtransform.AffineGet;
/*    */ import net.imglib2.util.LinAlgHelpers;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ConvexPolytope
/*    */   extends AbstractEuclideanSpace
/*    */ {
/*    */   private final Collection<? extends HyperPlane> hyperplanes;
/*    */   
/*    */   public ConvexPolytope(Collection<? extends HyperPlane> hyperplanes) {
/* 51 */     super(((HyperPlane)hyperplanes.iterator().next()).numDimensions());
/* 52 */     this.hyperplanes = hyperplanes;
/*    */   }
/*    */ 
/*    */   
/*    */   public ConvexPolytope(HyperPlane... hyperplanes) {
/* 57 */     this(Arrays.asList(hyperplanes));
/*    */   }
/*    */ 
/*    */   
/*    */   public Collection<? extends HyperPlane> getHyperplanes() {
/* 62 */     return this.hyperplanes;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static ConvexPolytope transform(ConvexPolytope polytope, AffineGet transform) {
/* 76 */     assert polytope.numDimensions() == transform.numDimensions();
/*    */     
/* 78 */     int n = transform.numDimensions();
/*    */     
/* 80 */     double[] O = new double[n];
/* 81 */     double[] tO = new double[n];
/* 82 */     double[] tN = new double[n];
/* 83 */     double[][] m = new double[n][n];
/* 84 */     for (int r = 0; r < n; r++) {
/* 85 */       for (int c = 0; c < n; c++)
/* 86 */         m[r][c] = transform.inverse().get(c, r); 
/*    */     } 
/* 88 */     ArrayList<HyperPlane> transformedPlanes = new ArrayList<>();
/* 89 */     for (HyperPlane plane : polytope.getHyperplanes()) {
/*    */       
/* 91 */       LinAlgHelpers.scale(plane.getNormal(), plane.getDistance(), O);
/* 92 */       transform.apply(O, tO);
/* 93 */       LinAlgHelpers.mult(m, plane.getNormal(), tN);
/* 94 */       LinAlgHelpers.normalize(tN);
/* 95 */       double td = LinAlgHelpers.dot(tN, tO);
/* 96 */       transformedPlanes.add(new HyperPlane(tN, td));
/*    */     } 
/* 98 */     return new ConvexPolytope(transformedPlanes);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/imglib2-algorithm-0.6.2.jar!/net/imglib2/algorithm/kdtree/ConvexPolytope.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */