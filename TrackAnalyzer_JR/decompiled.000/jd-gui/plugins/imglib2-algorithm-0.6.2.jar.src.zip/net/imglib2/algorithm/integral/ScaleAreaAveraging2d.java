/*     */ package net.imglib2.algorithm.integral;
/*     */ 
/*     */ import net.imglib2.Cursor;
/*     */ import net.imglib2.RandomAccess;
/*     */ import net.imglib2.RandomAccessibleInterval;
/*     */ import net.imglib2.algorithm.OutputAlgorithm;
/*     */ import net.imglib2.converter.Converter;
/*     */ import net.imglib2.converter.TypeIdentity;
/*     */ import net.imglib2.exception.IncompatibleTypeException;
/*     */ import net.imglib2.img.Img;
/*     */ import net.imglib2.img.ImgFactory;
/*     */ import net.imglib2.img.list.ListImgFactory;
/*     */ import net.imglib2.type.Type;
/*     */ import net.imglib2.type.numeric.RealType;
/*     */ import net.imglib2.view.Views;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ScaleAreaAveraging2d<T extends RealType<T>, R extends RealType<R>>
/*     */   implements OutputAlgorithm<Img<R>>
/*     */ {
/*     */   protected ImgFactory<R> imgFactory;
/*     */   protected Img<R> scaled;
/*     */   protected RandomAccessibleInterval<T> integralImg;
/*     */   protected String error;
/*     */   protected final long[] size;
/*     */   final R targetType;
/*     */   final Converter<T, R> converter;
/*     */   
/*     */   @Deprecated
/*     */   public ScaleAreaAveraging2d(Img<T> integralImg, R targetType, long[] size) {
/*  81 */     this((RandomAccessibleInterval<T>)integralImg, targetType, size, (ImgFactory<R>)null);
/*     */ 
/*     */     
/*     */     try {
/*  85 */       this.imgFactory = integralImg.factory().imgFactory(targetType);
/*     */     }
/*  87 */     catch (IncompatibleTypeException e) {
/*     */       
/*  89 */       this.imgFactory = (ImgFactory<R>)new ListImgFactory();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ScaleAreaAveraging2d(RandomAccessibleInterval<T> integralImg, R targetType, long[] size, ImgFactory<R> imgFactory) {
/* 104 */     this.size = size;
/* 105 */     this.targetType = targetType;
/* 106 */     this.integralImg = integralImg;
/* 107 */     this.imgFactory = imgFactory;
/*     */     
/* 109 */     if (targetType.getClass().isInstance(((RealType)Views.iterable(integralImg).firstElement()).createVariable())) {
/*     */ 
/*     */       
/* 112 */       this.converter = (Converter<T, R>)new TypeIdentity();
/*     */     }
/*     */     else {
/*     */       
/* 116 */       this.converter = new Converter<T, R>()
/*     */         {
/*     */           
/*     */           public void convert(T input, R output)
/*     */           {
/* 121 */             output.setReal(input.getRealDouble());
/*     */           }
/*     */         };
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public ScaleAreaAveraging2d(Img<T> integralImg, R targetType, Converter<T, R> converter, long[] size) {
/* 130 */     this((RandomAccessibleInterval<T>)integralImg, targetType, converter, size, null);
/*     */ 
/*     */     
/*     */     try {
/* 134 */       this.imgFactory = integralImg.factory().imgFactory(targetType);
/*     */     }
/* 136 */     catch (IncompatibleTypeException e) {
/*     */       
/* 138 */       this.imgFactory = (ImgFactory<R>)new ListImgFactory();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public ScaleAreaAveraging2d(RandomAccessibleInterval<T> integralImg, R targetType, Converter<T, R> converter, long[] size, ImgFactory<R> imgFactory) {
/* 144 */     this.size = size;
/* 145 */     this.targetType = targetType;
/* 146 */     this.integralImg = integralImg;
/* 147 */     this.converter = converter;
/* 148 */     this.imgFactory = imgFactory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setOutputDimensions(long width, long height) {
/* 160 */     this.size[0] = width;
/* 161 */     this.size[1] = height;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean checkInput() {
/* 167 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean process() {
/* 173 */     this.scaled = this.imgFactory.create(this.size, this.targetType);
/*     */     
/* 175 */     Cursor<R> cursor = this.scaled.cursor();
/* 176 */     RandomAccess<T> c2 = this.integralImg.randomAccess();
/*     */     
/* 178 */     RealType realType1 = (RealType)((RealType)Views.iterable(this.integralImg).firstElement()).createVariable();
/* 179 */     RealType realType2 = (RealType)realType1.createVariable();
/*     */     
/* 181 */     if (isIntegerDivision(this.integralImg, (RandomAccessibleInterval<?>)this.scaled)) {
/*     */       
/* 183 */       long stepSizeX = (this.integralImg.dimension(0) - 1L) / this.size[0];
/* 184 */       long stepSizeY = (this.integralImg.dimension(1) - 1L) / this.size[1];
/* 185 */       realType2.setReal((float)(stepSizeX * stepSizeY));
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 190 */       while (cursor.hasNext())
/*     */       {
/* 192 */         cursor.fwd();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 203 */         computeSum(cursor
/* 204 */             .getLongPosition(0) * stepSizeX, cursor
/* 205 */             .getLongPosition(1) * stepSizeY, stepSizeX, stepSizeY, c2, (T)realType1);
/*     */ 
/*     */ 
/*     */         
/* 209 */         realType1.div(realType2);
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 214 */         this.converter.convert(realType1, cursor.get());
/*     */       }
/*     */     
/*     */     } else {
/*     */       
/* 219 */       double stepSizeX = (this.integralImg.dimension(0) - 1.0D) / this.size[0];
/* 220 */       double stepSizeY = (this.integralImg.dimension(1) - 1.0D) / this.size[1];
/*     */       
/* 222 */       while (cursor.hasNext()) {
/*     */         
/* 224 */         cursor.fwd();
/*     */         
/* 226 */         long px = cursor.getLongPosition(0);
/* 227 */         long py = cursor.getLongPosition(1);
/*     */         
/* 229 */         double tmp1 = px * stepSizeX + 0.5D;
/* 230 */         long startX = (long)tmp1;
/* 231 */         long vX = (long)(tmp1 + stepSizeX) - startX;
/*     */         
/* 233 */         double tmp2 = py * stepSizeY + 0.5D;
/* 234 */         long startY = (long)tmp2;
/* 235 */         long vY = (long)(tmp2 + stepSizeY) - startY;
/*     */         
/* 237 */         realType2.setReal((float)(vX * vY));
/*     */         
/* 239 */         computeSum(startX, startY, vX, vY, c2, (T)realType1);
/*     */         
/* 241 */         realType1.div(realType2);
/*     */         
/* 243 */         this.converter.convert(realType1, cursor.get());
/*     */       } 
/*     */     } 
/*     */     
/* 247 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static final <T extends RealType<T>> void computeSum(long startX, long startY, long vX, long vY, RandomAccess<T> c2, T sum) {
/* 253 */     c2.setPosition(startX, 0);
/* 254 */     c2.setPosition(startY, 1);
/* 255 */     sum.set((Type)c2.get());
/*     */     
/* 257 */     c2.move(vX, 0);
/* 258 */     sum.sub(c2.get());
/*     */     
/* 260 */     c2.move(vY, 1);
/* 261 */     sum.add(c2.get());
/*     */     
/* 263 */     c2.move(-vX, 0);
/* 264 */     sum.sub(c2.get());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static final boolean isIntegerDivision(RandomAccessibleInterval<?> integralImg, RandomAccessibleInterval<?> scaled) {
/* 273 */     for (int d = 0; d < scaled.numDimensions(); d++) {
/* 274 */       if (0L != (integralImg.dimension(d) - 1L) % scaled.dimension(d))
/* 275 */         return false; 
/*     */     } 
/* 277 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getErrorMessage() {
/* 283 */     return this.error;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Img<R> getResult() {
/* 289 */     return this.scaled;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/imglib2-algorithm-0.6.2.jar!/net/imglib2/algorithm/integral/ScaleAreaAveraging2d.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */