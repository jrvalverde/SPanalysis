/*     */ package net.imglib2.algorithm.stats;
/*     */ 
/*     */ import net.imglib2.type.numeric.IntegerType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IntBinMapper<T extends IntegerType<T>>
/*     */   implements HistogramBinMapper<T>
/*     */ {
/*     */   private final T minType;
/*     */   private final T maxType;
/*     */   private final int numBins;
/*     */   private final int minVal;
/*     */   
/*     */   private static <R extends IntegerType<R>> R minType(R r) {
/*  63 */     IntegerType integerType = (IntegerType)r.createVariable();
/*  64 */     integerType.setReal(r.getMinValue());
/*  65 */     return (R)integerType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static <R extends IntegerType<R>> R maxType(R r) {
/*  80 */     IntegerType integerType = (IntegerType)r.createVariable();
/*  81 */     integerType.setReal(r.getMaxValue());
/*  82 */     return (R)integerType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IntBinMapper(T min, T max) {
/* 101 */     this.minType = min;
/* 102 */     this.maxType = max;
/* 103 */     this.numBins = max.getInteger() - min.getInteger() + 1;
/* 104 */     this.minVal = min.getInteger();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IntBinMapper(T type) {
/* 116 */     this(minType(type), maxType(type));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public T getMaxBin() {
/* 122 */     return this.maxType;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public T getMinBin() {
/* 128 */     return this.minType;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getNumBins() {
/* 134 */     return this.numBins;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public T invMap(int i) {
/* 140 */     IntegerType integerType = (IntegerType)this.minType.createVariable();
/* 141 */     integerType.setInteger(i + this.minVal);
/* 142 */     return (T)integerType;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int map(T type) {
/* 148 */     return type.getInteger() - this.minVal;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/imglib2-algorithm-0.6.2.jar!/net/imglib2/algorithm/stats/IntBinMapper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */