/*     */ package net.imglib2.algorithm.neighborhood;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import net.imglib2.AbstractEuclideanSpace;
/*     */ import net.imglib2.AbstractInterval;
/*     */ import net.imglib2.Cursor;
/*     */ import net.imglib2.FlatIterationOrder;
/*     */ import net.imglib2.Interval;
/*     */ import net.imglib2.IterableInterval;
/*     */ import net.imglib2.RandomAccess;
/*     */ import net.imglib2.RandomAccessible;
/*     */ import net.imglib2.RandomAccessibleInterval;
/*     */ import net.imglib2.RealCursor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DiamondShape
/*     */   implements Shape
/*     */ {
/*     */   private final long radius;
/*     */   
/*     */   public DiamondShape(long radius) {
/*  67 */     this.radius = radius;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> IterableInterval<Neighborhood<T>> neighborhoods(RandomAccessibleInterval<T> source) {
/*  73 */     return new NeighborhoodsIterableInterval<>(source, this.radius, DiamondNeighborhoodUnsafe.factory());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> NeighborhoodsAccessible<T> neighborhoodsRandomAccessible(RandomAccessible<T> source) {
/*  79 */     DiamondNeighborhoodFactory<T> f = DiamondNeighborhoodUnsafe.factory();
/*  80 */     return new NeighborhoodsAccessible<>(source, this.radius, f);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> NeighborhoodsIterableInterval<T> neighborhoodsSafe(RandomAccessibleInterval<T> source) {
/*  86 */     return new NeighborhoodsIterableInterval<>(source, this.radius, DiamondNeighborhood.factory());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> NeighborhoodsAccessible<T> neighborhoodsRandomAccessibleSafe(RandomAccessible<T> source) {
/*  92 */     return new NeighborhoodsAccessible<>(source, this.radius, DiamondNeighborhood.factory());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getRadius() {
/* 101 */     return this.radius;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 107 */     return "DiamondShape, radius = " + this.radius;
/*     */   }
/*     */ 
/*     */   
/*     */   public static final class NeighborhoodsIterableInterval<T>
/*     */     extends AbstractInterval
/*     */     implements IterableInterval<Neighborhood<T>>
/*     */   {
/*     */     final RandomAccessibleInterval<T> source;
/*     */     
/*     */     final DiamondNeighborhoodFactory<T> factory;
/*     */     final long size;
/*     */     private final long radius;
/*     */     
/*     */     public NeighborhoodsIterableInterval(RandomAccessibleInterval<T> source, long radius, DiamondNeighborhoodFactory<T> factory) {
/* 122 */       super((Interval)source);
/* 123 */       this.source = source;
/* 124 */       this.radius = radius;
/* 125 */       this.factory = factory;
/* 126 */       long s = source.dimension(0);
/* 127 */       for (int d = 1; d < this.n; d++)
/*     */       {
/* 129 */         s *= source.dimension(d);
/*     */       }
/* 131 */       this.size = s;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Cursor<Neighborhood<T>> cursor() {
/* 137 */       return new DiamondNeighborhoodCursor<>(this.source, this.radius, this.factory);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public long size() {
/* 143 */       return this.size;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Neighborhood<T> firstElement() {
/* 149 */       return (Neighborhood<T>)cursor().next();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Object iterationOrder() {
/* 155 */       return new FlatIterationOrder((Interval)this);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Cursor<Neighborhood<T>> localizingCursor() {
/* 161 */       return cursor();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Iterator<Neighborhood<T>> iterator() {
/* 167 */       return (Iterator<Neighborhood<T>>)cursor();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static final class NeighborhoodsAccessible<T>
/*     */     extends AbstractEuclideanSpace
/*     */     implements RandomAccessible<Neighborhood<T>>
/*     */   {
/*     */     final RandomAccessible<T> source;
/*     */     final DiamondNeighborhoodFactory<T> factory;
/*     */     private final long radius;
/*     */     
/*     */     public NeighborhoodsAccessible(RandomAccessible<T> source, long radius, DiamondNeighborhoodFactory<T> factory) {
/* 181 */       super(source.numDimensions());
/* 182 */       this.source = source;
/* 183 */       this.radius = radius;
/* 184 */       this.factory = factory;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public RandomAccess<Neighborhood<T>> randomAccess() {
/* 190 */       return new DiamondNeighborhoodRandomAccess<>(this.source, this.radius, this.factory);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public RandomAccess<Neighborhood<T>> randomAccess(Interval interval) {
/* 196 */       return randomAccess();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public int numDimensions() {
/* 202 */       return this.source.numDimensions();
/*     */     }
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/imglib2-algorithm-0.6.2.jar!/net/imglib2/algorithm/neighborhood/DiamondShape.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */