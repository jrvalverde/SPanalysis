/*     */ package net.imglib2.algorithm.morphology.table2d;
/*     */ 
/*     */ import net.imglib2.Cursor;
/*     */ import net.imglib2.Dimensions;
/*     */ import net.imglib2.Interval;
/*     */ import net.imglib2.IterableInterval;
/*     */ import net.imglib2.Localizable;
/*     */ import net.imglib2.RandomAccess;
/*     */ import net.imglib2.RandomAccessible;
/*     */ import net.imglib2.RandomAccessibleInterval;
/*     */ import net.imglib2.algorithm.neighborhood.Neighborhood;
/*     */ import net.imglib2.algorithm.neighborhood.RectangleShape;
/*     */ import net.imglib2.img.Img;
/*     */ import net.imglib2.type.BooleanType;
/*     */ import net.imglib2.type.Type;
/*     */ import net.imglib2.view.ExtendedRandomAccessibleInterval;
/*     */ import net.imglib2.view.Views;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Abstract3x3TableOperation
/*     */ {
/*  56 */   private static final RectangleShape shape = new RectangleShape(1, false);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract boolean[] getTable();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract boolean getExtendedValue();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected <T extends BooleanType<T>> Img<T> calculate(Img<T> source) {
/*  85 */     Img<T> target = source.factory().create((Dimensions)source, ((BooleanType)source.firstElement()).copy());
/*  86 */     BooleanType booleanType = (BooleanType)((BooleanType)source.firstElement()).createVariable();
/*  87 */     booleanType.set(getExtendedValue());
/*  88 */     ExtendedRandomAccessibleInterval<T, Img<T>> extended = Views.extendValue((RandomAccessibleInterval)source, (Type)booleanType);
/*  89 */     calculate((RandomAccessible)extended, (IterableInterval<T>)target);
/*  90 */     return target;
/*     */   }
/*     */ 
/*     */   
/*     */   protected <T extends BooleanType<T>> void calculate(RandomAccessible<T> source, IterableInterval<T> target) {
/*  95 */     RectangleShape.NeighborhoodsAccessible neighborhoodsAccessible = shape.neighborhoodsRandomAccessible(source);
/*  96 */     RandomAccess<Neighborhood<T>> randomAccess = neighborhoodsAccessible.randomAccess((Interval)target);
/*  97 */     Cursor<T> cursorTarget = target.cursor();
/*  98 */     boolean[] table = getTable();
/*  99 */     while (cursorTarget.hasNext()) {
/*     */       
/* 101 */       BooleanType booleanType = (BooleanType)cursorTarget.next();
/* 102 */       randomAccess.setPosition((Localizable)cursorTarget);
/* 103 */       Neighborhood<T> neighborhood = (Neighborhood<T>)randomAccess.get();
/* 104 */       Cursor<T> nc = neighborhood.cursor();
/* 105 */       int idx = 0;
/*     */ 
/*     */       
/* 108 */       while (nc.hasNext()) {
/*     */         
/* 110 */         idx <<= 1;
/* 111 */         idx |= ((BooleanType)nc.next()).get() ? 1 : 0;
/*     */       } 
/*     */       
/* 114 */       booleanType.set(table[idx]);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/imglib2-algorithm-0.6.2.jar!/net/imglib2/algorithm/morphology/table2d/Abstract3x3TableOperation.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */