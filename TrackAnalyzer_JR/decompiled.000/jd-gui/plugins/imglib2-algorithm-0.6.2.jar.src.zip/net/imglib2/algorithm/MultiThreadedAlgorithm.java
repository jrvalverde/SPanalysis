/*    */ package net.imglib2.algorithm;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class MultiThreadedAlgorithm
/*    */   implements MultiThreaded, Algorithm
/*    */ {
/*    */   protected int numThreads;
/* 52 */   protected String errorMessage = "";
/*    */ 
/*    */   
/*    */   public MultiThreadedAlgorithm() {
/* 56 */     setNumThreads();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void setNumThreads() {
/* 62 */     this.numThreads = Runtime.getRuntime().availableProcessors();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void setNumThreads(int numThreads) {
/* 68 */     this.numThreads = numThreads;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public int getNumThreads() {
/* 74 */     return this.numThreads;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String getErrorMessage() {
/* 80 */     return this.errorMessage;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/imglib2-algorithm-0.6.2.jar!/net/imglib2/algorithm/MultiThreadedAlgorithm.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */