/*     */ package net.imglib2.algorithm.neighborhood;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import net.imglib2.AbstractEuclideanSpace;
/*     */ import net.imglib2.AbstractLocalizable;
/*     */ import net.imglib2.Cursor;
/*     */ import net.imglib2.Interval;
/*     */ import net.imglib2.Positionable;
/*     */ import net.imglib2.RandomAccess;
/*     */ import net.imglib2.RealCursor;
/*     */ import net.imglib2.RealPositionable;
/*     */ import net.imglib2.Sampler;
/*     */ import net.imglib2.util.Intervals;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DiamondTipsNeighborhood<T>
/*     */   extends AbstractLocalizable
/*     */   implements Neighborhood<T>
/*     */ {
/*     */   private final long radius;
/*     */   private final RandomAccess<T> sourceRandomAccess;
/*     */   private final Interval structuringElementBoundingBox;
/*     */   
/*     */   public static <T> DiamondTipsNeighborhoodFactory<T> factory() {
/*  62 */     return new DiamondTipsNeighborhoodFactory<T>()
/*     */       {
/*     */         
/*     */         public DiamondTipsNeighborhood<T> create(long[] position, long radius, RandomAccess<T> sourceRandomAccess)
/*     */         {
/*  67 */           return new DiamondTipsNeighborhood<>(position, radius, sourceRandomAccess);
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DiamondTipsNeighborhood(long[] position, long radius, RandomAccess<T> sourceRandomAccess) {
/*  90 */     super(position);
/*  91 */     this.radius = radius;
/*  92 */     this.sourceRandomAccess = sourceRandomAccess;
/*  93 */     this.structuringElementBoundingBox = createInterval();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public LocalCursor cursor() {
/*  99 */     return new LocalCursor(this.sourceRandomAccess.copyRandomAccess());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public LocalCursor localizingCursor() {
/* 105 */     return cursor();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public long size() {
/* 111 */     return (this.sourceRandomAccess.numDimensions() * 2);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public T firstElement() {
/* 117 */     return cursor().next();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object iterationOrder() {
/* 123 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public double realMin(int d) {
/* 129 */     return (this.position[d] - this.radius);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void realMin(double[] min) {
/* 135 */     for (int d = 0; d < min.length; d++)
/*     */     {
/* 137 */       min[d] = (this.position[d] - this.radius);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void realMin(RealPositionable min) {
/* 144 */     for (int d = 0; d < this.position.length; d++)
/*     */     {
/* 146 */       min.setPosition(this.position[d] - this.radius, d);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public double realMax(int d) {
/* 153 */     return (this.position[d] + this.radius);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void realMax(double[] max) {
/* 159 */     for (int d = 0; d < max.length; d++)
/*     */     {
/* 161 */       max[d] = (this.position[d] + this.radius);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void realMax(RealPositionable max) {
/* 168 */     for (int d = 0; d < this.position.length; d++)
/*     */     {
/* 170 */       max.setPosition(this.position[d] + this.radius, d);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Iterator<T> iterator() {
/* 177 */     return (Iterator<T>)cursor();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public long min(int d) {
/* 183 */     return this.position[d] - this.radius;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void min(long[] min) {
/* 189 */     for (int d = 0; d < min.length; d++)
/*     */     {
/* 191 */       min[d] = this.position[d] - this.radius;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void min(Positionable min) {
/* 198 */     for (int d = 0; d < this.position.length; d++)
/*     */     {
/* 200 */       min.setPosition(this.position[d] - this.radius, d);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public long max(int d) {
/* 207 */     return this.position[d] + this.radius;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void max(long[] max) {
/* 213 */     for (int d = 0; d < max.length; d++)
/*     */     {
/* 215 */       max[d] = this.position[d] + this.radius;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void max(Positionable max) {
/* 222 */     for (int d = 0; d < this.position.length; d++)
/*     */     {
/* 224 */       max.setPosition(this.position[d] + this.radius, d);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void dimensions(long[] dimensions) {
/* 231 */     for (int d = 0; d < dimensions.length; d++)
/*     */     {
/* 233 */       dimensions[d] = 2L * this.radius + 1L;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public long dimension(int d) {
/* 240 */     return 2L * this.radius + 1L;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Interval getStructuringElementBoundingBox() {
/* 246 */     return this.structuringElementBoundingBox;
/*     */   }
/*     */ 
/*     */   
/*     */   public final class LocalCursor
/*     */     extends AbstractEuclideanSpace
/*     */     implements Cursor<T>
/*     */   {
/*     */     private final RandomAccess<T> source;
/*     */     private int currentDim;
/*     */     private boolean parity;
/*     */     
/*     */     public LocalCursor(RandomAccess<T> source) {
/* 259 */       super(source.numDimensions());
/* 260 */       this.source = source;
/* 261 */       reset();
/*     */     }
/*     */ 
/*     */     
/*     */     protected LocalCursor(LocalCursor c) {
/* 266 */       super(c.numDimensions());
/* 267 */       this.source = c.source.copyRandomAccess();
/* 268 */       this.currentDim = c.currentDim;
/* 269 */       this.parity = c.parity;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public T get() {
/* 275 */       return (T)this.source.get();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void fwd() {
/* 281 */       if (!this.parity) {
/*     */         
/* 283 */         if (this.currentDim >= 0)
/*     */         {
/* 285 */           this.source.setPosition(DiamondTipsNeighborhood.this.position[this.currentDim], this.currentDim);
/*     */         }
/* 287 */         this.currentDim++;
/* 288 */         this.source.move(-DiamondTipsNeighborhood.this.radius, this.currentDim);
/* 289 */         this.parity = true;
/*     */       }
/*     */       else {
/*     */         
/* 293 */         this.source.move(2L * DiamondTipsNeighborhood.this.radius, this.currentDim);
/* 294 */         this.parity = false;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void jumpFwd(long steps) {
/* 302 */       for (int i = 0; i < steps; i++)
/*     */       {
/* 304 */         fwd();
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public T next() {
/* 311 */       fwd();
/* 312 */       return get();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void remove() {}
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void reset() {
/* 324 */       this.source.setPosition(DiamondTipsNeighborhood.this.position);
/* 325 */       this.currentDim = -1;
/* 326 */       this.parity = false;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean hasNext() {
/* 332 */       return (this.currentDim < this.source.numDimensions() - 1 || this.parity);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public float getFloatPosition(int d) {
/* 338 */       return this.source.getFloatPosition(d);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public double getDoublePosition(int d) {
/* 344 */       return this.source.getDoublePosition(d);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public int getIntPosition(int d) {
/* 350 */       return this.source.getIntPosition(d);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public long getLongPosition(int d) {
/* 356 */       return this.source.getLongPosition(d);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void localize(long[] position) {
/* 362 */       this.source.localize(position);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void localize(float[] position) {
/* 368 */       this.source.localize(position);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void localize(double[] position) {
/* 374 */       this.source.localize(position);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void localize(int[] position) {
/* 380 */       this.source.localize(position);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public LocalCursor copy() {
/* 386 */       return new LocalCursor(this);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public LocalCursor copyCursor() {
/* 392 */       return copy();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private Interval createInterval() {
/* 398 */     long[] minmax = new long[2 * this.position.length]; int i;
/* 399 */     for (i = 0; i < this.position.length; i++)
/*     */     {
/* 401 */       minmax[i] = this.position[i] - this.radius;
/*     */     }
/* 403 */     for (i = this.position.length; i < minmax.length; i++)
/*     */     {
/* 405 */       minmax[i] = this.position[i - this.position.length] + this.radius;
/*     */     }
/* 407 */     return (Interval)Intervals.createMinMax(minmax);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/imglib2-algorithm-0.6.2.jar!/net/imglib2/algorithm/neighborhood/DiamondTipsNeighborhood.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */