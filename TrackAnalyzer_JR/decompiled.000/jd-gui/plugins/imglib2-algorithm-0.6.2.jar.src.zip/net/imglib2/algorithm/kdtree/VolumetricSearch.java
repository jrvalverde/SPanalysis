/*     */ package net.imglib2.algorithm.kdtree;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Stack;
/*     */ import net.imglib2.Interval;
/*     */ import net.imglib2.KDTree;
/*     */ import net.imglib2.KDTreeNode;
/*     */ import net.imglib2.Localizable;
/*     */ import net.imglib2.Point;
/*     */ import net.imglib2.RandomAccess;
/*     */ import net.imglib2.RandomAccessible;
/*     */ import net.imglib2.RealInterval;
/*     */ import net.imglib2.RealLocalizable;
/*     */ import net.imglib2.Sampler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class VolumetricSearch<I extends RealInterval>
/*     */   implements RandomAccessible<List<I>>
/*     */ {
/*     */   final int numDimensions;
/*     */   final KDTree<IntervalWrapper<I>> kdtree;
/*     */   
/*     */   public VolumetricSearch(List<I> intervals) {
/*  71 */     if (intervals.isEmpty()) {
/*     */       
/*  73 */       this.numDimensions = 0;
/*     */     }
/*     */     else {
/*     */       
/*  77 */       this.numDimensions = ((RealInterval)intervals.get(0)).numDimensions();
/*     */     } 
/*  79 */     ArrayList<IntervalWrapper<I>> wrappers = new ArrayList<>(intervals.size());
/*  80 */     for (RealInterval realInterval : intervals)
/*  81 */       wrappers.add(new IntervalWrapper<>((I)realInterval)); 
/*  82 */     this.kdtree = new KDTree(wrappers, wrappers);
/*     */   }
/*     */ 
/*     */   
/*     */   private static class IntervalWrapper<I extends RealInterval>
/*     */     implements RealLocalizable
/*     */   {
/*     */     final I interval;
/*     */     final int n;
/*     */     
/*     */     public IntervalWrapper(I interval) {
/*  93 */       this.interval = interval;
/*  94 */       this.n = interval.numDimensions();
/*     */     }
/*     */ 
/*     */     
/*     */     public I get() {
/*  99 */       return this.interval;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public int numDimensions() {
/* 105 */       return 2 * this.n;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void localize(float[] position) {
/* 111 */       for (int d = 0; d < this.n; d++) {
/*     */         
/* 113 */         position[d] = (float)this.interval.realMin(d);
/* 114 */         position[d + this.n] = (float)this.interval.realMax(d);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void localize(double[] position) {
/* 121 */       for (int d = 0; d < this.n; d++) {
/*     */         
/* 123 */         position[d] = this.interval.realMin(d);
/* 124 */         position[d + this.n] = this.interval.realMax(d);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public float getFloatPosition(int d) {
/* 131 */       return (float)getDoublePosition(d);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public double getDoublePosition(int d) {
/* 137 */       return (d < this.n) ? this.interval.realMin(d) : this.interval.realMax(d - this.n);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<I> find(RealLocalizable pt) {
/* 151 */     double[] position = new double[this.numDimensions];
/* 152 */     pt.localize(position);
/* 153 */     LinkedList<I> list = new LinkedList<>();
/* 154 */     if (this.kdtree.getRoot() == null) {
/* 155 */       return list;
/*     */     }
/* 157 */     Stack<KDTreeNode<IntervalWrapper<I>>> toDo = new Stack<>();
/* 158 */     toDo.push(this.kdtree.getRoot());
/* 159 */     while (toDo.size() > 0) {
/*     */       
/* 161 */       KDTreeNode<IntervalWrapper<I>> node = toDo.pop();
/* 162 */       int k = node.getSplitDimension();
/*     */ 
/*     */       
/* 165 */       I interval = ((IntervalWrapper<I>)node.get()).get();
/* 166 */       boolean good = true;
/* 167 */       for (int i = 0; i < this.numDimensions; i++) {
/*     */         
/* 169 */         if (position[i] < interval.realMin(i) || position[i] > interval.realMax(i)) {
/*     */           
/* 171 */           good = false;
/*     */           break;
/*     */         } 
/*     */       } 
/* 175 */       if (good) {
/* 176 */         list.add(interval);
/*     */       }
/*     */       
/* 179 */       if (k < this.numDimensions) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 186 */         if (node.left != null)
/* 187 */           toDo.push(node.left); 
/* 188 */         if (node.right != null && node.getSplitCoordinate() <= position[k]) {
/* 189 */           toDo.push(node.right);
/*     */         }
/*     */ 
/*     */ 
/*     */         
/*     */         continue;
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 199 */       if (node.right != null)
/* 200 */         toDo.push(node.right); 
/* 201 */       if (node.left != null && node.getSplitCoordinate() >= position[k - this.numDimensions]) {
/* 202 */         toDo.push(node.left);
/*     */       }
/*     */     } 
/*     */     
/* 206 */     return list;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int numDimensions() {
/* 212 */     return this.numDimensions;
/*     */   }
/*     */   
/*     */   private class VolumetricSearchRandomAccess
/*     */     extends Point
/*     */     implements RandomAccess<List<I>> {
/*     */     VolumetricSearchRandomAccess() {
/* 219 */       super(VolumetricSearch.this.numDimensions);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public List<I> get() {
/* 225 */       return VolumetricSearch.this.find((RealLocalizable)this);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public VolumetricSearchRandomAccess copy() {
/* 231 */       VolumetricSearchRandomAccess myCopy = new VolumetricSearchRandomAccess();
/* 232 */       myCopy.setPosition((Localizable)this);
/* 233 */       return myCopy;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public VolumetricSearchRandomAccess copyRandomAccess() {
/* 239 */       return copy();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public RandomAccess<List<I>> randomAccess() {
/* 246 */     return new VolumetricSearchRandomAccess();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public RandomAccess<List<I>> randomAccess(Interval interval) {
/* 252 */     return randomAccess();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/imglib2-algorithm-0.6.2.jar!/net/imglib2/algorithm/kdtree/VolumetricSearch.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */