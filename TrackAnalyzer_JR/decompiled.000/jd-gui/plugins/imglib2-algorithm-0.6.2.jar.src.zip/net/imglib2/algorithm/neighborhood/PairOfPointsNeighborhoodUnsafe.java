/*    */ package net.imglib2.algorithm.neighborhood;
/*    */ 
/*    */ import net.imglib2.Cursor;
/*    */ import net.imglib2.RandomAccess;
/*    */ import net.imglib2.RealCursor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PairOfPointsNeighborhoodUnsafe<T>
/*    */   extends PairOfPointsNeighborhood<T>
/*    */ {
/*    */   private final PairOfPointsNeighborhood<T>.LocalCursor theCursor;
/*    */   private final PairOfPointsNeighborhood<T>.LocalCursor firstElementCursor;
/*    */   
/*    */   public static <T> PairOfPointsNeighborhoodFactory<T> factory() {
/* 43 */     return new PairOfPointsNeighborhoodFactory<T>()
/*    */       {
/*    */         
/*    */         public Neighborhood<T> create(long[] position, long[] offset, RandomAccess<T> sourceRandomAccess)
/*    */         {
/* 48 */           return new PairOfPointsNeighborhoodUnsafe<>(position, offset, sourceRandomAccess);
/*    */         }
/*    */       };
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   PairOfPointsNeighborhoodUnsafe(long[] position, long[] offset, RandomAccess<T> sourceRandomAccess) {
/* 59 */     super(position, offset, sourceRandomAccess);
/* 60 */     this.theCursor = super.cursor();
/* 61 */     this.firstElementCursor = super.cursor();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public T firstElement() {
/* 67 */     this.firstElementCursor.reset();
/* 68 */     return this.firstElementCursor.next();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public PairOfPointsNeighborhood<T>.LocalCursor cursor() {
/* 74 */     this.theCursor.reset();
/* 75 */     return this.theCursor;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/imglib2-algorithm-0.6.2.jar!/net/imglib2/algorithm/neighborhood/PairOfPointsNeighborhoodUnsafe.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */