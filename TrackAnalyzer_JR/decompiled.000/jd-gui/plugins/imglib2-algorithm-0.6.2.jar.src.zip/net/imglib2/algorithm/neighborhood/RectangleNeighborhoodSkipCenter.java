/*     */ package net.imglib2.algorithm.neighborhood;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import net.imglib2.AbstractEuclideanSpace;
/*     */ import net.imglib2.AbstractLocalizable;
/*     */ import net.imglib2.Cursor;
/*     */ import net.imglib2.Interval;
/*     */ import net.imglib2.Positionable;
/*     */ import net.imglib2.RandomAccess;
/*     */ import net.imglib2.RealCursor;
/*     */ import net.imglib2.RealPositionable;
/*     */ import net.imglib2.Sampler;
/*     */ import net.imglib2.util.IntervalIndexer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RectangleNeighborhoodSkipCenter<T>
/*     */   extends AbstractLocalizable
/*     */   implements Neighborhood<T>
/*     */ {
/*     */   private final long[] currentMin;
/*     */   private final long[] currentMax;
/*     */   private final long[] dimensions;
/*     */   private final RandomAccess<T> sourceRandomAccess;
/*     */   private final Interval structuringElementBoundingBox;
/*     */   private final long maxIndex;
/*     */   private final long midIndex;
/*     */   
/*     */   public static <T> RectangleNeighborhoodFactory<T> factory() {
/*  52 */     return new RectangleNeighborhoodFactory<T>()
/*     */       {
/*     */         
/*     */         public Neighborhood<T> create(long[] position, long[] currentMin, long[] currentMax, Interval span, RandomAccess<T> sourceRandomAccess)
/*     */         {
/*  57 */           return new RectangleNeighborhoodSkipCenter<>(position, currentMin, currentMax, span, sourceRandomAccess);
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   RectangleNeighborhoodSkipCenter(long[] position, long[] currentMin, long[] currentMax, Interval span, RandomAccess<T> sourceRandomAccess) {
/*  78 */     super(position);
/*  79 */     this.currentMin = currentMin;
/*  80 */     this.currentMax = currentMax;
/*  81 */     this.dimensions = new long[this.n];
/*  82 */     span.dimensions(this.dimensions);
/*     */     
/*  84 */     long mi = this.dimensions[0];
/*  85 */     for (int d = 1; d < this.n; d++)
/*  86 */       mi *= this.dimensions[d]; 
/*  87 */     this.maxIndex = mi;
/*     */     
/*  89 */     long[] centerOffset = new long[this.n];
/*  90 */     for (int i = 0; i < this.n; i++)
/*  91 */       centerOffset[i] = -span.min(i); 
/*  92 */     this.midIndex = IntervalIndexer.positionToIndex(centerOffset, this.dimensions) + 1L;
/*     */     
/*  94 */     this.sourceRandomAccess = sourceRandomAccess;
/*  95 */     this.structuringElementBoundingBox = span;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Interval getStructuringElementBoundingBox() {
/* 101 */     return this.structuringElementBoundingBox;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public long size() {
/* 107 */     return this.maxIndex - 1L;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public T firstElement() {
/* 113 */     return cursor().next();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object iterationOrder() {
/* 119 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public double realMin(int d) {
/* 125 */     return this.currentMin[d];
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void realMin(double[] min) {
/* 131 */     for (int d = 0; d < this.n; d++) {
/* 132 */       min[d] = this.currentMin[d];
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void realMin(RealPositionable min) {
/* 138 */     for (int d = 0; d < this.n; d++) {
/* 139 */       min.setPosition(this.currentMin[d], d);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public double realMax(int d) {
/* 145 */     return this.currentMax[d];
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void realMax(double[] max) {
/* 151 */     for (int d = 0; d < this.n; d++) {
/* 152 */       max[d] = this.currentMax[d];
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void realMax(RealPositionable max) {
/* 158 */     for (int d = 0; d < this.n; d++) {
/* 159 */       max.setPosition(this.currentMax[d], d);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public Iterator<T> iterator() {
/* 165 */     return (Iterator<T>)cursor();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public long min(int d) {
/* 171 */     return this.currentMin[d];
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void min(long[] min) {
/* 177 */     for (int d = 0; d < this.n; d++) {
/* 178 */       min[d] = this.currentMin[d];
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void min(Positionable min) {
/* 184 */     for (int d = 0; d < this.n; d++) {
/* 185 */       min.setPosition(this.currentMin[d], d);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public long max(int d) {
/* 191 */     return this.currentMax[d];
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void max(long[] max) {
/* 197 */     for (int d = 0; d < this.n; d++) {
/* 198 */       max[d] = this.currentMax[d];
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void max(Positionable max) {
/* 204 */     for (int d = 0; d < this.n; d++) {
/* 205 */       max.setPosition(this.currentMax[d], d);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void dimensions(long[] dimensions) {
/* 211 */     for (int d = 0; d < this.n; d++) {
/* 212 */       dimensions[d] = this.dimensions[d];
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public long dimension(int d) {
/* 218 */     return this.dimensions[d];
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public LocalCursor cursor() {
/* 224 */     return new LocalCursor(this.sourceRandomAccess.copyRandomAccess());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public LocalCursor localizingCursor() {
/* 230 */     return cursor();
/*     */   }
/*     */ 
/*     */   
/*     */   public final class LocalCursor
/*     */     extends AbstractEuclideanSpace
/*     */     implements Cursor<T>
/*     */   {
/*     */     private final RandomAccess<T> source;
/*     */     private long index;
/*     */     private long maxIndexOnLine;
/*     */     
/*     */     public LocalCursor(RandomAccess<T> source) {
/* 243 */       super(source.numDimensions());
/* 244 */       this.source = source;
/* 245 */       reset();
/*     */     }
/*     */ 
/*     */     
/*     */     protected LocalCursor(LocalCursor c) {
/* 250 */       super(c.numDimensions());
/* 251 */       this.source = c.source.copyRandomAccess();
/* 252 */       this.index = c.index;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public T get() {
/* 258 */       return (T)this.source.get();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void fwd() {
/* 264 */       this.source.fwd(0);
/* 265 */       if (++this.index > this.maxIndexOnLine)
/* 266 */         nextLine(); 
/* 267 */       if (this.index == RectangleNeighborhoodSkipCenter.this.midIndex) {
/* 268 */         fwd();
/*     */       }
/*     */     }
/*     */     
/*     */     private void nextLine() {
/* 273 */       this.source.setPosition(RectangleNeighborhoodSkipCenter.this.currentMin[0], 0);
/* 274 */       this.maxIndexOnLine += RectangleNeighborhoodSkipCenter.this.dimensions[0];
/* 275 */       for (int d = 1; d < this.n; ) {
/*     */         
/* 277 */         this.source.fwd(d);
/* 278 */         if (this.source.getLongPosition(d) > RectangleNeighborhoodSkipCenter.this.currentMax[d]) {
/* 279 */           this.source.setPosition(RectangleNeighborhoodSkipCenter.this.currentMin[d], d);
/*     */           d++;
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void jumpFwd(long steps) {
/* 288 */       for (long i = 0L; i < steps; i++) {
/* 289 */         fwd();
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public T next() {
/* 295 */       fwd();
/* 296 */       return get();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void remove() {}
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void reset() {
/* 308 */       this.source.setPosition(RectangleNeighborhoodSkipCenter.this.currentMin);
/* 309 */       this.source.bck(0);
/* 310 */       this.index = 0L;
/* 311 */       this.maxIndexOnLine = RectangleNeighborhoodSkipCenter.this.dimensions[0];
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean hasNext() {
/* 317 */       return (this.index < RectangleNeighborhoodSkipCenter.this.maxIndex);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public float getFloatPosition(int d) {
/* 323 */       return this.source.getFloatPosition(d);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public double getDoublePosition(int d) {
/* 329 */       return this.source.getDoublePosition(d);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public int getIntPosition(int d) {
/* 335 */       return this.source.getIntPosition(d);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public long getLongPosition(int d) {
/* 341 */       return this.source.getLongPosition(d);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void localize(long[] position) {
/* 347 */       this.source.localize(position);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void localize(float[] position) {
/* 353 */       this.source.localize(position);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void localize(double[] position) {
/* 359 */       this.source.localize(position);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void localize(int[] position) {
/* 365 */       this.source.localize(position);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public LocalCursor copy() {
/* 371 */       return new LocalCursor(this);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public LocalCursor copyCursor() {
/* 377 */       return copy();
/*     */     }
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/imglib2-algorithm-0.6.2.jar!/net/imglib2/algorithm/neighborhood/RectangleNeighborhoodSkipCenter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */