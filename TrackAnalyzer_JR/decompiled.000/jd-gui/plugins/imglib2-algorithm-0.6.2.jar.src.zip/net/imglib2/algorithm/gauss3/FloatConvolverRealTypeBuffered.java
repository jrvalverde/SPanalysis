/*     */ package net.imglib2.algorithm.gauss3;
/*     */ 
/*     */ import net.imglib2.RandomAccess;
/*     */ import net.imglib2.type.numeric.RealType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class FloatConvolverRealTypeBuffered<S extends RealType<S>, T extends RealType<T>>
/*     */   implements Runnable
/*     */ {
/*     */   private final float[] kernel;
/*     */   private final RandomAccess<S> in;
/*     */   private final RandomAccess<T> out;
/*     */   private final int d;
/*     */   private final int k;
/*     */   private final int k1;
/*     */   private final int k1k1;
/*     */   private final int buflen;
/*     */   private final float[] buf;
/*     */   
/*     */   public static <S extends RealType<S>, T extends RealType<T>> ConvolverFactory<S, T> factory() {
/*  63 */     return new ConvolverFactory<S, T>()
/*     */       {
/*     */         
/*     */         public Runnable create(double[] halfkernel, RandomAccess<S> in, RandomAccess<T> out, int d, long lineLength)
/*     */         {
/*  68 */           return new FloatConvolverRealTypeBuffered<>(halfkernel, in, out, d, lineLength);
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private FloatConvolverRealTypeBuffered(double[] kernel, RandomAccess<S> in, RandomAccess<T> out, int d, long lineLength) {
/*  93 */     this.kernel = new float[kernel.length];
/*  94 */     for (int i = 0; i < kernel.length; i++)
/*  95 */       this.kernel[i] = (float)kernel[i]; 
/*  96 */     this.in = in;
/*  97 */     this.out = out;
/*  98 */     this.d = d;
/*     */     
/* 100 */     this.k = this.kernel.length;
/* 101 */     this.k1 = this.k - 1;
/* 102 */     this.k1k1 = this.k1 + this.k1;
/*     */     
/* 104 */     this.buflen = (int)lineLength + 2 * this.k1k1;
/* 105 */     this.buf = new float[this.buflen];
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void run() {
/* 111 */     int max = this.buflen - this.k1;
/* 112 */     for (int i = this.k1; i < max; i++) {
/*     */       
/* 114 */       float w = ((RealType)this.in.get()).getRealFloat();
/*     */ 
/*     */       
/* 117 */       this.buf[i] = this.buf[i] + w * this.kernel[0];
/*     */ 
/*     */       
/* 120 */       for (int j = 1; j < this.k1; j++) {
/*     */         
/* 122 */         float f = w * this.kernel[j];
/* 123 */         this.buf[i + j] = this.buf[i + j] + f;
/* 124 */         this.buf[i - j] = this.buf[i - j] + f;
/*     */       } 
/*     */ 
/*     */       
/* 128 */       float wk = w * this.kernel[this.k1];
/* 129 */       this.buf[i - this.k1] = this.buf[i - this.k1] + wk;
/* 130 */       this.buf[i + this.k1] = wk;
/*     */       
/* 132 */       this.in.fwd(this.d);
/*     */     } 
/*     */     
/* 135 */     writeLine();
/*     */   }
/*     */ 
/*     */   
/*     */   private void writeLine() {
/* 140 */     int max = this.buflen - this.k1k1;
/* 141 */     for (int i = this.k1k1; i < max; i++) {
/*     */       
/* 143 */       ((RealType)this.out.get()).setReal(this.buf[i]);
/* 144 */       this.out.fwd(this.d);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/imglib2-algorithm-0.6.2.jar!/net/imglib2/algorithm/gauss3/FloatConvolverRealTypeBuffered.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */