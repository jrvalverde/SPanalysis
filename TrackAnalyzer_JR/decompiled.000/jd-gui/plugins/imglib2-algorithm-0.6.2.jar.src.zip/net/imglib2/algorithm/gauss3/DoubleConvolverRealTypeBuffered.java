/*     */ package net.imglib2.algorithm.gauss3;
/*     */ 
/*     */ import net.imglib2.RandomAccess;
/*     */ import net.imglib2.type.numeric.RealType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class DoubleConvolverRealTypeBuffered<S extends RealType<S>, T extends RealType<T>>
/*     */   implements Runnable
/*     */ {
/*     */   private final double[] kernel;
/*     */   private final RandomAccess<S> in;
/*     */   private final RandomAccess<T> out;
/*     */   private final int d;
/*     */   private final int k;
/*     */   private final int k1;
/*     */   private final int k1k1;
/*     */   private final int buflen;
/*     */   private final double[] buf;
/*     */   
/*     */   public static <S extends RealType<S>, T extends RealType<T>> ConvolverFactory<S, T> factory() {
/*  63 */     return new ConvolverFactory<S, T>()
/*     */       {
/*     */         
/*     */         public Runnable create(double[] halfkernel, RandomAccess<S> in, RandomAccess<T> out, int d, long lineLength)
/*     */         {
/*  68 */           return new DoubleConvolverRealTypeBuffered<>(halfkernel, in, out, d, lineLength);
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private DoubleConvolverRealTypeBuffered(double[] kernel, RandomAccess<S> in, RandomAccess<T> out, int d, long lineLength) {
/*  93 */     this.kernel = kernel;
/*  94 */     this.in = in;
/*  95 */     this.out = out;
/*  96 */     this.d = d;
/*     */     
/*  98 */     this.k = this.kernel.length;
/*  99 */     this.k1 = this.k - 1;
/* 100 */     this.k1k1 = this.k1 + this.k1;
/*     */     
/* 102 */     this.buflen = (int)lineLength + 2 * this.k1k1;
/* 103 */     this.buf = new double[this.buflen];
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void run() {
/* 109 */     int max = this.buflen - this.k1;
/* 110 */     for (int i = this.k1; i < max; i++) {
/*     */       
/* 112 */       double w = ((RealType)this.in.get()).getRealDouble();
/*     */ 
/*     */       
/* 115 */       this.buf[i] = this.buf[i] + w * this.kernel[0];
/*     */ 
/*     */       
/* 118 */       for (int j = 1; j < this.k1; j++) {
/*     */         
/* 120 */         double d = w * this.kernel[j];
/* 121 */         this.buf[i + j] = this.buf[i + j] + d;
/* 122 */         this.buf[i - j] = this.buf[i - j] + d;
/*     */       } 
/*     */ 
/*     */       
/* 126 */       double wk = w * this.kernel[this.k1];
/* 127 */       this.buf[i - this.k1] = this.buf[i - this.k1] + wk;
/* 128 */       this.buf[i + this.k1] = wk;
/*     */       
/* 130 */       this.in.fwd(this.d);
/*     */     } 
/*     */     
/* 133 */     writeLine();
/*     */   }
/*     */ 
/*     */   
/*     */   private void writeLine() {
/* 138 */     int max = this.buflen - this.k1k1;
/* 139 */     for (int i = this.k1k1; i < max; i++) {
/*     */       
/* 141 */       ((RealType)this.out.get()).setReal(this.buf[i]);
/* 142 */       this.out.fwd(this.d);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/imglib2-algorithm-0.6.2.jar!/net/imglib2/algorithm/gauss3/DoubleConvolverRealTypeBuffered.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */