/*     */ package net.imglib2.algorithm.neighborhood;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import net.imglib2.AbstractEuclideanSpace;
/*     */ import net.imglib2.AbstractLocalizable;
/*     */ import net.imglib2.Cursor;
/*     */ import net.imglib2.Interval;
/*     */ import net.imglib2.Positionable;
/*     */ import net.imglib2.RandomAccess;
/*     */ import net.imglib2.RealCursor;
/*     */ import net.imglib2.RealPositionable;
/*     */ import net.imglib2.Sampler;
/*     */ import net.imglib2.util.Intervals;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HorizontalLineNeighborhood<T>
/*     */   extends AbstractLocalizable
/*     */   implements Neighborhood<T>
/*     */ {
/*     */   private final long span;
/*     */   private final int dim;
/*     */   private final RandomAccess<T> sourceRandomAccess;
/*     */   private final Interval structuringElementBoundingBox;
/*     */   private final long maxIndex;
/*     */   private final boolean skipCenter;
/*     */   
/*     */   public static <T> HorizontalLineNeighborhoodFactory<T> factory() {
/*  52 */     return new HorizontalLineNeighborhoodFactory<T>()
/*     */       {
/*     */         
/*     */         public Neighborhood<T> create(long[] position, long span, int dim, boolean skipCenter, RandomAccess<T> sourceRandomAccess)
/*     */         {
/*  57 */           return new HorizontalLineNeighborhood<>(position, span, dim, skipCenter, sourceRandomAccess);
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   HorizontalLineNeighborhood(long[] position, long span, int dim, boolean skipCenter, RandomAccess<T> sourceRandomAccess) {
/*  84 */     super(position);
/*  85 */     this.skipCenter = skipCenter;
/*  86 */     if (skipCenter) {
/*     */       
/*  88 */       this.maxIndex = 2L * span;
/*     */     }
/*     */     else {
/*     */       
/*  92 */       this.maxIndex = 2L * span + 1L;
/*     */     } 
/*  94 */     this.span = span;
/*  95 */     this.dim = dim;
/*  96 */     this.sourceRandomAccess = sourceRandomAccess;
/*  97 */     this.structuringElementBoundingBox = createInterval();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Interval getStructuringElementBoundingBox() {
/* 103 */     return this.structuringElementBoundingBox;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public long size() {
/* 109 */     return this.maxIndex;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public T firstElement() {
/* 115 */     return cursor().next();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object iterationOrder() {
/* 121 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public double realMin(int d) {
/* 127 */     return this.structuringElementBoundingBox.realMin(d);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void realMin(double[] min) {
/* 133 */     for (int d = 0; d < this.n; d++) {
/* 134 */       min[d] = this.structuringElementBoundingBox.realMin(d);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void realMin(RealPositionable min) {
/* 140 */     for (int d = 0; d < this.n; d++) {
/* 141 */       min.setPosition(this.structuringElementBoundingBox.realMin(d), d);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public double realMax(int d) {
/* 147 */     return this.structuringElementBoundingBox.realMax(d);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void realMax(double[] max) {
/* 153 */     for (int d = 0; d < this.n; d++) {
/* 154 */       max[d] = this.structuringElementBoundingBox.realMax(d);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void realMax(RealPositionable max) {
/* 160 */     for (int d = 0; d < this.n; d++) {
/* 161 */       max.setPosition(this.structuringElementBoundingBox.realMax(d), d);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public Iterator<T> iterator() {
/* 167 */     return (Iterator<T>)cursor();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public long min(int d) {
/* 173 */     return this.structuringElementBoundingBox.min(d);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void min(long[] min) {
/* 179 */     for (int d = 0; d < this.n; d++) {
/* 180 */       min[d] = this.structuringElementBoundingBox.min(d);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void min(Positionable min) {
/* 186 */     for (int d = 0; d < this.n; d++) {
/* 187 */       min.setPosition(this.structuringElementBoundingBox.min(d), d);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public long max(int d) {
/* 193 */     return this.structuringElementBoundingBox.max(d);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void max(long[] max) {
/* 199 */     for (int d = 0; d < this.n; d++) {
/* 200 */       max[d] = this.structuringElementBoundingBox.max(d);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void max(Positionable max) {
/* 206 */     for (int d = 0; d < this.n; d++) {
/* 207 */       max.setPosition(this.structuringElementBoundingBox.max(d), d);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void dimensions(long[] dimensions) {
/* 213 */     for (int d = 0; d < this.n; d++) {
/* 214 */       dimensions[d] = dimension(d);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public long dimension(int d) {
/* 220 */     if (d == this.dim)
/*     */     {
/* 222 */       return this.maxIndex;
/*     */     }
/*     */ 
/*     */     
/* 226 */     return 1L;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LocalCursor cursor() {
/* 233 */     return new LocalCursor(this.sourceRandomAccess.copyRandomAccess());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public LocalCursor localizingCursor() {
/* 239 */     return cursor();
/*     */   }
/*     */   
/*     */   public final class LocalCursor
/*     */     extends AbstractEuclideanSpace
/*     */     implements Cursor<T>
/*     */   {
/*     */     private final RandomAccess<T> source;
/*     */     private long index;
/*     */     
/*     */     public LocalCursor(RandomAccess<T> source) {
/* 250 */       super(source.numDimensions());
/* 251 */       this.source = source;
/* 252 */       reset();
/*     */     }
/*     */ 
/*     */     
/*     */     protected LocalCursor(LocalCursor c) {
/* 257 */       super(c.numDimensions());
/* 258 */       this.source = c.source.copyRandomAccess();
/* 259 */       this.index = c.index;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public T get() {
/* 265 */       return (T)this.source.get();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void fwd() {
/* 271 */       this.source.fwd(HorizontalLineNeighborhood.this.dim);
/* 272 */       if (HorizontalLineNeighborhood.this.skipCenter && this.index == HorizontalLineNeighborhood.this.span)
/*     */       {
/* 274 */         this.source.fwd(HorizontalLineNeighborhood.this.dim);
/*     */       }
/* 276 */       this.index++;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void jumpFwd(long steps) {
/* 282 */       for (int i = 0; i < steps; i++)
/*     */       {
/* 284 */         fwd();
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public T next() {
/* 291 */       fwd();
/* 292 */       return get();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void remove() {}
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void reset() {
/* 304 */       this.source.setPosition(HorizontalLineNeighborhood.this.position);
/* 305 */       this.source.move(-HorizontalLineNeighborhood.this.span - 1L, HorizontalLineNeighborhood.this.dim);
/* 306 */       this.index = 0L;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean hasNext() {
/* 312 */       return (this.index < HorizontalLineNeighborhood.this.maxIndex);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public float getFloatPosition(int d) {
/* 318 */       return this.source.getFloatPosition(d);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public double getDoublePosition(int d) {
/* 324 */       return this.source.getDoublePosition(d);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public int getIntPosition(int d) {
/* 330 */       return this.source.getIntPosition(d);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public long getLongPosition(int d) {
/* 336 */       return this.source.getLongPosition(d);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void localize(long[] position) {
/* 342 */       this.source.localize(position);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void localize(float[] position) {
/* 348 */       this.source.localize(position);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void localize(double[] position) {
/* 354 */       this.source.localize(position);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void localize(int[] position) {
/* 360 */       this.source.localize(position);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public LocalCursor copy() {
/* 366 */       return new LocalCursor(this);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public LocalCursor copyCursor() {
/* 372 */       return copy();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private Interval createInterval() {
/* 378 */     long[] minsize = new long[2 * this.position.length]; int i;
/* 379 */     for (i = 0; i < this.position.length; i++) {
/*     */       
/* 381 */       if (i == this.dim) {
/*     */         
/* 383 */         minsize[i] = this.position[i] - this.span;
/*     */       }
/*     */       else {
/*     */         
/* 387 */         minsize[i] = this.position[i];
/*     */       } 
/*     */     } 
/* 390 */     for (i = this.position.length; i < minsize.length; i++) {
/*     */       
/* 392 */       if (i - this.position.length == this.dim) {
/*     */         
/* 394 */         minsize[i] = this.position[i - this.position.length] + this.span;
/*     */       }
/*     */       else {
/*     */         
/* 398 */         minsize[i] = this.position[i - this.position.length];
/*     */       } 
/*     */     } 
/* 401 */     return (Interval)Intervals.createMinMax(minsize);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/imglib2-algorithm-0.6.2.jar!/net/imglib2/algorithm/neighborhood/HorizontalLineNeighborhood.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */