/*    */ package net.imglib2.algorithm.morphology.table2d;
/*    */ 
/*    */ import net.imglib2.IterableInterval;
/*    */ import net.imglib2.RandomAccessible;
/*    */ import net.imglib2.img.Img;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class Spur2
/*    */   extends Abstract3x3TableOperation
/*    */ {
/*    */   protected boolean[] getTable() {
/* 51 */     return table;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected boolean getExtendedValue() {
/* 57 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public static <T extends net.imglib2.type.BooleanType<T>> Img<T> spur2(Img<T> source) {
/* 62 */     return (new Spur2()).calculate(source);
/*    */   }
/*    */ 
/*    */   
/*    */   public static <T extends net.imglib2.type.BooleanType<T>> void spur2(RandomAccessible<T> source, IterableInterval<T> target) {
/* 67 */     (new Spur2()).calculate(source, target);
/*    */   }
/*    */   
/* 70 */   private static final boolean[] table = new boolean[] { 
/*    */       false, false, false, false, false, false, false, false, false, false, 
/*    */       false, false, false, false, false, false, true, true, true, true, 
/*    */       true, true, true, true, true, true, true, true, true, true, 
/*    */       true, true, false, false, false, false, false, false, false, false, 
/*    */       false, false, false, false, false, false, false, false, false, true, 
/*    */       true, true, true, true, true, true, true, true, true, true, 
/*    */       true, true, true, true, false, false, false, false, false, false, 
/*    */       false, false, false, false, false, false, false, false, false, false, 
/*    */       false, true, true, true, true, true, true, true, true, true, 
/*    */       true, true, true, true, true, true, false, false, false, false, 
/*    */       false, false, false, false, false, false, false, false, false, false, 
/*    */       false, false, true, true, true, true, true, true, true, true, 
/*    */       true, true, true, true, true, true, true, true, false, false, 
/*    */       false, false, false, false, false, false, false, false, false, false, 
/*    */       false, false, false, false, false, true, true, true, true, true, 
/*    */       true, true, true, true, true, true, true, true, true, true, 
/*    */       false, false, false, false, false, false, false, false, false, false, 
/*    */       false, false, false, false, false, false, true, true, true, true, 
/*    */       true, true, true, true, true, true, true, true, true, true, 
/*    */       true, true, false, false, false, false, false, false, false, false, 
/*    */       false, false, false, false, false, false, false, false, true, true, 
/*    */       true, true, true, true, true, true, true, true, true, true, 
/*    */       true, true, true, true, false, false, false, false, false, false, 
/*    */       false, false, false, false, false, false, false, false, false, false, 
/*    */       true, true, true, true, true, true, true, true, true, true, 
/*    */       true, true, true, true, true, true, false, false, false, false, 
/*    */       false, false, false, false, false, false, false, false, false, false, 
/*    */       false, false, false, true, true, true, true, true, true, true, 
/*    */       true, true, true, true, true, true, true, true, false, false, 
/*    */       false, false, false, false, false, false, false, false, false, false, 
/*    */       false, false, false, false, true, true, true, true, true, true, 
/*    */       true, true, true, true, true, true, true, true, true, true, 
/*    */       false, false, false, false, false, false, false, false, false, false, 
/*    */       false, false, false, false, false, false, true, true, true, true, 
/*    */       true, true, true, true, true, true, true, true, true, true, 
/*    */       true, true, false, false, false, false, false, false, false, false, 
/*    */       false, false, false, false, false, false, false, false, true, true, 
/*    */       true, true, true, true, true, true, true, true, true, true, 
/*    */       true, true, true, true, false, false, false, false, false, false, 
/*    */       false, false, false, false, false, false, false, false, false, false, 
/*    */       true, true, true, true, true, true, true, true, true, true, 
/*    */       true, true, true, true, true, true, false, false, false, false, 
/*    */       false, false, false, false, false, false, false, false, false, false, 
/*    */       false, false, true, true, true, true, true, true, true, true, 
/*    */       true, true, true, true, true, true, true, true, false, false, 
/*    */       false, false, false, false, false, false, false, false, false, false, 
/*    */       false, false, false, false, true, true, true, true, true, true, 
/*    */       true, true, true, true, true, true, true, true, true, true, 
/*    */       false, false, false, false, false, false, false, false, false, false, 
/*    */       false, false, false, false, false, false, true, true, true, true, 
/*    */       true, true, true, true, true, true, true, true, true, true, 
/*    */       true, true };
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/imglib2-algorithm-0.6.2.jar!/net/imglib2/algorithm/morphology/table2d/Spur2.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */