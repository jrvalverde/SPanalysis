/*     */ package net.imglib2.algorithm.componenttree.pixellist;
/*     */ 
/*     */ import net.imglib2.RandomAccessibleInterval;
/*     */ import net.imglib2.algorithm.componenttree.PartialComponent;
/*     */ import net.imglib2.img.Img;
/*     */ import net.imglib2.img.ImgFactory;
/*     */ import net.imglib2.type.Type;
/*     */ import net.imglib2.type.numeric.integer.LongType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class PixelListPartialComponentGenerator<T extends Type<T>>
/*     */   implements PartialComponent.Generator<T, PixelListPartialComponent<T>>
/*     */ {
/*     */   private final T maxValue;
/*     */   final long[] dimensions;
/*     */   final Img<LongType> linkedList;
/*     */   
/*     */   PixelListPartialComponentGenerator(T maxValue, RandomAccessibleInterval<T> input, ImgFactory<LongType> imgFactory) {
/*  86 */     this.maxValue = maxValue;
/*  87 */     this.dimensions = new long[input.numDimensions()];
/*  88 */     input.dimensions(this.dimensions);
/*  89 */     this.linkedList = imgFactory.create(this.dimensions, new LongType());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public PixelListPartialComponent<T> createComponent(T value) {
/*  95 */     return new PixelListPartialComponent<>(value, this);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public PixelListPartialComponent<T> createMaxComponent() {
/* 101 */     return new PixelListPartialComponent<>(this.maxValue, this);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/imglib2-algorithm-0.6.2.jar!/net/imglib2/algorithm/componenttree/pixellist/PixelListPartialComponentGenerator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */