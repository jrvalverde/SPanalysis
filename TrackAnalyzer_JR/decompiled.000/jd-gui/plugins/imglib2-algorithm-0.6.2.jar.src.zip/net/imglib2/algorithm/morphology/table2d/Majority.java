/*    */ package net.imglib2.algorithm.morphology.table2d;
/*    */ 
/*    */ import net.imglib2.IterableInterval;
/*    */ import net.imglib2.RandomAccessible;
/*    */ import net.imglib2.img.Img;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Majority
/*    */   extends Abstract3x3TableOperation
/*    */ {
/*    */   protected boolean[] getTable() {
/* 60 */     return table;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected boolean getExtendedValue() {
/* 66 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public static <T extends net.imglib2.type.BooleanType<T>> Img<T> majority(Img<T> source) {
/* 71 */     return (new Majority()).calculate(source);
/*    */   }
/*    */ 
/*    */   
/*    */   public static <T extends net.imglib2.type.BooleanType<T>> void majority(RandomAccessible<T> source, IterableInterval<T> target) {
/* 76 */     (new Majority()).calculate(source, target);
/*    */   }
/*    */   
/* 79 */   private static final boolean[] table = new boolean[] { 
/*    */       false, false, false, false, false, false, false, false, false, false, 
/*    */       false, false, false, false, false, false, false, false, false, false, 
/*    */       false, false, false, false, false, false, false, false, false, false, 
/*    */       false, true, false, false, false, false, false, false, false, false, 
/*    */       false, false, false, false, false, false, false, true, false, false, 
/*    */       false, false, false, false, false, true, false, false, false, true, 
/*    */       false, true, true, true, false, false, false, false, false, false, 
/*    */       false, false, false, false, false, false, false, false, false, true, 
/*    */       false, false, false, false, false, false, false, true, false, false, 
/*    */       false, true, false, true, true, true, false, false, false, false, 
/*    */       false, false, false, true, false, false, false, true, false, true, 
/*    */       true, true, false, false, false, true, false, true, true, true, 
/*    */       false, true, true, true, true, true, true, true, false, false, 
/*    */       false, false, false, false, false, false, false, false, false, false, 
/*    */       false, false, false, true, false, false, false, false, false, false, 
/*    */       false, true, false, false, false, true, false, true, true, true, 
/*    */       false, false, false, false, false, false, false, true, false, false, 
/*    */       false, true, false, true, true, true, false, false, false, true, 
/*    */       false, true, true, true, false, true, true, true, true, true, 
/*    */       true, true, false, false, false, false, false, false, false, true, 
/*    */       false, false, false, true, false, true, true, true, false, false, 
/*    */       false, true, false, true, true, true, false, true, true, true, 
/*    */       true, true, true, true, false, false, false, true, false, true, 
/*    */       true, true, false, true, true, true, true, true, true, true, 
/*    */       false, true, true, true, true, true, true, true, true, true, 
/*    */       true, true, true, true, true, true, false, false, false, false, 
/*    */       false, false, false, false, false, false, false, false, false, false, 
/*    */       false, true, false, false, false, false, false, false, false, true, 
/*    */       false, false, false, true, false, true, true, true, false, false, 
/*    */       false, false, false, false, false, true, false, false, false, true, 
/*    */       false, true, true, true, false, false, false, true, false, true, 
/*    */       true, true, false, true, true, true, true, true, true, true, 
/*    */       false, false, false, false, false, false, false, true, false, false, 
/*    */       false, true, false, true, true, true, false, false, false, true, 
/*    */       false, true, true, true, false, true, true, true, true, true, 
/*    */       true, true, false, false, false, true, false, true, true, true, 
/*    */       false, true, true, true, true, true, true, true, false, true, 
/*    */       true, true, true, true, true, true, true, true, true, true, 
/*    */       true, true, true, true, false, false, false, false, false, false, 
/*    */       false, true, false, false, false, true, false, true, true, true, 
/*    */       false, false, false, true, false, true, true, true, false, true, 
/*    */       true, true, true, true, true, true, false, false, false, true, 
/*    */       false, true, true, true, false, true, true, true, true, true, 
/*    */       true, true, false, true, true, true, true, true, true, true, 
/*    */       true, true, true, true, true, true, true, true, false, false, 
/*    */       false, true, false, true, true, true, false, true, true, true, 
/*    */       true, true, true, true, false, true, true, true, true, true, 
/*    */       true, true, true, true, true, true, true, true, true, true, 
/*    */       false, true, true, true, true, true, true, true, true, true, 
/*    */       true, true, true, true, true, true, true, true, true, true, 
/*    */       true, true, true, true, true, true, true, true, true, true, 
/*    */       true, true };
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/imglib2-algorithm-0.6.2.jar!/net/imglib2/algorithm/morphology/table2d/Majority.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */