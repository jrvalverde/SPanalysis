/*    */ package net.imglib2.algorithm.neighborhood;
/*    */ 
/*    */ import net.imglib2.Cursor;
/*    */ import net.imglib2.RandomAccess;
/*    */ import net.imglib2.RealCursor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HorizontalLineNeighborhoodUnsafe<T>
/*    */   extends HorizontalLineNeighborhood<T>
/*    */ {
/*    */   private final HorizontalLineNeighborhood<T>.LocalCursor theCursor;
/*    */   private final HorizontalLineNeighborhood<T>.LocalCursor firstElementCursor;
/*    */   
/*    */   public static <T> HorizontalLineNeighborhoodFactory<T> factory() {
/* 43 */     return new HorizontalLineNeighborhoodFactory<T>()
/*    */       {
/*    */         
/*    */         public Neighborhood<T> create(long[] position, long span, int dim, boolean skipCenter, RandomAccess<T> sourceRandomAccess)
/*    */         {
/* 48 */           return new HorizontalLineNeighborhoodUnsafe<>(position, span, dim, skipCenter, sourceRandomAccess);
/*    */         }
/*    */       };
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   HorizontalLineNeighborhoodUnsafe(long[] position, long span, int dim, boolean skipCenter, RandomAccess<T> sourceRandomAccess) {
/* 59 */     super(position, span, dim, skipCenter, sourceRandomAccess);
/* 60 */     this.theCursor = super.cursor();
/* 61 */     this.firstElementCursor = super.cursor();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public T firstElement() {
/* 67 */     this.firstElementCursor.reset();
/* 68 */     return this.firstElementCursor.next();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public HorizontalLineNeighborhood<T>.LocalCursor cursor() {
/* 74 */     this.theCursor.reset();
/* 75 */     return this.theCursor;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/imglib2-algorithm-0.6.2.jar!/net/imglib2/algorithm/neighborhood/HorizontalLineNeighborhoodUnsafe.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */