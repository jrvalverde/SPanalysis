/*     */ package net.imglib2.algorithm.region.hypersphere;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import net.imglib2.Cursor;
/*     */ import net.imglib2.IterableInterval;
/*     */ import net.imglib2.Localizable;
/*     */ import net.imglib2.Positionable;
/*     */ import net.imglib2.RandomAccessible;
/*     */ import net.imglib2.RealCursor;
/*     */ import net.imglib2.RealPositionable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HyperSphere<T>
/*     */   implements IterableInterval<T>
/*     */ {
/*     */   final int numDimensions;
/*     */   long radius;
/*     */   final RandomAccessible<T> source;
/*     */   final long[] center;
/*     */   
/*     */   public HyperSphere(RandomAccessible<T> source, Localizable center, long radius) {
/*  64 */     this.numDimensions = source.numDimensions();
/*  65 */     this.source = source;
/*  66 */     this.center = new long[this.numDimensions];
/*  67 */     center.localize(this.center);
/*     */     
/*  69 */     updateRadius(radius);
/*     */   }
/*     */ 
/*     */   
/*     */   public void updateCenter(long[] center) {
/*  74 */     for (int d = 0; d < this.numDimensions; d++) {
/*  75 */       this.center[d] = center[d];
/*     */     }
/*     */   }
/*     */   
/*     */   public void updateCenter(Localizable center) {
/*  80 */     for (int d = 0; d < this.numDimensions; d++) {
/*  81 */       this.center[d] = center.getLongPosition(d);
/*     */     }
/*     */   }
/*     */   
/*     */   public void updateRadius(long radius) {
/*  86 */     this.radius = radius;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected long computeSize() {
/*  94 */     HyperSphereCursor<T> cursor = new HyperSphereCursor<>(this.source, this.center, this.radius);
/*     */ 
/*     */     
/*  97 */     long size = 0L;
/*  98 */     while (cursor.hasNext()) {
/*     */       
/* 100 */       cursor.fwd();
/* 101 */       size++;
/*     */     } 
/*     */     
/* 104 */     return size;
/*     */   }
/*     */ 
/*     */   
/*     */   public void update(Localizable center, long radius) {
/* 109 */     updateCenter(center);
/* 110 */     updateRadius(radius);
/*     */   }
/*     */ 
/*     */   
/*     */   public void update(long[] center, long radius) {
/* 115 */     updateCenter(center);
/* 116 */     updateRadius(radius);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public long size() {
/* 122 */     return computeSize();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public T firstElement() {
/* 128 */     HyperSphereCursor<T> cursor = new HyperSphereCursor<>(this.source, this.center, this.radius);
/* 129 */     cursor.fwd();
/* 130 */     return cursor.get();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object iterationOrder() {
/* 136 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public double realMin(int d) {
/* 142 */     return min(d);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void realMin(double[] min) {
/* 148 */     for (int d = 0; d < this.numDimensions; d++) {
/* 149 */       min[d] = (this.center[d] - this.radius);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void realMin(RealPositionable min) {
/* 155 */     for (int d = 0; d < this.numDimensions; d++) {
/* 156 */       min.setPosition(this.center[d] - this.radius, d);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public double realMax(int d) {
/* 162 */     return max(d);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void realMax(double[] max) {
/* 168 */     for (int d = 0; d < this.numDimensions; d++) {
/* 169 */       max[d] = (this.center[d] + this.radius);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void realMax(RealPositionable max) {
/* 175 */     for (int d = 0; d < this.numDimensions; d++) {
/* 176 */       max.setPosition(this.center[d] - this.radius, d);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public int numDimensions() {
/* 182 */     return this.numDimensions;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Iterator<T> iterator() {
/* 188 */     return (Iterator<T>)cursor();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public long min(int d) {
/* 194 */     return this.center[d] - this.radius;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void min(long[] min) {
/* 200 */     for (int d = 0; d < this.numDimensions; d++) {
/* 201 */       min[d] = this.center[d] - this.radius;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void min(Positionable min) {
/* 207 */     for (int d = 0; d < this.numDimensions; d++) {
/* 208 */       min.setPosition(this.center[d] - this.radius, d);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public long max(int d) {
/* 214 */     return this.center[d] + this.radius;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void max(long[] max) {
/* 220 */     for (int d = 0; d < this.numDimensions; d++) {
/* 221 */       max[d] = this.center[d] + this.radius;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void max(Positionable max) {
/* 227 */     for (int d = 0; d < this.numDimensions; d++) {
/* 228 */       max.setPosition(this.center[d] + this.radius, d);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void dimensions(long[] dimensions) {
/* 234 */     long size = this.radius * 2L + 1L;
/* 235 */     for (int d = 0; d < this.numDimensions; d++) {
/* 236 */       dimensions[d] = size;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public long dimension(int d) {
/* 242 */     return this.radius * 2L + 1L;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public HyperSphereCursor<T> cursor() {
/* 248 */     return localizingCursor();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public HyperSphereCursor<T> localizingCursor() {
/* 254 */     return new HyperSphereCursor<>(this.source, this.center, this.radius);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/imglib2-algorithm-0.6.2.jar!/net/imglib2/algorithm/region/hypersphere/HyperSphere.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */