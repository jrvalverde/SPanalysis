/*    */ package net.imglib2.algorithm.morphology.table2d;
/*    */ 
/*    */ import net.imglib2.IterableInterval;
/*    */ import net.imglib2.RandomAccessible;
/*    */ import net.imglib2.img.Img;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Clean
/*    */   extends Abstract3x3TableOperation
/*    */ {
/*    */   protected boolean[] getTable() {
/* 59 */     return table;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected boolean getExtendedValue() {
/* 65 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public static <T extends net.imglib2.type.BooleanType<T>> Img<T> clean(Img<T> source) {
/* 70 */     return (new Clean()).calculate(source);
/*    */   }
/*    */ 
/*    */   
/*    */   public static <T extends net.imglib2.type.BooleanType<T>> void clean(RandomAccessible<T> source, IterableInterval<T> target) {
/* 75 */     (new Clean()).calculate(source, target);
/*    */   }
/*    */   
/* 78 */   private static final boolean[] table = new boolean[] { 
/*    */       false, false, false, false, false, false, false, false, false, false, 
/*    */       false, false, false, false, false, false, false, true, true, true, 
/*    */       true, true, true, true, true, true, true, true, true, true, 
/*    */       true, true, false, false, false, false, false, false, false, false, 
/*    */       false, false, false, false, false, false, false, false, true, true, 
/*    */       true, true, true, true, true, true, true, true, true, true, 
/*    */       true, true, true, true, false, false, false, false, false, false, 
/*    */       false, false, false, false, false, false, false, false, false, false, 
/*    */       true, true, true, true, true, true, true, true, true, true, 
/*    */       true, true, true, true, true, true, false, false, false, false, 
/*    */       false, false, false, false, false, false, false, false, false, false, 
/*    */       false, false, true, true, true, true, true, true, true, true, 
/*    */       true, true, true, true, true, true, true, true, false, false, 
/*    */       false, false, false, false, false, false, false, false, false, false, 
/*    */       false, false, false, false, true, true, true, true, true, true, 
/*    */       true, true, true, true, true, true, true, true, true, true, 
/*    */       false, false, false, false, false, false, false, false, false, false, 
/*    */       false, false, false, false, false, false, true, true, true, true, 
/*    */       true, true, true, true, true, true, true, true, true, true, 
/*    */       true, true, false, false, false, false, false, false, false, false, 
/*    */       false, false, false, false, false, false, false, false, true, true, 
/*    */       true, true, true, true, true, true, true, true, true, true, 
/*    */       true, true, true, true, false, false, false, false, false, false, 
/*    */       false, false, false, false, false, false, false, false, false, false, 
/*    */       true, true, true, true, true, true, true, true, true, true, 
/*    */       true, true, true, true, true, true, false, false, false, false, 
/*    */       false, false, false, false, false, false, false, false, false, false, 
/*    */       false, false, true, true, true, true, true, true, true, true, 
/*    */       true, true, true, true, true, true, true, true, false, false, 
/*    */       false, false, false, false, false, false, false, false, false, false, 
/*    */       false, false, false, false, true, true, true, true, true, true, 
/*    */       true, true, true, true, true, true, true, true, true, true, 
/*    */       false, false, false, false, false, false, false, false, false, false, 
/*    */       false, false, false, false, false, false, true, true, true, true, 
/*    */       true, true, true, true, true, true, true, true, true, true, 
/*    */       true, true, false, false, false, false, false, false, false, false, 
/*    */       false, false, false, false, false, false, false, false, true, true, 
/*    */       true, true, true, true, true, true, true, true, true, true, 
/*    */       true, true, true, true, false, false, false, false, false, false, 
/*    */       false, false, false, false, false, false, false, false, false, false, 
/*    */       true, true, true, true, true, true, true, true, true, true, 
/*    */       true, true, true, true, true, true, false, false, false, false, 
/*    */       false, false, false, false, false, false, false, false, false, false, 
/*    */       false, false, true, true, true, true, true, true, true, true, 
/*    */       true, true, true, true, true, true, true, true, false, false, 
/*    */       false, false, false, false, false, false, false, false, false, false, 
/*    */       false, false, false, false, true, true, true, true, true, true, 
/*    */       true, true, true, true, true, true, true, true, true, true, 
/*    */       false, false, false, false, false, false, false, false, false, false, 
/*    */       false, false, false, false, false, false, true, true, true, true, 
/*    */       true, true, true, true, true, true, true, true, true, true, 
/*    */       true, true };
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/imglib2-algorithm-0.6.2.jar!/net/imglib2/algorithm/morphology/table2d/Clean.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */