package net.imglib2.algorithm.neighborhood;

import net.imglib2.Interval;
import net.imglib2.RandomAccess;

public interface RectangleNeighborhoodFactory<T> {
  Neighborhood<T> create(long[] paramArrayOflong1, long[] paramArrayOflong2, long[] paramArrayOflong3, Interval paramInterval, RandomAccess<T> paramRandomAccess);
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/imglib2-algorithm-0.6.2.jar!/net/imglib2/algorithm/neighborhood/RectangleNeighborhoodFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */