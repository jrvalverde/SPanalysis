/*     */ package net.imglib2.multithreading;
/*     */ 
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public class SimpleMultiThreading
/*     */ {
/*     */   public static Vector<Chunk> divideIntoChunks(long imageSize, int numThreads) {
/*  61 */     long threadChunkSize = imageSize / numThreads;
/*  62 */     long threadChunkMod = imageSize % numThreads;
/*     */     
/*  64 */     Vector<Chunk> chunks = new Vector<>();
/*     */     
/*  66 */     for (int threadID = 0; threadID < numThreads; threadID++) {
/*     */ 
/*     */       
/*  69 */       long loopSize, startPosition = threadID * threadChunkSize;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  74 */       if (threadID == numThreads - 1) {
/*  75 */         loopSize = threadChunkSize + threadChunkMod;
/*     */       } else {
/*  77 */         loopSize = threadChunkSize;
/*     */       } 
/*  79 */       chunks.add(new Chunk(startPosition, loopSize));
/*     */     } 
/*     */     
/*  82 */     return chunks;
/*     */   }
/*     */ 
/*     */   
/*     */   public static void startTask(Runnable run) {
/*  87 */     Thread[] threads = newThreads();
/*     */     
/*  89 */     for (int ithread = 0; ithread < threads.length; ithread++) {
/*  90 */       threads[ithread] = new Thread(run);
/*     */     }
/*  92 */     startAndJoin(threads);
/*     */   }
/*     */ 
/*     */   
/*     */   public static void startTask(Runnable run, int numThreads) {
/*  97 */     if (1 == numThreads) {
/*     */       
/*  99 */       run.run();
/*     */       
/*     */       return;
/*     */     } 
/* 103 */     Thread[] threads = newThreads(numThreads);
/*     */     
/* 105 */     for (int ithread = 0; ithread < threads.length; ithread++) {
/* 106 */       threads[ithread] = new Thread(run);
/*     */     }
/* 108 */     startAndJoin(threads);
/*     */   }
/*     */ 
/*     */   
/*     */   public static Thread[] newThreads() {
/* 113 */     int nthread = Runtime.getRuntime().availableProcessors();
/* 114 */     return new Thread[nthread];
/*     */   }
/*     */ 
/*     */   
/*     */   public static Thread[] newThreads(int numThreads) {
/* 119 */     return new Thread[numThreads];
/*     */   }
/*     */ 
/*     */   
/*     */   public static void startAndJoin(Thread[] threads) {
/* 124 */     if (1 == threads.length) {
/*     */       
/* 126 */       threads[0].run();
/*     */       return;
/*     */     } 
/*     */     int ithread;
/* 130 */     for (ithread = 0; ithread < threads.length; ithread++) {
/*     */       
/* 132 */       threads[ithread].setPriority(5);
/* 133 */       threads[ithread].start();
/*     */     } 
/*     */ 
/*     */     
/*     */     try {
/* 138 */       for (ithread = 0; ithread < threads.length; ithread++) {
/* 139 */         threads[ithread].join();
/*     */       }
/* 141 */     } catch (InterruptedException ie) {
/*     */       
/* 143 */       throw new RuntimeException(ie);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static void start(Thread[] threads) {
/* 149 */     for (int ithread = 0; ithread < threads.length; ithread++) {
/*     */       
/* 151 */       threads[ithread].setPriority(1);
/* 152 */       threads[ithread].start();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static void threadHaltUnClean() {
/* 158 */     int i = 0;
/*     */     while (true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void threadWait(long milliseconds) {
/*     */     try {
/* 168 */       Thread.sleep(milliseconds);
/*     */     }
/* 170 */     catch (InterruptedException e) {
/*     */       
/* 172 */       System.err.println("MultiThreading.threadWait(): Thread woken up: " + e);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/imglib2-algorithm-0.6.2.jar!/net/imglib2/multithreading/SimpleMultiThreading.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */