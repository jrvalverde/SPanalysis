/*    */ package net.imglib2.multithreading;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ public class Chunk
/*    */ {
/*    */   protected long startPosition;
/*    */   protected long loopSize;
/*    */   
/*    */   public Chunk(long startPosition, long loopSize) {
/* 47 */     this.startPosition = startPosition;
/* 48 */     this.loopSize = loopSize;
/*    */   }
/*    */ 
/*    */   
/*    */   public long getStartPosition() {
/* 53 */     return this.startPosition;
/*    */   }
/*    */ 
/*    */   
/*    */   public long getLoopSize() {
/* 58 */     return this.loopSize;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/imglib2-algorithm-0.6.2.jar!/net/imglib2/multithreading/Chunk.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */