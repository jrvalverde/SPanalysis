/*    */ package de.biomedical_imaging.ij.trajectory_classifier;
/*    */ 
/*    */ import ij.gui.PolygonRoi;
/*    */ import ij.gui.Roi;
/*    */ import ij.gui.TextRoi;
/*    */ import ij.process.FloatPolygon;
/*    */ import java.awt.Color;
/*    */ import java.util.ArrayList;
/*    */ import org.scijava.vecmath.Point3d;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class VisualizationUtils
/*    */ {
/*    */   public static ArrayList<Roi> generateVisualizationRoisFromTrack(Subtrajectory t, Color c, boolean showID) {
/* 40 */     return generateVisualizationRoisFromTrack(t, c, showID, 1.0D);
/*    */   }
/*    */   
/*    */   public static ArrayList<Roi> generateVisualizationRoisFromTrack(Subtrajectory t, Color c, boolean showID, double pixelsize) {
/* 44 */     ArrayList<Roi> proi = new ArrayList<>();
/* 45 */     FloatPolygon p = new FloatPolygon();
/* 46 */     double sumx = 0.0D;
/* 47 */     double sumy = 0.0D;
/* 48 */     TextRoi.setFont("TimesRoman", 5, 0);
/* 49 */     for (int i = 0; i < t.getParent().size(); i++) {
/* 50 */       int to = t.size();
/* 51 */       if (i < t.size()) {
/*    */         
/* 53 */         sumx += ((Point3d)t.get(i)).x / pixelsize;
/* 54 */         sumy += ((Point3d)t.get(i)).y / pixelsize;
/* 55 */         p.addPoint(((Point3d)t.get(i)).x / pixelsize, ((Point3d)t.get(i)).y / pixelsize);
/*    */         
/* 57 */         to = i + 1;
/*    */       } 
/*    */       
/* 60 */       PolygonRoi pr = new PolygonRoi(new FloatPolygon(p.xpoints, p.ypoints, to), 6);
/* 61 */       pr.setStrokeColor(c);
/* 62 */       pr.setPosition(t.getRelativeStartTimepoint() + i + 1);
/* 63 */       proi.add(pr);
/*    */       
/* 65 */       if (showID) {
/* 66 */         long parentID = t.getParent().getID();
/* 67 */         TextRoi troi = new TextRoi(sumx / to, sumy / to, " " + parentID + ":" + t.getID() + " ");
/* 68 */         troi.setPosition(t.getRelativeStartTimepoint() + i + 1);
/* 69 */         troi.setFillColor(Color.BLACK);
/* 70 */         troi.setStrokeColor(c);
/* 71 */         troi.setAntialiased(true);
/* 72 */         proi.add(troi);
/*    */       } 
/*    */     } 
/* 75 */     return proi;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/ij_trajectory_classifier-0.8.2.jar!/de/biomedical_imaging/ij/trajectory_classifier/VisualizationUtils.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */