/*     */ package de.biomedical_imaging.ij.trajectory_classifier;
/*     */ 
/*     */ import de.biomedical_imaging.traJ.DiffusionCoefficientEstimator.AbstractDiffusionCoefficientEstimator;
/*     */ import de.biomedical_imaging.traJ.DiffusionCoefficientEstimator.CovarianceDiffusionCoefficientEstimator;
/*     */ import de.biomedical_imaging.traJ.DiffusionCoefficientEstimator.RegressionDiffusionCoefficientEstimator;
/*     */ import de.biomedical_imaging.traJ.Trajectory;
/*     */ import de.biomedical_imaging.traJ.drift.StaticDriftCalculator;
/*     */ import de.biomedical_imaging.traJ.drift.StaticDriftCorrector;
/*     */ import de.biomedical_imaging.traJ.features.AbstractTrajectoryFeature;
/*     */ import de.biomedical_imaging.traJ.features.ActiveTransportParametersFeature;
/*     */ import de.biomedical_imaging.traJ.features.Asymmetry3Feature;
/*     */ import de.biomedical_imaging.traJ.features.CenterOfGravityFeature;
/*     */ import de.biomedical_imaging.traJ.features.ConfinedDiffusionParametersFeature;
/*     */ import de.biomedical_imaging.traJ.features.EfficiencyFeature;
/*     */ import de.biomedical_imaging.traJ.features.FractalDimensionFeature;
/*     */ import de.biomedical_imaging.traJ.features.GaussianityFeauture;
/*     */ import de.biomedical_imaging.traJ.features.KurtosisFeature;
/*     */ import de.biomedical_imaging.traJ.features.MSDRatioFeature;
/*     */ import de.biomedical_imaging.traJ.features.MeanSpeedFeature;
/*     */ import de.biomedical_imaging.traJ.features.PowerLawFeature;
/*     */ import de.biomedical_imaging.traJ.features.StraightnessFeature;
/*     */ import de.biomedical_imaging.traJ.features.TrappedProbabilityFeature;
/*     */ import ij.IJ;
/*     */ import ij.Prefs;
/*     */ import ij.WindowManager;
/*     */ import ij.gui.DialogListener;
/*     */ import ij.gui.GenericDialog;
/*     */ import ij.gui.Overlay;
/*     */ import ij.gui.Roi;
/*     */ import ij.gui.TextRoi;
/*     */ import ij.io.OpenDialog;
/*     */ import ij.measure.ResultsTable;
/*     */ import ij.plugin.PlugIn;
/*     */ import java.awt.AWTEvent;
/*     */ import java.awt.Color;
/*     */ import java.io.File;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.text.DecimalFormat;
/*     */ import java.text.DecimalFormatSymbols;
/*     */ import java.text.NumberFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.math3.stat.StatUtils;
/*     */ import org.scijava.vecmath.Point3d;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TraJClassifier_
/*     */   implements PlugIn
/*     */ {
/*     */   private double timelag;
/*     */   private double minTrackLength;
/*     */   private int windowSizeClassification;
/*     */   private int minSegmentLength;
/*     */   private double pixelsize;
/*     */   private int resampleRate;
/*     */   private boolean showID;
/*     */   private boolean showOverviewClasses;
/*     */   private boolean removeGlobalDrift;
/*     */   private boolean useReducedModelConfinedMotion;
/*     */   private ArrayList<Subtrajectory> classifiedTrajectories;
/*     */   private ArrayList<Trajectory> tracksToClassify;
/*     */   private static TraJClassifier_ instance;
/*     */   ArrayList<Trajectory> parentTrajectories;
/*     */   
/*     */   public TraJClassifier_() {
/*  97 */     this.minTrackLength = 160.0D;
/*  98 */     this.windowSizeClassification = 60;
/*  99 */     this.minSegmentLength = 30;
/* 100 */     this.pixelsize = 0.166D;
/* 101 */     this.timelag = 0.03333333333333333D;
/* 102 */     this.resampleRate = 1;
/* 103 */     this.showID = true;
/* 104 */     instance = this;
/*     */   }
/*     */   
/*     */   public static TraJClassifier_ getInstance() {
/* 108 */     if (instance == null) {
/* 109 */       instance = new TraJClassifier_();
/*     */     }
/* 111 */     return instance;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void run(String arg) {
/* 119 */     String modelpath = "";
/*     */     try {
/* 121 */       modelpath = ExportResource("/randomForestModel.RData");
/* 122 */     } catch (Exception e) {
/*     */       
/* 124 */       e.printStackTrace();
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 130 */     if (!arg.contains("DEBUG")) {
/* 131 */       OpenDialog open = new OpenDialog("Choose the TrackMate xml file");
/* 132 */       String filepath = open.getPath();
/* 133 */       if (filepath == null) {
/*     */         return;
/*     */       }
/* 136 */       TrackMateImporter tMateImport = new TrackMateImporter();
/* 137 */       this.tracksToClassify = tMateImport.importTrackMateXML(filepath);
/*     */     } 
/* 139 */     int maxNumberOfPositions = 0;
/* 140 */     for (int i = 0; i < this.tracksToClassify.size(); i++) {
/* 141 */       if (((Trajectory)this.tracksToClassify.get(i)).size() > maxNumberOfPositions) {
/* 142 */         maxNumberOfPositions = ((Trajectory)this.tracksToClassify.get(i)).size();
/*     */       }
/*     */     } 
/* 145 */     boolean visualize = true;
/*     */     
/* 147 */     if (WindowManager.getCurrentImage() == null || (IJ.getImage().getNFrames() < maxNumberOfPositions && IJ.getImage().getNSlices() < maxNumberOfPositions)) {
/*     */       
/* 149 */       IJ.showMessage("Your image does not contain enough frames for visualization.Therefore visualization will be deactivated. \n For visualization please open the corresponding image stack to the trackmate file");
/*     */ 
/*     */       
/* 152 */       visualize = false;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 160 */     if (!arg.contains("NOGUI")) {
/*     */       
/* 162 */       String version = getClass().getPackage().getImplementationVersion();
/* 163 */       this.minTrackLength = Prefs.get("trajclass.minTrackLength", 160.0D);
/* 164 */       this.windowSizeClassification = (int)Prefs.get("trajclass.windowSize", 60.0D);
/* 165 */       this.minSegmentLength = (int)Prefs.get("trajclass.minSegmentLength", 60.0D);
/* 166 */       this.resampleRate = (int)Prefs.get("trajclass.ResampleRate", 1.0D);
/* 167 */       this.pixelsize = Prefs.get("trajclass.pixelsize", 0.166D);
/* 168 */       this.timelag = 1.0D / Prefs.get("trajclass.framerate", 30.0D);
/* 169 */       this.useReducedModelConfinedMotion = Prefs.get("trajclass.useReducedModelConfinedMotion", false);
/* 170 */       this.showID = Prefs.get("trajclass.showID", true);
/* 171 */       this.showOverviewClasses = Prefs.get("trajclass.showOverviewClasses", true);
/* 172 */       this.removeGlobalDrift = Prefs.get("trajclass.removeGlobalDrift", false);
/*     */ 
/*     */       
/* 175 */       GenericDialog gd = new GenericDialog("TraJectory Classification (" + version + ")");
/*     */       
/* 177 */       gd.addSlider("Min. tracklength", 30.0D, 1000.0D, this.minTrackLength);
/* 178 */       gd.addSlider("Windowsize (positions)", 30.0D, 1000.0D, this.windowSizeClassification);
/* 179 */       gd.addSlider("Min. segment length", 30.0D, 1000.0D, this.minSegmentLength);
/* 180 */       gd.addNumericField("Resample rate*", this.resampleRate, 0);
/* 181 */       gd.addNumericField("Pixelsize (µm)**", this.pixelsize, 4);
/* 182 */       gd.addNumericField("Framerate (FPS)", 1.0D / this.timelag, 0);
/* 183 */       gd.addCheckbox("Use reduced model confined motion", this.useReducedModelConfinedMotion);
/* 184 */       gd.addCheckbox("Show IDs", this.showID);
/* 185 */       gd.addCheckbox("Show overview classes", this.showOverviewClasses);
/* 186 */       gd.addCheckbox("Remove global drift", this.removeGlobalDrift);
/* 187 */       gd.addMessage("* The ratio of window size / resample rate have to be at least 30.");
/* 188 */       gd.addMessage("** Set to zero if the imported data is already correctly scaled.");
/* 189 */       gd.addHelp("http://imagej.net/TraJClassifier");
/* 190 */       gd.addDialogListener(new DialogListener()
/*     */           {
/*     */             public boolean dialogItemChanged(GenericDialog gd, AWTEvent e)
/*     */             {
/* 194 */               TraJClassifier_.this.minTrackLength = gd.getNextNumber();
/* 195 */               TraJClassifier_.this.windowSizeClassification = (int)gd.getNextNumber();
/* 196 */               TraJClassifier_.this.minSegmentLength = (int)gd.getNextNumber();
/* 197 */               TraJClassifier_.this.resampleRate = (int)gd.getNextNumber();
/* 198 */               TraJClassifier_.this.pixelsize = gd.getNextNumber();
/* 199 */               TraJClassifier_.this.timelag = 1.0D / gd.getNextNumber();
/* 200 */               TraJClassifier_.this.useReducedModelConfinedMotion = gd.getNextBoolean();
/* 201 */               TraJClassifier_.this.showID = gd.getNextBoolean();
/* 202 */               TraJClassifier_.this.showOverviewClasses = gd.getNextBoolean();
/* 203 */               TraJClassifier_.this.removeGlobalDrift = gd.getNextBoolean();
/* 204 */               boolean valid = (TraJClassifier_.this.windowSizeClassification / TraJClassifier_.this.resampleRate >= 30 && TraJClassifier_.this.minTrackLength >= TraJClassifier_.this.windowSizeClassification);
/*     */               
/* 206 */               return valid;
/*     */             }
/*     */           });
/* 209 */       gd.showDialog();
/* 210 */       if (gd.wasCanceled()) {
/*     */         return;
/*     */       }
/* 213 */       this.minTrackLength = gd.getNextNumber();
/* 214 */       this.windowSizeClassification = (int)(gd.getNextNumber() / 2.0D);
/* 215 */       this.minSegmentLength = (int)gd.getNextNumber();
/* 216 */       this.resampleRate = (int)gd.getNextNumber();
/* 217 */       this.pixelsize = gd.getNextNumber();
/* 218 */       this.timelag = 1.0D / gd.getNextNumber();
/* 219 */       this.useReducedModelConfinedMotion = gd.getNextBoolean();
/* 220 */       this.showID = gd.getNextBoolean();
/* 221 */       this.showOverviewClasses = gd.getNextBoolean();
/* 222 */       this.removeGlobalDrift = gd.getNextBoolean();
/*     */       
/* 224 */       Prefs.set("trajclass.minTrackLength", this.minTrackLength);
/* 225 */       Prefs.set("trajclass.windowSize", this.windowSizeClassification * 2);
/* 226 */       Prefs.set("trajclass.minSegmentLength", this.minSegmentLength);
/* 227 */       Prefs.set("trajclass.ResampleRate", this.resampleRate);
/* 228 */       Prefs.set("trajclass.pixelsize", this.pixelsize);
/* 229 */       Prefs.set("trajclass.framerate", 1.0D / this.timelag);
/* 230 */       Prefs.set("trajclass.showID", this.showID);
/* 231 */       Prefs.set("trajclass.showOverviewClasses", this.showOverviewClasses);
/* 232 */       Prefs.set("trajclass.removeGlobalDrift", this.removeGlobalDrift);
/* 233 */       Prefs.set("trajclass.useReducedModelConfinedMotion", this.useReducedModelConfinedMotion);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 240 */     if (this.pixelsize > 1.0E-6D) {
/* 241 */       for (int m = 0; m < this.tracksToClassify.size(); m++) {
/* 242 */         ((Trajectory)this.tracksToClassify.get(m)).scale(this.pixelsize);
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 254 */     HashMap<String, Color> mapTypeToColor = new HashMap<>();
/* 255 */     mapTypeToColor.put("DIRECTED/ACTIVE", Color.MAGENTA);
/* 256 */     mapTypeToColor.put("NORM. DIFFUSION", Color.RED);
/* 257 */     mapTypeToColor.put("CONFINED", Color.YELLOW);
/* 258 */     mapTypeToColor.put("SUBDIFFUSION", Color.GREEN);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 263 */     this.parentTrajectories = new ArrayList<>();
/* 264 */     for (Trajectory track : this.tracksToClassify) {
/* 265 */       if (track.size() > this.minTrackLength) {
/* 266 */         this.parentTrajectories.add(track);
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 273 */     StaticDriftCalculator<Trajectory> dcalc = new StaticDriftCalculator();
/* 274 */     if (this.removeGlobalDrift) {
/* 275 */       double[] drft = dcalc.calculateDrift(this.parentTrajectories);
/* 276 */       StaticDriftCorrector dcorr = new StaticDriftCorrector(drft);
/* 277 */       this.parentTrajectories = dcorr.removeDrift(this.parentTrajectories);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 284 */     this.classifiedTrajectories = classifyAndSegment(this.parentTrajectories, modelpath, this.windowSizeClassification, this.minSegmentLength, 10, this.resampleRate);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 290 */     if (visualize) {
/*     */       
/* 292 */       Overlay ov = new Overlay();
/* 293 */       for (int m = 0; m < this.classifiedTrajectories.size(); m++) {
/* 294 */         Subtrajectory tr = this.classifiedTrajectories.get(m);
/*     */         
/* 296 */         ArrayList<Roi> prois = null;
/* 297 */         if (this.pixelsize > 1.0E-6D) {
/*     */           
/* 299 */           prois = VisualizationUtils.generateVisualizationRoisFromTrack(tr, mapTypeToColor
/* 300 */               .get(tr.getType()), this.showID, this.pixelsize);
/*     */         
/*     */         }
/*     */         else {
/*     */           
/* 305 */           prois = VisualizationUtils.generateVisualizationRoisFromTrack(tr, mapTypeToColor
/* 306 */               .get(tr.getType()), this.showID, (IJ.getImage().getCalibration()).pixelWidth);
/*     */         } 
/* 308 */         for (Roi r : prois) {
/* 309 */           ov.add(r);
/*     */         }
/*     */       } 
/*     */ 
/*     */       
/* 314 */       if (this.showOverviewClasses) {
/* 315 */         Set<String> classes = mapTypeToColor.keySet();
/*     */         
/* 317 */         Iterator<String> it = classes.iterator();
/* 318 */         int y = 5;
/* 319 */         TextRoi.setFont("TimesRoman", 7, 0);
/*     */         
/* 321 */         while (it.hasNext()) {
/* 322 */           String type = it.next();
/* 323 */           TextRoi troi = new TextRoi(5, y, type);
/* 324 */           troi.setFillColor(Color.DARK_GRAY);
/* 325 */           troi.setStrokeColor(mapTypeToColor.get(type));
/* 326 */           ov.add((Roi)troi);
/* 327 */           y += 20;
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 332 */       IJ.getImage().setOverlay(ov);
/* 333 */       IJ.getImage().updateAndRepaintWindow();
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 342 */     HashMap<String, TraJResultsTable> rtables = new HashMap<>();
/* 343 */     rtables.put("DIRECTED/ACTIVE", new TraJResultsTable());
/* 344 */     rtables.put("NORM. DIFFUSION", new TraJResultsTable());
/* 345 */     rtables.put("SUBDIFFUSION", new TraJResultsTable());
/* 346 */     rtables.put("CONFINED", new TraJResultsTable());
/* 347 */     double sumConf = 0.0D;
/* 348 */     for (int j = 0; j < this.classifiedTrajectories.size(); j++) {
/* 349 */       RegressionDiffusionCoefficientEstimator regressionDiffusionCoefficientEstimator1; ActiveTransportParametersFeature apf; RegressionDiffusionCoefficientEstimator regressionDiffusionCoefficientEstimator2; ConfinedDiffusionParametersFeature confp; double[] p; PowerLawFeature pwf; IJ.showProgress(j, this.classifiedTrajectories.size());
/* 350 */       Subtrajectory t = this.classifiedTrajectories.get(j);
/* 351 */       TraJResultsTable rt = rtables.get(t.getType());
/* 352 */       if (rt == null) {
/* 353 */         IJ.log("Type: " + t.getType());
/* 354 */         IJ.log(t.toString());
/*     */       } 
/*     */       
/* 357 */       rt.incrementCounter();
/* 358 */       rt.addValue("PARENT-ID", t.getParent().getID());
/* 359 */       rt.addValue("ID", t.getID());
/* 360 */       rt.addValue("LENGTH", t.size());
/* 361 */       rt.addValue("START", t.getRelativeStartTimepoint());
/* 362 */       rt.addValue("END", (t.getRelativeStartTimepoint() + t.size() - 1));
/* 363 */       rt.addValue("CLASS", t.getType());
/*     */       
/* 365 */       AbstractTrajectoryFeature dcEstim = null;
/* 366 */       double dc = 0.0D;
/* 367 */       DecimalFormatSymbols otherSymbols = new DecimalFormatSymbols(Locale.ENGLISH);
/* 368 */       NumberFormat formatter = new DecimalFormat("0.###E0", otherSymbols);
/*     */       
/* 370 */       double goodness = 0.0D;
/* 371 */       double alphaGoodness = 0.0D;
/* 372 */       switch (t.getType()) {
/*     */         
/*     */         case "DIRECTED/ACTIVE":
/* 375 */           apf = new ActiveTransportParametersFeature(t, this.timelag);
/*     */ 
/*     */ 
/*     */           
/* 379 */           res = apf.evaluate();
/* 380 */           rt.addValue("(FIT) D", formatter.format(res[0]));
/* 381 */           rt.addValue("(FIT) Velocity", res[1]);
/* 382 */           goodness = res[2];
/*     */           break;
/*     */         
/*     */         case "NORM. DIFFUSION":
/* 386 */           regressionDiffusionCoefficientEstimator1 = new RegressionDiffusionCoefficientEstimator(t, 1.0D / this.timelag, 1, t.size() / 3);
/* 387 */           res = regressionDiffusionCoefficientEstimator1.evaluate();
/* 388 */           dc = res[0];
/* 389 */           rt.addValue("(FIT) D", formatter.format(dc));
/* 390 */           goodness = res[3];
/*     */           break;
/*     */         
/*     */         case "CONFINED":
/* 394 */           regressionDiffusionCoefficientEstimator2 = new RegressionDiffusionCoefficientEstimator(t, 1.0D / this.timelag, 1, 3);
/* 395 */           confp = new ConfinedDiffusionParametersFeature(t, this.timelag, this.useReducedModelConfinedMotion, (AbstractDiffusionCoefficientEstimator)regressionDiffusionCoefficientEstimator2);
/* 396 */           p = confp.evaluate();
/* 397 */           dc = p[1];
/* 398 */           if (this.useReducedModelConfinedMotion) {
/* 399 */             rt.addValue("(FIT) CONF. RADIUS", Math.sqrt(p[0]));
/* 400 */             rt.addValue("(FIT) D", formatter.format(p[1]));
/* 401 */             goodness = p[2]; break;
/*     */           } 
/* 403 */           rt.addValue("(FIT) CONF. RADIUS", Math.sqrt(p[0]));
/* 404 */           rt.addValue("(FIT) A [CONF. SHAPE]", p[2]);
/* 405 */           rt.addValue("(FIT) B (CONF SHAPE)", p[3]);
/* 406 */           rt.addValue("(FIT) D", formatter.format(p[1]));
/* 407 */           goodness = p[4];
/*     */           break;
/*     */ 
/*     */ 
/*     */         
/*     */         case "SUBDIFFUSION":
/* 413 */           pwf = new PowerLawFeature(t, 1.0D / this.timelag, 1, t.size() / 3);
/* 414 */           res = pwf.evaluate();
/* 415 */           dc = res[1];
/*     */           
/* 417 */           rt.addValue("(FIT) D", formatter.format(dc));
/*     */           
/* 419 */           goodness = res[2];
/*     */           break;
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 425 */       PowerLawFeature powerLawFeature1 = new PowerLawFeature(t, 1.0D / this.timelag, 1, t.size() / 3);
/* 426 */       double[] res = powerLawFeature1.evaluate();
/* 427 */       double alpha = res[0];
/* 428 */       alphaGoodness = res[2];
/*     */ 
/*     */       
/* 431 */       CenterOfGravityFeature centerOfGravityFeature = new CenterOfGravityFeature(t);
/* 432 */       double cog_x = centerOfGravityFeature.evaluate()[0];
/* 433 */       double cog_y = centerOfGravityFeature.evaluate()[1];
/* 434 */       rt.addValue("X (COG)", cog_x);
/* 435 */       rt.addValue("Y (COG)", cog_y);
/*     */       
/* 437 */       if (!t.getType().equals("NONE")) {
/* 438 */         FractalDimensionFeature fdf = new FractalDimensionFeature(t);
/* 439 */         double v = fdf.evaluate()[0];
/* 440 */         rt.addValue("FRACT. DIM.", v);
/*     */         
/* 442 */         TrappedProbabilityFeature trapped = new TrappedProbabilityFeature(t);
/* 443 */         v = trapped.evaluate()[0];
/* 444 */         rt.addValue("TRAPPEDNESS", v);
/*     */         
/* 446 */         EfficiencyFeature eff = new EfficiencyFeature(t);
/* 447 */         v = eff.evaluate()[0];
/* 448 */         rt.addValue("EFFICENCY", v);
/*     */         
/* 450 */         StraightnessFeature straight = new StraightnessFeature(t);
/* 451 */         v = straight.evaluate()[0];
/* 452 */         rt.addValue("STRAIGHTNESS", v);
/*     */         
/* 454 */         MeanSpeedFeature msfeature = new MeanSpeedFeature(t, this.timelag);
/* 455 */         v = msfeature.evaluate()[1];
/* 456 */         rt.addValue("SPEED", v);
/*     */         
/* 458 */         KurtosisFeature kurt = new KurtosisFeature(t);
/* 459 */         v = kurt.evaluate()[0];
/* 460 */         rt.addValue("KURTOSIS", v);
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 465 */         rt.addValue("(FIT) ALPHA", alpha);
/*     */         
/* 467 */         GaussianityFeauture gauss = new GaussianityFeauture(t, 1);
/* 468 */         v = gauss.evaluate()[0];
/* 469 */         rt.addValue("GAUSSIANITY", v);
/*     */         
/* 471 */         Asymmetry3Feature asym3 = new Asymmetry3Feature(t);
/* 472 */         v = asym3.evaluate()[0];
/* 473 */         rt.addValue("Asymmetry", v);
/*     */         
/* 475 */         MSDRatioFeature msdratio = new MSDRatioFeature(t, 1, 5);
/* 476 */         v = msdratio.evaluate()[0];
/* 477 */         rt.addValue("MSDRatio", v);
/*     */         
/* 479 */         CovarianceDiffusionCoefficientEstimator cest = new CovarianceDiffusionCoefficientEstimator(t, 1.0D / this.timelag);
/* 480 */         res = cest.evaluate();
/* 481 */         rt.addValue("Loc. noise_sigma", (res[1] + res[2]) / 2.0D);
/* 482 */         rt.addValue("Fit Goodness", goodness);
/* 483 */         rt.addValue("Alpha Fit Goodness", alphaGoodness);
/* 484 */         double conf = t.getConfidence();
/* 485 */         sumConf += conf;
/* 486 */         rt.addValue("Confidence", conf);
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 495 */     Iterator<String> rtIt = rtables.keySet().iterator();
/*     */     
/* 497 */     ResultsTable parents = new TraJResultsTable(true);
/*     */     
/* 499 */     for (int k = 0; k < this.parentTrajectories.size(); k++) {
/* 500 */       parents.incrementCounter();
/* 501 */       Trajectory t = this.parentTrajectories.get(k);
/* 502 */       parents.addValue("ID", t.getID());
/* 503 */       parents.addValue("LENGTH", t.size());
/* 504 */       parents.addValue("START", t.getRelativeStartTimepoint());
/* 505 */       parents.addValue("END", (t.getRelativeStartTimepoint() + t.size() - 1));
/* 506 */       int subPosCount = 0;
/* 507 */       int subSegCount = 0;
/* 508 */       int normPosCount = 0;
/* 509 */       int normSegCount = 0;
/* 510 */       int directedPosCount = 0;
/* 511 */       int directSegCount = 0;
/* 512 */       int confPosCount = 0;
/* 513 */       int confSegCount = 0;
/*     */       
/* 515 */       ArrayList<Subtrajectory> sameParent = Subtrajectory.getTracksWithSameParant(this.classifiedTrajectories, t.getID());
/* 516 */       for (Subtrajectory sub : sameParent) {
/* 517 */         switch (sub.getType()) {
/*     */           case "DIRECTED/ACTIVE":
/* 519 */             directedPosCount += sub.size();
/* 520 */             directSegCount++;
/*     */           
/*     */           case "NORM. DIFFUSION":
/* 523 */             normPosCount += sub.size();
/* 524 */             normSegCount++;
/*     */           
/*     */           case "CONFINED":
/* 527 */             confPosCount += sub.size();
/* 528 */             confSegCount++;
/*     */           
/*     */           case "SUBDIFFUSION":
/* 531 */             subPosCount += sub.size();
/* 532 */             subSegCount++;
/*     */         } 
/*     */ 
/*     */ 
/*     */       
/*     */       } 
/* 538 */       parents.addValue("#SEG_NORM", normSegCount);
/* 539 */       parents.addValue("#POS_NORM", normPosCount);
/* 540 */       parents.addValue("#SEG_SUB", subSegCount);
/* 541 */       parents.addValue("#POS_SUB", subPosCount);
/* 542 */       parents.addValue("#SEG_CONF", confSegCount);
/* 543 */       parents.addValue("#POS_CONF", confPosCount);
/* 544 */       parents.addValue("#SEG_DIRECTED", directSegCount);
/* 545 */       parents.addValue("#POS_DIRECTED", directedPosCount);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 561 */     double[] drift = dcalc.calculateDrift(this.parentTrajectories);
/* 562 */     ResultsTable overall = new ResultsTable();
/* 563 */     overall.incrementCounter();
/* 564 */     overall.addValue("Mean confindence", sumConf / this.classifiedTrajectories.size());
/* 565 */     overall.addValue("Drift x", drift[0]);
/* 566 */     overall.addValue("Drift y", drift[1]);
/* 567 */     overall.addValue("Min. track length", this.minTrackLength);
/* 568 */     overall.addValue("Window size", (this.windowSizeClassification * 2));
/* 569 */     overall.addValue("Min. segment length", this.minSegmentLength);
/* 570 */     overall.addValue("Resamplerate", this.resampleRate);
/* 571 */     overall.addValue("Pixelsize", this.pixelsize);
/* 572 */     overall.addValue("Framerate", 1.0D / this.timelag);
/* 573 */     overall.addValue("Reduced conf. model", Boolean.toString(this.useReducedModelConfinedMotion));
/* 574 */     overall.addValue("Remove global drift", Boolean.toString(this.removeGlobalDrift));
/* 575 */     overall.show("Settings & Miscellaneous");
/*     */ 
/*     */ 
/*     */     
/* 579 */     parents.show("Parents");
/* 580 */     rtIt = rtables.keySet().iterator();
/* 581 */     while (rtIt.hasNext()) {
/* 582 */       String rt = rtIt.next();
/* 583 */       ((TraJResultsTable)rtables.get(rt)).show(rt + " trajectories");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ArrayList<Subtrajectory> classifyAndSegment(Trajectory trackToClassify, String modelpath, int windowSizeClassification, int minSegmentLength, int modeFilterLength, int resampleRate) {
/* 590 */     ArrayList<Trajectory> help = new ArrayList<>();
/* 591 */     help.add(trackToClassify);
/* 592 */     return classifyAndSegment(help, modelpath, windowSizeClassification, minSegmentLength, modeFilterLength, resampleRate);
/*     */   }
/*     */   
/*     */   public ArrayList<Subtrajectory> classifyAndSegment(ArrayList<Trajectory> tracksToClassify, String modelpath, int windowSizeClassification, int minSegmentLength, int modeFilterLength, int resampleRate) {
/* 596 */     ArrayList<Subtrajectory> classified = new ArrayList<>();
/* 597 */     int j = 0;
/* 598 */     RRFClassifierRenjin rrf = new RRFClassifierRenjin(modelpath, resampleRate * this.timelag);
/* 599 */     rrf.start();
/* 600 */     WeightedWindowedClassificationProcess wcp = new WeightedWindowedClassificationProcess();
/* 601 */     int subidcounter = 1;
/* 602 */     for (Trajectory track : tracksToClassify) {
/* 603 */       j++;
/* 604 */       IJ.showProgress(j, tracksToClassify.size());
/* 605 */       Trajectory mTrack = track;
/*     */       
/* 607 */       String[] classes = wcp.windowedClassification(mTrack, rrf, windowSizeClassification, resampleRate);
/* 608 */       double[] classConfidence = wcp.getPositionConfidence();
/*     */       
/* 610 */       classes = movingMode(classes, modeFilterLength);
/* 611 */       double sumConf = 0.0D;
/* 612 */       int Nconf = 0;
/* 613 */       Subtrajectory tr = new Subtrajectory(track, 2);
/*     */       
/* 615 */       tr.setID(subidcounter);
/* 616 */       subidcounter++;
/* 617 */       tr.add(((Point3d)track.get(0)).x, ((Point3d)track.get(0)).y, 0.0D);
/* 618 */       sumConf += classConfidence[0];
/* 619 */       Nconf++;
/* 620 */       String prevCls = classes[0];
/* 621 */       int start = track.getRelativeStartTimepoint();
/* 622 */       tr.setRelativStartTimepoint(start);
/* 623 */       tr.setType(prevCls);
/*     */       
/* 625 */       for (int k = 1; k < classes.length; k++) {
/* 626 */         if (prevCls == classes[k]) {
/* 627 */           tr.add(((Point3d)track.get(k)).x, ((Point3d)track.get(k)).y, 0.0D);
/* 628 */           sumConf += classConfidence[k];
/* 629 */           Nconf++;
/*     */         } else {
/* 631 */           tr.setConfidence(sumConf / Nconf);
/* 632 */           classified.add(tr);
/* 633 */           tr = new Subtrajectory(track, 2);
/* 634 */           tr.setID(subidcounter);
/* 635 */           subidcounter++;
/* 636 */           tr.setRelativStartTimepoint(start + k);
/* 637 */           tr.add(((Point3d)track.get(k)).x, ((Point3d)track.get(k)).y, 0.0D);
/* 638 */           sumConf = classConfidence[k];
/* 639 */           Nconf = 1;
/* 640 */           prevCls = classes[k];
/* 641 */           tr.setType(prevCls);
/*     */         } 
/*     */       } 
/* 644 */       tr.setConfidence(sumConf / Nconf);
/* 645 */       classified.add(tr);
/* 646 */       sumConf = 0.0D;
/* 647 */       Nconf = 0;
/*     */     } 
/* 649 */     rrf.stop();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 658 */     for (int i = 0; i < classified.size(); i++) {
/* 659 */       if (((Subtrajectory)classified.get(i)).size() < minSegmentLength) {
/* 660 */         classified.remove(i);
/* 661 */         i--;
/*     */       } 
/*     */     } 
/* 664 */     return classified;
/*     */   }
/*     */   
/*     */   public double getTimelag() {
/* 668 */     return this.timelag;
/*     */   }
/*     */   public static String[] movingMode(String[] types, int n) {
/* 671 */     ArrayList<String> ltypes = new ArrayList<>();
/* 672 */     for (int i = 0; i < types.length; i++) {
/* 673 */       ltypes.add(types[i]);
/*     */     }
/* 675 */     return movingMode(ltypes, n);
/*     */   }
/*     */   
/*     */   public static String[] movingMode(ArrayList<String> types, int n) {
/* 679 */     int windowsize = 2 * n + 1;
/* 680 */     HashSet<String> uniqueTypes = new HashSet<>();
/* 681 */     uniqueTypes.addAll(types);
/* 682 */     HashMap<String, Integer> mapTypeToInt = new HashMap<>();
/* 683 */     HashMap<Integer, String> mapIntToType = new HashMap<>();
/* 684 */     Iterator<String> it = uniqueTypes.iterator();
/* 685 */     int key = 0;
/* 686 */     while (it.hasNext()) {
/* 687 */       String type = it.next();
/* 688 */       mapTypeToInt.put(type, Integer.valueOf(key));
/* 689 */       mapIntToType.put(Integer.valueOf(key), type);
/* 690 */       key++;
/*     */     } 
/*     */     
/* 693 */     String[] medTypes = new String[types.size()];
/*     */     int i;
/* 695 */     for (i = 0; i < n; i++) {
/* 696 */       medTypes[i] = types.get(i);
/*     */     }
/* 698 */     for (i = types.size() - n; i < types.size(); i++) {
/* 699 */       medTypes[i] = types.get(i);
/*     */     }
/*     */     
/* 702 */     for (i = 0; i < types.size() - windowsize + 1; i++) {
/* 703 */       List<String> sub = types.subList(i, i + windowsize - 1);
/* 704 */       double[] values = new double[sub.size()];
/* 705 */       for (int j = 0; j < sub.size(); j++) {
/* 706 */         values[j] = ((Integer)mapTypeToInt.get(sub.get(j))).intValue();
/*     */       }
/*     */       
/* 709 */       medTypes[i + n] = mapIntToType.get(Integer.valueOf((int)StatUtils.mode(values)[0]));
/*     */     } 
/* 711 */     return medTypes;
/*     */   }
/*     */   
/*     */   public ArrayList<Subtrajectory> getClassifiedTrajectories() {
/* 715 */     return this.classifiedTrajectories;
/*     */   }
/*     */   
/*     */   public ArrayList<Trajectory> getParentTrajectories() {
/* 719 */     return this.parentTrajectories;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String ExportResource(String resourceName) throws Exception {
/*     */     String tmpFolder;
/* 731 */     InputStream stream = null;
/* 732 */     OutputStream resStreamOut = null;
/*     */     
/*     */     try {
/* 735 */       stream = getClass().getResourceAsStream(resourceName);
/* 736 */       if (stream == null) {
/* 737 */         IJ.error("Cannot get resource \"" + resourceName + "\" from Jar file.");
/* 738 */         throw new Exception("Cannot get resource \"" + resourceName + "\" from Jar file.");
/*     */       } 
/*     */ 
/*     */       
/* 742 */       byte[] buffer = new byte[4096];
/* 743 */       File folderDir = new File(IJ.getDirectory("temp") + "/.trajclassifier");
/*     */ 
/*     */       
/* 746 */       if (!folderDir.exists()) {
/* 747 */         folderDir.mkdir();
/*     */       }
/* 749 */       tmpFolder = folderDir.getPath().replace('\\', '/');
/* 750 */       resStreamOut = new FileOutputStream(tmpFolder + resourceName); int readBytes;
/* 751 */       while ((readBytes = stream.read(buffer)) > 0) {
/* 752 */         resStreamOut.write(buffer, 0, readBytes);
/*     */       }
/* 754 */     } catch (Exception ex) {
/* 755 */       IJ.error(ex.getMessage());
/* 756 */       throw ex;
/*     */     } finally {
/* 758 */       stream.close();
/* 759 */       resStreamOut.close();
/*     */     } 
/*     */     
/* 762 */     return tmpFolder + resourceName;
/*     */   }
/*     */   
/*     */   public void setTracksToClassify(ArrayList<Trajectory> t) {
/* 766 */     this.tracksToClassify = t;
/*     */   }
/*     */ 
/*     */   
/*     */   public double getMinTrackLength() {
/* 771 */     return this.minTrackLength;
/*     */   }
/*     */   
/*     */   public void setMinTrackLength(double minTrackLength) {
/* 775 */     this.minTrackLength = minTrackLength;
/*     */   }
/*     */   
/*     */   public double getPixelsize() {
/* 779 */     return this.pixelsize;
/*     */   }
/*     */   
/*     */   public void setPixelsize(double pixelsize) {
/* 783 */     this.pixelsize = pixelsize;
/*     */   }
/*     */   
/*     */   public boolean isShowID() {
/* 787 */     return this.showID;
/*     */   }
/*     */   
/*     */   public void setShowID(boolean showID) {
/* 791 */     this.showID = showID;
/*     */   }
/*     */   
/*     */   public int getWindowSizeClassification() {
/* 795 */     return this.windowSizeClassification;
/*     */   }
/*     */   
/*     */   public boolean isUseReducedModelConfinedMotion() {
/* 799 */     return this.useReducedModelConfinedMotion;
/*     */   }
/*     */   
/*     */   public void setTimelag(double timelag) {
/* 803 */     this.timelag = timelag;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setWindowSizeClassification(int windowSizeClassification) {
/* 809 */     this.windowSizeClassification = windowSizeClassification;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/ij_trajectory_classifier-0.8.2.jar!/de/biomedical_imaging/ij/trajectory_classifier/TraJClassifier_.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */