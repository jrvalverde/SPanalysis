/*     */ package de.biomedical_imaging.ij.trajectory_classifier.help;
/*     */ 
/*     */ import de.biomedical_imaging.traJ.ExportTools;
/*     */ import de.biomedical_imaging.traJ.Trajectory;
/*     */ import de.biomedical_imaging.traJ.features.BoundednessFeature;
/*     */ import de.biomedical_imaging.traJ.simulation.AbstractSimulator;
/*     */ import de.biomedical_imaging.traJ.simulation.ActiveTransportSimulator;
/*     */ import de.biomedical_imaging.traJ.simulation.AnomalousDiffusionWMSimulation;
/*     */ import de.biomedical_imaging.traJ.simulation.CentralRandomNumberGenerator;
/*     */ import de.biomedical_imaging.traJ.simulation.CombinedSimulator;
/*     */ import de.biomedical_imaging.traJ.simulation.ConfinedDiffusionSimulator;
/*     */ import de.biomedical_imaging.traJ.simulation.FreeDiffusionSimulator;
/*     */ import de.biomedical_imaging.traJ.simulation.SimulationUtil;
/*     */ import java.util.ArrayList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GenerateTrainingSet
/*     */ {
/*     */   private static CentralRandomNumberGenerator r;
/*     */   
/*     */   enum SIM_TYPE
/*     */   {
/*  37 */     FREE,
/*  38 */     ANOMALOUS,
/*  39 */     CONFINED,
/*  40 */     ACTIVE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void main(String[] args) {
/*  47 */     int MODE_TRAINING = 1;
/*  48 */     int MODE_TEST = 2;
/*  49 */     int MODE_VALIDATION = 3;
/*     */ 
/*     */ 
/*     */     
/*  53 */     int numberOfTracks = 0;
/*  54 */     int seed = 0;
/*  55 */     int MODE = 1;
/*  56 */     String prefix = "";
/*  57 */     switch (MODE) {
/*     */       case 1:
/*  59 */         numberOfTracks = 5000;
/*  60 */         seed = 22;
/*  61 */         prefix = "training";
/*     */         break;
/*     */       case 2:
/*  64 */         numberOfTracks = 1000;
/*  65 */         prefix = "test";
/*  66 */         seed = 23;
/*     */         break;
/*     */       case 3:
/*  69 */         numberOfTracks = 250;
/*  70 */         prefix = "validation";
/*  71 */         seed = 24;
/*     */         break;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/*  77 */     String path = "/home/thorsten/tracks_" + prefix + ".RData";
/*  78 */     r = CentralRandomNumberGenerator.getInstance();
/*  79 */     r.setSeed(seed);
/*     */     
/*  81 */     double diffusioncoefficient = 9.02D;
/*  82 */     double timelag = 0.03333333333333333D;
/*  83 */     int dimension = 2;
/*     */ 
/*     */     
/*  86 */     double angleVelocity = 0.7853981633974483D;
/*     */ 
/*     */     
/*  89 */     SIM_TYPE[] types = SIM_TYPE.values();
/*  90 */     ArrayList<Trajectory> trajectorys = new ArrayList<>();
/*     */     
/*  92 */     System.out.println("Generation of free, confined , subdiffsuion and active trajectories");
/*  93 */     int tCounter = 0;
/*  94 */     for (SIM_TYPE type : types) {
/*     */       
/*  96 */       for (int i = 0; i < numberOfTracks; i++) {
/*  97 */         FreeDiffusionSimulator freeDiffusionSimulator1; ConfinedDiffusionSimulator confinedDiffusionSimulator; CombinedSimulator combinedSimulator; AnomalousDiffusionWMSimulation anomalousDiffusionWMSimulation; double radius_confined, aToDRatio, drift; ActiveTransportSimulator activeTransportSimulator; FreeDiffusionSimulator freeDiffusionSimulator2; double tracklength = 1.0D + r.nextDouble() * 20.0D;
/*  98 */         int numberOfSteps = (int)(tracklength * 1.0D / timelag);
/*  99 */         double boundedness = 1.0D + r.nextDouble() * 20.0D;
/* 100 */         double alpha = 0.3D + r.nextDouble() * 0.4D;
/* 101 */         AbstractSimulator sim = null;
/* 102 */         String typestring = "";
/* 103 */         typestring = typestring + type.toString();
/* 104 */         Trajectory t = null;
/* 105 */         double diffusionToNoiseRatio = 1.0D + r.nextDouble() * 8.0D;
/* 106 */         double sigmaPosNoise = 1.0D;
/* 107 */         switch (type) {
/*     */           
/*     */           case FREE:
/* 110 */             freeDiffusionSimulator1 = new FreeDiffusionSimulator(diffusioncoefficient, timelag, dimension, numberOfSteps);
/* 111 */             sigmaPosNoise = Math.sqrt(diffusioncoefficient * timelag) / diffusionToNoiseRatio;
/*     */             break;
/*     */           
/*     */           case CONFINED:
/* 115 */             radius_confined = Math.sqrt(BoundednessFeature.a(numberOfSteps) * diffusioncoefficient * timelag / 4.0D * boundedness);
/* 116 */             confinedDiffusionSimulator = new ConfinedDiffusionSimulator(diffusioncoefficient, timelag, radius_confined, dimension, numberOfSteps);
/* 117 */             sigmaPosNoise = Math.sqrt(diffusioncoefficient * timelag) / diffusionToNoiseRatio;
/*     */             break;
/*     */           case ACTIVE:
/* 120 */             aToDRatio = 2.0D + r.nextDouble() * 16.0D;
/* 121 */             drift = Math.sqrt(aToDRatio * 4.0D * diffusioncoefficient / tracklength);
/* 122 */             activeTransportSimulator = new ActiveTransportSimulator(drift, angleVelocity, timelag, dimension, numberOfSteps);
/* 123 */             freeDiffusionSimulator2 = new FreeDiffusionSimulator(diffusioncoefficient, timelag, dimension, numberOfSteps);
/* 124 */             combinedSimulator = new CombinedSimulator((AbstractSimulator)activeTransportSimulator, (AbstractSimulator)freeDiffusionSimulator2);
/* 125 */             sigmaPosNoise = Math.sqrt(diffusioncoefficient * timelag + drift * drift * timelag * timelag) / diffusionToNoiseRatio;
/*     */             break;
/*     */           case ANOMALOUS:
/* 128 */             anomalousDiffusionWMSimulation = new AnomalousDiffusionWMSimulation(diffusioncoefficient, timelag, dimension, 2000, alpha);
/* 129 */             sigmaPosNoise = Math.sqrt(diffusioncoefficient * timelag) / diffusionToNoiseRatio;
/*     */             break;
/*     */         } 
/*     */ 
/*     */ 
/*     */         
/* 135 */         t = anomalousDiffusionWMSimulation.generateTrajectory();
/* 136 */         if (type == SIM_TYPE.ANOMALOUS) {
/* 137 */           t = t.subList(0, numberOfSteps + 1);
/*     */         }
/*     */ 
/*     */ 
/*     */         
/* 142 */         t = SimulationUtil.addPositionNoise(t, sigmaPosNoise);
/*     */         
/* 144 */         t.setType(typestring);
/* 145 */         trajectorys.add(t);
/* 146 */         tCounter++;
/* 147 */         if (tCounter % 10 == 0) {
/* 148 */           System.out.println("T: " + tCounter + " Type " + t.getType());
/*     */         }
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 154 */     System.out.println("Tracks generated");
/* 155 */     ExportTools.exportTrajectoriesAsRData(trajectorys, path, timelag);
/* 156 */     trajectorys = null;
/* 157 */     System.out.println("Export done");
/*     */ 
/*     */     
/* 160 */     System.out.println("Done!");
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/ij_trajectory_classifier-0.8.2.jar!/de/biomedical_imaging/ij/trajectory_classifier/help/GenerateTrainingSet.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */