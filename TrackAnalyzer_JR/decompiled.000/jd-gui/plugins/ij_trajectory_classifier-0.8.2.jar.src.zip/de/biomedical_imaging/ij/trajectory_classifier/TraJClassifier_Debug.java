/*     */ package de.biomedical_imaging.ij.trajectory_classifier;
/*     */ 
/*     */ import de.biomedical_imaging.ij.trajectory_classifier.help.StalledSimulator;
/*     */ import de.biomedical_imaging.traJ.DiffusionCoefficientEstimator.RegressionDiffusionCoefficientEstimator;
/*     */ import de.biomedical_imaging.traJ.Trajectory;
/*     */ import de.biomedical_imaging.traJ.TrajectoryUtil;
/*     */ import de.biomedical_imaging.traJ.VisualizationUtils;
/*     */ import de.biomedical_imaging.traJ.features.Asymmetry2Feature;
/*     */ import de.biomedical_imaging.traJ.features.Asymmetry3Feature;
/*     */ import de.biomedical_imaging.traJ.features.AsymmetryFeature;
/*     */ import de.biomedical_imaging.traJ.features.BoundednessFeature;
/*     */ import de.biomedical_imaging.traJ.features.EfficiencyFeature;
/*     */ import de.biomedical_imaging.traJ.features.ElongationFeature;
/*     */ import de.biomedical_imaging.traJ.features.FractalDimensionFeature;
/*     */ import de.biomedical_imaging.traJ.features.GaussianityFeauture;
/*     */ import de.biomedical_imaging.traJ.features.KurtosisFeature;
/*     */ import de.biomedical_imaging.traJ.features.MSDRatioFeature;
/*     */ import de.biomedical_imaging.traJ.features.MaxDistanceBetweenTwoPositionsFeature;
/*     */ import de.biomedical_imaging.traJ.features.MeanSquaredDisplacmentCurvature;
/*     */ import de.biomedical_imaging.traJ.features.MeanSquaredDisplacmentFeature;
/*     */ import de.biomedical_imaging.traJ.features.PowerLawFeature;
/*     */ import de.biomedical_imaging.traJ.features.ShortTimeLongTimeDiffusioncoefficentRatio;
/*     */ import de.biomedical_imaging.traJ.features.SkewnessFeature;
/*     */ import de.biomedical_imaging.traJ.features.SplineCurveDynamicsFeature;
/*     */ import de.biomedical_imaging.traJ.features.StraightnessFeature;
/*     */ import de.biomedical_imaging.traJ.features.TrappedProbabilityFeature;
/*     */ import de.biomedical_imaging.traJ.simulation.AbstractSimulator;
/*     */ import de.biomedical_imaging.traJ.simulation.ActiveTransportSimulator;
/*     */ import de.biomedical_imaging.traJ.simulation.AnomalousDiffusionWMSimulation;
/*     */ import de.biomedical_imaging.traJ.simulation.CentralRandomNumberGenerator;
/*     */ import de.biomedical_imaging.traJ.simulation.CombinedSimulator;
/*     */ import de.biomedical_imaging.traJ.simulation.ConfinedDiffusionSimulator;
/*     */ import de.biomedical_imaging.traJ.simulation.FreeDiffusionSimulator;
/*     */ import de.biomedical_imaging.traJ.simulation.SimulationUtil;
/*     */ import ij.IJ;
/*     */ import ij.ImageJ;
/*     */ import ij.ImagePlus;
/*     */ import ij.ImageStack;
/*     */ import ij.measure.CurveFitter;
/*     */ import ij.process.ByteProcessor;
/*     */ import ij.process.ImageProcessor;
/*     */ import java.awt.Color;
/*     */ import java.io.File;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.apache.commons.lang3.ArrayUtils;
/*     */ import org.apache.commons.math.stat.descriptive.rank.Max;
/*     */ import org.apache.commons.math.stat.descriptive.rank.Median;
/*     */ import org.apache.commons.math.stat.descriptive.rank.Min;
/*     */ import org.apache.commons.math3.stat.StatUtils;
/*     */ import org.apache.commons.math3.stat.descriptive.moment.Mean;
/*     */ import org.apache.commons.math3.stat.descriptive.moment.StandardDeviation;
/*     */ import org.knowm.xchart.Chart;
/*     */ import org.knowm.xchart.Series;
/*     */ import org.knowm.xchart.SeriesMarker;
/*     */ import org.knowm.xchart.SwingWrapper;
/*     */ import org.scijava.vecmath.Point3d;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TraJClassifier_Debug
/*     */ {
/*     */   public static void main(String[] args) {
/*  97 */     TraJClassifier_Debug db = new TraJClassifier_Debug();
/*     */     
/*  99 */     StalledSimulator stallSim = new StalledSimulator(30, 1.0D);
/* 100 */     double[] val = new double[1000];
/* 101 */     for (int i = 0; i < 1000; i++) {
/* 102 */       Trajectory t = stallSim.generateTrajectory();
/* 103 */       PowerLawFeature pwf = new PowerLawFeature(t, 1.0D, 1, t.size() / 3);
/* 104 */       val[i] = pwf.evaluate()[0];
/*     */     } 
/* 106 */     Mean m = new Mean();
/* 107 */     StandardDeviation sd = new StandardDeviation();
/* 108 */     Median med = new Median();
/* 109 */     Max max = new Max();
/* 110 */     Min min = new Min();
/*     */     
/* 112 */     System.out.println("Mean: " + m.evaluate(val) + " SD: " + sd.evaluate(val) + " Median: " + med.evaluate(val) + " Min: " + min.evaluate(val) + " Max: " + max.evaluate(val));
/*     */   }
/*     */ 
/*     */   
/*     */   public void analyseConfidence() {
/* 117 */     CentralRandomNumberGenerator.getInstance().setSeed(10L);
/*     */     
/* 119 */     String modelpath = "";
/*     */     try {
/* 121 */       modelpath = ExportResource("/randomForestModel.RData");
/* 122 */     } catch (Exception e) {
/*     */       
/* 124 */       e.printStackTrace();
/*     */     } 
/*     */     
/* 127 */     double diffusioncoefficient = 1.0D;
/* 128 */     double timelag = 1.0D;
/* 129 */     int dimension = 2;
/* 130 */     int N = 100;
/* 131 */     int Nsteps = 800;
/* 132 */     double boundedness = 4.0D;
/* 133 */     double R = 60.0D;
/* 134 */     double drift = Math.sqrt(R * 4.0D * diffusioncoefficient / 90.0D);
/* 135 */     FreeDiffusionSimulator freeSim = new FreeDiffusionSimulator(diffusioncoefficient, timelag, dimension, Nsteps);
/* 136 */     ActiveTransportSimulator activeSim = new ActiveTransportSimulator(drift, 0.0D, timelag, dimension, Nsteps);
/* 137 */     CombinedSimulator directedSim = new CombinedSimulator((AbstractSimulator)freeSim, (AbstractSimulator)activeSim);
/* 138 */     AnomalousDiffusionWMSimulation anomSim = new AnomalousDiffusionWMSimulation(diffusioncoefficient, timelag, dimension, 2000, 0.3D);
/* 139 */     Trajectory th = anomSim.generateTrajectory().subList(0, Nsteps);
/* 140 */     Trajectory t = TrajectoryUtil.concactTrajectorie(directedSim.generateTrajectory(), th);
/* 141 */     RRFClassifierRenjin ren = new RRFClassifierRenjin(modelpath, timelag);
/* 142 */     ren.start();
/* 143 */     WeightedWindowedClassificationProcess wwcp = new WeightedWindowedClassificationProcess();
/* 144 */     String[] classes = wwcp.windowedClassification(t, ren, 45, 1);
/* 145 */     ren.stop();
/* 146 */     VisualizationUtils.plotChart(VisualizationUtils.getTrajectoryChart(t));
/* 147 */     double[] conf = wwcp.getPositionConfidence();
/* 148 */     for (int i = 0; i < conf.length; i++) {
/* 149 */       System.out.println((i + 1) + "\t" + conf[i] + "\t" + classes[i]);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void testSubsampling() {
/* 155 */     CentralRandomNumberGenerator.getInstance().setSeed(10L);
/* 156 */     String modelpath = "";
/*     */     try {
/* 158 */       modelpath = ExportResource("/randomForestModel.RData");
/* 159 */     } catch (Exception e) {
/*     */       
/* 161 */       e.printStackTrace();
/*     */     } 
/*     */     
/* 164 */     double diffusioncoefficient = 50.0D;
/* 165 */     double SNR = 5.0D;
/* 166 */     int n = 1;
/* 167 */     double sigma = Math.sqrt(diffusioncoefficient * 1.0D / 30.0D) / SNR;
/* 168 */     FreeDiffusionSimulator freesim = new FreeDiffusionSimulator(diffusioncoefficient, 0.03333333333333333D, 2, 250);
/* 169 */     int N = 2000;
/* 170 */     RRFClassifierRenjin cl = new RRFClassifierRenjin(modelpath, 0.03333333333333333D);
/*     */     
/* 172 */     cl.start();
/* 173 */     ArrayList<Trajectory> tracks = new ArrayList<>();
/* 174 */     for (int i = 0; i < N; i++) {
/* 175 */       Trajectory t = freesim.generateTrajectory();
/* 176 */       t = SimulationUtil.addPositionNoise(t, sigma);
/* 177 */       t = TrajectoryUtil.resample(t, n);
/*     */       
/* 179 */       tracks.add(t);
/*     */     } 
/* 181 */     cl.setTimelag(n * 1.0D / 30.0D);
/* 182 */     String[] res = cl.classify(tracks);
/*     */     
/* 184 */     int scounter = 0;
/* 185 */     int ncounter = 0;
/* 186 */     for (String s : res) {
/* 187 */       if (s.equals("SUBDIFFUSION")) {
/* 188 */         scounter++;
/*     */       }
/* 190 */       if (s.equals("NORM. DIFFUSION")) {
/* 191 */         ncounter++;
/*     */       }
/*     */     } 
/* 194 */     System.out.println("SC: " + (1.0D * scounter / res.length));
/* 195 */     System.out.println("SN: " + (1.0D * ncounter / res.length));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static double meanAbsoluteSteplength(Trajectory t) {
/* 201 */     double[] v = new double[t.size() - 1];
/*     */     
/* 203 */     for (int i = 1; i < t.size(); i++) {
/* 204 */       v[i - 1] = Math.abs(((Point3d)t.get(i)).distance((Point3d)t.get(i - 1)));
/*     */     }
/*     */     
/* 207 */     Mean m = new Mean();
/*     */     
/* 209 */     return m.evaluate(v);
/*     */   }
/*     */   
/*     */   public static void importTracksAndShow() {
/* 213 */     new ImageJ();
/* 214 */     IJ.getInstance().show(true);
/* 215 */     ImageStack is = new ImageStack(1000, 1000);
/* 216 */     for (int i = 0; i < 1005; i++) {
/* 217 */       is.addSlice((ImageProcessor)new ByteProcessor(1000, 1000));
/*     */     }
/*     */     
/* 220 */     ImagePlus img = new ImagePlus("", is);
/* 221 */     img.show();
/*     */ 
/*     */     
/* 224 */     TraJClassifier_ tclass = new TraJClassifier_();
/* 225 */     tclass.run("");
/*     */   }
/*     */   
/*     */   public void showProblematicTrack() {
/* 229 */     String modelpath = "";
/*     */     try {
/* 231 */       modelpath = ExportResource("/randomForestModel.RData");
/* 232 */     } catch (Exception e) {
/*     */       
/* 234 */       e.printStackTrace();
/*     */     } 
/*     */     
/* 237 */     ExportImportTools eit = new ExportImportTools();
/* 238 */     ArrayList<Trajectory> tracks = eit.importTrajectoryDataFromCSV("/home/thorsten/subdiffusion_alpha.csv");
/* 239 */     Trajectory t = tracks.get(0);
/* 240 */     PowerLawFeature pwf = new PowerLawFeature(t, 10.0D, 1, t.size() / 3);
/* 241 */     double[] ev = pwf.evaluate();
/* 242 */     double a = ev[0];
/* 243 */     double D = ev[1];
/* 244 */     Chart c = VisualizationUtils.getMSDLineWithPowerModelChart(t, 1, t.size() / 3, 0.1D, 0.4D, D * 10.0D);
/* 245 */     System.out.println("alpha: " + a);
/* 246 */     VisualizationUtils.plotChart(c);
/*     */   }
/*     */   
/*     */   public void showTestScene() {
/* 250 */     CentralRandomNumberGenerator.getInstance().setSeed(2L);
/* 251 */     String modelpath = "";
/*     */     try {
/* 253 */       modelpath = ExportResource("/randomForestModel.RData");
/* 254 */     } catch (Exception e) {
/*     */       
/* 256 */       e.printStackTrace();
/*     */     } 
/*     */     
/* 259 */     int w = 45;
/*     */     
/* 261 */     double diffusioncoefficient = 0.05D;
/* 262 */     double timelag = 0.03333333333333333D;
/* 263 */     double[] driftspeed = { 0.0D, 0.27D, 1.0D, 2.4D };
/* 264 */     double angularVelocity = 0.7853981633974483D;
/* 265 */     int numberOfSteps = 500;
/* 266 */     int diffusionToNoiseRatio = 1;
/* 267 */     double sigmaPosNoise = Math.sqrt(2.0D * diffusioncoefficient * timelag) / diffusionToNoiseRatio;
/*     */     
/* 269 */     double SNR = 2.5D;
/* 270 */     double boundedness = 5.0D;
/* 271 */     double radius_confined = Math.sqrt(BoundednessFeature.a(w) * diffusioncoefficient * timelag / 4.0D * boundedness);
/* 272 */     System.out.println("Radius confined" + radius_confined + " µm");
/* 273 */     double R = 5.0D;
/* 274 */     double velocity = Math.sqrt(R * 4.0D * diffusioncoefficient / w * timelag);
/* 275 */     System.out.println("Velocity " + velocity + " µm/s");
/*     */     
/* 277 */     double Dc = diffusioncoefficient;
/* 278 */     double rsig_1 = Math.sqrt(Dc * timelag) / SNR;
/* 279 */     double rsig_2 = Math.sqrt(Dc * timelag + velocity * velocity * timelag * timelag) / SNR;
/* 280 */     System.out.println("Sigma 1: " + rsig_1 + " Sigma 2: " + rsig_2);
/*     */     
/* 282 */     ArrayList<Trajectory> orig = new ArrayList<>();
/*     */     
/* 284 */     Trajectory combinedTrajectory = new Trajectory(2);
/*     */     
/* 286 */     ConfinedDiffusionSimulator confinedDiffusionSimulator = new ConfinedDiffusionSimulator(diffusioncoefficient, timelag, radius_confined, 2, 200);
/* 287 */     Trajectory tConf = confinedDiffusionSimulator.generateTrajectory();
/* 288 */     tConf = SimulationUtil.addPositionNoise(tConf, rsig_1);
/* 289 */     tConf.setType("confined");
/* 290 */     orig.add(tConf);
/*     */     
/* 292 */     FreeDiffusionSimulator freeDiffusionSimulator = new FreeDiffusionSimulator(diffusioncoefficient, timelag, 2, 330);
/* 293 */     ArrayList<Trajectory> t = new ArrayList<>();
/* 294 */     Trajectory trFree = freeDiffusionSimulator.generateTrajectory();
/* 295 */     trFree = SimulationUtil.addPositionNoise(trFree, rsig_1);
/* 296 */     trFree.setType("normal");
/* 297 */     trFree.offset(((Point3d)tConf.get(tConf.size() - 1)).x, ((Point3d)tConf.get(tConf.size() - 1)).y, 0.0D);
/* 298 */     orig.add(trFree);
/* 299 */     combinedTrajectory = TrajectoryUtil.concactTrajectorie(tConf, trFree);
/*     */ 
/*     */     
/* 302 */     freeDiffusionSimulator = new FreeDiffusionSimulator(diffusioncoefficient, timelag, 2, 200);
/*     */     
/* 304 */     ActiveTransportSimulator simActive = new ActiveTransportSimulator(velocity, angularVelocity, 4.743804906920587D, timelag, 2, 200);
/* 305 */     Trajectory trDirected = TrajectoryUtil.combineTrajectory(simActive.generateTrajectory(), freeDiffusionSimulator.generateTrajectory());
/* 306 */     trDirected = SimulationUtil.addPositionNoise(trDirected, rsig_2);
/* 307 */     combinedTrajectory = TrajectoryUtil.concactTrajectorie(combinedTrajectory, trDirected);
/* 308 */     trDirected.setType("directed");
/* 309 */     trDirected.offset(((Point3d)trFree.get(trFree.size() - 1)).x, ((Point3d)trFree.get(trFree.size() - 1)).y, 0.0D);
/* 310 */     orig.add(trDirected);
/*     */     
/* 312 */     AnomalousDiffusionWMSimulation anomalousDiffusionWMSimulation = new AnomalousDiffusionWMSimulation(diffusioncoefficient, timelag, 2, 200, 0.5D);
/* 313 */     Trajectory trAnom = anomalousDiffusionWMSimulation.generateTrajectory();
/* 314 */     trAnom = SimulationUtil.addPositionNoise(trAnom, rsig_1);
/* 315 */     trAnom.setType("anom");
/* 316 */     trAnom.offset(((Point3d)trDirected.get(trDirected.size() - 1)).x, ((Point3d)trDirected.get(trDirected.size() - 1)).y, 0.0D);
/* 317 */     orig.add(trAnom);
/* 318 */     combinedTrajectory = TrajectoryUtil.concactTrajectorie(combinedTrajectory, trAnom);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 328 */     ExportImportTools eit = new ExportImportTools();
/*     */     
/* 330 */     ArrayList<Subtrajectory> tracks = TraJClassifier_.getInstance().classifyAndSegment(combinedTrajectory, modelpath, w, 90, 10, 1);
/* 331 */     for (Trajectory tr : tracks) {
/* 332 */       tr.offset(2.0D, 0.0D, 0.0D);
/*     */     }
/* 334 */     eit.exportTrajectoryDataAsCSV((ArrayList)tracks, "/home/thorsten/track_seg.csv");
/* 335 */     showTracks((ArrayList)tracks);
/*     */     
/* 337 */     eit.exportTrajectoryDataAsCSV(orig, "/home/thorsten/track_orig.csv");
/* 338 */     showTracks(orig);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void outputFeatures(Trajectory t, double timelag) {
/* 360 */     int numberOfSegmentsSplineFit = 7;
/* 361 */     int numberOfPointsForShortTimeLongTimeRatio = 2;
/* 362 */     ElongationFeature elongationFeature = new ElongationFeature(t);
/* 363 */     System.out.println(elongationFeature.getShortName() + ": " + elongationFeature.evaluate()[0]);
/*     */     
/* 365 */     FractalDimensionFeature fractalDimensionFeature = new FractalDimensionFeature(t);
/* 366 */     System.out.println(fractalDimensionFeature.getShortName() + ": " + fractalDimensionFeature.evaluate()[0]);
/*     */     
/* 368 */     MeanSquaredDisplacmentCurvature meanSquaredDisplacmentCurvature = new MeanSquaredDisplacmentCurvature(t);
/* 369 */     System.out.println(meanSquaredDisplacmentCurvature.getShortName() + ": " + meanSquaredDisplacmentCurvature.evaluate()[0]);
/*     */     
/* 371 */     RegressionDiffusionCoefficientEstimator regressionDiffusionCoefficientEstimator = new RegressionDiffusionCoefficientEstimator(t, 1.0D / timelag, 1, 3);
/* 372 */     PowerLawFeature f2 = new PowerLawFeature(t, 1.0D / timelag, 1, t.size() / 3, 0.5D, regressionDiffusionCoefficientEstimator.evaluate()[0]);
/* 373 */     System.out.println(regressionDiffusionCoefficientEstimator.getShortName() + ": " + f2.evaluate()[0]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 379 */     SplineCurveDynamicsFeature splineCurveDynamicsFeature = new SplineCurveDynamicsFeature(t, numberOfSegmentsSplineFit, 1);
/* 380 */     System.out.println(splineCurveDynamicsFeature.getShortName() + ": " + (splineCurveDynamicsFeature.evaluate()[0] / splineCurveDynamicsFeature.evaluate()[1]));
/*     */     
/* 382 */     AsymmetryFeature asymmetryFeature = new AsymmetryFeature(t);
/* 383 */     System.out.println(asymmetryFeature.getShortName() + ": " + asymmetryFeature.evaluate()[0]);
/*     */ 
/*     */     
/* 386 */     Asymmetry2Feature asymmetry2Feature = new Asymmetry2Feature(t);
/* 387 */     System.out.println(asymmetry2Feature.getShortName() + ": " + asymmetry2Feature.evaluate()[0]);
/*     */     
/* 389 */     Asymmetry3Feature asymmetry3Feature = new Asymmetry3Feature(t);
/* 390 */     System.out.println(asymmetry3Feature.getShortName() + ": " + asymmetry3Feature.evaluate()[0]);
/*     */     
/* 392 */     EfficiencyFeature efficiencyFeature = new EfficiencyFeature(t);
/* 393 */     System.out.println(efficiencyFeature.getShortName() + ": " + efficiencyFeature.evaluate()[0]);
/*     */     
/* 395 */     ShortTimeLongTimeDiffusioncoefficentRatio shortTimeLongTimeDiffusioncoefficentRatio = new ShortTimeLongTimeDiffusioncoefficentRatio(t, numberOfPointsForShortTimeLongTimeRatio);
/* 396 */     System.out.println(shortTimeLongTimeDiffusioncoefficentRatio.getShortName() + ": " + shortTimeLongTimeDiffusioncoefficentRatio.evaluate()[0]);
/*     */     
/* 398 */     KurtosisFeature kurtosisFeature = new KurtosisFeature(t);
/* 399 */     System.out.println(kurtosisFeature.getShortName() + ": " + kurtosisFeature.evaluate()[0]);
/*     */     
/* 401 */     SkewnessFeature skewnessFeature = new SkewnessFeature(t);
/* 402 */     System.out.println(skewnessFeature.getShortName() + ": " + skewnessFeature.evaluate()[0]);
/*     */     
/* 404 */     MSDRatioFeature mSDRatioFeature = new MSDRatioFeature(t, 1, 5);
/* 405 */     System.out.println(mSDRatioFeature.getShortName() + ": " + mSDRatioFeature.evaluate()[0]);
/*     */     
/* 407 */     StraightnessFeature straightnessFeature = new StraightnessFeature(t);
/* 408 */     System.out.println(straightnessFeature.getShortName() + ": " + straightnessFeature.evaluate()[0]);
/*     */     
/* 410 */     TrappedProbabilityFeature trappedProbabilityFeature = new TrappedProbabilityFeature(t);
/* 411 */     System.out.println(trappedProbabilityFeature.getShortName() + ": " + trappedProbabilityFeature.evaluate()[0]);
/*     */     
/* 413 */     GaussianityFeauture gaussianityFeauture = new GaussianityFeauture(t, 1);
/* 414 */     System.out.println(gaussianityFeauture.getShortName() + ": " + gaussianityFeauture.evaluate()[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static double[] evaluate(Trajectory t, double timelag) {
/* 421 */     MeanSquaredDisplacmentFeature msd = new MeanSquaredDisplacmentFeature(t, 1);
/* 422 */     msd.setOverlap(false);
/*     */     
/* 424 */     ArrayList<Double> xDataList = new ArrayList<>();
/* 425 */     ArrayList<Double> yDataList = new ArrayList<>();
/* 426 */     for (int i = 1; i < t.size(); i++) {
/* 427 */       msd.setTimelag(i);
/* 428 */       double[] arrayOfDouble = msd.evaluate();
/* 429 */       double msdvalue = arrayOfDouble[0];
/* 430 */       int N = (int)arrayOfDouble[2];
/* 431 */       for (int j = 0; j < N; j++) {
/* 432 */         xDataList.add(Double.valueOf(i * timelag));
/* 433 */         yDataList.add(Double.valueOf(msdvalue));
/*     */       } 
/*     */     } 
/* 436 */     double[] xData = ArrayUtils.toPrimitive(xDataList.<Double>toArray(new Double[0]));
/* 437 */     double[] yData = ArrayUtils.toPrimitive(yDataList.<Double>toArray(new Double[0]));
/* 438 */     CurveFitter fitter = new CurveFitter(xData, yData);
/* 439 */     MaxDistanceBetweenTwoPositionsFeature maxdist = new MaxDistanceBetweenTwoPositionsFeature(t);
/* 440 */     RegressionDiffusionCoefficientEstimator regest = new RegressionDiffusionCoefficientEstimator(t, 1.0D / timelag, 5, 5);
/* 441 */     double estrad = maxdist.evaluate()[0];
/* 442 */     double estDC = regest.evaluate()[0];
/* 443 */     double[] initialParams = { estrad * estrad };
/*     */     
/* 445 */     fitter.doCustomFit("y=a*(1-exp(-4*" + estDC + "*x/a))", initialParams, false);
/* 446 */     double[] params = fitter.getParams();
/* 447 */     double[] res = { params[0] };
/* 448 */     return res;
/*     */   }
/*     */   
/*     */   public static String[] windowedClassification(Trajectory t, AbstractClassifier c, int n) {
/* 452 */     int windowsize = 2 * n + 1;
/* 453 */     String[] types = new String[t.size()]; int i;
/* 454 */     for (i = 0; i < n; i++) {
/* 455 */       types[i] = "NONE";
/*     */     }
/* 457 */     for (i = types.length - n; i < types.length; i++) {
/* 458 */       types[i] = "NONE";
/*     */     }
/* 460 */     ArrayList<Trajectory> tracks = new ArrayList<>();
/* 461 */     for (int j = 0; j < t.size() - windowsize + 1; j++) {
/* 462 */       Trajectory sub = t.subList(j, j + windowsize - 1);
/* 463 */       tracks.add(sub);
/*     */     } 
/*     */     
/* 466 */     String[] res = c.classify(tracks);
/* 467 */     for (int k = 0; k < res.length; k++) {
/* 468 */       types[k + n] = res[k];
/*     */     }
/*     */     
/* 471 */     return types;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ArrayList<Trajectory> segmentSubtrajectoriesAndShow(Trajectory t, String[] classes, double[] classConfidence, double confidenceThreshold, int minSegLength) {
/* 477 */     if (t.size() != classes.length) {
/* 478 */       throw new IllegalArgumentException("Tracklength and the number of classes have to be equal");
/*     */     }
/* 480 */     ArrayList<String> cls = new ArrayList<>();
/* 481 */     ArrayList<Trajectory> subtracks = new ArrayList<>();
/* 482 */     String prevCls = classes[0];
/* 483 */     Trajectory sub = new Trajectory(t.getDimension());
/* 484 */     sub.add((Point3d)t.get(0));
/* 485 */     for (int i = 1; i < t.size(); i++) {
/* 486 */       if (prevCls == classes[i]) {
/* 487 */         sub.add((Point3d)t.get(i));
/*     */       } else {
/*     */         
/* 490 */         subtracks.add(sub);
/* 491 */         cls.add(prevCls);
/*     */         
/* 493 */         prevCls = classes[i];
/* 494 */         sub = new Trajectory(t.getDimension());
/* 495 */         sub.add((Point3d)t.get(i));
/*     */       } 
/*     */     } 
/*     */     
/* 499 */     cls.add(prevCls);
/* 500 */     subtracks.add(sub);
/*     */ 
/*     */     
/* 503 */     int indexCounter = 0; int j;
/* 504 */     for (j = 0; j < subtracks.size(); j++) {
/* 505 */       for (int k = 0; k < ((Trajectory)subtracks.get(j)).size(); k++) {
/* 506 */         if (classConfidence[indexCounter] < confidenceThreshold) {
/* 507 */           ((Trajectory)subtracks.get(j)).remove(k);
/* 508 */           k--;
/*     */         } 
/* 510 */         indexCounter++;
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 515 */     for (j = 0; j < subtracks.size(); j++) {
/* 516 */       if (((Trajectory)subtracks.get(j)).size() < minSegLength) {
/* 517 */         subtracks.remove(j);
/* 518 */         cls.remove(j);
/* 519 */         j--;
/*     */       } 
/*     */     } 
/*     */     
/* 523 */     showTracks(subtracks, cls);
/* 524 */     return subtracks;
/*     */   }
/*     */ 
/*     */   
/*     */   public static void showTrack(Trajectory t, String[] classes, int minSegLength) {
/* 529 */     if (t.size() != classes.length) {
/* 530 */       throw new IllegalArgumentException("Tracklength and the number of classes have to be equal");
/*     */     }
/* 532 */     ArrayList<String> cls = new ArrayList<>();
/* 533 */     ArrayList<Trajectory> subtracks = new ArrayList<>();
/* 534 */     String prevCls = classes[0];
/* 535 */     Trajectory sub = new Trajectory(t.getDimension());
/* 536 */     sub.add((Point3d)t.get(0));
/* 537 */     for (int i = 1; i < t.size(); i++) {
/* 538 */       if (prevCls == classes[i]) {
/* 539 */         sub.add((Point3d)t.get(i));
/*     */       } else {
/* 541 */         if (sub.size() > minSegLength) {
/* 542 */           subtracks.add(sub);
/* 543 */           cls.add(prevCls);
/*     */         } 
/*     */         
/* 546 */         prevCls = classes[i];
/* 547 */         sub = new Trajectory(t.getDimension());
/* 548 */         sub.add((Point3d)t.get(i));
/*     */       } 
/*     */     } 
/*     */     
/* 552 */     if (sub.size() > minSegLength) {
/* 553 */       cls.add(prevCls);
/* 554 */       subtracks.add(sub);
/*     */     } 
/* 556 */     showTracks(subtracks, cls);
/*     */   }
/*     */   
/*     */   public static void showTracks(ArrayList<? extends Trajectory> tracks) {
/* 560 */     ArrayList<String> cls = new ArrayList<>();
/* 561 */     for (int i = 0; i < tracks.size(); i++) {
/* 562 */       cls.add(((Trajectory)tracks.get(i)).getType());
/*     */     }
/* 564 */     showTracks(tracks, cls);
/*     */   }
/*     */   
/*     */   public static void showTracks(ArrayList<? extends Trajectory> tracks, String[] classes) {
/* 568 */     ArrayList<String> cls = new ArrayList<>();
/* 569 */     for (int i = 0; i < classes.length; i++) {
/* 570 */       cls.add(classes[i]);
/*     */     }
/* 572 */     showTracks(tracks, cls);
/*     */   }
/*     */ 
/*     */   
/*     */   public static void showTracks(ArrayList<? extends Trajectory> tracks, ArrayList<String> classes) {
/* 577 */     Color[] colors = { Color.RED, Color.BLUE, Color.YELLOW, Color.GREEN, Color.BLACK, Color.PINK, Color.ORANGE, Color.MAGENTA };
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 582 */     HashSet<String> uniqueClasses = new HashSet<>();
/* 583 */     uniqueClasses.addAll(classes);
/* 584 */     HashMap<String, Integer> mapTypeToInt = new HashMap<>();
/* 585 */     HashMap<Integer, String> mapIntToType = new HashMap<>();
/* 586 */     Iterator<String> it = uniqueClasses.iterator();
/* 587 */     int key = 0;
/* 588 */     while (it.hasNext()) {
/* 589 */       String type = it.next();
/* 590 */       mapTypeToInt.put(type, Integer.valueOf(key));
/* 591 */       mapIntToType.put(Integer.valueOf(key), type);
/* 592 */       key++;
/*     */     } 
/*     */     
/* 595 */     Chart chart = new Chart(700, 400);
/* 596 */     for (int i = 0; i < tracks.size(); i++) {
/* 597 */       Trajectory t = tracks.get(i);
/* 598 */       String type = classes.get(i);
/* 599 */       if (t.getDimension() == 2) {
/* 600 */         double[] xData = new double[t.size()];
/* 601 */         double[] yData = new double[t.size()];
/* 602 */         for (int j = 0; j < t.size(); j++) {
/* 603 */           xData[j] = ((Point3d)t.get(j)).x;
/* 604 */           yData[j] = ((Point3d)t.get(j)).y;
/*     */         } 
/*     */ 
/*     */         
/* 608 */         Series s = chart.addSeries(i + ". " + type + "(" + t.size() + ")", xData, yData);
/* 609 */         s.setLineColor(colors[((Integer)mapTypeToInt.get(type)).intValue()]);
/* 610 */         s.setMarker(SeriesMarker.NONE);
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 618 */     (new SwingWrapper(chart)).displayChart();
/*     */   }
/*     */   
/*     */   public static void printTypes(String[] res) {
/* 622 */     String prev = res[0];
/* 623 */     int c = 1;
/* 624 */     for (int i = 1; i < res.length; i++) {
/* 625 */       if (prev == res[i]) {
/* 626 */         c++;
/*     */       } else {
/* 628 */         System.out.println("Type: " + prev + "(" + c + ")");
/* 629 */         c = 1;
/* 630 */         prev = res[i];
/*     */       } 
/*     */     } 
/*     */     
/* 634 */     System.out.println("Type: " + prev + "(" + c + ")");
/*     */   }
/*     */ 
/*     */   
/*     */   public static void addToTypes(ArrayList<String> types, String type, int n) {
/* 639 */     for (int i = 0; i < n; i++)
/* 640 */       types.add(type); 
/*     */   }
/*     */   
/*     */   public static String[] movingMode(String[] types, int n) {
/* 644 */     ArrayList<String> ltypes = new ArrayList<>();
/* 645 */     for (int i = 0; i < types.length; i++) {
/* 646 */       ltypes.add(types[i]);
/*     */     }
/* 648 */     return movingMode(ltypes, n);
/*     */   }
/*     */   
/*     */   public static String[] movingMode(ArrayList<String> types, int n) {
/* 652 */     int windowsize = 2 * n + 1;
/* 653 */     HashSet<String> uniqueTypes = new HashSet<>();
/* 654 */     uniqueTypes.addAll(types);
/* 655 */     HashMap<String, Integer> mapTypeToInt = new HashMap<>();
/* 656 */     HashMap<Integer, String> mapIntToType = new HashMap<>();
/* 657 */     Iterator<String> it = uniqueTypes.iterator();
/* 658 */     int key = 0;
/* 659 */     while (it.hasNext()) {
/* 660 */       String type = it.next();
/* 661 */       mapTypeToInt.put(type, Integer.valueOf(key));
/* 662 */       mapIntToType.put(Integer.valueOf(key), type);
/* 663 */       key++;
/*     */     } 
/*     */     
/* 666 */     String[] medTypes = new String[types.size()];
/*     */     int i;
/* 668 */     for (i = 0; i < n; i++) {
/* 669 */       medTypes[i] = types.get(i);
/*     */     }
/* 671 */     for (i = types.size() - n; i < types.size(); i++) {
/* 672 */       medTypes[i] = types.get(i);
/*     */     }
/*     */     
/* 675 */     for (i = 0; i < types.size() - windowsize + 1; i++) {
/* 676 */       List<String> sub = types.subList(i, i + windowsize - 1);
/* 677 */       double[] values = new double[sub.size()];
/* 678 */       for (int j = 0; j < sub.size(); j++) {
/* 679 */         values[j] = ((Integer)mapTypeToInt.get(sub.get(j))).intValue();
/*     */       }
/*     */       
/* 682 */       medTypes[i + n] = mapIntToType.get(Integer.valueOf((int)StatUtils.mode(values)[0]));
/*     */     } 
/* 684 */     return medTypes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String ExportResource(String resourceName) throws Exception {
/*     */     String tmpFolder;
/* 695 */     InputStream stream = null;
/* 696 */     OutputStream resStreamOut = null;
/*     */     
/*     */     try {
/* 699 */       stream = getClass().getResourceAsStream(resourceName);
/* 700 */       if (stream == null) {
/* 701 */         IJ.error("Cannot get resource \"" + resourceName + "\" from Jar file.");
/* 702 */         throw new Exception("Cannot get resource \"" + resourceName + "\" from Jar file.");
/*     */       } 
/*     */ 
/*     */       
/* 706 */       byte[] buffer = new byte[4096];
/* 707 */       File folderDir = new File(IJ.getDirectory("temp") + "/.trajclassifier");
/*     */ 
/*     */       
/* 710 */       if (!folderDir.exists()) {
/* 711 */         folderDir.mkdir();
/*     */       }
/* 713 */       tmpFolder = folderDir.getPath().replace('\\', '/');
/* 714 */       resStreamOut = new FileOutputStream(tmpFolder + resourceName); int readBytes;
/* 715 */       while ((readBytes = stream.read(buffer)) > 0) {
/* 716 */         resStreamOut.write(buffer, 0, readBytes);
/*     */       }
/* 718 */     } catch (Exception ex) {
/* 719 */       IJ.error(ex.getMessage());
/* 720 */       throw ex;
/*     */     } finally {
/* 722 */       stream.close();
/* 723 */       resStreamOut.close();
/*     */     } 
/*     */     
/* 726 */     return tmpFolder + resourceName;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/ij_trajectory_classifier-0.8.2.jar!/de/biomedical_imaging/ij/trajectory_classifier/TraJClassifier_Debug.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */