/*    */ package de.biomedical_imaging.ij.trajectory_classifier;
/*    */ 
/*    */ import de.biomedical_imaging.traJ.Trajectory;
/*    */ import java.util.ArrayList;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WindowedClassificationProcess
/*    */ {
/*    */   public String[] windowedClassification(Trajectory t, AbstractClassifier c, int n) {
/* 40 */     int windowsize = 2 * n + 1;
/* 41 */     String[] types = new String[t.size()];
/* 42 */     for (int i = 0; i < types.length; i++) {
/* 43 */       types[i] = "NONE";
/*    */     }
/*    */     
/* 46 */     ArrayList<Trajectory> tracks = new ArrayList<>();
/* 47 */     for (int j = 0; j < t.size() - windowsize + 1; j++) {
/* 48 */       Trajectory sub = t.subList(j, j + windowsize - 1);
/* 49 */       tracks.add(sub);
/*    */     } 
/* 51 */     String[] res = c.classify(tracks);
/* 52 */     if (res != null) {
/* 53 */       for (int k = 0; k < res.length; k++) {
/* 54 */         types[k + n] = res[k];
/*    */       }
/*    */     }
/* 57 */     return types;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/ij_trajectory_classifier-0.8.2.jar!/de/biomedical_imaging/ij/trajectory_classifier/WindowedClassificationProcess.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */