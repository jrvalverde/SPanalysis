/*     */ package de.biomedical_imaging.ij.trajectory_classifier;
/*     */ 
/*     */ import de.biomedical_imaging.traJ.DiffusionCoefficientEstimator.RegressionDiffusionCoefficientEstimator;
/*     */ import de.biomedical_imaging.traJ.Trajectory;
/*     */ import de.biomedical_imaging.traJ.features.AbstractTrajectoryFeature;
/*     */ import de.biomedical_imaging.traJ.features.Asymmetry3Feature;
/*     */ import de.biomedical_imaging.traJ.features.EfficiencyFeature;
/*     */ import de.biomedical_imaging.traJ.features.FractalDimensionFeature;
/*     */ import de.biomedical_imaging.traJ.features.GaussianityFeauture;
/*     */ import de.biomedical_imaging.traJ.features.KurtosisFeature;
/*     */ import de.biomedical_imaging.traJ.features.MSDRatioFeature;
/*     */ import de.biomedical_imaging.traJ.features.PowerLawFeature;
/*     */ import de.biomedical_imaging.traJ.features.ShortTimeLongTimeDiffusioncoefficentRatio;
/*     */ import de.biomedical_imaging.traJ.features.SkewnessFeature;
/*     */ import de.biomedical_imaging.traJ.features.StraightnessFeature;
/*     */ import de.biomedical_imaging.traJ.features.TrappedProbabilityFeature;
/*     */ import ij.IJ;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.Executors;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import javax.script.ScriptEngine;
/*     */ import javax.script.ScriptEngineManager;
/*     */ import javax.script.ScriptException;
/*     */ import org.renjin.eval.EvalException;
/*     */ import org.renjin.parser.ParseException;
/*     */ import org.renjin.sexp.DoubleVector;
/*     */ import org.renjin.sexp.StringVector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RRFClassifierRenjin
/*     */   extends AbstractClassifier
/*     */ {
/*  61 */   private ScriptEngine engine = null;
/*     */   
/*     */   private String pathToModel;
/*     */   
/*     */   public RRFClassifierRenjin(String pathToModel, double timelag) {
/*  66 */     this.pathToModel = pathToModel;
/*  67 */     this.timelag = timelag;
/*     */   }
/*     */   private double[] confindence; private double timelag;
/*     */   public void setTimelag(double timelag) {
/*  71 */     this.timelag = timelag;
/*     */   }
/*     */ 
/*     */   
/*     */   public String classify(Trajectory t) {
/*  76 */     ArrayList<Trajectory> tracks = new ArrayList<>();
/*  77 */     tracks.add(t);
/*     */     
/*  79 */     return classify(tracks)[0];
/*     */   }
/*     */ 
/*     */   
/*     */   public void start() {
/*  84 */     ScriptEngineManager manager = new ScriptEngineManager();
/*     */     
/*  86 */     this.engine = manager.getEngineByName("Renjin");
/*     */     try {
/*  88 */       this.engine.eval("library(randomForest)");
/*  89 */       this.engine.eval("library(plyr)");
/*  90 */       this.engine.eval("load(\"" + this.pathToModel + "\")");
/*  91 */     } catch (ScriptException e) {
/*  92 */       e.printStackTrace();
/*     */     } 
/*     */ 
/*     */     
/*  96 */     if (this.engine == null) {
/*  97 */       throw new RuntimeException("Renjin Script Engine not found on the classpath.");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void stop() {
/* 105 */     this.engine = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] classify(ArrayList<Trajectory> tracks) {
/* 112 */     int N = tracks.size();
/* 113 */     String[] result = new String[N];
/* 114 */     double[] fd = new double[N];
/* 115 */     int[] lengths = new int[N];
/* 116 */     double[] power = new double[N];
/* 117 */     Arrays.fill(power, -1.0D);
/* 118 */     double[] ltStRatio = new double[N];
/* 119 */     double[] asym3 = new double[N];
/* 120 */     double[] efficiency = new double[N];
/* 121 */     double[] kurtosis = new double[N];
/* 122 */     double[] skewness = new double[N];
/* 123 */     double[] msdratio = new double[N];
/* 124 */     double[] straightness = new double[N];
/* 125 */     double[] trappedness = new double[N];
/* 126 */     double[] gaussianity = new double[N];
/* 127 */     double[] pwrDCs = new double[N];
/* 128 */     Arrays.fill(power, -1.0D);
/* 129 */     int numberOfPointsForShortTimeLongTimeRatio = 2;
/* 130 */     int cores = Runtime.getRuntime().availableProcessors();
/* 131 */     ExecutorService pool = Executors.newFixedThreadPool(cores);
/*     */ 
/*     */     
/* 134 */     for (int i = 0; i < tracks.size(); i++) {
/* 135 */       Trajectory t = tracks.get(i);
/*     */       
/* 137 */       lengths[i] = t.size();
/*     */ 
/*     */       
/* 140 */       FractalDimensionFeature fdF = new FractalDimensionFeature(t);
/* 141 */       pool.submit(new FeatureWorker(fd, i, (AbstractTrajectoryFeature)fdF, FeatureWorker.EVALTYPE.FIRST));
/* 142 */       double initDC = 0.0D;
/* 143 */       double initAlpha = 0.0D;
/* 144 */       if (i - 1 > 0 && power[i - 1] > 0.0D && pwrDCs[i - 1] > 0.0D) {
/* 145 */         initDC = pwrDCs[i - 1];
/* 146 */         initAlpha = power[i - 1];
/*     */       } else {
/*     */         
/* 149 */         RegressionDiffusionCoefficientEstimator regest = new RegressionDiffusionCoefficientEstimator(t, 1.0D / this.timelag, 1, 3);
/* 150 */         initDC = regest.evaluate()[0];
/* 151 */         initAlpha = 0.5D;
/*     */       } 
/*     */       
/* 154 */       PowerLawFeature pwf = new PowerLawFeature(t, 1.0D / this.timelag, 1, t.size() / 3, initAlpha, initDC);
/* 155 */       pool.submit(new FeatureWorker(power, i, (AbstractTrajectoryFeature)pwf, FeatureWorker.EVALTYPE.FIRST));
/* 156 */       pool.submit(new FeatureWorker(pwrDCs, i, (AbstractTrajectoryFeature)pwf, FeatureWorker.EVALTYPE.SECOND));
/*     */       
/* 158 */       Asymmetry3Feature asymf3 = new Asymmetry3Feature(t);
/* 159 */       pool.submit(new FeatureWorker(asym3, i, (AbstractTrajectoryFeature)asymf3, FeatureWorker.EVALTYPE.FIRST));
/*     */       
/* 161 */       EfficiencyFeature eff = new EfficiencyFeature(t);
/* 162 */       pool.submit(new FeatureWorker(efficiency, i, (AbstractTrajectoryFeature)eff, FeatureWorker.EVALTYPE.FIRST));
/*     */       
/* 164 */       ShortTimeLongTimeDiffusioncoefficentRatio stltdf = new ShortTimeLongTimeDiffusioncoefficentRatio(t, numberOfPointsForShortTimeLongTimeRatio);
/* 165 */       pool.submit(new FeatureWorker(ltStRatio, i, (AbstractTrajectoryFeature)stltdf, FeatureWorker.EVALTYPE.FIRST));
/*     */       
/* 167 */       KurtosisFeature kurtf = new KurtosisFeature(t);
/* 168 */       pool.submit(new FeatureWorker(kurtosis, i, (AbstractTrajectoryFeature)kurtf, FeatureWorker.EVALTYPE.FIRST));
/*     */       
/* 170 */       SkewnessFeature skew = new SkewnessFeature(t);
/* 171 */       pool.submit(new FeatureWorker(skewness, i, (AbstractTrajectoryFeature)skew, FeatureWorker.EVALTYPE.FIRST));
/*     */       
/* 173 */       MSDRatioFeature msdr = new MSDRatioFeature(t, 1, 5);
/* 174 */       pool.submit(new FeatureWorker(msdratio, i, (AbstractTrajectoryFeature)msdr, FeatureWorker.EVALTYPE.FIRST));
/*     */       
/* 176 */       StraightnessFeature straight = new StraightnessFeature(t);
/* 177 */       pool.submit(new FeatureWorker(straightness, i, (AbstractTrajectoryFeature)straight, FeatureWorker.EVALTYPE.FIRST));
/*     */       
/* 179 */       TrappedProbabilityFeature trappf = new TrappedProbabilityFeature(t);
/* 180 */       pool.submit(new FeatureWorker(trappedness, i, (AbstractTrajectoryFeature)trappf, FeatureWorker.EVALTYPE.FIRST));
/*     */       
/* 182 */       GaussianityFeauture gaussf = new GaussianityFeauture(t, 1);
/* 183 */       pool.submit(new FeatureWorker(gaussianity, i, (AbstractTrajectoryFeature)gaussf, FeatureWorker.EVALTYPE.FIRST));
/*     */     } 
/*     */     
/* 186 */     pool.shutdown();
/*     */     
/*     */     try {
/* 189 */       pool.awaitTermination(Long.MAX_VALUE, TimeUnit.NANOSECONDS);
/* 190 */     } catch (InterruptedException e) {
/* 191 */       e.printStackTrace();
/*     */     } 
/*     */ 
/*     */     
/*     */     try {
/* 196 */       this.engine.put("fd", fd);
/* 197 */       this.engine.put("lengths", lengths);
/* 198 */       this.engine.put("power", power);
/* 199 */       this.engine.put("LtStRatio", ltStRatio);
/* 200 */       this.engine.put("asymmetry3", asym3);
/* 201 */       this.engine.put("efficiency", efficiency);
/* 202 */       this.engine.put("kurtosis", kurtosis);
/* 203 */       this.engine.put("skewness", skewness);
/* 204 */       this.engine.put("msdratio", msdratio);
/* 205 */       this.engine.put("straightness", straightness);
/* 206 */       this.engine.put("trappedness", trappedness);
/* 207 */       this.engine.put("gaussianity", gaussianity);
/*     */       
/* 209 */       this.engine.eval("data<-data.frame(LENGTHS=lengths,FD=fd,POWER=power,MSD.R=msdratio,ASYM3=asymmetry3,EFFICENCY=efficiency, KURT=kurtosis,SKEW=skewness,STRAIGHTNESS=straightness, TRAPPED=trappedness,GAUSS=gaussianity,LTST.RATIO=LtStRatio)");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 215 */       this.engine.eval("features.predict <- predict(model,data,type=\"prob\")");
/* 216 */       this.engine.eval("fprob<-features.predict");
/*     */       
/* 218 */       if (tracks.size() > 1) {
/* 219 */         this.engine.eval("probs <- as.vector(apply(fprob[1:nrow(fprob),],1,max))");
/* 220 */         this.engine.eval("indexmax <- as.vector(apply(fprob[1:nrow(fprob),],1,which.max))");
/*     */       } else {
/*     */         
/* 223 */         this.engine.eval("probs <- max(fprob)");
/* 224 */         this.engine.eval("indexmax <- which.max(fprob)");
/*     */       } 
/* 226 */       this.engine.eval("mynames <- colnames(fprob)");
/* 227 */       this.engine.eval("maxclass <- mynames[indexmax]");
/* 228 */       StringVector res = (StringVector)this.engine.eval("maxclass");
/* 229 */       result = res.toArray();
/* 230 */       DoubleVector confi = (DoubleVector)this.engine.eval("probs");
/* 231 */       this.confindence = confi.toDoubleArray();
/*     */     }
/* 233 */     catch (ParseException e) {
/* 234 */       System.out.println("R script parse error: " + e.getMessage());
/*     */     }
/* 236 */     catch (ScriptException e) {
/*     */       
/* 238 */       e.printStackTrace();
/*     */     }
/* 240 */     catch (EvalException e) {
/* 241 */       e.printStackTrace();
/* 242 */       IJ.log("BAD!");
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 261 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public double[] getConfindence() {
/* 267 */     return this.confindence;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/ij_trajectory_classifier-0.8.2.jar!/de/biomedical_imaging/ij/trajectory_classifier/RRFClassifierRenjin.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */