/*     */ package de.biomedical_imaging.ij.trajectory_classifier.help;
/*     */ 
/*     */ import com.opencsv.CSVWriter;
/*     */ import de.biomedical_imaging.ij.trajectory_classifier.AbstractClassifier;
/*     */ import de.biomedical_imaging.ij.trajectory_classifier.RRFClassifierRenjin;
/*     */ import de.biomedical_imaging.ij.trajectory_classifier.WeightedWindowedClassificationProcess;
/*     */ import de.biomedical_imaging.traJ.Trajectory;
/*     */ import de.biomedical_imaging.traJ.features.BoundednessFeature;
/*     */ import de.biomedical_imaging.traJ.simulation.AbstractSimulator;
/*     */ import de.biomedical_imaging.traJ.simulation.ActiveTransportSimulator;
/*     */ import de.biomedical_imaging.traJ.simulation.AnomalousDiffusionWMSimulation;
/*     */ import de.biomedical_imaging.traJ.simulation.CentralRandomNumberGenerator;
/*     */ import de.biomedical_imaging.traJ.simulation.CombinedSimulator;
/*     */ import de.biomedical_imaging.traJ.simulation.ConfinedDiffusionSimulator;
/*     */ import de.biomedical_imaging.traJ.simulation.FreeDiffusionSimulator;
/*     */ import de.biomedical_imaging.traJ.simulation.SimulationUtil;
/*     */ import ij.IJ;
/*     */ import java.io.File;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.FileWriter;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import org.apache.commons.math3.stat.descriptive.moment.Mean;
/*     */ import org.apache.commons.math3.stat.descriptive.moment.StandardDeviation;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PerformanceDataGenerator
/*     */ {
/*  40 */   public static double diffusioncoefficient = 9.02D;
/*  41 */   public static String modelpath = "";
/*     */   
/*     */   public static void main(String[] args) {
/*  44 */     PerformanceDataGenerator pg = new PerformanceDataGenerator();
/*     */     try {
/*  46 */       modelpath = pg.ExportResource("/randomForestModel.RData");
/*  47 */     } catch (Exception e) {
/*     */       
/*  49 */       e.printStackTrace();
/*     */     } 
/*  51 */     System.out.println("Start!");
/*  52 */     generateNormalDiffData();
/*  53 */     System.out.println("Finish normal!");
/*  54 */     generateActiveData();
/*  55 */     System.out.println("Finish active!");
/*     */     
/*  57 */     generateConfinedData();
/*  58 */     System.out.println("Finish confined!");
/*     */     
/*  60 */     generateSubdiffusionData();
/*  61 */     System.out.println("Finish subdiffusion!");
/*     */   }
/*     */ 
/*     */   
/*     */   public static void generateActiveData() {
/*  66 */     CentralRandomNumberGenerator.getInstance().setSeed(10L);
/*  67 */     int tracklength = 500;
/*  68 */     double dt = 0.03333333333333333D;
/*  69 */     double r = 1.0D;
/*  70 */     double[] SNRs = { 1.0D, 2.0D, 5.0D };
/*  71 */     double angleVelocity = 0.7853981633974483D;
/*  72 */     int N = 50;
/*  73 */     int w = 30;
/*  74 */     RRFClassifierRenjin rRFClassifierRenjin = new RRFClassifierRenjin(modelpath, dt);
/*  75 */     rRFClassifierRenjin.start();
/*  76 */     WeightedWindowedClassificationProcess wcp = new WeightedWindowedClassificationProcess();
/*  77 */     double[] par = new double[15];
/*  78 */     double[] cor = new double[15];
/*  79 */     double[] sdcor = new double[15];
/*  80 */     double[] semcor = new double[15];
/*  81 */     int j = 0;
/*  82 */     Mean m = new Mean();
/*  83 */     StandardDeviation sd = new StandardDeviation();
/*  84 */     for (double SNR : SNRs) {
/*  85 */       r = 1.0D;
/*  86 */       j = 0;
/*  87 */       while (r <= 15.0D) {
/*     */         
/*  89 */         double[] val = new double[N];
/*  90 */         for (int i = 0; i < N; i++) {
/*     */           
/*  92 */           double drift = Math.sqrt(r * 4.0D * diffusioncoefficient / (w * 2) * dt);
/*     */           
/*  94 */           double sigmaPosNoise = Math.sqrt(diffusioncoefficient * dt + drift * drift * dt * dt) / SNR;
/*     */ 
/*     */           
/*  97 */           ActiveTransportSimulator activeTransportSimulator = new ActiveTransportSimulator(drift, angleVelocity, dt, 2, tracklength);
/*     */           
/*  99 */           FreeDiffusionSimulator freeDiffusionSimulator = new FreeDiffusionSimulator(diffusioncoefficient, dt, 2, tracklength);
/*     */           
/* 101 */           CombinedSimulator combinedSimulator = new CombinedSimulator((AbstractSimulator)activeTransportSimulator, (AbstractSimulator)freeDiffusionSimulator);
/* 102 */           Trajectory t = combinedSimulator.generateTrajectory();
/* 103 */           t = SimulationUtil.addPositionNoise(t, sigmaPosNoise);
/* 104 */           String[] res = wcp.windowedClassification(t, (AbstractClassifier)rRFClassifierRenjin, w, 1);
/* 105 */           val[i] = getCorrectNess(res, "DIRECTED/ACTIVE");
/*     */         } 
/* 107 */         double meancorrectness = m.evaluate(val);
/* 108 */         double corrsd = sd.evaluate(val);
/* 109 */         par[j] = r;
/* 110 */         cor[j] = meancorrectness;
/* 111 */         sdcor[j] = corrsd;
/* 112 */         semcor[j] = corrsd / Math.sqrt(N);
/* 113 */         j++;
/* 114 */         r++;
/*     */       } 
/*     */       
/* 117 */       exportCSV("/home/thorsten/perform_active_SNR_" + SNR + "_N_" + N + ".csv", "r", par, cor, sdcor, semcor);
/*     */     } 
/*     */     
/* 120 */     rRFClassifierRenjin.stop();
/*     */   }
/*     */   
/*     */   public static void generateSubdiffusionData() {
/* 124 */     CentralRandomNumberGenerator.getInstance().setSeed(10L);
/* 125 */     int tracklength = 500;
/* 126 */     double dt = 0.03333333333333333D;
/* 127 */     double[] alphas = { 0.3D, 0.5D, 0.7D };
/* 128 */     double SNR = 5.0D;
/* 129 */     int N = 80;
/* 130 */     RRFClassifierRenjin rRFClassifierRenjin = new RRFClassifierRenjin(modelpath, dt);
/* 131 */     rRFClassifierRenjin.start();
/* 132 */     WeightedWindowedClassificationProcess wcp = new WeightedWindowedClassificationProcess();
/* 133 */     double[] par = new double[17];
/* 134 */     double[] cor = new double[17];
/* 135 */     double[] sdcor = new double[17];
/* 136 */     double[] semcor = new double[17];
/* 137 */     int j = 0;
/* 138 */     Mean m = new Mean();
/* 139 */     StandardDeviation sd = new StandardDeviation();
/*     */     
/* 141 */     for (double alpha : alphas) {
/* 142 */       j = 0;
/* 143 */       AnomalousDiffusionWMSimulation anomalousDiffusionWMSimulation = new AnomalousDiffusionWMSimulation(diffusioncoefficient, dt, 2, 2000, alpha);
/*     */       
/* 145 */       for (int w = 15; w < 100; w += 5) {
/* 146 */         double[] val = new double[N];
/* 147 */         double sigmaPosNoise = Math.sqrt(diffusioncoefficient * dt) / SNR;
/*     */ 
/*     */         
/* 150 */         for (int i = 0; i < N; i++) {
/* 151 */           Trajectory t = anomalousDiffusionWMSimulation.generateTrajectory();
/* 152 */           t = t.subList(0, tracklength);
/* 153 */           t = SimulationUtil.addPositionNoise(t, sigmaPosNoise);
/* 154 */           String[] res = wcp.windowedClassification(t, (AbstractClassifier)rRFClassifierRenjin, w, 1);
/* 155 */           val[i] = getCorrectNess(res, "SUBDIFFUSION");
/*     */         } 
/* 157 */         double meancorrectness = m.evaluate(val);
/* 158 */         double corrsd = sd.evaluate(val);
/*     */         
/* 160 */         par[j] = (2 * w);
/* 161 */         cor[j] = meancorrectness;
/* 162 */         sdcor[j] = corrsd;
/* 163 */         semcor[j] = corrsd / Math.sqrt(N);
/* 164 */         j++;
/*     */       } 
/*     */       
/* 167 */       exportCSV("/home/thorsten/perform_subdiffusion_SNR_" + SNR + "_N_" + N + "_alpha_" + alpha + "_.csv", "r", par, cor, sdcor, semcor);
/*     */     } 
/*     */ 
/*     */     
/* 171 */     rRFClassifierRenjin.stop();
/*     */   }
/*     */   
/*     */   public static void generateConfinedData() {
/* 175 */     CentralRandomNumberGenerator.getInstance().setSeed(10L);
/* 176 */     int tracklength = 500;
/* 177 */     double dt = 0.03333333333333333D;
/* 178 */     double B = 0.5D;
/* 179 */     double[] SNRs = { 1.0D, 2.0D, 5.0D };
/*     */     
/* 181 */     int N = 200;
/* 182 */     int w = 30;
/* 183 */     RRFClassifierRenjin rRFClassifierRenjin = new RRFClassifierRenjin(modelpath, dt);
/* 184 */     rRFClassifierRenjin.start();
/* 185 */     WeightedWindowedClassificationProcess wcp = new WeightedWindowedClassificationProcess();
/* 186 */     double[] par = new double[30];
/* 187 */     double[] cor = new double[30];
/* 188 */     double[] sdcor = new double[30];
/* 189 */     double[] semcor = new double[30];
/* 190 */     int j = 0;
/* 191 */     Mean m = new Mean();
/* 192 */     StandardDeviation sd = new StandardDeviation();
/* 193 */     for (double SNR : SNRs) {
/* 194 */       B = 0.5D;
/* 195 */       j = 0;
/* 196 */       while (B <= 4.0D) {
/*     */         
/* 198 */         double[] val = new double[N];
/* 199 */         double sigmaPosNoise = Math.sqrt(diffusioncoefficient * dt) / SNR;
/*     */         
/* 201 */         double radius = Math.sqrt(BoundednessFeature.a(2 * w) * diffusioncoefficient * dt / 4.0D * B);
/*     */         
/* 203 */         ConfinedDiffusionSimulator confinedDiffusionSimulator = new ConfinedDiffusionSimulator(diffusioncoefficient, dt, radius, 2, tracklength);
/*     */         
/* 205 */         for (int i = 0; i < N; i++) {
/*     */           
/* 207 */           Trajectory t = confinedDiffusionSimulator.generateTrajectory();
/* 208 */           t = SimulationUtil.addPositionNoise(t, sigmaPosNoise);
/* 209 */           String[] res = wcp.windowedClassification(t, (AbstractClassifier)rRFClassifierRenjin, w, 1);
/* 210 */           val[i] = getCorrectNess(res, "CONFINED");
/*     */         } 
/* 212 */         double meancorrectness = m.evaluate(val);
/* 213 */         double corrsd = sd.evaluate(val);
/*     */         
/* 215 */         par[j] = B;
/* 216 */         cor[j] = meancorrectness;
/* 217 */         sdcor[j] = corrsd;
/* 218 */         semcor[j] = corrsd / Math.sqrt(N);
/* 219 */         j++;
/* 220 */         B += 0.2D;
/*     */       } 
/*     */       
/* 223 */       exportCSV("/home/thorsten/perform_confined_SNR_" + SNR + "_N_" + N + "_B_" + B + "_.csv", "r", par, cor, sdcor, semcor);
/*     */     } 
/*     */     
/* 226 */     rRFClassifierRenjin.stop();
/*     */   }
/*     */   
/*     */   public static void generateNormalDiffData() {
/* 230 */     CentralRandomNumberGenerator.getInstance().setSeed(10L);
/* 231 */     int tracklength = 500;
/* 232 */     double dt = 0.03333333333333333D;
/* 233 */     double[] SNRs = { 1.0D, 2.0D, 5.0D };
/* 234 */     int N = 200;
/*     */     
/* 236 */     RRFClassifierRenjin rRFClassifierRenjin = new RRFClassifierRenjin(modelpath, dt);
/* 237 */     rRFClassifierRenjin.start();
/* 238 */     WeightedWindowedClassificationProcess wcp = new WeightedWindowedClassificationProcess();
/* 239 */     double[] par = new double[16];
/* 240 */     double[] cor = new double[16];
/* 241 */     double[] sdcor = new double[16];
/* 242 */     double[] semcor = new double[16];
/* 243 */     Mean m = new Mean();
/* 244 */     StandardDeviation sd = new StandardDeviation();
/* 245 */     for (double SNR : SNRs) {
/* 246 */       int w = 15;
/* 247 */       int j = 0;
/* 248 */       while (w <= 90) {
/*     */         
/* 250 */         double[] val = new double[N];
/* 251 */         for (int i = 0; i < N; i++) {
/*     */           
/* 253 */           double sigmaPosNoise = Math.sqrt(diffusioncoefficient * dt) / SNR;
/*     */           
/* 255 */           FreeDiffusionSimulator freeDiffusionSimulator = new FreeDiffusionSimulator(diffusioncoefficient, dt, 2, tracklength);
/*     */           
/* 257 */           Trajectory t = freeDiffusionSimulator.generateTrajectory();
/* 258 */           t = SimulationUtil.addPositionNoise(t, sigmaPosNoise);
/* 259 */           String[] res = wcp.windowedClassification(t, (AbstractClassifier)rRFClassifierRenjin, w, 1);
/* 260 */           val[i] = getCorrectNess(res, "NORM. DIFFUSION");
/*     */         } 
/* 262 */         double meancorrectness = m.evaluate(val);
/* 263 */         double corrsd = sd.evaluate(val);
/*     */         
/* 265 */         par[j] = (2 * w);
/* 266 */         cor[j] = meancorrectness;
/* 267 */         sdcor[j] = corrsd;
/* 268 */         semcor[j] = corrsd / Math.sqrt(N);
/* 269 */         j++;
/* 270 */         w += 5;
/*     */       } 
/*     */       
/* 273 */       exportCSV("/home/thorsten/perform_normal_SNR_" + SNR + "_N_" + N + ".csv", "w", par, cor, sdcor, semcor);
/*     */     } 
/*     */ 
/*     */     
/* 277 */     rRFClassifierRenjin.stop();
/*     */   }
/*     */ 
/*     */   
/*     */   public static void exportCSV(String path, String parameter, double[] par, double[] cor, double[] corsd, double[] semcor) {
/* 282 */     String[] nextLine = null;
/*     */ 
/*     */     
/*     */     try {
/* 286 */       CSVWriter writer = new CSVWriter(new FileWriter(path, false), '\t');
/* 287 */       nextLine = new String[] { parameter, "correctness", "sd", "sem" };
/* 288 */       writer.writeNext(nextLine);
/*     */       
/* 290 */       for (int i = 0; i < cor.length; i++) {
/* 291 */         double parv = par[i];
/* 292 */         double corv = cor[i];
/* 293 */         double sd = corsd[i];
/* 294 */         double sem = semcor[i];
/* 295 */         nextLine = new String[] { "" + parv, "" + corv, "" + sd + "" + sem };
/* 296 */         writer.writeNext(nextLine);
/*     */       } 
/*     */       
/* 299 */       writer.close();
/* 300 */     } catch (IOException e) {
/*     */       
/* 302 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static double getCorrectNess(String[] actual, String expclass) {
/* 308 */     int corr = 0;
/* 309 */     for (int i = 0; i < actual.length; i++) {
/* 310 */       if (actual[i].equals(expclass)) {
/* 311 */         corr++;
/*     */       }
/*     */     } 
/* 314 */     return 1.0D * corr / actual.length;
/*     */   }
/*     */   public String ExportResource(String resourceName) throws Exception {
/*     */     String tmpFolder;
/* 318 */     InputStream stream = null;
/* 319 */     OutputStream resStreamOut = null;
/*     */     
/*     */     try {
/* 322 */       stream = getClass().getResourceAsStream(resourceName);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 340 */       if (stream == null) {
/* 341 */         IJ.error("Cannot get resource \"" + resourceName + "\" from Jar file.");
/*     */         
/* 343 */         throw new Exception("Cannot get resource \"" + resourceName + "\" from Jar file.");
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 348 */       byte[] buffer = new byte[4096];
/* 349 */       File folderDir = new File(IJ.getDirectory("temp") + "/.trajclassifier");
/*     */ 
/*     */ 
/*     */       
/* 353 */       if (!folderDir.exists()) {
/* 354 */         folderDir.mkdir();
/*     */       }
/* 356 */       tmpFolder = folderDir.getPath().replace('\\', '/');
/* 357 */       resStreamOut = new FileOutputStream(tmpFolder + resourceName); int readBytes;
/* 358 */       while ((readBytes = stream.read(buffer)) > 0) {
/* 359 */         resStreamOut.write(buffer, 0, readBytes);
/*     */       }
/* 361 */     } catch (Exception ex) {
/* 362 */       IJ.error(ex.getMessage());
/* 363 */       throw ex;
/*     */     } finally {
/* 365 */       stream.close();
/* 366 */       resStreamOut.close();
/*     */     } 
/*     */     
/* 369 */     return tmpFolder + resourceName;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/ij_trajectory_classifier-0.8.2.jar!/de/biomedical_imaging/ij/trajectory_classifier/help/PerformanceDataGenerator.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */