/*    */ package de.biomedical_imaging.ij.trajectory_classifier;
/*    */ 
/*    */ import com.opencsv.CSVReader;
/*    */ import com.opencsv.CSVWriter;
/*    */ import de.biomedical_imaging.traJ.Trajectory;
/*    */ import java.io.FileReader;
/*    */ import java.io.FileWriter;
/*    */ import java.io.IOException;
/*    */ import java.util.ArrayList;
/*    */ import org.scijava.vecmath.Point3d;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ExportImportTools
/*    */ {
/*    */   public void exportTrajectoryDataAsCSV(ArrayList<? extends Trajectory> tracks, String path) {
/* 40 */     String[] nextLine = null;
/*    */     try {
/* 42 */       CSVWriter writer = new CSVWriter(new FileWriter(path, false), ',');
/* 43 */       nextLine = new String[] { "ID", "X", "Y", "CLASS" };
/* 44 */       writer.writeNext(nextLine);
/*    */       
/* 46 */       for (int i = 0; i < tracks.size(); i++) {
/* 47 */         Trajectory t = tracks.get(i);
/* 48 */         for (int j = 0; j < t.size(); j++) {
/* 49 */           nextLine = new String[] { "" + t.getID(), "" + ((Point3d)t.get(j)).x, "" + ((Point3d)t.get(j)).y, t.getType() };
/* 50 */           writer.writeNext(nextLine);
/*    */         } 
/*    */       } 
/* 53 */       writer.close();
/*    */     }
/* 55 */     catch (IOException e) {
/*    */       
/* 57 */       e.printStackTrace();
/*    */     } 
/*    */   }
/*    */   
/*    */   public ArrayList<Trajectory> importTrajectoryDataFromCSV(String path) {
/* 62 */     ArrayList<Trajectory> tracks = new ArrayList<>();
/*    */     try {
/* 64 */       CSVReader reader = new CSVReader(new FileReader(path));
/*    */       
/* 66 */       reader.readNext();
/* 67 */       Trajectory t = null;
/* 68 */       int lastID = -1; String[] nextLine;
/* 69 */       while ((nextLine = reader.readNext()) != null) {
/* 70 */         int nextID = Integer.parseInt(nextLine[0]);
/* 71 */         double nextX = Double.parseDouble(nextLine[1]);
/* 72 */         double nextY = Double.parseDouble(nextLine[2]);
/* 73 */         String nextClass = nextLine[3];
/* 74 */         if (nextID == lastID) {
/* 75 */           System.out.println();
/* 76 */           t.add(nextX, nextY, 0.0D);
/* 77 */           lastID = nextID; continue;
/*    */         } 
/* 79 */         if (t != null) {
/* 80 */           tracks.add(t);
/*    */         }
/* 82 */         t = new Trajectory(2);
/* 83 */         t.setID(nextID);
/* 84 */         t.setType(nextClass);
/* 85 */         t.add(nextX, nextY, 0.0D);
/* 86 */         lastID = nextID;
/*    */       } 
/*    */       
/* 89 */       tracks.add(t);
/* 90 */       reader.close();
/*    */     
/*    */     }
/* 93 */     catch (IOException e) {
/*    */       
/* 95 */       e.printStackTrace();
/*    */     } 
/*    */     
/* 98 */     return tracks;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/ij_trajectory_classifier-0.8.2.jar!/de/biomedical_imaging/ij/trajectory_classifier/ExportImportTools.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */