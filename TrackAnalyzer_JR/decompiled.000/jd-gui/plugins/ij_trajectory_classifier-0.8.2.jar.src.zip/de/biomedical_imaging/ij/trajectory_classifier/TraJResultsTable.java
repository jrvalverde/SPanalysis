/*     */ package de.biomedical_imaging.ij.trajectory_classifier;
/*     */ 
/*     */ import de.biomedical_imaging.traJ.DiffusionCoefficientEstimator.RegressionDiffusionCoefficientEstimator;
/*     */ import de.biomedical_imaging.traJ.Trajectory;
/*     */ import de.biomedical_imaging.traJ.TrajectoryUtil;
/*     */ import de.biomedical_imaging.traJ.VisualizationUtils;
/*     */ import de.biomedical_imaging.traJ.features.ActiveTransportParametersFeature;
/*     */ import de.biomedical_imaging.traJ.features.ConfinedDiffusionParametersFeature;
/*     */ import de.biomedical_imaging.traJ.features.PowerLawFeature;
/*     */ import ij.IJ;
/*     */ import ij.WindowManager;
/*     */ import ij.measure.ResultsTable;
/*     */ import ij.text.TextPanel;
/*     */ import java.awt.Frame;
/*     */ import java.awt.Menu;
/*     */ import java.awt.MenuItem;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.util.ArrayList;
/*     */ import javax.swing.JFileChooser;
/*     */ import javax.swing.filechooser.FileNameExtensionFilter;
/*     */ import org.knowm.xchart.Chart;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TraJResultsTable
/*     */   extends ResultsTable
/*     */ {
/*     */   boolean isParentTable;
/*     */   
/*     */   public TraJResultsTable() {
/*  55 */     this.isParentTable = false;
/*     */   }
/*     */   
/*     */   public TraJResultsTable(boolean isParentTable) {
/*  59 */     this.isParentTable = isParentTable;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void show(String windowTitle) {
/*  65 */     super.show(windowTitle);
/*  66 */     final ResultsTable table = this;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  72 */     MenuItem plotSelectedTrajectory = new MenuItem("Plot trajectory");
/*  73 */     plotSelectedTrajectory.addActionListener(new ActionListener()
/*     */         {
/*     */           
/*     */           public void actionPerformed(ActionEvent e)
/*     */           {
/*  78 */             Frame f = (Frame)WindowManager.getActiveWindow();
/*  79 */             if (f.getComponent(0) instanceof TextPanel) {
/*  80 */               TextPanel p = (TextPanel)f.getComponent(0);
/*     */               
/*  82 */               int selectionStart = p.getSelectionStart();
/*  83 */               int selectionEnd = p.getSelectionEnd();
/*  84 */               ArrayList<Chart> charts = new ArrayList<>();
/*  85 */               if (selectionStart >= 0 && selectionStart == selectionEnd) {
/*  86 */                 ArrayList<? extends Trajectory> cTracks; int id = (int)table.getValue("ID", selectionStart);
/*     */ 
/*     */                 
/*  89 */                 if (TraJResultsTable.this.isParentTable) {
/*  90 */                   cTracks = TraJClassifier_.getInstance().getParentTrajectories();
/*     */                 } else {
/*  92 */                   cTracks = (ArrayList)TraJClassifier_.getInstance().getClassifiedTrajectories();
/*     */                 } 
/*  94 */                 Trajectory t = TrajectoryUtil.getTrajectoryByID(cTracks, id);
/*  95 */                 Chart c = VisualizationUtils.getTrajectoryChart("Trajectory with ID " + id, t);
/*  96 */                 charts.add(c);
/*  97 */                 double timelag = TraJClassifier_.getInstance().getTimelag();
/*  98 */                 if (t.getType().equals("SUBDIFFUSION")) {
/*  99 */                   PowerLawFeature pwf = new PowerLawFeature(t, 1.0D / timelag, 1, t.size() / 3);
/* 100 */                   double[] res = pwf.evaluate();
/* 101 */                   c = VisualizationUtils.getMSDLineWithPowerModelChart(t, 1, t.size() / 3, timelag, res[0], res[1]);
/* 102 */                   charts.add(c);
/*     */                 
/*     */                 }
/* 105 */                 else if (t.getType().equals("CONFINED")) {
/* 106 */                   ConfinedDiffusionParametersFeature cfeature = new ConfinedDiffusionParametersFeature(t, timelag, TraJClassifier_.getInstance().isUseReducedModelConfinedMotion());
/* 107 */                   double[] res = cfeature.evaluate();
/* 108 */                   if (TraJClassifier_.getInstance().isUseReducedModelConfinedMotion()) {
/* 109 */                     c = VisualizationUtils.getMSDLineWithConfinedModelChart(t, 1, t.size() / 3, timelag, res[0], 1.0D, 1.0D, res[1]);
/* 110 */                     charts.add(c);
/*     */                   } else {
/* 112 */                     c = VisualizationUtils.getMSDLineWithConfinedModelChart(t, 1, t.size() / 3, timelag, res[0], res[2], res[3], res[1]);
/* 113 */                     charts.add(c);
/*     */                   } 
/* 115 */                 } else if (t.getType().equals("NORM. DIFFUSION")) {
/* 116 */                   RegressionDiffusionCoefficientEstimator regest = new RegressionDiffusionCoefficientEstimator(t, 1.0D / timelag, 1, t.size() / 3);
/* 117 */                   double[] res = regest.evaluate();
/* 118 */                   double dc = res[0];
/* 119 */                   double intercept = res[2];
/* 120 */                   c = VisualizationUtils.getMSDLineWithFreeModelChart(t, 1, t.size() / 3, timelag, dc, intercept);
/* 121 */                   charts.add(c);
/* 122 */                 } else if (t.getType().equals("DIRECTED/ACTIVE")) {
/* 123 */                   ActiveTransportParametersFeature apf = new ActiveTransportParametersFeature(t, timelag);
/* 124 */                   double[] ares = apf.evaluate();
/* 125 */                   c = VisualizationUtils.getMSDLineWithActiveTransportModelChart(t, 1, t.size() / 3, timelag, ares[0], ares[1]);
/* 126 */                   charts.add(c);
/*     */                 } else {
/* 128 */                   c = VisualizationUtils.getMSDLineChart(t, 1, t.size() / 3);
/* 129 */                   charts.add(c);
/*     */                 } 
/* 131 */                 VisualizationUtils.plotCharts(charts);
/* 132 */               } else if (selectionStart != selectionEnd) {
/* 133 */                 IJ.showMessage("Plot of multiple trajectories is not possible");
/*     */               } else {
/*     */                 
/* 136 */                 IJ.showMessage("No trajectory selected");
/*     */               } 
/*     */             } 
/*     */           }
/*     */         });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 146 */     MenuItem exportTrajectories = new MenuItem("Export trajetorie(s)");
/*     */     
/* 148 */     exportTrajectories.addActionListener(new ActionListener()
/*     */         {
/*     */           public void actionPerformed(ActionEvent e)
/*     */           {
/* 152 */             Frame f = (Frame)WindowManager.getActiveWindow();
/*     */             
/* 154 */             if (f.getComponent(0) instanceof TextPanel) {
/* 155 */               TextPanel p = (TextPanel)f.getComponent(0);
/*     */               
/* 157 */               int selectionStart = p.getSelectionStart();
/* 158 */               int selectionEnd = p.getSelectionEnd();
/* 159 */               if (selectionStart == -1 && selectionEnd == -1) {
/* 160 */                 selectionStart = 0;
/* 161 */                 selectionEnd = p.getResultsTable().getCounter();
/*     */               } 
/*     */               
/* 164 */               ArrayList<Trajectory> selectedTrajectories = new ArrayList<>();
/* 165 */               for (int i = selectionStart; i <= selectionEnd; i++) {
/* 166 */                 int id = (int)table.getValue("ID", i);
/*     */                 
/* 168 */                 ArrayList<? extends Trajectory> cTracks = null;
/* 169 */                 if (TraJResultsTable.this.isParentTable) {
/* 170 */                   cTracks = TraJClassifier_.getInstance().getParentTrajectories();
/*     */                 } else {
/* 172 */                   cTracks = (ArrayList)TraJClassifier_.getInstance().getClassifiedTrajectories();
/*     */                 } 
/* 174 */                 Trajectory t = TrajectoryUtil.getTrajectoryByID(cTracks, id);
/* 175 */                 selectedTrajectories.add(t);
/*     */               } 
/*     */               
/* 178 */               JFileChooser chooser = new JFileChooser();
/* 179 */               chooser.setFileSelectionMode(2);
/* 180 */               chooser.addChoosableFileFilter(new FileNameExtensionFilter("Comma seperated value (.csv)", new String[] { "csv" }));
/* 181 */               chooser.setAcceptAllFileFilterUsed(false);
/* 182 */               int c = chooser.showSaveDialog(null);
/* 183 */               if (c == 0) {
/* 184 */                 String path = chooser.getSelectedFile().getAbsolutePath();
/* 185 */                 if (!path.substring(path.length() - 3, path.length()).equals("csv")) {
/* 186 */                   path = path + ".csv";
/*     */                 }
/*     */                 
/* 189 */                 ExportImportTools eit = new ExportImportTools();
/* 190 */                 eit.exportTrajectoryDataAsCSV(selectedTrajectories, path);
/*     */               } 
/*     */             } 
/*     */           }
/*     */         });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 200 */     Menu traJ = new Menu("Trajectory classifier");
/* 201 */     traJ.add(plotSelectedTrajectory);
/* 202 */     traJ.add(exportTrajectories);
/*     */ 
/*     */     
/* 205 */     WindowManager.getFrame(windowTitle).getMenuBar().add(traJ);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/ij_trajectory_classifier-0.8.2.jar!/de/biomedical_imaging/ij/trajectory_classifier/TraJResultsTable.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */