/*    */ package de.biomedical_imaging.ij.trajectory_classifier;
/*    */ 
/*    */ import de.biomedical_imaging.traJ.features.AbstractTrajectoryFeature;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FeatureWorker
/*    */   extends Thread
/*    */ {
/*    */   double[] result;
/*    */   AbstractTrajectoryFeature c;
/*    */   EVALTYPE ev;
/*    */   int resIndex;
/*    */   
/*    */   enum EVALTYPE
/*    */   {
/* 31 */     FIRST, SECOND, RATIO_01, RATIO_10, RATIO_12;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public FeatureWorker(double[] result, int resIndex, AbstractTrajectoryFeature c, EVALTYPE ev) {
/* 39 */     this.result = result;
/* 40 */     this.c = c;
/* 41 */     this.ev = ev;
/* 42 */     this.resIndex = resIndex;
/*    */   }
/*    */ 
/*    */   
/*    */   public void run() {
/*    */     double[] res;
/* 48 */     switch (this.ev) {
/*    */       case FIRST:
/* 50 */         res = this.c.getValue();
/* 51 */         this.result[this.resIndex] = res[0];
/*    */         break;
/*    */       case SECOND:
/* 54 */         res = this.c.getValue();
/* 55 */         this.result[this.resIndex] = res[1];
/*    */         break;
/*    */       case RATIO_01:
/* 58 */         res = this.c.getValue();
/* 59 */         this.result[this.resIndex] = res[0] / res[1];
/*    */         break;
/*    */       case RATIO_10:
/* 62 */         res = this.c.getValue();
/* 63 */         this.result[this.resIndex] = res[1] / res[0];
/*    */         break;
/*    */       case RATIO_12:
/* 66 */         res = this.c.getValue();
/* 67 */         this.result[this.resIndex] = res[1] / res[2];
/*    */         break;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/ij_trajectory_classifier-0.8.2.jar!/de/biomedical_imaging/ij/trajectory_classifier/FeatureWorker.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */