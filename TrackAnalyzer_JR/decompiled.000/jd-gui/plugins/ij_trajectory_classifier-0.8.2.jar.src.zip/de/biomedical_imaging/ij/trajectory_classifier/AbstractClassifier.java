package de.biomedical_imaging.ij.trajectory_classifier;

import de.biomedical_imaging.traJ.Trajectory;
import java.util.ArrayList;

public abstract class AbstractClassifier {
  public abstract String classify(Trajectory paramTrajectory);
  
  public abstract void start();
  
  public abstract void stop();
  
  public abstract String[] classify(ArrayList<Trajectory> paramArrayList);
  
  public abstract double[] getConfindence();
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/ij_trajectory_classifier-0.8.2.jar!/de/biomedical_imaging/ij/trajectory_classifier/AbstractClassifier.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */