/*    */ package de.biomedical_imaging.ij.trajectory_classifier.help;
/*    */ 
/*    */ import de.biomedical_imaging.traJ.Trajectory;
/*    */ import de.biomedical_imaging.traJ.simulation.AbstractSimulator;
/*    */ import de.biomedical_imaging.traJ.simulation.CentralRandomNumberGenerator;
/*    */ 
/*    */ public class StalledSimulator extends AbstractSimulator {
/*    */   int N;
/*    */   double sigma;
/*    */   
/*    */   public StalledSimulator(int N, double sigma) {
/* 12 */     this.N = N;
/* 13 */     this.sigma = sigma;
/*    */   }
/*    */ 
/*    */   
/*    */   public Trajectory generateTrajectory() {
/* 18 */     Trajectory t = new Trajectory(2);
/* 19 */     CentralRandomNumberGenerator r = CentralRandomNumberGenerator.getInstance();
/* 20 */     for (int i = 0; i < this.N; i++) {
/* 21 */       t.add(r.nextDouble() * this.sigma, r.nextDouble() * this.sigma, 0.0D);
/*    */     }
/* 23 */     t.setType("STALLED");
/* 24 */     return t;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/ij_trajectory_classifier-0.8.2.jar!/de/biomedical_imaging/ij/trajectory_classifier/help/StalledSimulator.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */