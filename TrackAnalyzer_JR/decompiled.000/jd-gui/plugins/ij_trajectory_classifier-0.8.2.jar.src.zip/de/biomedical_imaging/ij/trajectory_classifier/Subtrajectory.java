/*    */ package de.biomedical_imaging.ij.trajectory_classifier;
/*    */ 
/*    */ import de.biomedical_imaging.traJ.Trajectory;
/*    */ import java.util.ArrayList;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Subtrajectory
/*    */   extends Trajectory
/*    */ {
/*    */   private static final long serialVersionUID = 3846588503781023924L;
/*    */   private Trajectory parent;
/*    */   private double confidence;
/*    */   
/*    */   public Subtrajectory(Trajectory parent, int dimension) {
/* 41 */     super(dimension);
/* 42 */     this.parent = parent;
/*    */   }
/*    */   
/*    */   public Subtrajectory(Trajectory parent, int dimension, int relativeStartPoint) {
/* 46 */     super(dimension, relativeStartPoint);
/* 47 */     this.parent = parent;
/*    */   }
/*    */   
/*    */   public Trajectory getParent() {
/* 51 */     return this.parent;
/*    */   }
/*    */   
/*    */   public static ArrayList<Subtrajectory> getTracksWithSameParant(ArrayList<Subtrajectory> tracks, long parentid) {
/* 55 */     ArrayList<Subtrajectory> res = new ArrayList<>();
/*    */     
/* 57 */     for (Subtrajectory sub : tracks) {
/* 58 */       if (sub.getParent().getID() == parentid) {
/* 59 */         res.add(sub);
/*    */       }
/*    */     } 
/*    */     
/* 63 */     return res;
/*    */   }
/*    */   
/*    */   public void setConfidence(double confidence) {
/* 67 */     this.confidence = confidence;
/*    */   }
/*    */   
/*    */   public double getConfidence() {
/* 71 */     return this.confidence;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/ij_trajectory_classifier-0.8.2.jar!/de/biomedical_imaging/ij/trajectory_classifier/Subtrajectory.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */