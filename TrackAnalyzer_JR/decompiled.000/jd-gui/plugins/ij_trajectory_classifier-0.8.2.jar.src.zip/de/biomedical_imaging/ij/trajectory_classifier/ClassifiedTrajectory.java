/*    */ package de.biomedical_imaging.ij.trajectory_classifier;
/*    */ 
/*    */ import de.biomedical_imaging.traJ.Trajectory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ClassifiedTrajectory
/*    */   extends Trajectory
/*    */ {
/*    */   private static final long serialVersionUID = 3845396333189368623L;
/*    */   private long parentID;
/*    */   
/*    */   public ClassifiedTrajectory(int dimension) {
/* 33 */     super(dimension);
/* 34 */     this.parentID = 0L;
/*    */   }
/*    */   
/*    */   public ClassifiedTrajectory(int dimension, long parentID) {
/* 38 */     super(dimension);
/* 39 */     this.parentID = parentID;
/*    */   }
/*    */   
/*    */   public long getParentID() {
/* 43 */     return this.parentID;
/*    */   }
/*    */   
/*    */   public void setParentID(long id) {
/* 47 */     this.parentID = id;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/ij_trajectory_classifier-0.8.2.jar!/de/biomedical_imaging/ij/trajectory_classifier/ClassifiedTrajectory.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */