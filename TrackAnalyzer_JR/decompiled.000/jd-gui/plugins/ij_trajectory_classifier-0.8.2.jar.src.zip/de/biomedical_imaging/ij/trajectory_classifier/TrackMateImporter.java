/*     */ package de.biomedical_imaging.ij.trajectory_classifier;
/*     */ 
/*     */ import de.biomedical_imaging.traJ.Trajectory;
/*     */ import ij.IJ;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import javax.xml.parsers.DocumentBuilder;
/*     */ import javax.xml.parsers.DocumentBuilderFactory;
/*     */ import javax.xml.parsers.ParserConfigurationException;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ import org.xml.sax.SAXException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TrackMateImporter
/*     */ {
/*     */   public ArrayList<Trajectory> importTrackMateXML(String path) {
/*  50 */     ArrayList<Trajectory> trajectories = new ArrayList<>();
/*  51 */     Trajectory.restIDCounter();
/*     */ 
/*     */ 
/*     */     
/*  55 */     Document doc = null;
/*     */     try {
/*  57 */       File fXmlFile = new File(path);
/*     */       
/*  59 */       DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
/*  60 */       DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
/*  61 */       doc = dBuilder.parse(fXmlFile);
/*     */     }
/*  63 */     catch (SAXException e) {
/*     */       
/*  65 */       IJ.log("" + e.getStackTrace());
/*  66 */     } catch (IOException e) {
/*     */       
/*  68 */       IJ.log("" + e.getStackTrace());
/*  69 */     } catch (ParserConfigurationException e) {
/*     */       
/*  71 */       IJ.log("" + e.getStackTrace());
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  78 */     NodeList nTracks = doc.getElementsByTagName("particle");
/*     */     
/*  80 */     for (int i = 0; i < nTracks.getLength(); i++) {
/*  81 */       Trajectory t = new Trajectory(2);
/*  82 */       Node track = nTracks.item(i);
/*  83 */       boolean firstPosition = true;
/*  84 */       NodeList nSteps = track.getChildNodes();
/*  85 */       for (int j = 0; j < nSteps.getLength(); j++) {
/*  86 */         Node step = nSteps.item(j);
/*  87 */         if (step.getNodeName() == "detection") {
/*  88 */           Element e = (Element)step;
/*  89 */           double x = Double.parseDouble(e.getAttribute("x"));
/*  90 */           double y = Double.parseDouble(e.getAttribute("y"));
/*  91 */           int time = Integer.parseInt(e.getAttribute("t"));
/*  92 */           if (firstPosition) {
/*  93 */             t.setRelativStartTimepoint(time);
/*  94 */             firstPosition = false;
/*     */           } 
/*  96 */           t.add(x, y, 0.0D);
/*     */         } 
/*     */       } 
/*     */       
/* 100 */       trajectories.add(t);
/*     */     } 
/*     */     
/* 103 */     return trajectories;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/ij_trajectory_classifier-0.8.2.jar!/de/biomedical_imaging/ij/trajectory_classifier/TrackMateImporter.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */