/*     */ package de.biomedical_imaging.ij.trajectory_classifier;
/*     */ 
/*     */ import de.biomedical_imaging.traJ.Trajectory;
/*     */ import de.biomedical_imaging.traJ.TrajectoryUtil;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WeightedWindowedClassificationProcess
/*     */ {
/*  38 */   private double[] posConfidence = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] windowedClassification(Trajectory t, AbstractClassifier c, int n, int rate) {
/*  48 */     int windowsize = 2 * n + 1;
/*     */     
/*  50 */     int increment = 1;
/*  51 */     ArrayList<Trajectory> tracks = new ArrayList<>(); int i;
/*  52 */     for (i = 0; i < t.size() - windowsize + increment; i += increment) {
/*  53 */       Trajectory sub = t.subList(i, i + windowsize - 1);
/*  54 */       if (rate > 1) {
/*  55 */         sub = TrajectoryUtil.resample(sub, rate);
/*     */       }
/*  57 */       tracks.add(sub);
/*     */     } 
/*     */     
/*  60 */     String[] res = c.classify(tracks);
/*     */     
/*  62 */     double[] confidence = c.getConfindence();
/*     */     
/*  64 */     String[] types = applyWeightening(res, confidence, n, t.size());
/*  65 */     return types;
/*     */   }
/*     */ 
/*     */   
/*     */   public double[] getPositionConfidence() {
/*  70 */     return this.posConfidence;
/*     */   }
/*     */ 
/*     */   
/*     */   protected String[] applyWeightening(String[] res, double[] confidence, int n, int tracklength) {
/*  75 */     String[] types = new String[tracklength];
/*  76 */     this.posConfidence = new double[tracklength];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  83 */     ArrayList<String> restypes = new ArrayList<>();
/*  84 */     for (int i = 0; i < res.length; i++) {
/*  85 */       restypes.add(res[i]);
/*     */     }
/*     */     
/*  88 */     HashSet<String> uniqueTypes = new HashSet<>();
/*  89 */     uniqueTypes.addAll(restypes);
/*  90 */     HashMap<String, Integer> mapTypeToInt = new HashMap<>();
/*  91 */     HashMap<Integer, String> mapIntToType = new HashMap<>();
/*  92 */     Iterator<String> it = uniqueTypes.iterator();
/*  93 */     int key = 0;
/*  94 */     while (it.hasNext()) {
/*  95 */       String type = it.next();
/*  96 */       mapTypeToInt.put(type, Integer.valueOf(key));
/*  97 */       mapIntToType.put(Integer.valueOf(key), type);
/*  98 */       key++;
/*     */     } 
/*     */     
/* 101 */     ArrayList<Double[]> weightes = (ArrayList)new ArrayList<>();
/* 102 */     ArrayList<Integer[]> Nvotes = (ArrayList)new ArrayList<>(); int j;
/* 103 */     for (j = 0; j < tracklength; j++) {
/* 104 */       Double[] h = new Double[key];
/* 105 */       Arrays.fill((Object[])h, new Double(0.0D));
/* 106 */       weightes.add(h);
/*     */       
/* 108 */       Integer[] h1 = new Integer[key];
/* 109 */       Arrays.fill((Object[])h1, new Integer(0));
/* 110 */       Nvotes.add(h1);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 115 */     for (j = 0; j < res.length; j++) {
/* 116 */       for (int k = j; k < j + 2 * n + 1; k++) {
/* 117 */         int typ = ((Integer)mapTypeToInt.get(res[j])).intValue();
/*     */ 
/*     */         
/* 120 */         ((Double[])weightes.get(k))[typ] = Double.valueOf(((Double[])weightes.get(k))[typ].doubleValue() + confidence[j]);
/* 121 */         ((Integer[])Nvotes.get(k))[typ] = Integer.valueOf(((Integer[])Nvotes.get(k))[typ].intValue() + 1);
/*     */       } 
/*     */     } 
/*     */     
/* 125 */     for (j = 0; j < types.length; j++) {
/* 126 */       if (((Double[])weightes.get(j)).length > 0) {
/* 127 */         double[] result = getHighest(weightes.get(j));
/* 128 */         int mode1 = (int)result[0];
/* 129 */         double maxv = result[1];
/* 130 */         double wConf = maxv / ((Integer[])Nvotes.get(j))[mode1].intValue();
/* 131 */         String mode = mapIntToType.get(Integer.valueOf(mode1));
/* 132 */         types[j] = mode;
/* 133 */         this.posConfidence[j] = wConf;
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 141 */     return types;
/*     */   }
/*     */   
/*     */   private double[] getHighest(Double[] weightes) {
/* 145 */     double max = 0.0D;
/* 146 */     int maxindex = 0;
/* 147 */     for (int i = 0; i < weightes.length; i++) {
/* 148 */       if (weightes[i].doubleValue() > max) {
/* 149 */         max = weightes[i].doubleValue();
/* 150 */         maxindex = i;
/*     */       } 
/*     */     } 
/* 153 */     return new double[] { maxindex, max };
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public double[] arrListToArray(ArrayList<Integer> l) {
/* 159 */     double[] a = new double[l.size()];
/* 160 */     for (int i = 0; i < l.size(); i++) {
/* 161 */       a[i] = ((Integer)l.get(i)).intValue();
/*     */     }
/* 163 */     return a;
/*     */   }
/*     */   
/*     */   public int[] arrListToArrayInt(ArrayList<Integer> l) {
/* 167 */     int[] a = new int[l.size()];
/* 168 */     for (int i = 0; i < l.size(); i++) {
/* 169 */       a[i] = ((Integer)l.get(i)).intValue();
/*     */     }
/* 171 */     return a;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/ij_trajectory_classifier-0.8.2.jar!/de/biomedical_imaging/ij/trajectory_classifier/WeightedWindowedClassificationProcess.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */