/*     */ package com.orsoncharts.marker;
/*     */ 
/*     */ import java.awt.geom.Point2D;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MarkerLine
/*     */ {
/*     */   private double pos;
/*     */   private boolean pegged;
/*     */   private int v0;
/*     */   private int v1;
/*     */   private Point2D startPoint;
/*     */   private Point2D endPoint;
/*     */   
/*     */   public MarkerLine(double pos, boolean pegged) {
/*  54 */     this(pos, pegged, -1, -1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MarkerLine(double pos, boolean pegged, int v0, int v1) {
/*  67 */     this.pos = pos;
/*  68 */     this.pegged = pegged;
/*  69 */     this.v0 = v0;
/*  70 */     this.v1 = v1;
/*  71 */     this.startPoint = null;
/*  72 */     this.endPoint = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getPos() {
/*  81 */     return this.pos;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isPegged() {
/*  94 */     return this.pegged;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getV0() {
/* 103 */     return this.v0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setV0(int v0) {
/* 112 */     this.v0 = v0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getV1() {
/* 121 */     return this.v1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setV1(int v1) {
/* 130 */     this.v1 = v1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Point2D getStartPoint() {
/* 139 */     return this.startPoint;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setStartPoint(Point2D pt) {
/* 148 */     this.startPoint = pt;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Point2D getEndPoint() {
/* 157 */     return this.endPoint;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setEndPoint(Point2D pt) {
/* 166 */     this.endPoint = pt;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/marker/MarkerLine.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */