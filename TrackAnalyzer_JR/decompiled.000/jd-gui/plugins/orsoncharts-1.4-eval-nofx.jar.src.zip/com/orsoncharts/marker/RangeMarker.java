/*     */ package com.orsoncharts.marker;
/*     */ 
/*     */ import com.orsoncharts.Range;
/*     */ import com.orsoncharts.util.Anchor2D;
/*     */ import com.orsoncharts.util.ArgChecks;
/*     */ import com.orsoncharts.util.ObjectUtils;
/*     */ import java.awt.Color;
/*     */ import java.awt.Font;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.geom.Line2D;
/*     */ import java.awt.geom.Path2D;
/*     */ import java.awt.geom.Point2D;
/*     */ import java.io.Serializable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RangeMarker
/*     */   extends AbstractMarker
/*     */   implements ValueMarker, MarkerChangeListener, Serializable
/*     */ {
/*     */   private NumberMarker start;
/*     */   private NumberMarker end;
/*     */   private String label;
/*     */   private Font font;
/*     */   private Color labelColor;
/*     */   private Anchor2D labelAnchor;
/*     */   Color fillColor;
/*     */   
/*     */   public RangeMarker(double lowerBound, double upperBound) {
/*  71 */     this(lowerBound, upperBound, (String)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RangeMarker(double lowerBound, double upperBound, String label) {
/*  83 */     this.start = new NumberMarker(lowerBound);
/*  84 */     this.start.addChangeListener(this);
/*  85 */     this.end = new NumberMarker(upperBound);
/*  86 */     this.end.addChangeListener(this);
/*  87 */     this.label = label;
/*  88 */     this.font = DEFAULT_MARKER_FONT;
/*  89 */     this.labelColor = DEFAULT_LABEL_COLOR;
/*  90 */     this.labelAnchor = Anchor2D.CENTER;
/*  91 */     this.fillColor = DEFAULT_FILL_COLOR;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NumberMarker getStart() {
/* 100 */     return this.start;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NumberMarker getEnd() {
/* 109 */     return this.end;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Range getRange() {
/* 119 */     return new Range(this.start.getValue(), this.end.getValue());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getLabel() {
/* 129 */     return this.label;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLabel(String label) {
/* 140 */     this.label = label;
/* 141 */     fireChangeEvent();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Font getFont() {
/* 151 */     return this.font;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFont(Font font) {
/* 161 */     ArgChecks.nullNotPermitted(font, "font");
/* 162 */     this.font = font;
/* 163 */     fireChangeEvent();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Color getLabelColor() {
/* 173 */     return this.labelColor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLabelColor(Color color) {
/* 183 */     ArgChecks.nullNotPermitted(color, "color");
/* 184 */     this.labelColor = color;
/* 185 */     fireChangeEvent();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Anchor2D getLabelAnchor() {
/* 195 */     return this.labelAnchor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLabelAnchor(Anchor2D anchor) {
/* 205 */     ArgChecks.nullNotPermitted(anchor, "anchor");
/* 206 */     this.labelAnchor = anchor;
/* 207 */     fireChangeEvent();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Color getFillColor() {
/* 217 */     return this.fillColor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFillColor(Color color) {
/* 227 */     ArgChecks.nullNotPermitted(color, "color");
/* 228 */     this.fillColor = color;
/* 229 */     fireChangeEvent();
/*     */   }
/*     */ 
/*     */   
/*     */   public void draw(Graphics2D g2, MarkerData markerData, boolean reverse) {
/* 234 */     MarkerLine startLine = markerData.getStartLine();
/*     */     
/* 236 */     Line2D l1 = new Line2D.Double(startLine.getStartPoint(), startLine.getEndPoint());
/* 237 */     MarkerLine endLine = markerData.getEndLine();
/*     */     
/* 239 */     Line2D l2 = new Line2D.Double(endLine.getStartPoint(), endLine.getEndPoint());
/*     */     
/* 241 */     Path2D path = new Path2D.Double();
/* 242 */     path.moveTo(l1.getX1(), l1.getY1());
/* 243 */     path.lineTo(l1.getX2(), l1.getY2());
/* 244 */     path.lineTo(l2.getX2(), l2.getY2());
/* 245 */     path.lineTo(l2.getX1(), l2.getY1());
/* 246 */     path.closePath();
/* 247 */     g2.setPaint(this.fillColor);
/* 248 */     g2.fill(path);
/*     */     
/* 250 */     if (!startLine.isPegged()) {
/* 251 */       g2.setPaint(this.start.getLineColor());
/* 252 */       g2.setStroke(this.start.getLineStroke());
/* 253 */       g2.draw(l1);
/*     */     } 
/* 255 */     if (!endLine.isPegged()) {
/* 256 */       g2.setPaint(this.end.getLineColor());
/* 257 */       g2.setStroke(this.end.getLineStroke());
/* 258 */       g2.draw(l2);
/*     */     } 
/*     */     
/* 261 */     Point2D labelPoint = markerData.getLabelPoint();
/* 262 */     if (labelPoint != null) {
/* 263 */       g2.setFont(this.font);
/* 264 */       g2.setColor(this.labelColor);
/* 265 */       drawMarkerLabel(g2, this.label, labelPoint.getX(), labelPoint
/* 266 */           .getY(), markerData.getLabelAnchor(), l1, l2, reverse);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void markerChanged(MarkerChangeEvent event) {
/* 279 */     fireChangeEvent();
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 284 */     int hash = 7;
/* 285 */     hash = 97 * hash + ObjectUtils.hashCode(this.start);
/* 286 */     hash = 97 * hash + ObjectUtils.hashCode(this.end);
/* 287 */     hash = 97 * hash + ObjectUtils.hashCode(this.label);
/* 288 */     return hash;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 300 */     if (obj == null) {
/* 301 */       return false;
/*     */     }
/* 303 */     if (getClass() != obj.getClass()) {
/* 304 */       return false;
/*     */     }
/* 306 */     RangeMarker other = (RangeMarker)obj;
/* 307 */     if (!ObjectUtils.equals(this.start, other.start)) {
/* 308 */       return false;
/*     */     }
/* 310 */     if (!ObjectUtils.equals(this.end, other.end)) {
/* 311 */       return false;
/*     */     }
/* 313 */     if (!ObjectUtils.equals(this.label, other.label)) {
/* 314 */       return false;
/*     */     }
/* 316 */     if (!ObjectUtils.equals(this.font, other.font)) {
/* 317 */       return false;
/*     */     }
/* 319 */     if (!ObjectUtils.equals(this.labelColor, other.labelColor)) {
/* 320 */       return false;
/*     */     }
/* 322 */     if (!ObjectUtils.equals(this.labelAnchor, other.labelAnchor)) {
/* 323 */       return false;
/*     */     }
/* 325 */     if (!ObjectUtils.equals(this.fillColor, other.fillColor)) {
/* 326 */       return false;
/*     */     }
/* 328 */     return true;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/marker/RangeMarker.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */