/*     */ package com.orsoncharts.marker;
/*     */ 
/*     */ import com.orsoncharts.util.Anchor2D;
/*     */ import com.orsoncharts.util.ArgChecks;
/*     */ import com.orsoncharts.util.ObjectUtils;
/*     */ import com.orsoncharts.util.SerialUtils;
/*     */ import java.awt.Color;
/*     */ import java.awt.Font;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.Stroke;
/*     */ import java.awt.geom.Line2D;
/*     */ import java.awt.geom.Path2D;
/*     */ import java.awt.geom.Point2D;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.io.Serializable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CategoryMarker
/*     */   extends AbstractMarker
/*     */   implements Serializable
/*     */ {
/*     */   Comparable<?> category;
/*     */   CategoryMarkerType type;
/*     */   private String label;
/*     */   private Font font;
/*     */   private Color labelColor;
/*     */   private Anchor2D labelAnchor;
/*     */   private transient Stroke lineStroke;
/*     */   private Color lineColor;
/*     */   private Color fillColor;
/*     */   
/*     */   public CategoryMarker(Comparable<?> category) {
/*  86 */     ArgChecks.nullNotPermitted(category, "category");
/*  87 */     this.category = category;
/*  88 */     this.type = CategoryMarkerType.BAND;
/*  89 */     this.font = Marker.DEFAULT_MARKER_FONT;
/*  90 */     this.labelColor = Marker.DEFAULT_LABEL_COLOR;
/*  91 */     this.labelAnchor = Anchor2D.CENTER;
/*  92 */     this.lineStroke = DEFAULT_LINE_STROKE;
/*  93 */     this.lineColor = DEFAULT_LINE_COLOR;
/*  94 */     this.fillColor = DEFAULT_FILL_COLOR;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Comparable<?> getCategory() {
/* 103 */     return this.category;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCategory(Comparable<?> category) {
/* 113 */     ArgChecks.nullNotPermitted(category, "category");
/* 114 */     this.category = category;
/* 115 */     fireChangeEvent();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CategoryMarkerType getType() {
/* 125 */     return this.type;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setType(CategoryMarkerType type) {
/* 135 */     ArgChecks.nullNotPermitted(type, "type");
/* 136 */     this.type = type;
/* 137 */     fireChangeEvent();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getLabel() {
/* 147 */     return this.label;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLabel(String label) {
/* 156 */     this.label = label;
/* 157 */     fireChangeEvent();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Font getFont() {
/* 167 */     return this.font;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFont(Font font) {
/* 177 */     ArgChecks.nullNotPermitted(font, "font");
/* 178 */     this.font = font;
/* 179 */     fireChangeEvent();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Color getLabelColor() {
/* 189 */     return this.labelColor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLabelColor(Color color) {
/* 199 */     ArgChecks.nullNotPermitted(color, "color");
/* 200 */     this.labelColor = color;
/* 201 */     fireChangeEvent();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Anchor2D getLabelAnchor() {
/* 211 */     return this.labelAnchor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLabelAnchor(Anchor2D anchor) {
/* 221 */     ArgChecks.nullNotPermitted(anchor, "anchor");
/* 222 */     this.labelAnchor = anchor;
/* 223 */     fireChangeEvent();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Color getLineColor() {
/* 232 */     return this.lineColor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLineColor(Color color) {
/* 242 */     ArgChecks.nullNotPermitted(color, "color");
/* 243 */     this.lineColor = color;
/* 244 */     fireChangeEvent();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Stroke getLineStroke() {
/* 254 */     return this.lineStroke;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLineStroke(Stroke stroke) {
/* 264 */     ArgChecks.nullNotPermitted(stroke, "stroke");
/* 265 */     this.lineStroke = stroke;
/* 266 */     fireChangeEvent();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Color getFillColor() {
/* 275 */     return this.fillColor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFillColor(Color color) {
/* 285 */     ArgChecks.nullNotPermitted(color, "color");
/* 286 */     this.fillColor = color;
/* 287 */     fireChangeEvent();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void draw(Graphics2D g2, MarkerData markerData, boolean reverse) {
/* 300 */     if (markerData.getType().equals(MarkerDataType.VALUE)) {
/* 301 */       MarkerLine ml = markerData.getValueLine();
/* 302 */       g2.setPaint(this.lineColor);
/* 303 */       g2.setStroke(this.lineStroke);
/* 304 */       Line2D l = new Line2D.Double(ml.getStartPoint(), ml.getEndPoint());
/* 305 */       g2.draw(l);
/* 306 */       Point2D labelPoint = markerData.getLabelPoint();
/* 307 */       if (labelPoint != null) {
/* 308 */         g2.setFont(this.font);
/* 309 */         g2.setColor(this.labelColor);
/* 310 */         drawMarkerLabel(g2, this.label, labelPoint.getX(), labelPoint
/* 311 */             .getY(), this.labelAnchor, l, reverse);
/*     */       } 
/* 313 */     } else if (markerData.getType().equals(MarkerDataType.RANGE)) {
/* 314 */       MarkerLine sl = markerData.getStartLine();
/* 315 */       Line2D l1 = new Line2D.Double(sl.getStartPoint(), sl.getEndPoint());
/* 316 */       MarkerLine el = markerData.getEndLine();
/* 317 */       Line2D l2 = new Line2D.Double(el.getStartPoint(), el.getEndPoint());
/*     */       
/* 319 */       Path2D path = new Path2D.Double();
/* 320 */       path.moveTo(l1.getX1(), l1.getY1());
/* 321 */       path.lineTo(l1.getX2(), l1.getY2());
/* 322 */       path.lineTo(l2.getX2(), l2.getY2());
/* 323 */       path.lineTo(l2.getX1(), l2.getY1());
/* 324 */       path.closePath();
/* 325 */       g2.setPaint(this.fillColor);
/* 326 */       g2.fill(path);
/*     */       
/* 328 */       g2.setColor(this.lineColor);
/* 329 */       g2.setStroke(this.lineStroke);
/* 330 */       g2.draw(l1);
/* 331 */       g2.draw(l2);
/*     */       
/* 333 */       Point2D labelPoint = markerData.getLabelPoint();
/* 334 */       if (labelPoint != null) {
/* 335 */         g2.setFont(this.font);
/* 336 */         g2.setColor(this.labelColor);
/* 337 */         drawMarkerLabel(g2, this.label, labelPoint.getX(), labelPoint
/* 338 */             .getY(), markerData.getLabelAnchor(), l1, l2, reverse);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 346 */     int hash = 7;
/* 347 */     hash = 73 * hash + ObjectUtils.hashCode(this.category);
/* 348 */     return hash;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 353 */     if (obj == null) {
/* 354 */       return false;
/*     */     }
/* 356 */     if (getClass() != obj.getClass()) {
/* 357 */       return false;
/*     */     }
/* 359 */     CategoryMarker other = (CategoryMarker)obj;
/* 360 */     if (!ObjectUtils.equals(this.category, other.category)) {
/* 361 */       return false;
/*     */     }
/* 363 */     if (this.type != other.type) {
/* 364 */       return false;
/*     */     }
/* 366 */     if (!ObjectUtils.equals(this.label, other.label)) {
/* 367 */       return false;
/*     */     }
/* 369 */     if (!ObjectUtils.equals(this.font, other.font)) {
/* 370 */       return false;
/*     */     }
/* 372 */     if (!ObjectUtils.equals(this.labelColor, other.labelColor)) {
/* 373 */       return false;
/*     */     }
/* 375 */     if (!ObjectUtils.equals(this.labelAnchor, other.labelAnchor)) {
/* 376 */       return false;
/*     */     }
/* 378 */     if (!ObjectUtils.equals(this.lineStroke, other.lineStroke)) {
/* 379 */       return false;
/*     */     }
/* 381 */     if (!ObjectUtils.equals(this.lineColor, other.lineColor)) {
/* 382 */       return false;
/*     */     }
/* 384 */     if (!ObjectUtils.equals(this.fillColor, other.fillColor)) {
/* 385 */       return false;
/*     */     }
/* 387 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void writeObject(ObjectOutputStream stream) throws IOException {
/* 398 */     stream.defaultWriteObject();
/* 399 */     SerialUtils.writeStroke(this.lineStroke, stream);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void readObject(ObjectInputStream stream) throws IOException, ClassNotFoundException {
/* 412 */     stream.defaultReadObject();
/* 413 */     this.lineStroke = SerialUtils.readStroke(stream);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/marker/CategoryMarker.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */