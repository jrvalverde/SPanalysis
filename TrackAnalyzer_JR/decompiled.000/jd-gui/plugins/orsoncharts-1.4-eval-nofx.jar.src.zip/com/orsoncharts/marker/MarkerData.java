/*     */ package com.orsoncharts.marker;
/*     */ 
/*     */ import com.orsoncharts.util.Anchor2D;
/*     */ import com.orsoncharts.util.ArgChecks;
/*     */ import java.awt.geom.Point2D;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MarkerData
/*     */ {
/*     */   private String markerKey;
/*     */   private MarkerDataType type;
/*     */   private Map<String, Object> data;
/*     */   
/*     */   public MarkerData(String key, double pos) {
/*  54 */     ArgChecks.nullNotPermitted(key, "key");
/*  55 */     this.markerKey = key;
/*  56 */     this.type = MarkerDataType.VALUE;
/*  57 */     this.data = new HashMap<String, Object>();
/*  58 */     this.data.put("valueLine", new MarkerLine(pos, false));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MarkerData(String key, double startPos, boolean startPegged, double endPos, boolean endPegged) {
/*  73 */     ArgChecks.nullNotPermitted(key, "key");
/*  74 */     this.markerKey = key;
/*  75 */     this.type = MarkerDataType.RANGE;
/*  76 */     this.data = new HashMap<String, Object>();
/*  77 */     this.data.put("startLine", new MarkerLine(startPos, startPegged));
/*  78 */     this.data.put("endLine", new MarkerLine(endPos, endPegged));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MarkerData(MarkerData source, int v0, int v1) {
/*  90 */     ArgChecks.nullNotPermitted(source, "source");
/*  91 */     if (!source.getType().equals(MarkerDataType.VALUE)) {
/*  92 */       throw new IllegalArgumentException("Must be MarkerDataType.VALUE");
/*     */     }
/*  94 */     this.markerKey = source.markerKey;
/*  95 */     this.type = source.type;
/*  96 */     this.data = new HashMap<String, Object>(source.data);
/*  97 */     double pos = source.getValueLine().getPos();
/*  98 */     MarkerLine valueLine = new MarkerLine(pos, false, v0, v1);
/*  99 */     this.data.put("valueLine", valueLine);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MarkerData(MarkerData source, int v0, int v1, int v2, int v3) {
/* 113 */     ArgChecks.nullNotPermitted(source, "source");
/* 114 */     if (!source.getType().equals(MarkerDataType.RANGE)) {
/* 115 */       throw new IllegalArgumentException("Must be MarkerDataType.RANGE");
/*     */     }
/* 117 */     this.markerKey = source.markerKey;
/* 118 */     this.type = MarkerDataType.RANGE;
/* 119 */     this.data = new HashMap<String, Object>(source.data);
/* 120 */     double startPos = source.getStartLine().getPos();
/* 121 */     boolean startPegged = source.getStartLine().isPegged();
/* 122 */     MarkerLine startLine = new MarkerLine(startPos, startPegged, v0, v1);
/* 123 */     this.data.put("startLine", startLine);
/* 124 */     double endPos = source.getEndLine().getPos();
/* 125 */     boolean endPegged = source.getEndLine().isPegged();
/* 126 */     MarkerLine endLine = new MarkerLine(endPos, endPegged, v2, v3);
/* 127 */     this.data.put("endLine", endLine);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getMarkerKey() {
/* 137 */     return this.markerKey;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MarkerDataType getType() {
/* 146 */     return this.type;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MarkerLine getValueLine() {
/* 155 */     return (MarkerLine)this.data.get("valueLine");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MarkerLine getStartLine() {
/* 164 */     return (MarkerLine)this.data.get("startLine");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MarkerLine getEndLine() {
/* 173 */     return (MarkerLine)this.data.get("endLine");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Anchor2D getLabelAnchor() {
/* 182 */     return (Anchor2D)this.data.get("labelAnchor");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLabelAnchor(Anchor2D anchor) {
/* 191 */     this.data.put("labelAnchor", anchor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getLabelVertexIndex() {
/* 200 */     Integer i = (Integer)this.data.get("labelVertexIndex");
/* 201 */     return (i != null) ? i.intValue() : -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLabelVertexIndex(int labelVertexIndex) {
/* 210 */     this.data.put("labelVertexIndex", Integer.valueOf(labelVertexIndex));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Point2D getLabelPoint() {
/* 219 */     return (Point2D)this.data.get("labelPoint");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateProjection(Point2D[] pts) {
/* 229 */     if (this.type.equals(MarkerDataType.VALUE)) {
/* 230 */       MarkerLine line = getValueLine();
/* 231 */       line.setStartPoint(pts[line.getV0()]);
/* 232 */       line.setEndPoint(pts[line.getV1()]);
/* 233 */     } else if (this.type.equals(MarkerDataType.RANGE)) {
/* 234 */       MarkerLine startLine = getStartLine();
/* 235 */       startLine.setStartPoint(pts[startLine.getV0()]);
/* 236 */       startLine.setEndPoint(pts[startLine.getV1()]);
/* 237 */       MarkerLine endLine = getEndLine();
/* 238 */       endLine.setStartPoint(pts[endLine.getV0()]);
/* 239 */       endLine.setEndPoint(pts[endLine.getV1()]);
/*     */     } 
/* 241 */     int labelVertex = getLabelVertexIndex();
/* 242 */     if (labelVertex >= 0) {
/* 243 */       this.data.put("labelPoint", pts[labelVertex]);
/*     */     } else {
/* 245 */       this.data.put("labelPoint", null);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 251 */     StringBuilder sb = new StringBuilder();
/* 252 */     sb.append("MarkerData[key=");
/* 253 */     sb.append(this.markerKey);
/* 254 */     sb.append("]");
/* 255 */     return sb.toString();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/marker/MarkerData.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */