/*     */ package com.orsoncharts.marker;
/*     */ 
/*     */ import com.orsoncharts.Chart3DChangeListener;
/*     */ import com.orsoncharts.ChartElementVisitor;
/*     */ import com.orsoncharts.graphics3d.Utils2D;
/*     */ import com.orsoncharts.util.Anchor2D;
/*     */ import com.orsoncharts.util.ArgChecks;
/*     */ import com.orsoncharts.util.RefPt2D;
/*     */ import com.orsoncharts.util.TextAnchor;
/*     */ import com.orsoncharts.util.TextUtils;
/*     */ import java.awt.FontMetrics;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.geom.Line2D;
/*     */ import java.awt.geom.Rectangle2D;
/*     */ import javax.swing.event.EventListenerList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractMarker
/*     */   implements Marker
/*     */ {
/*  44 */   private transient EventListenerList listenerList = new EventListenerList();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void drawMarkerLabel(Graphics2D g2, String label, double x, double y, Anchor2D anchor, Line2D refLine, boolean reverse) {
/*  62 */     double angle = Utils2D.calculateTheta(refLine);
/*  63 */     boolean vflip = false;
/*  64 */     if (angle > 1.5707963267948966D) {
/*  65 */       angle -= Math.PI;
/*  66 */       vflip = true;
/*     */     } 
/*  68 */     if (angle < -1.5707963267948966D) {
/*  69 */       angle += Math.PI;
/*  70 */       vflip = true;
/*     */     } 
/*  72 */     if (reverse) {
/*  73 */       vflip = !vflip;
/*     */     }
/*  75 */     double lineLength = Utils2D.length(refLine);
/*  76 */     FontMetrics fm = g2.getFontMetrics();
/*  77 */     Rectangle2D bounds = fm.getStringBounds(label, g2);
/*  78 */     if (bounds.getWidth() < lineLength) {
/*  79 */       TextAnchor textAnchor = deriveTextAnchorForLine(anchor.getRefPt(), !vflip);
/*     */       
/*  81 */       TextUtils.drawRotatedString(label, g2, (float)x, (float)y, textAnchor, angle, textAnchor);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void drawMarkerLabel(Graphics2D g2, String label, double x, double y, Anchor2D anchor, Line2D refLine1, Line2D refLine2, boolean reverse) {
/*     */     double angle;
/* 104 */     if (anchor.getRefPt().isTop()) {
/* 105 */       angle = Utils2D.calculateTheta(refLine2);
/* 106 */     } else if (anchor.getRefPt().isBottom()) {
/* 107 */       angle = Utils2D.calculateTheta(refLine1);
/*     */     } else {
/*     */       
/* 110 */       angle = (Utils2D.calculateTheta(refLine1) + Utils2D.calculateTheta(refLine2)) / 2.0D;
/*     */     } 
/* 112 */     boolean vflip = false;
/* 113 */     if (angle > 1.5707963267948966D) {
/* 114 */       angle -= Math.PI;
/* 115 */       vflip = true;
/*     */     } 
/* 117 */     if (angle < -1.5707963267948966D) {
/* 118 */       angle += Math.PI;
/* 119 */       vflip = true;
/*     */     } 
/* 121 */     if (reverse) {
/* 122 */       vflip = !vflip;
/*     */     }
/* 124 */     double lineLength1 = Utils2D.length(refLine1);
/* 125 */     double lineLength2 = Utils2D.length(refLine2);
/* 126 */     Rectangle2D bounds = g2.getFontMetrics().getStringBounds(label, g2);
/* 127 */     if (bounds.getWidth() < Math.min(lineLength1, lineLength2)) {
/* 128 */       TextAnchor textAnchor = deriveTextAnchor(anchor.getRefPt(), !vflip);
/* 129 */       TextUtils.drawRotatedString(label, g2, (float)x, (float)y, textAnchor, angle, textAnchor);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void receive(ChartElementVisitor visitor) {
/* 143 */     visitor.visit(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addChangeListener(MarkerChangeListener listener) {
/* 153 */     this.listenerList.add(MarkerChangeListener.class, listener);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeChangeListener(MarkerChangeListener listener) {
/* 164 */     this.listenerList.remove(MarkerChangeListener.class, listener);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void fireChangeEvent() {
/* 171 */     Object[] listeners = this.listenerList.getListenerList();
/* 172 */     for (int i = listeners.length - 2; i >= 0; i -= 2) {
/* 173 */       if (listeners[i] == Chart3DChangeListener.class) {
/* 174 */         ((MarkerChangeListener)listeners[i + 1]).markerChanged(new MarkerChangeEvent(this, this));
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static TextAnchor deriveTextAnchor(RefPt2D refPt, boolean vflip) {
/* 190 */     ArgChecks.nullNotPermitted(refPt, "refPt");
/* 191 */     if (refPt.equals(RefPt2D.TOP_LEFT))
/* 192 */       return vflip ? TextAnchor.TOP_LEFT : TextAnchor.BOTTOM_RIGHT; 
/* 193 */     if (refPt.equals(RefPt2D.TOP_CENTER))
/* 194 */       return vflip ? TextAnchor.TOP_CENTER : TextAnchor.BOTTOM_CENTER; 
/* 195 */     if (refPt.equals(RefPt2D.TOP_RIGHT))
/* 196 */       return vflip ? TextAnchor.TOP_RIGHT : TextAnchor.BOTTOM_LEFT; 
/* 197 */     if (refPt.equals(RefPt2D.CENTER_LEFT))
/* 198 */       return vflip ? TextAnchor.CENTER_LEFT : TextAnchor.CENTER_RIGHT; 
/* 199 */     if (refPt.equals(RefPt2D.CENTER))
/* 200 */       return TextAnchor.CENTER; 
/* 201 */     if (refPt.equals(RefPt2D.CENTER_RIGHT))
/* 202 */       return vflip ? TextAnchor.CENTER_RIGHT : TextAnchor.CENTER_LEFT; 
/* 203 */     if (refPt.equals(RefPt2D.BOTTOM_LEFT))
/* 204 */       return vflip ? TextAnchor.BOTTOM_LEFT : TextAnchor.TOP_RIGHT; 
/* 205 */     if (refPt.equals(RefPt2D.BOTTOM_CENTER))
/* 206 */       return vflip ? TextAnchor.BOTTOM_CENTER : TextAnchor.TOP_CENTER; 
/* 207 */     if (refPt.equals(RefPt2D.BOTTOM_RIGHT)) {
/* 208 */       return vflip ? TextAnchor.BOTTOM_RIGHT : TextAnchor.TOP_LEFT;
/*     */     }
/* 210 */     throw new RuntimeException("Unknown refPt " + refPt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static TextAnchor deriveTextAnchorForLine(RefPt2D refPt, boolean vflip) {
/* 225 */     if (refPt.equals(RefPt2D.TOP_LEFT))
/* 226 */       return vflip ? TextAnchor.BOTTOM_LEFT : TextAnchor.TOP_RIGHT; 
/* 227 */     if (refPt.equals(RefPt2D.TOP_CENTER))
/* 228 */       return vflip ? TextAnchor.BOTTOM_CENTER : TextAnchor.TOP_CENTER; 
/* 229 */     if (refPt.equals(RefPt2D.TOP_RIGHT))
/* 230 */       return vflip ? TextAnchor.BOTTOM_RIGHT : TextAnchor.TOP_LEFT; 
/* 231 */     if (refPt.equals(RefPt2D.CENTER_LEFT))
/* 232 */       return vflip ? TextAnchor.CENTER_LEFT : TextAnchor.CENTER_RIGHT; 
/* 233 */     if (refPt.equals(RefPt2D.CENTER))
/* 234 */       return TextAnchor.CENTER; 
/* 235 */     if (refPt.equals(RefPt2D.CENTER_RIGHT))
/* 236 */       return vflip ? TextAnchor.CENTER_RIGHT : TextAnchor.CENTER_LEFT; 
/* 237 */     if (refPt.equals(RefPt2D.BOTTOM_LEFT))
/* 238 */       return vflip ? TextAnchor.TOP_LEFT : TextAnchor.BOTTOM_RIGHT; 
/* 239 */     if (refPt.equals(RefPt2D.BOTTOM_CENTER))
/* 240 */       return vflip ? TextAnchor.TOP_CENTER : TextAnchor.BOTTOM_CENTER; 
/* 241 */     if (refPt.equals(RefPt2D.BOTTOM_RIGHT)) {
/* 242 */       return vflip ? TextAnchor.TOP_RIGHT : TextAnchor.BOTTOM_LEFT;
/*     */     }
/* 244 */     throw new RuntimeException("Unknown refPt " + refPt);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/marker/AbstractMarker.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */