/*    */ package com.orsoncharts.marker;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum CategoryMarkerType
/*    */ {
/* 23 */   LINE,
/*    */ 
/*    */   
/* 26 */   BAND;
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/marker/CategoryMarkerType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */