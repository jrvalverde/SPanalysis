/*    */ package com.orsoncharts.marker;
/*    */ 
/*    */ import com.orsoncharts.ChartElement;
/*    */ import java.awt.BasicStroke;
/*    */ import java.awt.Color;
/*    */ import java.awt.Font;
/*    */ import java.awt.Graphics2D;
/*    */ import java.awt.Stroke;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface Marker
/*    */   extends ChartElement
/*    */ {
/* 30 */   public static final Stroke DEFAULT_LINE_STROKE = new BasicStroke(0.0F, 1, 1);
/*    */ 
/*    */ 
/*    */   
/* 34 */   public static final Color DEFAULT_LINE_COLOR = Color.DARK_GRAY;
/*    */ 
/*    */   
/* 37 */   public static final Color DEFAULT_FILL_COLOR = new Color(128, 128, 192, 64);
/*    */ 
/*    */   
/* 40 */   public static final Font DEFAULT_MARKER_FONT = new Font("Dialog", 0, 10);
/*    */ 
/*    */ 
/*    */   
/* 44 */   public static final Color DEFAULT_LABEL_COLOR = Color.BLACK;
/*    */   
/*    */   void draw(Graphics2D paramGraphics2D, MarkerData paramMarkerData, boolean paramBoolean);
/*    */   
/*    */   void addChangeListener(MarkerChangeListener paramMarkerChangeListener);
/*    */   
/*    */   void removeChangeListener(MarkerChangeListener paramMarkerChangeListener);
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/marker/Marker.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */