/*     */ package com.orsoncharts.marker;
/*     */ 
/*     */ import com.orsoncharts.Range;
/*     */ import com.orsoncharts.util.Anchor2D;
/*     */ import com.orsoncharts.util.ArgChecks;
/*     */ import com.orsoncharts.util.ObjectUtils;
/*     */ import com.orsoncharts.util.SerialUtils;
/*     */ import java.awt.Color;
/*     */ import java.awt.Font;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.Stroke;
/*     */ import java.awt.geom.Line2D;
/*     */ import java.awt.geom.Point2D;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.io.Serializable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NumberMarker
/*     */   extends AbstractMarker
/*     */   implements ValueMarker, Serializable
/*     */ {
/*     */   private double value;
/*     */   private String label;
/*     */   private Font font;
/*     */   private Color labelColor;
/*     */   private Anchor2D labelAnchor;
/*     */   private transient Stroke stroke;
/*     */   private Color lineColor;
/*     */   
/*     */   public NumberMarker(double value) {
/*  73 */     this.value = value;
/*  74 */     this.label = null;
/*  75 */     this.font = DEFAULT_MARKER_FONT;
/*  76 */     this.labelColor = DEFAULT_LABEL_COLOR;
/*  77 */     this.stroke = DEFAULT_LINE_STROKE;
/*  78 */     this.lineColor = DEFAULT_LINE_COLOR;
/*  79 */     this.labelAnchor = Anchor2D.CENTER;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getValue() {
/*  89 */     return this.value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setValue(double value) {
/*  99 */     this.value = value;
/* 100 */     fireChangeEvent();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Range getRange() {
/* 112 */     return new Range(this.value, this.value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getLabel() {
/* 122 */     return this.label;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLabel(String label) {
/* 131 */     this.label = label;
/* 132 */     fireChangeEvent();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Font getFont() {
/* 142 */     return this.font;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFont(Font font) {
/* 152 */     ArgChecks.nullNotPermitted(font, "font");
/* 153 */     this.font = font;
/* 154 */     fireChangeEvent();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Color getLabelColor() {
/* 164 */     return this.labelColor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLabelColor(Color color) {
/* 174 */     ArgChecks.nullNotPermitted(color, "color");
/* 175 */     this.labelColor = color;
/* 176 */     fireChangeEvent();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Anchor2D getLabelAnchor() {
/* 186 */     return this.labelAnchor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLabelAnchor(Anchor2D anchor) {
/* 196 */     ArgChecks.nullNotPermitted(anchor, "anchor");
/* 197 */     this.labelAnchor = anchor;
/* 198 */     fireChangeEvent();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Stroke getLineStroke() {
/* 208 */     return this.stroke;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLineStroke(Stroke stroke) {
/* 218 */     ArgChecks.nullNotPermitted(stroke, "stroke");
/* 219 */     this.stroke = stroke;
/* 220 */     fireChangeEvent();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Color getLineColor() {
/* 230 */     return this.lineColor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLineColor(Color color) {
/* 240 */     ArgChecks.nullNotPermitted(color, "color");
/* 241 */     this.lineColor = color;
/* 242 */     fireChangeEvent();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void draw(Graphics2D g2, MarkerData markerData, boolean reverse) {
/* 255 */     MarkerLine line = markerData.getValueLine();
/* 256 */     g2.setPaint(this.lineColor);
/* 257 */     g2.setStroke(this.stroke);
/* 258 */     Line2D l = new Line2D.Double(line.getStartPoint(), line.getEndPoint());
/* 259 */     g2.draw(l);
/* 260 */     Point2D labelPoint = markerData.getLabelPoint();
/* 261 */     if (labelPoint != null) {
/* 262 */       g2.setFont(this.font);
/* 263 */       g2.setColor(this.labelColor);
/* 264 */       drawMarkerLabel(g2, this.label, labelPoint.getX(), labelPoint
/* 265 */           .getY(), this.labelAnchor, l, reverse);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 271 */     int hash = 7;
/*     */     
/* 273 */     hash = 19 * hash + (int)(Double.doubleToLongBits(this.value) ^ Double.doubleToLongBits(this.value) >>> 32L);
/* 274 */     hash = 19 * hash + ObjectUtils.hashCode(this.label);
/* 275 */     return hash;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 280 */     if (obj == null) {
/* 281 */       return false;
/*     */     }
/* 283 */     if (getClass() != obj.getClass()) {
/* 284 */       return false;
/*     */     }
/* 286 */     NumberMarker other = (NumberMarker)obj;
/* 287 */     if (Double.doubleToLongBits(this.value) != 
/* 288 */       Double.doubleToLongBits(other.value)) {
/* 289 */       return false;
/*     */     }
/* 291 */     if (!ObjectUtils.equals(this.label, other.label)) {
/* 292 */       return false;
/*     */     }
/* 294 */     if (!ObjectUtils.equals(this.font, other.font)) {
/* 295 */       return false;
/*     */     }
/* 297 */     if (!ObjectUtils.equals(this.labelColor, other.labelColor)) {
/* 298 */       return false;
/*     */     }
/* 300 */     if (!ObjectUtils.equals(this.labelAnchor, other.labelAnchor)) {
/* 301 */       return false;
/*     */     }
/* 303 */     if (!ObjectUtils.equals(this.stroke, other.stroke)) {
/* 304 */       return false;
/*     */     }
/* 306 */     if (!ObjectUtils.equals(this.lineColor, other.lineColor)) {
/* 307 */       return false;
/*     */     }
/* 309 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void writeObject(ObjectOutputStream stream) throws IOException {
/* 320 */     stream.defaultWriteObject();
/* 321 */     SerialUtils.writeStroke(this.stroke, stream);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void readObject(ObjectInputStream stream) throws IOException, ClassNotFoundException {
/* 334 */     stream.defaultReadObject();
/* 335 */     this.stroke = SerialUtils.readStroke(stream);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/marker/NumberMarker.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */