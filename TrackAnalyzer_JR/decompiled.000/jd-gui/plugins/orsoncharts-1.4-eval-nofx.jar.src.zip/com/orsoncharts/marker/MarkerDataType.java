/*    */ package com.orsoncharts.marker;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum MarkerDataType
/*    */ {
/* 23 */   VALUE,
/*    */ 
/*    */   
/* 26 */   RANGE;
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/marker/MarkerDataType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */