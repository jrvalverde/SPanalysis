/*    */ package com.orsoncharts.marker;
/*    */ 
/*    */ import com.orsoncharts.util.ArgChecks;
/*    */ import java.util.EventObject;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MarkerChangeEvent
/*    */   extends EventObject
/*    */ {
/*    */   private Marker marker;
/*    */   
/*    */   public MarkerChangeEvent(Marker marker) {
/* 43 */     this(marker, marker);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public MarkerChangeEvent(Object source, Marker marker) {
/* 53 */     super(source);
/* 54 */     ArgChecks.nullNotPermitted(marker, "marker");
/* 55 */     this.marker = marker;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Marker getMarker() {
/* 64 */     return this.marker;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/marker/MarkerChangeEvent.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */