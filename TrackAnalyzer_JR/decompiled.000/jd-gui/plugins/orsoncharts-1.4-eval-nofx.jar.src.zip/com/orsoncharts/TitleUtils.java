/*     */ package com.orsoncharts;
/*     */ 
/*     */ import com.orsoncharts.interaction.InteractiveElementType;
/*     */ import com.orsoncharts.table.GridElement;
/*     */ import com.orsoncharts.table.HAlign;
/*     */ import com.orsoncharts.table.TableElement;
/*     */ import com.orsoncharts.table.TextElement;
/*     */ import com.orsoncharts.util.Anchor2D;
/*     */ import java.awt.Color;
/*     */ import java.awt.Font;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TitleUtils
/*     */ {
/*  30 */   public static final Font DEFAULT_TITLE_FONT = new Font("Dialog", 1, 20);
/*     */ 
/*     */ 
/*     */   
/*  34 */   public static final Color DEFAULT_TITLE_COLOR = Color.BLACK;
/*     */ 
/*     */   
/*  37 */   public static final Font DEFAULT_SUBTITLE_FONT = new Font("Dialog", 0, 12);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static TableElement createTitle(String title) {
/*  52 */     return createTitle(title, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static TableElement createTitle(String title, String subtitle) {
/*  65 */     return createTitle(title, subtitle, TitleAnchor.TOP_LEFT);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static TableElement createTitle(String title, String subtitle, Anchor2D anchor) {
/*  83 */     HAlign alignment = HAlign.LEFT;
/*  84 */     if (anchor.getRefPt().isHorizontalCenter()) {
/*  85 */       alignment = HAlign.CENTER;
/*  86 */     } else if (anchor.getRefPt().isRight()) {
/*  87 */       alignment = HAlign.RIGHT;
/*     */     } 
/*  89 */     return createTitle(title, DEFAULT_TITLE_FONT, subtitle, DEFAULT_SUBTITLE_FONT, alignment);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static TableElement createTitle(String title, Font titleFont, String subtitle, Font subtitleFont, HAlign alignment) {
/* 109 */     TextElement t = new TextElement(title, titleFont);
/* 110 */     t.setHorizontalAligment(alignment);
/* 111 */     t.setColor(DEFAULT_TITLE_COLOR);
/* 112 */     t.setTag("CHART_TITLE");
/* 113 */     t.setProperty("class", InteractiveElementType.TITLE);
/* 114 */     if (subtitle == null) {
/* 115 */       return (TableElement)t;
/*     */     }
/* 117 */     if (subtitleFont == null) {
/* 118 */       throw new IllegalArgumentException("A subtitleFont is required when there is a subtitle.");
/*     */     }
/*     */     
/* 121 */     GridElement compositeTitle = new GridElement();
/* 122 */     TextElement st = new TextElement(subtitle, subtitleFont);
/* 123 */     st.setHorizontalAligment(alignment);
/* 124 */     st.setColor(DEFAULT_TITLE_COLOR);
/* 125 */     st.setTag("CHART_SUBTITLE");
/* 126 */     st.setProperty("class", InteractiveElementType.SUBTITLE);
/* 127 */     compositeTitle.setElement((TableElement)t, "R1", "C1");
/* 128 */     compositeTitle.setElement((TableElement)st, "R2", "C1");
/* 129 */     return (TableElement)compositeTitle;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/TitleUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */