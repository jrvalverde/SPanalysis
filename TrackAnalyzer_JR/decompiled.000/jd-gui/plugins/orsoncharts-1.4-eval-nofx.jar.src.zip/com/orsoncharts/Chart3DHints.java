/*    */ package com.orsoncharts;
/*    */ 
/*    */ import java.awt.RenderingHints;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class Chart3DHints
/*    */ {
/* 37 */   public static final Key KEY_BEGIN_ELEMENT = new Key(0);
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 42 */   public static final Key KEY_END_ELEMENT = new Key(1);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static class Key
/*    */     extends RenderingHints.Key
/*    */   {
/*    */     public Key(int privateKey) {
/* 56 */       super(privateKey);
/*    */     }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/*    */     public boolean isCompatibleValue(Object val) {
/* 69 */       switch (intKey()) {
/*    */         case 0:
/* 71 */           return (val == null || val instanceof String || val instanceof java.util.Map);
/*    */         
/*    */         case 1:
/* 74 */           return (val == null || val instanceof Object);
/*    */       } 
/* 76 */       throw new RuntimeException("Not possible!");
/*    */     }
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/Chart3DHints.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */