/*     */ package com.orsoncharts;
/*     */ 
/*     */ import com.orsoncharts.axis.CategoryAxis3D;
/*     */ import com.orsoncharts.axis.LabelOrientation;
/*     */ import com.orsoncharts.axis.NumberAxis3D;
/*     */ import com.orsoncharts.axis.StandardCategoryAxis3D;
/*     */ import com.orsoncharts.axis.ValueAxis3D;
/*     */ import com.orsoncharts.data.PieDataset3D;
/*     */ import com.orsoncharts.data.category.CategoryDataset3D;
/*     */ import com.orsoncharts.data.function.Function3D;
/*     */ import com.orsoncharts.data.xyz.XYZDataset;
/*     */ import com.orsoncharts.data.xyz.XYZSeriesCollection;
/*     */ import com.orsoncharts.legend.ColorScaleLegendBuilder;
/*     */ import com.orsoncharts.legend.LegendBuilder;
/*     */ import com.orsoncharts.plot.CategoryPlot3D;
/*     */ import com.orsoncharts.plot.PiePlot3D;
/*     */ import com.orsoncharts.plot.Plot3D;
/*     */ import com.orsoncharts.plot.XYZPlot;
/*     */ import com.orsoncharts.renderer.category.AreaRenderer3D;
/*     */ import com.orsoncharts.renderer.category.BarRenderer3D;
/*     */ import com.orsoncharts.renderer.category.CategoryRenderer3D;
/*     */ import com.orsoncharts.renderer.category.LineRenderer3D;
/*     */ import com.orsoncharts.renderer.category.StackedBarRenderer3D;
/*     */ import com.orsoncharts.renderer.xyz.BarXYZRenderer;
/*     */ import com.orsoncharts.renderer.xyz.ScatterXYZRenderer;
/*     */ import com.orsoncharts.renderer.xyz.SurfaceRenderer;
/*     */ import com.orsoncharts.renderer.xyz.XYZRenderer;
/*     */ import com.orsoncharts.style.ChartStyle;
/*     */ import com.orsoncharts.style.StandardChartStyle;
/*     */ import com.orsoncharts.util.ArgChecks;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Chart3DFactory
/*     */ {
/*  57 */   static ChartStyle defaultStyle = (ChartStyle)new StandardChartStyle();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ChartStyle getDefaultChartStyle() {
/*  68 */     return defaultStyle.clone();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setDefaultChartStyle(ChartStyle style) {
/*  79 */     ArgChecks.nullNotPermitted(style, "style");
/*  80 */     defaultStyle = style.clone();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Chart3D createPieChart(String title, String subtitle, PieDataset3D dataset) {
/* 104 */     PiePlot3D plot = new PiePlot3D(dataset);
/* 105 */     return new Chart3D(title, subtitle, (Plot3D)plot);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Chart3D createBarChart(String title, String subtitle, CategoryDataset3D dataset, String rowAxisLabel, String columnAxisLabel, String valueAxisLabel) {
/* 136 */     StandardCategoryAxis3D rowAxis = new StandardCategoryAxis3D(rowAxisLabel);
/*     */     
/* 138 */     rowAxis.setTickLabelOrientation(LabelOrientation.PERPENDICULAR);
/* 139 */     StandardCategoryAxis3D standardCategoryAxis3D1 = new StandardCategoryAxis3D(columnAxisLabel);
/* 140 */     NumberAxis3D valueAxis = new NumberAxis3D(valueAxisLabel, new Range(0.0D, 1.0D));
/*     */     
/* 142 */     valueAxis.setTickLabelOrientation(LabelOrientation.PERPENDICULAR);
/* 143 */     BarRenderer3D barRenderer3D = new BarRenderer3D();
/* 144 */     CategoryPlot3D plot = new CategoryPlot3D(dataset, (CategoryRenderer3D)barRenderer3D, (CategoryAxis3D)rowAxis, (CategoryAxis3D)standardCategoryAxis3D1, (ValueAxis3D)valueAxis);
/*     */     
/* 146 */     return new Chart3D(title, subtitle, (Plot3D)plot);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Chart3D createStackedBarChart(String title, String subtitle, CategoryDataset3D dataset, String rowAxisLabel, String columnAxisLabel, String valueAxisLabel) {
/* 177 */     StandardCategoryAxis3D rowAxis = new StandardCategoryAxis3D(rowAxisLabel);
/*     */     
/* 179 */     rowAxis.setTickLabelOrientation(LabelOrientation.PERPENDICULAR);
/* 180 */     StandardCategoryAxis3D standardCategoryAxis3D1 = new StandardCategoryAxis3D(columnAxisLabel);
/* 181 */     NumberAxis3D valueAxis = new NumberAxis3D(valueAxisLabel, new Range(0.0D, 1.0D));
/*     */     
/* 183 */     valueAxis.setTickLabelOrientation(LabelOrientation.PERPENDICULAR);
/* 184 */     StackedBarRenderer3D stackedBarRenderer3D = new StackedBarRenderer3D();
/* 185 */     CategoryPlot3D plot = new CategoryPlot3D(dataset, (CategoryRenderer3D)stackedBarRenderer3D, (CategoryAxis3D)rowAxis, (CategoryAxis3D)standardCategoryAxis3D1, (ValueAxis3D)valueAxis);
/*     */     
/* 187 */     return new Chart3D(title, subtitle, (Plot3D)plot);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Chart3D createAreaChart(String title, String subtitle, CategoryDataset3D dataset, String rowAxisLabel, String columnAxisLabel, String valueAxisLabel) {
/* 218 */     StandardCategoryAxis3D rowAxis = new StandardCategoryAxis3D(rowAxisLabel);
/*     */     
/* 220 */     rowAxis.setTickLabelOrientation(LabelOrientation.PERPENDICULAR);
/* 221 */     StandardCategoryAxis3D columnAxis = new StandardCategoryAxis3D(columnAxisLabel);
/*     */     
/* 223 */     columnAxis.setFirstCategoryHalfWidth(true);
/* 224 */     columnAxis.setLastCategoryHalfWidth(true);
/* 225 */     NumberAxis3D valueAxis = new NumberAxis3D(valueAxisLabel, new Range(0.0D, 1.0D));
/*     */     
/* 227 */     valueAxis.setTickLabelOrientation(LabelOrientation.PERPENDICULAR);
/* 228 */     AreaRenderer3D areaRenderer3D = new AreaRenderer3D();
/* 229 */     CategoryPlot3D plot = new CategoryPlot3D(dataset, (CategoryRenderer3D)areaRenderer3D, (CategoryAxis3D)rowAxis, (CategoryAxis3D)columnAxis, (ValueAxis3D)valueAxis);
/*     */     
/* 231 */     return new Chart3D(title, subtitle, (Plot3D)plot);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Chart3D createLineChart(String title, String subtitle, CategoryDataset3D dataset, String rowAxisLabel, String columnAxisLabel, String valueAxisLabel) {
/* 262 */     StandardCategoryAxis3D rowAxis = new StandardCategoryAxis3D(rowAxisLabel);
/*     */     
/* 264 */     rowAxis.setTickLabelOrientation(LabelOrientation.PERPENDICULAR);
/* 265 */     StandardCategoryAxis3D columnAxis = new StandardCategoryAxis3D(columnAxisLabel);
/*     */     
/* 267 */     columnAxis.setFirstCategoryHalfWidth(true);
/* 268 */     columnAxis.setLastCategoryHalfWidth(true);
/* 269 */     NumberAxis3D valueAxis = new NumberAxis3D(valueAxisLabel, new Range(0.0D, 1.0D));
/*     */     
/* 271 */     valueAxis.setTickLabelOrientation(LabelOrientation.PERPENDICULAR);
/* 272 */     LineRenderer3D lineRenderer3D = new LineRenderer3D();
/* 273 */     CategoryPlot3D plot = new CategoryPlot3D(dataset, (CategoryRenderer3D)lineRenderer3D, (CategoryAxis3D)rowAxis, (CategoryAxis3D)columnAxis, (ValueAxis3D)valueAxis);
/*     */     
/* 275 */     return new Chart3D(title, subtitle, (Plot3D)plot);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Chart3D createScatterChart(String title, String subtitle, XYZDataset dataset, String xAxisLabel, String yAxisLabel, String zAxisLabel) {
/* 305 */     NumberAxis3D xAxis = new NumberAxis3D(xAxisLabel);
/* 306 */     NumberAxis3D yAxis = new NumberAxis3D(yAxisLabel);
/* 307 */     yAxis.setTickLabelOrientation(LabelOrientation.PERPENDICULAR);
/* 308 */     NumberAxis3D zAxis = new NumberAxis3D(zAxisLabel);
/* 309 */     ScatterXYZRenderer scatterXYZRenderer = new ScatterXYZRenderer();
/* 310 */     XYZPlot plot = new XYZPlot(dataset, (XYZRenderer)scatterXYZRenderer, (ValueAxis3D)xAxis, (ValueAxis3D)yAxis, (ValueAxis3D)zAxis);
/* 311 */     return new Chart3D(title, subtitle, (Plot3D)plot);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Chart3D createSurfaceChart(String title, String subtitle, Function3D function, String xAxisLabel, String yAxisLabel, String zAxisLabel) {
/* 338 */     NumberAxis3D xAxis = new NumberAxis3D(xAxisLabel);
/* 339 */     NumberAxis3D yAxis = new NumberAxis3D(yAxisLabel);
/* 340 */     yAxis.setTickLabelOrientation(LabelOrientation.PERPENDICULAR);
/* 341 */     NumberAxis3D zAxis = new NumberAxis3D(zAxisLabel);
/* 342 */     SurfaceRenderer surfaceRenderer = new SurfaceRenderer(function);
/*     */ 
/*     */     
/* 345 */     XYZPlot plot = new XYZPlot((XYZDataset)new XYZSeriesCollection(), (XYZRenderer)surfaceRenderer, (ValueAxis3D)xAxis, (ValueAxis3D)yAxis, (ValueAxis3D)zAxis);
/*     */ 
/*     */     
/* 348 */     Chart3D chart = new Chart3D(title, subtitle, (Plot3D)plot);
/* 349 */     chart.setLegendBuilder((LegendBuilder)new ColorScaleLegendBuilder());
/* 350 */     return chart;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Chart3D createXYZBarChart(String title, String subtitle, XYZDataset dataset, String xAxisLabel, String yAxisLabel, String zAxisLabel) {
/* 381 */     NumberAxis3D numberAxis3D1 = new NumberAxis3D(xAxisLabel);
/* 382 */     NumberAxis3D yAxis = new NumberAxis3D(yAxisLabel);
/* 383 */     yAxis.setTickLabelOrientation(LabelOrientation.PERPENDICULAR);
/* 384 */     NumberAxis3D numberAxis3D2 = new NumberAxis3D(zAxisLabel);
/* 385 */     BarXYZRenderer barXYZRenderer = new BarXYZRenderer();
/* 386 */     XYZPlot plot = new XYZPlot(dataset, (XYZRenderer)barXYZRenderer, (ValueAxis3D)numberAxis3D1, (ValueAxis3D)yAxis, (ValueAxis3D)numberAxis3D2);
/* 387 */     return new Chart3D(title, subtitle, (Plot3D)plot);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/Chart3DFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */