/*     */ package com.orsoncharts;
/*     */ 
/*     */ import com.orsoncharts.util.ArgChecks;
/*     */ import java.io.Serializable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Range
/*     */   implements Serializable
/*     */ {
/*     */   private double min;
/*     */   private double max;
/*     */   
/*     */   public Range(double min, double max) {
/*  42 */     if (min > max) {
/*  43 */       throw new IllegalArgumentException("Requires min <= max.");
/*     */     }
/*  45 */     this.min = min;
/*  46 */     this.max = max;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getMin() {
/*  55 */     return this.min;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getMax() {
/*  64 */     return this.max;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getLength() {
/*  73 */     return this.max - this.min;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean contains(double value) {
/*  85 */     return (value >= this.min && value <= this.max);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double peggedValue(double value) {
/*  97 */     return Math.max(this.min, Math.min(this.max, value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean intersects(double bound1, double bound2) {
/* 111 */     double lowerBound = Math.min(bound1, bound2);
/* 112 */     double upperBound = Math.max(bound1, bound2);
/* 113 */     if (upperBound < this.min) {
/* 114 */       return false;
/*     */     }
/* 116 */     if (lowerBound > this.max) {
/* 117 */       return false;
/*     */     }
/* 119 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean intersects(Range range) {
/* 133 */     ArgChecks.nullNotPermitted(range, "range");
/* 134 */     return intersects(range.getMin(), range.getMax());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double percent(double value) {
/* 145 */     return (value - this.min) / getLength();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double value(double percent) {
/* 158 */     return this.min + percent * (this.max - this.min);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 170 */     if (obj == this) {
/* 171 */       return true;
/*     */     }
/* 173 */     if (!(obj instanceof Range)) {
/* 174 */       return false;
/*     */     }
/* 176 */     Range that = (Range)obj;
/* 177 */     if (this.min != that.min) {
/* 178 */       return false;
/*     */     }
/* 180 */     if (this.max != that.max) {
/* 181 */       return false;
/*     */     }
/* 183 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 193 */     int hash = 7;
/*     */     
/* 195 */     hash = 43 * hash + (int)(Double.doubleToLongBits(this.min) ^ Double.doubleToLongBits(this.min) >>> 32L);
/*     */     
/* 197 */     hash = 43 * hash + (int)(Double.doubleToLongBits(this.max) ^ Double.doubleToLongBits(this.max) >>> 32L);
/* 198 */     return hash;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 209 */     return "Range[" + this.min + ", " + this.max + "]";
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/Range.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */