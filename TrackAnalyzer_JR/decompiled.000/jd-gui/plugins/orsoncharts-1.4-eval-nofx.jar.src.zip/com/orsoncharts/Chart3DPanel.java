/*     */ package com.orsoncharts;
/*     */ 
/*     */ import com.orsoncharts.data.ItemKey;
/*     */ import com.orsoncharts.graphics3d.Object3D;
/*     */ import com.orsoncharts.graphics3d.RenderedElement;
/*     */ import com.orsoncharts.graphics3d.RenderingInfo;
/*     */ import com.orsoncharts.graphics3d.swing.Panel3D;
/*     */ import com.orsoncharts.interaction.Chart3DMouseEvent;
/*     */ import com.orsoncharts.interaction.Chart3DMouseListener;
/*     */ import com.orsoncharts.util.ArgChecks;
/*     */ import java.awt.event.ComponentEvent;
/*     */ import java.awt.event.ComponentListener;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.util.EventListener;
/*     */ import javax.swing.event.EventListenerList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Chart3DPanel
/*     */   extends Panel3D
/*     */   implements Chart3DChangeListener, ComponentListener
/*     */ {
/*     */   private Chart3D chart;
/*     */   private boolean autoFitOnPanelResize;
/*     */   private transient EventListenerList chartMouseListeners;
/*     */   
/*     */   public Chart3DPanel(Chart3D chart) {
/*  67 */     super(chart);
/*  68 */     this.chartMouseListeners = new EventListenerList();
/*  69 */     this.chart = chart;
/*  70 */     this.chart.addChangeListener(this);
/*  71 */     addComponentListener(this);
/*  72 */     this.autoFitOnPanelResize = false;
/*  73 */     registerForTooltips();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Chart3D getChart() {
/*  84 */     return this.chart;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void chartChanged(Chart3DChangeEvent event) {
/*  95 */     repaint();
/*     */   }
/*     */ 
/*     */   
/*     */   public void componentResized(ComponentEvent e) {
/* 100 */     if (this.autoFitOnPanelResize) {
/* 101 */       zoomToFit();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void componentMoved(ComponentEvent e) {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void componentShown(ComponentEvent e) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void componentHidden(ComponentEvent e) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public String getToolTipText(MouseEvent e) {
/* 122 */     RenderingInfo info = getRenderingInfo();
/* 123 */     if (info == null) {
/* 124 */       return null;
/*     */     }
/* 126 */     Object3D object = info.fetchObjectAt(e.getX(), e.getY());
/* 127 */     if (object != null) {
/* 128 */       ItemKey key = (ItemKey)object.getProperty("key");
/* 129 */       if (key != null) {
/* 130 */         return this.chart.getPlot().generateToolTipText(key);
/*     */       }
/*     */     } 
/* 133 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void mouseClicked(MouseEvent e) {
/* 145 */     Object[] listeners = this.chartMouseListeners.getListeners(Chart3DMouseListener.class);
/*     */     
/* 147 */     if (listeners.length == 0) {
/*     */       return;
/*     */     }
/* 150 */     RenderedElement element = null;
/* 151 */     RenderingInfo info = getRenderingInfo();
/* 152 */     if (info != null) {
/* 153 */       element = info.findElementAt(e.getX(), e.getY());
/*     */     }
/* 155 */     Chart3DMouseEvent chartEvent = new Chart3DMouseEvent(this.chart, e, element);
/*     */     
/* 157 */     for (int i = listeners.length - 1; i >= 0; i--) {
/* 158 */       ((Chart3DMouseListener)listeners[i]).chartMouseClicked(chartEvent);
/*     */     }
/* 160 */     super.mouseClicked(e);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void mouseMoved(MouseEvent e) {
/* 172 */     Object[] listeners = this.chartMouseListeners.getListeners(Chart3DMouseListener.class);
/*     */     
/* 174 */     if (listeners.length == 0) {
/*     */       return;
/*     */     }
/* 177 */     RenderedElement element = null;
/* 178 */     RenderingInfo info = getRenderingInfo();
/* 179 */     if (info != null) {
/* 180 */       element = info.findElementAt(e.getX(), e.getY());
/*     */     }
/* 182 */     Chart3DMouseEvent chartEvent = new Chart3DMouseEvent(this.chart, e, element);
/*     */     
/* 184 */     for (int i = listeners.length - 1; i >= 0; i--) {
/* 185 */       ((Chart3DMouseListener)listeners[i]).chartMouseMoved(chartEvent);
/*     */     }
/* 187 */     super.mouseMoved(e);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addChartMouseListener(Chart3DMouseListener listener) {
/* 198 */     ArgChecks.nullNotPermitted(listener, "listener");
/* 199 */     this.chartMouseListeners.add(Chart3DMouseListener.class, listener);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeChartMouseListener(Chart3DMouseListener listener) {
/* 211 */     this.chartMouseListeners.remove(Chart3DMouseListener.class, listener);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EventListener[] getListeners(Class<Chart3DMouseListener> listenerType) {
/* 224 */     if (listenerType == Chart3DMouseListener.class)
/*     */     {
/* 226 */       return (EventListener[])this.chartMouseListeners.getListeners(listenerType);
/*     */     }
/*     */     
/* 229 */     return super.getListeners(listenerType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void readObject(ObjectInputStream stream) throws IOException, ClassNotFoundException {
/* 243 */     stream.defaultReadObject();
/*     */     
/* 245 */     this.chartMouseListeners = new EventListenerList();
/*     */     
/* 247 */     if (this.chart != null)
/* 248 */       this.chart.addChangeListener(this); 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/Chart3DPanel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */