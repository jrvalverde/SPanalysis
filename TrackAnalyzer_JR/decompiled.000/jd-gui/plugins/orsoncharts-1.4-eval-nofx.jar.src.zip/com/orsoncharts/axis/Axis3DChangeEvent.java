/*    */ package com.orsoncharts.axis;
/*    */ 
/*    */ import com.orsoncharts.util.ArgChecks;
/*    */ import java.util.EventObject;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Axis3DChangeEvent
/*    */   extends EventObject
/*    */ {
/*    */   private Axis3D axis;
/*    */   private boolean requiresWorldUpdate;
/*    */   
/*    */   public Axis3DChangeEvent(Axis3D axis, boolean requiresWorldUpdate) {
/* 49 */     this(axis, axis, requiresWorldUpdate);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Axis3DChangeEvent(Object source, Axis3D axis, boolean requiresWorldUpdate) {
/* 62 */     super(source);
/* 63 */     ArgChecks.nullNotPermitted(axis, "axis");
/* 64 */     this.axis = axis;
/* 65 */     this.requiresWorldUpdate = requiresWorldUpdate;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Axis3D getAxis() {
/* 74 */     return this.axis;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean requiresWorldUpdate() {
/* 86 */     return this.requiresWorldUpdate;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/axis/Axis3DChangeEvent.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */