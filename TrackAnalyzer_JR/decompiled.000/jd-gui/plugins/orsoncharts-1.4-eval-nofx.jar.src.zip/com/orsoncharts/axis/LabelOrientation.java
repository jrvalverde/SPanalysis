/*    */ package com.orsoncharts.axis;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum LabelOrientation
/*    */ {
/* 21 */   PERPENDICULAR,
/*    */ 
/*    */   
/* 24 */   PARALLEL;
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/axis/LabelOrientation.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */