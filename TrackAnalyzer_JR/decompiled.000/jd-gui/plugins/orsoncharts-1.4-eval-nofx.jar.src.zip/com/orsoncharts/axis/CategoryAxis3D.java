package com.orsoncharts.axis;

import com.orsoncharts.data.category.CategoryDataset3D;
import com.orsoncharts.marker.CategoryMarker;
import com.orsoncharts.marker.MarkerData;
import com.orsoncharts.plot.CategoryPlot3D;
import java.util.List;

public interface CategoryAxis3D extends Axis3D {
  boolean isRowAxis();
  
  boolean isColumnAxis();
  
  void configureAsRowAxis(CategoryPlot3D paramCategoryPlot3D);
  
  void configureAsColumnAxis(CategoryPlot3D paramCategoryPlot3D);
  
  double getCategoryWidth();
  
  double getCategoryValue(Comparable<?> paramComparable);
  
  List<TickData> generateTickDataForRows(CategoryDataset3D paramCategoryDataset3D);
  
  List<TickData> generateTickDataForColumns(CategoryDataset3D paramCategoryDataset3D);
  
  List<MarkerData> generateMarkerData();
  
  CategoryMarker getMarker(String paramString);
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/axis/CategoryAxis3D.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */