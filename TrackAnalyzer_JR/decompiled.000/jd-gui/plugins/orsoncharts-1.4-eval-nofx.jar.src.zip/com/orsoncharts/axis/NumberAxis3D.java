/*     */ package com.orsoncharts.axis;
/*     */ 
/*     */ import com.orsoncharts.Chart3DHints;
/*     */ import com.orsoncharts.Range;
/*     */ import com.orsoncharts.graphics3d.RenderedElement;
/*     */ import com.orsoncharts.graphics3d.RenderingInfo;
/*     */ import com.orsoncharts.graphics3d.Utils2D;
/*     */ import com.orsoncharts.interaction.InteractiveElementType;
/*     */ import com.orsoncharts.util.ArgChecks;
/*     */ import com.orsoncharts.util.ObjectUtils;
/*     */ import com.orsoncharts.util.TextAnchor;
/*     */ import com.orsoncharts.util.TextUtils;
/*     */ import java.awt.FontMetrics;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.RenderingHints;
/*     */ import java.awt.Shape;
/*     */ import java.awt.font.LineMetrics;
/*     */ import java.awt.geom.Line2D;
/*     */ import java.awt.geom.Point2D;
/*     */ import java.io.Serializable;
/*     */ import java.text.DecimalFormat;
/*     */ import java.text.Format;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NumberAxis3D
/*     */   extends AbstractValueAxis3D
/*     */   implements ValueAxis3D, Serializable
/*     */ {
/*     */   private boolean autoRangeIncludesZero;
/*     */   private boolean autoRangeStickyZero;
/*     */   private TickSelector tickSelector;
/*     */   private double tickSize;
/*     */   private Format tickLabelFormatter;
/*     */   
/*     */   public NumberAxis3D(String label) {
/*  90 */     this(label, new Range(0.0D, 1.0D));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NumberAxis3D(String label, Range range) {
/* 100 */     super(label, range);
/* 101 */     this.autoRangeIncludesZero = false;
/* 102 */     this.autoRangeStickyZero = true;
/* 103 */     this.tickSelector = new NumberTickSelector();
/* 104 */     this.tickSize = range.getLength() / 10.0D;
/* 105 */     this.tickLabelFormatter = new DecimalFormat("0.00");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getAutoRangeIncludesZero() {
/* 116 */     return this.autoRangeIncludesZero;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAutoRangeIncludeZero(boolean include) {
/* 127 */     this.autoRangeIncludesZero = include;
/* 128 */     fireChangeEvent(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getAutoRangeStickyZero() {
/* 141 */     return this.autoRangeStickyZero;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAutoRangeStickyZero(boolean sticky) {
/* 153 */     this.autoRangeStickyZero = sticky;
/* 154 */     fireChangeEvent(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TickSelector getTickSelector() {
/* 167 */     return this.tickSelector;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTickSelector(TickSelector selector) {
/* 179 */     this.tickSelector = selector;
/* 180 */     fireChangeEvent(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getTickSize() {
/* 190 */     return this.tickSize;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTickSize(double tickSize) {
/* 199 */     this.tickSize = tickSize;
/* 200 */     fireChangeEvent(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Format getTickLabelFormatter() {
/* 210 */     return this.tickLabelFormatter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTickLabelFormatter(Format formatter) {
/* 220 */     ArgChecks.nullNotPermitted(formatter, "formatter");
/* 221 */     this.tickLabelFormatter = formatter;
/* 222 */     fireChangeEvent(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Range adjustedDataRange(Range range) {
/* 235 */     ArgChecks.nullNotPermitted(range, "range");
/* 236 */     double lm = range.getLength() * getLowerMargin();
/* 237 */     double um = range.getLength() * getUpperMargin();
/* 238 */     double lowerBound = range.getMin() - lm;
/* 239 */     double upperBound = range.getMax() + um;
/*     */     
/* 241 */     if (this.autoRangeStickyZero) {
/* 242 */       if (0.0D <= range.getMin() && 0.0D > lowerBound) {
/* 243 */         lowerBound = 0.0D;
/*     */       }
/* 245 */       if (0.0D >= range.getMax() && 0.0D < upperBound) {
/* 246 */         upperBound = 0.0D;
/*     */       }
/*     */     } 
/* 249 */     if (upperBound - lowerBound < getMinAutoRangeLength()) {
/* 250 */       double adj = (getMinAutoRangeLength() - upperBound - lowerBound) / 2.0D;
/*     */       
/* 252 */       lowerBound -= adj;
/* 253 */       upperBound += adj;
/*     */     } 
/* 255 */     return new Range(lowerBound, upperBound);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void draw(Graphics2D g2, Point2D pt0, Point2D pt1, Point2D opposingPt, List<TickData> tickData, RenderingInfo info, boolean hinting) {
/* 278 */     if (!isVisible()) {
/*     */       return;
/*     */     }
/* 281 */     if (pt0.equals(pt1)) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 286 */     g2.setStroke(getLineStroke());
/* 287 */     g2.setPaint(getLineColor());
/* 288 */     Line2D axisLine = new Line2D.Float(pt0, pt1);
/* 289 */     g2.draw(axisLine);
/*     */ 
/*     */     
/* 292 */     g2.setFont(getTickLabelFont());
/*     */ 
/*     */     
/* 295 */     double maxTickLabelDim = 0.0D;
/* 296 */     if (getTickLabelOrientation().equals(LabelOrientation.PARALLEL)) {
/* 297 */       LineMetrics lm = g2.getFontMetrics().getLineMetrics("123", g2);
/* 298 */       maxTickLabelDim = lm.getHeight();
/*     */     } 
/* 300 */     double tickMarkLength = getTickMarkLength();
/* 301 */     double tickLabelOffset = getTickLabelOffset();
/* 302 */     g2.setPaint(getTickMarkPaint());
/* 303 */     g2.setStroke(getTickMarkStroke());
/* 304 */     for (TickData t : tickData) {
/* 305 */       if (tickMarkLength > 0.0D) {
/* 306 */         Line2D tickLine = Utils2D.createPerpendicularLine(axisLine, t
/* 307 */             .getAnchorPt(), tickMarkLength, opposingPt);
/* 308 */         g2.draw(tickLine);
/*     */       } 
/* 310 */       String tickLabel = this.tickLabelFormatter.format(Double.valueOf(t.getDataValue()));
/* 311 */       if (getTickLabelOrientation().equals(LabelOrientation.PERPENDICULAR))
/*     */       {
/* 313 */         maxTickLabelDim = Math.max(maxTickLabelDim, g2
/* 314 */             .getFontMetrics().stringWidth(tickLabel));
/*     */       }
/*     */     } 
/*     */     
/* 318 */     if (getTickLabelsVisible()) {
/* 319 */       g2.setPaint(getTickLabelColor());
/* 320 */       if (getTickLabelOrientation().equals(LabelOrientation.PERPENDICULAR)) {
/*     */         
/* 322 */         drawPerpendicularTickLabels(g2, axisLine, opposingPt, tickData, info, hinting);
/*     */       } else {
/*     */         
/* 325 */         drawParallelTickLabels(g2, axisLine, opposingPt, tickData, info, hinting);
/*     */       } 
/*     */     } else {
/*     */       
/* 329 */       maxTickLabelDim = 0.0D;
/*     */     } 
/*     */ 
/*     */     
/* 333 */     if (getLabel() != null) {
/* 334 */       Shape labelBounds = drawAxisLabel(getLabel(), g2, axisLine, opposingPt, maxTickLabelDim + tickMarkLength + tickLabelOffset + 
/*     */           
/* 336 */           getLabelOffset(), info, hinting);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void drawParallelTickLabels(Graphics2D g2, Line2D axisLine, Point2D opposingPt, List<TickData> tickData, RenderingInfo info, boolean hinting) {
/* 355 */     g2.setFont(getTickLabelFont());
/* 356 */     double halfAscent = g2.getFontMetrics().getAscent() / 2.0D;
/* 357 */     for (TickData t : tickData) {
/* 358 */       Line2D perpLine = Utils2D.createPerpendicularLine(axisLine, t
/* 359 */           .getAnchorPt(), getTickMarkLength() + 
/* 360 */           getTickLabelOffset() + halfAscent, opposingPt);
/* 361 */       double axisTheta = Utils2D.calculateTheta(axisLine);
/* 362 */       TextAnchor textAnchor = TextAnchor.CENTER;
/* 363 */       if (axisTheta >= 1.5707963267948966D) {
/* 364 */         axisTheta -= Math.PI;
/* 365 */       } else if (axisTheta <= -1.5707963267948966D) {
/* 366 */         axisTheta += Math.PI;
/*     */       } 
/* 368 */       String tickLabel = this.tickLabelFormatter.format(
/* 369 */           Double.valueOf(t.getDataValue()));
/* 370 */       if (hinting) {
/* 371 */         Map<Object, Object> m = new HashMap<Object, Object>();
/* 372 */         m.put("ref", "{\"type\": \"valueTickLabel\", \"axis\": \"" + 
/* 373 */             axisStr() + "\", \"value\": \"" + t
/* 374 */             .getDataValue() + "\"}");
/* 375 */         g2.setRenderingHint((RenderingHints.Key)Chart3DHints.KEY_BEGIN_ELEMENT, m);
/*     */       } 
/* 377 */       Shape bounds = TextUtils.drawRotatedString(tickLabel, g2, 
/* 378 */           (float)perpLine.getX2(), (float)perpLine.getY2(), textAnchor, axisTheta, textAnchor);
/*     */       
/* 380 */       if (hinting) {
/* 381 */         g2.setRenderingHint((RenderingHints.Key)Chart3DHints.KEY_END_ELEMENT, Boolean.valueOf(true));
/*     */       }
/* 383 */       if (info != null) {
/* 384 */         RenderedElement tickLabelElement = new RenderedElement(InteractiveElementType.VALUE_AXIS_TICK_LABEL, bounds);
/*     */         
/* 386 */         tickLabelElement.setProperty("axis", axisStr());
/* 387 */         tickLabelElement.setProperty("value", 
/* 388 */             Double.valueOf(t.getDataValue()));
/* 389 */         info.addOffsetElement(tickLabelElement);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void drawPerpendicularTickLabels(Graphics2D g2, Line2D axisLine, Point2D opposingPt, List<TickData> tickData, RenderingInfo info, boolean hinting) {
/* 408 */     for (TickData t : tickData) {
/* 409 */       double theta = Utils2D.calculateTheta(axisLine);
/* 410 */       double thetaAdj = theta + 1.5707963267948966D;
/* 411 */       if (thetaAdj < -1.5707963267948966D) {
/* 412 */         thetaAdj += Math.PI;
/*     */       }
/* 414 */       if (thetaAdj > 1.5707963267948966D) {
/* 415 */         thetaAdj -= Math.PI;
/*     */       }
/*     */       
/* 418 */       Line2D perpLine = Utils2D.createPerpendicularLine(axisLine, t
/* 419 */           .getAnchorPt(), getTickMarkLength() + getTickLabelOffset(), opposingPt);
/*     */       
/* 421 */       double perpTheta = Utils2D.calculateTheta(perpLine);
/* 422 */       TextAnchor textAnchor = TextAnchor.CENTER_LEFT;
/* 423 */       if (Math.abs(perpTheta) > 1.5707963267948966D) {
/* 424 */         textAnchor = TextAnchor.CENTER_RIGHT;
/*     */       }
/* 426 */       String tickLabel = this.tickLabelFormatter.format(
/* 427 */           Double.valueOf(t.getDataValue()));
/* 428 */       if (hinting) {
/* 429 */         Map<Object, Object> m = new HashMap<Object, Object>();
/* 430 */         m.put("ref", "{\"type\": \"valueTickLabel\", \"axis\": \"" + 
/* 431 */             axisStr() + "\", \"value\": \"" + t
/* 432 */             .getDataValue() + "\"}");
/* 433 */         g2.setRenderingHint((RenderingHints.Key)Chart3DHints.KEY_BEGIN_ELEMENT, m);
/*     */       } 
/* 435 */       Shape bounds = TextUtils.drawRotatedString(tickLabel, g2, 
/* 436 */           (float)perpLine.getX2(), (float)perpLine.getY2(), textAnchor, thetaAdj, textAnchor);
/*     */       
/* 438 */       if (hinting) {
/* 439 */         g2.setRenderingHint((RenderingHints.Key)Chart3DHints.KEY_END_ELEMENT, Boolean.valueOf(true));
/*     */       }
/* 441 */       if (info != null) {
/* 442 */         RenderedElement tickLabelElement = new RenderedElement(InteractiveElementType.VALUE_AXIS_TICK_LABEL, bounds);
/*     */         
/* 444 */         tickLabelElement.setProperty("axis", axisStr());
/* 445 */         tickLabelElement.setProperty("value", 
/* 446 */             Double.valueOf(t.getDataValue()));
/* 447 */         info.addOffsetElement(tickLabelElement);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double translateToWorld(double value, double length) {
/* 464 */     return length * (value - getRange().getMin()) / getRange().getLength();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double selectTick(Graphics2D g2, Point2D pt0, Point2D pt1, Point2D opposingPt) {
/* 481 */     if (this.tickSelector == null) {
/* 482 */       return this.tickSize;
/*     */     }
/* 484 */     g2.setFont(getTickLabelFont());
/* 485 */     FontMetrics fm = g2.getFontMetrics(getTickLabelFont());
/* 486 */     double length = pt0.distance(pt1);
/* 487 */     LabelOrientation orientation = getTickLabelOrientation();
/* 488 */     if (orientation.equals(LabelOrientation.PERPENDICULAR)) {
/*     */ 
/*     */       
/* 491 */       double height = fm.getHeight();
/*     */ 
/*     */       
/* 494 */       int maxTicks = (int)(length / height * getTickLabelFactor());
/* 495 */       if (maxTicks > 2 && this.tickSelector != null) {
/* 496 */         double rangeLength = getRange().getLength();
/* 497 */         this.tickSelector.select(rangeLength / 2.0D);
/*     */ 
/*     */ 
/*     */         
/* 501 */         int tickCount = (int)(rangeLength / this.tickSelector.getCurrentTickSize());
/* 502 */         while (tickCount < maxTicks) {
/* 503 */           this.tickSelector.previous();
/*     */           
/* 505 */           tickCount = (int)(rangeLength / this.tickSelector.getCurrentTickSize());
/*     */         } 
/* 507 */         this.tickSelector.next();
/* 508 */         this.tickSize = this.tickSelector.getCurrentTickSize();
/* 509 */         this
/* 510 */           .tickLabelFormatter = this.tickSelector.getCurrentTickLabelFormat();
/*     */       } else {
/* 512 */         this.tickSize = Double.NaN;
/*     */       } 
/* 514 */     } else if (orientation.equals(LabelOrientation.PARALLEL)) {
/*     */       
/* 516 */       this.tickSelector.select(getRange().getLength());
/* 517 */       boolean done = false;
/* 518 */       while (!done) {
/* 519 */         if (this.tickSelector.previous()) {
/*     */           
/* 521 */           Format f = this.tickSelector.getCurrentTickLabelFormat();
/* 522 */           String s0 = f.format(Double.valueOf(this.range.getMin()));
/* 523 */           String s1 = f.format(Double.valueOf(this.range.getMax()));
/* 524 */           double w0 = fm.stringWidth(s0);
/* 525 */           double w1 = fm.stringWidth(s1);
/* 526 */           double w = Math.max(w0, w1);
/* 527 */           int n = (int)(length / w * getTickLabelFactor());
/* 528 */           if (n < getRange().getLength() / this.tickSelector
/* 529 */             .getCurrentTickSize()) {
/* 530 */             this.tickSelector.next();
/* 531 */             done = true;
/*     */           }  continue;
/*     */         } 
/* 534 */         done = true;
/*     */       } 
/*     */       
/* 537 */       this.tickSize = this.tickSelector.getCurrentTickSize();
/* 538 */       this
/* 539 */         .tickLabelFormatter = this.tickSelector.getCurrentTickLabelFormat();
/*     */     } 
/* 541 */     return this.tickSize;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<TickData> generateTickData(double tickUnit) {
/* 559 */     List<TickData> result = new ArrayList<TickData>();
/* 560 */     if (Double.isNaN(tickUnit)) {
/* 561 */       result.add(new TickData(0.0D, getRange().getMin()));
/* 562 */       result.add(new TickData(1.0D, getRange().getMax()));
/*     */     } else {
/* 564 */       double x = tickUnit * Math.ceil(this.range.getMin() / tickUnit);
/* 565 */       while (x <= this.range.getMax()) {
/* 566 */         result.add(new TickData(this.range.percent(x), x));
/* 567 */         x += tickUnit;
/*     */       } 
/*     */     } 
/* 570 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 582 */     if (obj == this) {
/* 583 */       return true;
/*     */     }
/* 585 */     if (!(obj instanceof NumberAxis3D)) {
/* 586 */       return false;
/*     */     }
/* 588 */     NumberAxis3D that = (NumberAxis3D)obj;
/* 589 */     if (this.autoRangeIncludesZero != that.autoRangeIncludesZero) {
/* 590 */       return false;
/*     */     }
/* 592 */     if (this.autoRangeStickyZero != that.autoRangeStickyZero) {
/* 593 */       return false;
/*     */     }
/* 595 */     if (this.tickSize != that.tickSize) {
/* 596 */       return false;
/*     */     }
/* 598 */     if (!ObjectUtils.equals(this.tickSelector, that.tickSelector)) {
/* 599 */       return false;
/*     */     }
/* 601 */     if (!this.tickLabelFormatter.equals(that.tickLabelFormatter)) {
/* 602 */       return false;
/*     */     }
/* 604 */     return super.equals(obj);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 614 */     int hash = 3;
/*     */     
/* 616 */     hash = 59 * hash + (int)(Double.doubleToLongBits(this.tickSize) ^ Double.doubleToLongBits(this.tickSize) >>> 32L);
/* 617 */     hash = 59 * hash + ObjectUtils.hashCode(this.tickLabelFormatter);
/* 618 */     return hash;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/axis/NumberAxis3D.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */