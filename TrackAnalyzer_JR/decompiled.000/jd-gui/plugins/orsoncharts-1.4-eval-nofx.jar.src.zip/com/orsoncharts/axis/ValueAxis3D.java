package com.orsoncharts.axis;

import com.orsoncharts.marker.MarkerData;
import com.orsoncharts.marker.ValueMarker;
import com.orsoncharts.plot.CategoryPlot3D;
import com.orsoncharts.plot.XYZPlot;
import java.awt.Graphics2D;
import java.awt.geom.Point2D;
import java.util.List;

public interface ValueAxis3D extends Axis3D {
  ValueAxis3DType getConfiguredType();
  
  void configureAsValueAxis(CategoryPlot3D paramCategoryPlot3D);
  
  void configureAsXAxis(XYZPlot paramXYZPlot);
  
  void configureAsYAxis(XYZPlot paramXYZPlot);
  
  void configureAsZAxis(XYZPlot paramXYZPlot);
  
  double selectTick(Graphics2D paramGraphics2D, Point2D paramPoint2D1, Point2D paramPoint2D2, Point2D paramPoint2D3);
  
  List<TickData> generateTickData(double paramDouble);
  
  List<MarkerData> generateMarkerData();
  
  ValueMarker getMarker(String paramString);
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/axis/ValueAxis3D.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */