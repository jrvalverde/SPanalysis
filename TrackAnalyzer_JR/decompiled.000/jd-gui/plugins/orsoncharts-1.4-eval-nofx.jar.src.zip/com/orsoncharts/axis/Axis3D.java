package com.orsoncharts.axis;

import com.orsoncharts.ChartElement;
import com.orsoncharts.Range;
import com.orsoncharts.graphics3d.RenderingInfo;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.geom.Point2D;
import java.util.List;

public interface Axis3D extends ChartElement {
  boolean isVisible();
  
  void setVisible(boolean paramBoolean);
  
  Font getLabelFont();
  
  void setLabelFont(Font paramFont);
  
  Color getLabelColor();
  
  void setLabelColor(Color paramColor);
  
  Font getTickLabelFont();
  
  void setTickLabelFont(Font paramFont);
  
  Color getTickLabelColor();
  
  void setTickLabelColor(Color paramColor);
  
  Range getRange();
  
  void setRange(Range paramRange);
  
  void setRange(double paramDouble1, double paramDouble2);
  
  double translateToWorld(double paramDouble1, double paramDouble2);
  
  void draw(Graphics2D paramGraphics2D, Point2D paramPoint2D1, Point2D paramPoint2D2, Point2D paramPoint2D3, List<TickData> paramList, RenderingInfo paramRenderingInfo, boolean paramBoolean);
  
  void addChangeListener(Axis3DChangeListener paramAxis3DChangeListener);
  
  void removeChangeListener(Axis3DChangeListener paramAxis3DChangeListener);
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/axis/Axis3D.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */