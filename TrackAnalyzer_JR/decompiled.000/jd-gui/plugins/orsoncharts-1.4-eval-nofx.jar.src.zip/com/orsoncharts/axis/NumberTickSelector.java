/*     */ package com.orsoncharts.axis;
/*     */ 
/*     */ import com.orsoncharts.util.ArgChecks;
/*     */ import java.io.Serializable;
/*     */ import java.text.DecimalFormat;
/*     */ import java.text.Format;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NumberTickSelector
/*     */   implements TickSelector, Serializable
/*     */ {
/*  31 */   private int power = 0;
/*     */   
/*  33 */   private int factor = 1; private boolean percentage; private DecimalFormat dfNeg4;
/*     */   private DecimalFormat dfNeg3;
/*     */   private DecimalFormat dfNeg2;
/*     */   private DecimalFormat dfNeg1;
/*     */   private DecimalFormat df0;
/*     */   private DecimalFormat dfNeg4P;
/*     */   private DecimalFormat dfNeg3P;
/*     */   private DecimalFormat dfNeg2P;
/*     */   private DecimalFormat dfNeg1P;
/*     */   private DecimalFormat df0P;
/*     */   
/*     */   public NumberTickSelector() {
/*  45 */     this(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double select(double reference) {
/*  78 */     ArgChecks.finitePositiveRequired(reference, "reference");
/*  79 */     this.power = (int)Math.ceil(Math.log10(reference));
/*  80 */     this.factor = 1;
/*  81 */     return getCurrentTickSize();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean next() {
/*  92 */     if (this.factor == 1) {
/*  93 */       this.factor = 2;
/*  94 */       return true;
/*     */     } 
/*  96 */     if (this.factor == 2) {
/*  97 */       this.factor = 5;
/*  98 */       return true;
/*     */     } 
/* 100 */     if (this.factor == 5) {
/* 101 */       this.power++;
/* 102 */       this.factor = 1;
/* 103 */       return true;
/*     */     } 
/* 105 */     throw new IllegalStateException("We should never get here.");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean previous() {
/* 116 */     if (this.factor == 1) {
/* 117 */       this.factor = 5;
/* 118 */       this.power--;
/* 119 */       return true;
/*     */     } 
/* 121 */     if (this.factor == 2) {
/* 122 */       this.factor = 1;
/* 123 */       return true;
/*     */     } 
/* 125 */     if (this.factor == 5) {
/* 126 */       this.factor = 2;
/* 127 */       return true;
/*     */     } 
/* 129 */     throw new IllegalStateException("We should never get here.");
/*     */   }
/*     */ 
/*     */   
/*     */   public double getCurrentTickSize() {
/* 134 */     return this.factor * Math.pow(10.0D, this.power);
/*     */   }
/*     */   
/* 137 */   public NumberTickSelector(boolean percentage) { this.dfNeg4 = new DecimalFormat("0.0000");
/* 138 */     this.dfNeg3 = new DecimalFormat("0.000");
/* 139 */     this.dfNeg2 = new DecimalFormat("0.00");
/* 140 */     this.dfNeg1 = new DecimalFormat("0.0");
/* 141 */     this.df0 = new DecimalFormat("#,##0");
/* 142 */     this.dfNeg4P = new DecimalFormat("0.00%");
/* 143 */     this.dfNeg3P = new DecimalFormat("0.0%");
/* 144 */     this.dfNeg2P = new DecimalFormat("0%");
/* 145 */     this.dfNeg1P = new DecimalFormat("0%");
/* 146 */     this.df0P = new DecimalFormat("#,##0%");
/*     */     this.power = 0;
/*     */     this.factor = 1;
/*     */     this.percentage = percentage; } public Format getCurrentTickLabelFormat() {
/* 150 */     if (this.power == -4) {
/* 151 */       return this.percentage ? this.dfNeg4P : this.dfNeg4;
/*     */     }
/* 153 */     if (this.power == -3) {
/* 154 */       return this.percentage ? this.dfNeg3P : this.dfNeg3;
/*     */     }
/* 156 */     if (this.power == -2) {
/* 157 */       return this.percentage ? this.dfNeg2P : this.dfNeg2;
/*     */     }
/* 159 */     if (this.power == -1) {
/* 160 */       return this.percentage ? this.dfNeg1P : this.dfNeg1;
/*     */     }
/* 162 */     if (this.power >= 0 && this.power <= 6) {
/* 163 */       return this.percentage ? this.df0P : this.df0;
/*     */     }
/* 165 */     return this.percentage ? new DecimalFormat("0.0000E0%") : new DecimalFormat("0.0000E0");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 178 */     if (obj == this) {
/* 179 */       return true;
/*     */     }
/* 181 */     if (!(obj instanceof NumberTickSelector)) {
/* 182 */       return false;
/*     */     }
/* 184 */     NumberTickSelector that = (NumberTickSelector)obj;
/* 185 */     if (this.percentage != that.percentage) {
/* 186 */       return false;
/*     */     }
/* 188 */     return true;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/axis/NumberTickSelector.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */