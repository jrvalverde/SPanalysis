package com.orsoncharts.axis;

import java.text.Format;

public interface TickSelector {
  double select(double paramDouble);
  
  boolean next();
  
  boolean previous();
  
  double getCurrentTickSize();
  
  Format getCurrentTickLabelFormat();
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/axis/TickSelector.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */