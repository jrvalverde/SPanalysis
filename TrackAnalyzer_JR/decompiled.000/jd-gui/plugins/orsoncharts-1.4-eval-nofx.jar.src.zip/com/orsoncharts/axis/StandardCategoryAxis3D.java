/*      */ package com.orsoncharts.axis;
/*      */ 
/*      */ import com.orsoncharts.Chart3DHints;
/*      */ import com.orsoncharts.ChartElementVisitor;
/*      */ import com.orsoncharts.Range;
/*      */ import com.orsoncharts.data.category.CategoryDataset3D;
/*      */ import com.orsoncharts.graphics3d.RenderedElement;
/*      */ import com.orsoncharts.graphics3d.RenderingInfo;
/*      */ import com.orsoncharts.graphics3d.Utils2D;
/*      */ import com.orsoncharts.interaction.InteractiveElementType;
/*      */ import com.orsoncharts.label.CategoryLabelGenerator;
/*      */ import com.orsoncharts.label.StandardCategoryLabelGenerator;
/*      */ import com.orsoncharts.marker.CategoryMarker;
/*      */ import com.orsoncharts.marker.CategoryMarkerType;
/*      */ import com.orsoncharts.marker.Marker;
/*      */ import com.orsoncharts.marker.MarkerData;
/*      */ import com.orsoncharts.plot.CategoryPlot3D;
/*      */ import com.orsoncharts.util.ArgChecks;
/*      */ import com.orsoncharts.util.ObjectUtils;
/*      */ import com.orsoncharts.util.SerialUtils;
/*      */ import com.orsoncharts.util.TextAnchor;
/*      */ import com.orsoncharts.util.TextUtils;
/*      */ import java.awt.BasicStroke;
/*      */ import java.awt.Color;
/*      */ import java.awt.Graphics2D;
/*      */ import java.awt.Paint;
/*      */ import java.awt.RenderingHints;
/*      */ import java.awt.Shape;
/*      */ import java.awt.Stroke;
/*      */ import java.awt.font.LineMetrics;
/*      */ import java.awt.geom.Line2D;
/*      */ import java.awt.geom.Point2D;
/*      */ import java.io.IOException;
/*      */ import java.io.ObjectInputStream;
/*      */ import java.io.ObjectOutputStream;
/*      */ import java.io.Serializable;
/*      */ import java.util.ArrayList;
/*      */ import java.util.HashMap;
/*      */ import java.util.LinkedHashMap;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class StandardCategoryAxis3D
/*      */   extends AbstractAxis3D
/*      */   implements CategoryAxis3D, Serializable
/*      */ {
/*      */   private List<Comparable<?>> categories;
/*      */   private Range range;
/*      */   private double lowerMargin;
/*      */   private double upperMargin;
/*      */   private boolean firstCategoryHalfWidth = false;
/*      */   private boolean lastCategoryHalfWidth = false;
/*      */   private double tickMarkLength;
/*      */   private transient Stroke tickMarkStroke;
/*      */   private transient Paint tickMarkPaint;
/*      */   private CategoryLabelGenerator tickLabelGenerator;
/*      */   private double tickLabelOffset;
/*      */   private LabelOrientation tickLabelOrientation;
/*  122 */   private int maxTickLabelLevels = 3;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  128 */   private double tickLabelFactor = 1.2D;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Map<String, CategoryMarker> markers;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean isRowAxis;
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean isColumnAxis;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public StandardCategoryAxis3D() {
/*  148 */     this((String)null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public StandardCategoryAxis3D(String label) {
/*  157 */     super(label);
/*  158 */     this.categories = new ArrayList<Comparable<?>>();
/*  159 */     this.range = new Range(0.0D, 1.0D);
/*  160 */     this.lowerMargin = 0.05D;
/*  161 */     this.upperMargin = 0.05D;
/*  162 */     this.firstCategoryHalfWidth = false;
/*  163 */     this.lastCategoryHalfWidth = false;
/*  164 */     this.tickMarkLength = 3.0D;
/*  165 */     this.tickMarkPaint = Color.GRAY;
/*  166 */     this.tickMarkStroke = new BasicStroke(0.5F);
/*  167 */     this.tickLabelGenerator = (CategoryLabelGenerator)new StandardCategoryLabelGenerator();
/*  168 */     this.tickLabelOffset = 5.0D;
/*  169 */     this.tickLabelOrientation = LabelOrientation.PARALLEL;
/*  170 */     this.tickLabelFactor = 1.4D;
/*  171 */     this.maxTickLabelLevels = 3;
/*  172 */     this.markers = new LinkedHashMap<String, CategoryMarker>();
/*  173 */     this.isRowAxis = false;
/*  174 */     this.isColumnAxis = false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isRowAxis() {
/*  188 */     return this.isRowAxis;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isColumnAxis() {
/*  202 */     return this.isColumnAxis;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Range getRange() {
/*  213 */     return this.range;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setRange(double lowerBound, double upperBound) {
/*  225 */     setRange(new Range(lowerBound, upperBound));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setRange(Range range) {
/*  237 */     ArgChecks.nullNotPermitted(range, "range");
/*  238 */     this.range = range;
/*  239 */     fireChangeEvent(true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public double getLowerMargin() {
/*  249 */     return this.lowerMargin;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setLowerMargin(double margin) {
/*  259 */     this.lowerMargin = margin;
/*  260 */     fireChangeEvent(true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public double getUpperMargin() {
/*  270 */     return this.upperMargin;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setUpperMargin(double margin) {
/*  280 */     this.upperMargin = margin;
/*  281 */     fireChangeEvent(true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isFirstCategoryHalfWidth() {
/*  293 */     return this.firstCategoryHalfWidth;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFirstCategoryHalfWidth(boolean half) {
/*  308 */     this.firstCategoryHalfWidth = half;
/*  309 */     fireChangeEvent(true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isLastCategoryHalfWidth() {
/*  321 */     return this.lastCategoryHalfWidth;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setLastCategoryHalfWidth(boolean half) {
/*  336 */     this.lastCategoryHalfWidth = half;
/*  337 */     fireChangeEvent(true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public double getTickMarkLength() {
/*  347 */     return this.tickMarkLength;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTickMarkLength(double length) {
/*  359 */     this.tickMarkLength = length;
/*  360 */     fireChangeEvent(false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Paint getTickMarkPaint() {
/*  370 */     return this.tickMarkPaint;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTickMarkPaint(Paint paint) {
/*  380 */     ArgChecks.nullNotPermitted(paint, "paint");
/*  381 */     this.tickMarkPaint = paint;
/*  382 */     fireChangeEvent(false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Stroke getTickMarkStroke() {
/*  392 */     return this.tickMarkStroke;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTickMarkStroke(Stroke stroke) {
/*  402 */     ArgChecks.nullNotPermitted(stroke, "stroke");
/*  403 */     this.tickMarkStroke = stroke;
/*  404 */     fireChangeEvent(false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CategoryLabelGenerator getTickLabelGenerator() {
/*  418 */     return this.tickLabelGenerator;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTickLabelGenerator(CategoryLabelGenerator generator) {
/*  430 */     ArgChecks.nullNotPermitted(generator, "generator");
/*  431 */     this.tickLabelGenerator = generator;
/*  432 */     fireChangeEvent(false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public double getTickLabelOffset() {
/*  443 */     return this.tickLabelOffset;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTickLabelOffset(double offset) {
/*  453 */     this.tickLabelOffset = offset;
/*  454 */     fireChangeEvent(false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LabelOrientation getTickLabelOrientation() {
/*  466 */     return this.tickLabelOrientation;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTickLabelOrientation(LabelOrientation orientation) {
/*  478 */     ArgChecks.nullNotPermitted(orientation, "orientation");
/*  479 */     this.tickLabelOrientation = orientation;
/*  480 */     fireChangeEvent(false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getMaxTickLabelLevels() {
/*  492 */     return this.maxTickLabelLevels;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMaxTickLabelLevels(int levels) {
/*  504 */     this.maxTickLabelLevels = levels;
/*  505 */     fireChangeEvent(false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public double getTickLabelFactor() {
/*  516 */     return this.tickLabelFactor;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTickLabelFactor(double factor) {
/*  528 */     this.tickLabelFactor = factor;
/*  529 */     fireChangeEvent(false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CategoryMarker getMarker(String key) {
/*  543 */     return this.markers.get(key);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMarker(String key, CategoryMarker marker) {
/*  559 */     CategoryMarker existing = this.markers.get(key);
/*  560 */     if (existing != null) {
/*  561 */       existing.removeChangeListener(this);
/*      */     }
/*  563 */     this.markers.put(key, marker);
/*  564 */     if (marker != null) {
/*  565 */       marker.addChangeListener(this);
/*      */     }
/*  567 */     fireChangeEvent(false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Map<String, CategoryMarker> getMarkers() {
/*  578 */     return new LinkedHashMap<String, CategoryMarker>(this.markers);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public double getCategoryWidth() {
/*  589 */     double length = this.range.getLength();
/*  590 */     double start = this.range.getMin() + this.lowerMargin * length;
/*  591 */     double end = this.range.getMax() - this.upperMargin * length;
/*  592 */     double available = end - start;
/*  593 */     return available / this.categories.size();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void configureAsRowAxis(CategoryPlot3D plot) {
/*  604 */     ArgChecks.nullNotPermitted(plot, "plot");
/*  605 */     this.categories = plot.getDataset().getRowKeys();
/*  606 */     this.isColumnAxis = false;
/*  607 */     this.isRowAxis = true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void configureAsColumnAxis(CategoryPlot3D plot) {
/*  619 */     ArgChecks.nullNotPermitted(plot, "plot");
/*  620 */     this.categories = plot.getDataset().getColumnKeys();
/*  621 */     this.isColumnAxis = true;
/*  622 */     this.isRowAxis = false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public double getCategoryValue(Comparable<?> category) {
/*  635 */     int index = this.categories.indexOf(category);
/*  636 */     if (index < 0) {
/*  637 */       return Double.NaN;
/*      */     }
/*  639 */     double length = this.range.getLength();
/*  640 */     double start = this.range.getMin() + this.lowerMargin * length;
/*  641 */     double end = this.range.getMax() - this.upperMargin * length;
/*  642 */     double available = end - start;
/*  643 */     double categoryCount = this.categories.size();
/*  644 */     if (categoryCount == 1.0D) {
/*  645 */       return (start + end) / 2.0D;
/*      */     }
/*  647 */     if (this.firstCategoryHalfWidth) {
/*  648 */       categoryCount -= 0.5D;
/*      */     }
/*  650 */     if (this.lastCategoryHalfWidth) {
/*  651 */       categoryCount -= 0.5D;
/*      */     }
/*  653 */     double categoryWidth = 0.0D;
/*  654 */     if (categoryCount > 0.0D) {
/*  655 */       categoryWidth = available / categoryCount;
/*      */     }
/*  657 */     double adj = this.firstCategoryHalfWidth ? 0.0D : 0.5D;
/*  658 */     return start + (adj + index) * categoryWidth;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public double translateToWorld(double value, double length) {
/*  672 */     return length * (value - this.range.getMin()) / this.range.getLength();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void draw(Graphics2D g2, Point2D pt0, Point2D pt1, Point2D opposingPt, List<TickData> tickData, RenderingInfo info, boolean hinting) {
/*  697 */     if (!isVisible()) {
/*      */       return;
/*      */     }
/*  700 */     if (pt0.equals(pt1)) {
/*      */       return;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  706 */     g2.setStroke(getLineStroke());
/*  707 */     g2.setPaint(getLineColor());
/*  708 */     Line2D axisLine = new Line2D.Float(pt0, pt1);
/*  709 */     g2.draw(axisLine);
/*      */ 
/*      */ 
/*      */     
/*  713 */     g2.setPaint(this.tickMarkPaint);
/*  714 */     g2.setStroke(this.tickMarkStroke);
/*  715 */     g2.setFont(getTickLabelFont());
/*  716 */     double maxTickLabelWidth = 0.0D;
/*  717 */     for (TickData t : tickData) {
/*  718 */       if (this.tickMarkLength > 0.0D) {
/*  719 */         Line2D tickLine = Utils2D.createPerpendicularLine(axisLine, t
/*  720 */             .getAnchorPt(), this.tickMarkLength, opposingPt);
/*  721 */         g2.draw(tickLine);
/*      */       } 
/*  723 */       String tickLabel = t.getKeyLabel();
/*  724 */       maxTickLabelWidth = Math.max(maxTickLabelWidth, g2
/*  725 */           .getFontMetrics().stringWidth(tickLabel));
/*      */     } 
/*      */     
/*  728 */     double maxTickLabelDim = maxTickLabelWidth;
/*  729 */     if (getTickLabelsVisible()) {
/*  730 */       g2.setPaint(getTickLabelColor());
/*  731 */       if (this.tickLabelOrientation.equals(LabelOrientation.PERPENDICULAR)) {
/*      */         
/*  733 */         drawPerpendicularTickLabels(g2, axisLine, opposingPt, tickData, info, hinting);
/*      */       }
/*  735 */       else if (this.tickLabelOrientation.equals(LabelOrientation.PARALLEL)) {
/*      */         
/*  737 */         maxTickLabelDim = drawParallelTickLabels(g2, axisLine, opposingPt, tickData, maxTickLabelWidth, info, hinting);
/*      */       } 
/*      */     } else {
/*      */       
/*  741 */       maxTickLabelDim = 0.0D;
/*      */     } 
/*      */ 
/*      */     
/*  745 */     if (getLabel() != null) {
/*  746 */       Shape labelBounds = drawAxisLabel(getLabel(), g2, axisLine, opposingPt, maxTickLabelDim + this.tickMarkLength + this.tickLabelOffset + 
/*      */           
/*  748 */           getLabelOffset(), info, hinting);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String axisStr() {
/*  763 */     String result = "";
/*  764 */     if (this.isRowAxis) {
/*  765 */       result = "row";
/*  766 */     } else if (this.isColumnAxis) {
/*  767 */       result = "column";
/*      */     } 
/*  769 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private double drawParallelTickLabels(Graphics2D g2, Line2D axisLine, Point2D opposingPt, List<TickData> tickData, double maxTickLabelWidth, RenderingInfo info, boolean hinting) {
/*  775 */     int levels = 1;
/*  776 */     LineMetrics lm = g2.getFontMetrics().getLineMetrics("123", g2);
/*  777 */     double height = lm.getHeight();
/*  778 */     if (tickData.size() > 1) {
/*      */ 
/*      */ 
/*      */       
/*  782 */       Point2D p0 = ((TickData)tickData.get(0)).getAnchorPt();
/*  783 */       Point2D pN = ((TickData)tickData.get(tickData.size() - 1)).getAnchorPt();
/*      */       
/*  785 */       double availableWidth = pN.distance(p0) * tickData.size() / (tickData.size() - 1);
/*  786 */       int labelsPerLevel = (int)Math.floor(availableWidth / maxTickLabelWidth * this.tickLabelFactor);
/*      */       
/*  788 */       int levelsRequired = this.maxTickLabelLevels;
/*  789 */       if (labelsPerLevel > 0) {
/*  790 */         levelsRequired = this.categories.size() / labelsPerLevel + 1;
/*      */       }
/*  792 */       levels = Math.min(levelsRequired, this.maxTickLabelLevels);
/*      */     } 
/*      */     
/*  795 */     int index = 0;
/*  796 */     for (TickData t : tickData) {
/*  797 */       int level = index % levels;
/*  798 */       double adj = height * (level + 0.5D);
/*  799 */       Line2D perpLine = Utils2D.createPerpendicularLine(axisLine, t
/*  800 */           .getAnchorPt(), this.tickMarkLength + this.tickLabelOffset + adj, opposingPt);
/*      */       
/*  802 */       double axisTheta = Utils2D.calculateTheta(axisLine);
/*  803 */       TextAnchor textAnchor = TextAnchor.CENTER;
/*  804 */       if (axisTheta >= 1.5707963267948966D) {
/*  805 */         axisTheta -= Math.PI;
/*  806 */       } else if (axisTheta <= -1.5707963267948966D) {
/*  807 */         axisTheta += Math.PI;
/*      */       } 
/*  809 */       String tickLabel = t.getKeyLabel();
/*  810 */       if (hinting) {
/*  811 */         Map<Object, Object> m = new HashMap<Object, Object>();
/*  812 */         m.put("ref", "{\"type\": \"categoryTickLabel\", \"axis\": \"" + 
/*  813 */             axisStr() + "\", \"key\": \"" + t
/*  814 */             .getKey() + "\"}");
/*  815 */         g2.setRenderingHint((RenderingHints.Key)Chart3DHints.KEY_BEGIN_ELEMENT, m);
/*      */       } 
/*      */       
/*  818 */       Shape bounds = TextUtils.drawRotatedString(tickLabel, g2, 
/*  819 */           (float)perpLine.getX2(), (float)perpLine.getY2(), textAnchor, axisTheta, textAnchor);
/*      */       
/*  821 */       if (hinting) {
/*  822 */         g2.setRenderingHint((RenderingHints.Key)Chart3DHints.KEY_END_ELEMENT, Boolean.valueOf(true));
/*      */       }
/*  824 */       if (info != null) {
/*  825 */         RenderedElement tickLabelElement = new RenderedElement(InteractiveElementType.CATEGORY_AXIS_TICK_LABEL, bounds);
/*      */         
/*  827 */         tickLabelElement.setProperty("label", tickLabel);
/*  828 */         tickLabelElement.setProperty("axis", axisStr());
/*  829 */         info.addOffsetElement(tickLabelElement);
/*      */       } 
/*  831 */       index++;
/*      */     } 
/*  833 */     return height * levels;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void drawPerpendicularTickLabels(Graphics2D g2, Line2D axisLine, Point2D opposingPt, List<TickData> tickData, RenderingInfo info, boolean hinting) {
/*  852 */     for (TickData t : tickData) {
/*  853 */       Line2D perpLine = Utils2D.createPerpendicularLine(axisLine, t
/*  854 */           .getAnchorPt(), this.tickMarkLength + this.tickLabelOffset, opposingPt);
/*      */       
/*  856 */       double perpTheta = Utils2D.calculateTheta(perpLine);
/*  857 */       TextAnchor textAnchor = TextAnchor.CENTER_LEFT;
/*  858 */       if (perpTheta >= 1.5707963267948966D) {
/*  859 */         perpTheta -= Math.PI;
/*  860 */         textAnchor = TextAnchor.CENTER_RIGHT;
/*  861 */       } else if (perpTheta <= -1.5707963267948966D) {
/*  862 */         perpTheta += Math.PI;
/*  863 */         textAnchor = TextAnchor.CENTER_RIGHT;
/*      */       } 
/*  865 */       String tickLabel = t.getKeyLabel();
/*  866 */       if (hinting) {
/*  867 */         Map<Object, Object> m = new HashMap<Object, Object>();
/*  868 */         m.put("ref", "{\"type\": \"categoryAxisLabel\", \"axis\": \"" + 
/*  869 */             axisStr() + "\", \"key\": \"" + t
/*  870 */             .getKey() + "\"}");
/*  871 */         g2.setRenderingHint((RenderingHints.Key)Chart3DHints.KEY_BEGIN_ELEMENT, m);
/*      */       } 
/*  873 */       Shape bounds = TextUtils.drawRotatedString(tickLabel, g2, 
/*  874 */           (float)perpLine.getX2(), (float)perpLine.getY2(), textAnchor, perpTheta, textAnchor);
/*      */       
/*  876 */       if (hinting) {
/*  877 */         g2.setRenderingHint((RenderingHints.Key)Chart3DHints.KEY_END_ELEMENT, Boolean.valueOf(true));
/*      */       }
/*  879 */       if (info != null) {
/*  880 */         RenderedElement tickLabelElement = new RenderedElement(InteractiveElementType.CATEGORY_AXIS_TICK_LABEL, bounds);
/*      */         
/*  882 */         tickLabelElement.setProperty("label", tickLabel);
/*  883 */         tickLabelElement.setProperty("axis", axisStr());
/*  884 */         info.addOffsetElement(tickLabelElement);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<TickData> generateTickDataForRows(CategoryDataset3D dataset) {
/*  904 */     ArgChecks.nullNotPermitted(dataset, "dataset");
/*  905 */     List<TickData> result = new ArrayList<TickData>(this.categories.size());
/*  906 */     for (Comparable<?> key : this.categories) {
/*  907 */       double pos = this.range.percent(getCategoryValue(key));
/*  908 */       String label = this.tickLabelGenerator.generateRowLabel(dataset, key);
/*      */       
/*  910 */       result.add(new TickData(pos, key, label));
/*      */     } 
/*  912 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<TickData> generateTickDataForColumns(CategoryDataset3D dataset) {
/*  931 */     ArgChecks.nullNotPermitted(dataset, "dataset");
/*  932 */     List<TickData> result = new ArrayList<TickData>(this.categories.size());
/*  933 */     for (Comparable<?> key : this.categories) {
/*  934 */       double pos = this.range.percent(getCategoryValue(key));
/*  935 */       String label = this.tickLabelGenerator.generateColumnLabel(dataset, key);
/*      */       
/*  937 */       result.add(new TickData(pos, key, label));
/*      */     } 
/*  939 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<MarkerData> generateMarkerData() {
/*  949 */     List<MarkerData> result = new ArrayList<MarkerData>();
/*      */     
/*  951 */     for (Map.Entry<String, CategoryMarker> entry : this.markers.entrySet()) {
/*  952 */       MarkerData markerData; CategoryMarker cm = entry.getValue();
/*  953 */       if (cm == null) {
/*      */         continue;
/*      */       }
/*      */       
/*  957 */       if (cm.getType().equals(CategoryMarkerType.LINE)) {
/*  958 */         double pos = getCategoryValue(cm.getCategory());
/*  959 */         markerData = new MarkerData(entry.getKey(), pos);
/*  960 */         markerData.setLabelAnchor((cm.getLabel() != null) ? cm
/*  961 */             .getLabelAnchor() : null);
/*  962 */       } else if (cm.getType().equals(CategoryMarkerType.BAND)) {
/*  963 */         double pos = getCategoryValue(cm.getCategory());
/*  964 */         double width = getCategoryWidth();
/*  965 */         markerData = new MarkerData(entry.getKey(), pos - width / 2.0D, false, pos + width / 2.0D, false);
/*      */         
/*  967 */         markerData.setLabelAnchor((cm.getLabel() != null) ? cm
/*  968 */             .getLabelAnchor() : null);
/*      */       } else {
/*  970 */         throw new RuntimeException("Unrecognised marker: " + cm
/*  971 */             .getType());
/*      */       } 
/*  973 */       result.add(markerData);
/*      */     } 
/*  975 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void receive(ChartElementVisitor visitor) {
/*  990 */     for (Marker marker : this.markers.values()) {
/*  991 */       marker.receive(visitor);
/*      */     }
/*  993 */     visitor.visit(this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean equals(Object obj) {
/* 1005 */     if (obj == this) {
/* 1006 */       return true;
/*      */     }
/* 1008 */     if (!(obj instanceof StandardCategoryAxis3D)) {
/* 1009 */       return false;
/*      */     }
/* 1011 */     StandardCategoryAxis3D that = (StandardCategoryAxis3D)obj;
/* 1012 */     if (this.lowerMargin != that.lowerMargin) {
/* 1013 */       return false;
/*      */     }
/* 1015 */     if (this.upperMargin != that.upperMargin) {
/* 1016 */       return false;
/*      */     }
/* 1018 */     if (this.firstCategoryHalfWidth != that.firstCategoryHalfWidth) {
/* 1019 */       return false;
/*      */     }
/* 1021 */     if (this.lastCategoryHalfWidth != that.lastCategoryHalfWidth) {
/* 1022 */       return false;
/*      */     }
/* 1024 */     if (this.tickMarkLength != that.tickMarkLength) {
/* 1025 */       return false;
/*      */     }
/* 1027 */     if (!ObjectUtils.equalsPaint(this.tickMarkPaint, that.tickMarkPaint)) {
/* 1028 */       return false;
/*      */     }
/* 1030 */     if (!this.tickMarkStroke.equals(that.tickMarkStroke)) {
/* 1031 */       return false;
/*      */     }
/* 1033 */     if (!this.tickLabelGenerator.equals(that.tickLabelGenerator)) {
/* 1034 */       return false;
/*      */     }
/* 1036 */     if (this.tickLabelOffset != that.tickLabelOffset) {
/* 1037 */       return false;
/*      */     }
/* 1039 */     if (!this.tickLabelOrientation.equals(that.tickLabelOrientation)) {
/* 1040 */       return false;
/*      */     }
/* 1042 */     if (this.tickLabelFactor != that.tickLabelFactor) {
/* 1043 */       return false;
/*      */     }
/* 1045 */     if (this.maxTickLabelLevels != that.maxTickLabelLevels) {
/* 1046 */       return false;
/*      */     }
/* 1048 */     if (!this.markers.equals(that.markers)) {
/* 1049 */       return false;
/*      */     }
/* 1051 */     return super.equals(obj);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void writeObject(ObjectOutputStream stream) throws IOException {
/* 1062 */     stream.defaultWriteObject();
/* 1063 */     SerialUtils.writePaint(this.tickMarkPaint, stream);
/* 1064 */     SerialUtils.writeStroke(this.tickMarkStroke, stream);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void readObject(ObjectInputStream stream) throws IOException, ClassNotFoundException {
/* 1077 */     stream.defaultReadObject();
/* 1078 */     this.tickMarkPaint = SerialUtils.readPaint(stream);
/* 1079 */     this.tickMarkStroke = SerialUtils.readStroke(stream);
/*      */   }
/*      */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/axis/StandardCategoryAxis3D.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */