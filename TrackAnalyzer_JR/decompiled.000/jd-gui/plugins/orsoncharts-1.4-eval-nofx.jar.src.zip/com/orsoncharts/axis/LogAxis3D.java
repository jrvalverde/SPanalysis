/*     */ package com.orsoncharts.axis;
/*     */ 
/*     */ import com.orsoncharts.Chart3DHints;
/*     */ import com.orsoncharts.Range;
/*     */ import com.orsoncharts.graphics3d.RenderingInfo;
/*     */ import com.orsoncharts.graphics3d.Utils2D;
/*     */ import com.orsoncharts.util.ArgChecks;
/*     */ import com.orsoncharts.util.ObjectUtils;
/*     */ import com.orsoncharts.util.TextAnchor;
/*     */ import com.orsoncharts.util.TextUtils;
/*     */ import java.awt.FontMetrics;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.RenderingHints;
/*     */ import java.awt.Shape;
/*     */ import java.awt.font.TextAttribute;
/*     */ import java.awt.font.TextLayout;
/*     */ import java.awt.geom.Line2D;
/*     */ import java.awt.geom.Point2D;
/*     */ import java.awt.geom.Rectangle2D;
/*     */ import java.text.AttributedString;
/*     */ import java.text.DecimalFormat;
/*     */ import java.text.Format;
/*     */ import java.text.NumberFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LogAxis3D
/*     */   extends AbstractValueAxis3D
/*     */   implements ValueAxis3D
/*     */ {
/*     */   public static final double DEFAULT_SMALLEST_VALUE = 1.0E-100D;
/*  57 */   private double base = 10.0D;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private double baseLog;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Range logRange;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private double smallestValue;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String baseSymbol;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  84 */   private NumberFormat baseFormatter = new DecimalFormat("0");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  90 */   private TickSelector tickSelector = new NumberTickSelector();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  96 */   private double tickSize = 1.0D;
/*     */ 
/*     */   
/*  99 */   private Format tickLabelFormatter = new DecimalFormat("0.0");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LogAxis3D(String label) {
/* 107 */     super(label, new Range(1.0E-100D, 1.0D));
/* 108 */     this.base = 10.0D;
/* 109 */     this.baseLog = Math.log(this.base);
/* 110 */     this
/* 111 */       .logRange = new Range(calculateLog(1.0E-100D), calculateLog(1.0D));
/* 112 */     this.smallestValue = 1.0E-100D;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getBase() {
/* 121 */     return this.base;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBase(double base) {
/* 131 */     this.base = base;
/* 132 */     this.baseLog = Math.log(base);
/* 133 */     fireChangeEvent(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getBaseSymbol() {
/* 145 */     return this.baseSymbol;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBaseSymbol(String symbol) {
/* 156 */     this.baseSymbol = symbol;
/* 157 */     fireChangeEvent(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NumberFormat getBaseFormatter() {
/* 167 */     return this.baseFormatter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBaseFormatter(NumberFormat formatter) {
/* 177 */     ArgChecks.nullNotPermitted(formatter, "formatter");
/* 178 */     this.baseFormatter = formatter;
/* 179 */     fireChangeEvent(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getSmallestValue() {
/* 190 */     return this.smallestValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSmallestValue(double smallestValue) {
/* 200 */     ArgChecks.positiveRequired(smallestValue, "smallestValue");
/* 201 */     this.smallestValue = smallestValue;
/* 202 */     fireChangeEvent(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TickSelector getTickSelector() {
/* 211 */     return this.tickSelector;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTickSelector(TickSelector selector) {
/* 221 */     this.tickSelector = selector;
/* 222 */     fireChangeEvent(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getTickSize() {
/* 232 */     return this.tickSize;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTickSize(double tickSize) {
/* 241 */     this.tickSize = tickSize;
/* 242 */     fireChangeEvent(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Format getTickLabelFormatter() {
/* 252 */     return this.tickLabelFormatter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTickLabelFormatter(Format formatter) {
/* 262 */     ArgChecks.nullNotPermitted(formatter, "formatter");
/* 263 */     this.tickLabelFormatter = formatter;
/* 264 */     fireChangeEvent(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRange(Range range) {
/* 276 */     ArgChecks.nullNotPermitted(range, "range");
/* 277 */     this
/* 278 */       .range = new Range(Math.max(range.getMin(), this.smallestValue), range.getMax());
/* 279 */     this
/* 280 */       .logRange = new Range(calculateLog(this.range.getMin()), calculateLog(this.range.getMax()));
/* 281 */     fireChangeEvent(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRange(double min, double max) {
/* 294 */     ArgChecks.negativeNotPermitted(min, "min");
/* 295 */     this.range = new Range(Math.max(min, this.smallestValue), max);
/* 296 */     this
/* 297 */       .logRange = new Range(calculateLog(this.range.getMin()), calculateLog(this.range.getMax()));
/* 298 */     fireChangeEvent(true);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void updateRange(Range range) {
/* 303 */     this.range = range;
/* 304 */     this
/* 305 */       .logRange = new Range(calculateLog(this.range.getMin()), calculateLog(this.range.getMax()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final double calculateLog(double value) {
/* 320 */     return Math.log(value) / this.baseLog;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final double calculateValue(double log) {
/* 334 */     return Math.pow(this.base, log);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double translateToWorld(double value, double length) {
/* 348 */     double logv = calculateLog(value);
/* 349 */     double percent = this.logRange.percent(logv);
/* 350 */     return percent * length;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void draw(Graphics2D g2, Point2D startPt, Point2D endPt, Point2D opposingPt, List<TickData> tickData, RenderingInfo info, boolean hinting) {
/* 372 */     if (!isVisible()) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 377 */     g2.setStroke(getLineStroke());
/* 378 */     g2.setPaint(getLineColor());
/* 379 */     Line2D axisLine = new Line2D.Float(startPt, endPt);
/* 380 */     g2.draw(axisLine);
/*     */ 
/*     */     
/* 383 */     double tickMarkLength = getTickMarkLength();
/* 384 */     double tickLabelOffset = getTickLabelOffset();
/* 385 */     g2.setPaint(getTickMarkPaint());
/* 386 */     g2.setStroke(getTickMarkStroke());
/* 387 */     for (TickData t : tickData) {
/* 388 */       if (tickMarkLength > 0.0D) {
/* 389 */         Line2D tickLine = Utils2D.createPerpendicularLine(axisLine, t
/* 390 */             .getAnchorPt(), tickMarkLength, opposingPt);
/* 391 */         g2.draw(tickLine);
/*     */       } 
/*     */     } 
/*     */     
/* 395 */     double maxTickLabelDim = 0.0D;
/* 396 */     if (getTickLabelsVisible()) {
/* 397 */       g2.setFont(getTickLabelFont());
/* 398 */       g2.setPaint(getTickLabelColor());
/* 399 */       LabelOrientation orientation = getTickLabelOrientation();
/* 400 */       if (orientation.equals(LabelOrientation.PERPENDICULAR)) {
/* 401 */         maxTickLabelDim = drawPerpendicularTickLabels(g2, axisLine, opposingPt, tickData, hinting);
/*     */       }
/* 403 */       else if (orientation.equals(LabelOrientation.PARALLEL)) {
/* 404 */         maxTickLabelDim = g2.getFontMetrics().getHeight();
/* 405 */         double adj = (g2.getFontMetrics().getAscent() / 2);
/* 406 */         drawParallelTickLabels(g2, axisLine, opposingPt, tickData, adj, hinting);
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 412 */     if (getLabel() != null) {
/* 413 */       Shape labelBounds = drawAxisLabel(getLabel(), g2, axisLine, opposingPt, maxTickLabelDim + tickMarkLength + tickLabelOffset + 
/*     */           
/* 415 */           getLabelOffset(), info, hinting);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private double drawPerpendicularTickLabels(Graphics2D g2, Line2D axisLine, Point2D opposingPt, List<TickData> tickData, boolean hinting) {
/* 421 */     double result = 0.0D;
/* 422 */     for (TickData t : tickData) {
/* 423 */       double theta = Utils2D.calculateTheta(axisLine);
/* 424 */       double thetaAdj = theta + 1.5707963267948966D;
/* 425 */       if (thetaAdj < -1.5707963267948966D) {
/* 426 */         thetaAdj += Math.PI;
/*     */       }
/* 428 */       if (thetaAdj > 1.5707963267948966D) {
/* 429 */         thetaAdj -= Math.PI;
/*     */       }
/* 431 */       Line2D perpLine = Utils2D.createPerpendicularLine(axisLine, t
/* 432 */           .getAnchorPt(), getTickMarkLength() + 
/* 433 */           getTickLabelOffset(), opposingPt);
/* 434 */       double perpTheta = Utils2D.calculateTheta(perpLine);
/* 435 */       TextAnchor textAnchor = TextAnchor.CENTER_LEFT;
/* 436 */       if (Math.abs(perpTheta) > 1.5707963267948966D) {
/* 437 */         textAnchor = TextAnchor.CENTER_RIGHT;
/*     */       }
/* 439 */       double logy = calculateLog(t.getDataValue());
/* 440 */       AttributedString as = createTickLabelAttributedString(logy, this.tickLabelFormatter);
/*     */       
/* 442 */       Rectangle2D nonRotatedBounds = new Rectangle2D.Double();
/* 443 */       if (hinting) {
/* 444 */         Map<Object, Object> m = new HashMap<Object, Object>();
/* 445 */         m.put("ref", "{\"type\": \"valueTickLabel\", \"axis\": " + 
/* 446 */             axisStr() + ", \"value\": \"" + t
/* 447 */             .getDataValue() + "\"}");
/* 448 */         g2.setRenderingHint((RenderingHints.Key)Chart3DHints.KEY_BEGIN_ELEMENT, m);
/*     */       } 
/* 450 */       TextUtils.drawRotatedString(as, g2, 
/* 451 */           (float)perpLine.getX2(), (float)perpLine.getY2(), textAnchor, thetaAdj, textAnchor, nonRotatedBounds);
/*     */       
/* 453 */       if (hinting) {
/* 454 */         g2.setRenderingHint((RenderingHints.Key)Chart3DHints.KEY_END_ELEMENT, Boolean.valueOf(true));
/*     */       }
/* 456 */       result = Math.max(result, nonRotatedBounds.getWidth());
/*     */     } 
/* 458 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void drawParallelTickLabels(Graphics2D g2, Line2D axisLine, Point2D opposingPt, List<TickData> tickData, double adj, boolean hinting) {
/* 465 */     for (TickData t : tickData) {
/* 466 */       double theta = Utils2D.calculateTheta(axisLine);
/* 467 */       TextAnchor anchor = TextAnchor.CENTER;
/* 468 */       if (theta < -1.5707963267948966D) {
/* 469 */         theta += Math.PI;
/* 470 */         anchor = TextAnchor.CENTER;
/*     */       } 
/* 472 */       if (theta > 1.5707963267948966D) {
/* 473 */         theta -= Math.PI;
/* 474 */         anchor = TextAnchor.CENTER;
/*     */       } 
/* 476 */       Line2D perpLine = Utils2D.createPerpendicularLine(axisLine, t
/* 477 */           .getAnchorPt(), getTickMarkLength() + 
/* 478 */           getTickLabelOffset() + adj, opposingPt);
/* 479 */       double logy = calculateLog(t.getDataValue());
/* 480 */       AttributedString as = createTickLabelAttributedString(logy, this.tickSelector
/* 481 */           .getCurrentTickLabelFormat());
/* 482 */       if (hinting) {
/* 483 */         Map<Object, Object> m = new HashMap<Object, Object>();
/* 484 */         m.put("ref", "{\"type\": \"valueTickLabel\", \"axis\": " + 
/* 485 */             axisStr() + ", \"value\": \"" + t
/* 486 */             .getDataValue() + "\"}");
/* 487 */         g2.setRenderingHint((RenderingHints.Key)Chart3DHints.KEY_BEGIN_ELEMENT, m);
/*     */       } 
/* 489 */       TextUtils.drawRotatedString(as, g2, 
/* 490 */           (float)perpLine.getX2(), (float)perpLine.getY2(), anchor, theta, anchor, null);
/*     */       
/* 492 */       if (hinting) {
/* 493 */         g2.setRenderingHint((RenderingHints.Key)Chart3DHints.KEY_END_ELEMENT, Boolean.valueOf(true));
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private AttributedString createTickLabelAttributedString(double logy, Format exponentFormatter) {
/* 500 */     String baseStr = this.baseSymbol;
/* 501 */     if (baseStr == null) {
/* 502 */       baseStr = this.baseFormatter.format(this.base);
/*     */     }
/* 504 */     String exponentStr = exponentFormatter.format(Double.valueOf(logy));
/* 505 */     AttributedString as = new AttributedString(baseStr + exponentStr);
/* 506 */     as.addAttributes((Map)getTickLabelFont().getAttributes(), 0, (baseStr + exponentStr)
/* 507 */         .length());
/* 508 */     as.addAttribute(TextAttribute.SUPERSCRIPT, TextAttribute.SUPERSCRIPT_SUPER, baseStr
/* 509 */         .length(), baseStr
/* 510 */         .length() + exponentStr.length());
/* 511 */     return as;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Range adjustedDataRange(Range range) {
/* 524 */     ArgChecks.nullNotPermitted(range, "range");
/* 525 */     double logmin = calculateLog(Math.max(range.getMin(), this.smallestValue));
/*     */     
/* 527 */     double logmax = calculateLog(range.getMax());
/* 528 */     double length = logmax - logmin;
/* 529 */     double lm = length * getLowerMargin();
/* 530 */     double um = length * getUpperMargin();
/* 531 */     double lowerBound = calculateValue(logmin - lm);
/* 532 */     double upperBound = calculateValue(logmax + um);
/* 533 */     return new Range(lowerBound, upperBound);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double selectTick(Graphics2D g2, Point2D pt0, Point2D pt1, Point2D opposingPt) {
/* 550 */     if (this.tickSelector == null) {
/* 551 */       return this.tickSize;
/*     */     }
/* 553 */     g2.setFont(getTickLabelFont());
/* 554 */     FontMetrics fm = g2.getFontMetrics();
/* 555 */     double length = pt0.distance(pt1);
/* 556 */     double rangeLength = this.logRange.getLength();
/*     */     
/* 558 */     LabelOrientation orientation = getTickLabelOrientation();
/* 559 */     if (orientation.equals(LabelOrientation.PERPENDICULAR)) {
/*     */ 
/*     */       
/* 562 */       int height = fm.getHeight();
/*     */ 
/*     */       
/* 565 */       int maxTicks = (int)(length / height * getTickLabelFactor());
/* 566 */       if (maxTicks > 2 && this.tickSelector != null) {
/* 567 */         this.tickSelector.select(rangeLength / 2.0D);
/*     */ 
/*     */ 
/*     */         
/* 571 */         int tickCount = (int)(rangeLength / this.tickSelector.getCurrentTickSize());
/* 572 */         while (tickCount < maxTicks) {
/* 573 */           this.tickSelector.previous();
/*     */           
/* 575 */           tickCount = (int)(rangeLength / this.tickSelector.getCurrentTickSize());
/*     */         } 
/* 577 */         this.tickSelector.next();
/* 578 */         this.tickSize = this.tickSelector.getCurrentTickSize();
/* 579 */         this
/* 580 */           .tickLabelFormatter = this.tickSelector.getCurrentTickLabelFormat();
/*     */       } else {
/* 582 */         this.tickSize = Double.NaN;
/*     */       } 
/* 584 */     } else if (orientation.equals(LabelOrientation.PARALLEL)) {
/*     */       
/* 586 */       this.tickSelector.select(rangeLength);
/* 587 */       boolean done = false;
/* 588 */       while (!done) {
/* 589 */         if (this.tickSelector.previous()) {
/*     */           
/* 591 */           AttributedString s0 = createTickLabelAttributedString(this.logRange
/* 592 */               .getMax() + this.logRange.getMin(), this.tickSelector
/* 593 */               .getCurrentTickLabelFormat());
/*     */           
/* 595 */           TextLayout layout0 = new TextLayout(s0.getIterator(), g2.getFontRenderContext());
/* 596 */           double w0 = layout0.getAdvance();
/* 597 */           AttributedString s1 = createTickLabelAttributedString(this.logRange
/* 598 */               .getMax() + this.logRange.getMin(), this.tickSelector
/* 599 */               .getCurrentTickLabelFormat());
/*     */           
/* 601 */           TextLayout layout1 = new TextLayout(s1.getIterator(), g2.getFontRenderContext());
/* 602 */           double w1 = layout1.getAdvance();
/* 603 */           double w = Math.max(w0, w1);
/* 604 */           int n = (int)(length / w * getTickLabelFactor());
/* 605 */           if (n < rangeLength / this.tickSelector
/* 606 */             .getCurrentTickSize()) {
/* 607 */             this.tickSelector.next();
/* 608 */             done = true;
/*     */           }  continue;
/*     */         } 
/* 611 */         done = true;
/*     */       } 
/*     */       
/* 614 */       this.tickSize = this.tickSelector.getCurrentTickSize();
/* 615 */       this
/* 616 */         .tickLabelFormatter = this.tickSelector.getCurrentTickLabelFormat();
/*     */     } 
/* 618 */     return this.tickSize;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<TickData> generateTickData(double tickUnit) {
/* 632 */     List<TickData> result = new ArrayList<TickData>();
/* 633 */     if (Double.isNaN(tickUnit)) {
/* 634 */       result.add(new TickData(0.0D, getRange().getMin()));
/* 635 */       result.add(new TickData(1.0D, getRange().getMax()));
/*     */     } else {
/*     */       
/* 638 */       double logx = tickUnit * Math.ceil(this.logRange.getMin() / tickUnit);
/* 639 */       while (logx <= this.logRange.getMax()) {
/* 640 */         result.add(new TickData(this.logRange.percent(logx), 
/* 641 */               calculateValue(logx)));
/* 642 */         logx += tickUnit;
/*     */       } 
/*     */     } 
/* 645 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 650 */     int hash = 5;
/*     */     
/* 652 */     hash = 59 * hash + (int)(Double.doubleToLongBits(this.base) ^ Double.doubleToLongBits(this.base) >>> 32L);
/*     */     
/* 654 */     hash = 59 * hash + (int)(Double.doubleToLongBits(this.smallestValue) ^ Double.doubleToLongBits(this.smallestValue) >>> 32L);
/* 655 */     hash = 59 * hash + ObjectUtils.hashCode(this.baseSymbol);
/* 656 */     hash = 59 * hash + ObjectUtils.hashCode(this.baseFormatter);
/* 657 */     hash = 59 * hash + ObjectUtils.hashCode(this.tickSelector);
/*     */     
/* 659 */     hash = 59 * hash + (int)(Double.doubleToLongBits(this.tickSize) ^ Double.doubleToLongBits(this.tickSize) >>> 32L);
/* 660 */     hash = 59 * hash + ObjectUtils.hashCode(this.tickLabelFormatter);
/* 661 */     return hash;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 666 */     if (obj == null) {
/* 667 */       return false;
/*     */     }
/* 669 */     if (getClass() != obj.getClass()) {
/* 670 */       return false;
/*     */     }
/* 672 */     LogAxis3D other = (LogAxis3D)obj;
/* 673 */     if (Double.doubleToLongBits(this.base) != 
/* 674 */       Double.doubleToLongBits(other.base)) {
/* 675 */       return false;
/*     */     }
/* 677 */     if (Double.doubleToLongBits(this.smallestValue) != 
/* 678 */       Double.doubleToLongBits(other.smallestValue)) {
/* 679 */       return false;
/*     */     }
/* 681 */     if (!ObjectUtils.equals(this.baseSymbol, other.baseSymbol)) {
/* 682 */       return false;
/*     */     }
/* 684 */     if (!ObjectUtils.equals(this.baseFormatter, other.baseFormatter)) {
/* 685 */       return false;
/*     */     }
/* 687 */     if (!ObjectUtils.equals(this.tickSelector, other.tickSelector)) {
/* 688 */       return false;
/*     */     }
/* 690 */     if (Double.doubleToLongBits(this.tickSize) != 
/* 691 */       Double.doubleToLongBits(other.tickSize)) {
/* 692 */       return false;
/*     */     }
/* 694 */     if (!ObjectUtils.equals(this.tickLabelFormatter, other.tickLabelFormatter))
/*     */     {
/* 696 */       return false;
/*     */     }
/* 698 */     return super.equals(obj);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/axis/LogAxis3D.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */