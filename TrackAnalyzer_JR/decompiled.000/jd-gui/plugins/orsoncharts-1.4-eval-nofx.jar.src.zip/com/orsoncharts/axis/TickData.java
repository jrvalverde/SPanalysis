/*     */ package com.orsoncharts.axis;
/*     */ 
/*     */ import com.orsoncharts.util.ArgChecks;
/*     */ import java.awt.geom.Point2D;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TickData
/*     */ {
/*     */   private double pos;
/*     */   private Comparable<?> key;
/*     */   private String keyLabel;
/*     */   private double dataValue;
/*     */   private int vertexIndex;
/*     */   private Point2D anchorPt;
/*     */   
/*     */   public TickData(double pos, Comparable<?> key, String keyLabel) {
/*  52 */     this.pos = pos;
/*  53 */     this.key = key;
/*  54 */     this.keyLabel = keyLabel;
/*  55 */     this.dataValue = Double.NaN;
/*  56 */     this.vertexIndex = -1;
/*  57 */     this.anchorPt = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TickData(double pos, double dataValue) {
/*  67 */     this.pos = pos;
/*  68 */     this.dataValue = dataValue;
/*  69 */     this.key = null;
/*  70 */     this.keyLabel = null;
/*  71 */     this.vertexIndex = -1;
/*  72 */     this.anchorPt = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TickData(TickData source, int vertexIndex) {
/*  83 */     ArgChecks.nullNotPermitted(source, "source");
/*  84 */     this.pos = source.pos;
/*  85 */     this.dataValue = source.dataValue;
/*  86 */     this.key = source.key;
/*  87 */     this.keyLabel = source.keyLabel;
/*  88 */     this.anchorPt = source.anchorPt;
/*  89 */     this.vertexIndex = vertexIndex;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getPos() {
/*  99 */     return this.pos;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Comparable<?> getKey() {
/* 109 */     return this.key;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getKeyLabel() {
/* 120 */     return this.keyLabel;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getDataValue() {
/* 130 */     return this.dataValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getVertexIndex() {
/* 139 */     return this.vertexIndex;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setVertexIndex(int index) {
/* 150 */     this.vertexIndex = index;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Point2D getAnchorPt() {
/* 159 */     return this.anchorPt;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAnchorPt(Point2D anchorPt) {
/* 169 */     this.anchorPt = anchorPt;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/axis/TickData.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */