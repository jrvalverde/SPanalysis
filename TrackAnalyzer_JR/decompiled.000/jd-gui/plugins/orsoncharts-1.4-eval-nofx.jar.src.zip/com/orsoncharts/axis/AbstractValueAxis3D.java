/*     */ package com.orsoncharts.axis;
/*     */ 
/*     */ import com.orsoncharts.ChartElementVisitor;
/*     */ import com.orsoncharts.Range;
/*     */ import com.orsoncharts.data.Values3D;
/*     */ import com.orsoncharts.data.category.CategoryDataset3D;
/*     */ import com.orsoncharts.marker.MarkerData;
/*     */ import com.orsoncharts.marker.NumberMarker;
/*     */ import com.orsoncharts.marker.RangeMarker;
/*     */ import com.orsoncharts.marker.ValueMarker;
/*     */ import com.orsoncharts.plot.CategoryPlot3D;
/*     */ import com.orsoncharts.plot.XYZPlot;
/*     */ import com.orsoncharts.util.ArgChecks;
/*     */ import com.orsoncharts.util.ObjectUtils;
/*     */ import com.orsoncharts.util.SerialUtils;
/*     */ import java.awt.BasicStroke;
/*     */ import java.awt.Color;
/*     */ import java.awt.Paint;
/*     */ import java.awt.Stroke;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractValueAxis3D
/*     */   extends AbstractAxis3D
/*     */   implements ValueAxis3D, Serializable
/*     */ {
/*     */   private ValueAxis3DType configuredType;
/*     */   protected Range range;
/*     */   private boolean autoAdjustRange;
/*     */   private double lowerMargin;
/*     */   private double upperMargin;
/*     */   private Range defaultAutoRange;
/*     */   private double minAutoRangeLength;
/*     */   private double tickLabelOffset;
/*     */   private double tickMarkLength;
/*     */   private transient Stroke tickMarkStroke;
/*     */   private transient Paint tickMarkPaint;
/*     */   private LabelOrientation tickLabelOrientation;
/*     */   private double tickLabelFactor;
/*     */   private Map<String, ValueMarker> valueMarkers;
/*     */   
/*     */   public AbstractValueAxis3D(String label, Range range) {
/* 111 */     super(label);
/* 112 */     ArgChecks.nullNotPermitted(range, "range");
/* 113 */     this.configuredType = null;
/* 114 */     this.range = range;
/* 115 */     this.autoAdjustRange = true;
/* 116 */     this.lowerMargin = 0.05D;
/* 117 */     this.upperMargin = 0.05D;
/* 118 */     this.defaultAutoRange = new Range(0.0D, 1.0D);
/* 119 */     this.minAutoRangeLength = 0.001D;
/* 120 */     this.tickLabelOffset = 5.0D;
/* 121 */     this.tickLabelOrientation = LabelOrientation.PARALLEL;
/* 122 */     this.tickLabelFactor = 1.4D;
/* 123 */     this.tickMarkLength = 3.0D;
/* 124 */     this.tickMarkStroke = new BasicStroke(0.5F);
/* 125 */     this.tickMarkPaint = Color.GRAY;
/* 126 */     this.valueMarkers = new LinkedHashMap<String, ValueMarker>();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ValueAxis3DType getConfiguredType() {
/* 139 */     return this.configuredType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String axisStr() {
/* 149 */     if (this.configuredType.equals(ValueAxis3DType.VALUE)) {
/* 150 */       return "value";
/*     */     }
/* 152 */     if (this.configuredType.equals(ValueAxis3DType.X)) {
/* 153 */       return "x";
/*     */     }
/* 155 */     if (this.configuredType.equals(ValueAxis3DType.Y)) {
/* 156 */       return "y";
/*     */     }
/* 158 */     if (this.configuredType.equals(ValueAxis3DType.Z)) {
/* 159 */       return "z";
/*     */     }
/* 161 */     return "";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Range getRange() {
/* 173 */     return this.range;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRange(Range range) {
/* 185 */     ArgChecks.nullNotPermitted(range, "range");
/* 186 */     if (range.getLength() <= 0.0D) {
/* 187 */       throw new IllegalArgumentException("Requires a range with length > 0");
/*     */     }
/*     */     
/* 190 */     this.range = range;
/* 191 */     this.autoAdjustRange = false;
/* 192 */     fireChangeEvent(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void updateRange(Range range) {
/* 202 */     this.range = range;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRange(double min, double max) {
/* 214 */     setRange(new Range(min, max));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isAutoAdjustRange() {
/* 225 */     return this.autoAdjustRange;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAutoAdjustRange(boolean autoAdjust) {
/* 236 */     this.autoAdjustRange = autoAdjust;
/* 237 */     fireChangeEvent(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getLowerMargin() {
/* 249 */     return this.lowerMargin;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLowerMargin(double margin) {
/* 263 */     this.lowerMargin = margin;
/* 264 */     fireChangeEvent(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getUpperMargin() {
/* 276 */     return this.upperMargin;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUpperMargin(double margin) {
/* 290 */     this.upperMargin = margin;
/* 291 */     fireChangeEvent(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Range getDefaultAutoRange() {
/* 306 */     return this.defaultAutoRange;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDefaultAutoRange(Range range) {
/* 319 */     ArgChecks.nullNotPermitted(range, "range");
/* 320 */     this.defaultAutoRange = range;
/* 321 */     fireChangeEvent(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getMinAutoRangeLength() {
/* 333 */     return this.minAutoRangeLength;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMinAutoRangeLength(double length) {
/* 345 */     ArgChecks.positiveRequired(length, "length");
/* 346 */     this.minAutoRangeLength = length;
/* 347 */     fireChangeEvent((this.range.getLength() < length));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LabelOrientation getTickLabelOrientation() {
/* 359 */     return this.tickLabelOrientation;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTickLabelOrientation(LabelOrientation orientation) {
/* 373 */     ArgChecks.nullNotPermitted(orientation, "orientation");
/* 374 */     this.tickLabelOrientation = orientation;
/* 375 */     fireChangeEvent(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getTickLabelFactor() {
/* 386 */     return this.tickLabelFactor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTickLabelFactor(double factor) {
/* 397 */     this.tickLabelFactor = factor;
/* 398 */     fireChangeEvent(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getTickLabelOffset() {
/* 408 */     return this.tickLabelOffset;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTickLabelOffset(double offset) {
/* 418 */     this.tickLabelOffset = offset;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getTickMarkLength() {
/* 428 */     return this.tickMarkLength;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTickMarkLength(double length) {
/* 439 */     this.tickMarkLength = length;
/* 440 */     fireChangeEvent(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Stroke getTickMarkStroke() {
/* 450 */     return this.tickMarkStroke;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTickMarkStroke(Stroke stroke) {
/* 460 */     ArgChecks.nullNotPermitted(stroke, "stroke");
/* 461 */     this.tickMarkStroke = stroke;
/* 462 */     fireChangeEvent(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Paint getTickMarkPaint() {
/* 472 */     return this.tickMarkPaint;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTickMarkPaint(Paint paint) {
/* 482 */     ArgChecks.nullNotPermitted(paint, "paint");
/* 483 */     this.tickMarkPaint = paint;
/* 484 */     fireChangeEvent(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void configureAsValueAxis(CategoryPlot3D plot) {
/* 496 */     this.configuredType = ValueAxis3DType.VALUE;
/* 497 */     if (this.autoAdjustRange) {
/* 498 */       CategoryDataset3D dataset = plot.getDataset();
/* 499 */       Range valueRange = plot.getRenderer().findValueRange((Values3D)dataset);
/* 500 */       if (valueRange != null) {
/* 501 */         updateRange(adjustedDataRange(valueRange));
/*     */       } else {
/* 503 */         updateRange(this.defaultAutoRange);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void configureAsXAxis(XYZPlot plot) {
/* 517 */     this.configuredType = ValueAxis3DType.X;
/* 518 */     if (this.autoAdjustRange) {
/* 519 */       Range xRange = plot.getRenderer().findXRange(plot.getDataset());
/* 520 */       if (xRange != null) {
/* 521 */         updateRange(adjustedDataRange(xRange));
/*     */       } else {
/* 523 */         updateRange(this.defaultAutoRange);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void configureAsYAxis(XYZPlot plot) {
/* 537 */     this.configuredType = ValueAxis3DType.Y;
/* 538 */     if (this.autoAdjustRange) {
/* 539 */       Range yRange = plot.getRenderer().findYRange(plot.getDataset());
/* 540 */       if (yRange != null) {
/* 541 */         updateRange(adjustedDataRange(yRange));
/*     */       } else {
/* 543 */         updateRange(this.defaultAutoRange);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void configureAsZAxis(XYZPlot plot) {
/* 557 */     this.configuredType = ValueAxis3DType.Z;
/* 558 */     if (this.autoAdjustRange) {
/* 559 */       Range zRange = plot.getRenderer().findZRange(plot.getDataset());
/* 560 */       if (zRange != null) {
/* 561 */         updateRange(adjustedDataRange(zRange));
/*     */       } else {
/* 563 */         updateRange(this.defaultAutoRange);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract Range adjustedDataRange(Range paramRange);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ValueMarker getMarker(String key) {
/* 589 */     return this.valueMarkers.get(key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMarker(String key, ValueMarker marker) {
/* 605 */     ValueMarker existing = this.valueMarkers.get(key);
/* 606 */     if (existing != null) {
/* 607 */       existing.removeChangeListener(this);
/*     */     }
/* 609 */     this.valueMarkers.put(key, marker);
/* 610 */     marker.addChangeListener(this);
/* 611 */     fireChangeEvent(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, ValueMarker> getMarkers() {
/* 622 */     return new LinkedHashMap<String, ValueMarker>(this.valueMarkers);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<MarkerData> generateMarkerData() {
/* 632 */     List<MarkerData> result = new ArrayList<MarkerData>();
/* 633 */     Range range = getRange();
/*     */     
/* 635 */     for (Map.Entry<String, ValueMarker> entry : this.valueMarkers.entrySet()) {
/* 636 */       ValueMarker vm = entry.getValue();
/* 637 */       if (range.intersects(vm.getRange())) {
/*     */         MarkerData markerData;
/* 639 */         if (vm instanceof NumberMarker) {
/* 640 */           NumberMarker nm = (NumberMarker)vm;
/*     */           
/* 642 */           markerData = new MarkerData(entry.getKey(), range.percent(nm.getValue()));
/* 643 */           markerData.setLabelAnchor((nm.getLabel() != null) ? nm
/* 644 */               .getLabelAnchor() : null);
/* 645 */         } else if (vm instanceof RangeMarker) {
/* 646 */           RangeMarker rm = (RangeMarker)vm;
/* 647 */           double startValue = rm.getStart().getValue();
/* 648 */           boolean startPegged = false;
/* 649 */           if (!range.contains(startValue)) {
/* 650 */             startValue = range.peggedValue(startValue);
/* 651 */             startPegged = true;
/*     */           } 
/* 653 */           double startPos = range.percent(startValue);
/* 654 */           double endValue = rm.getEnd().getValue();
/* 655 */           boolean endPegged = false;
/* 656 */           if (!range.contains(endValue)) {
/* 657 */             endValue = range.peggedValue(endValue);
/* 658 */             endPegged = true;
/*     */           } 
/* 660 */           double endPos = range.percent(endValue);
/* 661 */           markerData = new MarkerData(entry.getKey(), startPos, startPegged, endPos, endPegged);
/*     */           
/* 663 */           markerData.setLabelAnchor((rm.getLabel() != null) ? rm
/* 664 */               .getLabelAnchor() : null);
/*     */         } else {
/* 666 */           throw new RuntimeException("Unrecognised marker.");
/*     */         } 
/* 668 */         result.add(markerData);
/*     */       } 
/*     */     } 
/* 671 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void receive(ChartElementVisitor visitor) {
/* 686 */     for (ValueMarker marker : this.valueMarkers.values()) {
/* 687 */       marker.receive(visitor);
/*     */     }
/* 689 */     visitor.visit(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 694 */     if (obj == this) {
/* 695 */       return true;
/*     */     }
/* 697 */     if (!(obj instanceof AbstractValueAxis3D)) {
/* 698 */       return false;
/*     */     }
/* 700 */     AbstractValueAxis3D that = (AbstractValueAxis3D)obj;
/* 701 */     if (!this.range.equals(that.range)) {
/* 702 */       return false;
/*     */     }
/* 704 */     if (this.autoAdjustRange != that.autoAdjustRange) {
/* 705 */       return false;
/*     */     }
/* 707 */     if (this.lowerMargin != that.lowerMargin) {
/* 708 */       return false;
/*     */     }
/* 710 */     if (this.upperMargin != that.upperMargin) {
/* 711 */       return false;
/*     */     }
/* 713 */     if (!this.defaultAutoRange.equals(that.defaultAutoRange)) {
/* 714 */       return false;
/*     */     }
/* 716 */     if (this.tickLabelOffset != that.tickLabelOffset) {
/* 717 */       return false;
/*     */     }
/* 719 */     if (this.tickLabelFactor != that.tickLabelFactor) {
/* 720 */       return false;
/*     */     }
/* 722 */     if (!this.tickLabelOrientation.equals(that.tickLabelOrientation)) {
/* 723 */       return false;
/*     */     }
/* 725 */     if (this.tickMarkLength != that.tickMarkLength) {
/* 726 */       return false;
/*     */     }
/* 728 */     if (!ObjectUtils.equalsPaint(this.tickMarkPaint, that.tickMarkPaint)) {
/* 729 */       return false;
/*     */     }
/* 731 */     if (!this.tickMarkStroke.equals(that.tickMarkStroke)) {
/* 732 */       return false;
/*     */     }
/* 734 */     return super.equals(obj);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void writeObject(ObjectOutputStream stream) throws IOException {
/* 745 */     stream.defaultWriteObject();
/* 746 */     SerialUtils.writePaint(this.tickMarkPaint, stream);
/* 747 */     SerialUtils.writeStroke(this.tickMarkStroke, stream);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void readObject(ObjectInputStream stream) throws IOException, ClassNotFoundException {
/* 760 */     stream.defaultReadObject();
/* 761 */     this.tickMarkPaint = SerialUtils.readPaint(stream);
/* 762 */     this.tickMarkStroke = SerialUtils.readStroke(stream);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/axis/AbstractValueAxis3D.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */