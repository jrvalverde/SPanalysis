/*     */ package com.orsoncharts.axis;
/*     */ 
/*     */ import com.orsoncharts.Chart3DHints;
/*     */ import com.orsoncharts.ChartElementVisitor;
/*     */ import com.orsoncharts.graphics3d.RenderedElement;
/*     */ import com.orsoncharts.graphics3d.RenderingInfo;
/*     */ import com.orsoncharts.graphics3d.Utils2D;
/*     */ import com.orsoncharts.interaction.InteractiveElementType;
/*     */ import com.orsoncharts.marker.MarkerChangeEvent;
/*     */ import com.orsoncharts.marker.MarkerChangeListener;
/*     */ import com.orsoncharts.util.ArgChecks;
/*     */ import com.orsoncharts.util.ObjectUtils;
/*     */ import com.orsoncharts.util.SerialUtils;
/*     */ import com.orsoncharts.util.TextAnchor;
/*     */ import com.orsoncharts.util.TextUtils;
/*     */ import java.awt.BasicStroke;
/*     */ import java.awt.Color;
/*     */ import java.awt.Font;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.RenderingHints;
/*     */ import java.awt.Shape;
/*     */ import java.awt.Stroke;
/*     */ import java.awt.geom.Line2D;
/*     */ import java.awt.geom.Point2D;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.io.Serializable;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.swing.event.EventListenerList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractAxis3D
/*     */   implements Axis3D, MarkerChangeListener, Serializable
/*     */ {
/*  67 */   public static final Font DEFAULT_LABEL_FONT = new Font("Dialog", 1, 12);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  76 */   public static final Color DEFAULT_LABEL_COLOR = Color.BLACK;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final double DEFAULT_LABEL_OFFSET = 10.0D;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  91 */   public static final Font DEFAULT_TICK_LABEL_FONT = new Font("Dialog", 0, 12);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 100 */   public static final Color DEFAULT_TICK_LABEL_COLOR = Color.BLACK;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 107 */   public static final Stroke DEFAULT_LINE_STROKE = new BasicStroke(0.0F);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 114 */   public static final Color DEFAULT_LINE_COLOR = Color.GRAY;
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean visible;
/*     */ 
/*     */ 
/*     */   
/*     */   private String label;
/*     */ 
/*     */ 
/*     */   
/*     */   private Font labelFont;
/*     */ 
/*     */ 
/*     */   
/*     */   private Color labelColor;
/*     */ 
/*     */   
/*     */   private double labelOffset;
/*     */ 
/*     */   
/*     */   private transient Stroke lineStroke;
/*     */ 
/*     */   
/*     */   private Color lineColor;
/*     */ 
/*     */   
/*     */   private boolean tickLabelsVisible;
/*     */ 
/*     */   
/*     */   private Font tickLabelFont;
/*     */ 
/*     */   
/*     */   private Color tickLabelColor;
/*     */ 
/*     */   
/*     */   private final transient EventListenerList listenerList;
/*     */ 
/*     */ 
/*     */   
/*     */   public AbstractAxis3D(String label) {
/* 156 */     this.visible = true;
/* 157 */     this.label = label;
/* 158 */     this.labelFont = DEFAULT_LABEL_FONT;
/* 159 */     this.labelColor = DEFAULT_LABEL_COLOR;
/* 160 */     this.labelOffset = 10.0D;
/* 161 */     this.lineStroke = DEFAULT_LINE_STROKE;
/* 162 */     this.lineColor = DEFAULT_LINE_COLOR;
/* 163 */     this.tickLabelsVisible = true;
/* 164 */     this.tickLabelFont = DEFAULT_TICK_LABEL_FONT;
/* 165 */     this.tickLabelColor = DEFAULT_TICK_LABEL_COLOR;
/* 166 */     this.listenerList = new EventListenerList();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isVisible() {
/* 179 */     return this.visible;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setVisible(boolean visible) {
/* 192 */     this.visible = visible;
/* 193 */     fireChangeEvent(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getLabel() {
/* 202 */     return this.label;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLabel(String label) {
/* 213 */     this.label = label;
/* 214 */     fireChangeEvent(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Font getLabelFont() {
/* 225 */     return this.labelFont;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLabelFont(Font font) {
/* 236 */     ArgChecks.nullNotPermitted(font, "font");
/* 237 */     this.labelFont = font;
/* 238 */     fireChangeEvent(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Color getLabelColor() {
/* 249 */     return this.labelColor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLabelColor(Color color) {
/* 260 */     ArgChecks.nullNotPermitted(color, "color");
/* 261 */     this.labelColor = color;
/* 262 */     fireChangeEvent(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getLabelOffset() {
/* 273 */     return this.labelOffset;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLabelOffset(double offset) {
/* 285 */     this.labelOffset = offset;
/* 286 */     fireChangeEvent(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Stroke getLineStroke() {
/* 295 */     return this.lineStroke;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLineStroke(Stroke stroke) {
/* 305 */     ArgChecks.nullNotPermitted(stroke, "stroke");
/* 306 */     this.lineStroke = stroke;
/* 307 */     fireChangeEvent(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Color getLineColor() {
/* 316 */     return this.lineColor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLineColor(Color color) {
/* 326 */     ArgChecks.nullNotPermitted(color, "color");
/* 327 */     this.lineColor = color;
/* 328 */     fireChangeEvent(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getTickLabelsVisible() {
/* 338 */     return this.tickLabelsVisible;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTickLabelsVisible(boolean visible) {
/* 351 */     this.tickLabelsVisible = visible;
/* 352 */     fireChangeEvent(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Font getTickLabelFont() {
/* 362 */     return this.tickLabelFont;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTickLabelFont(Font font) {
/* 373 */     ArgChecks.nullNotPermitted(font, "font");
/* 374 */     this.tickLabelFont = font;
/* 375 */     fireChangeEvent(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Color getTickLabelColor() {
/* 386 */     return this.tickLabelColor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTickLabelColor(Color color) {
/* 397 */     ArgChecks.nullNotPermitted(color, "color");
/* 398 */     this.tickLabelColor = color;
/* 399 */     fireChangeEvent(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void receive(ChartElementVisitor paramChartElementVisitor);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Shape drawAxisLabel(String label, Graphics2D g2, Line2D axisLine, Point2D opposingPt, double offset, RenderingInfo info, boolean hinting) {
/* 432 */     ArgChecks.nullNotPermitted(label, "label");
/* 433 */     ArgChecks.nullNotPermitted(g2, "g2");
/* 434 */     ArgChecks.nullNotPermitted(axisLine, "axisLine");
/* 435 */     ArgChecks.nullNotPermitted(opposingPt, "opposingPt");
/* 436 */     g2.setFont(getLabelFont());
/* 437 */     g2.setPaint(getLabelColor());
/* 438 */     Line2D labelPosLine = Utils2D.createPerpendicularLine(axisLine, 0.5D, offset, opposingPt);
/*     */     
/* 440 */     double theta = Utils2D.calculateTheta(axisLine);
/* 441 */     if (theta < -1.5707963267948966D) {
/* 442 */       theta += Math.PI;
/*     */     }
/* 444 */     if (theta > 1.5707963267948966D) {
/* 445 */       theta -= Math.PI;
/*     */     }
/*     */     
/* 448 */     if (hinting) {
/* 449 */       Map<Object, Object> m = new HashMap<Object, Object>();
/* 450 */       m.put("ref", "{\"type\": \"axisLabel\", \"axis\": \"" + axisStr() + "\", \"label\": \"" + 
/* 451 */           getLabel() + "\"}");
/* 452 */       g2.setRenderingHint((RenderingHints.Key)Chart3DHints.KEY_BEGIN_ELEMENT, m);
/*     */     } 
/* 454 */     Shape bounds = TextUtils.drawRotatedString(getLabel(), g2, 
/* 455 */         (float)labelPosLine.getX2(), (float)labelPosLine.getY2(), TextAnchor.CENTER, theta, TextAnchor.CENTER);
/*     */     
/* 457 */     if (hinting) {
/* 458 */       g2.setRenderingHint((RenderingHints.Key)Chart3DHints.KEY_END_ELEMENT, Boolean.valueOf(true));
/*     */     }
/* 460 */     if (info != null) {
/* 461 */       RenderedElement labelElement = new RenderedElement(InteractiveElementType.AXIS_LABEL, bounds);
/*     */       
/* 463 */       labelElement.setProperty("axis", axisStr());
/* 464 */       labelElement.setProperty("label", getLabel());
/* 465 */       info.addOffsetElement(labelElement);
/*     */     } 
/* 467 */     return bounds;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract String axisStr();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void draw(Graphics2D paramGraphics2D, Point2D paramPoint2D1, Point2D paramPoint2D2, Point2D paramPoint2D3, List<TickData> paramList, RenderingInfo paramRenderingInfo, boolean paramBoolean);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 514 */     if (obj == this) {
/* 515 */       return true;
/*     */     }
/* 517 */     if (!(obj instanceof AbstractAxis3D)) {
/* 518 */       return false;
/*     */     }
/* 520 */     AbstractAxis3D that = (AbstractAxis3D)obj;
/* 521 */     if (this.visible != that.visible) {
/* 522 */       return false;
/*     */     }
/* 524 */     if (!ObjectUtils.equals(this.label, that.label)) {
/* 525 */       return false;
/*     */     }
/* 527 */     if (!this.labelFont.equals(that.labelFont)) {
/* 528 */       return false;
/*     */     }
/* 530 */     if (!this.labelColor.equals(that.labelColor)) {
/* 531 */       return false;
/*     */     }
/* 533 */     if (!this.lineStroke.equals(that.lineStroke)) {
/* 534 */       return false;
/*     */     }
/* 536 */     if (!this.lineColor.equals(that.lineColor)) {
/* 537 */       return false;
/*     */     }
/* 539 */     if (this.tickLabelsVisible != that.tickLabelsVisible) {
/* 540 */       return false;
/*     */     }
/* 542 */     if (!this.tickLabelFont.equals(that.tickLabelFont)) {
/* 543 */       return false;
/*     */     }
/* 545 */     if (!this.tickLabelColor.equals(that.tickLabelColor)) {
/* 546 */       return false;
/*     */     }
/* 548 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 558 */     int hash = 5;
/* 559 */     hash = 83 * hash + (this.visible ? 1 : 0);
/* 560 */     hash = 83 * hash + ObjectUtils.hashCode(this.label);
/* 561 */     hash = 83 * hash + ObjectUtils.hashCode(this.labelFont);
/* 562 */     hash = 83 * hash + ObjectUtils.hashCode(this.labelColor);
/* 563 */     hash = 83 * hash + ObjectUtils.hashCode(this.lineStroke);
/* 564 */     hash = 83 * hash + ObjectUtils.hashCode(this.lineColor);
/* 565 */     hash = 83 * hash + (this.tickLabelsVisible ? 1 : 0);
/* 566 */     hash = 83 * hash + ObjectUtils.hashCode(this.tickLabelFont);
/* 567 */     hash = 83 * hash + ObjectUtils.hashCode(this.tickLabelColor);
/* 568 */     return hash;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addChangeListener(Axis3DChangeListener listener) {
/* 578 */     this.listenerList.add(Axis3DChangeListener.class, listener);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeChangeListener(Axis3DChangeListener listener) {
/* 589 */     this.listenerList.remove(Axis3DChangeListener.class, listener);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void notifyListeners(Axis3DChangeEvent event) {
/* 598 */     Object[] listeners = this.listenerList.getListenerList();
/* 599 */     for (int i = listeners.length - 2; i >= 0; i -= 2) {
/* 600 */       if (listeners[i] == Axis3DChangeListener.class) {
/* 601 */         ((Axis3DChangeListener)listeners[i + 1]).axisChanged(event);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void fireChangeEvent(boolean requiresWorldUpdate) {
/* 613 */     notifyListeners(new Axis3DChangeEvent(this, requiresWorldUpdate));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void markerChanged(MarkerChangeEvent event) {
/* 628 */     fireChangeEvent(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void writeObject(ObjectOutputStream stream) throws IOException {
/* 639 */     stream.defaultWriteObject();
/* 640 */     SerialUtils.writeStroke(this.lineStroke, stream);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void readObject(ObjectInputStream stream) throws IOException, ClassNotFoundException {
/* 653 */     stream.defaultReadObject();
/* 654 */     this.lineStroke = SerialUtils.readStroke(stream);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/axis/AbstractAxis3D.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */