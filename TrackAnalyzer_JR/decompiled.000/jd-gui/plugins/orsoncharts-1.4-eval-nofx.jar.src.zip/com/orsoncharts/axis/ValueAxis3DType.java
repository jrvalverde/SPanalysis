/*    */ package com.orsoncharts.axis;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum ValueAxis3DType
/*    */ {
/* 27 */   VALUE,
/*    */ 
/*    */   
/* 30 */   X,
/*    */ 
/*    */   
/* 33 */   Y,
/*    */ 
/*    */   
/* 36 */   Z;
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/axis/ValueAxis3DType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */