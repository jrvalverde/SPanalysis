package com.orsoncharts.legend;

import com.orsoncharts.plot.Plot3D;
import com.orsoncharts.style.ChartStyle;
import com.orsoncharts.table.TableElement;
import com.orsoncharts.util.Anchor2D;
import com.orsoncharts.util.Orientation;

public interface LegendBuilder {
  TableElement createLegend(Plot3D paramPlot3D, Anchor2D paramAnchor2D, Orientation paramOrientation, ChartStyle paramChartStyle);
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/legend/LegendBuilder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */