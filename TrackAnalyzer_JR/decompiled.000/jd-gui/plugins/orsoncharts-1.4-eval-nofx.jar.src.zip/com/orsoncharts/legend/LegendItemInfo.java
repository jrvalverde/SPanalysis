package com.orsoncharts.legend;

import java.awt.Color;
import java.awt.Shape;
import java.util.Map;

public interface LegendItemInfo {
  Comparable<?> getSeriesKey();
  
  String getLabel();
  
  String getDescription();
  
  Shape getShape();
  
  Color getColor();
  
  Map<Comparable<?>, Object> getProperties();
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/legend/LegendItemInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */