/*     */ package com.orsoncharts.legend;
/*     */ 
/*     */ import com.orsoncharts.util.ArgChecks;
/*     */ import java.awt.Color;
/*     */ import java.awt.Shape;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StandardLegendItemInfo
/*     */   implements LegendItemInfo
/*     */ {
/*     */   private Comparable<?> seriesKey;
/*     */   private String label;
/*     */   private String description;
/*     */   private Color color;
/*     */   private Shape shape;
/*     */   private Map<Comparable<?>, Object> properties;
/*     */   
/*     */   public StandardLegendItemInfo(Comparable<?> seriesKey, String label, Color color) {
/*  53 */     this(seriesKey, label, null, color, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StandardLegendItemInfo(Comparable<?> seriesKey, String label, String description, Color color, Shape shape) {
/*  67 */     ArgChecks.nullNotPermitted(seriesKey, "seriesKey");
/*  68 */     ArgChecks.nullNotPermitted(label, "label");
/*  69 */     ArgChecks.nullNotPermitted(color, "color");
/*  70 */     this.seriesKey = seriesKey;
/*  71 */     this.label = label;
/*  72 */     this.description = description;
/*  73 */     this.color = color;
/*  74 */     this.shape = shape;
/*  75 */     this.properties = new HashMap<Comparable<?>, Object>();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Comparable<?> getSeriesKey() {
/*  85 */     return this.seriesKey;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getLabel() {
/*  95 */     return this.label;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDescription() {
/* 105 */     return this.description;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Shape getShape() {
/* 115 */     return this.shape;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Color getColor() {
/* 125 */     return this.color;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<Comparable<?>, Object> getProperties() {
/* 135 */     return this.properties;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/legend/StandardLegendItemInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */