/*     */ package com.orsoncharts.legend;
/*     */ 
/*     */ import com.orsoncharts.interaction.InteractiveElementType;
/*     */ import com.orsoncharts.plot.Plot3D;
/*     */ import com.orsoncharts.style.ChartStyle;
/*     */ import com.orsoncharts.table.FlowElement;
/*     */ import com.orsoncharts.table.GridElement;
/*     */ import com.orsoncharts.table.HAlign;
/*     */ import com.orsoncharts.table.ShapeElement;
/*     */ import com.orsoncharts.table.TableElement;
/*     */ import com.orsoncharts.table.TextElement;
/*     */ import com.orsoncharts.table.VAlign;
/*     */ import com.orsoncharts.table.VerticalFlowElement;
/*     */ import com.orsoncharts.util.Anchor2D;
/*     */ import com.orsoncharts.util.ArgChecks;
/*     */ import com.orsoncharts.util.ObjectUtils;
/*     */ import com.orsoncharts.util.Orientation;
/*     */ import java.awt.Color;
/*     */ import java.awt.Font;
/*     */ import java.awt.Shape;
/*     */ import java.io.Serializable;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class StandardLegendBuilder
/*     */   implements LegendBuilder, Serializable
/*     */ {
/*     */   private String header;
/*     */   private HAlign headerAlignment;
/*     */   private String footer;
/*     */   private HAlign footerAlignment;
/*     */   private HAlign rowAlignment;
/*     */   private VAlign columnAlignment;
/*     */   
/*     */   public StandardLegendBuilder() {
/*  82 */     this(null, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StandardLegendBuilder(String header, String footer) {
/*  93 */     this.header = header;
/*  94 */     this.headerAlignment = HAlign.LEFT;
/*  95 */     this.footer = footer;
/*  96 */     this.footerAlignment = HAlign.RIGHT;
/*  97 */     this.rowAlignment = null;
/*  98 */     this.columnAlignment = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getHeader() {
/* 107 */     return this.header;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setHeader(String header) {
/* 116 */     this.header = header;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HAlign getHeaderAlignment() {
/* 125 */     return this.headerAlignment;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setHeaderAlignment(HAlign align) {
/* 134 */     ArgChecks.nullNotPermitted(align, "align");
/* 135 */     this.headerAlignment = align;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getFooter() {
/* 144 */     return this.footer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFooter(String footer) {
/* 153 */     this.footer = footer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HAlign getFooterAlignment() {
/* 162 */     return this.footerAlignment;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFooterAlignment(HAlign align) {
/* 171 */     ArgChecks.nullNotPermitted(align, "align");
/* 172 */     this.footerAlignment = align;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HAlign getRowAlignment() {
/* 186 */     return this.rowAlignment;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRowAlignment(HAlign alignment) {
/* 200 */     this.rowAlignment = alignment;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public VAlign getColumnAlignment() {
/* 214 */     return this.columnAlignment;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setColumnAlignment(VAlign alignment) {
/* 228 */     this.columnAlignment = alignment;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TableElement createLegend(Plot3D plot, Anchor2D anchor, Orientation orientation, ChartStyle style) {
/* 254 */     TableElement legend = createSimpleLegend(plot.getLegendInfo(), anchor, orientation, style);
/*     */     
/* 256 */     if (this.header != null || this.footer != null) {
/* 257 */       GridElement compositeLegend = new GridElement();
/* 258 */       compositeLegend.setBackground(null);
/* 259 */       if (this.header != null) {
/*     */         
/* 261 */         TextElement he = new TextElement(this.header, style.getLegendHeaderFont());
/* 262 */         he.setHorizontalAligment(this.headerAlignment);
/* 263 */         he.setBackgroundColor(style.getLegendHeaderBackgroundColor());
/* 264 */         compositeLegend.setElement((TableElement)he, "R0", "C1");
/*     */       } 
/* 266 */       compositeLegend.setElement(legend, "R1", "C1");
/* 267 */       if (this.footer != null) {
/*     */         
/* 269 */         TextElement fe = new TextElement(this.footer, style.getLegendFooterFont());
/* 270 */         fe.setHorizontalAligment(this.footerAlignment);
/* 271 */         fe.setBackgroundColor(style.getLegendFooterBackgroundColor());
/* 272 */         compositeLegend.setElement((TableElement)fe, "R2", "C1");
/*     */       } 
/* 274 */       return (TableElement)compositeLegend;
/*     */     } 
/* 276 */     return legend;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private TableElement createSimpleLegend(List<LegendItemInfo> items, Anchor2D anchor, Orientation orientation, ChartStyle style) {
/*     */     VerticalFlowElement verticalFlowElement;
/* 294 */     ArgChecks.nullNotPermitted(items, "items");
/* 295 */     ArgChecks.nullNotPermitted(orientation, "orientation");
/*     */     
/* 297 */     if (orientation == Orientation.HORIZONTAL) {
/* 298 */       FlowElement fe = new FlowElement(horizontalAlignment(anchor), 2);
/* 299 */       fe.setRefPoint(anchor.getRefPt());
/* 300 */       FlowElement flowElement1 = fe;
/*     */     } else {
/*     */       
/* 303 */       VerticalFlowElement vfe = new VerticalFlowElement(verticalAlignment(anchor), 2);
/* 304 */       vfe.setRefPoint(anchor.getRefPt());
/* 305 */       verticalFlowElement = vfe;
/*     */     } 
/* 307 */     for (LegendItemInfo item : items) {
/* 308 */       Shape shape = item.getShape();
/* 309 */       if (shape == null) {
/* 310 */         shape = style.getLegendItemShape();
/*     */       }
/* 312 */       TableElement legendItem = createLegendItem(item.getLabel(), style
/* 313 */           .getLegendItemFont(), style.getLegendItemColor(), shape, item
/* 314 */           .getColor(), style
/* 315 */           .getLegendItemBackgroundColor());
/* 316 */       legendItem.setProperty("class", InteractiveElementType.LEGEND_ITEM);
/*     */       
/* 318 */       legendItem.setProperty("series_key", item.getSeriesKey());
/* 319 */       verticalFlowElement.addElement(legendItem);
/*     */     } 
/* 321 */     return (TableElement)verticalFlowElement;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private HAlign horizontalAlignment(Anchor2D anchor) {
/* 332 */     if (this.rowAlignment != null) {
/* 333 */       return this.rowAlignment;
/*     */     }
/* 335 */     if (anchor.getRefPt().isLeft()) {
/* 336 */       return HAlign.LEFT;
/*     */     }
/* 338 */     if (anchor.getRefPt().isRight()) {
/* 339 */       return HAlign.RIGHT;
/*     */     }
/* 341 */     return HAlign.CENTER;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private VAlign verticalAlignment(Anchor2D anchor) {
/* 352 */     if (this.columnAlignment != null) {
/* 353 */       return this.columnAlignment;
/*     */     }
/* 355 */     if (anchor.getRefPt().isTop()) {
/* 356 */       return VAlign.TOP;
/*     */     }
/* 358 */     if (anchor.getRefPt().isBottom()) {
/* 359 */       return VAlign.BOTTOM;
/*     */     }
/* 361 */     return VAlign.MIDDLE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private TableElement createLegendItem(String text, Font font, Color textColor, Shape shape, Color shapeColor, Color background) {
/* 381 */     ShapeElement se = new ShapeElement(shape, shapeColor);
/* 382 */     se.setBackgroundColor(background);
/* 383 */     TextElement te = new TextElement(text, font);
/* 384 */     te.setColor(textColor);
/* 385 */     te.setBackgroundColor(background);
/* 386 */     GridElement ge = new GridElement();
/* 387 */     ge.setElement((TableElement)se, "R1", "C1");
/* 388 */     ge.setElement((TableElement)te, "R1", "C2");
/* 389 */     return (TableElement)ge;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 401 */     if (obj == this) {
/* 402 */       return true;
/*     */     }
/* 404 */     if (!(obj instanceof StandardLegendBuilder)) {
/* 405 */       return false;
/*     */     }
/* 407 */     StandardLegendBuilder that = (StandardLegendBuilder)obj;
/* 408 */     if (!ObjectUtils.equals(this.header, that.header)) {
/* 409 */       return false;
/*     */     }
/* 411 */     if (this.headerAlignment != that.headerAlignment) {
/* 412 */       return false;
/*     */     }
/* 414 */     if (!ObjectUtils.equals(this.footer, that.footer)) {
/* 415 */       return false;
/*     */     }
/* 417 */     if (this.footerAlignment != that.footerAlignment) {
/* 418 */       return false;
/*     */     }
/* 420 */     return true;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/legend/StandardLegendBuilder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */