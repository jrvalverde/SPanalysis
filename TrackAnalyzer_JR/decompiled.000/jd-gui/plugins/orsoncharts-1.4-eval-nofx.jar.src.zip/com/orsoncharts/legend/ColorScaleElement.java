/*     */ package com.orsoncharts.legend;
/*     */ 
/*     */ import com.orsoncharts.Range;
/*     */ import com.orsoncharts.renderer.ColorScale;
/*     */ import com.orsoncharts.table.AbstractTableElement;
/*     */ import com.orsoncharts.table.ElementDimension;
/*     */ import com.orsoncharts.table.TableElement;
/*     */ import com.orsoncharts.table.TableElementOnDraw;
/*     */ import com.orsoncharts.table.TableElementVisitor;
/*     */ import com.orsoncharts.util.ArgChecks;
/*     */ import com.orsoncharts.util.Fit2D;
/*     */ import com.orsoncharts.util.Orientation;
/*     */ import com.orsoncharts.util.TextAnchor;
/*     */ import com.orsoncharts.util.TextUtils;
/*     */ import java.awt.BasicStroke;
/*     */ import java.awt.Color;
/*     */ import java.awt.Font;
/*     */ import java.awt.FontMetrics;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.Insets;
/*     */ import java.awt.Shape;
/*     */ import java.awt.geom.Dimension2D;
/*     */ import java.awt.geom.Rectangle2D;
/*     */ import java.text.DecimalFormat;
/*     */ import java.text.NumberFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ColorScaleElement
/*     */   extends AbstractTableElement
/*     */   implements TableElement
/*     */ {
/*     */   private ColorScale scale;
/*     */   private Orientation orientation;
/*     */   private double barLength;
/*     */   private double barWidth;
/*     */   private double textOffset;
/*     */   private Font font;
/*     */   private Color textColor;
/*     */   private NumberFormat formatter;
/*     */   
/*     */   public ColorScaleElement(ColorScale scale, Orientation orientation, double barWidth, double barLength, Font font, Color textColor) {
/*  96 */     ArgChecks.nullNotPermitted(scale, "scale");
/*  97 */     ArgChecks.nullNotPermitted(orientation, "orientation");
/*  98 */     ArgChecks.nullNotPermitted(font, "font");
/*  99 */     this.scale = scale;
/* 100 */     this.orientation = orientation;
/* 101 */     this.barWidth = barWidth;
/* 102 */     this.barLength = barLength;
/* 103 */     this.textOffset = 2.0D;
/* 104 */     this.font = font;
/* 105 */     this.textColor = textColor;
/* 106 */     this.formatter = new DecimalFormat("0.00");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ColorScale getColorScale() {
/* 115 */     return this.scale;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Orientation getOrientation() {
/* 124 */     return this.orientation;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getBarWidth() {
/* 133 */     return this.barWidth;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getBarLength() {
/* 142 */     return this.barLength;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Font getFont() {
/* 151 */     return this.font;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Color getTextColor() {
/* 160 */     return this.textColor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void receive(TableElementVisitor visitor) {
/* 174 */     visitor.visit(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Dimension2D preferredSize(Graphics2D g2, Rectangle2D bounds) {
/* 187 */     return preferredSize(g2, bounds, (Map<String, Object>)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Dimension2D preferredSize(Graphics2D g2, Rectangle2D bounds, Map<String, Object> constraints) {
/*     */     double w, h;
/* 202 */     g2.setFont(this.font);
/* 203 */     FontMetrics fm = g2.getFontMetrics();
/* 204 */     Range r = this.scale.getRange();
/* 205 */     String minStr = this.formatter.format(r.getMin());
/* 206 */     String maxStr = this.formatter.format(r.getMax());
/* 207 */     Rectangle2D minStrBounds = TextUtils.getTextBounds(minStr, fm);
/* 208 */     Rectangle2D maxStrBounds = TextUtils.getTextBounds(maxStr, fm);
/* 209 */     double maxStrWidth = Math.max(minStrBounds.getWidth(), maxStrBounds
/* 210 */         .getWidth());
/* 211 */     Insets insets = getInsets();
/*     */     
/* 213 */     if (this.orientation == Orientation.HORIZONTAL) {
/* 214 */       w = Math.min(this.barLength + insets.left + insets.right, bounds
/* 215 */           .getWidth());
/* 216 */       h = Math.min(insets.top + this.barWidth + this.textOffset + minStrBounds
/* 217 */           .getHeight() + insets.bottom, bounds
/* 218 */           .getHeight());
/*     */     } else {
/* 220 */       w = Math.min(insets.left + this.barWidth + this.textOffset + maxStrWidth + insets.right, bounds
/* 221 */           .getWidth());
/* 222 */       h = Math.min(insets.top + this.barLength + this.textOffset + minStrBounds
/* 223 */           .getHeight() + insets.bottom, bounds
/* 224 */           .getHeight());
/*     */     } 
/*     */     
/* 227 */     return (Dimension2D)new ElementDimension(w, h);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Rectangle2D> layoutElements(Graphics2D g2, Rectangle2D bounds, Map<String, Object> constraints) {
/* 233 */     List<Rectangle2D> result = new ArrayList<Rectangle2D>(1);
/* 234 */     Dimension2D prefDim = preferredSize(g2, bounds);
/* 235 */     Fit2D fitter = Fit2D.getNoScalingFitter(getRefPoint());
/* 236 */     Rectangle2D dest = fitter.fit(prefDim, bounds);
/* 237 */     result.add(dest);
/* 238 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void draw(Graphics2D g2, Rectangle2D bounds) {
/* 249 */     draw(g2, bounds, (TableElementOnDraw)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void draw(Graphics2D g2, Rectangle2D bounds, TableElementOnDraw onDrawHandler) {
/* 266 */     if (onDrawHandler != null) {
/* 267 */       onDrawHandler.beforeDraw(this, g2, bounds);
/*     */     }
/*     */     
/* 270 */     Shape savedClip = g2.getClip();
/* 271 */     g2.clip(bounds);
/* 272 */     List<Rectangle2D> layoutInfo = layoutElements(g2, bounds, (Map<String, Object>)null);
/* 273 */     Rectangle2D dest = layoutInfo.get(0);
/* 274 */     if (getBackground() != null) {
/* 275 */       getBackground().fill(g2, dest);
/*     */     }
/* 277 */     g2.setFont(this.font);
/* 278 */     FontMetrics fm = g2.getFontMetrics();
/* 279 */     Range r = this.scale.getRange();
/* 280 */     String minStr = this.formatter.format(r.getMin());
/* 281 */     String maxStr = this.formatter.format(r.getMax());
/* 282 */     Rectangle2D minStrBounds = TextUtils.getTextBounds(minStr, fm);
/* 283 */     Rectangle2D maxStrBounds = TextUtils.getTextBounds(maxStr, fm);
/* 284 */     Insets insets = getInsets();
/* 285 */     if (this.orientation == Orientation.HORIZONTAL) {
/*     */       
/* 287 */       double x0 = dest.getX() + insets.left + minStrBounds.getWidth() / 2.0D;
/*     */       
/* 289 */       double x1 = dest.getMaxX() - insets.right - maxStrBounds.getWidth() / 2.0D;
/* 290 */       double y0 = dest.getY() + insets.top;
/* 291 */       double y1 = y0 + this.barWidth;
/*     */       
/* 293 */       drawHorizontalScale(this.scale, g2, new Rectangle2D.Double((int)x0, (int)y0, (int)(x1 - x0), (int)this.barWidth));
/*     */ 
/*     */       
/* 296 */       g2.setPaint(this.textColor);
/* 297 */       TextUtils.drawAlignedString(minStr, g2, (float)x0, (float)(y1 + this.textOffset), TextAnchor.TOP_CENTER);
/*     */       
/* 299 */       TextUtils.drawAlignedString(maxStr, g2, (float)x1, (float)(y1 + this.textOffset), TextAnchor.TOP_CENTER);
/*     */     }
/*     */     else {
/*     */       
/* 303 */       double maxStrWidth = Math.max(minStrBounds.getWidth(), maxStrBounds
/* 304 */           .getWidth());
/* 305 */       double x1 = dest.getMaxX() - insets.right - maxStrWidth - this.textOffset;
/*     */       
/* 307 */       double x0 = x1 - this.barWidth;
/*     */       
/* 309 */       double y0 = dest.getY() + insets.top + maxStrBounds.getHeight() / 2.0D;
/* 310 */       double y1 = y0 + this.barLength;
/*     */       
/* 312 */       drawVerticalScale(this.scale, g2, new Rectangle2D.Double((int)x0, (int)y0, (int)(x1 - x0), (int)this.barLength));
/*     */       
/* 314 */       g2.setPaint(this.textColor);
/* 315 */       TextUtils.drawAlignedString(minStr, g2, (float)(x1 + this.textOffset), (float)y1, TextAnchor.HALF_ASCENT_LEFT);
/*     */ 
/*     */       
/* 318 */       TextUtils.drawAlignedString(maxStr, g2, (float)(x1 + this.textOffset), (float)y0, TextAnchor.HALF_ASCENT_LEFT);
/*     */     } 
/*     */ 
/*     */     
/* 322 */     g2.setClip(savedClip);
/*     */     
/* 324 */     if (onDrawHandler != null) {
/* 325 */       onDrawHandler.afterDraw(this, g2, bounds);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void drawHorizontalScale(ColorScale colorScale, Graphics2D g2, Rectangle2D bounds) {
/* 338 */     g2.setStroke(new BasicStroke(1.0F));
/* 339 */     for (int x = (int)bounds.getX(); x < bounds.getMaxX(); x++) {
/* 340 */       double p = (x - bounds.getX()) / bounds.getWidth();
/* 341 */       double value = colorScale.getRange().value(p);
/* 342 */       g2.setColor(colorScale.valueToColor(value));
/* 343 */       g2.drawLine(x, (int)bounds.getMinY(), x, (int)bounds.getMaxY());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void drawVerticalScale(ColorScale colorScale, Graphics2D g2, Rectangle2D bounds) {
/* 356 */     g2.setStroke(new BasicStroke(1.0F));
/* 357 */     for (int y = (int)bounds.getY(); y < bounds.getMaxY(); y++) {
/* 358 */       double p = (y - bounds.getY()) / bounds.getHeight();
/* 359 */       double value = colorScale.getRange().value(1.0D - p);
/* 360 */       g2.setColor(this.scale.valueToColor(value));
/* 361 */       g2.drawLine((int)bounds.getX(), y, (int)bounds.getMaxX(), y);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 367 */     if (obj == this) {
/* 368 */       return true;
/*     */     }
/* 370 */     if (!(obj instanceof ColorScaleElement)) {
/* 371 */       return false;
/*     */     }
/* 373 */     ColorScaleElement that = (ColorScaleElement)obj;
/* 374 */     if (!this.scale.equals(that.scale)) {
/* 375 */       return false;
/*     */     }
/* 377 */     if (!this.orientation.equals(that.orientation)) {
/* 378 */       return false;
/*     */     }
/* 380 */     if (this.barLength != that.barLength) {
/* 381 */       return false;
/*     */     }
/* 383 */     if (this.barWidth != that.barWidth) {
/* 384 */       return false;
/*     */     }
/* 386 */     if (!this.font.equals(that.font)) {
/* 387 */       return false;
/*     */     }
/* 389 */     return super.equals(obj);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/legend/ColorScaleElement.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */