/*    */ package com.orsoncharts.legend;
/*    */ 
/*    */ import com.orsoncharts.TitleAnchor;
/*    */ import com.orsoncharts.util.Anchor2D;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class LegendAnchor
/*    */ {
/* 27 */   public static final Anchor2D TOP_LEFT = TitleAnchor.TOP_LEFT;
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 32 */   public static final Anchor2D TOP_RIGHT = TitleAnchor.TOP_RIGHT;
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 37 */   public static final Anchor2D TOP_CENTER = TitleAnchor.TOP_CENTER;
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 42 */   public static final Anchor2D CENTER_LEFT = TitleAnchor.CENTER_LEFT;
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 47 */   public static final Anchor2D CENTER_RIGHT = TitleAnchor.CENTER_RIGHT;
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 52 */   public static final Anchor2D BOTTOM_CENTER = TitleAnchor.BOTTOM_CENTER;
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 57 */   public static final Anchor2D BOTTOM_LEFT = TitleAnchor.BOTTOM_LEFT;
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 62 */   public static final Anchor2D BOTTOM_RIGHT = TitleAnchor.BOTTOM_RIGHT;
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/legend/LegendAnchor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */