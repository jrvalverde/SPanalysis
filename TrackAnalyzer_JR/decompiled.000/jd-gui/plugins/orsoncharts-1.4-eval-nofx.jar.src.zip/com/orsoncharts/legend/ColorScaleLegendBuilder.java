/*     */ package com.orsoncharts.legend;
/*     */ 
/*     */ import com.orsoncharts.plot.CategoryPlot3D;
/*     */ import com.orsoncharts.plot.Plot3D;
/*     */ import com.orsoncharts.plot.XYZPlot;
/*     */ import com.orsoncharts.renderer.ColorScale;
/*     */ import com.orsoncharts.renderer.ColorScaleRenderer;
/*     */ import com.orsoncharts.renderer.category.CategoryRenderer3D;
/*     */ import com.orsoncharts.renderer.xyz.XYZRenderer;
/*     */ import com.orsoncharts.style.ChartStyle;
/*     */ import com.orsoncharts.table.TableElement;
/*     */ import com.orsoncharts.util.Anchor2D;
/*     */ import com.orsoncharts.util.Orientation;
/*     */ import java.io.Serializable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ColorScaleLegendBuilder
/*     */   implements LegendBuilder, Serializable
/*     */ {
/*  64 */   private double barWidth = 16.0D;
/*  65 */   private double barLength = 140.0D;
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean ignoreFixedColorScale = true;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getBarWidth() {
/*  75 */     return this.barWidth;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBarWidth(double width) {
/*  84 */     this.barWidth = width;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getBarLength() {
/*  93 */     return this.barLength;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBarLength(double length) {
/* 102 */     this.barLength = length;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getIgnoreFixedColorScale() {
/* 112 */     return this.ignoreFixedColorScale;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setIgnoreFixedColorScale(boolean ignore) {
/* 122 */     this.ignoreFixedColorScale = ignore;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TableElement createLegend(Plot3D plot, Anchor2D anchor, Orientation orientation, ChartStyle style) {
/* 141 */     ColorScaleRenderer renderer = null;
/* 142 */     if (plot instanceof CategoryPlot3D) {
/* 143 */       CategoryRenderer3D r = ((CategoryPlot3D)plot).getRenderer();
/* 144 */       if (r instanceof ColorScaleRenderer) {
/* 145 */         renderer = (ColorScaleRenderer)r;
/*     */       }
/* 147 */     } else if (plot instanceof XYZPlot) {
/* 148 */       XYZRenderer r = ((XYZPlot)plot).getRenderer();
/* 149 */       if (r instanceof ColorScaleRenderer) {
/* 150 */         renderer = (ColorScaleRenderer)r;
/*     */       }
/*     */     } 
/* 153 */     if (renderer == null) {
/* 154 */       return null;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 160 */     if (this.ignoreFixedColorScale && renderer
/* 161 */       .getColorScale() instanceof com.orsoncharts.renderer.FixedColorScale) {
/* 162 */       return null;
/*     */     }
/* 164 */     return createColorScaleLegend(renderer, orientation, anchor, style);
/*     */   }
/*     */ 
/*     */   
/*     */   private TableElement createColorScaleLegend(ColorScaleRenderer r, Orientation orientation, Anchor2D anchor, ChartStyle style) {
/* 169 */     ColorScale scale = r.getColorScale();
/*     */ 
/*     */     
/* 172 */     ColorScaleElement element = new ColorScaleElement(scale, orientation, this.barWidth, this.barLength, style.getLegendItemFont(), style.getLegendItemColor());
/* 173 */     element.setBackgroundColor(style.getLegendItemBackgroundColor());
/* 174 */     element.setRefPoint(anchor.getRefPt());
/* 175 */     return element;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 187 */     if (obj == this) {
/* 188 */       return true;
/*     */     }
/* 190 */     if (!(obj instanceof ColorScaleLegendBuilder)) {
/* 191 */       return false;
/*     */     }
/* 193 */     ColorScaleLegendBuilder that = (ColorScaleLegendBuilder)obj;
/* 194 */     if (this.barWidth != that.barWidth) {
/* 195 */       return false;
/*     */     }
/* 197 */     if (this.barLength != that.barLength) {
/* 198 */       return false;
/*     */     }
/* 200 */     return true;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/legend/ColorScaleLegendBuilder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */