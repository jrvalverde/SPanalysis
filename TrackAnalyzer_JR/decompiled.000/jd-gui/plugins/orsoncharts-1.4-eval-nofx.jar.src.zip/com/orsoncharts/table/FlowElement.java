/*     */ package com.orsoncharts.table;
/*     */ 
/*     */ import com.orsoncharts.util.ArgChecks;
/*     */ import com.orsoncharts.util.Fit2D;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.Insets;
/*     */ import java.awt.Shape;
/*     */ import java.awt.geom.Dimension2D;
/*     */ import java.awt.geom.Rectangle2D;
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FlowElement
/*     */   extends AbstractTableElement
/*     */   implements ContainerElement, Serializable
/*     */ {
/*     */   private List<TableElement> elements;
/*     */   private HAlign horizontalAlignment;
/*     */   private int hgap;
/*     */   
/*     */   public FlowElement() {
/*  56 */     this(HAlign.CENTER, 2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FlowElement(HAlign alignment, int hgap) {
/*  70 */     ArgChecks.nullNotPermitted(alignment, "alignment");
/*  71 */     this.elements = new ArrayList<TableElement>();
/*  72 */     this.horizontalAlignment = alignment;
/*  73 */     this.hgap = hgap;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getHGap() {
/*  83 */     return this.hgap;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setHGap(int gap) {
/*  92 */     this.hgap = gap;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HAlign getHorizontalAlignment() {
/* 104 */     return this.horizontalAlignment;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setHorizontalAlignment(HAlign alignment) {
/* 115 */     ArgChecks.nullNotPermitted(alignment, "alignment");
/* 116 */     this.horizontalAlignment = alignment;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<TableElement> getElements() {
/* 126 */     return new ArrayList<TableElement>(this.elements);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addElement(TableElement element) {
/* 136 */     ArgChecks.nullNotPermitted(element, "element");
/* 137 */     this.elements.add(element);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void receive(TableElementVisitor visitor) {
/* 150 */     for (TableElement element : this.elements) {
/* 151 */       element.receive(visitor);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private List<ElementInfo> rowOfElements(int first, Graphics2D g2, Rectangle2D bounds) {
/* 166 */     List<ElementInfo> result = new ArrayList<ElementInfo>();
/* 167 */     int index = first;
/* 168 */     boolean full = false;
/* 169 */     double w = ((getInsets()).left + (getInsets()).right);
/* 170 */     while (index < this.elements.size() && !full) {
/* 171 */       TableElement element = this.elements.get(index);
/* 172 */       Dimension2D dim = element.preferredSize(g2, bounds);
/* 173 */       if (w + dim.getWidth() <= bounds.getWidth() || index == first) {
/* 174 */         result.add(new ElementInfo(element, dim));
/* 175 */         w += dim.getWidth() + this.hgap;
/* 176 */         index++; continue;
/*     */       } 
/* 178 */       full = true;
/*     */     } 
/*     */     
/* 181 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private double calcRowHeight(List<ElementInfo> elementInfoList) {
/* 192 */     double result = 0.0D;
/* 193 */     for (ElementInfo elementInfo : elementInfoList) {
/* 194 */       result = Math.max(result, elementInfo.getDimension().getHeight());
/*     */     }
/* 196 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private double calcRowWidth(List<ElementInfo> elementInfoList, double hgap) {
/* 209 */     double result = 0.0D;
/* 210 */     for (ElementInfo elementInfo : elementInfoList) {
/* 211 */       result += elementInfo.getDimension().getWidth();
/*     */     }
/* 213 */     int count = elementInfoList.size();
/* 214 */     if (count > 1) {
/* 215 */       result += (count - 1) * hgap;
/*     */     }
/* 217 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Dimension2D preferredSize(Graphics2D g2, Rectangle2D bounds, Map<String, Object> constraints) {
/* 232 */     Insets insets = getInsets();
/* 233 */     double width = (insets.left + insets.right);
/* 234 */     double height = (insets.top + insets.bottom);
/* 235 */     double maxRowWidth = 0.0D;
/* 236 */     int elementCount = this.elements.size();
/* 237 */     int i = 0;
/* 238 */     while (i < elementCount) {
/*     */       
/* 240 */       List<ElementInfo> elementsInRow = rowOfElements(i, g2, bounds);
/*     */       
/* 242 */       double rowHeight = calcRowHeight(elementsInRow);
/* 243 */       double rowWidth = calcRowWidth(elementsInRow, this.hgap);
/* 244 */       maxRowWidth = Math.max(rowWidth, maxRowWidth);
/* 245 */       height += rowHeight;
/* 246 */       i += elementsInRow.size();
/*     */     } 
/* 248 */     width += maxRowWidth;
/* 249 */     return new ElementDimension(width, height);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Rectangle2D> layoutElements(Graphics2D g2, Rectangle2D bounds, Map<String, Object> constraints) {
/* 265 */     int elementCount = this.elements.size();
/* 266 */     List<Rectangle2D> result = new ArrayList<Rectangle2D>(elementCount);
/* 267 */     int i = 0;
/* 268 */     double x = bounds.getX() + (getInsets()).left;
/* 269 */     double y = bounds.getY() + (getInsets()).top;
/* 270 */     while (i < elementCount) {
/*     */       
/* 272 */       List<ElementInfo> elementsInRow = rowOfElements(i, g2, bounds);
/*     */       
/* 274 */       double height = calcRowHeight(elementsInRow);
/* 275 */       double width = calcRowWidth(elementsInRow, this.hgap);
/* 276 */       if (this.horizontalAlignment == HAlign.CENTER) {
/* 277 */         x = bounds.getCenterX() - width / 2.0D;
/* 278 */       } else if (this.horizontalAlignment == HAlign.RIGHT) {
/* 279 */         x = bounds.getMaxX() - (getInsets()).right - width;
/*     */       } 
/* 281 */       for (ElementInfo elementInfo : elementsInRow) {
/* 282 */         Dimension2D dim = elementInfo.getDimension();
/*     */         
/* 284 */         Rectangle2D position = new Rectangle2D.Double(x, y, dim.getWidth(), height);
/* 285 */         result.add(position);
/* 286 */         x += position.getWidth() + this.hgap;
/*     */       } 
/* 288 */       i += elementsInRow.size();
/* 289 */       x = bounds.getX() + (getInsets()).left;
/* 290 */       y += height;
/*     */     } 
/* 292 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void draw(Graphics2D g2, Rectangle2D bounds) {
/* 304 */     draw(g2, bounds, (TableElementOnDraw)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void draw(Graphics2D g2, Rectangle2D bounds, TableElementOnDraw onDrawHandler) {
/* 320 */     if (onDrawHandler != null) {
/* 321 */       onDrawHandler.beforeDraw(this, g2, bounds);
/*     */     }
/*     */     
/* 324 */     Shape savedClip = g2.getClip();
/* 325 */     g2.clip(bounds);
/*     */ 
/*     */     
/* 328 */     Dimension2D prefDim = preferredSize(g2, bounds);
/*     */ 
/*     */ 
/*     */     
/* 332 */     Fit2D fitter = Fit2D.getNoScalingFitter(getRefPoint());
/* 333 */     Rectangle2D dest = fitter.fit(prefDim, bounds);
/*     */ 
/*     */     
/* 336 */     List<Rectangle2D> layoutInfo = layoutElements(g2, dest, (Map<String, Object>)null);
/*     */ 
/*     */     
/* 339 */     for (int i = 0; i < this.elements.size(); i++) {
/* 340 */       Rectangle2D rect = layoutInfo.get(i);
/* 341 */       TableElement element = this.elements.get(i);
/* 342 */       element.draw(g2, rect, onDrawHandler);
/*     */     } 
/*     */     
/* 345 */     g2.setClip(savedClip);
/* 346 */     if (onDrawHandler != null) {
/* 347 */       onDrawHandler.afterDraw(this, g2, bounds);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 360 */     if (obj == this) {
/* 361 */       return true;
/*     */     }
/* 363 */     if (!(obj instanceof FlowElement)) {
/* 364 */       return false;
/*     */     }
/* 366 */     FlowElement that = (FlowElement)obj;
/* 367 */     if (this.hgap != that.hgap) {
/* 368 */       return false;
/*     */     }
/* 370 */     if (this.horizontalAlignment != that.horizontalAlignment) {
/* 371 */       return false;
/*     */     }
/* 373 */     if (!this.elements.equals(that.elements)) {
/* 374 */       return false;
/*     */     }
/* 376 */     return super.equals(obj);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/table/FlowElement.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */