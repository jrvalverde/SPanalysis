/*     */ package com.orsoncharts.table;
/*     */ 
/*     */ import com.orsoncharts.util.Anchor2D;
/*     */ import com.orsoncharts.util.ArgChecks;
/*     */ import com.orsoncharts.util.Fit2D;
/*     */ import com.orsoncharts.util.ObjectUtils;
/*     */ import com.orsoncharts.util.Scale2D;
/*     */ import com.orsoncharts.util.SerialUtils;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.Image;
/*     */ import java.awt.Paint;
/*     */ import java.awt.geom.Rectangle2D;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.io.Serializable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StandardRectanglePainter
/*     */   implements RectanglePainter, Serializable
/*     */ {
/*     */   private transient Paint paint;
/*     */   private transient Image image;
/*     */   private Fit2D imageFit;
/*     */   
/*     */   public StandardRectanglePainter(Paint paint) {
/*  64 */     this(paint, null, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StandardRectanglePainter(Paint paint, Image image, Fit2D imageFit) {
/*  76 */     ArgChecks.nullNotPermitted(paint, "paint");
/*  77 */     this.paint = paint;
/*  78 */     this.image = image;
/*  79 */     this.imageFit = new Fit2D(Anchor2D.TOP_CENTER, Scale2D.SCALE_BOTH);
/*  80 */     if (imageFit != null) {
/*  81 */       this.imageFit = imageFit;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Paint getPaint() {
/*  91 */     return this.paint;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Image getImage() {
/* 100 */     return this.image;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Fit2D getImageFit() {
/* 109 */     return this.imageFit;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void fill(Graphics2D g2, Rectangle2D bounds) {
/* 120 */     Paint saved = g2.getPaint();
/* 121 */     g2.setPaint(this.paint);
/* 122 */     g2.fill(bounds);
/* 123 */     if (this.image != null) {
/* 124 */       int w = this.image.getWidth(null);
/* 125 */       int h = this.image.getHeight(null);
/* 126 */       Rectangle2D imageBounds = this.imageFit.fit(new Dimension(w, h), bounds);
/*     */       
/* 128 */       g2.drawImage(this.image, (int)imageBounds.getX(), 
/* 129 */           (int)imageBounds.getY(), (int)imageBounds.getWidth(), 
/* 130 */           (int)imageBounds.getHeight(), null);
/*     */     } 
/* 132 */     g2.setPaint(saved);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 144 */     if (obj == this) {
/* 145 */       return true;
/*     */     }
/* 147 */     if (!(obj instanceof StandardRectanglePainter)) {
/* 148 */       return false;
/*     */     }
/* 150 */     StandardRectanglePainter that = (StandardRectanglePainter)obj;
/* 151 */     if (!ObjectUtils.equalsPaint(this.paint, that.paint)) {
/* 152 */       return false;
/*     */     }
/* 154 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void writeObject(ObjectOutputStream stream) throws IOException {
/* 165 */     stream.defaultWriteObject();
/* 166 */     SerialUtils.writePaint(this.paint, stream);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void readObject(ObjectInputStream stream) throws IOException, ClassNotFoundException {
/* 180 */     stream.defaultReadObject();
/* 181 */     this.paint = SerialUtils.readPaint(stream);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/table/StandardRectanglePainter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */