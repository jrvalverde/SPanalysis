/*     */ package com.orsoncharts.table;
/*     */ 
/*     */ import com.orsoncharts.util.ArgChecks;
/*     */ import com.orsoncharts.util.TextAnchor;
/*     */ import com.orsoncharts.util.TextUtils;
/*     */ import java.awt.Color;
/*     */ import java.awt.Font;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.Insets;
/*     */ import java.awt.geom.Dimension2D;
/*     */ import java.awt.geom.Rectangle2D;
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TextElement
/*     */   extends AbstractTableElement
/*     */   implements TableElement, Serializable
/*     */ {
/*  46 */   public static final Font DEFAULT_FONT = new Font("Dialog", 0, 12);
/*     */ 
/*     */ 
/*     */   
/*     */   private String text;
/*     */ 
/*     */ 
/*     */   
/*     */   private Font font;
/*     */ 
/*     */ 
/*     */   
/*     */   private Color color;
/*     */ 
/*     */ 
/*     */   
/*     */   private HAlign alignment;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TextElement(String text) {
/*  68 */     this(text, DEFAULT_FONT);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TextElement(String text, Font font) {
/*  79 */     ArgChecks.nullNotPermitted(text, "text");
/*  80 */     ArgChecks.nullNotPermitted(font, "font");
/*  81 */     this.text = text;
/*  82 */     this.font = font;
/*  83 */     this.color = Color.BLACK;
/*  84 */     this.alignment = HAlign.LEFT;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Font getFont() {
/*  93 */     return this.font;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFont(Font font) {
/* 102 */     ArgChecks.nullNotPermitted(font, "font");
/* 103 */     this.font = font;
/*     */   }
/*     */   
/*     */   public Color getColor() {
/* 107 */     return this.color;
/*     */   }
/*     */   
/*     */   public void setColor(Color color) {
/* 111 */     ArgChecks.nullNotPermitted(color, "color");
/* 112 */     this.color = color;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HAlign getHorizontalAlignment() {
/* 122 */     return this.alignment;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setHorizontalAligment(HAlign align) {
/* 131 */     ArgChecks.nullNotPermitted(align, "align");
/* 132 */     this.alignment = align;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Dimension2D preferredSize(Graphics2D g2, Rectangle2D bounds, Map<String, Object> constraints) {
/* 147 */     g2.setFont(this.font);
/* 148 */     Rectangle2D textBounds = TextUtils.getTextBounds(this.text, g2
/* 149 */         .getFontMetrics(this.font));
/* 150 */     Insets insets = getInsets();
/* 151 */     double w = Math.min(textBounds.getWidth() + insets.left + insets.right, bounds
/* 152 */         .getWidth());
/* 153 */     double h = Math.min(textBounds.getHeight() + insets.top + insets.bottom, bounds
/* 154 */         .getHeight());
/* 155 */     return new ElementDimension(w, h);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Rectangle2D> layoutElements(Graphics2D g2, Rectangle2D bounds, Map<String, Object> constraints) {
/* 172 */     g2.setFont(this.font);
/* 173 */     Rectangle2D textBounds = TextUtils.getTextBounds(this.text, g2
/* 174 */         .getFontMetrics(this.font));
/* 175 */     Insets insets = getInsets();
/* 176 */     double width = textBounds.getWidth() + insets.left + insets.right;
/* 177 */     double x = bounds.getX();
/* 178 */     switch (this.alignment) {
/*     */       case LEFT:
/* 180 */         x = bounds.getX();
/*     */         break;
/*     */       case CENTER:
/* 183 */         x = bounds.getCenterX() - width / 2.0D - insets.left;
/*     */         break;
/*     */       case RIGHT:
/* 186 */         x = bounds.getMaxX() - width - insets.right;
/*     */         break;
/*     */       default:
/* 189 */         throw new IllegalStateException("HAlign: " + this.alignment);
/*     */     } 
/* 191 */     double y = bounds.getY();
/* 192 */     double w = Math.min(width, bounds.getWidth());
/* 193 */     double h = Math.min(textBounds.getHeight() + insets.top + insets.bottom, bounds
/* 194 */         .getHeight());
/* 195 */     List<Rectangle2D> result = new ArrayList<Rectangle2D>(1);
/* 196 */     result.add(new Rectangle2D.Double(x, y, w, h));
/* 197 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void receive(TableElementVisitor visitor) {
/* 209 */     visitor.visit(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void draw(Graphics2D g2, Rectangle2D bounds) {
/* 220 */     draw(g2, bounds, (TableElementOnDraw)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void draw(Graphics2D g2, Rectangle2D bounds, TableElementOnDraw onDrawHandler) {
/* 237 */     if (onDrawHandler != null) {
/* 238 */       onDrawHandler.beforeDraw(this, g2, bounds);
/*     */     }
/* 240 */     List<Rectangle2D> layout = layoutElements(g2, bounds, (Map<String, Object>)null);
/* 241 */     Rectangle2D textBounds = layout.get(0);
/* 242 */     if (getBackground() != null) {
/* 243 */       getBackground().fill(g2, textBounds);
/*     */     }
/* 245 */     g2.setPaint(this.color);
/* 246 */     g2.setFont(this.font);
/* 247 */     Insets insets = getInsets();
/* 248 */     TextUtils.drawAlignedString(this.text, g2, 
/* 249 */         (float)(textBounds.getX() + insets.left), 
/* 250 */         (float)(textBounds.getY() + insets.top), TextAnchor.TOP_LEFT);
/* 251 */     if (onDrawHandler != null) {
/* 252 */       onDrawHandler.afterDraw(this, g2, bounds);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 265 */     if (obj == this) {
/* 266 */       return true;
/*     */     }
/* 268 */     if (!(obj instanceof TextElement)) {
/* 269 */       return false;
/*     */     }
/* 271 */     TextElement that = (TextElement)obj;
/* 272 */     if (!this.text.equals(that.text)) {
/* 273 */       return false;
/*     */     }
/* 275 */     if (!this.font.equals(that.font)) {
/* 276 */       return false;
/*     */     }
/* 278 */     if (!this.color.equals(that.color)) {
/* 279 */       return false;
/*     */     }
/* 281 */     if (this.alignment != that.alignment) {
/* 282 */       return false;
/*     */     }
/* 284 */     return super.equals(obj);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 289 */     StringBuilder sb = new StringBuilder();
/* 290 */     sb.append("TextElement[text=").append(this.text).append("]");
/* 291 */     return sb.toString();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/table/TextElement.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */