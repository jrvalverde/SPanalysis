/*     */ package com.orsoncharts.table;
/*     */ 
/*     */ import com.orsoncharts.data.DefaultKeyedValues2D;
/*     */ import java.awt.Color;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.Insets;
/*     */ import java.awt.geom.Dimension2D;
/*     */ import java.awt.geom.Rectangle2D;
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GridElement
/*     */   extends AbstractTableElement
/*     */   implements TableElement, Serializable
/*     */ {
/*  39 */   private static final Color TRANSPARENT_COLOR = new Color(0, 0, 0, 0);
/*     */ 
/*     */ 
/*     */   
/*     */   private DefaultKeyedValues2D<TableElement> elements;
/*     */ 
/*     */ 
/*     */   
/*     */   public GridElement() {
/*  48 */     this.elements = new DefaultKeyedValues2D();
/*  49 */     setBackgroundColor(TRANSPARENT_COLOR);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setElement(TableElement element, Comparable<?> rowKey, Comparable<?> columnKey) {
/*  62 */     this.elements.setValue(element, rowKey, columnKey);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void receive(TableElementVisitor visitor) {
/*  75 */     for (int r = 0; r < this.elements.getRowCount(); r++) {
/*  76 */       for (int c = 0; c < this.elements.getColumnCount(); c++) {
/*  77 */         TableElement element = (TableElement)this.elements.getValue(r, c);
/*  78 */         if (element != null) {
/*  79 */           element.receive(visitor);
/*     */         }
/*     */       } 
/*     */     } 
/*  83 */     visitor.visit(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private double[][] findCellDimensions(Graphics2D g2, Rectangle2D bounds) {
/*  96 */     int rowCount = this.elements.getRowCount();
/*  97 */     int columnCount = this.elements.getColumnCount();
/*  98 */     double[] widths = new double[columnCount];
/*  99 */     double[] heights = new double[rowCount];
/*     */     
/* 101 */     for (int r = 0; r < this.elements.getRowCount(); r++) {
/* 102 */       for (int c = 0; c < this.elements.getColumnCount(); c++) {
/* 103 */         TableElement element = (TableElement)this.elements.getValue(r, c);
/* 104 */         if (element != null) {
/*     */ 
/*     */           
/* 107 */           Dimension2D dim = element.preferredSize(g2, bounds);
/* 108 */           widths[c] = Math.max(widths[c], dim.getWidth());
/* 109 */           heights[r] = Math.max(heights[r], dim.getHeight());
/*     */         } 
/*     */       } 
/* 112 */     }  return new double[][] { widths, heights };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Dimension2D preferredSize(Graphics2D g2, Rectangle2D bounds, Map<String, Object> constraints) {
/* 128 */     Insets insets = getInsets();
/* 129 */     double[][] cellDimensions = findCellDimensions(g2, bounds);
/* 130 */     double[] widths = cellDimensions[0];
/* 131 */     double[] heights = cellDimensions[1];
/* 132 */     double w = (insets.left + insets.right);
/* 133 */     for (int i = 0; i < widths.length; i++) {
/* 134 */       w += widths[i];
/*     */     }
/* 136 */     double h = (insets.top + insets.bottom);
/* 137 */     for (int j = 0; j < heights.length; j++) {
/* 138 */       h += heights[j];
/*     */     }
/* 140 */     return new Dimension((int)w, (int)h);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Rectangle2D> layoutElements(Graphics2D g2, Rectangle2D bounds, Map<String, Object> constraints) {
/* 156 */     double[][] cellDimensions = findCellDimensions(g2, bounds);
/* 157 */     double[] widths = cellDimensions[0];
/* 158 */     double[] heights = cellDimensions[1];
/*     */     
/* 160 */     List<Rectangle2D> result = new ArrayList<Rectangle2D>(this.elements.getRowCount() * this.elements.getColumnCount());
/* 161 */     double y = bounds.getY() + (getInsets()).top;
/* 162 */     for (int r = 0; r < this.elements.getRowCount(); r++) {
/* 163 */       double x = bounds.getX() + (getInsets()).left;
/* 164 */       for (int c = 0; c < this.elements.getColumnCount(); c++) {
/* 165 */         result.add(new Rectangle2D.Double(x, y, widths[c], heights[r]));
/* 166 */         x += widths[c];
/*     */       } 
/* 168 */       y += heights[r];
/*     */     } 
/* 170 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void draw(Graphics2D g2, Rectangle2D bounds) {
/* 181 */     draw(g2, bounds, (TableElementOnDraw)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void draw(Graphics2D g2, Rectangle2D bounds, TableElementOnDraw onDrawHandler) {
/* 200 */     if (onDrawHandler != null) {
/* 201 */       onDrawHandler.beforeDraw(this, g2, bounds);
/*     */     }
/* 203 */     if (getBackground() != null) {
/* 204 */       getBackground().fill(g2, bounds);
/*     */     }
/* 206 */     List<Rectangle2D> positions = layoutElements(g2, bounds, (Map<String, Object>)null);
/* 207 */     for (int r = 0; r < this.elements.getRowCount(); r++) {
/* 208 */       for (int c = 0; c < this.elements.getColumnCount(); c++) {
/* 209 */         TableElement element = (TableElement)this.elements.getValue(r, c);
/* 210 */         if (element != null) {
/*     */ 
/*     */           
/* 213 */           Rectangle2D pos = positions.get(r * this.elements.getColumnCount() + c);
/*     */           
/* 215 */           element.draw(g2, pos, onDrawHandler);
/*     */         } 
/*     */       } 
/* 218 */     }  if (onDrawHandler != null) {
/* 219 */       onDrawHandler.afterDraw(this, g2, bounds);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 232 */     if (obj == this) {
/* 233 */       return true;
/*     */     }
/* 235 */     if (!(obj instanceof GridElement)) {
/* 236 */       return false;
/*     */     }
/* 238 */     GridElement that = (GridElement)obj;
/* 239 */     if (!this.elements.equals(that.elements)) {
/* 240 */       return false;
/*     */     }
/* 242 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 253 */     StringBuilder sb = new StringBuilder();
/* 254 */     sb.append("GridElement[rowCount=").append(this.elements.getRowCount());
/* 255 */     sb.append(", columnCount=").append(this.elements.getColumnCount());
/* 256 */     sb.append("]");
/* 257 */     return sb.toString();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/table/GridElement.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */