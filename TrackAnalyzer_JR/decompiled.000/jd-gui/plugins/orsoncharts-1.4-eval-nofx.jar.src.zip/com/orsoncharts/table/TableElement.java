package com.orsoncharts.table;

import com.orsoncharts.util.RefPt2D;
import java.awt.Graphics2D;
import java.awt.geom.Dimension2D;
import java.awt.geom.Rectangle2D;
import java.util.List;
import java.util.Map;

public interface TableElement {
  public static final String CLASS = "class";
  
  Dimension2D preferredSize(Graphics2D paramGraphics2D, Rectangle2D paramRectangle2D);
  
  Dimension2D preferredSize(Graphics2D paramGraphics2D, Rectangle2D paramRectangle2D, Map<String, Object> paramMap);
  
  RefPt2D getRefPoint();
  
  List<Rectangle2D> layoutElements(Graphics2D paramGraphics2D, Rectangle2D paramRectangle2D, Map<String, Object> paramMap);
  
  void draw(Graphics2D paramGraphics2D, Rectangle2D paramRectangle2D);
  
  void draw(Graphics2D paramGraphics2D, Rectangle2D paramRectangle2D, TableElementOnDraw paramTableElementOnDraw);
  
  Object getProperty(String paramString);
  
  void setProperty(String paramString, Object paramObject);
  
  void receive(TableElementVisitor paramTableElementVisitor);
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/table/TableElement.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */