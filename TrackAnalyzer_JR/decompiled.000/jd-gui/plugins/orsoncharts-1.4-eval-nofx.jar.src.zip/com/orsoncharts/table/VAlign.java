/*    */ package com.orsoncharts.table;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum VAlign
/*    */ {
/* 21 */   TOP,
/*    */ 
/*    */   
/* 24 */   MIDDLE,
/*    */ 
/*    */   
/* 27 */   BOTTOM;
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/table/VAlign.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */