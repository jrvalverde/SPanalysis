/*     */ package com.orsoncharts.table;
/*     */ 
/*     */ import com.orsoncharts.util.Anchor2D;
/*     */ import com.orsoncharts.util.ArgChecks;
/*     */ import com.orsoncharts.util.ObjectUtils;
/*     */ import java.awt.Color;
/*     */ import java.awt.GradientPaint;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.Paint;
/*     */ import java.awt.geom.Point2D;
/*     */ import java.awt.geom.Rectangle2D;
/*     */ import java.io.Serializable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class GradientRectanglePainter
/*     */   implements RectanglePainter, Serializable
/*     */ {
/*     */   private final Color color1;
/*     */   private final Anchor2D anchor1;
/*     */   private final Color color2;
/*     */   private final Anchor2D anchor2;
/*     */   
/*     */   public GradientRectanglePainter(Color color1, Anchor2D anchor1, Color color2, Anchor2D anchor2) {
/*  71 */     ArgChecks.nullNotPermitted(color1, "color1");
/*  72 */     ArgChecks.nullNotPermitted(anchor1, "anchor1");
/*  73 */     ArgChecks.nullNotPermitted(color2, "color2");
/*  74 */     ArgChecks.nullNotPermitted(anchor2, "anchor2");
/*  75 */     this.color1 = color1;
/*  76 */     this.anchor1 = anchor1;
/*  77 */     this.color2 = color2;
/*  78 */     this.anchor2 = anchor2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Color getColor1() {
/*  89 */     return this.color1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Anchor2D getAnchor1() {
/* 100 */     return this.anchor1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Color getColor2() {
/* 111 */     return this.color2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Anchor2D getAnchor2() {
/* 122 */     return this.anchor2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private GradientPaint createTransformedGradient(Rectangle2D area) {
/* 135 */     Point2D pt1 = this.anchor1.getAnchorPoint(area);
/* 136 */     Point2D pt2 = this.anchor2.getAnchorPoint(area);
/* 137 */     return new GradientPaint(pt1, this.color1, pt2, this.color2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void fill(Graphics2D g2, Rectangle2D area) {
/* 149 */     Paint saved = g2.getPaint();
/* 150 */     g2.setPaint(createTransformedGradient(area));
/* 151 */     g2.fill(area);
/* 152 */     g2.setPaint(saved);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 164 */     if (obj == this) {
/* 165 */       return true;
/*     */     }
/* 167 */     if (!(obj instanceof GradientRectanglePainter)) {
/* 168 */       return false;
/*     */     }
/* 170 */     GradientRectanglePainter that = (GradientRectanglePainter)obj;
/* 171 */     if (!this.color1.equals(that.color1)) {
/* 172 */       return false;
/*     */     }
/* 174 */     if (!this.anchor1.equals(that.anchor1)) {
/* 175 */       return false;
/*     */     }
/* 177 */     if (!this.color2.equals(that.color2)) {
/* 178 */       return false;
/*     */     }
/* 180 */     if (!this.anchor2.equals(that.anchor2)) {
/* 181 */       return false;
/*     */     }
/* 183 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 188 */     int hash = 5;
/* 189 */     hash = 67 * hash + ObjectUtils.hashCode(this.color1);
/* 190 */     hash = 67 * hash + ObjectUtils.hashCode(this.anchor1);
/* 191 */     hash = 67 * hash + ObjectUtils.hashCode(this.color2);
/* 192 */     hash = 67 * hash + ObjectUtils.hashCode(this.anchor2);
/* 193 */     return hash;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/table/GradientRectanglePainter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */