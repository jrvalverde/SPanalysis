/*    */ package com.orsoncharts.table;
/*    */ 
/*    */ import com.orsoncharts.util.ArgChecks;
/*    */ import java.awt.geom.Dimension2D;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ElementInfo
/*    */ {
/*    */   private TableElement element;
/*    */   private Dimension2D dimension;
/*    */   
/*    */   public ElementInfo(TableElement element, Dimension2D dimension) {
/* 39 */     ArgChecks.nullNotPermitted(element, "element");
/* 40 */     ArgChecks.nullNotPermitted(dimension, "dimension");
/* 41 */     this.element = element;
/* 42 */     this.dimension = dimension;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public TableElement getElement() {
/* 51 */     return this.element;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Dimension2D getDimension() {
/* 60 */     return this.dimension;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/table/ElementInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */