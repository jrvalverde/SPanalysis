package com.orsoncharts.table;

import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;

public interface RectanglePainter {
  void fill(Graphics2D paramGraphics2D, Rectangle2D paramRectangle2D);
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/table/RectanglePainter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */