/*     */ package com.orsoncharts.table;
/*     */ 
/*     */ import com.orsoncharts.util.ArgChecks;
/*     */ import java.awt.Color;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.Insets;
/*     */ import java.awt.Shape;
/*     */ import java.awt.geom.AffineTransform;
/*     */ import java.awt.geom.Dimension2D;
/*     */ import java.awt.geom.Rectangle2D;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ShapeElement
/*     */   extends AbstractTableElement
/*     */   implements TableElement
/*     */ {
/*     */   private Shape shape;
/*     */   private Color fillColor;
/*     */   
/*     */   public ShapeElement(Shape shape, Color fillColor) {
/*  55 */     ArgChecks.nullNotPermitted(shape, "shape");
/*  56 */     ArgChecks.nullNotPermitted(fillColor, "fillColor");
/*  57 */     this.shape = shape;
/*  58 */     this.fillColor = fillColor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Color getFillColor() {
/*  69 */     return this.fillColor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFillColor(Color color) {
/*  80 */     ArgChecks.nullNotPermitted(color, "color");
/*  81 */     this.fillColor = color;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Dimension2D preferredSize(Graphics2D g2, Rectangle2D bounds, Map<String, Object> constraints) {
/*  87 */     Insets insets = getInsets();
/*  88 */     Rectangle2D shapeBounds = this.shape.getBounds2D();
/*  89 */     return new ElementDimension(Math.min(shapeBounds.getWidth() + insets.left + insets.right, bounds
/*  90 */           .getWidth()), 
/*  91 */         Math.min(shapeBounds.getHeight() + insets.top + insets.bottom, bounds
/*  92 */           .getHeight()));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Rectangle2D> layoutElements(Graphics2D g2, Rectangle2D bounds, Map<String, Object> constraints) {
/*  98 */     List<Rectangle2D> result = new ArrayList<Rectangle2D>(1);
/*  99 */     Insets insets = getInsets();
/* 100 */     Rectangle2D shapeBounds = this.shape.getBounds2D();
/* 101 */     double w = Math.min(shapeBounds.getWidth() + insets.left + insets.right, bounds
/* 102 */         .getWidth());
/* 103 */     double h = Math.min(shapeBounds.getHeight() + insets.top + insets.bottom, bounds
/* 104 */         .getHeight());
/*     */     
/* 106 */     Rectangle2D pos = new Rectangle2D.Double(bounds.getCenterX() - w / 2.0D, bounds.getCenterY() - h / 2.0D, w, h);
/* 107 */     result.add(pos);
/* 108 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void draw(Graphics2D g2, Rectangle2D bounds) {
/* 119 */     draw(g2, bounds, (TableElementOnDraw)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void draw(Graphics2D g2, Rectangle2D bounds, TableElementOnDraw onDrawHandler) {
/* 138 */     if (onDrawHandler != null) {
/* 139 */       onDrawHandler.beforeDraw(this, g2, bounds);
/*     */     }
/* 141 */     AffineTransform saved = g2.getTransform();
/* 142 */     RectanglePainter background = getBackground();
/* 143 */     if (background != null) {
/* 144 */       background.fill(g2, bounds);
/*     */     }
/* 146 */     g2.translate(bounds.getCenterX(), bounds.getCenterY());
/* 147 */     g2.setPaint(this.fillColor);
/* 148 */     g2.fill(this.shape);
/* 149 */     g2.setTransform(saved);
/* 150 */     if (onDrawHandler != null) {
/* 151 */       onDrawHandler.afterDraw(this, g2, bounds);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void receive(TableElementVisitor visitor) {
/* 164 */     visitor.visit(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 175 */     StringBuilder sb = new StringBuilder();
/* 176 */     sb.append("ShapeElement[shape=").append(this.shape).append("]");
/* 177 */     return sb.toString();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/table/ShapeElement.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */