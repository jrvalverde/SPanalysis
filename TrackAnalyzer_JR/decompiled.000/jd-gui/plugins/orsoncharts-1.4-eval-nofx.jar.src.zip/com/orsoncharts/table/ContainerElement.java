package com.orsoncharts.table;

public interface ContainerElement extends TableElement {
  void addElement(TableElement paramTableElement);
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/table/ContainerElement.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */