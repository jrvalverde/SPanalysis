/*     */ package com.orsoncharts.table;
/*     */ 
/*     */ import com.orsoncharts.util.ArgChecks;
/*     */ import com.orsoncharts.util.Fit2D;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.Insets;
/*     */ import java.awt.Shape;
/*     */ import java.awt.geom.Dimension2D;
/*     */ import java.awt.geom.Rectangle2D;
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class VerticalFlowElement
/*     */   extends AbstractTableElement
/*     */   implements ContainerElement, Serializable
/*     */ {
/*     */   private List<TableElement> elements;
/*     */   private VAlign verticalAlignment;
/*     */   private int vgap;
/*     */   
/*     */   public VerticalFlowElement() {
/*  59 */     this(VAlign.MIDDLE, 2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public VerticalFlowElement(VAlign alignment, int vgap) {
/*  70 */     ArgChecks.nullNotPermitted(alignment, null);
/*  71 */     this.elements = new ArrayList<TableElement>();
/*  72 */     this.verticalAlignment = alignment;
/*  73 */     this.vgap = vgap;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public VAlign getVerticalAlignment() {
/*  82 */     return this.verticalAlignment;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setVerticalAlignment(VAlign alignment) {
/*  91 */     ArgChecks.nullNotPermitted(alignment, "alignment");
/*  92 */     this.verticalAlignment = alignment;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getVGap() {
/* 101 */     return this.vgap;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setVGap(int vgap) {
/* 110 */     this.vgap = vgap;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<TableElement> getElements() {
/* 120 */     return new ArrayList<TableElement>(this.elements);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addElement(TableElement element) {
/* 130 */     ArgChecks.nullNotPermitted(element, "element");
/* 131 */     this.elements.add(element);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void receive(TableElementVisitor visitor) {
/* 144 */     for (TableElement element : this.elements) {
/* 145 */       element.receive(visitor);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Dimension2D preferredSize(Graphics2D g2, Rectangle2D bounds, Map<String, Object> constraints) {
/* 161 */     Insets insets = getInsets();
/* 162 */     double width = (insets.left + insets.right);
/* 163 */     double height = (insets.top + insets.bottom);
/* 164 */     double maxColHeight = 0.0D;
/* 165 */     int elementCount = this.elements.size();
/* 166 */     int i = 0;
/* 167 */     while (i < elementCount) {
/*     */       
/* 169 */       List<ElementInfo> elementsInColumn = columnOfElements(i, g2, bounds);
/*     */       
/* 171 */       double colWidth = calcColumnWidth(elementsInColumn);
/* 172 */       double colHeight = calcColumnHeight(elementsInColumn, this.vgap);
/* 173 */       maxColHeight = Math.max(colHeight, maxColHeight);
/* 174 */       width += colWidth;
/* 175 */       i += elementsInColumn.size();
/*     */     } 
/* 177 */     height += maxColHeight;
/* 178 */     return new ElementDimension(width, height);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private List<ElementInfo> columnOfElements(int first, Graphics2D g2, Rectangle2D bounds) {
/* 192 */     List<ElementInfo> result = new ArrayList<ElementInfo>();
/* 193 */     int index = first;
/* 194 */     boolean full = false;
/* 195 */     double h = ((getInsets()).top + (getInsets()).bottom);
/* 196 */     while (index < this.elements.size() && !full) {
/* 197 */       TableElement element = this.elements.get(index);
/* 198 */       Dimension2D dim = element.preferredSize(g2, bounds);
/* 199 */       if (h + dim.getHeight() <= bounds.getHeight() || index == first) {
/* 200 */         result.add(new ElementInfo(element, dim));
/* 201 */         h += dim.getHeight() + this.vgap;
/* 202 */         index++; continue;
/*     */       } 
/* 204 */       full = true;
/*     */     } 
/*     */     
/* 207 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private double calcColumnWidth(List<ElementInfo> elementInfoList) {
/* 218 */     double result = 0.0D;
/* 219 */     for (ElementInfo elementInfo : elementInfoList) {
/* 220 */       result = Math.max(result, elementInfo.getDimension().getWidth());
/*     */     }
/* 222 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private double calcColumnHeight(List<ElementInfo> elementInfoList, double vgap) {
/* 235 */     double result = 0.0D;
/* 236 */     for (ElementInfo elementInfo : elementInfoList) {
/* 237 */       result += elementInfo.getDimension().getHeight();
/*     */     }
/* 239 */     int count = elementInfoList.size();
/* 240 */     if (count > 1) {
/* 241 */       result += (count - 1) * vgap;
/*     */     }
/* 243 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Rectangle2D> layoutElements(Graphics2D g2, Rectangle2D bounds, Map<String, Object> constraints) {
/* 249 */     int elementCount = this.elements.size();
/* 250 */     List<Rectangle2D> result = new ArrayList<Rectangle2D>(elementCount);
/* 251 */     int i = 0;
/* 252 */     double x = bounds.getX() + (getInsets()).left;
/* 253 */     double y = bounds.getY() + (getInsets()).top;
/* 254 */     while (i < elementCount) {
/*     */       
/* 256 */       List<ElementInfo> elementsInColumn = columnOfElements(i, g2, bounds);
/*     */       
/* 258 */       double width = calcColumnWidth(elementsInColumn);
/* 259 */       double height = calcColumnHeight(elementsInColumn, this.vgap);
/* 260 */       if (this.verticalAlignment == VAlign.MIDDLE) {
/* 261 */         y = bounds.getCenterY() - height / 2.0D;
/* 262 */       } else if (this.verticalAlignment == VAlign.BOTTOM) {
/* 263 */         y = bounds.getMaxY() - (getInsets()).bottom - height;
/*     */       } 
/* 265 */       for (ElementInfo elementInfo : elementsInColumn) {
/* 266 */         Dimension2D dim = elementInfo.getDimension();
/*     */         
/* 268 */         Rectangle2D position = new Rectangle2D.Double(x, y, width, dim.getHeight());
/* 269 */         result.add(position);
/* 270 */         y += position.getHeight() + this.vgap;
/*     */       } 
/* 272 */       i += elementsInColumn.size();
/* 273 */       x += width;
/* 274 */       y = bounds.getY() + (getInsets()).top;
/*     */     } 
/* 276 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void draw(Graphics2D g2, Rectangle2D bounds) {
/* 288 */     draw(g2, bounds, (TableElementOnDraw)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void draw(Graphics2D g2, Rectangle2D bounds, TableElementOnDraw onDrawHandler) {
/* 307 */     if (onDrawHandler != null) {
/* 308 */       onDrawHandler.beforeDraw(this, g2, bounds);
/*     */     }
/* 310 */     Shape savedClip = g2.getClip();
/* 311 */     g2.clip(bounds);
/*     */ 
/*     */     
/* 314 */     Dimension2D prefDim = preferredSize(g2, bounds);
/*     */ 
/*     */ 
/*     */     
/* 318 */     Fit2D fitter = Fit2D.getNoScalingFitter(getRefPoint());
/* 319 */     Rectangle2D dest = fitter.fit(prefDim, bounds);
/*     */ 
/*     */     
/* 322 */     List<Rectangle2D> layoutInfo = layoutElements(g2, dest, (Map<String, Object>)null);
/*     */ 
/*     */     
/* 325 */     for (int i = 0; i < this.elements.size(); i++) {
/* 326 */       Rectangle2D rect = layoutInfo.get(i);
/* 327 */       TableElement element = this.elements.get(i);
/* 328 */       element.draw(g2, rect, onDrawHandler);
/*     */     } 
/* 330 */     g2.setClip(savedClip);
/* 331 */     if (onDrawHandler != null) {
/* 332 */       onDrawHandler.afterDraw(this, g2, bounds);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 345 */     if (obj == this) {
/* 346 */       return true;
/*     */     }
/* 348 */     if (!(obj instanceof VerticalFlowElement)) {
/* 349 */       return false;
/*     */     }
/* 351 */     VerticalFlowElement that = (VerticalFlowElement)obj;
/* 352 */     if (this.vgap != that.vgap) {
/* 353 */       return false;
/*     */     }
/* 355 */     if (this.verticalAlignment != that.verticalAlignment) {
/* 356 */       return false;
/*     */     }
/* 358 */     if (!this.elements.equals(that.elements)) {
/* 359 */       return false;
/*     */     }
/* 361 */     return super.equals(obj);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/table/VerticalFlowElement.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */