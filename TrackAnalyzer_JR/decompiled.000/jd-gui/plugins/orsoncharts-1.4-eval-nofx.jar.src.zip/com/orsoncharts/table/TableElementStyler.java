/*    */ package com.orsoncharts.table;
/*    */ 
/*    */ import java.awt.Color;
/*    */ import java.awt.Font;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TableElementStyler
/*    */   implements TableElementVisitor
/*    */ {
/*    */   private Map<String, Font> fontChanges;
/*    */   private Map<String, Color> foregroundColorChanges;
/*    */   private Map<String, Color> backgroundColorChanges;
/*    */   
/*    */   public TableElementStyler(Map<String, Font> fontChanges, Map<String, Color> fgChanges, Map<String, Color> bgChanges) {
/* 44 */     this.fontChanges = new HashMap<String, Font>(fontChanges);
/* 45 */     this.foregroundColorChanges = fgChanges;
/* 46 */     this.backgroundColorChanges = bgChanges;
/*    */   }
/*    */ 
/*    */   
/*    */   public void visit(TableElement element) {
/* 51 */     if (element instanceof TextElement) {
/* 52 */       TextElement te = (TextElement)element;
/* 53 */       Font f = this.fontChanges.get(te.getTag());
/* 54 */       if (f != null) {
/* 55 */         te.setFont(f);
/*    */       }
/* 57 */       Color bg = this.backgroundColorChanges.get(te.getTag());
/* 58 */       if (bg != null) {
/* 59 */         te.setBackgroundColor(bg);
/*    */       }
/* 61 */       Color fg = this.foregroundColorChanges.get(te.getTag());
/* 62 */       if (fg != null)
/* 63 */         te.setColor(fg); 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/table/TableElementStyler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */