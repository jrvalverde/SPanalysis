/*     */ package com.orsoncharts.table;
/*     */ 
/*     */ import java.awt.geom.Dimension2D;
/*     */ import java.io.Serializable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ElementDimension
/*     */   extends Dimension2D
/*     */   implements Serializable
/*     */ {
/*     */   private double width;
/*     */   private double height;
/*     */   
/*     */   public ElementDimension(double width, double height) {
/*  44 */     this.width = width;
/*  45 */     this.height = height;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getWidth() {
/*  55 */     return this.width;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getHeight() {
/*  65 */     return this.height;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSize(double width, double height) {
/*  76 */     this.width = width;
/*  77 */     this.height = height;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/*  89 */     if (obj == this) {
/*  90 */       return true;
/*     */     }
/*  92 */     if (!(obj instanceof ElementDimension)) {
/*  93 */       return false;
/*     */     }
/*  95 */     ElementDimension that = (ElementDimension)obj;
/*  96 */     if (this.width != that.width) {
/*  97 */       return false;
/*     */     }
/*  99 */     if (this.height != that.height) {
/* 100 */       return false;
/*     */     }
/* 102 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 113 */     return "ElementDimension(" + this.width + ", " + this.height + ")";
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/table/ElementDimension.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */