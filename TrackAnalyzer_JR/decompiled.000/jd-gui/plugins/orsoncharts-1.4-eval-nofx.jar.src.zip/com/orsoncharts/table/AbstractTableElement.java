/*     */ package com.orsoncharts.table;
/*     */ 
/*     */ import com.orsoncharts.util.ArgChecks;
/*     */ import com.orsoncharts.util.ObjectUtils;
/*     */ import com.orsoncharts.util.RefPt2D;
/*     */ import java.awt.Color;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.Insets;
/*     */ import java.awt.geom.Dimension2D;
/*     */ import java.awt.geom.Rectangle2D;
/*     */ import java.io.Serializable;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractTableElement
/*     */   implements Serializable
/*     */ {
/*  39 */   private static final Color DEFAULT_BACKGROUND_COLOR = new Color(255, 255, 255, 127);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  61 */   private RefPt2D refPt = RefPt2D.CENTER;
/*  62 */   private Insets insets = new Insets(2, 2, 2, 2);
/*  63 */   private RectanglePainter background = new StandardRectanglePainter(DEFAULT_BACKGROUND_COLOR);
/*     */   
/*  65 */   private String tag = "";
/*  66 */   private HashMap<String, Object> properties = new HashMap<String, Object>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RefPt2D getRefPoint() {
/*  79 */     return this.refPt;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRefPoint(RefPt2D refPt) {
/*  90 */     ArgChecks.nullNotPermitted(refPt, "refPt");
/*  91 */     this.refPt = refPt;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Insets getInsets() {
/* 101 */     return this.insets;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setInsets(Insets insets) {
/* 110 */     ArgChecks.nullNotPermitted(insets, "insets");
/* 111 */     this.insets = insets;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RectanglePainter getBackground() {
/* 120 */     return this.background;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBackground(RectanglePainter background) {
/* 129 */     this.background = background;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBackgroundColor(Color color) {
/* 142 */     if (color != null) {
/* 143 */       this.background = new StandardRectanglePainter(color);
/*     */     } else {
/* 145 */       this.background = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getTag() {
/* 157 */     return this.tag;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTag(String tag) {
/* 168 */     ArgChecks.nullNotPermitted(tag, "tag");
/* 169 */     this.tag = tag;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getProperty(String key) {
/* 183 */     return this.properties.get(key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setProperty(String key, Object value) {
/* 195 */     ArgChecks.nullNotPermitted(key, "key");
/* 196 */     this.properties.put(key, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Dimension2D preferredSize(Graphics2D g2, Rectangle2D bounds) {
/* 208 */     return preferredSize(g2, bounds, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract Dimension2D preferredSize(Graphics2D paramGraphics2D, Rectangle2D paramRectangle2D, Map<String, Object> paramMap);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 232 */     if (obj == this) {
/* 233 */       return true;
/*     */     }
/* 235 */     if (!(obj instanceof AbstractTableElement)) {
/* 236 */       return false;
/*     */     }
/* 238 */     AbstractTableElement that = (AbstractTableElement)obj;
/* 239 */     if (!this.insets.equals(that.insets)) {
/* 240 */       return false;
/*     */     }
/* 242 */     if (!ObjectUtils.equals(this.background, that.background)) {
/* 243 */       return false;
/*     */     }
/* 245 */     return true;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/table/AbstractTableElement.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */