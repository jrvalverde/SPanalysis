/*     */ package com.orsoncharts.style;
/*     */ 
/*     */ import com.orsoncharts.Chart3D;
/*     */ import com.orsoncharts.ChartElement;
/*     */ import com.orsoncharts.ChartElementVisitor;
/*     */ import com.orsoncharts.axis.Axis3D;
/*     */ import com.orsoncharts.axis.CategoryAxis3D;
/*     */ import com.orsoncharts.axis.ValueAxis3D;
/*     */ import com.orsoncharts.marker.CategoryMarker;
/*     */ import com.orsoncharts.marker.Marker;
/*     */ import com.orsoncharts.marker.NumberMarker;
/*     */ import com.orsoncharts.marker.RangeMarker;
/*     */ import com.orsoncharts.plot.CategoryPlot3D;
/*     */ import com.orsoncharts.plot.PiePlot3D;
/*     */ import com.orsoncharts.plot.Plot3D;
/*     */ import com.orsoncharts.plot.XYZPlot;
/*     */ import com.orsoncharts.renderer.Renderer3D;
/*     */ import com.orsoncharts.renderer.category.CategoryRenderer3D;
/*     */ import com.orsoncharts.renderer.xyz.XYZRenderer;
/*     */ import com.orsoncharts.table.TableElement;
/*     */ import com.orsoncharts.table.TableElementStyler;
/*     */ import com.orsoncharts.table.TableElementVisitor;
/*     */ import java.awt.Color;
/*     */ import java.awt.Font;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ChartStyler
/*     */   implements ChartElementVisitor
/*     */ {
/*     */   private ChartStyle style;
/*     */   
/*     */   public ChartStyler(ChartStyle style) {
/*  56 */     this.style = style;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void visit(ChartElement element) {
/*  66 */     if (element instanceof Chart3D) {
/*  67 */       Chart3D chart = (Chart3D)element;
/*  68 */       styleChart(chart);
/*     */     } 
/*  70 */     if (element instanceof Plot3D) {
/*  71 */       Plot3D plot = (Plot3D)element;
/*  72 */       stylePlot(plot);
/*     */     } 
/*  74 */     if (element instanceof Axis3D) {
/*  75 */       Axis3D axis = (Axis3D)element;
/*  76 */       styleAxis(axis);
/*     */     } 
/*  78 */     if (element instanceof Renderer3D) {
/*  79 */       Renderer3D renderer = (Renderer3D)element;
/*  80 */       styleRenderer(renderer);
/*     */     } 
/*  82 */     if (element instanceof Marker) {
/*  83 */       Marker marker = (Marker)element;
/*  84 */       styleMarker(marker);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void styleChart(Chart3D chart) {
/*  94 */     chart.setBackground(this.style.getBackgroundPainter());
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  99 */     TableElement chartTitle = chart.getTitle();
/* 100 */     if (chartTitle != null) {
/* 101 */       Map<String, Font> fontChanges = new HashMap<String, Font>();
/* 102 */       fontChanges.put("CHART_TITLE", this.style.getTitleFont());
/* 103 */       fontChanges.put("CHART_SUBTITLE", this.style.getSubtitleFont());
/* 104 */       Map<String, Color> bgChanges = new HashMap<String, Color>();
/* 105 */       bgChanges.put("CHART_TITLE", this.style.getTitleBackgroundColor());
/* 106 */       bgChanges.put("CHART_SUBTITLE", this.style
/* 107 */           .getSubtitleBackgroundColor());
/* 108 */       Map<String, Color> fgChanges = new HashMap<String, Color>();
/* 109 */       fgChanges.put("CHART_TITLE", this.style.getTitleColor());
/* 110 */       fgChanges.put("CHART_SUBTITLE", this.style.getSubtitleColor());
/* 111 */       TableElementStyler m1 = new TableElementStyler(fontChanges, fgChanges, bgChanges);
/*     */       
/* 113 */       chartTitle.receive((TableElementVisitor)m1);
/*     */     } 
/* 115 */     chart.setChartBoxColor(this.style.getChartBoxColor());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void stylePlot(Plot3D plot) {
/* 124 */     if (plot instanceof PiePlot3D) {
/* 125 */       PiePlot3D p = (PiePlot3D)plot;
/* 126 */       p.getSectionLabelFontSource().style(this.style
/* 127 */           .getSectionLabelFont());
/* 128 */       p.getSectionLabelColorSource().style(new Color[] { this.style
/* 129 */             .getSectionLabelColor() });
/* 130 */       p.getSectionColorSource().style(this.style
/* 131 */           .getStandardColors());
/*     */     } 
/* 133 */     if (plot instanceof CategoryPlot3D) {
/* 134 */       CategoryPlot3D p = (CategoryPlot3D)plot;
/*     */ 
/*     */       
/* 137 */       p.setGridlinesVisibleForColumns(this.style
/* 138 */           .getColumnAxisGridlinesVisible());
/* 139 */       p.setGridlinesVisibleForRows(this.style
/* 140 */           .getRowAxisGridlinesVisible());
/* 141 */       p.setGridlinesVisibleForValues(this.style
/* 142 */           .getYAxisGridlinesVisible());
/* 143 */       p.setGridlinePaintForRows(this.style.getGridlineColor());
/* 144 */       p.setGridlinePaintForColumns(this.style.getGridlineColor());
/* 145 */       p.setGridlinePaintForValues(this.style.getGridlineColor());
/* 146 */       p.setGridlineStrokeForColumns(this.style.getGridlineStroke());
/* 147 */       p.setGridlineStrokeForRows(this.style.getGridlineStroke());
/* 148 */       p.setGridlineStrokeForValues(this.style.getGridlineStroke());
/*     */     } 
/* 150 */     if (plot instanceof XYZPlot) {
/* 151 */       XYZPlot p = (XYZPlot)plot;
/* 152 */       p.setGridlinesVisibleX(this.style.getXAxisGridlinesVisible());
/* 153 */       p.setGridlinesVisibleY(this.style.getYAxisGridlinesVisible());
/* 154 */       p.setGridlinesVisibleZ(this.style.getZAxisGridlinesVisible());
/* 155 */       p.setGridlinePaintX(this.style.getGridlineColor());
/* 156 */       p.setGridlinePaintY(this.style.getGridlineColor());
/* 157 */       p.setGridlinePaintZ(this.style.getGridlineColor());
/* 158 */       p.setGridlineStrokeX(this.style.getGridlineStroke());
/* 159 */       p.setGridlineStrokeY(this.style.getGridlineStroke());
/* 160 */       p.setGridlineStrokeZ(this.style.getGridlineStroke());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void styleAxis(Axis3D axis) {
/* 172 */     axis.setLabelFont(this.style.getAxisLabelFont());
/* 173 */     axis.setLabelColor(this.style.getAxisLabelColor());
/* 174 */     axis.setTickLabelFont(this.style.getAxisTickLabelFont());
/* 175 */     axis.setTickLabelColor(this.style.getAxisTickLabelColor());
/* 176 */     if (axis instanceof CategoryAxis3D) {
/* 177 */       styleCategoryAxis((CategoryAxis3D)axis);
/*     */     }
/* 179 */     if (axis instanceof ValueAxis3D) {
/* 180 */       styleValueAxis((ValueAxis3D)axis);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected void styleCategoryAxis(CategoryAxis3D axis) {}
/*     */ 
/*     */   
/*     */   protected void styleValueAxis(ValueAxis3D axis) {}
/*     */   
/*     */   protected void styleRenderer(Renderer3D renderer) {
/* 191 */     if (renderer instanceof CategoryRenderer3D) {
/* 192 */       styleCategoryRenderer3D((CategoryRenderer3D)renderer);
/*     */     }
/* 194 */     if (renderer instanceof XYZRenderer) {
/* 195 */       styleXYZRenderer((XYZRenderer)renderer);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void styleCategoryRenderer3D(CategoryRenderer3D renderer) {
/* 200 */     renderer.getColorSource().style(this.style.getStandardColors());
/*     */   }
/*     */   
/*     */   protected void styleXYZRenderer(XYZRenderer renderer) {
/* 204 */     renderer.getColorSource().style(this.style.getStandardColors());
/*     */   }
/*     */   
/*     */   protected void styleMarker(Marker marker) {
/* 208 */     if (marker instanceof CategoryMarker) {
/* 209 */       CategoryMarker cm = (CategoryMarker)marker;
/* 210 */       cm.setFont(this.style.getMarkerLabelFont());
/* 211 */       cm.setLabelColor(this.style.getMarkerLabelColor());
/* 212 */       cm.setLineColor(this.style.getMarkerLineColor());
/* 213 */       cm.setLineStroke(this.style.getMarkerLineStroke());
/* 214 */       cm.setFillColor(this.style.getMarkerFillColor());
/* 215 */     } else if (marker instanceof NumberMarker) {
/* 216 */       NumberMarker nm = (NumberMarker)marker;
/* 217 */       nm.setFont(this.style.getMarkerLabelFont());
/* 218 */       nm.setLabelColor(this.style.getMarkerLabelColor());
/* 219 */       nm.setLineColor(this.style.getMarkerLineColor());
/* 220 */       nm.setLineStroke(this.style.getMarkerLineStroke());
/* 221 */     } else if (marker instanceof RangeMarker) {
/* 222 */       RangeMarker rm = (RangeMarker)marker;
/* 223 */       rm.setFont(this.style.getMarkerLabelFont());
/* 224 */       rm.setLabelColor(this.style.getMarkerLabelColor());
/* 225 */       rm.setFillColor(this.style.getMarkerFillColor());
/*     */       
/* 227 */       rm.getStart().setFont(this.style.getMarkerLabelFont());
/* 228 */       rm.getStart().setLabelColor(this.style.getMarkerLabelColor());
/* 229 */       rm.getStart().setLineColor(this.style.getMarkerLineColor());
/* 230 */       rm.getStart().setLineStroke(this.style.getMarkerLineStroke());
/* 231 */       rm.getEnd().setFont(this.style.getMarkerLabelFont());
/* 232 */       rm.getEnd().setLabelColor(this.style.getMarkerLabelColor());
/* 233 */       rm.getEnd().setLineColor(this.style.getMarkerLineColor());
/* 234 */       rm.getEnd().setLineStroke(this.style.getMarkerLineStroke());
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/style/ChartStyler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */