/*     */ package com.orsoncharts.style;
/*     */ 
/*     */ import com.orsoncharts.Colors;
/*     */ import com.orsoncharts.table.RectanglePainter;
/*     */ import com.orsoncharts.table.StandardRectanglePainter;
/*     */ import java.awt.Color;
/*     */ import java.awt.Font;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ChartStyles
/*     */ {
/*     */   public static ChartStyle createOrson1Style() {
/*  33 */     StandardChartStyle s = new StandardChartStyle();
/*  34 */     s.setStandardColors(Colors.createFancyLightColors());
/*  35 */     return s;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ChartStyle createOrson2Style() {
/*  46 */     StandardChartStyle s = new StandardChartStyle();
/*  47 */     Color bgcolor = new Color(50, 50, 50, 150);
/*  48 */     s.setTitleColor(Color.LIGHT_GRAY);
/*  49 */     s.setTitleBackgroundColor(bgcolor);
/*  50 */     s.setSubtitleColor(Color.LIGHT_GRAY);
/*  51 */     s.setSubtitleBackgroundColor(bgcolor);
/*  52 */     s.setChartBoxColor(new Color(200, 200, 255, 50));
/*  53 */     s.setSectionLabelColor(Color.LIGHT_GRAY);
/*  54 */     s.setAxisLabelColor(Color.LIGHT_GRAY);
/*  55 */     s.setAxisTickLabelColor(Color.LIGHT_GRAY);
/*  56 */     s.setLegendHeaderColor(Color.LIGHT_GRAY);
/*  57 */     s.setLegendItemColor(Color.LIGHT_GRAY);
/*  58 */     s.setLegendHeaderBackgroundColor(bgcolor);
/*  59 */     s.setLegendItemBackgroundColor(bgcolor);
/*  60 */     s.setLegendFooterColor(Color.LIGHT_GRAY);
/*  61 */     s.setLegendFooterBackgroundColor(bgcolor);
/*  62 */     s.setStandardColors(Colors.createBlueOceanColors());
/*  63 */     s.setBackgroundPainter((RectanglePainter)new StandardRectanglePainter(Color.BLACK));
/*  64 */     s.setMarkerLabelColor(Color.LIGHT_GRAY);
/*  65 */     s.setMarkerLineColor(Color.LIGHT_GRAY);
/*  66 */     s.setMarkerFillColor(new Color(100, 100, 255, 32));
/*  67 */     return s;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ChartStyle createPastelStyle() {
/*  76 */     StandardChartStyle s = new StandardChartStyle();
/*  77 */     s.setStandardColors(Colors.createPastelColors());
/*  78 */     return s;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ChartStyle createIceCubeStyle() {
/*  87 */     StandardChartStyle s = new StandardChartStyle();
/*  88 */     s.setStandardColors(Colors.createIceCubeColors());
/*  89 */     s.setBackgroundPainter((RectanglePainter)new StandardRectanglePainter(Color.WHITE));
/*  90 */     return s;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ChartStyle createLogicalFontStyle() {
/* 101 */     StandardChartStyle s = new StandardChartStyle();
/* 102 */     s.setTitleFont(new Font("SansSerif", 1, 32));
/* 103 */     s.setSubtitleFont(new Font("Serif", 0, 16));
/* 104 */     s.setSectionLabelFont(new Font("Serif", 0, 16));
/* 105 */     s.setAxisLabelFont(new Font("Serif", 1, 16));
/* 106 */     s.setAxisTickLabelFont(new Font("Serif", 0, 14));
/* 107 */     s.setLegendHeaderFont(new Font("Serif", 1, 16));
/* 108 */     s.setLegendItemFont(new Font("Serif", 0, 14));
/* 109 */     s.setLegendFooterFont(new Font("Serif", 2, 10));
/* 110 */     s.setMarkerLabelFont(new Font("Serif", 0, 10));
/* 111 */     s.setStandardColors(Colors.createFancyLightColors());
/* 112 */     return s;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/style/ChartStyles.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */