/*      */ package com.orsoncharts.style;
/*      */ 
/*      */ import com.orsoncharts.Colors;
/*      */ import com.orsoncharts.table.RectanglePainter;
/*      */ import com.orsoncharts.table.StandardRectanglePainter;
/*      */ import com.orsoncharts.util.ArgChecks;
/*      */ import com.orsoncharts.util.SerialUtils;
/*      */ import java.awt.BasicStroke;
/*      */ import java.awt.Color;
/*      */ import java.awt.Font;
/*      */ import java.awt.Shape;
/*      */ import java.awt.Stroke;
/*      */ import java.awt.geom.Rectangle2D;
/*      */ import java.io.IOException;
/*      */ import java.io.ObjectInputStream;
/*      */ import java.io.ObjectOutputStream;
/*      */ import java.io.Serializable;
/*      */ import java.util.Arrays;
/*      */ import javax.swing.event.EventListenerList;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class StandardChartStyle
/*      */   implements ChartStyle, Cloneable, Serializable
/*      */ {
/*      */   private static final String FONT_FAMILY_1 = "Palatino Linotype";
/*      */   private static final String FONT_FAMILY_2 = "Palatino";
/*      */   
/*      */   public static Font createDefaultFont(int style, int size) {
/*   68 */     Font f = new Font("Palatino Linotype", style, size);
/*   69 */     if ("Dialog".equals(f.getFamily())) {
/*   70 */       f = new Font("Palatino", style, size);
/*   71 */       if ("Dialog".equals(f.getFamily())) {
/*   72 */         f = new Font("Serif", style, size);
/*      */       }
/*      */     } 
/*   75 */     return f;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   82 */   public static final Color DEFAULT_TEXT_BACKGROUND_COLOR = new Color(255, 255, 255, 100);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   87 */   public static final Font DEFAULT_TITLE_FONT = createDefaultFont(0, 32);
/*      */ 
/*      */ 
/*      */   
/*   91 */   public static final Font DEFAULT_SUBTITLE_FONT = createDefaultFont(0, 18);
/*      */ 
/*      */   
/*   94 */   public static final Color DEFAULT_CHARTBOX_COLOR = new Color(255, 255, 255, 100);
/*      */ 
/*      */ 
/*      */   
/*      */   public static final boolean DEFAULT_ROW_GRIDLINES_VISIBLE = false;
/*      */ 
/*      */   
/*      */   public static final boolean DEFAULT_COLUMN_GRIDLINES_VISIBLE = false;
/*      */ 
/*      */   
/*      */   public static final boolean DEFAULT_X_GRIDLINES_VISIBLE = true;
/*      */ 
/*      */   
/*      */   public static final boolean DEFAULT_Y_GRIDLINES_VISIBLE = true;
/*      */ 
/*      */   
/*      */   public static final boolean DEFAULT_Z_GRIDLINES_VISIBLE = true;
/*      */ 
/*      */   
/*  113 */   public static final Color DEFAULT_GRIDLINE_COLOR = Color.GRAY;
/*      */ 
/*      */   
/*  116 */   public static final Stroke DEFAULT_GRIDLINE_STROKE = new BasicStroke(0.0F);
/*      */ 
/*      */   
/*  119 */   public static final Font DEFAULT_SECTION_LABEL_FONT = createDefaultFont(0, 14);
/*      */ 
/*      */ 
/*      */   
/*  123 */   public static final Color DEFAULT_SECTION_LABEL_COLOR = Color.BLACK;
/*      */ 
/*      */ 
/*      */   
/*  127 */   public static final Font DEFAULT_AXIS_LABEL_FONT = createDefaultFont(1, 12);
/*      */ 
/*      */   
/*  130 */   public static final Color DEFAULT_AXIS_LABEL_COLOR = Color.BLACK;
/*      */ 
/*      */ 
/*      */   
/*  134 */   public static final Font DEFAULT_AXIS_TICK_LABEL_FONT = createDefaultFont(0, 12);
/*      */ 
/*      */   
/*  137 */   public static final Color DEFAULT_AXIS_TICK_LABEL_COLOR = Color.BLACK;
/*      */ 
/*      */   
/*  140 */   public static final Font DEFAULT_LEGEND_HEADER_FONT = createDefaultFont(1, 14);
/*      */ 
/*      */ 
/*      */   
/*  144 */   public static final Color DEFAULT_LEGEND_HEADER_COLOR = Color.BLACK;
/*      */ 
/*      */   
/*  147 */   public static final Shape DEFAULT_LEGEND_ITEM_SHAPE = new Rectangle2D.Double(-6.0D, -4.0D, 12.0D, 8.0D);
/*      */ 
/*      */ 
/*      */   
/*  151 */   public static final Font DEFAULT_LEGEND_ITEM_FONT = createDefaultFont(0, 12);
/*      */ 
/*      */ 
/*      */   
/*  155 */   public static final Color DEFAULT_LEGEND_ITEM_COLOR = Color.BLACK;
/*      */ 
/*      */   
/*  158 */   public static final Color DEFAULT_LEGEND_ITEM_BACKGROUND_COLOR = new Color(255, 255, 255, 100);
/*      */ 
/*      */ 
/*      */   
/*  162 */   public static final Font DEFAULT_LEGEND_FOOTER_FONT = createDefaultFont(0, 10);
/*      */ 
/*      */ 
/*      */   
/*  166 */   public static final Color DEFAULT_LEGEND_FOOTER_COLOR = Color.BLACK;
/*      */   
/*  168 */   public static final Font DEFAULT_MARKER_LABEL_FONT = createDefaultFont(0, 10);
/*      */ 
/*      */   
/*  171 */   public static final Color DEFAULT_MARKER_LABEL_COLOR = Color.DARK_GRAY;
/*      */   
/*  173 */   public static final Stroke DEFAULT_MARKER_LINE_STROKE = new BasicStroke(2.0F, 1, 1);
/*      */ 
/*      */   
/*  176 */   public static final Color DEFAULT_MARKER_LINE_COLOR = Color.DARK_GRAY;
/*      */   
/*  178 */   public static final Color DEFAULT_MARKER_FILL_COLOR = new Color(127, 127, 127, 63);
/*      */ 
/*      */ 
/*      */   
/*      */   private RectanglePainter backgroundPainter;
/*      */ 
/*      */ 
/*      */   
/*      */   private Font titleFont;
/*      */ 
/*      */ 
/*      */   
/*      */   private Color titleColor;
/*      */ 
/*      */ 
/*      */   
/*      */   private Color titleBackgroundColor;
/*      */ 
/*      */ 
/*      */   
/*      */   private Font subtitleFont;
/*      */ 
/*      */ 
/*      */   
/*      */   private Color subtitleColor;
/*      */ 
/*      */   
/*      */   private Color subtitleBackgroundColor;
/*      */ 
/*      */   
/*      */   private Color chartBoxColor;
/*      */ 
/*      */   
/*      */   private boolean rowAxisGridlinesVisible;
/*      */ 
/*      */   
/*      */   private boolean columnAxisGridlinesVisible;
/*      */ 
/*      */   
/*      */   private boolean xAxisGridlinesVisible;
/*      */ 
/*      */   
/*      */   private boolean yAxisGridlinesVisible;
/*      */ 
/*      */   
/*      */   private boolean zAxisGridlinesVisible;
/*      */ 
/*      */   
/*      */   private Color gridlineColor;
/*      */ 
/*      */   
/*      */   private transient Stroke gridlineStroke;
/*      */ 
/*      */   
/*      */   private Font sectionLabelFont;
/*      */ 
/*      */   
/*      */   private Color sectionLabelColor;
/*      */ 
/*      */   
/*      */   private Color[] standardColors;
/*      */ 
/*      */   
/*      */   private Font axisLabelFont;
/*      */ 
/*      */   
/*      */   private Color axisLabelColor;
/*      */ 
/*      */   
/*      */   private Font axisTickLabelFont;
/*      */ 
/*      */   
/*      */   private Color axisTickLabelColor;
/*      */ 
/*      */   
/*      */   private Font legendHeaderFont;
/*      */ 
/*      */   
/*      */   private Color legendHeaderColor;
/*      */ 
/*      */   
/*      */   private Color legendHeaderBackgroundColor;
/*      */ 
/*      */   
/*      */   private Shape legendItemShape;
/*      */ 
/*      */   
/*      */   private Font legendItemFont;
/*      */ 
/*      */   
/*      */   private Color legendItemColor;
/*      */ 
/*      */   
/*      */   private Color legendItemBackgroundColor;
/*      */ 
/*      */   
/*      */   private Font legendFooterFont;
/*      */ 
/*      */   
/*      */   private Color legendFooterColor;
/*      */ 
/*      */   
/*      */   private Color legendFooterBackgroundColor;
/*      */ 
/*      */   
/*      */   private Font markerLabelFont;
/*      */ 
/*      */   
/*      */   private Color markerLabelColor;
/*      */ 
/*      */   
/*      */   private transient Stroke markerLineStroke;
/*      */ 
/*      */   
/*      */   private Color markerLineColor;
/*      */ 
/*      */   
/*      */   private Color markerFillColor;
/*      */ 
/*      */   
/*      */   private transient EventListenerList listenerList;
/*      */ 
/*      */   
/*      */   private boolean notify;
/*      */ 
/*      */ 
/*      */   
/*      */   public StandardChartStyle() {
/*  306 */     this.backgroundPainter = (RectanglePainter)new StandardRectanglePainter(Color.WHITE);
/*  307 */     this.titleFont = DEFAULT_TITLE_FONT;
/*  308 */     this.titleColor = Color.BLACK;
/*  309 */     this.titleBackgroundColor = DEFAULT_TEXT_BACKGROUND_COLOR;
/*  310 */     this.subtitleColor = Color.BLACK;
/*  311 */     this.subtitleBackgroundColor = DEFAULT_TEXT_BACKGROUND_COLOR;
/*  312 */     this.subtitleFont = DEFAULT_SUBTITLE_FONT;
/*  313 */     this.chartBoxColor = DEFAULT_CHARTBOX_COLOR;
/*  314 */     this.rowAxisGridlinesVisible = false;
/*  315 */     this.columnAxisGridlinesVisible = false;
/*  316 */     this.xAxisGridlinesVisible = true;
/*  317 */     this.yAxisGridlinesVisible = true;
/*  318 */     this.zAxisGridlinesVisible = true;
/*  319 */     this.gridlineColor = DEFAULT_GRIDLINE_COLOR;
/*  320 */     this.gridlineStroke = DEFAULT_GRIDLINE_STROKE;
/*  321 */     this.sectionLabelFont = DEFAULT_SECTION_LABEL_FONT;
/*  322 */     this.sectionLabelColor = DEFAULT_SECTION_LABEL_COLOR;
/*  323 */     this.standardColors = Colors.getDefaultColors();
/*  324 */     this.axisLabelFont = DEFAULT_AXIS_LABEL_FONT;
/*  325 */     this.axisLabelColor = DEFAULT_AXIS_LABEL_COLOR;
/*  326 */     this.axisTickLabelFont = DEFAULT_AXIS_TICK_LABEL_FONT;
/*  327 */     this.axisTickLabelColor = DEFAULT_AXIS_TICK_LABEL_COLOR;
/*  328 */     this.legendHeaderFont = DEFAULT_LEGEND_HEADER_FONT;
/*  329 */     this.legendHeaderColor = DEFAULT_LEGEND_HEADER_COLOR;
/*  330 */     this.legendHeaderBackgroundColor = DEFAULT_TEXT_BACKGROUND_COLOR;
/*  331 */     this.legendItemShape = DEFAULT_LEGEND_ITEM_SHAPE;
/*  332 */     this.legendItemFont = DEFAULT_LEGEND_ITEM_FONT;
/*  333 */     this.legendItemColor = DEFAULT_LEGEND_ITEM_COLOR;
/*  334 */     this.legendItemBackgroundColor = DEFAULT_LEGEND_ITEM_BACKGROUND_COLOR;
/*  335 */     this.legendFooterFont = DEFAULT_LEGEND_FOOTER_FONT;
/*  336 */     this.legendFooterColor = DEFAULT_LEGEND_FOOTER_COLOR;
/*  337 */     this.legendFooterBackgroundColor = DEFAULT_TEXT_BACKGROUND_COLOR;
/*  338 */     this.markerLabelFont = DEFAULT_MARKER_LABEL_FONT;
/*  339 */     this.markerLabelColor = DEFAULT_MARKER_LABEL_COLOR;
/*  340 */     this.markerLineStroke = DEFAULT_MARKER_LINE_STROKE;
/*  341 */     this.markerLineColor = DEFAULT_MARKER_LINE_COLOR;
/*  342 */     this.markerFillColor = DEFAULT_MARKER_FILL_COLOR;
/*  343 */     this.listenerList = new EventListenerList();
/*  344 */     this.notify = true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public StandardChartStyle(StandardChartStyle source) {
/*  355 */     ArgChecks.nullNotPermitted(source, "source");
/*  356 */     this.backgroundPainter = source.getBackgroundPainter();
/*  357 */     this.titleFont = source.getTitleFont();
/*  358 */     this.titleColor = source.getTitleColor();
/*  359 */     this.titleBackgroundColor = source.getTitleBackgroundColor();
/*  360 */     this.subtitleFont = source.getSubtitleFont();
/*  361 */     this.subtitleColor = source.getSubtitleColor();
/*  362 */     this.subtitleBackgroundColor = source.getSubtitleBackgroundColor();
/*  363 */     this.chartBoxColor = source.getChartBoxColor();
/*  364 */     this.xAxisGridlinesVisible = source.getXAxisGridlinesVisible();
/*  365 */     this.yAxisGridlinesVisible = source.getYAxisGridlinesVisible();
/*  366 */     this.zAxisGridlinesVisible = source.getZAxisGridlinesVisible();
/*  367 */     this.sectionLabelFont = source.getSectionLabelFont();
/*  368 */     this.sectionLabelColor = source.getSectionLabelColor();
/*  369 */     this.standardColors = source.getStandardColors();
/*  370 */     this.gridlineColor = source.getGridlineColor();
/*  371 */     this.gridlineStroke = source.getGridlineStroke();
/*  372 */     this.axisLabelFont = source.getAxisLabelFont();
/*  373 */     this.axisLabelColor = source.getAxisLabelColor();
/*  374 */     this.axisTickLabelFont = source.getAxisTickLabelFont();
/*  375 */     this.axisTickLabelColor = source.getAxisTickLabelColor();
/*  376 */     this.legendHeaderFont = source.getLegendHeaderFont();
/*  377 */     this.legendHeaderColor = source.getLegendHeaderColor();
/*  378 */     this
/*  379 */       .legendHeaderBackgroundColor = source.getLegendHeaderBackgroundColor();
/*  380 */     this.legendItemShape = source.getLegendItemShape();
/*  381 */     this.legendItemFont = source.getLegendItemFont();
/*  382 */     this.legendItemColor = source.getLegendItemColor();
/*  383 */     this.legendItemBackgroundColor = source.getLegendItemBackgroundColor();
/*  384 */     this.legendFooterFont = source.getLegendFooterFont();
/*  385 */     this.legendFooterColor = source.getLegendFooterColor();
/*  386 */     this
/*  387 */       .legendFooterBackgroundColor = source.getLegendFooterBackgroundColor();
/*  388 */     this.markerLabelFont = source.getMarkerLabelFont();
/*  389 */     this.markerLabelColor = source.getMarkerLabelColor();
/*  390 */     this.markerLineStroke = source.getMarkerLineStroke();
/*  391 */     this.markerLineColor = source.getMarkerLineColor();
/*  392 */     this.markerFillColor = source.getMarkerFillColor();
/*  393 */     this.listenerList = new EventListenerList();
/*  394 */     this.notify = true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public RectanglePainter getBackgroundPainter() {
/*  404 */     return this.backgroundPainter;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBackgroundPainter(RectanglePainter painter) {
/*  413 */     ArgChecks.nullNotPermitted(painter, "painter");
/*  414 */     this.backgroundPainter = painter;
/*  415 */     fireChangeEvent();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Font getTitleFont() {
/*  426 */     return this.titleFont;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTitleFont(Font font) {
/*  436 */     ArgChecks.nullNotPermitted(font, "font");
/*  437 */     this.titleFont = font;
/*  438 */     fireChangeEvent();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Color getTitleColor() {
/*  448 */     return this.titleColor;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTitleColor(Color color) {
/*  458 */     this.titleColor = color;
/*  459 */     fireChangeEvent();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Color getTitleBackgroundColor() {
/*  470 */     return this.titleBackgroundColor;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTitleBackgroundColor(Color color) {
/*  480 */     this.titleBackgroundColor = color;
/*  481 */     fireChangeEvent();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Font getSubtitleFont() {
/*  492 */     return this.subtitleFont;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSubtitleFont(Font font) {
/*  502 */     ArgChecks.nullNotPermitted(font, "font");
/*  503 */     this.subtitleFont = font;
/*  504 */     fireChangeEvent();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Color getSubtitleColor() {
/*  515 */     return this.subtitleColor;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSubtitleColor(Color color) {
/*  525 */     ArgChecks.nullNotPermitted(color, "color");
/*  526 */     this.subtitleColor = color;
/*  527 */     fireChangeEvent();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Color getSubtitleBackgroundColor() {
/*  538 */     return this.subtitleBackgroundColor;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSubtitleBackgroundColor(Color color) {
/*  548 */     ArgChecks.nullNotPermitted(color, "color");
/*  549 */     this.subtitleBackgroundColor = color;
/*  550 */     fireChangeEvent();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Color getChartBoxColor() {
/*  561 */     return this.chartBoxColor;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setChartBoxColor(Color color) {
/*  571 */     ArgChecks.nullNotPermitted(color, "color");
/*  572 */     this.chartBoxColor = color;
/*  573 */     fireChangeEvent();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getColumnAxisGridlinesVisible() {
/*  584 */     return this.columnAxisGridlinesVisible;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getRowAxisGridlinesVisible() {
/*  595 */     return this.rowAxisGridlinesVisible;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getXAxisGridlinesVisible() {
/*  606 */     return this.xAxisGridlinesVisible;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setXAxisGridlinesVisible(boolean visible) {
/*  617 */     this.xAxisGridlinesVisible = visible;
/*  618 */     fireChangeEvent();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getYAxisGridlinesVisible() {
/*  629 */     return this.yAxisGridlinesVisible;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setYAxisGridlinesVisible(boolean visible) {
/*  640 */     this.yAxisGridlinesVisible = visible;
/*  641 */     fireChangeEvent();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getZAxisGridlinesVisible() {
/*  652 */     return this.zAxisGridlinesVisible;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setZAxisGridlinesVisible(boolean visible) {
/*  663 */     this.zAxisGridlinesVisible = visible;
/*  664 */     fireChangeEvent();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Color getGridlineColor() {
/*  675 */     return this.gridlineColor;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setGridlineColor(Color color) {
/*  685 */     ArgChecks.nullNotPermitted(color, "color");
/*  686 */     this.gridlineColor = color;
/*  687 */     fireChangeEvent();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Stroke getGridlineStroke() {
/*  698 */     return this.gridlineStroke;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setGridlineStroke(Stroke stroke) {
/*  708 */     ArgChecks.nullNotPermitted(stroke, "stroke");
/*  709 */     this.gridlineStroke = stroke;
/*  710 */     fireChangeEvent();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Font getSectionLabelFont() {
/*  720 */     return this.sectionLabelFont;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSectionLabelFont(Font font) {
/*  730 */     ArgChecks.nullNotPermitted(font, "font");
/*  731 */     this.sectionLabelFont = font;
/*  732 */     fireChangeEvent();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Color getSectionLabelColor() {
/*  743 */     return this.sectionLabelColor;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSectionLabelColor(Color color) {
/*  753 */     ArgChecks.nullNotPermitted(color, "color");
/*  754 */     this.sectionLabelColor = color;
/*  755 */     fireChangeEvent();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Color[] getStandardColors() {
/*  766 */     return this.standardColors;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setStandardColors(Color... colors) {
/*  776 */     this.standardColors = colors;
/*  777 */     fireChangeEvent();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Font getAxisLabelFont() {
/*  788 */     return this.axisLabelFont;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAxisLabelFont(Font font) {
/*  798 */     ArgChecks.nullNotPermitted(font, "font");
/*  799 */     this.axisLabelFont = font;
/*  800 */     fireChangeEvent();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Color getAxisLabelColor() {
/*  812 */     return this.axisLabelColor;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAxisLabelColor(Color color) {
/*  822 */     ArgChecks.nullNotPermitted(color, "color");
/*  823 */     this.axisLabelColor = color;
/*  824 */     fireChangeEvent();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Font getAxisTickLabelFont() {
/*  835 */     return this.axisTickLabelFont;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAxisTickLabelFont(Font font) {
/*  845 */     ArgChecks.nullNotPermitted(font, "font");
/*  846 */     this.axisTickLabelFont = font;
/*  847 */     fireChangeEvent();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Color getAxisTickLabelColor() {
/*  858 */     return this.axisTickLabelColor;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAxisTickLabelColor(Color color) {
/*  868 */     ArgChecks.nullNotPermitted(color, "color");
/*  869 */     this.axisTickLabelColor = color;
/*  870 */     fireChangeEvent();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Font getLegendHeaderFont() {
/*  881 */     return this.legendHeaderFont;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setLegendHeaderFont(Font font) {
/*  891 */     ArgChecks.nullNotPermitted(font, "font");
/*  892 */     this.legendHeaderFont = font;
/*  893 */     fireChangeEvent();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Color getLegendHeaderColor() {
/*  904 */     return this.legendHeaderColor;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setLegendHeaderColor(Color color) {
/*  914 */     ArgChecks.nullNotPermitted(color, "color");
/*  915 */     this.legendHeaderColor = color;
/*  916 */     fireChangeEvent();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Color getLegendHeaderBackgroundColor() {
/*  927 */     return this.legendHeaderBackgroundColor;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setLegendHeaderBackgroundColor(Color color) {
/*  937 */     ArgChecks.nullNotPermitted(color, "color");
/*  938 */     this.legendHeaderBackgroundColor = color;
/*  939 */     fireChangeEvent();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Shape getLegendItemShape() {
/*  950 */     return this.legendItemShape;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setLegendItemShape(Shape shape) {
/*  960 */     ArgChecks.nullNotPermitted(shape, "shape");
/*  961 */     this.legendItemShape = shape;
/*  962 */     fireChangeEvent();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Font getLegendItemFont() {
/*  973 */     return this.legendItemFont;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setLegendItemFont(Font font) {
/*  983 */     ArgChecks.nullNotPermitted(font, "font");
/*  984 */     this.legendItemFont = font;
/*  985 */     fireChangeEvent();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Color getLegendItemColor() {
/*  996 */     return this.legendItemColor;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setLegendItemColor(Color color) {
/* 1006 */     ArgChecks.nullNotPermitted(color, "color");
/* 1007 */     this.legendItemColor = color;
/* 1008 */     fireChangeEvent();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Color getLegendItemBackgroundColor() {
/* 1019 */     return this.legendItemBackgroundColor;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setLegendItemBackgroundColor(Color color) {
/* 1029 */     ArgChecks.nullNotPermitted(color, "color");
/* 1030 */     this.legendItemBackgroundColor = color;
/* 1031 */     fireChangeEvent();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Font getLegendFooterFont() {
/* 1042 */     return this.legendFooterFont;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setLegendFooterFont(Font font) {
/* 1052 */     ArgChecks.nullNotPermitted(font, "font");
/* 1053 */     this.legendFooterFont = font;
/* 1054 */     fireChangeEvent();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Color getLegendFooterColor() {
/* 1065 */     return this.legendFooterColor;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setLegendFooterColor(Color color) {
/* 1075 */     ArgChecks.nullNotPermitted(color, "color");
/* 1076 */     this.legendFooterColor = color;
/* 1077 */     fireChangeEvent();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Color getLegendFooterBackgroundColor() {
/* 1088 */     return this.legendFooterBackgroundColor;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setLegendFooterBackgroundColor(Color color) {
/* 1098 */     ArgChecks.nullNotPermitted(color, "color");
/* 1099 */     this.legendFooterBackgroundColor = color;
/* 1100 */     fireChangeEvent();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Font getMarkerLabelFont() {
/* 1110 */     return this.markerLabelFont;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMarkerLabelFont(Font font) {
/* 1120 */     ArgChecks.nullNotPermitted(font, "font");
/* 1121 */     this.markerLabelFont = font;
/* 1122 */     fireChangeEvent();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Color getMarkerLabelColor() {
/* 1132 */     return this.markerLabelColor;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMarkerLabelColor(Color color) {
/* 1142 */     ArgChecks.nullNotPermitted(color, "color");
/* 1143 */     this.markerLabelColor = color;
/* 1144 */     fireChangeEvent();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Stroke getMarkerLineStroke() {
/* 1154 */     return this.markerLineStroke;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMarkerLineStroke(Stroke stroke) {
/* 1164 */     ArgChecks.nullNotPermitted(stroke, "stroke");
/* 1165 */     this.markerLineStroke = stroke;
/* 1166 */     fireChangeEvent();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Color getMarkerLineColor() {
/* 1176 */     return this.markerLineColor;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMarkerLineColor(Color color) {
/* 1186 */     ArgChecks.nullNotPermitted(color, "color");
/* 1187 */     this.markerLineColor = color;
/* 1188 */     fireChangeEvent();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Color getMarkerFillColor() {
/* 1198 */     return this.markerFillColor;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMarkerFillColor(Color color) {
/* 1208 */     ArgChecks.nullNotPermitted(color, "color");
/* 1209 */     this.markerFillColor = color;
/* 1210 */     fireChangeEvent();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addChangeListener(ChartStyleChangeListener listener) {
/* 1222 */     this.listenerList.add(ChartStyleChangeListener.class, listener);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeChangeListener(ChartStyleChangeListener listener) {
/* 1233 */     this.listenerList.remove(ChartStyleChangeListener.class, listener);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void notifyListeners(ChartStyleChangeEvent event) {
/* 1244 */     if (!this.notify) {
/*      */       return;
/*      */     }
/* 1247 */     Object[] listeners = this.listenerList.getListenerList();
/* 1248 */     for (int i = listeners.length - 2; i >= 0; i -= 2) {
/* 1249 */       if (listeners[i] == ChartStyleChangeListener.class) {
/* 1250 */         ((ChartStyleChangeListener)listeners[i + 1]).styleChanged(event);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isNotify() {
/* 1263 */     return this.notify;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNotify(boolean notify) {
/* 1277 */     this.notify = notify;
/*      */     
/* 1279 */     if (notify) {
/* 1280 */       fireChangeEvent();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void fireChangeEvent() {
/* 1288 */     notifyListeners(new ChartStyleChangeEvent(this, this));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ChartStyle clone() {
/*      */     try {
/* 1300 */       return (ChartStyle)super.clone();
/* 1301 */     } catch (CloneNotSupportedException e) {
/* 1302 */       throw new IllegalStateException("If we get here, a bug needs fixing.");
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean equals(Object obj) {
/* 1316 */     if (obj == this) {
/* 1317 */       return true;
/*      */     }
/* 1319 */     if (!(obj instanceof StandardChartStyle)) {
/* 1320 */       return false;
/*      */     }
/* 1322 */     StandardChartStyle that = (StandardChartStyle)obj;
/* 1323 */     if (!this.backgroundPainter.equals(that.backgroundPainter)) {
/* 1324 */       return false;
/*      */     }
/* 1326 */     if (!this.titleFont.equals(that.titleFont)) {
/* 1327 */       return false;
/*      */     }
/* 1329 */     if (!this.titleColor.equals(that.titleColor)) {
/* 1330 */       return false;
/*      */     }
/* 1332 */     if (!this.titleBackgroundColor.equals(that.titleBackgroundColor)) {
/* 1333 */       return false;
/*      */     }
/* 1335 */     if (!this.subtitleFont.equals(that.subtitleFont)) {
/* 1336 */       return false;
/*      */     }
/* 1338 */     if (!this.subtitleColor.equals(that.subtitleColor)) {
/* 1339 */       return false;
/*      */     }
/* 1341 */     if (!this.subtitleBackgroundColor.equals(that.subtitleBackgroundColor))
/*      */     {
/* 1343 */       return false;
/*      */     }
/* 1345 */     if (!this.chartBoxColor.equals(that.chartBoxColor)) {
/* 1346 */       return false;
/*      */     }
/* 1348 */     if (this.rowAxisGridlinesVisible != that.rowAxisGridlinesVisible) {
/* 1349 */       return false;
/*      */     }
/* 1351 */     if (this.columnAxisGridlinesVisible != that.columnAxisGridlinesVisible)
/*      */     {
/* 1353 */       return false;
/*      */     }
/* 1355 */     if (this.xAxisGridlinesVisible != that.xAxisGridlinesVisible) {
/* 1356 */       return false;
/*      */     }
/* 1358 */     if (this.yAxisGridlinesVisible != that.yAxisGridlinesVisible) {
/* 1359 */       return false;
/*      */     }
/* 1361 */     if (this.zAxisGridlinesVisible != that.zAxisGridlinesVisible) {
/* 1362 */       return false;
/*      */     }
/* 1364 */     if (!this.gridlineColor.equals(that.gridlineColor)) {
/* 1365 */       return false;
/*      */     }
/* 1367 */     if (!this.gridlineStroke.equals(that.gridlineStroke)) {
/* 1368 */       return false;
/*      */     }
/* 1370 */     if (!this.sectionLabelFont.equals(that.sectionLabelFont)) {
/* 1371 */       return false;
/*      */     }
/* 1373 */     if (!this.sectionLabelColor.equals(that.sectionLabelColor)) {
/* 1374 */       return false;
/*      */     }
/* 1376 */     if (!Arrays.equals((Object[])this.standardColors, (Object[])that.standardColors)) {
/* 1377 */       return false;
/*      */     }
/* 1379 */     if (!this.axisLabelFont.equals(that.axisLabelFont)) {
/* 1380 */       return false;
/*      */     }
/* 1382 */     if (!this.axisLabelColor.equals(that.axisLabelColor)) {
/* 1383 */       return false;
/*      */     }
/* 1385 */     if (!this.axisTickLabelFont.equals(that.axisTickLabelFont)) {
/* 1386 */       return false;
/*      */     }
/* 1388 */     if (!this.axisTickLabelColor.equals(that.axisTickLabelColor)) {
/* 1389 */       return false;
/*      */     }
/* 1391 */     if (!this.legendHeaderFont.equals(that.legendHeaderFont)) {
/* 1392 */       return false;
/*      */     }
/* 1394 */     if (!this.legendHeaderColor.equals(that.legendHeaderColor)) {
/* 1395 */       return false;
/*      */     }
/* 1397 */     if (!this.legendHeaderBackgroundColor.equals(that.legendHeaderBackgroundColor))
/*      */     {
/* 1399 */       return false;
/*      */     }
/* 1401 */     if (!this.legendItemShape.equals(that.legendItemShape)) {
/* 1402 */       return false;
/*      */     }
/* 1404 */     if (!this.legendItemFont.equals(that.legendItemFont)) {
/* 1405 */       return false;
/*      */     }
/* 1407 */     if (!this.legendItemColor.equals(that.legendItemColor)) {
/* 1408 */       return false;
/*      */     }
/* 1410 */     if (!this.legendItemBackgroundColor.equals(that.legendItemBackgroundColor))
/*      */     {
/* 1412 */       return false;
/*      */     }
/* 1414 */     if (!this.legendFooterFont.equals(that.legendFooterFont)) {
/* 1415 */       return false;
/*      */     }
/* 1417 */     if (!this.legendFooterColor.equals(that.legendFooterColor)) {
/* 1418 */       return false;
/*      */     }
/* 1420 */     if (!this.legendFooterBackgroundColor.equals(that.legendFooterBackgroundColor))
/*      */     {
/* 1422 */       return false;
/*      */     }
/* 1424 */     if (!this.markerLabelFont.equals(that.markerLabelFont)) {
/* 1425 */       return false;
/*      */     }
/* 1427 */     if (!this.markerLabelColor.equals(that.markerLabelColor)) {
/* 1428 */       return false;
/*      */     }
/* 1430 */     if (!this.markerLineColor.equals(that.markerLineColor)) {
/* 1431 */       return false;
/*      */     }
/* 1433 */     if (!this.markerLineStroke.equals(that.markerLineStroke)) {
/* 1434 */       return false;
/*      */     }
/* 1436 */     if (!this.markerFillColor.equals(that.markerFillColor)) {
/* 1437 */       return false;
/*      */     }
/* 1439 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void writeObject(ObjectOutputStream stream) throws IOException {
/* 1450 */     stream.defaultWriteObject();
/* 1451 */     SerialUtils.writeStroke(this.gridlineStroke, stream);
/* 1452 */     SerialUtils.writeStroke(this.markerLineStroke, stream);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void readObject(ObjectInputStream stream) throws IOException, ClassNotFoundException {
/* 1465 */     stream.defaultReadObject();
/* 1466 */     this.gridlineStroke = SerialUtils.readStroke(stream);
/* 1467 */     this.markerLineStroke = SerialUtils.readStroke(stream);
/*      */   }
/*      */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/style/StandardChartStyle.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */