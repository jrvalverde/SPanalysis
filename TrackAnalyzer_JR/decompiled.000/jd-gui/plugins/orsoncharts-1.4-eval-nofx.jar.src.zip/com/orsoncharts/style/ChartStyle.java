package com.orsoncharts.style;

import com.orsoncharts.table.RectanglePainter;
import java.awt.Color;
import java.awt.Font;
import java.awt.Shape;
import java.awt.Stroke;

public interface ChartStyle {
  RectanglePainter getBackgroundPainter();
  
  Font getTitleFont();
  
  Color getTitleColor();
  
  Color getTitleBackgroundColor();
  
  Font getSubtitleFont();
  
  Color getSubtitleColor();
  
  Color getSubtitleBackgroundColor();
  
  Color getChartBoxColor();
  
  boolean getColumnAxisGridlinesVisible();
  
  boolean getRowAxisGridlinesVisible();
  
  boolean getXAxisGridlinesVisible();
  
  boolean getYAxisGridlinesVisible();
  
  boolean getZAxisGridlinesVisible();
  
  Color getGridlineColor();
  
  Stroke getGridlineStroke();
  
  Font getSectionLabelFont();
  
  Color getSectionLabelColor();
  
  Color[] getStandardColors();
  
  Font getAxisLabelFont();
  
  Color getAxisLabelColor();
  
  Font getAxisTickLabelFont();
  
  Color getAxisTickLabelColor();
  
  Font getLegendHeaderFont();
  
  Color getLegendHeaderColor();
  
  Color getLegendHeaderBackgroundColor();
  
  Shape getLegendItemShape();
  
  Font getLegendItemFont();
  
  Color getLegendItemColor();
  
  Color getLegendItemBackgroundColor();
  
  Font getLegendFooterFont();
  
  Color getLegendFooterColor();
  
  Color getLegendFooterBackgroundColor();
  
  Font getMarkerLabelFont();
  
  Color getMarkerLabelColor();
  
  Stroke getMarkerLineStroke();
  
  Color getMarkerLineColor();
  
  Color getMarkerFillColor();
  
  ChartStyle clone();
  
  void addChangeListener(ChartStyleChangeListener paramChartStyleChangeListener);
  
  void removeChangeListener(ChartStyleChangeListener paramChartStyleChangeListener);
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/style/ChartStyle.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */