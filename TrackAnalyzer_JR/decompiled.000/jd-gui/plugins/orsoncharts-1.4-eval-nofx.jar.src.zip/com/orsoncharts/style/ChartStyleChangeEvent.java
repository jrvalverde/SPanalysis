/*    */ package com.orsoncharts.style;
/*    */ 
/*    */ import com.orsoncharts.util.ArgChecks;
/*    */ import java.util.EventObject;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ChartStyleChangeEvent
/*    */   extends EventObject
/*    */ {
/*    */   private ChartStyle style;
/*    */   
/*    */   public ChartStyleChangeEvent(ChartStyle style) {
/* 39 */     this(style, style);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ChartStyleChangeEvent(Object source, ChartStyle style) {
/* 49 */     super(source);
/* 50 */     ArgChecks.nullNotPermitted(style, "style");
/* 51 */     this.style = style;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ChartStyle getChartStyle() {
/* 60 */     return this.style;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/style/ChartStyleChangeEvent.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */