package com.orsoncharts.style;

import java.util.EventListener;

public interface ChartStyleChangeListener extends EventListener {
  void styleChanged(ChartStyleChangeEvent paramChartStyleChangeEvent);
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/style/ChartStyleChangeListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */