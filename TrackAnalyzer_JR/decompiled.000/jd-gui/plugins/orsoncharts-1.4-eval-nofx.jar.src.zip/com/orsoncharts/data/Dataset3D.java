package com.orsoncharts.data;

import java.util.EventListener;

public interface Dataset3D {
  void addChangeListener(Dataset3DChangeListener paramDataset3DChangeListener);
  
  void removeChangeListener(Dataset3DChangeListener paramDataset3DChangeListener);
  
  boolean hasListener(EventListener paramEventListener);
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/data/Dataset3D.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */