package com.orsoncharts.data;

public interface Values3D<T> {
  int getSeriesCount();
  
  int getRowCount();
  
  int getColumnCount();
  
  T getValue(int paramInt1, int paramInt2, int paramInt3);
  
  double getDoubleValue(int paramInt1, int paramInt2, int paramInt3);
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/data/Values3D.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */