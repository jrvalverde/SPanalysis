package com.orsoncharts.data;

import java.util.List;

public interface KeyedValues3D<T> extends Values3D<T> {
  List<Comparable<?>> getSeriesKeys();
  
  List<Comparable<?>> getRowKeys();
  
  List<Comparable<?>> getColumnKeys();
  
  Comparable<?> getSeriesKey(int paramInt);
  
  Comparable<?> getRowKey(int paramInt);
  
  Comparable<?> getColumnKey(int paramInt);
  
  int getSeriesIndex(Comparable<?> paramComparable);
  
  int getRowIndex(Comparable<?> paramComparable);
  
  int getColumnIndex(Comparable<?> paramComparable);
  
  T getValue(Comparable<?> paramComparable1, Comparable<?> paramComparable2, Comparable<?> paramComparable3);
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/data/KeyedValues3D.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */