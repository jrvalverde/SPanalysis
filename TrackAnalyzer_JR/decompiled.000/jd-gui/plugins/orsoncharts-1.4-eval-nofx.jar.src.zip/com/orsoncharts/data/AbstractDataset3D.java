/*     */ package com.orsoncharts.data;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.EventListener;
/*     */ import java.util.List;
/*     */ import javax.swing.event.EventListenerList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AbstractDataset3D
/*     */   implements Dataset3D
/*     */ {
/*  40 */   private transient EventListenerList listenerList = new EventListenerList();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean notify;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isNotify() {
/*  52 */     return this.notify;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setNotify(boolean notify) {
/*  64 */     this.notify = notify;
/*     */     
/*  66 */     if (notify) {
/*  67 */       fireChangeEvent();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addChangeListener(Dataset3DChangeListener listener) {
/*  80 */     this.listenerList.add(Dataset3DChangeListener.class, listener);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeChangeListener(Dataset3DChangeListener listener) {
/*  93 */     this.listenerList.remove(Dataset3DChangeListener.class, listener);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasListener(EventListener listener) {
/* 110 */     List<?> list = Arrays.asList(this.listenerList.getListenerList());
/* 111 */     return list.contains(listener);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void fireDatasetChanged() {
/* 120 */     notifyListeners(new Dataset3DChangeEvent(this, this));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void notifyListeners(Dataset3DChangeEvent event) {
/* 137 */     if (!this.notify) {
/*     */       return;
/*     */     }
/* 140 */     Object[] listeners = this.listenerList.getListenerList();
/* 141 */     for (int i = listeners.length - 2; i >= 0; i -= 2) {
/* 142 */       if (listeners[i] == Dataset3DChangeListener.class) {
/* 143 */         ((Dataset3DChangeListener)listeners[i + 1])
/* 144 */           .datasetChanged(event);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void fireChangeEvent() {
/* 155 */     notifyListeners(new Dataset3DChangeEvent(this, this));
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/data/AbstractDataset3D.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */