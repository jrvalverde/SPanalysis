package com.orsoncharts.data;

public interface KeyedValue<T> {
  Comparable<?> getKey();
  
  T getValue();
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/data/KeyedValue.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */