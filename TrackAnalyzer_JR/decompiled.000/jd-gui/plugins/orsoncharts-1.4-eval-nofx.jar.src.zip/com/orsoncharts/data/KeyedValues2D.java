package com.orsoncharts.data;

import java.util.List;

public interface KeyedValues2D<T> extends Values2D<T> {
  Comparable<?> getRowKey(int paramInt);
  
  Comparable<?> getColumnKey(int paramInt);
  
  int getRowIndex(Comparable<?> paramComparable);
  
  int getColumnIndex(Comparable<?> paramComparable);
  
  List<Comparable<?>> getRowKeys();
  
  List<Comparable<?>> getColumnKeys();
  
  T getValue(Comparable<?> paramComparable1, Comparable<?> paramComparable2);
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/data/KeyedValues2D.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */