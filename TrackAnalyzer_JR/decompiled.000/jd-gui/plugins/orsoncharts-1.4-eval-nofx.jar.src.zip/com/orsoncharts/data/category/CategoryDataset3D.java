package com.orsoncharts.data.category;

import com.orsoncharts.data.Dataset3D;
import com.orsoncharts.data.KeyedValues3D;

public interface CategoryDataset3D extends KeyedValues3D<Number>, Dataset3D {}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/data/category/CategoryDataset3D.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */