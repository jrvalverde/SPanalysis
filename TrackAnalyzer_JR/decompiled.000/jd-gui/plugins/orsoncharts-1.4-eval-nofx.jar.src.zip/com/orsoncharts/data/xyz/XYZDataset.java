package com.orsoncharts.data.xyz;

import com.orsoncharts.data.Dataset3D;
import java.util.List;

public interface XYZDataset extends Dataset3D {
  int getSeriesCount();
  
  List<Comparable<?>> getSeriesKeys();
  
  Comparable<?> getSeriesKey(int paramInt);
  
  int getSeriesIndex(Comparable<?> paramComparable);
  
  int getItemCount(int paramInt);
  
  double getX(int paramInt1, int paramInt2);
  
  double getY(int paramInt1, int paramInt2);
  
  double getZ(int paramInt1, int paramInt2);
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/data/xyz/XYZDataset.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */