/*     */ package com.orsoncharts.data.xyz;
/*     */ 
/*     */ import com.orsoncharts.util.ArgChecks;
/*     */ import com.orsoncharts.util.ObjectUtils;
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XYZSeries
/*     */   implements Serializable
/*     */ {
/*     */   private final Comparable<?> key;
/*     */   private final List<XYZDataItem> items;
/*     */   
/*     */   public XYZSeries(Comparable<?> key) {
/*  46 */     ArgChecks.nullNotPermitted(key, "key");
/*  47 */     this.key = key;
/*  48 */     this.items = new ArrayList<XYZDataItem>();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Comparable<?> getKey() {
/*  57 */     return this.key;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getItemCount() {
/*  66 */     return this.items.size();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getXValue(int itemIndex) {
/*  77 */     return ((XYZDataItem)this.items.get(itemIndex)).getX();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getYValue(int itemIndex) {
/*  88 */     return ((XYZDataItem)this.items.get(itemIndex)).getY();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getZValue(int itemIndex) {
/*  99 */     return ((XYZDataItem)this.items.get(itemIndex)).getZ();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void add(double x, double y, double z) {
/* 110 */     add(new XYZDataItem(x, y, z));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void add(XYZDataItem item) {
/* 119 */     ArgChecks.nullNotPermitted(item, "item");
/* 120 */     this.items.add(item);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 132 */     if (obj == this) {
/* 133 */       return true;
/*     */     }
/* 135 */     if (!(obj instanceof XYZSeries)) {
/* 136 */       return false;
/*     */     }
/* 138 */     XYZSeries that = (XYZSeries)obj;
/* 139 */     if (!this.key.equals(that.key)) {
/* 140 */       return false;
/*     */     }
/* 142 */     if (!this.items.equals(that.items)) {
/* 143 */       return false;
/*     */     }
/* 145 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 150 */     int hash = 7;
/* 151 */     hash = 41 * hash + ObjectUtils.hashCode(this.key);
/* 152 */     return hash;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/data/xyz/XYZSeries.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */