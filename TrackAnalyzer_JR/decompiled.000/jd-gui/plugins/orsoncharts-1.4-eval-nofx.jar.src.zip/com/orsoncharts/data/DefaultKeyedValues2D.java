/*     */ package com.orsoncharts.data;
/*     */ 
/*     */ import com.orsoncharts.util.ArgChecks;
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class DefaultKeyedValues2D<T>
/*     */   implements KeyedValues2D<T>, Serializable
/*     */ {
/*     */   List<Comparable<?>> rowKeys;
/*     */   List<Comparable<?>> columnKeys;
/*     */   List<DefaultKeyedValues<T>> data;
/*     */   
/*     */   public DefaultKeyedValues2D() {
/*  46 */     this(new ArrayList<Comparable<?>>(), new ArrayList<Comparable<?>>());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DefaultKeyedValues2D(List<Comparable<?>> rowKeys, List<Comparable<?>> columnKeys) {
/*  58 */     ArgChecks.nullNotPermitted(rowKeys, "rowKeys");
/*  59 */     ArgChecks.nullNotPermitted(columnKeys, "columnKeys");
/*  60 */     this.rowKeys = new ArrayList<Comparable<?>>(rowKeys);
/*  61 */     this.columnKeys = new ArrayList<Comparable<?>>(columnKeys);
/*  62 */     this.data = new ArrayList<DefaultKeyedValues<T>>();
/*  63 */     for (int i = 0; i < rowKeys.size(); i++) {
/*  64 */       this.data.add(new DefaultKeyedValues<T>(columnKeys));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Comparable<?> getRowKey(int rowIndex) {
/*  77 */     return this.rowKeys.get(rowIndex);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Comparable<?> getColumnKey(int columnIndex) {
/*  89 */     return this.columnKeys.get(columnIndex);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getRowIndex(Comparable<?> rowKey) {
/* 101 */     ArgChecks.nullNotPermitted(rowKey, "rowKey");
/* 102 */     return this.rowKeys.indexOf(rowKey);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getColumnIndex(Comparable<?> columnKey) {
/* 114 */     ArgChecks.nullNotPermitted(columnKey, "columnKey");
/* 115 */     return this.columnKeys.indexOf(columnKey);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Comparable<?>> getRowKeys() {
/* 125 */     return new ArrayList<Comparable<?>>(this.rowKeys);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Comparable<?>> getColumnKeys() {
/* 135 */     return new ArrayList<Comparable<?>>(this.columnKeys);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getRowCount() {
/* 145 */     return this.rowKeys.size();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getColumnCount() {
/* 155 */     return this.columnKeys.size();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T getValue(Comparable<?> rowKey, Comparable<?> columnKey) {
/* 169 */     int rowIndex = getRowIndex(rowKey);
/* 170 */     int columnIndex = getColumnIndex(columnKey);
/* 171 */     return getValue(rowIndex, columnIndex);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T getValue(int rowIndex, int columnIndex) {
/* 184 */     return ((DefaultKeyedValues<T>)this.data.get(rowIndex)).getValue(columnIndex);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getDoubleValue(int rowIndex, int columnIndex) {
/* 199 */     T n = getValue(rowIndex, columnIndex);
/* 200 */     if (n != null && n instanceof Number) {
/* 201 */       return ((Number)n).doubleValue();
/*     */     }
/* 203 */     return Double.NaN;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setValue(T n, Comparable<?> rowKey, Comparable<?> columnKey) {
/* 214 */     ArgChecks.nullNotPermitted(rowKey, "rowKey");
/* 215 */     ArgChecks.nullNotPermitted(columnKey, "columnKey");
/*     */     
/* 217 */     if (this.data.isEmpty()) {
/* 218 */       this.rowKeys.add(rowKey);
/* 219 */       this.columnKeys.add(columnKey);
/* 220 */       DefaultKeyedValues<T> dkvs = new DefaultKeyedValues<T>();
/* 221 */       dkvs.put(columnKey, n);
/* 222 */       this.data.add(dkvs);
/*     */     } else {
/* 224 */       int rowIndex = getRowIndex(rowKey);
/* 225 */       int columnIndex = getColumnIndex(columnKey);
/* 226 */       if (rowIndex >= 0) {
/* 227 */         DefaultKeyedValues<T> dkvs = this.data.get(rowIndex);
/* 228 */         if (columnIndex >= 0)
/*     */         {
/* 230 */           dkvs.put(columnKey, n);
/*     */         }
/*     */         else
/*     */         {
/* 234 */           this.columnKeys.add(columnKey);
/* 235 */           for (DefaultKeyedValues<T> kv : this.data) {
/* 236 */             kv.put(columnKey, null);
/*     */           }
/* 238 */           dkvs.put(columnKey, n);
/*     */         }
/*     */       
/* 241 */       } else if (columnIndex >= 0) {
/*     */         
/* 243 */         this.rowKeys.add(rowKey);
/* 244 */         DefaultKeyedValues<T> d = new DefaultKeyedValues<T>(this.columnKeys);
/*     */         
/* 246 */         d.put(columnKey, n);
/* 247 */         this.data.add(d);
/*     */       }
/*     */       else {
/*     */         
/* 251 */         this.rowKeys.add(rowKey);
/* 252 */         this.columnKeys.add(columnKey);
/* 253 */         for (DefaultKeyedValues<T> kv : this.data) {
/* 254 */           kv.put(columnKey, null);
/*     */         }
/* 256 */         DefaultKeyedValues<T> d = new DefaultKeyedValues<T>(this.columnKeys);
/*     */         
/* 258 */         d.put(columnKey, n);
/* 259 */         this.data.add(d);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 267 */     if (obj == this) {
/* 268 */       return true;
/*     */     }
/* 270 */     if (!(obj instanceof DefaultKeyedValues2D)) {
/* 271 */       return false;
/*     */     }
/* 273 */     DefaultKeyedValues2D<?> that = (DefaultKeyedValues2D)obj;
/* 274 */     if (!this.rowKeys.equals(that.rowKeys)) {
/* 275 */       return false;
/*     */     }
/* 277 */     if (!this.columnKeys.equals(that.columnKeys)) {
/* 278 */       return false;
/*     */     }
/* 280 */     if (!this.data.equals(that.data)) {
/* 281 */       return false;
/*     */     }
/* 283 */     return true;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/data/DefaultKeyedValues2D.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */