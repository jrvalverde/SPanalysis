/*    */ package com.orsoncharts.data.function;
/*    */ 
/*    */ import com.orsoncharts.Range;
/*    */ import com.orsoncharts.util.ArgChecks;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Function3DUtils
/*    */ {
/*    */   public static Range findYRange(Function3D f, Range xRange, Range zRange, int xSamples, int zSamples, boolean ignoreNaN) {
/* 45 */     ArgChecks.nullNotPermitted(f, "f");
/* 46 */     ArgChecks.nullNotPermitted(xRange, "xRange");
/* 47 */     ArgChecks.nullNotPermitted(zRange, "zRange");
/* 48 */     double min = Double.POSITIVE_INFINITY;
/* 49 */     double max = Double.NEGATIVE_INFINITY;
/* 50 */     for (int xIndex = 0; xIndex <= xSamples - 1; xIndex++) {
/* 51 */       double fracX = xIndex / (xSamples - 1.0D);
/* 52 */       double x = xRange.value(fracX);
/* 53 */       for (int zIndex = 0; zIndex <= zSamples - 1; zIndex++) {
/* 54 */         double fracZ = zIndex / (zSamples - 1.0D);
/* 55 */         double z = zRange.value(fracZ);
/* 56 */         double y = f.getValue(x, z);
/* 57 */         if (!Double.isNaN(y) || !ignoreNaN) {
/*    */ 
/*    */           
/* 60 */           min = Math.min(y, min);
/* 61 */           max = Math.max(y, max);
/*    */         } 
/*    */       } 
/* 64 */     }  if (min <= max) {
/* 65 */       return new Range(min, max);
/*    */     }
/* 67 */     return null;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/data/function/Function3DUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */