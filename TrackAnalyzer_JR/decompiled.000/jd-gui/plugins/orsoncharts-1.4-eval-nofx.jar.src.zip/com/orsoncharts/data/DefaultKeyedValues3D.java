/*     */ package com.orsoncharts.data;
/*     */ 
/*     */ import com.orsoncharts.util.ArgChecks;
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class DefaultKeyedValues3D<V>
/*     */   implements KeyedValues3D<V>, Serializable
/*     */ {
/*  52 */   private List<Comparable<?>> seriesKeys = new ArrayList<Comparable<?>>();
/*  53 */   private List<Comparable<?>> rowKeys = new ArrayList<Comparable<?>>();
/*  54 */   private List<Comparable<?>> columnKeys = new ArrayList<Comparable<?>>();
/*  55 */   private List<DefaultKeyedValues2D<V>> data = new ArrayList<DefaultKeyedValues2D<V>>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Comparable<?> getSeriesKey(int seriesIndex) {
/*  67 */     return this.seriesKeys.get(seriesIndex);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Comparable<?> getRowKey(int rowIndex) {
/*  79 */     return this.rowKeys.get(rowIndex);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Comparable<?> getColumnKey(int columnIndex) {
/*  91 */     return this.columnKeys.get(columnIndex);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getSeriesIndex(Comparable<?> seriesKey) {
/* 104 */     ArgChecks.nullNotPermitted(seriesKey, "seriesKey");
/* 105 */     return this.seriesKeys.indexOf(seriesKey);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getRowIndex(Comparable<?> rowKey) {
/* 118 */     ArgChecks.nullNotPermitted(rowKey, "rowKey");
/* 119 */     return this.rowKeys.indexOf(rowKey);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getColumnIndex(Comparable<?> columnKey) {
/* 132 */     ArgChecks.nullNotPermitted(columnKey, "columnKey");
/* 133 */     return this.columnKeys.indexOf(columnKey);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Comparable<?>> getSeriesKeys() {
/* 145 */     return new ArrayList<Comparable<?>>(this.seriesKeys);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Comparable<?>> getRowKeys() {
/* 157 */     return new ArrayList<Comparable<?>>(this.rowKeys);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Comparable<?>> getColumnKeys() {
/* 169 */     return new ArrayList<Comparable<?>>(this.columnKeys);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getSeriesCount() {
/* 174 */     return this.seriesKeys.size();
/*     */   }
/*     */ 
/*     */   
/*     */   public int getRowCount() {
/* 179 */     return this.rowKeys.size();
/*     */   }
/*     */ 
/*     */   
/*     */   public int getColumnCount() {
/* 184 */     return this.columnKeys.size();
/*     */   }
/*     */ 
/*     */   
/*     */   public V getValue(int seriesIndex, int rowIndex, int columnIndex) {
/* 189 */     return ((DefaultKeyedValues2D<V>)this.data.get(seriesIndex)).getValue(rowIndex, columnIndex);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public V getValue(Comparable<?> seriesKey, Comparable<?> rowKey, Comparable<?> columnKey) {
/* 206 */     int seriesIndex = getSeriesIndex(seriesKey);
/* 207 */     if (seriesIndex < 0) {
/* 208 */       throw new IllegalArgumentException("Series '" + seriesKey.toString() + "' is not found.");
/*     */     }
/*     */     
/* 211 */     int rowIndex = getRowIndex(rowKey);
/* 212 */     if (rowIndex < 0) {
/* 213 */       throw new IllegalArgumentException("Row key '" + rowKey.toString() + "' is not found.");
/*     */     }
/*     */     
/* 216 */     int columnIndex = getColumnIndex(columnKey);
/* 217 */     if (columnIndex < 0) {
/* 218 */       throw new IllegalArgumentException("Column key '" + columnKey
/* 219 */           .toString() + "' is not found.");
/*     */     }
/* 221 */     return getValue(seriesIndex, rowIndex, columnIndex);
/*     */   }
/*     */ 
/*     */   
/*     */   public double getDoubleValue(int seriesIndex, int rowIndex, int columnIndex) {
/* 226 */     V n = getValue(seriesIndex, rowIndex, columnIndex);
/* 227 */     if (n != null && n instanceof Number) {
/* 228 */       return ((Number)n).doubleValue();
/*     */     }
/* 230 */     return Double.NaN;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setValue(V n, Comparable<?> seriesKey, Comparable<?> rowKey, Comparable<?> columnKey) {
/* 244 */     ArgChecks.nullNotPermitted(seriesKey, "seriesKey");
/* 245 */     ArgChecks.nullNotPermitted(rowKey, "rowKey");
/* 246 */     ArgChecks.nullNotPermitted(columnKey, "columnKey");
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 251 */     if (this.data.isEmpty()) {
/* 252 */       this.seriesKeys.add(seriesKey);
/* 253 */       this.rowKeys.add(rowKey);
/* 254 */       this.columnKeys.add(columnKey);
/* 255 */       DefaultKeyedValues2D<V> d = new DefaultKeyedValues2D<V>();
/* 256 */       d.setValue(n, rowKey, columnKey);
/* 257 */       this.data.add(d);
/*     */     } 
/*     */     
/* 260 */     int seriesIndex = getSeriesIndex(seriesKey);
/* 261 */     int rowIndex = getRowIndex(rowKey);
/* 262 */     int columnIndex = getColumnIndex(columnKey);
/* 263 */     if (rowIndex < 0) {
/* 264 */       this.rowKeys.add(rowKey);
/*     */     }
/* 266 */     if (columnIndex < 0) {
/* 267 */       this.columnKeys.add(columnKey);
/*     */     }
/* 269 */     if (rowIndex < 0 || columnIndex < 0) {
/* 270 */       for (DefaultKeyedValues2D<V> d : this.data) {
/* 271 */         d.setValue(null, rowKey, columnKey);
/*     */       }
/*     */     }
/* 274 */     if (seriesIndex >= 0) {
/* 275 */       DefaultKeyedValues2D<V> d = this.data.get(seriesIndex);
/* 276 */       d.setValue(n, rowKey, columnKey);
/*     */     } else {
/* 278 */       this.seriesKeys.add(seriesKey);
/* 279 */       DefaultKeyedValues2D<V> d = new DefaultKeyedValues2D<V>(this.rowKeys, this.columnKeys);
/*     */       
/* 281 */       d.setValue(n, rowKey, columnKey);
/* 282 */       this.data.add(d);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 295 */     if (obj == this) {
/* 296 */       return true;
/*     */     }
/* 298 */     if (!(obj instanceof DefaultKeyedValues3D)) {
/* 299 */       return false;
/*     */     }
/* 301 */     DefaultKeyedValues3D<?> that = (DefaultKeyedValues3D)obj;
/* 302 */     if (!this.seriesKeys.equals(that.seriesKeys)) {
/* 303 */       return false;
/*     */     }
/* 305 */     if (!this.rowKeys.equals(that.rowKeys)) {
/* 306 */       return false;
/*     */     }
/* 308 */     if (!this.columnKeys.equals(that.columnKeys)) {
/* 309 */       return false;
/*     */     }
/* 311 */     if (!this.data.equals(that.data)) {
/* 312 */       return false;
/*     */     }
/* 314 */     return true;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/data/DefaultKeyedValues3D.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */