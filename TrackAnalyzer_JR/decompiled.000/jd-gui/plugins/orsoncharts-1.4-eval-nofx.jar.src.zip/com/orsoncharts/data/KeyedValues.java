package com.orsoncharts.data;

import java.util.List;

public interface KeyedValues<T> extends Values<T> {
  Comparable<?> getKey(int paramInt);
  
  int getIndex(Comparable<?> paramComparable);
  
  List<Comparable<?>> getKeys();
  
  T getValue(Comparable<?> paramComparable);
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/data/KeyedValues.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */