/*     */ package com.orsoncharts.data;
/*     */ 
/*     */ import com.orsoncharts.data.category.StandardCategoryDataset3D;
/*     */ import com.orsoncharts.data.xyz.XYZDataset;
/*     */ import com.orsoncharts.data.xyz.XYZSeries;
/*     */ import com.orsoncharts.data.xyz.XYZSeriesCollection;
/*     */ import com.orsoncharts.util.ArgChecks;
/*     */ import com.orsoncharts.util.json.JSONValue;
/*     */ import com.orsoncharts.util.json.parser.ContainerFactory;
/*     */ import com.orsoncharts.util.json.parser.JSONParser;
/*     */ import com.orsoncharts.util.json.parser.ParseException;
/*     */ import java.io.IOException;
/*     */ import java.io.Reader;
/*     */ import java.io.StringReader;
/*     */ import java.io.StringWriter;
/*     */ import java.io.Writer;
/*     */ import java.util.ArrayList;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JSONUtils
/*     */ {
/*     */   public static KeyedValues<? extends Number> readKeyedValues(String json) {
/*     */     KeyedValues<? extends Number> result;
/*  53 */     ArgChecks.nullNotPermitted(json, "json");
/*  54 */     StringReader in = new StringReader(json);
/*     */     
/*     */     try {
/*  57 */       result = readKeyedValues(in);
/*  58 */     } catch (IOException ex) {
/*     */       
/*  60 */       result = null;
/*     */     } 
/*  62 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static KeyedValues<? extends Number> readKeyedValues(Reader reader) throws IOException {
/*  80 */     ArgChecks.nullNotPermitted(reader, "reader");
/*     */     try {
/*  82 */       JSONParser parser = new JSONParser();
/*     */       
/*  84 */       List list = (List)parser.parse(reader, createContainerFactory());
/*  85 */       StandardPieDataset3D result = new StandardPieDataset3D();
/*  86 */       for (Object item : list) {
/*  87 */         List<Comparable> itemAsList = (List)item;
/*  88 */         result.add(itemAsList.get(0), (Number)itemAsList
/*  89 */             .get(1));
/*     */       } 
/*  91 */       return result;
/*  92 */     } catch (ParseException ex) {
/*  93 */       throw new RuntimeException(ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String writeKeyedValues(KeyedValues<? extends Number> data) {
/* 111 */     ArgChecks.nullNotPermitted(data, "data");
/* 112 */     StringWriter sw = new StringWriter();
/*     */     try {
/* 114 */       writeKeyedValues(data, sw);
/* 115 */     } catch (IOException ex) {
/* 116 */       throw new RuntimeException(ex);
/*     */     } 
/* 118 */     return sw.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void writeKeyedValues(KeyedValues<? extends Number> data, Writer writer) throws IOException {
/* 133 */     ArgChecks.nullNotPermitted(data, "data");
/* 134 */     ArgChecks.nullNotPermitted(writer, "writer");
/* 135 */     writer.write("[");
/* 136 */     boolean first = true;
/* 137 */     for (Comparable<?> key : data.getKeys()) {
/* 138 */       if (!first) {
/* 139 */         writer.write(", ");
/*     */       } else {
/* 141 */         first = false;
/*     */       } 
/* 143 */       writer.write("[");
/* 144 */       writer.write(JSONValue.toJSONString(key.toString()));
/* 145 */       writer.write(", ");
/* 146 */       writer.write(JSONValue.toJSONString(data.getValue(key)));
/* 147 */       writer.write("]");
/*     */     } 
/* 149 */     writer.write("]");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static KeyedValues2D<? extends Number> readKeyedValues2D(String json) {
/*     */     KeyedValues2D<? extends Number> result;
/* 161 */     ArgChecks.nullNotPermitted(json, "json");
/* 162 */     StringReader in = new StringReader(json);
/*     */     
/*     */     try {
/* 165 */       result = readKeyedValues2D(in);
/* 166 */     } catch (IOException ex) {
/*     */       
/* 168 */       result = null;
/*     */     } 
/* 170 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static KeyedValues2D<? extends Number> readKeyedValues2D(Reader reader) throws IOException {
/* 186 */     JSONParser parser = new JSONParser();
/*     */     try {
/* 188 */       Map map = (Map)parser.parse(reader, createContainerFactory());
/* 189 */       DefaultKeyedValues2D<? extends Number> result = new DefaultKeyedValues2D();
/* 190 */       if (map.isEmpty()) {
/* 191 */         return result;
/*     */       }
/*     */ 
/*     */       
/* 195 */       Object keysObj = map.get("columnKeys");
/* 196 */       List<?> keys = null;
/* 197 */       if (keysObj instanceof List) {
/* 198 */         keys = (List)keysObj;
/*     */       } else {
/* 200 */         if (keysObj == null) {
/* 201 */           throw new RuntimeException("No 'columnKeys' defined.");
/*     */         }
/* 203 */         throw new RuntimeException("Please check the 'columnKeys', the format does not parse to a list.");
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 208 */       Object dataObj = map.get("rows");
/* 209 */       if (dataObj instanceof List) {
/* 210 */         List<?> rowList = (List)dataObj;
/*     */ 
/*     */         
/* 213 */         for (Object rowObj : rowList) {
/* 214 */           processRow(rowObj, keys, result);
/*     */         }
/*     */       } else {
/* 217 */         if (dataObj == null) {
/* 218 */           throw new RuntimeException("No 'rows' section defined.");
/*     */         }
/* 220 */         throw new RuntimeException("Please check the 'rows' entry, the format does not parse to a list of rows.");
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 225 */       return result;
/* 226 */     } catch (ParseException ex) {
/* 227 */       throw new RuntimeException(ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void processRow(Object rowObj, List<?> columnKeys, DefaultKeyedValues2D<Double> dataset) {
/* 240 */     if (!(rowObj instanceof List)) {
/* 241 */       throw new RuntimeException("Check the 'data' section it contains a row that does not parse to a list.");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 248 */     List rowList = (List)rowObj;
/* 249 */     Object rowKey = rowList.get(0);
/* 250 */     Object rowDataObj = rowList.get(1);
/* 251 */     if (!(rowDataObj instanceof List)) {
/* 252 */       throw new RuntimeException("Please check the row entry for " + rowKey + " because it is not parsing to a list (of " + "rowKey and rowDataValues items.");
/*     */     }
/*     */ 
/*     */     
/* 256 */     List<?> rowData = (List)rowDataObj;
/* 257 */     if (rowData.size() != columnKeys.size()) {
/* 258 */       throw new RuntimeException("The values list for series " + rowKey + " does not contain the correct number of " + "entries to match the columnKeys.");
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 263 */     for (int c = 0; c < rowData.size(); c++) {
/* 264 */       Object columnKey = columnKeys.get(c);
/* 265 */       dataset.setValue(Double.valueOf(objToDouble(rowData.get(c))), rowKey
/* 266 */           .toString(), columnKey.toString());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String writeKeyedValues2D(KeyedValues2D<? extends Number> data) {
/* 279 */     ArgChecks.nullNotPermitted(data, "data");
/* 280 */     StringWriter sw = new StringWriter();
/*     */     try {
/* 282 */       writeKeyedValues2D(data, sw);
/* 283 */     } catch (IOException ex) {
/* 284 */       throw new RuntimeException(ex);
/*     */     } 
/* 286 */     return sw.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void writeKeyedValues2D(KeyedValues2D<? extends Number> data, Writer writer) throws IOException {
/* 299 */     ArgChecks.nullNotPermitted(data, "data");
/* 300 */     ArgChecks.nullNotPermitted(writer, "writer");
/* 301 */     List<Comparable<?>> columnKeys = data.getColumnKeys();
/* 302 */     List<Comparable<?>> rowKeys = data.getRowKeys();
/* 303 */     writer.write("{");
/* 304 */     if (!columnKeys.isEmpty()) {
/* 305 */       writer.write("\"columnKeys\": [");
/* 306 */       boolean first = true;
/* 307 */       for (Comparable<?> columnKey : columnKeys) {
/* 308 */         if (!first) {
/* 309 */           writer.write(", ");
/*     */         } else {
/* 311 */           first = false;
/*     */         } 
/* 313 */         writer.write(JSONValue.toJSONString(columnKey.toString()));
/*     */       } 
/* 315 */       writer.write("]");
/*     */     } 
/* 317 */     if (!rowKeys.isEmpty()) {
/* 318 */       writer.write(", \"rows\": [");
/* 319 */       boolean firstRow = true;
/* 320 */       for (Comparable<?> rowKey : rowKeys) {
/* 321 */         if (!firstRow) {
/* 322 */           writer.write(", [");
/*     */         } else {
/* 324 */           writer.write("[");
/* 325 */           firstRow = false;
/*     */         } 
/*     */         
/* 328 */         writer.write(JSONValue.toJSONString(rowKey.toString()));
/* 329 */         writer.write(", [");
/* 330 */         boolean first = true;
/* 331 */         for (Comparable<?> columnKey : columnKeys) {
/* 332 */           if (!first) {
/* 333 */             writer.write(", ");
/*     */           } else {
/* 335 */             first = false;
/*     */           } 
/* 337 */           writer.write(JSONValue.toJSONString(data.getValue(rowKey, columnKey)));
/*     */         } 
/*     */         
/* 340 */         writer.write("]]");
/*     */       } 
/* 342 */       writer.write("]");
/*     */     } 
/* 344 */     writer.write("}");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static KeyedValues3D<? extends Number> readKeyedValues3D(String json) {
/*     */     KeyedValues3D<? extends Number> result;
/* 357 */     StringReader in = new StringReader(json);
/*     */     
/*     */     try {
/* 360 */       result = readKeyedValues3D(in);
/* 361 */     } catch (IOException ex) {
/*     */       
/* 363 */       result = null;
/*     */     } 
/* 365 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static KeyedValues3D<? extends Number> readKeyedValues3D(Reader reader) throws IOException {
/* 382 */     JSONParser parser = new JSONParser(); try {
/*     */       List<?> rowKeys, columnKeys;
/* 384 */       Map map = (Map)parser.parse(reader, createContainerFactory());
/* 385 */       StandardCategoryDataset3D result = new StandardCategoryDataset3D();
/* 386 */       if (map.isEmpty()) {
/* 387 */         return (KeyedValues3D<? extends Number>)result;
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 392 */       Object rowKeysObj = map.get("rowKeys");
/*     */       
/* 394 */       if (rowKeysObj instanceof List) {
/* 395 */         rowKeys = (List)rowKeysObj;
/*     */       } else {
/* 397 */         if (rowKeysObj == null) {
/* 398 */           throw new RuntimeException("No 'rowKeys' defined.");
/*     */         }
/* 400 */         throw new RuntimeException("Please check the 'rowKeys', the format does not parse to a list.");
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 407 */       Object columnKeysObj = map.get("columnKeys");
/*     */       
/* 409 */       if (columnKeysObj instanceof List) {
/* 410 */         columnKeys = (List)columnKeysObj;
/*     */       } else {
/* 412 */         if (columnKeysObj == null) {
/* 413 */           throw new RuntimeException("No 'columnKeys' defined.");
/*     */         }
/* 415 */         throw new RuntimeException("Please check the 'columnKeys', the format does not parse to a list.");
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 421 */       Object dataObj = map.get("data");
/* 422 */       if (dataObj instanceof List) {
/* 423 */         List<?> seriesList = (List)dataObj;
/*     */ 
/*     */         
/* 426 */         for (Object seriesObj : seriesList) {
/* 427 */           processSeries(seriesObj, rowKeys, columnKeys, result);
/*     */         }
/*     */       } else {
/* 430 */         if (dataObj == null) {
/* 431 */           throw new RuntimeException("No 'data' section defined.");
/*     */         }
/* 433 */         throw new RuntimeException("Please check the 'data' entry, the format does not parse to a list of series.");
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 438 */       return (KeyedValues3D<? extends Number>)result;
/* 439 */     } catch (ParseException ex) {
/* 440 */       throw new RuntimeException(ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void processSeries(Object seriesObj, List<?> rowKeys, List<?> columnKeys, StandardCategoryDataset3D dataset) {
/* 454 */     if (!(seriesObj instanceof Map)) {
/* 455 */       throw new RuntimeException("Check the 'data' section it contains a series that does not parse to a map.");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 462 */     Map seriesMap = (Map)seriesObj;
/* 463 */     Object seriesKey = seriesMap.get("seriesKey");
/* 464 */     Object seriesRowsObj = seriesMap.get("rows");
/* 465 */     if (!(seriesRowsObj instanceof Map)) {
/* 466 */       throw new RuntimeException("Please check the series entry for " + seriesKey + " because it is not parsing to a map (of " + "rowKey -> rowDataValues items.");
/*     */     }
/*     */ 
/*     */     
/* 470 */     Map<?, ?> seriesData = (Map<?, ?>)seriesRowsObj;
/* 471 */     for (Object rowKey : seriesData.keySet()) {
/* 472 */       if (!rowKeys.contains(rowKey)) {
/* 473 */         throw new RuntimeException("The row key " + rowKey + " is not " + "listed in the rowKeys entry.");
/*     */       }
/*     */       
/* 476 */       Object rowValuesObj = seriesData.get(rowKey);
/* 477 */       if (!(rowValuesObj instanceof List)) {
/* 478 */         throw new RuntimeException("Please check the entry for series " + seriesKey + " and row " + rowKey + " because it " + "does not parse to a list of values.");
/*     */       }
/*     */ 
/*     */       
/* 482 */       List<?> rowValues = (List)rowValuesObj;
/* 483 */       if (rowValues.size() != columnKeys.size()) {
/* 484 */         throw new RuntimeException("The values list for series " + seriesKey + " and row " + rowKey + " does not " + "contain the correct number of entries to match " + "the columnKeys.");
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 489 */       for (int c = 0; c < rowValues.size(); c++) {
/* 490 */         Object columnKey = columnKeys.get(c);
/* 491 */         dataset.addValue(Double.valueOf(objToDouble(rowValues.get(c))), seriesKey
/* 492 */             .toString(), rowKey.toString(), columnKey
/* 493 */             .toString());
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String writeKeyedValues3D(KeyedValues3D<? extends Number> dataset) {
/* 507 */     ArgChecks.nullNotPermitted(dataset, "dataset");
/* 508 */     StringWriter sw = new StringWriter();
/*     */     try {
/* 510 */       writeKeyedValues3D(dataset, sw);
/* 511 */     } catch (IOException ex) {
/* 512 */       throw new RuntimeException(ex);
/*     */     } 
/* 514 */     return sw.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void writeKeyedValues3D(KeyedValues3D<? extends Number> dataset, Writer writer) throws IOException {
/* 528 */     ArgChecks.nullNotPermitted(dataset, "dataset");
/* 529 */     ArgChecks.nullNotPermitted(writer, "writer");
/*     */     
/* 531 */     writer.write("{");
/* 532 */     if (!dataset.getColumnKeys().isEmpty()) {
/* 533 */       writer.write("\"columnKeys\": [");
/* 534 */       boolean first = true;
/* 535 */       for (Comparable<?> key : dataset.getColumnKeys()) {
/* 536 */         if (!first) {
/* 537 */           writer.write(", ");
/*     */         } else {
/* 539 */           first = false;
/*     */         } 
/* 541 */         writer.write(JSONValue.toJSONString(key.toString()));
/*     */       } 
/* 543 */       writer.write("], ");
/*     */     } 
/*     */ 
/*     */     
/* 547 */     if (!dataset.getRowKeys().isEmpty()) {
/* 548 */       writer.write("\"rowKeys\": [");
/* 549 */       boolean first = true;
/* 550 */       for (Comparable<?> key : dataset.getRowKeys()) {
/* 551 */         if (!first) {
/* 552 */           writer.write(", ");
/*     */         } else {
/* 554 */           first = false;
/*     */         } 
/* 556 */         writer.write(JSONValue.toJSONString(key.toString()));
/*     */       } 
/* 558 */       writer.write("], ");
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 564 */     if (dataset.getSeriesCount() != 0) {
/* 565 */       writer.write("\"series\": [");
/* 566 */       boolean first = true;
/* 567 */       for (Comparable<?> seriesKey : dataset.getSeriesKeys()) {
/* 568 */         if (!first) {
/* 569 */           writer.write(", ");
/*     */         } else {
/* 571 */           first = false;
/*     */         } 
/* 573 */         writer.write("{\"seriesKey\": ");
/* 574 */         writer.write(JSONValue.toJSONString(seriesKey.toString()));
/* 575 */         writer.write(", \"rows\": [");
/*     */         
/* 577 */         boolean firstRow = true;
/* 578 */         for (Comparable<?> rowKey : dataset.getRowKeys()) {
/* 579 */           if (countForRowInSeries(dataset, seriesKey, rowKey) > 0) {
/* 580 */             if (!firstRow) {
/* 581 */               writer.write(", [");
/*     */             } else {
/* 583 */               writer.write("[");
/* 584 */               firstRow = false;
/*     */             } 
/*     */             
/* 587 */             writer.write(JSONValue.toJSONString(rowKey.toString()) + ", [");
/*     */             
/* 589 */             for (int c = 0; c < dataset.getColumnCount(); c++) {
/* 590 */               Comparable<?> columnKey = dataset.getColumnKey(c);
/* 591 */               if (c != 0) {
/* 592 */                 writer.write(", ");
/*     */               }
/* 594 */               writer.write(JSONValue.toJSONString(dataset
/* 595 */                     .getValue(seriesKey, rowKey, columnKey)));
/*     */             } 
/*     */             
/* 598 */             writer.write("]]");
/*     */           } 
/*     */         } 
/* 601 */         writer.write("]}");
/*     */       } 
/* 603 */       writer.write("]");
/*     */     } 
/* 605 */     writer.write("}");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int countForRowInSeries(KeyedValues3D<?> data, Comparable<?> seriesKey, Comparable<?> rowKey) {
/* 620 */     ArgChecks.nullNotPermitted(data, "data");
/* 621 */     ArgChecks.nullNotPermitted(seriesKey, "seriesKey");
/* 622 */     ArgChecks.nullNotPermitted(rowKey, "rowKey");
/* 623 */     int seriesIndex = data.getSeriesIndex(seriesKey);
/* 624 */     if (seriesIndex < 0) {
/* 625 */       throw new IllegalArgumentException("Series not found: " + seriesKey);
/*     */     }
/*     */     
/* 628 */     int rowIndex = data.getRowIndex(rowKey);
/* 629 */     if (rowIndex < 0) {
/* 630 */       throw new IllegalArgumentException("Row not found: " + rowKey);
/*     */     }
/* 632 */     int count = 0;
/* 633 */     for (int c = 0; c < data.getColumnCount(); c++) {
/* 634 */       Number n = (Number)data.getValue(seriesIndex, rowIndex, c);
/* 635 */       if (n != null) {
/* 636 */         count++;
/*     */       }
/*     */     } 
/* 639 */     return count;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static XYZDataset readXYZDataset(String json) {
/*     */     XYZDataset result;
/* 655 */     ArgChecks.nullNotPermitted(json, "json");
/* 656 */     StringReader in = new StringReader(json);
/*     */     
/*     */     try {
/* 659 */       result = readXYZDataset(in);
/* 660 */     } catch (IOException ex) {
/*     */       
/* 662 */       result = null;
/*     */     } 
/* 664 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static XYZDataset readXYZDataset(Reader reader) throws IOException {
/* 678 */     JSONParser parser = new JSONParser();
/* 679 */     XYZSeriesCollection result = new XYZSeriesCollection();
/*     */     try {
/* 681 */       List<?> list = (List)parser.parse(reader, 
/* 682 */           createContainerFactory());
/*     */ 
/*     */ 
/*     */       
/* 686 */       for (Object seriesArray : list) {
/* 687 */         if (seriesArray instanceof List) {
/* 688 */           List<?> seriesList = (List)seriesArray;
/* 689 */           XYZSeries series = createSeries(seriesList);
/* 690 */           result.add(series); continue;
/*     */         } 
/* 692 */         throw new RuntimeException("Input for a series did not parse to a list.");
/*     */       }
/*     */     
/*     */     }
/* 696 */     catch (ParseException ex) {
/* 697 */       throw new RuntimeException(ex);
/*     */     } 
/* 699 */     return (XYZDataset)result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String writeXYZDataset(XYZDataset dataset) {
/* 710 */     StringWriter sw = new StringWriter();
/*     */     try {
/* 712 */       writeXYZDataset(dataset, sw);
/* 713 */     } catch (IOException ex) {
/* 714 */       throw new RuntimeException(ex);
/*     */     } 
/* 716 */     return sw.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void writeXYZDataset(XYZDataset dataset, Writer writer) throws IOException {
/* 729 */     writer.write("[");
/* 730 */     boolean first = true;
/* 731 */     for (Comparable<?> seriesKey : (Iterable<Comparable<?>>)dataset.getSeriesKeys()) {
/* 732 */       if (!first) {
/* 733 */         writer.write(", [");
/*     */       } else {
/* 735 */         writer.write("[");
/* 736 */         first = false;
/*     */       } 
/* 738 */       writer.write(JSONValue.toJSONString(seriesKey.toString()));
/* 739 */       writer.write(", [");
/* 740 */       int seriesIndex = dataset.getSeriesIndex(seriesKey);
/* 741 */       int itemCount = dataset.getItemCount(seriesIndex);
/* 742 */       for (int i = 0; i < itemCount; i++) {
/* 743 */         if (i != 0) {
/* 744 */           writer.write(", ");
/*     */         }
/* 746 */         writer.write("[");
/* 747 */         writer.write(JSONValue.toJSONString(Double.valueOf(dataset
/* 748 */                 .getX(seriesIndex, i))));
/* 749 */         writer.write(", ");
/* 750 */         writer.write(JSONValue.toJSONString(Double.valueOf(dataset
/* 751 */                 .getY(seriesIndex, i))));
/* 752 */         writer.write(", ");
/* 753 */         writer.write(JSONValue.toJSONString(Double.valueOf(dataset
/* 754 */                 .getZ(seriesIndex, i))));
/* 755 */         writer.write("]");
/*     */       } 
/* 757 */       writer.write("]]");
/*     */     } 
/* 759 */     writer.write("]");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static double objToDouble(Object obj) {
/* 770 */     if (obj == null) {
/* 771 */       return Double.NaN;
/*     */     }
/* 773 */     if (obj instanceof Number) {
/* 774 */       return ((Number)obj).doubleValue();
/*     */     }
/* 776 */     double result = Double.NaN;
/*     */     try {
/* 778 */       result = Double.valueOf(obj.toString()).doubleValue();
/* 779 */     } catch (Exception e) {}
/*     */ 
/*     */     
/* 782 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static XYZSeries createSeries(List<?> sArray) {
/* 796 */     Comparable<?> key = (Comparable)sArray.get(0);
/* 797 */     List<?> dataItems = (List)sArray.get(1);
/* 798 */     XYZSeries series = new XYZSeries(key);
/* 799 */     for (Object item : dataItems) {
/* 800 */       if (item instanceof List) {
/* 801 */         List<?> xyz = (List)item;
/* 802 */         if (xyz.size() != 3) {
/* 803 */           throw new RuntimeException("A data item should contain three numbers, but we have " + xyz);
/*     */         }
/*     */ 
/*     */         
/* 807 */         double x = objToDouble(xyz.get(0));
/* 808 */         double y = objToDouble(xyz.get(1));
/* 809 */         double z = objToDouble(xyz.get(2));
/* 810 */         series.add(x, y, z);
/*     */         continue;
/*     */       } 
/* 813 */       throw new RuntimeException("Expecting a data item (x, y, z) for series " + key + " but found " + item + ".");
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 818 */     return series;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static ContainerFactory createContainerFactory() {
/* 828 */     return new ContainerFactory()
/*     */       {
/*     */         public Map createObjectContainer() {
/* 831 */           return new LinkedHashMap<Object, Object>();
/*     */         }
/*     */ 
/*     */         
/*     */         public List creatArrayContainer() {
/* 836 */           return new ArrayList();
/*     */         }
/*     */       };
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/data/JSONUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */