/*     */ package com.orsoncharts.data;
/*     */ 
/*     */ import com.orsoncharts.util.ArgChecks;
/*     */ import com.orsoncharts.util.ObjectUtils;
/*     */ import java.io.Serializable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class DefaultKeyedValue<T>
/*     */   implements KeyedValue<T>, Serializable
/*     */ {
/*     */   private Comparable<?> key;
/*     */   private T value;
/*     */   
/*     */   public DefaultKeyedValue(Comparable<?> key, T value) {
/*  43 */     ArgChecks.nullNotPermitted(key, "key");
/*  44 */     this.key = key;
/*  45 */     this.value = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Comparable<?> getKey() {
/*  55 */     return this.key;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T getValue() {
/*  65 */     return this.value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setValue(T value) {
/*  74 */     this.value = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/*  86 */     if (obj == this) {
/*  87 */       return true;
/*     */     }
/*  89 */     if (!(obj instanceof DefaultKeyedValue)) {
/*  90 */       return false;
/*     */     }
/*  92 */     DefaultKeyedValue<?> that = (DefaultKeyedValue)obj;
/*  93 */     if (!this.key.equals(that.key)) {
/*  94 */       return false;
/*     */     }
/*  96 */     if (!ObjectUtils.equals(this.value, that.value)) {
/*  97 */       return false;
/*     */     }
/*  99 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 104 */     return "(" + this.key.toString() + ", " + this.value + ")";
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/data/DefaultKeyedValue.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */