/*    */ package com.orsoncharts.data.xyz;
/*    */ 
/*    */ import com.orsoncharts.Range;
/*    */ import com.orsoncharts.data.function.Function3D;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class XYZDatasetUtils
/*    */ {
/*    */   public static XYZDataset sampleFunction(Function3D f, String key, Range xrange, double xcount, Range zrange, double zcount) {
/* 38 */     return sampleFunction(f, key, xrange.getMin(), xrange.getMax(), xcount, zrange
/* 39 */         .getMin(), zrange.getMax(), zcount);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static XYZDataset sampleFunction(Function3D f, String key, double xmin, double xmax, double xcount, double zmin, double zmax, double zcount) {
/* 60 */     XYZSeries s = new XYZSeries(key); double x;
/* 61 */     for (x = xmin; x <= xmax; x += (xmax - xmin) / xcount) {
/* 62 */       double z; for (z = zmin; z <= zmax; z += (zmax - zmin) / zcount) {
/* 63 */         s.add(x, f.getValue(x, z), z);
/*    */       }
/*    */     } 
/* 66 */     XYZSeriesCollection dataset = new XYZSeriesCollection();
/* 67 */     dataset.add(s);
/* 68 */     return dataset;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/data/xyz/XYZDatasetUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */