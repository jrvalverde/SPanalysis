/*     */ package com.orsoncharts.data;
/*     */ 
/*     */ import com.orsoncharts.util.ArgChecks;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class KeyedValues3DItemKeys
/*     */ {
/*     */   public static Collection<KeyedValues3DItemKey> itemKeysForSeries(KeyedValues3D data, Comparable<?> seriesKey) {
/*  42 */     ArgChecks.nullNotPermitted(data, "data");
/*  43 */     ArgChecks.nullNotPermitted(seriesKey, "seriesKey");
/*  44 */     Collection<KeyedValues3DItemKey> result = new ArrayList<KeyedValues3DItemKey>();
/*     */     
/*  46 */     if (!data.getSeriesKeys().contains(seriesKey)) {
/*  47 */       return result;
/*     */     }
/*  49 */     for (Comparable<?> rowKey : data.getRowKeys()) {
/*     */       
/*  51 */       for (Comparable<?> columnKey : data.getColumnKeys()) {
/*  52 */         KeyedValues3DItemKey<Comparable<?>, Comparable<?>, Comparable> key = new KeyedValues3DItemKey<Comparable<?>, Comparable<?>, Comparable>(seriesKey, rowKey, columnKey);
/*     */         
/*  54 */         result.add(key);
/*     */       } 
/*     */     } 
/*  57 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Collection<KeyedValues3DItemKey> itemKeysForRow(KeyedValues3D data, Comparable<?> rowKey) {
/*  71 */     ArgChecks.nullNotPermitted(data, "data");
/*  72 */     ArgChecks.nullNotPermitted(rowKey, "rowKey");
/*  73 */     Collection<KeyedValues3DItemKey> result = new ArrayList<KeyedValues3DItemKey>();
/*     */     
/*  75 */     if (!data.getRowKeys().contains(rowKey)) {
/*  76 */       return result;
/*     */     }
/*     */     
/*  79 */     for (Comparable<?> seriesKey : data.getSeriesKeys()) {
/*  80 */       for (Comparable<?> columnKey : data
/*  81 */         .getColumnKeys()) {
/*  82 */         KeyedValues3DItemKey<Comparable<?>, Comparable<?>, Comparable> key = new KeyedValues3DItemKey<Comparable<?>, Comparable<?>, Comparable>(seriesKey, rowKey, columnKey);
/*     */         
/*  84 */         result.add(key);
/*     */       } 
/*     */     } 
/*  87 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Collection<KeyedValues3DItemKey> itemKeysForColumn(KeyedValues3D data, Comparable<?> columnKey) {
/* 101 */     ArgChecks.nullNotPermitted(data, "data");
/* 102 */     ArgChecks.nullNotPermitted(columnKey, "columnKey");
/* 103 */     Collection<KeyedValues3DItemKey> result = new ArrayList<KeyedValues3DItemKey>();
/*     */     
/* 105 */     if (!data.getColumnKeys().contains(columnKey)) {
/* 106 */       return result;
/*     */     }
/*     */     
/* 109 */     for (Comparable<?> seriesKey : data.getSeriesKeys()) {
/* 110 */       for (Comparable<?> rowKey : data.getRowKeys()) {
/* 111 */         KeyedValues3DItemKey<Comparable<?>, Comparable, Comparable<?>> key = new KeyedValues3DItemKey<Comparable<?>, Comparable, Comparable<?>>(seriesKey, rowKey, columnKey);
/*     */         
/* 113 */         result.add(key);
/*     */       } 
/*     */     } 
/* 116 */     return result;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/data/KeyedValues3DItemKeys.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */