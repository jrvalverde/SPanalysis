/*     */ package com.orsoncharts.data;
/*     */ 
/*     */ import com.orsoncharts.Range;
/*     */ import com.orsoncharts.data.xyz.XYZDataset;
/*     */ import com.orsoncharts.data.xyz.XYZSeries;
/*     */ import com.orsoncharts.data.xyz.XYZSeriesCollection;
/*     */ import com.orsoncharts.util.ArgChecks;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DataUtils
/*     */ {
/*     */   public static double total(Values<Number> values) {
/*  42 */     double result = 0.0D;
/*  43 */     for (int i = 0; i < values.getItemCount(); i++) {
/*  44 */       Number n = values.getValue(i);
/*  45 */       if (n != null) {
/*  46 */         result += n.doubleValue();
/*     */       }
/*     */     } 
/*  49 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int count(KeyedValues3D<?> data, Comparable<?> seriesKey) {
/*  65 */     ArgChecks.nullNotPermitted(data, "data");
/*  66 */     ArgChecks.nullNotPermitted(seriesKey, "seriesKey");
/*  67 */     int seriesIndex = data.getSeriesIndex(seriesKey);
/*  68 */     if (seriesIndex < 0) {
/*  69 */       throw new IllegalArgumentException("Series not found: " + seriesKey);
/*     */     }
/*     */     
/*  72 */     int count = 0;
/*  73 */     int rowCount = data.getRowCount();
/*  74 */     int columnCount = data.getColumnCount();
/*  75 */     for (int r = 0; r < rowCount; r++) {
/*  76 */       for (int c = 0; c < columnCount; c++) {
/*  77 */         Number n = (Number)data.getValue(seriesIndex, r, c);
/*  78 */         if (n != null) {
/*  79 */           count++;
/*     */         }
/*     */       } 
/*     */     } 
/*  83 */     return count;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int countForRow(KeyedValues3D<?> data, Comparable<?> rowKey) {
/*  98 */     ArgChecks.nullNotPermitted(data, "data");
/*  99 */     ArgChecks.nullNotPermitted(rowKey, "rowKey");
/* 100 */     int rowIndex = data.getRowIndex(rowKey);
/* 101 */     if (rowIndex < 0) {
/* 102 */       throw new IllegalArgumentException("Row not found: " + rowKey);
/*     */     }
/* 104 */     int count = 0;
/* 105 */     int seriesCount = data.getSeriesCount();
/* 106 */     int columnCount = data.getColumnCount();
/* 107 */     for (int s = 0; s < seriesCount; s++) {
/* 108 */       for (int c = 0; c < columnCount; c++) {
/* 109 */         Number n = (Number)data.getValue(s, rowIndex, c);
/* 110 */         if (n != null) {
/* 111 */           count++;
/*     */         }
/*     */       } 
/*     */     } 
/* 115 */     return count;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int countForColumn(KeyedValues3D<?> data, Comparable<?> columnKey) {
/* 131 */     ArgChecks.nullNotPermitted(data, "data");
/* 132 */     ArgChecks.nullNotPermitted(columnKey, "columnKey");
/* 133 */     int columnIndex = data.getColumnIndex(columnKey);
/* 134 */     if (columnIndex < 0) {
/* 135 */       throw new IllegalArgumentException("Column not found: " + columnKey);
/*     */     }
/*     */     
/* 138 */     int count = 0;
/* 139 */     int seriesCount = data.getSeriesCount();
/* 140 */     int rowCount = data.getRowCount();
/* 141 */     for (int s = 0; s < seriesCount; s++) {
/* 142 */       for (int r = 0; r < rowCount; r++) {
/* 143 */         Number n = (Number)data.getValue(s, r, columnIndex);
/* 144 */         if (n != null) {
/* 145 */           count++;
/*     */         }
/*     */       } 
/*     */     } 
/* 149 */     return count;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static double total(KeyedValues3D<? extends Number> data, Comparable<?> seriesKey) {
/* 166 */     ArgChecks.nullNotPermitted(data, "data");
/* 167 */     ArgChecks.nullNotPermitted(seriesKey, "seriesKey");
/* 168 */     int seriesIndex = data.getSeriesIndex(seriesKey);
/* 169 */     if (seriesIndex < 0) {
/* 170 */       throw new IllegalArgumentException("Series not found: " + seriesKey);
/*     */     }
/*     */     
/* 173 */     double total = 0.0D;
/* 174 */     int rowCount = data.getRowCount();
/* 175 */     int columnCount = data.getColumnCount();
/* 176 */     for (int r = 0; r < rowCount; r++) {
/* 177 */       for (int c = 0; c < columnCount; c++) {
/* 178 */         Number n = data.getValue(seriesIndex, r, c);
/* 179 */         if (n != null) {
/* 180 */           total += n.doubleValue();
/*     */         }
/*     */       } 
/*     */     } 
/* 184 */     return total;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static double totalForRow(KeyedValues3D<? extends Number> data, Comparable<?> rowKey) {
/* 200 */     ArgChecks.nullNotPermitted(data, "data");
/* 201 */     ArgChecks.nullNotPermitted(rowKey, "rowKey");
/* 202 */     int rowIndex = data.getRowIndex(rowKey);
/* 203 */     if (rowIndex < 0) {
/* 204 */       throw new IllegalArgumentException("Row not found: " + rowKey);
/*     */     }
/* 206 */     double total = 0.0D;
/* 207 */     int seriesCount = data.getSeriesCount();
/* 208 */     int columnCount = data.getColumnCount();
/* 209 */     for (int s = 0; s < seriesCount; s++) {
/* 210 */       for (int c = 0; c < columnCount; c++) {
/* 211 */         Number n = data.getValue(s, rowIndex, c);
/* 212 */         if (n != null) {
/* 213 */           total += n.doubleValue();
/*     */         }
/*     */       } 
/*     */     } 
/* 217 */     return total;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static double totalForColumn(KeyedValues3D<? extends Number> data, Comparable<?> columnKey) {
/* 233 */     ArgChecks.nullNotPermitted(data, "data");
/* 234 */     ArgChecks.nullNotPermitted(columnKey, "columnKey");
/* 235 */     int columnIndex = data.getColumnIndex(columnKey);
/* 236 */     if (columnIndex < 0) {
/* 237 */       throw new IllegalArgumentException("Column not found: " + columnKey);
/*     */     }
/*     */     
/* 240 */     double total = 0.0D;
/* 241 */     int seriesCount = data.getSeriesCount();
/* 242 */     int rowCount = data.getRowCount();
/* 243 */     for (int s = 0; s < seriesCount; s++) {
/* 244 */       for (int r = 0; r < rowCount; r++) {
/* 245 */         Number n = data.getValue(s, r, columnIndex);
/* 246 */         if (n != null) {
/* 247 */           total += n.doubleValue();
/*     */         }
/*     */       } 
/*     */     } 
/* 251 */     return total;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Range findValueRange(Values3D<? extends Number> data) {
/* 264 */     return findValueRange(data, Double.NaN);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Range findValueRange(Values3D<? extends Number> data, double base) {
/* 281 */     return findValueRange(data, base, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Range findValueRange(Values3D<? extends Number> data, double base, boolean finite) {
/* 302 */     ArgChecks.nullNotPermitted(data, "data");
/* 303 */     double min = Double.POSITIVE_INFINITY;
/* 304 */     double max = Double.NEGATIVE_INFINITY;
/* 305 */     for (int series = 0; series < data.getSeriesCount(); series++) {
/* 306 */       for (int row = 0; row < data.getRowCount(); row++) {
/* 307 */         for (int col = 0; col < data.getColumnCount(); col++) {
/* 308 */           double d = data.getDoubleValue(series, row, col);
/* 309 */           if (!Double.isNaN(d) && (
/* 310 */             !finite || !Double.isInfinite(d))) {
/* 311 */             min = Math.min(min, d);
/* 312 */             max = Math.max(max, d);
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 319 */     if (!Double.isNaN(base)) {
/* 320 */       min = Math.min(min, base);
/* 321 */       max = Math.max(max, base);
/*     */     } 
/* 323 */     if (min <= max) {
/* 324 */       return new Range(min, max);
/*     */     }
/* 326 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Range findStackedValueRange(Values3D<? extends Number> data) {
/* 339 */     return findStackedValueRange(data, 0.0D);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Range findStackedValueRange(Values3D<? extends Number> data, double base) {
/* 353 */     ArgChecks.nullNotPermitted(data, "data");
/* 354 */     double min = base;
/* 355 */     double max = base;
/* 356 */     int seriesCount = data.getSeriesCount();
/* 357 */     for (int row = 0; row < data.getRowCount(); row++) {
/* 358 */       for (int col = 0; col < data.getColumnCount(); col++) {
/* 359 */         double[] total = stackSubTotal(data, base, seriesCount, row, col);
/*     */         
/* 361 */         min = Math.min(min, total[0]);
/* 362 */         max = Math.max(max, total[1]);
/*     */       } 
/*     */     } 
/* 365 */     if (min <= max) {
/* 366 */       return new Range(min, max);
/*     */     }
/* 368 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static double[] stackSubTotal(Values3D<? extends Number> data, double base, int series, int row, int column) {
/* 393 */     double neg = base;
/* 394 */     double pos = base;
/* 395 */     for (int s = 0; s < series; s++) {
/* 396 */       double v = data.getDoubleValue(s, row, column);
/* 397 */       if (v > 0.0D) {
/* 398 */         pos += v;
/* 399 */       } else if (v < 0.0D) {
/* 400 */         neg += v;
/*     */       } 
/*     */     } 
/* 403 */     return new double[] { neg, pos };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static double total(XYZDataset data, Comparable<?> seriesKey) {
/* 418 */     ArgChecks.nullNotPermitted(data, "data");
/* 419 */     ArgChecks.nullNotPermitted(seriesKey, "seriesKey");
/* 420 */     int seriesIndex = data.getSeriesIndex(seriesKey);
/* 421 */     if (seriesIndex < 0) {
/* 422 */       throw new IllegalArgumentException("Series not found: " + seriesKey);
/*     */     }
/*     */     
/* 425 */     double total = 0.0D;
/* 426 */     int itemCount = data.getItemCount(seriesIndex);
/* 427 */     for (int item = 0; item < itemCount; item++) {
/* 428 */       double y = data.getY(seriesIndex, item);
/* 429 */       if (!Double.isNaN(y)) {
/* 430 */         total += y;
/*     */       }
/*     */     } 
/* 433 */     return total;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Range findXRange(XYZDataset dataset) {
/* 447 */     return findXRange(dataset, Double.NaN);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Range findXRange(XYZDataset dataset, double inc) {
/* 464 */     return findXRange(dataset, inc, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Range findXRange(XYZDataset dataset, double inc, boolean finite) {
/* 486 */     ArgChecks.nullNotPermitted(dataset, "dataset");
/* 487 */     double min = Double.POSITIVE_INFINITY;
/* 488 */     double max = Double.NEGATIVE_INFINITY;
/* 489 */     for (int s = 0; s < dataset.getSeriesCount(); s++) {
/* 490 */       for (int i = 0; i < dataset.getItemCount(s); i++) {
/* 491 */         double x = dataset.getX(s, i);
/* 492 */         if (!Double.isNaN(x) && (
/* 493 */           !finite || !Double.isInfinite(x))) {
/* 494 */           min = Math.min(x, min);
/* 495 */           max = Math.max(x, max);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 500 */     if (!Double.isNaN(inc)) {
/* 501 */       min = Math.min(inc, min);
/* 502 */       max = Math.max(inc, max);
/*     */     } 
/* 504 */     if (min <= max) {
/* 505 */       return new Range(min, max);
/*     */     }
/* 507 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Range findYRange(XYZDataset dataset) {
/* 522 */     return findYRange(dataset, Double.NaN);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Range findYRange(XYZDataset dataset, double inc) {
/* 539 */     return findYRange(dataset, inc, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Range findYRange(XYZDataset dataset, double inc, boolean finite) {
/* 561 */     ArgChecks.nullNotPermitted(dataset, "dataset");
/* 562 */     double min = Double.POSITIVE_INFINITY;
/* 563 */     double max = Double.NEGATIVE_INFINITY;
/* 564 */     for (int s = 0; s < dataset.getSeriesCount(); s++) {
/* 565 */       for (int i = 0; i < dataset.getItemCount(s); i++) {
/* 566 */         double y = dataset.getY(s, i);
/* 567 */         if (!Double.isNaN(y) && (
/* 568 */           !finite || !Double.isInfinite(y))) {
/* 569 */           min = Math.min(y, min);
/* 570 */           max = Math.max(y, max);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 575 */     if (!Double.isNaN(inc)) {
/* 576 */       min = Math.min(inc, min);
/* 577 */       max = Math.max(inc, max);
/*     */     } 
/* 579 */     if (min <= max) {
/* 580 */       return new Range(min, max);
/*     */     }
/* 582 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Range findZRange(XYZDataset dataset) {
/* 597 */     return findZRange(dataset, Double.NaN);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Range findZRange(XYZDataset dataset, double inc) {
/* 614 */     return findZRange(dataset, inc, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Range findZRange(XYZDataset dataset, double inc, boolean finite) {
/* 636 */     ArgChecks.nullNotPermitted(dataset, "dataset");
/* 637 */     ArgChecks.finiteRequired(inc, "inc");
/* 638 */     double min = Double.POSITIVE_INFINITY;
/* 639 */     double max = Double.NEGATIVE_INFINITY;
/* 640 */     for (int s = 0; s < dataset.getSeriesCount(); s++) {
/* 641 */       for (int i = 0; i < dataset.getItemCount(s); i++) {
/* 642 */         double z = dataset.getZ(s, i);
/* 643 */         if (!Double.isNaN(z) && (
/* 644 */           !finite || !Double.isInfinite(z))) {
/* 645 */           min = Math.min(z, min);
/* 646 */           max = Math.max(z, max);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 651 */     if (!Double.isNaN(inc)) {
/* 652 */       min = Math.min(inc, min);
/* 653 */       max = Math.max(inc, max);
/*     */     } 
/* 655 */     if (min <= max) {
/* 656 */       return new Range(min, max);
/*     */     }
/* 658 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static XYZDataset extractXYZDatasetFromRows(KeyedValues3D<? extends Number> source, Comparable<?> xRowKey, Comparable<?> yRowKey, Comparable<?> zRowKey) {
/* 689 */     return extractXYZDatasetFromColumns(source, xRowKey, yRowKey, zRowKey, NullConversion.SKIP, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static XYZDataset extractXYZDatasetFromRows(KeyedValues3D<? extends Number> source, Comparable<?> xRowKey, Comparable<?> yRowKey, Comparable<?> zRowKey, NullConversion nullConversion, List<KeyedValues3DItemKey> exceptions) {
/* 728 */     ArgChecks.nullNotPermitted(source, "source");
/* 729 */     ArgChecks.nullNotPermitted(xRowKey, "xRowKey");
/* 730 */     ArgChecks.nullNotPermitted(yRowKey, "yRowKey");
/* 731 */     ArgChecks.nullNotPermitted(zRowKey, "zRowKey");
/* 732 */     XYZSeriesCollection dataset = new XYZSeriesCollection();
/* 733 */     for (Comparable<?> seriesKey : source.getSeriesKeys()) {
/* 734 */       XYZSeries series = new XYZSeries(seriesKey);
/* 735 */       for (Comparable<?> colKey : source.getColumnKeys()) {
/* 736 */         Number x = source.getValue(seriesKey, xRowKey, colKey);
/* 737 */         Number y = source.getValue(seriesKey, yRowKey, colKey);
/* 738 */         Number z = source.getValue(seriesKey, zRowKey, colKey);
/* 739 */         if (x != null && y != null && z != null) {
/* 740 */           series.add(x.doubleValue(), y.doubleValue(), z
/* 741 */               .doubleValue()); continue;
/*     */         } 
/* 743 */         if (exceptions != null) {
/*     */           
/* 745 */           Comparable<?> rrKey = zRowKey;
/* 746 */           if (x == null) {
/* 747 */             rrKey = xRowKey;
/* 748 */           } else if (y == null) {
/* 749 */             rrKey = yRowKey;
/*     */           } 
/* 751 */           exceptions.add(new KeyedValues3DItemKey<Comparable<?>, Comparable<?>, Comparable<?>>(seriesKey, rrKey, colKey));
/*     */         } 
/*     */         
/* 754 */         if (nullConversion.equals(NullConversion.THROW_EXCEPTION)) {
/* 755 */           Comparable<?> rrKey = zRowKey;
/* 756 */           if (x == null) {
/* 757 */             rrKey = yRowKey;
/* 758 */           } else if (y == null) {
/* 759 */             rrKey = yRowKey;
/*     */           } 
/* 761 */           throw new RuntimeException("There is a null value for the item [" + seriesKey + ", " + rrKey + ", " + colKey + "].");
/*     */         } 
/*     */ 
/*     */         
/* 765 */         if (nullConversion != NullConversion.SKIP) {
/* 766 */           double xx = convert(x, nullConversion);
/* 767 */           double yy = convert(y, nullConversion);
/* 768 */           double zz = convert(z, nullConversion);
/* 769 */           series.add(xx, yy, zz);
/*     */         } 
/*     */       } 
/*     */       
/* 773 */       dataset.add(series);
/*     */     } 
/* 775 */     return (XYZDataset)dataset;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static XYZDataset extractXYZDatasetFromColumns(KeyedValues3D<? extends Number> source, Comparable<?> xColKey, Comparable<?> yColKey, Comparable<?> zColKey) {
/* 805 */     return extractXYZDatasetFromColumns(source, xColKey, yColKey, zColKey, NullConversion.SKIP, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static XYZDataset extractXYZDatasetFromColumns(KeyedValues3D<? extends Number> source, Comparable<?> xColKey, Comparable<?> yColKey, Comparable<?> zColKey, NullConversion nullConversion, List<KeyedValues3DItemKey> exceptions) {
/* 844 */     ArgChecks.nullNotPermitted(source, "source");
/* 845 */     ArgChecks.nullNotPermitted(xColKey, "xColKey");
/* 846 */     ArgChecks.nullNotPermitted(yColKey, "yColKey");
/* 847 */     ArgChecks.nullNotPermitted(zColKey, "zColKey");
/* 848 */     XYZSeriesCollection dataset = new XYZSeriesCollection();
/* 849 */     for (Comparable<?> seriesKey : source.getSeriesKeys()) {
/* 850 */       XYZSeries series = new XYZSeries(seriesKey);
/* 851 */       for (Comparable<?> rowKey : source.getRowKeys()) {
/* 852 */         Number x = source.getValue(seriesKey, rowKey, xColKey);
/* 853 */         Number y = source.getValue(seriesKey, rowKey, yColKey);
/* 854 */         Number z = source.getValue(seriesKey, rowKey, zColKey);
/* 855 */         if (x != null && y != null && z != null) {
/* 856 */           series.add(x.doubleValue(), y.doubleValue(), z
/* 857 */               .doubleValue()); continue;
/*     */         } 
/* 859 */         if (exceptions != null) {
/*     */           
/* 861 */           Comparable<?> ccKey = zColKey;
/* 862 */           if (x == null) {
/* 863 */             ccKey = xColKey;
/* 864 */           } else if (y == null) {
/* 865 */             ccKey = yColKey;
/*     */           } 
/* 867 */           exceptions.add(new KeyedValues3DItemKey<Comparable<?>, Comparable<?>, Comparable<?>>(seriesKey, rowKey, ccKey));
/*     */         } 
/*     */         
/* 870 */         if (nullConversion.equals(NullConversion.THROW_EXCEPTION)) {
/* 871 */           Comparable<?> ccKey = zColKey;
/* 872 */           if (x == null) {
/* 873 */             ccKey = xColKey;
/* 874 */           } else if (y == null) {
/* 875 */             ccKey = yColKey;
/*     */           } 
/* 877 */           throw new RuntimeException("There is a null value for the item [" + seriesKey + ", " + rowKey + ", " + ccKey + "].");
/*     */         } 
/*     */ 
/*     */         
/* 881 */         if (nullConversion != NullConversion.SKIP) {
/* 882 */           double xx = convert(x, nullConversion);
/* 883 */           double yy = convert(y, nullConversion);
/* 884 */           double zz = convert(z, nullConversion);
/* 885 */           series.add(xx, yy, zz);
/*     */         } 
/*     */       } 
/*     */       
/* 889 */       dataset.add(series);
/*     */     } 
/* 891 */     return (XYZDataset)dataset;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static double convert(Number n, NullConversion nullConversion) {
/* 909 */     if (n != null) {
/* 910 */       return n.doubleValue();
/*     */     }
/* 912 */     if (nullConversion.equals(NullConversion.CONVERT_TO_ZERO)) {
/* 913 */       return 0.0D;
/*     */     }
/* 915 */     return Double.NaN;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/data/DataUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */