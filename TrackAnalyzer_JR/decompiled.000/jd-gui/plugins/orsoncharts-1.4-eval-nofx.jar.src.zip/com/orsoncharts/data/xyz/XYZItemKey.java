/*     */ package com.orsoncharts.data.xyz;
/*     */ 
/*     */ import com.orsoncharts.data.ItemKey;
/*     */ import com.orsoncharts.util.ArgChecks;
/*     */ import com.orsoncharts.util.ObjectUtils;
/*     */ import java.io.Serializable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XYZItemKey<S extends Comparable<S>>
/*     */   implements ItemKey, Comparable<XYZItemKey<S>>, Serializable
/*     */ {
/*     */   private final S seriesKey;
/*     */   private final int itemIndex;
/*     */   
/*     */   public XYZItemKey(S seriesKey, int itemIndex) {
/*  45 */     ArgChecks.nullNotPermitted(seriesKey, "seriesKey");
/*  46 */     this.seriesKey = seriesKey;
/*  47 */     this.itemIndex = itemIndex;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public S getSeriesKey() {
/*  56 */     return this.seriesKey;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getItemIndex() {
/*  65 */     return this.itemIndex;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/*  77 */     if (obj == this) {
/*  78 */       return true;
/*     */     }
/*  80 */     if (!(obj instanceof XYZItemKey)) {
/*  81 */       return false;
/*     */     }
/*  83 */     XYZItemKey that = (XYZItemKey)obj;
/*  84 */     if (!this.seriesKey.equals(that.seriesKey)) {
/*  85 */       return false;
/*     */     }
/*  87 */     if (this.itemIndex != that.itemIndex) {
/*  88 */       return false;
/*     */     }
/*  90 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*  95 */     int hash = 7;
/*  96 */     hash = 41 * hash + ObjectUtils.hashCode(this.seriesKey);
/*  97 */     hash = 41 * hash + this.itemIndex;
/*  98 */     return hash;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toJSONString() {
/* 103 */     StringBuilder sb = new StringBuilder();
/* 104 */     sb.append("{\"seriesKey\": \"").append(this.seriesKey.toString());
/* 105 */     sb.append("\", ");
/* 106 */     sb.append("\"itemIndex\": ").append(this.itemIndex).append("}");
/* 107 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 112 */     StringBuilder sb = new StringBuilder();
/* 113 */     sb.append("XYZItemKey[seriesKey=");
/* 114 */     sb.append(this.seriesKey.toString()).append(",item=");
/* 115 */     sb.append(this.itemIndex);
/* 116 */     sb.append("]");
/* 117 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public int compareTo(XYZItemKey<S> key) {
/* 122 */     int result = this.seriesKey.compareTo(key.seriesKey);
/* 123 */     if (result == 0) {
/* 124 */       result = this.itemIndex - key.itemIndex;
/*     */     }
/* 126 */     return result;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/data/xyz/XYZItemKey.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */