/*     */ package com.orsoncharts.data;
/*     */ 
/*     */ import com.orsoncharts.util.ArgChecks;
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class DefaultKeyedValues<T>
/*     */   implements KeyedValues<T>, Serializable
/*     */ {
/*     */   private List<KeyedValue<T>> data;
/*     */   
/*     */   public DefaultKeyedValues() {
/*  41 */     this(new ArrayList<Comparable<?>>());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DefaultKeyedValues(List<Comparable<?>> keys) {
/*  53 */     ArgChecks.nullNotPermitted(keys, "keys");
/*  54 */     this.data = new ArrayList<KeyedValue<T>>();
/*  55 */     for (Comparable<?> key : keys) {
/*  56 */       this.data.add(new DefaultKeyedValue<T>(key, null));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void clear() {
/*  64 */     this.data.clear();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void put(Comparable<?> key, T value) {
/*  75 */     ArgChecks.nullNotPermitted(key, "key");
/*     */     
/*  77 */     int index = getIndex(key);
/*  78 */     if (index >= 0) {
/*  79 */       DefaultKeyedValue<T> dkv = (DefaultKeyedValue<T>)this.data.get(index);
/*  80 */       dkv.setValue(value);
/*     */     } else {
/*  82 */       this.data.add(new DefaultKeyedValue<T>(key, value));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void remove(Comparable<?> key) {
/*  92 */     ArgChecks.nullNotPermitted(key, "key");
/*  93 */     int index = getIndex(key);
/*  94 */     if (index >= 0) {
/*  95 */       remove(index);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void remove(int index) {
/* 105 */     this.data.remove(index);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Comparable<?> getKey(int index) {
/* 117 */     KeyedValue<T> kv = this.data.get(index);
/* 118 */     return kv.getKey();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getIndex(Comparable<?> key) {
/* 131 */     ArgChecks.nullNotPermitted(key, "key");
/* 132 */     for (int i = 0; i < this.data.size(); i++) {
/* 133 */       KeyedValue<T> kv = this.data.get(i);
/* 134 */       if (kv.getKey().equals(key)) {
/* 135 */         return i;
/*     */       }
/*     */     } 
/* 138 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Comparable<?>> getKeys() {
/* 149 */     List<Comparable<?>> keys = new ArrayList<Comparable<?>>();
/* 150 */     for (KeyedValue<T> kv : this.data) {
/* 151 */       keys.add(kv.getKey());
/*     */     }
/* 153 */     return keys;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T getValue(Comparable<?> key) {
/* 166 */     int index = getIndex(key);
/* 167 */     if (index < 0) {
/* 168 */       return null;
/*     */     }
/* 170 */     return getValue(index);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getItemCount() {
/* 180 */     return this.data.size();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T getValue(int item) {
/* 192 */     KeyedValue<T> kv = this.data.get(item);
/* 193 */     return kv.getValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getDoubleValue(int item) {
/* 206 */     T n = getValue(item);
/* 207 */     if (n != null && n instanceof Number) {
/* 208 */       return ((Number)n).doubleValue();
/*     */     }
/* 210 */     return Double.NaN;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 222 */     if (obj == this) {
/* 223 */       return true;
/*     */     }
/* 225 */     if (!(obj instanceof DefaultKeyedValues)) {
/* 226 */       return false;
/*     */     }
/* 228 */     DefaultKeyedValues<?> that = (DefaultKeyedValues)obj;
/* 229 */     if (!this.data.equals(that.data)) {
/* 230 */       return false;
/*     */     }
/* 232 */     return true;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/data/DefaultKeyedValues.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */