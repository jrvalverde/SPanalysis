/*     */ package com.orsoncharts.data;
/*     */ 
/*     */ import com.orsoncharts.util.ArgChecks;
/*     */ import com.orsoncharts.util.ObjectUtils;
/*     */ import java.io.Serializable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class KeyedValues3DItemKey<S extends Comparable<S>, R extends Comparable<R>, C extends Comparable<C>>
/*     */   implements ItemKey, Comparable<KeyedValues3DItemKey<S, R, C>>, Serializable
/*     */ {
/*     */   S seriesKey;
/*     */   R rowKey;
/*     */   C columnKey;
/*     */   
/*     */   public KeyedValues3DItemKey(S seriesKey, R rowKey, C columnKey) {
/*  49 */     ArgChecks.nullNotPermitted(seriesKey, "seriesKey");
/*  50 */     ArgChecks.nullNotPermitted(rowKey, "rowKey");
/*  51 */     ArgChecks.nullNotPermitted(columnKey, "columnKey");
/*  52 */     this.seriesKey = seriesKey;
/*  53 */     this.rowKey = rowKey;
/*  54 */     this.columnKey = columnKey;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public S getSeriesKey() {
/*  63 */     return this.seriesKey;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public R getRowKey() {
/*  72 */     return this.rowKey;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public C getColumnKey() {
/*  81 */     return this.columnKey;
/*     */   }
/*     */ 
/*     */   
/*     */   public int compareTo(KeyedValues3DItemKey<S, R, C> key) {
/*  86 */     int result = this.seriesKey.compareTo(key.getSeriesKey());
/*  87 */     if (result == 0) {
/*  88 */       result = this.rowKey.compareTo(key.rowKey);
/*  89 */       if (result == 0) {
/*  90 */         result = this.columnKey.compareTo(key.columnKey);
/*     */       }
/*     */     } 
/*  93 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 105 */     if (obj == this) {
/* 106 */       return true;
/*     */     }
/* 108 */     if (!(obj instanceof KeyedValues3DItemKey)) {
/* 109 */       return false;
/*     */     }
/* 111 */     KeyedValues3DItemKey that = (KeyedValues3DItemKey)obj;
/* 112 */     if (!this.seriesKey.equals(that.seriesKey)) {
/* 113 */       return false;
/*     */     }
/* 115 */     if (!this.rowKey.equals(that.rowKey)) {
/* 116 */       return false;
/*     */     }
/* 118 */     if (!this.columnKey.equals(that.columnKey)) {
/* 119 */       return false;
/*     */     }
/* 121 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 126 */     int hash = 3;
/* 127 */     hash = 17 * hash + ObjectUtils.hashCode(this.seriesKey);
/* 128 */     hash = 17 * hash + ObjectUtils.hashCode(this.rowKey);
/* 129 */     hash = 17 * hash + ObjectUtils.hashCode(this.columnKey);
/* 130 */     return hash;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toJSONString() {
/* 135 */     StringBuilder sb = new StringBuilder();
/* 136 */     sb.append("{\"seriesKey\": \"").append(this.seriesKey.toString());
/* 137 */     sb.append("\", ");
/* 138 */     sb.append("\"rowKey\": \"").append(this.rowKey.toString());
/* 139 */     sb.append("\", ");
/* 140 */     sb.append("\"columnKey\": \"").append(this.columnKey.toString());
/* 141 */     sb.append("\"}");
/* 142 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 147 */     StringBuilder sb = new StringBuilder();
/* 148 */     sb.append("Values3DItemKey[series=");
/* 149 */     sb.append(this.seriesKey.toString()).append(",row=");
/* 150 */     sb.append(this.rowKey.toString()).append(",column=");
/* 151 */     sb.append(this.columnKey.toString());
/* 152 */     sb.append("]");
/* 153 */     return sb.toString();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/data/KeyedValues3DItemKey.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */