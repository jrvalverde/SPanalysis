/*     */ package com.orsoncharts.data.xyz;
/*     */ 
/*     */ import com.orsoncharts.data.AbstractDataset3D;
/*     */ import com.orsoncharts.data.JSONUtils;
/*     */ import com.orsoncharts.util.ArgChecks;
/*     */ import com.orsoncharts.util.ObjectUtils;
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XYZSeriesCollection
/*     */   extends AbstractDataset3D
/*     */   implements XYZDataset, Serializable
/*     */ {
/*  46 */   private final List<XYZSeries> series = new ArrayList<XYZSeries>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getSeriesCount() {
/*  56 */     return this.series.size();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getSeriesIndex(Comparable<?> key) {
/*  69 */     ArgChecks.nullNotPermitted(key, "key");
/*  70 */     return getSeriesKeys().indexOf(key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Comparable<?>> getSeriesKeys() {
/*  82 */     List<Comparable<?>> result = new ArrayList<Comparable<?>>();
/*  83 */     for (XYZSeries s : this.series) {
/*  84 */       result.add(s.getKey());
/*     */     }
/*  86 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Comparable<?> getSeriesKey(int seriesIndex) {
/* 100 */     return getSeries(seriesIndex).getKey();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void add(XYZSeries series) {
/* 110 */     ArgChecks.nullNotPermitted(series, "series");
/* 111 */     if (getSeriesIndex(series.getKey()) >= 0) {
/* 112 */       throw new IllegalArgumentException("Another series with the same key already exists within the collection.");
/*     */     }
/* 114 */     this.series.add(series);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XYZSeries getSeries(int index) {
/* 127 */     ArgChecks.checkArrayBounds(index, "index", this.series.size());
/* 128 */     return this.series.get(index);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XYZSeries getSeries(Comparable<?> key) {
/* 142 */     ArgChecks.nullNotPermitted(key, "key");
/* 143 */     for (XYZSeries s : this.series) {
/* 144 */       if (s.getKey().equals(key)) {
/* 145 */         return s;
/*     */       }
/*     */     } 
/* 148 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getItemCount(int seriesIndex) {
/* 160 */     ArgChecks.nullNotPermitted(this, null);
/* 161 */     XYZSeries s = this.series.get(seriesIndex);
/* 162 */     return s.getItemCount();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getX(int seriesIndex, int itemIndex) {
/* 175 */     XYZSeries s = this.series.get(seriesIndex);
/* 176 */     return s.getXValue(itemIndex);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getY(int seriesIndex, int itemIndex) {
/* 189 */     XYZSeries s = this.series.get(seriesIndex);
/* 190 */     return s.getYValue(itemIndex);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getZ(int seriesIndex, int itemIndex) {
/* 203 */     XYZSeries s = this.series.get(seriesIndex);
/* 204 */     return s.getZValue(itemIndex);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 216 */     if (obj == this) {
/* 217 */       return true;
/*     */     }
/* 219 */     if (!(obj instanceof XYZSeriesCollection)) {
/* 220 */       return false;
/*     */     }
/* 222 */     XYZSeriesCollection that = (XYZSeriesCollection)obj;
/* 223 */     if (!this.series.equals(that.series)) {
/* 224 */       return false;
/*     */     }
/* 226 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 231 */     int hash = 5;
/* 232 */     hash = 59 * hash + ObjectUtils.hashCode(this.series);
/* 233 */     return hash;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 248 */     return JSONUtils.writeXYZDataset(this);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/data/xyz/XYZSeriesCollection.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */