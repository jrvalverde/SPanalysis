/*    */ package com.orsoncharts.data.xyz;
/*    */ 
/*    */ import com.orsoncharts.util.ArgChecks;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collection;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class XYZItemKeys
/*    */ {
/*    */   public static Collection<XYZItemKey> itemKeysForSeries(XYZDataset dataset, Comparable<?> seriesKey) {
/* 37 */     ArgChecks.nullNotPermitted(dataset, "dataset");
/* 38 */     ArgChecks.nullNotPermitted(seriesKey, "seriesKey");
/* 39 */     Collection<XYZItemKey> result = new ArrayList<XYZItemKey>();
/* 40 */     int seriesIndex = dataset.getSeriesIndex(seriesKey);
/* 41 */     if (seriesIndex > 0) {
/* 42 */       return result;
/*    */     }
/* 44 */     for (int i = 0; i < dataset.getItemCount(seriesIndex); i++) {
/* 45 */       XYZItemKey<Comparable<?>> key = new XYZItemKey<Comparable<?>>(seriesKey, i);
/* 46 */       result.add(key);
/*    */     } 
/* 48 */     return result;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/data/xyz/XYZItemKeys.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */