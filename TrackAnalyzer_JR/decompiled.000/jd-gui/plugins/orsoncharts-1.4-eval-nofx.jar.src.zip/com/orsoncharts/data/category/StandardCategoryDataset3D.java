/*     */ package com.orsoncharts.data.category;
/*     */ 
/*     */ import com.orsoncharts.data.AbstractDataset3D;
/*     */ import com.orsoncharts.data.DefaultKeyedValues3D;
/*     */ import com.orsoncharts.data.JSONUtils;
/*     */ import com.orsoncharts.data.KeyedValues;
/*     */ import com.orsoncharts.util.ArgChecks;
/*     */ import java.io.Serializable;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class StandardCategoryDataset3D
/*     */   extends AbstractDataset3D
/*     */   implements CategoryDataset3D, Serializable
/*     */ {
/*  45 */   private DefaultKeyedValues3D<Number> data = new DefaultKeyedValues3D();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getSeriesCount() {
/*  55 */     return this.data.getSeriesCount();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getRowCount() {
/*  65 */     return this.data.getRowCount();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getColumnCount() {
/*  75 */     return this.data.getColumnCount();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Comparable<?> getSeriesKey(int seriesIndex) {
/*  87 */     return this.data.getSeriesKey(seriesIndex);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Comparable<?> getRowKey(int rowIndex) {
/*  99 */     return this.data.getRowKey(rowIndex);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Comparable<?> getColumnKey(int columnIndex) {
/* 111 */     return this.data.getColumnKey(columnIndex);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getSeriesIndex(Comparable<?> serieskey) {
/* 124 */     return this.data.getSeriesIndex(serieskey);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getRowIndex(Comparable<?> rowkey) {
/* 138 */     return this.data.getRowIndex(rowkey);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getColumnIndex(Comparable<?> columnkey) {
/* 152 */     return this.data.getColumnIndex(columnkey);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Comparable<?>> getSeriesKeys() {
/* 164 */     return this.data.getSeriesKeys();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Comparable<?>> getRowKeys() {
/* 176 */     return this.data.getRowKeys();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Comparable<?>> getColumnKeys() {
/* 188 */     return this.data.getColumnKeys();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Number getValue(Comparable<?> seriesKey, Comparable<?> rowKey, Comparable<?> columnKey) {
/* 204 */     return (Number)this.data.getValue(seriesKey, rowKey, columnKey);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Number getValue(int seriesIndex, int rowIndex, int columnIndex) {
/* 219 */     return (Number)this.data.getValue(seriesIndex, rowIndex, columnIndex);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setValue(Number n, Comparable<?> seriesKey, Comparable<?> rowKey, Comparable<?> columnKey) {
/* 233 */     this.data.setValue(n, seriesKey, rowKey, columnKey);
/* 234 */     fireDatasetChanged();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addValue(Number n, Comparable<?> seriesKey, Comparable<?> rowKey, Comparable<?> columnKey) {
/* 250 */     setValue(n, seriesKey, rowKey, columnKey);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getDoubleValue(int seriesIndex, int rowIndex, int columnIndex) {
/* 267 */     return this.data.getDoubleValue(seriesIndex, rowIndex, columnIndex);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addSeriesAsRow(Comparable<?> seriesKey, KeyedValues<? extends Number> data) {
/* 278 */     addSeriesAsRow(seriesKey, seriesKey, data);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addSeriesAsRow(Comparable<?> seriesKey, Comparable<?> rowKey, KeyedValues<? extends Number> data) {
/* 290 */     ArgChecks.nullNotPermitted(seriesKey, "seriesKey");
/* 291 */     ArgChecks.nullNotPermitted(data, "data");
/* 292 */     for (Comparable<?> key : (Iterable<Comparable<?>>)data.getKeys()) {
/* 293 */       setValue((Number)data.getValue(key), seriesKey, rowKey, key);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 306 */     if (obj == this) {
/* 307 */       return true;
/*     */     }
/* 309 */     if (!(obj instanceof StandardCategoryDataset3D)) {
/* 310 */       return false;
/*     */     }
/* 312 */     StandardCategoryDataset3D that = (StandardCategoryDataset3D)obj;
/* 313 */     if (!this.data.equals(that.data)) {
/* 314 */       return false;
/*     */     }
/* 316 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 331 */     return JSONUtils.writeKeyedValues3D(this);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/data/category/StandardCategoryDataset3D.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */