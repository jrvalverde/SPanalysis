package com.orsoncharts.data.function;

import java.io.Serializable;

public interface Function3D extends Serializable {
  double getValue(double paramDouble1, double paramDouble2);
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/data/function/Function3D.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */