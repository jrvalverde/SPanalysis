package com.orsoncharts.data;

public interface Values2D<T> {
  int getRowCount();
  
  int getColumnCount();
  
  T getValue(int paramInt1, int paramInt2);
  
  double getDoubleValue(int paramInt1, int paramInt2);
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/data/Values2D.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */