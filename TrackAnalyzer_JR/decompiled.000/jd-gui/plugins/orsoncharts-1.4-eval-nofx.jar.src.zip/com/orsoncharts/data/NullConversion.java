/*    */ package com.orsoncharts.data;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum NullConversion
/*    */ {
/* 24 */   SKIP,
/*    */ 
/*    */   
/* 27 */   CONVERT_TO_NAN,
/*    */ 
/*    */   
/* 30 */   CONVERT_TO_ZERO,
/*    */ 
/*    */   
/* 33 */   THROW_EXCEPTION;
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/data/NullConversion.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */