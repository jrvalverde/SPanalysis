/*    */ package com.orsoncharts.data;
/*    */ 
/*    */ import com.orsoncharts.util.ArgChecks;
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class KeyedValuesItemKey
/*    */   implements ItemKey, Serializable
/*    */ {
/*    */   Comparable<? extends Object> key;
/*    */   
/*    */   public KeyedValuesItemKey(Comparable<? extends Object> key) {
/* 35 */     ArgChecks.nullNotPermitted(key, "key");
/* 36 */     this.key = key;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Comparable<?> getKey() {
/* 45 */     return this.key;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean equals(Object obj) {
/* 57 */     if (obj == this) {
/* 58 */       return true;
/*    */     }
/* 60 */     if (!(obj instanceof KeyedValuesItemKey)) {
/* 61 */       return false;
/*    */     }
/* 63 */     KeyedValuesItemKey that = (KeyedValuesItemKey)obj;
/* 64 */     if (!this.key.equals(that.key)) {
/* 65 */       return false;
/*    */     }
/* 67 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toJSONString() {
/* 72 */     StringBuilder sb = new StringBuilder();
/* 73 */     sb.append("{\"key\": \"").append(this.key.toString()).append("\"}");
/* 74 */     return sb.toString();
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 79 */     StringBuilder sb = new StringBuilder();
/* 80 */     sb.append("ValuesItemKey[");
/* 81 */     sb.append(this.key.toString());
/* 82 */     sb.append("]");
/* 83 */     return sb.toString();
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/data/KeyedValuesItemKey.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */