/*    */ package com.orsoncharts;
/*    */ 
/*    */ import com.orsoncharts.util.Anchor2D;
/*    */ import com.orsoncharts.util.RefPt2D;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class TitleAnchor
/*    */ {
/* 28 */   public static final Anchor2D TOP_LEFT = new Anchor2D(RefPt2D.TOP_LEFT);
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 33 */   public static final Anchor2D TOP_RIGHT = new Anchor2D(RefPt2D.TOP_RIGHT);
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 38 */   public static final Anchor2D TOP_CENTER = new Anchor2D(RefPt2D.TOP_CENTER);
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 43 */   public static final Anchor2D CENTER_LEFT = new Anchor2D(RefPt2D.CENTER_LEFT);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 51 */   public static final Anchor2D CENTER = new Anchor2D(RefPt2D.CENTER);
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 56 */   public static final Anchor2D CENTER_RIGHT = new Anchor2D(RefPt2D.CENTER_RIGHT);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 62 */   public static final Anchor2D BOTTOM_CENTER = new Anchor2D(RefPt2D.BOTTOM_CENTER);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 68 */   public static final Anchor2D BOTTOM_LEFT = new Anchor2D(RefPt2D.BOTTOM_LEFT);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 74 */   public static final Anchor2D BOTTOM_RIGHT = new Anchor2D(RefPt2D.BOTTOM_RIGHT);
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/TitleAnchor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */