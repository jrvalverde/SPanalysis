/*     */ package com.orsoncharts.label;
/*     */ 
/*     */ import com.orsoncharts.data.DataUtils;
/*     */ import com.orsoncharts.data.KeyedValues3D;
/*     */ import com.orsoncharts.data.category.CategoryDataset3D;
/*     */ import com.orsoncharts.util.ArgChecks;
/*     */ import java.io.Serializable;
/*     */ import java.util.Formatter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StandardCategoryLabelGenerator
/*     */   implements CategoryLabelGenerator, Serializable
/*     */ {
/*     */   public static final String KEY_ONLY_TEMPLATE = "%s";
/*     */   public static final String TOTAL_TEMPLATE = "%s (%3$,.0f)";
/*     */   public static final String TOTAL_TEMPLATE_2DP = "%s (%3$,.2f)";
/*     */   public static final String DEFAULT_TEMPLATE = "%s";
/*     */   private String template;
/*     */   
/*     */   public StandardCategoryLabelGenerator() {
/*  75 */     this("%s");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StandardCategoryLabelGenerator(String template) {
/*  87 */     ArgChecks.nullNotPermitted(template, "template");
/*  88 */     this.template = template;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String generateSeriesLabel(CategoryDataset3D dataset, Comparable<?> seriesKey) {
/* 102 */     ArgChecks.nullNotPermitted(dataset, "dataset");
/* 103 */     ArgChecks.nullNotPermitted(seriesKey, "seriesKey");
/* 104 */     Formatter formatter = new Formatter(new StringBuilder());
/* 105 */     int count = DataUtils.count((KeyedValues3D)dataset, seriesKey);
/* 106 */     double total = DataUtils.total((KeyedValues3D)dataset, seriesKey);
/* 107 */     formatter.format(this.template, new Object[] { seriesKey, Integer.valueOf(count), Double.valueOf(total) });
/* 108 */     String result = formatter.toString();
/* 109 */     formatter.close();
/* 110 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String generateRowLabel(CategoryDataset3D dataset, Comparable<?> rowKey) {
/* 124 */     ArgChecks.nullNotPermitted(dataset, "dataset");
/* 125 */     ArgChecks.nullNotPermitted(rowKey, "rowKey");
/* 126 */     Formatter formatter = new Formatter(new StringBuilder());
/* 127 */     int count = DataUtils.countForRow((KeyedValues3D)dataset, rowKey);
/* 128 */     double total = DataUtils.totalForRow((KeyedValues3D)dataset, rowKey);
/* 129 */     formatter.format(this.template, new Object[] { rowKey, Integer.valueOf(count), Double.valueOf(total) });
/* 130 */     String result = formatter.toString();
/* 131 */     formatter.close();
/* 132 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String generateColumnLabel(CategoryDataset3D dataset, Comparable<?> columnKey) {
/* 146 */     ArgChecks.nullNotPermitted(dataset, "dataset");
/* 147 */     ArgChecks.nullNotPermitted(columnKey, "columnKey");
/* 148 */     Formatter formatter = new Formatter(new StringBuilder());
/* 149 */     int count = DataUtils.countForColumn((KeyedValues3D)dataset, columnKey);
/* 150 */     double total = DataUtils.totalForColumn((KeyedValues3D)dataset, columnKey);
/* 151 */     formatter.format(this.template, new Object[] { columnKey, Integer.valueOf(count), Double.valueOf(total) });
/* 152 */     String result = formatter.toString();
/* 153 */     formatter.close();
/* 154 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 166 */     if (obj == this) {
/* 167 */       return true;
/*     */     }
/* 169 */     if (!(obj instanceof StandardCategoryLabelGenerator)) {
/* 170 */       return false;
/*     */     }
/* 172 */     StandardCategoryLabelGenerator that = (StandardCategoryLabelGenerator)obj;
/*     */     
/* 174 */     if (!this.template.equals(that.template)) {
/* 175 */       return false;
/*     */     }
/* 177 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 182 */     return this.template.hashCode();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/label/StandardCategoryLabelGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */