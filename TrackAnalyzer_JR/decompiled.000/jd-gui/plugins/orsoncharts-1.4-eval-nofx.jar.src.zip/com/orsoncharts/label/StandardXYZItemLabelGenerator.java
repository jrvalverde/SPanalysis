/*     */ package com.orsoncharts.label;
/*     */ 
/*     */ import com.orsoncharts.data.xyz.XYZDataset;
/*     */ import com.orsoncharts.data.xyz.XYZItemKey;
/*     */ import com.orsoncharts.interaction.XYZDataItemSelection;
/*     */ import com.orsoncharts.util.ArgChecks;
/*     */ import java.io.Serializable;
/*     */ import java.util.Formatter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StandardXYZItemLabelGenerator
/*     */   implements XYZItemLabelGenerator, Serializable
/*     */ {
/*     */   public static final String KEY_AND_COORDS_3DP_TEMPLATE = "%s (%2$.3f, %3$.3f, %4$.3f)";
/*     */   public static final String COORDS_3DP_TEMPLATE = "(%2$.3f, %3$.3f, %4$.3f)";
/*     */   public static final String DEFAULT_TEMPLATE = "%s (%2$.3f, %3$.3f, %4$.3f)";
/*     */   private String template;
/*     */   private XYZDataItemSelection itemSelection;
/*     */   
/*     */   public StandardXYZItemLabelGenerator() {
/*  65 */     this("%s (%2$.3f, %3$.3f, %4$.3f)");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StandardXYZItemLabelGenerator(String template) {
/*  74 */     ArgChecks.nullNotPermitted(template, "template");
/*  75 */     this.template = template;
/*  76 */     this.itemSelection = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XYZDataItemSelection getItemSelection() {
/*  86 */     return this.itemSelection;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setItemSelection(XYZDataItemSelection selection) {
/*  97 */     this.itemSelection = selection;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String generateItemLabel(XYZDataset dataset, Comparable<?> seriesKey, int itemIndex) {
/* 111 */     ArgChecks.nullNotPermitted(dataset, "dataset");
/* 112 */     ArgChecks.nullNotPermitted(seriesKey, "seriesKey");
/* 113 */     if (this.itemSelection != null) {
/* 114 */       XYZItemKey key = new XYZItemKey(seriesKey, itemIndex);
/* 115 */       if (!this.itemSelection.isSelected(key)) {
/* 116 */         return null;
/*     */       }
/*     */     } 
/* 119 */     int seriesIndex = dataset.getSeriesIndex(seriesKey);
/* 120 */     Formatter formatter = new Formatter(new StringBuilder());
/* 121 */     double x = dataset.getX(seriesIndex, itemIndex);
/* 122 */     double y = dataset.getY(seriesIndex, itemIndex);
/* 123 */     double z = dataset.getZ(seriesIndex, itemIndex);
/* 124 */     formatter.format(this.template, new Object[] { seriesKey, Double.valueOf(x), Double.valueOf(y), Double.valueOf(z) });
/* 125 */     String result = formatter.toString();
/* 126 */     formatter.close();
/* 127 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 139 */     if (obj == this) {
/* 140 */       return true;
/*     */     }
/* 142 */     if (!(obj instanceof StandardXYZItemLabelGenerator)) {
/* 143 */       return false;
/*     */     }
/* 145 */     StandardXYZItemLabelGenerator that = (StandardXYZItemLabelGenerator)obj;
/* 146 */     if (!this.template.equals(that.template)) {
/* 147 */       return false;
/*     */     }
/* 149 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 154 */     return this.template.hashCode();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/label/StandardXYZItemLabelGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */