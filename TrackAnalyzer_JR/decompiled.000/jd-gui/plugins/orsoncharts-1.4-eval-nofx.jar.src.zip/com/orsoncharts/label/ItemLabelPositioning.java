/*    */ package com.orsoncharts.label;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum ItemLabelPositioning
/*    */ {
/* 26 */   FRONT_AND_BACK,
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 31 */   CENTRAL;
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/label/ItemLabelPositioning.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */