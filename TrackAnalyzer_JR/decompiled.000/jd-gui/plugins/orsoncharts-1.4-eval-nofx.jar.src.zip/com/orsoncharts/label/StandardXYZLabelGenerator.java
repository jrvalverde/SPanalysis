/*     */ package com.orsoncharts.label;
/*     */ 
/*     */ import com.orsoncharts.data.DataUtils;
/*     */ import com.orsoncharts.data.xyz.XYZDataset;
/*     */ import com.orsoncharts.util.ArgChecks;
/*     */ import java.io.Serializable;
/*     */ import java.util.Formatter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StandardXYZLabelGenerator
/*     */   implements XYZLabelGenerator, Serializable
/*     */ {
/*     */   public static final String KEY_ONLY_TEMPLATE = "%s";
/*     */   public static final String TOTAL_TEMPLATE = "%s (%3$,.0f)";
/*     */   public static final String TOTAL_TEMPLATE_2DP = "%s (%3$,.2f)";
/*     */   public static final String COUNT_TEMPLATE = "%s (%2$,d)";
/*     */   public static final String DEFAULT_TEMPLATE = "%s";
/*     */   private String template;
/*     */   
/*     */   public StandardXYZLabelGenerator() {
/*  74 */     this("%s");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StandardXYZLabelGenerator(String template) {
/*  83 */     ArgChecks.nullNotPermitted(template, "template");
/*  84 */     this.template = template;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String generateSeriesLabel(XYZDataset dataset, Comparable<?> seriesKey) {
/*  98 */     ArgChecks.nullNotPermitted(dataset, "dataset");
/*  99 */     ArgChecks.nullNotPermitted(seriesKey, "seriesKey");
/* 100 */     Formatter formatter = new Formatter(new StringBuilder());
/* 101 */     int count = dataset.getItemCount(dataset.getSeriesIndex(seriesKey));
/* 102 */     double total = DataUtils.total(dataset, seriesKey);
/* 103 */     formatter.format(this.template, new Object[] { seriesKey, Integer.valueOf(count), Double.valueOf(total) });
/* 104 */     String result = formatter.toString();
/* 105 */     formatter.close();
/* 106 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 118 */     if (obj == this) {
/* 119 */       return true;
/*     */     }
/* 121 */     if (!(obj instanceof StandardXYZLabelGenerator)) {
/* 122 */       return false;
/*     */     }
/* 124 */     StandardXYZLabelGenerator that = (StandardXYZLabelGenerator)obj;
/* 125 */     if (!this.template.equals(that.template)) {
/* 126 */       return false;
/*     */     }
/* 128 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 133 */     return this.template.hashCode();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/label/StandardXYZLabelGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */