package com.orsoncharts.label;

import com.orsoncharts.data.category.CategoryDataset3D;

public interface CategoryItemLabelGenerator {
  String generateItemLabel(CategoryDataset3D paramCategoryDataset3D, Comparable<?> paramComparable1, Comparable<?> paramComparable2, Comparable<?> paramComparable3);
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/label/CategoryItemLabelGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */