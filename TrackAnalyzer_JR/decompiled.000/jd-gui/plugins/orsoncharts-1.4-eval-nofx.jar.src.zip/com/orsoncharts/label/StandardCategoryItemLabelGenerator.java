/*     */ package com.orsoncharts.label;
/*     */ 
/*     */ import com.orsoncharts.data.KeyedValues3DItemKey;
/*     */ import com.orsoncharts.data.category.CategoryDataset3D;
/*     */ import com.orsoncharts.interaction.KeyedValues3DItemSelection;
/*     */ import com.orsoncharts.interaction.StandardKeyedValues3DItemSelection;
/*     */ import com.orsoncharts.util.ArgChecks;
/*     */ import com.orsoncharts.util.ObjectUtils;
/*     */ import java.io.Serializable;
/*     */ import java.util.Formatter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StandardCategoryItemLabelGenerator
/*     */   implements CategoryItemLabelGenerator, Serializable
/*     */ {
/*     */   public static final String VALUE_TEMPLATE = "%4$.2f";
/*     */   public static final String KEYS_AND_VALUE_TEMPLATE = "%s, %s, %s = %4$.3f";
/*     */   public static final String SERIES_AND_COLUMN_KEYS_AND_VALUE_TEMPLATE = "%1$s, %3$s = %4$.3f";
/*     */   public static final String DEFAULT_TEMPLATE = "%1$s, %3$s = %4$.3f";
/*     */   private String template;
/*     */   private KeyedValues3DItemSelection itemSelection;
/*     */   
/*     */   public StandardCategoryItemLabelGenerator() {
/*  88 */     this("%1$s, %3$s = %4$.3f");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StandardCategoryItemLabelGenerator(String template) {
/* 100 */     ArgChecks.nullNotPermitted(template, "template");
/* 101 */     this.template = template;
/* 102 */     this.itemSelection = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public KeyedValues3DItemSelection getItemSelection() {
/* 113 */     return this.itemSelection;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setItemSelection(StandardKeyedValues3DItemSelection selection) {
/* 125 */     this.itemSelection = (KeyedValues3DItemSelection)selection;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String generateItemLabel(CategoryDataset3D dataset, Comparable<?> seriesKey, Comparable<?> rowKey, Comparable<?> columnKey) {
/* 142 */     ArgChecks.nullNotPermitted(dataset, "dataset");
/* 143 */     ArgChecks.nullNotPermitted(seriesKey, "seriesKey");
/* 144 */     ArgChecks.nullNotPermitted(rowKey, "rowKey");
/* 145 */     ArgChecks.nullNotPermitted(columnKey, "columnKey");
/* 146 */     if (this.itemSelection != null) {
/* 147 */       KeyedValues3DItemKey key = new KeyedValues3DItemKey(seriesKey, rowKey, columnKey);
/*     */       
/* 149 */       if (!this.itemSelection.isSelected(key)) {
/* 150 */         return null;
/*     */       }
/*     */     } 
/* 153 */     Formatter formatter = new Formatter(new StringBuilder());
/* 154 */     Number value = (Number)dataset.getValue(seriesKey, rowKey, columnKey);
/* 155 */     Double d = null;
/* 156 */     if (value != null) {
/* 157 */       d = Double.valueOf(value.doubleValue());
/*     */     }
/* 159 */     formatter.format(this.template, new Object[] { seriesKey, rowKey, columnKey, d });
/* 160 */     String result = formatter.toString();
/* 161 */     formatter.close();
/* 162 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 174 */     if (obj == this) {
/* 175 */       return true;
/*     */     }
/* 177 */     if (!(obj instanceof StandardCategoryItemLabelGenerator)) {
/* 178 */       return false;
/*     */     }
/* 180 */     StandardCategoryItemLabelGenerator that = (StandardCategoryItemLabelGenerator)obj;
/*     */     
/* 182 */     if (!this.template.equals(that.template)) {
/* 183 */       return false;
/*     */     }
/* 185 */     if (!ObjectUtils.equals(this.itemSelection, that.itemSelection)) {
/* 186 */       return false;
/*     */     }
/* 188 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 193 */     return this.template.hashCode();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/label/StandardCategoryItemLabelGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */