package com.orsoncharts.label;

import com.orsoncharts.data.PieDataset3D;

public interface PieLabelGenerator {
  String generateLabel(PieDataset3D paramPieDataset3D, Comparable<?> paramComparable);
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/label/PieLabelGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */