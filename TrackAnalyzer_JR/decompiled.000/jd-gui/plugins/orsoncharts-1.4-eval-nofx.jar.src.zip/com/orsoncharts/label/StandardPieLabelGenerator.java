/*     */ package com.orsoncharts.label;
/*     */ 
/*     */ import com.orsoncharts.data.DataUtils;
/*     */ import com.orsoncharts.data.PieDataset3D;
/*     */ import com.orsoncharts.data.Values;
/*     */ import com.orsoncharts.util.ArgChecks;
/*     */ import java.io.Serializable;
/*     */ import java.util.Formatter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StandardPieLabelGenerator
/*     */   implements PieLabelGenerator, Serializable
/*     */ {
/*     */   public static final String KEY_ONLY_TEMPLATE = "%s";
/*     */   public static final String PERCENT_TEMPLATE = "%s (%3$,.0f%%)";
/*     */   public static final String PERCENT_TEMPLATE_2DP = "%s (%3$,.2f%%)";
/*     */   public static final String VALUE_TEMPLATE = "%s (%2$,.0f)";
/*     */   public static final String VALUE_TEMPLATE_2DP = "%s (%2$,.2f)";
/*     */   public static final String DEFAULT_TEMPLATE = "%s (%3$,.0f%%)";
/*     */   private String template;
/*     */   
/*     */   public StandardPieLabelGenerator() {
/*  96 */     this("%s (%3$,.0f%%)");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StandardPieLabelGenerator(String template) {
/* 108 */     ArgChecks.nullNotPermitted(template, "template");
/* 109 */     this.template = template;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String generateLabel(PieDataset3D dataset, Comparable<?> key) {
/* 122 */     ArgChecks.nullNotPermitted(dataset, "dataset");
/* 123 */     ArgChecks.nullNotPermitted(key, "key");
/* 124 */     Formatter formatter = new Formatter(new StringBuilder());
/* 125 */     Number value = (Number)dataset.getValue(key);
/* 126 */     Number percent = Double.valueOf(Double.NaN);
/* 127 */     if (value != null) {
/* 128 */       double total = DataUtils.total((Values)dataset);
/* 129 */       percent = Double.valueOf(100.0D * value.doubleValue() / total);
/*     */     } 
/* 131 */     formatter.format(this.template, new Object[] { key, value, percent });
/* 132 */     String result = formatter.toString();
/* 133 */     formatter.close();
/* 134 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 146 */     if (obj == this) {
/* 147 */       return true;
/*     */     }
/* 149 */     if (!(obj instanceof StandardPieLabelGenerator)) {
/* 150 */       return false;
/*     */     }
/* 152 */     StandardPieLabelGenerator that = (StandardPieLabelGenerator)obj;
/* 153 */     if (!this.template.equals(that.template)) {
/* 154 */       return false;
/*     */     }
/* 156 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 161 */     return this.template.hashCode();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/label/StandardPieLabelGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */