package com.orsoncharts.label;

import com.orsoncharts.data.xyz.XYZDataset;

public interface XYZItemLabelGenerator {
  String generateItemLabel(XYZDataset paramXYZDataset, Comparable<?> paramComparable, int paramInt);
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/label/XYZItemLabelGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */