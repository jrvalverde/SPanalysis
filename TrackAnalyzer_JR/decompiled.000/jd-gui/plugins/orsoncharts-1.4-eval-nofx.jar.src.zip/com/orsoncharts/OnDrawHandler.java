/*     */ package com.orsoncharts;
/*     */ 
/*     */ import com.orsoncharts.graphics3d.RenderedElement;
/*     */ import com.orsoncharts.graphics3d.RenderingInfo;
/*     */ import com.orsoncharts.interaction.InteractiveElementType;
/*     */ import com.orsoncharts.table.TableElement;
/*     */ import com.orsoncharts.table.TableElementOnDraw;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.geom.Rectangle2D;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OnDrawHandler
/*     */   implements TableElementOnDraw
/*     */ {
/*     */   private RenderingInfo info;
/*     */   boolean elementHinting;
/*     */   
/*     */   public OnDrawHandler(RenderingInfo info, boolean elementHinting) {
/*  51 */     this.info = info;
/*  52 */     this.elementHinting = elementHinting;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void beforeDraw(TableElement element, Graphics2D g2, Rectangle2D bounds) {
/*  60 */     InteractiveElementType t = (InteractiveElementType)element.getProperty("class");
/*     */ 
/*     */     
/*  63 */     if (t != null && this.info != null) {
/*  64 */       RenderedElement re; RenderedElement legendItemRE; switch (t) {
/*     */         case TITLE:
/*     */         case SUBTITLE:
/*  67 */           re = new RenderedElement(t, bounds);
/*  68 */           this.info.addElement(re);
/*     */           break;
/*     */         
/*     */         case LEGEND_ITEM:
/*  72 */           legendItemRE = new RenderedElement(InteractiveElementType.LEGEND_ITEM, bounds);
/*     */           
/*  74 */           legendItemRE.setProperty("series_key", element
/*  75 */               .getProperty("series_key"));
/*  76 */           this.info.addElement(legendItemRE);
/*     */           break;
/*     */         default:
/*  79 */           throw new RuntimeException();
/*     */       } 
/*     */ 
/*     */     
/*     */     } 
/*  84 */     if (t != null && this.elementHinting) {
/*  85 */       Map<Object, Object> m = new HashMap<Object, Object>();
/*  86 */       switch (t) {
/*     */         case TITLE:
/*  88 */           m.put("ref", "{\"type\": \"title\"}");
/*  89 */           g2.setRenderingHint(Chart3DHints.KEY_BEGIN_ELEMENT, m);
/*     */           return;
/*     */         case SUBTITLE:
/*  92 */           m.put("ref", "{\"type\": \"subtitle\"}");
/*  93 */           g2.setRenderingHint(Chart3DHints.KEY_BEGIN_ELEMENT, m);
/*     */           return;
/*     */         case LEGEND_ITEM:
/*  96 */           m.put("ref", generateLegendItemRef(element));
/*  97 */           g2.setRenderingHint(Chart3DHints.KEY_BEGIN_ELEMENT, m);
/*     */           return;
/*     */       } 
/* 100 */       throw new RuntimeException();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void afterDraw(TableElement element, Graphics2D g2, Rectangle2D bounds) {
/* 108 */     if (!this.elementHinting) {
/*     */       return;
/*     */     }
/*     */     
/* 112 */     InteractiveElementType t = (InteractiveElementType)element.getProperty("class");
/* 113 */     if (t == null) {
/*     */       return;
/*     */     }
/* 116 */     switch (t) {
/*     */       case TITLE:
/*     */       case SUBTITLE:
/*     */       case LEGEND_ITEM:
/* 120 */         g2.setRenderingHint(Chart3DHints.KEY_END_ELEMENT, Boolean.TRUE);
/*     */         return;
/*     */     } 
/* 123 */     throw new RuntimeException("Seeing type " + t);
/*     */   }
/*     */ 
/*     */   
/*     */   private String generateLegendItemRef(TableElement element) {
/* 128 */     Object key = element.getProperty("series_key");
/* 129 */     return "{\"type\": \"legendItem\", \"seriesKey\": \"" + key.toString() + "\"}";
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/OnDrawHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */