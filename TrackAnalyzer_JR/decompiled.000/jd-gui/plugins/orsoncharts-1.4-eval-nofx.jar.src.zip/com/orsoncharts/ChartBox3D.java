/*      */ package com.orsoncharts;
/*      */ 
/*      */ import com.orsoncharts.axis.TickData;
/*      */ import com.orsoncharts.graphics3d.Face;
/*      */ import com.orsoncharts.graphics3d.Object3D;
/*      */ import com.orsoncharts.graphics3d.Point3D;
/*      */ import com.orsoncharts.marker.MarkerData;
/*      */ import com.orsoncharts.marker.MarkerDataType;
/*      */ import com.orsoncharts.util.Anchor2D;
/*      */ import com.orsoncharts.util.ArgChecks;
/*      */ import java.awt.Color;
/*      */ import java.awt.geom.Point2D;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collections;
/*      */ import java.util.List;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class ChartBox3D
/*      */ {
/*      */   private double xLength;
/*      */   private double yLength;
/*      */   private double zLength;
/*      */   private double xOffset;
/*      */   private double yOffset;
/*      */   private double zOffset;
/*      */   private List<TickData> xTicks;
/*      */   private List<TickData> yTicks;
/*      */   private List<TickData> zTicks;
/*      */   private List<MarkerData> xMarkers;
/*      */   private List<MarkerData> yMarkers;
/*      */   private List<MarkerData> zMarkers;
/*      */   private Color color;
/*      */   private ChartBoxFace faceA;
/*      */   private ChartBoxFace faceB;
/*      */   private ChartBoxFace faceC;
/*      */   private ChartBoxFace faceD;
/*      */   private ChartBoxFace faceE;
/*      */   private ChartBoxFace faceF;
/*      */   
/*      */   public ChartBox3D(double xLength, double yLength, double zLength, double xOffset, double yOffset, double zOffset, Color color) {
/*   96 */     ArgChecks.nullNotPermitted(color, "color");
/*   97 */     this.xLength = xLength;
/*   98 */     this.yLength = yLength;
/*   99 */     this.zLength = zLength;
/*  100 */     this.xOffset = xOffset;
/*  101 */     this.yOffset = yOffset;
/*  102 */     this.zOffset = zOffset;
/*  103 */     this.color = color;
/*  104 */     this.xTicks = new ArrayList<TickData>(0);
/*  105 */     this.yTicks = new ArrayList<TickData>(0);
/*  106 */     this.zTicks = new ArrayList<TickData>(0);
/*  107 */     this.xMarkers = new ArrayList<MarkerData>(0);
/*  108 */     this.yMarkers = new ArrayList<MarkerData>(0);
/*  109 */     this.zMarkers = new ArrayList<MarkerData>(0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<TickData> getXTicks() {
/*  121 */     return this.xTicks;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setXTicks(List<TickData> ticks) {
/*  132 */     ArgChecks.nullNotPermitted(ticks, "ticks");
/*  133 */     this.xTicks = ticks;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<TickData> getYTicks() {
/*  145 */     return this.yTicks;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setYTicks(List<TickData> ticks) {
/*  156 */     ArgChecks.nullNotPermitted(ticks, "ticks");
/*  157 */     this.yTicks = ticks;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<TickData> getZTicks() {
/*  169 */     return this.zTicks;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setZTicks(List<TickData> ticks) {
/*  180 */     ArgChecks.nullNotPermitted(ticks, "ticks");
/*  181 */     this.zTicks = ticks;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<MarkerData> getXMarkers() {
/*  193 */     return this.xMarkers;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setXMarkers(List<MarkerData> markers) {
/*  205 */     ArgChecks.nullNotPermitted(markers, "markers");
/*  206 */     this.xMarkers = markers;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<MarkerData> getYMarkers() {
/*  218 */     return this.yMarkers;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setYMarkers(List<MarkerData> markers) {
/*  230 */     ArgChecks.nullNotPermitted(markers, "markers");
/*  231 */     this.yMarkers = markers;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<MarkerData> getZMarkers() {
/*  243 */     return this.zMarkers;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setZMarkers(List<MarkerData> markers) {
/*  255 */     ArgChecks.nullNotPermitted(markers, "markers");
/*  256 */     this.zMarkers = markers;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ChartBoxFace faceA() {
/*  265 */     return this.faceA;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ChartBoxFace faceB() {
/*  274 */     return this.faceB;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ChartBoxFace faceC() {
/*  283 */     return this.faceC;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ChartBoxFace faceD() {
/*  292 */     return this.faceD;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ChartBoxFace faceE() {
/*  301 */     return this.faceE;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ChartBoxFace faceF() {
/*  310 */     return this.faceF;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object3D createObject3D() {
/*  321 */     Object3D box = new Object3D(this.color);
/*  322 */     Point3D v0 = new Point3D(this.xOffset, this.yOffset, this.zOffset);
/*  323 */     Point3D v1 = new Point3D(this.xLength + this.xOffset, this.yOffset, this.zOffset);
/*  324 */     Point3D v2 = new Point3D(this.xLength + this.xOffset, this.yLength + this.yOffset, this.zOffset);
/*  325 */     Point3D v3 = new Point3D(this.xOffset, this.yLength + this.yOffset, this.zOffset);
/*  326 */     Point3D v4 = new Point3D(this.xOffset, this.yLength + this.yOffset, this.zLength + this.zOffset);
/*  327 */     Point3D v5 = new Point3D(this.xOffset, this.yOffset, this.zLength + this.zOffset);
/*  328 */     Point3D v6 = new Point3D(this.xLength + this.xOffset, this.yOffset, this.zLength + this.zOffset);
/*  329 */     Point3D v7 = new Point3D(this.xLength + this.xOffset, this.yLength + this.yOffset, this.zLength + this.zOffset);
/*      */ 
/*      */     
/*  332 */     box.addVertex(v0);
/*  333 */     box.addVertex(v1);
/*  334 */     box.addVertex(v2);
/*  335 */     box.addVertex(v3);
/*      */     
/*  337 */     box.addVertex(v4);
/*  338 */     box.addVertex(v5);
/*  339 */     box.addVertex(v6);
/*  340 */     box.addVertex(v7);
/*      */     
/*  342 */     this.faceA = new ChartBoxFace(box, new int[] { 0, 5, 6, 1 });
/*  343 */     this.faceB = new ChartBoxFace(box, new int[] { 0, 1, 2, 3 });
/*  344 */     this.faceC = new ChartBoxFace(box, new int[] { 7, 4, 3, 2 });
/*  345 */     this.faceD = new ChartBoxFace(box, new int[] { 5, 4, 7, 6 });
/*  346 */     this.faceE = new ChartBoxFace(box, new int[] { 0, 3, 4, 5 });
/*  347 */     this.faceF = new ChartBoxFace(box, new int[] { 6, 7, 2, 1 });
/*  348 */     box.addFace(this.faceA);
/*  349 */     box.addFace(this.faceB);
/*  350 */     box.addFace(this.faceC);
/*  351 */     box.addFace(this.faceD);
/*  352 */     box.addFace(this.faceE);
/*  353 */     box.addFace(this.faceF);
/*      */ 
/*      */     
/*  356 */     int base = 8;
/*  357 */     for (TickData t : this.xTicks) {
/*  358 */       double xx = this.xOffset + this.xLength * t.getPos();
/*  359 */       box.addVertex(xx, this.yOffset, this.zOffset);
/*  360 */       box.addVertex(xx, this.yOffset, this.zOffset + this.zLength);
/*  361 */       box.addVertex(xx, this.yOffset + this.yLength, this.zOffset + this.zLength);
/*  362 */       box.addVertex(xx, this.yOffset + this.yLength, this.zOffset);
/*  363 */       TickData td0 = new TickData(t, base);
/*  364 */       TickData td1 = new TickData(t, base + 1);
/*  365 */       TickData td2 = new TickData(t, base + 2);
/*  366 */       TickData td3 = new TickData(t, base + 3);
/*  367 */       this.faceA.addXTicks(td0, td1);
/*  368 */       this.faceB.addXTicks(td0, td3);
/*  369 */       this.faceC.addXTicks(td3, td2);
/*  370 */       this.faceD.addXTicks(td2, td1);
/*  371 */       base += 4;
/*      */     } 
/*      */ 
/*      */     
/*  375 */     for (TickData t : this.yTicks) {
/*  376 */       double yy = this.yOffset + this.yLength * t.getPos();
/*  377 */       box.addVertex(this.xOffset, yy, this.zOffset);
/*  378 */       box.addVertex(this.xOffset + this.xLength, yy, this.zOffset);
/*  379 */       box.addVertex(this.xOffset + this.xLength, yy, this.zOffset + this.zLength);
/*  380 */       box.addVertex(this.xOffset, yy, this.zOffset + this.zLength);
/*  381 */       TickData td0 = new TickData(t, base);
/*  382 */       TickData td1 = new TickData(t, base + 1);
/*  383 */       TickData td2 = new TickData(t, base + 2);
/*  384 */       TickData td3 = new TickData(t, base + 3);
/*  385 */       this.faceB.addYTicks(td0, td1);
/*  386 */       this.faceD.addYTicks(td2, td3);
/*  387 */       this.faceE.addYTicks(td0, td3);
/*  388 */       this.faceF.addYTicks(td1, td2);
/*  389 */       base += 4;
/*      */     } 
/*      */ 
/*      */     
/*  393 */     for (TickData t : this.zTicks) {
/*  394 */       double zz = this.zOffset + this.zLength * t.getPos();
/*  395 */       box.addVertex(this.xOffset, this.yOffset, zz);
/*  396 */       box.addVertex(this.xOffset + this.xLength, this.yOffset, zz);
/*  397 */       box.addVertex(this.xOffset + this.xLength, this.yOffset + this.yLength, zz);
/*  398 */       box.addVertex(this.xOffset, this.yOffset + this.yLength, zz);
/*  399 */       TickData td0 = new TickData(t, base);
/*  400 */       TickData td1 = new TickData(t, base + 1);
/*  401 */       TickData td2 = new TickData(t, base + 2);
/*  402 */       TickData td3 = new TickData(t, base + 3);
/*  403 */       this.faceA.addZTicks(td0, td1);
/*  404 */       this.faceC.addZTicks(td3, td2);
/*  405 */       this.faceE.addZTicks(td0, td3);
/*  406 */       this.faceF.addZTicks(td1, td2);
/*  407 */       base += 4;
/*      */     } 
/*      */ 
/*      */     
/*  411 */     for (MarkerData m : this.xMarkers) {
/*  412 */       if (m.getType().equals(MarkerDataType.VALUE)) {
/*      */         
/*  414 */         double xpos = this.xOffset + this.xLength * m.getValueLine().getPos();
/*  415 */         base += addXMarker(box, m, xpos, base); continue;
/*  416 */       }  if (m.getType().equals(MarkerDataType.RANGE)) {
/*      */         
/*  418 */         double startX = this.xOffset + this.xLength * m.getStartLine().getPos();
/*  419 */         double endX = this.xOffset + this.xLength * m.getEndLine().getPos();
/*  420 */         base += addXRangeMarker(box, m, startX, endX, base);
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  425 */     for (MarkerData m : this.yMarkers) {
/*  426 */       if (m.getType().equals(MarkerDataType.VALUE)) {
/*      */         
/*  428 */         double ypos = this.yOffset + this.yLength * m.getValueLine().getPos();
/*  429 */         base += addYMarker(box, m, ypos, base); continue;
/*  430 */       }  if (m.getType().equals(MarkerDataType.RANGE)) {
/*      */         
/*  432 */         double startY = this.yOffset + this.yLength * m.getStartLine().getPos();
/*  433 */         double endY = this.yOffset + this.yLength * m.getEndLine().getPos();
/*  434 */         base += addYRangeMarker(box, m, startY, endY, base);
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  439 */     for (MarkerData m : this.zMarkers) {
/*  440 */       if (m.getType().equals(MarkerDataType.VALUE)) {
/*      */         
/*  442 */         double zpos = this.zOffset + this.zLength * m.getValueLine().getPos();
/*  443 */         base += addZMarker(box, m, zpos, base); continue;
/*  444 */       }  if (m.getType().equals(MarkerDataType.RANGE)) {
/*      */         
/*  446 */         double startZ = this.zOffset + this.zLength * m.getStartLine().getPos();
/*  447 */         double endZ = this.zOffset + this.zLength * m.getEndLine().getPos();
/*  448 */         base += addZRangeMarker(box, m, startZ, endZ, base);
/*      */       } 
/*      */     } 
/*      */     
/*  452 */     return box;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int addXMarker(Object3D box, MarkerData m, double x, int base) {
/*  467 */     int result = 4;
/*  468 */     Point3D v0 = new Point3D(x, this.yOffset, this.zOffset);
/*  469 */     Point3D v1 = new Point3D(x, this.yOffset, this.zOffset + this.zLength);
/*  470 */     Point3D v2 = new Point3D(x, this.yOffset + this.yLength, this.zOffset + this.zLength);
/*  471 */     Point3D v3 = new Point3D(x, this.yOffset + this.yLength, this.zOffset);
/*  472 */     box.addVertex(v0);
/*  473 */     box.addVertex(v1);
/*  474 */     box.addVertex(v2);
/*  475 */     box.addVertex(v3);
/*  476 */     MarkerData md0 = new MarkerData(m, base, base + 1);
/*  477 */     MarkerData md1 = new MarkerData(m, base + 1, base + 2);
/*  478 */     MarkerData md2 = new MarkerData(m, base + 2, base + 3);
/*  479 */     MarkerData md3 = new MarkerData(m, base + 3, base);
/*  480 */     if (m.getLabelAnchor() != null) {
/*      */       
/*  482 */       Point3D v4 = calcAnchorXY(m.getLabelAnchor(), v0, v3, this.xLength);
/*  483 */       Point3D v5 = calcAnchorXY(m.getLabelAnchor(), v2, v1, this.xLength);
/*  484 */       Point3D v6 = calcAnchorXZ(m.getLabelAnchor(), v1, v0, this.xLength);
/*  485 */       Point3D v7 = calcAnchorXZ(m.getLabelAnchor(), v3, v2, this.xLength);
/*  486 */       box.addVertex(v4);
/*  487 */       box.addVertex(v5);
/*  488 */       box.addVertex(v6);
/*  489 */       box.addVertex(v7);
/*      */       
/*  491 */       md3.setLabelVertexIndex(base + 4);
/*  492 */       md1.setLabelVertexIndex(base + 5);
/*  493 */       md0.setLabelVertexIndex(base + 6);
/*  494 */       md2.setLabelVertexIndex(base + 7);
/*  495 */       result += 4;
/*      */     } 
/*  497 */     this.faceA.addXMarker(md0);
/*  498 */     this.faceD.addXMarker(md1);
/*  499 */     this.faceC.addXMarker(md2);
/*  500 */     this.faceB.addXMarker(md3);
/*  501 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int addXRangeMarker(Object3D box, MarkerData m, double startX, double endX, int base) {
/*  518 */     int result = 8;
/*  519 */     Point3D v0 = new Point3D(startX, this.yOffset, this.zOffset);
/*  520 */     Point3D v1 = new Point3D(startX, this.yOffset, this.zOffset + this.zLength);
/*  521 */     Point3D v2 = new Point3D(startX, this.yOffset + this.yLength, this.zOffset + this.zLength);
/*  522 */     Point3D v3 = new Point3D(startX, this.yOffset + this.yLength, this.zOffset);
/*  523 */     Point3D v4 = new Point3D(endX, this.yOffset, this.zOffset);
/*  524 */     Point3D v5 = new Point3D(endX, this.yOffset, this.zOffset + this.zLength);
/*  525 */     Point3D v6 = new Point3D(endX, this.yOffset + this.yLength, this.zOffset + this.zLength);
/*  526 */     Point3D v7 = new Point3D(endX, this.yOffset + this.yLength, this.zOffset);
/*  527 */     box.addVertex(v0);
/*  528 */     box.addVertex(v1);
/*  529 */     box.addVertex(v2);
/*  530 */     box.addVertex(v3);
/*  531 */     box.addVertex(v4);
/*  532 */     box.addVertex(v5);
/*  533 */     box.addVertex(v6);
/*  534 */     box.addVertex(v7);
/*  535 */     MarkerData md0 = new MarkerData(m, base, base + 1, base + 4, base + 5);
/*      */     
/*  537 */     MarkerData md1 = new MarkerData(m, base + 1, base + 2, base + 5, base + 6);
/*      */     
/*  539 */     MarkerData md2 = new MarkerData(m, base + 2, base + 3, base + 6, base + 7);
/*      */     
/*  541 */     MarkerData md3 = new MarkerData(m, base + 3, base + 0, base + 7, base + 4);
/*      */     
/*  543 */     if (m.getLabelAnchor() != null) {
/*      */       
/*  545 */       Point3D v8 = calcRangeAnchorXY(m.getLabelAnchor(), v2, v1, v6, v5);
/*  546 */       Point3D v9 = calcRangeAnchorXY(m.getLabelAnchor(), v0, v3, v4, v7);
/*  547 */       Point3D v10 = calcRangeAnchorXZ(m.getLabelAnchor(), v3, v2, v7, v6);
/*  548 */       Point3D v11 = calcRangeAnchorXZ(m.getLabelAnchor(), v1, v0, v5, v4);
/*  549 */       box.addVertex(v8);
/*  550 */       box.addVertex(v9);
/*  551 */       box.addVertex(v10);
/*  552 */       box.addVertex(v11);
/*      */       
/*  554 */       md1.setLabelVertexIndex(base + 8);
/*  555 */       md3.setLabelVertexIndex(base + 9);
/*  556 */       md2.setLabelVertexIndex(base + 10);
/*  557 */       md0.setLabelVertexIndex(base + 11);
/*  558 */       result += 4;
/*      */     } 
/*  560 */     this.faceA.addXMarker(md0);
/*  561 */     this.faceD.addXMarker(md1);
/*  562 */     this.faceC.addXMarker(md2);
/*  563 */     this.faceB.addXMarker(md3);
/*  564 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int addYMarker(Object3D box, MarkerData m, double y, int base) {
/*  579 */     int result = 4;
/*  580 */     Point3D v0 = new Point3D(this.xOffset, y, this.zOffset);
/*  581 */     Point3D v1 = new Point3D(this.xOffset, y, this.zOffset + this.zLength);
/*  582 */     Point3D v2 = new Point3D(this.xOffset + this.xLength, y, this.zOffset + this.zLength);
/*  583 */     Point3D v3 = new Point3D(this.xOffset + this.xLength, y, this.zOffset);
/*  584 */     box.addVertex(v0);
/*  585 */     box.addVertex(v1);
/*  586 */     box.addVertex(v2);
/*  587 */     box.addVertex(v3);
/*  588 */     MarkerData md0 = new MarkerData(m, base, base + 1);
/*  589 */     MarkerData md1 = new MarkerData(m, base + 1, base + 2);
/*  590 */     MarkerData md2 = new MarkerData(m, base + 2, base + 3);
/*  591 */     MarkerData md3 = new MarkerData(m, base + 3, base);
/*  592 */     if (m.getLabelAnchor() != null) {
/*      */       
/*  594 */       Point3D v4 = calcAnchorYX(m.getLabelAnchor(), v1, v2, this.yLength);
/*  595 */       Point3D v5 = calcAnchorYX(m.getLabelAnchor(), v3, v0, this.yLength);
/*  596 */       Point3D v6 = calcAnchorYZ(m.getLabelAnchor(), v0, v1, this.yLength);
/*  597 */       Point3D v7 = calcAnchorYZ(m.getLabelAnchor(), v2, v3, this.yLength);
/*  598 */       box.addVertex(v4);
/*  599 */       box.addVertex(v5);
/*  600 */       box.addVertex(v6);
/*  601 */       box.addVertex(v7);
/*      */       
/*  603 */       md1.setLabelVertexIndex(base + 4);
/*  604 */       md3.setLabelVertexIndex(base + 5);
/*  605 */       md0.setLabelVertexIndex(base + 6);
/*  606 */       md2.setLabelVertexIndex(base + 7);
/*  607 */       result += 4;
/*      */     } 
/*  609 */     this.faceE.addYMarker(md0);
/*  610 */     this.faceD.addYMarker(md1);
/*  611 */     this.faceF.addYMarker(md2);
/*  612 */     this.faceB.addYMarker(md3);
/*  613 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int addYRangeMarker(Object3D box, MarkerData m, double startY, double endY, int base) {
/*  630 */     int result = 8;
/*  631 */     Point3D v0 = new Point3D(this.xOffset, startY, this.zOffset);
/*  632 */     Point3D v1 = new Point3D(this.xOffset, startY, this.zOffset + this.zLength);
/*  633 */     Point3D v2 = new Point3D(this.xOffset + this.xLength, startY, this.zOffset + this.zLength);
/*  634 */     Point3D v3 = new Point3D(this.xOffset + this.xLength, startY, this.zOffset);
/*  635 */     Point3D v4 = new Point3D(this.xOffset, endY, this.zOffset);
/*  636 */     Point3D v5 = new Point3D(this.xOffset, endY, this.zOffset + this.zLength);
/*  637 */     Point3D v6 = new Point3D(this.xOffset + this.xLength, endY, this.zOffset + this.zLength);
/*  638 */     Point3D v7 = new Point3D(this.xOffset + this.xLength, endY, this.zOffset);
/*  639 */     box.addVertex(v0);
/*  640 */     box.addVertex(v1);
/*  641 */     box.addVertex(v2);
/*  642 */     box.addVertex(v3);
/*  643 */     box.addVertex(v4);
/*  644 */     box.addVertex(v5);
/*  645 */     box.addVertex(v6);
/*  646 */     box.addVertex(v7);
/*  647 */     MarkerData md0 = new MarkerData(m, base, base + 1, base + 4, base + 5);
/*      */     
/*  649 */     MarkerData md1 = new MarkerData(m, base + 1, base + 2, base + 5, base + 6);
/*      */     
/*  651 */     MarkerData md2 = new MarkerData(m, base + 2, base + 3, base + 6, base + 7);
/*      */     
/*  653 */     MarkerData md3 = new MarkerData(m, base + 3, base, base + 7, base + 4);
/*      */     
/*  655 */     if (m.getLabelAnchor() != null) {
/*      */       
/*  657 */       Point3D v8 = calcRangeAnchorYX(m.getLabelAnchor(), v1, v2, v5, v6);
/*  658 */       Point3D v9 = calcRangeAnchorYX(m.getLabelAnchor(), v3, v0, v7, v4);
/*  659 */       Point3D v10 = calcRangeAnchorYZ(m.getLabelAnchor(), v2, v3, v6, v7);
/*  660 */       Point3D v11 = calcRangeAnchorYZ(m.getLabelAnchor(), v0, v1, v4, v5);
/*  661 */       box.addVertex(v8);
/*  662 */       box.addVertex(v9);
/*  663 */       box.addVertex(v10);
/*  664 */       box.addVertex(v11);
/*      */       
/*  666 */       md1.setLabelVertexIndex(base + 8);
/*  667 */       md3.setLabelVertexIndex(base + 9);
/*  668 */       md2.setLabelVertexIndex(base + 10);
/*  669 */       md0.setLabelVertexIndex(base + 11);
/*  670 */       result += 4;
/*      */     } 
/*  672 */     this.faceE.addYMarker(md0);
/*  673 */     this.faceD.addYMarker(md1);
/*  674 */     this.faceF.addYMarker(md2);
/*  675 */     this.faceB.addYMarker(md3);
/*  676 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int addZMarker(Object3D box, MarkerData m, double z, int base) {
/*  691 */     int result = 4;
/*  692 */     Point3D v0 = new Point3D(this.xOffset, this.yOffset, z);
/*  693 */     Point3D v1 = new Point3D(this.xOffset + this.xLength, this.yOffset, z);
/*  694 */     Point3D v2 = new Point3D(this.xOffset + this.xLength, this.yOffset + this.yLength, z);
/*  695 */     Point3D v3 = new Point3D(this.xOffset, this.yOffset + this.yLength, z);
/*  696 */     box.addVertex(v0);
/*  697 */     box.addVertex(v1);
/*  698 */     box.addVertex(v2);
/*  699 */     box.addVertex(v3);
/*  700 */     MarkerData md0 = new MarkerData(m, base, base + 1);
/*  701 */     MarkerData md1 = new MarkerData(m, base + 1, base + 2);
/*  702 */     MarkerData md2 = new MarkerData(m, base + 2, base + 3);
/*  703 */     MarkerData md3 = new MarkerData(m, base + 3, base);
/*  704 */     if (m.getLabelAnchor() != null) {
/*      */       
/*  706 */       Point3D v4 = calcAnchorZX(m.getLabelAnchor(), v0, v1, this.zLength);
/*  707 */       Point3D v5 = calcAnchorZX(m.getLabelAnchor(), v2, v3, this.zLength);
/*  708 */       Point3D v6 = calcAnchorZY(m.getLabelAnchor(), v1, v2, this.zLength);
/*  709 */       Point3D v7 = calcAnchorZY(m.getLabelAnchor(), v3, v0, this.zLength);
/*  710 */       box.addVertex(v4);
/*  711 */       box.addVertex(v5);
/*  712 */       box.addVertex(v6);
/*  713 */       box.addVertex(v7);
/*      */       
/*  715 */       md0.setLabelVertexIndex(base + 4);
/*  716 */       md2.setLabelVertexIndex(base + 5);
/*  717 */       md1.setLabelVertexIndex(base + 6);
/*  718 */       md3.setLabelVertexIndex(base + 7);
/*  719 */       result += 4;
/*      */     } 
/*  721 */     this.faceA.addZMarker(md0);
/*  722 */     this.faceF.addZMarker(md1);
/*  723 */     this.faceC.addZMarker(md2);
/*  724 */     this.faceE.addZMarker(md3);
/*  725 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int addZRangeMarker(Object3D box, MarkerData m, double startZ, double endZ, int base) {
/*  742 */     int result = 8;
/*  743 */     Point3D v0 = new Point3D(this.xOffset, this.yOffset, startZ);
/*  744 */     Point3D v1 = new Point3D(this.xOffset + this.xLength, this.yOffset, startZ);
/*  745 */     Point3D v2 = new Point3D(this.xOffset + this.xLength, this.yOffset + this.yLength, startZ);
/*  746 */     Point3D v3 = new Point3D(this.xOffset, this.yOffset + this.yLength, startZ);
/*  747 */     Point3D v4 = new Point3D(this.xOffset, this.yOffset, endZ);
/*  748 */     Point3D v5 = new Point3D(this.xOffset + this.xLength, this.yOffset, endZ);
/*  749 */     Point3D v6 = new Point3D(this.xOffset + this.xLength, this.yOffset + this.yLength, endZ);
/*  750 */     Point3D v7 = new Point3D(this.xOffset, this.yOffset + this.yLength, endZ);
/*  751 */     box.addVertex(v0);
/*  752 */     box.addVertex(v1);
/*  753 */     box.addVertex(v2);
/*  754 */     box.addVertex(v3);
/*  755 */     box.addVertex(v4);
/*  756 */     box.addVertex(v5);
/*  757 */     box.addVertex(v6);
/*  758 */     box.addVertex(v7);
/*  759 */     MarkerData md0 = new MarkerData(m, base, base + 1, base + 4, base + 5);
/*      */     
/*  761 */     MarkerData md1 = new MarkerData(m, base + 1, base + 2, base + 5, base + 6);
/*      */     
/*  763 */     MarkerData md2 = new MarkerData(m, base + 2, base + 3, base + 6, base + 7);
/*      */     
/*  765 */     MarkerData md3 = new MarkerData(m, base + 3, base, base + 7, base + 4);
/*      */     
/*  767 */     if (m.getLabelAnchor() != null) {
/*      */       
/*  769 */       Point3D v8 = calcRangeAnchorZX(m.getLabelAnchor(), v0, v1, v4, v5);
/*  770 */       Point3D v9 = calcRangeAnchorZX(m.getLabelAnchor(), v2, v3, v6, v7);
/*  771 */       Point3D v10 = calcRangeAnchorZY(m.getLabelAnchor(), v3, v0, v7, v4);
/*  772 */       Point3D v11 = calcRangeAnchorZY(m.getLabelAnchor(), v1, v2, v5, v6);
/*  773 */       box.addVertex(v8);
/*  774 */       box.addVertex(v9);
/*  775 */       box.addVertex(v10);
/*  776 */       box.addVertex(v11);
/*      */       
/*  778 */       md0.setLabelVertexIndex(base + 8);
/*  779 */       md2.setLabelVertexIndex(base + 9);
/*  780 */       md3.setLabelVertexIndex(base + 10);
/*  781 */       md1.setLabelVertexIndex(base + 11);
/*  782 */       result += 4;
/*      */     } 
/*  784 */     this.faceA.addZMarker(md0);
/*  785 */     this.faceF.addZMarker(md1);
/*  786 */     this.faceC.addZMarker(md2);
/*  787 */     this.faceE.addZMarker(md3);
/*  788 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private double hoffset(Anchor2D anchor, double length) {
/*  802 */     double offset = 0.0D;
/*  803 */     if (anchor.getRefPt().isLeft()) {
/*  804 */       offset = length * anchor.getOffset().getDX();
/*  805 */     } else if (anchor.getRefPt().isRight()) {
/*  806 */       offset = -length * anchor.getOffset().getDX();
/*      */     } 
/*  808 */     return offset;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private double voffset(Anchor2D anchor, double length) {
/*  822 */     double offset = 0.0D;
/*  823 */     if (anchor.getRefPt().isTop()) {
/*  824 */       offset = length * anchor.getOffset().getDY();
/*  825 */     } else if (anchor.getRefPt().isBottom()) {
/*  826 */       offset = -length * anchor.getOffset().getDY();
/*      */     } 
/*  828 */     return offset;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private double hpos(Anchor2D anchor, double start, double end) {
/*  842 */     if (anchor.getRefPt().isLeft())
/*  843 */       return start; 
/*  844 */     if (anchor.getRefPt().isRight()) {
/*  845 */       return end;
/*      */     }
/*  847 */     return (start + end) / 2.0D;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private Point3D calcAnchorXY(Anchor2D anchor, Point3D start, Point3D end, double xLength) {
/*  853 */     double dx = hoffset(anchor, end.getY() - start.getY());
/*  854 */     double dy = voffset(anchor, xLength);
/*  855 */     double y = hpos(anchor, start.getY(), end.getY());
/*  856 */     return new Point3D(start.getX() + dy, y + dx, start.getZ());
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private Point3D calcAnchorXZ(Anchor2D anchor, Point3D start, Point3D end, double xLength) {
/*  862 */     double dx = hoffset(anchor, end.getZ() - start.getZ());
/*  863 */     double dy = voffset(anchor, xLength);
/*  864 */     double z = hpos(anchor, start.getZ(), end.getZ());
/*  865 */     return new Point3D(start.getX() + dy, start.getY(), z + dx);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private Point3D calcAnchorYX(Anchor2D anchor, Point3D start, Point3D end, double yLength) {
/*  871 */     double dx = hoffset(anchor, end.getX() - start.getX());
/*  872 */     double dy = voffset(anchor, yLength);
/*  873 */     double x = hpos(anchor, start.getX(), end.getX());
/*  874 */     return new Point3D(x + dx, start.getY() + dy, start.getZ());
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private Point3D calcAnchorYZ(Anchor2D anchor, Point3D start, Point3D end, double yLength) {
/*  880 */     double dx = hoffset(anchor, end.getZ() - start.getZ());
/*  881 */     double dy = voffset(anchor, yLength);
/*  882 */     double z = hpos(anchor, start.getZ(), end.getZ());
/*  883 */     return new Point3D(start.getX(), start.getY() + dy, z + dx);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private Point3D calcAnchorZX(Anchor2D anchor, Point3D start, Point3D end, double zLength) {
/*  889 */     double dx = hoffset(anchor, end.getX() - start.getX());
/*  890 */     double dy = voffset(anchor, zLength);
/*  891 */     double x = hpos(anchor, start.getX(), end.getX());
/*  892 */     return new Point3D(x + dx, start.getY(), start.getZ() + dy);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private Point3D calcAnchorZY(Anchor2D anchor, Point3D start, Point3D end, double zLength) {
/*  898 */     double dx = hoffset(anchor, end.getY() - start.getY());
/*  899 */     double dy = voffset(anchor, zLength);
/*  900 */     double y = hpos(anchor, start.getY(), end.getY());
/*  901 */     return new Point3D(start.getX(), y + dx, start.getZ() + dy);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private Point3D calcRangeAnchorXY(Anchor2D anchor, Point3D start1, Point3D end1, Point3D start2, Point3D end2) {
/*  907 */     Point2D p = anchor.resolveAnchorWithPercentOffset(start1.getY(), start1
/*  908 */         .getX(), end2.getY(), end2.getX());
/*  909 */     return new Point3D(p.getY(), p.getX(), end1.getZ());
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private Point3D calcRangeAnchorXZ(Anchor2D anchor, Point3D start1, Point3D end1, Point3D start2, Point3D end2) {
/*  915 */     Point2D p = anchor.resolveAnchorWithPercentOffset(start1.getZ(), start1
/*  916 */         .getX(), end2.getZ(), end2.getX());
/*  917 */     return new Point3D(p.getY(), end1.getY(), p.getX());
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private Point3D calcRangeAnchorYX(Anchor2D anchor, Point3D start1, Point3D end1, Point3D start2, Point3D end2) {
/*  923 */     Point2D p = anchor.resolveAnchorWithPercentOffset(start1.getX(), start1
/*  924 */         .getY(), end2.getX(), end2.getY());
/*  925 */     return new Point3D(p.getX(), p.getY(), end1.getZ());
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private Point3D calcRangeAnchorYZ(Anchor2D anchor, Point3D start1, Point3D end1, Point3D start2, Point3D end2) {
/*  931 */     Point2D p = anchor.resolveAnchorWithPercentOffset(start1.getZ(), start1
/*  932 */         .getY(), end2.getZ(), end2.getY());
/*  933 */     return new Point3D(start1.getX(), p.getY(), p.getX());
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private Point3D calcRangeAnchorZX(Anchor2D anchor, Point3D start1, Point3D end1, Point3D start2, Point3D end2) {
/*  939 */     Point2D p = anchor.resolveAnchorWithPercentOffset(start1.getX(), start1
/*  940 */         .getZ(), end2.getX(), end2.getZ());
/*  941 */     return new Point3D(p.getX(), end1.getY(), p.getY());
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private Point3D calcRangeAnchorZY(Anchor2D anchor, Point3D start1, Point3D end1, Point3D start2, Point3D end2) {
/*  947 */     Point2D p = anchor.resolveAnchorWithPercentOffset(start1.getY(), start1
/*  948 */         .getZ(), end2.getY(), end2.getZ());
/*  949 */     return new Point3D(end1.getX(), p.getX(), p.getY());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final class ChartBoxFace
/*      */     extends Face
/*      */   {
/*      */     private List<TickData> xTicksA;
/*      */ 
/*      */ 
/*      */     
/*      */     private List<TickData> xTicksB;
/*      */ 
/*      */ 
/*      */     
/*      */     private List<TickData> yTicksA;
/*      */ 
/*      */ 
/*      */     
/*      */     private List<TickData> yTicksB;
/*      */ 
/*      */ 
/*      */     
/*      */     private List<TickData> zTicksA;
/*      */ 
/*      */ 
/*      */     
/*      */     private List<TickData> zTicksB;
/*      */ 
/*      */ 
/*      */     
/*      */     private List<MarkerData> xMarkers;
/*      */ 
/*      */ 
/*      */     
/*      */     private List<MarkerData> yMarkers;
/*      */ 
/*      */     
/*      */     private List<MarkerData> zMarkers;
/*      */ 
/*      */ 
/*      */     
/*      */     public ChartBoxFace(Object3D owner, int[] vertices) {
/*  994 */       super(owner, vertices);
/*  995 */       this.xTicksA = new ArrayList<TickData>();
/*  996 */       this.xTicksB = new ArrayList<TickData>();
/*  997 */       this.yTicksA = new ArrayList<TickData>();
/*  998 */       this.yTicksB = new ArrayList<TickData>();
/*  999 */       this.zTicksA = new ArrayList<TickData>();
/* 1000 */       this.zTicksB = new ArrayList<TickData>();
/* 1001 */       this.xMarkers = new ArrayList<MarkerData>();
/* 1002 */       this.yMarkers = new ArrayList<MarkerData>();
/* 1003 */       this.zMarkers = new ArrayList<MarkerData>();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void clearXTicks() {
/* 1010 */       this.xTicksA.clear();
/* 1011 */       this.xTicksB.clear();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public List<TickData> getXTicksA() {
/* 1020 */       return this.xTicksA;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void addXTicks(TickData a, TickData b) {
/* 1030 */       this.xTicksA.add(a);
/* 1031 */       this.xTicksB.add(b);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public List<TickData> getXTicksB() {
/* 1040 */       return this.xTicksB;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void addYTicks(TickData a, TickData b) {
/* 1050 */       this.yTicksA.add(a);
/* 1051 */       this.yTicksB.add(b);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public List<TickData> getYTicksA() {
/* 1060 */       return this.yTicksA;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public List<TickData> getYTicksB() {
/* 1069 */       return this.yTicksB;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void addZTicks(TickData a, TickData b) {
/* 1079 */       this.zTicksA.add(a);
/* 1080 */       this.zTicksB.add(b);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public List<TickData> getZTicksA() {
/* 1089 */       return this.zTicksA;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public List<TickData> getZTicksB() {
/* 1098 */       return this.zTicksB;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void addXMarker(MarkerData marker) {
/* 1107 */       ArgChecks.nullNotPermitted(marker, "marker");
/* 1108 */       this.xMarkers.add(marker);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public List<MarkerData> getXMarkers() {
/* 1118 */       return Collections.unmodifiableList(this.xMarkers);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void addYMarker(MarkerData marker) {
/* 1127 */       ArgChecks.nullNotPermitted(marker, "marker");
/* 1128 */       this.yMarkers.add(marker);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public List<MarkerData> getYMarkers() {
/* 1138 */       return Collections.unmodifiableList(this.yMarkers);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void addZMarker(MarkerData marker) {
/* 1147 */       ArgChecks.nullNotPermitted(marker, "marker");
/* 1148 */       this.zMarkers.add(marker);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public List<MarkerData> getZMarkers() {
/* 1158 */       return Collections.unmodifiableList(this.zMarkers);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public float calculateAverageZValue(Point3D[] points) {
/* 1171 */       return -123456.0F;
/*      */     }
/*      */   }
/*      */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/ChartBox3D.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */