/*    */ package com.orsoncharts.util;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ExportFormats
/*    */ {
/*    */   public static boolean isJFreeSVGAvailable() {
/* 32 */     Class<?> svgClass = null;
/*    */     try {
/* 34 */       svgClass = Class.forName("org.jfree.graphics2d.svg.SVGGraphics2D");
/* 35 */     } catch (ClassNotFoundException e) {}
/*    */ 
/*    */     
/* 38 */     return (svgClass != null);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static boolean isOrsonPDFAvailable() {
/* 49 */     Class<?> pdfDocumentClass = null;
/*    */     try {
/* 51 */       pdfDocumentClass = Class.forName("com.orsonpdf.PDFDocument");
/* 52 */     } catch (ClassNotFoundException e) {}
/*    */ 
/*    */     
/* 55 */     return (pdfDocumentClass != null);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/util/ExportFormats.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */