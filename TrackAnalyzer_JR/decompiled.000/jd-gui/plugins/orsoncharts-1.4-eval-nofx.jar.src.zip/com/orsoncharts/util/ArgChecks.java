/*     */ package com.orsoncharts.util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ArgChecks
/*     */ {
/*     */   public static void nullNotPermitted(Object arg, String name) {
/*  35 */     if (arg == null) {
/*  36 */       throw new IllegalArgumentException("Null '" + name + "' argument.");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void negativeNotPermitted(double value, String name) {
/*  48 */     if (value < 0.0D) {
/*  49 */       throw new IllegalArgumentException("Param '" + name + "' cannot be negative");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void positiveRequired(double value, String name) {
/*  62 */     if (value <= 0.0D) {
/*  63 */       throw new IllegalArgumentException("Param '" + name + "' must be positive.");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void finiteRequired(double value, String name) {
/*  78 */     if (Double.isInfinite(value)) {
/*  79 */       throw new IllegalArgumentException("Param '" + name + "' must be finite.");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void finitePositiveRequired(double value, String name) {
/*  94 */     if (value <= 0.0D || Double.isInfinite(value)) {
/*  95 */       throw new IllegalArgumentException("Param '" + name + "' must be finite and positive.");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void checkArrayBounds(int index, String name, int arrayLimit) {
/* 110 */     if (index >= arrayLimit)
/* 111 */       throw new IllegalArgumentException("Requires '" + name + "' in the range 0 to " + (arrayLimit - 1)); 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/util/ArgChecks.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */