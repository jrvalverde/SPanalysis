/*    */ package com.orsoncharts.util;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum Scale2D
/*    */ {
/* 21 */   NONE,
/*    */ 
/*    */   
/* 24 */   SCALE_HORIZONTAL,
/*    */ 
/*    */   
/* 27 */   SCALE_VERTICAL,
/*    */ 
/*    */   
/* 30 */   SCALE_BOTH;
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/util/Scale2D.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */