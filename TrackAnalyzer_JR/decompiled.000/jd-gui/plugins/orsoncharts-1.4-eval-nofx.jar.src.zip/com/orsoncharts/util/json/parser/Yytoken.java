/*    */ package com.orsoncharts.util.json.parser;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Yytoken
/*    */ {
/*    */   public static final int TYPE_VALUE = 0;
/*    */   public static final int TYPE_LEFT_BRACE = 1;
/*    */   public static final int TYPE_RIGHT_BRACE = 2;
/*    */   public static final int TYPE_LEFT_SQUARE = 3;
/*    */   public static final int TYPE_RIGHT_SQUARE = 4;
/*    */   public static final int TYPE_COMMA = 5;
/*    */   public static final int TYPE_COLON = 6;
/*    */   public static final int TYPE_EOF = -1;
/* 39 */   public int type = 0;
/* 40 */   public Object value = null;
/*    */   
/*    */   public Yytoken(int type, Object value) {
/* 43 */     this.type = type;
/* 44 */     this.value = value;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 49 */     StringBuilder sb = new StringBuilder();
/* 50 */     switch (this.type) {
/*    */       case 0:
/* 52 */         sb.append("VALUE(").append(this.value).append(")");
/*    */         break;
/*    */       case 1:
/* 55 */         sb.append("LEFT BRACE({)");
/*    */         break;
/*    */       case 2:
/* 58 */         sb.append("RIGHT BRACE(})");
/*    */         break;
/*    */       case 3:
/* 61 */         sb.append("LEFT SQUARE([)");
/*    */         break;
/*    */       case 4:
/* 64 */         sb.append("RIGHT SQUARE(])");
/*    */         break;
/*    */       case 5:
/* 67 */         sb.append("COMMA(,)");
/*    */         break;
/*    */       case 6:
/* 70 */         sb.append("COLON(:)");
/*    */         break;
/*    */       case -1:
/* 73 */         sb.append("END OF FILE");
/*    */         break;
/*    */     } 
/* 76 */     return sb.toString();
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/util/json/parser/Yytoken.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */