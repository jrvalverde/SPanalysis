/*     */ package com.orsoncharts.util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public enum RefPt2D
/*     */ {
/*  24 */   TOP_LEFT,
/*     */ 
/*     */   
/*  27 */   TOP_CENTER,
/*     */ 
/*     */   
/*  30 */   TOP_RIGHT,
/*     */ 
/*     */   
/*  33 */   CENTER_LEFT,
/*     */ 
/*     */   
/*  36 */   CENTER,
/*     */ 
/*     */   
/*  39 */   CENTER_RIGHT,
/*     */ 
/*     */   
/*  42 */   BOTTOM_LEFT,
/*     */ 
/*     */   
/*  45 */   BOTTOM_CENTER,
/*     */ 
/*     */   
/*  48 */   BOTTOM_RIGHT;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isLeft() {
/*  57 */     return (this == TOP_LEFT || this == CENTER_LEFT || this == BOTTOM_LEFT);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isRight() {
/*  67 */     return (this == TOP_RIGHT || this == CENTER_RIGHT || this == BOTTOM_RIGHT);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isHorizontalCenter() {
/*  78 */     return (this == TOP_CENTER || this == CENTER || this == BOTTOM_CENTER);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isTop() {
/*  89 */     return (this == TOP_LEFT || this == TOP_CENTER || this == TOP_RIGHT);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isBottom() {
/*  99 */     return (this == BOTTOM_LEFT || this == BOTTOM_CENTER || this == BOTTOM_RIGHT);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isVerticalCenter() {
/* 110 */     return (this == CENTER_LEFT || this == CENTER || this == CENTER_RIGHT);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/util/RefPt2D.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */