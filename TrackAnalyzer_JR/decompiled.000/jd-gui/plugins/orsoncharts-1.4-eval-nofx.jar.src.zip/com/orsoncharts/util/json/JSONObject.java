/*     */ package com.orsoncharts.util.json;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Writer;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JSONObject
/*     */   extends HashMap
/*     */   implements Map, JSONAware, JSONStreamAware
/*     */ {
/*     */   private static final long serialVersionUID = -503443796854799292L;
/*     */   
/*     */   public static void writeJSONString(Map map, Writer out) throws IOException {
/*  54 */     if (map == null) {
/*  55 */       out.write("null");
/*     */       return;
/*     */     } 
/*  58 */     boolean first = true;
/*  59 */     Iterator<Map.Entry> iter = map.entrySet().iterator();
/*  60 */     out.write(123);
/*  61 */     while (iter.hasNext()) {
/*  62 */       if (first) {
/*  63 */         first = false;
/*     */       } else {
/*     */         
/*  66 */         out.write(44);
/*     */       } 
/*  68 */       Map.Entry entry = iter.next();
/*  69 */       out.write(34);
/*  70 */       out.write(JSONValue.escape(String.valueOf(entry.getKey())));
/*  71 */       out.write(34);
/*  72 */       out.write(58);
/*  73 */       JSONValue.writeJSONString(entry.getValue(), out);
/*     */     } 
/*  75 */     out.write(125);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeJSONString(Writer out) throws IOException {
/*  88 */     writeJSONString(this, out);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String toJSONString(Map map) {
/* 103 */     if (map == null) {
/* 104 */       return "null";
/*     */     }
/*     */     
/* 107 */     StringBuffer sb = new StringBuffer();
/* 108 */     boolean first = true;
/* 109 */     Iterator<Map.Entry> iter = map.entrySet().iterator();
/*     */     
/* 111 */     sb.append('{');
/* 112 */     while (iter.hasNext()) {
/* 113 */       if (first) {
/* 114 */         first = false;
/*     */       } else {
/*     */         
/* 117 */         sb.append(',');
/*     */       } 
/*     */       
/* 120 */       Map.Entry entry = iter.next();
/* 121 */       toJSONString(String.valueOf(entry.getKey()), entry.getValue(), sb);
/*     */     } 
/* 123 */     sb.append('}');
/* 124 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toJSONString() {
/* 134 */     return toJSONString(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String toJSONString(String key, Object value, StringBuffer sb) {
/* 148 */     sb.append('"');
/* 149 */     if (key == null) {
/* 150 */       sb.append("null");
/*     */     } else {
/*     */       
/* 153 */       JSONValue.escape(key, sb);
/*     */     } 
/* 155 */     sb.append('"').append(':');
/*     */     
/* 157 */     sb.append(JSONValue.toJSONString(value));
/*     */     
/* 159 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 169 */     return toJSONString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String toString(String key, Object value) {
/* 181 */     StringBuffer sb = new StringBuffer();
/* 182 */     toJSONString(key, value, sb);
/* 183 */     return sb.toString();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/util/json/JSONObject.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */