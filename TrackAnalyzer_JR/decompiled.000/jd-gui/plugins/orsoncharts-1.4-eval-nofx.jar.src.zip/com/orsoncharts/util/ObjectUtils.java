/*    */ package com.orsoncharts.util;
/*    */ 
/*    */ import java.awt.GradientPaint;
/*    */ import java.awt.Paint;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ObjectUtils
/*    */ {
/*    */   public static boolean equals(Object obj1, Object obj2) {
/* 33 */     if (obj1 != null) {
/* 34 */       return obj1.equals(obj2);
/*    */     }
/* 36 */     return (obj2 == null);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static int hashCode(Object obj) {
/* 52 */     return (obj != null) ? obj.hashCode() : 0;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static boolean equalsPaint(Paint p1, Paint p2) {
/* 68 */     if (p1 == null) {
/* 69 */       return (p2 == null);
/*    */     }
/* 71 */     if (p2 == null) {
/* 72 */       return false;
/*    */     }
/*    */ 
/*    */     
/* 76 */     if (p1 instanceof GradientPaint && p2 instanceof GradientPaint) {
/* 77 */       GradientPaint gp1 = (GradientPaint)p1;
/* 78 */       GradientPaint gp2 = (GradientPaint)p2;
/* 79 */       return (gp1.getColor1().equals(gp2.getColor1()) && gp1
/* 80 */         .getColor2().equals(gp2.getColor2()) && gp1
/* 81 */         .getPoint1().equals(gp2.getPoint1()) && gp1
/* 82 */         .getPoint2().equals(gp2.getPoint2()) && gp1
/* 83 */         .isCyclic() == gp2.isCyclic() && gp1
/* 84 */         .getTransparency() == gp1.getTransparency());
/*    */     } 
/* 86 */     return p1.equals(p2);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/util/ObjectUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */