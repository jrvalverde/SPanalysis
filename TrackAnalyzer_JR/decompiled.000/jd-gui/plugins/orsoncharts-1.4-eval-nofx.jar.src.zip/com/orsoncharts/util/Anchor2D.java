/*     */ package com.orsoncharts.util;
/*     */ 
/*     */ import com.orsoncharts.graphics3d.Offset2D;
/*     */ import java.awt.geom.Point2D;
/*     */ import java.awt.geom.Rectangle2D;
/*     */ import java.io.Serializable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Anchor2D
/*     */   implements Serializable
/*     */ {
/*  45 */   public static final Anchor2D TOP_LEFT = new Anchor2D(RefPt2D.TOP_LEFT, Offset2D.ZERO_OFFSET);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  54 */   public static final Anchor2D TOP_CENTER = new Anchor2D(RefPt2D.TOP_CENTER, Offset2D.ZERO_OFFSET);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  63 */   public static final Anchor2D TOP_RIGHT = new Anchor2D(RefPt2D.TOP_RIGHT, Offset2D.ZERO_OFFSET);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  72 */   public static final Anchor2D CENTER_LEFT = new Anchor2D(RefPt2D.CENTER_LEFT, Offset2D.ZERO_OFFSET);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  80 */   public static final Anchor2D CENTER = new Anchor2D(RefPt2D.CENTER, Offset2D.ZERO_OFFSET);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  89 */   public static final Anchor2D CENTER_RIGHT = new Anchor2D(RefPt2D.CENTER_RIGHT, Offset2D.ZERO_OFFSET);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  98 */   public static final Anchor2D BOTTOM_LEFT = new Anchor2D(RefPt2D.BOTTOM_LEFT, Offset2D.ZERO_OFFSET);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 107 */   public static final Anchor2D BOTTOM_CENTER = new Anchor2D(RefPt2D.BOTTOM_CENTER, Offset2D.ZERO_OFFSET);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 116 */   public static final Anchor2D BOTTOM_RIGHT = new Anchor2D(RefPt2D.BOTTOM_RIGHT, Offset2D.ZERO_OFFSET);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private RefPt2D refPt;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Offset2D offset;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Anchor2D() {
/* 134 */     this(RefPt2D.TOP_LEFT);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Anchor2D(RefPt2D refPt) {
/* 144 */     this(refPt, new Offset2D(4.0D, 4.0D));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Anchor2D(RefPt2D refPt, Offset2D offset) {
/* 154 */     ArgChecks.nullNotPermitted(refPt, "refPt");
/* 155 */     ArgChecks.nullNotPermitted(offset, "offset");
/* 156 */     this.refPt = refPt;
/* 157 */     this.offset = offset;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RefPt2D getRefPt() {
/* 166 */     return this.refPt;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Offset2D getOffset() {
/* 175 */     return this.offset;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Point2D getAnchorPoint(Rectangle2D rect) {
/* 186 */     ArgChecks.nullNotPermitted(rect, "rect");
/* 187 */     double x = 0.0D;
/* 188 */     double y = 0.0D;
/* 189 */     if (this.refPt.isLeft()) {
/* 190 */       x = rect.getX() + this.offset.getDX();
/* 191 */     } else if (this.refPt.isHorizontalCenter()) {
/* 192 */       x = rect.getCenterX();
/* 193 */     } else if (this.refPt.isRight()) {
/* 194 */       x = rect.getMaxX() - this.offset.getDX();
/*     */     } 
/* 196 */     if (this.refPt.isTop()) {
/* 197 */       y = rect.getMinY() + this.offset.getDY();
/* 198 */     } else if (this.refPt.isVerticalCenter()) {
/* 199 */       y = rect.getCenterY();
/* 200 */     } else if (this.refPt.isBottom()) {
/* 201 */       y = rect.getMaxY() - this.offset.getDY();
/*     */     } 
/* 203 */     return new Point2D.Double(x, y);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Point2D resolveAnchorWithPercentOffset(double startX, double startY, double endX, double endY) {
/* 225 */     double x = 0.0D;
/* 226 */     double y = 0.0D;
/* 227 */     if (this.refPt.isLeft()) {
/* 228 */       x = startX + this.offset.getDX() * (endX - startX);
/* 229 */     } else if (this.refPt.isHorizontalCenter()) {
/* 230 */       x = (startX + endX) / 2.0D;
/* 231 */     } else if (this.refPt.isRight()) {
/* 232 */       x = endX - this.offset.getDX() * (endX - startX);
/*     */     } 
/* 234 */     if (this.refPt.isTop()) {
/* 235 */       y = endY - this.offset.getDY() * (endY - startY);
/* 236 */     } else if (this.refPt.isVerticalCenter()) {
/* 237 */       y = (startY + endY) / 2.0D;
/* 238 */     } else if (this.refPt.isBottom()) {
/* 239 */       y = startY + this.offset.getDY() * (endY - startY);
/*     */     } 
/* 241 */     return new Point2D.Double(x, y);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 253 */     if (obj == this) {
/* 254 */       return true;
/*     */     }
/* 256 */     if (!(obj instanceof Anchor2D)) {
/* 257 */       return false;
/*     */     }
/* 259 */     Anchor2D that = (Anchor2D)obj;
/* 260 */     if (!this.refPt.equals(that.refPt)) {
/* 261 */       return false;
/*     */     }
/* 263 */     if (!this.offset.equals(that.offset)) {
/* 264 */       return false;
/*     */     }
/* 266 */     return true;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/util/Anchor2D.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */