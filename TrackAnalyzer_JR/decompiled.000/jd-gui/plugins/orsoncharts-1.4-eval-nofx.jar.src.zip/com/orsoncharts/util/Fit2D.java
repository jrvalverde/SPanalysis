/*     */ package com.orsoncharts.util;
/*     */ 
/*     */ import java.awt.geom.Dimension2D;
/*     */ import java.awt.geom.Point2D;
/*     */ import java.awt.geom.Rectangle2D;
/*     */ import java.io.Serializable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Fit2D
/*     */   implements Serializable
/*     */ {
/*  42 */   public static final Fit2D CENTER_NO_SCALING = new Fit2D(Anchor2D.CENTER, Scale2D.NONE);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  51 */   public static final Fit2D TOP_LEFT_NO_SCALING = new Fit2D(Anchor2D.TOP_LEFT, Scale2D.NONE);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  60 */   public static final Fit2D TOP_CENTER_NO_SCALING = new Fit2D(Anchor2D.TOP_CENTER, Scale2D.NONE);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  69 */   public static final Fit2D TOP_RIGHT_NO_SCALING = new Fit2D(Anchor2D.TOP_RIGHT, Scale2D.NONE);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  78 */   public static final Fit2D CENTER_LEFT_NO_SCALING = new Fit2D(Anchor2D.CENTER_LEFT, Scale2D.NONE);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  87 */   public static final Fit2D CENTER_RIGHT_NO_SCALING = new Fit2D(Anchor2D.CENTER_RIGHT, Scale2D.NONE);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  96 */   public static final Fit2D BOTTOM_LEFT_NO_SCALING = new Fit2D(Anchor2D.BOTTOM_LEFT, Scale2D.NONE);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 105 */   public static final Fit2D BOTTOM_CENTER_NO_SCALING = new Fit2D(Anchor2D.BOTTOM_CENTER, Scale2D.NONE);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 114 */   public static final Fit2D BOTTOM_RIGHT_NO_SCALING = new Fit2D(Anchor2D.BOTTOM_RIGHT, Scale2D.NONE);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Fit2D getNoScalingFitter(RefPt2D refPt) {
/* 127 */     switch (refPt) { case TOP_LEFT:
/* 128 */         return TOP_LEFT_NO_SCALING;
/* 129 */       case TOP_CENTER: return TOP_CENTER_NO_SCALING;
/* 130 */       case TOP_RIGHT: return TOP_RIGHT_NO_SCALING;
/* 131 */       case CENTER_LEFT: return CENTER_LEFT_NO_SCALING;
/* 132 */       case CENTER: return CENTER_NO_SCALING;
/* 133 */       case CENTER_RIGHT: return CENTER_RIGHT_NO_SCALING;
/* 134 */       case BOTTOM_LEFT: return BOTTOM_LEFT_NO_SCALING;
/* 135 */       case BOTTOM_CENTER: return BOTTOM_CENTER_NO_SCALING;
/* 136 */       case BOTTOM_RIGHT: return BOTTOM_RIGHT_NO_SCALING; }
/*     */     
/* 138 */     throw new IllegalStateException("RefPt2D not recognised : " + refPt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 146 */   public static final Fit2D SCALE_TO_FIT_TARGET = new Fit2D(Anchor2D.CENTER, Scale2D.SCALE_BOTH);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Anchor2D anchor;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Scale2D scale;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Fit2D(Anchor2D anchor, Scale2D scale) {
/* 162 */     ArgChecks.nullNotPermitted(anchor, "anchor");
/* 163 */     ArgChecks.nullNotPermitted(scale, "scale");
/* 164 */     this.anchor = anchor;
/* 165 */     this.scale = scale;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Anchor2D getAnchor() {
/* 176 */     return this.anchor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Scale2D getScale() {
/* 187 */     return this.scale;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Rectangle2D fit(Dimension2D srcDim, Rectangle2D target) {
/* 201 */     Rectangle2D result = new Rectangle2D.Double();
/* 202 */     if (this.scale == Scale2D.SCALE_BOTH) {
/* 203 */       result.setFrame(target);
/* 204 */       return result;
/*     */     } 
/* 206 */     double width = srcDim.getWidth();
/* 207 */     if (this.scale == Scale2D.SCALE_HORIZONTAL) {
/* 208 */       width = target.getWidth();
/* 209 */       if (!this.anchor.getRefPt().isHorizontalCenter()) {
/* 210 */         width -= 2.0D * this.anchor.getOffset().getDX();
/*     */       }
/*     */     } 
/* 213 */     double height = srcDim.getHeight();
/* 214 */     if (this.scale == Scale2D.SCALE_VERTICAL) {
/* 215 */       height = target.getHeight();
/* 216 */       if (!this.anchor.getRefPt().isVerticalCenter()) {
/* 217 */         height -= 2.0D * this.anchor.getOffset().getDY();
/*     */       }
/*     */     } 
/* 220 */     Point2D pt = this.anchor.getAnchorPoint(target);
/* 221 */     double x = Double.NaN;
/* 222 */     if (this.anchor.getRefPt().isLeft()) {
/* 223 */       x = pt.getX();
/* 224 */     } else if (this.anchor.getRefPt().isHorizontalCenter()) {
/* 225 */       x = target.getCenterX() - width / 2.0D;
/* 226 */     } else if (this.anchor.getRefPt().isRight()) {
/* 227 */       x = pt.getX() - width;
/*     */     } 
/* 229 */     double y = Double.NaN;
/* 230 */     if (this.anchor.getRefPt().isTop()) {
/* 231 */       y = pt.getY();
/* 232 */     } else if (this.anchor.getRefPt().isVerticalCenter()) {
/* 233 */       y = target.getCenterY() - height / 2.0D;
/* 234 */     } else if (this.anchor.getRefPt().isBottom()) {
/* 235 */       y = pt.getY() - height;
/*     */     } 
/* 237 */     result.setRect(x, y, width, height);
/* 238 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 250 */     if (obj == this) {
/* 251 */       return true;
/*     */     }
/* 253 */     if (!(obj instanceof Fit2D)) {
/* 254 */       return false;
/*     */     }
/* 256 */     Fit2D that = (Fit2D)obj;
/* 257 */     if (!this.anchor.equals(that.anchor)) {
/* 258 */       return false;
/*     */     }
/* 260 */     if (!this.scale.equals(that.scale)) {
/* 261 */       return false;
/*     */     }
/* 263 */     return true;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/util/Fit2D.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */