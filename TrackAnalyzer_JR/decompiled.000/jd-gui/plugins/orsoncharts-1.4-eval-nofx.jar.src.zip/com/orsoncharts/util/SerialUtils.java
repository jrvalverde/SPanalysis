/*     */ package com.orsoncharts.util;
/*     */ 
/*     */ import java.awt.BasicStroke;
/*     */ import java.awt.Color;
/*     */ import java.awt.GradientPaint;
/*     */ import java.awt.Paint;
/*     */ import java.awt.Stroke;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.io.Serializable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SerialUtils
/*     */ {
/*     */   public static Paint readPaint(ObjectInputStream stream) throws IOException, ClassNotFoundException {
/*  48 */     ArgChecks.nullNotPermitted(stream, "stream");
/*  49 */     Paint result = null;
/*  50 */     boolean isNull = stream.readBoolean();
/*  51 */     if (!isNull) {
/*  52 */       Class<?> c = (Class)stream.readObject();
/*  53 */       if (Serializable.class.isAssignableFrom(c)) {
/*  54 */         result = (Paint)stream.readObject();
/*  55 */       } else if (c.equals(GradientPaint.class)) {
/*  56 */         float x1 = stream.readFloat();
/*  57 */         float y1 = stream.readFloat();
/*  58 */         Color c1 = (Color)stream.readObject();
/*  59 */         float x2 = stream.readFloat();
/*  60 */         float y2 = stream.readFloat();
/*  61 */         Color c2 = (Color)stream.readObject();
/*  62 */         boolean isCyclic = stream.readBoolean();
/*  63 */         result = new GradientPaint(x1, y1, c1, x2, y2, c2, isCyclic);
/*     */       } 
/*     */     } 
/*  66 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void writePaint(Paint paint, ObjectOutputStream stream) throws IOException {
/*  81 */     ArgChecks.nullNotPermitted(stream, "stream");
/*  82 */     if (paint != null) {
/*  83 */       stream.writeBoolean(false);
/*  84 */       stream.writeObject(paint.getClass());
/*  85 */       if (paint instanceof Serializable) {
/*  86 */         stream.writeObject(paint);
/*  87 */       } else if (paint instanceof GradientPaint) {
/*  88 */         GradientPaint gp = (GradientPaint)paint;
/*  89 */         stream.writeFloat((float)gp.getPoint1().getX());
/*  90 */         stream.writeFloat((float)gp.getPoint1().getY());
/*  91 */         stream.writeObject(gp.getColor1());
/*  92 */         stream.writeFloat((float)gp.getPoint2().getX());
/*  93 */         stream.writeFloat((float)gp.getPoint2().getY());
/*  94 */         stream.writeObject(gp.getColor2());
/*  95 */         stream.writeBoolean(gp.isCyclic());
/*     */       } 
/*     */     } else {
/*  98 */       stream.writeBoolean(true);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Stroke readStroke(ObjectInputStream stream) throws IOException, ClassNotFoundException {
/* 116 */     ArgChecks.nullNotPermitted(stream, "stream");
/* 117 */     Stroke result = null;
/* 118 */     boolean isNull = stream.readBoolean();
/* 119 */     if (!isNull) {
/* 120 */       Class<?> c = (Class)stream.readObject();
/* 121 */       if (c.equals(BasicStroke.class)) {
/* 122 */         float width = stream.readFloat();
/* 123 */         int cap = stream.readInt();
/* 124 */         int join = stream.readInt();
/* 125 */         float miterLimit = stream.readFloat();
/* 126 */         float[] dash = (float[])stream.readObject();
/* 127 */         float dashPhase = stream.readFloat();
/* 128 */         result = new BasicStroke(width, cap, join, miterLimit, dash, dashPhase);
/*     */       } else {
/*     */         
/* 131 */         result = (Stroke)stream.readObject();
/*     */       } 
/*     */     } 
/* 134 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void writeStroke(Stroke stroke, ObjectOutputStream stream) throws IOException {
/* 151 */     ArgChecks.nullNotPermitted(stream, "stream");
/* 152 */     if (stroke != null) {
/* 153 */       stream.writeBoolean(false);
/* 154 */       if (stroke instanceof BasicStroke) {
/* 155 */         BasicStroke s = (BasicStroke)stroke;
/* 156 */         stream.writeObject(BasicStroke.class);
/* 157 */         stream.writeFloat(s.getLineWidth());
/* 158 */         stream.writeInt(s.getEndCap());
/* 159 */         stream.writeInt(s.getLineJoin());
/* 160 */         stream.writeFloat(s.getMiterLimit());
/* 161 */         stream.writeObject(s.getDashArray());
/* 162 */         stream.writeFloat(s.getDashPhase());
/*     */       } else {
/* 164 */         stream.writeObject(stroke.getClass());
/* 165 */         stream.writeObject(stroke);
/*     */       } 
/*     */     } else {
/*     */       
/* 169 */       stream.writeBoolean(true);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/util/SerialUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */