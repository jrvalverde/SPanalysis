/*     */ package com.orsoncharts.util.json;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Writer;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JSONArray
/*     */   extends ArrayList
/*     */   implements List, JSONAware, JSONStreamAware
/*     */ {
/*     */   private static final long serialVersionUID = 3957988303675231981L;
/*     */   
/*     */   public static void writeJSONString(List list, Writer out) throws IOException {
/*  61 */     if (list == null) {
/*  62 */       out.write("null");
/*     */       
/*     */       return;
/*     */     } 
/*  66 */     boolean first = true;
/*  67 */     Iterator iter = list.iterator();
/*  68 */     out.write(91);
/*  69 */     while (iter.hasNext()) {
/*  70 */       if (first) {
/*  71 */         first = false;
/*     */       } else {
/*     */         
/*  74 */         out.write(44);
/*     */       } 
/*     */       
/*  77 */       Object value = iter.next();
/*  78 */       if (value == null) {
/*  79 */         out.write("null");
/*     */         continue;
/*     */       } 
/*  82 */       JSONValue.writeJSONString(value, out);
/*     */     } 
/*  84 */     out.write(93);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeJSONString(Writer out) throws IOException {
/*  96 */     writeJSONString(this, out);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String toJSONString(List list) {
/* 111 */     if (list == null) {
/* 112 */       return "null";
/*     */     }
/*     */     
/* 115 */     boolean first = true;
/* 116 */     StringBuilder sb = new StringBuilder();
/* 117 */     Iterator iter = list.iterator();
/* 118 */     sb.append('[');
/* 119 */     while (iter.hasNext()) {
/* 120 */       if (first) {
/* 121 */         first = false;
/*     */       } else {
/*     */         
/* 124 */         sb.append(',');
/*     */       } 
/*     */       
/* 127 */       Object value = iter.next();
/* 128 */       if (value == null) {
/* 129 */         sb.append("null");
/*     */         continue;
/*     */       } 
/* 132 */       sb.append(JSONValue.toJSONString(value));
/*     */     } 
/* 134 */     sb.append(']');
/* 135 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toJSONString() {
/* 145 */     return toJSONString(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 155 */     return toJSONString();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/util/json/JSONArray.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */