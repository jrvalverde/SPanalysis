/*    */ package com.orsoncharts.util;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum Orientation
/*    */ {
/* 25 */   HORIZONTAL,
/*    */ 
/*    */   
/* 28 */   VERTICAL;
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/util/Orientation.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */