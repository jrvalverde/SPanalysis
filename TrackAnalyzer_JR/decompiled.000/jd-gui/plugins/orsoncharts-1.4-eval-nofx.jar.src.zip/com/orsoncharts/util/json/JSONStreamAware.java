package com.orsoncharts.util.json;

import java.io.IOException;
import java.io.Writer;

public interface JSONStreamAware {
  void writeJSONString(Writer paramWriter) throws IOException;
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/util/json/JSONStreamAware.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */