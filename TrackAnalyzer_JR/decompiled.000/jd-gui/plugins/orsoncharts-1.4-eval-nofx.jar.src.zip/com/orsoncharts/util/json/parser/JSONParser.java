/*     */ package com.orsoncharts.util.json.parser;
/*     */ 
/*     */ import com.orsoncharts.util.json.JSONArray;
/*     */ import com.orsoncharts.util.json.JSONObject;
/*     */ import java.io.IOException;
/*     */ import java.io.Reader;
/*     */ import java.io.StringReader;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JSONParser
/*     */ {
/*     */   public static final int S_INIT = 0;
/*     */   public static final int S_IN_FINISHED_VALUE = 1;
/*     */   public static final int S_IN_OBJECT = 2;
/*     */   public static final int S_IN_ARRAY = 3;
/*     */   public static final int S_PASSED_PAIR_KEY = 4;
/*     */   public static final int S_IN_PAIR_VALUE = 5;
/*     */   public static final int S_END = 6;
/*     */   public static final int S_IN_ERROR = -1;
/*     */   private LinkedList handlerStatusStack;
/*  51 */   private Yylex lexer = new Yylex((Reader)null);
/*  52 */   private Yytoken token = null;
/*  53 */   private int status = 0;
/*     */   
/*     */   private int peekStatus(LinkedList<Integer> statusStack) {
/*  56 */     if (statusStack.size() == 0) {
/*  57 */       return -1;
/*     */     }
/*  59 */     Integer result = statusStack.getFirst();
/*  60 */     return result.intValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void reset() {
/*  68 */     this.token = null;
/*  69 */     this.status = 0;
/*  70 */     this.handlerStatusStack = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void reset(Reader in) {
/*  79 */     this.lexer.yyreset(in);
/*  80 */     reset();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getPosition() {
/*  87 */     return this.lexer.getPosition();
/*     */   }
/*     */   
/*     */   public Object parse(String s) throws ParseException {
/*  91 */     return parse(s, (ContainerFactory)null);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object parse(String s, ContainerFactory containerFactory) throws ParseException {
/*  96 */     StringReader in = new StringReader(s);
/*     */     try {
/*  98 */       return parse(in, containerFactory);
/*     */     }
/* 100 */     catch (IOException ie) {
/*     */ 
/*     */ 
/*     */       
/* 104 */       throw new ParseException(-1, 2, ie);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Object parse(Reader in) throws IOException, ParseException {
/* 110 */     return parse(in, (ContainerFactory)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object parse(Reader in, ContainerFactory containerFactory) throws IOException, ParseException {
/* 132 */     reset(in);
/* 133 */     LinkedList<Integer> statusStack = new LinkedList();
/* 134 */     LinkedList<Object> valueStack = new LinkedList(); try {
/*     */       do {
/*     */         String key; List<Object> val; Map<String, Object> parent; Map newObject; List newArray;
/*     */         Map map1;
/* 138 */         nextToken();
/* 139 */         switch (this.status) {
/*     */           case 0:
/* 141 */             switch (this.token.type) {
/*     */               case 0:
/* 143 */                 this.status = 1;
/* 144 */                 statusStack.addFirst(new Integer(this.status));
/* 145 */                 valueStack.addFirst(this.token.value);
/*     */                 break;
/*     */               case 1:
/* 148 */                 this.status = 2;
/* 149 */                 statusStack.addFirst(new Integer(this.status));
/* 150 */                 valueStack.addFirst(createObjectContainer(containerFactory));
/*     */                 break;
/*     */               case 3:
/* 153 */                 this.status = 3;
/* 154 */                 statusStack.addFirst(new Integer(this.status));
/* 155 */                 valueStack.addFirst(createArrayContainer(containerFactory));
/*     */                 break;
/*     */             } 
/* 158 */             this.status = -1;
/*     */             break;
/*     */ 
/*     */           
/*     */           case 1:
/* 163 */             if (this.token.type == -1) {
/* 164 */               return valueStack.removeFirst();
/*     */             }
/* 166 */             throw new ParseException(getPosition(), 1, this.token);
/*     */ 
/*     */ 
/*     */           
/*     */           case 2:
/* 171 */             switch (this.token.type) {
/*     */               case 5:
/*     */                 break;
/*     */               case 0:
/* 175 */                 if (this.token.value instanceof String) {
/* 176 */                   String str = (String)this.token.value;
/* 177 */                   valueStack.addFirst(str);
/* 178 */                   this.status = 4;
/* 179 */                   statusStack.addFirst(new Integer(this.status));
/*     */                   break;
/*     */                 } 
/* 182 */                 this.status = -1;
/*     */                 break;
/*     */               
/*     */               case 2:
/* 186 */                 if (valueStack.size() > 1) {
/* 187 */                   statusStack.removeFirst();
/* 188 */                   valueStack.removeFirst();
/* 189 */                   this.status = peekStatus(statusStack);
/*     */                   break;
/*     */                 } 
/* 192 */                 this.status = 1;
/*     */                 break;
/*     */             } 
/*     */             
/* 196 */             this.status = -1;
/*     */             break;
/*     */ 
/*     */ 
/*     */           
/*     */           case 4:
/* 202 */             switch (this.token.type) {
/*     */               case 6:
/*     */                 break;
/*     */               case 0:
/* 206 */                 statusStack.removeFirst();
/* 207 */                 key = (String)valueStack.removeFirst();
/* 208 */                 parent = (Map)valueStack.getFirst();
/* 209 */                 parent.put(key, this.token.value);
/* 210 */                 this.status = peekStatus(statusStack);
/*     */                 break;
/*     */               case 3:
/* 213 */                 statusStack.removeFirst();
/* 214 */                 key = (String)valueStack.removeFirst();
/* 215 */                 parent = (Map<String, Object>)valueStack.getFirst();
/* 216 */                 newArray = createArrayContainer(containerFactory);
/* 217 */                 parent.put(key, newArray);
/* 218 */                 this.status = 3;
/* 219 */                 statusStack.addFirst(new Integer(this.status));
/* 220 */                 valueStack.addFirst(newArray);
/*     */                 break;
/*     */               case 1:
/* 223 */                 statusStack.removeFirst();
/* 224 */                 key = (String)valueStack.removeFirst();
/* 225 */                 parent = (Map<String, Object>)valueStack.getFirst();
/* 226 */                 map1 = createObjectContainer(containerFactory);
/* 227 */                 parent.put(key, map1);
/* 228 */                 this.status = 2;
/* 229 */                 statusStack.addFirst(new Integer(this.status));
/* 230 */                 valueStack.addFirst(map1);
/*     */                 break;
/*     */             } 
/* 233 */             this.status = -1;
/*     */             break;
/*     */ 
/*     */           
/*     */           case 3:
/* 238 */             switch (this.token.type) {
/*     */               case 5:
/*     */                 break;
/*     */               case 0:
/* 242 */                 val = (List)valueStack.getFirst();
/* 243 */                 val.add(this.token.value);
/*     */                 break;
/*     */               case 4:
/* 246 */                 if (valueStack.size() > 1) {
/* 247 */                   statusStack.removeFirst();
/* 248 */                   valueStack.removeFirst();
/* 249 */                   this.status = peekStatus(statusStack);
/*     */                   break;
/*     */                 } 
/* 252 */                 this.status = 1;
/*     */                 break;
/*     */               
/*     */               case 1:
/* 256 */                 val = (List<Object>)valueStack.getFirst();
/* 257 */                 newObject = createObjectContainer(containerFactory);
/* 258 */                 val.add(newObject);
/* 259 */                 this.status = 2;
/* 260 */                 statusStack.addFirst(new Integer(this.status));
/* 261 */                 valueStack.addFirst(newObject);
/*     */                 break;
/*     */               case 3:
/* 264 */                 val = (List<Object>)valueStack.getFirst();
/* 265 */                 newArray = createArrayContainer(containerFactory);
/* 266 */                 val.add(newArray);
/* 267 */                 this.status = 3;
/* 268 */                 statusStack.addFirst(new Integer(this.status));
/* 269 */                 valueStack.addFirst(newArray);
/*     */                 break;
/*     */             } 
/* 272 */             this.status = -1;
/*     */             break;
/*     */           
/*     */           case -1:
/* 276 */             throw new ParseException(getPosition(), 1, this.token);
/*     */         } 
/*     */         
/* 279 */         if (this.status == -1) {
/* 280 */           throw new ParseException(getPosition(), 1, this.token);
/*     */         }
/*     */       }
/* 283 */       while (this.token.type != -1);
/*     */     }
/* 285 */     catch (IOException ie) {
/* 286 */       throw ie;
/*     */     } 
/*     */     
/* 289 */     throw new ParseException(getPosition(), 1, this.token);
/*     */   }
/*     */ 
/*     */   
/*     */   private void nextToken() throws ParseException, IOException {
/* 294 */     this.token = this.lexer.yylex();
/* 295 */     if (this.token == null) {
/* 296 */       this.token = new Yytoken(-1, null);
/*     */     }
/*     */   }
/*     */   
/*     */   private Map createObjectContainer(ContainerFactory containerFactory) {
/* 301 */     if (containerFactory == null) {
/* 302 */       return (Map)new JSONObject();
/*     */     }
/* 304 */     Map m = containerFactory.createObjectContainer();
/* 305 */     if (m == null) {
/* 306 */       return (Map)new JSONObject();
/*     */     }
/* 308 */     return m;
/*     */   }
/*     */   
/*     */   private List createArrayContainer(ContainerFactory containerFactory) {
/* 312 */     if (containerFactory == null) {
/* 313 */       return (List)new JSONArray();
/*     */     }
/* 315 */     List l = containerFactory.creatArrayContainer();
/* 316 */     if (l == null) {
/* 317 */       return (List)new JSONArray();
/*     */     }
/* 319 */     return l;
/*     */   }
/*     */ 
/*     */   
/*     */   public void parse(String s, ContentHandler contentHandler) throws ParseException {
/* 324 */     parse(s, contentHandler, false);
/*     */   }
/*     */ 
/*     */   
/*     */   public void parse(String s, ContentHandler contentHandler, boolean isResume) throws ParseException {
/* 329 */     StringReader in = new StringReader(s);
/*     */     try {
/* 331 */       parse(in, contentHandler, isResume);
/*     */     }
/* 333 */     catch (IOException ie) {
/*     */ 
/*     */ 
/*     */       
/* 337 */       throw new ParseException(-1, 2, ie);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void parse(Reader in, ContentHandler contentHandler) throws IOException, ParseException {
/* 344 */     parse(in, contentHandler, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void parse(Reader in, ContentHandler contentHandler, boolean isResume) throws IOException, ParseException {
/* 364 */     if (!isResume) {
/* 365 */       reset(in);
/* 366 */       this.handlerStatusStack = new LinkedList();
/*     */     
/*     */     }
/* 369 */     else if (this.handlerStatusStack == null) {
/* 370 */       isResume = false;
/* 371 */       reset(in);
/* 372 */       this.handlerStatusStack = new LinkedList();
/*     */     } 
/*     */ 
/*     */     
/* 376 */     LinkedList<Integer> statusStack = this.handlerStatusStack;
/*     */     
/*     */     try {
/*     */       do {
/* 380 */         switch (this.status) {
/*     */           case 0:
/* 382 */             contentHandler.startJSON();
/* 383 */             nextToken();
/* 384 */             switch (this.token.type) {
/*     */               case 0:
/* 386 */                 this.status = 1;
/* 387 */                 statusStack.addFirst(new Integer(this.status));
/* 388 */                 if (!contentHandler.primitive(this.token.value)) {
/*     */                   return;
/*     */                 }
/*     */                 break;
/*     */               case 1:
/* 393 */                 this.status = 2;
/* 394 */                 statusStack.addFirst(new Integer(this.status));
/* 395 */                 if (!contentHandler.startObject()) {
/*     */                   return;
/*     */                 }
/*     */                 break;
/*     */               case 3:
/* 400 */                 this.status = 3;
/* 401 */                 statusStack.addFirst(new Integer(this.status));
/* 402 */                 if (!contentHandler.startArray()) {
/*     */                   return;
/*     */                 }
/*     */                 break;
/*     */             } 
/* 407 */             this.status = -1;
/*     */             break;
/*     */ 
/*     */           
/*     */           case 1:
/* 412 */             nextToken();
/* 413 */             if (this.token.type == -1) {
/* 414 */               contentHandler.endJSON();
/* 415 */               this.status = 6;
/*     */               
/*     */               return;
/*     */             } 
/* 419 */             this.status = -1;
/* 420 */             throw new ParseException(getPosition(), 1, this.token);
/*     */ 
/*     */ 
/*     */           
/*     */           case 2:
/* 425 */             nextToken();
/* 426 */             switch (this.token.type) {
/*     */               case 5:
/*     */                 break;
/*     */               case 0:
/* 430 */                 if (this.token.value instanceof String) {
/* 431 */                   String key = (String)this.token.value;
/* 432 */                   this.status = 4;
/* 433 */                   statusStack.addFirst(new Integer(this.status));
/* 434 */                   if (!contentHandler.startObjectEntry(key)) {
/*     */                     return;
/*     */                   }
/*     */                   break;
/*     */                 } 
/* 439 */                 this.status = -1;
/*     */                 break;
/*     */               
/*     */               case 2:
/* 443 */                 if (statusStack.size() > 1) {
/* 444 */                   statusStack.removeFirst();
/* 445 */                   this.status = peekStatus(statusStack);
/*     */                 } else {
/*     */                   
/* 448 */                   this.status = 1;
/*     */                 } 
/* 450 */                 if (!contentHandler.endObject()) {
/*     */                   return;
/*     */                 }
/*     */                 break;
/*     */             } 
/* 455 */             this.status = -1;
/*     */             break;
/*     */ 
/*     */ 
/*     */           
/*     */           case 4:
/* 461 */             nextToken();
/* 462 */             switch (this.token.type) {
/*     */               case 6:
/*     */                 break;
/*     */               case 0:
/* 466 */                 statusStack.removeFirst();
/* 467 */                 this.status = peekStatus(statusStack);
/* 468 */                 if (!contentHandler.primitive(this.token.value)) {
/*     */                   return;
/*     */                 }
/* 471 */                 if (!contentHandler.endObjectEntry()) {
/*     */                   return;
/*     */                 }
/*     */                 break;
/*     */               case 3:
/* 476 */                 statusStack.removeFirst();
/* 477 */                 statusStack.addFirst(new Integer(5));
/* 478 */                 this.status = 3;
/* 479 */                 statusStack.addFirst(new Integer(this.status));
/* 480 */                 if (!contentHandler.startArray()) {
/*     */                   return;
/*     */                 }
/*     */                 break;
/*     */               case 1:
/* 485 */                 statusStack.removeFirst();
/* 486 */                 statusStack.addFirst(new Integer(5));
/* 487 */                 this.status = 2;
/* 488 */                 statusStack.addFirst(new Integer(this.status));
/* 489 */                 if (!contentHandler.startObject()) {
/*     */                   return;
/*     */                 }
/*     */                 break;
/*     */             } 
/* 494 */             this.status = -1;
/*     */             break;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           case 5:
/* 504 */             statusStack.removeFirst();
/* 505 */             this.status = peekStatus(statusStack);
/* 506 */             if (!contentHandler.endObjectEntry()) {
/*     */               return;
/*     */             }
/*     */             break;
/*     */           
/*     */           case 3:
/* 512 */             nextToken();
/* 513 */             switch (this.token.type) {
/*     */               case 5:
/*     */                 break;
/*     */               case 0:
/* 517 */                 if (!contentHandler.primitive(this.token.value)) {
/*     */                   return;
/*     */                 }
/*     */                 break;
/*     */               case 4:
/* 522 */                 if (statusStack.size() > 1) {
/* 523 */                   statusStack.removeFirst();
/* 524 */                   this.status = peekStatus(statusStack);
/*     */                 } else {
/*     */                   
/* 527 */                   this.status = 1;
/*     */                 } 
/* 529 */                 if (!contentHandler.endArray()) {
/*     */                   return;
/*     */                 }
/*     */                 break;
/*     */               case 1:
/* 534 */                 this.status = 2;
/* 535 */                 statusStack.addFirst(new Integer(this.status));
/* 536 */                 if (!contentHandler.startObject()) {
/*     */                   return;
/*     */                 }
/*     */                 break;
/*     */               case 3:
/* 541 */                 this.status = 3;
/* 542 */                 statusStack.addFirst(new Integer(this.status));
/* 543 */                 if (!contentHandler.startArray()) {
/*     */                   return;
/*     */                 }
/*     */                 break;
/*     */             } 
/* 548 */             this.status = -1;
/*     */             break;
/*     */ 
/*     */           
/*     */           case 6:
/*     */             return;
/*     */           
/*     */           case -1:
/* 556 */             throw new ParseException(getPosition(), 1, this.token);
/*     */         } 
/*     */         
/* 559 */         if (this.status == -1) {
/* 560 */           throw new ParseException(getPosition(), 1, this.token);
/*     */         }
/*     */       }
/* 563 */       while (this.token.type != -1);
/*     */     }
/* 565 */     catch (IOException ie) {
/* 566 */       this.status = -1;
/* 567 */       throw ie;
/*     */     }
/* 569 */     catch (ParseException pe) {
/* 570 */       this.status = -1;
/* 571 */       throw pe;
/*     */     }
/* 573 */     catch (RuntimeException re) {
/* 574 */       this.status = -1;
/* 575 */       throw re;
/*     */     }
/* 577 */     catch (Error e) {
/* 578 */       this.status = -1;
/* 579 */       throw e;
/*     */     } 
/*     */     
/* 582 */     this.status = -1;
/* 583 */     throw new ParseException(getPosition(), 1, this.token);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/util/json/parser/JSONParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */