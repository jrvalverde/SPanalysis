/*     */ package com.orsoncharts.util.json;
/*     */ 
/*     */ import com.orsoncharts.util.json.parser.JSONParser;
/*     */ import com.orsoncharts.util.json.parser.ParseException;
/*     */ import java.io.IOException;
/*     */ import java.io.Reader;
/*     */ import java.io.StringReader;
/*     */ import java.io.Writer;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JSONValue
/*     */ {
/*     */   public static Object parse(Reader in) {
/*     */     try {
/*  59 */       JSONParser parser = new JSONParser();
/*  60 */       return parser.parse(in);
/*     */     }
/*  62 */     catch (Exception e) {
/*  63 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object parse(String s) {
/*  75 */     StringReader in = new StringReader(s);
/*  76 */     return parse(in);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object parseWithException(Reader in) throws IOException, ParseException {
/*  99 */     JSONParser parser = new JSONParser();
/* 100 */     return parser.parse(in);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object parseWithException(String s) throws ParseException {
/* 113 */     JSONParser parser = new JSONParser();
/* 114 */     return parser.parse(s);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void writeJSONString(Object value, Writer out) throws IOException {
/* 139 */     if (value == null) {
/* 140 */       out.write("null");
/*     */       
/*     */       return;
/*     */     } 
/* 144 */     if (value instanceof String) {
/* 145 */       out.write(34);
/* 146 */       out.write(escape((String)value));
/* 147 */       out.write(34);
/*     */       
/*     */       return;
/*     */     } 
/* 151 */     if (value instanceof Double) {
/* 152 */       if (((Double)value).isInfinite() || ((Double)value).isNaN()) {
/* 153 */         out.write("null");
/*     */       } else {
/*     */         
/* 156 */         out.write(value.toString());
/*     */       } 
/*     */       
/*     */       return;
/*     */     } 
/* 161 */     if (value instanceof Float) {
/* 162 */       if (((Float)value).isInfinite() || ((Float)value).isNaN()) {
/* 163 */         out.write("null");
/*     */       } else {
/*     */         
/* 166 */         out.write(value.toString());
/*     */       } 
/*     */       
/*     */       return;
/*     */     } 
/* 171 */     if (value instanceof Number) {
/* 172 */       out.write(value.toString());
/*     */       
/*     */       return;
/*     */     } 
/* 176 */     if (value instanceof Boolean) {
/* 177 */       out.write(value.toString());
/*     */       
/*     */       return;
/*     */     } 
/* 181 */     if (value instanceof JSONStreamAware) {
/* 182 */       ((JSONStreamAware)value).writeJSONString(out);
/*     */       
/*     */       return;
/*     */     } 
/* 186 */     if (value instanceof JSONAware) {
/* 187 */       out.write(((JSONAware)value).toJSONString());
/*     */       
/*     */       return;
/*     */     } 
/* 191 */     if (value instanceof Map) {
/* 192 */       JSONObject.writeJSONString((Map)value, out);
/*     */       
/*     */       return;
/*     */     } 
/* 196 */     if (value instanceof List) {
/* 197 */       JSONArray.writeJSONString((List)value, out);
/*     */       
/*     */       return;
/*     */     } 
/* 201 */     out.write(value.toString());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String toJSONString(Object value) {
/* 223 */     if (value == null) {
/* 224 */       return "null";
/*     */     }
/*     */     
/* 227 */     if (value instanceof String) {
/* 228 */       return "\"" + escape((String)value) + "\"";
/*     */     }
/*     */     
/* 231 */     if (value instanceof Double) {
/* 232 */       if (((Double)value).isInfinite() || ((Double)value).isNaN()) {
/* 233 */         return "null";
/*     */       }
/*     */       
/* 236 */       return value.toString();
/*     */     } 
/*     */ 
/*     */     
/* 240 */     if (value instanceof Float) {
/* 241 */       if (((Float)value).isInfinite() || ((Float)value).isNaN()) {
/* 242 */         return "null";
/*     */       }
/*     */       
/* 245 */       return value.toString();
/*     */     } 
/*     */ 
/*     */     
/* 249 */     if (value instanceof Number) {
/* 250 */       return value.toString();
/*     */     }
/*     */     
/* 253 */     if (value instanceof Boolean) {
/* 254 */       return value.toString();
/*     */     }
/*     */     
/* 257 */     if (value instanceof JSONAware) {
/* 258 */       return ((JSONAware)value).toJSONString();
/*     */     }
/*     */     
/* 261 */     if (value instanceof Map) {
/* 262 */       return JSONObject.toJSONString((Map)value);
/*     */     }
/*     */     
/* 265 */     if (value instanceof List) {
/* 266 */       return JSONArray.toJSONString((List)value);
/*     */     }
/*     */     
/* 269 */     return value.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String escape(String s) {
/* 281 */     if (s == null) {
/* 282 */       return null;
/*     */     }
/* 284 */     StringBuffer sb = new StringBuffer();
/* 285 */     escape(s, sb);
/* 286 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void escape(String s, StringBuffer sb) {
/* 294 */     for (int i = 0; i < s.length(); i++) {
/* 295 */       char ch = s.charAt(i);
/* 296 */       switch (ch) {
/*     */         case '"':
/* 298 */           sb.append("\\\"");
/*     */           break;
/*     */         case '\\':
/* 301 */           sb.append("\\\\");
/*     */           break;
/*     */         case '\b':
/* 304 */           sb.append("\\b");
/*     */           break;
/*     */         case '\f':
/* 307 */           sb.append("\\f");
/*     */           break;
/*     */         case '\n':
/* 310 */           sb.append("\\n");
/*     */           break;
/*     */         case '\r':
/* 313 */           sb.append("\\r");
/*     */           break;
/*     */         case '\t':
/* 316 */           sb.append("\\t");
/*     */           break;
/*     */         case '/':
/* 319 */           sb.append("\\/");
/*     */           break;
/*     */         
/*     */         default:
/* 323 */           if ((ch >= '\000' && ch <= '\037') || (ch >= '' && ch <= '') || (ch >= ' ' && ch <= '⃿')) {
/*     */ 
/*     */             
/* 326 */             String ss = Integer.toHexString(ch);
/* 327 */             sb.append("\\u");
/* 328 */             for (int k = 0; k < 4 - ss.length(); k++) {
/* 329 */               sb.append('0');
/*     */             }
/* 331 */             sb.append(ss.toUpperCase());
/*     */             break;
/*     */           } 
/* 334 */           sb.append(ch);
/*     */           break;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/util/json/JSONValue.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */