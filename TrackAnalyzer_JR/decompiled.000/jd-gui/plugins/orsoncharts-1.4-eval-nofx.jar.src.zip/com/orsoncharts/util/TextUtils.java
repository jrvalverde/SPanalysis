/*     */ package com.orsoncharts.util;
/*     */ 
/*     */ import java.awt.Font;
/*     */ import java.awt.FontMetrics;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.Shape;
/*     */ import java.awt.font.FontRenderContext;
/*     */ import java.awt.font.LineMetrics;
/*     */ import java.awt.font.TextLayout;
/*     */ import java.awt.geom.AffineTransform;
/*     */ import java.awt.geom.Rectangle2D;
/*     */ import java.text.AttributedString;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TextUtils
/*     */ {
/*     */   public static Rectangle2D drawAlignedString(String text, Graphics2D g2, float x, float y, TextAnchor anchor) {
/*  51 */     Rectangle2D textBounds = new Rectangle2D.Double();
/*  52 */     float[] adjust = deriveTextBoundsAnchorOffsets(g2, text, anchor, textBounds);
/*     */ 
/*     */     
/*  55 */     textBounds.setRect((x + adjust[0]), (y + adjust[1] + adjust[2]), textBounds
/*  56 */         .getWidth(), textBounds.getHeight());
/*  57 */     g2.drawString(text, x + adjust[0], y + adjust[1]);
/*  58 */     return textBounds;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Rectangle2D calcAlignedStringBounds(String text, Graphics2D g2, float x, float y, TextAnchor anchor) {
/*  78 */     Rectangle2D textBounds = new Rectangle2D.Double();
/*  79 */     float[] adjust = deriveTextBoundsAnchorOffsets(g2, text, anchor, textBounds);
/*     */ 
/*     */     
/*  82 */     textBounds.setRect((x + adjust[0]), (y + adjust[1] + adjust[2]), textBounds
/*  83 */         .getWidth(), textBounds.getHeight());
/*  84 */     return textBounds;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static float[] deriveTextBoundsAnchorOffsets(Graphics2D g2, String text, TextAnchor anchor) {
/* 103 */     float[] result = new float[2];
/* 104 */     FontRenderContext frc = g2.getFontRenderContext();
/* 105 */     Font f = g2.getFont();
/* 106 */     FontMetrics fm = g2.getFontMetrics(f);
/* 107 */     Rectangle2D bounds = getTextBounds(text, fm);
/* 108 */     LineMetrics metrics = f.getLineMetrics(text, frc);
/* 109 */     float ascent = metrics.getAscent();
/* 110 */     float halfAscent = ascent / 2.0F;
/* 111 */     float descent = metrics.getDescent();
/* 112 */     float leading = metrics.getLeading();
/* 113 */     float xAdj = 0.0F;
/* 114 */     float yAdj = 0.0F;
/*     */     
/* 116 */     if (anchor.isHorizontalCenter()) {
/* 117 */       xAdj = (float)-bounds.getWidth() / 2.0F;
/*     */     }
/* 119 */     else if (anchor.isRight()) {
/* 120 */       xAdj = (float)-bounds.getWidth();
/*     */     } 
/*     */     
/* 123 */     if (anchor.isTop()) {
/* 124 */       yAdj = -descent - leading + (float)bounds.getHeight();
/*     */     }
/* 126 */     else if (anchor.isHalfAscent()) {
/* 127 */       yAdj = halfAscent;
/*     */     }
/* 129 */     else if (anchor.isHalfHeight()) {
/* 130 */       yAdj = -descent - leading + (float)(bounds.getHeight() / 2.0D);
/*     */     }
/* 132 */     else if (anchor.isBaseline()) {
/* 133 */       yAdj = 0.0F;
/*     */     }
/* 135 */     else if (anchor.isBottom()) {
/* 136 */       yAdj = -metrics.getDescent() - metrics.getLeading();
/*     */     } 
/* 138 */     result[0] = xAdj;
/* 139 */     result[1] = yAdj;
/* 140 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static float[] deriveTextBoundsAnchorOffsets(Graphics2D g2, String text, TextAnchor anchor, Rectangle2D textBounds) {
/* 163 */     float[] result = new float[3];
/* 164 */     FontRenderContext frc = g2.getFontRenderContext();
/* 165 */     Font f = g2.getFont();
/* 166 */     FontMetrics fm = g2.getFontMetrics(f);
/* 167 */     Rectangle2D bounds = getTextBounds(text, fm);
/* 168 */     LineMetrics metrics = f.getLineMetrics(text, frc);
/* 169 */     float ascent = metrics.getAscent();
/* 170 */     result[2] = -ascent;
/* 171 */     float halfAscent = ascent / 2.0F;
/* 172 */     float descent = metrics.getDescent();
/* 173 */     float leading = metrics.getLeading();
/* 174 */     float xAdj = 0.0F;
/* 175 */     float yAdj = 0.0F;
/*     */     
/* 177 */     if (anchor.isHorizontalCenter()) {
/* 178 */       xAdj = (float)-bounds.getWidth() / 2.0F;
/*     */     }
/* 180 */     else if (anchor.isRight()) {
/* 181 */       xAdj = (float)-bounds.getWidth();
/*     */     } 
/*     */     
/* 184 */     if (anchor.isTop()) {
/* 185 */       yAdj = -descent - leading + (float)bounds.getHeight();
/*     */     }
/* 187 */     else if (anchor.isHalfAscent()) {
/* 188 */       yAdj = halfAscent;
/*     */     }
/* 190 */     else if (anchor.isHorizontalCenter()) {
/* 191 */       yAdj = -descent - leading + (float)(bounds.getHeight() / 2.0D);
/*     */     }
/* 193 */     else if (anchor.isBaseline()) {
/* 194 */       yAdj = 0.0F;
/*     */     }
/* 196 */     else if (anchor.isBottom()) {
/* 197 */       yAdj = -metrics.getDescent() - metrics.getLeading();
/*     */     } 
/* 199 */     if (textBounds != null) {
/* 200 */       textBounds.setRect(bounds);
/*     */     }
/* 202 */     result[0] = xAdj;
/* 203 */     result[1] = yAdj;
/* 204 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Rectangle2D getTextBounds(String text, FontMetrics fm) {
/* 218 */     return getTextBounds(text, 0.0D, 0.0D, fm);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Rectangle2D getTextBounds(String text, double x, double y, FontMetrics fm) {
/* 234 */     ArgChecks.nullNotPermitted(text, "text");
/* 235 */     ArgChecks.nullNotPermitted(fm, "fm");
/* 236 */     double width = fm.stringWidth(text);
/* 237 */     double height = fm.getHeight();
/* 238 */     return new Rectangle2D.Double(x, y - fm.getAscent(), width, height);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Shape drawRotatedString(String text, Graphics2D g2, float x, float y, TextAnchor textAnchor, double angle, float rotationX, float rotationY) {
/* 260 */     ArgChecks.nullNotPermitted(text, "text");
/* 261 */     float[] textAdj = deriveTextBoundsAnchorOffsets(g2, text, textAnchor);
/* 262 */     return drawRotatedString(text, g2, x + textAdj[0], y + textAdj[1], angle, rotationX, rotationY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Shape drawRotatedString(String text, Graphics2D g2, float x, float y, TextAnchor textAnchor, double angle, TextAnchor rotationAnchor) {
/* 284 */     ArgChecks.nullNotPermitted(text, "text");
/* 285 */     float[] textAdj = deriveTextBoundsAnchorOffsets(g2, text, textAnchor);
/* 286 */     float[] rotateAdj = deriveRotationAnchorOffsets(g2, text, rotationAnchor);
/*     */     
/* 288 */     return drawRotatedString(text, g2, x + textAdj[0], y + textAdj[1], angle, x + textAdj[0] + rotateAdj[0], y + textAdj[1] + rotateAdj[1]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static float[] deriveRotationAnchorOffsets(Graphics2D g2, String text, TextAnchor anchor) {
/* 308 */     float[] result = new float[2];
/* 309 */     FontRenderContext frc = g2.getFontRenderContext();
/* 310 */     LineMetrics metrics = g2.getFont().getLineMetrics(text, frc);
/* 311 */     FontMetrics fm = g2.getFontMetrics();
/* 312 */     Rectangle2D bounds = getTextBounds(text, fm);
/* 313 */     float ascent = metrics.getAscent();
/* 314 */     float halfAscent = ascent / 2.0F;
/* 315 */     float descent = metrics.getDescent();
/* 316 */     float leading = metrics.getLeading();
/* 317 */     float xAdj = 0.0F;
/* 318 */     float yAdj = 0.0F;
/*     */     
/* 320 */     if (anchor.isLeft()) {
/* 321 */       xAdj = 0.0F;
/*     */     }
/* 323 */     else if (anchor.isHorizontalCenter()) {
/* 324 */       xAdj = (float)bounds.getWidth() / 2.0F;
/*     */     }
/* 326 */     else if (anchor.isRight()) {
/* 327 */       xAdj = (float)bounds.getWidth();
/*     */     } 
/*     */     
/* 330 */     if (anchor.isTop()) {
/* 331 */       yAdj = descent + leading - (float)bounds.getHeight();
/*     */     }
/* 333 */     else if (anchor.isHalfHeight()) {
/* 334 */       yAdj = descent + leading - (float)(bounds.getHeight() / 2.0D);
/*     */     }
/* 336 */     else if (anchor.isHalfAscent()) {
/* 337 */       yAdj = -halfAscent;
/*     */     }
/* 339 */     else if (anchor.isBaseline()) {
/* 340 */       yAdj = 0.0F;
/*     */     }
/* 342 */     else if (anchor.isBottom()) {
/* 343 */       yAdj = metrics.getDescent() + metrics.getLeading();
/*     */     } 
/* 345 */     result[0] = xAdj;
/* 346 */     result[1] = yAdj;
/* 347 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Shape drawRotatedString(String text, Graphics2D g2, double angle, float x, float y) {
/* 367 */     return drawRotatedString(text, g2, x, y, angle, x, y);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Shape drawRotatedString(String text, Graphics2D g2, float textX, float textY, double angle, float rotateX, float rotateY) {
/* 389 */     ArgChecks.nullNotPermitted(text, "text");
/* 390 */     AffineTransform saved = g2.getTransform();
/* 391 */     Rectangle2D rect = getTextBounds(text, textX, textY, g2
/* 392 */         .getFontMetrics());
/* 393 */     AffineTransform rotate = AffineTransform.getRotateInstance(angle, rotateX, rotateY);
/*     */     
/* 395 */     Shape bounds = rotate.createTransformedShape(rect);
/* 396 */     g2.transform(rotate);
/* 397 */     g2.drawString(text, textX, textY);
/* 398 */     g2.setTransform(saved);
/* 399 */     return bounds;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Shape drawRotatedString(AttributedString text, Graphics2D g2, double angle, float x, float y) {
/* 418 */     return drawRotatedString(text, g2, x, y, angle, x, y);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Shape drawRotatedString(AttributedString text, Graphics2D g2, float textX, float textY, double angle, float rotateX, float rotateY) {
/* 441 */     ArgChecks.nullNotPermitted(text, "text");
/* 442 */     AffineTransform saved = g2.getTransform();
/* 443 */     AffineTransform rotate = AffineTransform.getRotateInstance(angle, rotateX, rotateY);
/*     */     
/* 445 */     g2.transform(rotate);
/*     */     
/* 447 */     TextLayout tl = new TextLayout(text.getIterator(), g2.getFontRenderContext());
/* 448 */     Rectangle2D rect = tl.getBounds();
/* 449 */     tl.draw(g2, textX, textY);
/* 450 */     g2.setTransform(saved);
/* 451 */     return rotate.createTransformedShape(rect);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Shape drawRotatedString(AttributedString text, Graphics2D g2, float x, float y, TextAnchor textAnchor, double angle, TextAnchor rotationAnchor, Rectangle2D nonRotatedBounds) {
/* 478 */     ArgChecks.nullNotPermitted(text, "text");
/* 479 */     float[] textAdj = deriveTextBoundsAnchorOffsets(g2, text, textAnchor, nonRotatedBounds);
/*     */     
/* 481 */     float[] rotateAdj = deriveRotationAnchorOffsets(g2, text, rotationAnchor);
/*     */     
/* 483 */     return drawRotatedString(text, g2, x + textAdj[0], y + textAdj[1], angle, x + textAdj[0] + rotateAdj[0], y + textAdj[1] + rotateAdj[1]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static float[] deriveTextBoundsAnchorOffsets(Graphics2D g2, AttributedString text, TextAnchor anchor, Rectangle2D textBounds) {
/* 504 */     TextLayout layout = new TextLayout(text.getIterator(), g2.getFontRenderContext());
/* 505 */     Rectangle2D bounds = layout.getBounds();
/*     */     
/* 507 */     float[] result = new float[3];
/* 508 */     float ascent = layout.getAscent();
/* 509 */     result[2] = -ascent;
/* 510 */     float halfAscent = ascent / 2.0F;
/* 511 */     float descent = layout.getDescent();
/* 512 */     float leading = layout.getLeading();
/* 513 */     float xAdj = 0.0F;
/* 514 */     float yAdj = 0.0F;
/*     */     
/* 516 */     if (anchor.isHorizontalCenter()) {
/* 517 */       xAdj = (float)-bounds.getWidth() / 2.0F;
/*     */     }
/* 519 */     else if (anchor.isRight()) {
/* 520 */       xAdj = (float)-bounds.getWidth();
/*     */     } 
/*     */     
/* 523 */     if (anchor.isTop()) {
/* 524 */       yAdj = -descent - leading + (float)bounds.getHeight();
/*     */     }
/* 526 */     else if (anchor.isHalfAscent()) {
/* 527 */       yAdj = halfAscent;
/*     */     }
/* 529 */     else if (anchor.isHalfHeight()) {
/* 530 */       yAdj = -descent - leading + (float)(bounds.getHeight() / 2.0D);
/*     */     }
/* 532 */     else if (anchor.isBaseline()) {
/* 533 */       yAdj = 0.0F;
/*     */     }
/* 535 */     else if (anchor.isBottom()) {
/* 536 */       yAdj = -descent - leading;
/*     */     } 
/* 538 */     if (textBounds != null) {
/* 539 */       textBounds.setRect(bounds);
/*     */     }
/* 541 */     result[0] = xAdj;
/* 542 */     result[1] = yAdj;
/* 543 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static float[] deriveRotationAnchorOffsets(Graphics2D g2, AttributedString text, TextAnchor anchor) {
/* 560 */     float[] result = new float[2];
/*     */ 
/*     */     
/* 563 */     TextLayout layout = new TextLayout(text.getIterator(), g2.getFontRenderContext());
/* 564 */     Rectangle2D bounds = layout.getBounds();
/* 565 */     float ascent = layout.getAscent();
/* 566 */     float halfAscent = ascent / 2.0F;
/* 567 */     float descent = layout.getDescent();
/* 568 */     float leading = layout.getLeading();
/* 569 */     float xAdj = 0.0F;
/* 570 */     float yAdj = 0.0F;
/*     */     
/* 572 */     if (anchor.isLeft()) {
/* 573 */       xAdj = 0.0F;
/*     */     }
/* 575 */     else if (anchor.isHorizontalCenter()) {
/* 576 */       xAdj = (float)bounds.getWidth() / 2.0F;
/*     */     }
/* 578 */     else if (anchor.isRight()) {
/* 579 */       xAdj = (float)bounds.getWidth();
/*     */     } 
/*     */     
/* 582 */     if (anchor.isTop()) {
/* 583 */       yAdj = descent + leading - (float)bounds.getHeight();
/*     */     }
/* 585 */     else if (anchor.isHalfHeight()) {
/* 586 */       yAdj = descent + leading - (float)(bounds.getHeight() / 2.0D);
/*     */     }
/* 588 */     else if (anchor.isHalfAscent()) {
/* 589 */       yAdj = -halfAscent;
/*     */     }
/* 591 */     else if (anchor.isBaseline()) {
/* 592 */       yAdj = 0.0F;
/*     */     }
/* 594 */     else if (anchor.isBottom()) {
/* 595 */       yAdj = descent + leading;
/*     */     } 
/* 597 */     result[0] = xAdj;
/* 598 */     result[1] = yAdj;
/* 599 */     return result;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/util/TextUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */