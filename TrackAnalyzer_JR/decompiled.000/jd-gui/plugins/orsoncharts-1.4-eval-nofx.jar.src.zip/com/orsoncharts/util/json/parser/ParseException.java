/*     */ package com.orsoncharts.util.json.parser;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ParseException
/*     */   extends Exception
/*     */ {
/*     */   private static final long serialVersionUID = -7880698968187728548L;
/*     */   public static final int ERROR_UNEXPECTED_CHAR = 0;
/*     */   public static final int ERROR_UNEXPECTED_TOKEN = 1;
/*     */   public static final int ERROR_UNEXPECTED_EXCEPTION = 2;
/*     */   private int errorType;
/*     */   private Object unexpectedObject;
/*     */   private int position;
/*     */   
/*     */   public ParseException(int errorType) {
/*  43 */     this(-1, errorType, null);
/*     */   }
/*     */   
/*     */   public ParseException(int errorType, Object unexpectedObject) {
/*  47 */     this(-1, errorType, unexpectedObject);
/*     */   }
/*     */ 
/*     */   
/*     */   public ParseException(int position, int errorType, Object unexpectedObject) {
/*  52 */     this.position = position;
/*  53 */     this.errorType = errorType;
/*  54 */     this.unexpectedObject = unexpectedObject;
/*     */   }
/*     */   
/*     */   public int getErrorType() {
/*  58 */     return this.errorType;
/*     */   }
/*     */   
/*     */   public void setErrorType(int errorType) {
/*  62 */     this.errorType = errorType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getPosition() {
/*  72 */     return this.position;
/*     */   }
/*     */   
/*     */   public void setPosition(int position) {
/*  76 */     this.position = position;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getUnexpectedObject() {
/*  88 */     return this.unexpectedObject;
/*     */   }
/*     */   
/*     */   public void setUnexpectedObject(Object unexpectedObject) {
/*  92 */     this.unexpectedObject = unexpectedObject;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/*  97 */     StringBuilder sb = new StringBuilder();
/*     */     
/*  99 */     switch (this.errorType)
/*     */     { case 0:
/* 101 */         sb.append("Unexpected character (").append(this.unexpectedObject);
/* 102 */         sb.append(") at position ").append(this.position).append(".");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 116 */         return sb.toString();case 1: sb.append("Unexpected token ").append(this.unexpectedObject); sb.append(" at position ").append(this.position).append("."); return sb.toString();case 2: sb.append("Unexpected exception at position ").append(this.position); sb.append(": ").append(this.unexpectedObject); return sb.toString(); }  sb.append("Unkown error at position ").append(this.position).append("."); return sb.toString();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/util/json/parser/ParseException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */