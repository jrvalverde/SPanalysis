/*     */ package com.orsoncharts.util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public enum TextAnchor
/*     */ {
/*  22 */   TOP_LEFT("TextAnchor.TOP_LEFT"),
/*     */ 
/*     */   
/*  25 */   TOP_CENTER("TextAnchor.TOP_CENTER"),
/*     */ 
/*     */   
/*  28 */   TOP_RIGHT("TextAnchor.TOP_RIGHT"),
/*     */ 
/*     */   
/*  31 */   HALF_ASCENT_LEFT("TextAnchor.HALF_ASCENT_LEFT"),
/*     */ 
/*     */   
/*  34 */   HALF_ASCENT_CENTER("TextAnchor.HALF_ASCENT_CENTER"),
/*     */ 
/*     */   
/*  37 */   HALF_ASCENT_RIGHT("TextAnchor.HALF_ASCENT_RIGHT"),
/*     */ 
/*     */   
/*  40 */   CENTER_LEFT("TextAnchor.CENTER_LEFT"),
/*     */ 
/*     */   
/*  43 */   CENTER("TextAnchor.CENTER"),
/*     */ 
/*     */   
/*  46 */   CENTER_RIGHT("TextAnchor.CENTER_RIGHT"),
/*     */ 
/*     */   
/*  49 */   BASELINE_LEFT("TextAnchor.BASELINE_LEFT"),
/*     */ 
/*     */   
/*  52 */   BASELINE_CENTER("TextAnchor.BASELINE_CENTER"),
/*     */ 
/*     */   
/*  55 */   BASELINE_RIGHT("TextAnchor.BASELINE_RIGHT"),
/*     */ 
/*     */   
/*  58 */   BOTTOM_LEFT("TextAnchor.BOTTOM_LEFT"),
/*     */ 
/*     */   
/*  61 */   BOTTOM_CENTER("TextAnchor.BOTTOM_CENTER"),
/*     */ 
/*     */   
/*  64 */   BOTTOM_RIGHT("TextAnchor.BOTTOM_RIGHT");
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String name;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   TextAnchor(String name) {
/*  75 */     this.name = name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isLeft() {
/*  85 */     return (this == TOP_LEFT || this == CENTER_LEFT || this == HALF_ASCENT_LEFT || this == BASELINE_LEFT || this == BOTTOM_LEFT);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isHorizontalCenter() {
/*  97 */     return (this == TOP_CENTER || this == CENTER || this == HALF_ASCENT_CENTER || this == BASELINE_CENTER || this == BOTTOM_CENTER);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isRight() {
/* 109 */     return (this == TOP_RIGHT || this == CENTER_RIGHT || this == HALF_ASCENT_RIGHT || this == BASELINE_RIGHT || this == BOTTOM_RIGHT);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isTop() {
/* 121 */     return (this == TOP_LEFT || this == TOP_CENTER || this == TOP_RIGHT);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isHalfAscent() {
/* 131 */     return (this == HALF_ASCENT_LEFT || this == HALF_ASCENT_CENTER || this == HALF_ASCENT_RIGHT);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isHalfHeight() {
/* 142 */     return (this == CENTER_LEFT || this == CENTER || this == CENTER_RIGHT);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isBaseline() {
/* 152 */     return (this == BASELINE_LEFT || this == BASELINE_CENTER || this == BASELINE_RIGHT);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isBottom() {
/* 163 */     return (this == BOTTOM_LEFT || this == BOTTOM_CENTER || this == BOTTOM_RIGHT);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 174 */     return this.name;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/util/TextAnchor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */