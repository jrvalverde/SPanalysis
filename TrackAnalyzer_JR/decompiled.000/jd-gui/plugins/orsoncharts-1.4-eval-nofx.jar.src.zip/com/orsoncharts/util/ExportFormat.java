/*    */ package com.orsoncharts.util;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum ExportFormat
/*    */ {
/* 26 */   PNG,
/*    */ 
/*    */   
/* 29 */   JPEG,
/*    */ 
/*    */   
/* 32 */   PDF,
/*    */ 
/*    */   
/* 35 */   SVG;
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/util/ExportFormat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */