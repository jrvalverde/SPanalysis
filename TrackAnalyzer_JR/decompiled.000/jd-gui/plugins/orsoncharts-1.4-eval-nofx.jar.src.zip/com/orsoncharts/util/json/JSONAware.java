package com.orsoncharts.util.json;

public interface JSONAware {
  String toJSONString();
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/util/json/JSONAware.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */