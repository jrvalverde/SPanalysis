/*      */ package com.orsoncharts;
/*      */ 
/*      */ import com.orsoncharts.axis.Axis3D;
/*      */ import com.orsoncharts.axis.CategoryAxis3D;
/*      */ import com.orsoncharts.axis.TickData;
/*      */ import com.orsoncharts.axis.ValueAxis3D;
/*      */ import com.orsoncharts.data.ItemKey;
/*      */ import com.orsoncharts.graphics3d.Dimension3D;
/*      */ import com.orsoncharts.graphics3d.Drawable3D;
/*      */ import com.orsoncharts.graphics3d.Face;
/*      */ import com.orsoncharts.graphics3d.FaceSorter;
/*      */ import com.orsoncharts.graphics3d.LabelFace;
/*      */ import com.orsoncharts.graphics3d.Object3D;
/*      */ import com.orsoncharts.graphics3d.Offset2D;
/*      */ import com.orsoncharts.graphics3d.Point3D;
/*      */ import com.orsoncharts.graphics3d.RenderedElement;
/*      */ import com.orsoncharts.graphics3d.RenderingInfo;
/*      */ import com.orsoncharts.graphics3d.StandardFaceSorter;
/*      */ import com.orsoncharts.graphics3d.Utils2D;
/*      */ import com.orsoncharts.graphics3d.ViewPoint3D;
/*      */ import com.orsoncharts.graphics3d.World;
/*      */ import com.orsoncharts.interaction.InteractiveElementType;
/*      */ import com.orsoncharts.legend.LegendAnchor;
/*      */ import com.orsoncharts.legend.LegendBuilder;
/*      */ import com.orsoncharts.legend.StandardLegendBuilder;
/*      */ import com.orsoncharts.marker.Marker;
/*      */ import com.orsoncharts.marker.MarkerData;
/*      */ import com.orsoncharts.plot.CategoryPlot3D;
/*      */ import com.orsoncharts.plot.PiePlot3D;
/*      */ import com.orsoncharts.plot.Plot3D;
/*      */ import com.orsoncharts.plot.Plot3DChangeEvent;
/*      */ import com.orsoncharts.plot.Plot3DChangeListener;
/*      */ import com.orsoncharts.plot.XYZPlot;
/*      */ import com.orsoncharts.style.ChartStyle;
/*      */ import com.orsoncharts.style.ChartStyleChangeEvent;
/*      */ import com.orsoncharts.style.ChartStyleChangeListener;
/*      */ import com.orsoncharts.style.ChartStyler;
/*      */ import com.orsoncharts.table.GridElement;
/*      */ import com.orsoncharts.table.HAlign;
/*      */ import com.orsoncharts.table.RectanglePainter;
/*      */ import com.orsoncharts.table.StandardRectanglePainter;
/*      */ import com.orsoncharts.table.TableElement;
/*      */ import com.orsoncharts.table.TextElement;
/*      */ import com.orsoncharts.util.Anchor2D;
/*      */ import com.orsoncharts.util.ArgChecks;
/*      */ import com.orsoncharts.util.ObjectUtils;
/*      */ import com.orsoncharts.util.Orientation;
/*      */ import com.orsoncharts.util.RefPt2D;
/*      */ import com.orsoncharts.util.TextAnchor;
/*      */ import com.orsoncharts.util.TextUtils;
/*      */ import java.awt.BasicStroke;
/*      */ import java.awt.Color;
/*      */ import java.awt.Font;
/*      */ import java.awt.Graphics2D;
/*      */ import java.awt.Paint;
/*      */ import java.awt.RenderingHints;
/*      */ import java.awt.Shape;
/*      */ import java.awt.Stroke;
/*      */ import java.awt.geom.AffineTransform;
/*      */ import java.awt.geom.Dimension2D;
/*      */ import java.awt.geom.Line2D;
/*      */ import java.awt.geom.Path2D;
/*      */ import java.awt.geom.Point2D;
/*      */ import java.awt.geom.Rectangle2D;
/*      */ import java.io.IOException;
/*      */ import java.io.ObjectInputStream;
/*      */ import java.io.Serializable;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collections;
/*      */ import java.util.HashMap;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import javax.swing.event.EventListenerList;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class Chart3D
/*      */   implements Drawable3D, ChartElement, Plot3DChangeListener, ChartStyleChangeListener, Serializable
/*      */ {
/*      */   public static final double DEFAULT_PROJ_DIST = 1500.0D;
/*      */   public static final String INTERACTIVE_ELEMENT_TYPE = "interactive_element_type";
/*      */   public static final String SERIES_KEY = "series_key";
/*      */   private String id;
/*      */   private RectanglePainter background;
/*      */   private TableElement title;
/*      */   private Anchor2D titleAnchor;
/*      */   private LegendBuilder legendBuilder;
/*      */   private Anchor2D legendAnchor;
/*      */   private Orientation legendOrientation;
/*      */   private Plot3D plot;
/*      */   private ViewPoint3D viewPoint;
/*      */   private double projDist;
/*      */   private Color chartBoxColor;
/*      */   private Offset2D translate2D;
/*      */   private transient EventListenerList listenerList;
/*      */   private boolean notify;
/*      */   private transient RenderingHints renderingHints;
/*      */   private ChartStyle style;
/*      */   private transient World world;
/*      */   private FaceSorter faceSorter;
/*      */   private boolean elementHinting;
/*      */   
/*      */   public Chart3D(String title, String subtitle, Plot3D plot) {
/*  246 */     this(title, subtitle, plot, Chart3DFactory.getDefaultChartStyle());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Chart3D(String title, String subtitle, Plot3D plot, ChartStyle style) {
/*  261 */     ArgChecks.nullNotPermitted(plot, "plot");
/*  262 */     ArgChecks.nullNotPermitted(style, "style");
/*  263 */     plot.setChart(this);
/*  264 */     this.background = (RectanglePainter)new StandardRectanglePainter(Color.WHITE);
/*  265 */     if (title != null) {
/*  266 */       this.title = TitleUtils.createTitle(title, subtitle);
/*      */     }
/*  268 */     this.titleAnchor = TitleAnchor.TOP_LEFT;
/*  269 */     this.legendBuilder = (LegendBuilder)new StandardLegendBuilder();
/*  270 */     this.legendAnchor = LegendAnchor.BOTTOM_RIGHT;
/*  271 */     this.legendOrientation = Orientation.HORIZONTAL;
/*  272 */     this.plot = plot;
/*  273 */     this.plot.addChangeListener(this);
/*  274 */     Dimension3D dim = this.plot.getDimensions();
/*  275 */     float distance = (float)dim.getDiagonalLength() * 3.0F;
/*  276 */     this.viewPoint = ViewPoint3D.createAboveViewPoint(distance);
/*  277 */     this.projDist = 1500.0D;
/*  278 */     this.chartBoxColor = new Color(255, 255, 255, 100);
/*  279 */     this.translate2D = new Offset2D();
/*  280 */     this.faceSorter = (FaceSorter)new StandardFaceSorter();
/*  281 */     this.renderingHints = new RenderingHints(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
/*      */ 
/*      */     
/*  284 */     this.renderingHints.put(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
/*      */     
/*  286 */     this.elementHinting = false;
/*  287 */     this.notify = true;
/*  288 */     this.listenerList = new EventListenerList();
/*  289 */     this.style = style;
/*  290 */     this.style.addChangeListener(this);
/*  291 */     receive((ChartElementVisitor)new ChartStyler(this.style));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getID() {
/*  302 */     return this.id;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setID(String id) {
/*  313 */     this.id = id;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public RectanglePainter getBackground() {
/*  327 */     return this.background;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBackground(RectanglePainter background) {
/*  343 */     this.background = background;
/*  344 */     fireChangeEvent();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TableElement getTitle() {
/*  355 */     return this.title;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTitle(String title) {
/*  366 */     if (title == null) {
/*  367 */       setTitle((TableElement)null);
/*      */     } else {
/*  369 */       setTitle(title, this.style.getTitleFont(), TitleUtils.DEFAULT_TITLE_COLOR);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTitle(String title, Font font, Color color) {
/*  385 */     ArgChecks.nullNotPermitted(font, "font");
/*  386 */     ArgChecks.nullNotPermitted(color, "color");
/*  387 */     TextElement te = new TextElement(title);
/*  388 */     te.setTag("CHART_TITLE");
/*  389 */     te.setFont(font);
/*  390 */     te.setColor(color);
/*  391 */     setTitle((TableElement)te);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTitle(TableElement title) {
/*  402 */     this.title = title;
/*  403 */     fireChangeEvent();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Anchor2D getTitleAnchor() {
/*  415 */     return this.titleAnchor;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTitleAnchor(Anchor2D anchor) {
/*  428 */     ArgChecks.nullNotPermitted(anchor, "anchor");
/*  429 */     this.titleAnchor = anchor;
/*  430 */     fireChangeEvent();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Plot3D getPlot() {
/*  442 */     return this.plot;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Color getChartBoxColor() {
/*  455 */     return this.chartBoxColor;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setChartBoxColor(Color color) {
/*  468 */     ArgChecks.nullNotPermitted(color, "color");
/*  469 */     this.chartBoxColor = color;
/*  470 */     fireChangeEvent();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Dimension3D getDimensions() {
/*  480 */     return this.plot.getDimensions();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ViewPoint3D getViewPoint() {
/*  490 */     return this.viewPoint;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setViewPoint(ViewPoint3D viewPoint) {
/*  500 */     ArgChecks.nullNotPermitted(viewPoint, "viewPoint");
/*  501 */     this.viewPoint = viewPoint;
/*  502 */     fireChangeEvent();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public double getProjDistance() {
/*  516 */     return this.projDist;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setProjDistance(double dist) {
/*  529 */     this.projDist = dist;
/*  530 */     fireChangeEvent();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Offset2D getTranslate2D() {
/*  544 */     return this.translate2D;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTranslate2D(Offset2D offset) {
/*  555 */     ArgChecks.nullNotPermitted(offset, "offset");
/*  556 */     this.translate2D = offset;
/*  557 */     fireChangeEvent();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LegendBuilder getLegendBuilder() {
/*  571 */     return this.legendBuilder;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setLegendBuilder(LegendBuilder legendBuilder) {
/*  584 */     this.legendBuilder = legendBuilder;
/*  585 */     fireChangeEvent();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Anchor2D getLegendAnchor() {
/*  596 */     return this.legendAnchor;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setLegendAnchor(Anchor2D anchor) {
/*  609 */     ArgChecks.nullNotPermitted(anchor, "anchor");
/*  610 */     this.legendAnchor = anchor;
/*  611 */     fireChangeEvent();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Orientation getLegendOrientation() {
/*  622 */     return this.legendOrientation;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setLegendOrientation(Orientation orientation) {
/*  634 */     ArgChecks.nullNotPermitted(orientation, "orientation");
/*  635 */     this.legendOrientation = orientation;
/*  636 */     fireChangeEvent();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setLegendPosition(Anchor2D anchor, Orientation orientation) {
/*  653 */     setNotify(false);
/*  654 */     setLegendAnchor(anchor);
/*  655 */     setLegendOrientation(orientation);
/*  656 */     setNotify(true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public RenderingHints getRenderingHints() {
/*  669 */     return this.renderingHints;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setRenderingHints(RenderingHints hints) {
/*  687 */     ArgChecks.nullNotPermitted(hints, "hints");
/*  688 */     this.renderingHints = hints;
/*  689 */     fireChangeEvent();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getAntiAlias() {
/*  702 */     Object val = this.renderingHints.get(RenderingHints.KEY_ANTIALIASING);
/*  703 */     return RenderingHints.VALUE_ANTIALIAS_ON.equals(val);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAntiAlias(boolean flag) {
/*  718 */     if (flag) {
/*  719 */       this.renderingHints.put(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
/*      */     }
/*      */     else {
/*      */       
/*  723 */       this.renderingHints.put(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_OFF);
/*      */     } 
/*      */     
/*  726 */     fireChangeEvent();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getElementHinting() {
/*  739 */     return this.elementHinting;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setElementHinting(boolean hinting) {
/*  752 */     this.elementHinting = hinting;
/*  753 */     fireChangeEvent();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ChartStyle getStyle() {
/*  764 */     return this.style;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setStyle(ChartStyle style) {
/*  775 */     ArgChecks.nullNotPermitted(style, "style");
/*  776 */     this.style.removeChangeListener(this);
/*  777 */     this.style = style;
/*  778 */     this.style.addChangeListener(this);
/*  779 */     setNotify(false);
/*  780 */     receive((ChartElementVisitor)new ChartStyler(this.style));
/*  781 */     setNotify(true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private World createWorld(ChartBox3D chartBox) {
/*  790 */     World result = new World();
/*  791 */     Dimension3D dim = this.plot.getDimensions();
/*  792 */     double w = dim.getWidth();
/*  793 */     double h = dim.getHeight();
/*  794 */     double d = dim.getDepth();
/*  795 */     if (chartBox != null) {
/*  796 */       result.add("chartbox", chartBox.createObject3D());
/*      */     }
/*  798 */     this.plot.compose(result, -w / 2.0D, -h / 2.0D, -d / 2.0D);
/*  799 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public RenderingInfo draw(Graphics2D g2, Rectangle2D bounds) {
/*  811 */     beginElement(g2, this.id, "ORSON_CHART_TOP_LEVEL");
/*  812 */     Shape savedClip = g2.getClip();
/*  813 */     g2.clip(bounds);
/*  814 */     g2.addRenderingHints(this.renderingHints);
/*  815 */     g2.setStroke(new BasicStroke(1.5F, 1, 1, 1.0F));
/*      */     
/*  817 */     Dimension3D dim3D = this.plot.getDimensions();
/*  818 */     double w = dim3D.getWidth();
/*  819 */     double h = dim3D.getHeight();
/*  820 */     double depth = dim3D.getDepth();
/*  821 */     ChartBox3D chartBox = null;
/*  822 */     if (this.plot instanceof XYZPlot || this.plot instanceof CategoryPlot3D) {
/*      */       
/*  824 */       double[] tickUnits = findAxisTickUnits(g2, w, h, depth);
/*  825 */       chartBox = new ChartBox3D(w, h, depth, -w / 2.0D, -h / 2.0D, -depth / 2.0D, this.chartBoxColor);
/*      */       
/*  827 */       chartBox.setXTicks(fetchXTickData(this.plot, tickUnits[0]));
/*  828 */       chartBox.setYTicks(fetchYTickData(this.plot, tickUnits[1]));
/*  829 */       chartBox.setZTicks(fetchZTickData(this.plot, tickUnits[2]));
/*  830 */       chartBox.setXMarkers(fetchXMarkerData(this.plot));
/*  831 */       chartBox.setYMarkers(fetchYMarkerData(this.plot));
/*  832 */       chartBox.setZMarkers(fetchZMarkerData(this.plot));
/*      */     } 
/*  834 */     if (this.world == null) {
/*  835 */       this.world = createWorld(chartBox);
/*  836 */     } else if (chartBox != null) {
/*  837 */       this.world.clear("chartbox");
/*  838 */       this.world.add("chartbox", chartBox.createObject3D());
/*      */     } 
/*  840 */     if (this.background != null) {
/*  841 */       this.background.fill(g2, bounds);
/*      */     }
/*  843 */     AffineTransform saved = g2.getTransform();
/*  844 */     double dx = bounds.getWidth() / 2.0D + this.translate2D.getDX();
/*  845 */     double dy = bounds.getHeight() / 2.0D + this.translate2D.getDY();
/*  846 */     g2.translate(dx, dy);
/*  847 */     Point3D[] eyePts = this.world.calculateEyeCoordinates(this.viewPoint);
/*  848 */     Point2D[] pts = this.world.calculateProjectedPoints(this.viewPoint, this.projDist);
/*      */ 
/*      */ 
/*      */     
/*  852 */     List<Face> facesInPaintOrder = new ArrayList<Face>(this.world.getFaces());
/*  853 */     facesInPaintOrder = this.faceSorter.sort(facesInPaintOrder, eyePts);
/*  854 */     for (Face f : facesInPaintOrder) {
/*  855 */       boolean drawOutline = f.getOutline();
/*  856 */       double[] plane = f.calculateNormal(eyePts);
/*      */       
/*  858 */       double inprod = plane[0] * this.world.getSunX() + plane[1] * this.world.getSunY() + plane[2] * this.world.getSunZ();
/*  859 */       double shade = (inprod + 1.0D) / 2.0D;
/*  860 */       if (f instanceof com.orsoncharts.graphics3d.DoubleSidedFace || 
/*  861 */         Utils2D.area2(pts[f.getVertexIndex(0)], pts[f
/*  862 */             .getVertexIndex(1)], pts[f.getVertexIndex(2)]) > 0.0D) {
/*  863 */         Color c = f.getColor();
/*  864 */         if (c != null) {
/*  865 */           Path2D p = f.createPath(pts);
/*  866 */           g2.setPaint(new Color((int)(c.getRed() * shade), 
/*  867 */                 (int)(c.getGreen() * shade), 
/*  868 */                 (int)(c.getBlue() * shade), c.getAlpha()));
/*  869 */           if (this.elementHinting) {
/*  870 */             beginElementGroup(f, g2);
/*      */           }
/*  872 */           g2.fill(p);
/*  873 */           if (drawOutline) {
/*  874 */             g2.draw(p);
/*      */           }
/*  876 */           if (this.elementHinting) {
/*  877 */             endElementGroup(f, g2);
/*      */           }
/*      */         } 
/*      */         
/*  881 */         if (f instanceof ChartBox3D.ChartBoxFace && (this.plot instanceof CategoryPlot3D || this.plot instanceof XYZPlot)) {
/*      */ 
/*      */           
/*  884 */           Stroke savedStroke = g2.getStroke();
/*  885 */           ChartBox3D.ChartBoxFace cbf = (ChartBox3D.ChartBoxFace)f;
/*  886 */           drawGridlines(g2, cbf, pts);
/*  887 */           drawMarkers(g2, cbf, pts);
/*  888 */           g2.setStroke(savedStroke);
/*      */         }  continue;
/*  890 */       }  if (f instanceof LabelFace) {
/*  891 */         LabelFace lf = (LabelFace)f;
/*  892 */         Path2D p = lf.createPath(pts);
/*  893 */         Rectangle2D lb = p.getBounds2D();
/*  894 */         g2.setFont(lf.getFont());
/*  895 */         g2.setColor(lf.getBackgroundColor());
/*  896 */         Rectangle2D bb = TextUtils.calcAlignedStringBounds(lf
/*  897 */             .getLabel(), g2, 
/*  898 */             (float)lb.getCenterX(), (float)lb.getCenterY(), TextAnchor.CENTER);
/*      */         
/*  900 */         g2.fill(bb);
/*  901 */         g2.setColor(lf.getTextColor());
/*  902 */         Rectangle2D r = TextUtils.drawAlignedString(lf.getLabel(), g2, 
/*  903 */             (float)lb.getCenterX(), (float)lb.getCenterY(), TextAnchor.CENTER);
/*      */         
/*  905 */         lf.getOwner().setProperty("labelBounds", r);
/*      */       } 
/*      */     } 
/*  908 */     RenderingInfo info = new RenderingInfo(facesInPaintOrder, pts, dx, dy);
/*  909 */     OnDrawHandler onDrawHandler = new OnDrawHandler(info, this.elementHinting);
/*      */ 
/*      */ 
/*      */     
/*  913 */     if (this.plot instanceof PiePlot3D) {
/*  914 */       drawPieLabels(g2, w, h, depth, info);
/*      */     }
/*      */ 
/*      */     
/*  918 */     if (this.plot instanceof XYZPlot || this.plot instanceof CategoryPlot3D)
/*      */     {
/*  920 */       drawAxes(g2, chartBox, pts, info);
/*      */     }
/*      */     
/*  923 */     g2.setTransform(saved);
/*      */ 
/*      */     
/*  926 */     if (this.legendBuilder != null) {
/*  927 */       TableElement legend = this.legendBuilder.createLegend(this.plot, this.legendAnchor, this.legendOrientation, this.style);
/*      */       
/*  929 */       if (legend != null) {
/*      */         
/*  931 */         GridElement legend2 = new GridElement();
/*  932 */         legend2.setBackground(null);
/*  933 */         legend2.setElement(legend, "R1", "C1");
/*      */         
/*  935 */         TextElement te = new TextElement("Orson Charts (evaluation) (c) 2013, 2014, by Object Refinery Limited", this.style.getLegendFooterFont());
/*  936 */         te.setColor(this.style.getLegendFooterColor());
/*  937 */         te.setBackgroundColor(this.style.getLegendFooterBackgroundColor());
/*  938 */         te.setHorizontalAligment(HAlign.RIGHT);
/*  939 */         legend2.setElement((TableElement)te, "R2", "C1");
/*  940 */         GridElement gridElement1 = legend2;
/*      */         
/*  942 */         Dimension2D legendSize = gridElement1.preferredSize(g2, bounds);
/*  943 */         Rectangle2D legendArea = calculateDrawArea(legendSize, this.legendAnchor, bounds);
/*      */         
/*  945 */         gridElement1.draw(g2, legendArea, onDrawHandler);
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  950 */     if (this.title != null) {
/*  951 */       Dimension2D titleSize = this.title.preferredSize(g2, bounds);
/*  952 */       Rectangle2D titleArea = calculateDrawArea(titleSize, this.titleAnchor, bounds);
/*      */       
/*  954 */       this.title.draw(g2, titleArea, onDrawHandler);
/*      */     } 
/*  956 */     g2.setClip(savedClip);
/*  957 */     endElement(g2);
/*  958 */     return info;
/*      */   }
/*      */   
/*      */   private void beginElementGroup(Face face, Graphics2D g2) {
/*  962 */     Object3D owner = face.getOwner();
/*  963 */     ItemKey itemKey = (ItemKey)owner.getProperty("key");
/*  964 */     if (itemKey != null) {
/*  965 */       Map<Object, Object> m = new HashMap<Object, Object>();
/*  966 */       m.put("ref", itemKey.toJSONString());
/*  967 */       g2.setRenderingHint(Chart3DHints.KEY_BEGIN_ELEMENT, m);
/*      */     } 
/*      */   }
/*      */   
/*      */   private void endElementGroup(Face face, Graphics2D g2) {
/*  972 */     Object3D owner = face.getOwner();
/*  973 */     ItemKey itemKey = (ItemKey)owner.getProperty("key");
/*  974 */     if (itemKey != null) {
/*  975 */       g2.setRenderingHint(Chart3DHints.KEY_END_ELEMENT, Boolean.TRUE);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private List<TickData> fetchXTickData(Plot3D plot, double tickUnit) {
/*  992 */     if (plot instanceof CategoryPlot3D) {
/*  993 */       CategoryPlot3D cp = (CategoryPlot3D)plot;
/*  994 */       return cp.getColumnAxis().generateTickDataForColumns(cp
/*  995 */           .getDataset());
/*      */     } 
/*  997 */     if (plot instanceof XYZPlot) {
/*  998 */       XYZPlot xp = (XYZPlot)plot;
/*  999 */       return xp.getXAxis().generateTickData(tickUnit);
/*      */     } 
/* 1001 */     return Collections.emptyList();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private List<TickData> fetchYTickData(Plot3D plot, double tickUnit) {
/* 1016 */     if (plot instanceof CategoryPlot3D) {
/* 1017 */       CategoryPlot3D cp = (CategoryPlot3D)plot;
/* 1018 */       return cp.getValueAxis().generateTickData(tickUnit);
/*      */     } 
/* 1020 */     if (plot instanceof XYZPlot) {
/* 1021 */       XYZPlot xp = (XYZPlot)plot;
/* 1022 */       return xp.getYAxis().generateTickData(tickUnit);
/*      */     } 
/* 1024 */     return Collections.emptyList();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private List<TickData> fetchZTickData(Plot3D plot, double tickUnit) {
/* 1040 */     if (plot instanceof CategoryPlot3D) {
/* 1041 */       CategoryPlot3D cp = (CategoryPlot3D)plot;
/* 1042 */       return cp.getRowAxis().generateTickDataForRows(cp.getDataset());
/*      */     } 
/* 1044 */     if (plot instanceof XYZPlot) {
/* 1045 */       XYZPlot xp = (XYZPlot)plot;
/* 1046 */       return xp.getZAxis().generateTickData(tickUnit);
/*      */     } 
/* 1048 */     return Collections.emptyList();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private List<MarkerData> fetchXMarkerData(Plot3D plot) {
/* 1060 */     if (plot instanceof CategoryPlot3D) {
/* 1061 */       return ((CategoryPlot3D)plot).getColumnAxis().generateMarkerData();
/*      */     }
/* 1063 */     if (plot instanceof XYZPlot) {
/* 1064 */       return ((XYZPlot)plot).getXAxis().generateMarkerData();
/*      */     }
/* 1066 */     return new ArrayList<MarkerData>(0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private List<MarkerData> fetchYMarkerData(Plot3D plot) {
/* 1078 */     if (plot instanceof CategoryPlot3D) {
/* 1079 */       return ((CategoryPlot3D)plot).getValueAxis().generateMarkerData();
/*      */     }
/* 1081 */     if (plot instanceof XYZPlot) {
/* 1082 */       return ((XYZPlot)plot).getYAxis().generateMarkerData();
/*      */     }
/* 1084 */     return new ArrayList<MarkerData>(0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private List<MarkerData> fetchZMarkerData(Plot3D plot) {
/* 1096 */     if (plot instanceof CategoryPlot3D) {
/* 1097 */       return ((CategoryPlot3D)plot).getRowAxis().generateMarkerData();
/*      */     }
/* 1099 */     if (plot instanceof XYZPlot) {
/* 1100 */       return ((XYZPlot)plot).getZAxis().generateMarkerData();
/*      */     }
/* 1102 */     return new ArrayList<MarkerData>(0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void drawGridlines(Graphics2D g2, ChartBox3D.ChartBoxFace face, Point2D[] pts) {
/* 1114 */     if (isGridlinesVisibleForX(this.plot)) {
/* 1115 */       g2.setPaint(fetchGridlinePaintX(this.plot));
/* 1116 */       g2.setStroke(fetchGridlineStrokeX(this.plot));
/* 1117 */       List<TickData> xA = face.getXTicksA();
/* 1118 */       List<TickData> xB = face.getXTicksB();
/* 1119 */       for (int i = 0; i < xA.size(); i++) {
/*      */ 
/*      */         
/* 1122 */         Line2D line = new Line2D.Double(pts[face.getOffset() + ((TickData)xA.get(i)).getVertexIndex()], pts[face.getOffset() + ((TickData)xB.get(i)).getVertexIndex()]);
/* 1123 */         g2.draw(line);
/*      */       } 
/*      */     } 
/*      */     
/* 1127 */     if (isGridlinesVisibleForY(this.plot)) {
/* 1128 */       g2.setPaint(fetchGridlinePaintY(this.plot));
/* 1129 */       g2.setStroke(fetchGridlineStrokeY(this.plot));
/* 1130 */       List<TickData> yA = face.getYTicksA();
/* 1131 */       List<TickData> yB = face.getYTicksB();
/* 1132 */       for (int i = 0; i < yA.size(); i++) {
/*      */ 
/*      */         
/* 1135 */         Line2D line = new Line2D.Double(pts[face.getOffset() + ((TickData)yA.get(i)).getVertexIndex()], pts[face.getOffset() + ((TickData)yB.get(i)).getVertexIndex()]);
/* 1136 */         g2.draw(line);
/*      */       } 
/*      */     } 
/*      */     
/* 1140 */     if (isGridlinesVisibleForZ(this.plot)) {
/* 1141 */       g2.setPaint(fetchGridlinePaintZ(this.plot));
/* 1142 */       g2.setStroke(fetchGridlineStrokeZ(this.plot));
/* 1143 */       List<TickData> zA = face.getZTicksA();
/* 1144 */       List<TickData> zB = face.getZTicksB();
/* 1145 */       for (int i = 0; i < zA.size(); i++) {
/*      */ 
/*      */         
/* 1148 */         Line2D line = new Line2D.Double(pts[face.getOffset() + ((TickData)zA.get(i)).getVertexIndex()], pts[face.getOffset() + ((TickData)zB.get(i)).getVertexIndex()]);
/* 1149 */         g2.draw(line);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean isGridlinesVisibleForX(Plot3D plot) {
/* 1165 */     if (plot instanceof CategoryPlot3D) {
/* 1166 */       CategoryPlot3D cp = (CategoryPlot3D)plot;
/* 1167 */       return cp.getGridlinesVisibleForColumns();
/*      */     } 
/* 1169 */     if (plot instanceof XYZPlot) {
/* 1170 */       XYZPlot xp = (XYZPlot)plot;
/* 1171 */       return xp.isGridlinesVisibleX();
/*      */     } 
/* 1173 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean isGridlinesVisibleForY(Plot3D plot) {
/* 1186 */     if (plot instanceof CategoryPlot3D) {
/* 1187 */       CategoryPlot3D cp = (CategoryPlot3D)plot;
/* 1188 */       return cp.getGridlinesVisibleForValues();
/*      */     } 
/* 1190 */     if (plot instanceof XYZPlot) {
/* 1191 */       XYZPlot xp = (XYZPlot)plot;
/* 1192 */       return xp.isGridlinesVisibleY();
/*      */     } 
/* 1194 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean isGridlinesVisibleForZ(Plot3D plot) {
/* 1207 */     if (plot instanceof CategoryPlot3D) {
/* 1208 */       CategoryPlot3D cp = (CategoryPlot3D)plot;
/* 1209 */       return cp.getGridlinesVisibleForRows();
/*      */     } 
/* 1211 */     if (plot instanceof XYZPlot) {
/* 1212 */       XYZPlot xp = (XYZPlot)plot;
/* 1213 */       return xp.isGridlinesVisibleZ();
/*      */     } 
/* 1215 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Paint fetchGridlinePaintX(Plot3D plot) {
/* 1227 */     if (plot instanceof CategoryPlot3D) {
/* 1228 */       CategoryPlot3D cp = (CategoryPlot3D)plot;
/* 1229 */       return cp.getGridlinePaintForColumns();
/*      */     } 
/* 1231 */     if (plot instanceof XYZPlot) {
/* 1232 */       XYZPlot xp = (XYZPlot)plot;
/* 1233 */       return xp.getGridlinePaintX();
/*      */     } 
/* 1235 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Paint fetchGridlinePaintY(Plot3D plot) {
/* 1247 */     if (plot instanceof CategoryPlot3D) {
/* 1248 */       CategoryPlot3D cp = (CategoryPlot3D)plot;
/* 1249 */       return cp.getGridlinePaintForValues();
/*      */     } 
/* 1251 */     if (plot instanceof XYZPlot) {
/* 1252 */       XYZPlot xp = (XYZPlot)plot;
/* 1253 */       return xp.getGridlinePaintY();
/*      */     } 
/* 1255 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Paint fetchGridlinePaintZ(Plot3D plot) {
/* 1267 */     if (plot instanceof CategoryPlot3D) {
/* 1268 */       CategoryPlot3D cp = (CategoryPlot3D)plot;
/* 1269 */       return cp.getGridlinePaintForRows();
/*      */     } 
/* 1271 */     if (plot instanceof XYZPlot) {
/* 1272 */       XYZPlot xp = (XYZPlot)plot;
/* 1273 */       return xp.getGridlinePaintZ();
/*      */     } 
/* 1275 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Stroke fetchGridlineStrokeX(Plot3D plot) {
/* 1287 */     if (plot instanceof CategoryPlot3D) {
/* 1288 */       CategoryPlot3D cp = (CategoryPlot3D)plot;
/* 1289 */       return cp.getGridlineStrokeForColumns();
/*      */     } 
/* 1291 */     if (plot instanceof XYZPlot) {
/* 1292 */       XYZPlot xp = (XYZPlot)plot;
/* 1293 */       return xp.getGridlineStrokeX();
/*      */     } 
/* 1295 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Stroke fetchGridlineStrokeY(Plot3D plot) {
/* 1307 */     if (plot instanceof CategoryPlot3D) {
/* 1308 */       CategoryPlot3D cp = (CategoryPlot3D)plot;
/* 1309 */       return cp.getGridlineStrokeForValues();
/*      */     } 
/* 1311 */     if (plot instanceof XYZPlot) {
/* 1312 */       XYZPlot xp = (XYZPlot)plot;
/* 1313 */       return xp.getGridlineStrokeY();
/*      */     } 
/* 1315 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Stroke fetchGridlineStrokeZ(Plot3D plot) {
/* 1327 */     if (plot instanceof CategoryPlot3D) {
/* 1328 */       CategoryPlot3D cp = (CategoryPlot3D)plot;
/* 1329 */       return cp.getGridlineStrokeForRows();
/*      */     } 
/* 1331 */     if (plot instanceof XYZPlot) {
/* 1332 */       XYZPlot xp = (XYZPlot)plot;
/* 1333 */       return xp.getGridlineStrokeZ();
/*      */     } 
/* 1335 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void drawPieLabels(Graphics2D g2, double w, double h, double depth, RenderingInfo info) {
/* 1351 */     PiePlot3D p = (PiePlot3D)this.plot;
/* 1352 */     World labelOverlay = new World();
/* 1353 */     List<Object3D> objs = p.getLabelFaces(-w / 2.0D, -h / 2.0D, -depth / 2.0D);
/* 1354 */     for (Object3D obj : objs) {
/* 1355 */       labelOverlay.add(obj);
/*      */     }
/* 1357 */     Point2D[] ppts = labelOverlay.calculateProjectedPoints(this.viewPoint, this.projDist);
/*      */     
/* 1359 */     for (int i = 0; i < p.getDataset().getItemCount() * 2; i++) {
/* 1360 */       if (p.getDataset().getValue(i / 2) != null) {
/*      */ 
/*      */         
/* 1363 */         Face f = labelOverlay.getFaces().get(i);
/* 1364 */         if (Utils2D.area2(ppts[f.getVertexIndex(0)], ppts[f
/* 1365 */               .getVertexIndex(1)], ppts[f
/* 1366 */               .getVertexIndex(2)]) > 0.0D) {
/* 1367 */           Comparable<?> key = p.getDataset().getKey(i / 2);
/* 1368 */           g2.setColor(p.getSectionLabelColorSource().getColor(key));
/* 1369 */           g2.setFont(p.getSectionLabelFontSource().getFont(key));
/* 1370 */           Point2D pt = Utils2D.centerPoint(ppts[f.getVertexIndex(0)], ppts[f
/* 1371 */                 .getVertexIndex(1)], ppts[f.getVertexIndex(2)], ppts[f
/* 1372 */                 .getVertexIndex(3)]);
/* 1373 */           String label = p.getSectionLabelGenerator().generateLabel(p
/* 1374 */               .getDataset(), key);
/*      */           
/* 1376 */           String ref = "{\"type\": \"sectionLabel\", \"key\": \"" + key.toString() + "\"}";
/* 1377 */           beginElementWithRef(g2, ref);
/* 1378 */           Rectangle2D bounds = TextUtils.drawAlignedString(label, g2, 
/* 1379 */               (float)pt.getX(), (float)pt.getY(), TextAnchor.CENTER);
/*      */           
/* 1381 */           endElement(g2);
/*      */           
/* 1383 */           if (info != null) {
/* 1384 */             RenderedElement pieLabelRE = new RenderedElement(InteractiveElementType.SECTION_LABEL, bounds);
/*      */             
/* 1386 */             pieLabelRE.setProperty("key", key);
/* 1387 */             info.addOffsetElement(pieLabelRE);
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */   private void beginElementWithRef(Graphics2D g2, String ref) {
/* 1394 */     beginElement(g2, null, ref);
/*      */   }
/*      */   
/*      */   private void beginElement(Graphics2D g2, String id, String ref) {
/* 1398 */     if (this.elementHinting) {
/* 1399 */       Map<Object, Object> m = new HashMap<Object, Object>();
/* 1400 */       if (id != null) {
/* 1401 */         m.put("id", id);
/*      */       }
/* 1403 */       m.put("ref", ref);
/* 1404 */       g2.setRenderingHint(Chart3DHints.KEY_BEGIN_ELEMENT, m);
/*      */     } 
/*      */   }
/*      */   
/*      */   private void endElement(Graphics2D g2) {
/* 1409 */     if (this.elementHinting) {
/* 1410 */       g2.setRenderingHint(Chart3DHints.KEY_END_ELEMENT, Boolean.TRUE);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private double[] findAxisTickUnits(Graphics2D g2, double w, double h, double depth) {
/*      */     CategoryAxis3D categoryAxis3D1, categoryAxis3D2;
/* 1426 */     World tempWorld = new World();
/* 1427 */     ChartBox3D chartBox = new ChartBox3D(w, h, depth, -w / 2.0D, -h / 2.0D, -depth / 2.0D, Color.WHITE);
/*      */     
/* 1429 */     tempWorld.add(chartBox.createObject3D());
/* 1430 */     Point2D[] axisPts2D = tempWorld.calculateProjectedPoints(this.viewPoint, this.projDist);
/*      */ 
/*      */ 
/*      */     
/* 1434 */     Point2D v0 = axisPts2D[0];
/* 1435 */     Point2D v1 = axisPts2D[1];
/* 1436 */     Point2D v2 = axisPts2D[2];
/* 1437 */     Point2D v3 = axisPts2D[3];
/* 1438 */     Point2D v4 = axisPts2D[4];
/* 1439 */     Point2D v5 = axisPts2D[5];
/* 1440 */     Point2D v6 = axisPts2D[6];
/* 1441 */     Point2D v7 = axisPts2D[7];
/*      */ 
/*      */     
/* 1444 */     boolean a = chartBox.faceA().isFrontFacing(axisPts2D);
/* 1445 */     boolean b = chartBox.faceB().isFrontFacing(axisPts2D);
/* 1446 */     boolean c = chartBox.faceC().isFrontFacing(axisPts2D);
/* 1447 */     boolean d = chartBox.faceD().isFrontFacing(axisPts2D);
/* 1448 */     boolean e = chartBox.faceE().isFrontFacing(axisPts2D);
/* 1449 */     boolean f = chartBox.faceF().isFrontFacing(axisPts2D);
/*      */     
/* 1451 */     double xtick = 0.0D, ytick = 0.0D, ztick = 0.0D;
/* 1452 */     Axis3D xAxis = null;
/* 1453 */     ValueAxis3D yAxis = null;
/* 1454 */     Axis3D zAxis = null;
/* 1455 */     if (this.plot instanceof XYZPlot) {
/* 1456 */       XYZPlot pp = (XYZPlot)this.plot;
/* 1457 */       ValueAxis3D valueAxis3D1 = pp.getXAxis();
/* 1458 */       yAxis = pp.getYAxis();
/* 1459 */       ValueAxis3D valueAxis3D2 = pp.getZAxis();
/* 1460 */     } else if (this.plot instanceof CategoryPlot3D) {
/* 1461 */       CategoryPlot3D pp = (CategoryPlot3D)this.plot;
/* 1462 */       categoryAxis3D1 = pp.getColumnAxis();
/* 1463 */       yAxis = pp.getValueAxis();
/* 1464 */       categoryAxis3D2 = pp.getRowAxis();
/*      */     } 
/*      */     
/* 1467 */     if (categoryAxis3D1 != null && yAxis != null && categoryAxis3D2 != null) {
/* 1468 */       double ab = (count(a, b) == 1) ? v0.distance(v1) : 0.0D;
/* 1469 */       double bc = (count(b, c) == 1) ? v3.distance(v2) : 0.0D;
/* 1470 */       double cd = (count(c, d) == 1) ? v4.distance(v7) : 0.0D;
/* 1471 */       double da = (count(d, a) == 1) ? v5.distance(v6) : 0.0D;
/* 1472 */       double be = (count(b, e) == 1) ? v0.distance(v3) : 0.0D;
/* 1473 */       double bf = (count(b, f) == 1) ? v1.distance(v2) : 0.0D;
/* 1474 */       double df = (count(d, f) == 1) ? v6.distance(v7) : 0.0D;
/* 1475 */       double de = (count(d, e) == 1) ? v5.distance(v4) : 0.0D;
/* 1476 */       double ae = (count(a, e) == 1) ? v0.distance(v5) : 0.0D;
/* 1477 */       double af = (count(a, f) == 1) ? v1.distance(v6) : 0.0D;
/* 1478 */       double cf = (count(c, f) == 1) ? v2.distance(v7) : 0.0D;
/* 1479 */       double ce = (count(c, e) == 1) ? v3.distance(v4) : 0.0D;
/*      */       
/* 1481 */       if (count(a, b) == 1 && longest(ab, bc, cd, da) && 
/* 1482 */         categoryAxis3D1 instanceof ValueAxis3D) {
/* 1483 */         xtick = ((ValueAxis3D)categoryAxis3D1).selectTick(g2, v0, v1, v7);
/*      */       }
/*      */       
/* 1486 */       if (count(b, c) == 1 && longest(bc, ab, cd, da) && 
/* 1487 */         categoryAxis3D1 instanceof ValueAxis3D) {
/* 1488 */         xtick = ((ValueAxis3D)categoryAxis3D1).selectTick(g2, v3, v2, v6);
/*      */       }
/*      */       
/* 1491 */       if (count(c, d) == 1 && longest(cd, ab, bc, da) && 
/* 1492 */         categoryAxis3D1 instanceof ValueAxis3D) {
/* 1493 */         xtick = ((ValueAxis3D)categoryAxis3D1).selectTick(g2, v4, v7, v1);
/*      */       }
/*      */       
/* 1496 */       if (count(d, a) == 1 && longest(da, ab, bc, cd) && 
/* 1497 */         categoryAxis3D1 instanceof ValueAxis3D) {
/* 1498 */         xtick = ((ValueAxis3D)categoryAxis3D1).selectTick(g2, v5, v6, v3);
/*      */       }
/*      */ 
/*      */       
/* 1502 */       if (count(b, e) == 1 && longest(be, bf, df, de)) {
/* 1503 */         ytick = yAxis.selectTick(g2, v0, v3, v7);
/*      */       }
/* 1505 */       if (count(b, f) == 1 && longest(bf, be, df, de)) {
/* 1506 */         ytick = yAxis.selectTick(g2, v1, v2, v4);
/*      */       }
/* 1508 */       if (count(d, f) == 1 && longest(df, be, bf, de)) {
/* 1509 */         ytick = yAxis.selectTick(g2, v6, v7, v0);
/*      */       }
/* 1511 */       if (count(d, e) == 1 && longest(de, be, bf, df)) {
/* 1512 */         ytick = yAxis.selectTick(g2, v5, v4, v1);
/*      */       }
/*      */       
/* 1515 */       if (count(a, e) == 1 && longest(ae, af, cf, ce) && 
/* 1516 */         categoryAxis3D2 instanceof ValueAxis3D) {
/* 1517 */         ztick = ((ValueAxis3D)categoryAxis3D2).selectTick(g2, v0, v5, v2);
/*      */       }
/*      */       
/* 1520 */       if (count(a, f) == 1 && longest(af, ae, cf, ce) && 
/* 1521 */         categoryAxis3D2 instanceof ValueAxis3D) {
/* 1522 */         ztick = ((ValueAxis3D)categoryAxis3D2).selectTick(g2, v1, v6, v3);
/*      */       }
/*      */       
/* 1525 */       if (count(c, f) == 1 && longest(cf, ae, af, ce) && 
/* 1526 */         categoryAxis3D2 instanceof ValueAxis3D) {
/* 1527 */         ztick = ((ValueAxis3D)categoryAxis3D2).selectTick(g2, v2, v7, v5);
/*      */       }
/*      */       
/* 1530 */       if (count(c, e) == 1 && longest(ce, ae, af, cf) && 
/* 1531 */         categoryAxis3D2 instanceof ValueAxis3D) {
/* 1532 */         ztick = ((ValueAxis3D)categoryAxis3D2).selectTick(g2, v3, v4, v6);
/*      */       }
/*      */     } 
/*      */     
/* 1536 */     return new double[] { xtick, ytick, ztick };
/*      */   }
/*      */   
/*      */   private void populateAnchorPoints(List<TickData> tickData, Point2D[] pts) {
/* 1540 */     for (TickData t : tickData) {
/* 1541 */       t.setAnchorPt(pts[t.getVertexIndex()]);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void drawAxes(Graphics2D g2, ChartBox3D chartBox, Point2D[] pts, RenderingInfo info) {
/*      */     CategoryAxis3D categoryAxis3D1;
/*      */     ValueAxis3D valueAxis3D;
/*      */     CategoryAxis3D categoryAxis3D2;
/* 1559 */     Point2D v0 = pts[0];
/* 1560 */     Point2D v1 = pts[1];
/* 1561 */     Point2D v2 = pts[2];
/* 1562 */     Point2D v3 = pts[3];
/* 1563 */     Point2D v4 = pts[4];
/* 1564 */     Point2D v5 = pts[5];
/* 1565 */     Point2D v6 = pts[6];
/* 1566 */     Point2D v7 = pts[7];
/*      */ 
/*      */     
/* 1569 */     boolean a = chartBox.faceA().isFrontFacing(pts);
/* 1570 */     boolean b = chartBox.faceB().isFrontFacing(pts);
/* 1571 */     boolean c = chartBox.faceC().isFrontFacing(pts);
/* 1572 */     boolean d = chartBox.faceD().isFrontFacing(pts);
/* 1573 */     boolean e = chartBox.faceE().isFrontFacing(pts);
/* 1574 */     boolean f = chartBox.faceF().isFrontFacing(pts);
/*      */     
/* 1576 */     Axis3D xAxis = null, yAxis = null, zAxis = null;
/* 1577 */     if (this.plot instanceof XYZPlot) {
/* 1578 */       XYZPlot pp = (XYZPlot)this.plot;
/* 1579 */       ValueAxis3D valueAxis3D1 = pp.getXAxis();
/* 1580 */       valueAxis3D = pp.getYAxis();
/* 1581 */       ValueAxis3D valueAxis3D2 = pp.getZAxis();
/* 1582 */     } else if (this.plot instanceof CategoryPlot3D) {
/* 1583 */       CategoryPlot3D pp = (CategoryPlot3D)this.plot;
/* 1584 */       categoryAxis3D1 = pp.getColumnAxis();
/* 1585 */       valueAxis3D = pp.getValueAxis();
/* 1586 */       categoryAxis3D2 = pp.getRowAxis();
/*      */     } 
/*      */     
/* 1589 */     if (categoryAxis3D1 != null && valueAxis3D != null && categoryAxis3D2 != null) {
/* 1590 */       double ab = (count(a, b) == 1) ? v0.distance(v1) : 0.0D;
/* 1591 */       double bc = (count(b, c) == 1) ? v3.distance(v2) : 0.0D;
/* 1592 */       double cd = (count(c, d) == 1) ? v4.distance(v7) : 0.0D;
/* 1593 */       double da = (count(d, a) == 1) ? v5.distance(v6) : 0.0D;
/* 1594 */       double be = (count(b, e) == 1) ? v0.distance(v3) : 0.0D;
/* 1595 */       double bf = (count(b, f) == 1) ? v1.distance(v2) : 0.0D;
/* 1596 */       double df = (count(d, f) == 1) ? v6.distance(v7) : 0.0D;
/* 1597 */       double de = (count(d, e) == 1) ? v5.distance(v4) : 0.0D;
/* 1598 */       double ae = (count(a, e) == 1) ? v0.distance(v5) : 0.0D;
/* 1599 */       double af = (count(a, f) == 1) ? v1.distance(v6) : 0.0D;
/* 1600 */       double cf = (count(c, f) == 1) ? v2.distance(v7) : 0.0D;
/* 1601 */       double ce = (count(c, e) == 1) ? v3.distance(v4) : 0.0D;
/*      */ 
/*      */       
/* 1604 */       if (count(a, b) == 1 && longest(ab, bc, cd, da)) {
/* 1605 */         List<TickData> ticks = chartBox.faceA().getXTicksA();
/* 1606 */         populateAnchorPoints(ticks, pts);
/* 1607 */         categoryAxis3D1.draw(g2, v0, v1, v7, ticks, info, this.elementHinting);
/*      */       } 
/* 1609 */       if (count(b, c) == 1 && longest(bc, ab, cd, da)) {
/* 1610 */         List<TickData> ticks = chartBox.faceB().getXTicksB();
/* 1611 */         populateAnchorPoints(ticks, pts);
/* 1612 */         categoryAxis3D1.draw(g2, v3, v2, v6, ticks, info, this.elementHinting);
/*      */       } 
/* 1614 */       if (count(c, d) == 1 && longest(cd, ab, bc, da)) {
/* 1615 */         List<TickData> ticks = chartBox.faceC().getXTicksB();
/* 1616 */         populateAnchorPoints(ticks, pts);
/* 1617 */         categoryAxis3D1.draw(g2, v4, v7, v1, ticks, info, this.elementHinting);
/*      */       } 
/* 1619 */       if (count(d, a) == 1 && longest(da, ab, bc, cd)) {
/* 1620 */         List<TickData> ticks = chartBox.faceA().getXTicksB();
/* 1621 */         populateAnchorPoints(ticks, pts);
/* 1622 */         categoryAxis3D1.draw(g2, v5, v6, v3, ticks, info, this.elementHinting);
/*      */       } 
/*      */       
/* 1625 */       if (count(b, e) == 1 && longest(be, bf, df, de)) {
/* 1626 */         List<TickData> ticks = chartBox.faceB().getYTicksA();
/* 1627 */         populateAnchorPoints(ticks, pts);
/* 1628 */         valueAxis3D.draw(g2, v0, v3, v7, ticks, info, this.elementHinting);
/*      */       } 
/* 1630 */       if (count(b, f) == 1 && longest(bf, be, df, de)) {
/* 1631 */         List<TickData> ticks = chartBox.faceB().getYTicksB();
/* 1632 */         populateAnchorPoints(ticks, pts);
/* 1633 */         valueAxis3D.draw(g2, v1, v2, v4, ticks, info, this.elementHinting);
/*      */       } 
/* 1635 */       if (count(d, f) == 1 && longest(df, be, bf, de)) {
/* 1636 */         List<TickData> ticks = chartBox.faceD().getYTicksA();
/* 1637 */         populateAnchorPoints(ticks, pts);
/* 1638 */         valueAxis3D.draw(g2, v6, v7, v0, ticks, info, this.elementHinting);
/*      */       } 
/* 1640 */       if (count(d, e) == 1 && longest(de, be, bf, df)) {
/* 1641 */         List<TickData> ticks = chartBox.faceD().getYTicksB();
/* 1642 */         populateAnchorPoints(ticks, pts);
/* 1643 */         valueAxis3D.draw(g2, v5, v4, v1, ticks, info, this.elementHinting);
/*      */       } 
/*      */       
/* 1646 */       if (count(a, e) == 1 && longest(ae, af, cf, ce)) {
/* 1647 */         List<TickData> ticks = chartBox.faceA().getZTicksA();
/* 1648 */         populateAnchorPoints(ticks, pts);
/* 1649 */         categoryAxis3D2.draw(g2, v0, v5, v2, ticks, info, this.elementHinting);
/*      */       } 
/* 1651 */       if (count(a, f) == 1 && longest(af, ae, cf, ce)) {
/* 1652 */         List<TickData> ticks = chartBox.faceA().getZTicksB();
/* 1653 */         populateAnchorPoints(ticks, pts);
/* 1654 */         categoryAxis3D2.draw(g2, v1, v6, v3, ticks, info, this.elementHinting);
/*      */       } 
/* 1656 */       if (count(c, f) == 1 && longest(cf, ae, af, ce)) {
/* 1657 */         List<TickData> ticks = chartBox.faceC().getZTicksB();
/* 1658 */         populateAnchorPoints(ticks, pts);
/* 1659 */         categoryAxis3D2.draw(g2, v2, v7, v5, ticks, info, this.elementHinting);
/*      */       } 
/* 1661 */       if (count(c, e) == 1 && longest(ce, ae, af, cf)) {
/* 1662 */         List<TickData> ticks = chartBox.faceC().getZTicksA();
/* 1663 */         populateAnchorPoints(ticks, pts);
/* 1664 */         categoryAxis3D2.draw(g2, v3, v4, v6, ticks, info, this.elementHinting);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void drawMarkers(Graphics2D g2, ChartBox3D.ChartBoxFace face, Point2D[] pts) {
/* 1680 */     List<MarkerData> xmarkers = face.getXMarkers();
/* 1681 */     for (MarkerData m : xmarkers) {
/* 1682 */       m.updateProjection(pts);
/* 1683 */       Marker marker = fetchXMarker(this.plot, m.getMarkerKey());
/* 1684 */       beginElementWithRef(g2, "{\"type\": \"xMarker\", \"key\": \"" + m
/* 1685 */           .getMarkerKey() + "\"}");
/* 1686 */       marker.draw(g2, m, true);
/* 1687 */       endElement(g2);
/*      */     } 
/*      */ 
/*      */     
/* 1691 */     List<MarkerData> ymarkers = face.getYMarkers();
/* 1692 */     for (MarkerData m : ymarkers) {
/* 1693 */       m.updateProjection(pts);
/* 1694 */       Marker marker = fetchYMarker(this.plot, m.getMarkerKey());
/* 1695 */       beginElementWithRef(g2, "{\"type\": \"yMarker\", \"key\": \"" + m
/* 1696 */           .getMarkerKey() + "\"}");
/* 1697 */       marker.draw(g2, m, false);
/* 1698 */       endElement(g2);
/*      */     } 
/*      */ 
/*      */     
/* 1702 */     List<MarkerData> zmarkers = face.getZMarkers();
/* 1703 */     for (MarkerData m : zmarkers) {
/* 1704 */       m.updateProjection(pts);
/* 1705 */       beginElementWithRef(g2, "{\"type\": \"zMarker\", \"key\": \"" + m
/* 1706 */           .getMarkerKey() + "\"}");
/* 1707 */       Marker marker = fetchZMarker(this.plot, m.getMarkerKey());
/* 1708 */       marker.draw(g2, m, false);
/* 1709 */       endElement(g2);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Marker fetchXMarker(Plot3D plot, String key) {
/* 1723 */     if (plot instanceof CategoryPlot3D)
/* 1724 */       return (Marker)((CategoryPlot3D)plot).getColumnAxis().getMarker(key); 
/* 1725 */     if (plot instanceof XYZPlot) {
/* 1726 */       return (Marker)((XYZPlot)plot).getXAxis().getMarker(key);
/*      */     }
/* 1728 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Marker fetchYMarker(Plot3D plot, String key) {
/* 1741 */     if (plot instanceof CategoryPlot3D)
/* 1742 */       return (Marker)((CategoryPlot3D)plot).getValueAxis().getMarker(key); 
/* 1743 */     if (plot instanceof XYZPlot) {
/* 1744 */       return (Marker)((XYZPlot)plot).getYAxis().getMarker(key);
/*      */     }
/* 1746 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Marker fetchZMarker(Plot3D plot, String key) {
/* 1759 */     if (plot instanceof CategoryPlot3D)
/* 1760 */       return (Marker)((CategoryPlot3D)plot).getRowAxis().getMarker(key); 
/* 1761 */     if (plot instanceof XYZPlot) {
/* 1762 */       return (Marker)((XYZPlot)plot).getZAxis().getMarker(key);
/*      */     }
/* 1764 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void receive(ChartElementVisitor visitor) {
/* 1777 */     this.plot.receive(visitor);
/* 1778 */     visitor.visit(this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean equals(Object obj) {
/* 1790 */     if (obj == this) {
/* 1791 */       return true;
/*      */     }
/* 1793 */     if (!(obj instanceof Chart3D)) {
/* 1794 */       return false;
/*      */     }
/* 1796 */     Chart3D that = (Chart3D)obj;
/* 1797 */     if (!ObjectUtils.equals(this.background, that.background)) {
/* 1798 */       return false;
/*      */     }
/* 1800 */     if (!ObjectUtils.equals(this.title, that.title)) {
/* 1801 */       return false;
/*      */     }
/* 1803 */     if (!this.titleAnchor.equals(that.titleAnchor)) {
/* 1804 */       return false;
/*      */     }
/* 1806 */     if (!ObjectUtils.equalsPaint(this.chartBoxColor, that.chartBoxColor)) {
/* 1807 */       return false;
/*      */     }
/* 1809 */     if (!ObjectUtils.equals(this.legendBuilder, that.legendBuilder)) {
/* 1810 */       return false;
/*      */     }
/* 1812 */     if (!this.legendAnchor.equals(that.legendAnchor)) {
/* 1813 */       return false;
/*      */     }
/* 1815 */     if (this.legendOrientation != that.legendOrientation) {
/* 1816 */       return false;
/*      */     }
/* 1818 */     if (!this.renderingHints.equals(that.renderingHints)) {
/* 1819 */       return false;
/*      */     }
/* 1821 */     if (this.projDist != that.projDist) {
/* 1822 */       return false;
/*      */     }
/* 1824 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Rectangle2D calculateDrawArea(Dimension2D dim, Anchor2D anchor, Rectangle2D bounds) {
/*      */     double x, y;
/* 1840 */     ArgChecks.nullNotPermitted(dim, "dim");
/* 1841 */     ArgChecks.nullNotPermitted(anchor, "anchor");
/* 1842 */     ArgChecks.nullNotPermitted(bounds, "bounds");
/*      */     
/* 1844 */     double w = Math.min(dim.getWidth(), bounds.getWidth());
/* 1845 */     double h = Math.min(dim.getHeight(), bounds.getHeight());
/* 1846 */     if (anchor.getRefPt().equals(RefPt2D.CENTER)) {
/* 1847 */       x = bounds.getCenterX() - w / 2.0D;
/* 1848 */       y = bounds.getCenterY() - h / 2.0D;
/* 1849 */     } else if (anchor.getRefPt().equals(RefPt2D.CENTER_LEFT)) {
/* 1850 */       x = bounds.getX() + anchor.getOffset().getDX();
/* 1851 */       y = bounds.getCenterY() - h / 2.0D;
/* 1852 */     } else if (anchor.getRefPt().equals(RefPt2D.CENTER_RIGHT)) {
/* 1853 */       x = bounds.getMaxX() - anchor.getOffset().getDX() - dim.getWidth();
/* 1854 */       y = bounds.getCenterY() - h / 2.0D;
/* 1855 */     } else if (anchor.getRefPt().equals(RefPt2D.TOP_CENTER)) {
/* 1856 */       x = bounds.getCenterX() - w / 2.0D;
/* 1857 */       y = bounds.getY() + anchor.getOffset().getDY();
/* 1858 */     } else if (anchor.getRefPt().equals(RefPt2D.TOP_LEFT)) {
/* 1859 */       x = bounds.getX() + anchor.getOffset().getDX();
/* 1860 */       y = bounds.getY() + anchor.getOffset().getDY();
/* 1861 */     } else if (anchor.getRefPt().equals(RefPt2D.TOP_RIGHT)) {
/* 1862 */       x = bounds.getMaxX() - anchor.getOffset().getDX() - dim.getWidth();
/* 1863 */       y = bounds.getY() + anchor.getOffset().getDY();
/* 1864 */     } else if (anchor.getRefPt().equals(RefPt2D.BOTTOM_CENTER)) {
/* 1865 */       x = bounds.getCenterX() - w / 2.0D;
/* 1866 */       y = bounds.getMaxY() - anchor.getOffset().getDY() - dim.getHeight();
/* 1867 */     } else if (anchor.getRefPt().equals(RefPt2D.BOTTOM_RIGHT)) {
/* 1868 */       x = bounds.getMaxX() - anchor.getOffset().getDX() - dim.getWidth();
/* 1869 */       y = bounds.getMaxY() - anchor.getOffset().getDY() - dim.getHeight();
/* 1870 */     } else if (anchor.getRefPt().equals(RefPt2D.BOTTOM_LEFT)) {
/* 1871 */       x = bounds.getX() + anchor.getOffset().getDX();
/* 1872 */       y = bounds.getMaxY() - anchor.getOffset().getDY() - dim.getHeight();
/*      */     } else {
/* 1874 */       x = 0.0D;
/* 1875 */       y = 0.0D;
/*      */     } 
/* 1877 */     return new Rectangle2D.Double(x, y, w, h);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean longest(double x, double a, double b, double c) {
/* 1892 */     return (x >= a && x >= b && x >= c);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int count(boolean a, boolean b) {
/* 1907 */     int result = 0;
/* 1908 */     if (a) {
/* 1909 */       result++;
/*      */     }
/* 1911 */     if (b) {
/* 1912 */       result++;
/*      */     }
/* 1914 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void plotChanged(Plot3DChangeEvent event) {
/* 1926 */     if (event.requiresWorldUpdate()) {
/* 1927 */       this.world = null;
/*      */     }
/* 1929 */     notifyListeners(new Chart3DChangeEvent(event, this));
/*      */   }
/*      */ 
/*      */   
/*      */   public void styleChanged(ChartStyleChangeEvent event) {
/* 1934 */     ChartStyler styler = new ChartStyler(event.getChartStyle());
/* 1935 */     receive((ChartElementVisitor)styler);
/*      */ 
/*      */     
/* 1938 */     notifyListeners(new Chart3DChangeEvent(event, this));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addChangeListener(Chart3DChangeListener listener) {
/* 1947 */     this.listenerList.add(Chart3DChangeListener.class, listener);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeChangeListener(Chart3DChangeListener listener) {
/* 1957 */     this.listenerList.remove(Chart3DChangeListener.class, listener);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void notifyListeners(Chart3DChangeEvent event) {
/* 1968 */     if (!this.notify) {
/*      */       return;
/*      */     }
/* 1971 */     Object[] listeners = this.listenerList.getListenerList();
/* 1972 */     for (int i = listeners.length - 2; i >= 0; i -= 2) {
/* 1973 */       if (listeners[i] == Chart3DChangeListener.class) {
/* 1974 */         ((Chart3DChangeListener)listeners[i + 1]).chartChanged(event);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isNotify() {
/* 1988 */     return this.notify;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNotify(boolean notify) {
/* 2000 */     this.notify = notify;
/*      */     
/* 2002 */     if (notify) {
/* 2003 */       this.world = null;
/* 2004 */       fireChangeEvent();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void fireChangeEvent() {
/* 2012 */     notifyListeners(new Chart3DChangeEvent(this, this));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void readObject(ObjectInputStream stream) throws IOException, ClassNotFoundException {
/* 2025 */     stream.defaultReadObject();
/*      */     
/* 2027 */     this.listenerList = new EventListenerList();
/* 2028 */     this.plot.addChangeListener(this);
/*      */ 
/*      */     
/* 2031 */     this.renderingHints = new RenderingHints(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
/*      */ 
/*      */     
/* 2034 */     this.renderingHints.put(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String renderedElementToString(RenderedElement element) {
/* 2048 */     Object type = element.getProperty("type");
/* 2049 */     if (InteractiveElementType.SECTION_LABEL.equals(type)) {
/* 2050 */       StringBuilder sb = new StringBuilder();
/* 2051 */       sb.append("Section label with key '");
/* 2052 */       Object key = element.getProperty("key");
/* 2053 */       sb.append(key.toString());
/* 2054 */       sb.append("'");
/* 2055 */       return sb.toString();
/* 2056 */     }  if (InteractiveElementType.LEGEND_ITEM.equals(type)) {
/* 2057 */       StringBuilder sb = new StringBuilder();
/* 2058 */       sb.append("Legend item with section key '");
/* 2059 */       Object key = element.getProperty("series_key");
/* 2060 */       sb.append(key);
/* 2061 */       sb.append("'");
/* 2062 */       return sb.toString();
/* 2063 */     }  if (InteractiveElementType.AXIS_LABEL.equals(type)) {
/* 2064 */       StringBuilder sb = new StringBuilder();
/* 2065 */       sb.append("Axis label with the label '");
/* 2066 */       sb.append(element.getProperty("label"));
/* 2067 */       sb.append("'");
/* 2068 */       return sb.toString();
/* 2069 */     }  if (InteractiveElementType.CATEGORY_AXIS_TICK_LABEL.equals(type)) {
/* 2070 */       StringBuilder sb = new StringBuilder();
/* 2071 */       sb.append("Axis tick label with the label '");
/* 2072 */       sb.append(element.getProperty("label"));
/* 2073 */       sb.append("'");
/* 2074 */       return sb.toString();
/* 2075 */     }  if (InteractiveElementType.VALUE_AXIS_TICK_LABEL.equals(type)) {
/* 2076 */       StringBuilder sb = new StringBuilder();
/* 2077 */       sb.append("Axis tick label with the value '");
/* 2078 */       sb.append(element.getProperty("value"));
/* 2079 */       sb.append("'");
/* 2080 */       return sb.toString();
/* 2081 */     }  if ("obj3d".equals(type)) {
/* 2082 */       StringBuilder sb = new StringBuilder();
/* 2083 */       sb.append("An object in the 3D model");
/* 2084 */       ItemKey itemKey = (ItemKey)element.getProperty("key");
/* 2085 */       if (itemKey != null) {
/* 2086 */         sb.append(" representing the data item [");
/* 2087 */         sb.append(itemKey.toString());
/* 2088 */         sb.append("]");
/*      */       } 
/* 2090 */       return sb.toString();
/*      */     } 
/* 2092 */     return element.toString();
/*      */   }
/*      */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/Chart3D.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */