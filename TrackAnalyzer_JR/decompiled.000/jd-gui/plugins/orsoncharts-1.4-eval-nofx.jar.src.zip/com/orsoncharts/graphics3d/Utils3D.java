/*    */ package com.orsoncharts.graphics3d;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Utils3D
/*    */ {
/*    */   public static double length(Point3D v) {
/* 32 */     return Math.sqrt(v.x * v.x + v.y * v.y + v.z * v.z);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static Point3D normalise(Point3D v) {
/* 46 */     double length = length(v);
/* 47 */     return new Point3D(v.x / length, v.y / length, v.z / length);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static double scalarprod(Point3D a, Point3D b) {
/* 59 */     return a.x * b.x + a.y * b.y + a.z * b.z;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static Point3D normal(Point3D a, Point3D b, Point3D c) {
/* 72 */     double ax = a.x - c.x;
/* 73 */     double ay = a.y - c.y;
/* 74 */     double az = a.z - c.z;
/* 75 */     double bx = b.x - c.x;
/* 76 */     double by = b.y - c.y;
/* 77 */     double bz = b.z - c.z;
/* 78 */     return new Point3D(ay * bz - az * by, az * bx - ax * bz, ax * by - ay * bx);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static double angle(Point3D a, Point3D b) {
/* 91 */     double dp = a.x * b.x + a.y * b.y + a.z * b.z;
/* 92 */     double alen = length(a);
/* 93 */     double blen = length(b);
/* 94 */     double c = dp / alen * blen;
/*    */ 
/*    */     
/* 97 */     c = Math.max(-1.0D, Math.min(1.0D, c));
/* 98 */     return Math.acos(c);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/graphics3d/Utils3D.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */