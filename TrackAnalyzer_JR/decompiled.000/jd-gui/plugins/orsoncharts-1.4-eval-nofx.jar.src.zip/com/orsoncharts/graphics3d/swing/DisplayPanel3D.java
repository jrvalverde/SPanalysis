/*     */ package com.orsoncharts.graphics3d.swing;
/*     */ 
/*     */ import com.orsoncharts.Resources;
/*     */ import com.orsoncharts.util.ArgChecks;
/*     */ import com.orsoncharts.util.ExportFormat;
/*     */ import com.orsoncharts.util.ExportFormats;
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.Font;
/*     */ import java.awt.FontFormatException;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.awt.event.MouseListener;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JMenu;
/*     */ import javax.swing.JMenuItem;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JPopupMenu;
/*     */ import javax.swing.JToolBar;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DisplayPanel3D
/*     */   extends JPanel
/*     */   implements MouseListener
/*     */ {
/*     */   private static final int FONT_SIZE = 22;
/*     */   private static Font FONT_AWESOME;
/*     */   Panel3D content;
/*     */   private JPopupMenu popup;
/*     */   
/*     */   public static Font getFontAwesomeFont(int size) {
/*  61 */     if (FONT_AWESOME == null) {
/*     */       try {
/*  63 */         InputStream in = DisplayPanel3D.class.getResourceAsStream("fontawesome-webfont.ttf");
/*     */         
/*  65 */         FONT_AWESOME = Font.createFont(0, in);
/*  66 */       } catch (FontFormatException ex) {
/*  67 */         Logger.getLogger(Panel3D.class.getName()).log(Level.SEVERE, (String)null, ex);
/*     */       }
/*  69 */       catch (IOException ex) {
/*  70 */         Logger.getLogger(Panel3D.class.getName()).log(Level.SEVERE, (String)null, ex);
/*     */       } 
/*     */     }
/*     */     
/*  74 */     return FONT_AWESOME.deriveFont(0, size);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DisplayPanel3D(Panel3D content) {
/*  90 */     this(content, true, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DisplayPanel3D(Panel3D content, boolean toolbar, boolean popupMenu) {
/* 101 */     super(new BorderLayout());
/*     */     
/* 103 */     this.content = content;
/* 104 */     add(this.content);
/*     */     
/* 106 */     if (toolbar) {
/* 107 */       JToolBar tb = createToolBar(content);
/* 108 */       add(tb, "East");
/*     */     } 
/* 110 */     if (popupMenu) {
/* 111 */       this.popup = createPopupMenu(ExportFormat.values());
/*     */     }
/* 113 */     this.content.addMouseListener(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Panel3D getContent() {
/* 122 */     return this.content;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setExportFormats(ExportFormat... formats) {
/* 136 */     this.popup = createPopupMenu(formats);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private JToolBar createToolBar(Panel3D content) {
/* 147 */     JToolBar tb = new JToolBar(1);
/* 148 */     Font font = getFontAwesomeFont(22);
/* 149 */     JButton zoomInButton = new JButton(new ZoomInAction(this.content, true));
/*     */     
/* 151 */     zoomInButton.setFont(font);
/* 152 */     JButton zoomOutButton = new JButton(new ZoomOutAction(this.content, true));
/*     */     
/* 154 */     zoomOutButton.setFont(font);
/* 155 */     JButton zoomToFitButton = new JButton(new ZoomToFitAction(this.content, true));
/*     */     
/* 157 */     zoomToFitButton.setFont(font);
/* 158 */     JButton leftButton = new JButton(new LeftAction(content));
/* 159 */     leftButton.setFont(font);
/* 160 */     JButton rightButton = new JButton(new RightAction(content));
/* 161 */     rightButton.setFont(font);
/* 162 */     JButton upButton = new JButton(new UpAction(content));
/* 163 */     upButton.setFont(font);
/* 164 */     JButton downButton = new JButton(new DownAction(content));
/* 165 */     downButton.setFont(font);
/* 166 */     JButton rotateLeftButton = new JButton(new RollLeftAction(content));
/* 167 */     rotateLeftButton.setFont(font);
/* 168 */     JButton rotateRightButton = new JButton(new RollRightAction(content));
/* 169 */     rotateRightButton.setFont(font);
/* 170 */     tb.add(zoomInButton);
/* 171 */     tb.add(zoomOutButton);
/* 172 */     tb.add(zoomToFitButton);
/* 173 */     tb.add(new JToolBar.Separator());
/* 174 */     tb.add(leftButton);
/* 175 */     tb.add(rightButton);
/* 176 */     tb.add(upButton);
/* 177 */     tb.add(downButton);
/* 178 */     tb.add(rotateLeftButton);
/* 179 */     tb.add(rotateRightButton);
/* 180 */     return tb;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private JPopupMenu createPopupMenu(ExportFormat... exportFormats) {
/* 193 */     ArgChecks.nullNotPermitted(exportFormats, "exportFormats");
/* 194 */     JPopupMenu popupMenu = new JPopupMenu();
/* 195 */     popupMenu.add(new JMenuItem(new ZoomInAction(this.content, false)));
/* 196 */     popupMenu.add(new JMenuItem(new ZoomOutAction(this.content, false)));
/* 197 */     popupMenu.add(new JMenuItem(new ZoomToFitAction(this.content, false)));
/*     */     
/* 199 */     if (exportFormats.length > 0) {
/* 200 */       JMenu exportSubMenu = new JMenu(Resources.localString("EXPORT_AS"));
/* 201 */       for (ExportFormat f : exportFormats) {
/* 202 */         if (f.equals(ExportFormat.PNG)) {
/* 203 */           JMenuItem pngItem = new JMenuItem(new ExportToPNGAction(this.content));
/*     */           
/* 205 */           exportSubMenu.add(pngItem);
/* 206 */         } else if (f.equals(ExportFormat.JPEG)) {
/* 207 */           JMenuItem jpgItem = new JMenuItem(new ExportToJPEGAction(this.content));
/*     */           
/* 209 */           exportSubMenu.add(jpgItem);
/* 210 */         } else if (f.equals(ExportFormat.PDF)) {
/* 211 */           if (ExportFormats.isOrsonPDFAvailable()) {
/* 212 */             JMenuItem pdfItem = new JMenuItem(new ExportToPDFAction(this.content));
/*     */             
/* 214 */             exportSubMenu.add(pdfItem);
/*     */           } 
/* 216 */         } else if (f.equals(ExportFormat.SVG) && 
/* 217 */           ExportFormats.isJFreeSVGAvailable()) {
/* 218 */           JMenuItem svgItem = new JMenuItem(new ExportToSVGAction(this.content));
/*     */           
/* 220 */           exportSubMenu.add(svgItem);
/*     */         } 
/*     */       } 
/*     */       
/* 224 */       if (exportSubMenu.getItemCount() > 0) {
/* 225 */         popupMenu.addSeparator();
/* 226 */         popupMenu.add(exportSubMenu);
/*     */       } 
/*     */     } 
/* 229 */     return popupMenu;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void mouseClicked(MouseEvent e) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void mousePressed(MouseEvent e) {
/* 251 */     if (e.isPopupTrigger() && 
/* 252 */       this.popup != null) {
/* 253 */       this.popup.show(this, e.getX(), e.getY());
/* 254 */       e.consume();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void mouseReleased(MouseEvent e) {
/* 268 */     if (e.isPopupTrigger() && 
/* 269 */       this.popup != null) {
/* 270 */       this.popup.show(this, e.getX(), e.getY());
/* 271 */       e.consume();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void mouseEntered(MouseEvent e) {}
/*     */   
/*     */   public void mouseExited(MouseEvent e) {}
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/graphics3d/swing/DisplayPanel3D.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */