/*    */ package com.orsoncharts.graphics3d.swing;
/*    */ 
/*    */ import com.orsoncharts.Resources;
/*    */ import com.orsoncharts.graphics3d.ViewPoint3D;
/*    */ import com.orsoncharts.util.ArgChecks;
/*    */ import java.awt.event.ActionEvent;
/*    */ import javax.swing.AbstractAction;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ZoomInAction
/*    */   extends AbstractAction
/*    */ {
/*    */   private Panel3D panel;
/*    */   private double zoomMultiplier;
/*    */   
/*    */   public ZoomInAction(Panel3D panel, boolean fontAwesome) {
/* 49 */     super("");
/* 50 */     ArgChecks.nullNotPermitted(panel, "panel");
/* 51 */     this.panel = panel;
/* 52 */     this.zoomMultiplier = 0.95D;
/* 53 */     if (!fontAwesome) {
/* 54 */       putValue("Name", Resources.localString("ZOOM_IN"));
/*    */     }
/* 56 */     putValue("ActionCommandKey", "ZOOM_IN");
/* 57 */     putValue("ShortDescription", Resources.localString("ZOOM_IN"));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public double getZoomMultiplier() {
/* 69 */     return this.zoomMultiplier;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setZoomMultiplier(double multiplier) {
/* 81 */     this.zoomMultiplier = multiplier;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void actionPerformed(ActionEvent e) {
/* 91 */     ViewPoint3D viewPt = this.panel.getViewPoint();
/* 92 */     double minDistance = this.panel.getMinViewingDistance();
/*    */     
/* 94 */     double maxDistance = minDistance * this.panel.getMaxViewingDistanceMultiplier();
/* 95 */     double valRho = Math.max(minDistance, 
/* 96 */         Math.min(maxDistance, viewPt.getRho() * this.zoomMultiplier));
/* 97 */     this.panel.getViewPoint().setRho(valRho);
/* 98 */     this.panel.repaint();
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/graphics3d/swing/ZoomInAction.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */