/*    */ package com.orsoncharts.graphics3d.swing;
/*    */ 
/*    */ import com.orsoncharts.Resources;
/*    */ import com.orsoncharts.util.ArgChecks;
/*    */ import java.awt.Graphics2D;
/*    */ import java.awt.Rectangle;
/*    */ import java.awt.event.ActionEvent;
/*    */ import java.awt.geom.Dimension2D;
/*    */ import java.awt.image.BufferedImage;
/*    */ import java.io.File;
/*    */ import java.io.IOException;
/*    */ import javax.imageio.ImageIO;
/*    */ import javax.swing.AbstractAction;
/*    */ import javax.swing.JFileChooser;
/*    */ import javax.swing.filechooser.FileNameExtensionFilter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ExportToJPEGAction
/*    */   extends AbstractAction
/*    */ {
/*    */   private Panel3D panel;
/*    */   
/*    */   public ExportToJPEGAction(Panel3D panel) {
/* 52 */     super(Resources.localString("JPG_MENU_LABEL"));
/* 53 */     ArgChecks.nullNotPermitted(panel, "panel");
/* 54 */     this.panel = panel;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void actionPerformed(ActionEvent e) {
/* 64 */     JFileChooser fileChooser = new JFileChooser();
/*    */     
/* 66 */     FileNameExtensionFilter filter = new FileNameExtensionFilter(Resources.localString("JPG_FILE_FILTER_DESCRIPTION"), new String[] { "jpg" });
/* 67 */     fileChooser.addChoosableFileFilter(filter);
/* 68 */     fileChooser.setFileFilter(filter);
/*    */     
/* 70 */     int option = fileChooser.showSaveDialog(this.panel);
/* 71 */     if (option == 0) {
/* 72 */       String filename = fileChooser.getSelectedFile().getPath();
/* 73 */       if (!filename.endsWith(".jpg")) {
/* 74 */         filename = filename + ".jpg";
/*    */       }
/* 76 */       Dimension2D size = this.panel.getSize();
/* 77 */       int w = (int)size.getWidth();
/* 78 */       int h = (int)size.getHeight();
/* 79 */       BufferedImage image = new BufferedImage(w, h, 1);
/*    */       
/* 81 */       Graphics2D g2 = image.createGraphics();
/* 82 */       this.panel.getDrawable().draw(g2, new Rectangle(w, h));
/*    */       try {
/* 84 */         ImageIO.write(image, "jpeg", new File(filename));
/* 85 */       } catch (IOException ex) {
/* 86 */         throw new RuntimeException(ex);
/*    */       } 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/graphics3d/swing/ExportToJPEGAction.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */