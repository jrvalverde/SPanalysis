/*     */ package com.orsoncharts.graphics3d;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Point3D
/*     */   implements Serializable
/*     */ {
/*  29 */   public static final Point3D ORIGIN = new Point3D(0.0D, 0.0D, 0.0D);
/*     */ 
/*     */   
/*  32 */   public static final Point3D UNIT_X = new Point3D(1.0D, 0.0D, 0.0D);
/*     */ 
/*     */   
/*  35 */   public static final Point3D UNIT_Y = new Point3D(0.0D, 1.0D, 0.0D);
/*     */ 
/*     */   
/*  38 */   public static final Point3D UNIT_Z = new Point3D(0.0D, 0.0D, 1.0D);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double x;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double y;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double z;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Point3D createPoint3D(double theta, double phi, double rho) {
/*  59 */     double x = rho * Math.sin(phi) * Math.cos(theta);
/*  60 */     double y = rho * Math.sin(phi) * Math.sin(theta);
/*  61 */     double z = rho * Math.cos(phi);
/*  62 */     return new Point3D(x, y, z);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Point3D(double x, double y, double z) {
/*  73 */     this.x = x;
/*  74 */     this.y = y;
/*  75 */     this.z = z;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getX() {
/*  84 */     return this.x;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getY() {
/*  93 */     return this.y;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getZ() {
/* 102 */     return this.z;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getTheta() {
/* 111 */     return Math.atan2(this.y, this.x);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getPhi() {
/* 120 */     return Math.acos(this.z / getRho());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getRho() {
/* 129 */     return Math.sqrt(this.x * this.x + this.y * this.y + this.z * this.z);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 141 */     if (obj == this) {
/* 142 */       return true;
/*     */     }
/* 144 */     if (!(obj instanceof Point3D)) {
/* 145 */       return false;
/*     */     }
/* 147 */     Point3D that = (Point3D)obj;
/* 148 */     if (this.x != that.x) {
/* 149 */       return false;
/*     */     }
/* 151 */     if (this.y != that.y) {
/* 152 */       return false;
/*     */     }
/* 154 */     if (this.z != that.z) {
/* 155 */       return false;
/*     */     }
/* 157 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 162 */     int hash = 7;
/*     */     
/* 164 */     hash = 29 * hash + (int)(Double.doubleToLongBits(this.x) ^ Double.doubleToLongBits(this.x) >>> 32L);
/*     */     
/* 166 */     hash = 29 * hash + (int)(Double.doubleToLongBits(this.y) ^ Double.doubleToLongBits(this.y) >>> 32L);
/*     */     
/* 168 */     hash = 29 * hash + (int)(Double.doubleToLongBits(this.z) ^ Double.doubleToLongBits(this.z) >>> 32L);
/* 169 */     return hash;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 180 */     return "[" + this.x + ", " + this.y + ", " + this.z + "]";
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/graphics3d/Point3D.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */