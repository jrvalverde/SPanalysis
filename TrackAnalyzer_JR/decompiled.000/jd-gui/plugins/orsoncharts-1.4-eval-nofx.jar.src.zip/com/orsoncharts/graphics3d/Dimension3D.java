/*     */ package com.orsoncharts.graphics3d;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Dimension3D
/*     */   implements Serializable
/*     */ {
/*     */   private double width;
/*     */   private double height;
/*     */   private double depth;
/*     */   
/*     */   public Dimension3D(double width, double height, double depth) {
/*  46 */     this.width = width;
/*  47 */     this.height = height;
/*  48 */     this.depth = depth;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getWidth() {
/*  57 */     return this.width;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getHeight() {
/*  66 */     return this.height;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getDepth() {
/*  75 */     return this.depth;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getDiagonalLength() {
/*  84 */     return Math.sqrt(this.depth * this.depth + this.height * this.height + this.width * this.width);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/*  97 */     if (obj == null) {
/*  98 */       return false;
/*     */     }
/* 100 */     if (getClass() != obj.getClass()) {
/* 101 */       return false;
/*     */     }
/* 103 */     Dimension3D other = (Dimension3D)obj;
/* 104 */     if (Double.doubleToLongBits(this.width) != Double.doubleToLongBits(other.width))
/*     */     {
/* 106 */       return false;
/*     */     }
/* 108 */     if (Double.doubleToLongBits(this.height) != Double.doubleToLongBits(other.height))
/*     */     {
/* 110 */       return false;
/*     */     }
/* 112 */     if (Double.doubleToLongBits(this.depth) != Double.doubleToLongBits(other.depth))
/*     */     {
/* 114 */       return false;
/*     */     }
/* 116 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 126 */     int hash = 7;
/*     */     
/* 128 */     hash = 17 * hash + (int)(Double.doubleToLongBits(this.width) ^ Double.doubleToLongBits(this.width) >>> 32L);
/*     */     
/* 130 */     hash = 17 * hash + (int)(Double.doubleToLongBits(this.height) ^ Double.doubleToLongBits(this.height) >>> 32L);
/*     */     
/* 132 */     hash = 17 * hash + (int)(Double.doubleToLongBits(this.depth) ^ Double.doubleToLongBits(this.depth) >>> 32L);
/* 133 */     return hash;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 144 */     return "[" + this.width + ", " + this.height + ", " + this.depth + "]";
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/graphics3d/Dimension3D.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */