/*    */ package com.orsoncharts.graphics3d.swing;
/*    */ 
/*    */ import com.orsoncharts.Resources;
/*    */ import com.orsoncharts.util.ArgChecks;
/*    */ import java.awt.event.ActionEvent;
/*    */ import javax.swing.AbstractAction;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ZoomToFitAction
/*    */   extends AbstractAction
/*    */ {
/*    */   private Panel3D panel;
/*    */   
/*    */   public ZoomToFitAction(Panel3D panel, boolean fontAwesome) {
/* 44 */     super("");
/* 45 */     ArgChecks.nullNotPermitted(panel, "panel");
/* 46 */     this.panel = panel;
/* 47 */     if (!fontAwesome) {
/* 48 */       putValue("Name", Resources.localString("ZOOM_TO_FIT"));
/*    */     }
/* 50 */     putValue("ActionCommandKey", "ZOOM_TO_FIT");
/* 51 */     putValue("ShortDescription", Resources.localString("ZOOM_TO_FIT"));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void actionPerformed(ActionEvent e) {
/* 61 */     this.panel.zoomToFit();
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/graphics3d/swing/ZoomToFitAction.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */