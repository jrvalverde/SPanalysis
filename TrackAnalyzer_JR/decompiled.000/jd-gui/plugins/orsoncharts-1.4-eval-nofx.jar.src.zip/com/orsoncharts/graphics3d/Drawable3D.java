package com.orsoncharts.graphics3d;

import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;

public interface Drawable3D {
  Dimension3D getDimensions();
  
  ViewPoint3D getViewPoint();
  
  void setViewPoint(ViewPoint3D paramViewPoint3D);
  
  double getProjDistance();
  
  void setProjDistance(double paramDouble);
  
  Offset2D getTranslate2D();
  
  void setTranslate2D(Offset2D paramOffset2D);
  
  RenderingInfo draw(Graphics2D paramGraphics2D, Rectangle2D paramRectangle2D);
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/graphics3d/Drawable3D.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */