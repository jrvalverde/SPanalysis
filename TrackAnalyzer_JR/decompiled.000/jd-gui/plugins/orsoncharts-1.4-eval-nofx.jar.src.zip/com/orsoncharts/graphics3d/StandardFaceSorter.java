/*    */ package com.orsoncharts.graphics3d;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StandardFaceSorter
/*    */   implements FaceSorter, Serializable
/*    */ {
/*    */   public List<Face> sort(List<Face> faces, Point3D[] eyePts) {
/* 35 */     Collections.sort(faces, new ZOrderComparator(eyePts));
/* 36 */     return faces;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/graphics3d/StandardFaceSorter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */