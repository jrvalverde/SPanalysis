/*    */ package com.orsoncharts.graphics3d;
/*    */ 
/*    */ import java.util.Comparator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ZOrderComparator
/*    */   implements Comparator<Face>
/*    */ {
/*    */   Point3D[] pts;
/*    */   
/*    */   public ZOrderComparator(Point3D[] pts) {
/* 30 */     this.pts = pts;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int compare(Face f1, Face f2) {
/* 38 */     double z1 = f1.calculateAverageZValue(this.pts);
/* 39 */     double z2 = f2.calculateAverageZValue(this.pts);
/* 40 */     if (z1 > z2)
/* 41 */       return 1; 
/* 42 */     if (z2 > z1) {
/* 43 */       return -1;
/*    */     }
/* 45 */     return 0;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/graphics3d/ZOrderComparator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */