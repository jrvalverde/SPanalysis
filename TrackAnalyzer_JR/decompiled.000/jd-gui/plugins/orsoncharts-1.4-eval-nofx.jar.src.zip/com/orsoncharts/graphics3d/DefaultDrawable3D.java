/*     */ package com.orsoncharts.graphics3d;
/*     */ 
/*     */ import com.orsoncharts.util.ArgChecks;
/*     */ import java.awt.BasicStroke;
/*     */ import java.awt.Color;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.RenderingHints;
/*     */ import java.awt.geom.AffineTransform;
/*     */ import java.awt.geom.GeneralPath;
/*     */ import java.awt.geom.Point2D;
/*     */ import java.awt.geom.Rectangle2D;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultDrawable3D
/*     */   implements Drawable3D
/*     */ {
/*     */   public static final double DEFAULT_PROJ_DIST = 1500.0D;
/*     */   private ViewPoint3D viewPoint;
/*     */   private double projDist;
/*     */   private World world;
/*     */   private Offset2D offset;
/*     */   
/*     */   public DefaultDrawable3D(World world) {
/*  63 */     ArgChecks.nullNotPermitted(world, "world");
/*  64 */     this.viewPoint = new ViewPoint3D(4.71238899230957D, 0.5235987901687622D, 40.0D, 0.0D);
/*     */     
/*  66 */     this.projDist = 1500.0D;
/*  67 */     this.world = world;
/*  68 */     this.offset = new Offset2D();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Dimension3D getDimensions() {
/*  78 */     return new Dimension3D(1.0D, 1.0D, 1.0D);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ViewPoint3D getViewPoint() {
/*  88 */     return this.viewPoint;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setViewPoint(ViewPoint3D viewPoint) {
/*  98 */     ArgChecks.nullNotPermitted(viewPoint, "viewPoint");
/*  99 */     this.viewPoint = viewPoint;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getProjDistance() {
/* 113 */     return this.projDist;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setProjDistance(double dist) {
/* 125 */     this.projDist = dist;
/*     */   }
/*     */ 
/*     */   
/*     */   public Offset2D getTranslate2D() {
/* 130 */     return this.offset;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setTranslate2D(Offset2D offset) {
/* 135 */     ArgChecks.nullNotPermitted(offset, "offset");
/* 136 */     this.offset = offset;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RenderingInfo draw(Graphics2D g2, Rectangle2D bounds) {
/* 147 */     ArgChecks.nullNotPermitted(g2, "g2");
/* 148 */     g2.setStroke(new BasicStroke(1.0F, 1, 1));
/*     */     
/* 150 */     g2.setPaint(Color.WHITE);
/* 151 */     g2.fill(bounds);
/* 152 */     AffineTransform saved = g2.getTransform();
/* 153 */     double dx = bounds.getWidth() / 2.0D;
/* 154 */     double dy = bounds.getHeight() / 2.0D;
/* 155 */     g2.translate(dx, dy);
/* 156 */     g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
/*     */ 
/*     */     
/* 159 */     Point3D[] eyePts = this.world.calculateEyeCoordinates(this.viewPoint);
/*     */     
/* 161 */     Point2D[] pts = this.world.calculateProjectedPoints(this.viewPoint, this.projDist);
/*     */ 
/*     */     
/* 164 */     List<Face> facesInPaintOrder = new ArrayList<Face>(this.world.getFaces());
/*     */ 
/*     */     
/* 167 */     Collections.sort(facesInPaintOrder, new ZOrderComparator(eyePts));
/*     */     
/* 169 */     for (Face f : facesInPaintOrder) {
/* 170 */       double[] plane = f.calculateNormal(eyePts);
/*     */       
/* 172 */       double inprod = plane[0] * this.world.getSunX() + plane[1] * this.world.getSunY() + plane[2] * this.world.getSunZ();
/* 173 */       double shade = (inprod + 1.0D) / 2.0D;
/* 174 */       if (Utils2D.area2(pts[f.getVertexIndex(0)], pts[f
/* 175 */             .getVertexIndex(1)], pts[f.getVertexIndex(2)]) > 0.0D) {
/* 176 */         Color c = f.getColor();
/* 177 */         if (c != null) {
/* 178 */           GeneralPath p = new GeneralPath();
/* 179 */           for (int v = 0; v < f.getVertexCount(); v++) {
/* 180 */             if (v == 0) {
/* 181 */               p.moveTo(pts[f.getVertexIndex(v)].getX(), pts[f
/* 182 */                     .getVertexIndex(v)].getY());
/*     */             } else {
/*     */               
/* 185 */               p.lineTo(pts[f.getVertexIndex(v)].getX(), pts[f
/* 186 */                     .getVertexIndex(v)].getY());
/*     */             } 
/*     */           } 
/* 189 */           p.closePath();
/* 190 */           g2.setPaint(new Color((int)(c.getRed() * shade), 
/* 191 */                 (int)(c.getGreen() * shade), 
/* 192 */                 (int)(c.getBlue() * shade), c.getAlpha()));
/* 193 */           g2.fill(p);
/* 194 */           g2.draw(p);
/*     */         } 
/*     */       } 
/*     */     } 
/* 198 */     g2.setTransform(saved);
/* 199 */     RenderingInfo info = new RenderingInfo(facesInPaintOrder, pts, dx, dy);
/* 200 */     return info;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/graphics3d/DefaultDrawable3D.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */