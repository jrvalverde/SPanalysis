/*     */ package com.orsoncharts.graphics3d;
/*     */ 
/*     */ import com.orsoncharts.util.ArgChecks;
/*     */ import com.orsoncharts.util.ExportFormats;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.geom.Rectangle2D;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.io.BufferedOutputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import javax.imageio.ImageIO;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ExportUtils
/*     */ {
/*     */   public static RenderingInfo writeAsSVG(Drawable3D drawable, int w, int h, File file) {
/*  54 */     if (!ExportFormats.isJFreeSVGAvailable()) {
/*  55 */       throw new IllegalStateException("JFreeSVG is not present on the classpath.");
/*     */     }
/*     */     
/*  58 */     ArgChecks.nullNotPermitted(drawable, "drawable");
/*  59 */     ArgChecks.nullNotPermitted(file, "file");
/*     */     try {
/*  61 */       Class<?> svg2Class = Class.forName("org.jfree.graphics2d.svg.SVGGraphics2D");
/*     */       
/*  63 */       Constructor<?> c1 = svg2Class.getConstructor(new Class[] { int.class, int.class });
/*  64 */       Graphics2D svg2 = (Graphics2D)c1.newInstance(new Object[] { Integer.valueOf(w), Integer.valueOf(h) });
/*  65 */       Rectangle2D drawArea = new Rectangle2D.Double(0.0D, 0.0D, w, h);
/*  66 */       RenderingInfo info = drawable.draw(svg2, drawArea);
/*  67 */       Class<?> svgUtilsClass = Class.forName("org.jfree.graphics2d.svg.SVGUtils");
/*     */       
/*  69 */       Method m1 = svg2Class.getMethod("getSVGElement", (Class[])null);
/*  70 */       String element = (String)m1.invoke(svg2, (Object[])null);
/*  71 */       Method m2 = svgUtilsClass.getMethod("writeToSVG", new Class[] { File.class, String.class });
/*     */       
/*  73 */       m2.invoke(svgUtilsClass, new Object[] { file, element });
/*  74 */       return info;
/*  75 */     } catch (ClassNotFoundException ex) {
/*  76 */       throw new RuntimeException(ex);
/*  77 */     } catch (InstantiationException ex) {
/*  78 */       throw new RuntimeException(ex);
/*  79 */     } catch (IllegalAccessException ex) {
/*  80 */       throw new RuntimeException(ex);
/*  81 */     } catch (NoSuchMethodException ex) {
/*  82 */       throw new RuntimeException(ex);
/*  83 */     } catch (SecurityException ex) {
/*  84 */       throw new RuntimeException(ex);
/*  85 */     } catch (IllegalArgumentException ex) {
/*  86 */       throw new RuntimeException(ex);
/*  87 */     } catch (InvocationTargetException ex) {
/*  88 */       throw new RuntimeException(ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final RenderingInfo writeAsPDF(Drawable3D drawable, int w, int h, File file) {
/* 107 */     if (!ExportFormats.isOrsonPDFAvailable()) {
/* 108 */       throw new IllegalStateException("OrsonPDF is not present on the classpath.");
/*     */     }
/*     */     
/* 111 */     ArgChecks.nullNotPermitted(drawable, "drawable");
/* 112 */     ArgChecks.nullNotPermitted(file, "file");
/*     */     try {
/* 114 */       Class<?> pdfDocClass = Class.forName("com.orsonpdf.PDFDocument");
/* 115 */       Object pdfDoc = pdfDocClass.newInstance();
/* 116 */       Method m = pdfDocClass.getMethod("createPage", new Class[] { Rectangle2D.class });
/* 117 */       Rectangle2D rect = new Rectangle(w, h);
/* 118 */       Object page = m.invoke(pdfDoc, new Object[] { rect });
/* 119 */       Method m2 = page.getClass().getMethod("getGraphics2D", new Class[0]);
/* 120 */       Graphics2D g2 = (Graphics2D)m2.invoke(page, new Object[0]);
/* 121 */       Rectangle2D drawArea = new Rectangle2D.Double(0.0D, 0.0D, w, h);
/* 122 */       RenderingInfo info = drawable.draw(g2, drawArea);
/* 123 */       Method m3 = pdfDocClass.getMethod("writeToFile", new Class[] { File.class });
/* 124 */       m3.invoke(pdfDoc, new Object[] { file });
/* 125 */       return info;
/* 126 */     } catch (ClassNotFoundException ex) {
/* 127 */       throw new RuntimeException(ex);
/* 128 */     } catch (InstantiationException ex) {
/* 129 */       throw new RuntimeException(ex);
/* 130 */     } catch (IllegalAccessException ex) {
/* 131 */       throw new RuntimeException(ex);
/* 132 */     } catch (NoSuchMethodException ex) {
/* 133 */       throw new RuntimeException(ex);
/* 134 */     } catch (SecurityException ex) {
/* 135 */       throw new RuntimeException(ex);
/* 136 */     } catch (IllegalArgumentException ex) {
/* 137 */       throw new RuntimeException(ex);
/* 138 */     } catch (InvocationTargetException ex) {
/* 139 */       throw new RuntimeException(ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static RenderingInfo writeAsPNG(Drawable3D drawable, int w, int h, File file) throws FileNotFoundException, IOException {
/* 158 */     BufferedImage image = new BufferedImage(w, h, 2);
/*     */     
/* 160 */     Graphics2D g2 = image.createGraphics();
/* 161 */     RenderingInfo result = drawable.draw(g2, new Rectangle(w, h));
/* 162 */     OutputStream out = new BufferedOutputStream(new FileOutputStream(file));
/*     */     try {
/* 164 */       ImageIO.write(image, "png", out);
/*     */     } finally {
/*     */       
/* 167 */       out.close();
/*     */     } 
/* 169 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static RenderingInfo writeAsJPEG(Drawable3D drawable, int w, int h, File file) throws FileNotFoundException, IOException {
/* 187 */     BufferedImage image = new BufferedImage(w, h, 1);
/*     */     
/* 189 */     Graphics2D g2 = image.createGraphics();
/* 190 */     RenderingInfo result = drawable.draw(g2, new Rectangle(w, h));
/* 191 */     OutputStream out = new BufferedOutputStream(new FileOutputStream(file));
/*     */     try {
/* 193 */       ImageIO.write(image, "jpg", out);
/*     */     } finally {
/*     */       
/* 196 */       out.close();
/*     */     } 
/* 198 */     return result;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/graphics3d/ExportUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */