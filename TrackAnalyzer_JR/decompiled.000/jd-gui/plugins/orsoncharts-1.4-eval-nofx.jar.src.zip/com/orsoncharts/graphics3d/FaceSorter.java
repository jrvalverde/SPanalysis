package com.orsoncharts.graphics3d;

import java.util.List;

public interface FaceSorter {
  List<Face> sort(List<Face> paramList, Point3D[] paramArrayOfPoint3D);
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/graphics3d/FaceSorter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */