/*    */ package com.orsoncharts.graphics3d.swing;
/*    */ 
/*    */ import com.orsoncharts.Resources;
/*    */ import com.orsoncharts.util.ArgChecks;
/*    */ import java.awt.event.ActionEvent;
/*    */ import java.io.File;
/*    */ import javax.swing.AbstractAction;
/*    */ import javax.swing.JFileChooser;
/*    */ import javax.swing.filechooser.FileNameExtensionFilter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ExportToPDFAction
/*    */   extends AbstractAction
/*    */ {
/*    */   private Panel3D panel;
/*    */   
/*    */   public ExportToPDFAction(Panel3D panel) {
/* 46 */     super(Resources.localString("PDF_MENU_LABEL"));
/* 47 */     ArgChecks.nullNotPermitted(panel, "Name");
/* 48 */     this.panel = panel;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void actionPerformed(ActionEvent e) {
/* 58 */     JFileChooser fileChooser = new JFileChooser();
/*    */     
/* 60 */     FileNameExtensionFilter filter = new FileNameExtensionFilter(Resources.localString("PDF_FILE_FILTER_DESCRIPTION"), new String[] { "pdf" });
/* 61 */     fileChooser.addChoosableFileFilter(filter);
/* 62 */     fileChooser.setFileFilter(filter);
/*    */     
/* 64 */     int option = fileChooser.showSaveDialog(this.panel);
/* 65 */     if (option == 0) {
/* 66 */       String filename = fileChooser.getSelectedFile().getPath();
/* 67 */       if (!filename.endsWith(".pdf")) {
/* 68 */         filename = filename + ".pdf";
/*    */       }
/* 70 */       this.panel.writeAsPDF(new File(filename), this.panel.getWidth(), this.panel
/* 71 */           .getHeight());
/*    */     } 
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/graphics3d/swing/ExportToPDFAction.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */