/*     */ package com.orsoncharts.graphics3d;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Offset3D
/*     */   implements Serializable
/*     */ {
/*  31 */   public static final Offset3D ZERO_OFFSET = new Offset3D(0.0D, 0.0D, 0.0D);
/*     */ 
/*     */ 
/*     */   
/*     */   private double dx;
/*     */ 
/*     */   
/*     */   private double dy;
/*     */ 
/*     */   
/*     */   private double dz;
/*     */ 
/*     */ 
/*     */   
/*     */   public Offset3D() {
/*  46 */     this(0.0D, 0.0D, 0.0D);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Offset3D(double dx, double dy, double dz) {
/*  57 */     this.dx = dx;
/*  58 */     this.dy = dy;
/*  59 */     this.dz = dz;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getDX() {
/*  68 */     return this.dx;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getDY() {
/*  77 */     return this.dy;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getDZ() {
/*  86 */     return this.dz;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/*  98 */     if (obj == this) {
/*  99 */       return true;
/*     */     }
/* 101 */     if (!(obj instanceof Offset3D)) {
/* 102 */       return false;
/*     */     }
/* 104 */     Offset3D that = (Offset3D)obj;
/* 105 */     if (this.dx != that.dx) {
/* 106 */       return false;
/*     */     }
/* 108 */     if (this.dy != that.dy) {
/* 109 */       return false;
/*     */     }
/* 111 */     if (this.dz != that.dz) {
/* 112 */       return false;
/*     */     }
/* 114 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 119 */     int hash = 7;
/*     */     
/* 121 */     hash = 97 * hash + (int)(Double.doubleToLongBits(this.dx) ^ Double.doubleToLongBits(this.dx) >>> 32L);
/*     */     
/* 123 */     hash = 97 * hash + (int)(Double.doubleToLongBits(this.dy) ^ Double.doubleToLongBits(this.dy) >>> 32L);
/*     */     
/* 125 */     hash = 97 * hash + (int)(Double.doubleToLongBits(this.dz) ^ Double.doubleToLongBits(this.dz) >>> 32L);
/* 126 */     return hash;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 131 */     return "[" + this.dx + ", " + this.dy + ", " + this.dz + "]";
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/graphics3d/Offset3D.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */