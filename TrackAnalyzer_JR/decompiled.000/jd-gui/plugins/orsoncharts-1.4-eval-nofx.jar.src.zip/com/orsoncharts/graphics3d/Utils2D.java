/*     */ package com.orsoncharts.graphics3d;
/*     */ 
/*     */ import java.awt.Dimension;
/*     */ import java.awt.geom.Line2D;
/*     */ import java.awt.geom.Point2D;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Utils2D
/*     */ {
/*     */   public static boolean spans(double value, double bound1, double bound2) {
/*  39 */     return ((bound1 < value && bound2 > value) || (bound1 > value && bound2 < value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static double area2(Point2D a, Point2D b, Point2D c) {
/*  55 */     double ax = a.getX();
/*  56 */     double ay = a.getY();
/*  57 */     double bx = b.getX();
/*  58 */     double by = b.getY();
/*  59 */     double cx = c.getX();
/*  60 */     double cy = c.getY();
/*  61 */     return (ax - cx) * (by - cy) - (ay - cy) * (bx - cx);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Point2D centerPoint(Point2D pt0, Point2D pt1, Point2D pt2, Point2D pt3) {
/*  76 */     float x = (float)((pt0.getX() + pt1.getX() + pt2.getX() + pt3.getX()) / 4.0D);
/*     */     
/*  78 */     float y = (float)((pt0.getY() + pt1.getY() + pt2.getY() + pt3.getY()) / 4.0D);
/*     */     
/*  80 */     return new Point2D.Float(x, y);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Dimension findDimension(Point2D[] pts) {
/*  92 */     double minx = Double.POSITIVE_INFINITY;
/*  93 */     double maxx = Double.NEGATIVE_INFINITY;
/*  94 */     double miny = Double.POSITIVE_INFINITY;
/*  95 */     double maxy = Double.NEGATIVE_INFINITY;
/*  96 */     for (Point2D pt : pts) {
/*  97 */       minx = Math.min(minx, pt.getX());
/*  98 */       maxx = Math.max(maxx, pt.getX());
/*  99 */       miny = Math.min(miny, pt.getY());
/* 100 */       maxy = Math.max(maxy, pt.getY());
/*     */     } 
/* 102 */     return new Dimension((int)(maxx - minx), (int)(maxy - miny));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Line2D createPerpendicularLine(Line2D line, double b, double size, Point2D opposingPoint) {
/* 120 */     double dx = line.getX2() - line.getX1();
/* 121 */     double dy = line.getY2() - line.getY1();
/* 122 */     double length = Math.sqrt(dx * dx + dy * dy);
/* 123 */     double pdx = dy / length;
/* 124 */     double pdy = -dx / length;
/* 125 */     int ccw = line.relativeCCW(opposingPoint);
/*     */     
/* 127 */     Point2D pt1 = new Point2D.Double(line.getX1() + b * dx, line.getY1() + b * dy);
/*     */     
/* 129 */     Point2D pt2 = new Point2D.Double(pt1.getX() - ccw * size * pdx, pt1.getY() - ccw * size * pdy);
/* 130 */     return new Line2D.Double(pt1, pt2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Line2D createPerpendicularLine(Line2D line, Point2D pt1, double size, Point2D opposingPoint) {
/* 149 */     double dx = line.getX2() - line.getX1();
/* 150 */     double dy = line.getY2() - line.getY1();
/* 151 */     double length = Math.sqrt(dx * dx + dy * dy);
/* 152 */     double pdx = dy / length;
/* 153 */     double pdy = -dx / length;
/* 154 */     int ccw = line.relativeCCW(opposingPoint);
/*     */     
/* 156 */     Point2D pt2 = new Point2D.Double(pt1.getX() - ccw * size * pdx, pt1.getY() - ccw * size * pdy);
/* 157 */     return new Line2D.Double(pt1, pt2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static double calculateTheta(Line2D line) {
/* 168 */     double dx = line.getX2() - line.getX1();
/* 169 */     double dy = line.getY2() - line.getY1();
/* 170 */     return Math.atan2(dy, dx);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static double length(Line2D line) {
/* 181 */     double dx = line.getX2() - line.getX1();
/* 182 */     double dy = line.getY2() - line.getY1();
/* 183 */     return Math.sqrt(dx * dx + dy * dy);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/graphics3d/Utils2D.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */