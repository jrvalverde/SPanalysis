/*    */ package com.orsoncharts.graphics3d.swing;
/*    */ 
/*    */ import com.orsoncharts.Resources;
/*    */ import com.orsoncharts.util.ArgChecks;
/*    */ import java.awt.event.ActionEvent;
/*    */ import javax.swing.AbstractAction;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RollRightAction
/*    */   extends AbstractAction
/*    */ {
/*    */   private Panel3D panel;
/*    */   
/*    */   public RollRightAction(Panel3D panel) {
/* 42 */     super("");
/* 43 */     ArgChecks.nullNotPermitted(panel, "panel");
/* 44 */     this.panel = panel;
/* 45 */     putValue("ShortDescription", 
/* 46 */         Resources.localString("ROLL_RIGHT_ACTION_SHORT_DESCRIPTION"));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void actionPerformed(ActionEvent e) {
/* 56 */     this.panel.getViewPoint().roll(this.panel.getRollIncrement());
/* 57 */     this.panel.repaint();
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/graphics3d/swing/RollRightAction.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */