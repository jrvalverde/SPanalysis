/*     */ package com.orsoncharts.graphics3d;
/*     */ 
/*     */ import com.orsoncharts.util.ArgChecks;
/*     */ import java.awt.Color;
/*     */ import java.awt.Font;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LabelFace
/*     */   extends Face
/*     */ {
/*  27 */   private static final Color TRANSPARENT = new Color(0, 0, 0, 0);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String label;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Font font;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Color textColor;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Color backgroundColor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LabelFace(Object3D owner, int[] vertices, String label, Font font, Color textColor, Color backgroundColor) {
/*  56 */     super(owner, vertices);
/*  57 */     ArgChecks.nullNotPermitted(label, "label");
/*  58 */     ArgChecks.nullNotPermitted(font, "font");
/*  59 */     ArgChecks.nullNotPermitted(textColor, "textColor");
/*  60 */     ArgChecks.nullNotPermitted(backgroundColor, "backgroundColor");
/*  61 */     this.label = label;
/*  62 */     this.font = font;
/*  63 */     this.textColor = textColor;
/*  64 */     this.backgroundColor = backgroundColor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Color getColor() {
/*  74 */     return TRANSPARENT;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getLabel() {
/*  83 */     return this.label;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLabel(String label) {
/*  92 */     ArgChecks.nullNotPermitted(label, "label");
/*  93 */     this.label = label;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Font getFont() {
/* 102 */     return this.font;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFont(Font font) {
/* 111 */     ArgChecks.nullNotPermitted(font, "font");
/* 112 */     this.font = font;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Color getTextColor() {
/* 121 */     return this.textColor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTextColor(Color color) {
/* 130 */     this.textColor = color;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Color getBackgroundColor() {
/* 140 */     return this.backgroundColor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBackgroundColor(Color color) {
/* 149 */     this.backgroundColor = color;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/graphics3d/LabelFace.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */