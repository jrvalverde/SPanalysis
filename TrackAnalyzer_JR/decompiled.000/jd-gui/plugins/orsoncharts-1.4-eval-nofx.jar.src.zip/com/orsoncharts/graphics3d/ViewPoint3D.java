/*     */ package com.orsoncharts.graphics3d;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.geom.Dimension2D;
/*     */ import java.awt.geom.Point2D;
/*     */ import java.io.Serializable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ViewPoint3D
/*     */   implements Serializable
/*     */ {
/*     */   private double theta;
/*     */   private double phi;
/*     */   private double rho;
/*     */   private double v11;
/*     */   private double v12;
/*     */   private double v13;
/*     */   private double v21;
/*     */   private double v22;
/*     */   private double v23;
/*     */   private double v32;
/*     */   private double v33;
/*     */   private double v43;
/*     */   private Point3D up;
/*     */   private Rotate3D rotation;
/*     */   private double[] workspace;
/*     */   
/*     */   public static ViewPoint3D createAboveViewPoint(double rho) {
/*  53 */     return new ViewPoint3D(-1.5707963267948966D, 3.5342917352885173D, rho, 0.0D);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ViewPoint3D createAboveLeftViewPoint(double rho) {
/*  65 */     ViewPoint3D vp = createAboveViewPoint(rho);
/*  66 */     vp.panLeftRight(-0.5235987755982988D);
/*  67 */     return vp;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ViewPoint3D createAboveRightViewPoint(double rho) {
/*  79 */     ViewPoint3D vp = createAboveViewPoint(rho);
/*  80 */     vp.panLeftRight(0.5235987755982988D);
/*  81 */     return vp;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ViewPoint3D(double theta, double phi, double rho, double orientation) {
/* 120 */     this.theta = theta;
/* 121 */     this.phi = phi;
/* 122 */     this.rho = rho;
/* 123 */     updateMatrixElements();
/* 124 */     this.rotation = new Rotate3D(Point3D.ORIGIN, Point3D.UNIT_Z, orientation);
/*     */     
/* 126 */     this.up = this.rotation.applyRotation(Point3D.createPoint3D(this.theta, this.phi - 1.5707963267948966D, this.rho));
/*     */     
/* 128 */     this.workspace = new double[3];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ViewPoint3D(Point3D p, double orientation) {
/* 138 */     this.rho = (float)Math.sqrt(p.x * p.x + p.y * p.y + p.z * p.z);
/* 139 */     if (Math.sqrt(p.x * p.x + p.y * p.y) > 1.0E-6D) {
/* 140 */       this.theta = (float)Math.atan2(p.y, p.x);
/*     */     }
/* 142 */     this.phi = (float)Math.acos(p.z / this.rho);
/* 143 */     updateMatrixElements();
/* 144 */     this.rotation = new Rotate3D(Point3D.ORIGIN, Point3D.UNIT_Z, orientation);
/*     */     
/* 146 */     this.up = this.rotation.applyRotation(Point3D.createPoint3D(this.theta, this.phi - 1.5707963267948966D, this.rho));
/*     */     
/* 148 */     this.workspace = new double[3];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final double getTheta() {
/* 160 */     return this.theta;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final double getPhi() {
/* 173 */     return this.phi;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final double getRho() {
/* 184 */     return this.rho;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRho(double rho) {
/* 193 */     this.rho = rho;
/* 194 */     this.up = Point3D.createPoint3D(this.up.getTheta(), this.up.getPhi(), rho);
/*     */     
/* 196 */     updateMatrixElements();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final double getX() {
/* 206 */     return this.rho * Math.sin(this.phi) * Math.cos(this.theta);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final double getY() {
/* 216 */     return this.rho * Math.sin(this.phi) * Math.sin(this.theta);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final double getZ() {
/* 226 */     return this.rho * Math.cos(this.phi);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Point3D getPoint() {
/* 236 */     return new Point3D(getX(), getY(), getZ());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double calcRollAngle() {
/* 248 */     Point3D vp = getPoint();
/* 249 */     Point3D n1 = Utils3D.normal(vp, this.up, Point3D.ORIGIN);
/* 250 */     Point3D screenup = Point3D.createPoint3D(this.theta, this.phi - 1.5707963267948966D, this.rho);
/*     */     
/* 252 */     Point3D n2 = Utils3D.normal(vp, screenup, Point3D.ORIGIN);
/* 253 */     double angle = Utils3D.angle(n1, n2);
/* 254 */     if (Utils3D.scalarprod(n1, screenup) >= 0.0D) {
/* 255 */       return angle;
/*     */     }
/* 257 */     return -angle;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void panLeftRight(double delta) {
/* 267 */     Point3D v = getVerticalRotationAxis();
/* 268 */     Rotate3D r = new Rotate3D(Point3D.ORIGIN, v, delta);
/* 269 */     Point3D p = r.applyRotation(getX(), getY(), getZ());
/* 270 */     this.theta = p.getTheta();
/* 271 */     this.phi = p.getPhi();
/* 272 */     updateMatrixElements();
/* 273 */     this.rotation.setAngle(calcRollAngle());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void moveUpDown(double delta) {
/* 282 */     Point3D v = getHorizontalRotationAxis();
/* 283 */     Rotate3D r = new Rotate3D(Point3D.ORIGIN, v, delta);
/* 284 */     Point3D p = r.applyRotation(getX(), getY(), getZ());
/* 285 */     this.up = r.applyRotation(this.up);
/* 286 */     this.theta = p.getTheta();
/* 287 */     this.phi = p.getPhi();
/* 288 */     updateMatrixElements();
/* 289 */     this.rotation.setAngle(calcRollAngle());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void roll(double delta) {
/* 299 */     Rotate3D r = new Rotate3D(getPoint(), Point3D.ORIGIN, delta);
/* 300 */     this.up = r.applyRotation(this.up);
/* 301 */     this.rotation.setAngle(calcRollAngle());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Point3D worldToEye(Point3D p) {
/* 312 */     double x = this.v11 * p.x + this.v21 * p.y;
/* 313 */     double y = this.v12 * p.x + this.v22 * p.y + this.v32 * p.z;
/* 314 */     double z = this.v13 * p.x + this.v23 * p.y + this.v33 * p.z + this.v43;
/* 315 */     double[] rotated = this.rotation.applyRotation(x, y, z, this.workspace);
/* 316 */     return new Point3D(rotated[0], rotated[1], rotated[2]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Point2D worldToScreen(Point3D p, double d) {
/* 329 */     double x = this.v11 * p.x + this.v21 * p.y;
/* 330 */     double y = this.v12 * p.x + this.v22 * p.y + this.v32 * p.z;
/* 331 */     double z = this.v13 * p.x + this.v23 * p.y + this.v33 * p.z + this.v43;
/* 332 */     double[] rotated = this.rotation.applyRotation(x, y, z, this.workspace);
/* 333 */     return new Point2D.Double(-d * rotated[0] / rotated[2], -d * rotated[1] / rotated[2]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float optimalDistance(Dimension2D target, Dimension3D dim3D, double projDist) {
/* 352 */     ViewPoint3D vp = new ViewPoint3D(this.theta, this.phi, this.rho, calcRollAngle());
/* 353 */     float near = (float)dim3D.getDiagonalLength();
/* 354 */     float far = near * 40.0F;
/*     */     
/* 356 */     World w = new World();
/* 357 */     double ww = dim3D.getWidth();
/* 358 */     double hh = dim3D.getHeight();
/* 359 */     double dd = dim3D.getDepth();
/* 360 */     w.add(Object3D.createBox(0.0D, ww, 0.0D, hh, 0.0D, dd, Color.RED));
/*     */     
/*     */     while (true) {
/* 363 */       vp.setRho(near);
/* 364 */       Point2D[] nearpts = w.calculateProjectedPoints(vp, projDist);
/* 365 */       Dimension neardim = Utils2D.findDimension(nearpts);
/* 366 */       double nearcover = coverage(neardim, target);
/* 367 */       vp.setRho(far);
/* 368 */       Point2D[] farpts = w.calculateProjectedPoints(vp, projDist);
/* 369 */       Dimension fardim = Utils2D.findDimension(farpts);
/* 370 */       double farcover = coverage(fardim, target);
/* 371 */       if (nearcover <= 1.0D) {
/* 372 */         return near;
/*     */       }
/* 374 */       if (farcover >= 1.0D) {
/* 375 */         return far;
/*     */       }
/*     */ 
/*     */       
/* 379 */       float mid = (near + far) / 2.0F;
/* 380 */       vp.setRho(mid);
/* 381 */       Point2D[] midpts = w.calculateProjectedPoints(vp, projDist);
/* 382 */       Dimension middim = Utils2D.findDimension(midpts);
/* 383 */       double midcover = coverage(middim, target);
/* 384 */       if (midcover >= 1.0D) {
/* 385 */         near = mid; continue;
/*     */       } 
/* 387 */       far = mid;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private double coverage(Dimension2D d, Dimension2D target) {
/* 393 */     double wpercent = d.getWidth() / target.getWidth();
/* 394 */     double hpercent = d.getHeight() / target.getHeight();
/* 395 */     if (wpercent <= 1.0D && hpercent <= 1.0D) {
/* 396 */       return Math.max(wpercent, hpercent);
/*     */     }
/* 398 */     if (wpercent >= 1.0D) {
/* 399 */       if (hpercent >= 1.0D) {
/* 400 */         return Math.max(wpercent, hpercent);
/*     */       }
/* 402 */       return wpercent;
/*     */     } 
/*     */     
/* 405 */     return hpercent;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void updateMatrixElements() {
/* 414 */     float cosTheta = (float)Math.cos(this.theta);
/* 415 */     float sinTheta = (float)Math.sin(this.theta);
/* 416 */     float cosPhi = (float)Math.cos(this.phi);
/* 417 */     float sinPhi = (float)Math.sin(this.phi);
/* 418 */     this.v11 = -sinTheta;
/* 419 */     this.v12 = (-cosPhi * cosTheta);
/* 420 */     this.v13 = (sinPhi * cosTheta);
/* 421 */     this.v21 = cosTheta;
/* 422 */     this.v22 = (-cosPhi * sinTheta);
/* 423 */     this.v23 = (sinPhi * sinTheta);
/* 424 */     this.v32 = sinPhi;
/* 425 */     this.v33 = cosPhi;
/* 426 */     this.v43 = -this.rho;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Point3D getVerticalRotationAxis() {
/* 438 */     return this.up;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Point3D getHorizontalRotationAxis() {
/* 448 */     return Utils3D.normal(getPoint(), this.up, Point3D.ORIGIN);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 459 */     return "[theta=" + this.theta + ", phi=" + this.phi + ", rho=" + this.rho + "]";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 472 */     if (obj == this) {
/* 473 */       return true;
/*     */     }
/* 475 */     if (!(obj instanceof ViewPoint3D)) {
/* 476 */       return false;
/*     */     }
/* 478 */     ViewPoint3D that = (ViewPoint3D)obj;
/* 479 */     if (this.theta != that.theta) {
/* 480 */       return false;
/*     */     }
/* 482 */     if (this.phi != that.phi) {
/* 483 */       return false;
/*     */     }
/* 485 */     if (this.rho != that.rho) {
/* 486 */       return false;
/*     */     }
/* 488 */     if (!this.up.equals(that.up)) {
/* 489 */       return false;
/*     */     }
/* 491 */     return true;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/graphics3d/ViewPoint3D.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */