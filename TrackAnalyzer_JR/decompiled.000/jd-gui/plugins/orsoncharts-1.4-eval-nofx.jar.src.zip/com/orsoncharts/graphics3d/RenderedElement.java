/*     */ package com.orsoncharts.graphics3d;
/*     */ 
/*     */ import com.orsoncharts.util.ArgChecks;
/*     */ import java.awt.Shape;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RenderedElement
/*     */ {
/*     */   public static final String TYPE = "type";
/*     */   public static final String BOUNDS = "bounds";
/*     */   private final Map<String, Object> properties;
/*     */   
/*     */   public RenderedElement(Object type, Shape bounds) {
/*  47 */     ArgChecks.nullNotPermitted(type, "type");
/*  48 */     this.properties = new HashMap<String, Object>();
/*  49 */     this.properties.put("type", type);
/*  50 */     this.properties.put("bounds", bounds);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getType() {
/*  59 */     return this.properties.get("type");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getProperty(String key) {
/*  71 */     return this.properties.get(key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setProperty(String key, Object value) {
/*  81 */     this.properties.put(key, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void clearProperties() {
/*  88 */     this.properties.clear();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/*  99 */     StringBuilder sb = new StringBuilder();
/* 100 */     Object type = this.properties.get("type");
/* 101 */     sb.append("RenderedElement[").append(type).append(",")
/* 102 */       .append(this.properties.entrySet()).append("]");
/* 103 */     return sb.toString();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/graphics3d/RenderedElement.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */