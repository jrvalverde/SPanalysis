/*    */ package com.orsoncharts.graphics3d.swing;
/*    */ 
/*    */ import com.orsoncharts.Resources;
/*    */ import com.orsoncharts.util.ArgChecks;
/*    */ import java.awt.event.ActionEvent;
/*    */ import javax.swing.AbstractAction;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DownAction
/*    */   extends AbstractAction
/*    */ {
/*    */   private Panel3D panel;
/*    */   
/*    */   public DownAction(Panel3D panel) {
/* 39 */     super("");
/* 40 */     ArgChecks.nullNotPermitted(panel, "panel");
/* 41 */     this.panel = panel;
/* 42 */     putValue("ShortDescription", 
/* 43 */         Resources.localString("DOWN_ACTION_SHORT_DESCRIPTION"));
/*    */   }
/*    */ 
/*    */   
/*    */   public void actionPerformed(ActionEvent e) {
/* 48 */     double delta = this.panel.getRotateIncrement();
/* 49 */     this.panel.getViewPoint().moveUpDown(-delta);
/* 50 */     this.panel.repaint();
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/graphics3d/swing/DownAction.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */