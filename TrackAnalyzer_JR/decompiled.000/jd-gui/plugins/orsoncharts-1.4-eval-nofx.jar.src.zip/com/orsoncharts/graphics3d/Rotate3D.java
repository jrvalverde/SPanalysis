/*     */ package com.orsoncharts.graphics3d;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Rotate3D
/*     */   implements Serializable
/*     */ {
/*     */   Point3D a;
/*     */   Point3D b;
/*     */   double angle;
/*     */   double r11;
/*     */   double r12;
/*     */   double r13;
/*     */   double r21;
/*     */   double r22;
/*     */   double r23;
/*     */   double r31;
/*     */   double r32;
/*     */   double r33;
/*     */   double r41;
/*     */   double r42;
/*     */   double r43;
/*     */   
/*     */   public Rotate3D(Point3D a, Point3D b, double angle) {
/*  59 */     this.a = a;
/*  60 */     this.b = b;
/*  61 */     this.angle = angle;
/*  62 */     double v1 = b.x - a.x;
/*  63 */     double v2 = b.y - a.y;
/*  64 */     double v3 = b.z - a.z;
/*  65 */     double theta = Math.atan2(v2, v1);
/*  66 */     double phi = Math.atan2(Math.sqrt(v1 * v1 + v2 * v2), v3);
/*  67 */     initRotate(a, theta, phi, angle);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getAngle() {
/*  76 */     return this.angle;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAngle(double angle) {
/*  87 */     this.angle = angle;
/*  88 */     double v1 = this.b.x - this.a.x;
/*  89 */     double v2 = this.b.y - this.a.y;
/*  90 */     double v3 = this.b.z - this.a.z;
/*  91 */     double theta = Math.atan2(v2, v1);
/*  92 */     double phi = Math.atan2(Math.sqrt(v1 * v1 + v2 * v2), v3);
/*  93 */     initRotate(this.a, theta, phi, angle);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void initRotate(Point3D a, double theta, double phi, double alpha) {
/* 105 */     double cosAlpha = Math.cos(alpha);
/* 106 */     double sinAlpha = Math.sin(alpha);
/* 107 */     double cosPhi = Math.cos(phi);
/* 108 */     double cosPhi2 = cosPhi * cosPhi;
/* 109 */     double sinPhi = Math.sin(phi);
/* 110 */     double sinPhi2 = sinPhi * sinPhi;
/* 111 */     double cosTheta = Math.cos(theta);
/* 112 */     double cosTheta2 = cosTheta * cosTheta;
/* 113 */     double sinTheta = Math.sin(theta);
/* 114 */     double sinTheta2 = sinTheta * sinTheta;
/* 115 */     double a1 = a.x;
/* 116 */     double a2 = a.y;
/* 117 */     double a3 = a.z;
/* 118 */     double c = 1.0D - cosAlpha;
/* 119 */     this.r11 = cosTheta2 * (cosAlpha * cosPhi2 + sinPhi2) + cosAlpha * sinTheta2;
/*     */     
/* 121 */     this.r12 = sinAlpha * cosPhi + c * sinPhi2 * cosTheta * sinTheta;
/* 122 */     this.r13 = sinPhi * (cosPhi * cosTheta * c - sinAlpha * sinTheta);
/* 123 */     this.r21 = sinPhi2 * cosTheta * sinTheta * c - sinAlpha * cosPhi;
/* 124 */     this.r22 = sinTheta2 * (cosAlpha * cosPhi2 + sinPhi2) + cosAlpha * cosTheta2;
/*     */     
/* 126 */     this.r23 = sinPhi * (cosPhi * sinTheta * c + sinAlpha * cosTheta);
/* 127 */     this.r31 = sinPhi * (cosPhi * cosTheta * c + sinAlpha * sinTheta);
/* 128 */     this.r32 = sinPhi * (cosPhi * sinTheta * c - sinAlpha * cosTheta);
/* 129 */     this.r33 = cosAlpha * sinPhi2 + cosPhi2;
/* 130 */     this.r41 = a1 - a1 * this.r11 - a2 * this.r21 - a3 * this.r31;
/* 131 */     this.r42 = a2 - a1 * this.r12 - a2 * this.r22 - a3 * this.r32;
/* 132 */     this.r43 = a3 - a1 * this.r13 - a2 * this.r23 - a3 * this.r33;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Point3D applyRotation(Point3D p) {
/* 144 */     return applyRotation(p.x, p.y, p.z);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Point3D applyRotation(double x, double y, double z) {
/* 159 */     return new Point3D(x * this.r11 + y * this.r21 + z * this.r31 + this.r41, x * this.r12 + y * this.r22 + z * this.r32 + this.r42, x * this.r13 + y * this.r23 + z * this.r33 + this.r43);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double[] applyRotation(double x, double y, double z, double[] result) {
/* 180 */     if (result == null) {
/* 181 */       result = new double[3];
/*     */     }
/* 183 */     result[0] = x * this.r11 + y * this.r21 + z * this.r31 + this.r41;
/* 184 */     result[1] = x * this.r12 + y * this.r22 + z * this.r32 + this.r42;
/* 185 */     result[2] = x * this.r13 + y * this.r23 + z * this.r33 + this.r43;
/* 186 */     return result;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/graphics3d/Rotate3D.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */