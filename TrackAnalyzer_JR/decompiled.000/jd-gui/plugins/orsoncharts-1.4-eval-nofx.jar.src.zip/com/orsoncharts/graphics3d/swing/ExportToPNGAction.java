/*    */ package com.orsoncharts.graphics3d.swing;
/*    */ 
/*    */ import com.orsoncharts.Resources;
/*    */ import com.orsoncharts.util.ArgChecks;
/*    */ import java.awt.Graphics2D;
/*    */ import java.awt.Rectangle;
/*    */ import java.awt.event.ActionEvent;
/*    */ import java.awt.geom.Dimension2D;
/*    */ import java.awt.image.BufferedImage;
/*    */ import java.io.File;
/*    */ import java.io.IOException;
/*    */ import javax.imageio.ImageIO;
/*    */ import javax.swing.AbstractAction;
/*    */ import javax.swing.JFileChooser;
/*    */ import javax.swing.filechooser.FileNameExtensionFilter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ExportToPNGAction
/*    */   extends AbstractAction
/*    */ {
/*    */   private Panel3D panel;
/*    */   
/*    */   public ExportToPNGAction(Panel3D panel) {
/* 50 */     super(Resources.localString("PNG_MENU_LABEL"));
/* 51 */     ArgChecks.nullNotPermitted(panel, "panel");
/* 52 */     this.panel = panel;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void actionPerformed(ActionEvent e) {
/* 62 */     JFileChooser fileChooser = new JFileChooser();
/*    */     
/* 64 */     FileNameExtensionFilter filter = new FileNameExtensionFilter(Resources.localString("PNG_FILE_FILTER_DESCRIPTION"), new String[] { "png" });
/* 65 */     fileChooser.addChoosableFileFilter(filter);
/* 66 */     fileChooser.setFileFilter(filter);
/*    */     
/* 68 */     int option = fileChooser.showSaveDialog(this.panel);
/* 69 */     if (option == 0) {
/* 70 */       String filename = fileChooser.getSelectedFile().getPath();
/* 71 */       if (!filename.endsWith(".png")) {
/* 72 */         filename = filename + ".png";
/*    */       }
/* 74 */       Dimension2D size = this.panel.getSize();
/* 75 */       int w = (int)size.getWidth();
/* 76 */       int h = (int)size.getHeight();
/* 77 */       BufferedImage image = new BufferedImage(w, h, 2);
/*    */       
/* 79 */       Graphics2D g2 = image.createGraphics();
/* 80 */       this.panel.getDrawable().draw(g2, new Rectangle(w, h));
/*    */       try {
/* 82 */         ImageIO.write(image, "png", new File(filename));
/* 83 */       } catch (IOException ex) {
/* 84 */         throw new RuntimeException(ex);
/*    */       } 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/graphics3d/swing/ExportToPNGAction.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */