/*     */ package com.orsoncharts.graphics3d.swing;
/*     */ 
/*     */ import com.orsoncharts.graphics3d.Dimension3D;
/*     */ import com.orsoncharts.graphics3d.Drawable3D;
/*     */ import com.orsoncharts.graphics3d.ExportUtils;
/*     */ import com.orsoncharts.graphics3d.Offset2D;
/*     */ import com.orsoncharts.graphics3d.RenderingInfo;
/*     */ import com.orsoncharts.graphics3d.ViewPoint3D;
/*     */ import com.orsoncharts.util.ArgChecks;
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.Insets;
/*     */ import java.awt.Point;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.awt.event.MouseListener;
/*     */ import java.awt.event.MouseMotionListener;
/*     */ import java.awt.event.MouseWheelEvent;
/*     */ import java.awt.event.MouseWheelListener;
/*     */ import java.awt.geom.AffineTransform;
/*     */ import java.awt.geom.Dimension2D;
/*     */ import java.io.File;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.ToolTipManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Panel3D
/*     */   extends JPanel
/*     */   implements MouseListener, MouseMotionListener, MouseWheelListener
/*     */ {
/*     */   private Drawable3D drawable;
/*     */   private double minViewingDistance;
/*     */   private double maxViewingDistanceMultiplier;
/*     */   private double margin;
/*     */   private double panIncrement;
/*     */   private double rotateIncrement;
/*     */   private double rollIncrement;
/*     */   private Point lastClickPoint;
/*     */   private Point lastMovePoint;
/*     */   private Offset2D offsetAtMousePressed;
/*     */   private RenderingInfo renderingInfo;
/*     */   
/*     */   public Panel3D(Drawable3D drawable) {
/* 110 */     super(new BorderLayout());
/* 111 */     ArgChecks.nullNotPermitted(drawable, "drawable");
/* 112 */     this.drawable = drawable;
/* 113 */     this.margin = 0.25D;
/* 114 */     this
/* 115 */       .minViewingDistance = drawable.getDimensions().getDiagonalLength();
/* 116 */     this.maxViewingDistanceMultiplier = 8.0D;
/* 117 */     this.panIncrement = 0.05235987755982988D;
/* 118 */     this.rotateIncrement = 0.05235987755982988D;
/* 119 */     this.rollIncrement = 0.05235987755982988D;
/* 120 */     addMouseListener(this);
/* 121 */     addMouseMotionListener(this);
/* 122 */     addMouseWheelListener(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Drawable3D getDrawable() {
/* 133 */     return this.drawable;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getMargin() {
/* 145 */     return this.margin;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMargin(double margin) {
/* 156 */     this.margin = margin;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getMinViewingDistance() {
/* 168 */     return this.minViewingDistance;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getMaxViewingDistanceMultiplier() {
/* 180 */     return this.maxViewingDistanceMultiplier;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMaxViewingDistanceMultiplier(double multiplier) {
/* 191 */     this.maxViewingDistanceMultiplier = multiplier;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getPanIncrement() {
/* 201 */     return this.panIncrement;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPanIncrement(double panIncrement) {
/* 211 */     this.panIncrement = panIncrement;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getRotateIncrement() {
/* 221 */     return this.rotateIncrement;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRotateIncrement(double rotateIncrement) {
/* 230 */     this.rotateIncrement = rotateIncrement;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getRollIncrement() {
/* 240 */     return this.rollIncrement;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRollIncrement(double rollIncrement) {
/* 249 */     this.rollIncrement = rollIncrement;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ViewPoint3D getViewPoint() {
/* 259 */     return this.drawable.getViewPoint();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setViewPoint(ViewPoint3D vp) {
/* 268 */     ArgChecks.nullNotPermitted(vp, "vp");
/* 269 */     this.drawable.setViewPoint(vp);
/* 270 */     repaint();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Point getLastClickPoint() {
/* 279 */     return this.lastClickPoint;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected RenderingInfo getRenderingInfo() {
/* 289 */     return this.renderingInfo;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void panLeftRight(double angle) {
/* 300 */     this.drawable.getViewPoint().panLeftRight(angle);
/* 301 */     repaint();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void zoomToFit() {
/* 310 */     zoomToFit(getSize());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void zoomToFit(Dimension2D size) {
/* 321 */     int w = (int)(size.getWidth() * (1.0D - this.margin));
/* 322 */     int h = (int)(size.getHeight() * (1.0D - this.margin));
/* 323 */     Dimension2D target = new Dimension(w, h);
/* 324 */     Dimension3D d3d = this.drawable.getDimensions();
/* 325 */     float distance = this.drawable.getViewPoint().optimalDistance(target, d3d, this.drawable
/* 326 */         .getProjDistance());
/* 327 */     this.drawable.getViewPoint().setRho(distance);
/* 328 */     repaint();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void paintComponent(Graphics g) {
/* 340 */     super.paintComponent(g);
/* 341 */     Graphics2D g2 = (Graphics2D)g;
/* 342 */     AffineTransform saved = g2.getTransform();
/* 343 */     Dimension size = getSize();
/* 344 */     Insets insets = getInsets();
/* 345 */     Rectangle drawArea = new Rectangle(insets.left, insets.top, size.width - insets.left - insets.right, size.height - insets.top - insets.bottom);
/*     */ 
/*     */     
/* 348 */     this.renderingInfo = this.drawable.draw(g2, drawArea);
/* 349 */     g2.setTransform(saved);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void registerForTooltips() {
/* 358 */     ToolTipManager.sharedInstance().registerComponent(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void unregisterForTooltips() {
/* 367 */     ToolTipManager.sharedInstance().unregisterComponent(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void mouseClicked(MouseEvent e) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void mouseEntered(MouseEvent e) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void mouseExited(MouseEvent e) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void mousePressed(MouseEvent e) {
/* 401 */     this.lastClickPoint = e.getPoint();
/* 402 */     this.lastMovePoint = this.lastClickPoint;
/* 403 */     this.offsetAtMousePressed = this.drawable.getTranslate2D();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void mouseReleased(MouseEvent e) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void mouseDragged(MouseEvent e) {
/* 419 */     if (e.isAltDown()) {
/* 420 */       Point currPt = e.getPoint();
/* 421 */       Offset2D offset = this.offsetAtMousePressed;
/* 422 */       Point lastPt = getLastClickPoint();
/* 423 */       double dx = offset.getDX() + (currPt.x - lastPt.x);
/* 424 */       double dy = offset.getDY() + (currPt.y - lastPt.y);
/* 425 */       this.drawable.setTranslate2D(new Offset2D(dx, dy));
/*     */     } else {
/* 427 */       Point currPt = e.getPoint();
/* 428 */       int dx = currPt.x - this.lastMovePoint.x;
/* 429 */       int dy = currPt.y - this.lastMovePoint.y;
/* 430 */       this.lastMovePoint = currPt;
/* 431 */       this.drawable.getViewPoint().panLeftRight(-dx * Math.PI / 120.0D);
/* 432 */       this.drawable.getViewPoint().moveUpDown(-dy * Math.PI / 120.0D);
/* 433 */       repaint();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void mouseMoved(MouseEvent e) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void mouseWheelMoved(MouseWheelEvent mwe) {
/* 453 */     float units = mwe.getUnitsToScroll();
/* 454 */     double maxViewingDistance = this.maxViewingDistanceMultiplier * this.minViewingDistance;
/*     */     
/* 456 */     double valRho = Math.max(this.minViewingDistance, 
/* 457 */         Math.min(maxViewingDistance, this.drawable
/* 458 */           .getViewPoint().getRho() + units));
/* 459 */     this.drawable.getViewPoint().setRho(valRho);
/* 460 */     repaint();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void writeAsPDF(File file, int w, int h) {
/* 476 */     ExportUtils.writeAsPDF(this.drawable, w, h, file);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void writeAsSVG(File file, int w, int h) {
/* 492 */     ExportUtils.writeAsSVG(this.drawable, w, h, file);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/graphics3d/swing/Panel3D.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */