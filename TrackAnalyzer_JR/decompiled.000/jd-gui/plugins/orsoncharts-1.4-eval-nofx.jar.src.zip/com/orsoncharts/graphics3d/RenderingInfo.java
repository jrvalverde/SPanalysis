/*     */ package com.orsoncharts.graphics3d;
/*     */ 
/*     */ import java.awt.Shape;
/*     */ import java.awt.geom.Path2D;
/*     */ import java.awt.geom.Point2D;
/*     */ import java.awt.geom.Rectangle2D;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RenderingInfo
/*     */ {
/*     */   private List<Face> faces;
/*     */   Point2D[] projPts;
/*     */   private double dx;
/*     */   public double dy;
/*     */   List<RenderedElement> otherElements;
/*     */   List<RenderedElement> otherOffsetElements;
/*     */   
/*     */   public RenderingInfo(List<Face> faces, Point2D[] projPts, double dx, double dy) {
/*  62 */     this.faces = faces;
/*  63 */     this.projPts = projPts;
/*  64 */     this.dx = dx;
/*  65 */     this.dy = dy;
/*  66 */     this.otherElements = new ArrayList<RenderedElement>();
/*  67 */     this.otherOffsetElements = new ArrayList<RenderedElement>();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Face> getFaces() {
/*  76 */     return this.faces;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Point2D[] getProjectedPoints() {
/*  85 */     return this.projPts;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getDX() {
/*  99 */     return this.dx;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getDY() {
/* 108 */     return this.dy;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addElement(RenderedElement element) {
/* 117 */     this.otherElements.add(element);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addOffsetElement(RenderedElement element) {
/* 126 */     this.otherOffsetElements.add(element);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object3D fetchObjectAt(double x, double y) {
/* 138 */     for (int i = this.faces.size() - 1; i >= 0; i--) {
/* 139 */       Face f = this.faces.get(i);
/* 140 */       if (f instanceof LabelFace) {
/*     */         
/* 142 */         Rectangle2D bounds = (Rectangle2D)f.getOwner().getProperty("labelBounds");
/* 143 */         if (bounds != null && bounds.contains(x - this.dx, y - this.dy)) {
/* 144 */           return f.getOwner();
/*     */         }
/*     */       } else {
/* 147 */         Path2D p = f.createPath(this.projPts);
/* 148 */         if (p.contains(x - this.dx, y - this.dy)) {
/* 149 */           return f.getOwner();
/*     */         }
/*     */       } 
/*     */     } 
/* 153 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RenderedElement findElementAt(double x, double y) {
/*     */     int i;
/* 171 */     for (i = this.otherElements.size() - 1; i >= 0; i--) {
/* 172 */       RenderedElement element = this.otherElements.get(i);
/* 173 */       Shape bounds = (Shape)element.getProperty("bounds");
/* 174 */       if (bounds.contains(x, y)) {
/* 175 */         return element;
/*     */       }
/*     */     } 
/*     */     
/* 179 */     for (i = this.otherOffsetElements.size() - 1; i >= 0; i--) {
/* 180 */       RenderedElement element = this.otherOffsetElements.get(i);
/* 181 */       Shape bounds = (Shape)element.getProperty("bounds");
/* 182 */       if (bounds != null && bounds.contains(x - this.dx, y - this.dy)) {
/* 183 */         return element;
/*     */       }
/*     */     } 
/*     */     
/* 187 */     Object3D obj = fetchObjectAt(x, y);
/* 188 */     if (obj != null) {
/* 189 */       RenderedElement element = new RenderedElement("obj3d", null);
/* 190 */       element.setProperty("key", obj
/* 191 */           .getProperty("key"));
/* 192 */       if (obj.getProperty("class") != null) {
/* 193 */         element.setProperty("class", obj
/* 194 */             .getProperty("class"));
/*     */       }
/* 196 */       return element;
/*     */     } 
/* 198 */     return null;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/graphics3d/RenderingInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */