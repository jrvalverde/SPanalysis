/*     */ package com.orsoncharts.graphics3d;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Offset2D
/*     */   implements Serializable
/*     */ {
/*  29 */   public static final Offset2D ZERO_OFFSET = new Offset2D(0.0D, 0.0D);
/*     */ 
/*     */ 
/*     */   
/*     */   private double dx;
/*     */ 
/*     */   
/*     */   private double dy;
/*     */ 
/*     */ 
/*     */   
/*     */   public Offset2D() {
/*  41 */     this(0.0D, 0.0D);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Offset2D(double dx, double dy) {
/*  51 */     this.dx = dx;
/*  52 */     this.dy = dy;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getDX() {
/*  61 */     return this.dx;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getDY() {
/*  70 */     return this.dy;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/*  82 */     if (obj == this) {
/*  83 */       return true;
/*     */     }
/*  85 */     if (!(obj instanceof Offset2D)) {
/*  86 */       return false;
/*     */     }
/*  88 */     Offset2D that = (Offset2D)obj;
/*  89 */     if (this.dx != that.dx) {
/*  90 */       return false;
/*     */     }
/*  92 */     if (this.dy != that.dy) {
/*  93 */       return false;
/*     */     }
/*  95 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 105 */     int hash = 3;
/*     */     
/* 107 */     hash = 59 * hash + (int)(Double.doubleToLongBits(this.dx) ^ Double.doubleToLongBits(this.dx) >>> 32L);
/*     */     
/* 109 */     hash = 59 * hash + (int)(Double.doubleToLongBits(this.dy) ^ Double.doubleToLongBits(this.dy) >>> 32L);
/* 110 */     return hash;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/graphics3d/Offset2D.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */