/*     */ package com.orsoncharts.graphics3d;
/*     */ 
/*     */ import com.orsoncharts.util.ArgChecks;
/*     */ import java.awt.geom.Point2D;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.TreeMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class World
/*     */ {
/*     */   public static final String DEFAULT_PARTITION_KEY = "default";
/*     */   private double sunX;
/*     */   private double sunY;
/*     */   private double sunZ;
/*     */   private Map<String, List<Object3D>> objects;
/*     */   
/*     */   public World() {
/*  56 */     this.objects = new TreeMap<String, List<Object3D>>();
/*  57 */     this.objects.put("default", new ArrayList<Object3D>());
/*  58 */     setSunSource(new Point3D(2.0D, -1.0D, 10.0D));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getSunX() {
/*  68 */     return this.sunX;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getSunY() {
/*  77 */     return this.sunY;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getSunZ() {
/*  86 */     return this.sunZ;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setSunSource(double x, double y, double z) {
/*  99 */     setSunSource(new Point3D(x, y, z));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setSunSource(Point3D p) {
/* 110 */     ArgChecks.nullNotPermitted(p, "p");
/* 111 */     Point3D normal = Utils3D.normalise(p);
/* 112 */     this.sunX = normal.getX();
/* 113 */     this.sunY = normal.getY();
/* 114 */     this.sunZ = normal.getZ();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void add(Object3D object) {
/* 124 */     add("default", object);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void add(String partition, Object3D object) {
/* 136 */     ArgChecks.nullNotPermitted(partition, "partition");
/* 137 */     ArgChecks.nullNotPermitted(object, "object");
/* 138 */     List<Object3D> list = this.objects.get(partition);
/* 139 */     if (list == null) {
/* 140 */       list = new ArrayList<Object3D>();
/* 141 */       this.objects.put(partition, list);
/*     */     } 
/* 143 */     list.add(object);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addAll(Collection<Object3D> objects) {
/* 153 */     ArgChecks.nullNotPermitted(objects, "objects");
/* 154 */     for (Object3D object : objects) {
/* 155 */       add(object);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void clear(String partitionKey) {
/* 167 */     ArgChecks.nullNotPermitted(partitionKey, "partitionKey");
/* 168 */     this.objects.put(partitionKey, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getVertexCount() {
/* 177 */     int count = 0;
/* 178 */     for (Map.Entry<String, List<Object3D>> entry : this.objects.entrySet()) {
/* 179 */       List<Object3D> objs = entry.getValue();
/* 180 */       for (Object3D object : objs) {
/* 181 */         count += object.getVertexCount();
/*     */       }
/*     */     } 
/* 184 */     return count;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Point3D[] calculateEyeCoordinates(ViewPoint3D vp) {
/* 196 */     Point3D[] result = new Point3D[getVertexCount()];
/* 197 */     int index = 0;
/* 198 */     for (Map.Entry<String, List<Object3D>> entry : this.objects.entrySet()) {
/* 199 */       List<Object3D> objs = entry.getValue();
/* 200 */       for (Object3D object : objs) {
/* 201 */         Point3D[] vertices = object.calculateEyeCoordinates(vp);
/* 202 */         System.arraycopy(vertices, 0, result, index, vertices.length);
/* 203 */         index += vertices.length;
/*     */       } 
/*     */     } 
/* 206 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Point2D[] calculateProjectedPoints(ViewPoint3D vp, double d) {
/* 219 */     Point2D[] result = new Point2D[getVertexCount()];
/* 220 */     int index = 0;
/* 221 */     for (Map.Entry<String, List<Object3D>> entry : this.objects.entrySet()) {
/* 222 */       List<Object3D> objs = entry.getValue();
/* 223 */       for (Object3D object : objs) {
/* 224 */         Point2D[] pts = object.calculateProjectedPoints(vp, d);
/* 225 */         System.arraycopy(pts, 0, result, index, pts.length);
/* 226 */         index += pts.length;
/*     */       } 
/*     */     } 
/* 229 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Face> getFaces() {
/* 239 */     List<Face> result = new ArrayList<Face>();
/* 240 */     int offset = 0;
/* 241 */     for (Map.Entry<String, List<Object3D>> entry : this.objects.entrySet()) {
/* 242 */       List<Object3D> objs = entry.getValue();
/* 243 */       for (Object3D object : objs) {
/* 244 */         for (Face f : object.getFaces()) {
/* 245 */           f.setOffset(offset);
/*     */         }
/* 247 */         offset += object.getVertexCount();
/* 248 */         result.addAll(object.getFaces());
/*     */       } 
/*     */     } 
/* 251 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Object3D> getObjects() {
/* 263 */     List<Object3D> result = new ArrayList<Object3D>();
/* 264 */     for (Map.Entry<String, List<Object3D>> entry : this.objects.entrySet()) {
/* 265 */       List<Object3D> objs = entry.getValue();
/* 266 */       result.addAll(objs);
/*     */     } 
/* 268 */     return result;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/graphics3d/World.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */