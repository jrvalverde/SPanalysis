/*     */ package com.orsoncharts.graphics3d;
/*     */ 
/*     */ import com.orsoncharts.util.ArgChecks;
/*     */ import java.awt.Color;
/*     */ import java.awt.geom.Path2D;
/*     */ import java.awt.geom.Point2D;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Face
/*     */ {
/*     */   private Object3D owner;
/*     */   private int offset;
/*     */   private int[] vertices;
/*     */   
/*     */   public Face(Object3D owner, int[] vertices) {
/*  46 */     if (vertices.length < 3) {
/*  47 */       throw new IllegalArgumentException("Faces must have at least 3 vertices.");
/*     */     }
/*  49 */     ArgChecks.nullNotPermitted(owner, "owner");
/*  50 */     this.owner = owner;
/*  51 */     this.vertices = vertices;
/*  52 */     this.offset = 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object3D getOwner() {
/*  63 */     return this.owner;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getOffset() {
/*  72 */     return this.offset;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setOffset(int offset) {
/*  81 */     this.offset = offset;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getVertexCount() {
/*  90 */     return this.vertices.length;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getVertexIndex(int i) {
/* 101 */     return this.vertices[i] + this.offset;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Color getColor() {
/* 113 */     return this.owner.getColor(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getOutline() {
/* 124 */     return this.owner.getOutline(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getTag() {
/* 136 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double[] calculateNormal(Point3D[] points) {
/* 148 */     int iA = this.vertices[0] + this.offset;
/* 149 */     int iB = this.vertices[1] + this.offset;
/* 150 */     int iC = this.vertices[2] + this.offset;
/* 151 */     double aX = (points[iA]).x;
/* 152 */     double aY = (points[iA]).y;
/* 153 */     double aZ = (points[iA]).z;
/* 154 */     double bX = (points[iB]).x;
/* 155 */     double bY = (points[iB]).y;
/* 156 */     double bZ = (points[iB]).z;
/* 157 */     double cX = (points[iC]).x;
/* 158 */     double cY = (points[iC]).y;
/* 159 */     double cZ = (points[iC]).z;
/* 160 */     double u1 = bX - aX, u2 = bY - aY, u3 = bZ - aZ;
/* 161 */     double v1 = cX - aX, v2 = cY - aY, v3 = cZ - aZ;
/* 162 */     double a = u2 * v3 - u3 * v2;
/* 163 */     double b = u3 * v1 - u1 * v3;
/* 164 */     double c = u1 * v2 - u2 * v1;
/* 165 */     double len = Math.sqrt(a * a + b * b + c * c);
/* 166 */     a /= len; b /= len; c /= len;
/* 167 */     return new double[] { a, b, c };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float calculateAverageZValue(Point3D[] points) {
/* 178 */     float total = 0.0F;
/* 179 */     for (int i = 0; i < this.vertices.length; i++) {
/* 180 */       total += (float)(points[this.vertices[i] + this.offset]).z;
/*     */     }
/* 182 */     return total / this.vertices.length;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isFrontFacing(Point2D[] projPts) {
/* 194 */     return (Utils2D.area2(projPts[getVertexIndex(0)], projPts[
/* 195 */           getVertexIndex(1)], projPts[getVertexIndex(2)]) > 0.0D);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Path2D createPath(Point2D[] pts) {
/* 209 */     Path2D path = new Path2D.Float();
/* 210 */     for (int v = 0; v < getVertexCount(); v++) {
/* 211 */       Point2D pt = pts[getVertexIndex(v)];
/* 212 */       if (v == 0) {
/* 213 */         path.moveTo(pt.getX(), pt.getY());
/*     */       } else {
/* 215 */         path.lineTo(pt.getX(), pt.getY());
/*     */       } 
/*     */     } 
/* 218 */     path.closePath();
/* 219 */     return path;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 230 */     String result = "[";
/* 231 */     for (int i = 0; i < this.vertices.length; i++) {
/* 232 */       result = result + this.vertices[i];
/* 233 */       if (i < this.vertices.length - 1) {
/* 234 */         result = result + ", ";
/*     */       }
/*     */     } 
/* 237 */     return result + "]";
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/graphics3d/Face.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */