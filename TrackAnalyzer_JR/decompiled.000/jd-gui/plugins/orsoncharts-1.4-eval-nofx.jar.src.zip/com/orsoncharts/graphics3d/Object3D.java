/*     */ package com.orsoncharts.graphics3d;
/*     */ 
/*     */ import com.orsoncharts.util.ArgChecks;
/*     */ import java.awt.Color;
/*     */ import java.awt.Font;
/*     */ import java.awt.geom.Point2D;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Object3D
/*     */ {
/*     */   public static final String CLASS_KEY = "class";
/*     */   public static final String ITEM_KEY = "key";
/*     */   public static final String COLOR_PREFIX = "color/";
/*     */   private List<Point3D> vertices;
/*     */   private List<Face> faces;
/*     */   private Color color;
/*     */   private boolean outline;
/*     */   private Map<String, Object> properties;
/*     */   
/*     */   public Object3D(Color color) {
/*  86 */     this(color, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object3D(Color color, boolean outline) {
/*  99 */     ArgChecks.nullNotPermitted(color, "color");
/* 100 */     this.color = color;
/* 101 */     this.outline = outline;
/* 102 */     this.vertices = new ArrayList<Point3D>();
/* 103 */     this.faces = new ArrayList<Face>();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Color getColor() {
/* 114 */     return this.color;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getOutline() {
/* 125 */     return this.outline;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setOutline(boolean outline) {
/* 137 */     this.outline = outline;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getProperty(String key) {
/* 151 */     ArgChecks.nullNotPermitted(key, "key");
/* 152 */     if (this.properties == null) {
/* 153 */       return null;
/*     */     }
/* 155 */     return this.properties.get(key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setProperty(String key, Object value) {
/* 171 */     ArgChecks.nullNotPermitted(key, "key");
/* 172 */     if (this.properties == null) {
/* 173 */       this.properties = new HashMap<String, Object>();
/*     */     }
/* 175 */     this.properties.put(key, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Color getColor(Face face) {
/* 191 */     if (face.getTag() != null) {
/*     */       
/* 193 */       Object obj = getProperty("color/" + face.getTag());
/* 194 */       if (obj != null) {
/* 195 */         return (Color)obj;
/*     */       }
/*     */     } 
/* 198 */     return this.color;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getOutline(Face face) {
/* 212 */     return this.outline;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getVertexCount() {
/* 221 */     return this.vertices.size();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addVertex(double x, double y, double z) {
/* 232 */     addVertex(new Point3D(x, y, z));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addVertex(Point3D vertex) {
/* 241 */     ArgChecks.nullNotPermitted(vertex, "vertex");
/* 242 */     this.vertices.add(vertex);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getFaceCount() {
/* 251 */     return this.faces.size();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addFace(int[] vertices) {
/* 263 */     addFace(new Face(this, vertices));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addFace(int[] vertices, String tag) {
/* 275 */     addFace(new TaggedFace(this, vertices, tag));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addDoubleSidedFace(int[] vertices) {
/* 287 */     addFace(new DoubleSidedFace(this, vertices));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addFace(Face face) {
/* 296 */     ArgChecks.nullNotPermitted(face, "face");
/* 297 */     this.faces.add(face);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Face> getFaces() {
/* 309 */     return this.faces;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Point2D[] calculateProjectedPoints(ViewPoint3D viewPoint, double d) {
/* 322 */     ArgChecks.nullNotPermitted(viewPoint, "viewPoint");
/* 323 */     Point2D[] result = new Point2D[this.vertices.size()];
/* 324 */     int vertexCount = this.vertices.size();
/* 325 */     for (int i = 0; i < vertexCount; i++) {
/* 326 */       Point3D p = this.vertices.get(i);
/* 327 */       result[i] = viewPoint.worldToScreen(p, d);
/*     */     } 
/* 329 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Point3D[] calculateEyeCoordinates(ViewPoint3D viewPoint) {
/* 340 */     ArgChecks.nullNotPermitted(viewPoint, "viewPoint");
/* 341 */     Point3D[] result = new Point3D[this.vertices.size()];
/* 342 */     int i = 0;
/* 343 */     for (Point3D vertex : this.vertices) {
/* 344 */       result[i] = viewPoint.worldToEye(vertex);
/* 345 */       i++;
/*     */     } 
/* 347 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object3D createYSheet(double size, double x, double y, double z, Color color, boolean invert) {
/* 365 */     ArgChecks.nullNotPermitted(color, "color");
/* 366 */     Object3D sheet = new Object3D(color);
/* 367 */     double delta = size / 2.0D;
/* 368 */     sheet.addVertex(new Point3D(x + delta, y, z - delta));
/* 369 */     sheet.addVertex(new Point3D(x + delta, y, z + delta));
/* 370 */     sheet.addVertex(new Point3D(x - delta, y, z + delta));
/* 371 */     sheet.addVertex(new Point3D(x - delta, y, z - delta));
/* 372 */     if (invert) {
/* 373 */       sheet.addFace(new Face(sheet, new int[] { 3, 2, 1, 0 }));
/*     */     } else {
/* 375 */       sheet.addFace(new Face(sheet, new int[] { 0, 1, 2, 3 }));
/*     */     } 
/* 377 */     return sheet;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object3D createZSheet(double size, double x, double y, double z, Color color) {
/* 393 */     Object3D sheet = new Object3D(color);
/* 394 */     double delta = size / 2.0D;
/* 395 */     sheet.addVertex(new Point3D(x + delta, y - delta, z));
/* 396 */     sheet.addVertex(new Point3D(x + delta, y + delta, z));
/* 397 */     sheet.addVertex(new Point3D(x - delta, y + delta, z));
/* 398 */     sheet.addVertex(new Point3D(x - delta, y - delta, z));
/* 399 */     sheet.addFace(new Face(sheet, new int[] { 0, 1, 2, 3 }));
/* 400 */     return sheet;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object3D createCube(double size, double x, double y, double z, Color color) {
/* 417 */     return createBox(x, size, y, size, z, size, color);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object3D createBox(double x, double xdim, double y, double ydim, double z, double zdim, Color color) {
/* 438 */     ArgChecks.nullNotPermitted(color, "color");
/* 439 */     Object3D box = new Object3D(color);
/* 440 */     double xdelta = xdim / 2.0D;
/* 441 */     double ydelta = ydim / 2.0D;
/* 442 */     double zdelta = zdim / 2.0D;
/* 443 */     box.addVertex(new Point3D(x - xdelta, y - ydelta, z - zdelta));
/* 444 */     box.addVertex(new Point3D(x + xdelta, y - ydelta, z - zdelta));
/* 445 */     box.addVertex(new Point3D(x + xdelta, y - ydelta, z + zdelta));
/* 446 */     box.addVertex(new Point3D(x - xdelta, y - ydelta, z + zdelta));
/* 447 */     box.addVertex(new Point3D(x - xdelta, y + ydelta, z - zdelta));
/* 448 */     box.addVertex(new Point3D(x + xdelta, y + ydelta, z - zdelta));
/* 449 */     box.addVertex(new Point3D(x + xdelta, y + ydelta, z + zdelta));
/* 450 */     box.addVertex(new Point3D(x - xdelta, y + ydelta, z + zdelta));
/* 451 */     box.addFace(new Face(box, new int[] { 4, 5, 1, 0 }));
/* 452 */     box.addFace(new Face(box, new int[] { 5, 6, 2, 1 }));
/* 453 */     box.addFace(new Face(box, new int[] { 6, 7, 3, 2 }));
/* 454 */     box.addFace(new Face(box, new int[] { 3, 7, 4, 0 }));
/* 455 */     box.addFace(new Face(box, new int[] { 7, 6, 5, 4 }));
/* 456 */     box.addFace(new Face(box, new int[] { 0, 1, 2, 3 }));
/* 457 */     return box;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object3D createTetrahedron(double size, double xOffset, double yOffset, double zOffset, Color color) {
/* 473 */     ArgChecks.nullNotPermitted(color, "color");
/* 474 */     Object3D tetra = new Object3D(color);
/* 475 */     tetra.addVertex(new Point3D(size + xOffset, -size + yOffset, -size + zOffset));
/*     */     
/* 477 */     tetra.addVertex(new Point3D(-size + xOffset, size + yOffset, -size + zOffset));
/*     */     
/* 479 */     tetra.addVertex(new Point3D(size + xOffset, size + yOffset, size + zOffset));
/*     */     
/* 481 */     tetra.addVertex(new Point3D(-size + xOffset, -size + yOffset, size + zOffset));
/*     */     
/* 483 */     tetra.addFace(new Face(tetra, new int[] { 0, 1, 2 }));
/* 484 */     tetra.addFace(new Face(tetra, new int[] { 1, 3, 2 }));
/* 485 */     tetra.addFace(new Face(tetra, new int[] { 0, 3, 1 }));
/* 486 */     tetra.addFace(new Face(tetra, new int[] { 0, 2, 3 }));
/* 487 */     return tetra;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object3D createOctahedron(double size, double xOffset, double yOffset, double zOffset, Color color) {
/* 503 */     ArgChecks.nullNotPermitted(color, "color");
/* 504 */     Object3D octa = new Object3D(color);
/* 505 */     octa.addVertex(new Point3D(size + xOffset, 0.0D + yOffset, 0.0D + zOffset));
/* 506 */     octa.addVertex(new Point3D(0.0D + xOffset, size + yOffset, 0.0D + zOffset));
/* 507 */     octa.addVertex(new Point3D(-size + xOffset, 0.0D + yOffset, 0.0D + zOffset));
/* 508 */     octa.addVertex(new Point3D(0.0D + xOffset, -size + yOffset, 0.0D + zOffset));
/* 509 */     octa.addVertex(new Point3D(0.0D + xOffset, 0.0D + yOffset, -size + zOffset));
/* 510 */     octa.addVertex(new Point3D(0.0D + xOffset, 0.0D + yOffset, size + zOffset));
/*     */     
/* 512 */     octa.addFace(new Face(octa, new int[] { 0, 1, 5 }));
/* 513 */     octa.addFace(new Face(octa, new int[] { 1, 2, 5 }));
/* 514 */     octa.addFace(new Face(octa, new int[] { 2, 3, 5 }));
/* 515 */     octa.addFace(new Face(octa, new int[] { 3, 0, 5 }));
/* 516 */     octa.addFace(new Face(octa, new int[] { 1, 0, 4 }));
/* 517 */     octa.addFace(new Face(octa, new int[] { 2, 1, 4 }));
/* 518 */     octa.addFace(new Face(octa, new int[] { 3, 2, 4 }));
/* 519 */     octa.addFace(new Face(octa, new int[] { 0, 3, 4 }));
/* 520 */     return octa;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object3D createSphere(double radius, int n, double x, double y, double z, Color extColor, Color intColor) {
/* 538 */     Object3D sphere = new Object3D(extColor);
/* 539 */     sphere.setProperty("color/interior", intColor);
/* 540 */     double theta = Math.PI / n;
/* 541 */     Point3D[] prevLayer = new Point3D[n * 2 + 1];
/* 542 */     for (int i = 0; i <= n * 2; i++) {
/* 543 */       prevLayer[i] = new Point3D(x, y + radius, z);
/* 544 */       if (i != n * 2) {
/* 545 */         sphere.addVertex(prevLayer[i]);
/*     */       }
/*     */     } 
/*     */     
/* 549 */     for (int layer = 1; layer < n; layer++) {
/* 550 */       Point3D[] currLayer = new Point3D[n * 2 + 1];
/* 551 */       for (int j = 0; j <= n * 2; j++) {
/*     */         
/* 553 */         double xx = radius * Math.cos(j * theta) * Math.sin(layer * theta);
/* 554 */         double yy = radius * Math.cos(layer * theta);
/*     */         
/* 556 */         double zz = radius * Math.sin(j * theta) * Math.sin(layer * theta);
/* 557 */         currLayer[j] = new Point3D(x + xx, y + yy, z + zz);
/* 558 */         if (j != n * 2) {
/* 559 */           sphere.addVertex(currLayer[j]);
/*     */         }
/* 561 */         if (j > 0 && layer > 1) {
/* 562 */           if (j != n * 2) {
/* 563 */             Face f = new Face(sphere, new int[] { (layer - 1) * n * 2 + j - 1, (layer - 1) * n * 2 + j, layer * n * 2 + j, layer * n * 2 + j - 1 });
/*     */ 
/*     */ 
/*     */             
/* 567 */             sphere.addFace(f);
/* 568 */             f = new TaggedFace(sphere, new int[] { layer * n * 2 + j - 1, layer * n * 2 + j, (layer - 1) * n * 2 + j, (layer - 1) * n * 2 + j - 1 }, "interior");
/*     */ 
/*     */ 
/*     */             
/* 572 */             sphere.addFace(f);
/*     */           } else {
/*     */             
/* 575 */             sphere.addFace(new Face(sphere, new int[] { (layer - 1) * n * 2 + j - 1, (layer - 1) * n * 2, layer * n * 2, layer * n * 2 + j - 1 }));
/*     */ 
/*     */             
/* 578 */             sphere.addFace(new TaggedFace(sphere, new int[] { layer * n * 2 + j - 1, layer * n * 2, (layer - 1) * n * 2, (layer - 1) * n * 2 + j - 1 }, "interior"));
/*     */           } 
/*     */         }
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 586 */     return sphere;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object3D createPieSegment(double radius, double explodeRadius, double base, double height, double angle1, double angle2, double inc, Color color) {
/* 606 */     ArgChecks.nullNotPermitted(color, "color");
/* 607 */     Object3D segment = new Object3D(color, true);
/* 608 */     double angleCentre = (angle1 + angle2) / 2.0D;
/*     */     
/* 610 */     Point3D centre = new Point3D(explodeRadius * Math.cos(angleCentre), base, explodeRadius * Math.sin(angleCentre));
/* 611 */     float cx = (float)centre.x;
/* 612 */     float cz = (float)centre.z;
/* 613 */     segment.addVertex(new Point3D(cx + 0.0D, base, cz + 0.0D));
/* 614 */     segment.addVertex(new Point3D(cx + 0.0D, base + height, cz + 0.0D));
/*     */     
/* 616 */     Point3D v0 = new Point3D(cx + radius * Math.cos(angle1), base, cz + radius * Math.sin(angle1));
/*     */     
/* 618 */     Point3D v1 = new Point3D(cx + radius * Math.cos(angle1), base + height, cz + radius * Math.sin(angle1));
/* 619 */     segment.addVertex(v0);
/* 620 */     segment.addVertex(v1);
/* 621 */     segment.addFace(new Face(segment, new int[] { 1, 3, 2, 0 }));
/* 622 */     int vc = 4;
/* 623 */     double theta = angle1 + inc;
/* 624 */     while (theta < angle2) {
/*     */       
/* 626 */       Point3D v2 = new Point3D(cx + radius * Math.cos(theta), base, cz + radius * Math.sin(theta));
/*     */       
/* 628 */       Point3D v3 = new Point3D(cx + radius * Math.cos(theta), base + height, cz + radius * Math.sin(theta));
/* 629 */       segment.addVertex(v2);
/* 630 */       segment.addVertex(v3);
/* 631 */       vc += 2;
/*     */ 
/*     */       
/* 634 */       segment.addFace(new Face(segment, new int[] { vc - 2, vc - 4, vc - 3, vc - 1 }));
/*     */ 
/*     */ 
/*     */       
/* 638 */       segment.addFace(new Face(segment, new int[] { 0, vc - 4, vc - 2, 0 }));
/*     */       
/* 640 */       segment.addFace(new Face(segment, new int[] { 1, vc - 1, vc - 3, 1 }));
/*     */       
/* 642 */       theta += inc;
/*     */     } 
/*     */     
/* 645 */     v0 = new Point3D(cx + radius * Math.cos(angle2), base, cz + radius * Math.sin(angle2));
/*     */     
/* 647 */     v1 = new Point3D(cx + radius * Math.cos(angle2), base + height, cz + radius * Math.sin(angle2));
/* 648 */     segment.addVertex(v0);
/* 649 */     segment.addVertex(v1);
/* 650 */     vc += 2;
/* 651 */     segment.addFace(new Face(segment, new int[] { vc - 2, vc - 4, vc - 3, vc - 1 }));
/*     */ 
/*     */ 
/*     */     
/* 655 */     segment.addFace(new Face(segment, new int[] { 0, vc - 4, vc - 2, 0 }));
/* 656 */     segment.addFace(new Face(segment, new int[] { 1, vc - 1, vc - 3, 1 }));
/*     */ 
/*     */     
/* 659 */     segment.addFace(new Face(segment, new int[] { 1, 0, vc - 2, vc - 1 }));
/* 660 */     return segment;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List<Object3D> createPieLabelMarkers(double radius, double explodeRadius, double base, double height, double angle1, double angle2) {
/* 683 */     List<Object3D> result = new ArrayList<Object3D>();
/* 684 */     double angle = (angle1 + angle2) / 2.0D;
/*     */     
/* 686 */     Point3D centre = new Point3D(explodeRadius * Math.cos(angle), base, explodeRadius * Math.sin(angle));
/* 687 */     float cx = (float)centre.x;
/* 688 */     float cz = (float)centre.z;
/* 689 */     double r = radius * 0.9D;
/*     */     
/* 691 */     Point3D v0 = new Point3D(cx + r * Math.cos(angle), base, cz + r * Math.sin(angle));
/*     */     
/* 693 */     Point3D v1 = new Point3D(cx + r * Math.cos(angle), base + height, cz + r * Math.sin(angle));
/* 694 */     result.add(createYSheet(2.0D, v0.x, v0.y, v0.z, Color.RED, false));
/*     */     
/* 696 */     result.add(createYSheet(2.0D, v1.x, v1.y, v1.z, Color.BLUE, true));
/*     */     
/* 698 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object3D createBar(double xWidth, double zWidth, double x, double y, double z, double zero, Color barColor, Color baseColor, Color topColor, boolean inverted) {
/* 723 */     ArgChecks.nullNotPermitted(barColor, "barColor");
/* 724 */     Color c0 = baseColor;
/* 725 */     Color c1 = topColor;
/* 726 */     if (inverted) {
/* 727 */       Color cc = c1;
/* 728 */       c1 = c0;
/* 729 */       c0 = cc;
/*     */     } 
/* 731 */     Object3D bar = new Object3D(barColor);
/* 732 */     if (c0 != null) {
/* 733 */       bar.setProperty("color/c0", c0);
/*     */     }
/* 735 */     if (c1 != null) {
/* 736 */       bar.setProperty("color/c1", c1);
/*     */     }
/* 738 */     double xdelta = xWidth / 2.0D;
/* 739 */     double zdelta = zWidth / 2.0D;
/* 740 */     bar.addVertex(new Point3D(x - xdelta, zero, z - zdelta));
/* 741 */     bar.addVertex(new Point3D(x + xdelta, zero, z - zdelta));
/* 742 */     bar.addVertex(new Point3D(x + xdelta, zero, z + zdelta));
/* 743 */     bar.addVertex(new Point3D(x - xdelta, zero, z + zdelta));
/* 744 */     bar.addVertex(new Point3D(x - xdelta, y, z - zdelta));
/* 745 */     bar.addVertex(new Point3D(x + xdelta, y, z - zdelta));
/* 746 */     bar.addVertex(new Point3D(x + xdelta, y, z + zdelta));
/* 747 */     bar.addVertex(new Point3D(x - xdelta, y, z + zdelta));
/*     */     
/* 749 */     bar.addFace(new Face(bar, new int[] { 0, 1, 5, 4 }));
/* 750 */     bar.addFace(new Face(bar, new int[] { 4, 5, 1, 0 }));
/* 751 */     bar.addFace(new Face(bar, new int[] { 1, 2, 6, 5 }));
/* 752 */     bar.addFace(new Face(bar, new int[] { 5, 6, 2, 1 }));
/* 753 */     bar.addFace(new Face(bar, new int[] { 2, 3, 7, 6 }));
/* 754 */     bar.addFace(new Face(bar, new int[] { 6, 7, 3, 2 }));
/* 755 */     bar.addFace(new Face(bar, new int[] { 0, 4, 7, 3 }));
/* 756 */     bar.addFace(new Face(bar, new int[] { 3, 7, 4, 0 }));
/* 757 */     bar.addFace(new Face(bar, new int[] { 4, 5, 6, 7 }));
/* 758 */     bar.addFace(new Face(bar, new int[] { 3, 2, 1, 0 }));
/* 759 */     if (c1 != null) {
/* 760 */       bar.addFace(new TaggedFace(bar, new int[] { 7, 6, 5, 4 }, "c1"));
/*     */     } else {
/* 762 */       bar.addFace(new Face(bar, new int[] { 7, 6, 5, 4 }));
/*     */     } 
/* 764 */     if (c0 != null) {
/* 765 */       bar.addFace(new TaggedFace(bar, new int[] { 0, 1, 2, 3 }, "c0"));
/*     */     } else {
/* 767 */       bar.addFace(new Face(bar, new int[] { 0, 1, 2, 3 }));
/*     */     } 
/*     */     
/* 770 */     return bar;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object3D createLabelObject(String label, Font font, Color fgColor, Color bgColor, double x, double y, double z, boolean reversed, boolean doubleSided) {
/* 797 */     Object3D labelObj = new Object3D(bgColor);
/* 798 */     labelObj.setProperty("class", "ItemLabel");
/* 799 */     labelObj.addVertex(x - 0.1D, y, z);
/* 800 */     labelObj.addVertex(x + 0.1D, y, z);
/* 801 */     labelObj.addVertex(x + 0.1D, y + 0.1D, z);
/* 802 */     labelObj.addVertex(x - 0.1D, y + 0.1D, z);
/*     */     
/* 804 */     if (!reversed || doubleSided) {
/* 805 */       labelObj.addFace(new LabelFace(labelObj, new int[] { 0, 1, 2, 3 }, label, font, fgColor, bgColor));
/*     */     }
/*     */     
/* 808 */     if (reversed || doubleSided) {
/* 809 */       labelObj.addFace(new LabelFace(labelObj, new int[] { 3, 2, 1, 0 }, label, font, fgColor, bgColor));
/*     */     }
/*     */     
/* 812 */     return labelObj;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/graphics3d/Object3D.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */