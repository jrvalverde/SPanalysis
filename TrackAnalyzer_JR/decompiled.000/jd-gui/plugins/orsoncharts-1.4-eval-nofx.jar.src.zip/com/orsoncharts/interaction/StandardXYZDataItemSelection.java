/*    */ package com.orsoncharts.interaction;
/*    */ 
/*    */ import com.orsoncharts.data.xyz.XYZItemKey;
/*    */ import com.orsoncharts.util.ArgChecks;
/*    */ import java.util.Collection;
/*    */ import java.util.Set;
/*    */ import java.util.TreeSet;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StandardXYZDataItemSelection
/*    */   implements XYZDataItemSelection
/*    */ {
/* 36 */   Set<XYZItemKey> selectedItems = new TreeSet<XYZItemKey>();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean add(XYZItemKey item) {
/* 48 */     ArgChecks.nullNotPermitted(item, "item");
/* 49 */     return this.selectedItems.add(item);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean addAll(Collection<XYZItemKey> keys) {
/* 62 */     ArgChecks.nullNotPermitted(keys, "keys");
/* 63 */     return this.selectedItems.addAll(keys);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean remove(XYZItemKey item) {
/* 76 */     return this.selectedItems.remove(item);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isSelected(XYZItemKey item) {
/* 89 */     return this.selectedItems.contains(item);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void clear() {
/* 96 */     this.selectedItems.clear();
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/interaction/StandardXYZDataItemSelection.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */