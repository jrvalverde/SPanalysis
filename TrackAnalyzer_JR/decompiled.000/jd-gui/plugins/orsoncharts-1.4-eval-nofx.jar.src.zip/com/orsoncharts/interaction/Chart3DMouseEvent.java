/*    */ package com.orsoncharts.interaction;
/*    */ 
/*    */ import com.orsoncharts.Chart3D;
/*    */ import com.orsoncharts.graphics3d.RenderedElement;
/*    */ import java.awt.event.MouseEvent;
/*    */ import java.io.Serializable;
/*    */ import java.util.EventObject;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Chart3DMouseEvent
/*    */   extends EventObject
/*    */   implements Serializable
/*    */ {
/*    */   private Chart3D chart;
/*    */   private MouseEvent trigger;
/*    */   private RenderedElement element;
/*    */   
/*    */   public Chart3DMouseEvent(Chart3D chart, MouseEvent trigger, RenderedElement element) {
/* 51 */     super(chart);
/* 52 */     this.chart = chart;
/* 53 */     this.trigger = trigger;
/* 54 */     this.element = element;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Chart3D getChart() {
/* 63 */     return this.chart;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public MouseEvent getTrigger() {
/* 72 */     return this.trigger;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public RenderedElement getElement() {
/* 81 */     return this.element;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/interaction/Chart3DMouseEvent.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */