/*    */ package com.orsoncharts.interaction;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum InteractiveElementType
/*    */ {
/* 32 */   DATA_ITEM,
/*    */ 
/*    */   
/* 35 */   TITLE,
/*    */ 
/*    */   
/* 38 */   SUBTITLE,
/*    */ 
/*    */   
/* 41 */   GRIDLINE,
/*    */ 
/*    */   
/* 44 */   AXIS_LABEL,
/*    */ 
/*    */   
/* 47 */   CATEGORY_AXIS_TICK_LABEL,
/*    */ 
/*    */   
/* 50 */   VALUE_AXIS_TICK_LABEL,
/*    */ 
/*    */   
/* 53 */   SECTION_LABEL,
/*    */ 
/*    */   
/* 56 */   LEGEND,
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 61 */   LEGEND_ITEM,
/*    */ 
/*    */   
/* 64 */   MARKER;
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/interaction/InteractiveElementType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */