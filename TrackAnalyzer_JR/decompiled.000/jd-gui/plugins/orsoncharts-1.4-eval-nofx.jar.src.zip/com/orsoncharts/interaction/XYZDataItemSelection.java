package com.orsoncharts.interaction;

import com.orsoncharts.data.xyz.XYZItemKey;

public interface XYZDataItemSelection {
  boolean isSelected(XYZItemKey paramXYZItemKey);
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/interaction/XYZDataItemSelection.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */