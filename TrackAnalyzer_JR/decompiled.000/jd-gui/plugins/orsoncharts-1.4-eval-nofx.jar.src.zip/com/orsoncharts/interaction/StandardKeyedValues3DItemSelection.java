/*     */ package com.orsoncharts.interaction;
/*     */ 
/*     */ import com.orsoncharts.data.KeyedValues3DItemKey;
/*     */ import com.orsoncharts.util.ArgChecks;
/*     */ import java.io.Serializable;
/*     */ import java.util.Collection;
/*     */ import java.util.Set;
/*     */ import java.util.TreeSet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StandardKeyedValues3DItemSelection
/*     */   implements KeyedValues3DItemSelection, Serializable
/*     */ {
/*  38 */   Set<KeyedValues3DItemKey> selectedItems = new TreeSet<KeyedValues3DItemKey>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean add(KeyedValues3DItemKey itemKey) {
/*  51 */     ArgChecks.nullNotPermitted(itemKey, "itemKey");
/*  52 */     return this.selectedItems.add(itemKey);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean addAll(Collection<? extends KeyedValues3DItemKey> keys) {
/*  65 */     ArgChecks.nullNotPermitted(keys, "keys");
/*  66 */     return this.selectedItems.addAll(keys);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean remove(KeyedValues3DItemKey itemKey) {
/*  79 */     return this.selectedItems.remove(itemKey);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSelected(KeyedValues3DItemKey itemKey) {
/*  92 */     return this.selectedItems.contains(itemKey);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void clear() {
/* 100 */     this.selectedItems.clear();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 105 */     if (obj == this) {
/* 106 */       return true;
/*     */     }
/* 108 */     if (!(obj instanceof StandardKeyedValues3DItemSelection)) {
/* 109 */       return false;
/*     */     }
/* 111 */     StandardKeyedValues3DItemSelection that = (StandardKeyedValues3DItemSelection)obj;
/*     */     
/* 113 */     if (!this.selectedItems.equals(that.selectedItems)) {
/* 114 */       return false;
/*     */     }
/* 116 */     return true;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/interaction/StandardKeyedValues3DItemSelection.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */