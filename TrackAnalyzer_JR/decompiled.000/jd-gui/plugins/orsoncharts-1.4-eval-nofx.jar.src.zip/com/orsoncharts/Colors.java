/*     */ package com.orsoncharts;
/*     */ 
/*     */ import java.awt.Color;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Colors
/*     */ {
/*     */   public static Color[] getDefaultColors() {
/*  36 */     return createShadesColors();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Color[] createFancyLightColors() {
/*  50 */     Color[] result = new Color[10];
/*  51 */     result[0] = new Color(239, 164, 127);
/*  52 */     result[1] = new Color(140, 228, 139);
/*  53 */     result[2] = new Color(155, 208, 227);
/*  54 */     result[3] = new Color(221, 228, 95);
/*  55 */     result[4] = new Color(118, 223, 194);
/*  56 */     result[5] = new Color(240, 166, 184);
/*  57 */     result[6] = new Color(231, 185, 98);
/*  58 */     result[7] = new Color(186, 214, 150);
/*  59 */     result[8] = new Color(217, 184, 226);
/*  60 */     result[9] = new Color(201, 212, 116);
/*  61 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Color[] createFancyDarkColors() {
/*  75 */     Color[] result = new Color[10];
/*  76 */     result[0] = new Color(78, 81, 97);
/*  77 */     result[1] = new Color(91, 104, 51);
/*  78 */     result[2] = new Color(138, 75, 65);
/*  79 */     result[3] = new Color(72, 62, 34);
/*  80 */     result[4] = new Color(58, 100, 75);
/*  81 */     result[5] = new Color(39, 63, 59);
/*  82 */     result[6] = new Color(105, 68, 75);
/*  83 */     result[7] = new Color(120, 90, 120);
/*  84 */     result[8] = new Color(119, 90, 50);
/*  85 */     result[9] = new Color(59, 103, 111);
/*  86 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Color[] createShadesColors() {
/* 100 */     Color[] result = new Color[10];
/* 101 */     result[0] = new Color(137, 132, 104);
/* 102 */     result[1] = new Color(217, 232, 208);
/* 103 */     result[2] = new Color(53, 48, 40);
/* 104 */     result[3] = new Color(240, 225, 172);
/* 105 */     result[4] = new Color(196, 160, 128);
/* 106 */     result[5] = new Color(92, 96, 87);
/* 107 */     result[6] = new Color(136, 141, 136);
/* 108 */     result[7] = new Color(106, 93, 66);
/* 109 */     result[8] = new Color(205, 199, 168);
/* 110 */     result[9] = new Color(158, 168, 143);
/* 111 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Color[] createTarnishColors() {
/* 125 */     Color[] result = new Color[10];
/* 126 */     result[0] = new Color(148, 129, 121);
/* 127 */     result[1] = new Color(179, 181, 136);
/* 128 */     result[2] = new Color(204, 163, 140);
/* 129 */     result[3] = new Color(102, 93, 80);
/* 130 */     result[4] = new Color(164, 178, 159);
/* 131 */     result[5] = new Color(156, 130, 100);
/* 132 */     result[6] = new Color(129, 142, 124);
/* 133 */     result[7] = new Color(186, 168, 159);
/* 134 */     result[8] = new Color(144, 148, 108);
/* 135 */     result[9] = new Color(189, 169, 131);
/* 136 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Color[] createPastelColors() {
/* 150 */     Color[] result = new Color[10];
/* 151 */     result[0] = new Color(232, 177, 165);
/* 152 */     result[1] = new Color(207, 235, 142);
/* 153 */     result[2] = new Color(142, 220, 220);
/* 154 */     result[3] = new Color(228, 186, 115);
/* 155 */     result[4] = new Color(187, 200, 230);
/* 156 */     result[5] = new Color(157, 222, 177);
/* 157 */     result[6] = new Color(234, 183, 210);
/* 158 */     result[7] = new Color(213, 206, 169);
/* 159 */     result[8] = new Color(202, 214, 205);
/* 160 */     result[9] = new Color(195, 204, 133);
/* 161 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Color[] createPimpColors() {
/* 175 */     Color[] result = new Color[10];
/* 176 */     result[0] = new Color(197, 75, 103);
/* 177 */     result[1] = new Color(85, 154, 48);
/* 178 */     result[2] = new Color(122, 110, 206);
/* 179 */     result[3] = new Color(190, 100, 50);
/* 180 */     result[4] = new Color(201, 79, 209);
/* 181 */     result[5] = new Color(95, 127, 170);
/* 182 */     result[6] = new Color(147, 129, 39);
/* 183 */     result[7] = new Color(63, 142, 96);
/* 184 */     result[8] = new Color(186, 84, 150);
/* 185 */     result[9] = new Color(219, 66, 52);
/* 186 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Color[] createIntenseColors() {
/* 200 */     Color[] result = new Color[10];
/* 201 */     result[0] = new Color(107, 122, 160);
/* 202 */     result[1] = new Color(99, 176, 67);
/* 203 */     result[2] = new Color(214, 85, 52);
/* 204 */     result[3] = new Color(202, 79, 200);
/* 205 */     result[4] = new Color(184, 149, 57);
/* 206 */     result[5] = new Color(82, 168, 146);
/* 207 */     result[6] = new Color(194, 84, 128);
/* 208 */     result[7] = new Color(77, 102, 50);
/* 209 */     result[8] = new Color(132, 108, 197);
/* 210 */     result[9] = new Color(144, 74, 61);
/* 211 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Color[] createFluoColors() {
/* 225 */     Color[] result = new Color[10];
/* 226 */     result[0] = new Color(108, 236, 137);
/* 227 */     result[1] = new Color(253, 187, 46);
/* 228 */     result[2] = new Color(56, 236, 216);
/* 229 */     result[3] = new Color(171, 231, 51);
/* 230 */     result[4] = new Color(221, 214, 74);
/* 231 */     result[5] = new Color(106, 238, 70);
/* 232 */     result[6] = new Color(172, 230, 100);
/* 233 */     result[7] = new Color(242, 191, 82);
/* 234 */     result[8] = new Color(221, 233, 56);
/* 235 */     result[9] = new Color(242, 206, 47);
/* 236 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Color[] createRedRosesColors() {
/* 250 */     Color[] result = new Color[10];
/* 251 */     result[0] = new Color(230, 129, 128);
/* 252 */     result[1] = new Color(233, 56, 39);
/* 253 */     result[2] = new Color(225, 45, 102);
/* 254 */     result[3] = new Color(172, 79, 55);
/* 255 */     result[4] = new Color(214, 154, 128);
/* 256 */     result[5] = new Color(156, 96, 81);
/* 257 */     result[6] = new Color(190, 77, 91);
/* 258 */     result[7] = new Color(228, 121, 91);
/* 259 */     result[8] = new Color(216, 63, 80);
/* 260 */     result[9] = new Color(209, 75, 46);
/* 261 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Color[] createOchreSandColors() {
/* 275 */     Color[] result = new Color[10];
/* 276 */     result[0] = new Color(218, 180, 125);
/* 277 */     result[1] = new Color(245, 184, 36);
/* 278 */     result[2] = new Color(159, 103, 28);
/* 279 */     result[3] = new Color(124, 96, 55);
/* 280 */     result[4] = new Color(224, 132, 56);
/* 281 */     result[5] = new Color(185, 143, 48);
/* 282 */     result[6] = new Color(229, 171, 97);
/* 283 */     result[7] = new Color(232, 165, 54);
/* 284 */     result[8] = new Color(171, 102, 53);
/* 285 */     result[9] = new Color(160, 122, 71);
/* 286 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Color[] createYellowLimeColors() {
/* 300 */     Color[] result = new Color[10];
/* 301 */     result[0] = new Color(235, 203, 59);
/* 302 */     result[1] = new Color(113, 108, 56);
/* 303 */     result[2] = new Color(222, 206, 134);
/* 304 */     result[3] = new Color(169, 166, 62);
/* 305 */     result[4] = new Color(214, 230, 54);
/* 306 */     result[5] = new Color(225, 221, 105);
/* 307 */     result[6] = new Color(128, 104, 23);
/* 308 */     result[7] = new Color(162, 151, 86);
/* 309 */     result[8] = new Color(117, 121, 25);
/* 310 */     result[9] = new Color(183, 179, 40);
/* 311 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Color[] createGreenMintColors() {
/* 325 */     Color[] result = new Color[10];
/* 326 */     result[0] = new Color(99, 224, 113);
/* 327 */     result[1] = new Color(98, 132, 83);
/* 328 */     result[2] = new Color(145, 234, 49);
/* 329 */     result[3] = new Color(181, 215, 158);
/* 330 */     result[4] = new Color(95, 171, 43);
/* 331 */     result[5] = new Color(100, 208, 142);
/* 332 */     result[6] = new Color(172, 222, 84);
/* 333 */     result[7] = new Color(75, 139, 53);
/* 334 */     result[8] = new Color(177, 216, 123);
/* 335 */     result[9] = new Color(83, 223, 60);
/* 336 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Color[] createIceCubeColors() {
/* 350 */     Color[] result = new Color[10];
/* 351 */     result[0] = new Color(112, 235, 233);
/* 352 */     result[1] = new Color(54, 110, 100);
/* 353 */     result[2] = new Color(211, 232, 208);
/* 354 */     result[3] = new Color(94, 230, 191);
/* 355 */     result[4] = new Color(76, 154, 155);
/* 356 */     result[5] = new Color(156, 181, 157);
/* 357 */     result[6] = new Color(67, 152, 126);
/* 358 */     result[7] = new Color(112, 135, 119);
/* 359 */     result[8] = new Color(155, 213, 192);
/* 360 */     result[9] = new Color(80, 195, 190);
/* 361 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Color[] createBlueOceanColors() {
/* 375 */     Color[] result = new Color[10];
/* 376 */     result[0] = new Color(53, 84, 154);
/* 377 */     result[1] = new Color(41, 46, 57);
/* 378 */     result[2] = new Color(115, 124, 151);
/* 379 */     result[3] = new Color(38, 52, 91);
/* 380 */     result[4] = new Color(84, 117, 211);
/* 381 */     result[5] = new Color(76, 125, 181);
/* 382 */     result[6] = new Color(109, 108, 112);
/* 383 */     result[7] = new Color(48, 105, 134);
/* 384 */     result[8] = new Color(72, 82, 107);
/* 385 */     result[9] = new Color(91, 99, 144);
/* 386 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Color[] createIndigoNightColors() {
/* 400 */     Color[] result = new Color[10];
/* 401 */     result[0] = new Color(127, 88, 147);
/* 402 */     result[1] = new Color(201, 67, 217);
/* 403 */     result[2] = new Color(112, 97, 218);
/* 404 */     result[3] = new Color(219, 134, 222);
/* 405 */     result[4] = new Color(154, 80, 172);
/* 406 */     result[5] = new Color(170, 106, 231);
/* 407 */     result[6] = new Color(142, 111, 210);
/* 408 */     result[7] = new Color(194, 149, 235);
/* 409 */     result[8] = new Color(152, 118, 188);
/* 410 */     result[9] = new Color(214, 101, 237);
/* 411 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Color[] createPurpleWineColors() {
/* 425 */     Color[] result = new Color[10];
/* 426 */     result[0] = new Color(116, 28, 93);
/* 427 */     result[1] = new Color(112, 79, 75);
/* 428 */     result[2] = new Color(178, 37, 101);
/* 429 */     result[3] = new Color(109, 24, 56);
/* 430 */     result[4] = new Color(167, 42, 140);
/* 431 */     result[5] = new Color(66, 30, 40);
/* 432 */     result[6] = new Color(128, 70, 95);
/* 433 */     result[7] = new Color(78, 20, 56);
/* 434 */     result[8] = new Color(155, 62, 111);
/* 435 */     result[9] = new Color(139, 61, 75);
/* 436 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Color[] getEarthColors() {
/* 445 */     Color[] result = new Color[7];
/* 446 */     result[0] = new Color(98, 98, 98);
/* 447 */     result[1] = new Color(159, 87, 43);
/* 448 */     result[2] = new Color(194, 176, 46);
/* 449 */     result[3] = new Color(134, 155, 64);
/* 450 */     result[4] = new Color(57, 118, 40);
/* 451 */     result[5] = new Color(40, 114, 110);
/* 452 */     result[6] = new Color(78, 79, 62);
/* 453 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Color[] getBrewerQualitativeSet1N9Colors() {
/* 466 */     Color[] result = new Color[9];
/* 467 */     result[0] = new Color(228, 26, 28);
/* 468 */     result[1] = new Color(55, 126, 184);
/* 469 */     result[2] = new Color(77, 175, 74);
/* 470 */     result[3] = new Color(152, 78, 163);
/* 471 */     result[4] = new Color(255, 127, 0);
/* 472 */     result[5] = new Color(255, 255, 51);
/* 473 */     result[6] = new Color(166, 86, 40);
/* 474 */     result[7] = new Color(247, 129, 191);
/* 475 */     result[8] = new Color(153, 153, 153);
/* 476 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Color[] getBrewerQualitativePairedN12Colors() {
/* 488 */     Color[] result = new Color[12];
/* 489 */     result[0] = new Color(166, 206, 227);
/* 490 */     result[1] = new Color(31, 120, 180);
/* 491 */     result[2] = new Color(178, 223, 138);
/* 492 */     result[3] = new Color(51, 160, 44);
/* 493 */     result[4] = new Color(251, 154, 153);
/* 494 */     result[5] = new Color(227, 26, 28);
/* 495 */     result[6] = new Color(253, 191, 111);
/* 496 */     result[7] = new Color(255, 127, 0);
/* 497 */     result[8] = new Color(202, 178, 214);
/* 498 */     result[9] = new Color(106, 61, 154);
/* 499 */     result[10] = new Color(255, 255, 153);
/* 500 */     result[11] = new Color(177, 89, 40);
/* 501 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Color[] getBrewerQualitativeSet3N12Colors() {
/* 514 */     Color[] result = new Color[12];
/* 515 */     result[0] = new Color(141, 211, 199);
/* 516 */     result[1] = new Color(255, 255, 179);
/* 517 */     result[2] = new Color(190, 186, 218);
/* 518 */     result[3] = new Color(251, 128, 114);
/* 519 */     result[4] = new Color(128, 177, 211);
/* 520 */     result[5] = new Color(253, 180, 98);
/* 521 */     result[6] = new Color(179, 222, 105);
/* 522 */     result[7] = new Color(252, 205, 229);
/* 523 */     result[8] = new Color(217, 217, 217);
/* 524 */     result[9] = new Color(188, 128, 189);
/* 525 */     result[10] = new Color(204, 235, 197);
/* 526 */     result[11] = new Color(255, 237, 111);
/* 527 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Color[] getSAPMultiColor() {
/* 537 */     return new Color[] { new Color(255, 248, 163), new Color(169, 204, 143), new Color(178, 200, 217), new Color(190, 163, 122), new Color(243, 170, 121), new Color(181, 181, 169), new Color(230, 165, 164), new Color(248, 215, 83), new Color(92, 151, 70), new Color(62, 117, 167), new Color(122, 101, 62), new Color(225, 102, 42), new Color(116, 121, 111), new Color(196, 56, 79) };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Color[] getColors1() {
/* 561 */     return new Color[] { new Color(0, 55, 122), new Color(24, 123, 58), Color.RED, Color.YELLOW };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Color[] getColors2() {
/* 571 */     return new Color[] { new Color(1742401), new Color(10934634), new Color(16625249), new Color(16777151) };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Color[] getDesignSeedsShells() {
/* 582 */     return new Color[] { new Color(228, 233, 239), new Color(184, 197, 219), new Color(111, 122, 143), new Color(95, 89, 89), new Color(206, 167, 145), new Color(188, 182, 173) };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Color[] getDesignSeedsPepper() {
/* 599 */     return new Color[] { new Color(255, 219, 142), new Color(220, 21, 20), new Color(149, 0, 1), new Color(82, 102, 41), new Color(142, 101, 72), new Color(199, 169, 128) };
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/Colors.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */