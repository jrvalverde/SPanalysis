/*    */ package com.orsoncharts.plot;
/*    */ 
/*    */ import com.orsoncharts.util.ArgChecks;
/*    */ import java.util.EventObject;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Plot3DChangeEvent
/*    */   extends EventObject
/*    */ {
/*    */   private Plot3D plot;
/*    */   private boolean requiresWorldUpdate;
/*    */   
/*    */   public Plot3DChangeEvent(Object source, Plot3D plot, boolean requiresWorldUpdate) {
/* 53 */     super(source);
/* 54 */     ArgChecks.nullNotPermitted(plot, "plot");
/* 55 */     this.plot = plot;
/* 56 */     this.requiresWorldUpdate = requiresWorldUpdate;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Plot3D getPlot() {
/* 65 */     return this.plot;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean requiresWorldUpdate() {
/* 77 */     return this.requiresWorldUpdate;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/plot/Plot3DChangeEvent.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */