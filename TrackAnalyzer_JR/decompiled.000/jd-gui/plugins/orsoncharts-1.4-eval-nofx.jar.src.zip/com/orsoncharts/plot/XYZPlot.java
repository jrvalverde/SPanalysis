/*     */ package com.orsoncharts.plot;
/*     */ 
/*     */ import com.orsoncharts.ChartElementVisitor;
/*     */ import com.orsoncharts.axis.Axis3DChangeEvent;
/*     */ import com.orsoncharts.axis.Axis3DChangeListener;
/*     */ import com.orsoncharts.axis.ValueAxis3D;
/*     */ import com.orsoncharts.data.Dataset3DChangeEvent;
/*     */ import com.orsoncharts.data.Dataset3DChangeListener;
/*     */ import com.orsoncharts.data.ItemKey;
/*     */ import com.orsoncharts.data.xyz.XYZDataset;
/*     */ import com.orsoncharts.data.xyz.XYZItemKey;
/*     */ import com.orsoncharts.graphics3d.Dimension3D;
/*     */ import com.orsoncharts.graphics3d.World;
/*     */ import com.orsoncharts.label.StandardXYZItemLabelGenerator;
/*     */ import com.orsoncharts.label.StandardXYZLabelGenerator;
/*     */ import com.orsoncharts.label.XYZItemLabelGenerator;
/*     */ import com.orsoncharts.label.XYZLabelGenerator;
/*     */ import com.orsoncharts.legend.LegendItemInfo;
/*     */ import com.orsoncharts.legend.StandardLegendItemInfo;
/*     */ import com.orsoncharts.renderer.ComposeType;
/*     */ import com.orsoncharts.renderer.Renderer3DChangeEvent;
/*     */ import com.orsoncharts.renderer.Renderer3DChangeListener;
/*     */ import com.orsoncharts.renderer.xyz.XYZRenderer;
/*     */ import com.orsoncharts.util.ArgChecks;
/*     */ import com.orsoncharts.util.ObjectUtils;
/*     */ import com.orsoncharts.util.SerialUtils;
/*     */ import java.awt.BasicStroke;
/*     */ import java.awt.Color;
/*     */ import java.awt.Paint;
/*     */ import java.awt.Stroke;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XYZPlot
/*     */   extends AbstractPlot3D
/*     */   implements Dataset3DChangeListener, Axis3DChangeListener, Renderer3DChangeListener, Serializable
/*     */ {
/*  63 */   private static Stroke DEFAULT_GRIDLINE_STROKE = new BasicStroke(0.5F, 1, 1, 1.0F, new float[] { 3.0F, 3.0F }, 0.0F);
/*     */ 
/*     */ 
/*     */   
/*     */   private XYZDataset dataset;
/*     */ 
/*     */ 
/*     */   
/*     */   private XYZRenderer renderer;
/*     */ 
/*     */ 
/*     */   
/*     */   private ValueAxis3D xAxis;
/*     */ 
/*     */ 
/*     */   
/*     */   private ValueAxis3D yAxis;
/*     */ 
/*     */ 
/*     */   
/*     */   private ValueAxis3D zAxis;
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean gridlinesVisibleX;
/*     */ 
/*     */ 
/*     */   
/*     */   private transient Paint gridlinePaintX;
/*     */ 
/*     */ 
/*     */   
/*     */   private transient Stroke gridlineStrokeX;
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean gridlinesVisibleY;
/*     */ 
/*     */ 
/*     */   
/*     */   private transient Paint gridlinePaintY;
/*     */ 
/*     */   
/*     */   private transient Stroke gridlineStrokeY;
/*     */ 
/*     */   
/*     */   private boolean gridlinesVisibleZ;
/*     */ 
/*     */   
/*     */   private transient Paint gridlinePaintZ;
/*     */ 
/*     */   
/*     */   private transient Stroke gridlineStrokeZ;
/*     */ 
/*     */   
/*     */   private XYZLabelGenerator legendLabelGenerator;
/*     */ 
/*     */   
/*     */   private XYZItemLabelGenerator toolTipGenerator;
/*     */ 
/*     */ 
/*     */   
/*     */   public XYZPlot(XYZDataset dataset, XYZRenderer renderer, ValueAxis3D xAxis, ValueAxis3D yAxis, ValueAxis3D zAxis) {
/* 126 */     ArgChecks.nullNotPermitted(dataset, "dataset");
/* 127 */     ArgChecks.nullNotPermitted(renderer, "renderer");
/* 128 */     ArgChecks.nullNotPermitted(xAxis, "xAxis");
/* 129 */     ArgChecks.nullNotPermitted(yAxis, "yAxis");
/* 130 */     ArgChecks.nullNotPermitted(zAxis, "zAxis");
/* 131 */     this.dimensions = new Dimension3D(10.0D, 10.0D, 10.0D);
/* 132 */     this.dataset = dataset;
/* 133 */     this.dataset.addChangeListener(this);
/* 134 */     this.renderer = renderer;
/* 135 */     this.renderer.setPlot(this);
/* 136 */     this.renderer.addChangeListener(this);
/* 137 */     this.xAxis = xAxis;
/* 138 */     this.xAxis.addChangeListener(this);
/* 139 */     this.xAxis.configureAsXAxis(this);
/* 140 */     this.zAxis = zAxis;
/* 141 */     this.zAxis.addChangeListener(this);
/* 142 */     this.zAxis.configureAsZAxis(this);
/* 143 */     this.yAxis = yAxis;
/* 144 */     this.yAxis.addChangeListener(this);
/* 145 */     this.yAxis.configureAsYAxis(this);
/* 146 */     this.gridlinesVisibleX = true;
/* 147 */     this.gridlinePaintX = Color.WHITE;
/* 148 */     this.gridlineStrokeX = DEFAULT_GRIDLINE_STROKE;
/* 149 */     this.gridlinesVisibleY = true;
/* 150 */     this.gridlinePaintY = Color.WHITE;
/* 151 */     this.gridlineStrokeY = DEFAULT_GRIDLINE_STROKE;
/* 152 */     this.gridlinesVisibleZ = true;
/* 153 */     this.gridlinePaintZ = Color.WHITE;
/* 154 */     this.gridlineStrokeZ = DEFAULT_GRIDLINE_STROKE;
/* 155 */     this.legendLabelGenerator = (XYZLabelGenerator)new StandardXYZLabelGenerator();
/* 156 */     this.toolTipGenerator = (XYZItemLabelGenerator)new StandardXYZItemLabelGenerator();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDimensions(Dimension3D dim) {
/* 166 */     ArgChecks.nullNotPermitted(dim, "dim");
/* 167 */     this.dimensions = dim;
/* 168 */     fireChangeEvent(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XYZDataset getDataset() {
/* 177 */     return this.dataset;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDataset(XYZDataset dataset) {
/* 187 */     ArgChecks.nullNotPermitted(dataset, "dataset");
/* 188 */     this.dataset.removeChangeListener(this);
/* 189 */     this.dataset = dataset;
/* 190 */     this.dataset.addChangeListener(this);
/* 191 */     fireChangeEvent(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ValueAxis3D getXAxis() {
/* 200 */     return this.xAxis;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setXAxis(ValueAxis3D xAxis) {
/* 210 */     ArgChecks.nullNotPermitted(xAxis, "xAxis");
/* 211 */     this.xAxis.removeChangeListener(this);
/* 212 */     xAxis.configureAsXAxis(this);
/* 213 */     xAxis.addChangeListener(this);
/* 214 */     this.xAxis = xAxis;
/* 215 */     fireChangeEvent(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ValueAxis3D getYAxis() {
/* 224 */     return this.yAxis;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setYAxis(ValueAxis3D yAxis) {
/* 234 */     ArgChecks.nullNotPermitted(yAxis, "yAxis");
/* 235 */     this.yAxis.removeChangeListener(this);
/* 236 */     yAxis.configureAsYAxis(this);
/* 237 */     yAxis.addChangeListener(this);
/* 238 */     this.yAxis = yAxis;
/* 239 */     fireChangeEvent(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ValueAxis3D getZAxis() {
/* 248 */     return this.zAxis;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setZAxis(ValueAxis3D zAxis) {
/* 258 */     ArgChecks.nullNotPermitted(zAxis, "zAxis");
/* 259 */     this.zAxis.removeChangeListener(this);
/* 260 */     zAxis.configureAsZAxis(this);
/* 261 */     zAxis.addChangeListener(this);
/* 262 */     this.zAxis = zAxis;
/* 263 */     fireChangeEvent(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XYZRenderer getRenderer() {
/* 272 */     return this.renderer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRenderer(XYZRenderer renderer) {
/* 282 */     this.renderer.setPlot(null);
/* 283 */     this.renderer.removeChangeListener(this);
/* 284 */     this.renderer = renderer;
/* 285 */     this.renderer.setPlot(this);
/* 286 */     this.renderer.addChangeListener(this);
/* 287 */     fireChangeEvent(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isGridlinesVisibleX() {
/* 297 */     return this.gridlinesVisibleX;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setGridlinesVisibleX(boolean visible) {
/* 308 */     this.gridlinesVisibleX = visible;
/* 309 */     fireChangeEvent(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Paint getGridlinePaintX() {
/* 318 */     return this.gridlinePaintX;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setGridlinePaintX(Paint paint) {
/* 328 */     ArgChecks.nullNotPermitted(paint, "paint");
/* 329 */     this.gridlinePaintX = paint;
/* 330 */     fireChangeEvent(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Stroke getGridlineStrokeX() {
/* 339 */     return this.gridlineStrokeX;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setGridlineStrokeX(Stroke stroke) {
/* 349 */     ArgChecks.nullNotPermitted(stroke, "stroke");
/* 350 */     this.gridlineStrokeX = stroke;
/* 351 */     fireChangeEvent(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isGridlinesVisibleY() {
/* 361 */     return this.gridlinesVisibleY;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setGridlinesVisibleY(boolean visible) {
/* 372 */     this.gridlinesVisibleY = visible;
/* 373 */     fireChangeEvent(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Paint getGridlinePaintY() {
/* 382 */     return this.gridlinePaintY;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setGridlinePaintY(Paint paint) {
/* 392 */     ArgChecks.nullNotPermitted(paint, "paint");
/* 393 */     this.gridlinePaintY = paint;
/* 394 */     fireChangeEvent(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Stroke getGridlineStrokeY() {
/* 403 */     return this.gridlineStrokeY;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setGridlineStrokeY(Stroke stroke) {
/* 413 */     ArgChecks.nullNotPermitted(stroke, "stroke");
/* 414 */     this.gridlineStrokeY = stroke;
/* 415 */     fireChangeEvent(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isGridlinesVisibleZ() {
/* 425 */     return this.gridlinesVisibleZ;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setGridlinesVisibleZ(boolean visible) {
/* 436 */     this.gridlinesVisibleZ = visible;
/* 437 */     fireChangeEvent(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Paint getGridlinePaintZ() {
/* 446 */     return this.gridlinePaintZ;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setGridlinePaintZ(Paint paint) {
/* 456 */     ArgChecks.nullNotPermitted(paint, "paint");
/* 457 */     this.gridlinePaintZ = paint;
/* 458 */     fireChangeEvent(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Stroke getGridlineStrokeZ() {
/* 467 */     return this.gridlineStrokeZ;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setGridlineStrokeZ(Stroke stroke) {
/* 477 */     ArgChecks.nullNotPermitted(stroke, "stroke");
/* 478 */     this.gridlineStrokeZ = stroke;
/* 479 */     fireChangeEvent(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XYZLabelGenerator getLegendLabelGenerator() {
/* 491 */     return this.legendLabelGenerator;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLegendLabelGenerator(XYZLabelGenerator generator) {
/* 503 */     ArgChecks.nullNotPermitted(generator, "generator");
/* 504 */     this.legendLabelGenerator = generator;
/* 505 */     fireChangeEvent(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<LegendItemInfo> getLegendInfo() {
/* 517 */     List<LegendItemInfo> result = new ArrayList<LegendItemInfo>();
/* 518 */     List<Comparable<?>> keys = this.dataset.getSeriesKeys();
/* 519 */     for (Comparable<?> key : keys) {
/* 520 */       String label = this.legendLabelGenerator.generateSeriesLabel(this.dataset, key);
/*     */       
/* 522 */       int series = this.dataset.getSeriesIndex(key);
/* 523 */       Color color = this.renderer.getColorSource().getLegendColor(series);
/* 524 */       StandardLegendItemInfo standardLegendItemInfo = new StandardLegendItemInfo(key, label, color);
/* 525 */       result.add(standardLegendItemInfo);
/*     */     } 
/* 527 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void compose(World world, double xOffset, double yOffset, double zOffset) {
/* 543 */     if (this.renderer.getComposeType() == ComposeType.ALL) {
/* 544 */       this.renderer.composeAll(this, world, this.dimensions, xOffset, yOffset, zOffset);
/*     */     }
/* 546 */     else if (this.renderer.getComposeType() == ComposeType.PER_ITEM) {
/*     */ 
/*     */ 
/*     */       
/* 550 */       int seriesCount = this.dataset.getSeriesCount();
/* 551 */       for (int series = 0; series < seriesCount; series++) {
/* 552 */         int itemCount = this.dataset.getItemCount(series);
/* 553 */         for (int item = 0; item < itemCount; item++) {
/* 554 */           this.renderer.composeItem(this.dataset, series, item, world, this.dimensions, xOffset, yOffset, zOffset);
/*     */         }
/*     */       }
/*     */     
/*     */     } else {
/*     */       
/* 560 */       throw new IllegalStateException("ComposeType not expected: " + this.renderer
/* 561 */           .getComposeType());
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public String generateToolTipText(ItemKey itemKey) {
/* 567 */     if (!(itemKey instanceof XYZItemKey)) {
/* 568 */       throw new IllegalArgumentException("The itemKey must be a XYZItemKey instance.");
/*     */     }
/*     */     
/* 571 */     if (this.toolTipGenerator == null) {
/* 572 */       return null;
/*     */     }
/* 574 */     XYZItemKey k = (XYZItemKey)itemKey;
/* 575 */     return this.toolTipGenerator.generateItemLabel(this.dataset, k
/* 576 */         .getSeriesKey(), k.getItemIndex());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void receive(ChartElementVisitor visitor) {
/* 590 */     this.xAxis.receive(visitor);
/* 591 */     this.yAxis.receive(visitor);
/* 592 */     this.zAxis.receive(visitor);
/* 593 */     this.renderer.receive(visitor);
/* 594 */     visitor.visit(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 606 */     if (obj == this) {
/* 607 */       return true;
/*     */     }
/* 609 */     if (!(obj instanceof XYZPlot)) {
/* 610 */       return false;
/*     */     }
/* 612 */     XYZPlot that = (XYZPlot)obj;
/* 613 */     if (!this.dimensions.equals(that.dimensions)) {
/* 614 */       return false;
/*     */     }
/* 616 */     if (this.gridlinesVisibleX != that.gridlinesVisibleX) {
/* 617 */       return false;
/*     */     }
/* 619 */     if (this.gridlinesVisibleY != that.gridlinesVisibleY) {
/* 620 */       return false;
/*     */     }
/* 622 */     if (this.gridlinesVisibleZ != that.gridlinesVisibleZ) {
/* 623 */       return false;
/*     */     }
/* 625 */     if (!ObjectUtils.equalsPaint(this.gridlinePaintX, that.gridlinePaintX))
/*     */     {
/* 627 */       return false;
/*     */     }
/* 629 */     if (!ObjectUtils.equalsPaint(this.gridlinePaintY, that.gridlinePaintY))
/*     */     {
/* 631 */       return false;
/*     */     }
/* 633 */     if (!ObjectUtils.equalsPaint(this.gridlinePaintZ, that.gridlinePaintZ))
/*     */     {
/* 635 */       return false;
/*     */     }
/* 637 */     if (!this.gridlineStrokeX.equals(that.gridlineStrokeX)) {
/* 638 */       return false;
/*     */     }
/* 640 */     if (!this.gridlineStrokeY.equals(that.gridlineStrokeY)) {
/* 641 */       return false;
/*     */     }
/* 643 */     if (!this.gridlineStrokeZ.equals(that.gridlineStrokeZ)) {
/* 644 */       return false;
/*     */     }
/* 646 */     if (!this.legendLabelGenerator.equals(that.legendLabelGenerator)) {
/* 647 */       return false;
/*     */     }
/* 649 */     return super.equals(obj);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void axisChanged(Axis3DChangeEvent event) {
/* 662 */     this.yAxis.configureAsYAxis(this);
/* 663 */     fireChangeEvent(event.requiresWorldUpdate());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void rendererChanged(Renderer3DChangeEvent event) {
/* 676 */     fireChangeEvent(event.requiresWorldUpdate());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void datasetChanged(Dataset3DChangeEvent event) {
/* 689 */     this.xAxis.configureAsXAxis(this);
/* 690 */     this.yAxis.configureAsYAxis(this);
/* 691 */     this.zAxis.configureAsZAxis(this);
/* 692 */     super.datasetChanged(event);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void writeObject(ObjectOutputStream stream) throws IOException {
/* 703 */     stream.defaultWriteObject();
/* 704 */     SerialUtils.writePaint(this.gridlinePaintX, stream);
/* 705 */     SerialUtils.writePaint(this.gridlinePaintY, stream);
/* 706 */     SerialUtils.writePaint(this.gridlinePaintZ, stream);
/* 707 */     SerialUtils.writeStroke(this.gridlineStrokeX, stream);
/* 708 */     SerialUtils.writeStroke(this.gridlineStrokeY, stream);
/* 709 */     SerialUtils.writeStroke(this.gridlineStrokeZ, stream);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void readObject(ObjectInputStream stream) throws IOException, ClassNotFoundException {
/* 723 */     stream.defaultReadObject();
/* 724 */     this.gridlinePaintX = SerialUtils.readPaint(stream);
/* 725 */     this.gridlinePaintY = SerialUtils.readPaint(stream);
/* 726 */     this.gridlinePaintZ = SerialUtils.readPaint(stream);
/* 727 */     this.gridlineStrokeX = SerialUtils.readStroke(stream);
/* 728 */     this.gridlineStrokeY = SerialUtils.readStroke(stream);
/* 729 */     this.gridlineStrokeZ = SerialUtils.readStroke(stream);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/plot/XYZPlot.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */