/*     */ package com.orsoncharts.plot;
/*     */ 
/*     */ import com.orsoncharts.Chart3D;
/*     */ import com.orsoncharts.ChartElementVisitor;
/*     */ import com.orsoncharts.data.Dataset3DChangeEvent;
/*     */ import com.orsoncharts.data.Dataset3DChangeListener;
/*     */ import com.orsoncharts.data.ItemKey;
/*     */ import com.orsoncharts.graphics3d.Dimension3D;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.Serializable;
/*     */ import javax.swing.event.EventListenerList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractPlot3D
/*     */   implements Plot3D, Dataset3DChangeListener, Serializable
/*     */ {
/*  81 */   private Chart3D chart = null;
/*  82 */   protected Dimension3D dimensions = new Dimension3D(1.0D, 1.0D, 1.0D);
/*     */   protected boolean autoAdjustDimensions = true;
/*  84 */   private transient EventListenerList listenerList = new EventListenerList();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean notify = true;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Chart3D getChart() {
/*  97 */     return this.chart;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setChart(Chart3D chart) {
/* 109 */     this.chart = chart;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Dimension3D getDimensions() {
/* 123 */     return this.dimensions;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isAutoAdjustDimensions() {
/* 135 */     return this.autoAdjustDimensions;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract String generateToolTipText(ItemKey paramItemKey);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void receive(ChartElementVisitor paramChartElementVisitor);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 170 */     if (obj == this) {
/* 171 */       return true;
/*     */     }
/* 173 */     if (!(obj instanceof AbstractPlot3D)) {
/* 174 */       return false;
/*     */     }
/* 176 */     AbstractPlot3D that = (AbstractPlot3D)obj;
/* 177 */     if (!this.dimensions.equals(that.dimensions)) {
/* 178 */       return false;
/*     */     }
/* 180 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isNotify() {
/* 192 */     return this.notify;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setNotify(boolean notify) {
/* 204 */     this.notify = notify;
/*     */     
/* 206 */     if (notify) {
/* 207 */       fireChangeEvent(true);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addChangeListener(Plot3DChangeListener listener) {
/* 220 */     this.listenerList.add(Plot3DChangeListener.class, listener);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeChangeListener(Plot3DChangeListener listener) {
/* 232 */     this.listenerList.remove(Plot3DChangeListener.class, listener);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void notifyListeners(Plot3DChangeEvent event) {
/* 243 */     if (!this.notify) {
/*     */       return;
/*     */     }
/* 246 */     Object[] listeners = this.listenerList.getListenerList();
/* 247 */     for (int i = listeners.length - 2; i >= 0; i -= 2) {
/* 248 */       if (listeners[i] == Plot3DChangeListener.class) {
/* 249 */         ((Plot3DChangeListener)listeners[i + 1]).plotChanged(event);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void fireChangeEvent(boolean requiresWorldUpdate) {
/* 260 */     notifyListeners(new Plot3DChangeEvent(this, this, requiresWorldUpdate));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void datasetChanged(Dataset3DChangeEvent event) {
/* 271 */     notifyListeners(new Plot3DChangeEvent(event, this, true));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void readObject(ObjectInputStream stream) throws IOException, ClassNotFoundException {
/* 284 */     stream.defaultReadObject();
/*     */     
/* 286 */     this.listenerList = new EventListenerList();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/plot/AbstractPlot3D.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */