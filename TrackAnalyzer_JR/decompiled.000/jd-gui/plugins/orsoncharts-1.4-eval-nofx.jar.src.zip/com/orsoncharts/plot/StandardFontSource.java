/*     */ package com.orsoncharts.plot;
/*     */ 
/*     */ import com.orsoncharts.data.DefaultKeyedValues;
/*     */ import com.orsoncharts.util.ArgChecks;
/*     */ import java.awt.Font;
/*     */ import java.io.Serializable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class StandardFontSource
/*     */   implements FontSource, Serializable
/*     */ {
/*  31 */   private static Font DEFAULT_FONT = new Font("Dialog", 0, 12);
/*     */ 
/*     */ 
/*     */   
/*     */   private DefaultKeyedValues<Font> fonts;
/*     */ 
/*     */   
/*     */   private Font defaultFont;
/*     */ 
/*     */ 
/*     */   
/*     */   public StandardFontSource() {
/*  43 */     this(DEFAULT_FONT);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StandardFontSource(Font defaultFont) {
/*  52 */     ArgChecks.nullNotPermitted(defaultFont, "defaultFont");
/*  53 */     this.defaultFont = defaultFont;
/*  54 */     this.fonts = new DefaultKeyedValues();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Font getDefaultFont() {
/*  63 */     return this.defaultFont;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDefaultFont(Font font) {
/*  72 */     ArgChecks.nullNotPermitted(font, "font");
/*  73 */     this.defaultFont = font;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Font getFont(Comparable<?> key) {
/*  85 */     Font result = (Font)this.fonts.getValue(key);
/*  86 */     if (result != null) {
/*  87 */       return result;
/*     */     }
/*  89 */     return this.defaultFont;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFont(Comparable<?> key, Font font) {
/* 101 */     if (font != null) {
/* 102 */       this.fonts.put(key, font);
/*     */     } else {
/* 104 */       this.fonts.remove(key);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void style(Font font) {
/* 119 */     ArgChecks.nullNotPermitted(font, "font");
/* 120 */     this.defaultFont = font;
/* 121 */     this.fonts.clear();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 133 */     if (obj == this) {
/* 134 */       return true;
/*     */     }
/* 136 */     if (!(obj instanceof StandardFontSource)) {
/* 137 */       return false;
/*     */     }
/* 139 */     StandardFontSource that = (StandardFontSource)obj;
/* 140 */     if (!this.defaultFont.equals(that.defaultFont)) {
/* 141 */       return false;
/*     */     }
/* 143 */     if (!this.fonts.equals(that.fonts)) {
/* 144 */       return false;
/*     */     }
/* 146 */     return true;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/plot/StandardFontSource.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */