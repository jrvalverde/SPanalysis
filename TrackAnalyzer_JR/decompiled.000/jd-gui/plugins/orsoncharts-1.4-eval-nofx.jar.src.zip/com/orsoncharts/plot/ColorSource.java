package com.orsoncharts.plot;

import java.awt.Color;

public interface ColorSource {
  Color getColor(Comparable<?> paramComparable);
  
  void setColor(Comparable<?> paramComparable, Color paramColor);
  
  void style(Color... paramVarArgs);
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/plot/ColorSource.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */