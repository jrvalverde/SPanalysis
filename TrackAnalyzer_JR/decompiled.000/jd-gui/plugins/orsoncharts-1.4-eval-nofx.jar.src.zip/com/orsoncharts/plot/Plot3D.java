package com.orsoncharts.plot;

import com.orsoncharts.Chart3D;
import com.orsoncharts.ChartElement;
import com.orsoncharts.data.ItemKey;
import com.orsoncharts.graphics3d.Dimension3D;
import com.orsoncharts.graphics3d.World;
import com.orsoncharts.legend.LegendItemInfo;
import java.util.List;

public interface Plot3D extends ChartElement {
  Chart3D getChart();
  
  void setChart(Chart3D paramChart3D);
  
  Dimension3D getDimensions();
  
  void compose(World paramWorld, double paramDouble1, double paramDouble2, double paramDouble3);
  
  List<LegendItemInfo> getLegendInfo();
  
  String generateToolTipText(ItemKey paramItemKey);
  
  void addChangeListener(Plot3DChangeListener paramPlot3DChangeListener);
  
  void removeChangeListener(Plot3DChangeListener paramPlot3DChangeListener);
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/plot/Plot3D.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */