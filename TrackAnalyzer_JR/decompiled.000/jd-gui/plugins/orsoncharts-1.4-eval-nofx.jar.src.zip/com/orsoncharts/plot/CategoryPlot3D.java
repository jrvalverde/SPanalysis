/*     */ package com.orsoncharts.plot;
/*     */ 
/*     */ import com.orsoncharts.ChartElementVisitor;
/*     */ import com.orsoncharts.axis.Axis3DChangeEvent;
/*     */ import com.orsoncharts.axis.Axis3DChangeListener;
/*     */ import com.orsoncharts.axis.CategoryAxis3D;
/*     */ import com.orsoncharts.axis.ValueAxis3D;
/*     */ import com.orsoncharts.data.Dataset3DChangeEvent;
/*     */ import com.orsoncharts.data.ItemKey;
/*     */ import com.orsoncharts.data.KeyedValues3DItemKey;
/*     */ import com.orsoncharts.data.category.CategoryDataset3D;
/*     */ import com.orsoncharts.graphics3d.Dimension3D;
/*     */ import com.orsoncharts.graphics3d.World;
/*     */ import com.orsoncharts.label.CategoryItemLabelGenerator;
/*     */ import com.orsoncharts.label.CategoryLabelGenerator;
/*     */ import com.orsoncharts.label.StandardCategoryItemLabelGenerator;
/*     */ import com.orsoncharts.label.StandardCategoryLabelGenerator;
/*     */ import com.orsoncharts.legend.LegendItemInfo;
/*     */ import com.orsoncharts.legend.StandardLegendItemInfo;
/*     */ import com.orsoncharts.renderer.Renderer3DChangeEvent;
/*     */ import com.orsoncharts.renderer.Renderer3DChangeListener;
/*     */ import com.orsoncharts.renderer.category.CategoryRenderer3D;
/*     */ import com.orsoncharts.util.ArgChecks;
/*     */ import com.orsoncharts.util.ObjectUtils;
/*     */ import com.orsoncharts.util.SerialUtils;
/*     */ import java.awt.BasicStroke;
/*     */ import java.awt.Color;
/*     */ import java.awt.Paint;
/*     */ import java.awt.Stroke;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CategoryPlot3D
/*     */   extends AbstractPlot3D
/*     */   implements Axis3DChangeListener, Renderer3DChangeListener, Serializable
/*     */ {
/*  72 */   private static Stroke DEFAULT_GRIDLINE_STROKE = new BasicStroke(0.5F, 1, 1, 1.0F, new float[] { 3.0F, 3.0F }, 0.0F);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private CategoryDataset3D dataset;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private CategoryRenderer3D renderer;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private CategoryAxis3D rowAxis;
/*     */ 
/*     */ 
/*     */   
/*     */   private CategoryAxis3D columnAxis;
/*     */ 
/*     */ 
/*     */   
/*     */   private ValueAxis3D valueAxis;
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean gridlinesVisibleForRows;
/*     */ 
/*     */ 
/*     */   
/*     */   private transient Paint gridlinePaintForRows;
/*     */ 
/*     */ 
/*     */   
/*     */   private transient Stroke gridlineStrokeForRows;
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean gridlinesVisibleForColumns;
/*     */ 
/*     */ 
/*     */   
/*     */   private transient Paint gridlinePaintForColumns;
/*     */ 
/*     */ 
/*     */   
/*     */   private transient Stroke gridlineStrokeForColumns;
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean gridlinesVisibleForValues;
/*     */ 
/*     */ 
/*     */   
/*     */   private transient Paint gridlinePaintForValues;
/*     */ 
/*     */ 
/*     */   
/*     */   private transient Stroke gridlineStrokeForValues;
/*     */ 
/*     */ 
/*     */   
/*     */   private CategoryLabelGenerator legendLabelGenerator;
/*     */ 
/*     */ 
/*     */   
/*     */   private Double yDimensionOverride;
/*     */ 
/*     */ 
/*     */   
/*     */   private CategoryItemLabelGenerator toolTipGenerator;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CategoryPlot3D(CategoryDataset3D dataset, CategoryRenderer3D renderer, CategoryAxis3D rowAxis, CategoryAxis3D columnAxis, ValueAxis3D valueAxis) {
/* 149 */     ArgChecks.nullNotPermitted(dataset, "dataset");
/* 150 */     ArgChecks.nullNotPermitted(renderer, "renderer");
/* 151 */     ArgChecks.nullNotPermitted(rowAxis, "rowAxis");
/* 152 */     ArgChecks.nullNotPermitted(columnAxis, "columnAxis");
/* 153 */     ArgChecks.nullNotPermitted(valueAxis, "valueAxis");
/* 154 */     this.dataset = dataset;
/* 155 */     this.dataset.addChangeListener(this);
/* 156 */     this.dimensions = calculateDimensions();
/* 157 */     this.renderer = renderer;
/* 158 */     this.renderer.setPlot(this);
/* 159 */     this.renderer.addChangeListener(this);
/* 160 */     this.rowAxis = rowAxis;
/* 161 */     this.rowAxis.addChangeListener(this);
/* 162 */     this.columnAxis = columnAxis;
/* 163 */     this.columnAxis.addChangeListener(this);
/* 164 */     this.valueAxis = valueAxis;
/* 165 */     this.valueAxis.addChangeListener(this);
/* 166 */     this.rowAxis.configureAsRowAxis(this);
/* 167 */     this.columnAxis.configureAsColumnAxis(this);
/* 168 */     this.valueAxis.configureAsValueAxis(this);
/* 169 */     this.gridlinesVisibleForValues = true;
/* 170 */     this.gridlinesVisibleForColumns = false;
/* 171 */     this.gridlinesVisibleForRows = false;
/* 172 */     this.gridlinePaintForRows = Color.WHITE;
/* 173 */     this.gridlinePaintForColumns = Color.WHITE;
/* 174 */     this.gridlinePaintForValues = Color.WHITE;
/* 175 */     this.gridlineStrokeForRows = DEFAULT_GRIDLINE_STROKE;
/* 176 */     this.gridlineStrokeForColumns = DEFAULT_GRIDLINE_STROKE;
/* 177 */     this.gridlineStrokeForValues = DEFAULT_GRIDLINE_STROKE;
/* 178 */     this.legendLabelGenerator = (CategoryLabelGenerator)new StandardCategoryLabelGenerator();
/* 179 */     this.yDimensionOverride = null;
/* 180 */     this.toolTipGenerator = (CategoryItemLabelGenerator)new StandardCategoryItemLabelGenerator();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAutoAdjustDimensions(boolean auto) {
/* 193 */     this.autoAdjustDimensions = auto;
/* 194 */     if (auto) {
/* 195 */       this.dimensions = calculateDimensions();
/* 196 */       fireChangeEvent(true);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDimensions(Dimension3D dimensions) {
/* 210 */     ArgChecks.nullNotPermitted(dimensions, "dimensions");
/* 211 */     this.dimensions = dimensions;
/* 212 */     this.autoAdjustDimensions = false;
/* 213 */     fireChangeEvent(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CategoryDataset3D getDataset() {
/* 222 */     return this.dataset;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDataset(CategoryDataset3D dataset) {
/* 232 */     ArgChecks.nullNotPermitted(dataset, "dataset");
/* 233 */     this.dataset.removeChangeListener(this);
/* 234 */     this.dataset = dataset;
/* 235 */     this.dataset.addChangeListener(this);
/* 236 */     fireChangeEvent(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CategoryRenderer3D getRenderer() {
/* 246 */     return this.renderer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRenderer(CategoryRenderer3D renderer) {
/* 255 */     ArgChecks.nullNotPermitted(renderer, "renderer");
/* 256 */     this.renderer.removeChangeListener(this);
/* 257 */     this.renderer = renderer;
/* 258 */     this.renderer.addChangeListener(this);
/*     */     
/* 260 */     this.valueAxis.configureAsValueAxis(this);
/* 261 */     fireChangeEvent(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CategoryAxis3D getRowAxis() {
/* 270 */     return this.rowAxis;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRowAxis(CategoryAxis3D axis) {
/* 280 */     ArgChecks.nullNotPermitted(axis, "axis");
/* 281 */     this.rowAxis.removeChangeListener(this);
/* 282 */     this.rowAxis = axis;
/* 283 */     this.rowAxis.addChangeListener(this);
/* 284 */     fireChangeEvent(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CategoryAxis3D getColumnAxis() {
/* 293 */     return this.columnAxis;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setColumnAxis(CategoryAxis3D axis) {
/* 307 */     ArgChecks.nullNotPermitted(axis, "axis");
/* 308 */     this.columnAxis.removeChangeListener(this);
/* 309 */     this.columnAxis = axis;
/* 310 */     this.columnAxis.addChangeListener(this);
/* 311 */     fireChangeEvent(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ValueAxis3D getValueAxis() {
/* 320 */     return this.valueAxis;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setValueAxis(ValueAxis3D axis) {
/* 330 */     ArgChecks.nullNotPermitted(axis, "axis");
/* 331 */     this.valueAxis.removeChangeListener(this);
/* 332 */     this.valueAxis = axis;
/* 333 */     this.valueAxis.configureAsValueAxis(this);
/* 334 */     this.valueAxis.addChangeListener(this);
/* 335 */     fireChangeEvent(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getGridlinesVisibleForRows() {
/* 346 */     return this.gridlinesVisibleForRows;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setGridlinesVisibleForRows(boolean visible) {
/* 357 */     this.gridlinesVisibleForRows = visible;
/* 358 */     fireChangeEvent(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Paint getGridlinePaintForRows() {
/* 368 */     return this.gridlinePaintForRows;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setGridlinePaintForRows(Paint paint) {
/* 378 */     ArgChecks.nullNotPermitted(paint, "paint");
/* 379 */     this.gridlinePaintForRows = paint;
/* 380 */     fireChangeEvent(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Stroke getGridlineStrokeForRows() {
/* 391 */     return this.gridlineStrokeForRows;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setGridlineStrokeForRows(Stroke stroke) {
/* 402 */     ArgChecks.nullNotPermitted(stroke, "stroke");
/* 403 */     this.gridlineStrokeForRows = stroke;
/* 404 */     fireChangeEvent(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getGridlinesVisibleForColumns() {
/* 415 */     return this.gridlinesVisibleForColumns;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setGridlinesVisibleForColumns(boolean visible) {
/* 426 */     this.gridlinesVisibleForColumns = visible;
/* 427 */     fireChangeEvent(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getGridlinesVisibleForValues() {
/* 437 */     return this.gridlinesVisibleForValues;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setGridlinesVisibleForValues(boolean visible) {
/* 448 */     this.gridlinesVisibleForValues = visible;
/* 449 */     fireChangeEvent(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Paint getGridlinePaintForValues() {
/* 459 */     return this.gridlinePaintForValues;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setGridlinePaintForValues(Paint paint) {
/* 469 */     ArgChecks.nullNotPermitted(paint, "paint");
/* 470 */     this.gridlinePaintForValues = paint;
/* 471 */     fireChangeEvent(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Stroke getGridlineStrokeForValues() {
/* 482 */     return this.gridlineStrokeForValues;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setGridlineStrokeForValues(Stroke stroke) {
/* 493 */     ArgChecks.nullNotPermitted(stroke, "stroke");
/* 494 */     this.gridlineStrokeForValues = stroke;
/* 495 */     fireChangeEvent(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Paint getGridlinePaintForColumns() {
/* 505 */     return this.gridlinePaintForColumns;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setGridlinePaintForColumns(Paint paint) {
/* 516 */     ArgChecks.nullNotPermitted(paint, "paint");
/* 517 */     this.gridlinePaintForColumns = paint;
/* 518 */     fireChangeEvent(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Stroke getGridlineStrokeForColumns() {
/* 529 */     return this.gridlineStrokeForColumns;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setGridlineStrokeForColumns(Stroke stroke) {
/* 540 */     ArgChecks.nullNotPermitted(stroke, "stroke");
/* 541 */     this.gridlineStrokeForColumns = stroke;
/* 542 */     fireChangeEvent(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CategoryLabelGenerator getLegendLabelGenerator() {
/* 553 */     return this.legendLabelGenerator;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLegendLabelGenerator(CategoryLabelGenerator generator) {
/* 565 */     ArgChecks.nullNotPermitted(generator, "generator");
/* 566 */     this.legendLabelGenerator = generator;
/* 567 */     fireChangeEvent(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Double getYDimensionOverride() {
/* 579 */     return this.yDimensionOverride;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setYDimensionOverride(Double dim) {
/* 592 */     this.yDimensionOverride = dim;
/* 593 */     if (this.autoAdjustDimensions) {
/* 594 */       this.dimensions = calculateDimensions();
/* 595 */       fireChangeEvent(true);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CategoryItemLabelGenerator getToolTipGenerator() {
/* 607 */     return this.toolTipGenerator;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setToolTipGenerator(CategoryItemLabelGenerator generator) {
/* 619 */     this.toolTipGenerator = generator;
/* 620 */     fireChangeEvent(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<LegendItemInfo> getLegendInfo() {
/* 632 */     List<LegendItemInfo> result = new ArrayList<LegendItemInfo>();
/* 633 */     List<Comparable<?>> keys = this.dataset.getSeriesKeys();
/* 634 */     for (Comparable<?> key : keys) {
/* 635 */       int series = this.dataset.getSeriesIndex(key);
/* 636 */       Color color = this.renderer.getColorSource().getLegendColor(series);
/* 637 */       String seriesLabel = this.legendLabelGenerator.generateSeriesLabel(this.dataset, key);
/*     */       
/* 639 */       StandardLegendItemInfo standardLegendItemInfo = new StandardLegendItemInfo(key, seriesLabel, color);
/*     */       
/* 641 */       result.add(standardLegendItemInfo);
/*     */     } 
/* 643 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void compose(World world, double xOffset, double yOffset, double zOffset) {
/* 649 */     for (int series = 0; series < this.dataset.getSeriesCount(); series++) {
/* 650 */       for (int row = 0; row < this.dataset.getRowCount(); row++) {
/* 651 */         for (int column = 0; column < this.dataset.getColumnCount(); 
/* 652 */           column++) {
/* 653 */           this.renderer.composeItem(this.dataset, series, row, column, world, 
/* 654 */               getDimensions(), xOffset, yOffset, zOffset);
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public String generateToolTipText(ItemKey itemKey) {
/* 662 */     if (!(itemKey instanceof KeyedValues3DItemKey)) {
/* 663 */       throw new IllegalArgumentException("The itemKey must be a Values3DItemKey instance.");
/*     */     }
/*     */     
/* 666 */     KeyedValues3DItemKey vik = (KeyedValues3DItemKey)itemKey;
/* 667 */     return this.toolTipGenerator.generateItemLabel(this.dataset, vik
/* 668 */         .getSeriesKey(), vik.getRowKey(), vik.getColumnKey());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void receive(ChartElementVisitor visitor) {
/* 682 */     this.columnAxis.receive(visitor);
/* 683 */     this.rowAxis.receive(visitor);
/* 684 */     this.valueAxis.receive(visitor);
/* 685 */     this.renderer.receive(visitor);
/* 686 */     visitor.visit(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 698 */     if (obj == this) {
/* 699 */       return true;
/*     */     }
/* 701 */     if (!(obj instanceof CategoryPlot3D)) {
/* 702 */       return false;
/*     */     }
/* 704 */     CategoryPlot3D that = (CategoryPlot3D)obj;
/* 705 */     if (this.gridlinesVisibleForRows != that.gridlinesVisibleForRows) {
/* 706 */       return false;
/*     */     }
/* 708 */     if (!this.gridlineStrokeForRows.equals(that.gridlineStrokeForRows)) {
/* 709 */       return false;
/*     */     }
/* 711 */     if (!ObjectUtils.equalsPaint(this.gridlinePaintForRows, that.gridlinePaintForRows))
/*     */     {
/* 713 */       return false;
/*     */     }
/* 715 */     if (this.gridlinesVisibleForColumns != that.gridlinesVisibleForColumns)
/*     */     {
/* 717 */       return false;
/*     */     }
/* 719 */     if (!this.gridlineStrokeForColumns.equals(that.gridlineStrokeForColumns))
/*     */     {
/* 721 */       return false;
/*     */     }
/* 723 */     if (!ObjectUtils.equalsPaint(this.gridlinePaintForColumns, that.gridlinePaintForColumns))
/*     */     {
/* 725 */       return false;
/*     */     }
/* 727 */     if (this.gridlinesVisibleForValues != that.gridlinesVisibleForValues) {
/* 728 */       return false;
/*     */     }
/* 730 */     if (!this.gridlineStrokeForValues.equals(that.gridlineStrokeForValues)) {
/* 731 */       return false;
/*     */     }
/* 733 */     if (!ObjectUtils.equalsPaint(this.gridlinePaintForValues, that.gridlinePaintForValues))
/*     */     {
/* 735 */       return false;
/*     */     }
/* 737 */     if (!this.legendLabelGenerator.equals(that.legendLabelGenerator)) {
/* 738 */       return false;
/*     */     }
/* 740 */     if (!ObjectUtils.equals(this.yDimensionOverride, that.yDimensionOverride))
/*     */     {
/* 742 */       return false;
/*     */     }
/* 744 */     if (!ObjectUtils.equals(this.toolTipGenerator, that.toolTipGenerator)) {
/* 745 */       return false;
/*     */     }
/* 747 */     return super.equals(obj);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void datasetChanged(Dataset3DChangeEvent event) {
/* 759 */     if (this.autoAdjustDimensions) {
/* 760 */       this.dimensions = calculateDimensions();
/*     */     }
/* 762 */     this.columnAxis.configureAsColumnAxis(this);
/* 763 */     this.rowAxis.configureAsRowAxis(this);
/* 764 */     this.valueAxis.configureAsValueAxis(this);
/* 765 */     super.datasetChanged(event);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Dimension3D calculateDimensions() {
/* 780 */     double depth = Math.max(1.0D, (this.dataset.getRowCount() + 1));
/* 781 */     double width = Math.max(1.0D, (this.dataset.getColumnCount() + 1));
/* 782 */     double height = Math.max(1.0D, Math.min(width, depth));
/* 783 */     if (this.yDimensionOverride != null) {
/* 784 */       height = this.yDimensionOverride.doubleValue();
/*     */     }
/* 786 */     return new Dimension3D(width, height, depth);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void axisChanged(Axis3DChangeEvent event) {
/* 798 */     fireChangeEvent(event.requiresWorldUpdate());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void rendererChanged(Renderer3DChangeEvent event) {
/* 810 */     fireChangeEvent(event.requiresWorldUpdate());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void writeObject(ObjectOutputStream stream) throws IOException {
/* 821 */     stream.defaultWriteObject();
/* 822 */     SerialUtils.writePaint(this.gridlinePaintForRows, stream);
/* 823 */     SerialUtils.writePaint(this.gridlinePaintForColumns, stream);
/* 824 */     SerialUtils.writePaint(this.gridlinePaintForValues, stream);
/* 825 */     SerialUtils.writeStroke(this.gridlineStrokeForRows, stream);
/* 826 */     SerialUtils.writeStroke(this.gridlineStrokeForColumns, stream);
/* 827 */     SerialUtils.writeStroke(this.gridlineStrokeForValues, stream);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void readObject(ObjectInputStream stream) throws IOException, ClassNotFoundException {
/* 840 */     stream.defaultReadObject();
/* 841 */     this.gridlinePaintForRows = SerialUtils.readPaint(stream);
/* 842 */     this.gridlinePaintForColumns = SerialUtils.readPaint(stream);
/* 843 */     this.gridlinePaintForValues = SerialUtils.readPaint(stream);
/* 844 */     this.gridlineStrokeForRows = SerialUtils.readStroke(stream);
/* 845 */     this.gridlineStrokeForColumns = SerialUtils.readStroke(stream);
/* 846 */     this.gridlineStrokeForValues = SerialUtils.readStroke(stream);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/plot/CategoryPlot3D.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */