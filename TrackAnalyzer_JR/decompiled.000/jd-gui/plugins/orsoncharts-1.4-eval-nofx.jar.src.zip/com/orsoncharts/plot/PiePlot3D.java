/*     */ package com.orsoncharts.plot;
/*     */ 
/*     */ import com.orsoncharts.ChartElementVisitor;
/*     */ import com.orsoncharts.data.DataUtils;
/*     */ import com.orsoncharts.data.ItemKey;
/*     */ import com.orsoncharts.data.KeyedValuesItemKey;
/*     */ import com.orsoncharts.data.PieDataset3D;
/*     */ import com.orsoncharts.data.Values;
/*     */ import com.orsoncharts.graphics3d.Dimension3D;
/*     */ import com.orsoncharts.graphics3d.Dot3D;
/*     */ import com.orsoncharts.graphics3d.Object3D;
/*     */ import com.orsoncharts.graphics3d.World;
/*     */ import com.orsoncharts.label.PieLabelGenerator;
/*     */ import com.orsoncharts.label.StandardPieLabelGenerator;
/*     */ import com.orsoncharts.legend.LegendItemInfo;
/*     */ import com.orsoncharts.legend.StandardLegendItemInfo;
/*     */ import com.orsoncharts.util.ArgChecks;
/*     */ import java.awt.Color;
/*     */ import java.awt.Font;
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PiePlot3D
/*     */   extends AbstractPlot3D
/*     */   implements Serializable
/*     */ {
/*  56 */   public static final Font DEFAULT_SECTION_LABEL_FONT = new Font("Dialog", 0, 14);
/*     */ 
/*     */ 
/*     */   
/*     */   private PieDataset3D dataset;
/*     */ 
/*     */ 
/*     */   
/*     */   private double radius;
/*     */ 
/*     */ 
/*     */   
/*     */   private double depth;
/*     */ 
/*     */ 
/*     */   
/*     */   private ColorSource sectionColorSource;
/*     */ 
/*     */ 
/*     */   
/*     */   private PieLabelGenerator sectionLabelGenerator;
/*     */ 
/*     */ 
/*     */   
/*     */   private FontSource sectionLabelFontSource;
/*     */ 
/*     */ 
/*     */   
/*     */   private ColorSource sectionLabelColorSource;
/*     */ 
/*     */ 
/*     */   
/*     */   private PieLabelGenerator legendLabelGenerator;
/*     */ 
/*     */ 
/*     */   
/*     */   private PieLabelGenerator toolTipGenerator;
/*     */ 
/*     */   
/*  95 */   private int segments = 40;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PiePlot3D(PieDataset3D dataset) {
/* 103 */     ArgChecks.nullNotPermitted(dataset, "dataset");
/* 104 */     this.dataset = dataset;
/* 105 */     this.dataset.addChangeListener(this);
/* 106 */     this.radius = 4.0D;
/* 107 */     this.depth = 0.5D;
/* 108 */     this.sectionColorSource = new StandardColorSource();
/* 109 */     this.sectionLabelGenerator = (PieLabelGenerator)new StandardPieLabelGenerator("%s");
/*     */     
/* 111 */     this.sectionLabelFontSource = new StandardFontSource(DEFAULT_SECTION_LABEL_FONT);
/*     */     
/* 113 */     this.sectionLabelColorSource = new StandardColorSource(new Color[] { Color.BLACK });
/* 114 */     this.legendLabelGenerator = (PieLabelGenerator)new StandardPieLabelGenerator();
/* 115 */     this.toolTipGenerator = (PieLabelGenerator)new StandardPieLabelGenerator("%s (%3$,.2f%%)");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PieDataset3D getDataset() {
/* 125 */     return this.dataset;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDataset(PieDataset3D dataset) {
/* 135 */     ArgChecks.nullNotPermitted(dataset, "dataset");
/* 136 */     this.dataset.removeChangeListener(this);
/* 137 */     this.dataset = dataset;
/* 138 */     this.dataset.addChangeListener(this);
/* 139 */     fireChangeEvent(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getRadius() {
/* 148 */     return this.radius;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRadius(double radius) {
/* 158 */     this.radius = radius;
/* 159 */     fireChangeEvent(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getDepth() {
/* 168 */     return this.depth;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDepth(double depth) {
/* 178 */     this.depth = depth;
/* 179 */     fireChangeEvent(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ColorSource getSectionColorSource() {
/* 188 */     return this.sectionColorSource;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSectionColorSource(ColorSource source) {
/* 198 */     ArgChecks.nullNotPermitted(source, "source");
/* 199 */     this.sectionColorSource = source;
/* 200 */     fireChangeEvent(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSectionColors(Color... colors) {
/* 214 */     setSectionColorSource(new StandardColorSource(colors));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PieLabelGenerator getSectionLabelGenerator() {
/* 226 */     return this.sectionLabelGenerator;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSectionLabelGenerator(PieLabelGenerator generator) {
/* 238 */     ArgChecks.nullNotPermitted(generator, "generator");
/* 239 */     this.sectionLabelGenerator = generator;
/* 240 */     fireChangeEvent(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FontSource getSectionLabelFontSource() {
/* 250 */     return this.sectionLabelFontSource;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSectionLabelFontSource(FontSource source) {
/* 260 */     ArgChecks.nullNotPermitted(source, "source");
/* 261 */     this.sectionLabelFontSource = source;
/* 262 */     fireChangeEvent(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ColorSource getSectionLabelColorSource() {
/* 275 */     return this.sectionLabelColorSource;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSectionLabelColorSource(ColorSource source) {
/* 287 */     ArgChecks.nullNotPermitted(source, "source");
/* 288 */     this.sectionLabelColorSource = source;
/* 289 */     fireChangeEvent(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PieLabelGenerator getLegendLabelGenerator() {
/* 301 */     return this.legendLabelGenerator;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLegendLabelGenerator(PieLabelGenerator generator) {
/* 314 */     ArgChecks.nullNotPermitted(generator, "generator");
/* 315 */     this.legendLabelGenerator = generator;
/* 316 */     fireChangeEvent(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PieLabelGenerator getToolTipGenerator() {
/* 327 */     return this.toolTipGenerator;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setToolTipGenerator(PieLabelGenerator generator) {
/* 339 */     this.toolTipGenerator = generator;
/* 340 */     fireChangeEvent(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Dimension3D getDimensions() {
/* 352 */     return new Dimension3D(this.radius * 2.0D, this.depth, this.radius * 2.0D);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getSegmentCount() {
/* 362 */     return this.segments;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSegmentCount(int count) {
/* 374 */     this.segments = count;
/* 375 */     fireChangeEvent(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<LegendItemInfo> getLegendInfo() {
/* 387 */     List<LegendItemInfo> result = new ArrayList<LegendItemInfo>();
/* 388 */     for (Comparable<?> key : (Iterable<Comparable<?>>)this.dataset.getKeys()) {
/* 389 */       String label = this.legendLabelGenerator.generateLabel(this.dataset, key);
/*     */ 
/*     */       
/* 392 */       StandardLegendItemInfo standardLegendItemInfo = new StandardLegendItemInfo(key, label, this.sectionColorSource.getColor(key));
/* 393 */       result.add(standardLegendItemInfo);
/*     */     } 
/* 395 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void compose(World world, double xOffset, double yOffset, double zOffset) {
/* 412 */     double total = DataUtils.total((Values)this.dataset);
/* 413 */     double r = 0.0D;
/* 414 */     int count = this.dataset.getItemCount();
/* 415 */     for (int i = 0; i < count; i++) {
/* 416 */       Comparable<?> key = this.dataset.getKey(i);
/* 417 */       Number n = (Number)this.dataset.getValue(i);
/* 418 */       if (n != null) {
/* 419 */         double angle = 6.283185307179586D * n.doubleValue() / total;
/* 420 */         Color c = this.sectionColorSource.getColor(this.dataset
/* 421 */             .getKey(i));
/* 422 */         Object3D segment = Object3D.createPieSegment(this.radius, 0.0D, yOffset, this.depth, r, r + angle, Math.PI / this.segments, c);
/*     */ 
/*     */         
/* 425 */         segment.setProperty("key", new KeyedValuesItemKey(key));
/*     */         
/* 427 */         world.add(segment);
/* 428 */         r += angle;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Object3D> getLabelFaces(double xOffset, double yOffset, double zOffset) {
/* 449 */     double total = DataUtils.total((Values)this.dataset);
/* 450 */     List<Object3D> result = new ArrayList<Object3D>();
/*     */     
/* 452 */     result.add(new Dot3D(0.0F, 0.0F, 0.0F, Color.RED));
/* 453 */     result.add(new Dot3D(0.0F, (float)yOffset, 0.0F, Color.RED));
/* 454 */     double r = 0.0D;
/* 455 */     int count = this.dataset.getItemCount();
/* 456 */     for (int i = 0; i < count; i++) {
/* 457 */       Number n = (Number)this.dataset.getValue(i);
/* 458 */       double angle = 0.0D;
/* 459 */       if (n != null) {
/* 460 */         angle = 6.283185307179586D * n.doubleValue() / total;
/*     */       }
/* 462 */       result.addAll(Object3D.createPieLabelMarkers(this.radius * 1.2D, 0.0D, yOffset - this.depth * 0.05D, this.depth * 1.1D, r, r + angle));
/*     */ 
/*     */       
/* 465 */       r += angle;
/*     */     } 
/* 467 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public String generateToolTipText(ItemKey itemKey) {
/* 472 */     if (!(itemKey instanceof KeyedValuesItemKey)) {
/* 473 */       throw new IllegalArgumentException("The itemKey must be a ValuesItemKey instance.");
/*     */     }
/*     */     
/* 476 */     KeyedValuesItemKey vik = (KeyedValuesItemKey)itemKey;
/* 477 */     return this.toolTipGenerator.generateLabel(this.dataset, vik.getKey());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void receive(ChartElementVisitor visitor) {
/* 491 */     visitor.visit(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 504 */     if (obj == this) {
/* 505 */       return true;
/*     */     }
/* 507 */     if (!(obj instanceof PiePlot3D)) {
/* 508 */       return false;
/*     */     }
/* 510 */     PiePlot3D that = (PiePlot3D)obj;
/* 511 */     if (this.radius != that.radius) {
/* 512 */       return false;
/*     */     }
/* 514 */     if (this.depth != that.depth) {
/* 515 */       return false;
/*     */     }
/* 517 */     if (!this.sectionColorSource.equals(that.sectionColorSource)) {
/* 518 */       return false;
/*     */     }
/* 520 */     if (!this.sectionLabelGenerator.equals(that.sectionLabelGenerator)) {
/* 521 */       return false;
/*     */     }
/* 523 */     if (!this.sectionLabelFontSource.equals(that.sectionLabelFontSource)) {
/* 524 */       return false;
/*     */     }
/* 526 */     if (!this.sectionLabelColorSource.equals(that.sectionLabelColorSource))
/*     */     {
/* 528 */       return false;
/*     */     }
/* 530 */     if (!this.legendLabelGenerator.equals(that.legendLabelGenerator)) {
/* 531 */       return false;
/*     */     }
/* 533 */     if (!this.toolTipGenerator.equals(that.toolTipGenerator)) {
/* 534 */       return false;
/*     */     }
/* 536 */     if (this.segments != that.segments) {
/* 537 */       return false;
/*     */     }
/* 539 */     return super.equals(obj);
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 544 */     int hash = 5;
/*     */     
/* 546 */     hash = 97 * hash + (int)(Double.doubleToLongBits(this.radius) ^ Double.doubleToLongBits(this.radius) >>> 32L);
/*     */     
/* 548 */     hash = 97 * hash + (int)(Double.doubleToLongBits(this.depth) ^ Double.doubleToLongBits(this.depth) >>> 32L);
/* 549 */     hash = 97 * hash + this.sectionColorSource.hashCode();
/* 550 */     hash = 97 * hash + this.sectionLabelGenerator.hashCode();
/* 551 */     hash = 97 * hash + this.sectionLabelFontSource.hashCode();
/* 552 */     hash = 97 * hash + this.sectionLabelColorSource.hashCode();
/* 553 */     hash = 97 * hash + this.segments;
/* 554 */     return hash;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/plot/PiePlot3D.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */