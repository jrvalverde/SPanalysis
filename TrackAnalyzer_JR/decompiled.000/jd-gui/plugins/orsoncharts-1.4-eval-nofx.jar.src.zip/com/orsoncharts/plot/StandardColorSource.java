/*     */ package com.orsoncharts.plot;
/*     */ 
/*     */ import com.orsoncharts.Colors;
/*     */ import com.orsoncharts.data.DefaultKeyedValues;
/*     */ import com.orsoncharts.util.ArgChecks;
/*     */ import java.awt.Color;
/*     */ import java.io.Serializable;
/*     */ import java.util.Arrays;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class StandardColorSource
/*     */   implements ColorSource, Serializable
/*     */ {
/*     */   private Color[] standardColors;
/*     */   private DefaultKeyedValues<Color> colors;
/*     */   
/*     */   public StandardColorSource() {
/*  47 */     this(Colors.getDefaultColors());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StandardColorSource(Color... colors) {
/*  58 */     ArgChecks.nullNotPermitted(colors, "colors");
/*  59 */     if (colors.length == 0) {
/*  60 */       throw new IllegalArgumentException("Zero length array not permitted.");
/*     */     }
/*     */     
/*  63 */     for (Color c : colors) {
/*  64 */       if (c == null) {
/*  65 */         throw new IllegalArgumentException("Null array entries not permitted.");
/*     */       }
/*     */     } 
/*     */     
/*  69 */     this.standardColors = (Color[])colors.clone();
/*  70 */     this.colors = new DefaultKeyedValues();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Color getColor(Comparable<?> key) {
/*  83 */     Color c = (Color)this.colors.getValue(key);
/*  84 */     if (c != null) {
/*  85 */       return c;
/*     */     }
/*  87 */     c = this.standardColors[this.colors.getItemCount() % this.standardColors.length];
/*     */     
/*  89 */     this.colors.put(key, c);
/*  90 */     return c;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setColor(Comparable<?> key, Color color) {
/* 101 */     if (color != null) {
/* 102 */       this.colors.put(key, color);
/*     */     } else {
/* 104 */       this.colors.remove(key);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void style(Color... colors) {
/* 119 */     this.standardColors = colors;
/* 120 */     this.colors.clear();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 132 */     if (obj == this) {
/* 133 */       return true;
/*     */     }
/* 135 */     if (!(obj instanceof StandardColorSource)) {
/* 136 */       return false;
/*     */     }
/* 138 */     StandardColorSource that = (StandardColorSource)obj;
/* 139 */     if (!Arrays.equals((Object[])this.standardColors, (Object[])that.standardColors)) {
/* 140 */       return false;
/*     */     }
/* 142 */     if (!this.colors.equals(that.colors)) {
/* 143 */       return false;
/*     */     }
/* 145 */     return true;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/plot/StandardColorSource.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */