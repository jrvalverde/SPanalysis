/*    */ package com.orsoncharts;
/*    */ 
/*    */ import com.orsoncharts.util.ArgChecks;
/*    */ import java.util.Locale;
/*    */ import java.util.ResourceBundle;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Resources
/*    */ {
/* 27 */   private static Locale locale = Locale.getDefault();
/*    */ 
/*    */   
/* 30 */   private static ResourceBundle resources = ResourceBundle.getBundle("com.orsoncharts.Resources", 
/* 31 */       Locale.getDefault());
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static Locale getLocale() {
/* 40 */     return locale;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static void setLocale(Locale l) {
/* 49 */     ArgChecks.nullNotPermitted(l, "l");
/* 50 */     locale = l;
/* 51 */     resources = ResourceBundle.getBundle("com.orsoncharts.Resources", locale);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static String localString(String key) {
/* 63 */     return resources.getString(key);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/Resources.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */