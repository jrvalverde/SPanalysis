package com.orsoncharts.renderer;

public interface ColorScaleRenderer {
  ColorScale getColorScale();
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/renderer/ColorScaleRenderer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */