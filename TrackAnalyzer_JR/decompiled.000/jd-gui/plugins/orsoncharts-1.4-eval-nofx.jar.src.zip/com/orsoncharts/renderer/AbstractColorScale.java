/*    */ package com.orsoncharts.renderer;
/*    */ 
/*    */ import com.orsoncharts.Range;
/*    */ import com.orsoncharts.util.ArgChecks;
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractColorScale
/*    */   implements Serializable
/*    */ {
/*    */   private Range range;
/*    */   
/*    */   protected AbstractColorScale(Range range) {
/* 42 */     ArgChecks.nullNotPermitted(range, "range");
/* 43 */     this.range = range;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Range getRange() {
/* 53 */     return this.range;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean equals(Object obj) {
/* 65 */     if (obj == this) {
/* 66 */       return true;
/*    */     }
/* 68 */     if (!(obj instanceof AbstractColorScale)) {
/* 69 */       return false;
/*    */     }
/* 71 */     AbstractColorScale that = (AbstractColorScale)obj;
/* 72 */     if (!this.range.equals(that.range)) {
/* 73 */       return false;
/*    */     }
/* 75 */     return true;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/renderer/AbstractColorScale.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */