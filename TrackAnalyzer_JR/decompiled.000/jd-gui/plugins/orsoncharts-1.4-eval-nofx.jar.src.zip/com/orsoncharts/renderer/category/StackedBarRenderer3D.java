/*     */ package com.orsoncharts.renderer.category;
/*     */ 
/*     */ import com.orsoncharts.Range;
/*     */ import com.orsoncharts.data.DataUtils;
/*     */ import com.orsoncharts.data.KeyedValues3DItemKey;
/*     */ import com.orsoncharts.data.Values3D;
/*     */ import com.orsoncharts.data.category.CategoryDataset3D;
/*     */ import com.orsoncharts.graphics3d.Dimension3D;
/*     */ import com.orsoncharts.graphics3d.Object3D;
/*     */ import com.orsoncharts.graphics3d.Offset3D;
/*     */ import com.orsoncharts.graphics3d.World;
/*     */ import com.orsoncharts.label.ItemLabelPositioning;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StackedBarRenderer3D
/*     */   extends BarRenderer3D
/*     */ {
/*     */   public StackedBarRenderer3D() {
/*  55 */     setItemLabelPositioning(ItemLabelPositioning.FRONT_AND_BACK);
/*  56 */     setItemLabelOffsets(new Offset3D(0.0D, 0.0D, -1.0D));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Range findValueRange(Values3D<? extends Number> data) {
/*  71 */     return DataUtils.findStackedValueRange(data);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void composeItem(CategoryDataset3D dataset, int series, int row, int column, World world, Dimension3D dimensions, double xOffset, double yOffset, double zOffset) {
/*  94 */     double value = dataset.getDoubleValue(series, row, column);
/*  95 */     if (Double.isNaN(value)) {
/*     */       return;
/*     */     }
/*  98 */     double[] stack = DataUtils.stackSubTotal((Values3D)dataset, getBase(), series, row, column);
/*     */     
/* 100 */     double lower = stack[1];
/* 101 */     if (value < 0.0D) {
/* 102 */       lower = stack[0];
/*     */     }
/* 104 */     double upper = lower + value;
/* 105 */     composeItem(upper, lower, dataset, series, row, column, world, dimensions, xOffset, yOffset, zOffset);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void drawItemLabels(World world, CategoryDataset3D dataset, KeyedValues3DItemKey itemKey, double xw, double yw, double zw, double basew, boolean inverted) {
/* 114 */     ItemLabelPositioning positioning = getItemLabelPositioning();
/* 115 */     if (getItemLabelGenerator() != null) {
/* 116 */       String label = getItemLabelGenerator().generateItemLabel(dataset, itemKey
/* 117 */           .getSeriesKey(), itemKey.getRowKey(), itemKey
/* 118 */           .getColumnKey());
/* 119 */       if (label != null) {
/* 120 */         Dimension3D dimensions = getPlot().getDimensions();
/* 121 */         double dx = getItemLabelOffsets().getDX();
/*     */         
/* 123 */         double dy = getItemLabelOffsets().getDY() * dimensions.getHeight();
/* 124 */         double dz = getItemLabelOffsets().getDZ() * getBarZWidth();
/* 125 */         if (positioning.equals(ItemLabelPositioning.CENTRAL)) {
/* 126 */           double yy = yw;
/* 127 */           if (inverted) {
/* 128 */             yy = basew;
/* 129 */             dy = -dy;
/*     */           } 
/* 131 */           Object3D labelObj = Object3D.createLabelObject(label, 
/* 132 */               getItemLabelFont(), getItemLabelColor(), 
/* 133 */               getItemLabelBackgroundColor(), xw + dx, yy + dy, zw, false, true);
/*     */           
/* 135 */           labelObj.setProperty("key", itemKey);
/* 136 */           world.add(labelObj);
/* 137 */         } else if (positioning.equals(ItemLabelPositioning.FRONT_AND_BACK)) {
/*     */           
/* 139 */           double yy = (yw + basew) / 2.0D;
/* 140 */           Object3D labelObj1 = Object3D.createLabelObject(label, 
/* 141 */               getItemLabelFont(), getItemLabelColor(), 
/* 142 */               getItemLabelBackgroundColor(), xw + dx, yy + dy, zw + dz, false, false);
/*     */           
/* 144 */           labelObj1.setProperty("key", itemKey);
/* 145 */           world.add(labelObj1);
/* 146 */           Object3D labelObj2 = Object3D.createLabelObject(label, 
/* 147 */               getItemLabelFont(), getItemLabelColor(), 
/* 148 */               getItemLabelBackgroundColor(), xw + dx, yy + dy, zw - dz, true, false);
/*     */           
/* 150 */           labelObj2.setProperty("key", itemKey);
/* 151 */           world.add(labelObj2);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 166 */     if (obj == this) {
/* 167 */       return true;
/*     */     }
/* 169 */     if (!(obj instanceof StackedBarRenderer3D)) {
/* 170 */       return false;
/*     */     }
/* 172 */     return super.equals(obj);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/renderer/category/StackedBarRenderer3D.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */