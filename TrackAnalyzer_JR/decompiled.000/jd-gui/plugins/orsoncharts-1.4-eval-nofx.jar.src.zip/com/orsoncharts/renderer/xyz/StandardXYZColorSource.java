/*     */ package com.orsoncharts.renderer.xyz;
/*     */ 
/*     */ import com.orsoncharts.Colors;
/*     */ import com.orsoncharts.util.ArgChecks;
/*     */ import com.orsoncharts.util.ObjectUtils;
/*     */ import java.awt.Color;
/*     */ import java.io.Serializable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StandardXYZColorSource
/*     */   implements XYZColorSource, Serializable
/*     */ {
/*     */   private Color[] colors;
/*     */   
/*     */   public StandardXYZColorSource() {
/*  39 */     this(Colors.getDefaultColors());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StandardXYZColorSource(Color... colors) {
/*  50 */     ArgChecks.nullNotPermitted(colors, "colors");
/*  51 */     if (colors.length == 0) {
/*  52 */       throw new IllegalArgumentException("Zero length array not permitted.");
/*     */     }
/*     */     
/*  55 */     for (Color c : colors) {
/*  56 */       if (c == null) {
/*  57 */         throw new IllegalArgumentException("Null array entries not permitted.");
/*     */       }
/*     */     } 
/*     */     
/*  61 */     this.colors = colors;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Color getColor(int series, int item) {
/*  74 */     return this.colors[series % this.colors.length];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Color getLegendColor(int series) {
/*  86 */     return this.colors[series % this.colors.length];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void style(Color... colors) {
/* 101 */     ArgChecks.nullNotPermitted(colors, "colors");
/* 102 */     if (colors.length == 0) {
/* 103 */       throw new IllegalArgumentException("Zero length array not permitted.");
/*     */     }
/*     */     
/* 106 */     for (Color c : colors) {
/* 107 */       if (c == null) {
/* 108 */         throw new IllegalArgumentException("Null array entries not permitted.");
/*     */       }
/*     */     } 
/*     */     
/* 112 */     this.colors = (Color[])colors.clone();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 124 */     if (obj == this) {
/* 125 */       return true;
/*     */     }
/* 127 */     if (!(obj instanceof StandardXYZColorSource)) {
/* 128 */       return false;
/*     */     }
/* 130 */     StandardXYZColorSource that = (StandardXYZColorSource)obj;
/* 131 */     if (this.colors.length != that.colors.length) {
/* 132 */       return false;
/*     */     }
/* 134 */     for (int i = 0; i < this.colors.length; i++) {
/* 135 */       if (!ObjectUtils.equalsPaint(this.colors[i], that.colors[i])) {
/* 136 */         return false;
/*     */       }
/*     */     } 
/* 139 */     return true;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/renderer/xyz/StandardXYZColorSource.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */