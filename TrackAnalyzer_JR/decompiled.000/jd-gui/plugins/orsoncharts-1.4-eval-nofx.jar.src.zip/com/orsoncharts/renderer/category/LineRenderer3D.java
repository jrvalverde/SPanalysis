/*      */ package com.orsoncharts.renderer.category;
/*      */ 
/*      */ import com.orsoncharts.Range;
/*      */ import com.orsoncharts.axis.CategoryAxis3D;
/*      */ import com.orsoncharts.axis.ValueAxis3D;
/*      */ import com.orsoncharts.data.KeyedValues3DItemKey;
/*      */ import com.orsoncharts.data.category.CategoryDataset3D;
/*      */ import com.orsoncharts.graphics3d.Dimension3D;
/*      */ import com.orsoncharts.graphics3d.Object3D;
/*      */ import com.orsoncharts.graphics3d.Offset3D;
/*      */ import com.orsoncharts.graphics3d.World;
/*      */ import com.orsoncharts.label.ItemLabelPositioning;
/*      */ import com.orsoncharts.plot.CategoryPlot3D;
/*      */ import com.orsoncharts.util.ObjectUtils;
/*      */ import java.awt.Color;
/*      */ import java.io.Serializable;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class LineRenderer3D
/*      */   extends AbstractCategoryRenderer3D
/*      */   implements Serializable
/*      */ {
/*   84 */   private double lineWidth = 0.4D;
/*   85 */   private double lineHeight = 0.2D;
/*   86 */   private double isolatedItemWidthPercent = 0.25D;
/*   87 */   private CategoryColorSource clipColorSource = new StandardCategoryColorSource(new Color[] { Color.RED });
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public double getLineWidth() {
/*   97 */     return this.lineWidth;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setLineWidth(double width) {
/*  107 */     this.lineWidth = width;
/*  108 */     fireChangeEvent(true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public double getLineHeight() {
/*  118 */     return this.lineHeight;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setLineHeight(double height) {
/*  128 */     this.lineHeight = height;
/*  129 */     fireChangeEvent(true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public double getIsolatedItemWidthPercent() {
/*  141 */     return this.isolatedItemWidthPercent;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setIsolatedItemWidthPercent(double percent) {
/*  153 */     this.isolatedItemWidthPercent = percent;
/*  154 */     fireChangeEvent(true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CategoryColorSource getClipColorSource() {
/*  165 */     return this.clipColorSource;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setClipColorSource(CategoryColorSource source) {
/*  176 */     this.clipColorSource = source;
/*  177 */     fireChangeEvent(true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void composeItem(CategoryDataset3D dataset, int series, int row, int column, World world, Dimension3D dimensions, double xOffset, double yOffset, double zOffset) {
/*      */     boolean createLeftSegment, createRightSegment, createIsolatedSegment;
/*  203 */     Number y = (Number)dataset.getValue(series, row, column);
/*  204 */     Number yprev = null;
/*  205 */     if (column > 0) {
/*  206 */       yprev = (Number)dataset.getValue(series, row, column - 1);
/*      */     }
/*  208 */     Number ynext = null;
/*  209 */     if (column < dataset.getColumnCount() - 1) {
/*  210 */       ynext = (Number)dataset.getValue(series, row, column + 1);
/*      */     }
/*      */     
/*  213 */     CategoryPlot3D plot = getPlot();
/*  214 */     CategoryAxis3D rowAxis = plot.getRowAxis();
/*  215 */     CategoryAxis3D columnAxis = plot.getColumnAxis();
/*  216 */     ValueAxis3D valueAxis = plot.getValueAxis();
/*  217 */     Range r = valueAxis.getRange();
/*      */     
/*  219 */     Comparable<?> seriesKey = dataset.getSeriesKey(series);
/*  220 */     Comparable<?> rowKey = dataset.getRowKey(row);
/*  221 */     Comparable<?> columnKey = dataset.getColumnKey(column);
/*  222 */     double rowValue = rowAxis.getCategoryValue(rowKey);
/*  223 */     double columnValue = columnAxis.getCategoryValue(columnKey);
/*  224 */     double ww = dimensions.getWidth();
/*  225 */     double hh = dimensions.getHeight();
/*  226 */     double dd = dimensions.getDepth();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  237 */     boolean leftOpen = false;
/*  238 */     boolean leftClose = false;
/*  239 */     boolean rightOpen = false;
/*  240 */     boolean rightClose = false;
/*  241 */     if (column == 0) {
/*  242 */       createLeftSegment = false;
/*  243 */       if (dataset.getColumnCount() == 1) {
/*  244 */         createRightSegment = false;
/*  245 */         createIsolatedSegment = (y != null);
/*      */       } else {
/*  247 */         createRightSegment = (y != null && ynext != null);
/*  248 */         rightOpen = true;
/*  249 */         rightClose = false;
/*  250 */         createIsolatedSegment = (y != null && ynext == null);
/*      */       } 
/*  252 */     } else if (column == dataset.getColumnCount() - 1) {
/*  253 */       createRightSegment = false;
/*  254 */       createLeftSegment = (y != null && yprev != null);
/*  255 */       leftOpen = false;
/*  256 */       leftClose = true;
/*  257 */       createIsolatedSegment = (y != null && yprev == null);
/*      */     } else {
/*  259 */       createLeftSegment = (y != null && yprev != null);
/*  260 */       leftOpen = false;
/*  261 */       leftClose = (createLeftSegment && ynext == null);
/*  262 */       createRightSegment = (y != null && ynext != null);
/*  263 */       rightOpen = (createRightSegment && yprev == null);
/*  264 */       rightClose = false;
/*  265 */       createIsolatedSegment = (y != null && yprev == null && ynext == null);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  271 */     double xw = columnAxis.translateToWorld(columnValue, ww) + xOffset;
/*  272 */     double yw = Double.NaN;
/*  273 */     if (y != null) {
/*  274 */       yw = valueAxis.translateToWorld(y.doubleValue(), hh) + yOffset;
/*      */     }
/*  276 */     double zw = rowAxis.translateToWorld(rowValue, dd) + zOffset;
/*  277 */     double ywmin = valueAxis.translateToWorld(r.getMin(), hh) + yOffset;
/*  278 */     double ywmax = valueAxis.translateToWorld(r.getMax(), hh) + yOffset;
/*  279 */     Color color = getColorSource().getColor(series, row, column);
/*  280 */     Color clipColor = color;
/*  281 */     if (getClipColorSource() != null) {
/*  282 */       Color c = getClipColorSource().getColor(series, row, column);
/*  283 */       if (c != null) {
/*  284 */         clipColor = c;
/*      */       }
/*      */     } 
/*  287 */     KeyedValues3DItemKey itemKey = new KeyedValues3DItemKey(seriesKey, rowKey, columnKey);
/*      */     
/*  289 */     if (createLeftSegment) {
/*  290 */       Comparable<?> prevColumnKey = dataset.getColumnKey(column - 1);
/*  291 */       double prevColumnValue = columnAxis.getCategoryValue(prevColumnKey);
/*  292 */       double prevColumnX = columnAxis.translateToWorld(prevColumnValue, ww) + xOffset;
/*      */       
/*  294 */       double xl = (prevColumnX + xw) / 2.0D;
/*  295 */       double yprevw = valueAxis.translateToWorld(yprev.doubleValue(), hh) + yOffset;
/*      */       
/*  297 */       double yl = (yprevw + yw) / 2.0D;
/*  298 */       Object3D left = createSegment(xl, yl, xw, yw, zw, this.lineWidth, this.lineHeight, ywmin, ywmax, color, clipColor, leftOpen, leftClose);
/*      */ 
/*      */       
/*  301 */       if (left != null) {
/*  302 */         left.setProperty("key", itemKey);
/*  303 */         world.add(left);
/*      */       } 
/*      */     } 
/*  306 */     if (createRightSegment) {
/*  307 */       Comparable<?> nextColumnKey = dataset.getColumnKey(column + 1);
/*  308 */       double nextColumnValue = columnAxis.getCategoryValue(nextColumnKey);
/*  309 */       double nextColumnX = columnAxis.translateToWorld(nextColumnValue, ww) + xOffset;
/*      */       
/*  311 */       double xr = (nextColumnX + xw) / 2.0D;
/*  312 */       double ynextw = valueAxis.translateToWorld(ynext.doubleValue(), hh) + yOffset;
/*      */       
/*  314 */       double yr = (ynextw + yw) / 2.0D;
/*  315 */       Object3D right = createSegment(xw, yw, xr, yr, zw, this.lineWidth, this.lineHeight, ywmin, ywmax, color, clipColor, rightOpen, rightClose);
/*      */ 
/*      */       
/*  318 */       if (right != null) {
/*  319 */         right.setProperty("key", itemKey);
/*  320 */         world.add(right);
/*      */       } 
/*      */     } 
/*  323 */     if (createIsolatedSegment) {
/*  324 */       double cw = columnAxis.getCategoryWidth() * this.isolatedItemWidthPercent;
/*      */       
/*  326 */       double cww = columnAxis.translateToWorld(cw, ww);
/*  327 */       Object3D isolated = Object3D.createBox(xw, cww, yw, this.lineHeight, zw, this.lineWidth, color);
/*      */       
/*  329 */       if (isolated != null) {
/*  330 */         isolated.setProperty("key", itemKey);
/*  331 */         world.add(isolated);
/*      */       } 
/*      */     } 
/*      */     
/*  335 */     if (getItemLabelGenerator() != null && !Double.isNaN(yw) && yw >= ywmin && yw <= ywmax) {
/*      */       
/*  337 */       String label = getItemLabelGenerator().generateItemLabel(dataset, seriesKey, rowKey, columnKey);
/*      */       
/*  339 */       if (label != null) {
/*  340 */         ItemLabelPositioning positioning = getItemLabelPositioning();
/*  341 */         Offset3D offsets = getItemLabelOffsets();
/*  342 */         double dy = offsets.getDY() * dimensions.getHeight();
/*  343 */         if (positioning.equals(ItemLabelPositioning.CENTRAL)) {
/*  344 */           Object3D labelObj = Object3D.createLabelObject(label, 
/*  345 */               getItemLabelFont(), getItemLabelColor(), 
/*  346 */               getItemLabelBackgroundColor(), xw, yw + dy, zw, false, true);
/*      */           
/*  348 */           labelObj.setProperty("key", itemKey);
/*  349 */           world.add(labelObj);
/*  350 */         } else if (positioning.equals(ItemLabelPositioning.FRONT_AND_BACK)) {
/*      */           
/*  352 */           double dz = this.lineWidth;
/*  353 */           Object3D labelObj1 = Object3D.createLabelObject(label, 
/*  354 */               getItemLabelFont(), getItemLabelColor(), 
/*  355 */               getItemLabelBackgroundColor(), xw, yw, zw - dz, false, false);
/*      */           
/*  357 */           labelObj1.setProperty("key", itemKey);
/*  358 */           world.add(labelObj1);
/*  359 */           Object3D labelObj2 = Object3D.createLabelObject(label, 
/*  360 */               getItemLabelFont(), getItemLabelColor(), 
/*  361 */               getItemLabelBackgroundColor(), xw, yw, zw + dz, true, false);
/*      */           
/*  363 */           labelObj2.setProperty("key", itemKey);
/*  364 */           world.add(labelObj2);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Object3D createSegment(double x0, double y0, double x1, double y1, double z, double lineWidth, double lineHeight, double ymin, double ymax, Color color, Color clipColor, boolean openingFace, boolean closingFace) {
/*  397 */     double wdelta = lineWidth / 2.0D;
/*  398 */     double hdelta = lineHeight / 2.0D;
/*  399 */     double y0b = y0 - hdelta;
/*  400 */     double y0t = y0 + hdelta;
/*  401 */     double y1b = y1 - hdelta;
/*  402 */     double y1t = y1 + hdelta;
/*  403 */     double zf = z - wdelta;
/*  404 */     double zb = z + wdelta;
/*  405 */     double[] xpts = calcCrossPoints(x0, x1, y0b, y0t, y1b, y1t, ymin, ymax);
/*  406 */     Object3D seg = null;
/*  407 */     if (y0b >= ymax) {
/*  408 */       seg = createSegmentA(x0, x1, xpts, y0b, y0t, y1b, y1t, ymin, ymax, zf, zb, color, clipColor, false, closingFace);
/*      */     }
/*  410 */     else if (y0t > ymax && y0b > ymin) {
/*  411 */       seg = createSegmentB(x0, x1, xpts, y0b, y0t, y1b, y1t, ymin, ymax, zf, zb, color, clipColor, openingFace, closingFace);
/*      */     }
/*  413 */     else if (y0t > ymax && y0b <= ymin) {
/*  414 */       seg = createSegmentC(x0, x1, xpts, y0b, y0t, y1b, y1t, ymin, ymax, zf, zb, color, clipColor, openingFace, closingFace);
/*      */     }
/*  416 */     else if (y0t > ymin && y0b >= ymin) {
/*  417 */       seg = createSegmentD(x0, x1, xpts, y0b, y0t, y1b, y1t, ymin, ymax, zf, zb, color, clipColor, openingFace, closingFace);
/*      */     }
/*  419 */     else if (y0t > ymin && y0b < ymin) {
/*  420 */       seg = createSegmentE(x0, x1, xpts, y0b, y0t, y1b, y1t, ymin, ymax, zf, zb, color, clipColor, openingFace, closingFace);
/*      */     }
/*  422 */     else if (y0t <= ymin) {
/*  423 */       seg = createSegmentF(x0, x1, xpts, y0b, y0t, y1b, y1t, ymin, ymax, zf, zb, color, clipColor, false, closingFace);
/*      */     } 
/*      */     
/*  426 */     return seg;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private double[] calcCrossPoints(double x0, double x1, double y0b, double y0t, double y1b, double y1t, double ymin, double ymax) {
/*  447 */     double[] xpts = { Double.NaN, Double.NaN, Double.NaN, Double.NaN };
/*      */     
/*  449 */     double factor = (y0b - ymin) / (y0b - y1b);
/*  450 */     xpts[0] = x0 + factor * (x1 - x0);
/*  451 */     factor = (y0t - ymin) / (y0t - y1t);
/*  452 */     xpts[1] = x0 + factor * (x1 - x0);
/*  453 */     factor = (y0b - ymax) / (y0b - y1b);
/*  454 */     xpts[2] = x0 + factor * (x1 - x0);
/*  455 */     factor = (y0t - ymax) / (y0t - y1t);
/*  456 */     xpts[3] = x0 + factor * (x1 - x0);
/*  457 */     return xpts;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Object3D createSegmentA(double x0, double x1, double[] xpts, double y0b, double y0t, double y1b, double y1t, double wmin, double wmax, double zf, double zb, Color color, Color clipColor, boolean openingFace, boolean closingFace) {
/*  488 */     if (y1b > wmax) {
/*  489 */       return null;
/*      */     }
/*  491 */     if (y1t > wmax) {
/*  492 */       if (y1b >= wmin) {
/*      */         
/*  494 */         Object3D object3D1 = new Object3D(color, true);
/*  495 */         object3D1.setProperty("color/clip", clipColor);
/*  496 */         object3D1.addVertex(xpts[2], wmax, zf);
/*  497 */         object3D1.addVertex(xpts[2], wmax, zb);
/*  498 */         object3D1.addVertex(x1, wmax, zf);
/*  499 */         object3D1.addVertex(x1, wmax, zb);
/*  500 */         object3D1.addVertex(x1, y1b, zf);
/*  501 */         object3D1.addVertex(x1, y1b, zb);
/*  502 */         object3D1.addFace(new int[] { 0, 2, 4 });
/*  503 */         object3D1.addFace(new int[] { 1, 5, 3 });
/*  504 */         object3D1.addFace(new int[] { 0, 1, 3, 2 }, "clip");
/*  505 */         object3D1.addFace(new int[] { 4, 5, 1, 0 });
/*  506 */         if (closingFace) {
/*  507 */           object3D1.addFace(new int[] { 2, 3, 5, 4 });
/*      */         }
/*  509 */         return object3D1;
/*      */       } 
/*  511 */       Object3D object3D = new Object3D(color, true);
/*  512 */       object3D.setProperty("color/clip", clipColor);
/*  513 */       object3D.addVertex(xpts[2], wmax, zf);
/*  514 */       object3D.addVertex(xpts[2], wmax, zb);
/*  515 */       object3D.addVertex(x1, wmax, zf);
/*  516 */       object3D.addVertex(x1, wmax, zb);
/*  517 */       object3D.addVertex(x1, wmin, zf);
/*  518 */       object3D.addVertex(x1, wmin, zb);
/*  519 */       object3D.addVertex(xpts[0], wmin, zf);
/*  520 */       object3D.addVertex(xpts[0], wmin, zb);
/*  521 */       object3D.addFace(new int[] { 0, 2, 4, 6 });
/*  522 */       object3D.addFace(new int[] { 1, 7, 5, 3 });
/*  523 */       object3D.addFace(new int[] { 0, 1, 3, 2 });
/*  524 */       object3D.addFace(new int[] { 4, 5, 7, 6 }, "clip");
/*  525 */       object3D.addFace(new int[] { 6, 7, 1, 0 });
/*  526 */       if (closingFace) {
/*  527 */         object3D.addFace(new int[] { 2, 3, 5, 4 });
/*      */       }
/*  529 */       return object3D;
/*      */     } 
/*  531 */     if (y1t >= wmin) {
/*  532 */       if (y1b >= wmin) {
/*  533 */         Object3D object3D1 = new Object3D(color, true);
/*  534 */         object3D1.setProperty("color/clip", clipColor);
/*  535 */         object3D1.addVertex(xpts[2], wmax, zf);
/*  536 */         object3D1.addVertex(xpts[2], wmax, zb);
/*  537 */         object3D1.addVertex(xpts[3], wmax, zf);
/*  538 */         object3D1.addVertex(xpts[3], wmax, zb);
/*  539 */         object3D1.addVertex(x1, y1t, zf);
/*  540 */         object3D1.addVertex(x1, y1t, zb);
/*  541 */         object3D1.addVertex(x1, y1b, zf);
/*  542 */         object3D1.addVertex(x1, y1b, zb);
/*  543 */         object3D1.addFace(new int[] { 0, 2, 4, 6 });
/*  544 */         object3D1.addFace(new int[] { 1, 7, 5, 3 });
/*  545 */         object3D1.addFace(new int[] { 0, 1, 3, 2 }, "clip");
/*  546 */         object3D1.addFace(new int[] { 2, 3, 5, 4 });
/*  547 */         object3D1.addFace(new int[] { 6, 7, 1, 0 });
/*  548 */         if (closingFace) {
/*  549 */           object3D1.addFace(new int[] { 4, 5, 7, 6 });
/*      */         }
/*  551 */         return object3D1;
/*      */       } 
/*  553 */       Object3D object3D = new Object3D(color, true);
/*  554 */       object3D.setProperty("color/clip", clipColor);
/*  555 */       object3D.addVertex(xpts[2], wmax, zf);
/*  556 */       object3D.addVertex(xpts[2], wmax, zb);
/*  557 */       object3D.addVertex(xpts[3], wmax, zf);
/*  558 */       object3D.addVertex(xpts[3], wmax, zb);
/*  559 */       object3D.addVertex(x1, y1t, zf);
/*  560 */       object3D.addVertex(x1, y1t, zb);
/*  561 */       object3D.addVertex(x1, wmin, zf);
/*  562 */       object3D.addVertex(x1, wmin, zb);
/*  563 */       object3D.addVertex(xpts[0], wmin, zf);
/*  564 */       object3D.addVertex(xpts[0], wmin, zb);
/*  565 */       object3D.addFace(new int[] { 0, 2, 4, 6, 8 });
/*  566 */       object3D.addFace(new int[] { 1, 9, 7, 5, 3 });
/*  567 */       object3D.addFace(new int[] { 2, 3, 5, 4 });
/*  568 */       object3D.addFace(new int[] { 0, 1, 3, 2 }, "clip");
/*  569 */       object3D.addFace(new int[] { 6, 7, 9, 8 }, "clip");
/*  570 */       object3D.addFace(new int[] { 8, 9, 1, 0 });
/*      */       
/*  572 */       if (closingFace) {
/*  573 */         object3D.addFace(new int[] { 4, 5, 7, 6 });
/*      */       }
/*  575 */       return object3D;
/*      */     } 
/*      */     
/*  578 */     Object3D seg = new Object3D(color, true);
/*  579 */     seg.setProperty("color/clip", clipColor);
/*  580 */     seg.addVertex(xpts[2], wmax, zf);
/*  581 */     seg.addVertex(xpts[2], wmax, zb);
/*  582 */     seg.addVertex(xpts[3], wmax, zf);
/*  583 */     seg.addVertex(xpts[3], wmax, zb);
/*  584 */     seg.addVertex(xpts[1], wmin, zf);
/*  585 */     seg.addVertex(xpts[1], wmin, zb);
/*  586 */     seg.addVertex(xpts[0], wmin, zf);
/*  587 */     seg.addVertex(xpts[0], wmin, zb);
/*  588 */     seg.addFace(new int[] { 0, 2, 4, 6 });
/*  589 */     seg.addFace(new int[] { 1, 7, 5, 3 });
/*  590 */     seg.addFace(new int[] { 4, 2, 3, 5 });
/*  591 */     seg.addFace(new int[] { 0, 6, 7, 1 });
/*  592 */     seg.addFace(new int[] { 0, 1, 3, 2 }, "clip");
/*  593 */     seg.addFace(new int[] { 4, 5, 7, 6 }, "clip");
/*      */     
/*  595 */     return seg;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Object3D createSegmentB(double x0, double x1, double[] xpts, double y0b, double y0t, double y1b, double y1t, double wmin, double wmax, double zf, double zb, Color color, Color clipColor, boolean openingFace, boolean closingFace) {
/*  626 */     if (y1b >= wmax) {
/*  627 */       Object3D object3D = new Object3D(color, true);
/*  628 */       object3D.setProperty("color/clip", clipColor);
/*  629 */       object3D.addVertex(x0, y0b, zf);
/*  630 */       object3D.addVertex(x0, y0b, zb);
/*  631 */       object3D.addVertex(x0, wmax, zf);
/*  632 */       object3D.addVertex(x0, wmax, zb);
/*  633 */       object3D.addVertex(xpts[2], wmax, zf);
/*  634 */       object3D.addVertex(xpts[2], wmax, zb);
/*  635 */       object3D.addFace(new int[] { 0, 2, 4 });
/*  636 */       object3D.addFace(new int[] { 1, 5, 3 });
/*  637 */       object3D.addFace(new int[] { 0, 4, 5, 1 });
/*  638 */       object3D.addFace(new int[] { 2, 3, 5, 4 }, "clip");
/*  639 */       if (openingFace) {
/*  640 */         object3D.addFace(new int[] { 0, 1, 3, 2 });
/*      */       }
/*      */       
/*  643 */       return object3D;
/*      */     } 
/*  645 */     if (y1t > wmax) {
/*  646 */       if (y1b >= wmin) {
/*  647 */         Object3D object3D1 = new Object3D(color, true);
/*  648 */         object3D1.setProperty("color/clip", clipColor);
/*  649 */         object3D1.addVertex(x0, y0b, zf);
/*  650 */         object3D1.addVertex(x0, y0b, zb);
/*  651 */         object3D1.addVertex(x0, wmax, zf);
/*  652 */         object3D1.addVertex(x0, wmax, zb);
/*  653 */         object3D1.addVertex(x1, wmax, zf);
/*  654 */         object3D1.addVertex(x1, wmax, zb);
/*  655 */         object3D1.addVertex(x1, y1b, zf);
/*  656 */         object3D1.addVertex(x1, y1b, zb);
/*  657 */         object3D1.addFace(new int[] { 0, 2, 4, 6 });
/*  658 */         object3D1.addFace(new int[] { 1, 7, 5, 3 });
/*  659 */         object3D1.addFace(new int[] { 2, 3, 5, 4 }, "clip");
/*  660 */         object3D1.addFace(new int[] { 0, 6, 7, 1 });
/*  661 */         if (openingFace) {
/*  662 */           object3D1.addFace(new int[] { 0, 1, 3, 2 });
/*      */         }
/*  664 */         if (closingFace) {
/*  665 */           object3D1.addFace(new int[] { 4, 5, 7, 6 });
/*      */         }
/*  667 */         return object3D1;
/*      */       } 
/*  669 */       Object3D object3D = new Object3D(color, true);
/*  670 */       object3D.setProperty("color/clip", clipColor);
/*  671 */       object3D.addVertex(x0, y0b, zf);
/*  672 */       object3D.addVertex(x0, y0b, zb);
/*  673 */       object3D.addVertex(x0, wmax, zf);
/*  674 */       object3D.addVertex(x0, wmax, zb);
/*  675 */       object3D.addVertex(x1, wmax, zf);
/*  676 */       object3D.addVertex(x1, wmax, zb);
/*  677 */       object3D.addVertex(x1, wmin, zf);
/*  678 */       object3D.addVertex(x1, wmin, zb);
/*  679 */       object3D.addVertex(xpts[0], wmin, zf);
/*  680 */       object3D.addVertex(xpts[0], wmin, zb);
/*  681 */       object3D.addFace(new int[] { 0, 2, 4, 6, 8 });
/*  682 */       object3D.addFace(new int[] { 1, 9, 7, 5, 3 });
/*  683 */       object3D.addFace(new int[] { 2, 3, 5, 4 }, "clip");
/*  684 */       object3D.addFace(new int[] { 8, 6, 7, 9 }, "clip");
/*  685 */       object3D.addFace(new int[] { 0, 8, 9, 1 });
/*  686 */       if (openingFace) {
/*  687 */         object3D.addFace(new int[] { 0, 1, 3, 2 });
/*      */       }
/*  689 */       if (closingFace) {
/*  690 */         object3D.addFace(new int[] { 4, 5, 7, 6 });
/*      */       }
/*  692 */       return object3D;
/*      */     } 
/*      */     
/*  695 */     if (y1t > wmin) {
/*  696 */       if (y1b >= wmin) {
/*  697 */         Object3D object3D1 = new Object3D(color, true);
/*  698 */         object3D1.setProperty("color/clip", clipColor);
/*  699 */         object3D1.addVertex(x0, y0b, zf);
/*  700 */         object3D1.addVertex(x0, y0b, zb);
/*  701 */         object3D1.addVertex(x0, wmax, zf);
/*  702 */         object3D1.addVertex(x0, wmax, zb);
/*  703 */         object3D1.addVertex(xpts[3], wmax, zf);
/*  704 */         object3D1.addVertex(xpts[3], wmax, zb);
/*  705 */         object3D1.addVertex(x1, y1t, zf);
/*  706 */         object3D1.addVertex(x1, y1t, zb);
/*  707 */         object3D1.addVertex(x1, y1b, zf);
/*  708 */         object3D1.addVertex(x1, y1b, zb);
/*  709 */         object3D1.addFace(new int[] { 0, 2, 4, 6, 8 });
/*  710 */         object3D1.addFace(new int[] { 1, 9, 7, 5, 3 });
/*  711 */         object3D1.addFace(new int[] { 2, 3, 5, 4 }, "clip");
/*  712 */         object3D1.addFace(new int[] { 4, 5, 7, 6 });
/*  713 */         object3D1.addFace(new int[] { 0, 8, 9, 1 });
/*  714 */         if (openingFace) {
/*  715 */           object3D1.addFace(new int[] { 0, 1, 3, 2 });
/*      */         }
/*  717 */         if (closingFace) {
/*  718 */           object3D1.addFace(new int[] { 6, 7, 9, 8 });
/*      */         }
/*  720 */         return object3D1;
/*      */       } 
/*  722 */       Object3D object3D = new Object3D(color, true);
/*  723 */       object3D.setProperty("color/clip", clipColor);
/*  724 */       object3D.addVertex(x0, y0b, zf);
/*  725 */       object3D.addVertex(x0, y0b, zb);
/*  726 */       object3D.addVertex(x0, wmax, zf);
/*  727 */       object3D.addVertex(x0, wmax, zb);
/*  728 */       object3D.addVertex(xpts[3], wmax, zf);
/*  729 */       object3D.addVertex(xpts[3], wmax, zb);
/*  730 */       object3D.addVertex(x1, y1t, zf);
/*  731 */       object3D.addVertex(x1, y1t, zb);
/*  732 */       object3D.addVertex(x1, wmin, zf);
/*  733 */       object3D.addVertex(x1, wmin, zb);
/*  734 */       object3D.addVertex(xpts[0], wmin, zf);
/*  735 */       object3D.addVertex(xpts[0], wmin, zb);
/*  736 */       object3D.addFace(new int[] { 0, 2, 4, 6, 8, 10 });
/*  737 */       object3D.addFace(new int[] { 1, 11, 9, 7, 5, 3 });
/*  738 */       object3D.addFace(new int[] { 2, 3, 5, 4 }, "clip");
/*  739 */       object3D.addFace(new int[] { 4, 5, 7, 6 });
/*  740 */       object3D.addFace(new int[] { 8, 9, 11, 10 }, "clip");
/*  741 */       object3D.addFace(new int[] { 10, 11, 1, 0 });
/*  742 */       if (openingFace) {
/*  743 */         object3D.addFace(new int[] { 0, 1, 3, 2 });
/*      */       }
/*  745 */       if (closingFace) {
/*  746 */         object3D.addFace(new int[] { 6, 7, 9, 8 });
/*      */       }
/*  748 */       return object3D;
/*      */     } 
/*      */     
/*  751 */     Object3D seg = new Object3D(color, true);
/*  752 */     seg.setProperty("color/clip", clipColor);
/*  753 */     seg.addVertex(x0, y0b, zf);
/*  754 */     seg.addVertex(x0, y0b, zb);
/*  755 */     seg.addVertex(x0, wmax, zf);
/*  756 */     seg.addVertex(x0, wmax, zb);
/*  757 */     seg.addVertex(xpts[3], wmax, zf);
/*  758 */     seg.addVertex(xpts[3], wmax, zb);
/*  759 */     seg.addVertex(xpts[1], wmin, zf);
/*  760 */     seg.addVertex(xpts[1], wmin, zb);
/*  761 */     seg.addVertex(xpts[0], wmin, zf);
/*  762 */     seg.addVertex(xpts[0], wmin, zb);
/*  763 */     seg.addFace(new int[] { 0, 2, 4, 6, 8 });
/*  764 */     seg.addFace(new int[] { 1, 9, 7, 5, 3 });
/*  765 */     seg.addFace(new int[] { 2, 3, 5, 4 }, "clip");
/*  766 */     seg.addFace(new int[] { 4, 5, 7, 6 });
/*  767 */     seg.addFace(new int[] { 6, 7, 9, 8 }, "clip");
/*  768 */     seg.addFace(new int[] { 8, 9, 1, 0 });
/*  769 */     if (openingFace) {
/*  770 */       seg.addFace(new int[] { 0, 1, 3, 2 });
/*      */     }
/*      */     
/*  773 */     return seg;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Object3D createSegmentC(double x0, double x1, double[] xpts, double y0b, double y0t, double y1b, double y1t, double wmin, double wmax, double zf, double zb, Color color, Color clipColor, boolean openingFace, boolean closingFace) {
/*  805 */     Object3D seg = new Object3D(color, true);
/*  806 */     seg.setProperty("color/clip", clipColor);
/*  807 */     seg.addVertex(x0, wmin, zf);
/*  808 */     seg.addVertex(x0, wmin, zb);
/*  809 */     seg.addVertex(x0, wmax, zf);
/*  810 */     seg.addVertex(x0, wmax, zb);
/*  811 */     if (openingFace) {
/*  812 */       seg.addFace(new int[] { 0, 1, 3, 2 });
/*      */     }
/*      */     
/*  815 */     if (y1b >= wmax) {
/*  816 */       seg.addVertex(xpts[2], wmax, zf);
/*  817 */       seg.addVertex(xpts[2], wmax, zb);
/*  818 */       seg.addVertex(xpts[0], wmin, zf);
/*  819 */       seg.addVertex(xpts[0], wmin, zb);
/*  820 */       seg.addFace(new int[] { 0, 2, 4, 6 });
/*  821 */       seg.addFace(new int[] { 1, 7, 5, 3 });
/*  822 */       seg.addFace(new int[] { 2, 3, 5, 4 }, "clip");
/*  823 */       seg.addFace(new int[] { 4, 5, 7, 6 });
/*  824 */       seg.addFace(new int[] { 7, 1, 0, 6 }, "clip");
/*  825 */       return seg;
/*      */     } 
/*  827 */     if (y1t > wmax) {
/*  828 */       if (y1b >= wmin) {
/*  829 */         seg.addVertex(x1, wmax, zf);
/*  830 */         seg.addVertex(x1, wmax, zb);
/*  831 */         seg.addVertex(x1, y1b, zf);
/*  832 */         seg.addVertex(x1, y1b, zb);
/*  833 */         seg.addVertex(xpts[0], wmin, zf);
/*  834 */         seg.addVertex(xpts[0], wmin, zb);
/*  835 */         seg.addFace(new int[] { 0, 2, 4, 6, 8 });
/*  836 */         seg.addFace(new int[] { 1, 9, 7, 5, 3 });
/*  837 */         seg.addFace(new int[] { 2, 3, 5, 4 }, "clip");
/*  838 */         seg.addFace(new int[] { 6, 7, 9, 8 });
/*  839 */         seg.addFace(new int[] { 8, 9, 1, 0 }, "clip");
/*  840 */         if (closingFace) {
/*  841 */           seg.addFace(new int[] { 4, 5, 7, 6 });
/*      */         }
/*  843 */         return seg;
/*      */       } 
/*  845 */       seg.addVertex(x1, wmax, zf);
/*  846 */       seg.addVertex(x1, wmax, zb);
/*  847 */       seg.addVertex(x1, wmin, zf);
/*  848 */       seg.addVertex(x1, wmin, zb);
/*  849 */       seg.addFace(new int[] { 0, 2, 4, 6 });
/*  850 */       seg.addFace(new int[] { 1, 7, 5, 3 });
/*  851 */       seg.addFace(new int[] { 2, 3, 5, 4 }, "clip");
/*  852 */       seg.addFace(new int[] { 4, 5, 7, 6 });
/*  853 */       seg.addFace(new int[] { 7, 1, 0, 6 }, "clip");
/*  854 */       return seg;
/*      */     } 
/*      */     
/*  857 */     if (y1t > wmin) {
/*  858 */       if (y1b >= wmin) {
/*  859 */         return null;
/*      */       }
/*      */       
/*  862 */       seg.addVertex(xpts[3], wmax, zf);
/*  863 */       seg.addVertex(xpts[3], wmax, zb);
/*  864 */       seg.addVertex(x1, y1t, zf);
/*  865 */       seg.addVertex(x1, y1t, zb);
/*  866 */       seg.addVertex(x1, wmin, zf);
/*  867 */       seg.addVertex(x1, wmin, zb);
/*  868 */       seg.addFace(new int[] { 0, 2, 4, 6, 8 });
/*  869 */       seg.addFace(new int[] { 1, 9, 7, 5, 3 });
/*  870 */       seg.addFace(new int[] { 2, 3, 5, 4 }, "clip");
/*  871 */       seg.addFace(new int[] { 4, 5, 7, 6 });
/*  872 */       seg.addFace(new int[] { 9, 1, 0, 8 }, "clip");
/*  873 */       if (closingFace) {
/*  874 */         seg.addFace(new int[] { 6, 7, 9, 8 });
/*      */       }
/*  876 */       return seg;
/*      */     } 
/*      */     
/*  879 */     seg.addVertex(xpts[3], wmax, zf);
/*  880 */     seg.addVertex(xpts[3], wmax, zb);
/*  881 */     seg.addVertex(xpts[1], wmin, zf);
/*  882 */     seg.addVertex(xpts[1], wmin, zb);
/*  883 */     seg.addFace(new int[] { 0, 2, 4, 6 });
/*  884 */     seg.addFace(new int[] { 1, 7, 5, 3 });
/*  885 */     seg.addFace(new int[] { 2, 3, 5, 4 }, "clip");
/*  886 */     seg.addFace(new int[] { 4, 5, 7, 6 });
/*  887 */     seg.addFace(new int[] { 6, 7, 1, 0 }, "clip");
/*  888 */     return seg;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Object3D createSegmentD(double x0, double x1, double[] xpts, double y0b, double y0t, double y1b, double y1t, double wmin, double wmax, double zf, double zb, Color color, Color clipColor, boolean openingFace, boolean closingFace) {
/*  918 */     Object3D seg = new Object3D(color, true);
/*  919 */     seg.setProperty("color/clip", clipColor);
/*  920 */     seg.addVertex(x0, y0b, zf);
/*  921 */     seg.addVertex(x0, y0b, zb);
/*  922 */     seg.addVertex(x0, y0t, zf);
/*  923 */     seg.addVertex(x0, y0t, zb);
/*  924 */     if (y1b >= wmax) {
/*  925 */       seg.addVertex(xpts[3], wmax, zf);
/*  926 */       seg.addVertex(xpts[3], wmax, zb);
/*  927 */       seg.addVertex(xpts[2], wmax, zf);
/*  928 */       seg.addVertex(xpts[2], wmax, zb);
/*  929 */       seg.addFace(new int[] { 0, 2, 4, 6 });
/*  930 */       seg.addFace(new int[] { 1, 7, 5, 3 });
/*  931 */       seg.addFace(new int[] { 2, 3, 5, 4 });
/*  932 */       seg.addFace(new int[] { 4, 5, 7, 6 }, "clip");
/*  933 */       seg.addFace(new int[] { 0, 6, 7, 1 });
/*  934 */       if (openingFace) {
/*  935 */         seg.addFace(new int[] { 0, 1, 3, 2 });
/*      */       }
/*      */       
/*  938 */       return seg;
/*      */     } 
/*  940 */     if (y1t > wmax) {
/*  941 */       if (y1b >= wmin) {
/*  942 */         seg.addVertex(xpts[3], wmax, zf);
/*  943 */         seg.addVertex(xpts[3], wmax, zb);
/*  944 */         seg.addVertex(x1, wmax, zf);
/*  945 */         seg.addVertex(x1, wmax, zb);
/*  946 */         seg.addVertex(x1, y1b, zf);
/*  947 */         seg.addVertex(x1, y1b, zb);
/*  948 */         seg.addFace(new int[] { 0, 2, 4, 6, 8 });
/*  949 */         seg.addFace(new int[] { 1, 9, 7, 5, 3 });
/*  950 */         seg.addFace(new int[] { 2, 3, 5, 4 });
/*  951 */         seg.addFace(new int[] { 4, 5, 7, 6 }, "clip");
/*  952 */         seg.addFace(new int[] { 0, 8, 9, 1 });
/*  953 */         if (openingFace) {
/*  954 */           seg.addFace(new int[] { 0, 1, 3, 2 });
/*      */         }
/*  956 */         if (closingFace) {
/*  957 */           seg.addFace(new int[] { 6, 7, 9, 8 });
/*      */         }
/*  959 */         return seg;
/*      */       } 
/*  961 */       return null;
/*      */     } 
/*      */     
/*  964 */     if (y1t > wmin) {
/*  965 */       if (y1b >= wmin) {
/*      */         
/*  967 */         seg.addVertex(x1, y1t, zf);
/*  968 */         seg.addVertex(x1, y1t, zb);
/*  969 */         seg.addVertex(x1, y1b, zf);
/*  970 */         seg.addVertex(x1, y1b, zb);
/*  971 */         seg.addFace(new int[] { 0, 2, 4, 6 });
/*  972 */         seg.addFace(new int[] { 1, 7, 5, 3 });
/*  973 */         seg.addFace(new int[] { 2, 3, 5, 4 });
/*  974 */         seg.addFace(new int[] { 0, 6, 7, 1 });
/*  975 */         if (openingFace) {
/*  976 */           seg.addFace(new int[] { 0, 1, 3, 2 });
/*      */         }
/*  978 */         if (closingFace) {
/*  979 */           seg.addFace(new int[] { 4, 5, 7, 6 });
/*      */         }
/*  981 */         return seg;
/*      */       } 
/*  983 */       seg.addVertex(x1, y1t, zf);
/*  984 */       seg.addVertex(x1, y1t, zb);
/*  985 */       seg.addVertex(x1, wmin, zf);
/*  986 */       seg.addVertex(x1, wmin, zb);
/*  987 */       seg.addVertex(xpts[0], wmin, zf);
/*  988 */       seg.addVertex(xpts[0], wmin, zb);
/*  989 */       seg.addFace(new int[] { 0, 2, 4, 6, 8 });
/*  990 */       seg.addFace(new int[] { 1, 9, 7, 5, 3 });
/*  991 */       seg.addFace(new int[] { 2, 3, 5, 4 });
/*  992 */       seg.addFace(new int[] { 0, 8, 9, 1 });
/*  993 */       seg.addFace(new int[] { 6, 7, 9, 8 }, "clip");
/*  994 */       if (openingFace) {
/*  995 */         seg.addFace(new int[] { 0, 1, 3, 2 });
/*      */       }
/*  997 */       if (closingFace) {
/*  998 */         seg.addFace(new int[] { 4, 5, 7, 6 });
/*      */       }
/* 1000 */       return seg;
/*      */     } 
/*      */     
/* 1003 */     seg.addVertex(xpts[1], wmin, zf);
/* 1004 */     seg.addVertex(xpts[1], wmin, zb);
/* 1005 */     seg.addVertex(xpts[0], wmin, zf);
/* 1006 */     seg.addVertex(xpts[0], wmin, zb);
/* 1007 */     seg.addFace(new int[] { 0, 2, 4, 6 });
/* 1008 */     seg.addFace(new int[] { 1, 7, 5, 3 });
/* 1009 */     seg.addFace(new int[] { 2, 3, 5, 4 });
/* 1010 */     seg.addFace(new int[] { 0, 6, 7, 1 });
/* 1011 */     seg.addFace(new int[] { 4, 5, 7, 6 }, "clip");
/* 1012 */     if (openingFace) {
/* 1013 */       seg.addFace(new int[] { 0, 1, 3, 2 });
/*      */     }
/*      */     
/* 1016 */     return seg;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Object3D createSegmentE(double x0, double x1, double[] xpts, double y0b, double y0t, double y1b, double y1t, double wmin, double wmax, double zf, double zb, Color color, Color clipColor, boolean openingFace, boolean closingFace) {
/* 1046 */     if (y1b > wmax) {
/* 1047 */       Object3D object3D = new Object3D(color, true);
/* 1048 */       object3D.setProperty("color/clip", clipColor);
/* 1049 */       object3D.addVertex(x0, wmin, zf);
/* 1050 */       object3D.addVertex(x0, wmin, zb);
/* 1051 */       object3D.addVertex(x0, y0t, zf);
/* 1052 */       object3D.addVertex(x0, y0t, zb);
/* 1053 */       object3D.addVertex(xpts[3], wmax, zf);
/* 1054 */       object3D.addVertex(xpts[3], wmax, zb);
/* 1055 */       object3D.addVertex(xpts[2], wmax, zf);
/* 1056 */       object3D.addVertex(xpts[2], wmax, zb);
/* 1057 */       object3D.addVertex(xpts[0], wmin, zf);
/* 1058 */       object3D.addVertex(xpts[0], wmin, zb);
/* 1059 */       object3D.addFace(new int[] { 0, 2, 4, 6, 8 });
/* 1060 */       object3D.addFace(new int[] { 1, 9, 7, 5, 3 });
/* 1061 */       object3D.addFace(new int[] { 2, 3, 5, 4 });
/* 1062 */       object3D.addFace(new int[] { 4, 5, 7, 6 }, "clip");
/* 1063 */       object3D.addFace(new int[] { 6, 7, 9, 8 });
/* 1064 */       object3D.addFace(new int[] { 0, 8, 9, 1 }, "clip");
/* 1065 */       if (openingFace) {
/* 1066 */         object3D.addFace(new int[] { 0, 1, 3, 2 });
/*      */       }
/* 1068 */       return object3D;
/*      */     } 
/* 1070 */     if (y1t > wmax) {
/* 1071 */       if (y1b >= wmin) {
/* 1072 */         Object3D object3D1 = new Object3D(color, true);
/* 1073 */         object3D1.setProperty("color/clip", clipColor);
/* 1074 */         object3D1.addVertex(x0, wmin, zf);
/* 1075 */         object3D1.addVertex(x0, wmin, zb);
/* 1076 */         object3D1.addVertex(x0, y0t, zf);
/* 1077 */         object3D1.addVertex(x0, y0t, zb);
/* 1078 */         object3D1.addVertex(xpts[3], wmax, zf);
/* 1079 */         object3D1.addVertex(xpts[3], wmax, zb);
/* 1080 */         object3D1.addVertex(x1, wmax, zf);
/* 1081 */         object3D1.addVertex(x1, wmax, zb);
/* 1082 */         object3D1.addVertex(x1, y1b, zf);
/* 1083 */         object3D1.addVertex(x1, y1b, zb);
/* 1084 */         object3D1.addVertex(xpts[0], wmin, zf);
/* 1085 */         object3D1.addVertex(xpts[0], wmin, zb);
/* 1086 */         object3D1.addFace(new int[] { 0, 2, 4, 6, 8, 10 });
/* 1087 */         object3D1.addFace(new int[] { 1, 11, 9, 7, 5, 3 });
/* 1088 */         object3D1.addFace(new int[] { 2, 3, 5, 4 });
/* 1089 */         object3D1.addFace(new int[] { 5, 7, 6, 4 }, "clip");
/* 1090 */         object3D1.addFace(new int[] { 8, 9, 11, 10 });
/* 1091 */         object3D1.addFace(new int[] { 1, 0, 10, 11 }, "clip");
/* 1092 */         if (openingFace) {
/* 1093 */           object3D1.addFace(new int[] { 0, 1, 3, 2 });
/*      */         }
/* 1095 */         if (closingFace) {
/* 1096 */           object3D1.addFace(new int[] { 6, 7, 9, 8 });
/*      */         }
/* 1098 */         return object3D1;
/*      */       } 
/* 1100 */       Object3D object3D = new Object3D(color, true);
/* 1101 */       object3D.setProperty("color/clip", clipColor);
/* 1102 */       object3D.addVertex(x0, wmin, zf);
/* 1103 */       object3D.addVertex(x0, wmin, zb);
/* 1104 */       object3D.addVertex(x0, y0t, zf);
/* 1105 */       object3D.addVertex(x0, y0t, zb);
/* 1106 */       object3D.addVertex(xpts[3], wmax, zf);
/* 1107 */       object3D.addVertex(xpts[3], wmax, zb);
/* 1108 */       object3D.addVertex(x1, wmax, zf);
/* 1109 */       object3D.addVertex(x1, wmax, zb);
/* 1110 */       object3D.addVertex(x1, wmin, zf);
/* 1111 */       object3D.addVertex(x1, wmin, zb);
/* 1112 */       object3D.addFace(new int[] { 0, 2, 4, 6, 8 });
/* 1113 */       object3D.addFace(new int[] { 1, 9, 7, 5, 3 });
/* 1114 */       object3D.addFace(new int[] { 2, 3, 5, 4 });
/* 1115 */       object3D.addFace(new int[] { 5, 7, 6, 4 }, "clip");
/* 1116 */       object3D.addFace(new int[] { 0, 8, 9, 1 }, "clip");
/* 1117 */       if (openingFace) {
/* 1118 */         object3D.addFace(new int[] { 0, 1, 3, 2 });
/*      */       }
/* 1120 */       if (closingFace) {
/* 1121 */         object3D.addFace(new int[] { 6, 7, 9, 8 });
/*      */       }
/* 1123 */       return object3D;
/*      */     } 
/*      */     
/* 1126 */     if (y1t > wmin) {
/* 1127 */       if (y1b >= wmin) {
/* 1128 */         Object3D object3D1 = new Object3D(color, true);
/* 1129 */         object3D1.setProperty("color/clip", clipColor);
/* 1130 */         object3D1.addVertex(x0, wmin, zf);
/* 1131 */         object3D1.addVertex(x0, wmin, zb);
/* 1132 */         object3D1.addVertex(x0, y0t, zf);
/* 1133 */         object3D1.addVertex(x0, y0t, zb);
/* 1134 */         object3D1.addVertex(x1, y1t, zf);
/* 1135 */         object3D1.addVertex(x1, y1t, zb);
/* 1136 */         object3D1.addVertex(x1, y1b, zf);
/* 1137 */         object3D1.addVertex(x1, y1b, zb);
/* 1138 */         object3D1.addVertex(xpts[0], wmin, zf);
/* 1139 */         object3D1.addVertex(xpts[0], wmin, zb);
/* 1140 */         object3D1.addFace(new int[] { 0, 2, 4, 6, 8 });
/* 1141 */         object3D1.addFace(new int[] { 1, 9, 7, 5, 3 });
/* 1142 */         object3D1.addFace(new int[] { 2, 3, 5, 4 });
/* 1143 */         object3D1.addFace(new int[] { 6, 7, 9, 8 });
/* 1144 */         object3D1.addFace(new int[] { 0, 8, 9, 1 }, "clip");
/* 1145 */         if (openingFace) {
/* 1146 */           object3D1.addFace(new int[] { 0, 1, 3, 2 });
/*      */         }
/* 1148 */         if (closingFace) {
/* 1149 */           object3D1.addFace(new int[] { 4, 5, 7, 6 });
/*      */         }
/* 1151 */         return object3D1;
/*      */       } 
/* 1153 */       Object3D object3D = new Object3D(color, true);
/* 1154 */       object3D.setProperty("color/clip", clipColor);
/* 1155 */       object3D.addVertex(x0, wmin, zf);
/* 1156 */       object3D.addVertex(x0, wmin, zb);
/* 1157 */       object3D.addVertex(x0, y0t, zf);
/* 1158 */       object3D.addVertex(x0, y0t, zb);
/* 1159 */       object3D.addVertex(x1, y1t, zf);
/* 1160 */       object3D.addVertex(x1, y1t, zb);
/* 1161 */       object3D.addVertex(x1, wmin, zf);
/* 1162 */       object3D.addVertex(x1, wmin, zb);
/* 1163 */       object3D.addFace(new int[] { 0, 2, 4, 6 });
/* 1164 */       object3D.addFace(new int[] { 1, 7, 5, 3 });
/* 1165 */       object3D.addFace(new int[] { 2, 3, 5, 4 });
/* 1166 */       object3D.addFace(new int[] { 0, 6, 7, 1 }, "clip");
/* 1167 */       if (openingFace) {
/* 1168 */         object3D.addFace(new int[] { 0, 1, 3, 2 });
/*      */       }
/* 1170 */       if (closingFace) {
/* 1171 */         object3D.addFace(new int[] { 4, 5, 7, 6 });
/*      */       }
/* 1173 */       return object3D;
/*      */     } 
/*      */     
/* 1176 */     Object3D seg = new Object3D(color, true);
/* 1177 */     seg.setProperty("color/clip", clipColor);
/* 1178 */     seg.addVertex(x0, wmin, zf);
/* 1179 */     seg.addVertex(x0, wmin, zb);
/* 1180 */     seg.addVertex(x0, y0t, zf);
/* 1181 */     seg.addVertex(x0, y0t, zb);
/* 1182 */     seg.addVertex(xpts[1], wmin, zf);
/* 1183 */     seg.addVertex(xpts[1], wmin, zb);
/* 1184 */     seg.addFace(new int[] { 0, 2, 4 });
/* 1185 */     seg.addFace(new int[] { 1, 5, 3 });
/* 1186 */     seg.addFace(new int[] { 2, 3, 5, 4 });
/* 1187 */     seg.addFace(new int[] { 0, 4, 5, 1 }, "clip");
/* 1188 */     if (openingFace) {
/* 1189 */       seg.addFace(new int[] { 0, 1, 3, 2 });
/*      */     }
/*      */     
/* 1192 */     return seg;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Object3D createSegmentF(double x0, double x1, double[] xpts, double y0b, double y0t, double y1b, double y1t, double wmin, double wmax, double zf, double zb, Color color, Color clipColor, boolean openingFace, boolean closingFace) {
/* 1223 */     if (y1b > wmax) {
/* 1224 */       Object3D seg = new Object3D(color, true);
/* 1225 */       seg.setProperty("color/clip", clipColor);
/* 1226 */       seg.addVertex(xpts[1], wmin, zf);
/* 1227 */       seg.addVertex(xpts[1], wmin, zb);
/* 1228 */       seg.addVertex(xpts[3], wmax, zf);
/* 1229 */       seg.addVertex(xpts[3], wmax, zb);
/* 1230 */       seg.addVertex(xpts[2], wmax, zf);
/* 1231 */       seg.addVertex(xpts[2], wmax, zb);
/* 1232 */       seg.addVertex(xpts[0], wmin, zf);
/* 1233 */       seg.addVertex(xpts[0], wmin, zb);
/* 1234 */       seg.addFace(new int[] { 0, 2, 4, 6 });
/* 1235 */       seg.addFace(new int[] { 1, 7, 5, 3 });
/* 1236 */       seg.addFace(new int[] { 0, 1, 3, 2 });
/* 1237 */       seg.addFace(new int[] { 2, 3, 5, 4 }, "clip");
/* 1238 */       seg.addFace(new int[] { 4, 5, 7, 6 });
/* 1239 */       seg.addFace(new int[] { 0, 6, 7, 1 }, "clip");
/*      */       
/* 1241 */       return seg;
/*      */     } 
/* 1243 */     if (y1t > wmax) {
/* 1244 */       if (y1b > wmin) {
/* 1245 */         Object3D object3D = new Object3D(color, true);
/* 1246 */         object3D.setProperty("color/clip", clipColor);
/* 1247 */         object3D.addVertex(xpts[1], wmin, zf);
/* 1248 */         object3D.addVertex(xpts[1], wmin, zb);
/* 1249 */         object3D.addVertex(xpts[3], wmax, zf);
/* 1250 */         object3D.addVertex(xpts[3], wmax, zb);
/* 1251 */         object3D.addVertex(x1, wmax, zf);
/* 1252 */         object3D.addVertex(x1, wmax, zb);
/* 1253 */         object3D.addVertex(x1, y1b, zf);
/* 1254 */         object3D.addVertex(x1, y1b, zb);
/* 1255 */         object3D.addVertex(xpts[0], wmin, zf);
/* 1256 */         object3D.addVertex(xpts[0], wmin, zb);
/* 1257 */         object3D.addFace(new int[] { 0, 2, 4, 6, 8 });
/* 1258 */         object3D.addFace(new int[] { 1, 9, 7, 5, 3 });
/* 1259 */         object3D.addFace(new int[] { 2, 3, 5, 4 });
/* 1260 */         object3D.addFace(new int[] { 0, 1, 3, 2 });
/* 1261 */         object3D.addFace(new int[] { 0, 8, 9, 1 }, "clip");
/* 1262 */         object3D.addFace(new int[] { 6, 7, 9, 8 });
/*      */         
/* 1264 */         if (closingFace) {
/* 1265 */           object3D.addFace(new int[] { 4, 5, 7, 6 });
/*      */         }
/* 1267 */         return object3D;
/*      */       } 
/* 1269 */       Object3D seg = new Object3D(color, true);
/* 1270 */       seg.setProperty("color/clip", clipColor);
/* 1271 */       seg.addVertex(xpts[1], wmin, zf);
/* 1272 */       seg.addVertex(xpts[1], wmin, zb);
/* 1273 */       seg.addVertex(xpts[3], wmax, zf);
/* 1274 */       seg.addVertex(xpts[3], wmax, zb);
/* 1275 */       seg.addVertex(x1, wmax, zf);
/* 1276 */       seg.addVertex(x1, wmax, zb);
/* 1277 */       seg.addVertex(x1, wmin, zf);
/* 1278 */       seg.addVertex(x1, wmin, zb);
/* 1279 */       seg.addFace(new int[] { 0, 2, 4, 6 });
/* 1280 */       seg.addFace(new int[] { 1, 7, 5, 3 });
/* 1281 */       seg.addFace(new int[] { 0, 1, 3, 2 });
/* 1282 */       seg.addFace(new int[] { 2, 3, 5, 4 }, "clip");
/* 1283 */       seg.addFace(new int[] { 6, 7, 1, 0 }, "clip");
/* 1284 */       if (closingFace) {
/* 1285 */         seg.addFace(new int[] { 4, 5, 7, 6 });
/*      */       }
/* 1287 */       return seg;
/*      */     } 
/*      */     
/* 1290 */     if (y1t > wmin) {
/* 1291 */       if (y1b >= wmin) {
/* 1292 */         Object3D object3D = new Object3D(color, true);
/* 1293 */         object3D.setProperty("color/clip", clipColor);
/* 1294 */         object3D.addVertex(xpts[1], wmin, zf);
/* 1295 */         object3D.addVertex(xpts[1], wmin, zb);
/* 1296 */         object3D.addVertex(x1, y1t, zf);
/* 1297 */         object3D.addVertex(x1, y1t, zb);
/* 1298 */         object3D.addVertex(x1, y1b, zf);
/* 1299 */         object3D.addVertex(x1, y1b, zb);
/* 1300 */         object3D.addVertex(xpts[0], wmin, zf);
/* 1301 */         object3D.addVertex(xpts[0], wmin, zb);
/* 1302 */         object3D.addFace(new int[] { 0, 2, 4, 6 });
/* 1303 */         object3D.addFace(new int[] { 1, 7, 5, 3 });
/* 1304 */         object3D.addFace(new int[] { 0, 1, 3, 2 });
/* 1305 */         object3D.addFace(new int[] { 4, 5, 7, 6 });
/* 1306 */         object3D.addFace(new int[] { 0, 6, 7, 1 }, "clip");
/* 1307 */         if (closingFace) {
/* 1308 */           object3D.addFace(new int[] { 2, 3, 5, 4 });
/*      */         }
/* 1310 */         return object3D;
/*      */       } 
/* 1312 */       Object3D seg = new Object3D(color, true);
/* 1313 */       seg.setProperty("color/clip", clipColor);
/* 1314 */       seg.addVertex(xpts[1], wmin, zf);
/* 1315 */       seg.addVertex(xpts[1], wmin, zb);
/* 1316 */       seg.addVertex(x1, y1t, zf);
/* 1317 */       seg.addVertex(x1, y1t, zb);
/* 1318 */       seg.addVertex(x1, wmin, zf);
/* 1319 */       seg.addVertex(x1, wmin, zb);
/* 1320 */       seg.addFace(new int[] { 0, 2, 4 });
/* 1321 */       seg.addFace(new int[] { 1, 5, 3 });
/* 1322 */       seg.addFace(new int[] { 0, 1, 3, 2 });
/* 1323 */       seg.addFace(new int[] { 0, 4, 5, 1 }, "clip");
/*      */       
/* 1325 */       if (closingFace) {
/* 1326 */         seg.addFace(new int[] { 2, 3, 5, 4 });
/*      */       }
/* 1328 */       return seg;
/*      */     } 
/*      */     
/* 1331 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean equals(Object obj) {
/* 1343 */     if (obj == this) {
/* 1344 */       return true;
/*      */     }
/* 1346 */     if (!(obj instanceof LineRenderer3D)) {
/* 1347 */       return false;
/*      */     }
/* 1349 */     LineRenderer3D that = (LineRenderer3D)obj;
/* 1350 */     if (this.lineWidth != that.lineWidth) {
/* 1351 */       return false;
/*      */     }
/* 1353 */     if (this.lineHeight != that.lineHeight) {
/* 1354 */       return false;
/*      */     }
/* 1356 */     if (this.isolatedItemWidthPercent != that.isolatedItemWidthPercent) {
/* 1357 */       return false;
/*      */     }
/* 1359 */     if (!ObjectUtils.equals(this.clipColorSource, that.clipColorSource)) {
/* 1360 */       return false;
/*      */     }
/* 1362 */     return super.equals(obj);
/*      */   }
/*      */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/renderer/category/LineRenderer3D.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */