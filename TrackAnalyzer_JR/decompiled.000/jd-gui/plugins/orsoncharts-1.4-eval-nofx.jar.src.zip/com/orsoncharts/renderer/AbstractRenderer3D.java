/*     */ package com.orsoncharts.renderer;
/*     */ 
/*     */ import com.orsoncharts.ChartElementVisitor;
/*     */ import com.orsoncharts.label.ItemLabelPositioning;
/*     */ import com.orsoncharts.util.ArgChecks;
/*     */ import java.awt.Color;
/*     */ import java.awt.Font;
/*     */ import java.io.Serializable;
/*     */ import javax.swing.event.EventListenerList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractRenderer3D
/*     */   implements Renderer3D, Serializable
/*     */ {
/*  55 */   private Font itemLabelFont = new Font("Serif", 0, 12);
/*  56 */   private Color itemLabelColor = Color.WHITE;
/*  57 */   private Color itemLabelBackgroundColor = new Color(100, 100, 100, 100);
/*  58 */   private ItemLabelPositioning itemLabelPositioning = ItemLabelPositioning.CENTRAL;
/*  59 */   private transient EventListenerList listenerList = new EventListenerList();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean notify = true;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Font getItemLabelFont() {
/*  72 */     return this.itemLabelFont;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setItemLabelFont(Font itemLabelFont) {
/*  84 */     ArgChecks.nullNotPermitted(itemLabelFont, "itemLabelFont");
/*  85 */     this.itemLabelFont = itemLabelFont;
/*  86 */     fireChangeEvent(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Color getItemLabelColor() {
/*  98 */     return this.itemLabelColor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setItemLabelColor(Color itemLabelColor) {
/* 110 */     ArgChecks.nullNotPermitted(itemLabelColor, "itemLabelColor");
/* 111 */     this.itemLabelColor = itemLabelColor;
/* 112 */     fireChangeEvent(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Color getItemLabelBackgroundColor() {
/* 123 */     return this.itemLabelBackgroundColor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setItemLabelBackgroundColor(Color color) {
/* 135 */     ArgChecks.nullNotPermitted(color, "color");
/* 136 */     this.itemLabelBackgroundColor = color;
/* 137 */     fireChangeEvent(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ItemLabelPositioning getItemLabelPositioning() {
/* 149 */     return this.itemLabelPositioning;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setItemLabelPositioning(ItemLabelPositioning positioning) {
/* 162 */     ArgChecks.nullNotPermitted(positioning, "positioning");
/* 163 */     this.itemLabelPositioning = positioning;
/* 164 */     fireChangeEvent(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isNotify() {
/* 176 */     return this.notify;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setNotify(boolean notify) {
/* 188 */     this.notify = notify;
/*     */     
/* 190 */     if (notify) {
/* 191 */       fireChangeEvent(true);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void receive(ChartElementVisitor visitor) {
/* 207 */     visitor.visit(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addChangeListener(Renderer3DChangeListener listener) {
/* 219 */     this.listenerList.add(Renderer3DChangeListener.class, listener);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeChangeListener(Renderer3DChangeListener listener) {
/* 231 */     this.listenerList.remove(Renderer3DChangeListener.class, listener);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void notifyListeners(Renderer3DChangeEvent event) {
/* 242 */     if (!this.notify) {
/*     */       return;
/*     */     }
/* 245 */     Object[] listeners = this.listenerList.getListenerList();
/* 246 */     for (int i = listeners.length - 2; i >= 0; i -= 2) {
/* 247 */       if (listeners[i] == Renderer3DChangeListener.class) {
/* 248 */         ((Renderer3DChangeListener)listeners[i + 1]).rendererChanged(event);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void fireChangeEvent(boolean requiresWorldUpdate) {
/* 261 */     notifyListeners(new Renderer3DChangeEvent(this, requiresWorldUpdate));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 275 */     if (obj == this) {
/* 276 */       return true;
/*     */     }
/* 278 */     if (!(obj instanceof AbstractRenderer3D)) {
/* 279 */       return false;
/*     */     }
/* 281 */     AbstractRenderer3D that = (AbstractRenderer3D)obj;
/* 282 */     if (this.notify != that.notify) {
/* 283 */       return false;
/*     */     }
/* 285 */     if (!this.itemLabelFont.equals(that.itemLabelFont)) {
/* 286 */       return false;
/*     */     }
/* 288 */     if (!this.itemLabelColor.equals(that.itemLabelColor)) {
/* 289 */       return false;
/*     */     }
/* 291 */     if (!this.itemLabelBackgroundColor.equals(that.itemLabelBackgroundColor))
/*     */     {
/* 293 */       return false;
/*     */     }
/* 295 */     if (this.itemLabelPositioning != that.itemLabelPositioning) {
/* 296 */       return false;
/*     */     }
/* 298 */     return true;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/renderer/AbstractRenderer3D.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */