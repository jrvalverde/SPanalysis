/*     */ package com.orsoncharts.renderer.xyz;
/*     */ 
/*     */ import com.orsoncharts.Range;
/*     */ import com.orsoncharts.axis.ValueAxis3D;
/*     */ import com.orsoncharts.data.function.Function3D;
/*     */ import com.orsoncharts.data.function.Function3DUtils;
/*     */ import com.orsoncharts.data.xyz.XYZDataset;
/*     */ import com.orsoncharts.graphics3d.Dimension3D;
/*     */ import com.orsoncharts.graphics3d.Object3D;
/*     */ import com.orsoncharts.graphics3d.Point3D;
/*     */ import com.orsoncharts.graphics3d.World;
/*     */ import com.orsoncharts.plot.XYZPlot;
/*     */ import com.orsoncharts.renderer.ColorScale;
/*     */ import com.orsoncharts.renderer.ColorScaleRenderer;
/*     */ import com.orsoncharts.renderer.ComposeType;
/*     */ import com.orsoncharts.renderer.FixedColorScale;
/*     */ import com.orsoncharts.util.ArgChecks;
/*     */ import java.awt.Color;
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SurfaceRenderer
/*     */   extends AbstractXYZRenderer
/*     */   implements XYZRenderer, ColorScaleRenderer, Serializable
/*     */ {
/*     */   private Function3D function;
/*     */   private int xSamples;
/*     */   private int zSamples;
/*     */   private ColorScale colorScale;
/*     */   private boolean drawFaceOutlines;
/*     */   
/*     */   public SurfaceRenderer(Function3D function) {
/*  87 */     ArgChecks.nullNotPermitted(function, "function");
/*  88 */     this.function = function;
/*  89 */     this.xSamples = 30;
/*  90 */     this.zSamples = 30;
/*  91 */     this.colorScale = (ColorScale)new FixedColorScale(Color.YELLOW);
/*  92 */     this.drawFaceOutlines = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getXSamples() {
/* 102 */     return this.xSamples;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setXSamples(int count) {
/* 117 */     this.xSamples = count;
/* 118 */     fireChangeEvent(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getZSamples() {
/* 129 */     return this.zSamples;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setZSamples(int count) {
/* 144 */     this.zSamples = count;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ComposeType getComposeType() {
/* 158 */     return ComposeType.ALL;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ColorScale getColorScale() {
/* 169 */     return this.colorScale;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setColorScale(ColorScale colorScale) {
/* 179 */     ArgChecks.nullNotPermitted(colorScale, "colorScale");
/* 180 */     this.colorScale = colorScale;
/* 181 */     fireChangeEvent(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getDrawFaceOutlines() {
/* 192 */     return this.drawFaceOutlines;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDrawFaceOutlines(boolean draw) {
/* 207 */     this.drawFaceOutlines = draw;
/* 208 */     fireChangeEvent(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void composeAll(XYZPlot plot, World world, Dimension3D dimensions, double xOffset, double yOffset, double zOffset) {
/* 227 */     ValueAxis3D xAxis = plot.getXAxis();
/* 228 */     ValueAxis3D yAxis = plot.getYAxis();
/* 229 */     ValueAxis3D zAxis = plot.getZAxis();
/* 230 */     Dimension3D dim = plot.getDimensions();
/* 231 */     double xlen = dim.getWidth();
/* 232 */     double ylen = dim.getHeight();
/* 233 */     double zlen = dim.getDepth();
/* 234 */     Range yRange = new Range(yOffset, -yOffset);
/* 235 */     for (int xIndex = 0; xIndex < this.xSamples; xIndex++) {
/* 236 */       double xfrac0 = xIndex / this.xSamples;
/* 237 */       double xfrac1 = (xIndex + 1) / this.xSamples;
/* 238 */       for (int zIndex = 0; zIndex < this.zSamples; zIndex++) {
/* 239 */         double zfrac0 = zIndex / this.zSamples;
/* 240 */         double zfrac1 = (zIndex + 1) / this.zSamples;
/*     */         
/* 242 */         double x0 = xAxis.getRange().value(xfrac0);
/* 243 */         double x1 = xAxis.getRange().value(xfrac1);
/* 244 */         double xm = x0 / 2.0D + x1 / 2.0D;
/* 245 */         double z0 = zAxis.getRange().value(zfrac0);
/* 246 */         double z1 = zAxis.getRange().value(zfrac1);
/* 247 */         double zm = z0 / 2.0D + z1 / 2.0D;
/* 248 */         double y00 = this.function.getValue(x0, z0);
/* 249 */         double y01 = this.function.getValue(x0, z1);
/* 250 */         double y10 = this.function.getValue(x1, z0);
/* 251 */         double y11 = this.function.getValue(x1, z1);
/* 252 */         double ymm = this.function.getValue(xm, zm);
/*     */         
/* 254 */         double wx0 = xAxis.translateToWorld(x0, xlen) + xOffset;
/* 255 */         double wx1 = xAxis.translateToWorld(x1, xlen) + xOffset;
/* 256 */         double wy00 = yAxis.translateToWorld(y00, ylen) + yOffset;
/* 257 */         double wy01 = yAxis.translateToWorld(y01, ylen) + yOffset;
/* 258 */         double wy10 = yAxis.translateToWorld(y10, ylen) + yOffset;
/* 259 */         double wy11 = yAxis.translateToWorld(y11, ylen) + yOffset;
/* 260 */         double wz0 = zAxis.translateToWorld(z0, zlen) + zOffset;
/* 261 */         double wz1 = zAxis.translateToWorld(z1, zlen) + zOffset;
/*     */         
/* 263 */         Color color = this.colorScale.valueToColor(ymm);
/* 264 */         Object3D obj = new Object3D(color, this.drawFaceOutlines);
/* 265 */         List<Point3D> pts1 = facePoints1(wx0, wx1, wz0, wz1, wy00, wy01, wy11, yRange);
/*     */         
/* 267 */         int count1 = pts1.size();
/* 268 */         for (Point3D pt : pts1) {
/* 269 */           obj.addVertex(pt);
/*     */         }
/* 271 */         if (count1 == 3) {
/* 272 */           obj.addDoubleSidedFace(new int[] { 0, 1, 2 });
/* 273 */         } else if (count1 == 4) {
/* 274 */           obj.addDoubleSidedFace(new int[] { 0, 1, 2, 3 });
/* 275 */         } else if (count1 == 5) {
/* 276 */           obj.addDoubleSidedFace(new int[] { 0, 1, 2, 3, 4 });
/*     */         } 
/* 278 */         List<Point3D> pts2 = facePoints2(wx0, wx1, wz0, wz1, wy00, wy11, wy10, yRange);
/*     */         
/* 280 */         int count2 = pts2.size();
/* 281 */         for (Point3D pt : pts2) {
/* 282 */           obj.addVertex(pt);
/*     */         }
/* 284 */         if (count2 == 3) {
/* 285 */           obj.addDoubleSidedFace(new int[] { count1, count1 + 1, count1 + 2 });
/*     */         }
/* 287 */         else if (count2 == 4) {
/* 288 */           obj.addDoubleSidedFace(new int[] { count1, count1 + 1, count1 + 2, count1 + 3 });
/*     */         }
/* 290 */         else if (count2 == 5) {
/* 291 */           obj.addDoubleSidedFace(new int[] { count1, count1 + 1, count1 + 2, count1 + 3, count1 + 4 });
/*     */         } 
/*     */         
/* 294 */         world.add(obj);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private Point3D intersectPoint(double x0, double y0, double z0, double x1, double y1, double z1, double yy) {
/* 302 */     double p = (yy - y0) / (y1 - y0);
/* 303 */     double x = x0 + p * (x1 - x0);
/* 304 */     double y = y0 + p * (y1 - y0);
/* 305 */     double z = z0 + p * (z1 - z0);
/* 306 */     return new Point3D(x, y, z);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private List<Point3D> facePoints1(double x0, double x1, double z0, double z1, double y00, double y01, double y11, Range yRange) {
/* 312 */     List<Point3D> pts = new ArrayList<Point3D>(4);
/* 313 */     double ymin = yRange.getMin();
/* 314 */     double ymax = yRange.getMax();
/*     */ 
/*     */     
/* 317 */     if (y00 > yRange.getMax()) {
/* 318 */       if (yRange.contains(y01)) {
/* 319 */         pts.add(intersectPoint(x0, y00, z0, x0, y01, z1, ymax));
/* 320 */       } else if (y01 < yRange.getMin()) {
/* 321 */         pts.add(intersectPoint(x0, y00, z0, x0, y01, z1, ymax));
/* 322 */         pts.add(intersectPoint(x0, y00, z0, x0, y01, z1, ymin));
/*     */       } 
/* 324 */     } else if (yRange.contains(y00)) {
/* 325 */       pts.add(new Point3D(x0, y00, z0));
/* 326 */       if (y01 > yRange.getMax()) {
/* 327 */         pts.add(intersectPoint(x0, y00, z0, x0, y01, z1, ymax));
/* 328 */       } else if (y01 < yRange.getMin()) {
/* 329 */         pts.add(intersectPoint(x0, y00, z0, x0, y01, z1, ymin));
/*     */       }
/*     */     
/* 332 */     } else if (yRange.contains(y01)) {
/* 333 */       pts.add(intersectPoint(x0, y00, z0, x0, y01, z1, ymin));
/* 334 */     } else if (y01 > yRange.getMax()) {
/* 335 */       pts.add(intersectPoint(x0, y00, z0, x0, y01, z1, ymin));
/* 336 */       pts.add(intersectPoint(x0, y00, z0, x0, y01, z1, ymax));
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 341 */     if (y01 > yRange.getMax()) {
/* 342 */       if (yRange.contains(y11)) {
/* 343 */         pts.add(intersectPoint(x0, y01, z1, x1, y11, z1, ymax));
/* 344 */       } else if (y11 < yRange.getMin()) {
/* 345 */         pts.add(intersectPoint(x0, y01, z1, x1, y11, z1, ymax));
/* 346 */         pts.add(intersectPoint(x0, y01, z1, x1, y11, z1, ymin));
/*     */       } 
/* 348 */     } else if (yRange.contains(y01)) {
/* 349 */       pts.add(new Point3D(x0, y01, z1));
/* 350 */       if (y11 > yRange.getMax()) {
/* 351 */         pts.add(intersectPoint(x0, y01, z1, x1, y11, z1, ymax));
/* 352 */       } else if (y11 < yRange.getMin()) {
/* 353 */         pts.add(intersectPoint(x0, y01, z1, x1, y11, z1, ymin));
/*     */       }
/*     */     
/* 356 */     } else if (y11 > yRange.getMax()) {
/* 357 */       pts.add(intersectPoint(x0, y01, z1, x1, y11, z1, ymin));
/* 358 */       pts.add(intersectPoint(x0, y01, z1, x1, y11, z1, ymax));
/* 359 */     } else if (yRange.contains(y11)) {
/* 360 */       pts.add(intersectPoint(x0, y01, z1, x1, y11, z1, ymin));
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 365 */     if (y11 > yRange.getMax()) {
/* 366 */       if (yRange.contains(y00)) {
/* 367 */         pts.add(intersectPoint(x1, y11, z1, x0, y00, z0, ymax));
/* 368 */       } else if (y00 < yRange.getMin()) {
/* 369 */         pts.add(intersectPoint(x1, y11, z1, x0, y00, z0, ymax));
/* 370 */         pts.add(intersectPoint(x1, y11, z1, x0, y00, z0, ymin));
/*     */       } 
/* 372 */     } else if (yRange.contains(y11)) {
/* 373 */       pts.add(new Point3D(x1, y11, z1));
/* 374 */       if (y00 > yRange.getMax()) {
/* 375 */         pts.add(intersectPoint(x1, y11, z1, x0, y00, z0, ymax));
/* 376 */       } else if (y00 < yRange.getMin()) {
/* 377 */         pts.add(intersectPoint(x1, y11, z1, x0, y00, z0, ymin));
/*     */       }
/*     */     
/* 380 */     } else if (y00 > yRange.getMax()) {
/* 381 */       pts.add(intersectPoint(x1, y11, z1, x0, y00, z0, ymin));
/* 382 */       pts.add(intersectPoint(x1, y11, z1, x0, y00, z0, ymax));
/* 383 */     } else if (yRange.contains(y00)) {
/* 384 */       pts.add(intersectPoint(x1, y11, z1, x0, y00, z0, ymin));
/*     */     } 
/*     */     
/* 387 */     return pts;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private List<Point3D> facePoints2(double x0, double x1, double z0, double z1, double y00, double y11, double y10, Range yRange) {
/* 393 */     List<Point3D> pts = new ArrayList<Point3D>(4);
/* 394 */     double ymin = yRange.getMin();
/* 395 */     double ymax = yRange.getMax();
/*     */     
/* 397 */     if (y00 > yRange.getMax()) {
/* 398 */       if (yRange.contains(y11)) {
/* 399 */         pts.add(intersectPoint(x0, y00, z0, x1, y11, z1, ymax));
/* 400 */       } else if (y11 < yRange.getMin()) {
/* 401 */         pts.add(intersectPoint(x0, y00, z0, x1, y11, z1, ymax));
/* 402 */         pts.add(intersectPoint(x0, y00, z0, x1, y11, z1, ymin));
/*     */       } 
/* 404 */     } else if (yRange.contains(y00)) {
/* 405 */       pts.add(new Point3D(x0, y00, z0));
/* 406 */       if (y11 > yRange.getMax()) {
/* 407 */         pts.add(intersectPoint(x0, y00, z0, x1, y11, z1, ymax));
/* 408 */       } else if (y11 < yRange.getMin()) {
/* 409 */         pts.add(intersectPoint(x0, y00, z0, x1, y11, z1, ymin));
/*     */       }
/*     */     
/* 412 */     } else if (yRange.contains(y11)) {
/* 413 */       pts.add(intersectPoint(x0, y00, z0, x1, y11, z1, ymin));
/* 414 */     } else if (y11 > yRange.getMax()) {
/* 415 */       pts.add(intersectPoint(x0, y00, z0, x1, y11, z1, ymin));
/* 416 */       pts.add(intersectPoint(x0, y00, z0, x1, y11, z1, ymax));
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 421 */     if (y11 > yRange.getMax()) {
/* 422 */       if (yRange.contains(y10)) {
/* 423 */         pts.add(intersectPoint(x1, y11, z1, x1, y10, z0, ymax));
/* 424 */       } else if (y10 < yRange.getMin()) {
/* 425 */         pts.add(intersectPoint(x1, y11, z1, x1, y10, z0, ymax));
/* 426 */         pts.add(intersectPoint(x1, y11, z1, x1, y10, z0, ymin));
/*     */       } 
/* 428 */     } else if (yRange.contains(y11)) {
/* 429 */       pts.add(new Point3D(x1, y11, z1));
/* 430 */       if (y10 > yRange.getMax()) {
/* 431 */         pts.add(intersectPoint(x1, y11, z1, x1, y10, z0, ymax));
/* 432 */       } else if (y10 < yRange.getMin()) {
/* 433 */         pts.add(intersectPoint(x1, y11, z1, x1, y10, z0, ymin));
/*     */       }
/*     */     
/* 436 */     } else if (y10 > yRange.getMax()) {
/* 437 */       pts.add(intersectPoint(x1, y11, z1, x1, y10, z0, ymin));
/* 438 */       pts.add(intersectPoint(x1, y11, z1, x1, y10, z0, ymax));
/* 439 */     } else if (yRange.contains(y10)) {
/* 440 */       pts.add(intersectPoint(x1, y11, z1, x1, y10, z0, ymin));
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 445 */     if (y10 > yRange.getMax()) {
/* 446 */       if (yRange.contains(y00)) {
/* 447 */         pts.add(intersectPoint(x1, y10, z0, x0, y00, z0, ymax));
/* 448 */       } else if (y00 < yRange.getMin()) {
/* 449 */         pts.add(intersectPoint(x1, y10, z0, x0, y00, z0, ymax));
/* 450 */         pts.add(intersectPoint(x1, y10, z0, x0, y00, z0, ymin));
/*     */       } 
/* 452 */     } else if (yRange.contains(y10)) {
/* 453 */       pts.add(new Point3D(x1, y10, z0));
/* 454 */       if (y00 > yRange.getMax()) {
/* 455 */         pts.add(intersectPoint(x1, y10, z0, x0, y00, z0, ymax));
/* 456 */       } else if (y00 < yRange.getMin()) {
/* 457 */         pts.add(intersectPoint(x1, y10, z0, x0, y00, z0, ymin));
/*     */       }
/*     */     
/* 460 */     } else if (y00 > yRange.getMax()) {
/* 461 */       pts.add(intersectPoint(x1, y10, z0, x0, y00, z0, ymin));
/* 462 */       pts.add(intersectPoint(x1, y10, z0, x0, y00, z0, ymax));
/* 463 */     } else if (yRange.contains(y00)) {
/* 464 */       pts.add(intersectPoint(x1, y10, z0, x0, y00, z0, ymin));
/*     */     } 
/*     */ 
/*     */     
/* 468 */     return pts;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void composeItem(XYZDataset dataset, int series, int item, World world, Dimension3D dimensions, double xOffset, double yOffset, double zOffset) {
/* 488 */     throw new UnsupportedOperationException("Not supported by this renderer.");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Range findXRange(XYZDataset dataset) {
/* 503 */     return getPlot().getXAxis().getRange();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Range findYRange(XYZDataset dataset) {
/* 516 */     return Function3DUtils.findYRange(this.function, 
/* 517 */         getPlot().getXAxis().getRange(), 
/* 518 */         getPlot().getZAxis().getRange(), this.xSamples, this.zSamples, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Range findZRange(XYZDataset dataset) {
/* 533 */     return getPlot().getZAxis().getRange();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 545 */     if (obj == this) {
/* 546 */       return true;
/*     */     }
/* 548 */     if (!(obj instanceof SurfaceRenderer)) {
/* 549 */       return false;
/*     */     }
/* 551 */     SurfaceRenderer that = (SurfaceRenderer)obj;
/* 552 */     if (!this.function.equals(that.function)) {
/* 553 */       return false;
/*     */     }
/* 555 */     if (this.xSamples != that.xSamples) {
/* 556 */       return false;
/*     */     }
/* 558 */     if (this.zSamples != that.zSamples) {
/* 559 */       return false;
/*     */     }
/* 561 */     if (!this.colorScale.equals(that.colorScale)) {
/* 562 */       return false;
/*     */     }
/* 564 */     if (this.drawFaceOutlines != that.drawFaceOutlines) {
/* 565 */       return false;
/*     */     }
/* 567 */     return super.equals(obj);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/renderer/xyz/SurfaceRenderer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */