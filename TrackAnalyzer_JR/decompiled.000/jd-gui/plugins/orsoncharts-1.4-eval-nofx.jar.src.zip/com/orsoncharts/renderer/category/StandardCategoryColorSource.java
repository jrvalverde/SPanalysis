/*     */ package com.orsoncharts.renderer.category;
/*     */ 
/*     */ import com.orsoncharts.Colors;
/*     */ import com.orsoncharts.util.ArgChecks;
/*     */ import java.awt.Color;
/*     */ import java.io.Serializable;
/*     */ import java.util.Arrays;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StandardCategoryColorSource
/*     */   implements CategoryColorSource, Serializable
/*     */ {
/*     */   private Color[] colors;
/*     */   
/*     */   public StandardCategoryColorSource() {
/*  40 */     this(Colors.getDefaultColors());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StandardCategoryColorSource(Color... colors) {
/*  51 */     ArgChecks.nullNotPermitted(colors, "colors");
/*  52 */     if (colors.length == 0) {
/*  53 */       throw new IllegalArgumentException("Zero length array not permitted.");
/*     */     }
/*     */     
/*  56 */     for (Color c : colors) {
/*  57 */       if (c == null) {
/*  58 */         throw new IllegalArgumentException("Null array entries not permitted.");
/*     */       }
/*     */     } 
/*     */     
/*  62 */     this.colors = (Color[])colors.clone();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Color getColor(int series, int row, int column) {
/*  76 */     return this.colors[series % this.colors.length];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Color getLegendColor(int series) {
/*  88 */     return this.colors[series % this.colors.length];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void style(Color... colors) {
/* 103 */     ArgChecks.nullNotPermitted(colors, "colors");
/* 104 */     if (colors.length == 0) {
/* 105 */       throw new IllegalArgumentException("Zero length array not permitted.");
/*     */     }
/*     */     
/* 108 */     for (Color c : colors) {
/* 109 */       if (c == null) {
/* 110 */         throw new IllegalArgumentException("Null array entries not permitted.");
/*     */       }
/*     */     } 
/*     */     
/* 114 */     this.colors = (Color[])colors.clone();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 126 */     if (obj == this) {
/* 127 */       return true;
/*     */     }
/* 129 */     if (!(obj instanceof StandardCategoryColorSource)) {
/* 130 */       return false;
/*     */     }
/* 132 */     StandardCategoryColorSource that = (StandardCategoryColorSource)obj;
/*     */     
/* 134 */     if (!Arrays.equals((Object[])this.colors, (Object[])that.colors)) {
/* 135 */       return false;
/*     */     }
/* 137 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 142 */     int hash = 7;
/* 143 */     hash = 97 * hash + Arrays.deepHashCode((Object[])this.colors);
/* 144 */     return hash;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/renderer/category/StandardCategoryColorSource.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */