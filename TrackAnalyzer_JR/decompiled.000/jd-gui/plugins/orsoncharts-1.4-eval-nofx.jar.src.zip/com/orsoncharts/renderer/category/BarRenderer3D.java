/*     */ package com.orsoncharts.renderer.category;
/*     */ 
/*     */ import com.orsoncharts.Range;
/*     */ import com.orsoncharts.axis.CategoryAxis3D;
/*     */ import com.orsoncharts.axis.ValueAxis3D;
/*     */ import com.orsoncharts.data.DataUtils;
/*     */ import com.orsoncharts.data.KeyedValues3DItemKey;
/*     */ import com.orsoncharts.data.Values3D;
/*     */ import com.orsoncharts.data.category.CategoryDataset3D;
/*     */ import com.orsoncharts.graphics3d.Dimension3D;
/*     */ import com.orsoncharts.graphics3d.Object3D;
/*     */ import com.orsoncharts.graphics3d.World;
/*     */ import com.orsoncharts.label.ItemLabelPositioning;
/*     */ import com.orsoncharts.plot.CategoryPlot3D;
/*     */ import com.orsoncharts.util.ObjectUtils;
/*     */ import java.awt.Color;
/*     */ import java.io.Serializable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BarRenderer3D
/*     */   extends AbstractCategoryRenderer3D
/*     */   implements Serializable
/*     */ {
/*  86 */   private double base = 0.0D;
/*  87 */   private double barXWidth = 0.8D;
/*  88 */   private double barZWidth = 0.5D;
/*  89 */   private CategoryColorSource baseColorSource = new StandardCategoryColorSource(new Color[] { Color.WHITE });
/*  90 */   private CategoryColorSource topColorSource = new StandardCategoryColorSource(new Color[] { Color.BLACK });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getBase() {
/* 102 */     return this.base;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBase(double base) {
/* 114 */     this.base = base;
/* 115 */     fireChangeEvent(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getBarXWidth() {
/* 127 */     return this.barXWidth;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBarXWidth(double barXWidth) {
/* 137 */     this.barXWidth = barXWidth;
/* 138 */     fireChangeEvent(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getBarZWidth() {
/* 148 */     return this.barZWidth;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBarZWidth(double barZWidth) {
/* 158 */     this.barZWidth = barZWidth;
/* 159 */     fireChangeEvent(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CategoryColorSource getBaseColorSource() {
/* 173 */     return this.baseColorSource;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBaseColorSource(CategoryColorSource source) {
/* 191 */     this.baseColorSource = source;
/* 192 */     fireChangeEvent(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CategoryColorSource getTopColorSource() {
/* 206 */     return this.topColorSource;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTopColorSource(CategoryColorSource source) {
/* 220 */     this.topColorSource = source;
/* 221 */     fireChangeEvent(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Range findValueRange(Values3D<? extends Number> data) {
/* 235 */     return DataUtils.findValueRange(data, this.base);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void composeItem(CategoryDataset3D dataset, int series, int row, int column, World world, Dimension3D dimensions, double xOffset, double yOffset, double zOffset) {
/* 258 */     double value = dataset.getDoubleValue(series, row, column);
/* 259 */     if (Double.isNaN(value)) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 264 */     composeItem(value, this.base, dataset, series, row, column, world, dimensions, xOffset, yOffset, zOffset);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void composeItem(double value, double barBase, CategoryDataset3D dataset, int series, int row, int column, World world, Dimension3D dimensions, double xOffset, double yOffset, double zOffset) {
/* 290 */     Comparable<?> seriesKey = dataset.getSeriesKey(series);
/* 291 */     Comparable<?> rowKey = dataset.getRowKey(row);
/* 292 */     Comparable<?> columnKey = dataset.getColumnKey(column);
/*     */     
/* 294 */     double vlow = Math.min(barBase, value);
/* 295 */     double vhigh = Math.max(barBase, value);
/*     */     
/* 297 */     CategoryPlot3D plot = getPlot();
/* 298 */     CategoryAxis3D rowAxis = plot.getRowAxis();
/* 299 */     CategoryAxis3D columnAxis = plot.getColumnAxis();
/* 300 */     ValueAxis3D valueAxis = plot.getValueAxis();
/* 301 */     Range range = valueAxis.getRange();
/* 302 */     if (!range.intersects(vlow, vhigh)) {
/*     */       return;
/*     */     }
/*     */     
/* 306 */     double vbase = range.peggedValue(vlow);
/* 307 */     double vtop = range.peggedValue(vhigh);
/* 308 */     boolean inverted = (barBase > value);
/*     */     
/* 310 */     double rowValue = rowAxis.getCategoryValue(rowKey);
/* 311 */     double columnValue = columnAxis.getCategoryValue(columnKey);
/*     */     
/* 313 */     double width = dimensions.getWidth();
/* 314 */     double height = dimensions.getHeight();
/* 315 */     double depth = dimensions.getDepth();
/* 316 */     double xx = columnAxis.translateToWorld(columnValue, width) + xOffset;
/* 317 */     double yy = valueAxis.translateToWorld(vtop, height) + yOffset;
/* 318 */     double zz = rowAxis.translateToWorld(rowValue, depth) + zOffset;
/*     */     
/* 320 */     double xw = this.barXWidth * columnAxis.getCategoryWidth();
/* 321 */     double zw = this.barZWidth * rowAxis.getCategoryWidth();
/* 322 */     double xxw = columnAxis.translateToWorld(xw, width);
/* 323 */     double xzw = rowAxis.translateToWorld(zw, depth);
/* 324 */     double basew = valueAxis.translateToWorld(vbase, height) + yOffset;
/*     */     
/* 326 */     Color color = getColorSource().getColor(series, row, column);
/* 327 */     Color baseColor = null;
/* 328 */     if (this.baseColorSource != null && !range.contains(this.base)) {
/* 329 */       baseColor = this.baseColorSource.getColor(series, row, column);
/*     */     }
/* 331 */     if (baseColor == null) {
/* 332 */       baseColor = color;
/*     */     }
/*     */     
/* 335 */     Color topColor = null;
/* 336 */     if (this.topColorSource != null && !range.contains(value)) {
/* 337 */       topColor = this.topColorSource.getColor(series, row, column);
/*     */     }
/* 339 */     if (topColor == null) {
/* 340 */       topColor = color;
/*     */     }
/* 342 */     Object3D bar = Object3D.createBar(xxw, xzw, xx, yy, zz, basew, color, baseColor, topColor, inverted);
/*     */     
/* 344 */     KeyedValues3DItemKey itemKey = new KeyedValues3DItemKey(seriesKey, rowKey, columnKey);
/*     */     
/* 346 */     bar.setProperty("key", itemKey);
/* 347 */     world.add(bar);
/* 348 */     drawItemLabels(world, dataset, itemKey, xx, yy, zz, basew, inverted);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void drawItemLabels(World world, CategoryDataset3D dataset, KeyedValues3DItemKey itemKey, double xw, double yw, double zw, double basew, boolean inverted) {
/* 354 */     ItemLabelPositioning positioning = getItemLabelPositioning();
/* 355 */     if (getItemLabelGenerator() == null) {
/*     */       return;
/*     */     }
/* 358 */     String label = getItemLabelGenerator().generateItemLabel(dataset, itemKey
/* 359 */         .getSeriesKey(), itemKey.getRowKey(), itemKey
/* 360 */         .getColumnKey());
/* 361 */     if (label != null) {
/* 362 */       Dimension3D dimensions = getPlot().getDimensions();
/* 363 */       double dx = getItemLabelOffsets().getDX();
/* 364 */       double dy = getItemLabelOffsets().getDY() * dimensions.getHeight();
/* 365 */       double dz = getItemLabelOffsets().getDZ() * getBarZWidth();
/* 366 */       double yy = yw;
/* 367 */       if (inverted) {
/* 368 */         yy = basew;
/* 369 */         dy = -dy;
/*     */       } 
/* 371 */       if (positioning.equals(ItemLabelPositioning.CENTRAL)) {
/* 372 */         Object3D labelObj = Object3D.createLabelObject(label, 
/* 373 */             getItemLabelFont(), getItemLabelColor(), 
/* 374 */             getItemLabelBackgroundColor(), xw + dx, yy + dy, zw, false, true);
/*     */         
/* 376 */         labelObj.setProperty("key", itemKey);
/* 377 */         world.add(labelObj);
/* 378 */       } else if (positioning.equals(ItemLabelPositioning.FRONT_AND_BACK)) {
/*     */         
/* 380 */         Object3D labelObj1 = Object3D.createLabelObject(label, 
/* 381 */             getItemLabelFont(), getItemLabelColor(), 
/* 382 */             getItemLabelBackgroundColor(), xw + dx, yy + dy, zw + dz, false, false);
/*     */         
/* 384 */         labelObj1.setProperty("key", itemKey);
/* 385 */         world.add(labelObj1);
/* 386 */         Object3D labelObj2 = Object3D.createLabelObject(label, 
/* 387 */             getItemLabelFont(), getItemLabelColor(), 
/* 388 */             getItemLabelBackgroundColor(), xw + dx, yy + dy, zw - dz, true, false);
/*     */         
/* 390 */         labelObj1.setProperty("key", itemKey);
/* 391 */         world.add(labelObj2);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 405 */     if (obj == this) {
/* 406 */       return true;
/*     */     }
/* 408 */     if (!(obj instanceof BarRenderer3D)) {
/* 409 */       return false;
/*     */     }
/* 411 */     BarRenderer3D that = (BarRenderer3D)obj;
/* 412 */     if (this.base != that.base) {
/* 413 */       return false;
/*     */     }
/* 415 */     if (this.barXWidth != that.barXWidth) {
/* 416 */       return false;
/*     */     }
/* 418 */     if (this.barZWidth != that.barZWidth) {
/* 419 */       return false;
/*     */     }
/* 421 */     if (!ObjectUtils.equals(this.baseColorSource, that.baseColorSource)) {
/* 422 */       return false;
/*     */     }
/* 424 */     if (!ObjectUtils.equals(this.topColorSource, that.topColorSource)) {
/* 425 */       return false;
/*     */     }
/* 427 */     return super.equals(obj);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/renderer/category/BarRenderer3D.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */