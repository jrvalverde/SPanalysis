/*     */ package com.orsoncharts.renderer;
/*     */ 
/*     */ import com.orsoncharts.Range;
/*     */ import com.orsoncharts.util.ArgChecks;
/*     */ import java.awt.Color;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RainbowScale
/*     */   extends AbstractColorScale
/*     */   implements ColorScale
/*     */ {
/*  37 */   public static final Range ALL_HUES = new Range(0.0D, 1.0D);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  43 */   public static final Range BLUE_TO_RED_RANGE = new Range(0.0D, 0.6666D);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Color[] colors;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Range hueSubrange;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RainbowScale(Range range) {
/*  61 */     this(range, 256, BLUE_TO_RED_RANGE);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RainbowScale(Range range, int samples, Range hueSubrange) {
/*  73 */     super(range);
/*  74 */     ArgChecks.nullNotPermitted(hueSubrange, "hueSubrange");
/*  75 */     this.colors = new Color[samples];
/*  76 */     this.hueSubrange = hueSubrange;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getSampleCount() {
/*  85 */     return this.colors.length;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Range getHueSubrange() {
/*  94 */     return this.hueSubrange;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Color valueToColor(double value) {
/* 106 */     Range r = getRange();
/* 107 */     if (value < r.getMin()) {
/* 108 */       return valueToColor(r.getMin());
/*     */     }
/* 110 */     if (value > r.getMax()) {
/* 111 */       return valueToColor(r.getMax());
/*     */     }
/* 113 */     double fraction = getRange().percent(value);
/* 114 */     int i = (int)(fraction * (this.colors.length - 1));
/* 115 */     if (this.colors[i] == null) {
/* 116 */       this.colors[i] = createRainbowColor(fraction);
/*     */     }
/* 118 */     return this.colors[i];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Color createRainbowColor(double fraction) {
/* 130 */     double inv = 1.0D - fraction;
/* 131 */     double hue = this.hueSubrange.value(inv);
/* 132 */     return Color.getHSBColor((float)hue, 1.0F, 1.0F);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 144 */     if (obj == this) {
/* 145 */       return true;
/*     */     }
/* 147 */     if (!(obj instanceof RainbowScale)) {
/* 148 */       return false;
/*     */     }
/* 150 */     RainbowScale that = (RainbowScale)obj;
/* 151 */     if (this.colors.length != that.colors.length) {
/* 152 */       return false;
/*     */     }
/* 154 */     if (!this.hueSubrange.equals(that.hueSubrange)) {
/* 155 */       return false;
/*     */     }
/* 157 */     return super.equals(obj);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/renderer/RainbowScale.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */