package com.orsoncharts.renderer.xyz;

import com.orsoncharts.Range;
import com.orsoncharts.data.xyz.XYZDataset;
import com.orsoncharts.graphics3d.Dimension3D;
import com.orsoncharts.graphics3d.World;
import com.orsoncharts.plot.XYZPlot;
import com.orsoncharts.renderer.ComposeType;
import com.orsoncharts.renderer.Renderer3D;
import java.awt.Color;

public interface XYZRenderer extends Renderer3D {
  XYZPlot getPlot();
  
  void setPlot(XYZPlot paramXYZPlot);
  
  XYZColorSource getColorSource();
  
  void setColorSource(XYZColorSource paramXYZColorSource);
  
  void setColors(Color... paramVarArgs);
  
  Range findXRange(XYZDataset paramXYZDataset);
  
  Range findYRange(XYZDataset paramXYZDataset);
  
  Range findZRange(XYZDataset paramXYZDataset);
  
  ComposeType getComposeType();
  
  void composeItem(XYZDataset paramXYZDataset, int paramInt1, int paramInt2, World paramWorld, Dimension3D paramDimension3D, double paramDouble1, double paramDouble2, double paramDouble3);
  
  void composeAll(XYZPlot paramXYZPlot, World paramWorld, Dimension3D paramDimension3D, double paramDouble1, double paramDouble2, double paramDouble3);
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/renderer/xyz/XYZRenderer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */