/*     */ package com.orsoncharts.renderer;
/*     */ 
/*     */ import com.orsoncharts.Range;
/*     */ import com.orsoncharts.util.ArgChecks;
/*     */ import java.awt.Color;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GradientColorScale
/*     */   extends AbstractColorScale
/*     */   implements ColorScale
/*     */ {
/*     */   private Color lowColor;
/*     */   private Color highColor;
/*     */   private Color[] colors;
/*     */   
/*     */   public GradientColorScale(Range range, Color lowColor, Color highColor) {
/*  52 */     super(range);
/*  53 */     ArgChecks.nullNotPermitted(lowColor, "lowColor");
/*  54 */     ArgChecks.nullNotPermitted(highColor, "highColor");
/*  55 */     this.lowColor = lowColor;
/*  56 */     this.highColor = highColor;
/*  57 */     this.colors = new Color[255];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Color getLowColor() {
/*  66 */     return this.lowColor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Color getHighColor() {
/*  75 */     return this.highColor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getSampleCount() {
/*  84 */     return this.colors.length;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Color valueToColor(double value) {
/*  96 */     Range r = getRange();
/*  97 */     if (value < r.getMin()) {
/*  98 */       return valueToColor(r.getMin());
/*     */     }
/* 100 */     if (value > r.getMax()) {
/* 101 */       return valueToColor(r.getMax());
/*     */     }
/* 103 */     double fraction = getRange().percent(value);
/* 104 */     int i = (int)(fraction * this.colors.length);
/* 105 */     if (this.colors[i] == null) {
/* 106 */       float[] lrgba = this.lowColor.getRGBComponents(null);
/* 107 */       float[] hrgba = this.highColor.getRGBComponents(null);
/* 108 */       float p = (float)fraction;
/* 109 */       this.colors[i] = new Color(lrgba[0] * (1.0F - p) + hrgba[0] * p, lrgba[1] * (1.0F - p) + hrgba[1] * p, lrgba[2] * (1.0F - p) + hrgba[2] * p, lrgba[3] * (1.0F - p) + hrgba[3] * p);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 114 */     return this.colors[i];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 126 */     if (obj == this) {
/* 127 */       return true;
/*     */     }
/* 129 */     if (!(obj instanceof GradientColorScale)) {
/* 130 */       return false;
/*     */     }
/* 132 */     GradientColorScale that = (GradientColorScale)obj;
/* 133 */     if (!this.lowColor.equals(that.lowColor)) {
/* 134 */       return false;
/*     */     }
/* 136 */     if (!this.highColor.equals(that.highColor)) {
/* 137 */       return false;
/*     */     }
/* 139 */     return super.equals(obj);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/renderer/GradientColorScale.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */