/*     */ package com.orsoncharts.renderer.category;
/*     */ 
/*     */ import com.orsoncharts.Range;
/*     */ import com.orsoncharts.axis.CategoryAxis3D;
/*     */ import com.orsoncharts.axis.ValueAxis3D;
/*     */ import com.orsoncharts.data.DataUtils;
/*     */ import com.orsoncharts.data.KeyedValues3DItemKey;
/*     */ import com.orsoncharts.data.Values3D;
/*     */ import com.orsoncharts.data.category.CategoryDataset3D;
/*     */ import com.orsoncharts.graphics3d.Dimension3D;
/*     */ import com.orsoncharts.graphics3d.Object3D;
/*     */ import com.orsoncharts.graphics3d.Offset3D;
/*     */ import com.orsoncharts.graphics3d.Utils2D;
/*     */ import com.orsoncharts.graphics3d.World;
/*     */ import com.orsoncharts.label.ItemLabelPositioning;
/*     */ import com.orsoncharts.plot.CategoryPlot3D;
/*     */ import com.orsoncharts.util.ObjectUtils;
/*     */ import java.awt.Color;
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AreaRenderer3D
/*     */   extends AbstractCategoryRenderer3D
/*     */   implements Serializable
/*     */ {
/*  97 */   private double base = 0.0D;
/*  98 */   private Color baseColor = null;
/*  99 */   private double depth = 0.6D;
/* 100 */   private double isolatedItemWidthPercent = 0.25D;
/* 101 */   private CategoryColorSource clipColorSource = new StandardCategoryColorSource(new Color[] { Color.RED });
/*     */ 
/*     */   
/*     */   private boolean drawFaceOutlines = true;
/*     */ 
/*     */   
/*     */   private static final double EPSILON = 0.001D;
/*     */ 
/*     */ 
/*     */   
/*     */   public double getBase() {
/* 112 */     return this.base;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBase(double base) {
/* 121 */     this.base = base;
/* 122 */     fireChangeEvent(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Color getBaseColor() {
/* 135 */     return this.baseColor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBaseColor(Color color) {
/* 147 */     this.baseColor = color;
/* 148 */     fireChangeEvent(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getDepth() {
/* 158 */     return this.depth;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDepth(double depth) {
/* 168 */     this.depth = depth;
/* 169 */     fireChangeEvent(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CategoryColorSource getClipColorSource() {
/* 182 */     return this.clipColorSource;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setClipColorSource(CategoryColorSource source) {
/* 195 */     this.clipColorSource = source;
/* 196 */     fireChangeEvent(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getDrawFaceOutlines() {
/* 215 */     return this.drawFaceOutlines;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDrawFaceOutlines(boolean outline) {
/* 228 */     this.drawFaceOutlines = outline;
/* 229 */     fireChangeEvent(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Range findValueRange(Values3D<? extends Number> data) {
/* 244 */     return DataUtils.findValueRange(data, this.base);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void composeItem(CategoryDataset3D dataset, int series, int row, int column, World world, Dimension3D dimensions, double xOffset, double yOffset, double zOffset) {
/*     */     boolean createLeftSegment, createRightSegment, createIsolatedSegment;
/* 267 */     Number y = (Number)dataset.getValue(series, row, column);
/* 268 */     Number yprev = null;
/* 269 */     if (column > 0) {
/* 270 */       yprev = (Number)dataset.getValue(series, row, column - 1);
/*     */     }
/* 272 */     Number ynext = null;
/* 273 */     if (column < dataset.getColumnCount() - 1) {
/* 274 */       ynext = (Number)dataset.getValue(series, row, column + 1);
/*     */     }
/*     */     
/* 277 */     CategoryPlot3D plot = getPlot();
/* 278 */     CategoryAxis3D rowAxis = plot.getRowAxis();
/* 279 */     CategoryAxis3D columnAxis = plot.getColumnAxis();
/* 280 */     ValueAxis3D valueAxis = plot.getValueAxis();
/* 281 */     Range r = valueAxis.getRange();
/*     */     
/* 283 */     Comparable<?> seriesKey = dataset.getSeriesKey(series);
/* 284 */     Comparable<?> rowKey = dataset.getRowKey(row);
/* 285 */     Comparable<?> columnKey = dataset.getColumnKey(column);
/* 286 */     double rowValue = rowAxis.getCategoryValue(rowKey);
/* 287 */     double columnValue = columnAxis.getCategoryValue(columnKey);
/* 288 */     double ww = dimensions.getWidth();
/* 289 */     double hh = dimensions.getHeight();
/* 290 */     double dd = dimensions.getDepth();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 301 */     boolean leftOpen = false;
/* 302 */     boolean leftClose = false;
/* 303 */     boolean rightOpen = false;
/* 304 */     boolean rightClose = false;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 309 */     if (column == 0) {
/* 310 */       createLeftSegment = false;
/* 311 */       if (dataset.getColumnCount() == 1) {
/* 312 */         createRightSegment = false;
/* 313 */         createIsolatedSegment = (y != null);
/*     */       } else {
/* 315 */         createRightSegment = (y != null && ynext != null);
/* 316 */         rightOpen = true;
/* 317 */         rightClose = false;
/* 318 */         createIsolatedSegment = (y != null && ynext == null);
/*     */       
/*     */       }
/*     */     
/*     */     }
/* 323 */     else if (column == dataset.getColumnCount() - 1) {
/* 324 */       createRightSegment = false;
/* 325 */       createLeftSegment = (y != null && yprev != null);
/* 326 */       leftOpen = false;
/* 327 */       leftClose = true;
/* 328 */       createIsolatedSegment = (y != null && yprev == null);
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */       
/* 334 */       createLeftSegment = (y != null && yprev != null);
/* 335 */       leftOpen = false;
/* 336 */       leftClose = (createLeftSegment && ynext == null);
/* 337 */       createRightSegment = (y != null && ynext != null);
/* 338 */       rightOpen = (createRightSegment && yprev == null);
/* 339 */       rightClose = false;
/* 340 */       createIsolatedSegment = (y != null && yprev == null && ynext == null);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 346 */     double xw = columnAxis.translateToWorld(columnValue, ww) + xOffset;
/* 347 */     double yw = Double.NaN;
/* 348 */     if (y != null) {
/* 349 */       yw = valueAxis.translateToWorld(y.doubleValue(), hh) + yOffset;
/*     */     }
/* 351 */     double zw = rowAxis.translateToWorld(rowValue, dd) + zOffset;
/* 352 */     double ywmin = valueAxis.translateToWorld(r.getMin(), hh) + yOffset;
/* 353 */     double ywmax = valueAxis.translateToWorld(r.getMax(), hh) + yOffset;
/* 354 */     double basew = valueAxis.translateToWorld(this.base, hh) + yOffset;
/* 355 */     Color color = getColorSource().getColor(series, row, column);
/* 356 */     Color clipColor = color;
/* 357 */     if (getClipColorSource() != null) {
/* 358 */       Color c = getClipColorSource().getColor(series, row, column);
/* 359 */       if (c != null) {
/* 360 */         clipColor = c;
/*     */       }
/*     */     } 
/* 363 */     KeyedValues3DItemKey itemKey = new KeyedValues3DItemKey(seriesKey, rowKey, columnKey);
/*     */ 
/*     */     
/* 366 */     if (createLeftSegment) {
/* 367 */       Comparable<?> prevColumnKey = dataset.getColumnKey(column - 1);
/* 368 */       double prevColumnValue = columnAxis.getCategoryValue(prevColumnKey);
/* 369 */       double prevColumnX = columnAxis.translateToWorld(prevColumnValue, ww) + xOffset;
/*     */       
/* 371 */       double xl = (prevColumnX + xw) / 2.0D;
/* 372 */       assert yprev != null;
/*     */       
/* 374 */       double yprevw = valueAxis.translateToWorld(yprev.doubleValue(), hh) + yOffset;
/*     */       
/* 376 */       double yl = (yprevw + yw) / 2.0D;
/* 377 */       List<Object3D> leftObjs = createSegment(xl, yl, xw, yw, zw, basew, ywmin, ywmax, color, this.baseColor, clipColor, leftOpen, leftClose);
/*     */ 
/*     */       
/* 380 */       for (Object3D obj : leftObjs) {
/* 381 */         obj.setProperty("key", itemKey);
/* 382 */         obj.setOutline(this.drawFaceOutlines);
/* 383 */         world.add(obj);
/*     */       } 
/*     */     } 
/*     */     
/* 387 */     if (createRightSegment) {
/* 388 */       Comparable<?> nextColumnKey = dataset.getColumnKey(column + 1);
/* 389 */       double nextColumnValue = columnAxis.getCategoryValue(nextColumnKey);
/* 390 */       double nextColumnX = columnAxis.translateToWorld(nextColumnValue, ww) + xOffset;
/*     */       
/* 392 */       double xr = (nextColumnX + xw) / 2.0D;
/* 393 */       assert ynext != null;
/*     */       
/* 395 */       double ynextw = valueAxis.translateToWorld(ynext.doubleValue(), hh) + yOffset;
/*     */       
/* 397 */       double yr = (ynextw + yw) / 2.0D;
/* 398 */       List<Object3D> rightObjs = createSegment(xw, yw, xr, yr, zw, basew, ywmin, ywmax, color, this.baseColor, clipColor, rightOpen, rightClose);
/*     */ 
/*     */       
/* 401 */       for (Object3D obj : rightObjs) {
/* 402 */         obj.setProperty("key", itemKey);
/* 403 */         obj.setOutline(this.drawFaceOutlines);
/* 404 */         world.add(obj);
/*     */       } 
/*     */     } 
/*     */     
/* 408 */     if (createIsolatedSegment) {
/* 409 */       double cw = columnAxis.getCategoryWidth() * this.isolatedItemWidthPercent;
/*     */       
/* 411 */       double cww = columnAxis.translateToWorld(cw, ww);
/* 412 */       double h = yw - basew;
/* 413 */       Object3D isolated = Object3D.createBox(xw, cww, yw - h / 2.0D, h, zw, this.depth, color);
/*     */       
/* 415 */       isolated.setOutline(this.drawFaceOutlines);
/* 416 */       isolated.setProperty("key", itemKey);
/* 417 */       world.add(isolated);
/*     */     } 
/*     */     
/* 420 */     if (getItemLabelGenerator() != null && !Double.isNaN(yw) && yw >= ywmin && yw <= ywmax) {
/*     */       
/* 422 */       String label = getItemLabelGenerator().generateItemLabel(dataset, seriesKey, rowKey, columnKey);
/*     */       
/* 424 */       ItemLabelPositioning positioning = getItemLabelPositioning();
/* 425 */       Offset3D offsets = getItemLabelOffsets();
/* 426 */       double ydelta = dimensions.getHeight() * offsets.getDY();
/* 427 */       if (yw < basew) {
/* 428 */         ydelta = -ydelta;
/*     */       }
/* 430 */       if (positioning.equals(ItemLabelPositioning.CENTRAL)) {
/* 431 */         Object3D labelObj = Object3D.createLabelObject(label, 
/* 432 */             getItemLabelFont(), getItemLabelColor(), 
/* 433 */             getItemLabelBackgroundColor(), xw, yw + ydelta, zw, false, true);
/*     */ 
/*     */         
/* 436 */         labelObj.setProperty("key", itemKey);
/* 437 */         world.add(labelObj);
/* 438 */       } else if (positioning.equals(ItemLabelPositioning.FRONT_AND_BACK)) {
/*     */         
/* 440 */         double zdelta = this.depth / 2.0D * offsets.getDZ();
/* 441 */         Object3D labelObj1 = Object3D.createLabelObject(label, 
/* 442 */             getItemLabelFont(), getItemLabelColor(), 
/* 443 */             getItemLabelBackgroundColor(), xw, yw + ydelta, zw - zdelta, false, false);
/*     */         
/* 445 */         labelObj1.setProperty("class", "ItemLabel");
/* 446 */         labelObj1.setProperty("key", itemKey);
/* 447 */         world.add(labelObj1);
/* 448 */         Object3D labelObj2 = Object3D.createLabelObject(label, 
/* 449 */             getItemLabelFont(), getItemLabelColor(), 
/* 450 */             getItemLabelBackgroundColor(), xw, yw + ydelta, zw + zdelta, true, false);
/*     */         
/* 452 */         labelObj2.setProperty("class", "ItemLabel");
/* 453 */         labelObj2.setProperty("key", itemKey);
/* 454 */         world.add(labelObj2);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private List<Object3D> createSegment(double x0, double y0, double x1, double y1, double z, double base, double ymin, double ymax, Color color, Color baseColor, Color clipColor, boolean openingFace, boolean closingFace) {
/* 484 */     List<Object3D> result = new ArrayList<Object3D>(2);
/*     */     
/* 486 */     if (!isBaselineCrossed(y0, y1, base)) {
/* 487 */       Object3D segment = createSegmentWithoutCrossing(x0, y0, x1, y1, z, base, ymin, ymax, color, baseColor, clipColor, openingFace, closingFace);
/*     */ 
/*     */       
/* 490 */       result.add(segment);
/*     */     } else {
/* 492 */       result.addAll(createSegmentWithCrossing(x0, y0, x1, y1, z, base, ymin, ymax, color, baseColor, clipColor, openingFace, closingFace));
/*     */     } 
/*     */ 
/*     */     
/* 496 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isBaselineCrossed(double y0, double y1, double baseline) {
/* 512 */     return ((y0 > baseline && y1 < baseline) || (y0 < baseline && y1 > baseline));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Object3D createSegmentWithoutCrossing(double x0, double y0, double x1, double y1, double z, double base, double ymin, double ymax, Color color, Color baseColor, Color clipColor, boolean openingFace, boolean closingFace) {
/* 521 */     boolean positive = (y0 > base || y1 > base);
/* 522 */     if (positive) {
/* 523 */       Object3D pos = createPositiveArea(x0, y0, x1, y1, base, z, new Range(ymin, ymax), color, openingFace, closingFace);
/*     */ 
/*     */       
/* 526 */       return pos;
/*     */     } 
/* 528 */     Object3D neg = createNegativeArea(x0, y0, x1, y1, base, z, new Range(ymin, ymax), color, openingFace, closingFace);
/*     */     
/* 530 */     return neg;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private List<Object3D> createSegmentWithCrossing(double x0, double y0, double x1, double y1, double z, double base, double ymin, double ymax, Color color, Color baseColor, Color clipColor, boolean openingFace, boolean closingFace) {
/* 538 */     List<Object3D> result = new ArrayList<Object3D>(2);
/* 539 */     Range range = new Range(ymin, ymax);
/*     */     
/* 541 */     double ydelta = Math.abs(y1 - y0);
/* 542 */     double factor = 0.0D;
/* 543 */     if (ydelta != 0.0D) {
/* 544 */       factor = Math.abs(y0 - base) / ydelta;
/*     */     }
/* 546 */     double xcross = x0 + factor * (x1 - x0);
/* 547 */     if (y0 > base) {
/* 548 */       Object3D pos = createPositiveArea(x0, y0, xcross, base, base, z, range, color, openingFace, closingFace);
/*     */       
/* 550 */       if (pos != null) {
/* 551 */         result.add(pos);
/*     */       }
/* 553 */       Object3D neg = createNegativeArea(xcross, base, x1, y1, base, z, range, color, openingFace, closingFace);
/*     */       
/* 555 */       if (neg != null) {
/* 556 */         result.add(neg);
/*     */       }
/*     */     } else {
/* 559 */       Object3D neg = createNegativeArea(x0, y0, xcross, base, base, z, range, color, openingFace, closingFace);
/*     */       
/* 561 */       if (neg != null) {
/* 562 */         result.add(neg);
/*     */       }
/* 564 */       Object3D pos = createPositiveArea(xcross, base, x1, y1, base, z, range, color, openingFace, closingFace);
/*     */       
/* 566 */       if (pos != null) {
/* 567 */         result.add(pos);
/*     */       }
/*     */     } 
/* 570 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private double fraction(double x, double x0, double x1) {
/* 584 */     double dist = x - x0;
/* 585 */     double length = x1 - x0;
/* 586 */     return dist / length;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Object3D createPositiveArea(double wx0, double wy0, double wx1, double wy1, double wbase, double wz, Range range, Color color, boolean openingFace, boolean closingFace) {
/* 617 */     if (!range.intersects(wy0, wbase) && !range.intersects(wy1, wbase)) {
/* 618 */       return null;
/*     */     }
/* 620 */     double wy00 = range.peggedValue(wy0);
/* 621 */     double wy11 = range.peggedValue(wy1);
/* 622 */     double wbb = range.peggedValue(wbase);
/*     */     
/* 624 */     double wx00 = wx0;
/* 625 */     if (wy0 < range.getMin()) {
/* 626 */       wx00 = wx0 + (wx1 - wx0) * fraction(wy00, wy0, wy1);
/*     */     }
/* 628 */     double wx11 = wx1;
/* 629 */     if (wy1 < range.getMin()) {
/* 630 */       wx11 = wx1 - (wx1 - wx0) * fraction(wy11, wy1, wy0);
/*     */     }
/* 632 */     double wx22 = Double.NaN;
/* 633 */     boolean p2required = Utils2D.spans(range.getMax(), wy0, wy1);
/* 634 */     if (p2required) {
/* 635 */       wx22 = wx0 + (wx1 - wx0) * fraction(range.getMax(), wy0, wy1);
/*     */     }
/*     */     
/* 638 */     double delta = this.depth / 2.0D;
/*     */ 
/*     */     
/* 641 */     Object3D obj = new Object3D(color, true);
/* 642 */     obj.addVertex(wx00, wbb, wz - delta);
/* 643 */     obj.addVertex(wx00, wbb, wz + delta);
/* 644 */     boolean leftSide = false;
/* 645 */     if (Math.abs(wy00 - wbb) > 0.001D) {
/* 646 */       leftSide = true;
/* 647 */       obj.addVertex(wx00, wy00, wz - delta);
/* 648 */       obj.addVertex(wx00, wy00, wz + delta);
/*     */     } 
/* 650 */     if (p2required) {
/* 651 */       obj.addVertex(wx22, range.getMax(), wz - delta);
/* 652 */       obj.addVertex(wx22, range.getMax(), wz + delta);
/*     */     } 
/* 654 */     obj.addVertex(wx11, wy11, wz - delta);
/* 655 */     obj.addVertex(wx11, wy11, wz + delta);
/* 656 */     boolean rightSide = false;
/* 657 */     if (Math.abs(wy11 - wbb) > 0.001D) {
/* 658 */       rightSide = true;
/* 659 */       obj.addVertex(wx11, wbb, wz - delta);
/* 660 */       obj.addVertex(wx11, wbb, wz + delta);
/*     */     } 
/* 662 */     int vertices = obj.getVertexCount();
/*     */     
/* 664 */     if (vertices == 10) {
/* 665 */       obj.addFace(new int[] { 0, 2, 4, 6, 8 });
/* 666 */       obj.addFace(new int[] { 1, 9, 7, 5, 3 });
/* 667 */       obj.addFace(new int[] { 0, 8, 9, 1 });
/* 668 */       obj.addFace(new int[] { 2, 3, 5, 4 });
/* 669 */       obj.addFace(new int[] { 4, 5, 7, 6 });
/* 670 */       if (openingFace) {
/* 671 */         obj.addFace(new int[] { 0, 1, 3, 2 });
/*     */       }
/* 673 */       if (closingFace) {
/* 674 */         obj.addFace(new int[] { 6, 7, 9, 8 });
/*     */       }
/* 676 */     } else if (vertices == 8) {
/* 677 */       obj.addFace(new int[] { 0, 2, 4, 6 });
/* 678 */       obj.addFace(new int[] { 7, 5, 3, 1 });
/* 679 */       if (!leftSide) {
/* 680 */         obj.addFace(new int[] { 0, 1, 3, 2 });
/*     */       }
/* 682 */       obj.addFace(new int[] { 2, 3, 5, 4 });
/* 683 */       if (!rightSide) {
/* 684 */         obj.addFace(new int[] { 4, 5, 7, 6 });
/*     */       }
/* 686 */       obj.addFace(new int[] { 1, 0, 6, 7 });
/* 687 */       if (openingFace) {
/* 688 */         obj.addFace(new int[] { 0, 1, 3, 2 });
/*     */       }
/* 690 */       if (closingFace) {
/* 691 */         obj.addFace(new int[] { 4, 5, 7, 6 });
/*     */       }
/* 693 */     } else if (vertices == 6) {
/* 694 */       obj.addFace(new int[] { 0, 2, 4 });
/* 695 */       obj.addFace(new int[] { 5, 3, 1 });
/* 696 */       if (leftSide) {
/* 697 */         obj.addFace(new int[] { 3, 5, 4, 2 });
/* 698 */         if (openingFace) {
/* 699 */           obj.addFace(new int[] { 0, 1, 3, 2 });
/*     */         }
/*     */       } else {
/* 702 */         obj.addFace(new int[] { 0, 1, 3, 2 });
/* 703 */         if (closingFace) {
/* 704 */           obj.addFace(new int[] { 2, 3, 5, 4 });
/*     */         }
/*     */       } 
/* 707 */       obj.addFace(new int[] { 0, 4, 5, 1 });
/*     */     } else {
/* 709 */       obj.addFace(new int[] { 0, 1, 3, 2 });
/* 710 */       obj.addFace(new int[] { 2, 3, 1, 0 });
/*     */     } 
/* 712 */     return obj;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Object3D createNegativeArea(double wx0, double wy0, double wx1, double wy1, double wbase, double wz, Range range, Color color, boolean openingFace, boolean closingFace) {
/* 736 */     if (!range.intersects(wy0, wbase) && !range.intersects(wy1, wbase)) {
/* 737 */       return null;
/*     */     }
/* 739 */     double wy00 = range.peggedValue(wy0);
/* 740 */     double wy11 = range.peggedValue(wy1);
/* 741 */     double wbb = range.peggedValue(wbase);
/*     */     
/* 743 */     double wx00 = wx0;
/* 744 */     if (wy0 > range.getMax()) {
/* 745 */       wx00 = wx0 + (wx1 - wx0) * fraction(wy00, wy0, wy1);
/*     */     }
/* 747 */     double wx11 = wx1;
/* 748 */     if (wy1 > range.getMax()) {
/* 749 */       wx11 = wx1 - (wx1 - wx0) * fraction(wy11, wy1, wy0);
/*     */     }
/* 751 */     double wx22 = (wx00 + wx11) / 2.0D;
/* 752 */     boolean p2required = Utils2D.spans(range.getMin(), wy0, wy1);
/* 753 */     if (p2required) {
/* 754 */       wx22 = wx0 + (wx1 - wx0) * fraction(range.getMin(), wy0, wy1);
/*     */     }
/*     */     
/* 757 */     double delta = this.depth / 2.0D;
/*     */ 
/*     */     
/* 760 */     Object3D obj = new Object3D(color, true);
/* 761 */     obj.addVertex(wx00, wbb, wz - delta);
/* 762 */     obj.addVertex(wx00, wbb, wz + delta);
/* 763 */     boolean leftSide = false;
/* 764 */     if (Math.abs(wy00 - wbb) > 0.001D) {
/* 765 */       leftSide = true;
/* 766 */       obj.addVertex(wx00, wy00, wz - delta);
/* 767 */       obj.addVertex(wx00, wy00, wz + delta);
/*     */     } 
/* 769 */     if (p2required) {
/* 770 */       obj.addVertex(wx22, range.getMin(), wz - delta);
/* 771 */       obj.addVertex(wx22, range.getMin(), wz + delta);
/*     */     } 
/* 773 */     obj.addVertex(wx11, wy11, wz - delta);
/* 774 */     obj.addVertex(wx11, wy11, wz + delta);
/* 775 */     boolean rightSide = false;
/* 776 */     if (Math.abs(wy11 - wbb) > 0.001D) {
/* 777 */       obj.addVertex(wx11, wbb, wz - delta);
/* 778 */       obj.addVertex(wx11, wbb, wz + delta);
/*     */     } 
/* 780 */     int vertices = obj.getVertexCount();
/* 781 */     if (vertices == 10) {
/* 782 */       obj.addFace(new int[] { 8, 6, 4, 2, 0 });
/* 783 */       obj.addFace(new int[] { 1, 3, 5, 7, 9 });
/* 784 */       obj.addFace(new int[] { 1, 9, 8, 0 });
/* 785 */       obj.addFace(new int[] { 4, 5, 3, 2 });
/* 786 */       obj.addFace(new int[] { 6, 7, 5, 4 });
/* 787 */       if (openingFace) {
/* 788 */         obj.addFace(new int[] { 2, 3, 1, 0 });
/*     */       }
/* 790 */       if (closingFace) {
/* 791 */         obj.addFace(new int[] { 8, 9, 7, 6 });
/*     */       }
/* 793 */     } else if (vertices == 8) {
/* 794 */       obj.addFace(new int[] { 2, 0, 6, 4 });
/* 795 */       obj.addFace(new int[] { 1, 3, 5, 7 });
/* 796 */       obj.addFace(new int[] { 0, 1, 7, 6 });
/* 797 */       if (!leftSide) {
/* 798 */         obj.addFace(new int[] { 2, 3, 1, 0 });
/*     */       }
/* 800 */       obj.addFace(new int[] { 3, 2, 4, 5 });
/* 801 */       if (!rightSide) {
/* 802 */         obj.addFace(new int[] { 6, 7, 5, 4 });
/*     */       }
/* 804 */       if (openingFace) {
/* 805 */         obj.addFace(new int[] { 1, 0, 2, 3 });
/*     */       }
/* 807 */       if (closingFace) {
/* 808 */         obj.addFace(new int[] { 5, 4, 6, 7 });
/*     */       }
/* 810 */     } else if (vertices == 6) {
/* 811 */       obj.addFace(new int[] { 4, 2, 0 });
/* 812 */       obj.addFace(new int[] { 1, 3, 5 });
/* 813 */       if (leftSide) {
/* 814 */         obj.addFace(new int[] { 4, 5, 3, 2 });
/* 815 */         if (openingFace) {
/* 816 */           obj.addFace(new int[] { 1, 0, 2, 3 });
/*     */         }
/*     */       } else {
/* 819 */         obj.addFace(new int[] { 2, 3, 1, 0 });
/* 820 */         if (closingFace) {
/* 821 */           obj.addFace(new int[] { 3, 2, 4, 5 });
/*     */         }
/*     */       } 
/* 824 */       obj.addFace(new int[] { 0, 1, 5, 4 });
/*     */     } else {
/* 826 */       obj.addFace(new int[] { 0, 1, 3, 2 });
/* 827 */       obj.addFace(new int[] { 2, 3, 1, 0 });
/*     */     } 
/* 829 */     return obj;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 841 */     if (obj == this) {
/* 842 */       return true;
/*     */     }
/* 844 */     if (!(obj instanceof AreaRenderer3D)) {
/* 845 */       return false;
/*     */     }
/* 847 */     AreaRenderer3D that = (AreaRenderer3D)obj;
/* 848 */     if (this.base != that.base) {
/* 849 */       return false;
/*     */     }
/* 851 */     if (!ObjectUtils.equals(this.baseColor, that.baseColor)) {
/* 852 */       return false;
/*     */     }
/* 854 */     if (this.depth != that.depth) {
/* 855 */       return false;
/*     */     }
/* 857 */     return super.equals(obj);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/renderer/category/AreaRenderer3D.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */