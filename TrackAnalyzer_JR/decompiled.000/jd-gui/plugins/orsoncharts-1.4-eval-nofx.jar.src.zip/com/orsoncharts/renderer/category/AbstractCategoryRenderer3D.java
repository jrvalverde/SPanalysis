/*     */ package com.orsoncharts.renderer.category;
/*     */ 
/*     */ import com.orsoncharts.Range;
/*     */ import com.orsoncharts.data.DataUtils;
/*     */ import com.orsoncharts.data.Values3D;
/*     */ import com.orsoncharts.graphics3d.Offset3D;
/*     */ import com.orsoncharts.label.CategoryItemLabelGenerator;
/*     */ import com.orsoncharts.plot.CategoryPlot3D;
/*     */ import com.orsoncharts.renderer.AbstractRenderer3D;
/*     */ import com.orsoncharts.util.ArgChecks;
/*     */ import com.orsoncharts.util.ObjectUtils;
/*     */ import java.awt.Color;
/*     */ import java.io.Serializable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractCategoryRenderer3D
/*     */   extends AbstractRenderer3D
/*     */   implements CategoryRenderer3D, Serializable
/*     */ {
/*     */   private CategoryPlot3D plot;
/*  56 */   private CategoryColorSource colorSource = new StandardCategoryColorSource();
/*  57 */   private CategoryItemLabelGenerator itemLabelGenerator = null;
/*  58 */   private Offset3D itemLabelOffsets = new Offset3D(0.0D, 0.05D, 1.1D);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CategoryPlot3D getPlot() {
/*  68 */     return this.plot;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPlot(CategoryPlot3D plot) {
/*  80 */     this.plot = plot;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CategoryColorSource getColorSource() {
/*  92 */     return this.colorSource;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setColorSource(CategoryColorSource colorSource) {
/* 103 */     ArgChecks.nullNotPermitted(colorSource, "colorSource");
/* 104 */     this.colorSource = colorSource;
/* 105 */     fireChangeEvent(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setColors(Color... colors) {
/* 120 */     setColorSource(new StandardCategoryColorSource(colors));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CategoryItemLabelGenerator getItemLabelGenerator() {
/* 132 */     return this.itemLabelGenerator;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setItemLabelGenerator(CategoryItemLabelGenerator generator) {
/* 144 */     this.itemLabelGenerator = generator;
/* 145 */     fireChangeEvent(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Offset3D getItemLabelOffsets() {
/* 156 */     return this.itemLabelOffsets;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setItemLabelOffsets(Offset3D offsets) {
/* 168 */     ArgChecks.nullNotPermitted(offsets, "offsets");
/* 169 */     this.itemLabelOffsets = offsets;
/* 170 */     fireChangeEvent(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Range findValueRange(Values3D<? extends Number> data) {
/* 183 */     return DataUtils.findValueRange(data);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 195 */     if (obj == this) {
/* 196 */       return true;
/*     */     }
/* 198 */     if (!(obj instanceof AbstractCategoryRenderer3D)) {
/* 199 */       return false;
/*     */     }
/* 201 */     AbstractCategoryRenderer3D that = (AbstractCategoryRenderer3D)obj;
/* 202 */     if (!this.colorSource.equals(that.colorSource)) {
/* 203 */       return false;
/*     */     }
/* 205 */     if (!ObjectUtils.equals(this.itemLabelGenerator, that.itemLabelGenerator))
/*     */     {
/* 207 */       return false;
/*     */     }
/* 209 */     if (!this.itemLabelOffsets.equals(that.itemLabelOffsets)) {
/* 210 */       return false;
/*     */     }
/* 212 */     return super.equals(obj);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/renderer/category/AbstractCategoryRenderer3D.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */