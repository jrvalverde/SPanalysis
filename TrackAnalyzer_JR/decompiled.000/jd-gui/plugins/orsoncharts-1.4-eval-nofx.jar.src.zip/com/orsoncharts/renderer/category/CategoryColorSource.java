package com.orsoncharts.renderer.category;

import java.awt.Color;

public interface CategoryColorSource {
  Color getColor(int paramInt1, int paramInt2, int paramInt3);
  
  Color getLegendColor(int paramInt);
  
  void style(Color... paramVarArgs);
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/renderer/category/CategoryColorSource.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */