package com.orsoncharts.renderer.category;

import com.orsoncharts.Range;
import com.orsoncharts.data.Values3D;
import com.orsoncharts.data.category.CategoryDataset3D;
import com.orsoncharts.graphics3d.Dimension3D;
import com.orsoncharts.graphics3d.World;
import com.orsoncharts.plot.CategoryPlot3D;
import com.orsoncharts.renderer.Renderer3D;
import java.awt.Color;

public interface CategoryRenderer3D extends Renderer3D {
  CategoryPlot3D getPlot();
  
  void setPlot(CategoryPlot3D paramCategoryPlot3D);
  
  CategoryColorSource getColorSource();
  
  void setColorSource(CategoryColorSource paramCategoryColorSource);
  
  void setColors(Color... paramVarArgs);
  
  Range findValueRange(Values3D<? extends Number> paramValues3D);
  
  void composeItem(CategoryDataset3D paramCategoryDataset3D, int paramInt1, int paramInt2, int paramInt3, World paramWorld, Dimension3D paramDimension3D, double paramDouble1, double paramDouble2, double paramDouble3);
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/renderer/category/CategoryRenderer3D.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */