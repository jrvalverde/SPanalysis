/*     */ package com.orsoncharts.renderer.xyz;
/*     */ 
/*     */ import com.orsoncharts.Range;
/*     */ import com.orsoncharts.axis.ValueAxis3D;
/*     */ import com.orsoncharts.data.DataUtils;
/*     */ import com.orsoncharts.data.xyz.XYZDataset;
/*     */ import com.orsoncharts.graphics3d.Dimension3D;
/*     */ import com.orsoncharts.graphics3d.Object3D;
/*     */ import com.orsoncharts.graphics3d.World;
/*     */ import com.orsoncharts.plot.XYZPlot;
/*     */ import com.orsoncharts.util.ObjectUtils;
/*     */ import java.awt.Color;
/*     */ import java.io.Serializable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BarXYZRenderer
/*     */   extends AbstractXYZRenderer
/*     */   implements XYZRenderer, Serializable
/*     */ {
/*  76 */   private double base = 0.0D;
/*  77 */   private double barXWidth = 0.8D;
/*  78 */   private double barZWidth = 0.8D;
/*  79 */   private XYZColorSource baseColorSource = new StandardXYZColorSource(new Color[] { Color.WHITE });
/*  80 */   private XYZColorSource topColorSource = new StandardXYZColorSource(new Color[] { Color.BLACK });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getBase() {
/*  91 */     return this.base;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBase(double base) {
/* 101 */     this.base = base;
/* 102 */     fireChangeEvent(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getBarXWidth() {
/* 112 */     return this.barXWidth;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBarXWidth(double width) {
/* 122 */     this.barXWidth = width;
/* 123 */     fireChangeEvent(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getBarZWidth() {
/* 133 */     return this.barZWidth;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBarZWidth(double width) {
/* 143 */     this.barZWidth = width;
/* 144 */     fireChangeEvent(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XYZColorSource getBaseColorSource() {
/* 158 */     return this.baseColorSource;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBaseColorSource(XYZColorSource source) {
/* 176 */     this.baseColorSource = source;
/* 177 */     fireChangeEvent(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XYZColorSource getTopColorSource() {
/* 191 */     return this.topColorSource;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTopColorSource(XYZColorSource source) {
/* 205 */     this.topColorSource = source;
/* 206 */     fireChangeEvent(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Range findXRange(XYZDataset dataset) {
/* 220 */     Range xRange = DataUtils.findXRange(dataset);
/* 221 */     if (xRange == null) {
/* 222 */       return null;
/*     */     }
/* 224 */     double delta = this.barXWidth / 2.0D;
/* 225 */     return new Range(xRange.getMin() - delta, xRange.getMax() + delta);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Range findYRange(XYZDataset dataset) {
/* 239 */     return DataUtils.findYRange(dataset, this.base);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Range findZRange(XYZDataset dataset) {
/* 253 */     Range zRange = DataUtils.findZRange(dataset);
/* 254 */     if (zRange == null) {
/* 255 */       return null;
/*     */     }
/* 257 */     double delta = this.barZWidth / 2.0D;
/* 258 */     return new Range(zRange.getMin() - delta, zRange.getMax() + delta);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void composeItem(XYZDataset dataset, int series, int item, World world, Dimension3D dimensions, double xOffset, double yOffset, double zOffset) {
/* 278 */     XYZPlot plot = getPlot();
/* 279 */     ValueAxis3D valueAxis3D1 = plot.getXAxis();
/* 280 */     ValueAxis3D valueAxis3D2 = plot.getYAxis();
/* 281 */     ValueAxis3D valueAxis3D3 = plot.getZAxis();
/* 282 */     double x = dataset.getX(series, item);
/* 283 */     double y = dataset.getY(series, item);
/* 284 */     double z = dataset.getZ(series, item);
/* 285 */     double xdelta = this.barXWidth / 2.0D;
/* 286 */     double zdelta = this.barZWidth / 2.0D;
/*     */     
/* 288 */     double x0 = valueAxis3D1.getRange().peggedValue(x - xdelta);
/* 289 */     double x1 = valueAxis3D1.getRange().peggedValue(x + xdelta);
/* 290 */     double z0 = valueAxis3D3.getRange().peggedValue(z - zdelta);
/* 291 */     double z1 = valueAxis3D3.getRange().peggedValue(z + zdelta);
/* 292 */     if (x1 <= x0 || z1 <= z0) {
/*     */       return;
/*     */     }
/* 295 */     double ylow = Math.min(this.base, y);
/* 296 */     double yhigh = Math.max(this.base, y);
/* 297 */     Range range = valueAxis3D2.getRange();
/* 298 */     if (!range.intersects(ylow, yhigh)) {
/*     */       return;
/*     */     }
/* 301 */     double ybase = range.peggedValue(ylow);
/* 302 */     double ytop = range.peggedValue(yhigh);
/* 303 */     boolean inverted = (this.base > y);
/*     */     
/* 305 */     double wx0 = valueAxis3D1.translateToWorld(x0, dimensions.getWidth());
/* 306 */     double wx1 = valueAxis3D1.translateToWorld(x1, dimensions.getWidth());
/* 307 */     double wy0 = valueAxis3D2.translateToWorld(ybase, dimensions.getHeight());
/* 308 */     double wy1 = valueAxis3D2.translateToWorld(ytop, dimensions.getHeight());
/* 309 */     double wz0 = valueAxis3D3.translateToWorld(z0, dimensions.getDepth());
/* 310 */     double wz1 = valueAxis3D3.translateToWorld(z1, dimensions.getDepth());
/*     */     
/* 312 */     Color color = getColorSource().getColor(series, item);
/* 313 */     Color baseColor = null;
/* 314 */     if (this.baseColorSource != null && !range.contains(this.base)) {
/* 315 */       baseColor = this.baseColorSource.getColor(series, item);
/*     */     }
/* 317 */     if (baseColor == null) {
/* 318 */       baseColor = color;
/*     */     }
/*     */     
/* 321 */     Color topColor = null;
/* 322 */     if (this.topColorSource != null && !range.contains(y)) {
/* 323 */       topColor = this.topColorSource.getColor(series, item);
/*     */     }
/* 325 */     if (topColor == null) {
/* 326 */       topColor = color;
/*     */     }
/*     */     
/* 329 */     Object3D bar = Object3D.createBar(wx1 - wx0, wz1 - wz0, (wx0 + wx1) / 2.0D + xOffset, wy1 + yOffset, (wz0 + wz1) / 2.0D + zOffset, wy0 + yOffset, color, baseColor, topColor, inverted);
/*     */ 
/*     */ 
/*     */     
/* 333 */     world.add(bar);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 345 */     if (obj == this) {
/* 346 */       return true;
/*     */     }
/* 348 */     if (!(obj instanceof BarXYZRenderer)) {
/* 349 */       return false;
/*     */     }
/* 351 */     BarXYZRenderer that = (BarXYZRenderer)obj;
/* 352 */     if (this.base != that.base) {
/* 353 */       return false;
/*     */     }
/* 355 */     if (this.barXWidth != that.barXWidth) {
/* 356 */       return false;
/*     */     }
/* 358 */     if (this.barZWidth != that.barZWidth) {
/* 359 */       return false;
/*     */     }
/* 361 */     if (!ObjectUtils.equals(this.baseColorSource, that.baseColorSource)) {
/* 362 */       return false;
/*     */     }
/* 364 */     if (!ObjectUtils.equals(this.topColorSource, that.topColorSource)) {
/* 365 */       return false;
/*     */     }
/* 367 */     return super.equals(obj);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/renderer/xyz/BarXYZRenderer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */