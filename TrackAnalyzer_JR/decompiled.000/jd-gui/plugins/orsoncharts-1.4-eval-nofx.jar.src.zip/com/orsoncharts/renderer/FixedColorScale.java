/*    */ package com.orsoncharts.renderer;
/*    */ 
/*    */ import com.orsoncharts.Range;
/*    */ import com.orsoncharts.util.ArgChecks;
/*    */ import java.awt.Color;
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FixedColorScale
/*    */   implements ColorScale, Serializable
/*    */ {
/*    */   private Color color;
/*    */   private Range range;
/*    */   
/*    */   public FixedColorScale(Color color) {
/* 52 */     ArgChecks.nullNotPermitted(color, "color");
/* 53 */     this.color = color;
/* 54 */     this.range = new Range(0.0D, 1.0D);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Range getRange() {
/* 64 */     return this.range;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Color valueToColor(double value) {
/* 76 */     return this.color;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean equals(Object obj) {
/* 88 */     if (obj == this) {
/* 89 */       return true;
/*    */     }
/* 91 */     if (!(obj instanceof FixedColorScale)) {
/* 92 */       return false;
/*    */     }
/* 94 */     FixedColorScale that = (FixedColorScale)obj;
/* 95 */     if (!this.color.equals(that.color)) {
/* 96 */       return false;
/*    */     }
/* 98 */     return true;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/renderer/FixedColorScale.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */