/*    */ package com.orsoncharts.renderer;
/*    */ 
/*    */ import java.util.EventObject;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Renderer3DChangeEvent
/*    */   extends EventObject
/*    */ {
/*    */   private Renderer3D renderer;
/*    */   private boolean requiresWorldUpdate;
/*    */   
/*    */   public Renderer3DChangeEvent(Renderer3D renderer, boolean requiresWorldUpdate) {
/* 45 */     this(renderer, renderer, requiresWorldUpdate);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Renderer3DChangeEvent(Object source, Renderer3D renderer, boolean requiresWorldUpdate) {
/* 58 */     super(source);
/* 59 */     this.renderer = renderer;
/* 60 */     this.requiresWorldUpdate = requiresWorldUpdate;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Renderer3D getRenderer() {
/* 69 */     return this.renderer;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean requiresWorldUpdate() {
/* 81 */     return this.requiresWorldUpdate;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/renderer/Renderer3DChangeEvent.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */