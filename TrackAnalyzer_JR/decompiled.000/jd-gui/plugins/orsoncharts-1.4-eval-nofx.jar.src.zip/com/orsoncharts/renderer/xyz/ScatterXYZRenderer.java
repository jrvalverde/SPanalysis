/*     */ package com.orsoncharts.renderer.xyz;
/*     */ 
/*     */ import com.orsoncharts.axis.ValueAxis3D;
/*     */ import com.orsoncharts.data.xyz.XYZDataset;
/*     */ import com.orsoncharts.data.xyz.XYZItemKey;
/*     */ import com.orsoncharts.graphics3d.Dimension3D;
/*     */ import com.orsoncharts.graphics3d.Object3D;
/*     */ import com.orsoncharts.graphics3d.Offset3D;
/*     */ import com.orsoncharts.graphics3d.World;
/*     */ import com.orsoncharts.plot.XYZPlot;
/*     */ import com.orsoncharts.util.ArgChecks;
/*     */ import java.awt.Color;
/*     */ import java.io.Serializable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ScatterXYZRenderer
/*     */   extends AbstractXYZRenderer
/*     */   implements XYZRenderer, Serializable
/*     */ {
/*  63 */   private double size = 0.1D;
/*  64 */   private Offset3D itemLabelOffsetPercent = new Offset3D(0.0D, 1.0D, 0.0D);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getSize() {
/*  74 */     return this.size;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSize(double size) {
/*  85 */     ArgChecks.positiveRequired(size, "size");
/*  86 */     this.size = size;
/*  87 */     fireChangeEvent(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Offset3D getItemLabelOffsetPercent() {
/*  98 */     return this.itemLabelOffsetPercent;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setItemLabelOffsetPercent(Offset3D offset) {
/* 110 */     ArgChecks.nullNotPermitted(offset, "offset");
/* 111 */     this.itemLabelOffsetPercent = offset;
/* 112 */     fireChangeEvent(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void composeItem(XYZDataset dataset, int series, int item, World world, Dimension3D dimensions, double xOffset, double yOffset, double zOffset) {
/* 135 */     double x = dataset.getX(series, item);
/* 136 */     double y = dataset.getY(series, item);
/* 137 */     double z = dataset.getZ(series, item);
/*     */     
/* 139 */     XYZPlot plot = getPlot();
/* 140 */     ValueAxis3D valueAxis3D1 = plot.getXAxis();
/* 141 */     ValueAxis3D valueAxis3D2 = plot.getYAxis();
/* 142 */     ValueAxis3D valueAxis3D3 = plot.getZAxis();
/*     */     
/* 144 */     double delta = this.size / 2.0D;
/* 145 */     Dimension3D dim = plot.getDimensions();
/* 146 */     double xx = valueAxis3D1.translateToWorld(x, dim.getWidth());
/* 147 */     double xmin = Math.max(0.0D, xx - delta);
/* 148 */     double xmax = Math.min(dim.getWidth(), xx + delta);
/* 149 */     double yy = valueAxis3D2.translateToWorld(y, dim.getHeight());
/* 150 */     double ymin = Math.max(0.0D, yy - delta);
/* 151 */     double ymax = Math.min(dim.getHeight(), yy + delta);
/* 152 */     double zz = valueAxis3D3.translateToWorld(z, dim.getDepth());
/* 153 */     double zmin = Math.max(0.0D, zz - delta);
/* 154 */     double zmax = Math.min(dim.getDepth(), zz + delta);
/* 155 */     if (xmin >= xmax || ymin >= ymax || zmin >= zmax) {
/*     */       return;
/*     */     }
/* 158 */     Color color = getColorSource().getColor(series, item);
/* 159 */     double cx = (xmax + xmin) / 2.0D + xOffset;
/* 160 */     double cy = (ymax + ymin) / 2.0D + yOffset;
/* 161 */     double cz = (zmax + zmin) / 2.0D + zOffset;
/* 162 */     Object3D cube = Object3D.createBox(cx, xmax - xmin, cy, ymax - ymin, cz, zmax - zmin, color);
/*     */     
/* 164 */     Comparable<?> seriesKey = dataset.getSeriesKey(series);
/* 165 */     XYZItemKey itemKey = new XYZItemKey(seriesKey, item);
/* 166 */     cube.setProperty("key", itemKey);
/* 167 */     world.add(cube);
/*     */     
/* 169 */     if (getItemLabelGenerator() != null) {
/* 170 */       String label = getItemLabelGenerator().generateItemLabel(dataset, seriesKey, item);
/*     */       
/* 172 */       if (label != null) {
/* 173 */         double dx = this.itemLabelOffsetPercent.getDX() * this.size;
/* 174 */         double dy = this.itemLabelOffsetPercent.getDY() * this.size;
/* 175 */         double dz = this.itemLabelOffsetPercent.getDZ() * this.size;
/* 176 */         Object3D labelObj = Object3D.createLabelObject(label, 
/* 177 */             getItemLabelFont(), getItemLabelColor(), 
/* 178 */             getItemLabelBackgroundColor(), cx + dx, cy + dy, cz + dz, false, true);
/*     */         
/* 180 */         labelObj.setProperty("key", itemKey);
/* 181 */         world.add(labelObj);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 196 */     if (obj == this) {
/* 197 */       return true;
/*     */     }
/* 199 */     if (!(obj instanceof ScatterXYZRenderer)) {
/* 200 */       return false;
/*     */     }
/* 202 */     ScatterXYZRenderer that = (ScatterXYZRenderer)obj;
/* 203 */     if (this.size != that.size) {
/* 204 */       return false;
/*     */     }
/* 206 */     if (!this.itemLabelOffsetPercent.equals(that.itemLabelOffsetPercent)) {
/* 207 */       return false;
/*     */     }
/* 209 */     return super.equals(obj);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/renderer/xyz/ScatterXYZRenderer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */