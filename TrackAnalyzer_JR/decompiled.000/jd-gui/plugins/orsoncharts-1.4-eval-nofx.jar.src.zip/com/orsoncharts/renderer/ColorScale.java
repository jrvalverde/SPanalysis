package com.orsoncharts.renderer;

import com.orsoncharts.Range;
import java.awt.Color;

public interface ColorScale {
  Range getRange();
  
  Color valueToColor(double paramDouble);
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/renderer/ColorScale.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */