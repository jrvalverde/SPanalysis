/*    */ package com.orsoncharts.renderer;
/*    */ 
/*    */ import com.orsoncharts.ChartElement;
/*    */ import java.awt.Color;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface Renderer3D
/*    */   extends ChartElement
/*    */ {
/* 44 */   public static final Color TRANSPARENT_COLOR = new Color(0, 0, 0, 0);
/*    */   
/*    */   void addChangeListener(Renderer3DChangeListener paramRenderer3DChangeListener);
/*    */   
/*    */   void removeChangeListener(Renderer3DChangeListener paramRenderer3DChangeListener);
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/renderer/Renderer3D.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */