/*     */ package com.orsoncharts.renderer.xyz;
/*     */ 
/*     */ import com.orsoncharts.Range;
/*     */ import com.orsoncharts.data.DataUtils;
/*     */ import com.orsoncharts.data.xyz.XYZDataset;
/*     */ import com.orsoncharts.graphics3d.Dimension3D;
/*     */ import com.orsoncharts.graphics3d.World;
/*     */ import com.orsoncharts.label.XYZItemLabelGenerator;
/*     */ import com.orsoncharts.plot.XYZPlot;
/*     */ import com.orsoncharts.renderer.AbstractRenderer3D;
/*     */ import com.orsoncharts.renderer.ComposeType;
/*     */ import com.orsoncharts.util.ArgChecks;
/*     */ import com.orsoncharts.util.ObjectUtils;
/*     */ import java.awt.Color;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AbstractXYZRenderer
/*     */   extends AbstractRenderer3D
/*     */ {
/*     */   private XYZPlot plot;
/*  48 */   private XYZColorSource colorSource = new StandardXYZColorSource();
/*  49 */   private XYZItemLabelGenerator itemLabelGenerator = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XYZPlot getPlot() {
/*  58 */     return this.plot;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPlot(XYZPlot plot) {
/*  67 */     this.plot = plot;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XYZItemLabelGenerator getItemLabelGenerator() {
/*  80 */     return this.itemLabelGenerator;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setItemLabelGenerator(XYZItemLabelGenerator generator) {
/*  93 */     this.itemLabelGenerator = generator;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ComposeType getComposeType() {
/* 110 */     return ComposeType.PER_ITEM;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void composeAll(XYZPlot plot, World world, Dimension3D dimensions, double xOffset, double yOffset, double zOffset) {
/* 128 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XYZColorSource getColorSource() {
/* 138 */     return this.colorSource;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setColorSource(XYZColorSource colorSource) {
/* 148 */     ArgChecks.nullNotPermitted(colorSource, "colorSource");
/* 149 */     this.colorSource = colorSource;
/* 150 */     fireChangeEvent(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setColors(Color... colors) {
/* 165 */     setColorSource(new StandardXYZColorSource(colors));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Range findXRange(XYZDataset dataset) {
/* 177 */     return DataUtils.findXRange(dataset);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Range findYRange(XYZDataset dataset) {
/* 189 */     return DataUtils.findYRange(dataset);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Range findZRange(XYZDataset dataset) {
/* 201 */     return DataUtils.findZRange(dataset);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 213 */     if (obj == this) {
/* 214 */       return true;
/*     */     }
/* 216 */     if (!(obj instanceof AbstractXYZRenderer)) {
/* 217 */       return false;
/*     */     }
/* 219 */     AbstractXYZRenderer that = (AbstractXYZRenderer)obj;
/* 220 */     if (!this.colorSource.equals(that.colorSource)) {
/* 221 */       return false;
/*     */     }
/* 223 */     if (!ObjectUtils.equals(this.itemLabelGenerator, that.itemLabelGenerator))
/*     */     {
/* 225 */       return false;
/*     */     }
/* 227 */     return super.equals(obj);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsoncharts-1.4-eval-nofx.jar!/com/orsoncharts/renderer/xyz/AbstractXYZRenderer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */