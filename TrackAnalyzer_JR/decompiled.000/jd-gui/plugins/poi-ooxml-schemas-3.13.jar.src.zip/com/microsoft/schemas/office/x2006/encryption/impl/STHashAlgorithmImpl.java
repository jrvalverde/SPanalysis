package com.microsoft.schemas.office.x2006.encryption.impl;

import com.microsoft.schemas.office.x2006.encryption.STHashAlgorithm;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.impl.values.JavaStringEnumerationHolderEx;

public class STHashAlgorithmImpl extends JavaStringEnumerationHolderEx implements STHashAlgorithm {
  public STHashAlgorithmImpl(SchemaType paramSchemaType) {
    super(paramSchemaType, false);
  }
  
  protected STHashAlgorithmImpl(SchemaType paramSchemaType, boolean paramBoolean) {
    super(paramSchemaType, paramBoolean);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/poi-ooxml-schemas-3.13.jar!/com/microsoft/schemas/office/x2006/encryption/impl/STHashAlgorithmImpl.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */