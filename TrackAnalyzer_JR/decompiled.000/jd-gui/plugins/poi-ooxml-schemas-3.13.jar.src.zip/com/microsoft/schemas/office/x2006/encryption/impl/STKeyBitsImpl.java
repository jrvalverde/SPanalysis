package com.microsoft.schemas.office.x2006.encryption.impl;

import com.microsoft.schemas.office.x2006.encryption.STKeyBits;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.impl.values.JavaLongHolderEx;

public class STKeyBitsImpl extends JavaLongHolderEx implements STKeyBits {
  public STKeyBitsImpl(SchemaType paramSchemaType) {
    super(paramSchemaType, false);
  }
  
  protected STKeyBitsImpl(SchemaType paramSchemaType, boolean paramBoolean) {
    super(paramSchemaType, paramBoolean);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/poi-ooxml-schemas-3.13.jar!/com/microsoft/schemas/office/x2006/encryption/impl/STKeyBitsImpl.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */