package org.etsi.uri.x01903.v13;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.net.URL;
import java.util.List;
import javax.xml.stream.XMLStreamReader;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.XmlBeans;
import org.apache.xmlbeans.XmlException;
import org.apache.xmlbeans.XmlObject;
import org.apache.xmlbeans.XmlOptions;
import org.apache.xmlbeans.xml.stream.XMLInputStream;
import org.apache.xmlbeans.xml.stream.XMLStreamException;
import org.w3c.dom.Node;

public interface CertIDListType extends XmlObject {
  public static final SchemaType type = (SchemaType)XmlBeans.typeSystemForClassLoader(CertIDListType.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s0B482D0B338CC9641C1543C3510577FE").resolveHandle("certidlisttype488btype");
  
  List<CertIDType> getCertList();
  
  CertIDType[] getCertArray();
  
  CertIDType getCertArray(int paramInt);
  
  int sizeOfCertArray();
  
  void setCertArray(CertIDType[] paramArrayOfCertIDType);
  
  void setCertArray(int paramInt, CertIDType paramCertIDType);
  
  CertIDType insertNewCert(int paramInt);
  
  CertIDType addNewCert();
  
  void removeCert(int paramInt);
  
  public static final class Factory {
    public static CertIDListType newInstance() {
      return (CertIDListType)XmlBeans.getContextTypeLoader().newInstance(CertIDListType.type, null);
    }
    
    public static CertIDListType newInstance(XmlOptions param1XmlOptions) {
      return (CertIDListType)XmlBeans.getContextTypeLoader().newInstance(CertIDListType.type, param1XmlOptions);
    }
    
    public static CertIDListType parse(String param1String) throws XmlException {
      return (CertIDListType)XmlBeans.getContextTypeLoader().parse(param1String, CertIDListType.type, null);
    }
    
    public static CertIDListType parse(String param1String, XmlOptions param1XmlOptions) throws XmlException {
      return (CertIDListType)XmlBeans.getContextTypeLoader().parse(param1String, CertIDListType.type, param1XmlOptions);
    }
    
    public static CertIDListType parse(File param1File) throws XmlException, IOException {
      return (CertIDListType)XmlBeans.getContextTypeLoader().parse(param1File, CertIDListType.type, null);
    }
    
    public static CertIDListType parse(File param1File, XmlOptions param1XmlOptions) throws XmlException, IOException {
      return (CertIDListType)XmlBeans.getContextTypeLoader().parse(param1File, CertIDListType.type, param1XmlOptions);
    }
    
    public static CertIDListType parse(URL param1URL) throws XmlException, IOException {
      return (CertIDListType)XmlBeans.getContextTypeLoader().parse(param1URL, CertIDListType.type, null);
    }
    
    public static CertIDListType parse(URL param1URL, XmlOptions param1XmlOptions) throws XmlException, IOException {
      return (CertIDListType)XmlBeans.getContextTypeLoader().parse(param1URL, CertIDListType.type, param1XmlOptions);
    }
    
    public static CertIDListType parse(InputStream param1InputStream) throws XmlException, IOException {
      return (CertIDListType)XmlBeans.getContextTypeLoader().parse(param1InputStream, CertIDListType.type, null);
    }
    
    public static CertIDListType parse(InputStream param1InputStream, XmlOptions param1XmlOptions) throws XmlException, IOException {
      return (CertIDListType)XmlBeans.getContextTypeLoader().parse(param1InputStream, CertIDListType.type, param1XmlOptions);
    }
    
    public static CertIDListType parse(Reader param1Reader) throws XmlException, IOException {
      return (CertIDListType)XmlBeans.getContextTypeLoader().parse(param1Reader, CertIDListType.type, null);
    }
    
    public static CertIDListType parse(Reader param1Reader, XmlOptions param1XmlOptions) throws XmlException, IOException {
      return (CertIDListType)XmlBeans.getContextTypeLoader().parse(param1Reader, CertIDListType.type, param1XmlOptions);
    }
    
    public static CertIDListType parse(XMLStreamReader param1XMLStreamReader) throws XmlException {
      return (CertIDListType)XmlBeans.getContextTypeLoader().parse(param1XMLStreamReader, CertIDListType.type, null);
    }
    
    public static CertIDListType parse(XMLStreamReader param1XMLStreamReader, XmlOptions param1XmlOptions) throws XmlException {
      return (CertIDListType)XmlBeans.getContextTypeLoader().parse(param1XMLStreamReader, CertIDListType.type, param1XmlOptions);
    }
    
    public static CertIDListType parse(Node param1Node) throws XmlException {
      return (CertIDListType)XmlBeans.getContextTypeLoader().parse(param1Node, CertIDListType.type, null);
    }
    
    public static CertIDListType parse(Node param1Node, XmlOptions param1XmlOptions) throws XmlException {
      return (CertIDListType)XmlBeans.getContextTypeLoader().parse(param1Node, CertIDListType.type, param1XmlOptions);
    }
    
    public static CertIDListType parse(XMLInputStream param1XMLInputStream) throws XmlException, XMLStreamException {
      return (CertIDListType)XmlBeans.getContextTypeLoader().parse(param1XMLInputStream, CertIDListType.type, null);
    }
    
    public static CertIDListType parse(XMLInputStream param1XMLInputStream, XmlOptions param1XmlOptions) throws XmlException, XMLStreamException {
      return (CertIDListType)XmlBeans.getContextTypeLoader().parse(param1XMLInputStream, CertIDListType.type, param1XmlOptions);
    }
    
    public static XMLInputStream newValidatingXMLInputStream(XMLInputStream param1XMLInputStream) throws XmlException, XMLStreamException {
      return XmlBeans.getContextTypeLoader().newValidatingXMLInputStream(param1XMLInputStream, CertIDListType.type, null);
    }
    
    public static XMLInputStream newValidatingXMLInputStream(XMLInputStream param1XMLInputStream, XmlOptions param1XmlOptions) throws XmlException, XMLStreamException {
      return XmlBeans.getContextTypeLoader().newValidatingXMLInputStream(param1XMLInputStream, CertIDListType.type, param1XmlOptions);
    }
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/poi-ooxml-schemas-3.13.jar!/org/etsi/uri/x01903/v13/CertIDListType.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */