package org.etsi.uri.x01903.v13.impl;

import java.util.Calendar;
import javax.xml.namespace.QName;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.SimpleValue;
import org.apache.xmlbeans.XmlAnyURI;
import org.apache.xmlbeans.XmlDateTime;
import org.apache.xmlbeans.XmlObject;
import org.apache.xmlbeans.impl.values.XmlComplexContentImpl;
import org.etsi.uri.x01903.v13.OCSPIdentifierType;
import org.etsi.uri.x01903.v13.ResponderIDType;

public class OCSPIdentifierTypeImpl extends XmlComplexContentImpl implements OCSPIdentifierType {
  private static final QName RESPONDERID$0 = new QName("http://uri.etsi.org/01903/v1.3.2#", "ResponderID");
  
  private static final QName PRODUCEDAT$2 = new QName("http://uri.etsi.org/01903/v1.3.2#", "ProducedAt");
  
  private static final QName URI$4 = new QName("", "URI");
  
  public OCSPIdentifierTypeImpl(SchemaType paramSchemaType) {
    super(paramSchemaType);
  }
  
  public ResponderIDType getResponderID() {
    synchronized (monitor()) {
      check_orphaned();
      ResponderIDType responderIDType = null;
      responderIDType = (ResponderIDType)get_store().find_element_user(RESPONDERID$0, 0);
      if (responderIDType == null)
        return null; 
      return responderIDType;
    } 
  }
  
  public void setResponderID(ResponderIDType paramResponderIDType) {
    synchronized (monitor()) {
      check_orphaned();
      ResponderIDType responderIDType = null;
      responderIDType = (ResponderIDType)get_store().find_element_user(RESPONDERID$0, 0);
      if (responderIDType == null)
        responderIDType = (ResponderIDType)get_store().add_element_user(RESPONDERID$0); 
      responderIDType.set((XmlObject)paramResponderIDType);
    } 
  }
  
  public ResponderIDType addNewResponderID() {
    synchronized (monitor()) {
      check_orphaned();
      ResponderIDType responderIDType = null;
      responderIDType = (ResponderIDType)get_store().add_element_user(RESPONDERID$0);
      return responderIDType;
    } 
  }
  
  public Calendar getProducedAt() {
    synchronized (monitor()) {
      check_orphaned();
      SimpleValue simpleValue = null;
      simpleValue = (SimpleValue)get_store().find_element_user(PRODUCEDAT$2, 0);
      if (simpleValue == null)
        return null; 
      return simpleValue.getCalendarValue();
    } 
  }
  
  public XmlDateTime xgetProducedAt() {
    synchronized (monitor()) {
      check_orphaned();
      XmlDateTime xmlDateTime = null;
      xmlDateTime = (XmlDateTime)get_store().find_element_user(PRODUCEDAT$2, 0);
      return xmlDateTime;
    } 
  }
  
  public void setProducedAt(Calendar paramCalendar) {
    synchronized (monitor()) {
      check_orphaned();
      SimpleValue simpleValue = null;
      simpleValue = (SimpleValue)get_store().find_element_user(PRODUCEDAT$2, 0);
      if (simpleValue == null)
        simpleValue = (SimpleValue)get_store().add_element_user(PRODUCEDAT$2); 
      simpleValue.setCalendarValue(paramCalendar);
    } 
  }
  
  public void xsetProducedAt(XmlDateTime paramXmlDateTime) {
    synchronized (monitor()) {
      check_orphaned();
      XmlDateTime xmlDateTime = null;
      xmlDateTime = (XmlDateTime)get_store().find_element_user(PRODUCEDAT$2, 0);
      if (xmlDateTime == null)
        xmlDateTime = (XmlDateTime)get_store().add_element_user(PRODUCEDAT$2); 
      xmlDateTime.set((XmlObject)paramXmlDateTime);
    } 
  }
  
  public String getURI() {
    synchronized (monitor()) {
      check_orphaned();
      SimpleValue simpleValue = null;
      simpleValue = (SimpleValue)get_store().find_attribute_user(URI$4);
      if (simpleValue == null)
        return null; 
      return simpleValue.getStringValue();
    } 
  }
  
  public XmlAnyURI xgetURI() {
    synchronized (monitor()) {
      check_orphaned();
      XmlAnyURI xmlAnyURI = null;
      xmlAnyURI = (XmlAnyURI)get_store().find_attribute_user(URI$4);
      return xmlAnyURI;
    } 
  }
  
  public boolean isSetURI() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().find_attribute_user(URI$4) != null);
    } 
  }
  
  public void setURI(String paramString) {
    synchronized (monitor()) {
      check_orphaned();
      SimpleValue simpleValue = null;
      simpleValue = (SimpleValue)get_store().find_attribute_user(URI$4);
      if (simpleValue == null)
        simpleValue = (SimpleValue)get_store().add_attribute_user(URI$4); 
      simpleValue.setStringValue(paramString);
    } 
  }
  
  public void xsetURI(XmlAnyURI paramXmlAnyURI) {
    synchronized (monitor()) {
      check_orphaned();
      XmlAnyURI xmlAnyURI = null;
      xmlAnyURI = (XmlAnyURI)get_store().find_attribute_user(URI$4);
      if (xmlAnyURI == null)
        xmlAnyURI = (XmlAnyURI)get_store().add_attribute_user(URI$4); 
      xmlAnyURI.set((XmlObject)paramXmlAnyURI);
    } 
  }
  
  public void unsetURI() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_attribute(URI$4);
    } 
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/poi-ooxml-schemas-3.13.jar!/org/etsi/uri/x01903/v13/impl/OCSPIdentifierTypeImpl.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */