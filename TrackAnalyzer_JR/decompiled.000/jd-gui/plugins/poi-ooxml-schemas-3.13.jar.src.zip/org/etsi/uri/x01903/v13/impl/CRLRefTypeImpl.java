package org.etsi.uri.x01903.v13.impl;

import javax.xml.namespace.QName;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.XmlObject;
import org.apache.xmlbeans.impl.values.XmlComplexContentImpl;
import org.etsi.uri.x01903.v13.CRLIdentifierType;
import org.etsi.uri.x01903.v13.CRLRefType;
import org.etsi.uri.x01903.v13.DigestAlgAndValueType;

public class CRLRefTypeImpl extends XmlComplexContentImpl implements CRLRefType {
  private static final QName DIGESTALGANDVALUE$0 = new QName("http://uri.etsi.org/01903/v1.3.2#", "DigestAlgAndValue");
  
  private static final QName CRLIDENTIFIER$2 = new QName("http://uri.etsi.org/01903/v1.3.2#", "CRLIdentifier");
  
  public CRLRefTypeImpl(SchemaType paramSchemaType) {
    super(paramSchemaType);
  }
  
  public DigestAlgAndValueType getDigestAlgAndValue() {
    synchronized (monitor()) {
      check_orphaned();
      DigestAlgAndValueType digestAlgAndValueType = null;
      digestAlgAndValueType = (DigestAlgAndValueType)get_store().find_element_user(DIGESTALGANDVALUE$0, 0);
      if (digestAlgAndValueType == null)
        return null; 
      return digestAlgAndValueType;
    } 
  }
  
  public void setDigestAlgAndValue(DigestAlgAndValueType paramDigestAlgAndValueType) {
    synchronized (monitor()) {
      check_orphaned();
      DigestAlgAndValueType digestAlgAndValueType = null;
      digestAlgAndValueType = (DigestAlgAndValueType)get_store().find_element_user(DIGESTALGANDVALUE$0, 0);
      if (digestAlgAndValueType == null)
        digestAlgAndValueType = (DigestAlgAndValueType)get_store().add_element_user(DIGESTALGANDVALUE$0); 
      digestAlgAndValueType.set((XmlObject)paramDigestAlgAndValueType);
    } 
  }
  
  public DigestAlgAndValueType addNewDigestAlgAndValue() {
    synchronized (monitor()) {
      check_orphaned();
      DigestAlgAndValueType digestAlgAndValueType = null;
      digestAlgAndValueType = (DigestAlgAndValueType)get_store().add_element_user(DIGESTALGANDVALUE$0);
      return digestAlgAndValueType;
    } 
  }
  
  public CRLIdentifierType getCRLIdentifier() {
    synchronized (monitor()) {
      check_orphaned();
      CRLIdentifierType cRLIdentifierType = null;
      cRLIdentifierType = (CRLIdentifierType)get_store().find_element_user(CRLIDENTIFIER$2, 0);
      if (cRLIdentifierType == null)
        return null; 
      return cRLIdentifierType;
    } 
  }
  
  public boolean isSetCRLIdentifier() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().count_elements(CRLIDENTIFIER$2) != 0);
    } 
  }
  
  public void setCRLIdentifier(CRLIdentifierType paramCRLIdentifierType) {
    synchronized (monitor()) {
      check_orphaned();
      CRLIdentifierType cRLIdentifierType = null;
      cRLIdentifierType = (CRLIdentifierType)get_store().find_element_user(CRLIDENTIFIER$2, 0);
      if (cRLIdentifierType == null)
        cRLIdentifierType = (CRLIdentifierType)get_store().add_element_user(CRLIDENTIFIER$2); 
      cRLIdentifierType.set((XmlObject)paramCRLIdentifierType);
    } 
  }
  
  public CRLIdentifierType addNewCRLIdentifier() {
    synchronized (monitor()) {
      check_orphaned();
      CRLIdentifierType cRLIdentifierType = null;
      cRLIdentifierType = (CRLIdentifierType)get_store().add_element_user(CRLIDENTIFIER$2);
      return cRLIdentifierType;
    } 
  }
  
  public void unsetCRLIdentifier() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(CRLIDENTIFIER$2, 0);
    } 
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/poi-ooxml-schemas-3.13.jar!/org/etsi/uri/x01903/v13/impl/CRLRefTypeImpl.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */