package org.etsi.uri.x01903.v13.impl;

import java.util.ArrayList;
import java.util.List;
import javax.xml.namespace.QName;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.XmlObject;
import org.apache.xmlbeans.impl.values.XmlComplexContentImpl;
import org.etsi.uri.x01903.v13.EncapsulatedPKIDataType;
import org.etsi.uri.x01903.v13.OCSPValuesType;

public class OCSPValuesTypeImpl extends XmlComplexContentImpl implements OCSPValuesType {
  private static final QName ENCAPSULATEDOCSPVALUE$0 = new QName("http://uri.etsi.org/01903/v1.3.2#", "EncapsulatedOCSPValue");
  
  public OCSPValuesTypeImpl(SchemaType paramSchemaType) {
    super(paramSchemaType);
  }
  
  public List<EncapsulatedPKIDataType> getEncapsulatedOCSPValueList() {
    synchronized (monitor()) {
      check_orphaned();
      return (List<EncapsulatedPKIDataType>)new EncapsulatedOCSPValueList(this);
    } 
  }
  
  public EncapsulatedPKIDataType[] getEncapsulatedOCSPValueArray() {
    synchronized (monitor()) {
      check_orphaned();
      ArrayList arrayList = new ArrayList();
      get_store().find_all_element_users(ENCAPSULATEDOCSPVALUE$0, arrayList);
      EncapsulatedPKIDataType[] arrayOfEncapsulatedPKIDataType = new EncapsulatedPKIDataType[arrayList.size()];
      arrayList.toArray((Object[])arrayOfEncapsulatedPKIDataType);
      return arrayOfEncapsulatedPKIDataType;
    } 
  }
  
  public EncapsulatedPKIDataType getEncapsulatedOCSPValueArray(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      EncapsulatedPKIDataType encapsulatedPKIDataType = null;
      encapsulatedPKIDataType = (EncapsulatedPKIDataType)get_store().find_element_user(ENCAPSULATEDOCSPVALUE$0, paramInt);
      if (encapsulatedPKIDataType == null)
        throw new IndexOutOfBoundsException(); 
      return encapsulatedPKIDataType;
    } 
  }
  
  public int sizeOfEncapsulatedOCSPValueArray() {
    synchronized (monitor()) {
      check_orphaned();
      return get_store().count_elements(ENCAPSULATEDOCSPVALUE$0);
    } 
  }
  
  public void setEncapsulatedOCSPValueArray(EncapsulatedPKIDataType[] paramArrayOfEncapsulatedPKIDataType) {
    synchronized (monitor()) {
      check_orphaned();
      arraySetterHelper((XmlObject[])paramArrayOfEncapsulatedPKIDataType, ENCAPSULATEDOCSPVALUE$0);
    } 
  }
  
  public void setEncapsulatedOCSPValueArray(int paramInt, EncapsulatedPKIDataType paramEncapsulatedPKIDataType) {
    synchronized (monitor()) {
      check_orphaned();
      EncapsulatedPKIDataType encapsulatedPKIDataType = null;
      encapsulatedPKIDataType = (EncapsulatedPKIDataType)get_store().find_element_user(ENCAPSULATEDOCSPVALUE$0, paramInt);
      if (encapsulatedPKIDataType == null)
        throw new IndexOutOfBoundsException(); 
      encapsulatedPKIDataType.set((XmlObject)paramEncapsulatedPKIDataType);
    } 
  }
  
  public EncapsulatedPKIDataType insertNewEncapsulatedOCSPValue(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      EncapsulatedPKIDataType encapsulatedPKIDataType = null;
      encapsulatedPKIDataType = (EncapsulatedPKIDataType)get_store().insert_element_user(ENCAPSULATEDOCSPVALUE$0, paramInt);
      return encapsulatedPKIDataType;
    } 
  }
  
  public EncapsulatedPKIDataType addNewEncapsulatedOCSPValue() {
    synchronized (monitor()) {
      check_orphaned();
      EncapsulatedPKIDataType encapsulatedPKIDataType = null;
      encapsulatedPKIDataType = (EncapsulatedPKIDataType)get_store().add_element_user(ENCAPSULATEDOCSPVALUE$0);
      return encapsulatedPKIDataType;
    } 
  }
  
  public void removeEncapsulatedOCSPValue(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(ENCAPSULATEDOCSPVALUE$0, paramInt);
    } 
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/poi-ooxml-schemas-3.13.jar!/org/etsi/uri/x01903/v13/impl/OCSPValuesTypeImpl.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */