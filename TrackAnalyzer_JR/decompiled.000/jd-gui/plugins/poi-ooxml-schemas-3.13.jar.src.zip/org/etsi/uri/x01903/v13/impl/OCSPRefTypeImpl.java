package org.etsi.uri.x01903.v13.impl;

import javax.xml.namespace.QName;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.XmlObject;
import org.apache.xmlbeans.impl.values.XmlComplexContentImpl;
import org.etsi.uri.x01903.v13.DigestAlgAndValueType;
import org.etsi.uri.x01903.v13.OCSPIdentifierType;
import org.etsi.uri.x01903.v13.OCSPRefType;

public class OCSPRefTypeImpl extends XmlComplexContentImpl implements OCSPRefType {
  private static final QName OCSPIDENTIFIER$0 = new QName("http://uri.etsi.org/01903/v1.3.2#", "OCSPIdentifier");
  
  private static final QName DIGESTALGANDVALUE$2 = new QName("http://uri.etsi.org/01903/v1.3.2#", "DigestAlgAndValue");
  
  public OCSPRefTypeImpl(SchemaType paramSchemaType) {
    super(paramSchemaType);
  }
  
  public OCSPIdentifierType getOCSPIdentifier() {
    synchronized (monitor()) {
      check_orphaned();
      OCSPIdentifierType oCSPIdentifierType = null;
      oCSPIdentifierType = (OCSPIdentifierType)get_store().find_element_user(OCSPIDENTIFIER$0, 0);
      if (oCSPIdentifierType == null)
        return null; 
      return oCSPIdentifierType;
    } 
  }
  
  public void setOCSPIdentifier(OCSPIdentifierType paramOCSPIdentifierType) {
    synchronized (monitor()) {
      check_orphaned();
      OCSPIdentifierType oCSPIdentifierType = null;
      oCSPIdentifierType = (OCSPIdentifierType)get_store().find_element_user(OCSPIDENTIFIER$0, 0);
      if (oCSPIdentifierType == null)
        oCSPIdentifierType = (OCSPIdentifierType)get_store().add_element_user(OCSPIDENTIFIER$0); 
      oCSPIdentifierType.set((XmlObject)paramOCSPIdentifierType);
    } 
  }
  
  public OCSPIdentifierType addNewOCSPIdentifier() {
    synchronized (monitor()) {
      check_orphaned();
      OCSPIdentifierType oCSPIdentifierType = null;
      oCSPIdentifierType = (OCSPIdentifierType)get_store().add_element_user(OCSPIDENTIFIER$0);
      return oCSPIdentifierType;
    } 
  }
  
  public DigestAlgAndValueType getDigestAlgAndValue() {
    synchronized (monitor()) {
      check_orphaned();
      DigestAlgAndValueType digestAlgAndValueType = null;
      digestAlgAndValueType = (DigestAlgAndValueType)get_store().find_element_user(DIGESTALGANDVALUE$2, 0);
      if (digestAlgAndValueType == null)
        return null; 
      return digestAlgAndValueType;
    } 
  }
  
  public boolean isSetDigestAlgAndValue() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().count_elements(DIGESTALGANDVALUE$2) != 0);
    } 
  }
  
  public void setDigestAlgAndValue(DigestAlgAndValueType paramDigestAlgAndValueType) {
    synchronized (monitor()) {
      check_orphaned();
      DigestAlgAndValueType digestAlgAndValueType = null;
      digestAlgAndValueType = (DigestAlgAndValueType)get_store().find_element_user(DIGESTALGANDVALUE$2, 0);
      if (digestAlgAndValueType == null)
        digestAlgAndValueType = (DigestAlgAndValueType)get_store().add_element_user(DIGESTALGANDVALUE$2); 
      digestAlgAndValueType.set((XmlObject)paramDigestAlgAndValueType);
    } 
  }
  
  public DigestAlgAndValueType addNewDigestAlgAndValue() {
    synchronized (monitor()) {
      check_orphaned();
      DigestAlgAndValueType digestAlgAndValueType = null;
      digestAlgAndValueType = (DigestAlgAndValueType)get_store().add_element_user(DIGESTALGANDVALUE$2);
      return digestAlgAndValueType;
    } 
  }
  
  public void unsetDigestAlgAndValue() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(DIGESTALGANDVALUE$2, 0);
    } 
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/poi-ooxml-schemas-3.13.jar!/org/etsi/uri/x01903/v13/impl/OCSPRefTypeImpl.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */