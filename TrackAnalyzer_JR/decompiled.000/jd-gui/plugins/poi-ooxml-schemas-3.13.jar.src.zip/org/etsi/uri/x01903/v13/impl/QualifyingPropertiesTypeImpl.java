package org.etsi.uri.x01903.v13.impl;

import javax.xml.namespace.QName;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.SimpleValue;
import org.apache.xmlbeans.XmlAnyURI;
import org.apache.xmlbeans.XmlID;
import org.apache.xmlbeans.XmlObject;
import org.apache.xmlbeans.impl.values.XmlComplexContentImpl;
import org.etsi.uri.x01903.v13.QualifyingPropertiesType;
import org.etsi.uri.x01903.v13.SignedPropertiesType;
import org.etsi.uri.x01903.v13.UnsignedPropertiesType;

public class QualifyingPropertiesTypeImpl extends XmlComplexContentImpl implements QualifyingPropertiesType {
  private static final QName SIGNEDPROPERTIES$0 = new QName("http://uri.etsi.org/01903/v1.3.2#", "SignedProperties");
  
  private static final QName UNSIGNEDPROPERTIES$2 = new QName("http://uri.etsi.org/01903/v1.3.2#", "UnsignedProperties");
  
  private static final QName TARGET$4 = new QName("", "Target");
  
  private static final QName ID$6 = new QName("", "Id");
  
  public QualifyingPropertiesTypeImpl(SchemaType paramSchemaType) {
    super(paramSchemaType);
  }
  
  public SignedPropertiesType getSignedProperties() {
    synchronized (monitor()) {
      check_orphaned();
      SignedPropertiesType signedPropertiesType = null;
      signedPropertiesType = (SignedPropertiesType)get_store().find_element_user(SIGNEDPROPERTIES$0, 0);
      if (signedPropertiesType == null)
        return null; 
      return signedPropertiesType;
    } 
  }
  
  public boolean isSetSignedProperties() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().count_elements(SIGNEDPROPERTIES$0) != 0);
    } 
  }
  
  public void setSignedProperties(SignedPropertiesType paramSignedPropertiesType) {
    synchronized (monitor()) {
      check_orphaned();
      SignedPropertiesType signedPropertiesType = null;
      signedPropertiesType = (SignedPropertiesType)get_store().find_element_user(SIGNEDPROPERTIES$0, 0);
      if (signedPropertiesType == null)
        signedPropertiesType = (SignedPropertiesType)get_store().add_element_user(SIGNEDPROPERTIES$0); 
      signedPropertiesType.set((XmlObject)paramSignedPropertiesType);
    } 
  }
  
  public SignedPropertiesType addNewSignedProperties() {
    synchronized (monitor()) {
      check_orphaned();
      SignedPropertiesType signedPropertiesType = null;
      signedPropertiesType = (SignedPropertiesType)get_store().add_element_user(SIGNEDPROPERTIES$0);
      return signedPropertiesType;
    } 
  }
  
  public void unsetSignedProperties() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(SIGNEDPROPERTIES$0, 0);
    } 
  }
  
  public UnsignedPropertiesType getUnsignedProperties() {
    synchronized (monitor()) {
      check_orphaned();
      UnsignedPropertiesType unsignedPropertiesType = null;
      unsignedPropertiesType = (UnsignedPropertiesType)get_store().find_element_user(UNSIGNEDPROPERTIES$2, 0);
      if (unsignedPropertiesType == null)
        return null; 
      return unsignedPropertiesType;
    } 
  }
  
  public boolean isSetUnsignedProperties() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().count_elements(UNSIGNEDPROPERTIES$2) != 0);
    } 
  }
  
  public void setUnsignedProperties(UnsignedPropertiesType paramUnsignedPropertiesType) {
    synchronized (monitor()) {
      check_orphaned();
      UnsignedPropertiesType unsignedPropertiesType = null;
      unsignedPropertiesType = (UnsignedPropertiesType)get_store().find_element_user(UNSIGNEDPROPERTIES$2, 0);
      if (unsignedPropertiesType == null)
        unsignedPropertiesType = (UnsignedPropertiesType)get_store().add_element_user(UNSIGNEDPROPERTIES$2); 
      unsignedPropertiesType.set((XmlObject)paramUnsignedPropertiesType);
    } 
  }
  
  public UnsignedPropertiesType addNewUnsignedProperties() {
    synchronized (monitor()) {
      check_orphaned();
      UnsignedPropertiesType unsignedPropertiesType = null;
      unsignedPropertiesType = (UnsignedPropertiesType)get_store().add_element_user(UNSIGNEDPROPERTIES$2);
      return unsignedPropertiesType;
    } 
  }
  
  public void unsetUnsignedProperties() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(UNSIGNEDPROPERTIES$2, 0);
    } 
  }
  
  public String getTarget() {
    synchronized (monitor()) {
      check_orphaned();
      SimpleValue simpleValue = null;
      simpleValue = (SimpleValue)get_store().find_attribute_user(TARGET$4);
      if (simpleValue == null)
        return null; 
      return simpleValue.getStringValue();
    } 
  }
  
  public XmlAnyURI xgetTarget() {
    synchronized (monitor()) {
      check_orphaned();
      XmlAnyURI xmlAnyURI = null;
      xmlAnyURI = (XmlAnyURI)get_store().find_attribute_user(TARGET$4);
      return xmlAnyURI;
    } 
  }
  
  public void setTarget(String paramString) {
    synchronized (monitor()) {
      check_orphaned();
      SimpleValue simpleValue = null;
      simpleValue = (SimpleValue)get_store().find_attribute_user(TARGET$4);
      if (simpleValue == null)
        simpleValue = (SimpleValue)get_store().add_attribute_user(TARGET$4); 
      simpleValue.setStringValue(paramString);
    } 
  }
  
  public void xsetTarget(XmlAnyURI paramXmlAnyURI) {
    synchronized (monitor()) {
      check_orphaned();
      XmlAnyURI xmlAnyURI = null;
      xmlAnyURI = (XmlAnyURI)get_store().find_attribute_user(TARGET$4);
      if (xmlAnyURI == null)
        xmlAnyURI = (XmlAnyURI)get_store().add_attribute_user(TARGET$4); 
      xmlAnyURI.set((XmlObject)paramXmlAnyURI);
    } 
  }
  
  public String getId() {
    synchronized (monitor()) {
      check_orphaned();
      SimpleValue simpleValue = null;
      simpleValue = (SimpleValue)get_store().find_attribute_user(ID$6);
      if (simpleValue == null)
        return null; 
      return simpleValue.getStringValue();
    } 
  }
  
  public XmlID xgetId() {
    synchronized (monitor()) {
      check_orphaned();
      XmlID xmlID = null;
      xmlID = (XmlID)get_store().find_attribute_user(ID$6);
      return xmlID;
    } 
  }
  
  public boolean isSetId() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().find_attribute_user(ID$6) != null);
    } 
  }
  
  public void setId(String paramString) {
    synchronized (monitor()) {
      check_orphaned();
      SimpleValue simpleValue = null;
      simpleValue = (SimpleValue)get_store().find_attribute_user(ID$6);
      if (simpleValue == null)
        simpleValue = (SimpleValue)get_store().add_attribute_user(ID$6); 
      simpleValue.setStringValue(paramString);
    } 
  }
  
  public void xsetId(XmlID paramXmlID) {
    synchronized (monitor()) {
      check_orphaned();
      XmlID xmlID = null;
      xmlID = (XmlID)get_store().find_attribute_user(ID$6);
      if (xmlID == null)
        xmlID = (XmlID)get_store().add_attribute_user(ID$6); 
      xmlID.set((XmlObject)paramXmlID);
    } 
  }
  
  public void unsetId() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_attribute(ID$6);
    } 
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/poi-ooxml-schemas-3.13.jar!/org/etsi/uri/x01903/v13/impl/QualifyingPropertiesTypeImpl.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */