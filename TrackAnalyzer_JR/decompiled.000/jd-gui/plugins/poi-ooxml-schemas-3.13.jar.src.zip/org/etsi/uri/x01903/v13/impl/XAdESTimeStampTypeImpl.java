package org.etsi.uri.x01903.v13.impl;

import org.apache.xmlbeans.SchemaType;
import org.etsi.uri.x01903.v13.XAdESTimeStampType;

public class XAdESTimeStampTypeImpl extends GenericTimeStampTypeImpl implements XAdESTimeStampType {
  public XAdESTimeStampTypeImpl(SchemaType paramSchemaType) {
    super(paramSchemaType);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/poi-ooxml-schemas-3.13.jar!/org/etsi/uri/x01903/v13/impl/XAdESTimeStampTypeImpl.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */