package org.etsi.uri.x01903.v13.impl;

import javax.xml.namespace.QName;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.SimpleValue;
import org.apache.xmlbeans.XmlID;
import org.apache.xmlbeans.XmlObject;
import org.apache.xmlbeans.impl.values.XmlComplexContentImpl;
import org.etsi.uri.x01903.v13.CRLRefsType;
import org.etsi.uri.x01903.v13.CompleteRevocationRefsType;
import org.etsi.uri.x01903.v13.OCSPRefsType;
import org.etsi.uri.x01903.v13.OtherCertStatusRefsType;

public class CompleteRevocationRefsTypeImpl extends XmlComplexContentImpl implements CompleteRevocationRefsType {
  private static final QName CRLREFS$0 = new QName("http://uri.etsi.org/01903/v1.3.2#", "CRLRefs");
  
  private static final QName OCSPREFS$2 = new QName("http://uri.etsi.org/01903/v1.3.2#", "OCSPRefs");
  
  private static final QName OTHERREFS$4 = new QName("http://uri.etsi.org/01903/v1.3.2#", "OtherRefs");
  
  private static final QName ID$6 = new QName("", "Id");
  
  public CompleteRevocationRefsTypeImpl(SchemaType paramSchemaType) {
    super(paramSchemaType);
  }
  
  public CRLRefsType getCRLRefs() {
    synchronized (monitor()) {
      check_orphaned();
      CRLRefsType cRLRefsType = null;
      cRLRefsType = (CRLRefsType)get_store().find_element_user(CRLREFS$0, 0);
      if (cRLRefsType == null)
        return null; 
      return cRLRefsType;
    } 
  }
  
  public boolean isSetCRLRefs() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().count_elements(CRLREFS$0) != 0);
    } 
  }
  
  public void setCRLRefs(CRLRefsType paramCRLRefsType) {
    synchronized (monitor()) {
      check_orphaned();
      CRLRefsType cRLRefsType = null;
      cRLRefsType = (CRLRefsType)get_store().find_element_user(CRLREFS$0, 0);
      if (cRLRefsType == null)
        cRLRefsType = (CRLRefsType)get_store().add_element_user(CRLREFS$0); 
      cRLRefsType.set((XmlObject)paramCRLRefsType);
    } 
  }
  
  public CRLRefsType addNewCRLRefs() {
    synchronized (monitor()) {
      check_orphaned();
      CRLRefsType cRLRefsType = null;
      cRLRefsType = (CRLRefsType)get_store().add_element_user(CRLREFS$0);
      return cRLRefsType;
    } 
  }
  
  public void unsetCRLRefs() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(CRLREFS$0, 0);
    } 
  }
  
  public OCSPRefsType getOCSPRefs() {
    synchronized (monitor()) {
      check_orphaned();
      OCSPRefsType oCSPRefsType = null;
      oCSPRefsType = (OCSPRefsType)get_store().find_element_user(OCSPREFS$2, 0);
      if (oCSPRefsType == null)
        return null; 
      return oCSPRefsType;
    } 
  }
  
  public boolean isSetOCSPRefs() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().count_elements(OCSPREFS$2) != 0);
    } 
  }
  
  public void setOCSPRefs(OCSPRefsType paramOCSPRefsType) {
    synchronized (monitor()) {
      check_orphaned();
      OCSPRefsType oCSPRefsType = null;
      oCSPRefsType = (OCSPRefsType)get_store().find_element_user(OCSPREFS$2, 0);
      if (oCSPRefsType == null)
        oCSPRefsType = (OCSPRefsType)get_store().add_element_user(OCSPREFS$2); 
      oCSPRefsType.set((XmlObject)paramOCSPRefsType);
    } 
  }
  
  public OCSPRefsType addNewOCSPRefs() {
    synchronized (monitor()) {
      check_orphaned();
      OCSPRefsType oCSPRefsType = null;
      oCSPRefsType = (OCSPRefsType)get_store().add_element_user(OCSPREFS$2);
      return oCSPRefsType;
    } 
  }
  
  public void unsetOCSPRefs() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(OCSPREFS$2, 0);
    } 
  }
  
  public OtherCertStatusRefsType getOtherRefs() {
    synchronized (monitor()) {
      check_orphaned();
      OtherCertStatusRefsType otherCertStatusRefsType = null;
      otherCertStatusRefsType = (OtherCertStatusRefsType)get_store().find_element_user(OTHERREFS$4, 0);
      if (otherCertStatusRefsType == null)
        return null; 
      return otherCertStatusRefsType;
    } 
  }
  
  public boolean isSetOtherRefs() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().count_elements(OTHERREFS$4) != 0);
    } 
  }
  
  public void setOtherRefs(OtherCertStatusRefsType paramOtherCertStatusRefsType) {
    synchronized (monitor()) {
      check_orphaned();
      OtherCertStatusRefsType otherCertStatusRefsType = null;
      otherCertStatusRefsType = (OtherCertStatusRefsType)get_store().find_element_user(OTHERREFS$4, 0);
      if (otherCertStatusRefsType == null)
        otherCertStatusRefsType = (OtherCertStatusRefsType)get_store().add_element_user(OTHERREFS$4); 
      otherCertStatusRefsType.set((XmlObject)paramOtherCertStatusRefsType);
    } 
  }
  
  public OtherCertStatusRefsType addNewOtherRefs() {
    synchronized (monitor()) {
      check_orphaned();
      OtherCertStatusRefsType otherCertStatusRefsType = null;
      otherCertStatusRefsType = (OtherCertStatusRefsType)get_store().add_element_user(OTHERREFS$4);
      return otherCertStatusRefsType;
    } 
  }
  
  public void unsetOtherRefs() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(OTHERREFS$4, 0);
    } 
  }
  
  public String getId() {
    synchronized (monitor()) {
      check_orphaned();
      SimpleValue simpleValue = null;
      simpleValue = (SimpleValue)get_store().find_attribute_user(ID$6);
      if (simpleValue == null)
        return null; 
      return simpleValue.getStringValue();
    } 
  }
  
  public XmlID xgetId() {
    synchronized (monitor()) {
      check_orphaned();
      XmlID xmlID = null;
      xmlID = (XmlID)get_store().find_attribute_user(ID$6);
      return xmlID;
    } 
  }
  
  public boolean isSetId() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().find_attribute_user(ID$6) != null);
    } 
  }
  
  public void setId(String paramString) {
    synchronized (monitor()) {
      check_orphaned();
      SimpleValue simpleValue = null;
      simpleValue = (SimpleValue)get_store().find_attribute_user(ID$6);
      if (simpleValue == null)
        simpleValue = (SimpleValue)get_store().add_attribute_user(ID$6); 
      simpleValue.setStringValue(paramString);
    } 
  }
  
  public void xsetId(XmlID paramXmlID) {
    synchronized (monitor()) {
      check_orphaned();
      XmlID xmlID = null;
      xmlID = (XmlID)get_store().find_attribute_user(ID$6);
      if (xmlID == null)
        xmlID = (XmlID)get_store().add_attribute_user(ID$6); 
      xmlID.set((XmlObject)paramXmlID);
    } 
  }
  
  public void unsetId() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_attribute(ID$6);
    } 
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/poi-ooxml-schemas-3.13.jar!/org/etsi/uri/x01903/v13/impl/CompleteRevocationRefsTypeImpl.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */