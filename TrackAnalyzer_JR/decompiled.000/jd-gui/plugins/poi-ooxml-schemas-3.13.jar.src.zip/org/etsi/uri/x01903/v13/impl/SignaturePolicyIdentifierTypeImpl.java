package org.etsi.uri.x01903.v13.impl;

import javax.xml.namespace.QName;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.XmlObject;
import org.apache.xmlbeans.impl.values.XmlComplexContentImpl;
import org.etsi.uri.x01903.v13.SignaturePolicyIdType;
import org.etsi.uri.x01903.v13.SignaturePolicyIdentifierType;

public class SignaturePolicyIdentifierTypeImpl extends XmlComplexContentImpl implements SignaturePolicyIdentifierType {
  private static final QName SIGNATUREPOLICYID$0 = new QName("http://uri.etsi.org/01903/v1.3.2#", "SignaturePolicyId");
  
  private static final QName SIGNATUREPOLICYIMPLIED$2 = new QName("http://uri.etsi.org/01903/v1.3.2#", "SignaturePolicyImplied");
  
  public SignaturePolicyIdentifierTypeImpl(SchemaType paramSchemaType) {
    super(paramSchemaType);
  }
  
  public SignaturePolicyIdType getSignaturePolicyId() {
    synchronized (monitor()) {
      check_orphaned();
      SignaturePolicyIdType signaturePolicyIdType = null;
      signaturePolicyIdType = (SignaturePolicyIdType)get_store().find_element_user(SIGNATUREPOLICYID$0, 0);
      if (signaturePolicyIdType == null)
        return null; 
      return signaturePolicyIdType;
    } 
  }
  
  public boolean isSetSignaturePolicyId() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().count_elements(SIGNATUREPOLICYID$0) != 0);
    } 
  }
  
  public void setSignaturePolicyId(SignaturePolicyIdType paramSignaturePolicyIdType) {
    synchronized (monitor()) {
      check_orphaned();
      SignaturePolicyIdType signaturePolicyIdType = null;
      signaturePolicyIdType = (SignaturePolicyIdType)get_store().find_element_user(SIGNATUREPOLICYID$0, 0);
      if (signaturePolicyIdType == null)
        signaturePolicyIdType = (SignaturePolicyIdType)get_store().add_element_user(SIGNATUREPOLICYID$0); 
      signaturePolicyIdType.set((XmlObject)paramSignaturePolicyIdType);
    } 
  }
  
  public SignaturePolicyIdType addNewSignaturePolicyId() {
    synchronized (monitor()) {
      check_orphaned();
      SignaturePolicyIdType signaturePolicyIdType = null;
      signaturePolicyIdType = (SignaturePolicyIdType)get_store().add_element_user(SIGNATUREPOLICYID$0);
      return signaturePolicyIdType;
    } 
  }
  
  public void unsetSignaturePolicyId() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(SIGNATUREPOLICYID$0, 0);
    } 
  }
  
  public XmlObject getSignaturePolicyImplied() {
    synchronized (monitor()) {
      check_orphaned();
      XmlObject xmlObject = null;
      xmlObject = (XmlObject)get_store().find_element_user(SIGNATUREPOLICYIMPLIED$2, 0);
      if (xmlObject == null)
        return null; 
      return xmlObject;
    } 
  }
  
  public boolean isSetSignaturePolicyImplied() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().count_elements(SIGNATUREPOLICYIMPLIED$2) != 0);
    } 
  }
  
  public void setSignaturePolicyImplied(XmlObject paramXmlObject) {
    synchronized (monitor()) {
      check_orphaned();
      XmlObject xmlObject = null;
      xmlObject = (XmlObject)get_store().find_element_user(SIGNATUREPOLICYIMPLIED$2, 0);
      if (xmlObject == null)
        xmlObject = (XmlObject)get_store().add_element_user(SIGNATUREPOLICYIMPLIED$2); 
      xmlObject.set(paramXmlObject);
    } 
  }
  
  public XmlObject addNewSignaturePolicyImplied() {
    synchronized (monitor()) {
      check_orphaned();
      XmlObject xmlObject = null;
      xmlObject = (XmlObject)get_store().add_element_user(SIGNATUREPOLICYIMPLIED$2);
      return xmlObject;
    } 
  }
  
  public void unsetSignaturePolicyImplied() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(SIGNATUREPOLICYIMPLIED$2, 0);
    } 
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/poi-ooxml-schemas-3.13.jar!/org/etsi/uri/x01903/v13/impl/SignaturePolicyIdentifierTypeImpl.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */