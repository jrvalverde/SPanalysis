package org.etsi.uri.x01903.v13;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.net.URL;
import java.util.Calendar;
import javax.xml.stream.XMLStreamReader;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.XmlBeans;
import org.apache.xmlbeans.XmlDateTime;
import org.apache.xmlbeans.XmlException;
import org.apache.xmlbeans.XmlID;
import org.apache.xmlbeans.XmlObject;
import org.apache.xmlbeans.XmlOptions;
import org.apache.xmlbeans.xml.stream.XMLInputStream;
import org.apache.xmlbeans.xml.stream.XMLStreamException;
import org.w3c.dom.Node;

public interface SignedSignaturePropertiesType extends XmlObject {
  public static final SchemaType type = (SchemaType)XmlBeans.typeSystemForClassLoader(SignedSignaturePropertiesType.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s0B482D0B338CC9641C1543C3510577FE").resolveHandle("signedsignaturepropertiestype06abtype");
  
  Calendar getSigningTime();
  
  XmlDateTime xgetSigningTime();
  
  boolean isSetSigningTime();
  
  void setSigningTime(Calendar paramCalendar);
  
  void xsetSigningTime(XmlDateTime paramXmlDateTime);
  
  void unsetSigningTime();
  
  CertIDListType getSigningCertificate();
  
  boolean isSetSigningCertificate();
  
  void setSigningCertificate(CertIDListType paramCertIDListType);
  
  CertIDListType addNewSigningCertificate();
  
  void unsetSigningCertificate();
  
  SignaturePolicyIdentifierType getSignaturePolicyIdentifier();
  
  boolean isSetSignaturePolicyIdentifier();
  
  void setSignaturePolicyIdentifier(SignaturePolicyIdentifierType paramSignaturePolicyIdentifierType);
  
  SignaturePolicyIdentifierType addNewSignaturePolicyIdentifier();
  
  void unsetSignaturePolicyIdentifier();
  
  SignatureProductionPlaceType getSignatureProductionPlace();
  
  boolean isSetSignatureProductionPlace();
  
  void setSignatureProductionPlace(SignatureProductionPlaceType paramSignatureProductionPlaceType);
  
  SignatureProductionPlaceType addNewSignatureProductionPlace();
  
  void unsetSignatureProductionPlace();
  
  SignerRoleType getSignerRole();
  
  boolean isSetSignerRole();
  
  void setSignerRole(SignerRoleType paramSignerRoleType);
  
  SignerRoleType addNewSignerRole();
  
  void unsetSignerRole();
  
  String getId();
  
  XmlID xgetId();
  
  boolean isSetId();
  
  void setId(String paramString);
  
  void xsetId(XmlID paramXmlID);
  
  void unsetId();
  
  public static final class Factory {
    public static SignedSignaturePropertiesType newInstance() {
      return (SignedSignaturePropertiesType)XmlBeans.getContextTypeLoader().newInstance(SignedSignaturePropertiesType.type, null);
    }
    
    public static SignedSignaturePropertiesType newInstance(XmlOptions param1XmlOptions) {
      return (SignedSignaturePropertiesType)XmlBeans.getContextTypeLoader().newInstance(SignedSignaturePropertiesType.type, param1XmlOptions);
    }
    
    public static SignedSignaturePropertiesType parse(String param1String) throws XmlException {
      return (SignedSignaturePropertiesType)XmlBeans.getContextTypeLoader().parse(param1String, SignedSignaturePropertiesType.type, null);
    }
    
    public static SignedSignaturePropertiesType parse(String param1String, XmlOptions param1XmlOptions) throws XmlException {
      return (SignedSignaturePropertiesType)XmlBeans.getContextTypeLoader().parse(param1String, SignedSignaturePropertiesType.type, param1XmlOptions);
    }
    
    public static SignedSignaturePropertiesType parse(File param1File) throws XmlException, IOException {
      return (SignedSignaturePropertiesType)XmlBeans.getContextTypeLoader().parse(param1File, SignedSignaturePropertiesType.type, null);
    }
    
    public static SignedSignaturePropertiesType parse(File param1File, XmlOptions param1XmlOptions) throws XmlException, IOException {
      return (SignedSignaturePropertiesType)XmlBeans.getContextTypeLoader().parse(param1File, SignedSignaturePropertiesType.type, param1XmlOptions);
    }
    
    public static SignedSignaturePropertiesType parse(URL param1URL) throws XmlException, IOException {
      return (SignedSignaturePropertiesType)XmlBeans.getContextTypeLoader().parse(param1URL, SignedSignaturePropertiesType.type, null);
    }
    
    public static SignedSignaturePropertiesType parse(URL param1URL, XmlOptions param1XmlOptions) throws XmlException, IOException {
      return (SignedSignaturePropertiesType)XmlBeans.getContextTypeLoader().parse(param1URL, SignedSignaturePropertiesType.type, param1XmlOptions);
    }
    
    public static SignedSignaturePropertiesType parse(InputStream param1InputStream) throws XmlException, IOException {
      return (SignedSignaturePropertiesType)XmlBeans.getContextTypeLoader().parse(param1InputStream, SignedSignaturePropertiesType.type, null);
    }
    
    public static SignedSignaturePropertiesType parse(InputStream param1InputStream, XmlOptions param1XmlOptions) throws XmlException, IOException {
      return (SignedSignaturePropertiesType)XmlBeans.getContextTypeLoader().parse(param1InputStream, SignedSignaturePropertiesType.type, param1XmlOptions);
    }
    
    public static SignedSignaturePropertiesType parse(Reader param1Reader) throws XmlException, IOException {
      return (SignedSignaturePropertiesType)XmlBeans.getContextTypeLoader().parse(param1Reader, SignedSignaturePropertiesType.type, null);
    }
    
    public static SignedSignaturePropertiesType parse(Reader param1Reader, XmlOptions param1XmlOptions) throws XmlException, IOException {
      return (SignedSignaturePropertiesType)XmlBeans.getContextTypeLoader().parse(param1Reader, SignedSignaturePropertiesType.type, param1XmlOptions);
    }
    
    public static SignedSignaturePropertiesType parse(XMLStreamReader param1XMLStreamReader) throws XmlException {
      return (SignedSignaturePropertiesType)XmlBeans.getContextTypeLoader().parse(param1XMLStreamReader, SignedSignaturePropertiesType.type, null);
    }
    
    public static SignedSignaturePropertiesType parse(XMLStreamReader param1XMLStreamReader, XmlOptions param1XmlOptions) throws XmlException {
      return (SignedSignaturePropertiesType)XmlBeans.getContextTypeLoader().parse(param1XMLStreamReader, SignedSignaturePropertiesType.type, param1XmlOptions);
    }
    
    public static SignedSignaturePropertiesType parse(Node param1Node) throws XmlException {
      return (SignedSignaturePropertiesType)XmlBeans.getContextTypeLoader().parse(param1Node, SignedSignaturePropertiesType.type, null);
    }
    
    public static SignedSignaturePropertiesType parse(Node param1Node, XmlOptions param1XmlOptions) throws XmlException {
      return (SignedSignaturePropertiesType)XmlBeans.getContextTypeLoader().parse(param1Node, SignedSignaturePropertiesType.type, param1XmlOptions);
    }
    
    public static SignedSignaturePropertiesType parse(XMLInputStream param1XMLInputStream) throws XmlException, XMLStreamException {
      return (SignedSignaturePropertiesType)XmlBeans.getContextTypeLoader().parse(param1XMLInputStream, SignedSignaturePropertiesType.type, null);
    }
    
    public static SignedSignaturePropertiesType parse(XMLInputStream param1XMLInputStream, XmlOptions param1XmlOptions) throws XmlException, XMLStreamException {
      return (SignedSignaturePropertiesType)XmlBeans.getContextTypeLoader().parse(param1XMLInputStream, SignedSignaturePropertiesType.type, param1XmlOptions);
    }
    
    public static XMLInputStream newValidatingXMLInputStream(XMLInputStream param1XMLInputStream) throws XmlException, XMLStreamException {
      return XmlBeans.getContextTypeLoader().newValidatingXMLInputStream(param1XMLInputStream, SignedSignaturePropertiesType.type, null);
    }
    
    public static XMLInputStream newValidatingXMLInputStream(XMLInputStream param1XMLInputStream, XmlOptions param1XmlOptions) throws XmlException, XMLStreamException {
      return XmlBeans.getContextTypeLoader().newValidatingXMLInputStream(param1XMLInputStream, SignedSignaturePropertiesType.type, param1XmlOptions);
    }
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/poi-ooxml-schemas-3.13.jar!/org/etsi/uri/x01903/v13/SignedSignaturePropertiesType.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */