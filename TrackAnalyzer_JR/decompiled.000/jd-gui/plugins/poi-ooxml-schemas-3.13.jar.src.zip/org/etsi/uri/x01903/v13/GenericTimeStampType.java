package org.etsi.uri.x01903.v13;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.net.URL;
import java.util.List;
import javax.xml.stream.XMLStreamReader;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.XmlBeans;
import org.apache.xmlbeans.XmlException;
import org.apache.xmlbeans.XmlID;
import org.apache.xmlbeans.XmlObject;
import org.apache.xmlbeans.XmlOptions;
import org.apache.xmlbeans.xml.stream.XMLInputStream;
import org.apache.xmlbeans.xml.stream.XMLStreamException;
import org.w3.x2000.x09.xmldsig.CanonicalizationMethodType;
import org.w3c.dom.Node;

public interface GenericTimeStampType extends XmlObject {
  public static final SchemaType type = (SchemaType)XmlBeans.typeSystemForClassLoader(GenericTimeStampType.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s0B482D0B338CC9641C1543C3510577FE").resolveHandle("generictimestamptypecdadtype");
  
  List<IncludeType> getIncludeList();
  
  IncludeType[] getIncludeArray();
  
  IncludeType getIncludeArray(int paramInt);
  
  int sizeOfIncludeArray();
  
  void setIncludeArray(IncludeType[] paramArrayOfIncludeType);
  
  void setIncludeArray(int paramInt, IncludeType paramIncludeType);
  
  IncludeType insertNewInclude(int paramInt);
  
  IncludeType addNewInclude();
  
  void removeInclude(int paramInt);
  
  List<ReferenceInfoType> getReferenceInfoList();
  
  ReferenceInfoType[] getReferenceInfoArray();
  
  ReferenceInfoType getReferenceInfoArray(int paramInt);
  
  int sizeOfReferenceInfoArray();
  
  void setReferenceInfoArray(ReferenceInfoType[] paramArrayOfReferenceInfoType);
  
  void setReferenceInfoArray(int paramInt, ReferenceInfoType paramReferenceInfoType);
  
  ReferenceInfoType insertNewReferenceInfo(int paramInt);
  
  ReferenceInfoType addNewReferenceInfo();
  
  void removeReferenceInfo(int paramInt);
  
  CanonicalizationMethodType getCanonicalizationMethod();
  
  boolean isSetCanonicalizationMethod();
  
  void setCanonicalizationMethod(CanonicalizationMethodType paramCanonicalizationMethodType);
  
  CanonicalizationMethodType addNewCanonicalizationMethod();
  
  void unsetCanonicalizationMethod();
  
  List<EncapsulatedPKIDataType> getEncapsulatedTimeStampList();
  
  EncapsulatedPKIDataType[] getEncapsulatedTimeStampArray();
  
  EncapsulatedPKIDataType getEncapsulatedTimeStampArray(int paramInt);
  
  int sizeOfEncapsulatedTimeStampArray();
  
  void setEncapsulatedTimeStampArray(EncapsulatedPKIDataType[] paramArrayOfEncapsulatedPKIDataType);
  
  void setEncapsulatedTimeStampArray(int paramInt, EncapsulatedPKIDataType paramEncapsulatedPKIDataType);
  
  EncapsulatedPKIDataType insertNewEncapsulatedTimeStamp(int paramInt);
  
  EncapsulatedPKIDataType addNewEncapsulatedTimeStamp();
  
  void removeEncapsulatedTimeStamp(int paramInt);
  
  List<AnyType> getXMLTimeStampList();
  
  AnyType[] getXMLTimeStampArray();
  
  AnyType getXMLTimeStampArray(int paramInt);
  
  int sizeOfXMLTimeStampArray();
  
  void setXMLTimeStampArray(AnyType[] paramArrayOfAnyType);
  
  void setXMLTimeStampArray(int paramInt, AnyType paramAnyType);
  
  AnyType insertNewXMLTimeStamp(int paramInt);
  
  AnyType addNewXMLTimeStamp();
  
  void removeXMLTimeStamp(int paramInt);
  
  String getId();
  
  XmlID xgetId();
  
  boolean isSetId();
  
  void setId(String paramString);
  
  void xsetId(XmlID paramXmlID);
  
  void unsetId();
  
  public static final class Factory {
    public static GenericTimeStampType newInstance() {
      return (GenericTimeStampType)XmlBeans.getContextTypeLoader().newInstance(GenericTimeStampType.type, null);
    }
    
    public static GenericTimeStampType newInstance(XmlOptions param1XmlOptions) {
      return (GenericTimeStampType)XmlBeans.getContextTypeLoader().newInstance(GenericTimeStampType.type, param1XmlOptions);
    }
    
    public static GenericTimeStampType parse(String param1String) throws XmlException {
      return (GenericTimeStampType)XmlBeans.getContextTypeLoader().parse(param1String, GenericTimeStampType.type, null);
    }
    
    public static GenericTimeStampType parse(String param1String, XmlOptions param1XmlOptions) throws XmlException {
      return (GenericTimeStampType)XmlBeans.getContextTypeLoader().parse(param1String, GenericTimeStampType.type, param1XmlOptions);
    }
    
    public static GenericTimeStampType parse(File param1File) throws XmlException, IOException {
      return (GenericTimeStampType)XmlBeans.getContextTypeLoader().parse(param1File, GenericTimeStampType.type, null);
    }
    
    public static GenericTimeStampType parse(File param1File, XmlOptions param1XmlOptions) throws XmlException, IOException {
      return (GenericTimeStampType)XmlBeans.getContextTypeLoader().parse(param1File, GenericTimeStampType.type, param1XmlOptions);
    }
    
    public static GenericTimeStampType parse(URL param1URL) throws XmlException, IOException {
      return (GenericTimeStampType)XmlBeans.getContextTypeLoader().parse(param1URL, GenericTimeStampType.type, null);
    }
    
    public static GenericTimeStampType parse(URL param1URL, XmlOptions param1XmlOptions) throws XmlException, IOException {
      return (GenericTimeStampType)XmlBeans.getContextTypeLoader().parse(param1URL, GenericTimeStampType.type, param1XmlOptions);
    }
    
    public static GenericTimeStampType parse(InputStream param1InputStream) throws XmlException, IOException {
      return (GenericTimeStampType)XmlBeans.getContextTypeLoader().parse(param1InputStream, GenericTimeStampType.type, null);
    }
    
    public static GenericTimeStampType parse(InputStream param1InputStream, XmlOptions param1XmlOptions) throws XmlException, IOException {
      return (GenericTimeStampType)XmlBeans.getContextTypeLoader().parse(param1InputStream, GenericTimeStampType.type, param1XmlOptions);
    }
    
    public static GenericTimeStampType parse(Reader param1Reader) throws XmlException, IOException {
      return (GenericTimeStampType)XmlBeans.getContextTypeLoader().parse(param1Reader, GenericTimeStampType.type, null);
    }
    
    public static GenericTimeStampType parse(Reader param1Reader, XmlOptions param1XmlOptions) throws XmlException, IOException {
      return (GenericTimeStampType)XmlBeans.getContextTypeLoader().parse(param1Reader, GenericTimeStampType.type, param1XmlOptions);
    }
    
    public static GenericTimeStampType parse(XMLStreamReader param1XMLStreamReader) throws XmlException {
      return (GenericTimeStampType)XmlBeans.getContextTypeLoader().parse(param1XMLStreamReader, GenericTimeStampType.type, null);
    }
    
    public static GenericTimeStampType parse(XMLStreamReader param1XMLStreamReader, XmlOptions param1XmlOptions) throws XmlException {
      return (GenericTimeStampType)XmlBeans.getContextTypeLoader().parse(param1XMLStreamReader, GenericTimeStampType.type, param1XmlOptions);
    }
    
    public static GenericTimeStampType parse(Node param1Node) throws XmlException {
      return (GenericTimeStampType)XmlBeans.getContextTypeLoader().parse(param1Node, GenericTimeStampType.type, null);
    }
    
    public static GenericTimeStampType parse(Node param1Node, XmlOptions param1XmlOptions) throws XmlException {
      return (GenericTimeStampType)XmlBeans.getContextTypeLoader().parse(param1Node, GenericTimeStampType.type, param1XmlOptions);
    }
    
    public static GenericTimeStampType parse(XMLInputStream param1XMLInputStream) throws XmlException, XMLStreamException {
      return (GenericTimeStampType)XmlBeans.getContextTypeLoader().parse(param1XMLInputStream, GenericTimeStampType.type, null);
    }
    
    public static GenericTimeStampType parse(XMLInputStream param1XMLInputStream, XmlOptions param1XmlOptions) throws XmlException, XMLStreamException {
      return (GenericTimeStampType)XmlBeans.getContextTypeLoader().parse(param1XMLInputStream, GenericTimeStampType.type, param1XmlOptions);
    }
    
    public static XMLInputStream newValidatingXMLInputStream(XMLInputStream param1XMLInputStream) throws XmlException, XMLStreamException {
      return XmlBeans.getContextTypeLoader().newValidatingXMLInputStream(param1XMLInputStream, GenericTimeStampType.type, null);
    }
    
    public static XMLInputStream newValidatingXMLInputStream(XMLInputStream param1XMLInputStream, XmlOptions param1XmlOptions) throws XmlException, XMLStreamException {
      return XmlBeans.getContextTypeLoader().newValidatingXMLInputStream(param1XMLInputStream, GenericTimeStampType.type, param1XmlOptions);
    }
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/poi-ooxml-schemas-3.13.jar!/org/etsi/uri/x01903/v13/GenericTimeStampType.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */