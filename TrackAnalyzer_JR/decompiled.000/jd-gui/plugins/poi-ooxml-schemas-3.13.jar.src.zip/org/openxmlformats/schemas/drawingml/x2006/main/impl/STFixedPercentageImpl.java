package org.openxmlformats.schemas.drawingml.x2006.main.impl;

import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.impl.values.JavaIntHolderEx;
import org.openxmlformats.schemas.drawingml.x2006.main.STFixedPercentage;

public class STFixedPercentageImpl extends JavaIntHolderEx implements STFixedPercentage {
  public STFixedPercentageImpl(SchemaType paramSchemaType) {
    super(paramSchemaType, false);
  }
  
  protected STFixedPercentageImpl(SchemaType paramSchemaType, boolean paramBoolean) {
    super(paramSchemaType, paramBoolean);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/poi-ooxml-schemas-3.13.jar!/org/openxmlformats/schemas/drawingml/x2006/main/impl/STFixedPercentageImpl.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */