package org.openxmlformats.schemas.drawingml.x2006.main.impl;

import javax.xml.namespace.QName;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.SimpleValue;
import org.apache.xmlbeans.XmlObject;
import org.apache.xmlbeans.impl.values.XmlComplexContentImpl;
import org.openxmlformats.schemas.drawingml.x2006.main.CTLineJoinMiterProperties;
import org.openxmlformats.schemas.drawingml.x2006.main.STPositivePercentage;

public class CTLineJoinMiterPropertiesImpl extends XmlComplexContentImpl implements CTLineJoinMiterProperties {
  private static final QName LIM$0 = new QName("", "lim");
  
  public CTLineJoinMiterPropertiesImpl(SchemaType paramSchemaType) {
    super(paramSchemaType);
  }
  
  public int getLim() {
    synchronized (monitor()) {
      check_orphaned();
      SimpleValue simpleValue = null;
      simpleValue = (SimpleValue)get_store().find_attribute_user(LIM$0);
      if (simpleValue == null)
        return 0; 
      return simpleValue.getIntValue();
    } 
  }
  
  public STPositivePercentage xgetLim() {
    synchronized (monitor()) {
      check_orphaned();
      STPositivePercentage sTPositivePercentage = null;
      sTPositivePercentage = (STPositivePercentage)get_store().find_attribute_user(LIM$0);
      return sTPositivePercentage;
    } 
  }
  
  public boolean isSetLim() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().find_attribute_user(LIM$0) != null);
    } 
  }
  
  public void setLim(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      SimpleValue simpleValue = null;
      simpleValue = (SimpleValue)get_store().find_attribute_user(LIM$0);
      if (simpleValue == null)
        simpleValue = (SimpleValue)get_store().add_attribute_user(LIM$0); 
      simpleValue.setIntValue(paramInt);
    } 
  }
  
  public void xsetLim(STPositivePercentage paramSTPositivePercentage) {
    synchronized (monitor()) {
      check_orphaned();
      STPositivePercentage sTPositivePercentage = null;
      sTPositivePercentage = (STPositivePercentage)get_store().find_attribute_user(LIM$0);
      if (sTPositivePercentage == null)
        sTPositivePercentage = (STPositivePercentage)get_store().add_attribute_user(LIM$0); 
      sTPositivePercentage.set((XmlObject)paramSTPositivePercentage);
    } 
  }
  
  public void unsetLim() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_attribute(LIM$0);
    } 
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/poi-ooxml-schemas-3.13.jar!/org/openxmlformats/schemas/drawingml/x2006/main/impl/CTLineJoinMiterPropertiesImpl.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */