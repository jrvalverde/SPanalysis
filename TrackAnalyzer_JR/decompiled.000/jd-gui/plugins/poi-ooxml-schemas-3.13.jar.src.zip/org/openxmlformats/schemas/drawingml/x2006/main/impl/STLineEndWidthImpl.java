package org.openxmlformats.schemas.drawingml.x2006.main.impl;

import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.impl.values.JavaStringEnumerationHolderEx;
import org.openxmlformats.schemas.drawingml.x2006.main.STLineEndWidth;

public class STLineEndWidthImpl extends JavaStringEnumerationHolderEx implements STLineEndWidth {
  public STLineEndWidthImpl(SchemaType paramSchemaType) {
    super(paramSchemaType, false);
  }
  
  protected STLineEndWidthImpl(SchemaType paramSchemaType, boolean paramBoolean) {
    super(paramSchemaType, paramBoolean);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/poi-ooxml-schemas-3.13.jar!/org/openxmlformats/schemas/drawingml/x2006/main/impl/STLineEndWidthImpl.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */