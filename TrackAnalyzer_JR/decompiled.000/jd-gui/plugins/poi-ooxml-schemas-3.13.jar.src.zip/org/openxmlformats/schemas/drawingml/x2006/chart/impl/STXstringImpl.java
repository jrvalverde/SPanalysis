package org.openxmlformats.schemas.drawingml.x2006.chart.impl;

import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.impl.values.JavaStringHolderEx;
import org.openxmlformats.schemas.drawingml.x2006.chart.STXstring;

public class STXstringImpl extends JavaStringHolderEx implements STXstring {
  public STXstringImpl(SchemaType paramSchemaType) {
    super(paramSchemaType, false);
  }
  
  protected STXstringImpl(SchemaType paramSchemaType, boolean paramBoolean) {
    super(paramSchemaType, paramBoolean);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/poi-ooxml-schemas-3.13.jar!/org/openxmlformats/schemas/drawingml/x2006/chart/impl/STXstringImpl.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */