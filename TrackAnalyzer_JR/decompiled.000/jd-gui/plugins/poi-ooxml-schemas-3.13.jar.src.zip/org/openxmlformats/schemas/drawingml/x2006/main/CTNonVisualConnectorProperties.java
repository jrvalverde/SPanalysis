package org.openxmlformats.schemas.drawingml.x2006.main;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.net.URL;
import javax.xml.stream.XMLStreamReader;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.XmlBeans;
import org.apache.xmlbeans.XmlException;
import org.apache.xmlbeans.XmlObject;
import org.apache.xmlbeans.XmlOptions;
import org.apache.xmlbeans.xml.stream.XMLInputStream;
import org.apache.xmlbeans.xml.stream.XMLStreamException;
import org.w3c.dom.Node;

public interface CTNonVisualConnectorProperties extends XmlObject {
  public static final SchemaType type = (SchemaType)XmlBeans.typeSystemForClassLoader(CTNonVisualConnectorProperties.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.sE130CAA0A01A7CDE5A2B4FEB8B311707").resolveHandle("ctnonvisualconnectorproperties6f8etype");
  
  CTConnectorLocking getCxnSpLocks();
  
  boolean isSetCxnSpLocks();
  
  void setCxnSpLocks(CTConnectorLocking paramCTConnectorLocking);
  
  CTConnectorLocking addNewCxnSpLocks();
  
  void unsetCxnSpLocks();
  
  CTConnection getStCxn();
  
  boolean isSetStCxn();
  
  void setStCxn(CTConnection paramCTConnection);
  
  CTConnection addNewStCxn();
  
  void unsetStCxn();
  
  CTConnection getEndCxn();
  
  boolean isSetEndCxn();
  
  void setEndCxn(CTConnection paramCTConnection);
  
  CTConnection addNewEndCxn();
  
  void unsetEndCxn();
  
  CTOfficeArtExtensionList getExtLst();
  
  boolean isSetExtLst();
  
  void setExtLst(CTOfficeArtExtensionList paramCTOfficeArtExtensionList);
  
  CTOfficeArtExtensionList addNewExtLst();
  
  void unsetExtLst();
  
  public static final class Factory {
    public static CTNonVisualConnectorProperties newInstance() {
      return (CTNonVisualConnectorProperties)XmlBeans.getContextTypeLoader().newInstance(CTNonVisualConnectorProperties.type, null);
    }
    
    public static CTNonVisualConnectorProperties newInstance(XmlOptions param1XmlOptions) {
      return (CTNonVisualConnectorProperties)XmlBeans.getContextTypeLoader().newInstance(CTNonVisualConnectorProperties.type, param1XmlOptions);
    }
    
    public static CTNonVisualConnectorProperties parse(String param1String) throws XmlException {
      return (CTNonVisualConnectorProperties)XmlBeans.getContextTypeLoader().parse(param1String, CTNonVisualConnectorProperties.type, null);
    }
    
    public static CTNonVisualConnectorProperties parse(String param1String, XmlOptions param1XmlOptions) throws XmlException {
      return (CTNonVisualConnectorProperties)XmlBeans.getContextTypeLoader().parse(param1String, CTNonVisualConnectorProperties.type, param1XmlOptions);
    }
    
    public static CTNonVisualConnectorProperties parse(File param1File) throws XmlException, IOException {
      return (CTNonVisualConnectorProperties)XmlBeans.getContextTypeLoader().parse(param1File, CTNonVisualConnectorProperties.type, null);
    }
    
    public static CTNonVisualConnectorProperties parse(File param1File, XmlOptions param1XmlOptions) throws XmlException, IOException {
      return (CTNonVisualConnectorProperties)XmlBeans.getContextTypeLoader().parse(param1File, CTNonVisualConnectorProperties.type, param1XmlOptions);
    }
    
    public static CTNonVisualConnectorProperties parse(URL param1URL) throws XmlException, IOException {
      return (CTNonVisualConnectorProperties)XmlBeans.getContextTypeLoader().parse(param1URL, CTNonVisualConnectorProperties.type, null);
    }
    
    public static CTNonVisualConnectorProperties parse(URL param1URL, XmlOptions param1XmlOptions) throws XmlException, IOException {
      return (CTNonVisualConnectorProperties)XmlBeans.getContextTypeLoader().parse(param1URL, CTNonVisualConnectorProperties.type, param1XmlOptions);
    }
    
    public static CTNonVisualConnectorProperties parse(InputStream param1InputStream) throws XmlException, IOException {
      return (CTNonVisualConnectorProperties)XmlBeans.getContextTypeLoader().parse(param1InputStream, CTNonVisualConnectorProperties.type, null);
    }
    
    public static CTNonVisualConnectorProperties parse(InputStream param1InputStream, XmlOptions param1XmlOptions) throws XmlException, IOException {
      return (CTNonVisualConnectorProperties)XmlBeans.getContextTypeLoader().parse(param1InputStream, CTNonVisualConnectorProperties.type, param1XmlOptions);
    }
    
    public static CTNonVisualConnectorProperties parse(Reader param1Reader) throws XmlException, IOException {
      return (CTNonVisualConnectorProperties)XmlBeans.getContextTypeLoader().parse(param1Reader, CTNonVisualConnectorProperties.type, null);
    }
    
    public static CTNonVisualConnectorProperties parse(Reader param1Reader, XmlOptions param1XmlOptions) throws XmlException, IOException {
      return (CTNonVisualConnectorProperties)XmlBeans.getContextTypeLoader().parse(param1Reader, CTNonVisualConnectorProperties.type, param1XmlOptions);
    }
    
    public static CTNonVisualConnectorProperties parse(XMLStreamReader param1XMLStreamReader) throws XmlException {
      return (CTNonVisualConnectorProperties)XmlBeans.getContextTypeLoader().parse(param1XMLStreamReader, CTNonVisualConnectorProperties.type, null);
    }
    
    public static CTNonVisualConnectorProperties parse(XMLStreamReader param1XMLStreamReader, XmlOptions param1XmlOptions) throws XmlException {
      return (CTNonVisualConnectorProperties)XmlBeans.getContextTypeLoader().parse(param1XMLStreamReader, CTNonVisualConnectorProperties.type, param1XmlOptions);
    }
    
    public static CTNonVisualConnectorProperties parse(Node param1Node) throws XmlException {
      return (CTNonVisualConnectorProperties)XmlBeans.getContextTypeLoader().parse(param1Node, CTNonVisualConnectorProperties.type, null);
    }
    
    public static CTNonVisualConnectorProperties parse(Node param1Node, XmlOptions param1XmlOptions) throws XmlException {
      return (CTNonVisualConnectorProperties)XmlBeans.getContextTypeLoader().parse(param1Node, CTNonVisualConnectorProperties.type, param1XmlOptions);
    }
    
    public static CTNonVisualConnectorProperties parse(XMLInputStream param1XMLInputStream) throws XmlException, XMLStreamException {
      return (CTNonVisualConnectorProperties)XmlBeans.getContextTypeLoader().parse(param1XMLInputStream, CTNonVisualConnectorProperties.type, null);
    }
    
    public static CTNonVisualConnectorProperties parse(XMLInputStream param1XMLInputStream, XmlOptions param1XmlOptions) throws XmlException, XMLStreamException {
      return (CTNonVisualConnectorProperties)XmlBeans.getContextTypeLoader().parse(param1XMLInputStream, CTNonVisualConnectorProperties.type, param1XmlOptions);
    }
    
    public static XMLInputStream newValidatingXMLInputStream(XMLInputStream param1XMLInputStream) throws XmlException, XMLStreamException {
      return XmlBeans.getContextTypeLoader().newValidatingXMLInputStream(param1XMLInputStream, CTNonVisualConnectorProperties.type, null);
    }
    
    public static XMLInputStream newValidatingXMLInputStream(XMLInputStream param1XMLInputStream, XmlOptions param1XmlOptions) throws XmlException, XMLStreamException {
      return XmlBeans.getContextTypeLoader().newValidatingXMLInputStream(param1XMLInputStream, CTNonVisualConnectorProperties.type, param1XmlOptions);
    }
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/poi-ooxml-schemas-3.13.jar!/org/openxmlformats/schemas/drawingml/x2006/main/CTNonVisualConnectorProperties.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */