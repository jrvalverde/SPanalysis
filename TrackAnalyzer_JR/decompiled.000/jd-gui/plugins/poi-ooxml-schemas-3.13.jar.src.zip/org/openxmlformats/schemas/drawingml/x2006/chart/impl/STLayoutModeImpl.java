package org.openxmlformats.schemas.drawingml.x2006.chart.impl;

import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.impl.values.JavaStringEnumerationHolderEx;
import org.openxmlformats.schemas.drawingml.x2006.chart.STLayoutMode;

public class STLayoutModeImpl extends JavaStringEnumerationHolderEx implements STLayoutMode {
  public STLayoutModeImpl(SchemaType paramSchemaType) {
    super(paramSchemaType, false);
  }
  
  protected STLayoutModeImpl(SchemaType paramSchemaType, boolean paramBoolean) {
    super(paramSchemaType, paramBoolean);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/poi-ooxml-schemas-3.13.jar!/org/openxmlformats/schemas/drawingml/x2006/chart/impl/STLayoutModeImpl.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */