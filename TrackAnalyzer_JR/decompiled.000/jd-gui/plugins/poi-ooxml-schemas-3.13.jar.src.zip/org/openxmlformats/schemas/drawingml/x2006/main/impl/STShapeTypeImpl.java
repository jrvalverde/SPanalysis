package org.openxmlformats.schemas.drawingml.x2006.main.impl;

import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.impl.values.JavaStringEnumerationHolderEx;
import org.openxmlformats.schemas.drawingml.x2006.main.STShapeType;

public class STShapeTypeImpl extends JavaStringEnumerationHolderEx implements STShapeType {
  public STShapeTypeImpl(SchemaType paramSchemaType) {
    super(paramSchemaType, false);
  }
  
  protected STShapeTypeImpl(SchemaType paramSchemaType, boolean paramBoolean) {
    super(paramSchemaType, paramBoolean);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/poi-ooxml-schemas-3.13.jar!/org/openxmlformats/schemas/drawingml/x2006/main/impl/STShapeTypeImpl.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */