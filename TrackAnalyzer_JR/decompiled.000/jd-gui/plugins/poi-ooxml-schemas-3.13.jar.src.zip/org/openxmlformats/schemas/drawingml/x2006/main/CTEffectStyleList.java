package org.openxmlformats.schemas.drawingml.x2006.main;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.net.URL;
import java.util.List;
import javax.xml.stream.XMLStreamReader;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.XmlBeans;
import org.apache.xmlbeans.XmlException;
import org.apache.xmlbeans.XmlObject;
import org.apache.xmlbeans.XmlOptions;
import org.apache.xmlbeans.xml.stream.XMLInputStream;
import org.apache.xmlbeans.xml.stream.XMLStreamException;
import org.w3c.dom.Node;

public interface CTEffectStyleList extends XmlObject {
  public static final SchemaType type = (SchemaType)XmlBeans.typeSystemForClassLoader(CTEffectStyleList.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.sE130CAA0A01A7CDE5A2B4FEB8B311707").resolveHandle("cteffectstylelistc50ftype");
  
  List<CTEffectStyleItem> getEffectStyleList();
  
  CTEffectStyleItem[] getEffectStyleArray();
  
  CTEffectStyleItem getEffectStyleArray(int paramInt);
  
  int sizeOfEffectStyleArray();
  
  void setEffectStyleArray(CTEffectStyleItem[] paramArrayOfCTEffectStyleItem);
  
  void setEffectStyleArray(int paramInt, CTEffectStyleItem paramCTEffectStyleItem);
  
  CTEffectStyleItem insertNewEffectStyle(int paramInt);
  
  CTEffectStyleItem addNewEffectStyle();
  
  void removeEffectStyle(int paramInt);
  
  public static final class Factory {
    public static CTEffectStyleList newInstance() {
      return (CTEffectStyleList)XmlBeans.getContextTypeLoader().newInstance(CTEffectStyleList.type, null);
    }
    
    public static CTEffectStyleList newInstance(XmlOptions param1XmlOptions) {
      return (CTEffectStyleList)XmlBeans.getContextTypeLoader().newInstance(CTEffectStyleList.type, param1XmlOptions);
    }
    
    public static CTEffectStyleList parse(String param1String) throws XmlException {
      return (CTEffectStyleList)XmlBeans.getContextTypeLoader().parse(param1String, CTEffectStyleList.type, null);
    }
    
    public static CTEffectStyleList parse(String param1String, XmlOptions param1XmlOptions) throws XmlException {
      return (CTEffectStyleList)XmlBeans.getContextTypeLoader().parse(param1String, CTEffectStyleList.type, param1XmlOptions);
    }
    
    public static CTEffectStyleList parse(File param1File) throws XmlException, IOException {
      return (CTEffectStyleList)XmlBeans.getContextTypeLoader().parse(param1File, CTEffectStyleList.type, null);
    }
    
    public static CTEffectStyleList parse(File param1File, XmlOptions param1XmlOptions) throws XmlException, IOException {
      return (CTEffectStyleList)XmlBeans.getContextTypeLoader().parse(param1File, CTEffectStyleList.type, param1XmlOptions);
    }
    
    public static CTEffectStyleList parse(URL param1URL) throws XmlException, IOException {
      return (CTEffectStyleList)XmlBeans.getContextTypeLoader().parse(param1URL, CTEffectStyleList.type, null);
    }
    
    public static CTEffectStyleList parse(URL param1URL, XmlOptions param1XmlOptions) throws XmlException, IOException {
      return (CTEffectStyleList)XmlBeans.getContextTypeLoader().parse(param1URL, CTEffectStyleList.type, param1XmlOptions);
    }
    
    public static CTEffectStyleList parse(InputStream param1InputStream) throws XmlException, IOException {
      return (CTEffectStyleList)XmlBeans.getContextTypeLoader().parse(param1InputStream, CTEffectStyleList.type, null);
    }
    
    public static CTEffectStyleList parse(InputStream param1InputStream, XmlOptions param1XmlOptions) throws XmlException, IOException {
      return (CTEffectStyleList)XmlBeans.getContextTypeLoader().parse(param1InputStream, CTEffectStyleList.type, param1XmlOptions);
    }
    
    public static CTEffectStyleList parse(Reader param1Reader) throws XmlException, IOException {
      return (CTEffectStyleList)XmlBeans.getContextTypeLoader().parse(param1Reader, CTEffectStyleList.type, null);
    }
    
    public static CTEffectStyleList parse(Reader param1Reader, XmlOptions param1XmlOptions) throws XmlException, IOException {
      return (CTEffectStyleList)XmlBeans.getContextTypeLoader().parse(param1Reader, CTEffectStyleList.type, param1XmlOptions);
    }
    
    public static CTEffectStyleList parse(XMLStreamReader param1XMLStreamReader) throws XmlException {
      return (CTEffectStyleList)XmlBeans.getContextTypeLoader().parse(param1XMLStreamReader, CTEffectStyleList.type, null);
    }
    
    public static CTEffectStyleList parse(XMLStreamReader param1XMLStreamReader, XmlOptions param1XmlOptions) throws XmlException {
      return (CTEffectStyleList)XmlBeans.getContextTypeLoader().parse(param1XMLStreamReader, CTEffectStyleList.type, param1XmlOptions);
    }
    
    public static CTEffectStyleList parse(Node param1Node) throws XmlException {
      return (CTEffectStyleList)XmlBeans.getContextTypeLoader().parse(param1Node, CTEffectStyleList.type, null);
    }
    
    public static CTEffectStyleList parse(Node param1Node, XmlOptions param1XmlOptions) throws XmlException {
      return (CTEffectStyleList)XmlBeans.getContextTypeLoader().parse(param1Node, CTEffectStyleList.type, param1XmlOptions);
    }
    
    public static CTEffectStyleList parse(XMLInputStream param1XMLInputStream) throws XmlException, XMLStreamException {
      return (CTEffectStyleList)XmlBeans.getContextTypeLoader().parse(param1XMLInputStream, CTEffectStyleList.type, null);
    }
    
    public static CTEffectStyleList parse(XMLInputStream param1XMLInputStream, XmlOptions param1XmlOptions) throws XmlException, XMLStreamException {
      return (CTEffectStyleList)XmlBeans.getContextTypeLoader().parse(param1XMLInputStream, CTEffectStyleList.type, param1XmlOptions);
    }
    
    public static XMLInputStream newValidatingXMLInputStream(XMLInputStream param1XMLInputStream) throws XmlException, XMLStreamException {
      return XmlBeans.getContextTypeLoader().newValidatingXMLInputStream(param1XMLInputStream, CTEffectStyleList.type, null);
    }
    
    public static XMLInputStream newValidatingXMLInputStream(XMLInputStream param1XMLInputStream, XmlOptions param1XmlOptions) throws XmlException, XMLStreamException {
      return XmlBeans.getContextTypeLoader().newValidatingXMLInputStream(param1XMLInputStream, CTEffectStyleList.type, param1XmlOptions);
    }
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/poi-ooxml-schemas-3.13.jar!/org/openxmlformats/schemas/drawingml/x2006/main/CTEffectStyleList.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */