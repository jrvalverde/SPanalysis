package org.openxmlformats.schemas.drawingml.x2006.main;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.net.URL;
import javax.xml.stream.XMLStreamReader;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.XmlBeans;
import org.apache.xmlbeans.XmlException;
import org.apache.xmlbeans.XmlObject;
import org.apache.xmlbeans.XmlOptions;
import org.apache.xmlbeans.xml.stream.XMLInputStream;
import org.apache.xmlbeans.xml.stream.XMLStreamException;
import org.w3c.dom.Node;

public interface CTPath2DClose extends XmlObject {
  public static final SchemaType type = (SchemaType)XmlBeans.typeSystemForClassLoader(CTPath2DClose.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.sE130CAA0A01A7CDE5A2B4FEB8B311707").resolveHandle("ctpath2dclose09f2type");
  
  public static final class Factory {
    public static CTPath2DClose newInstance() {
      return (CTPath2DClose)XmlBeans.getContextTypeLoader().newInstance(CTPath2DClose.type, null);
    }
    
    public static CTPath2DClose newInstance(XmlOptions param1XmlOptions) {
      return (CTPath2DClose)XmlBeans.getContextTypeLoader().newInstance(CTPath2DClose.type, param1XmlOptions);
    }
    
    public static CTPath2DClose parse(String param1String) throws XmlException {
      return (CTPath2DClose)XmlBeans.getContextTypeLoader().parse(param1String, CTPath2DClose.type, null);
    }
    
    public static CTPath2DClose parse(String param1String, XmlOptions param1XmlOptions) throws XmlException {
      return (CTPath2DClose)XmlBeans.getContextTypeLoader().parse(param1String, CTPath2DClose.type, param1XmlOptions);
    }
    
    public static CTPath2DClose parse(File param1File) throws XmlException, IOException {
      return (CTPath2DClose)XmlBeans.getContextTypeLoader().parse(param1File, CTPath2DClose.type, null);
    }
    
    public static CTPath2DClose parse(File param1File, XmlOptions param1XmlOptions) throws XmlException, IOException {
      return (CTPath2DClose)XmlBeans.getContextTypeLoader().parse(param1File, CTPath2DClose.type, param1XmlOptions);
    }
    
    public static CTPath2DClose parse(URL param1URL) throws XmlException, IOException {
      return (CTPath2DClose)XmlBeans.getContextTypeLoader().parse(param1URL, CTPath2DClose.type, null);
    }
    
    public static CTPath2DClose parse(URL param1URL, XmlOptions param1XmlOptions) throws XmlException, IOException {
      return (CTPath2DClose)XmlBeans.getContextTypeLoader().parse(param1URL, CTPath2DClose.type, param1XmlOptions);
    }
    
    public static CTPath2DClose parse(InputStream param1InputStream) throws XmlException, IOException {
      return (CTPath2DClose)XmlBeans.getContextTypeLoader().parse(param1InputStream, CTPath2DClose.type, null);
    }
    
    public static CTPath2DClose parse(InputStream param1InputStream, XmlOptions param1XmlOptions) throws XmlException, IOException {
      return (CTPath2DClose)XmlBeans.getContextTypeLoader().parse(param1InputStream, CTPath2DClose.type, param1XmlOptions);
    }
    
    public static CTPath2DClose parse(Reader param1Reader) throws XmlException, IOException {
      return (CTPath2DClose)XmlBeans.getContextTypeLoader().parse(param1Reader, CTPath2DClose.type, null);
    }
    
    public static CTPath2DClose parse(Reader param1Reader, XmlOptions param1XmlOptions) throws XmlException, IOException {
      return (CTPath2DClose)XmlBeans.getContextTypeLoader().parse(param1Reader, CTPath2DClose.type, param1XmlOptions);
    }
    
    public static CTPath2DClose parse(XMLStreamReader param1XMLStreamReader) throws XmlException {
      return (CTPath2DClose)XmlBeans.getContextTypeLoader().parse(param1XMLStreamReader, CTPath2DClose.type, null);
    }
    
    public static CTPath2DClose parse(XMLStreamReader param1XMLStreamReader, XmlOptions param1XmlOptions) throws XmlException {
      return (CTPath2DClose)XmlBeans.getContextTypeLoader().parse(param1XMLStreamReader, CTPath2DClose.type, param1XmlOptions);
    }
    
    public static CTPath2DClose parse(Node param1Node) throws XmlException {
      return (CTPath2DClose)XmlBeans.getContextTypeLoader().parse(param1Node, CTPath2DClose.type, null);
    }
    
    public static CTPath2DClose parse(Node param1Node, XmlOptions param1XmlOptions) throws XmlException {
      return (CTPath2DClose)XmlBeans.getContextTypeLoader().parse(param1Node, CTPath2DClose.type, param1XmlOptions);
    }
    
    public static CTPath2DClose parse(XMLInputStream param1XMLInputStream) throws XmlException, XMLStreamException {
      return (CTPath2DClose)XmlBeans.getContextTypeLoader().parse(param1XMLInputStream, CTPath2DClose.type, null);
    }
    
    public static CTPath2DClose parse(XMLInputStream param1XMLInputStream, XmlOptions param1XmlOptions) throws XmlException, XMLStreamException {
      return (CTPath2DClose)XmlBeans.getContextTypeLoader().parse(param1XMLInputStream, CTPath2DClose.type, param1XmlOptions);
    }
    
    public static XMLInputStream newValidatingXMLInputStream(XMLInputStream param1XMLInputStream) throws XmlException, XMLStreamException {
      return XmlBeans.getContextTypeLoader().newValidatingXMLInputStream(param1XMLInputStream, CTPath2DClose.type, null);
    }
    
    public static XMLInputStream newValidatingXMLInputStream(XMLInputStream param1XMLInputStream, XmlOptions param1XmlOptions) throws XmlException, XMLStreamException {
      return XmlBeans.getContextTypeLoader().newValidatingXMLInputStream(param1XMLInputStream, CTPath2DClose.type, param1XmlOptions);
    }
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/poi-ooxml-schemas-3.13.jar!/org/openxmlformats/schemas/drawingml/x2006/main/CTPath2DClose.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */