/*     */ package fiji.plugin.trackmate;
/*     */ 
/*     */ import fiji.plugin.trackmate.detection.DetectionUtils;
/*     */ import fiji.plugin.trackmate.detection.SpotDetectorFactoryBase;
/*     */ import fiji.plugin.trackmate.features.FeatureAnalyzer;
/*     */ import fiji.plugin.trackmate.features.FeatureFilter;
/*     */ import fiji.plugin.trackmate.features.edges.EdgeAnalyzer;
/*     */ import fiji.plugin.trackmate.features.spot.SpotAnalyzerFactory;
/*     */ import fiji.plugin.trackmate.features.spot.SpotAnalyzerFactoryBase;
/*     */ import fiji.plugin.trackmate.features.track.TrackAnalyzer;
/*     */ import fiji.plugin.trackmate.providers.EdgeAnalyzerProvider;
/*     */ import fiji.plugin.trackmate.providers.SpotAnalyzerProvider;
/*     */ import fiji.plugin.trackmate.providers.SpotMorphologyAnalyzerProvider;
/*     */ import fiji.plugin.trackmate.providers.TrackAnalyzerProvider;
/*     */ import fiji.plugin.trackmate.tracking.SpotTrackerFactory;
/*     */ import ij.ImagePlus;
/*     */ import ij.gui.Roi;
/*     */ import ij.io.FileInfo;
/*     */ import java.awt.Rectangle;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Settings
/*     */ {
/*     */   public final ImagePlus imp;
/*     */   public double dt;
/*     */   public double dx;
/*     */   public double dy;
/*     */   public double dz;
/*     */   public int width;
/*     */   public int height;
/*     */   public int nslices;
/*     */   public int nframes;
/*     */   public String imageFolder;
/*     */   public String imageFileName;
/*     */   public Roi roi;
/*     */   public int tstart;
/*     */   public int tend;
/*     */   public int xstart;
/*     */   public int xend;
/*     */   public int ystart;
/*     */   public int yend;
/*     */   public int zstart;
/*     */   public int zend;
/*     */   public SpotDetectorFactoryBase<?> detectorFactory;
/*     */   public SpotTrackerFactory trackerFactory;
/* 145 */   public Map<String, Object> detectorSettings = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 152 */   public Map<String, Object> trackerSettings = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 159 */   protected List<FeatureFilter> spotFilters = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 165 */   public Double initialSpotFilterValue = Double.valueOf(0.0D);
/*     */ 
/*     */   
/* 168 */   protected List<FeatureFilter> trackFilters = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String errorMessage;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 179 */   protected List<SpotAnalyzerFactoryBase<?>> spotAnalyzerFactories = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 188 */   protected List<EdgeAnalyzer> edgeAnalyzers = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 197 */   protected List<TrackAnalyzer> trackAnalyzers = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Settings() {
/* 205 */     this(null);
/*     */   }
/*     */ 
/*     */   
/*     */   public Settings(ImagePlus imp) {
/* 210 */     this.imp = imp;
/* 211 */     if (null == imp) {
/*     */       
/* 213 */       this.dx = 1.0D;
/* 214 */       this.dy = 1.0D;
/* 215 */       this.dz = 1.0D;
/* 216 */       this.dt = 1.0D;
/* 217 */       this.width = 0;
/* 218 */       this.height = 0;
/* 219 */       this.imageFileName = "";
/* 220 */       this.imageFolder = "";
/* 221 */       this.nframes = 0;
/* 222 */       this.nslices = 0;
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 227 */     FileInfo fileInfo = imp.getOriginalFileInfo();
/* 228 */     if (null != fileInfo) {
/*     */       
/* 230 */       this.imageFileName = fileInfo.fileName;
/* 231 */       this.imageFolder = fileInfo.directory;
/*     */     }
/*     */     else {
/*     */       
/* 235 */       this.imageFileName = imp.getShortTitle();
/* 236 */       this.imageFolder = "";
/*     */     } 
/*     */ 
/*     */     
/* 240 */     this.width = imp.getWidth();
/* 241 */     this.height = imp.getHeight();
/* 242 */     this.nslices = imp.getNSlices();
/* 243 */     this.nframes = imp.getNFrames();
/* 244 */     this.dx = (imp.getCalibration()).pixelWidth;
/* 245 */     this.dy = (imp.getCalibration()).pixelHeight;
/* 246 */     this.dz = (imp.getCalibration()).pixelDepth;
/* 247 */     double ldt = (imp.getCalibration()).frameInterval;
/* 248 */     this.dt = (ldt == 0.0D) ? 1.0D : ldt;
/*     */ 
/*     */     
/* 251 */     this.zstart = 0;
/* 252 */     this.zend = imp.getNSlices() - 1;
/* 253 */     this.tstart = 0;
/* 254 */     this.tend = imp.getNFrames() - 1;
/* 255 */     this.roi = imp.getRoi();
/* 256 */     if (this.roi == null) {
/*     */       
/* 258 */       this.xstart = 0;
/* 259 */       this.xend = this.width - 1;
/* 260 */       this.ystart = 0;
/* 261 */       this.yend = this.height - 1;
/*     */     }
/*     */     else {
/*     */       
/* 265 */       Rectangle boundingRect = this.roi.getBounds();
/* 266 */       this.xstart = boundingRect.x;
/* 267 */       this.xend = boundingRect.width + boundingRect.x;
/* 268 */       this.ystart = boundingRect.y;
/* 269 */       this.yend = boundingRect.height + boundingRect.y;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Settings copyOn(ImagePlus newImp) {
/* 287 */     Settings newSettings = new Settings(newImp);
/* 288 */     if (this.detectorFactory != null)
/* 289 */       newSettings.detectorFactory = this.detectorFactory.copy(); 
/* 290 */     newSettings.detectorSettings = new HashMap<>(this.detectorSettings);
/* 291 */     if (this.trackerFactory != null)
/* 292 */       newSettings.trackerFactory = this.trackerFactory.copy(); 
/* 293 */     newSettings.trackerSettings = new HashMap<>(this.trackerSettings);
/* 294 */     newSettings.initialSpotFilterValue = this.initialSpotFilterValue;
/*     */     
/* 296 */     newSettings.spotFilters = new ArrayList<>();
/* 297 */     for (FeatureFilter filter : this.spotFilters) {
/* 298 */       newSettings.spotFilters.add(new FeatureFilter(filter.feature, filter.value, filter.isAbove));
/*     */     }
/* 300 */     newSettings.trackFilters = new ArrayList<>();
/* 301 */     for (FeatureFilter filter : this.trackFilters) {
/* 302 */       newSettings.trackFilters.add(new FeatureFilter(filter.feature, filter.value, filter.isAbove));
/*     */     }
/*     */     
/* 305 */     newSettings.addAllAnalyzers();
/* 306 */     return newSettings;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toStringImageInfo() {
/* 320 */     StringBuilder str = new StringBuilder();
/*     */     
/* 322 */     str.append("Image data:\n");
/* 323 */     if (null == this.imp) {
/*     */       
/* 325 */       str.append("Source image not set.\n");
/*     */     }
/*     */     else {
/*     */       
/* 329 */       str.append("For the image named: " + this.imp.getTitle() + ".\n");
/*     */     } 
/* 331 */     if (this.imageFileName == null || this.imageFileName == "") {
/*     */       
/* 333 */       str.append("Not matching any file.\n");
/*     */     }
/*     */     else {
/*     */       
/* 337 */       str.append("Matching file " + this.imageFileName + " ");
/* 338 */       if (this.imageFolder == null || this.imageFolder == "") {
/*     */         
/* 340 */         str.append("in current folder.\n");
/*     */       }
/*     */       else {
/*     */         
/* 344 */         str.append("in folder: " + this.imageFolder + "\n");
/*     */       } 
/*     */     } 
/*     */     
/* 348 */     str.append("Geometry:\n");
/* 349 */     str.append(String.format("  X = %4d - %4d, dx = %g\n", new Object[] { Integer.valueOf(this.xstart), Integer.valueOf(this.xend), Double.valueOf(this.dx) }));
/* 350 */     str.append(String.format("  Y = %4d - %4d, dy = %g\n", new Object[] { Integer.valueOf(this.ystart), Integer.valueOf(this.yend), Double.valueOf(this.dy) }));
/* 351 */     str.append(String.format("  Z = %4d - %4d, dz = %g\n", new Object[] { Integer.valueOf(this.zstart), Integer.valueOf(this.zend), Double.valueOf(this.dz) }));
/* 352 */     str.append(String.format("  T = %4d - %4d, dt = %g\n", new Object[] { Integer.valueOf(this.tstart), Integer.valueOf(this.tend), Double.valueOf(this.dt) }));
/*     */     
/* 354 */     return str.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public String toStringFeatureAnalyzersInfo() {
/* 359 */     StringBuilder str = new StringBuilder();
/*     */     
/* 361 */     if (this.spotAnalyzerFactories.isEmpty()) {
/*     */       
/* 363 */       str.append("No spot feature analyzers.\n");
/*     */     }
/*     */     else {
/*     */       
/* 367 */       str.append("Spot feature analyzers:\n");
/* 368 */       prettyPrintFeatureAnalyzer((List)this.spotAnalyzerFactories, str);
/*     */     } 
/*     */     
/* 371 */     if (this.edgeAnalyzers.isEmpty()) {
/*     */       
/* 373 */       str.append("No edge feature analyzers.\n");
/*     */     }
/*     */     else {
/*     */       
/* 377 */       str.append("Edge feature analyzers:\n");
/* 378 */       prettyPrintFeatureAnalyzer((List)this.edgeAnalyzers, str);
/*     */     } 
/*     */     
/* 381 */     if (this.trackAnalyzers.isEmpty()) {
/*     */       
/* 383 */       str.append("No track feature analyzers.\n");
/*     */     }
/*     */     else {
/*     */       
/* 387 */       str.append("Track feature analyzers:\n");
/* 388 */       prettyPrintFeatureAnalyzer((List)this.trackAnalyzers, str);
/*     */     } 
/*     */     
/* 391 */     return str.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 397 */     StringBuilder str = new StringBuilder();
/*     */     
/* 399 */     str.append(toStringImageInfo());
/*     */     
/* 401 */     str.append('\n');
/* 402 */     str.append("Spot detection:\n");
/* 403 */     if (null == this.detectorFactory) {
/*     */       
/* 405 */       str.append("No detector factory set.\n");
/*     */     }
/*     */     else {
/*     */       
/* 409 */       str.append("Detector: " + this.detectorFactory.toString() + ".\n");
/* 410 */       if (null == this.detectorSettings) {
/*     */         
/* 412 */         str.append("No detector settings found.\n");
/*     */       }
/*     */       else {
/*     */         
/* 416 */         str.append("Detector settings:\n");
/* 417 */         str.append(this.detectorSettings);
/* 418 */         str.append('\n');
/*     */       } 
/*     */     } 
/*     */     
/* 422 */     str.append('\n');
/* 423 */     str.append(toStringFeatureAnalyzersInfo());
/*     */     
/* 425 */     str.append('\n');
/* 426 */     str.append("Initial spot filter:\n");
/* 427 */     if (null == this.initialSpotFilterValue) {
/*     */       
/* 429 */       str.append("No initial quality filter.\n");
/*     */     }
/*     */     else {
/*     */       
/* 433 */       str.append("Initial quality filter value: " + this.initialSpotFilterValue + ".\n");
/*     */     } 
/*     */     
/* 436 */     str.append('\n');
/* 437 */     str.append("Spot feature filters:\n");
/* 438 */     if (this.spotFilters == null || this.spotFilters.size() == 0) {
/*     */       
/* 440 */       str.append("No spot feature filters.\n");
/*     */     }
/*     */     else {
/*     */       
/* 444 */       str.append("Set with " + this.spotFilters.size() + " spot feature filters:\n");
/* 445 */       for (FeatureFilter featureFilter : this.spotFilters)
/*     */       {
/* 447 */         str.append(" - " + featureFilter + "\n");
/*     */       }
/*     */     } 
/*     */     
/* 451 */     str.append('\n');
/* 452 */     str.append("Particle linking:\n");
/* 453 */     if (null == this.trackerFactory) {
/*     */       
/* 455 */       str.append("No spot tracker set.\n");
/*     */     }
/*     */     else {
/*     */       
/* 459 */       str.append("Tracker: " + this.trackerFactory.toString() + ".\n");
/* 460 */       if (null == this.trackerSettings) {
/*     */         
/* 462 */         str.append("No tracker settings found.\n");
/*     */       }
/*     */       else {
/*     */         
/* 466 */         str.append("Tracker settings:\n");
/* 467 */         str.append(this.trackerSettings);
/* 468 */         str.append('\n');
/*     */       } 
/*     */     } 
/*     */     
/* 472 */     str.append('\n');
/* 473 */     str.append("Track feature filters:\n");
/* 474 */     if (this.trackFilters == null || this.trackFilters.size() == 0) {
/*     */       
/* 476 */       str.append("No track feature filters.\n");
/*     */     }
/*     */     else {
/*     */       
/* 480 */       str.append("Set with " + this.trackFilters.size() + " track feature filters:\n");
/* 481 */       for (FeatureFilter featureFilter : this.trackFilters)
/*     */       {
/* 483 */         str.append(" - " + featureFilter + "\n");
/*     */       }
/*     */     } 
/*     */     
/* 487 */     return str.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean checkValidity() {
/* 492 */     if (null == this.imp) {
/*     */       
/* 494 */       this.errorMessage = "The source image is null.\n";
/* 495 */       return false;
/*     */     } 
/* 497 */     if (null == this.detectorFactory) {
/*     */       
/* 499 */       this.errorMessage = "The detector factory is null.\n";
/* 500 */       return false;
/*     */     } 
/* 502 */     if (null == this.detectorSettings) {
/*     */       
/* 504 */       this.errorMessage = "The detector settings is null.\n";
/* 505 */       return false;
/*     */     } 
/* 507 */     if (null == this.initialSpotFilterValue) {
/*     */       
/* 509 */       this.errorMessage = "Initial spot quality threshold is not set.\n";
/* 510 */       return false;
/*     */     } 
/* 512 */     if (null == this.trackerFactory) {
/*     */       
/* 514 */       this.errorMessage = "The tracker factory is null.\n";
/* 515 */       return false;
/*     */     } 
/* 517 */     if (!this.trackerFactory.checkSettingsValidity(this.trackerSettings)) {
/*     */       
/* 519 */       this.errorMessage = "The tracker has invalid input:\n" + this.trackerFactory.getErrorMessage();
/* 520 */       return false;
/*     */     } 
/* 522 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getErrorMessage() {
/* 527 */     return this.errorMessage;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addAllAnalyzers() {
/* 541 */     SpotAnalyzerProvider spotAnalyzerProvider = new SpotAnalyzerProvider((this.imp == null) ? 1 : this.imp.getNChannels());
/* 542 */     List<String> spotAnalyzerKeys = spotAnalyzerProvider.getKeys();
/* 543 */     for (String key : spotAnalyzerKeys) {
/* 544 */       addSpotAnalyzerFactory((SpotAnalyzerFactoryBase<?>)spotAnalyzerProvider.getFactory(key));
/*     */     }
/* 546 */     if (this.imp != null && DetectionUtils.is2D(this.imp) && this.detectorFactory != null && this.detectorFactory.has2Dsegmentation()) {
/*     */       
/* 548 */       SpotMorphologyAnalyzerProvider spotMorphologyAnalyzerProvider = new SpotMorphologyAnalyzerProvider(this.imp.getNChannels());
/* 549 */       List<String> spotMorphologyAnaylyzerKeys = spotMorphologyAnalyzerProvider.getKeys();
/* 550 */       for (String key : spotMorphologyAnaylyzerKeys) {
/* 551 */         addSpotAnalyzerFactory((SpotAnalyzerFactoryBase<?>)spotMorphologyAnalyzerProvider.getFactory(key));
/*     */       }
/*     */     } 
/* 554 */     EdgeAnalyzerProvider edgeAnalyzerProvider = new EdgeAnalyzerProvider();
/* 555 */     List<String> edgeAnalyzerKeys = edgeAnalyzerProvider.getKeys();
/* 556 */     for (String key : edgeAnalyzerKeys) {
/* 557 */       addEdgeAnalyzer((EdgeAnalyzer)edgeAnalyzerProvider.getFactory(key));
/*     */     }
/* 559 */     TrackAnalyzerProvider trackAnalyzerProvider = new TrackAnalyzerProvider();
/* 560 */     List<String> trackAnalyzerKeys = trackAnalyzerProvider.getKeys();
/* 561 */     for (String key : trackAnalyzerKeys) {
/* 562 */       addTrackAnalyzer((TrackAnalyzer)trackAnalyzerProvider.getFactory(key));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void clearSpotAnalyzerFactories() {
/* 574 */     this.spotAnalyzerFactories.clear();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<SpotAnalyzerFactoryBase<?>> getSpotAnalyzerFactories() {
/* 587 */     return new ArrayList<>(this.spotAnalyzerFactories);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addSpotAnalyzerFactory(SpotAnalyzerFactoryBase<?> spotAnalyzer) {
/* 600 */     if (contains(spotAnalyzer))
/*     */       return; 
/* 602 */     this.spotAnalyzerFactories.add(spotAnalyzer);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addSpotAnalyzerFactory(int index, SpotAnalyzerFactory<?> spotAnalyzer) {
/* 617 */     if (contains((SpotAnalyzerFactoryBase<?>)spotAnalyzer))
/*     */       return; 
/* 619 */     this.spotAnalyzerFactories.add(index, spotAnalyzer);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean removeSpotAnalyzerFactory(SpotAnalyzerFactory<?> spotAnalyzer) {
/* 633 */     return this.spotAnalyzerFactories.remove(spotAnalyzer);
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean contains(SpotAnalyzerFactoryBase<?> spotAnalyzer) {
/* 638 */     for (SpotAnalyzerFactoryBase<?> saf : this.spotAnalyzerFactories) {
/* 639 */       if (saf.getKey().equals(spotAnalyzer.getKey()))
/* 640 */         return true; 
/*     */     } 
/* 642 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void clearEdgeAnalyzers() {
/* 654 */     this.edgeAnalyzers.clear();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<EdgeAnalyzer> getEdgeAnalyzers() {
/* 667 */     return new ArrayList<>(this.edgeAnalyzers);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addEdgeAnalyzer(EdgeAnalyzer edgeAnalyzer) {
/* 679 */     if (contains(edgeAnalyzer))
/*     */       return; 
/* 681 */     this.edgeAnalyzers.add(edgeAnalyzer);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addEdgeAnalyzer(int index, EdgeAnalyzer edgeAnalyzer) {
/* 697 */     if (contains(edgeAnalyzer))
/*     */       return; 
/* 699 */     this.edgeAnalyzers.add(index, edgeAnalyzer);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean removeEdgeAnalyzer(EdgeAnalyzer edgeAnalyzer) {
/* 712 */     return this.edgeAnalyzers.remove(edgeAnalyzer);
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean contains(EdgeAnalyzer edgeAnalyzer) {
/* 717 */     for (EdgeAnalyzer ea : this.edgeAnalyzers) {
/* 718 */       if (ea.getKey().equals(edgeAnalyzer.getKey()))
/* 719 */         return true; 
/*     */     } 
/* 721 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void clearTrackAnalyzers() {
/* 733 */     this.trackAnalyzers.clear();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<TrackAnalyzer> getTrackAnalyzers() {
/* 746 */     return new ArrayList<>(this.trackAnalyzers);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addTrackAnalyzer(TrackAnalyzer trackAnalyzer) {
/* 758 */     if (contains(trackAnalyzer))
/*     */       return; 
/* 760 */     this.trackAnalyzers.add(trackAnalyzer);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addTrackAnalyzer(int index, TrackAnalyzer trackAnalyzer) {
/* 776 */     if (contains(trackAnalyzer))
/*     */       return; 
/* 778 */     this.trackAnalyzers.add(index, trackAnalyzer);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean removeTrackAnalyzer(TrackAnalyzer trackAnalyzer) {
/* 792 */     return this.trackAnalyzers.remove(trackAnalyzer);
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean contains(TrackAnalyzer trackAnalyzer) {
/* 797 */     for (TrackAnalyzer ta : this.trackAnalyzers) {
/* 798 */       if (ta.getKey().equals(trackAnalyzer.getKey()))
/* 799 */         return true; 
/*     */     } 
/* 801 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addSpotFilter(FeatureFilter filter) {
/* 816 */     this.spotFilters.add(filter);
/*     */   }
/*     */ 
/*     */   
/*     */   public void removeSpotFilter(FeatureFilter filter) {
/* 821 */     this.spotFilters.remove(filter);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void clearSpotFilters() {
/* 827 */     this.spotFilters.clear();
/*     */   }
/*     */ 
/*     */   
/*     */   public List<FeatureFilter> getSpotFilters() {
/* 832 */     return this.spotFilters;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setSpotFilters(List<FeatureFilter> spotFilters) {
/* 837 */     this.spotFilters = spotFilters;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addTrackFilter(FeatureFilter filter) {
/* 848 */     this.trackFilters.add(filter);
/*     */   }
/*     */ 
/*     */   
/*     */   public void removeTrackFilter(FeatureFilter filter) {
/* 853 */     this.trackFilters.remove(filter);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void clearTrackFilters() {
/* 859 */     this.trackFilters.clear();
/*     */   }
/*     */ 
/*     */   
/*     */   public List<FeatureFilter> getTrackFilters() {
/* 864 */     return this.trackFilters;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setTrackFilters(List<FeatureFilter> trackFilters) {
/* 869 */     this.trackFilters = trackFilters;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final void prettyPrintFeatureAnalyzer(List<? extends FeatureAnalyzer> analyzers, StringBuilder str) {
/* 878 */     for (FeatureAnalyzer analyzer : analyzers) {
/*     */       
/* 880 */       str.append(" - " + analyzer.getName() + " provides: ");
/* 881 */       for (String feature : analyzer.getFeatures()) {
/* 882 */         str.append((String)analyzer.getFeatureShortNames().get(feature) + ", ");
/*     */       }
/* 884 */       str.deleteCharAt(str.length() - 1);
/* 885 */       str.deleteCharAt(str.length() - 1);
/*     */       
/* 887 */       if (str.charAt(str.length() - 1) != '.') {
/* 888 */         str.append('.');
/*     */       }
/*     */       
/* 891 */       if (analyzer.isManualFeature()) {
/*     */         
/* 893 */         str.deleteCharAt(str.length() - 1);
/* 894 */         str.append("; is manual.");
/*     */       } 
/* 896 */       str.append('\n');
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/Settings.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */