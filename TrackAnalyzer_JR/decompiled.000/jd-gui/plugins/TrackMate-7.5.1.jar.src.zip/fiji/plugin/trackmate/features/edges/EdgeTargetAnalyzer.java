/*    */ package fiji.plugin.trackmate.features.edges;
/*    */ 
/*    */ import fiji.plugin.trackmate.Dimension;
/*    */ import fiji.plugin.trackmate.FeatureModel;
/*    */ import fiji.plugin.trackmate.Model;
/*    */ import fiji.plugin.trackmate.Spot;
/*    */ import java.util.ArrayList;
/*    */ import java.util.HashMap;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import org.jgrapht.graph.DefaultWeightedEdge;
/*    */ import org.scijava.plugin.Plugin;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Plugin(type = EdgeAnalyzer.class)
/*    */ public class EdgeTargetAnalyzer
/*    */   extends AbstractEdgeAnalyzer
/*    */ {
/*    */   public static final String KEY = "Edge target";
/*    */   public static final String SPOT_SOURCE_ID = "SPOT_SOURCE_ID";
/*    */   public static final String SPOT_TARGET_ID = "SPOT_TARGET_ID";
/*    */   public static final String EDGE_COST = "LINK_COST";
/* 46 */   public static final List<String> FEATURES = new ArrayList<>(3);
/* 47 */   public static final Map<String, String> FEATURE_NAMES = new HashMap<>(3);
/* 48 */   public static final Map<String, String> FEATURE_SHORT_NAMES = new HashMap<>(3);
/* 49 */   public static final Map<String, Dimension> FEATURE_DIMENSIONS = new HashMap<>(3);
/* 50 */   public static final Map<String, Boolean> IS_INT = new HashMap<>(3);
/*    */ 
/*    */   
/*    */   static {
/* 54 */     FEATURES.add("SPOT_SOURCE_ID");
/* 55 */     FEATURES.add("SPOT_TARGET_ID");
/* 56 */     FEATURES.add("LINK_COST");
/*    */     
/* 58 */     FEATURE_NAMES.put("SPOT_SOURCE_ID", "Source spot ID");
/* 59 */     FEATURE_NAMES.put("SPOT_TARGET_ID", "Target spot ID");
/* 60 */     FEATURE_NAMES.put("LINK_COST", "Edge cost");
/*    */     
/* 62 */     FEATURE_SHORT_NAMES.put("SPOT_SOURCE_ID", "Source ID");
/* 63 */     FEATURE_SHORT_NAMES.put("SPOT_TARGET_ID", "Target ID");
/* 64 */     FEATURE_SHORT_NAMES.put("LINK_COST", "Cost");
/*    */     
/* 66 */     FEATURE_DIMENSIONS.put("SPOT_SOURCE_ID", Dimension.NONE);
/* 67 */     FEATURE_DIMENSIONS.put("SPOT_TARGET_ID", Dimension.NONE);
/* 68 */     FEATURE_DIMENSIONS.put("LINK_COST", Dimension.COST);
/*    */     
/* 70 */     IS_INT.put("SPOT_SOURCE_ID", Boolean.TRUE);
/* 71 */     IS_INT.put("SPOT_TARGET_ID", Boolean.TRUE);
/* 72 */     IS_INT.put("LINK_COST", Boolean.FALSE);
/*    */   }
/*    */ 
/*    */   
/*    */   public EdgeTargetAnalyzer() {
/* 77 */     super("Edge target", "Edge target", FEATURES, FEATURE_NAMES, FEATURE_SHORT_NAMES, FEATURE_DIMENSIONS, IS_INT);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected void analyze(DefaultWeightedEdge edge, Model model) {
/* 83 */     FeatureModel featureModel = model.getFeatureModel();
/*    */     
/* 85 */     featureModel.putEdgeFeature(edge, "LINK_COST", Double.valueOf(model.getTrackModel().getEdgeWeight(edge)));
/*    */     
/* 87 */     Spot source = model.getTrackModel().getEdgeSource(edge);
/* 88 */     featureModel.putEdgeFeature(edge, "SPOT_SOURCE_ID", Double.valueOf(source.ID()));
/* 89 */     Spot target = model.getTrackModel().getEdgeTarget(edge);
/* 90 */     featureModel.putEdgeFeature(edge, "SPOT_TARGET_ID", Double.valueOf(target.ID()));
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/features/edges/EdgeTargetAnalyzer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */