/*    */ package fiji.plugin.trackmate.visualization;
/*    */ 
/*    */ import fiji.plugin.trackmate.Model;
/*    */ import fiji.plugin.trackmate.Spot;
/*    */ import fiji.plugin.trackmate.gui.displaysettings.Colormap;
/*    */ import java.awt.Color;
/*    */ import java.util.Set;
/*    */ import org.jgrapht.graph.DefaultWeightedEdge;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SpotColorGeneratorPerEdgeFeature
/*    */   implements FeatureColorGenerator<Spot>
/*    */ {
/*    */   private final Model model;
/*    */   private final Color missingValueColor;
/*    */   private final PerEdgeFeatureColorGenerator colorGenerator;
/*    */   
/*    */   public SpotColorGeneratorPerEdgeFeature(Model model, String edgeFeature, Color missingValueColor, Color undefinedValueColor, Colormap colormap, double min, double max) {
/* 51 */     this.model = model;
/* 52 */     this.missingValueColor = missingValueColor;
/* 53 */     this.colorGenerator = new PerEdgeFeatureColorGenerator(model, edgeFeature, missingValueColor, undefinedValueColor, colormap, min, max);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Color color(Spot spot) {
/* 59 */     Set<DefaultWeightedEdge> edges = this.model.getTrackModel().edgesOf(spot);
/* 60 */     DefaultWeightedEdge edge = null;
/* 61 */     for (DefaultWeightedEdge e : edges) {
/*    */       
/* 63 */       if (this.model.getTrackModel().getEdgeTarget(e).equals(spot)) {
/*    */         
/* 65 */         edge = e;
/*    */         break;
/*    */       } 
/*    */     } 
/* 69 */     if (edge == null) {
/* 70 */       return this.missingValueColor;
/*    */     }
/* 72 */     return this.colorGenerator.color(edge);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/visualization/SpotColorGeneratorPerEdgeFeature.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */