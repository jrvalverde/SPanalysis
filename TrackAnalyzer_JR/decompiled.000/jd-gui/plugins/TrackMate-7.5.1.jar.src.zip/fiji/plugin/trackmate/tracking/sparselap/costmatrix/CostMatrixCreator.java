package fiji.plugin.trackmate.tracking.sparselap.costmatrix;

import fiji.plugin.trackmate.tracking.sparselap.linker.SparseCostMatrix;
import java.util.List;
import net.imglib2.algorithm.Benchmark;
import net.imglib2.algorithm.OutputAlgorithm;

public interface CostMatrixCreator<K extends Comparable<K>, J extends Comparable<J>> extends Benchmark, OutputAlgorithm<SparseCostMatrix> {
  List<K> getSourceList();
  
  List<J> getTargetList();
  
  double getAlternativeCostForSource(K paramK);
  
  double getAlternativeCostForTarget(J paramJ);
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/tracking/sparselap/costmatrix/CostMatrixCreator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */