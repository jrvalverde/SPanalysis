/*     */ package fiji.plugin.trackmate.features.track;
/*     */ 
/*     */ import fiji.plugin.trackmate.Dimension;
/*     */ import fiji.plugin.trackmate.FeatureModel;
/*     */ import fiji.plugin.trackmate.Model;
/*     */ import fiji.plugin.trackmate.Spot;
/*     */ import fiji.plugin.trackmate.util.TMUtils;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import net.imglib2.RealLocalizable;
/*     */ import net.imglib2.util.Util;
/*     */ import org.jgrapht.graph.DefaultWeightedEdge;
/*     */ import org.scijava.plugin.Plugin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Plugin(type = TrackAnalyzer.class)
/*     */ public class TrackSpeedStatisticsAnalyzer
/*     */   extends AbstractTrackAnalyzer
/*     */ {
/*     */   public static final String KEY = "Track speed";
/*     */   public static final String TRACK_MEAN_SPEED = "TRACK_MEAN_SPEED";
/*     */   public static final String TRACK_MAX_SPEED = "TRACK_MAX_SPEED";
/*     */   public static final String TRACK_MIN_SPEED = "TRACK_MIN_SPEED";
/*     */   public static final String TRACK_MEDIAN_SPEED = "TRACK_MEDIAN_SPEED";
/*     */   public static final String TRACK_STD_SPEED = "TRACK_STD_SPEED";
/*  51 */   public static final List<String> FEATURES = new ArrayList<>(5);
/*  52 */   public static final Map<String, String> FEATURE_NAMES = new HashMap<>(5);
/*  53 */   public static final Map<String, String> FEATURE_SHORT_NAMES = new HashMap<>(5);
/*  54 */   public static final Map<String, Dimension> FEATURE_DIMENSIONS = new HashMap<>(5);
/*  55 */   public static final Map<String, Boolean> IS_INT = new HashMap<>(5);
/*     */ 
/*     */   
/*     */   static {
/*  59 */     FEATURES.add("TRACK_MEAN_SPEED");
/*  60 */     FEATURES.add("TRACK_MAX_SPEED");
/*  61 */     FEATURES.add("TRACK_MIN_SPEED");
/*  62 */     FEATURES.add("TRACK_MEDIAN_SPEED");
/*  63 */     FEATURES.add("TRACK_STD_SPEED");
/*     */     
/*  65 */     FEATURE_NAMES.put("TRACK_MEAN_SPEED", "Track mean speed");
/*  66 */     FEATURE_NAMES.put("TRACK_STD_SPEED", "Track std speed");
/*  67 */     FEATURE_NAMES.put("TRACK_MAX_SPEED", "Track max speed");
/*  68 */     FEATURE_NAMES.put("TRACK_MIN_SPEED", "Track min speed");
/*  69 */     FEATURE_NAMES.put("TRACK_MEDIAN_SPEED", "Track median speed");
/*     */     
/*  71 */     FEATURE_SHORT_NAMES.put("TRACK_MEAN_SPEED", "Mean sp.");
/*  72 */     FEATURE_SHORT_NAMES.put("TRACK_MAX_SPEED", "Max speed");
/*  73 */     FEATURE_SHORT_NAMES.put("TRACK_MIN_SPEED", "Min speed");
/*  74 */     FEATURE_SHORT_NAMES.put("TRACK_MEDIAN_SPEED", "Med. speed");
/*  75 */     FEATURE_SHORT_NAMES.put("TRACK_STD_SPEED", "Std speed");
/*     */     
/*  77 */     FEATURE_DIMENSIONS.put("TRACK_MEAN_SPEED", Dimension.VELOCITY);
/*  78 */     FEATURE_DIMENSIONS.put("TRACK_MAX_SPEED", Dimension.VELOCITY);
/*  79 */     FEATURE_DIMENSIONS.put("TRACK_MIN_SPEED", Dimension.VELOCITY);
/*  80 */     FEATURE_DIMENSIONS.put("TRACK_MEDIAN_SPEED", Dimension.VELOCITY);
/*  81 */     FEATURE_DIMENSIONS.put("TRACK_STD_SPEED", Dimension.VELOCITY);
/*     */     
/*  83 */     IS_INT.put("TRACK_MEAN_SPEED", Boolean.FALSE);
/*  84 */     IS_INT.put("TRACK_MAX_SPEED", Boolean.FALSE);
/*  85 */     IS_INT.put("TRACK_MIN_SPEED", Boolean.FALSE);
/*  86 */     IS_INT.put("TRACK_MEDIAN_SPEED", Boolean.FALSE);
/*  87 */     IS_INT.put("TRACK_STD_SPEED", Boolean.FALSE);
/*     */   }
/*     */ 
/*     */   
/*     */   public TrackSpeedStatisticsAnalyzer() {
/*  92 */     super("Track speed", "Track speed", FEATURES, FEATURE_NAMES, FEATURE_SHORT_NAMES, FEATURE_DIMENSIONS, IS_INT);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void analyze(Integer trackID, Model model) {
/*  98 */     FeatureModel fm = model.getFeatureModel();
/*  99 */     Set<DefaultWeightedEdge> track = model.getTrackModel().trackEdges(trackID);
/* 100 */     double[] speeds = new double[track.size()];
/* 101 */     int n = 0;
/* 102 */     for (DefaultWeightedEdge edge : track) {
/*     */       
/* 104 */       Spot source = model.getTrackModel().getEdgeSource(edge);
/* 105 */       Spot target = model.getTrackModel().getEdgeTarget(edge);
/* 106 */       double d2 = source.squareDistanceTo((RealLocalizable)target);
/* 107 */       double dt = source.diffTo(target, "POSITION_T");
/* 108 */       double val = Math.sqrt(d2) / Math.abs(dt);
/* 109 */       speeds[n++] = val;
/*     */     } 
/*     */     
/* 112 */     Util.quicksort(speeds, 0, track.size() - 1);
/* 113 */     double median = speeds[track.size() / 2];
/* 114 */     double min = speeds[0];
/* 115 */     double max = speeds[track.size() - 1];
/* 116 */     double mean = Util.average(speeds);
/* 117 */     double std = TMUtils.standardDeviation(speeds);
/*     */     
/* 119 */     fm.putTrackFeature(trackID, "TRACK_MEDIAN_SPEED", Double.valueOf(median));
/* 120 */     fm.putTrackFeature(trackID, "TRACK_MIN_SPEED", Double.valueOf(min));
/* 121 */     fm.putTrackFeature(trackID, "TRACK_MAX_SPEED", Double.valueOf(max));
/* 122 */     fm.putTrackFeature(trackID, "TRACK_MEAN_SPEED", Double.valueOf(mean));
/* 123 */     fm.putTrackFeature(trackID, "TRACK_STD_SPEED", Double.valueOf(std));
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/features/track/TrackSpeedStatisticsAnalyzer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */