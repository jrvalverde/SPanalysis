/*     */ package fiji.plugin.trackmate.tracking.overlap;
/*     */ 
/*     */ import fiji.plugin.trackmate.Model;
/*     */ import fiji.plugin.trackmate.SpotCollection;
/*     */ import fiji.plugin.trackmate.gui.components.ConfigurationPanel;
/*     */ import fiji.plugin.trackmate.io.IOUtils;
/*     */ import fiji.plugin.trackmate.tracking.SpotTracker;
/*     */ import fiji.plugin.trackmate.tracking.SpotTrackerFactory;
/*     */ import fiji.plugin.trackmate.util.TMUtils;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import javax.swing.ImageIcon;
/*     */ import org.jdom2.Element;
/*     */ import org.scijava.plugin.Plugin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Plugin(type = SpotTrackerFactory.class)
/*     */ public class OverlapTrackerFactory
/*     */   implements SpotTrackerFactory
/*     */ {
/*     */   static final String BASE_ERROR_MESSAGE = "[IoUTracker] ";
/*     */   public static final String KEY_SCALE_FACTOR = "SCALE_FACTOR";
/*  57 */   public static final Double DEFAULT_SCALE_FACTOR = Double.valueOf(1.0D);
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String KEY_MIN_IOU = "MIN_IOU";
/*     */ 
/*     */ 
/*     */   
/*  65 */   public static final Double DEFAULT_MIN_IOU = Double.valueOf(0.3D);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String KEY_IOU_CALCULATION = "IOU_CALCULATION";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  79 */   public static final String FAST_CALCULATION = OverlapTracker.IoUCalculation.FAST.name();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  86 */   public static final String PRECISE_CALCULATION = OverlapTracker.IoUCalculation.PRECISE.name();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String TRACKER_KEY = "OVERLAP_TRACKER";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String TRACKER_NAME = "Overlap tracker";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String TRACKER_INFO_TEXT = "<html> This tracker is a simple extension of the Intersection - over - Union (IoU) tracker. <p> <p> It generates links between spots whose shapes overlap between consecutive frames. When several spots are eligible as a source for a target, the one with the largest IoU is chosen.<p> <p> The minimal IoU parameter sets a threshold below which links won't be created. The scale factor allows for enlarging (&gt;1) or shrinking (&lt;1) the spot shapes before computing their IoU. Two methods can be used to compute IoU: The <it>Fast</it> one approximates  the spot shapes by their rectangular bounding-box. The <it>Precise</it> one uses the actual spot polygon. <p> <p> Careful: this tracker is only suited to 2D images. It treats all the spots as 2D objects. The Z dimension is ignored. </html>";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String errorMessage;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getKey() {
/* 117 */     return "OVERLAP_TRACKER";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/* 123 */     return "Overlap tracker";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getInfoText() {
/* 129 */     return "<html> This tracker is a simple extension of the Intersection - over - Union (IoU) tracker. <p> <p> It generates links between spots whose shapes overlap between consecutive frames. When several spots are eligible as a source for a target, the one with the largest IoU is chosen.<p> <p> The minimal IoU parameter sets a threshold below which links won't be created. The scale factor allows for enlarging (&gt;1) or shrinking (&lt;1) the spot shapes before computing their IoU. Two methods can be used to compute IoU: The <it>Fast</it> one approximates  the spot shapes by their rectangular bounding-box. The <it>Precise</it> one uses the actual spot polygon. <p> <p> Careful: this tracker is only suited to 2D images. It treats all the spots as 2D objects. The Z dimension is ignored. </html>";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ImageIcon getIcon() {
/* 135 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public SpotTracker create(SpotCollection spots, Map<String, Object> settings) {
/* 141 */     double pixelSize = ((Double)settings.get("SCALE_FACTOR")).doubleValue();
/* 142 */     double minIoU = ((Double)settings.get("MIN_IOU")).doubleValue();
/* 143 */     String methodStr = (String)settings.get("IOU_CALCULATION");
/* 144 */     OverlapTracker.IoUCalculation method = OverlapTracker.IoUCalculation.valueOf(methodStr);
/* 145 */     return new OverlapTracker(spots, method, minIoU, pixelSize);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ConfigurationPanel getTrackerConfigurationPanel(Model model) {
/* 151 */     return new OverlapTrackerSettingsPanel();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean marshall(Map<String, Object> settings, Element element) {
/* 157 */     boolean ok = true;
/* 158 */     StringBuilder str = new StringBuilder();
/*     */     
/* 160 */     ok &= IOUtils.writeAttribute(settings, element, "SCALE_FACTOR", Double.class, str);
/* 161 */     ok &= IOUtils.writeAttribute(settings, element, "MIN_IOU", Double.class, str);
/* 162 */     ok &= IOUtils.writeAttribute(settings, element, "IOU_CALCULATION", String.class, str);
/* 163 */     return ok;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean unmarshall(Element element, Map<String, Object> settings) {
/* 169 */     settings.clear();
/* 170 */     StringBuilder errorHolder = new StringBuilder();
/* 171 */     boolean ok = true;
/*     */     
/* 173 */     ok &= IOUtils.readDoubleAttribute(element, settings, "SCALE_FACTOR", errorHolder);
/* 174 */     ok &= IOUtils.readDoubleAttribute(element, settings, "MIN_IOU", errorHolder);
/* 175 */     ok &= IOUtils.readStringAttribute(element, settings, "IOU_CALCULATION", errorHolder);
/* 176 */     return ok;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString(Map<String, Object> settings) {
/* 182 */     if (!checkSettingsValidity(settings)) {
/* 183 */       return this.errorMessage;
/*     */     }
/* 185 */     double scale = ((Double)settings.get("SCALE_FACTOR")).doubleValue();
/* 186 */     double minIoU = ((Double)settings.get("MIN_IOU")).doubleValue();
/* 187 */     String methodStr = (String)settings.get("IOU_CALCULATION");
/* 188 */     OverlapTracker.IoUCalculation method = OverlapTracker.IoUCalculation.valueOf(methodStr);
/*     */     
/* 190 */     StringBuilder str = new StringBuilder();
/*     */     
/* 192 */     str.append(String.format("  - IoU calculation: %s\n", new Object[] { method.toString() }));
/* 193 */     str.append(String.format("  - scale factor: %.2f\n", new Object[] { Double.valueOf(scale) }));
/* 194 */     str.append(String.format("  - min. IoU: %.2f\n", new Object[] { Double.valueOf(minIoU) }));
/* 195 */     return str.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, Object> getDefaultSettings() {
/* 201 */     Map<String, Object> settings = new HashMap<>();
/* 202 */     settings.put("IOU_CALCULATION", PRECISE_CALCULATION);
/* 203 */     settings.put("SCALE_FACTOR", DEFAULT_SCALE_FACTOR);
/* 204 */     settings.put("MIN_IOU", DEFAULT_MIN_IOU);
/* 205 */     return settings;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean checkSettingsValidity(Map<String, Object> settings) {
/* 211 */     if (null == settings) {
/*     */       
/* 213 */       this.errorMessage = "[IoUTracker] Settings map is null.\n";
/* 214 */       return false;
/*     */     } 
/*     */     
/* 217 */     boolean ok = true;
/* 218 */     StringBuilder str = new StringBuilder();
/* 219 */     ok &= TMUtils.checkParameter(settings, "SCALE_FACTOR", Double.class, str);
/* 220 */     ok &= TMUtils.checkParameter(settings, "MIN_IOU", Double.class, str);
/* 221 */     ok &= TMUtils.checkParameter(settings, "IOU_CALCULATION", String.class, str);
/* 222 */     if (!ok) {
/*     */       
/* 224 */       this.errorMessage = str.toString();
/* 225 */       return false;
/*     */     } 
/*     */     
/* 228 */     double scale = ((Double)settings.get("SCALE_FACTOR")).doubleValue();
/* 229 */     if (scale <= 0.0D) {
/*     */       
/* 231 */       this.errorMessage = "[IoUTracker] Scale factor must be strictly positive, was " + scale;
/* 232 */       return false;
/*     */     } 
/*     */     
/* 235 */     String methodStr = "";
/*     */     
/*     */     try {
/* 238 */       methodStr = (String)settings.get("IOU_CALCULATION");
/* 239 */       OverlapTracker.IoUCalculation.valueOf(methodStr);
/*     */     }
/* 241 */     catch (IllegalArgumentException e) {
/*     */       
/* 243 */       this.errorMessage = "[IoUTracker] Unknown IoU calculation method: " + methodStr;
/* 244 */       return false;
/*     */     } 
/* 246 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getErrorMessage() {
/* 252 */     return this.errorMessage;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public OverlapTrackerFactory copy() {
/* 258 */     return new OverlapTrackerFactory();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/tracking/overlap/OverlapTrackerFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */