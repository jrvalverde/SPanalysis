/*     */ package fiji.plugin.trackmate.action;
/*     */ 
/*     */ import fiji.plugin.trackmate.Model;
/*     */ import fiji.plugin.trackmate.SelectionModel;
/*     */ import fiji.plugin.trackmate.Spot;
/*     */ import fiji.plugin.trackmate.TrackMate;
/*     */ import fiji.plugin.trackmate.TrackModel;
/*     */ import fiji.plugin.trackmate.gui.Icons;
/*     */ import fiji.plugin.trackmate.gui.displaysettings.DisplaySettings;
/*     */ import java.awt.Frame;
/*     */ import java.util.Set;
/*     */ import javax.swing.ImageIcon;
/*     */ import net.imglib2.RealLocalizable;
/*     */ import net.imglib2.RealPoint;
/*     */ import org.jgrapht.graph.DefaultWeightedEdge;
/*     */ import org.scijava.plugin.Plugin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CloseGapsByLinearInterpolationAction
/*     */   extends AbstractTMAction
/*     */ {
/*     */   public static final String NAME = "Close gaps by introducing new spots";
/*     */   public static final String KEY = "CLOSE_GAPS_BY_LINEAR_INPERPOLATION";
/*     */   public static final String INFO_TEXT = "<html>This action closes gaps in tracks by introducing new spots. The spots positions and size are calculated using linear interpolation.</html>";
/*     */   
/*     */   public void execute(TrackMate trackmate, SelectionModel selectionModel, DisplaySettings displaySettings, Frame parent) {
/*  71 */     Model model = trackmate.getModel();
/*  72 */     TrackModel trackModel = model.getTrackModel();
/*  73 */     boolean changed = true;
/*     */     
/*  75 */     this.logger.log("Interpolating gaps.\n");
/*  76 */     model.beginUpdate();
/*     */ 
/*     */     
/*     */     try {
/*  80 */       while (changed) {
/*     */         
/*  82 */         changed = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*  88 */         Set<DefaultWeightedEdge> edges = model.getTrackModel().edgeSet();
/*  89 */         for (DefaultWeightedEdge edge : edges)
/*     */         {
/*  91 */           Spot currentSpot = trackModel.getEdgeSource(edge);
/*  92 */           Spot nextSpot = trackModel.getEdgeTarget(edge);
/*     */           
/*  94 */           int currentFrame = currentSpot.getFeature("FRAME").intValue();
/*  95 */           int nextFrame = nextSpot.getFeature("FRAME").intValue();
/*     */           
/*  97 */           if (Math.abs(nextFrame - currentFrame) > 1)
/*     */           {
/*  99 */             int presign = (nextFrame > currentFrame) ? 1 : -1;
/*     */             
/* 101 */             double[] currentPosition = new double[3];
/* 102 */             double[] nextPosition = new double[3];
/*     */             
/* 104 */             nextSpot.localize(nextPosition);
/* 105 */             currentSpot.localize(currentPosition);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 111 */             Spot formerSpot = currentSpot;
/* 112 */             int nspots = 0;
/* 113 */             int f = currentFrame + presign;
/* 114 */             for (; (f < nextFrame && presign == 1) || (f > nextFrame && presign == -1); f += presign) {
/*     */               
/* 116 */               double weight = (nextFrame - f) / (nextFrame - currentFrame);
/*     */               
/* 118 */               double[] position = new double[3];
/* 119 */               for (int d = 0; d < currentSpot.numDimensions(); d++) {
/* 120 */                 position[d] = weight * currentPosition[d] + (1.0D - weight) * nextPosition[d];
/*     */               }
/* 122 */               RealPoint rp = new RealPoint(position);
/* 123 */               Spot newSpot = new Spot((RealLocalizable)rp, 0.0D, 0.0D);
/*     */ 
/*     */               
/* 126 */               interpolateFeature(newSpot, currentSpot, nextSpot, weight, "RADIUS");
/* 127 */               interpolateFeature(newSpot, currentSpot, nextSpot, weight, "QUALITY");
/* 128 */               interpolateFeature(newSpot, currentSpot, nextSpot, weight, "POSITION_T");
/*     */               
/* 130 */               model.addSpotTo(newSpot, Integer.valueOf(f));
/* 131 */               model.addEdge(formerSpot, newSpot, 1.0D);
/* 132 */               formerSpot = newSpot;
/* 133 */               nspots++;
/*     */             } 
/* 135 */             model.addEdge(formerSpot, nextSpot, 1.0D);
/* 136 */             model.removeEdge(currentSpot, nextSpot);
/* 137 */             this.logger.log("Added " + nspots + " new spots between spots " + currentSpot + " and " + nextSpot + ".\n");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 143 */             changed = true;
/*     */           }
/*     */         
/*     */         }
/*     */       
/*     */       } 
/*     */     } finally {
/*     */       
/* 151 */       model.endUpdate();
/*     */     } 
/* 153 */     this.logger.log("Finished.\n");
/*     */   }
/*     */ 
/*     */   
/*     */   private void interpolateFeature(Spot targetSpot, Spot spot1, Spot spot2, double weight, String feature) {
/* 158 */     if (targetSpot.getFeatures().containsKey(feature))
/*     */     {
/* 160 */       targetSpot.getFeatures().remove(feature);
/*     */     }
/*     */     
/* 163 */     targetSpot.getFeatures().put(feature, 
/* 164 */         Double.valueOf(weight * spot1.getFeature(feature).doubleValue() + (1.0D - weight) * spot2.getFeature(feature).doubleValue()));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Plugin(type = TrackMateActionFactory.class)
/*     */   public static class Factory
/*     */     implements TrackMateActionFactory
/*     */   {
/*     */     public String getInfoText() {
/* 174 */       return "<html>This action closes gaps in tracks by introducing new spots. The spots positions and size are calculated using linear interpolation.</html>";
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public String getName() {
/* 180 */       return "Close gaps by introducing new spots";
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public String getKey() {
/* 186 */       return "CLOSE_GAPS_BY_LINEAR_INPERPOLATION";
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public ImageIcon getIcon() {
/* 192 */       return Icons.ORANGE_ASTERISK_ICON;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public TrackMateAction create() {
/* 198 */       return new CloseGapsByLinearInterpolationAction();
/*     */     }
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/action/CloseGapsByLinearInterpolationAction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */