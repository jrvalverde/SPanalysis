/*     */ package fiji.plugin.trackmate.tracking;
/*     */ 
/*     */ import fiji.plugin.trackmate.Spot;
/*     */ import fiji.plugin.trackmate.util.TMUtils;
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Dimension;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javax.swing.JFrame;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JScrollPane;
/*     */ import javax.swing.JTable;
/*     */ import javax.swing.border.Border;
/*     */ import javax.swing.border.LineBorder;
/*     */ import javax.swing.table.AbstractTableModel;
/*     */ import javax.swing.table.DefaultTableModel;
/*     */ import javax.swing.table.TableCellRenderer;
/*     */ import javax.swing.table.TableModel;
/*     */ import net.imglib2.RealLocalizable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LAPUtils
/*     */ {
/*  82 */   private static final Border RED_BORDER = new LineBorder(Color.RED);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String XML_ELEMENT_NAME_LINKING = "Linking";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String XML_ELEMENT_NAME_GAP_CLOSING = "GapClosing";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String XML_ELEMENT_NAME_MERGING = "TrackMerging";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String XML_ELEMENT_NAME_SPLITTING = "TrackSplitting";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String XML_ELEMENT_NAME_FEATURE_PENALTIES = "FeaturePenalties";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final boolean addFeaturePenaltyToSettings(Map<?, ?> motherMap, Object motherKey, Object childKey, Object childValue, StringBuilder errorHolder) {
/* 114 */     Object childObj = motherMap.get(motherKey);
/* 115 */     if (null == childObj) {
/* 116 */       errorHolder.append("Mother map has no value for key " + motherKey + ".\n");
/* 117 */       return false;
/*     */     } 
/* 119 */     if (!(childObj instanceof Map)) {
/* 120 */       errorHolder.append("Value for key " + motherKey + " is not a map.\n");
/* 121 */       return false;
/*     */     } 
/*     */ 
/*     */     
/* 125 */     Map<Object, Object> childMap = (Map<Object, Object>)childObj;
/* 126 */     childMap.put(childKey, childValue);
/* 127 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final Map<String, Object> getDefaultLAPSettingsMap() {
/* 137 */     Map<String, Object> settings = new HashMap<>();
/*     */     
/* 139 */     settings.put("LINKING_MAX_DISTANCE", Double.valueOf(15.0D));
/* 140 */     settings.put("LINKING_FEATURE_PENALTIES", new HashMap<>(TrackerKeys.DEFAULT_LINKING_FEATURE_PENALTIES));
/*     */     
/* 142 */     settings.put("ALLOW_GAP_CLOSING", Boolean.valueOf(true));
/* 143 */     settings.put("MAX_FRAME_GAP", Integer.valueOf(2));
/* 144 */     settings.put("GAP_CLOSING_MAX_DISTANCE", Double.valueOf(15.0D));
/* 145 */     settings.put("GAP_CLOSING_FEATURE_PENALTIES", new HashMap<>(TrackerKeys.DEFAULT_GAP_CLOSING_FEATURE_PENALTIES));
/*     */     
/* 147 */     settings.put("ALLOW_TRACK_SPLITTING", Boolean.valueOf(false));
/* 148 */     settings.put("SPLITTING_MAX_DISTANCE", Double.valueOf(15.0D));
/* 149 */     settings.put("SPLITTING_FEATURE_PENALTIES", new HashMap<>(TrackerKeys.DEFAULT_SPLITTING_FEATURE_PENALTIES));
/*     */     
/* 151 */     settings.put("ALLOW_TRACK_MERGING", Boolean.valueOf(false));
/* 152 */     settings.put("MERGING_MAX_DISTANCE", Double.valueOf(15.0D));
/* 153 */     settings.put("MERGING_FEATURE_PENALTIES", new HashMap<>(TrackerKeys.DEFAULT_MERGING_FEATURE_PENALTIES));
/*     */     
/* 155 */     settings.put("BLOCKING_VALUE", Double.valueOf(Double.POSITIVE_INFINITY));
/* 156 */     settings.put("ALTERNATIVE_LINKING_COST_FACTOR", Double.valueOf(1.05D));
/* 157 */     settings.put("CUTOFF_PERCENTILE", Double.valueOf(0.9D));
/*     */     
/* 159 */     return settings;
/*     */   }
/*     */ 
/*     */   
/*     */   public static String echoFeaturePenalties(Map<String, Double> featurePenalties) {
/* 164 */     String str = "";
/* 165 */     if (featurePenalties.isEmpty()) {
/* 166 */       str = str + "    - no feature penalties\n";
/*     */     } else {
/* 168 */       str = str + "    - with feature penalties:\n";
/* 169 */       for (String feature : featurePenalties.keySet()) {
/* 170 */         str = str + "      - " + feature.toString() + ": weight = " + String.format("%.1f", new Object[] { featurePenalties.get(feature) }) + '\n';
/*     */       } 
/*     */     } 
/* 173 */     return str;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final double computeLinkingCostFor(Spot s0, Spot s1, double distanceCutOff, double blockingValue, Map<String, Double> featurePenalties) {
/* 203 */     double d2 = s0.squareDistanceTo((RealLocalizable)s1);
/*     */ 
/*     */     
/* 206 */     if (d2 > distanceCutOff * distanceCutOff) {
/* 207 */       return blockingValue;
/*     */     }
/*     */     
/* 210 */     double penalty = 1.0D;
/* 211 */     for (String feature : featurePenalties.keySet()) {
/* 212 */       double ndiff = s0.normalizeDiffTo(s1, feature);
/* 213 */       if (Double.isNaN(ndiff))
/*     */         continue; 
/* 215 */       double factor = ((Double)featurePenalties.get(feature)).doubleValue();
/* 216 */       penalty += factor * 1.5D * ndiff;
/*     */     } 
/*     */ 
/*     */     
/* 220 */     return d2 * penalty * penalty;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final boolean checkSettingsValidity(Map<String, Object> settings, StringBuilder errorHolder) {
/* 239 */     if (null == settings) {
/* 240 */       errorHolder.append("Settings map is null.\n");
/* 241 */       return false;
/*     */     } 
/*     */     
/* 244 */     boolean ok = true;
/*     */     
/* 246 */     ok &= TMUtils.checkParameter(settings, "LINKING_MAX_DISTANCE", Double.class, errorHolder);
/* 247 */     ok &= checkFeatureMap(settings, "LINKING_FEATURE_PENALTIES", errorHolder);
/*     */     
/* 249 */     ok &= TMUtils.checkParameter(settings, "ALLOW_GAP_CLOSING", Boolean.class, errorHolder);
/* 250 */     ok &= TMUtils.checkParameter(settings, "GAP_CLOSING_MAX_DISTANCE", Double.class, errorHolder);
/* 251 */     ok &= TMUtils.checkParameter(settings, "MAX_FRAME_GAP", Integer.class, errorHolder);
/* 252 */     ok &= checkFeatureMap(settings, "GAP_CLOSING_FEATURE_PENALTIES", errorHolder);
/*     */     
/* 254 */     ok &= TMUtils.checkParameter(settings, "ALLOW_TRACK_SPLITTING", Boolean.class, errorHolder);
/* 255 */     ok &= TMUtils.checkParameter(settings, "SPLITTING_MAX_DISTANCE", Double.class, errorHolder);
/* 256 */     ok &= checkFeatureMap(settings, "SPLITTING_FEATURE_PENALTIES", errorHolder);
/*     */     
/* 258 */     ok &= TMUtils.checkParameter(settings, "ALLOW_TRACK_MERGING", Boolean.class, errorHolder);
/* 259 */     ok &= TMUtils.checkParameter(settings, "MERGING_MAX_DISTANCE", Double.class, errorHolder);
/* 260 */     ok &= checkFeatureMap(settings, "MERGING_FEATURE_PENALTIES", errorHolder);
/*     */     
/* 262 */     ok &= TMUtils.checkParameter(settings, "CUTOFF_PERCENTILE", Double.class, errorHolder);
/* 263 */     ok &= TMUtils.checkParameter(settings, "ALTERNATIVE_LINKING_COST_FACTOR", Double.class, errorHolder);
/* 264 */     ok &= TMUtils.checkParameter(settings, "BLOCKING_VALUE", Double.class, errorHolder);
/*     */ 
/*     */     
/* 267 */     List<String> mandatoryKeys = new ArrayList<>();
/* 268 */     mandatoryKeys.add("LINKING_MAX_DISTANCE");
/* 269 */     mandatoryKeys.add("ALLOW_GAP_CLOSING");
/* 270 */     mandatoryKeys.add("GAP_CLOSING_MAX_DISTANCE");
/* 271 */     mandatoryKeys.add("MAX_FRAME_GAP");
/* 272 */     mandatoryKeys.add("ALLOW_TRACK_SPLITTING");
/* 273 */     mandatoryKeys.add("SPLITTING_MAX_DISTANCE");
/* 274 */     mandatoryKeys.add("ALLOW_TRACK_MERGING");
/* 275 */     mandatoryKeys.add("MERGING_MAX_DISTANCE");
/* 276 */     mandatoryKeys.add("ALTERNATIVE_LINKING_COST_FACTOR");
/* 277 */     mandatoryKeys.add("CUTOFF_PERCENTILE");
/* 278 */     mandatoryKeys.add("BLOCKING_VALUE");
/* 279 */     List<String> optionalKeys = new ArrayList<>();
/* 280 */     optionalKeys.add("LINKING_FEATURE_PENALTIES");
/* 281 */     optionalKeys.add("GAP_CLOSING_FEATURE_PENALTIES");
/* 282 */     optionalKeys.add("SPLITTING_FEATURE_PENALTIES");
/* 283 */     optionalKeys.add("MERGING_FEATURE_PENALTIES");
/* 284 */     ok &= TMUtils.checkMapKeys(settings, mandatoryKeys, optionalKeys, errorHolder);
/*     */     
/* 286 */     return ok;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final boolean checkFeatureMap(Map<String, Object> map, String featurePenaltiesKey, StringBuilder errorHolder) {
/* 307 */     Object obj = map.get(featurePenaltiesKey);
/* 308 */     if (null == obj) {
/* 309 */       return true;
/*     */     }
/* 311 */     if (!(obj instanceof Map)) {
/* 312 */       errorHolder.append("Feature penalty map is not of the right class. Expected a Map, got a " + obj.getClass().getName() + ".\n");
/* 313 */       return false;
/*     */     } 
/* 315 */     boolean ok = true;
/* 316 */     Map fpMap = (Map)obj;
/* 317 */     Set fpKeys = fpMap.keySet();
/* 318 */     for (Object fpKey : fpKeys) {
/* 319 */       if (!(fpKey instanceof String)) {
/* 320 */         ok = false;
/* 321 */         errorHolder.append("One key (" + fpKey.toString() + ") in the map is not of the right class.\nExpected String, got " + fpKey
/* 322 */             .getClass().getName() + ".\n");
/*     */       } 
/* 324 */       Object fpVal = fpMap.get(fpKey);
/* 325 */       if (!(fpVal instanceof Double)) {
/* 326 */         ok = false;
/* 327 */         errorHolder.append("The value for key " + fpVal.toString() + " in the map is not of the right class.\nExpected Double, got " + fpVal
/* 328 */             .getClass().getName() + ".\n");
/*     */       } 
/*     */     } 
/* 331 */     return ok;
/*     */   }
/*     */   
/*     */   public static final void echoMatrix(double[][] m) {
/* 335 */     int nlines = m.length;
/* 336 */     if (nlines == 0) {
/* 337 */       System.out.println("0x0 empty matrix");
/*     */       return;
/*     */     } 
/* 340 */     int nrows = (m[0]).length;
/*     */     
/* 342 */     System.out.print("L\\C\t");
/* 343 */     for (int j = 0; j < nrows; j++) {
/* 344 */       System.out.print(String.format("%7d: ", new Object[] { Integer.valueOf(j) }));
/*     */     } 
/* 346 */     System.out.println();
/* 347 */     for (int i = 0; i < nlines; i++) {
/* 348 */       System.out.print(i + ":\t");
/* 349 */       for (int k = 0; k < nrows; k++) {
/* 350 */         double val = m[i][k];
/* 351 */         if (val > 8.988465674311579E307D) {
/* 352 */           System.out.print("     B   ");
/*     */         } else {
/* 354 */           System.out.print(String.format("%7.1f  ", new Object[] { Double.valueOf(val) }));
/*     */         } 
/* 356 */       }  System.out.println();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final void displayCostMatrix(double[][] costs, final int nSegments, final int nSpots, double blockingValue, final int[][] solutions) {
/* 369 */     int width = costs.length;
/* 370 */     int height = (costs[0]).length;
/*     */ 
/*     */     
/* 373 */     System.out.println(String.format("Displaying table with: Width = %d, Height = %d", new Object[] { Integer.valueOf(width), Integer.valueOf(height) }));
/*     */ 
/*     */     
/* 376 */     TableModel model = new DefaultTableModel(height, width)
/*     */       {
/*     */         private static final long serialVersionUID = 1L;
/*     */         
/*     */         public String getColumnName(int i) {
/* 381 */           if (i < nSegments)
/* 382 */             return "Ts " + i; 
/* 383 */           if (i < nSegments + nSpots) {
/* 384 */             return "Sp " + (i - nSegments);
/*     */           }
/* 386 */           return "ø";
/*     */         }
/*     */       };
/*     */ 
/*     */     
/* 391 */     JTable debugTable = new JTable(model)
/*     */       {
/*     */         private static final long serialVersionUID = 1L;
/*     */ 
/*     */         
/*     */         public Component prepareRenderer(TableCellRenderer renderer, int row, int col) {
/* 397 */           JLabel label = (JLabel)super.prepareRenderer(renderer, row, col);
/*     */           
/* 399 */           if (col < nSegments) {
/*     */             
/* 401 */             if (row < nSegments) {
/* 402 */               label.setForeground(Color.BLUE);
/* 403 */             } else if (row < nSegments + nSpots) {
/* 404 */               label.setForeground(Color.GREEN.darker());
/*     */             } else {
/* 406 */               label.setForeground(Color.BLACK);
/*     */             } 
/* 408 */           } else if (col < nSegments + nSpots) {
/*     */             
/* 410 */             if (row < nSegments) {
/* 411 */               label.setForeground(Color.CYAN.darker());
/* 412 */             } else if (row < nSegments + nSpots) {
/* 413 */               label.setForeground(Color.RED.darker());
/*     */             } else {
/* 415 */               label.setForeground(Color.BLACK);
/*     */             }
/*     */           
/* 418 */           } else if (row < nSegments + nSpots) {
/* 419 */             label.setForeground(Color.BLACK);
/*     */           } else {
/* 421 */             label.setForeground(Color.GRAY);
/*     */           } 
/* 423 */           label.setHorizontalAlignment(0);
/*     */ 
/*     */           
/* 426 */           label.setBorder(null);
/* 427 */           for (int i = 0; i < solutions.length; i++) {
/* 428 */             int srow = solutions[i][0];
/* 429 */             int scol = solutions[i][1];
/* 430 */             if (row == srow && col == scol) {
/* 431 */               label.setBorder(LAPUtils.RED_BORDER);
/*     */             }
/*     */           } 
/* 434 */           return label;
/*     */         }
/*     */       };
/*     */ 
/*     */ 
/*     */     
/* 440 */     for (int row = 0; row < height; row++) {
/* 441 */       for (int col = 0; col < width; col++) {
/* 442 */         String txt; double val = costs[row][col];
/* 443 */         if (val == blockingValue) {
/* 444 */           txt = "B";
/*     */         } else {
/* 446 */           txt = String.format("%.1f", new Object[] { Double.valueOf(val) });
/* 447 */         }  model.setValueAt(txt, row, col);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 452 */     TableModel rhm = new AbstractTableModel() {
/*     */         private static final long serialVersionUID = 1L;
/* 454 */         String[] headers = new String[2 * (nSegments + nSpots)];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         public int getColumnCount() {
/* 465 */           return 1;
/*     */         } public int getRowCount() {
/* 467 */           return this.headers.length;
/*     */         }
/*     */         public Object getValueAt(int rowIndex, int columnIndex) {
/* 470 */           return this.headers[rowIndex];
/*     */         }
/*     */       };
/* 473 */     JTable rowHeader = new JTable(rhm);
/* 474 */     Dimension d = rowHeader.getPreferredScrollableViewportSize();
/* 475 */     d.width = (rowHeader.getPreferredSize()).width;
/* 476 */     rowHeader.setPreferredScrollableViewportSize(d);
/*     */ 
/*     */     
/* 479 */     debugTable.setAutoResizeMode(0);
/* 480 */     for (int i = 0; i < debugTable.getColumnCount(); i++) {
/* 481 */       debugTable.getColumnModel().getColumn(i).setPreferredWidth(50);
/*     */     }
/*     */ 
/*     */     
/* 485 */     JScrollPane scrollPane = new JScrollPane(debugTable);
/* 486 */     debugTable.setFillsViewportHeight(true);
/* 487 */     scrollPane.setRowHeaderView(rowHeader);
/* 488 */     JFrame frame = new JFrame("Segment cost matrix");
/* 489 */     frame.getContentPane().add(scrollPane);
/* 490 */     frame.setSize(800, 600);
/* 491 */     frame.setVisible(true);
/*     */   }
/*     */ 
/*     */   
/*     */   public static void echoSolutions(int[][] solutions) {
/* 496 */     for (int i = 0; i < solutions.length; i++) {
/* 497 */       System.out.println(String.format("%3d: %3d -> %3d", new Object[] { Integer.valueOf(i), Integer.valueOf(solutions[i][0]), Integer.valueOf(solutions[i][1]) }));
/*     */     } 
/*     */   }
/*     */   public static void displayLAPresults(int[][] array) {
/* 501 */     Object[][] data = new Object[array.length][(array[0]).length];
/* 502 */     Object[] headers = new Object[(array[0]).length]; int i;
/* 503 */     for (i = 0; i < data.length; i++) {
/* 504 */       for (int j = 0; j < (data[0]).length; j++) {
/* 505 */         data[i][j] = "" + array[i][j];
/*     */       }
/*     */     } 
/* 508 */     for (i = 0; i < headers.length; i++) {
/* 509 */       headers[i] = "" + i;
/*     */     }
/* 511 */     JTable table = new JTable(data, headers);
/*     */     
/* 513 */     JScrollPane scrollPane = new JScrollPane(table);
/* 514 */     table.setFillsViewportHeight(true);
/* 515 */     JFrame frame = new JFrame("Hungarian solution");
/* 516 */     frame.getContentPane().add(scrollPane);
/* 517 */     frame.setVisible(true);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/tracking/LAPUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */