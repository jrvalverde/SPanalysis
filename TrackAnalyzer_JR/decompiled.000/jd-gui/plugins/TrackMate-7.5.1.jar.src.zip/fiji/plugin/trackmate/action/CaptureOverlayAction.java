/*     */ package fiji.plugin.trackmate.action;
/*     */ 
/*     */ import fiji.plugin.trackmate.Logger;
/*     */ import fiji.plugin.trackmate.SelectionModel;
/*     */ import fiji.plugin.trackmate.TrackMate;
/*     */ import fiji.plugin.trackmate.gui.Icons;
/*     */ import fiji.plugin.trackmate.gui.displaysettings.DisplaySettings;
/*     */ import fiji.plugin.trackmate.util.TMUtils;
/*     */ import fiji.plugin.trackmate.visualization.ViewUtils;
/*     */ import fiji.plugin.trackmate.visualization.hyperstack.HyperStackDisplayer;
/*     */ import ij.ImagePlus;
/*     */ import ij.ImageStack;
/*     */ import ij.measure.Calibration;
/*     */ import ij.process.ColorProcessor;
/*     */ import ij.process.ImageProcessor;
/*     */ import java.awt.Frame;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.image.BufferedImage;
/*     */ import javax.swing.ImageIcon;
/*     */ import javax.swing.JOptionPane;
/*     */ import org.scijava.plugin.Plugin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CaptureOverlayAction
/*     */   extends AbstractTMAction
/*     */ {
/*     */   public static final String NAME = "Capture overlay";
/*     */   public static final String KEY = "CAPTURE_OVERLAY";
/*     */   public static final String INFO_TEXT = "<html>If the current displayer is the HyperstackDisplayer, this action <br>will capture the TrackMate overlay with current display settings. <br>That is: a new RGB stack will be created (careful with large data) where <br>each frame contains a RGB snapshot of the TrackMate display. <p>It can take long since we pause between each frame to ensure the whole <br>overlay is redrawn. The current zoom is taken into account. <br>Also, make sure nothing is moved over the image while capturing. </html>";
/*  66 */   private static int firstFrame = -1;
/*     */   
/*  68 */   private static int lastFrame = -1;
/*     */ 
/*     */   
/*     */   private static boolean hideImage = false;
/*     */ 
/*     */   
/*     */   public void execute(TrackMate trackmate, SelectionModel selectionModel, DisplaySettings displaySettings, Frame gui) {
/*  75 */     ImagePlus imp = (trackmate.getSettings()).imp;
/*     */     
/*  77 */     if (firstFrame < 0)
/*  78 */       firstFrame = 1; 
/*  79 */     firstFrame = Math.max(firstFrame, 1);
/*  80 */     if (lastFrame < 0)
/*  81 */       lastFrame = imp.getNFrames(); 
/*  82 */     lastFrame = Math.min(lastFrame, imp.getNFrames());
/*     */     
/*  84 */     if (gui != null) {
/*     */       
/*  86 */       CaptureOverlayPanel panel = new CaptureOverlayPanel(firstFrame, lastFrame, hideImage);
/*  87 */       int userInput = JOptionPane.showConfirmDialog(gui, panel, "Capture TrackMate overlay", 2, 3, Icons.TRACKMATE_ICON);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  95 */       if (userInput != 0) {
/*     */         return;
/*     */       }
/*  98 */       int first = panel.getFirstFrame();
/*  99 */       int last = panel.getLastFrame();
/* 100 */       firstFrame = Math.min(last, first);
/* 101 */       lastFrame = Math.max(last, first);
/* 102 */       firstFrame = Math.max(1, firstFrame);
/* 103 */       lastFrame = Math.min(imp.getNFrames(), lastFrame);
/* 104 */       hideImage = panel.isHideImage();
/*     */     } 
/*     */     
/* 107 */     if (hideImage) {
/*     */ 
/*     */       
/* 110 */       ImagePlus imp2 = ViewUtils.makeEmptyImagePlus(imp
/* 111 */           .getWidth(), imp
/* 112 */           .getHeight(), imp
/* 113 */           .getNSlices(), imp
/* 114 */           .getNFrames(), 
/* 115 */           TMUtils.getSpatialCalibration(imp));
/*     */       
/* 117 */       HyperStackDisplayer displayer = new HyperStackDisplayer(trackmate.getModel(), new SelectionModel(trackmate.getModel()), imp2, displaySettings);
/* 118 */       displayer.render();
/* 119 */       ImagePlus capture = capture(imp2, firstFrame, lastFrame, this.logger);
/* 120 */       imp2.close();
/* 121 */       capture.show();
/*     */     }
/*     */     else {
/*     */       
/* 125 */       ImagePlus capture = capture(trackmate, firstFrame, lastFrame, this.logger);
/* 126 */       capture.show();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImagePlus capture(TrackMate trackmate, int first, int last, Logger logger) {
/* 147 */     ImagePlus imp = (trackmate.getSettings()).imp;
/* 148 */     return capture(imp, first, last, logger);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImagePlus capture(ImagePlus imp, int first, int last, Logger log) {
/* 170 */     Logger logger = (null == log) ? Logger.VOID_LOGGER : log;
/* 171 */     int firstFrame = Math.max(1, 
/* 172 */         Math.min(last, first));
/* 173 */     int lastFrame = Math.min(imp.getNFrames(), 
/* 174 */         Math.max(last, first));
/*     */     
/* 176 */     logger.log("Capturing TrackMate overlay from frame " + firstFrame + " to " + lastFrame + ".\n");
/* 177 */     Rectangle bounds = imp.getCanvas().getBounds();
/* 178 */     int width = bounds.width;
/* 179 */     int height = bounds.height;
/* 180 */     int nCaptures = lastFrame - firstFrame + 1;
/* 181 */     ImageStack stack = new ImageStack(width, height);
/*     */     
/* 183 */     int channel = imp.getChannel();
/* 184 */     int slice = imp.getSlice();
/* 185 */     imp.getCanvas().hideZoomIndicator(true);
/* 186 */     for (int frame = firstFrame; frame <= lastFrame; frame++) {
/*     */       
/* 188 */       logger.setProgress(((frame - firstFrame) / nCaptures));
/* 189 */       imp.setPositionWithoutUpdate(channel, slice, frame);
/* 190 */       BufferedImage bi = new BufferedImage(width, height, 2);
/* 191 */       imp.getCanvas().paint(bi.getGraphics());
/* 192 */       ColorProcessor cp = new ColorProcessor(bi);
/* 193 */       int index = imp.getStackIndex(channel, slice, frame);
/* 194 */       stack.addSlice(imp.getImageStack().getSliceLabel(index), (ImageProcessor)cp);
/*     */     } 
/* 196 */     imp.getCanvas().hideZoomIndicator(false);
/* 197 */     ImagePlus capture = new ImagePlus("TrackMate capture of " + imp.getShortTitle(), stack);
/* 198 */     transferCalibration(imp, capture);
/*     */     
/* 200 */     logger.log(" done.\n");
/* 201 */     logger.setProgress(0.0D);
/*     */     
/* 203 */     return capture;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final void transferCalibration(ImagePlus from, ImagePlus to) {
/* 218 */     Calibration fc = from.getCalibration();
/* 219 */     Calibration tc = to.getCalibration();
/*     */     
/* 221 */     tc.setUnit(fc.getUnit());
/* 222 */     tc.setTimeUnit(fc.getTimeUnit());
/* 223 */     tc.frameInterval = fc.frameInterval;
/*     */     
/* 225 */     double mag = from.getCanvas().getMagnification();
/* 226 */     fc.pixelWidth /= mag;
/* 227 */     fc.pixelHeight /= mag;
/* 228 */     tc.pixelDepth = fc.pixelDepth;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Plugin(type = TrackMateActionFactory.class)
/*     */   public static class Factory
/*     */     implements TrackMateActionFactory
/*     */   {
/*     */     public String getInfoText() {
/* 238 */       return "<html>If the current displayer is the HyperstackDisplayer, this action <br>will capture the TrackMate overlay with current display settings. <br>That is: a new RGB stack will be created (careful with large data) where <br>each frame contains a RGB snapshot of the TrackMate display. <p>It can take long since we pause between each frame to ensure the whole <br>overlay is redrawn. The current zoom is taken into account. <br>Also, make sure nothing is moved over the image while capturing. </html>";
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public String getKey() {
/* 244 */       return "CAPTURE_OVERLAY";
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public TrackMateAction create() {
/* 250 */       return new CaptureOverlayAction();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public ImageIcon getIcon() {
/* 256 */       return Icons.CAMERA_ICON;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public String getName() {
/* 262 */       return "Capture overlay";
/*     */     }
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/action/CaptureOverlayAction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */