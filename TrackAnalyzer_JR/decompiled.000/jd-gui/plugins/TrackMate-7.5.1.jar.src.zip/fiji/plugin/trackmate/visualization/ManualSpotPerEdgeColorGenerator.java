/*    */ package fiji.plugin.trackmate.visualization;
/*    */ 
/*    */ import fiji.plugin.trackmate.Model;
/*    */ import fiji.plugin.trackmate.Spot;
/*    */ import java.awt.Color;
/*    */ import java.util.Set;
/*    */ import org.jgrapht.graph.DefaultWeightedEdge;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ManualSpotPerEdgeColorGenerator
/*    */   implements FeatureColorGenerator<Spot>
/*    */ {
/*    */   private final Color missingValueColor;
/*    */   private final Model model;
/*    */   private final ManualEdgeColorGenerator manualEdgeColorGenerator;
/*    */   
/*    */   public ManualSpotPerEdgeColorGenerator(Model model, Color missingValueColor) {
/* 46 */     this.model = model;
/* 47 */     this.missingValueColor = missingValueColor;
/* 48 */     this.manualEdgeColorGenerator = new ManualEdgeColorGenerator(model, missingValueColor);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Color color(Spot spot) {
/* 54 */     Set<DefaultWeightedEdge> edges = this.model.getTrackModel().edgesOf(spot);
/* 55 */     DefaultWeightedEdge edge = null;
/* 56 */     for (DefaultWeightedEdge e : edges) {
/*    */       
/* 58 */       if (this.model.getTrackModel().getEdgeTarget(e).equals(spot)) {
/*    */         
/* 60 */         edge = e;
/*    */         break;
/*    */       } 
/*    */     } 
/* 64 */     if (edge == null) {
/* 65 */       return this.missingValueColor;
/*    */     }
/* 67 */     return this.manualEdgeColorGenerator.color(edge);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/visualization/ManualSpotPerEdgeColorGenerator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */