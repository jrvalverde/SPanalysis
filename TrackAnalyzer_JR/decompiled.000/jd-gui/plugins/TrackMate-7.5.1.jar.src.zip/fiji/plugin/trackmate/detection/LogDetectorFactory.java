/*     */ package fiji.plugin.trackmate.detection;
/*     */ 
/*     */ import fiji.plugin.trackmate.Model;
/*     */ import fiji.plugin.trackmate.Settings;
/*     */ import fiji.plugin.trackmate.gui.components.ConfigurationPanel;
/*     */ import fiji.plugin.trackmate.gui.components.detector.LogDetectorConfigurationPanel;
/*     */ import fiji.plugin.trackmate.io.IOUtils;
/*     */ import fiji.plugin.trackmate.util.TMUtils;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.swing.ImageIcon;
/*     */ import net.imagej.ImgPlus;
/*     */ import net.imagej.ImgPlusMetadata;
/*     */ import net.imagej.axis.Axes;
/*     */ import net.imglib2.Interval;
/*     */ import net.imglib2.RandomAccessible;
/*     */ import net.imglib2.RandomAccessibleInterval;
/*     */ import net.imglib2.type.NativeType;
/*     */ import net.imglib2.type.numeric.RealType;
/*     */ import net.imglib2.view.IntervalView;
/*     */ import net.imglib2.view.MixedTransformView;
/*     */ import net.imglib2.view.Views;
/*     */ import org.jdom2.Element;
/*     */ import org.scijava.plugin.Plugin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Plugin(type = SpotDetectorFactory.class)
/*     */ public class LogDetectorFactory<T extends RealType<T> & NativeType<T>>
/*     */   implements SpotDetectorFactory<T>
/*     */ {
/*     */   public static final String DETECTOR_KEY = "LOG_DETECTOR";
/*     */   public static final String NAME = "LoG detector";
/*     */   public static final String INFO_TEXT = "<html>This detector applies a LoG (Laplacian of Gaussian) filter <br>to the image, with a sigma suited to the blob estimated size. <br>Calculations are made in the Fourier space. The maxima in the <br>filtered image are searched for, and maxima too close from each <br>other are suppressed. A quadratic fitting scheme allows to do <br>sub-pixel localization. </html>";
/*     */   protected ImgPlus<T> img;
/*     */   protected Map<String, Object> settings;
/*     */   protected String errorMessage;
/*     */   
/*     */   public boolean setTarget(ImgPlus<T> img, Map<String, Object> settings) {
/* 103 */     this.img = img;
/* 104 */     this.settings = settings;
/* 105 */     return checkSettings(settings);
/*     */   }
/*     */   
/*     */   protected RandomAccessible<T> prepareFrameImg(int frame) {
/*     */     IntervalView intervalView;
/*     */     MixedTransformView mixedTransformView;
/* 111 */     double[] calibration = TMUtils.getSpatialCalibration((ImgPlusMetadata)this.img);
/*     */     
/* 113 */     int cDim = this.img.dimensionIndex(Axes.CHANNEL);
/* 114 */     if (cDim < 0) {
/*     */       
/* 116 */       ImgPlus<T> imgPlus = this.img;
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 121 */       int channel = ((Integer)this.settings.get("TARGET_CHANNEL")).intValue() - 1;
/* 122 */       intervalView = Views.hyperSlice((RandomAccessibleInterval)this.img, cDim, channel);
/*     */     } 
/*     */     
/* 125 */     int timeDim = this.img.dimensionIndex(Axes.TIME);
/* 126 */     if (timeDim >= 0) {
/*     */       
/* 128 */       if (cDim >= 0 && timeDim > cDim) {
/* 129 */         timeDim--;
/*     */       }
/* 131 */       mixedTransformView = Views.hyperSlice((RandomAccessible)intervalView, timeDim, frame);
/*     */     } 
/*     */ 
/*     */     
/* 135 */     if (this.img.dimension(0) < 2L) {
/*     */       
/* 137 */       calibration[0] = calibration[1];
/* 138 */       calibration[1] = 1.0D;
/* 139 */       mixedTransformView = Views.hyperSlice((RandomAccessible)mixedTransformView, 0, 0L);
/*     */     } 
/* 141 */     if (this.img.dimension(1) < 2L)
/*     */     {
/* 143 */       mixedTransformView = Views.hyperSlice((RandomAccessible)mixedTransformView, 1, 0L);
/*     */     }
/*     */     
/* 146 */     return (RandomAccessible<T>)mixedTransformView;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public SpotDetector<T> getDetector(Interval interval, int frame) {
/* 152 */     double radius = ((Double)this.settings.get("RADIUS")).doubleValue();
/* 153 */     double threshold = ((Double)this.settings.get("THRESHOLD")).doubleValue();
/* 154 */     boolean doMedian = ((Boolean)this.settings.get("DO_MEDIAN_FILTERING")).booleanValue();
/* 155 */     boolean doSubpixel = ((Boolean)this.settings.get("DO_SUBPIXEL_LOCALIZATION")).booleanValue();
/* 156 */     double[] calibration = TMUtils.getSpatialCalibration((ImgPlusMetadata)this.img);
/* 157 */     RandomAccessible<T> imFrame = prepareFrameImg(frame);
/*     */     
/* 159 */     LogDetector<T> detector = new LogDetector<>(imFrame, interval, calibration, radius, threshold, doSubpixel, doMedian);
/* 160 */     detector.setNumThreads(1);
/* 161 */     return detector;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getKey() {
/* 167 */     return "LOG_DETECTOR";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getErrorMessage() {
/* 173 */     return this.errorMessage;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean checkSettings(Map<String, Object> lSettings) {
/* 179 */     boolean ok = true;
/* 180 */     StringBuilder errorHolder = new StringBuilder();
/* 181 */     ok &= TMUtils.checkParameter(lSettings, "TARGET_CHANNEL", Integer.class, errorHolder);
/* 182 */     ok &= TMUtils.checkParameter(lSettings, "RADIUS", Double.class, errorHolder);
/* 183 */     ok &= TMUtils.checkParameter(lSettings, "THRESHOLD", Double.class, errorHolder);
/* 184 */     ok &= TMUtils.checkParameter(lSettings, "DO_MEDIAN_FILTERING", Boolean.class, errorHolder);
/* 185 */     ok &= TMUtils.checkParameter(lSettings, "DO_SUBPIXEL_LOCALIZATION", Boolean.class, errorHolder);
/* 186 */     List<String> mandatoryKeys = new ArrayList<>();
/* 187 */     mandatoryKeys.add("TARGET_CHANNEL");
/* 188 */     mandatoryKeys.add("RADIUS");
/* 189 */     mandatoryKeys.add("THRESHOLD");
/* 190 */     mandatoryKeys.add("DO_MEDIAN_FILTERING");
/* 191 */     mandatoryKeys.add("DO_SUBPIXEL_LOCALIZATION");
/* 192 */     ok &= TMUtils.checkMapKeys(lSettings, mandatoryKeys, null, errorHolder);
/* 193 */     if (!ok)
/*     */     {
/* 195 */       this.errorMessage = errorHolder.toString();
/*     */     }
/* 197 */     return ok;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean marshall(Map<String, Object> lSettings, Element element) {
/* 203 */     StringBuilder errorHolder = new StringBuilder();
/* 204 */     boolean ok = (IOUtils.writeTargetChannel(lSettings, element, errorHolder) && IOUtils.writeRadius(lSettings, element, errorHolder) && IOUtils.writeThreshold(lSettings, element, errorHolder) && IOUtils.writeDoMedian(lSettings, element, errorHolder) && IOUtils.writeDoSubPixel(lSettings, element, errorHolder));
/* 205 */     if (!ok)
/*     */     {
/* 207 */       this.errorMessage = errorHolder.toString();
/*     */     }
/* 209 */     return ok;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean unmarshall(Element element, Map<String, Object> lSettings) {
/* 215 */     lSettings.clear();
/* 216 */     StringBuilder errorHolder = new StringBuilder();
/* 217 */     boolean ok = true;
/* 218 */     ok &= IOUtils.readDoubleAttribute(element, lSettings, "RADIUS", errorHolder);
/* 219 */     ok &= IOUtils.readDoubleAttribute(element, lSettings, "THRESHOLD", errorHolder);
/* 220 */     ok &= IOUtils.readBooleanAttribute(element, lSettings, "DO_SUBPIXEL_LOCALIZATION", errorHolder);
/* 221 */     ok &= IOUtils.readBooleanAttribute(element, lSettings, "DO_MEDIAN_FILTERING", errorHolder);
/* 222 */     ok &= IOUtils.readIntegerAttribute(element, lSettings, "TARGET_CHANNEL", errorHolder);
/* 223 */     if (!ok) {
/*     */       
/* 225 */       this.errorMessage = errorHolder.toString();
/* 226 */       return false;
/*     */     } 
/* 228 */     return checkSettings(lSettings);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ConfigurationPanel getDetectorConfigurationPanel(Settings lSettings, Model model) {
/* 234 */     return (ConfigurationPanel)new LogDetectorConfigurationPanel(lSettings, model, "<html>This detector applies a LoG (Laplacian of Gaussian) filter <br>to the image, with a sigma suited to the blob estimated size. <br>Calculations are made in the Fourier space. The maxima in the <br>filtered image are searched for, and maxima too close from each <br>other are suppressed. A quadratic fitting scheme allows to do <br>sub-pixel localization. </html>", "LoG detector");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getInfoText() {
/* 240 */     return "<html>This detector applies a LoG (Laplacian of Gaussian) filter <br>to the image, with a sigma suited to the blob estimated size. <br>Calculations are made in the Fourier space. The maxima in the <br>filtered image are searched for, and maxima too close from each <br>other are suppressed. A quadratic fitting scheme allows to do <br>sub-pixel localization. </html>";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/* 246 */     return "LoG detector";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, Object> getDefaultSettings() {
/* 252 */     Map<String, Object> lSettings = new HashMap<>();
/* 253 */     lSettings.put("TARGET_CHANNEL", Integer.valueOf(1));
/* 254 */     lSettings.put("RADIUS", Double.valueOf(5.0D));
/* 255 */     lSettings.put("THRESHOLD", Double.valueOf(0.0D));
/* 256 */     lSettings.put("DO_MEDIAN_FILTERING", Boolean.valueOf(false));
/* 257 */     lSettings.put("DO_SUBPIXEL_LOCALIZATION", Boolean.valueOf(true));
/* 258 */     return lSettings;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ImageIcon getIcon() {
/* 264 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public LogDetectorFactory<T> copy() {
/* 270 */     return new LogDetectorFactory();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/detection/LogDetectorFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */