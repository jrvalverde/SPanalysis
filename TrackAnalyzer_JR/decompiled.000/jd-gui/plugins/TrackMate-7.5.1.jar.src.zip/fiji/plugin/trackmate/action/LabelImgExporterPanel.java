/*    */ package fiji.plugin.trackmate.action;
/*    */ 
/*    */ import java.awt.GridBagConstraints;
/*    */ import java.awt.GridBagLayout;
/*    */ import java.awt.Insets;
/*    */ import javax.swing.JCheckBox;
/*    */ import javax.swing.JPanel;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LabelImgExporterPanel
/*    */   extends JPanel
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private final JCheckBox exportSpotsAsDots;
/*    */   private final JCheckBox exportTracksOnly;
/*    */   
/*    */   public LabelImgExporterPanel() {
/* 42 */     GridBagLayout gridBagLayout = new GridBagLayout();
/* 43 */     setLayout(gridBagLayout);
/*    */     
/* 45 */     GridBagConstraints gbc = new GridBagConstraints();
/* 46 */     gbc.anchor = 17;
/* 47 */     gbc.insets = new Insets(5, 5, 5, 5);
/* 48 */     gbc.gridx = 0;
/* 49 */     gbc.gridy = 0;
/*    */     
/* 51 */     this.exportSpotsAsDots = new JCheckBox("Export spots as single pixels", false);
/* 52 */     add(this.exportSpotsAsDots, gbc);
/*    */     
/* 54 */     this.exportTracksOnly = new JCheckBox("Export only spots in tracks", false);
/* 55 */     gbc.gridy++;
/* 56 */     add(this.exportTracksOnly, gbc);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isExportSpotsAsDots() {
/* 62 */     return this.exportSpotsAsDots.isSelected();
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isExportTracksOnly() {
/* 67 */     return this.exportTracksOnly.isSelected();
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/action/LabelImgExporterPanel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */