/*     */ package fiji.plugin.trackmate.tracking.sparselap.costmatrix;
/*     */ 
/*     */ import fiji.plugin.trackmate.tracking.sparselap.linker.SparseCostMatrix;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import net.imglib2.util.Util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultCostMatrixCreator<K extends Comparable<K>, J extends Comparable<J>>
/*     */   implements CostMatrixCreator<K, J>
/*     */ {
/*     */   private static final String BASE_ERROR_MESSAGE = "[DefaultCostMatrixCreator] ";
/*     */   private SparseCostMatrix scm;
/*     */   private ArrayList<K> uniqueRows;
/*     */   private ArrayList<J> uniqueCols;
/*     */   private long processingTime;
/*     */   private String errorMessage;
/*     */   private double alternativeCost;
/*     */   private final List<K> rows;
/*     */   private final List<J> cols;
/*     */   private final double[] costs;
/*     */   private final double alternativeCostFactor;
/*     */   private final double percentile;
/*     */   
/*     */   public DefaultCostMatrixCreator(List<K> rows, List<J> cols, double[] costs, double alternativeCostFactor, double percentile) {
/*  70 */     this.rows = rows;
/*  71 */     this.cols = cols;
/*  72 */     this.costs = costs;
/*  73 */     this.alternativeCostFactor = alternativeCostFactor;
/*  74 */     this.percentile = percentile;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public long getProcessingTime() {
/*  80 */     return this.processingTime;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public SparseCostMatrix getResult() {
/*  86 */     return this.scm;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean checkInput() {
/*  92 */     if (this.rows == null || this.rows.isEmpty()) {
/*     */       
/*  94 */       this.errorMessage = "[DefaultCostMatrixCreator] The row list is null or empty.";
/*  95 */       return false;
/*     */     } 
/*  97 */     if (this.rows.size() != this.cols.size()) {
/*  98 */       this.errorMessage = "[DefaultCostMatrixCreator] Row and column lists do not have the same number of elements. Found " + this.rows.size() + " and " + this.cols.size() + ".";
/*  99 */       return false;
/*     */     } 
/* 101 */     if (this.rows.size() != this.costs.length) {
/*     */       
/* 103 */       this.errorMessage = "[DefaultCostMatrixCreator] Row list and cost array do not have the same number of elements. Found " + this.rows.size() + " and " + this.costs.length + ".";
/* 104 */       return false;
/*     */     } 
/* 106 */     if (this.alternativeCostFactor <= 0.0D) {
/*     */       
/* 108 */       this.errorMessage = "[DefaultCostMatrixCreator] The alternative cost factor must be greater than 0. Was: " + this.alternativeCostFactor + ".";
/* 109 */       return false;
/*     */     } 
/* 111 */     if (this.percentile < 0.0D || this.percentile > 1.0D) {
/*     */       
/* 113 */       this.errorMessage = "[DefaultCostMatrixCreator] The percentile must no be smaller than 0 or greater than 1. Was: " + this.percentile;
/* 114 */       return false;
/*     */     } 
/* 116 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean process() {
/* 122 */     this.uniqueRows = new ArrayList<>(new HashSet<>(this.rows));
/* 123 */     Collections.sort(this.uniqueRows);
/* 124 */     this.uniqueCols = new ArrayList<>(new HashSet<>(this.cols));
/* 125 */     Collections.sort(this.uniqueCols);
/*     */     
/* 127 */     List<Assignment> assignments = new ArrayList<>(this.costs.length);
/* 128 */     for (int i = 0; i < this.costs.length; i++) {
/*     */       
/* 130 */       Comparable comparable1 = (Comparable)this.rows.get(i);
/* 131 */       Comparable comparable2 = (Comparable)this.cols.get(i);
/* 132 */       int r = Collections.binarySearch(this.uniqueRows, comparable1);
/* 133 */       int c = Collections.binarySearch(this.uniqueCols, comparable2);
/* 134 */       assignments.add(new Assignment(r, c, this.costs[i]));
/*     */     } 
/* 136 */     Collections.sort(assignments);
/*     */ 
/*     */     
/* 139 */     Assignment previousAssgn = assignments.get(0);
/* 140 */     for (int j = 1; j < assignments.size(); j++) {
/*     */       
/* 142 */       Assignment assgn = assignments.get(j);
/* 143 */       if (assgn.equals(previousAssgn)) {
/*     */         
/* 145 */         this.errorMessage = "[DefaultCostMatrixCreator] Found duplicate assignment at index: " + assgn + ".";
/* 146 */         return false;
/*     */       } 
/* 148 */       previousAssgn = assgn;
/*     */     } 
/*     */     
/* 151 */     int nRows = this.uniqueRows.size();
/* 152 */     int nCols = this.uniqueCols.size();
/* 153 */     int[] kk = new int[this.costs.length];
/* 154 */     int[] number = new int[nRows];
/* 155 */     double[] cc = new double[this.costs.length];
/*     */     
/* 157 */     Assignment a = assignments.get(0);
/* 158 */     kk[0] = a.c;
/* 159 */     cc[0] = a.cost;
/* 160 */     int currentRow = a.r;
/* 161 */     int nOfEl = 0;
/* 162 */     for (int k = 1; k < assignments.size(); k++) {
/*     */       
/* 164 */       a = assignments.get(k);
/*     */       
/* 166 */       kk[k] = a.c;
/* 167 */       cc[k] = a.cost;
/* 168 */       nOfEl++;
/*     */       
/* 170 */       if (a.r != currentRow) {
/*     */         
/* 172 */         number[currentRow] = nOfEl;
/* 173 */         nOfEl = 0;
/* 174 */         currentRow = a.r;
/*     */       } 
/*     */     } 
/* 177 */     number[currentRow] = nOfEl + 1;
/*     */     
/* 179 */     this.scm = new SparseCostMatrix(cc, kk, number, nCols);
/*     */     
/* 181 */     this.alternativeCost = computeAlternativeCosts();
/*     */     
/* 183 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   protected double computeAlternativeCosts() {
/* 188 */     if (this.percentile == 1.0D) return this.alternativeCostFactor * Util.max(this.costs); 
/* 189 */     return this.alternativeCostFactor * Util.percentile(this.costs, this.percentile);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getErrorMessage() {
/* 195 */     return this.errorMessage;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public List<K> getSourceList() {
/* 201 */     return this.uniqueRows;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public List<J> getTargetList() {
/* 207 */     return this.uniqueCols;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getAlternativeCostForSource(K source) {
/* 214 */     return this.alternativeCost;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public double getAlternativeCostForTarget(J target) {
/* 220 */     return this.alternativeCost;
/*     */   }
/*     */ 
/*     */   
/*     */   public static final class Assignment
/*     */     implements Comparable<Assignment>
/*     */   {
/*     */     private final int r;
/*     */     
/*     */     private final int c;
/*     */     private final double cost;
/*     */     
/*     */     public Assignment(int r, int c, double cost) {
/* 233 */       this.r = r;
/* 234 */       this.c = c;
/* 235 */       this.cost = cost;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public int compareTo(Assignment o) {
/* 241 */       if (this.r == o.r) return this.c - o.c; 
/* 242 */       return this.r - o.r;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean equals(Object obj) {
/* 248 */       if (obj instanceof Assignment) {
/*     */         
/* 250 */         Assignment o = (Assignment)obj;
/* 251 */         return (this.r == o.r && this.c == o.c);
/*     */       } 
/* 253 */       return false;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 259 */       int hash = 23;
/* 260 */       hash = hash * 31 + this.r;
/* 261 */       hash = hash * 31 + this.c;
/* 262 */       return hash;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public String toString() {
/* 268 */       return "Assignment r = " + this.r + ", c = " + this.c + ", cost = " + this.cost;
/*     */     }
/*     */ 
/*     */     
/*     */     public int getC() {
/* 273 */       return this.c;
/*     */     }
/*     */ 
/*     */     
/*     */     public int getR() {
/* 278 */       return this.r;
/*     */     }
/*     */ 
/*     */     
/*     */     public double getCost() {
/* 283 */       return this.cost;
/*     */     }
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/tracking/sparselap/costmatrix/DefaultCostMatrixCreator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */