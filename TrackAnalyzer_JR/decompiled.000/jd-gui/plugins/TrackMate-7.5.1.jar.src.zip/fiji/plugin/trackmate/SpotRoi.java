/*     */ package fiji.plugin.trackmate;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import net.imagej.ImgPlus;
/*     */ import net.imglib2.IterableInterval;
/*     */ import net.imglib2.RandomAccessible;
/*     */ import net.imglib2.RandomAccessibleInterval;
/*     */ import net.imglib2.roi.IterableRegion;
/*     */ import net.imglib2.roi.Masks;
/*     */ import net.imglib2.roi.RealMaskRealInterval;
/*     */ import net.imglib2.roi.Regions;
/*     */ import net.imglib2.roi.geom.GeomMasks;
/*     */ import net.imglib2.roi.geom.real.WritablePolygon2D;
/*     */ import net.imglib2.type.logic.BoolType;
/*     */ import net.imglib2.view.Views;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SpotRoi
/*     */ {
/*     */   public final double[] x;
/*     */   public final double[] y;
/*     */   
/*     */   public SpotRoi(double[] x, double[] y) {
/*  52 */     this.x = x;
/*  53 */     this.y = y;
/*     */   }
/*     */ 
/*     */   
/*     */   public SpotRoi copy() {
/*  58 */     return new SpotRoi((double[])this.x.clone(), (double[])this.y.clone());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double[] toPolygonX(double calibration, double xcorner, double spotXCenter, double magnification) {
/*  76 */     double[] xp = new double[this.x.length];
/*  77 */     for (int i = 0; i < xp.length; i++) {
/*     */       
/*  79 */       double xc = (spotXCenter + this.x[i]) / calibration;
/*  80 */       xp[i] = (xc - xcorner) * magnification;
/*     */     } 
/*  82 */     return xp;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double[] toPolygonY(double calibration, double ycorner, double spotYCenter, double magnification) {
/* 100 */     double[] yp = new double[this.y.length];
/* 101 */     for (int i = 0; i < yp.length; i++) {
/*     */       
/* 103 */       double yc = (spotYCenter + this.y[i]) / calibration;
/* 104 */       yp[i] = (yc - ycorner) * magnification;
/*     */     } 
/* 106 */     return yp;
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> IterableInterval<T> sample(Spot spot, ImgPlus<T> img) {
/* 111 */     return sample(spot.getDoublePosition(0), spot.getDoublePosition(1), (RandomAccessibleInterval<T>)img, img.averageScale(0), img.averageScale(1));
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> IterableInterval<T> sample(double spotXCenter, double spotYCenter, RandomAccessibleInterval<T> img, double xScale, double yScale) {
/* 116 */     double[] xp = toPolygonX(xScale, 0.0D, spotXCenter, 1.0D);
/* 117 */     double[] yp = toPolygonY(yScale, 0.0D, spotYCenter, 1.0D);
/* 118 */     WritablePolygon2D polygon = GeomMasks.closedPolygon2D(xp, yp);
/* 119 */     IterableRegion<BoolType> region = Masks.toIterableRegion((RealMaskRealInterval)polygon);
/* 120 */     return Regions.sample((IterableInterval)region, (RandomAccessible)Views.extendMirrorDouble(Views.dropSingletonDimensions(img)));
/*     */   }
/*     */ 
/*     */   
/*     */   public double radius() {
/* 125 */     return Math.sqrt(area() / Math.PI);
/*     */   }
/*     */ 
/*     */   
/*     */   public double area() {
/* 130 */     return Math.abs(signedArea(this.x, this.y));
/*     */   }
/*     */ 
/*     */   
/*     */   public void scale(double alpha) {
/* 135 */     for (int i = 0; i < this.x.length; i++) {
/*     */       
/* 137 */       double x = this.x[i];
/* 138 */       double y = this.y[i];
/* 139 */       double r = Math.sqrt(x * x + y * y);
/* 140 */       double costheta = x / r;
/* 141 */       double sintheta = y / r;
/* 142 */       this.x[i] = costheta * r * alpha;
/* 143 */       this.y[i] = sintheta * r * alpha;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static Spot createSpot(double[] x, double[] y, double quality) {
/* 150 */     double[] centroid = centroid(x, y);
/* 151 */     double xc = centroid[0];
/* 152 */     double yc = centroid[1];
/* 153 */     double[] xr = Arrays.stream(x).map(x0 -> x0 - xc).toArray();
/* 154 */     double[] yr = Arrays.stream(y).map(y0 -> y0 - yc).toArray();
/*     */ 
/*     */     
/* 157 */     SpotRoi roi = new SpotRoi(xr, yr);
/*     */ 
/*     */     
/* 160 */     double z = 0.0D;
/* 161 */     double r = roi.radius();
/* 162 */     Spot spot = new Spot(xc, yc, 0.0D, r, quality);
/* 163 */     spot.setRoi(roi);
/* 164 */     return spot;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final double[] centroid(double[] x, double[] y) {
/* 173 */     double area = signedArea(x, y);
/* 174 */     double ax = 0.0D;
/* 175 */     double ay = 0.0D;
/* 176 */     int n = x.length;
/* 177 */     for (int i = 0; i < n - 1; i++) {
/*     */       
/* 179 */       double w = x[i] * y[i + 1] - x[i + 1] * y[i];
/* 180 */       ax += (x[i] + x[i + 1]) * w;
/* 181 */       ay += (y[i] + y[i + 1]) * w;
/*     */     } 
/*     */     
/* 184 */     double w0 = x[n - 1] * y[0] - x[0] * y[n - 1];
/* 185 */     ax += (x[n - 1] + x[0]) * w0;
/* 186 */     ay += (y[n - 1] + y[0]) * w0;
/* 187 */     return new double[] { ax / 6.0D / area, ay / 6.0D / area };
/*     */   }
/*     */ 
/*     */   
/*     */   private static final double signedArea(double[] x, double[] y) {
/* 192 */     int n = x.length;
/* 193 */     double a = 0.0D;
/* 194 */     for (int i = 0; i < n - 1; i++) {
/* 195 */       a += x[i] * y[i + 1] - x[i + 1] * y[i];
/*     */     }
/* 197 */     return (a + x[n - 1] * y[0] - x[0] * y[n - 1]) / 2.0D;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/SpotRoi.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */