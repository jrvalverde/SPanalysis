/*     */ package fiji.plugin.trackmate.gui.wizard;
/*     */ 
/*     */ import fiji.plugin.trackmate.util.ImageHelper;
/*     */ import java.awt.Component;
/*     */ import java.awt.image.BufferedImage;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TransitionAnimator
/*     */   extends AbstractAnimator
/*     */ {
/*     */   private final BufferedImage combined;
/*     */   private final int width;
/*     */   private final int height;
/*     */   private final Direction direction;
/*     */   
/*     */   public enum Direction
/*     */   {
/*  34 */     LEFT, RIGHT, TOP, BOTTOM;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TransitionAnimator(Component from, Component to, Direction direction, long duration) {
/*  47 */     super(duration);
/*  48 */     this.direction = direction;
/*  49 */     switch (direction) {
/*     */ 
/*     */       
/*     */       default:
/*  53 */         this.combined = ImageHelper.combineImages(
/*  54 */             ImageHelper.captureComponent(to), 
/*  55 */             ImageHelper.captureComponent(from), 0);
/*     */         break;
/*     */       
/*     */       case RIGHT:
/*  59 */         this.combined = ImageHelper.combineImages(
/*  60 */             ImageHelper.captureComponent(from), 
/*  61 */             ImageHelper.captureComponent(to), 0);
/*     */         break;
/*     */       
/*     */       case BOTTOM:
/*  65 */         this.combined = ImageHelper.combineImages(
/*  66 */             ImageHelper.captureComponent(to), 
/*  67 */             ImageHelper.captureComponent(from), 1);
/*     */         break;
/*     */       
/*     */       case TOP:
/*  71 */         this.combined = ImageHelper.combineImages(
/*  72 */             ImageHelper.captureComponent(from), 
/*  73 */             ImageHelper.captureComponent(to), 1);
/*     */         break;
/*     */     } 
/*     */ 
/*     */     
/*  78 */     this.width = from.getWidth();
/*  79 */     this.height = from.getHeight();
/*     */   }
/*     */ 
/*     */   
/*     */   public BufferedImage getCurrent(long time) {
/*  84 */     setTime(time);
/*  85 */     return get(ratioComplete());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BufferedImage get(double t) {
/*  92 */     switch (this.direction)
/*     */     
/*     */     { 
/*     */       default:
/*  96 */         x = this.width - (int)Math.round(t * this.width);
/*  97 */         y = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 112 */         return this.combined.getSubimage(x, y, this.width, this.height);case RIGHT: x = (int)Math.round(t * this.width); y = 0; return this.combined.getSubimage(x, y, this.width, this.height);case BOTTOM: x = 0; y = this.height - (int)Math.round(t * this.height); return this.combined.getSubimage(x, y, this.width, this.height);case TOP: break; }  int x = 0; int y = (int)Math.round(t * this.height); return this.combined.getSubimage(x, y, this.width, this.height);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/gui/wizard/TransitionAnimator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */