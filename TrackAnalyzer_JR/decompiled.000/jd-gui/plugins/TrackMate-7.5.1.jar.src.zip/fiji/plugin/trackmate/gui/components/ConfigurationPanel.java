/*    */ package fiji.plugin.trackmate.gui.components;
/*    */ 
/*    */ import java.awt.event.ActionEvent;
/*    */ import java.util.Map;
/*    */ import javax.swing.JPanel;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class ConfigurationPanel
/*    */   extends JPanel
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/* 45 */   public final ActionEvent PREVIEW_BUTTON_PUSHED = new ActionEvent(this, 0, "PreviewButtonPushed");
/*    */   
/*    */   public abstract void setSettings(Map<String, Object> paramMap);
/*    */   
/*    */   public abstract Map<String, Object> getSettings();
/*    */   
/*    */   public abstract void clean();
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/gui/components/ConfigurationPanel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */