package fiji.plugin.trackmate.graph;

public interface Function1<T1, T2> {
  void compute(T1 paramT1, T2 paramT2);
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/graph/Function1.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */