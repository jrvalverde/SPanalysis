/*     */ package fiji.plugin.trackmate.tracking;
/*     */ 
/*     */ import fiji.plugin.trackmate.Model;
/*     */ import fiji.plugin.trackmate.gui.components.ConfigurationPanel;
/*     */ import fiji.plugin.trackmate.gui.components.tracker.LAPTrackerSettingsPanel;
/*     */ import fiji.plugin.trackmate.io.IOUtils;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import javax.swing.ImageIcon;
/*     */ import org.jdom2.Content;
/*     */ import org.jdom2.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class LAPTrackerFactory
/*     */   implements SpotTrackerFactory
/*     */ {
/*     */   private String errorMessage;
/*     */   
/*     */   public ImageIcon getIcon() {
/*  75 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ConfigurationPanel getTrackerConfigurationPanel(Model model) {
/*  81 */     String spaceUnits = model.getSpaceUnits();
/*  82 */     Collection<String> features = model.getFeatureModel().getSpotFeatures();
/*  83 */     Map<String, String> featureNames = model.getFeatureModel().getSpotFeatureNames();
/*  84 */     return (ConfigurationPanel)new LAPTrackerSettingsPanel(getName(), spaceUnits, features, featureNames);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean marshall(Map<String, Object> settings, Element element) {
/*  90 */     boolean ok = true;
/*  91 */     StringBuilder str = new StringBuilder();
/*     */ 
/*     */     
/*  94 */     Element linkingElement = new Element("Linking");
/*  95 */     ok &= IOUtils.writeAttribute(settings, linkingElement, "LINKING_MAX_DISTANCE", Double.class, str);
/*     */ 
/*     */     
/*  98 */     Map<String, Double> lfpm = (Map<String, Double>)settings.get("LINKING_FEATURE_PENALTIES");
/*  99 */     Element lfpElement = new Element("FeaturePenalties");
/* 100 */     IOUtils.marshallMap(lfpm, lfpElement);
/* 101 */     linkingElement.addContent((Content)lfpElement);
/* 102 */     element.addContent((Content)linkingElement);
/*     */ 
/*     */     
/* 105 */     Element gapClosingElement = new Element("GapClosing");
/* 106 */     ok &= IOUtils.writeAttribute(settings, gapClosingElement, "ALLOW_GAP_CLOSING", Boolean.class, str);
/* 107 */     ok &= IOUtils.writeAttribute(settings, gapClosingElement, "GAP_CLOSING_MAX_DISTANCE", Double.class, str);
/* 108 */     ok &= IOUtils.writeAttribute(settings, gapClosingElement, "MAX_FRAME_GAP", Integer.class, str);
/*     */ 
/*     */     
/* 111 */     Map<String, Double> gcfpm = (Map<String, Double>)settings.get("GAP_CLOSING_FEATURE_PENALTIES");
/* 112 */     Element gcfpElement = new Element("FeaturePenalties");
/* 113 */     IOUtils.marshallMap(gcfpm, gcfpElement);
/* 114 */     gapClosingElement.addContent((Content)gcfpElement);
/* 115 */     element.addContent((Content)gapClosingElement);
/*     */ 
/*     */     
/* 118 */     Element trackSplittingElement = new Element("TrackSplitting");
/* 119 */     ok &= IOUtils.writeAttribute(settings, trackSplittingElement, "ALLOW_TRACK_SPLITTING", Boolean.class, str);
/* 120 */     ok &= IOUtils.writeAttribute(settings, trackSplittingElement, "SPLITTING_MAX_DISTANCE", Double.class, str);
/*     */ 
/*     */     
/* 123 */     Map<String, Double> tsfpm = (Map<String, Double>)settings.get("SPLITTING_FEATURE_PENALTIES");
/* 124 */     Element tsfpElement = new Element("FeaturePenalties");
/* 125 */     IOUtils.marshallMap(tsfpm, tsfpElement);
/* 126 */     trackSplittingElement.addContent((Content)tsfpElement);
/* 127 */     element.addContent((Content)trackSplittingElement);
/*     */ 
/*     */     
/* 130 */     Element trackMergingElement = new Element("TrackMerging");
/* 131 */     ok &= IOUtils.writeAttribute(settings, trackMergingElement, "ALLOW_TRACK_MERGING", Boolean.class, str);
/* 132 */     ok &= IOUtils.writeAttribute(settings, trackMergingElement, "MERGING_MAX_DISTANCE", Double.class, str);
/*     */ 
/*     */     
/* 135 */     Map<String, Double> tmfpm = (Map<String, Double>)settings.get("MERGING_FEATURE_PENALTIES");
/* 136 */     Element tmfpElement = new Element("FeaturePenalties");
/* 137 */     IOUtils.marshallMap(tmfpm, tmfpElement);
/* 138 */     trackMergingElement.addContent((Content)tmfpElement);
/* 139 */     element.addContent((Content)trackMergingElement);
/*     */ 
/*     */     
/* 142 */     ok &= IOUtils.writeAttribute(settings, element, "CUTOFF_PERCENTILE", Double.class, str);
/* 143 */     ok &= IOUtils.writeAttribute(settings, element, "ALTERNATIVE_LINKING_COST_FACTOR", Double.class, str);
/* 144 */     ok &= IOUtils.writeAttribute(settings, element, "BLOCKING_VALUE", Double.class, str);
/*     */     
/* 146 */     return ok;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean unmarshall(Element element, Map<String, Object> settings) {
/* 152 */     settings.clear();
/* 153 */     StringBuilder errorHolder = new StringBuilder();
/* 154 */     boolean ok = true;
/*     */ 
/*     */     
/* 157 */     Element linkingElement = element.getChild("Linking");
/* 158 */     if (null == linkingElement) {
/*     */       
/* 160 */       errorHolder.append("Could not found the Linking element in XML.\n");
/* 161 */       ok = false;
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */       
/* 167 */       ok &= IOUtils.readDoubleAttribute(linkingElement, settings, "LINKING_MAX_DISTANCE", errorHolder);
/*     */       
/* 169 */       Map<String, Double> lfpMap = new HashMap<>();
/* 170 */       Element lfpElement = linkingElement.getChild("FeaturePenalties");
/* 171 */       if (null != lfpElement)
/*     */       {
/* 173 */         ok &= IOUtils.unmarshallMap(lfpElement, lfpMap, errorHolder);
/*     */       }
/* 175 */       settings.put("LINKING_FEATURE_PENALTIES", lfpMap);
/*     */     } 
/*     */ 
/*     */     
/* 179 */     Element gapClosingElement = element.getChild("GapClosing");
/* 180 */     if (null == gapClosingElement) {
/*     */       
/* 182 */       errorHolder.append("Could not found the GapClosing element in XML.\n");
/* 183 */       ok = false;
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */       
/* 189 */       ok &= IOUtils.readBooleanAttribute(gapClosingElement, settings, "ALLOW_GAP_CLOSING", errorHolder);
/* 190 */       ok &= IOUtils.readIntegerAttribute(gapClosingElement, settings, "MAX_FRAME_GAP", errorHolder);
/* 191 */       ok &= IOUtils.readDoubleAttribute(gapClosingElement, settings, "GAP_CLOSING_MAX_DISTANCE", errorHolder);
/*     */       
/* 193 */       Map<String, Double> gcfpm = new HashMap<>();
/* 194 */       Element gcfpElement = gapClosingElement.getChild("FeaturePenalties");
/* 195 */       if (null != gcfpElement)
/*     */       {
/* 197 */         ok &= IOUtils.unmarshallMap(gcfpElement, gcfpm, errorHolder);
/*     */       }
/* 199 */       settings.put("GAP_CLOSING_FEATURE_PENALTIES", gcfpm);
/*     */     } 
/*     */ 
/*     */     
/* 203 */     Element trackSplittingElement = element.getChild("TrackSplitting");
/* 204 */     if (null == trackSplittingElement) {
/*     */       
/* 206 */       errorHolder.append("Could not found the TrackSplitting element in XML.\n");
/* 207 */       ok = false;
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */       
/* 213 */       ok &= IOUtils.readBooleanAttribute(trackSplittingElement, settings, "ALLOW_TRACK_SPLITTING", errorHolder);
/* 214 */       ok &= IOUtils.readDoubleAttribute(trackSplittingElement, settings, "SPLITTING_MAX_DISTANCE", errorHolder);
/*     */       
/* 216 */       Map<String, Double> tsfpm = new HashMap<>();
/* 217 */       Element tsfpElement = trackSplittingElement.getChild("FeaturePenalties");
/* 218 */       if (null != tsfpElement)
/*     */       {
/* 220 */         ok &= IOUtils.unmarshallMap(tsfpElement, tsfpm, errorHolder);
/*     */       }
/* 222 */       settings.put("SPLITTING_FEATURE_PENALTIES", tsfpm);
/*     */     } 
/*     */ 
/*     */     
/* 226 */     Element trackMergingElement = element.getChild("TrackMerging");
/* 227 */     if (null == trackMergingElement) {
/*     */       
/* 229 */       errorHolder.append("Could not found the TrackMerging element in XML.\n");
/* 230 */       ok = false;
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */       
/* 236 */       ok &= IOUtils.readBooleanAttribute(trackMergingElement, settings, "ALLOW_TRACK_MERGING", errorHolder);
/* 237 */       ok &= IOUtils.readDoubleAttribute(trackMergingElement, settings, "MERGING_MAX_DISTANCE", errorHolder);
/*     */       
/* 239 */       Map<String, Double> tmfpm = new HashMap<>();
/* 240 */       Element tmfpElement = trackMergingElement.getChild("FeaturePenalties");
/* 241 */       if (null != tmfpElement)
/*     */       {
/* 243 */         ok &= IOUtils.unmarshallMap(tmfpElement, tmfpm, errorHolder);
/*     */       }
/* 245 */       settings.put("MERGING_FEATURE_PENALTIES", tmfpm);
/*     */     } 
/*     */ 
/*     */     
/* 249 */     ok &= IOUtils.readDoubleAttribute(element, settings, "CUTOFF_PERCENTILE", errorHolder);
/* 250 */     ok &= IOUtils.readDoubleAttribute(element, settings, "ALTERNATIVE_LINKING_COST_FACTOR", errorHolder);
/* 251 */     ok &= IOUtils.readDoubleAttribute(element, settings, "BLOCKING_VALUE", errorHolder);
/*     */     
/* 253 */     if (!checkSettingsValidity(settings)) {
/*     */       
/* 255 */       ok = false;
/* 256 */       errorHolder.append(this.errorMessage);
/*     */     } 
/*     */     
/* 259 */     if (!ok)
/*     */     {
/* 261 */       this.errorMessage = errorHolder.toString();
/*     */     }
/* 263 */     return ok;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString(Map<String, Object> sm) {
/* 271 */     if (!checkSettingsValidity(sm)) return this.errorMessage;
/*     */     
/* 273 */     StringBuilder str = new StringBuilder();
/*     */     
/* 275 */     str.append("  Linking conditions:\n");
/* 276 */     str.append(String.format("    - max distance: %.1f\n", new Object[] { sm.get("LINKING_MAX_DISTANCE") }));
/* 277 */     str.append(LAPUtils.echoFeaturePenalties((Map<String, Double>)sm.get("LINKING_FEATURE_PENALTIES")));
/*     */     
/* 279 */     if (((Boolean)sm.get("ALLOW_GAP_CLOSING")).booleanValue()) {
/*     */       
/* 281 */       str.append("  Gap-closing conditions:\n");
/* 282 */       str.append(String.format("    - max distance: %.1f\n", new Object[] { sm.get("GAP_CLOSING_MAX_DISTANCE") }));
/* 283 */       str.append(String.format("    - max frame gap: %d\n", new Object[] { sm.get("MAX_FRAME_GAP") }));
/* 284 */       str.append(LAPUtils.echoFeaturePenalties((Map<String, Double>)sm.get("GAP_CLOSING_FEATURE_PENALTIES")));
/*     */     }
/*     */     else {
/*     */       
/* 288 */       str.append("  Gap-closing not allowed.\n");
/*     */     } 
/*     */     
/* 291 */     if (((Boolean)sm.get("ALLOW_TRACK_SPLITTING")).booleanValue()) {
/*     */       
/* 293 */       str.append("  Track splitting conditions:\n");
/* 294 */       str.append(String.format("    - max distance: %.1f\n", new Object[] { sm.get("SPLITTING_MAX_DISTANCE") }));
/* 295 */       str.append(LAPUtils.echoFeaturePenalties((Map<String, Double>)sm.get("SPLITTING_FEATURE_PENALTIES")));
/*     */     }
/*     */     else {
/*     */       
/* 299 */       str.append("  Track splitting not allowed.\n");
/*     */     } 
/*     */     
/* 302 */     if (((Boolean)sm.get("ALLOW_TRACK_MERGING")).booleanValue()) {
/*     */       
/* 304 */       str.append("  Track merging conditions:\n");
/* 305 */       str.append(String.format("    - max distance: %.1f\n", new Object[] { sm.get("MERGING_MAX_DISTANCE") }));
/* 306 */       str.append(LAPUtils.echoFeaturePenalties((Map<String, Double>)sm.get("MERGING_FEATURE_PENALTIES")));
/*     */     }
/*     */     else {
/*     */       
/* 310 */       str.append("  Track merging not allowed.\n");
/*     */     } 
/*     */     
/* 313 */     return str.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, Object> getDefaultSettings() {
/* 319 */     return LAPUtils.getDefaultLAPSettingsMap();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean checkSettingsValidity(Map<String, Object> settings) {
/* 325 */     if (null == settings) {
/*     */       
/* 327 */       this.errorMessage = "Settings map is null.\n";
/* 328 */       return false;
/*     */     } 
/*     */     
/* 331 */     StringBuilder str = new StringBuilder();
/* 332 */     boolean ok = LAPUtils.checkSettingsValidity(settings, str);
/* 333 */     if (!ok)
/*     */     {
/* 335 */       this.errorMessage = str.toString();
/*     */     }
/* 337 */     return ok;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getErrorMessage() {
/* 343 */     return this.errorMessage;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/tracking/LAPTrackerFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */