/*      */ package fiji.plugin.trackmate;
/*      */ 
/*      */ import fiji.plugin.trackmate.features.FeatureFilter;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.NavigableSet;
/*      */ import java.util.Set;
/*      */ import java.util.concurrent.ConcurrentSkipListMap;
/*      */ import java.util.concurrent.ExecutorService;
/*      */ import java.util.concurrent.Executors;
/*      */ import java.util.concurrent.TimeUnit;
/*      */ import net.imglib2.algorithm.MultiThreaded;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class SpotCollection
/*      */   implements MultiThreaded
/*      */ {
/*   56 */   public static final Double ZERO = Double.valueOf(0.0D);
/*      */   
/*   58 */   public static final Double ONE = Double.valueOf(1.0D);
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String VISIBILITY = "VISIBILITY";
/*      */ 
/*      */ 
/*      */   
/*   66 */   private static final TimeUnit TIME_OUT_UNITS = TimeUnit.MINUTES;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final long TIME_OUT_DELAY = 1L;
/*      */ 
/*      */ 
/*      */   
/*   75 */   private ConcurrentSkipListMap<Integer, Set<Spot>> content = new ConcurrentSkipListMap<>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int numThreads;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SpotCollection() {
/*   88 */     setNumThreads();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Spot search(int ID) {
/*  111 */     for (Spot spot : iterable(false)) {
/*  112 */       if (spot.ID() == ID)
/*  113 */         return spot; 
/*      */     } 
/*  115 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/*  121 */     String str = super.toString();
/*      */ 
/*      */     
/*  124 */     str = str + ": contains " + getNSpots(false) + " spots total in " + keySet().size() + " different frames, over which " + getNSpots(true) + " are visible:\n";
/*  125 */     for (Iterator<Integer> iterator = this.content.keySet().iterator(); iterator.hasNext(); ) { int key = ((Integer)iterator.next()).intValue();
/*      */ 
/*      */       
/*  128 */       str = str + "\tframe " + key + ": " + getNSpots(key, false) + " spots total, " + getNSpots(key, true) + " visible.\n"; }
/*      */     
/*  130 */     return str;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void add(Spot spot, Integer frame) {
/*  148 */     Set<Spot> spots = this.content.get(frame);
/*  149 */     if (null == spots) {
/*      */       
/*  151 */       spots = new HashSet<>();
/*  152 */       this.content.put(frame, spots);
/*      */     } 
/*  154 */     spots.add(spot);
/*  155 */     spot.putFeature("FRAME", Double.valueOf(frame.intValue()));
/*  156 */     spot.putFeature("VISIBILITY", ONE);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean remove(Spot spot, Integer frame) {
/*  174 */     Set<Spot> spots = this.content.get(frame);
/*  175 */     if (null == spots)
/*  176 */       return false; 
/*  177 */     return spots.remove(spot);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setVisible(boolean visible) {
/*  188 */     final Double val = visible ? ONE : ZERO;
/*  189 */     Collection<Integer> frames = this.content.keySet();
/*      */     
/*  191 */     ExecutorService executors = Executors.newFixedThreadPool(this.numThreads);
/*  192 */     for (Integer frame : frames) {
/*      */ 
/*      */       
/*  195 */       Runnable command = new Runnable()
/*      */         {
/*      */ 
/*      */           
/*      */           public void run()
/*      */           {
/*  201 */             Set<Spot> spots = (Set<Spot>)SpotCollection.this.content.get(frame);
/*  202 */             for (Spot spot : spots)
/*  203 */               spot.putFeature("VISIBILITY", val); 
/*      */           }
/*      */         };
/*  206 */       executors.execute(command);
/*      */     } 
/*      */     
/*  209 */     executors.shutdown();
/*      */     
/*      */     try {
/*  212 */       boolean ok = executors.awaitTermination(1L, TIME_OUT_UNITS);
/*  213 */       if (!ok) {
/*  214 */         System.err.println("[SpotCollection.setVisible()] Timeout of 1 " + TIME_OUT_UNITS + " reached.");
/*      */       }
/*  216 */     } catch (InterruptedException e) {
/*      */       
/*  218 */       e.printStackTrace();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void filter(final FeatureFilter featurefilter) {
/*  233 */     Collection<Integer> frames = this.content.keySet();
/*  234 */     ExecutorService executors = Executors.newFixedThreadPool(this.numThreads);
/*      */     
/*  236 */     for (Integer frame : frames) {
/*      */ 
/*      */       
/*  239 */       Runnable command = new Runnable()
/*      */         {
/*      */           
/*      */           public void run()
/*      */           {
/*  244 */             Set<Spot> spots = (Set<Spot>)SpotCollection.this.content.get(frame);
/*  245 */             double tval = featurefilter.value;
/*      */             
/*  247 */             if (featurefilter.isAbove) {
/*      */               
/*  249 */               for (Spot spot : spots)
/*      */               {
/*  251 */                 Double val = spot.getFeature(featurefilter.feature);
/*  252 */                 spot.putFeature("VISIBILITY", (val.compareTo(Double.valueOf(tval)) < 0) ? SpotCollection.ZERO : SpotCollection.ONE);
/*      */               }
/*      */             
/*      */             }
/*      */             else {
/*      */               
/*  258 */               for (Spot spot : spots) {
/*      */                 
/*  260 */                 Double val = spot.getFeature(featurefilter.feature);
/*  261 */                 spot.putFeature("VISIBILITY", (val.compareTo(Double.valueOf(tval)) > 0) ? SpotCollection.ZERO : SpotCollection.ONE);
/*      */               } 
/*      */             } 
/*      */           }
/*      */         };
/*  266 */       executors.execute(command);
/*      */     } 
/*      */     
/*  269 */     executors.shutdown();
/*      */     
/*      */     try {
/*  272 */       boolean ok = executors.awaitTermination(1L, TIME_OUT_UNITS);
/*  273 */       if (!ok) {
/*  274 */         System.err.println("[SpotCollection.filter()] Timeout of 1 " + TIME_OUT_UNITS + " reached while filtering.");
/*      */       }
/*  276 */     } catch (InterruptedException e) {
/*      */       
/*  278 */       e.printStackTrace();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void filter(final Collection<FeatureFilter> filters) {
/*  294 */     Collection<Integer> frames = this.content.keySet();
/*  295 */     ExecutorService executors = Executors.newFixedThreadPool(this.numThreads);
/*      */     
/*  297 */     for (Integer frame : frames) {
/*      */       
/*  299 */       Runnable command = new Runnable()
/*      */         {
/*      */           
/*      */           public void run()
/*      */           {
/*  304 */             Set<Spot> spots = (Set<Spot>)SpotCollection.this.content.get(frame);
/*  305 */             for (Spot spot : spots) {
/*      */ 
/*      */               
/*  308 */               boolean shouldNotBeVisible = false;
/*  309 */               for (FeatureFilter featureFilter : filters) {
/*      */ 
/*      */                 
/*  312 */                 Double val = spot.getFeature(featureFilter.feature);
/*  313 */                 double tval = featureFilter.value;
/*  314 */                 boolean isAbove = featureFilter.isAbove;
/*      */                 
/*  316 */                 if (null == val || (isAbove && val.compareTo(Double.valueOf(tval)) < 0) || (!isAbove && val.compareTo(Double.valueOf(tval)) > 0)) {
/*      */                   
/*  318 */                   shouldNotBeVisible = true;
/*      */                   break;
/*      */                 } 
/*      */               } 
/*  322 */               spot.putFeature("VISIBILITY", shouldNotBeVisible ? SpotCollection.ZERO : SpotCollection.ONE);
/*      */             } 
/*      */           }
/*      */         };
/*      */       
/*  327 */       executors.execute(command);
/*      */     } 
/*      */     
/*  330 */     executors.shutdown();
/*      */     
/*      */     try {
/*  333 */       boolean ok = executors.awaitTermination(1L, TIME_OUT_UNITS);
/*  334 */       if (!ok) {
/*  335 */         System.err.println("[SpotCollection.filter()] Timeout of 1 " + TIME_OUT_UNITS + " reached while filtering.");
/*      */       }
/*  337 */     } catch (InterruptedException e) {
/*      */       
/*  339 */       e.printStackTrace();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Spot getClosestSpot(Spot location, int frame, boolean visibleSpotsOnly) {
/*  360 */     Set<Spot> spots = this.content.get(Integer.valueOf(frame));
/*  361 */     if (null == spots)
/*  362 */       return null; 
/*  363 */     double minDist = Double.POSITIVE_INFINITY;
/*  364 */     Spot target = null;
/*  365 */     for (Spot spot : spots) {
/*      */ 
/*      */       
/*  368 */       if (visibleSpotsOnly && !isVisible(spot)) {
/*      */         continue;
/*      */       }
/*  371 */       double d2 = spot.squareDistanceTo(location);
/*  372 */       if (d2 < minDist) {
/*      */         
/*  374 */         minDist = d2;
/*  375 */         target = spot;
/*      */       } 
/*      */     } 
/*  378 */     return target;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Spot getSpotAt(Spot location, int frame, boolean visibleSpotsOnly) {
/*  400 */     Set<Spot> spots = this.content.get(Integer.valueOf(frame));
/*  401 */     if (null == spots || spots.isEmpty()) {
/*  402 */       return null;
/*      */     }
/*  404 */     double minDist2 = Double.POSITIVE_INFINITY;
/*  405 */     Spot bestSpot = null;
/*  406 */     for (Spot spot : spots) {
/*      */       
/*  408 */       if (visibleSpotsOnly && !isVisible(spot)) {
/*      */         continue;
/*      */       }
/*  411 */       double d2 = spot.squareDistanceTo(location);
/*  412 */       double radius = spot.getFeature("RADIUS").doubleValue();
/*  413 */       if (d2 < Math.min(minDist2, radius * radius)) {
/*      */         
/*  415 */         minDist2 = d2;
/*  416 */         bestSpot = spot;
/*      */       } 
/*      */     } 
/*  419 */     return bestSpot;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final int getNSpots(boolean visibleSpotsOnly) {
/*  432 */     int nspots = 0;
/*  433 */     if (visibleSpotsOnly) {
/*      */       
/*  435 */       Iterator<Spot> it = iterator(true);
/*  436 */       while (it.hasNext())
/*      */       {
/*  438 */         it.next();
/*  439 */         nspots++;
/*      */       }
/*      */     
/*      */     }
/*      */     else {
/*      */       
/*  445 */       for (Set<Spot> spots : this.content.values())
/*  446 */         nspots += spots.size(); 
/*      */     } 
/*  448 */     return nspots;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getNSpots(int frame, boolean visibleSpotsOnly) {
/*  463 */     if (visibleSpotsOnly) {
/*      */       
/*  465 */       Iterator<Spot> it = iterator(Integer.valueOf(frame), true);
/*  466 */       int nspots = 0;
/*  467 */       while (it.hasNext()) {
/*      */         
/*  469 */         it.next();
/*  470 */         nspots++;
/*      */       } 
/*  472 */       return nspots;
/*      */     } 
/*      */     
/*  475 */     Set<Spot> spots = this.content.get(Integer.valueOf(frame));
/*  476 */     if (null == spots) {
/*  477 */       return 0;
/*      */     }
/*  479 */     return spots.size();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Iterator<Spot> iterator(boolean visibleSpotsOnly) {
/*  497 */     if (visibleSpotsOnly) {
/*  498 */       return new VisibleSpotsIterator();
/*      */     }
/*  500 */     return new AllSpotsIterator();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Iterator<Spot> iterator(Integer frame, boolean visibleSpotsOnly) {
/*  516 */     Set<Spot> frameContent = this.content.get(frame);
/*  517 */     if (null == frameContent) {
/*  518 */       return EMPTY_ITERATOR;
/*      */     }
/*  520 */     if (visibleSpotsOnly) {
/*  521 */       return new VisibleSpotsFrameIterator(frameContent);
/*      */     }
/*  523 */     return frameContent.iterator();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Iterable<Spot> iterable(boolean visibleSpotsOnly) {
/*  537 */     return new WholeCollectionIterable(visibleSpotsOnly);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Iterable<Spot> iterable(int frame, boolean visibleSpotsOnly) {
/*  556 */     if (visibleSpotsOnly) {
/*  557 */       return new FrameVisibleIterable(frame);
/*      */     }
/*  559 */     return this.content.get(Integer.valueOf(frame));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void put(int frame, Collection<Spot> spots) {
/*  579 */     Set<Spot> value = new HashSet<>(spots);
/*  580 */     for (Spot spot : value) {
/*      */       
/*  582 */       spot.putFeature("FRAME", Double.valueOf(frame));
/*  583 */       spot.putFeature("VISIBILITY", ZERO);
/*      */     } 
/*  585 */     this.content.put(Integer.valueOf(frame), value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Integer firstKey() {
/*  595 */     if (this.content.isEmpty())
/*  596 */       return Integer.valueOf(0); 
/*  597 */     return this.content.firstKey();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Integer lastKey() {
/*  607 */     if (this.content.isEmpty())
/*  608 */       return Integer.valueOf(0); 
/*  609 */     return this.content.lastKey();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public NavigableSet<Integer> keySet() {
/*  631 */     return this.content.keySet();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void clear() {
/*  639 */     this.content.clear();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNumThreads() {
/*  649 */     this.numThreads = Runtime.getRuntime().availableProcessors();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNumThreads(int numThreads) {
/*  655 */     this.numThreads = numThreads;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int getNumThreads() {
/*  661 */     return this.numThreads;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private class AllSpotsIterator
/*      */     implements Iterator<Spot>
/*      */   {
/*      */     private boolean hasNext = true;
/*      */ 
/*      */     
/*      */     private final Iterator<Integer> frameIterator;
/*      */ 
/*      */     
/*      */     private Iterator<Spot> contentIterator;
/*      */     
/*  677 */     private Spot next = null;
/*      */ 
/*      */     
/*      */     public AllSpotsIterator() {
/*  681 */       this.frameIterator = SpotCollection.this.content.keySet().iterator();
/*  682 */       if (!this.frameIterator.hasNext()) {
/*      */         
/*  684 */         this.hasNext = false;
/*      */         return;
/*      */       } 
/*  687 */       Set<Spot> currentFrameContent = (Set<Spot>)SpotCollection.this.content.get(this.frameIterator.next());
/*  688 */       this.contentIterator = currentFrameContent.iterator();
/*  689 */       iterate();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private void iterate() {
/*  698 */       while (!this.contentIterator.hasNext()) {
/*      */ 
/*      */ 
/*      */         
/*  702 */         if (!this.frameIterator.hasNext()) {
/*      */ 
/*      */           
/*  705 */           this.hasNext = false;
/*  706 */           this.next = null;
/*      */           
/*      */           return;
/*      */         } 
/*  710 */         this.contentIterator = ((Set<Spot>)SpotCollection.this.content.get(this.frameIterator.next())).iterator();
/*      */       } 
/*      */       
/*  713 */       this.next = this.contentIterator.next();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean hasNext() {
/*  721 */       return this.hasNext;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public Spot next() {
/*  727 */       Spot toReturn = this.next;
/*  728 */       iterate();
/*  729 */       return toReturn;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public void remove() {
/*  735 */       throw new UnsupportedOperationException("Remove operation is not supported for SpotCollection iterators.");
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private class VisibleSpotsIterator
/*      */     implements Iterator<Spot>
/*      */   {
/*      */     private boolean hasNext = true;
/*      */     
/*      */     private final Iterator<Integer> frameIterator;
/*      */     
/*      */     private Iterator<Spot> contentIterator;
/*  748 */     private Spot next = null;
/*      */     
/*      */     private Set<Spot> currentFrameContent;
/*      */ 
/*      */     
/*      */     public VisibleSpotsIterator() {
/*  754 */       this.frameIterator = SpotCollection.this.content.keySet().iterator();
/*  755 */       if (!this.frameIterator.hasNext()) {
/*      */         
/*  757 */         this.hasNext = false;
/*      */         return;
/*      */       } 
/*  760 */       this.currentFrameContent = (Set<Spot>)SpotCollection.this.content.get(this.frameIterator.next());
/*  761 */       this.contentIterator = this.currentFrameContent.iterator();
/*  762 */       iterate();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private void iterate() {
/*      */       do {
/*  771 */         while (!this.contentIterator.hasNext()) {
/*      */ 
/*      */ 
/*      */           
/*  775 */           if (!this.frameIterator.hasNext()) {
/*      */ 
/*      */             
/*  778 */             this.hasNext = false;
/*  779 */             this.next = null;
/*      */             
/*      */             return;
/*      */           } 
/*      */           
/*  784 */           this.currentFrameContent = (Set<Spot>)SpotCollection.this.content.get(this.frameIterator.next());
/*  785 */           this.contentIterator = this.currentFrameContent.iterator();
/*      */         } 
/*      */         
/*  788 */         this.next = this.contentIterator.next();
/*      */       }
/*  790 */       while (this.next.getFeature("VISIBILITY").compareTo(SpotCollection.ZERO) <= 0);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean hasNext() {
/*  801 */       return this.hasNext;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public Spot next() {
/*  807 */       Spot toReturn = this.next;
/*  808 */       iterate();
/*  809 */       return toReturn;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public void remove() {
/*  815 */       throw new UnsupportedOperationException("Remove operation is not supported for SpotCollection iterators.");
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private class VisibleSpotsFrameIterator
/*      */     implements Iterator<Spot>
/*      */   {
/*      */     private boolean hasNext = true;
/*  824 */     private Spot next = null;
/*      */     
/*      */     private final Iterator<Spot> contentIterator;
/*      */ 
/*      */     
/*      */     public VisibleSpotsFrameIterator(Set<Spot> frameContent) {
/*  830 */       this.contentIterator = (null == frameContent) ? SpotCollection.EMPTY_ITERATOR : frameContent.iterator();
/*  831 */       iterate();
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     private void iterate() {
/*      */       do {
/*  838 */         if (!this.contentIterator.hasNext()) {
/*      */ 
/*      */           
/*  841 */           this.hasNext = false;
/*  842 */           this.next = null;
/*      */           return;
/*      */         } 
/*  845 */         this.next = this.contentIterator.next();
/*      */       }
/*  847 */       while (this.next.getFeature("VISIBILITY").compareTo(SpotCollection.ZERO) <= 0);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean hasNext() {
/*  858 */       return this.hasNext;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public Spot next() {
/*  864 */       Spot toReturn = this.next;
/*  865 */       iterate();
/*  866 */       return toReturn;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public void remove() {
/*  872 */       throw new UnsupportedOperationException("Remove operation is not supported for SpotCollection iterators.");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void crop() {
/*  881 */     Collection<Integer> frames = this.content.keySet();
/*  882 */     for (Integer frame : frames) {
/*      */       
/*  884 */       Set<Spot> fc = this.content.get(frame);
/*  885 */       List<Spot> toRemove = new ArrayList<>();
/*  886 */       for (Spot spot : fc) {
/*  887 */         if (!isVisible(spot))
/*  888 */           toRemove.add(spot); 
/*      */       } 
/*  890 */       fc.removeAll(toRemove);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final class WholeCollectionIterable
/*      */     implements Iterable<Spot>
/*      */   {
/*      */     private final boolean visibleSpotsOnly;
/*      */ 
/*      */ 
/*      */     
/*      */     public WholeCollectionIterable(boolean visibleSpotsOnly) {
/*  905 */       this.visibleSpotsOnly = visibleSpotsOnly;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public Iterator<Spot> iterator() {
/*  911 */       if (this.visibleSpotsOnly) {
/*  912 */         return new SpotCollection.VisibleSpotsIterator();
/*      */       }
/*  914 */       return new SpotCollection.AllSpotsIterator();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final class FrameVisibleIterable
/*      */     implements Iterable<Spot>
/*      */   {
/*      */     private final int frame;
/*      */ 
/*      */ 
/*      */     
/*      */     public FrameVisibleIterable(int frame) {
/*  929 */       this.frame = frame;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public Iterator<Spot> iterator() {
/*  935 */       return new SpotCollection.VisibleSpotsFrameIterator((Set<Spot>)SpotCollection.this.content.get(Integer.valueOf(this.frame)));
/*      */     }
/*      */   }
/*      */   
/*  939 */   private static final Iterator<Spot> EMPTY_ITERATOR = new Iterator<Spot>()
/*      */     {
/*      */ 
/*      */       
/*      */       public boolean hasNext()
/*      */       {
/*  945 */         return false;
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*      */       public Spot next() {
/*  951 */         return null;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public void remove() {}
/*      */     };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static SpotCollection fromCollection(Iterable<Spot> spots) {
/*  975 */     SpotCollection sc = new SpotCollection();
/*  976 */     for (Spot spot : spots) {
/*      */       
/*  978 */       int frame = spot.getFeature("FRAME").intValue();
/*  979 */       Set<Spot> fc = sc.content.get(Integer.valueOf(frame));
/*  980 */       if (null == fc) {
/*      */         
/*  982 */         fc = new HashSet<>();
/*  983 */         sc.content.put(Integer.valueOf(frame), fc);
/*      */       } 
/*  985 */       fc.add(spot);
/*      */     } 
/*  987 */     return sc;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static SpotCollection fromMap(Map<Integer, Set<Spot>> source) {
/* 1002 */     SpotCollection sc = new SpotCollection();
/* 1003 */     sc.content = new ConcurrentSkipListMap<>(source);
/* 1004 */     return sc;
/*      */   }
/*      */ 
/*      */   
/*      */   private static final boolean isVisible(Spot spot) {
/* 1009 */     return (spot.getFeature("VISIBILITY").compareTo(ZERO) > 0);
/*      */   }
/*      */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/SpotCollection.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */