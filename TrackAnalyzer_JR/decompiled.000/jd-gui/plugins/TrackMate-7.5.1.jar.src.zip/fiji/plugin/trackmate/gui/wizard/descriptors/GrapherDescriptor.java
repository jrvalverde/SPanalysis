/*    */ package fiji.plugin.trackmate.gui.wizard.descriptors;
/*    */ 
/*    */ import fiji.plugin.trackmate.SelectionModel;
/*    */ import fiji.plugin.trackmate.TrackMate;
/*    */ import fiji.plugin.trackmate.features.FeatureUtils;
/*    */ import fiji.plugin.trackmate.gui.components.FeaturePlotSelectionPanel;
/*    */ import fiji.plugin.trackmate.gui.components.GrapherPanel;
/*    */ import fiji.plugin.trackmate.gui.displaysettings.DisplaySettings;
/*    */ import fiji.plugin.trackmate.gui.wizard.WizardPanelDescriptor;
/*    */ import java.awt.Component;
/*    */ import java.util.Map;
/*    */ import java.util.Set;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GrapherDescriptor
/*    */   extends WizardPanelDescriptor
/*    */ {
/*    */   private static final String KEY = "GraphFeatures";
/*    */   private final TrackMate trackmate;
/*    */   
/*    */   public GrapherDescriptor(TrackMate trackmate, SelectionModel selectionModel, DisplaySettings displaySettings) {
/* 45 */     super("GraphFeatures");
/* 46 */     this.trackmate = trackmate;
/* 47 */     this.targetPanel = (Component)new GrapherPanel(trackmate, selectionModel, displaySettings);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void aboutToDisplayPanel() {
/* 54 */     GrapherPanel panel = (GrapherPanel)this.targetPanel;
/*    */     
/* 56 */     Map<String, String> spotFeatureNames = FeatureUtils.collectFeatureKeys(DisplaySettings.TrackMateObject.SPOTS, this.trackmate.getModel(), this.trackmate.getSettings());
/* 57 */     Set<String> spotFeatures = spotFeatureNames.keySet();
/* 58 */     FeaturePlotSelectionPanel spotFeatureSelectionPanel = panel.getSpotFeatureSelectionPanel();
/* 59 */     spotFeatureSelectionPanel.setFeatures(spotFeatures, spotFeatureNames);
/*    */     
/* 61 */     Map<String, String> edgeFeatureNames = FeatureUtils.collectFeatureKeys(DisplaySettings.TrackMateObject.EDGES, this.trackmate.getModel(), this.trackmate.getSettings());
/* 62 */     Set<String> edgeFeatures = edgeFeatureNames.keySet();
/* 63 */     FeaturePlotSelectionPanel edgeFeatureSelectionPanel = panel.getEdgeFeatureSelectionPanel();
/* 64 */     edgeFeatureSelectionPanel.setFeatures(edgeFeatures, edgeFeatureNames);
/*    */     
/* 66 */     Map<String, String> trackFeatureNames = FeatureUtils.collectFeatureKeys(DisplaySettings.TrackMateObject.TRACKS, this.trackmate.getModel(), this.trackmate.getSettings());
/* 67 */     Set<String> trackFeatures = trackFeatureNames.keySet();
/* 68 */     FeaturePlotSelectionPanel trackFeatureSelectionPanel = panel.getTrackFeatureSelectionPanel();
/* 69 */     trackFeatureSelectionPanel.setFeatures(trackFeatures, trackFeatureNames);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/gui/wizard/descriptors/GrapherDescriptor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */