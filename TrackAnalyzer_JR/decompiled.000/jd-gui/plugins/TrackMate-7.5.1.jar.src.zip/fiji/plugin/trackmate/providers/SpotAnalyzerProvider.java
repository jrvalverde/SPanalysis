/*    */ package fiji.plugin.trackmate.providers;
/*    */ 
/*    */ import fiji.plugin.trackmate.TrackMateModule;
/*    */ import fiji.plugin.trackmate.features.spot.SpotAnalyzerFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SpotAnalyzerProvider
/*    */   extends AbstractProvider<SpotAnalyzerFactory>
/*    */ {
/*    */   private final int nChannels;
/*    */   
/*    */   public SpotAnalyzerProvider(int nChannels) {
/* 37 */     super(SpotAnalyzerFactory.class);
/* 38 */     this.nChannels = nChannels;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public SpotAnalyzerFactory getFactory(String key) {
/* 44 */     SpotAnalyzerFactory factory = super.getFactory(key);
/* 45 */     if (factory == null) {
/* 46 */       return null;
/*    */     }
/* 48 */     factory.setNChannels(this.nChannels);
/* 49 */     return factory;
/*    */   }
/*    */ 
/*    */   
/*    */   public static void main(String[] args) {
/* 54 */     SpotAnalyzerProvider provider = new SpotAnalyzerProvider(2);
/* 55 */     System.out.println(provider.echo());
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/providers/SpotAnalyzerProvider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */