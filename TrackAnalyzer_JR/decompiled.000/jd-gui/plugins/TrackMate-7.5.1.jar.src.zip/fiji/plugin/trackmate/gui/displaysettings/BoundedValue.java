/*    */ package fiji.plugin.trackmate.gui.displaysettings;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BoundedValue
/*    */ {
/*    */   private int rangeMin;
/*    */   private int rangeMax;
/*    */   private int currentValue;
/*    */   private UpdateListener updateListener;
/*    */   
/*    */   public BoundedValue(int rangeMin, int rangeMax, int currentValue) {
/* 48 */     this.rangeMin = rangeMin;
/* 49 */     this.rangeMax = rangeMax;
/* 50 */     this.currentValue = currentValue;
/* 51 */     this.updateListener = null;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getRangeMin() {
/* 56 */     return this.rangeMin;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getRangeMax() {
/* 61 */     return this.rangeMax;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getCurrentValue() {
/* 66 */     return this.currentValue;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setRange(int min, int max) {
/* 71 */     assert min <= max;
/* 72 */     this.rangeMin = min;
/* 73 */     this.rangeMax = max;
/* 74 */     this.currentValue = Math.min(Math.max(this.currentValue, min), max);
/*    */     
/* 76 */     if (this.updateListener != null) {
/* 77 */       this.updateListener.update();
/*    */     }
/*    */   }
/*    */   
/*    */   public void setCurrentValue(int value) {
/* 82 */     this.currentValue = value;
/*    */     
/* 84 */     if (this.currentValue < this.rangeMin) {
/* 85 */       this.currentValue = this.rangeMin;
/* 86 */     } else if (this.currentValue > this.rangeMax) {
/* 87 */       this.currentValue = this.rangeMax;
/*    */     } 
/* 89 */     if (this.updateListener != null) {
/* 90 */       this.updateListener.update();
/*    */     }
/*    */   }
/*    */   
/*    */   public void setUpdateListener(UpdateListener l) {
/* 95 */     this.updateListener = l;
/*    */   }
/*    */   
/*    */   public static interface UpdateListener {
/*    */     void update();
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/gui/displaysettings/BoundedValue.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */