/*     */ package fiji.plugin.trackmate.features.spot;
/*     */ 
/*     */ import fiji.plugin.trackmate.Dimension;
/*     */ import fiji.plugin.trackmate.util.TMUtils;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.swing.ImageIcon;
/*     */ import net.imagej.ImgPlus;
/*     */ import net.imglib2.type.NativeType;
/*     */ import net.imglib2.type.numeric.RealType;
/*     */ import org.scijava.plugin.Plugin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Plugin(type = SpotAnalyzerFactory.class, priority = -100.0D)
/*     */ public class SpotContrastAndSNRAnalyzerFactory<T extends RealType<T> & NativeType<T>>
/*     */   implements SpotAnalyzerFactory<T>
/*     */ {
/*     */   public static final String CONTRAST = "CONTRAST_CH";
/*     */   public static final String SNR = "SNR_CH";
/*     */   private static final String CONTRAST_NAME = "Contrast ch";
/*     */   private static final String SNR_NAME = "Signal/Noise ratio ch";
/*     */   private static final String CONTRAST_SHORTNAME = "Ctrst ch";
/*     */   private static final String SNR_SHORTNAME = "SNR ch";
/*  62 */   private static final List<String> FEATURES = Arrays.asList(new String[] { "CONTRAST_CH", "SNR_CH" });
/*     */   
/*  64 */   private static final List<String> FEATURE_SHORTNAMES = Arrays.asList(new String[] { "Ctrst ch", "SNR ch" });
/*     */   
/*  66 */   private static final List<String> FEATURE_NAMES = Arrays.asList(new String[] { "Contrast ch", "Signal/Noise ratio ch" });
/*     */ 
/*     */   
/*     */   public static final String KEY = "Spot contrast and SNR";
/*     */   
/*  71 */   private int nChannels = 1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SpotAnalyzer<T> getAnalyzer(ImgPlus<T> img, int frame, int channel) {
/*  82 */     ImgPlus<T> imgTC = TMUtils.hyperSlice(img, channel, frame);
/*  83 */     return (SpotAnalyzer)new SpotContrastAndSNRAnalyzer<>(imgTC, channel);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getKey() {
/*  89 */     return "Spot contrast and SNR";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public List<String> getFeatures() {
/*  95 */     List<String> features = new ArrayList<>(this.nChannels * FEATURES.size());
/*  96 */     for (int c = 0; c < this.nChannels; c++) {
/*  97 */       for (String feature : FEATURES)
/*  98 */         features.add(SpotIntensityMultiCAnalyzerFactory.makeFeatureKey(feature, c)); 
/*     */     } 
/* 100 */     return features;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, String> getFeatureShortNames() {
/* 106 */     Map<String, String> names = new LinkedHashMap<>(this.nChannels * FEATURES.size());
/* 107 */     for (int c = 0; c < this.nChannels; c++) {
/* 108 */       for (int i = 0; i < FEATURES.size(); i++) {
/*     */         
/* 110 */         String feature = FEATURES.get(i);
/* 111 */         String shortName = FEATURE_SHORTNAMES.get(i);
/* 112 */         names.put(SpotIntensityMultiCAnalyzerFactory.makeFeatureKey(feature, c), SpotIntensityMultiCAnalyzerFactory.makeFeatureKey(shortName, c));
/*     */       } 
/*     */     } 
/* 115 */     return names;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, String> getFeatureNames() {
/* 121 */     Map<String, String> names = new LinkedHashMap<>(this.nChannels * FEATURES.size());
/* 122 */     for (int c = 0; c < this.nChannels; c++) {
/* 123 */       for (int i = 0; i < FEATURES.size(); i++) {
/*     */         
/* 125 */         String feature = FEATURES.get(i);
/* 126 */         String shortName = FEATURE_NAMES.get(i);
/* 127 */         names.put(SpotIntensityMultiCAnalyzerFactory.makeFeatureKey(feature, c), SpotIntensityMultiCAnalyzerFactory.makeFeatureKey(shortName, c));
/*     */       } 
/*     */     } 
/* 130 */     return names;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, Dimension> getFeatureDimensions() {
/* 136 */     List<String> features = getFeatures();
/* 137 */     Map<String, Dimension> dimensions = new LinkedHashMap<>(features.size());
/* 138 */     for (String feature : features) {
/* 139 */       dimensions.put(feature, Dimension.NONE);
/*     */     }
/* 141 */     return dimensions;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, Boolean> getIsIntFeature() {
/* 147 */     List<String> features = getFeatures();
/* 148 */     Map<String, Boolean> isints = new LinkedHashMap<>(features.size());
/* 149 */     for (String feature : features) {
/* 150 */       isints.put(feature, Boolean.FALSE);
/*     */     }
/* 152 */     return isints;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getInfoText() {
/* 159 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ImageIcon getIcon() {
/* 165 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/* 171 */     return "Spot contrast and SNR";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isManualFeature() {
/* 177 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setNChannels(int nChannels) {
/* 183 */     this.nChannels = nChannels;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/features/spot/SpotContrastAndSNRAnalyzerFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */