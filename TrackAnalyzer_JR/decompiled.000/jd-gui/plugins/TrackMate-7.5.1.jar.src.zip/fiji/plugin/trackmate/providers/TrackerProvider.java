/*    */ package fiji.plugin.trackmate.providers;
/*    */ 
/*    */ import fiji.plugin.trackmate.tracking.SpotTrackerFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TrackerProvider
/*    */   extends AbstractProvider<SpotTrackerFactory>
/*    */ {
/*    */   public TrackerProvider() {
/* 32 */     super(SpotTrackerFactory.class);
/*    */   }
/*    */ 
/*    */   
/*    */   public static void main(String[] args) {
/* 37 */     TrackerProvider provider = new TrackerProvider();
/* 38 */     System.out.println(provider.echo());
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/providers/TrackerProvider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */