/*    */ package fiji.plugin.trackmate.gui.wizard.descriptors;
/*    */ 
/*    */ import fiji.plugin.trackmate.Logger;
/*    */ import fiji.plugin.trackmate.Settings;
/*    */ import fiji.plugin.trackmate.gui.components.ConfigurationPanel;
/*    */ import fiji.plugin.trackmate.gui.wizard.WizardPanelDescriptor;
/*    */ import fiji.plugin.trackmate.io.SettingsPersistence;
/*    */ import fiji.plugin.trackmate.util.TMUtils;
/*    */ import java.awt.Component;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SpotDetectorDescriptor
/*    */   extends WizardPanelDescriptor
/*    */ {
/*    */   public static final String KEY = "ConfigureDetector";
/*    */   private final Settings settings;
/*    */   private final Logger logger;
/*    */   
/*    */   public SpotDetectorDescriptor(Settings settings, ConfigurationPanel configurationPanel, Logger logger) {
/* 43 */     super("ConfigureDetector");
/* 44 */     this.settings = settings;
/* 45 */     this.targetPanel = (Component)configurationPanel;
/* 46 */     this.logger = logger;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void aboutToHidePanel() {
/* 52 */     ConfigurationPanel configurationPanel = (ConfigurationPanel)this.targetPanel;
/* 53 */     this.settings.detectorSettings = configurationPanel.getSettings();
/*    */     
/* 55 */     this.logger.log("\nConfigured detector ");
/* 56 */     this.logger.log(this.settings.detectorFactory.getName(), Logger.BLUE_COLOR);
/* 57 */     this.logger.log(" with settings:\n");
/* 58 */     this.logger.log(TMUtils.echoMap(this.settings.detectorSettings, 2) + "\n");
/*    */ 
/*    */     
/* 61 */     SettingsPersistence.saveLastUsedSettings(this.settings, this.logger);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/gui/wizard/descriptors/SpotDetectorDescriptor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */