/*    */ package fiji.plugin.trackmate.gui.components.detector;
/*    */ 
/*    */ import fiji.plugin.trackmate.Model;
/*    */ import fiji.plugin.trackmate.Settings;
/*    */ import fiji.plugin.trackmate.detection.MaskDetectorFactory;
/*    */ import fiji.plugin.trackmate.detection.SpotDetectorFactory;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MaskDetectorConfigurationPanel
/*    */   extends ThresholdDetectorConfigurationPanel
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   public MaskDetectorConfigurationPanel(Settings settings, Model model) {
/* 52 */     super(settings, model, "<html>This detector creates spots from a black and white mask.<p>More precisely, all the pixels in the designated channel that have a value strictly larger than 0 are considered as part of the foreground, and used to build connected regions. In 2D, spots are created with the (possibly simplified) contour of the region. In 3D, a spherical spot is created for each region in its center, with a volume equal to the region volume.</html>", "Mask detector");
/* 53 */     this.ftfIntensityThreshold.setVisible(false);
/* 54 */     this.btnAutoThreshold.setVisible(false);
/* 55 */     this.lblIntensityThreshold.setVisible(false);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Map<String, Object> getSettings() {
/* 61 */     Map<String, Object> lSettings = super.getSettings();
/* 62 */     lSettings.remove("INTENSITY_THRESHOLD");
/* 63 */     return lSettings;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void setSettings(Map<String, Object> settings) {
/* 69 */     this.sliderChannel.setValue(((Integer)settings.get("TARGET_CHANNEL")).intValue());
/* 70 */     this.chkboxSimplify.setSelected(((Boolean)settings.get("SIMPLIFY_CONTOURS")).booleanValue());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected SpotDetectorFactory<?> getDetectorFactory() {
/* 85 */     return (SpotDetectorFactory<?>)new MaskDetectorFactory();
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/gui/components/detector/MaskDetectorConfigurationPanel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */