/*     */ package fiji.plugin.trackmate.gui.components.tracker;
/*     */ 
/*     */ import fiji.plugin.trackmate.gui.Icons;
/*     */ import java.awt.Component;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.LayoutManager;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Stack;
/*     */ import javax.swing.BoxLayout;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JPanel;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JPanelFeatureSelectionGui
/*     */   extends JPanel
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private final JPanel panelButtons;
/*     */   private final JButton btnRemove;
/*     */   private final JButton btnAdd;
/*  51 */   private final Stack<JPanelFeaturePenalty> featurePanels = new Stack<>();
/*     */   
/*     */   private List<String> features;
/*     */   
/*     */   private Map<String, String> featureNames;
/*     */   
/*     */   private int index;
/*     */ 
/*     */   
/*     */   public JPanelFeatureSelectionGui() {
/*  61 */     BoxLayout layout = new BoxLayout(this, 1);
/*  62 */     setLayout(layout);
/*  63 */     this.panelButtons = new JPanel();
/*  64 */     add(this.panelButtons);
/*  65 */     this.panelButtons.setPreferredSize(new Dimension(260, 25));
/*  66 */     this.panelButtons.setLayout((LayoutManager)null);
/*     */     
/*  68 */     this.btnRemove = new JButton();
/*  69 */     this.panelButtons.add(this.btnRemove);
/*  70 */     this.btnRemove.setIcon(Icons.REMOVE_ICON);
/*  71 */     this.btnRemove.setBounds(48, 5, 21, 22);
/*  72 */     this.btnRemove.addActionListener(e -> removeButtonPushed());
/*     */     
/*  74 */     this.btnAdd = new JButton();
/*  75 */     this.panelButtons.add(this.btnAdd);
/*  76 */     this.btnAdd.setIcon(Icons.ADD_ICON);
/*  77 */     this.btnAdd.setBounds(12, 5, 24, 22);
/*  78 */     this.btnAdd.addActionListener(e -> addButtonPushed());
/*  79 */     this.index = -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDisplayFeatures(Collection<String> features, Map<String, String> featureNames) {
/*  92 */     this.features = new ArrayList<>(features);
/*  93 */     this.featureNames = featureNames;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSelectedFeaturePenalties(Map<String, Double> penalties) {
/*  99 */     while (!this.featurePanels.isEmpty()) {
/*     */       
/* 101 */       JPanelFeaturePenalty panel = this.featurePanels.pop();
/* 102 */       remove(panel);
/*     */     } 
/*     */     
/* 105 */     remove(this.panelButtons);
/*     */     
/* 107 */     for (String feature : penalties.keySet()) {
/*     */       
/* 109 */       int localIndex = this.features.indexOf(feature);
/* 110 */       JPanelFeaturePenalty panel = new JPanelFeaturePenalty(this.features, this.featureNames, localIndex);
/* 111 */       panel.setSelectedFeature(feature, ((Double)penalties.get(feature)).doubleValue());
/* 112 */       add(panel);
/* 113 */       this.featurePanels.push(panel);
/*     */     } 
/*     */     
/* 116 */     add(this.panelButtons);
/*     */   }
/*     */ 
/*     */   
/*     */   public Map<String, Double> getFeaturePenalties() {
/* 121 */     Map<String, Double> weights = new HashMap<>(this.featurePanels.size());
/* 122 */     for (JPanelFeaturePenalty panel : this.featurePanels)
/* 123 */       weights.put(panel.getSelectedFeature(), Double.valueOf(panel.getPenaltyWeight())); 
/* 124 */     return weights;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setEnabled(boolean enabled) {
/* 130 */     super.setEnabled(enabled);
/* 131 */     ArrayList<Component> components = new ArrayList<>(3 + this.featurePanels.size());
/* 132 */     components.add(this.panelButtons);
/* 133 */     components.add(this.btnAdd);
/* 134 */     components.add(this.btnRemove);
/* 135 */     components.addAll((Collection)this.featurePanels);
/* 136 */     for (Component component : components) {
/* 137 */       component.setEnabled(enabled);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void addButtonPushed() {
/* 146 */     this.index++;
/* 147 */     if (this.index >= this.features.size())
/* 148 */       this.index = 0; 
/* 149 */     JPanelFeaturePenalty panel = new JPanelFeaturePenalty(this.features, this.featureNames, this.index);
/* 150 */     this.featurePanels.push(panel);
/* 151 */     remove(this.panelButtons);
/* 152 */     add(panel);
/* 153 */     add(this.panelButtons);
/* 154 */     Dimension size = getSize();
/* 155 */     setSize(size.width, size.height + (panel.getSize()).height);
/* 156 */     revalidate();
/*     */   }
/*     */ 
/*     */   
/*     */   private void removeButtonPushed() {
/* 161 */     if (this.featurePanels.isEmpty())
/*     */       return; 
/* 163 */     JPanelFeaturePenalty panel = this.featurePanels.pop();
/* 164 */     remove(panel);
/* 165 */     Dimension size = getSize();
/* 166 */     setSize(size.width, size.height - (panel.getSize()).height);
/* 167 */     revalidate();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/gui/components/tracker/JPanelFeatureSelectionGui.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */