/*     */ package fiji.plugin.trackmate.util;
/*     */ 
/*     */ import fiji.plugin.trackmate.Dimension;
/*     */ import fiji.plugin.trackmate.Logger;
/*     */ import fiji.plugin.trackmate.Settings;
/*     */ import fiji.plugin.trackmate.Spot;
/*     */ import ij.IJ;
/*     */ import ij.ImagePlus;
/*     */ import java.io.File;
/*     */ import java.nio.file.Paths;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.Date;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import net.imagej.ImgPlus;
/*     */ import net.imagej.ImgPlusMetadata;
/*     */ import net.imagej.axis.Axes;
/*     */ import net.imagej.axis.CalibratedAxis;
/*     */ import net.imglib2.FinalInterval;
/*     */ import net.imglib2.Interval;
/*     */ import net.imglib2.img.ImagePlusAdapter;
/*     */ import net.imglib2.img.display.imagej.ImgPlusViews;
/*     */ import net.imglib2.type.numeric.real.DoubleType;
/*     */ import net.imglib2.util.Util;
/*     */ import org.scijava.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TMUtils
/*     */ {
/*  66 */   private static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("EEE, d MMM yyyy HH:mm:ss");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <K, V extends Comparable<? super V>> Map<K, V> sortByValue(Map<K, V> map, final Comparator<V> comparator) {
/*  77 */     List<Map.Entry<K, V>> list = new ArrayList<>(map.entrySet());
/*  78 */     Comparator<Map.Entry<K, V>> c = new Comparator<Map.Entry<K, V>>()
/*     */       {
/*     */ 
/*     */         
/*     */         public int compare(Map.Entry<K, V> o1, Map.Entry<K, V> o2)
/*     */         {
/*  84 */           Comparable comparable1 = (Comparable)o1.getValue();
/*  85 */           Comparable comparable2 = (Comparable)o2.getValue();
/*  86 */           return comparator.compare(comparable1, comparable2);
/*     */         }
/*     */       };
/*  89 */     Collections.sort(list, c);
/*  90 */     LinkedHashMap<K, V> result = new LinkedHashMap<>();
/*  91 */     for (Map.Entry<K, V> entry : list)
/*  92 */       result.put(entry.getKey(), entry.getValue()); 
/*  93 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String echoMap(Map<String, Object> map, int indent) {
/* 102 */     StringBuilder builder = new StringBuilder();
/* 103 */     for (String key : map.keySet()) {
/*     */       
/* 105 */       for (int i = 0; i < indent; i++) {
/* 106 */         builder.append(" ");
/*     */       }
/* 108 */       builder.append("- ");
/* 109 */       builder.append(key.toLowerCase().replace("_", " "));
/* 110 */       builder.append(": ");
/* 111 */       Object obj = map.get(key);
/* 112 */       if (obj instanceof Map) {
/*     */         
/* 114 */         builder.append('\n');
/*     */         
/* 116 */         Map<String, Object> submap = (Map<String, Object>)obj;
/* 117 */         builder.append(echoMap(submap, indent + 2)); continue;
/*     */       } 
/* 119 */       if (obj instanceof Logger) {
/*     */         
/* 121 */         builder.append(obj.getClass().getSimpleName());
/* 122 */         builder.append('\n');
/*     */         
/*     */         continue;
/*     */       } 
/* 126 */       builder.append(obj.toString());
/* 127 */       builder.append('\n');
/*     */     } 
/*     */     
/* 130 */     return builder.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final ImgPlus rawWraps(ImagePlus imp) {
/* 141 */     ImgPlus<DoubleType> img = ImagePlusAdapter.wrapImgPlus(imp);
/* 142 */     ImgPlus<DoubleType> raw = img;
/* 143 */     return raw;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final <T> boolean checkMapKeys(Map<T, ?> map, Collection<T> mandatoryKeys, Collection<T> optionalKeys, StringBuilder errorHolder) {
/* 165 */     if (null == optionalKeys) {
/* 166 */       optionalKeys = new ArrayList<>();
/*     */     }
/* 168 */     if (null == mandatoryKeys) {
/* 169 */       mandatoryKeys = new ArrayList<>();
/*     */     }
/* 171 */     boolean ok = true;
/* 172 */     Set<T> keySet = map.keySet();
/* 173 */     for (T key : keySet) {
/*     */       
/* 175 */       if (!mandatoryKeys.contains(key) && !optionalKeys.contains(key)) {
/*     */         
/* 177 */         ok = false;
/* 178 */         errorHolder.append("Map contains unexpected key: " + key + ".\n");
/*     */       } 
/*     */     } 
/*     */     
/* 182 */     for (T key : mandatoryKeys) {
/*     */       
/* 184 */       if (!keySet.contains(key)) {
/*     */         
/* 186 */         ok = false;
/* 187 */         errorHolder.append("Mandatory key " + key + " was not found in the map.\n");
/*     */       } 
/*     */     } 
/* 190 */     return ok;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final boolean checkParameter(Map<String, Object> map, String key, Class<?> expectedClass, StringBuilder errorHolder) {
/* 211 */     Object obj = map.get(key);
/* 212 */     if (null == obj) {
/*     */       
/* 214 */       errorHolder.append("Parameter " + key + " could not be found in settings map, or is null.\n");
/* 215 */       return false;
/*     */     } 
/* 217 */     if (!expectedClass.isInstance(obj)) {
/*     */       
/* 219 */       errorHolder.append("Value for parameter " + key + " is not of the right class. Expected " + expectedClass.getName() + ", got " + obj.getClass().getName() + ".\n");
/* 220 */       return false;
/*     */     } 
/* 222 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final <J, K> List<K> getArrayFromMaping(Collection<J> keys, Map<J, K> mapping) {
/* 231 */     List<K> names = new ArrayList<>(keys.size());
/* 232 */     for (J key : keys)
/* 233 */       names.add(mapping.get(key)); 
/* 234 */     return names;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final double[] getSpatialCalibration(ImgPlusMetadata img) {
/* 248 */     double[] calibration = Util.getArrayFromValue(1.0D, 3);
/*     */     
/* 250 */     for (int d = 0; d < img.numDimensions(); d++) {
/*     */       
/* 252 */       if (((CalibratedAxis)img.axis(d)).type() == Axes.X) {
/* 253 */         calibration[0] = img.averageScale(d);
/* 254 */       } else if (((CalibratedAxis)img.axis(d)).type() == Axes.Y) {
/* 255 */         calibration[1] = img.averageScale(d);
/* 256 */       } else if (((CalibratedAxis)img.axis(d)).type() == Axes.Z) {
/* 257 */         calibration[2] = img.averageScale(d);
/*     */       } 
/* 259 */     }  return calibration;
/*     */   }
/*     */ 
/*     */   
/*     */   public static double[] getSpatialCalibration(ImagePlus imp) {
/* 264 */     double[] calibration = Util.getArrayFromValue(1.0D, 3);
/* 265 */     calibration[0] = (imp.getCalibration()).pixelWidth;
/* 266 */     calibration[1] = (imp.getCalibration()).pixelHeight;
/* 267 */     if (imp.getNSlices() > 1) {
/* 268 */       calibration[2] = (imp.getCalibration()).pixelDepth;
/*     */     }
/* 270 */     return calibration;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final double getPercentile(double[] values, double p) {
/* 280 */     int size = values.length;
/* 281 */     if (p > 1.0D || p <= 0.0D) {
/* 282 */       throw new IllegalArgumentException("invalid quantile value: " + p);
/*     */     }
/* 284 */     if (size == 0)
/* 285 */       return Double.NaN; 
/* 286 */     if (size == 1)
/* 287 */       return values[0]; 
/* 288 */     double n = size;
/* 289 */     double pos = p * (n + 1.0D);
/* 290 */     double fpos = Math.floor(pos);
/* 291 */     int intPos = (int)fpos;
/* 292 */     double dif = pos - fpos;
/* 293 */     double[] sorted = new double[size];
/* 294 */     System.arraycopy(values, 0, sorted, 0, size);
/* 295 */     Arrays.sort(sorted);
/*     */     
/* 297 */     if (pos < 1.0D)
/* 298 */       return sorted[0]; 
/* 299 */     if (pos >= n)
/* 300 */       return sorted[size - 1]; 
/* 301 */     double lower = sorted[intPos - 1];
/* 302 */     double upper = sorted[intPos];
/* 303 */     return lower + dif * (upper - lower);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final double[] getRange(double[] data) {
/* 314 */     double min = Arrays.stream(data).min().getAsDouble();
/* 315 */     double max = Arrays.stream(data).max().getAsDouble();
/* 316 */     return new double[] { max - min, min, max };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final void localize(Spot spot, double[] coords) {
/* 325 */     coords[0] = spot.getFeature("POSITION_X").doubleValue();
/* 326 */     coords[1] = spot.getFeature("POSITION_Y").doubleValue();
/* 327 */     coords[2] = spot.getFeature("POSITION_Z").doubleValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int getNBins(double[] values, int minBinNumber, int maxBinNumber) {
/* 338 */     int size = values.length;
/* 339 */     double q1 = getPercentile(values, 0.25D);
/* 340 */     double q3 = getPercentile(values, 0.75D);
/* 341 */     double iqr = q3 - q1;
/* 342 */     double binWidth = 2.0D * iqr * Math.pow(size, -0.33D);
/* 343 */     double[] range = getRange(values);
/* 344 */     int nBin = (int)(range[0] / binWidth + 1.0D);
/*     */     
/* 346 */     if (nBin > maxBinNumber) {
/* 347 */       nBin = maxBinNumber;
/* 348 */     } else if (nBin < minBinNumber) {
/* 349 */       nBin = minBinNumber;
/*     */     } 
/* 351 */     return nBin;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final int getNBins(double[] values) {
/* 362 */     return getNBins(values, 8, 256);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final int[] histogram(double[] data, int nBins) {
/* 370 */     double[] range = getRange(data);
/* 371 */     double binWidth = range[0] / nBins;
/* 372 */     int[] hist = new int[nBins];
/*     */ 
/*     */     
/* 375 */     if (nBins > 0)
/*     */     {
/* 377 */       for (int i = 0; i < data.length; i++) {
/*     */         
/* 379 */         int index = Math.min((int)Math.floor((data[i] - range[1]) / binWidth), nBins - 1);
/* 380 */         hist[index] = hist[index] + 1;
/*     */       } 
/*     */     }
/* 383 */     return hist;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final double otsuThreshold(double[] data) {
/* 392 */     return otsuThreshold(data, getNBins(data));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final double otsuThreshold(double[] data, int nBins) {
/* 401 */     int[] hist = histogram(data, nBins);
/* 402 */     int thresholdIndex = otsuThresholdIndex(hist, data.length);
/* 403 */     double[] range = getRange(data);
/* 404 */     double binWidth = range[0] / nBins;
/* 405 */     return range[1] + binWidth * thresholdIndex;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final int otsuThresholdIndex(int[] hist, int nPoints) {
/* 422 */     int total = nPoints;
/*     */     
/* 424 */     double sum = 0.0D;
/* 425 */     for (int t = 0; t < hist.length; t++) {
/* 426 */       sum += (t * hist[t]);
/*     */     }
/* 428 */     double sumB = 0.0D;
/* 429 */     int wB = 0;
/* 430 */     int wF = 0;
/*     */     
/* 432 */     double varMax = 0.0D;
/* 433 */     int threshold = 0;
/*     */     
/* 435 */     for (int i = 0; i < hist.length; i++) {
/*     */       
/* 437 */       wB += hist[i];
/* 438 */       if (wB != 0) {
/*     */ 
/*     */         
/* 441 */         wF = total - wB;
/* 442 */         if (wF == 0) {
/*     */           break;
/*     */         }
/* 445 */         sumB += (i * hist[i]);
/*     */         
/* 447 */         double mB = sumB / wB;
/* 448 */         double mF = (sum - sumB) / wF;
/*     */ 
/*     */         
/* 451 */         double varBetween = (wB * wF) * (mB - mF) * (mB - mF);
/*     */ 
/*     */         
/* 454 */         if (varBetween > varMax) {
/*     */           
/* 456 */           varMax = varBetween;
/* 457 */           threshold = i;
/*     */         } 
/*     */       } 
/* 460 */     }  return threshold;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String getUnitsFor(Dimension dimension, String spaceUnits, String timeUnits) {
/* 470 */     switch (dimension) {
/*     */       
/*     */       case ANGLE:
/* 473 */         return "radians";
/*     */       case INTENSITY:
/* 475 */         return "counts";
/*     */       case INTENSITY_SQUARED:
/* 477 */         return "counts^2";
/*     */       case NONE:
/* 479 */         return "";
/*     */       case POSITION:
/*     */       case LENGTH:
/* 482 */         return spaceUnits;
/*     */       case AREA:
/* 484 */         return spaceUnits + "^2";
/*     */       case QUALITY:
/* 486 */         return "quality";
/*     */       case COST:
/* 488 */         return "cost";
/*     */       case TIME:
/* 490 */         return timeUnits;
/*     */       case VELOCITY:
/* 492 */         return spaceUnits + "/" + timeUnits;
/*     */       case RATE:
/* 494 */         return "/" + timeUnits;
/*     */       case ANGLE_RATE:
/* 496 */         return "rad/" + timeUnits;
/*     */     } 
/*     */     
/* 499 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String getCurrentTimeString() {
/* 505 */     return DATE_FORMAT.format(new Date());
/*     */   }
/*     */   
/*     */   public static <T extends net.imglib2.type.Type<T>> ImgPlus<T> hyperSlice(ImgPlus<T> img, long channel, long frame) {
/*     */     ImgPlus<T> imgTCZ;
/* 510 */     int timeDim = img.dimensionIndex(Axes.TIME);
/*     */ 
/*     */     
/* 513 */     ImgPlus<T> imgT = (timeDim < 0) ? img : ImgPlusViews.hyperSlice(img, timeDim, frame);
/*     */     
/* 515 */     int channelDim = imgT.dimensionIndex(Axes.CHANNEL);
/*     */ 
/*     */     
/* 518 */     ImgPlus<T> imgTC = (channelDim < 0) ? imgT : ImgPlusViews.hyperSlice(imgT, channelDim, channel);
/*     */ 
/*     */     
/* 521 */     int zDim = imgTC.dimensionIndex(Axes.Z);
/*     */     
/* 523 */     if (zDim >= 0 && imgTC.dimension(zDim) <= 1L) {
/* 524 */       imgTCZ = ImgPlusViews.hyperSlice(imgTC, zDim, imgTC.min(zDim));
/*     */     } else {
/* 526 */       imgTCZ = imgTC;
/*     */     } 
/* 528 */     return imgTCZ;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final Interval getIntervalWithTime(ImgPlus<?> img, Settings settings) {
/* 551 */     long[] max2, min2, max = new long[img.numDimensions()];
/* 552 */     long[] min = new long[img.numDimensions()];
/*     */ 
/*     */     
/* 555 */     int xindex = img.dimensionIndex(Axes.X);
/* 556 */     min[xindex] = settings.xstart;
/* 557 */     max[xindex] = settings.xend;
/*     */ 
/*     */     
/* 560 */     int yindex = img.dimensionIndex(Axes.Y);
/* 561 */     min[yindex] = settings.ystart;
/* 562 */     max[yindex] = settings.yend;
/*     */ 
/*     */     
/* 565 */     int zindex = img.dimensionIndex(Axes.Z);
/* 566 */     if (zindex >= 0) {
/*     */       
/* 568 */       min[zindex] = settings.zstart;
/* 569 */       max[zindex] = settings.zend;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 574 */     int tindex = img.dimensionIndex(Axes.TIME);
/* 575 */     if (tindex >= 0) {
/*     */       
/* 577 */       min[tindex] = settings.tstart;
/* 578 */       max[tindex] = settings.tend;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 584 */     int cindex = img.dimensionIndex(Axes.CHANNEL);
/* 585 */     if (cindex >= 0) {
/*     */       
/* 587 */       max2 = new long[img.numDimensions() - 1];
/* 588 */       min2 = new long[img.numDimensions() - 1];
/* 589 */       int d2 = 0;
/* 590 */       for (int d = 0; d < min.length; d++) {
/*     */         
/* 592 */         if (d != cindex)
/*     */         {
/* 594 */           min2[d2] = min[d];
/* 595 */           max2[d2] = max[d];
/* 596 */           d2++;
/*     */         }
/*     */       
/*     */       } 
/*     */     } else {
/*     */       
/* 602 */       max2 = max;
/* 603 */       min2 = min;
/*     */     } 
/*     */     
/* 606 */     FinalInterval interval = new FinalInterval(min2, max2);
/* 607 */     return (Interval)interval;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final Interval getInterval(ImgPlus<?> img, Settings settings) {
/* 632 */     long[] intervalMin, intervalMax, max = new long[img.numDimensions()];
/* 633 */     long[] min = new long[img.numDimensions()];
/*     */ 
/*     */     
/* 636 */     int xindex = img.dimensionIndex(Axes.X);
/* 637 */     min[xindex] = settings.xstart;
/* 638 */     max[xindex] = settings.xend;
/*     */ 
/*     */     
/* 641 */     int yindex = img.dimensionIndex(Axes.Y);
/* 642 */     min[yindex] = settings.ystart;
/* 643 */     max[yindex] = settings.yend;
/*     */ 
/*     */     
/* 646 */     int zindex = img.dimensionIndex(Axes.Z);
/* 647 */     if (zindex >= 0) {
/*     */       
/* 649 */       min[zindex] = settings.zstart;
/* 650 */       max[zindex] = settings.zend;
/*     */     } 
/*     */ 
/*     */     
/* 654 */     int cindex = img.dimensionIndex(Axes.CHANNEL);
/* 655 */     if (cindex >= 0) {
/*     */       
/* 657 */       Integer c = (Integer)settings.detectorSettings.get("TARGET_CHANNEL");
/* 658 */       if (null == c) {
/* 659 */         c = Integer.valueOf(1);
/*     */       }
/* 661 */       min[cindex] = (c.intValue() - 1);
/* 662 */       max[cindex] = min[cindex];
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 667 */     int tindex = img.dimensionIndex(Axes.TIME);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 676 */     if (tindex >= 0) {
/*     */       
/* 678 */       intervalMin = new long[min.length - 1];
/* 679 */       intervalMax = new long[min.length - 1];
/* 680 */       int nindex = -1;
/* 681 */       for (int d = 0; d < min.length; d++) {
/*     */         
/* 683 */         if (d != tindex) {
/*     */ 
/*     */           
/* 686 */           nindex++;
/* 687 */           intervalMin[nindex] = Math.max(0L, min[d]);
/* 688 */           intervalMax[nindex] = Math.min(img.max(d), max[d]);
/*     */         } 
/*     */       } 
/*     */     } else {
/*     */       
/* 693 */       intervalMin = min;
/* 694 */       intervalMax = max;
/*     */     } 
/* 696 */     FinalInterval interval = new FinalInterval(intervalMin, intervalMax);
/* 697 */     return (Interval)interval;
/*     */   }
/*     */ 
/*     */   
/*     */   public static Context getContext() {
/* 702 */     return (Context)IJ.runPlugIn("org.scijava.Context", "");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static File proposeTrackMateSaveFile(Settings settings, Logger logger) {
/*     */     File folder;
/*     */     File file;
/* 719 */     if (null != settings.imp && null != settings.imp
/* 720 */       .getOriginalFileInfo() && null != 
/* 721 */       (settings.imp.getOriginalFileInfo()).directory) {
/*     */       
/* 723 */       String directory = (settings.imp.getOriginalFileInfo()).directory;
/* 724 */       folder = Paths.get(directory, new String[0]).toAbsolutePath().toFile();
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 729 */       settings.imageFolder = (settings.imp.getOriginalFileInfo()).directory;
/*     */     }
/*     */     else {
/*     */       
/* 733 */       folder = new File(System.getProperty("user.dir"));
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 738 */       logger.error("Warning: The source image does not match a file on the system.TrackMate won't be able to reload it when opening this XML file.\nTo fix this, save the source image to a TIF file before saving the TrackMate session.\n");
/*     */ 
/*     */       
/* 741 */       settings.imageFolder = "";
/*     */     } 
/*     */     
/*     */     try {
/* 745 */       file = new File(folder.getPath() + File.separator + settings.imp.getShortTitle() + ".xml");
/*     */     }
/* 747 */     catch (NullPointerException npe) {
/*     */       
/* 749 */       file = new File(folder.getPath() + File.separator + "TrackMateData.xml");
/*     */     } 
/* 751 */     return file;
/*     */   }
/*     */ 
/*     */   
/*     */   public static final double variance(double[] data) {
/* 756 */     double mean = Util.average(data);
/* 757 */     double variance = 0.0D;
/* 758 */     for (int i = 0; i < data.length; i++) {
/*     */       
/* 760 */       double dx = data[i] - mean;
/* 761 */       variance += dx * dx;
/*     */     } 
/* 763 */     variance /= (data.length - 1);
/* 764 */     return variance;
/*     */   }
/*     */ 
/*     */   
/*     */   public static final double standardDeviation(double[] data) {
/* 769 */     return Math.sqrt(variance(data));
/*     */   }
/*     */ 
/*     */   
/*     */   public static double sum(double[] intensities) {
/* 774 */     return Arrays.stream(intensities).sum();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/util/TMUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */