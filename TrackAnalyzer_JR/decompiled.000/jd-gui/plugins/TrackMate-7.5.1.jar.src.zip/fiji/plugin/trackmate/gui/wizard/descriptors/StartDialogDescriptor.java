/*     */ package fiji.plugin.trackmate.gui.wizard.descriptors;
/*     */ 
/*     */ import fiji.plugin.trackmate.Logger;
/*     */ import fiji.plugin.trackmate.Settings;
/*     */ import fiji.plugin.trackmate.TrackMate;
/*     */ import fiji.plugin.trackmate.gui.Fonts;
/*     */ import fiji.plugin.trackmate.gui.GuiUtils;
/*     */ import fiji.plugin.trackmate.gui.wizard.WizardPanelDescriptor;
/*     */ import fiji.plugin.trackmate.io.SettingsPersistence;
/*     */ import fiji.plugin.trackmate.util.TMUtils;
/*     */ import ij.ImagePlus;
/*     */ import ij.gui.Roi;
/*     */ import ij.measure.Calibration;
/*     */ import java.awt.Cursor;
/*     */ import java.awt.Desktop;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.GridBagConstraints;
/*     */ import java.awt.GridBagLayout;
/*     */ import java.awt.Insets;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.event.MouseAdapter;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.net.URI;
/*     */ import java.net.URISyntaxException;
/*     */ import java.text.DecimalFormat;
/*     */ import java.text.NumberFormat;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JFormattedTextField;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JPanel;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StartDialogDescriptor
/*     */   extends WizardPanelDescriptor
/*     */ {
/*     */   private static final String KEY = "Start";
/*     */   public static final String PUB1_URL = "https://doi.org/10.1101/2021.09.03.458852";
/*     */   public static final String PUB1_TXT = "Ershov D, Phan M-S, Pylvänäinen JW, Rigaud SU, et al. 'Bringing TrackMate in the era of machine-learning and deep-learning.'bioRxiv. 2021; doi:10.1101/2021.09.03.458852";
/*     */   private final Settings settings;
/*     */   private final Logger logger;
/*     */   
/*     */   public StartDialogDescriptor(Settings settings, Logger logger) {
/*  78 */     super("Start");
/*  79 */     this.settings = settings;
/*  80 */     this.logger = logger;
/*  81 */     this.targetPanel = new RoiSettingsPanel(settings.imp);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void aboutToDisplayPanel() {
/*  87 */     String welcomeMessage = "TrackMate v" + TrackMate.PLUGIN_NAME_VERSION + " started on:\n" + TMUtils.getCurrentTimeString() + '\n';
/*     */     
/*  89 */     this.logger.log(welcomeMessage, Logger.BLUE_COLOR);
/*  90 */     this.logger.log("Please note that TrackMate is available through Fiji, and is based on a publication. If you use it successfully for your research please be so kind to cite our work:\n");
/*     */     
/*  92 */     this.logger.log("Ershov D, Phan M-S, Pylvänäinen JW, Rigaud SU, et al. 'Bringing TrackMate in the era of machine-learning and deep-learning.'bioRxiv. 2021; doi:10.1101/2021.09.03.458852\n", Logger.GREEN_COLOR);
/*  93 */     this.logger.log("https://doi.org/10.1101/2021.09.03.458852\n", Logger.BLUE_COLOR);
/*  94 */     this.logger.log("and / or:\n");
/*  95 */     this.logger.log("Tinevez, JY.; Perry, N. & Schindelin, J. et al. (2017), 'TrackMate: An open and extensible platform for single-particle tracking.', Methods 115: 80-90, PMID 27713081.\n", Logger.GREEN_COLOR);
/*     */     
/*  97 */     this.logger.log("https://www.sciencedirect.com/science/article/pii/S1046202316303346\n", Logger.BLUE_COLOR);
/*     */     
/*  99 */     this.logger.log("\nNumerical feature analyzers:\n", Logger.BLUE_COLOR);
/* 100 */     this.logger.log(this.settings.toStringFeatureAnalyzersInfo());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void aboutToHidePanel() {
/* 107 */     RoiSettingsPanel panel = (RoiSettingsPanel)this.targetPanel;
/* 108 */     this.settings.xstart = ((Number)panel.tfXStart.getValue()).intValue();
/* 109 */     this.settings.xend = ((Number)panel.tfXEnd.getValue()).intValue();
/* 110 */     this.settings.ystart = ((Number)panel.tfYStart.getValue()).intValue();
/* 111 */     this.settings.yend = ((Number)panel.tfYEnd.getValue()).intValue();
/* 112 */     this.settings.zstart = ((Number)panel.tfZStart.getValue()).intValue();
/* 113 */     this.settings.zend = ((Number)panel.tfZEnd.getValue()).intValue();
/* 114 */     this.settings.tstart = ((Number)panel.tfTStart.getValue()).intValue();
/* 115 */     this.settings.tend = ((Number)panel.tfTEnd.getValue()).intValue();
/* 116 */     this.settings.roi = this.settings.imp.getRoi();
/*     */     
/* 118 */     this.logger.log("\nImage region of interest:\n", Logger.BLUE_COLOR);
/* 119 */     this.logger.log(this.settings.toStringImageInfo());
/*     */ 
/*     */     
/* 122 */     SettingsPersistence.saveLastUsedSettings(this.settings, this.logger);
/*     */   }
/*     */ 
/*     */   
/*     */   private static class RoiSettingsPanel
/*     */     extends JPanel
/*     */   {
/*     */     private static final long serialVersionUID = -1L;
/* 130 */     private static final NumberFormat DOUBLE_FORMAT = new DecimalFormat("#.###");
/*     */     
/*     */     private static final String TOOLTIP = "<html>Pressing this button will make the current <br>ImagePlus the source for TrackMate. If the <br>image has a ROI, it will be used to set the <br>crop rectangle as well.</html>";
/*     */     
/*     */     private final JFormattedTextField tfXStart;
/*     */     
/*     */     private final JFormattedTextField tfXEnd;
/*     */     
/*     */     private final JFormattedTextField tfYStart;
/*     */     
/*     */     private final JFormattedTextField tfYEnd;
/*     */     
/*     */     private final JFormattedTextField tfZStart;
/*     */     
/*     */     private final JFormattedTextField tfZEnd;
/*     */     private final JFormattedTextField tfTStart;
/*     */     private final JFormattedTextField tfTEnd;
/*     */     
/*     */     public RoiSettingsPanel(final ImagePlus imp) {
/* 149 */       setPreferredSize(new Dimension(291, 491));
/* 150 */       GridBagLayout gridBagLayout = new GridBagLayout();
/* 151 */       gridBagLayout.rowWeights = new double[] { 0.0D, 0.0D, 0.0D, 0.0D, 0.0D, 0.0D, 0.0D, 0.0D, 0.0D, 0.0D, 0.0D, 0.0D, 0.0D, 0.0D, 1.0D };
/* 152 */       gridBagLayout.columnWeights = new double[] { 1.0D, 1.0D, 1.0D, 1.0D };
/* 153 */       setLayout(gridBagLayout);
/*     */       
/* 155 */       JLabel lblCitation = new JLabel("<html>Please note that TrackMate is available through Fiji, and is based on a publication. If you use it successfully for your research please be so kind to cite our work:<p><b>Ershov D, Phan M-S, Pylvänäinen JW, Rigaud SU, et al. (2021), <i>Bringing TrackMate in the era of machine-learning and deep-learning.</i></b> bioRxiv; doi:10.1101/2021.09.03.458852.</html>");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 164 */       lblCitation.setFont(Fonts.SMALL_FONT);
/*     */       
/* 166 */       GridBagConstraints gbcLblCitation = new GridBagConstraints();
/* 167 */       gbcLblCitation.fill = 1;
/* 168 */       gbcLblCitation.insets = new Insets(5, 5, 5, 5);
/* 169 */       gbcLblCitation.gridwidth = 4;
/* 170 */       gbcLblCitation.gridx = 0;
/* 171 */       gbcLblCitation.gridy = 0;
/* 172 */       add(lblCitation, gbcLblCitation);
/*     */       
/* 174 */       JLabel lblLinkPubMed = new JLabel("<html><a href=https://doi.org/10.1101/2021.09.03.458852>on bioRxiv</a></html>");
/*     */       
/* 176 */       lblLinkPubMed.setFont(Fonts.SMALL_FONT);
/* 177 */       lblLinkPubMed.setCursor(new Cursor(12));
/* 178 */       lblLinkPubMed.addMouseListener(new MouseAdapter()
/*     */           {
/*     */ 
/*     */             
/*     */             public void mouseClicked(MouseEvent e)
/*     */             {
/*     */               try {
/* 185 */                 Desktop.getDesktop().browse(new URI("https://doi.org/10.1101/2021.09.03.458852"));
/*     */               }
/* 187 */               catch (URISyntaxException|java.io.IOException ex) {
/*     */                 
/* 189 */                 ex.printStackTrace();
/*     */               } 
/*     */             }
/*     */           });
/* 193 */       GridBagConstraints gbcLblLinkPubMed = new GridBagConstraints();
/* 194 */       gbcLblLinkPubMed.anchor = 11;
/* 195 */       gbcLblLinkPubMed.fill = 2;
/* 196 */       gbcLblLinkPubMed.gridwidth = 4;
/* 197 */       gbcLblLinkPubMed.insets = new Insets(0, 10, 5, 5);
/* 198 */       gbcLblLinkPubMed.gridx = 0;
/* 199 */       gbcLblLinkPubMed.gridy = 1;
/* 200 */       add(lblLinkPubMed, gbcLblLinkPubMed);
/*     */       
/* 202 */       JLabel lblImageName = new JLabel("Target image: " + imp.getShortTitle());
/* 203 */       lblImageName.setFont(Fonts.BIG_FONT);
/* 204 */       GridBagConstraints gbcLabelImageName = new GridBagConstraints();
/* 205 */       gbcLabelImageName.anchor = 15;
/* 206 */       gbcLabelImageName.fill = 2;
/* 207 */       gbcLabelImageName.insets = new Insets(5, 5, 5, 5);
/* 208 */       gbcLabelImageName.gridwidth = 4;
/* 209 */       gbcLabelImageName.gridx = 0;
/* 210 */       gbcLabelImageName.gridy = 3;
/* 211 */       add(lblImageName, gbcLabelImageName);
/*     */       
/* 213 */       JLabel lblCalibrationSettings = new JLabel("Calibration settings:");
/* 214 */       lblCalibrationSettings.setFont(Fonts.SMALL_FONT);
/* 215 */       GridBagConstraints gbcLabelCalibration = new GridBagConstraints();
/* 216 */       gbcLabelCalibration.anchor = 15;
/* 217 */       gbcLabelCalibration.fill = 2;
/* 218 */       gbcLabelCalibration.insets = new Insets(5, 5, 5, 5);
/* 219 */       gbcLabelCalibration.gridwidth = 4;
/* 220 */       gbcLabelCalibration.gridx = 0;
/* 221 */       gbcLabelCalibration.gridy = 4;
/* 222 */       add(lblCalibrationSettings, gbcLabelCalibration);
/*     */       
/* 224 */       JLabel lblPixelWidth = new JLabel("Pixel width:");
/* 225 */       lblPixelWidth.setFont(Fonts.SMALL_FONT);
/* 226 */       GridBagConstraints gbcLabelPixelWidth = new GridBagConstraints();
/* 227 */       gbcLabelPixelWidth.anchor = 13;
/* 228 */       gbcLabelPixelWidth.insets = new Insets(5, 5, 5, 5);
/* 229 */       gbcLabelPixelWidth.gridwidth = 2;
/* 230 */       gbcLabelPixelWidth.gridx = 0;
/* 231 */       gbcLabelPixelWidth.gridy = 5;
/* 232 */       add(lblPixelWidth, gbcLabelPixelWidth);
/*     */       
/* 234 */       JLabel lblPixelWidthVal = new JLabel();
/* 235 */       lblPixelWidthVal.setHorizontalAlignment(0);
/* 236 */       lblPixelWidthVal.setFont(Fonts.SMALL_FONT);
/* 237 */       GridBagConstraints gbcTextFieldPixelWidth = new GridBagConstraints();
/* 238 */       gbcTextFieldPixelWidth.fill = 2;
/* 239 */       gbcTextFieldPixelWidth.anchor = 11;
/* 240 */       gbcTextFieldPixelWidth.insets = new Insets(5, 5, 5, 5);
/* 241 */       gbcTextFieldPixelWidth.gridx = 2;
/* 242 */       gbcTextFieldPixelWidth.gridy = 5;
/* 243 */       add(lblPixelWidthVal, gbcTextFieldPixelWidth);
/*     */       
/* 245 */       JLabel lblSpatialUnits1 = new JLabel();
/* 246 */       lblSpatialUnits1.setFont(Fonts.SMALL_FONT);
/* 247 */       GridBagConstraints gbcLabelSpatialUnits = new GridBagConstraints();
/* 248 */       gbcLabelSpatialUnits.anchor = 17;
/* 249 */       gbcLabelSpatialUnits.insets = new Insets(5, 5, 5, 5);
/* 250 */       gbcLabelSpatialUnits.gridx = 3;
/* 251 */       gbcLabelSpatialUnits.gridy = 5;
/* 252 */       add(lblSpatialUnits1, gbcLabelSpatialUnits);
/*     */       
/* 254 */       JLabel lblPixelHeight = new JLabel("Pixel height:");
/* 255 */       lblPixelHeight.setFont(Fonts.SMALL_FONT);
/* 256 */       GridBagConstraints gbcLabelPixelHeight = new GridBagConstraints();
/* 257 */       gbcLabelPixelHeight.anchor = 13;
/* 258 */       gbcLabelPixelHeight.insets = new Insets(5, 5, 5, 5);
/* 259 */       gbcLabelPixelHeight.gridwidth = 2;
/* 260 */       gbcLabelPixelHeight.gridx = 0;
/* 261 */       gbcLabelPixelHeight.gridy = 6;
/* 262 */       add(lblPixelHeight, gbcLabelPixelHeight);
/*     */       
/* 264 */       JLabel lblPixelHeightVal = new JLabel();
/* 265 */       lblPixelHeightVal.setHorizontalAlignment(0);
/* 266 */       lblPixelHeightVal.setFont(Fonts.SMALL_FONT);
/* 267 */       GridBagConstraints gbcLblPixelHeight = new GridBagConstraints();
/* 268 */       gbcLblPixelHeight.anchor = 11;
/* 269 */       gbcLblPixelHeight.fill = 2;
/* 270 */       gbcLblPixelHeight.insets = new Insets(5, 5, 5, 5);
/* 271 */       gbcLblPixelHeight.gridx = 2;
/* 272 */       gbcLblPixelHeight.gridy = 6;
/* 273 */       add(lblPixelHeightVal, gbcLblPixelHeight);
/*     */       
/* 275 */       JLabel lblTimeInterval = new JLabel("Time interval:");
/* 276 */       lblTimeInterval.setFont(Fonts.SMALL_FONT);
/* 277 */       GridBagConstraints gbcLabelTimeInterval = new GridBagConstraints();
/* 278 */       gbcLabelTimeInterval.anchor = 13;
/* 279 */       gbcLabelTimeInterval.insets = new Insets(5, 5, 5, 5);
/* 280 */       gbcLabelTimeInterval.gridwidth = 2;
/* 281 */       gbcLabelTimeInterval.gridx = 0;
/* 282 */       gbcLabelTimeInterval.gridy = 8;
/* 283 */       add(lblTimeInterval, gbcLabelTimeInterval);
/*     */       
/* 285 */       JLabel lblSpatialUnits2 = new JLabel();
/* 286 */       lblSpatialUnits2.setFont(Fonts.SMALL_FONT);
/* 287 */       GridBagConstraints gbcLabelTimeUnits = new GridBagConstraints();
/* 288 */       gbcLabelTimeUnits.anchor = 17;
/* 289 */       gbcLabelTimeUnits.insets = new Insets(5, 5, 5, 5);
/* 290 */       gbcLabelTimeUnits.gridx = 3;
/* 291 */       gbcLabelTimeUnits.gridy = 6;
/* 292 */       add(lblSpatialUnits2, gbcLabelTimeUnits);
/*     */       
/* 294 */       JLabel lblVoxelDepthVal = new JLabel();
/* 295 */       lblVoxelDepthVal.setHorizontalAlignment(0);
/* 296 */       lblVoxelDepthVal.setFont(Fonts.SMALL_FONT);
/* 297 */       GridBagConstraints gbcLblVoxelDepth = new GridBagConstraints();
/* 298 */       gbcLblVoxelDepth.anchor = 11;
/* 299 */       gbcLblVoxelDepth.fill = 2;
/* 300 */       gbcLblVoxelDepth.insets = new Insets(5, 5, 5, 5);
/* 301 */       gbcLblVoxelDepth.gridx = 2;
/* 302 */       gbcLblVoxelDepth.gridy = 7;
/* 303 */       add(lblVoxelDepthVal, gbcLblVoxelDepth);
/*     */       
/* 305 */       JLabel lblVoxelDepth = new JLabel("Voxel depth:");
/* 306 */       lblVoxelDepth.setFont(Fonts.SMALL_FONT);
/* 307 */       GridBagConstraints gbcLabelVoxelDepth = new GridBagConstraints();
/* 308 */       gbcLabelVoxelDepth.anchor = 13;
/* 309 */       gbcLabelVoxelDepth.insets = new Insets(5, 5, 5, 5);
/* 310 */       gbcLabelVoxelDepth.gridwidth = 2;
/* 311 */       gbcLabelVoxelDepth.gridx = 0;
/* 312 */       gbcLabelVoxelDepth.gridy = 7;
/* 313 */       add(lblVoxelDepth, gbcLabelVoxelDepth);
/*     */       
/* 315 */       JLabel lblSpatialUnits3 = new JLabel();
/* 316 */       lblSpatialUnits3.setFont(Fonts.SMALL_FONT);
/* 317 */       GridBagConstraints gbcLabelUnits3 = new GridBagConstraints();
/* 318 */       gbcLabelUnits3.anchor = 17;
/* 319 */       gbcLabelUnits3.insets = new Insets(5, 5, 5, 5);
/* 320 */       gbcLabelUnits3.gridx = 3;
/* 321 */       gbcLabelUnits3.gridy = 7;
/* 322 */       add(lblSpatialUnits3, gbcLabelUnits3);
/*     */       
/* 324 */       JLabel lblTimeUnits = new JLabel();
/* 325 */       lblTimeUnits.setFont(Fonts.SMALL_FONT);
/* 326 */       GridBagConstraints gbcLabelUnits4 = new GridBagConstraints();
/* 327 */       gbcLabelUnits4.anchor = 17;
/* 328 */       gbcLabelUnits4.insets = new Insets(5, 5, 5, 5);
/* 329 */       gbcLabelUnits4.gridx = 3;
/* 330 */       gbcLabelUnits4.gridy = 8;
/* 331 */       add(lblTimeUnits, gbcLabelUnits4);
/*     */       
/* 333 */       JLabel lblTimeIntervalVal = new JLabel();
/* 334 */       lblTimeIntervalVal.setHorizontalAlignment(0);
/* 335 */       lblTimeIntervalVal.setFont(Fonts.SMALL_FONT);
/* 336 */       GridBagConstraints gbcTextFieldTimeInterval = new GridBagConstraints();
/* 337 */       gbcTextFieldTimeInterval.anchor = 11;
/* 338 */       gbcTextFieldTimeInterval.fill = 2;
/* 339 */       gbcTextFieldTimeInterval.insets = new Insets(5, 5, 5, 5);
/* 340 */       gbcTextFieldTimeInterval.gridx = 2;
/* 341 */       gbcTextFieldTimeInterval.gridy = 8;
/* 342 */       add(lblTimeIntervalVal, gbcTextFieldTimeInterval);
/*     */       
/* 344 */       JLabel lblCropSetting = new JLabel("Crop settings (in pixels, 0-based):");
/* 345 */       lblCropSetting.setFont(Fonts.SMALL_FONT);
/* 346 */       GridBagConstraints gbcLabelCropSetting = new GridBagConstraints();
/* 347 */       gbcLabelCropSetting.anchor = 15;
/* 348 */       gbcLabelCropSetting.fill = 2;
/* 349 */       gbcLabelCropSetting.insets = new Insets(5, 5, 5, 5);
/* 350 */       gbcLabelCropSetting.gridwidth = 4;
/* 351 */       gbcLabelCropSetting.gridx = 0;
/* 352 */       gbcLabelCropSetting.gridy = 9;
/* 353 */       add(lblCropSetting, gbcLabelCropSetting);
/*     */       
/* 355 */       this.tfXStart = new JFormattedTextField(Integer.valueOf(0));
/* 356 */       GuiUtils.selectAllOnFocus(this.tfXStart);
/* 357 */       this.tfXStart.setHorizontalAlignment(0);
/* 358 */       this.tfXStart.setPreferredSize(Fonts.TEXTFIELD_DIMENSION);
/* 359 */       this.tfXStart.setFont(Fonts.SMALL_FONT);
/* 360 */       GridBagConstraints gbcTextFieldXStart = new GridBagConstraints();
/* 361 */       gbcTextFieldXStart.fill = 2;
/* 362 */       gbcTextFieldXStart.anchor = 11;
/* 363 */       gbcTextFieldXStart.insets = new Insets(5, 5, 5, 5);
/* 364 */       gbcTextFieldXStart.gridx = 1;
/* 365 */       gbcTextFieldXStart.gridy = 10;
/* 366 */       add(this.tfXStart, gbcTextFieldXStart);
/*     */       
/* 368 */       this.tfXEnd = new JFormattedTextField(Integer.valueOf(0));
/* 369 */       GuiUtils.selectAllOnFocus(this.tfXEnd);
/* 370 */       this.tfXEnd.setHorizontalAlignment(0);
/* 371 */       this.tfXEnd.setPreferredSize(Fonts.TEXTFIELD_DIMENSION);
/* 372 */       this.tfXEnd.setFont(Fonts.SMALL_FONT);
/* 373 */       GridBagConstraints gbcTextFieldXEnd = new GridBagConstraints();
/* 374 */       gbcTextFieldXEnd.fill = 2;
/* 375 */       gbcTextFieldXEnd.anchor = 11;
/* 376 */       gbcTextFieldXEnd.insets = new Insets(5, 5, 5, 5);
/* 377 */       gbcTextFieldXEnd.gridx = 3;
/* 378 */       gbcTextFieldXEnd.gridy = 10;
/* 379 */       add(this.tfXEnd, gbcTextFieldXEnd);
/*     */       
/* 381 */       JLabel jLabelX = new JLabel("X");
/* 382 */       jLabelX.setFont(Fonts.SMALL_FONT);
/* 383 */       GridBagConstraints gbcLabelX = new GridBagConstraints();
/* 384 */       gbcLabelX.anchor = 13;
/* 385 */       gbcLabelX.insets = new Insets(5, 5, 5, 5);
/* 386 */       gbcLabelX.gridx = 0;
/* 387 */       gbcLabelX.gridy = 10;
/* 388 */       add(jLabelX, gbcLabelX);
/*     */       
/* 390 */       JLabel jLabelTo1 = new JLabel("to");
/* 391 */       jLabelTo1.setFont(Fonts.SMALL_FONT);
/* 392 */       GridBagConstraints gbcLabelTo1 = new GridBagConstraints();
/* 393 */       gbcLabelTo1.insets = new Insets(5, 5, 5, 5);
/* 394 */       gbcLabelTo1.gridx = 2;
/* 395 */       gbcLabelTo1.gridy = 10;
/* 396 */       add(jLabelTo1, gbcLabelTo1);
/*     */       
/* 398 */       JLabel jLabelY = new JLabel("Y");
/* 399 */       jLabelY.setFont(Fonts.SMALL_FONT);
/* 400 */       GridBagConstraints gbcLabelY = new GridBagConstraints();
/* 401 */       gbcLabelY.anchor = 13;
/* 402 */       gbcLabelY.insets = new Insets(5, 5, 5, 5);
/* 403 */       gbcLabelY.gridx = 0;
/* 404 */       gbcLabelY.gridy = 11;
/* 405 */       add(jLabelY, gbcLabelY);
/*     */       
/* 407 */       JLabel jLabelTo3 = new JLabel("to");
/* 408 */       jLabelTo3.setFont(Fonts.SMALL_FONT);
/* 409 */       GridBagConstraints gbcLabelTo3 = new GridBagConstraints();
/* 410 */       gbcLabelTo3.insets = new Insets(5, 5, 5, 5);
/* 411 */       gbcLabelTo3.gridx = 2;
/* 412 */       gbcLabelTo3.gridy = 12;
/* 413 */       add(jLabelTo3, gbcLabelTo3);
/*     */       
/* 415 */       this.tfYStart = new JFormattedTextField(Integer.valueOf(0));
/* 416 */       GuiUtils.selectAllOnFocus(this.tfYStart);
/* 417 */       this.tfYStart.setHorizontalAlignment(0);
/* 418 */       this.tfYStart.setPreferredSize(Fonts.TEXTFIELD_DIMENSION);
/* 419 */       this.tfYStart.setFont(Fonts.SMALL_FONT);
/* 420 */       GridBagConstraints gbcTextFieldYStart = new GridBagConstraints();
/* 421 */       gbcTextFieldYStart.fill = 2;
/* 422 */       gbcTextFieldYStart.anchor = 11;
/* 423 */       gbcTextFieldYStart.insets = new Insets(5, 5, 5, 5);
/* 424 */       gbcTextFieldYStart.gridx = 1;
/* 425 */       gbcTextFieldYStart.gridy = 11;
/* 426 */       add(this.tfYStart, gbcTextFieldYStart);
/*     */       
/* 428 */       JLabel jLabelTo2 = new JLabel("to");
/* 429 */       jLabelTo2.setFont(Fonts.SMALL_FONT);
/* 430 */       GridBagConstraints gbcLabelTo2 = new GridBagConstraints();
/* 431 */       gbcLabelTo2.insets = new Insets(5, 5, 5, 5);
/* 432 */       gbcLabelTo2.gridx = 2;
/* 433 */       gbcLabelTo2.gridy = 11;
/* 434 */       add(jLabelTo2, gbcLabelTo2);
/*     */       
/* 436 */       JLabel jLabelZ = new JLabel("Z");
/* 437 */       jLabelZ.setFont(Fonts.SMALL_FONT);
/* 438 */       GridBagConstraints gbcLabelZ = new GridBagConstraints();
/* 439 */       gbcLabelZ.anchor = 13;
/* 440 */       gbcLabelZ.insets = new Insets(5, 5, 5, 5);
/* 441 */       gbcLabelZ.gridx = 0;
/* 442 */       gbcLabelZ.gridy = 12;
/* 443 */       add(jLabelZ, gbcLabelZ);
/*     */       
/* 445 */       this.tfYEnd = new JFormattedTextField(Integer.valueOf(0));
/* 446 */       GuiUtils.selectAllOnFocus(this.tfYEnd);
/* 447 */       this.tfYEnd.setHorizontalAlignment(0);
/* 448 */       this.tfYEnd.setPreferredSize(Fonts.TEXTFIELD_DIMENSION);
/* 449 */       this.tfYEnd.setFont(Fonts.SMALL_FONT);
/* 450 */       GridBagConstraints gbcTextFieldYEnd = new GridBagConstraints();
/* 451 */       gbcTextFieldYEnd.fill = 2;
/* 452 */       gbcTextFieldYEnd.anchor = 11;
/* 453 */       gbcTextFieldYEnd.insets = new Insets(5, 5, 5, 5);
/* 454 */       gbcTextFieldYEnd.gridx = 3;
/* 455 */       gbcTextFieldYEnd.gridy = 11;
/* 456 */       add(this.tfYEnd, gbcTextFieldYEnd);
/*     */       
/* 458 */       this.tfZStart = new JFormattedTextField(Integer.valueOf(0));
/* 459 */       GuiUtils.selectAllOnFocus(this.tfZStart);
/* 460 */       this.tfZStart.setHorizontalAlignment(0);
/* 461 */       this.tfZStart.setPreferredSize(Fonts.TEXTFIELD_DIMENSION);
/* 462 */       this.tfZStart.setFont(Fonts.SMALL_FONT);
/* 463 */       GridBagConstraints gbcTextFieldZStart = new GridBagConstraints();
/* 464 */       gbcTextFieldZStart.fill = 2;
/* 465 */       gbcTextFieldZStart.anchor = 11;
/* 466 */       gbcTextFieldZStart.insets = new Insets(5, 5, 5, 5);
/* 467 */       gbcTextFieldZStart.gridx = 1;
/* 468 */       gbcTextFieldZStart.gridy = 12;
/* 469 */       add(this.tfZStart, gbcTextFieldZStart);
/*     */       
/* 471 */       this.tfZEnd = new JFormattedTextField(Integer.valueOf(0));
/* 472 */       GuiUtils.selectAllOnFocus(this.tfZEnd);
/* 473 */       this.tfZEnd.setHorizontalAlignment(0);
/* 474 */       this.tfZEnd.setPreferredSize(Fonts.TEXTFIELD_DIMENSION);
/* 475 */       this.tfZEnd.setFont(Fonts.SMALL_FONT);
/* 476 */       GridBagConstraints gbcTextFieldZEnd = new GridBagConstraints();
/* 477 */       gbcTextFieldZEnd.fill = 2;
/* 478 */       gbcTextFieldZEnd.anchor = 11;
/* 479 */       gbcTextFieldZEnd.insets = new Insets(5, 5, 5, 5);
/* 480 */       gbcTextFieldZEnd.gridx = 3;
/* 481 */       gbcTextFieldZEnd.gridy = 12;
/* 482 */       add(this.tfZEnd, gbcTextFieldZEnd);
/*     */       
/* 484 */       this.tfTStart = new JFormattedTextField(Integer.valueOf(0));
/* 485 */       GuiUtils.selectAllOnFocus(this.tfTStart);
/* 486 */       this.tfTStart.setHorizontalAlignment(0);
/* 487 */       this.tfTStart.setPreferredSize(Fonts.TEXTFIELD_DIMENSION);
/* 488 */       this.tfTStart.setFont(Fonts.SMALL_FONT);
/* 489 */       GridBagConstraints gbcTextFieldTStart = new GridBagConstraints();
/* 490 */       gbcTextFieldTStart.fill = 2;
/* 491 */       gbcTextFieldTStart.anchor = 11;
/* 492 */       gbcTextFieldTStart.insets = new Insets(5, 5, 5, 5);
/* 493 */       gbcTextFieldTStart.gridx = 1;
/* 494 */       gbcTextFieldTStart.gridy = 13;
/* 495 */       add(this.tfTStart, gbcTextFieldTStart);
/*     */       
/* 497 */       JLabel jLabelT = new JLabel("T");
/* 498 */       jLabelT.setFont(Fonts.SMALL_FONT);
/* 499 */       GridBagConstraints gbcLabelT = new GridBagConstraints();
/* 500 */       gbcLabelT.anchor = 13;
/* 501 */       gbcLabelT.insets = new Insets(5, 5, 5, 5);
/* 502 */       gbcLabelT.gridx = 0;
/* 503 */       gbcLabelT.gridy = 13;
/* 504 */       add(jLabelT, gbcLabelT);
/*     */       
/* 506 */       this.tfTEnd = new JFormattedTextField(Integer.valueOf(0));
/* 507 */       GuiUtils.selectAllOnFocus(this.tfTEnd);
/* 508 */       this.tfTEnd.setHorizontalAlignment(0);
/* 509 */       this.tfTEnd.setPreferredSize(Fonts.TEXTFIELD_DIMENSION);
/* 510 */       this.tfTEnd.setFont(Fonts.SMALL_FONT);
/* 511 */       GridBagConstraints gbcTextFieldTEnd = new GridBagConstraints();
/* 512 */       gbcTextFieldTEnd.fill = 2;
/* 513 */       gbcTextFieldTEnd.anchor = 11;
/* 514 */       gbcTextFieldTEnd.insets = new Insets(5, 5, 5, 5);
/* 515 */       gbcTextFieldTEnd.gridx = 3;
/* 516 */       gbcTextFieldTEnd.gridy = 13;
/* 517 */       add(this.tfTEnd, gbcTextFieldTEnd);
/*     */       
/* 519 */       JLabel jLabelTo4 = new JLabel("to");
/* 520 */       jLabelTo4.setFont(Fonts.SMALL_FONT);
/* 521 */       GridBagConstraints gbcLabelTo4 = new GridBagConstraints();
/* 522 */       gbcLabelTo4.insets = new Insets(5, 5, 5, 5);
/* 523 */       gbcLabelTo4.gridx = 2;
/* 524 */       gbcLabelTo4.gridy = 13;
/* 525 */       add(jLabelTo4, gbcLabelTo4);
/*     */       
/* 527 */       JButton btnRefreshROI = new JButton("Refresh ROI");
/* 528 */       btnRefreshROI.setToolTipText("<html>Pressing this button will make the current <br>ImagePlus the source for TrackMate. If the <br>image has a ROI, it will be used to set the <br>crop rectangle as well.</html>");
/* 529 */       btnRefreshROI.setFont(Fonts.SMALL_FONT);
/* 530 */       GridBagConstraints gbcButtonRefresh = new GridBagConstraints();
/* 531 */       gbcButtonRefresh.anchor = 18;
/* 532 */       gbcButtonRefresh.insets = new Insets(5, 5, 5, 5);
/* 533 */       gbcButtonRefresh.gridwidth = 4;
/* 534 */       gbcButtonRefresh.gridx = 0;
/* 535 */       gbcButtonRefresh.gridy = 14;
/* 536 */       add(btnRefreshROI, gbcButtonRefresh);
/* 537 */       btnRefreshROI.addActionListener(new ActionListener()
/*     */           {
/*     */             
/*     */             public void actionPerformed(ActionEvent e)
/*     */             {
/* 542 */               Roi roi = imp.getRoi();
/* 543 */               if (null == roi) {
/* 544 */                 roi = new Roi(0, 0, imp.getWidth(), imp.getHeight());
/*     */               }
/* 546 */               Rectangle boundingRect = roi.getBounds();
/* 547 */               StartDialogDescriptor.RoiSettingsPanel.this.tfXStart.setValue(Integer.valueOf(boundingRect.x));
/* 548 */               StartDialogDescriptor.RoiSettingsPanel.this.tfYStart.setValue(Integer.valueOf(boundingRect.y));
/* 549 */               StartDialogDescriptor.RoiSettingsPanel.this.tfXEnd.setValue(Integer.valueOf(boundingRect.width + boundingRect.x - 1));
/* 550 */               StartDialogDescriptor.RoiSettingsPanel.this.tfYEnd.setValue(Integer.valueOf(boundingRect.height + boundingRect.y - 1));
/* 551 */               StartDialogDescriptor.RoiSettingsPanel.this.tfZStart.setValue(Integer.valueOf(0));
/* 552 */               StartDialogDescriptor.RoiSettingsPanel.this.tfZEnd.setValue(Integer.valueOf(imp.getNSlices() - 1));
/* 553 */               StartDialogDescriptor.RoiSettingsPanel.this.tfTStart.setValue(Integer.valueOf(0));
/* 554 */               StartDialogDescriptor.RoiSettingsPanel.this.tfTEnd.setValue(Integer.valueOf(imp.getNFrames() - 1));
/*     */             }
/*     */           });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 562 */       Calibration cal = imp.getCalibration();
/* 563 */       lblPixelWidthVal.setText(DOUBLE_FORMAT.format(cal.pixelWidth));
/* 564 */       lblPixelHeightVal.setText(DOUBLE_FORMAT.format(cal.pixelHeight));
/* 565 */       lblVoxelDepthVal.setText(DOUBLE_FORMAT.format(cal.pixelDepth));
/*     */       
/* 567 */       if (cal.frameInterval == 0.0D) {
/*     */         
/* 569 */         cal.frameInterval = 1.0D;
/* 570 */         cal.setTimeUnit("frame");
/* 571 */         lblTimeIntervalVal.setText(DOUBLE_FORMAT.format(1.0D));
/* 572 */         lblTimeUnits.setText("frame");
/*     */       }
/*     */       else {
/*     */         
/* 576 */         lblTimeIntervalVal.setText(DOUBLE_FORMAT.format(cal.frameInterval));
/* 577 */         lblTimeUnits.setText(cal.getTimeUnit());
/*     */       } 
/* 579 */       lblSpatialUnits1.setText(cal.getXUnit());
/* 580 */       lblSpatialUnits2.setText(cal.getYUnit());
/* 581 */       lblSpatialUnits3.setText(cal.getZUnit());
/* 582 */       btnRefreshROI.doClick();
/*     */     }
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/gui/wizard/descriptors/StartDialogDescriptor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */