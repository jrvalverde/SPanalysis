/*     */ package fiji.plugin.trackmate.action.fit;
/*     */ 
/*     */ import fiji.plugin.trackmate.Logger;
/*     */ import fiji.plugin.trackmate.ModelChangeEvent;
/*     */ import fiji.plugin.trackmate.ModelChangeListener;
/*     */ import fiji.plugin.trackmate.SelectionModel;
/*     */ import fiji.plugin.trackmate.Settings;
/*     */ import fiji.plugin.trackmate.Spot;
/*     */ import fiji.plugin.trackmate.TrackMate;
/*     */ import fiji.plugin.trackmate.detection.DetectionUtils;
/*     */ import fiji.plugin.trackmate.gui.GuiUtils;
/*     */ import fiji.plugin.trackmate.gui.Icons;
/*     */ import fiji.plugin.trackmate.util.EverythingDisablerAndReenabler;
/*     */ import ij.ImagePlus;
/*     */ import java.awt.Component;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.swing.JFrame;
/*     */ import javax.swing.JLabel;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SpotFitterController
/*     */ {
/*     */   private final TrackMate trackmate;
/*     */   private final SelectionModel selectionModel;
/*     */   private final SpotFitterPanel gui;
/*     */   private final Logger logger;
/*     */   private final Map<Spot, double[]> undo;
/*     */   
/*     */   public SpotFitterController(TrackMate trackmate, SelectionModel selectionModel, Logger logger) {
/*  59 */     this.trackmate = trackmate;
/*  60 */     this.selectionModel = selectionModel;
/*  61 */     this.logger = logger;
/*  62 */     this.undo = (Map)new HashMap<>();
/*     */     
/*  64 */     Settings settings = trackmate.getSettings();
/*  65 */     List<String> fits = getAvailableFits(DetectionUtils.is2D(settings.imp));
/*  66 */     List<String> docs = getDocs(DetectionUtils.is2D(settings.imp));
/*  67 */     this.gui = new SpotFitterPanel(fits, docs, settings.imp.getNChannels());
/*     */     
/*  69 */     this.gui.btnFit.addActionListener(e -> fit());
/*  70 */     this.gui.btnUndo.addActionListener(e -> undo());
/*     */   }
/*     */ 
/*     */   
/*     */   private void undo() {
/*  75 */     final EverythingDisablerAndReenabler disabler = new EverythingDisablerAndReenabler(this.gui, new Class[] { JLabel.class });
/*  76 */     disabler.disable();
/*  77 */     (new Thread("SpotFitterControllerUndoThread")
/*     */       {
/*     */ 
/*     */         
/*     */         public void run()
/*     */         {
/*     */           try {
/*  84 */             SpotFitterController.this.logger.log("Undoing last fit.\n");
/*  85 */             SpotFitterController.this.logger.setStatus("Undoing");
/*     */             
/*  87 */             int progress = 0;
/*  88 */             for (Spot spot : SpotFitterController.this.undo.keySet()) {
/*     */               
/*  90 */               double[] arr = (double[])SpotFitterController.this.undo.get(spot);
/*  91 */               spot.putFeature("POSITION_X", Double.valueOf(arr[0]));
/*  92 */               spot.putFeature("POSITION_Y", Double.valueOf(arr[1]));
/*  93 */               spot.putFeature("POSITION_Z", Double.valueOf(arr[2]));
/*  94 */               spot.putFeature("RADIUS", Double.valueOf(arr[3]));
/*  95 */               SpotFitterController.this.logger.setProgress(progress++ / SpotFitterController.this.undo.size());
/*     */             } 
/*  97 */             SpotFitterController.this.logger.setProgress(0.0D);
/*     */             
/*  99 */             SpotFitterController.this.trackmate.computeSpotFeatures(true);
/* 100 */             SpotFitterController.this.trackmate.computeEdgeFeatures(true);
/* 101 */             SpotFitterController.this.trackmate.computeTrackFeatures(true);
/* 102 */             SpotFitterController.this.logger.log("Undoing done.\n");
/*     */ 
/*     */             
/* 105 */             SpotFitterController.this.trackmate.getModel().getModelChangeListener().forEach(l -> l.modelChanged(new ModelChangeEvent(this, 8)));
/*     */           }
/*     */           finally {
/*     */             
/* 109 */             disabler.reenable();
/*     */           } 
/*     */         }
/* 112 */       }).start();
/*     */   }
/*     */ 
/*     */   
/*     */   private void fit() {
/* 117 */     final EverythingDisablerAndReenabler disabler = new EverythingDisablerAndReenabler(this.gui, new Class[] { JLabel.class });
/* 118 */     disabler.disable();
/* 119 */     (new Thread("SpotFitterControllerFitterThread")
/*     */       {
/*     */         public void run()
/*     */         {
/*     */           try {
/*     */             SpotFitter fitter;
/*     */             Iterable<Spot> spots;
/* 126 */             ImagePlus imp = (SpotFitterController.this.trackmate.getSettings()).imp;
/*     */             
/* 128 */             int channel = SpotFitterController.this.gui.getSelectedChannel();
/* 129 */             int index = SpotFitterController.this.gui.getSelectedFitIndex();
/*     */ 
/*     */             
/* 132 */             if (DetectionUtils.is2D(imp)) {
/*     */               
/* 134 */               if (index == 0) {
/* 135 */                 fitter = new SpotGaussianFitter2D(imp, channel);
/* 136 */               } else if (index == 1) {
/* 137 */                 fitter = new SpotGaussianFitter2DFixedRadius(imp, channel);
/*     */               } else {
/* 139 */                 throw new IllegalArgumentException("Index points to an unknown fit model: " + index);
/*     */               }
/*     */             
/*     */             }
/* 143 */             else if (index == 0) {
/* 144 */               fitter = new SpotGaussianFitter3D(imp, channel);
/* 145 */             } else if (index == 1) {
/* 146 */               fitter = new SpotGaussianFitter3DFixedRadius(imp, channel);
/*     */             } else {
/* 148 */               throw new IllegalArgumentException("Index points to an unknown fit model: " + index);
/*     */             } 
/* 150 */             fitter.setNumThreads(SpotFitterController.this.trackmate.getNumThreads());
/*     */ 
/*     */ 
/*     */             
/* 154 */             if (SpotFitterController.this.gui.rdbtnAll.isSelected()) {
/* 155 */               spots = SpotFitterController.this.trackmate.getModel().getSpots().iterable(true);
/* 156 */             } else if (SpotFitterController.this.gui.rdbtnSelection.isSelected()) {
/* 157 */               spots = SpotFitterController.this.selectionModel.getSpotSelection();
/*     */             } else {
/*     */               
/* 160 */               SpotFitterController.this.selectionModel.selectTrack(SpotFitterController.this
/* 161 */                   .selectionModel.getSpotSelection(), SpotFitterController.this
/* 162 */                   .selectionModel.getEdgeSelection(), 0);
/* 163 */               spots = SpotFitterController.this.selectionModel.getSpotSelection();
/*     */             } 
/*     */ 
/*     */             
/* 167 */             SpotFitterController.this.undo.clear();
/* 168 */             for (Spot spot : spots) {
/*     */               
/* 170 */               SpotFitterController.this.undo.put(spot, new double[] { spot
/* 171 */                     .getDoublePosition(0), spot
/* 172 */                     .getDoublePosition(1), spot
/* 173 */                     .getDoublePosition(2), spot
/* 174 */                     .getFeature("RADIUS").doubleValue() });
/*     */             } 
/*     */ 
/*     */ 
/*     */             
/* 179 */             fitter.process(spots, SpotFitterController.this.logger);
/*     */ 
/*     */             
/* 182 */             SpotFitterController.this.trackmate.computeSpotFeatures(true);
/* 183 */             SpotFitterController.this.trackmate.computeEdgeFeatures(true);
/* 184 */             SpotFitterController.this.trackmate.computeTrackFeatures(true);
/*     */ 
/*     */             
/* 187 */             SpotFitterController.this.trackmate.getModel().getModelChangeListener().forEach(l -> l.modelChanged(new ModelChangeEvent(this, 8)));
/*     */           }
/*     */           finally {
/*     */             
/* 191 */             disabler.reenable();
/*     */           } 
/*     */         }
/* 194 */       }).start();
/*     */   }
/*     */ 
/*     */   
/*     */   public void show() {
/* 199 */     if (this.gui.getParent() != null && this.gui.getParent().isVisible()) {
/*     */       return;
/*     */     }
/* 202 */     JFrame frame = new JFrame("TrackMate spot fitting");
/* 203 */     frame.setIconImage(Icons.SPOT_ICON.getImage());
/* 204 */     frame.setSize(300, 300);
/* 205 */     frame.getContentPane().add(this.gui);
/* 206 */     GuiUtils.positionWindow(frame, (Component)(this.trackmate.getSettings()).imp.getCanvas());
/* 207 */     frame.setVisible(true);
/*     */   }
/*     */ 
/*     */   
/*     */   private List<String> getDocs(boolean is2d) {
/* 212 */     List<String> docs = new ArrayList<>();
/* 213 */     if (is2d) {
/*     */       
/* 215 */       docs.add("<html>Fit a 2D circular Gaussian on each spot, allowing for the radius to vary.</html>");
/*     */ 
/*     */       
/* 218 */       docs.add("<html>Fit a 2D circular Gaussian on each spot, but blocking its sigma value. The radius of the spotis not updated.</html>");
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */       
/* 224 */       docs.add("<html>Fit a 3D anisotropic Gaussian on each spot. The Z sigma can be different from the sigmas in X and Y, which are forced to be identical. The radius of the spot is set from the sigma in XY.</html>");
/*     */ 
/*     */ 
/*     */       
/* 228 */       docs.add("<html>Fit a 3D anisotropic Gaussian on each spot. We only allow X, Y, Z and the amplitude to adjust in the fit. The spot radius is left unchanged.</html>");
/*     */     } 
/*     */ 
/*     */     
/* 232 */     return docs;
/*     */   }
/*     */ 
/*     */   
/*     */   private List<String> getAvailableFits(boolean is2d) {
/* 237 */     List<String> fits = new ArrayList<>();
/* 238 */     if (is2d) {
/*     */       
/* 240 */       fits.add("Gaussian 2D");
/* 241 */       fits.add("Gaussian 2D with fixed radius");
/*     */     }
/*     */     else {
/*     */       
/* 245 */       fits.add("Elliptical orthogonal Gaussian 3D");
/* 246 */       fits.add("Gaussian 3D with fixed radius");
/*     */     } 
/* 248 */     return fits;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/action/fit/SpotFitterController.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */