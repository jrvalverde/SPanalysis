/*     */ package fiji.plugin.trackmate.action;
/*     */ 
/*     */ import fiji.plugin.trackmate.SelectionModel;
/*     */ import fiji.plugin.trackmate.Spot;
/*     */ import fiji.plugin.trackmate.SpotCollection;
/*     */ import fiji.plugin.trackmate.TrackMate;
/*     */ import fiji.plugin.trackmate.gui.Icons;
/*     */ import fiji.plugin.trackmate.gui.displaysettings.DisplaySettings;
/*     */ import java.awt.Frame;
/*     */ import java.util.Iterator;
/*     */ import java.util.Set;
/*     */ import javax.swing.ImageIcon;
/*     */ import org.scijava.plugin.Plugin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ResetSpotTimeFeatureAction
/*     */   extends AbstractTMAction
/*     */ {
/*     */   public static final String NAME = "Reset spot time";
/*     */   public static final String INFO_TEXT = "<html>Reset the time feature of all spots: it is set to the frame number times the frame interval. </html>";
/*     */   private static final String KEY = "RESET_SPOT_TIME";
/*     */   
/*     */   public void execute(TrackMate trackmate, SelectionModel selectionModel, DisplaySettings displaySettings, Frame parent) {
/*  58 */     this.logger.log("Reset spot time.\n");
/*  59 */     double dt = (trackmate.getSettings()).dt;
/*  60 */     if (dt == 0.0D) {
/*  61 */       dt = 1.0D;
/*     */     }
/*  63 */     SpotCollection spots = trackmate.getModel().getSpots();
/*  64 */     Set<Integer> frames = spots.keySet();
/*  65 */     for (Iterator<Integer> iterator = frames.iterator(); iterator.hasNext(); ) { int frame = ((Integer)iterator.next()).intValue();
/*  66 */       for (Iterator<Spot> iterator1 = spots.iterator(Integer.valueOf(frame), true); iterator1.hasNext();) {
/*  67 */         ((Spot)iterator1.next()).putFeature("POSITION_T", Double.valueOf(frame * dt));
/*     */       }
/*  69 */       this.logger.setProgress((frame + 1) / frames.size()); }
/*     */     
/*  71 */     this.logger.log("Done.\n");
/*  72 */     this.logger.setProgress(0.0D);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Plugin(type = TrackMateActionFactory.class, visible = false)
/*     */   public static class Factory
/*     */     implements TrackMateActionFactory
/*     */   {
/*     */     public String getInfoText() {
/*  82 */       return "<html>Reset the time feature of all spots: it is set to the frame number times the frame interval. </html>";
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public String getName() {
/*  88 */       return "Reset spot time";
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public String getKey() {
/*  94 */       return "RESET_SPOT_TIME";
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public ImageIcon getIcon() {
/* 100 */       return Icons.TIME_ICON;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public TrackMateAction create() {
/* 106 */       return new ResetSpotTimeFeatureAction();
/*     */     }
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/action/ResetSpotTimeFeatureAction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */