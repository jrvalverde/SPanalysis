/*    */ package fiji.plugin.trackmate.gui.wizard.descriptors;
/*    */ 
/*    */ import fiji.plugin.trackmate.SelectionModel;
/*    */ import fiji.plugin.trackmate.TrackMate;
/*    */ import fiji.plugin.trackmate.gui.components.ActionChooserPanel;
/*    */ import fiji.plugin.trackmate.gui.displaysettings.DisplaySettings;
/*    */ import fiji.plugin.trackmate.gui.wizard.WizardPanelDescriptor;
/*    */ import fiji.plugin.trackmate.providers.ActionProvider;
/*    */ import java.awt.Component;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ActionChooserDescriptor
/*    */   extends WizardPanelDescriptor
/*    */ {
/*    */   private static final String KEY = "Actions";
/*    */   
/*    */   public ActionChooserDescriptor(ActionProvider actionProvider, TrackMate trackmate, SelectionModel selectionModel, DisplaySettings displaySettings) {
/* 38 */     super("Actions");
/* 39 */     this.targetPanel = (Component)new ActionChooserPanel(actionProvider, trackmate, selectionModel, displaySettings);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/gui/wizard/descriptors/ActionChooserDescriptor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */