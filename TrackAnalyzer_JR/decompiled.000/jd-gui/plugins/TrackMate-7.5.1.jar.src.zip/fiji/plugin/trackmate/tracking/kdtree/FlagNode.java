/*    */ package fiji.plugin.trackmate.tracking.kdtree;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FlagNode<K>
/*    */ {
/*    */   private K value;
/*    */   private boolean visited = false;
/*    */   
/*    */   public FlagNode(K value) {
/* 33 */     setValue(value);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isVisited() {
/* 38 */     return this.visited;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setVisited(boolean visited) {
/* 43 */     this.visited = visited;
/*    */   }
/*    */ 
/*    */   
/*    */   public K getValue() {
/* 48 */     return this.value;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setValue(K value) {
/* 53 */     this.value = value;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/tracking/kdtree/FlagNode.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */