/*     */ package fiji.plugin.trackmate.detection;
/*     */ 
/*     */ import fiji.plugin.trackmate.Logger;
/*     */ import fiji.plugin.trackmate.Model;
/*     */ import fiji.plugin.trackmate.Settings;
/*     */ import fiji.plugin.trackmate.Spot;
/*     */ import fiji.plugin.trackmate.SpotCollection;
/*     */ import fiji.plugin.trackmate.TrackMate;
/*     */ import fiji.plugin.trackmate.detection.util.MedianFilter2D;
/*     */ import ij.ImagePlus;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.Executors;
/*     */ import java.util.function.Consumer;
/*     */ import net.imagej.ImgPlus;
/*     */ import net.imagej.axis.Axes;
/*     */ import net.imglib2.Cursor;
/*     */ import net.imglib2.Dimensions;
/*     */ import net.imglib2.FinalInterval;
/*     */ import net.imglib2.Interval;
/*     */ import net.imglib2.Localizable;
/*     */ import net.imglib2.Point;
/*     */ import net.imglib2.RandomAccess;
/*     */ import net.imglib2.RandomAccessible;
/*     */ import net.imglib2.RandomAccessibleInterval;
/*     */ import net.imglib2.algorithm.localextrema.LocalExtrema;
/*     */ import net.imglib2.algorithm.localextrema.RefinedPeak;
/*     */ import net.imglib2.algorithm.localextrema.SubpixelLocalization;
/*     */ import net.imglib2.algorithm.neighborhood.RectangleShape;
/*     */ import net.imglib2.algorithm.neighborhood.Shape;
/*     */ import net.imglib2.converter.RealFloatConverter;
/*     */ import net.imglib2.img.Img;
/*     */ import net.imglib2.img.ImgFactory;
/*     */ import net.imglib2.img.array.ArrayCursor;
/*     */ import net.imglib2.img.array.ArrayImg;
/*     */ import net.imglib2.img.array.ArrayImgs;
/*     */ import net.imglib2.img.basictypeaccess.array.FloatArray;
/*     */ import net.imglib2.img.display.imagej.ImgPlusViews;
/*     */ import net.imglib2.type.numeric.RealType;
/*     */ import net.imglib2.type.numeric.real.FloatType;
/*     */ import net.imglib2.util.Intervals;
/*     */ import net.imglib2.view.IntervalView;
/*     */ import net.imglib2.view.Views;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DetectionUtils
/*     */ {
/*     */   public static final void preview(final Model model, final Settings settings, final SpotDetectorFactoryBase<?> detectorFactory, final Map<String, Object> detectorSettings, final int frame, final Logger logger, final Consumer<Boolean> buttonEnabler) {
/* 110 */     buttonEnabler.accept(Boolean.valueOf(false));
/* 111 */     (new Thread("TrackMate preview detection thread")
/*     */       {
/*     */ 
/*     */ 
/*     */         
/*     */         public void run()
/*     */         {
/*     */           try {
/* 119 */             Settings lSettings = new Settings(settings.imp);
/* 120 */             lSettings.tstart = frame;
/* 121 */             lSettings.tend = frame;
/* 122 */             lSettings.roi = settings.roi;
/*     */             
/* 124 */             lSettings.detectorFactory = detectorFactory;
/* 125 */             lSettings.detectorSettings = detectorSettings;
/*     */             
/* 127 */             TrackMate trackmate = new TrackMate(lSettings);
/* 128 */             trackmate.getModel().setLogger(logger);
/*     */             
/* 130 */             boolean detectionOk = trackmate.execDetection();
/* 131 */             if (!detectionOk) {
/*     */               
/* 133 */               logger.error(trackmate.getErrorMessage());
/*     */               return;
/*     */             } 
/* 136 */             logger.log("Found " + trackmate.getModel().getSpots().getNSpots(false) + " spots.");
/*     */ 
/*     */             
/* 139 */             SpotCollection newspots = trackmate.getModel().getSpots();
/* 140 */             Iterator<Spot> it = newspots.iterator(Integer.valueOf(frame), false);
/* 141 */             ArrayList<Spot> spotsToCopy = new ArrayList<>(newspots.getNSpots(frame, false));
/* 142 */             while (it.hasNext()) {
/* 143 */               spotsToCopy.add(it.next());
/*     */             }
/*     */             
/* 146 */             model.getSpots().put(frame, spotsToCopy);
/*     */             
/* 148 */             for (Spot spot : spotsToCopy) {
/* 149 */               spot.putFeature("VISIBILITY", SpotCollection.ONE);
/*     */             }
/*     */             
/* 152 */             model.setSpots(model.getSpots(), true);
/*     */           
/*     */           }
/* 155 */           catch (Exception e) {
/*     */             
/* 157 */             logger.error(e.getMessage());
/* 158 */             e.printStackTrace();
/*     */           }
/*     */           finally {
/*     */             
/* 162 */             buttonEnabler.accept(Boolean.valueOf(true));
/*     */           } 
/*     */         }
/* 165 */       }).start();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final boolean is2D(ImgPlus<?> img) {
/* 180 */     return (img.dimensionIndex(Axes.Z) < 0 || img
/* 181 */       .dimension(img.dimensionIndex(Axes.Z)) <= 1L);
/*     */   }
/*     */ 
/*     */   
/*     */   public static final boolean is2D(ImagePlus imp) {
/* 186 */     return (imp.getNSlices() <= 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final Img<FloatType> createLoGKernel(double radius, int nDims, double[] calibration) {
/* 206 */     double sigma = radius / Math.sqrt(nDims);
/* 207 */     double[] sigmaPixels = new double[nDims];
/* 208 */     for (int i = 0; i < sigmaPixels.length; i++)
/*     */     {
/* 210 */       sigmaPixels[i] = sigma / calibration[i];
/*     */     }
/*     */     
/* 213 */     int n = sigmaPixels.length;
/* 214 */     long[] sizes = new long[n];
/* 215 */     long[] middle = new long[n];
/* 216 */     for (int d = 0; d < n; d++) {
/*     */ 
/*     */       
/* 219 */       int hksizes = Math.max(2, (int)(3.0D * sigmaPixels[d] + 0.5D) + 1);
/* 220 */       sizes[d] = (3 + 2 * hksizes);
/* 221 */       middle[d] = (1 + hksizes);
/*     */     } 
/*     */     
/* 224 */     ArrayImg<FloatType, FloatArray> kernel = ArrayImgs.floats(sizes);
/*     */     
/* 226 */     ArrayCursor<FloatType> c = kernel.cursor();
/* 227 */     long[] coords = new long[nDims];
/*     */ 
/*     */     
/* 230 */     while (c.hasNext()) {
/*     */       
/* 232 */       c.fwd();
/* 233 */       c.localize(coords);
/*     */       
/* 235 */       double sumx2 = 0.0D;
/* 236 */       double mantissa = 0.0D;
/* 237 */       for (int j = 0; j < coords.length; j++) {
/*     */         
/* 239 */         double x = calibration[j] * (coords[j] - middle[j]);
/* 240 */         sumx2 += x * x;
/* 241 */         mantissa += 1.0D / sigmaPixels[j] / sigmaPixels[j] * (x * x / sigma / sigma - 1.0D);
/*     */       } 
/* 243 */       double exponent = -sumx2 / 2.0D / sigma / sigma;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 255 */       double C = 0.3183098861837907D / sigmaPixels[0] / sigmaPixels[0];
/*     */       
/* 257 */       ((FloatType)c.get()).setReal(-C * mantissa * Math.exp(exponent));
/*     */     } 
/*     */     
/* 260 */     return (Img)kernel;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final <T extends RealType<T>> Img<FloatType> copyToFloatImg(RandomAccessible<T> img, Interval interval, ImgFactory<FloatType> factory) {
/* 278 */     Img<FloatType> output = factory.create((Dimensions)interval);
/* 279 */     RandomAccess<T> in = Views.zeroMin((RandomAccessibleInterval)Views.interval(img, interval)).randomAccess();
/* 280 */     Cursor<FloatType> out = output.cursor();
/* 281 */     RealFloatConverter<T> c = new RealFloatConverter();
/*     */     
/* 283 */     while (out.hasNext()) {
/*     */       
/* 285 */       out.fwd();
/* 286 */       in.setPosition((Localizable)out);
/* 287 */       c.convert((RealType)in.get(), (FloatType)out.get());
/*     */     } 
/* 289 */     return output;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final Interval squeeze(Interval interval) {
/* 302 */     int nNonSingletonDimensions = 0;
/* 303 */     for (int d = nNonSingletonDimensions; d < interval.numDimensions(); d++) {
/*     */       
/* 305 */       if (interval.dimension(d) > 1L)
/*     */       {
/* 307 */         nNonSingletonDimensions++;
/*     */       }
/*     */     } 
/*     */     
/* 311 */     long[] min = new long[nNonSingletonDimensions];
/* 312 */     long[] max = new long[nNonSingletonDimensions];
/* 313 */     int index = 0;
/* 314 */     for (int i = 0; i < interval.numDimensions(); i++) {
/*     */       
/* 316 */       if (interval.dimension(i) > 1L) {
/*     */         
/* 318 */         min[index] = interval.min(i);
/* 319 */         max[index] = interval.max(i);
/* 320 */         index++;
/*     */       } 
/*     */     } 
/* 323 */     return (Interval)new FinalInterval(min, max);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final <R extends RealType<R> & net.imglib2.type.NativeType<R>> Img<R> applyMedianFilter(RandomAccessibleInterval<R> image) {
/* 331 */     MedianFilter2D<R> medFilt = new MedianFilter2D(image, 1);
/* 332 */     if (!medFilt.checkInput() || !medFilt.process())
/* 333 */       return null; 
/* 334 */     return medFilt.getResult();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final List<Spot> findLocalMaxima(RandomAccessibleInterval<FloatType> source, double threshold, double[] calibration, double radius, boolean doSubPixelLocalization, int numThreads) {
/*     */     List<Point> peaks;
/*     */     List<Spot> spots;
/* 343 */     FloatType val = new FloatType();
/* 344 */     val.setReal(threshold);
/* 345 */     LocalExtrema.MaximumCheck maximumCheck = new LocalExtrema.MaximumCheck((Comparable)val);
/* 346 */     IntervalView<FloatType> dogWithBorder = Views.interval((RandomAccessible)Views.extendMirrorSingle(source), (Interval)Intervals.expand((Interval)source, 1L));
/* 347 */     ExecutorService service = Executors.newFixedThreadPool(numThreads);
/*     */ 
/*     */     
/*     */     try {
/* 351 */       peaks = LocalExtrema.findLocalExtrema((RandomAccessibleInterval)dogWithBorder, (LocalExtrema.LocalNeighborhoodCheck)maximumCheck, (Shape)new RectangleShape(1, true), service, numThreads);
/*     */     }
/* 353 */     catch (InterruptedException|java.util.concurrent.ExecutionException e) {
/*     */       
/* 355 */       e.printStackTrace();
/* 356 */       peaks = Collections.emptyList();
/*     */     } 
/* 358 */     service.shutdown();
/*     */     
/* 360 */     if (peaks.isEmpty()) {
/* 361 */       return Collections.emptyList();
/*     */     }
/*     */     
/* 364 */     if (doSubPixelLocalization) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 371 */       SubpixelLocalization<Point, FloatType> spl = new SubpixelLocalization(source.numDimensions());
/* 372 */       spl.setNumThreads(numThreads);
/* 373 */       spl.setReturnInvalidPeaks(true);
/* 374 */       spl.setCanMoveOutside(true);
/* 375 */       spl.setAllowMaximaTolerance(true);
/* 376 */       spl.setMaxNumMoves(10);
/* 377 */       ArrayList<RefinedPeak<Point>> refined = spl.process(peaks, (RandomAccessible)dogWithBorder, (Interval)source);
/*     */       
/* 379 */       spots = new ArrayList<>(refined.size());
/* 380 */       RandomAccess<FloatType> ra = source.randomAccess();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 389 */       if (source.numDimensions() > 2) {
/*     */         
/* 391 */         for (RefinedPeak<Point> refinedPeak : refined)
/*     */         {
/* 393 */           ra.setPosition(refinedPeak.getOriginalPeak());
/* 394 */           double quality = ((FloatType)ra.get()).getRealDouble();
/* 395 */           double x = refinedPeak.getDoublePosition(0) * calibration[0];
/* 396 */           double y = refinedPeak.getDoublePosition(1) * calibration[1];
/* 397 */           double z = refinedPeak.getDoublePosition(2) * calibration[2];
/* 398 */           Spot spot = new Spot(x, y, z, radius, quality);
/* 399 */           spots.add(spot);
/*     */         }
/*     */       
/* 402 */       } else if (source.numDimensions() > 1) {
/*     */         
/* 404 */         double z = 0.0D;
/* 405 */         for (RefinedPeak<Point> refinedPeak : refined)
/*     */         {
/* 407 */           ra.setPosition(refinedPeak.getOriginalPeak());
/* 408 */           double quality = ((FloatType)ra.get()).getRealDouble();
/* 409 */           double x = refinedPeak.getDoublePosition(0) * calibration[0];
/* 410 */           double y = refinedPeak.getDoublePosition(1) * calibration[1];
/* 411 */           Spot spot = new Spot(x, y, 0.0D, radius, quality);
/* 412 */           spots.add(spot);
/*     */         }
/*     */       
/*     */       } else {
/*     */         
/* 417 */         double z = 0.0D;
/* 418 */         double y = 0.0D;
/* 419 */         for (RefinedPeak<Point> refinedPeak : refined)
/*     */         {
/* 421 */           ra.setPosition(refinedPeak.getOriginalPeak());
/* 422 */           double quality = ((FloatType)ra.get()).getRealDouble();
/* 423 */           double x = refinedPeak.getDoublePosition(0) * calibration[0];
/* 424 */           Spot spot = new Spot(x, 0.0D, 0.0D, radius, quality);
/* 425 */           spots.add(spot);
/*     */         }
/*     */       
/*     */       }
/*     */     
/*     */     } else {
/*     */       
/* 432 */       spots = new ArrayList<>(peaks.size());
/* 433 */       RandomAccess<FloatType> ra = source.randomAccess();
/* 434 */       if (source.numDimensions() > 2) {
/*     */         
/* 436 */         for (Point peak : peaks)
/*     */         {
/* 438 */           ra.setPosition((Localizable)peak);
/* 439 */           double quality = ((FloatType)ra.get()).getRealDouble();
/* 440 */           double x = peak.getDoublePosition(0) * calibration[0];
/* 441 */           double y = peak.getDoublePosition(1) * calibration[1];
/* 442 */           double z = peak.getDoublePosition(2) * calibration[2];
/* 443 */           Spot spot = new Spot(x, y, z, radius, quality);
/* 444 */           spots.add(spot);
/*     */         }
/*     */       
/* 447 */       } else if (source.numDimensions() > 1) {
/*     */         
/* 449 */         double z = 0.0D;
/* 450 */         for (Point peak : peaks)
/*     */         {
/* 452 */           ra.setPosition((Localizable)peak);
/* 453 */           double quality = ((FloatType)ra.get()).getRealDouble();
/* 454 */           double x = peak.getDoublePosition(0) * calibration[0];
/* 455 */           double y = peak.getDoublePosition(1) * calibration[1];
/* 456 */           Spot spot = new Spot(x, y, 0.0D, radius, quality);
/* 457 */           spots.add(spot);
/*     */         }
/*     */       
/*     */       } else {
/*     */         
/* 462 */         double z = 0.0D;
/* 463 */         double y = 0.0D;
/* 464 */         for (Point peak : peaks) {
/*     */           
/* 466 */           ra.setPosition((Localizable)peak);
/* 467 */           double quality = ((FloatType)ra.get()).getRealDouble();
/* 468 */           double x = peak.getDoublePosition(0) * calibration[0];
/* 469 */           Spot spot = new Spot(x, 0.0D, 0.0D, radius, quality);
/* 470 */           spots.add(spot);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 476 */     return spots;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final <T extends net.imglib2.type.Type<T>> RandomAccessibleInterval<T> prepareFrameImg(ImgPlus<T> img, int channel, int frame) {
/*     */     ImgPlus<T> singleTimePoint;
/*     */     ImgPlus<T> singleChannel;
/* 499 */     if (img.dimensionIndex(Axes.TIME) < 0) {
/* 500 */       singleTimePoint = img;
/*     */     } else {
/* 502 */       singleTimePoint = ImgPlusViews.hyperSlice(img, img.dimensionIndex(Axes.TIME), frame);
/*     */     } 
/*     */     
/* 505 */     if (singleTimePoint.dimensionIndex(Axes.CHANNEL) < 0) {
/* 506 */       singleChannel = singleTimePoint;
/*     */     } else {
/* 508 */       singleChannel = ImgPlusViews.hyperSlice(singleTimePoint, singleTimePoint.dimensionIndex(Axes.CHANNEL), channel);
/* 509 */     }  return (RandomAccessibleInterval<T>)singleChannel;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/detection/DetectionUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */