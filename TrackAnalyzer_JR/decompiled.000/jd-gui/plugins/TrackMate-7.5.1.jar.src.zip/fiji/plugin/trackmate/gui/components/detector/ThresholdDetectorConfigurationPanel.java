/*     */ package fiji.plugin.trackmate.gui.components.detector;
/*     */ 
/*     */ import fiji.plugin.trackmate.Logger;
/*     */ import fiji.plugin.trackmate.Model;
/*     */ import fiji.plugin.trackmate.Settings;
/*     */ import fiji.plugin.trackmate.detection.DetectionUtils;
/*     */ import fiji.plugin.trackmate.detection.MaskUtils;
/*     */ import fiji.plugin.trackmate.detection.SpotDetectorFactory;
/*     */ import fiji.plugin.trackmate.detection.SpotDetectorFactoryBase;
/*     */ import fiji.plugin.trackmate.detection.ThresholdDetectorFactory;
/*     */ import fiji.plugin.trackmate.gui.Fonts;
/*     */ import fiji.plugin.trackmate.gui.GuiUtils;
/*     */ import fiji.plugin.trackmate.gui.Icons;
/*     */ import fiji.plugin.trackmate.gui.components.ConfigurationPanel;
/*     */ import fiji.plugin.trackmate.util.JLabelLogger;
/*     */ import fiji.plugin.trackmate.util.TMUtils;
/*     */ import ij.ImagePlus;
/*     */ import java.awt.Component;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.GridBagConstraints;
/*     */ import java.awt.GridBagLayout;
/*     */ import java.awt.Insets;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.text.DecimalFormat;
/*     */ import java.text.NumberFormat;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JCheckBox;
/*     */ import javax.swing.JFormattedTextField;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JSlider;
/*     */ import javax.swing.SwingUtilities;
/*     */ import javax.swing.event.ChangeEvent;
/*     */ import net.imagej.ImgPlus;
/*     */ import net.imglib2.Interval;
/*     */ import net.imglib2.RandomAccessible;
/*     */ import net.imglib2.RandomAccessibleInterval;
/*     */ import net.imglib2.view.IntervalView;
/*     */ import net.imglib2.view.Views;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ThresholdDetectorConfigurationPanel
/*     */   extends ConfigurationPanel
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  78 */   private static final NumberFormat THRESHOLD_FORMAT = new DecimalFormat("#.###");
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String TOOLTIP_PREVIEW = "<html>Preview the current settings on the current frame.<p>Advice: change the settings until you get at least <br><b>all</b> the spots you want, and do not mind the <br>spurious spots too much. You will get a chance to <br>get rid of them later.</html>";
/*     */ 
/*     */ 
/*     */   
/*     */   protected final Settings settings;
/*     */ 
/*     */ 
/*     */   
/*     */   protected JCheckBox chkboxSimplify;
/*     */ 
/*     */ 
/*     */   
/*     */   protected JSlider sliderChannel;
/*     */ 
/*     */ 
/*     */   
/*     */   protected final JFormattedTextField ftfIntensityThreshold;
/*     */ 
/*     */   
/*     */   protected final JButton btnAutoThreshold;
/*     */ 
/*     */   
/*     */   protected final JLabel lblIntensityThreshold;
/*     */ 
/*     */ 
/*     */   
/*     */   public ThresholdDetectorConfigurationPanel(Settings settings, Model model) {
/* 109 */     this(settings, model, "<html>This detector creates spots by thresholding a grayscale image.<p>Pixels in the designated channel that have a value larger than the threshold are considered as part of the foreground, and used to build connected regions. In 2D, spots are created with the (possibly simplified) contour of the region. In 3D, a spherical spot is created for each region in its center, with a volume equal to the region volume.</html>", "Thresholding detector");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ThresholdDetectorConfigurationPanel(Settings settings, Model model, String infoText, String detectorName) {
/* 135 */     this.settings = settings;
/* 136 */     ImagePlus imp = settings.imp;
/*     */     
/* 138 */     setPreferredSize(new Dimension(300, 511));
/* 139 */     GridBagLayout gridBagLayout = new GridBagLayout();
/* 140 */     gridBagLayout.rowHeights = new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 47 };
/* 141 */     gridBagLayout.columnWidths = new int[] { 0, 0, 20 };
/* 142 */     gridBagLayout.columnWeights = new double[] { 0.0D, 1.0D, 0.0D };
/* 143 */     gridBagLayout.rowWeights = new double[] { 0.0D, 0.0D, 0.0D, 0.0D, 0.0D, 0.0D, 0.0D, 1.0D, 0.0D, 0.0D };
/* 144 */     setLayout(gridBagLayout);
/*     */     
/* 146 */     JLabel jLabelPreTitle = new JLabel();
/* 147 */     GridBagConstraints gbcLabel1 = new GridBagConstraints();
/* 148 */     gbcLabel1.anchor = 18;
/* 149 */     gbcLabel1.insets = new Insets(5, 5, 5, 5);
/* 150 */     gbcLabel1.gridwidth = 3;
/* 151 */     gbcLabel1.gridx = 0;
/* 152 */     gbcLabel1.gridy = 0;
/* 153 */     add(jLabelPreTitle, gbcLabel1);
/* 154 */     jLabelPreTitle.setText("Settings for detector:");
/* 155 */     jLabelPreTitle.setFont(Fonts.FONT);
/*     */     
/* 157 */     JLabel jLabelDetectorName = new JLabel();
/* 158 */     jLabelDetectorName.setFont(Fonts.BIG_FONT);
/* 159 */     GridBagConstraints gbclblSegmenterName = new GridBagConstraints();
/* 160 */     gbclblSegmenterName.anchor = 18;
/* 161 */     gbclblSegmenterName.insets = new Insets(5, 5, 5, 5);
/* 162 */     gbclblSegmenterName.gridwidth = 3;
/* 163 */     gbclblSegmenterName.gridx = 0;
/* 164 */     gbclblSegmenterName.gridy = 1;
/* 165 */     add(jLabelDetectorName, gbclblSegmenterName);
/* 166 */     jLabelDetectorName.setFont(Fonts.BIG_FONT);
/* 167 */     jLabelDetectorName.setText(detectorName);
/*     */     
/* 169 */     JLabel jLabelHelpText = new JLabel();
/* 170 */     GridBagConstraints gbcLblHelpText = new GridBagConstraints();
/* 171 */     gbcLblHelpText.anchor = 17;
/* 172 */     gbcLblHelpText.fill = 1;
/* 173 */     gbcLblHelpText.insets = new Insets(5, 5, 5, 5);
/* 174 */     gbcLblHelpText.gridwidth = 3;
/* 175 */     gbcLblHelpText.gridx = 0;
/* 176 */     gbcLblHelpText.gridy = 2;
/* 177 */     add(jLabelHelpText, gbcLblHelpText);
/* 178 */     jLabelHelpText.setFont(Fonts.FONT.deriveFont(2));
/* 179 */     jLabelHelpText.setText(infoText.replace("<br>", "").replace("<p>", "<p align=\"justify\">").replace("<html>", "<html><p align=\"justify\">"));
/*     */     
/* 181 */     JLabel labelChannel = new JLabel("1");
/* 182 */     labelChannel.setHorizontalAlignment(0);
/* 183 */     labelChannel.setFont(Fonts.SMALL_FONT);
/* 184 */     GridBagConstraints gbcLblChannel = new GridBagConstraints();
/* 185 */     gbcLblChannel.fill = 3;
/* 186 */     gbcLblChannel.insets = new Insets(5, 5, 5, 5);
/* 187 */     gbcLblChannel.gridx = 2;
/* 188 */     gbcLblChannel.gridy = 4;
/* 189 */     add(labelChannel, gbcLblChannel);
/*     */     
/* 191 */     this.sliderChannel = new JSlider();
/* 192 */     this.sliderChannel.addChangeListener(e -> labelChannel.setText("" + this.sliderChannel.getValue()));
/*     */     
/* 194 */     JLabel lblDetectInChannel = new JLabel("Segment in channel:");
/* 195 */     lblDetectInChannel.setFont(Fonts.SMALL_FONT);
/* 196 */     GridBagConstraints gbcLblDetectInChannel = new GridBagConstraints();
/* 197 */     gbcLblDetectInChannel.anchor = 13;
/* 198 */     gbcLblDetectInChannel.insets = new Insets(5, 5, 5, 5);
/* 199 */     gbcLblDetectInChannel.gridx = 0;
/* 200 */     gbcLblDetectInChannel.gridy = 4;
/* 201 */     add(lblDetectInChannel, gbcLblDetectInChannel);
/*     */     
/* 203 */     GridBagConstraints gbcSliderChannel = new GridBagConstraints();
/* 204 */     gbcSliderChannel.fill = 1;
/* 205 */     gbcSliderChannel.insets = new Insets(5, 5, 5, 5);
/* 206 */     gbcSliderChannel.gridx = 1;
/* 207 */     gbcSliderChannel.gridy = 4;
/* 208 */     add(this.sliderChannel, gbcSliderChannel);
/*     */     
/* 210 */     this.lblIntensityThreshold = new JLabel("Intensity threshold:");
/* 211 */     this.lblIntensityThreshold.setFont(Fonts.SMALL_FONT);
/* 212 */     GridBagConstraints gbcLblNewLabel = new GridBagConstraints();
/* 213 */     gbcLblNewLabel.anchor = 13;
/* 214 */     gbcLblNewLabel.insets = new Insets(5, 5, 5, 5);
/* 215 */     gbcLblNewLabel.gridx = 0;
/* 216 */     gbcLblNewLabel.gridy = 5;
/* 217 */     add(this.lblIntensityThreshold, gbcLblNewLabel);
/*     */     
/* 219 */     this.ftfIntensityThreshold = new JFormattedTextField(THRESHOLD_FORMAT);
/* 220 */     GuiUtils.selectAllOnFocus(this.ftfIntensityThreshold);
/* 221 */     this.ftfIntensityThreshold.setValue(Double.valueOf(0.0D));
/* 222 */     this.ftfIntensityThreshold.setFont(Fonts.SMALL_FONT);
/* 223 */     this.ftfIntensityThreshold.setHorizontalAlignment(0);
/* 224 */     GridBagConstraints gbcFtfIntensityThreshold = new GridBagConstraints();
/* 225 */     gbcFtfIntensityThreshold.fill = 2;
/* 226 */     gbcFtfIntensityThreshold.insets = new Insets(5, 5, 5, 5);
/* 227 */     gbcFtfIntensityThreshold.gridx = 1;
/* 228 */     gbcFtfIntensityThreshold.gridy = 5;
/* 229 */     add(this.ftfIntensityThreshold, gbcFtfIntensityThreshold);
/*     */     
/* 231 */     this.btnAutoThreshold = new JButton("Auto");
/* 232 */     this.btnAutoThreshold.setFont(Fonts.SMALL_FONT);
/* 233 */     GridBagConstraints gbcBtnAutoThreshold = new GridBagConstraints();
/* 234 */     gbcBtnAutoThreshold.insets = new Insets(5, 5, 5, 5);
/* 235 */     gbcBtnAutoThreshold.gridx = 2;
/* 236 */     gbcBtnAutoThreshold.gridy = 5;
/* 237 */     add(this.btnAutoThreshold, gbcBtnAutoThreshold);
/*     */     
/* 239 */     this.chkboxSimplify = new JCheckBox();
/* 240 */     GridBagConstraints gbChkboxSimplify = new GridBagConstraints();
/* 241 */     gbChkboxSimplify.anchor = 18;
/* 242 */     gbChkboxSimplify.insets = new Insets(5, 5, 5, 5);
/* 243 */     gbChkboxSimplify.gridwidth = 3;
/* 244 */     gbChkboxSimplify.gridx = 0;
/* 245 */     gbChkboxSimplify.gridy = 6;
/* 246 */     add(this.chkboxSimplify, gbChkboxSimplify);
/* 247 */     this.chkboxSimplify.setText("Simplify contours.");
/* 248 */     this.chkboxSimplify.setFont(Fonts.FONT);
/*     */     
/* 250 */     JButton btnPreview = new JButton("Preview", Icons.PREVIEW_ICON);
/* 251 */     btnPreview.setToolTipText("<html>Preview the current settings on the current frame.<p>Advice: change the settings until you get at least <br><b>all</b> the spots you want, and do not mind the <br>spurious spots too much. You will get a chance to <br>get rid of them later.</html>");
/* 252 */     GridBagConstraints gbcBtnPreview = new GridBagConstraints();
/* 253 */     gbcBtnPreview.anchor = 12;
/* 254 */     gbcBtnPreview.insets = new Insets(5, 5, 5, 5);
/* 255 */     gbcBtnPreview.gridwidth = 3;
/* 256 */     gbcBtnPreview.gridx = 0;
/* 257 */     gbcBtnPreview.gridy = 8;
/* 258 */     add(btnPreview, gbcBtnPreview);
/* 259 */     btnPreview.setFont(Fonts.SMALL_FONT);
/*     */     
/* 261 */     JLabelLogger labelLogger = new JLabelLogger();
/* 262 */     labelLogger.setText("    ");
/* 263 */     GridBagConstraints gbcLblLogger = new GridBagConstraints();
/* 264 */     gbcLblLogger.insets = new Insets(5, 5, 5, 5);
/* 265 */     gbcLblLogger.anchor = 11;
/* 266 */     gbcLblLogger.fill = 2;
/* 267 */     gbcLblLogger.gridwidth = 3;
/* 268 */     gbcLblLogger.gridx = 0;
/* 269 */     gbcLblLogger.gridy = 9;
/* 270 */     add((Component)labelLogger, gbcLblLogger);
/* 271 */     Logger localLogger = labelLogger.getLogger();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 277 */     int nChannels = imp.getNChannels();
/* 278 */     this.sliderChannel.setMinimum(1);
/* 279 */     this.sliderChannel.setMaximum(nChannels);
/* 280 */     if (nChannels <= 1) {
/*     */       
/* 282 */       labelChannel.setVisible(false);
/* 283 */       lblDetectInChannel.setVisible(false);
/* 284 */       this.sliderChannel.setVisible(false);
/*     */     }
/*     */     else {
/*     */       
/* 288 */       labelChannel.setVisible(true);
/* 289 */       lblDetectInChannel.setVisible(true);
/* 290 */       this.sliderChannel.setVisible(true);
/*     */     } 
/*     */     
/* 293 */     this.btnAutoThreshold.addActionListener(e -> autoThreshold());
/*     */     
/* 295 */     btnPreview.addActionListener(e -> DetectionUtils.preview(model, settings, (SpotDetectorFactoryBase)getDetectorFactory(), getSettings(), imp.getFrame() - 1, localLogger, ()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private <T extends net.imglib2.type.numeric.RealType<T> & net.imglib2.type.NativeType<T>> void autoThreshold() {
/* 311 */     this.btnAutoThreshold.setEnabled(false);
/* 312 */     (new Thread("TrackMate compute threshold thread")
/*     */       {
/*     */ 
/*     */ 
/*     */         
/*     */         public void run()
/*     */         {
/*     */           try {
/* 320 */             ImgPlus<T> img = TMUtils.rawWraps(ThresholdDetectorConfigurationPanel.this.settings.imp);
/* 321 */             int channel = Integer.valueOf(ThresholdDetectorConfigurationPanel.this.sliderChannel.getValue()).intValue() - 1;
/* 322 */             int frame = ThresholdDetectorConfigurationPanel.this.settings.imp.getT() - 1;
/* 323 */             RandomAccessibleInterval<T> imFrame = DetectionUtils.prepareFrameImg(img, channel, frame);
/* 324 */             Interval interval = DetectionUtils.squeeze(TMUtils.getInterval(img, ThresholdDetectorConfigurationPanel.this.settings));
/* 325 */             IntervalView<T> crop = Views.interval((RandomAccessible)imFrame, interval);
/* 326 */             double threshold = MaskUtils.otsuThreshold((RandomAccessibleInterval)crop);
/* 327 */             SwingUtilities.invokeLater(() -> ThresholdDetectorConfigurationPanel.this.ftfIntensityThreshold.setValue(Double.valueOf(threshold)));
/*     */           }
/*     */           finally {
/*     */             
/* 331 */             SwingUtilities.invokeLater(() -> ThresholdDetectorConfigurationPanel.this.btnAutoThreshold.setEnabled(true));
/*     */           } 
/*     */         }
/* 334 */       }).start();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, Object> getSettings() {
/* 340 */     int targetChannel = this.sliderChannel.getValue();
/* 341 */     boolean simplify = this.chkboxSimplify.isSelected();
/* 342 */     double intensityThreshold = ((Number)this.ftfIntensityThreshold.getValue()).doubleValue();
/*     */     
/* 344 */     HashMap<String, Object> lSettings = new HashMap<>(3);
/* 345 */     lSettings.put("TARGET_CHANNEL", Integer.valueOf(targetChannel));
/* 346 */     lSettings.put("INTENSITY_THRESHOLD", Double.valueOf(intensityThreshold));
/* 347 */     lSettings.put("SIMPLIFY_CONTOURS", Boolean.valueOf(simplify));
/* 348 */     return lSettings;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSettings(Map<String, Object> settings) {
/* 354 */     this.sliderChannel.setValue(((Integer)settings.get("TARGET_CHANNEL")).intValue());
/* 355 */     this.chkboxSimplify.setSelected(((Boolean)settings.get("SIMPLIFY_CONTOURS")).booleanValue());
/*     */     
/* 357 */     Double intensityThreshold = Double.valueOf(((Double)settings.get("INTENSITY_THRESHOLD")).doubleValue());
/* 358 */     if (intensityThreshold == null || intensityThreshold.doubleValue() == 0.0D) {
/* 359 */       autoThreshold();
/*     */     } else {
/* 361 */       this.ftfIntensityThreshold.setValue(intensityThreshold);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected SpotDetectorFactory<?> getDetectorFactory() {
/* 375 */     return (SpotDetectorFactory<?>)new ThresholdDetectorFactory();
/*     */   }
/*     */   
/*     */   public void clean() {}
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/gui/components/detector/ThresholdDetectorConfigurationPanel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */