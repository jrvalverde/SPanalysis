/*     */ package fiji.plugin.trackmate.io;
/*     */ 
/*     */ import fiji.plugin.trackmate.Logger;
/*     */ import fiji.plugin.trackmate.gui.Icons;
/*     */ import fiji.util.NumberParser;
/*     */ import ij.IJ;
/*     */ import java.awt.Component;
/*     */ import java.awt.FileDialog;
/*     */ import java.awt.Frame;
/*     */ import java.awt.HeadlessException;
/*     */ import java.io.File;
/*     */ import java.io.FilenameFilter;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.swing.JDialog;
/*     */ import javax.swing.JFileChooser;
/*     */ import javax.swing.filechooser.FileNameExtensionFilter;
/*     */ import org.jdom2.Attribute;
/*     */ import org.jdom2.DataConversionException;
/*     */ import org.jdom2.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IOUtils
/*     */ {
/*     */   public static final boolean canReadFile(String path, StringBuilder errorHolder) {
/*  64 */     if (path.isEmpty()) {
/*     */       
/*  66 */       errorHolder.append("The path to the file is empty.");
/*  67 */       return false;
/*     */     } 
/*  69 */     File file = new File(path);
/*  70 */     if (!file.exists()) {
/*     */       
/*  72 */       errorHolder.append("The file " + path + " does not exist.");
/*  73 */       return false;
/*     */     } 
/*  75 */     if (!file.isFile()) {
/*     */       
/*  77 */       errorHolder.append("The path" + path + " is not a file.");
/*  78 */       return false;
/*     */     } 
/*  80 */     if (!file.canRead()) {
/*     */       
/*  82 */       errorHolder.append("The file" + path + " cannot be read.");
/*  83 */       return false;
/*     */     } 
/*  85 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static File askForFileForSaving(File file, Frame parent, Logger logger) {
/* 106 */     if (IJ.isMacintosh() && parent != null) {
/*     */ 
/*     */       
/* 109 */       FileDialog dialog = new FileDialog(parent, "Save to a XML file", 1);
/* 110 */       dialog.setIconImage(Icons.TRACKMATE_ICON.getImage());
/* 111 */       dialog.setDirectory(file.getParent());
/* 112 */       dialog.setFile(file.getName());
/* 113 */       FilenameFilter filter = new FilenameFilter()
/*     */         {
/*     */           
/*     */           public boolean accept(File dir, String name)
/*     */           {
/* 118 */             return name.endsWith(".xml");
/*     */           }
/*     */         };
/* 121 */       dialog.setFilenameFilter(filter);
/* 122 */       dialog.setVisible(true);
/* 123 */       String selectedFile = dialog.getFile();
/* 124 */       if (null == selectedFile) {
/*     */         
/* 126 */         logger.log("Save data aborted.\n");
/* 127 */         return null;
/*     */       } 
/* 129 */       if (!selectedFile.endsWith(".xml"))
/* 130 */         selectedFile = selectedFile + ".xml"; 
/* 131 */       file = new File(dialog.getDirectory(), selectedFile);
/*     */     }
/*     */     else {
/*     */       
/* 135 */       JFileChooser fileChooser = new JFileChooser(file.getParent())
/*     */         {
/*     */           private static final long serialVersionUID = 1L;
/*     */ 
/*     */ 
/*     */           
/*     */           protected JDialog createDialog(Component lParent) throws HeadlessException {
/* 142 */             JDialog dialog = super.createDialog(lParent);
/* 143 */             dialog.setIconImage(Icons.TRACKMATE_ICON.getImage());
/* 144 */             return dialog;
/*     */           }
/*     */         };
/* 147 */       fileChooser.setSelectedFile(file);
/* 148 */       FileNameExtensionFilter filter = new FileNameExtensionFilter("XML files", new String[] { "xml" });
/* 149 */       fileChooser.setFileFilter(filter);
/*     */       
/* 151 */       int returnVal = fileChooser.showSaveDialog(parent);
/* 152 */       if (returnVal == 0) {
/*     */         
/* 154 */         file = fileChooser.getSelectedFile();
/*     */       }
/*     */       else {
/*     */         
/* 158 */         logger.log("Save data aborted.\n");
/* 159 */         return null;
/*     */       } 
/*     */     } 
/* 162 */     return file;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static File askForFileForLoading(File file, String title, Frame parent, Logger logger) {
/* 183 */     if (IJ.isMacintosh()) {
/*     */ 
/*     */       
/* 186 */       FileDialog dialog = new FileDialog(parent, title, 0);
/* 187 */       dialog.setIconImage(Icons.TRACKMATE_ICON.getImage());
/* 188 */       dialog.setDirectory(file.getParent());
/* 189 */       dialog.setFile(file.getName());
/* 190 */       FilenameFilter filter = new FilenameFilter()
/*     */         {
/*     */           
/*     */           public boolean accept(File dir, String name)
/*     */           {
/* 195 */             return name.endsWith(".xml");
/*     */           }
/*     */         };
/* 198 */       dialog.setFilenameFilter(filter);
/* 199 */       dialog.setVisible(true);
/* 200 */       String selectedFile = dialog.getFile();
/* 201 */       if (null == selectedFile) {
/*     */         
/* 203 */         logger.log("Load data aborted.\n");
/* 204 */         return null;
/*     */       } 
/* 206 */       if (!selectedFile.endsWith(".xml"))
/* 207 */         selectedFile = selectedFile + ".xml"; 
/* 208 */       file = new File(dialog.getDirectory(), selectedFile);
/*     */     }
/*     */     else {
/*     */       
/* 212 */       JFileChooser fileChooser = new JFileChooser(file.getParent())
/*     */         {
/*     */           private static final long serialVersionUID = 1L;
/*     */ 
/*     */ 
/*     */           
/*     */           protected JDialog createDialog(Component lParent) throws HeadlessException {
/* 219 */             JDialog dialog = super.createDialog(lParent);
/* 220 */             dialog.setIconImage(Icons.TRACKMATE_ICON.getImage());
/* 221 */             return dialog;
/*     */           }
/*     */         };
/* 224 */       fileChooser.setName(title);
/* 225 */       fileChooser.setSelectedFile(file);
/* 226 */       FileNameExtensionFilter filter = new FileNameExtensionFilter("XML files", new String[] { "xml" });
/* 227 */       fileChooser.setFileFilter(filter);
/*     */       
/* 229 */       int returnVal = fileChooser.showOpenDialog(parent);
/* 230 */       if (returnVal == 0) {
/*     */         
/* 232 */         file = fileChooser.getSelectedFile();
/*     */       }
/*     */       else {
/*     */         
/* 236 */         logger.log("Load data aborted.\n");
/* 237 */         return null;
/*     */       } 
/*     */     } 
/* 240 */     return file;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static File askForFolder(File file, String title, Frame parent, Logger logger) {
/* 261 */     if (IJ.isMacintosh()) {
/*     */ 
/*     */       
/* 264 */       System.setProperty("apple.awt.fileDialogForDirectories", "true");
/* 265 */       FileDialog dialog = new FileDialog(parent, title, 0);
/* 266 */       dialog.setIconImage(Icons.TRACKMATE_ICON.getImage());
/* 267 */       dialog.setDirectory(file.getParent());
/* 268 */       dialog.setFile(file.getName());
/* 269 */       dialog.setVisible(true);
/* 270 */       String selectedFile = dialog.getFile();
/* 271 */       System.setProperty("apple.awt.fileDialogForDirectories", "false");
/*     */       
/* 273 */       if (null == selectedFile) {
/*     */         
/* 275 */         logger.log("Load data aborted.\n");
/* 276 */         return null;
/*     */       } 
/* 278 */       file = new File(dialog.getDirectory(), dialog.getFile());
/*     */     }
/*     */     else {
/*     */       
/* 282 */       JFileChooser fileChooser = new JFileChooser(file.getParent())
/*     */         {
/*     */           private static final long serialVersionUID = 1L;
/*     */ 
/*     */ 
/*     */           
/*     */           protected JDialog createDialog(Component lParent) throws HeadlessException {
/* 289 */             JDialog dialog = super.createDialog(lParent);
/* 290 */             dialog.setIconImage(Icons.TRACKMATE_ICON.getImage());
/* 291 */             return dialog;
/*     */           }
/*     */         };
/* 294 */       fileChooser.setFileSelectionMode(1);
/* 295 */       fileChooser.setName(title);
/* 296 */       fileChooser.setSelectedFile(file);
/*     */       
/* 298 */       int returnVal = fileChooser.showOpenDialog(parent);
/* 299 */       if (returnVal == 0) {
/*     */         
/* 301 */         file = fileChooser.getSelectedFile();
/*     */       }
/*     */       else {
/*     */         
/* 305 */         logger.log("Load data aborted.\n");
/* 306 */         return null;
/*     */       } 
/*     */     } 
/* 309 */     return file;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int readIntAttribute(Element element, String name, Logger logger) {
/* 319 */     return readIntAttribute(element, name, logger, 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public static final int readIntAttribute(Element element, String name, Logger logger, int defaultValue) {
/* 324 */     int val = defaultValue;
/* 325 */     Attribute att = element.getAttribute(name);
/* 326 */     if (null == att) {
/*     */       
/* 328 */       logger.error("Could not find attribute " + name + " for element " + element.getName() + ", substituting default value: " + defaultValue + ".\n");
/* 329 */       return val;
/*     */     } 
/*     */     
/*     */     try {
/* 333 */       val = att.getIntValue();
/*     */     }
/* 335 */     catch (DataConversionException e) {
/*     */       
/* 337 */       logger.error("Cannot read the attribute " + name + " of the element " + element.getName() + ", substituting default value: " + defaultValue + ".\n");
/*     */     } 
/* 339 */     return val;
/*     */   }
/*     */ 
/*     */   
/*     */   public static final double readFloatAttribute(Element element, String name, Logger logger) {
/* 344 */     double val = 0.0D;
/* 345 */     Attribute att = element.getAttribute(name);
/* 346 */     if (null == att) {
/*     */       
/* 348 */       logger.error("Could not find attribute " + name + " for element " + element.getName() + ", substituting default value.\n");
/* 349 */       return val;
/*     */     } 
/*     */     
/*     */     try {
/* 353 */       val = att.getFloatValue();
/*     */     }
/* 355 */     catch (DataConversionException e) {
/*     */       
/* 357 */       logger.error("Cannot read the attribute " + name + " of the element " + element.getName() + ", substituting default value.\n");
/*     */     } 
/* 359 */     return val;
/*     */   }
/*     */ 
/*     */   
/*     */   public static final double readDoubleAttribute(Element element, String name, Logger logger) {
/* 364 */     return readDoubleAttribute(element, name, logger, 0.0D);
/*     */   }
/*     */ 
/*     */   
/*     */   public static final double readDoubleAttribute(Element element, String name, Logger logger, double defaultValue) {
/* 369 */     double val = defaultValue;
/* 370 */     Attribute att = element.getAttribute(name);
/* 371 */     if (null == att) {
/*     */       
/* 373 */       logger.error("Could not find attribute " + name + " for element " + element.getName() + ", substituting default value.\n");
/* 374 */       return val;
/*     */     } 
/*     */     
/*     */     try {
/* 378 */       val = att.getDoubleValue();
/*     */     }
/* 380 */     catch (DataConversionException e) {
/*     */       
/* 382 */       logger.error("Cannot read the attribute " + name + " of the element " + element.getName() + ", substituting default value.\n");
/*     */     } 
/* 384 */     return val;
/*     */   }
/*     */ 
/*     */   
/*     */   public static final boolean readBooleanAttribute(Element element, String name, Logger logger) {
/* 389 */     return readBooleanAttribute(element, name, logger, false);
/*     */   }
/*     */ 
/*     */   
/*     */   public static final boolean readBooleanAttribute(Element element, String name, Logger logger, boolean defaultValue) {
/* 394 */     boolean val = defaultValue;
/* 395 */     Attribute att = element.getAttribute(name);
/* 396 */     if (null == att) {
/*     */       
/* 398 */       logger.error("Could not find attribute " + name + " for element " + element.getName() + ", substituting default value.\n");
/* 399 */       return val;
/*     */     } 
/*     */     
/*     */     try {
/* 403 */       val = att.getBooleanValue();
/*     */     }
/* 405 */     catch (DataConversionException e) {
/*     */       
/* 407 */       logger.error("Cannot read the attribute " + name + " of the element " + element.getName() + ", substituting default value.\n");
/*     */     } 
/* 409 */     return val;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final boolean readDoubleAttribute(Element element, Map<String, Object> settings, String parameterKey, StringBuilder errorHolder) {
/* 418 */     String str = element.getAttributeValue(parameterKey);
/* 419 */     if (null == str) {
/*     */       
/* 421 */       errorHolder.append("Attribute " + parameterKey + " could not be found in XML element.\n");
/* 422 */       return false;
/*     */     } 
/*     */     
/*     */     try {
/* 426 */       double val = NumberParser.parseDouble(str);
/* 427 */       settings.put(parameterKey, Double.valueOf(val));
/*     */     }
/* 429 */     catch (NumberFormatException nfe) {
/*     */       
/* 431 */       errorHolder.append("Could not read " + parameterKey + " attribute as a double value. Got " + str + ".\n");
/* 432 */       return false;
/*     */     } 
/* 434 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public static final boolean readIntegerAttribute(Element element, Map<String, Object> settings, String parameterKey, StringBuilder errorHolder) {
/* 439 */     String str = element.getAttributeValue(parameterKey);
/* 440 */     if (null == str) {
/*     */       
/* 442 */       errorHolder.append("Attribute " + parameterKey + " could not be found in XML element.\n");
/* 443 */       return false;
/*     */     } 
/*     */     
/*     */     try {
/* 447 */       int val = NumberParser.parseInteger(str);
/* 448 */       settings.put(parameterKey, Integer.valueOf(val));
/*     */     }
/* 450 */     catch (NumberFormatException nfe) {
/*     */       
/* 452 */       errorHolder.append("Could not read " + parameterKey + " attribute as an integer value. Got " + str + ".\n");
/* 453 */       return false;
/*     */     } 
/* 455 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public static final boolean readBooleanAttribute(Element element, Map<String, Object> settings, String parameterKey, StringBuilder errorHolder) {
/* 460 */     String str = element.getAttributeValue(parameterKey);
/* 461 */     if (null == str) {
/*     */       
/* 463 */       errorHolder.append("Attribute " + parameterKey + " could not be found in XML element.\n");
/* 464 */       return false;
/*     */     } 
/*     */     
/*     */     try {
/* 468 */       boolean val = Boolean.parseBoolean(str);
/* 469 */       settings.put(parameterKey, Boolean.valueOf(val));
/*     */     }
/* 471 */     catch (NumberFormatException nfe) {
/*     */       
/* 473 */       errorHolder.append("Could not read " + parameterKey + " attribute as an boolean value. Got " + str + ".");
/* 474 */       return false;
/*     */     } 
/* 476 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public static final boolean readStringAttribute(Element element, Map<String, Object> settings, String parameterKey, StringBuilder errorHolder) {
/* 481 */     String str = element.getAttributeValue(parameterKey);
/* 482 */     if (null == str) {
/*     */       
/* 484 */       errorHolder.append("Attribute " + parameterKey + " could not be found in XML element.\n");
/* 485 */       return false;
/*     */     } 
/* 487 */     settings.put(parameterKey, str);
/* 488 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean unmarshallMap(Element element, Map<String, Double> map, StringBuilder errorHolder) {
/* 501 */     boolean ok = true;
/* 502 */     List<Attribute> attributes = element.getAttributes();
/* 503 */     for (Attribute att : attributes) {
/*     */       
/* 505 */       String key = att.getName();
/*     */       
/*     */       try {
/* 508 */         double val = att.getDoubleValue();
/* 509 */         map.put(key, Double.valueOf(val));
/*     */       }
/* 511 */       catch (DataConversionException e) {
/*     */         
/* 513 */         errorHolder.append("Could not convert the " + key + " attribute to double. Got " + att.getValue() + ".\n");
/* 514 */         ok = false;
/*     */       } 
/*     */     } 
/* 517 */     return ok;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final boolean writeTargetChannel(Map<String, Object> settings, Element element, StringBuilder errorHolder) {
/* 526 */     return writeAttribute(settings, element, "TARGET_CHANNEL", Integer.class, errorHolder);
/*     */   }
/*     */ 
/*     */   
/*     */   public static final boolean writeRadius(Map<String, Object> settings, Element element, StringBuilder errorHolder) {
/* 531 */     return writeAttribute(settings, element, "RADIUS", Double.class, errorHolder);
/*     */   }
/*     */ 
/*     */   
/*     */   public static final boolean writeThreshold(Map<String, Object> settings, Element element, StringBuilder errorHolder) {
/* 536 */     return writeAttribute(settings, element, "THRESHOLD", Double.class, errorHolder);
/*     */   }
/*     */ 
/*     */   
/*     */   public static final boolean writeDoMedian(Map<String, Object> settings, Element element, StringBuilder errorHolder) {
/* 541 */     return writeAttribute(settings, element, "DO_MEDIAN_FILTERING", Boolean.class, errorHolder);
/*     */   }
/*     */ 
/*     */   
/*     */   public static final boolean writeDoSubPixel(Map<String, Object> settings, Element element, StringBuilder errorHolder) {
/* 546 */     return writeAttribute(settings, element, "DO_SUBPIXEL_LOCALIZATION", Boolean.class, errorHolder);
/*     */   }
/*     */ 
/*     */   
/*     */   public static final boolean writeDownsamplingFactor(Map<String, Object> settings, Element element, StringBuilder errorHolder) {
/* 551 */     return writeAttribute(settings, element, "DOWNSAMPLE_FACTOR", Integer.class, errorHolder);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final boolean writeAttribute(Map<String, Object> settings, Element element, String parameterKey, Class<?> expectedClass, StringBuilder errorHolder) {
/* 573 */     Object obj = settings.get(parameterKey);
/*     */     
/* 575 */     if (null == obj) {
/*     */       
/* 577 */       errorHolder.append("Could not find parameter " + parameterKey + " in settings map.\n");
/* 578 */       return false;
/*     */     } 
/*     */     
/* 581 */     if (!expectedClass.isInstance(obj)) {
/*     */       
/* 583 */       errorHolder.append("Expected " + parameterKey + " parameter to be a " + expectedClass.getName() + " but was a " + obj.getClass().getName() + ".\n");
/* 584 */       return false;
/*     */     } 
/*     */     
/* 587 */     element.setAttribute(parameterKey, "" + obj);
/* 588 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void marshallMap(Map<String, Double> map, Element element) {
/* 597 */     for (String key : map.keySet())
/* 598 */       element.setAttribute(key, ((Double)map.get(key)).toString()); 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/io/IOUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */