/*     */ package fiji.plugin.trackmate.features.track;
/*     */ 
/*     */ import fiji.plugin.trackmate.Dimension;
/*     */ import fiji.plugin.trackmate.FeatureModel;
/*     */ import fiji.plugin.trackmate.Model;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.swing.ImageIcon;
/*     */ import org.scijava.plugin.Plugin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Plugin(type = TrackAnalyzer.class)
/*     */ public class TrackIndexAnalyzer
/*     */   implements TrackAnalyzer
/*     */ {
/*     */   public static final String KEY = "Track index";
/*     */   public static final String TRACK_INDEX = "TRACK_INDEX";
/*     */   public static final String TRACK_ID = "TRACK_ID";
/*  49 */   public static final List<String> FEATURES = new ArrayList<>(2);
/*  50 */   public static final Map<String, String> FEATURE_NAMES = new HashMap<>(2);
/*  51 */   public static final Map<String, String> FEATURE_SHORT_NAMES = new HashMap<>(2);
/*  52 */   public static final Map<String, Dimension> FEATURE_DIMENSIONS = new HashMap<>(2);
/*  53 */   public static final Map<String, Boolean> IS_INT = new HashMap<>(2);
/*     */   private long processingTime;
/*     */   
/*     */   static {
/*  57 */     FEATURES.add("TRACK_INDEX");
/*  58 */     FEATURES.add("TRACK_ID");
/*     */     
/*  60 */     FEATURE_NAMES.put("TRACK_INDEX", "Track index");
/*  61 */     FEATURE_NAMES.put("TRACK_ID", "Track ID");
/*     */     
/*  63 */     FEATURE_SHORT_NAMES.put("TRACK_INDEX", "Index");
/*  64 */     FEATURE_SHORT_NAMES.put("TRACK_ID", "ID");
/*     */     
/*  66 */     FEATURE_DIMENSIONS.put("TRACK_INDEX", Dimension.NONE);
/*  67 */     FEATURE_DIMENSIONS.put("TRACK_ID", Dimension.NONE);
/*     */     
/*  69 */     IS_INT.put("TRACK_INDEX", Boolean.TRUE);
/*  70 */     IS_INT.put("TRACK_ID", Boolean.TRUE);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isLocal() {
/*  82 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void process(Collection<Integer> trackIDs, Model model) {
/*  88 */     long start = System.currentTimeMillis();
/*  89 */     FeatureModel fm = model.getFeatureModel();
/*  90 */     int index = 0;
/*  91 */     for (Integer trackID : trackIDs) {
/*     */       
/*  93 */       fm.putTrackFeature(trackID, "TRACK_INDEX", Double.valueOf(index++));
/*  94 */       fm.putTrackFeature(trackID, "TRACK_ID", Double.valueOf(trackID.intValue()));
/*     */     } 
/*  96 */     long end = System.currentTimeMillis();
/*  97 */     this.processingTime = end - start;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public long getProcessingTime() {
/* 103 */     return this.processingTime;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getKey() {
/* 109 */     return "Track index";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public List<String> getFeatures() {
/* 115 */     return FEATURES;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, String> getFeatureShortNames() {
/* 121 */     return FEATURE_SHORT_NAMES;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, String> getFeatureNames() {
/* 127 */     return FEATURE_NAMES;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, Dimension> getFeatureDimensions() {
/* 133 */     return FEATURE_DIMENSIONS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setNumThreads() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setNumThreads(int numThreads) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getNumThreads() {
/* 156 */     return 1;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getInfoText() {
/* 162 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ImageIcon getIcon() {
/* 168 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/* 174 */     return "Track index";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, Boolean> getIsIntFeature() {
/* 180 */     return IS_INT;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isManualFeature() {
/* 186 */     return false;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/features/track/TrackIndexAnalyzer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */