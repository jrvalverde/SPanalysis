/*     */ package fiji.plugin.trackmate.visualization.hyperstack;
/*     */ 
/*     */ import fiji.plugin.trackmate.Logger;
/*     */ import fiji.plugin.trackmate.Model;
/*     */ import fiji.plugin.trackmate.SelectionModel;
/*     */ import fiji.plugin.trackmate.gui.Fonts;
/*     */ import fiji.plugin.trackmate.gui.Icons;
/*     */ import fiji.plugin.trackmate.util.ModelTools;
/*     */ import ij.ImagePlus;
/*     */ import java.awt.Color;
/*     */ import java.awt.LayoutManager;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.event.FocusEvent;
/*     */ import java.awt.event.FocusListener;
/*     */ import javax.swing.BoxLayout;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JFormattedTextField;
/*     */ import javax.swing.JFrame;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JScrollPane;
/*     */ import javax.swing.JTextPane;
/*     */ import javax.swing.SwingUtilities;
/*     */ import javax.swing.border.LineBorder;
/*     */ import javax.swing.text.AttributeSet;
/*     */ import javax.swing.text.SimpleAttributeSet;
/*     */ import javax.swing.text.StyleConstants;
/*     */ import javax.swing.text.StyleContext;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SpotEditToolConfigPanel
/*     */   extends JFrame
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private final Logger logger;
/*     */   private final JFormattedTextField jNFQualityThreshold;
/*     */   private final JFormattedTextField jNFDistanceTolerance;
/*     */   private final JFormattedTextField jNFNFrames;
/*     */   private final SpotEditTool parent;
/*     */   private final JFormattedTextField jNFNStepwiseTime;
/*     */   
/*     */   public SpotEditToolConfigPanel(SpotEditTool parent) {
/*  84 */     this.parent = parent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  90 */     ActionListener al = new ActionListener()
/*     */       {
/*     */         
/*     */         public void actionPerformed(ActionEvent e)
/*     */         {
/*  95 */           SpotEditToolConfigPanel.this.updateParamsFromTextFields();
/*     */         }
/*     */       };
/*  98 */     FocusListener fl = new FocusListener()
/*     */       {
/*     */         
/*     */         public void focusLost(FocusEvent arg0)
/*     */         {
/* 103 */           SpotEditToolConfigPanel.this.updateParamsFromTextFields();
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         public void focusGained(FocusEvent arg0) {}
/*     */       };
/* 115 */     setTitle("TrackMate tools");
/* 116 */     setIconImage(Icons.TRACK_ICON.getImage());
/* 117 */     setResizable(false);
/* 118 */     getContentPane().setLayout(new BoxLayout(getContentPane(), 0));
/*     */     
/* 120 */     JPanel mainPanel = new JPanel();
/* 121 */     getContentPane().add(mainPanel);
/* 122 */     mainPanel.setLayout((LayoutManager)null);
/*     */     
/* 124 */     JLabel lblTitle = new JLabel("TrackMate tools");
/* 125 */     lblTitle.setBounds(6, 6, 395, 33);
/* 126 */     lblTitle.setFont(Fonts.BIG_FONT);
/* 127 */     lblTitle.setIcon(Icons.TRACK_ICON_64x64);
/* 128 */     mainPanel.add(lblTitle);
/*     */     
/* 130 */     JPanel panelSemiAutoParams = new JPanel();
/* 131 */     panelSemiAutoParams.setBorder(new LineBorder(new Color(252, 117, 0), 1, false));
/* 132 */     panelSemiAutoParams.setBounds(6, 51, 192, 142);
/* 133 */     mainPanel.add(panelSemiAutoParams);
/* 134 */     panelSemiAutoParams.setLayout((LayoutManager)null);
/*     */     
/* 136 */     JLabel lblSemiAutoTracking = new JLabel("Semi-automatic tracking");
/* 137 */     lblSemiAutoTracking.setBounds(6, 6, 180, 16);
/* 138 */     lblSemiAutoTracking.setFont(Fonts.FONT.deriveFont(1));
/* 139 */     panelSemiAutoParams.add(lblSemiAutoTracking);
/*     */     
/* 141 */     JLabel lblQualityThreshold = new JLabel("Quality threshold");
/* 142 */     lblQualityThreshold.setToolTipText("<html>The fraction of the initial spot quality <br>found spots must have to be considered for linking. <br>The higher, the more stringent.</html>");
/*     */ 
/*     */ 
/*     */     
/* 146 */     lblQualityThreshold.setBounds(6, 66, 119, 16);
/* 147 */     lblQualityThreshold.setFont(Fonts.SMALL_FONT);
/* 148 */     panelSemiAutoParams.add(lblQualityThreshold);
/*     */     
/* 150 */     this.jNFQualityThreshold = new JFormattedTextField(Double.valueOf(parent.params.qualityThreshold));
/* 151 */     this.jNFQualityThreshold.setHorizontalAlignment(0);
/* 152 */     this.jNFQualityThreshold.setFont(Fonts.SMALL_FONT);
/* 153 */     this.jNFQualityThreshold.setBounds(137, 64, 49, 18);
/* 154 */     this.jNFQualityThreshold.addActionListener(al);
/* 155 */     this.jNFQualityThreshold.addFocusListener(fl);
/*     */     
/* 157 */     panelSemiAutoParams.add(this.jNFQualityThreshold);
/*     */     
/* 159 */     JLabel lblDistanceTolerance = new JLabel("Distance tolerance");
/* 160 */     lblDistanceTolerance.setToolTipText("<html>The maximal distance above which found spots are rejected, <br>expressed in units of the initial spot radius.</html>");
/*     */ 
/*     */     
/* 163 */     lblDistanceTolerance.setBounds(6, 86, 119, 16);
/* 164 */     lblDistanceTolerance.setFont(Fonts.SMALL_FONT);
/* 165 */     panelSemiAutoParams.add(lblDistanceTolerance);
/*     */     
/* 167 */     this.jNFDistanceTolerance = new JFormattedTextField(Double.valueOf(parent.params.distanceTolerance));
/* 168 */     this.jNFDistanceTolerance.setHorizontalAlignment(0);
/* 169 */     this.jNFDistanceTolerance.setFont(Fonts.SMALL_FONT);
/* 170 */     this.jNFDistanceTolerance.setBounds(137, 84, 49, 18);
/* 171 */     this.jNFDistanceTolerance.addActionListener(al);
/* 172 */     this.jNFDistanceTolerance.addFocusListener(fl);
/* 173 */     panelSemiAutoParams.add(this.jNFDistanceTolerance);
/*     */     
/* 175 */     JLabel lblNFrames = new JLabel("Max nFrames");
/* 176 */     lblNFrames.setToolTipText("<html>How many frames to process at max. <br/>Make it 0 or negative for no limit.</html>");
/* 177 */     lblNFrames.setBounds(6, 104, 119, 16);
/* 178 */     lblNFrames.setFont(Fonts.SMALL_FONT);
/* 179 */     panelSemiAutoParams.add(lblNFrames);
/*     */     
/* 181 */     this.jNFNFrames = new JFormattedTextField(Integer.valueOf(parent.params.nFrames));
/* 182 */     this.jNFNFrames.setBounds(137, 104, 49, 18);
/* 183 */     this.jNFNFrames.setHorizontalAlignment(0);
/* 184 */     this.jNFNFrames.setFont(Fonts.SMALL_FONT);
/* 185 */     this.jNFNFrames.addActionListener(al);
/* 186 */     this.jNFNFrames.addFocusListener(fl);
/* 187 */     panelSemiAutoParams.add(this.jNFNFrames);
/*     */     
/* 189 */     JButton buttonSemiAutoTracking = new JButton(Icons.SPOT_ICON_64x64);
/* 190 */     buttonSemiAutoTracking.setBounds(6, 31, 33, 23);
/* 191 */     panelSemiAutoParams.add(buttonSemiAutoTracking);
/* 192 */     buttonSemiAutoTracking.addActionListener(new ActionListener()
/*     */         {
/*     */           
/*     */           public void actionPerformed(ActionEvent arg0)
/*     */           {
/* 197 */             SpotEditToolConfigPanel.this.semiAutoTracking();
/*     */           }
/*     */         });
/*     */     
/* 201 */     JLabel labelSemiAutoTracking = new JLabel("Semi-automatic tracking");
/* 202 */     labelSemiAutoTracking.setToolTipText("Launch semi-automatic tracking on selected spots.");
/* 203 */     labelSemiAutoTracking.setFont(Fonts.SMALL_FONT);
/* 204 */     labelSemiAutoTracking.setBounds(49, 31, 137, 23);
/* 205 */     panelSemiAutoParams.add(labelSemiAutoTracking);
/*     */ 
/*     */     
/* 208 */     JScrollPane scrollPane = new JScrollPane();
/* 209 */     scrollPane.setHorizontalScrollBarPolicy(31);
/* 210 */     scrollPane.setVerticalScrollBarPolicy(22);
/* 211 */     scrollPane.setBounds(210, 51, 264, 328);
/* 212 */     mainPanel.add(scrollPane);
/*     */     
/* 214 */     final JTextPane textPane = new JTextPane();
/* 215 */     textPane.setFont(Fonts.SMALL_FONT);
/* 216 */     textPane.setEditable(false);
/* 217 */     textPane.setBackground(getBackground());
/* 218 */     scrollPane.setViewportView(textPane);
/*     */     
/* 220 */     JPanel panelButtons = new JPanel();
/* 221 */     panelButtons.setBounds(6, 262, 192, 117);
/* 222 */     panelButtons.setBorder(new LineBorder(new Color(252, 117, 0), 1, false));
/* 223 */     mainPanel.add(panelButtons);
/* 224 */     panelButtons.setLayout((LayoutManager)null);
/*     */     
/* 226 */     JLabel lblSelectionTools = new JLabel("Selection tools");
/* 227 */     lblSelectionTools.setFont(Fonts.FONT.deriveFont(1));
/* 228 */     lblSelectionTools.setBounds(6, 11, 172, 14);
/* 229 */     panelButtons.add(lblSelectionTools);
/*     */     
/* 231 */     JButton buttonSelectTrack = new JButton(Icons.SELECT_TRACK_ICON);
/* 232 */     buttonSelectTrack.setBounds(10, 36, 33, 23);
/* 233 */     buttonSelectTrack.addActionListener(new ActionListener()
/*     */         {
/*     */           
/*     */           public void actionPerformed(ActionEvent e)
/*     */           {
/* 238 */             SpotEditToolConfigPanel.this.selectTrack();
/*     */           }
/*     */         });
/* 241 */     panelButtons.add(buttonSelectTrack);
/*     */     
/* 243 */     JLabel lblSelectTrack = new JLabel("Select track");
/* 244 */     lblSelectTrack.setBounds(53, 36, 129, 23);
/* 245 */     lblSelectTrack.setFont(Fonts.SMALL_FONT);
/* 246 */     lblSelectTrack.setToolTipText("Select the whole tracks selected spots belong to.");
/* 247 */     panelButtons.add(lblSelectTrack);
/*     */     
/* 249 */     JButton buttonSelectTrackUp = new JButton(Icons.SELECT_TRACK_ICON_UPWARDS);
/* 250 */     buttonSelectTrackUp.setBounds(10, 61, 33, 23);
/* 251 */     buttonSelectTrackUp.addActionListener(new ActionListener()
/*     */         {
/*     */           
/*     */           public void actionPerformed(ActionEvent e)
/*     */           {
/* 256 */             SpotEditToolConfigPanel.this.selectTrackUpward();
/*     */           }
/*     */         });
/* 259 */     panelButtons.add(buttonSelectTrackUp);
/*     */     
/* 261 */     JLabel lblSelectTrackUpward = new JLabel("Select track upward");
/* 262 */     lblSelectTrackUpward.setBounds(53, 61, 129, 23);
/* 263 */     lblSelectTrackUpward.setFont(Fonts.SMALL_FONT);
/* 264 */     lblSelectTrackUpward.setToolTipText("<html>Select the whole tracks selected spots <br>belong to, backward in time.</html>");
/*     */ 
/*     */     
/* 267 */     panelButtons.add(lblSelectTrackUpward);
/*     */     
/* 269 */     JButton buttonSelectTrackDown = new JButton(Icons.SELECT_TRACK_ICON_DOWNWARDS);
/* 270 */     buttonSelectTrackDown.setBounds(10, 86, 33, 23);
/* 271 */     buttonSelectTrackDown.addActionListener(new ActionListener()
/*     */         {
/*     */           
/*     */           public void actionPerformed(ActionEvent e)
/*     */           {
/* 276 */             SpotEditToolConfigPanel.this.selectTrackDownward();
/*     */           }
/*     */         });
/* 279 */     panelButtons.add(buttonSelectTrackDown);
/*     */     
/* 281 */     JLabel lblSelectTrackDown = new JLabel("Select track downward");
/* 282 */     lblSelectTrackDown.setBounds(53, 86, 129, 23);
/* 283 */     lblSelectTrackDown.setFont(Fonts.SMALL_FONT);
/* 284 */     lblSelectTrackDown.setToolTipText("<html>Select the whole tracks selected spots <br>belong to, forward in time.</html>");
/*     */ 
/*     */     
/* 287 */     panelButtons.add(lblSelectTrackDown);
/*     */     
/* 289 */     JPanel panel = new JPanel();
/* 290 */     panel.setBorder(new LineBorder(new Color(252, 117, 0)));
/* 291 */     panel.setBounds(6, 201, 192, 53);
/* 292 */     mainPanel.add(panel);
/* 293 */     panel.setLayout((LayoutManager)null);
/*     */     
/* 295 */     JLabel lblNavigationTools = new JLabel("Navigation tools");
/* 296 */     lblNavigationTools.setBounds(6, 6, 172, 14);
/* 297 */     lblNavigationTools.setFont(Fonts.FONT.deriveFont(1));
/* 298 */     panel.add(lblNavigationTools);
/*     */     
/* 300 */     this.jNFNStepwiseTime = new JFormattedTextField(Integer.valueOf(parent.params.stepwiseTimeBrowsing));
/* 301 */     this.jNFNStepwiseTime.setBounds(137, 26, 49, 18);
/* 302 */     this.jNFNStepwiseTime.setHorizontalAlignment(0);
/* 303 */     this.jNFNStepwiseTime.setFont(Fonts.SMALL_FONT);
/* 304 */     this.jNFNStepwiseTime.addActionListener(al);
/* 305 */     this.jNFNStepwiseTime.addFocusListener(fl);
/* 306 */     panel.add(this.jNFNStepwiseTime);
/*     */     
/* 308 */     JLabel lblJumpByb = new JLabel("Stepwise time browsing");
/* 309 */     lblJumpByb.setBounds(10, 29, 120, 14);
/* 310 */     lblJumpByb.setFont(Fonts.SMALL_FONT);
/* 311 */     panel.add(lblJumpByb);
/*     */     
/* 313 */     this.logger = new Logger()
/*     */       {
/*     */ 
/*     */         
/*     */         public void error(String message)
/*     */         {
/* 319 */           log(message, Logger.ERROR_COLOR);
/*     */         }
/*     */ 
/*     */ 
/*     */         
/*     */         public void log(final String message, final Color color) {
/* 325 */           SwingUtilities.invokeLater(new Runnable()
/*     */               {
/*     */                 
/*     */                 public void run()
/*     */                 {
/* 330 */                   textPane.setEditable(true);
/* 331 */                   StyleContext sc = StyleContext.getDefaultStyleContext();
/* 332 */                   AttributeSet aset = sc.addAttribute(SimpleAttributeSet.EMPTY, StyleConstants.Foreground, color);
/* 333 */                   int len = textPane.getDocument().getLength();
/* 334 */                   textPane.setCaretPosition(len);
/* 335 */                   textPane.setCharacterAttributes(aset, false);
/* 336 */                   textPane.replaceSelection(message);
/* 337 */                   textPane.setEditable(false);
/*     */                 }
/*     */               });
/*     */         }
/*     */ 
/*     */ 
/*     */         
/*     */         public void setStatus(String status) {
/* 345 */           log(status, Logger.GREEN_COLOR);
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         public void setProgress(double val) {}
/*     */       };
/* 353 */     setSize(487, 418);
/* 354 */     setDefaultCloseOperation(1);
/* 355 */     setVisible(true);
/*     */   }
/*     */ 
/*     */   
/*     */   private void selectTrackDownward() {
/* 360 */     ImagePlus imp = this.parent.imp;
/* 361 */     if (imp == null)
/*     */       return; 
/* 363 */     HyperStackDisplayer displayer = this.parent.displayers.get(imp);
/* 364 */     if (null == displayer)
/*     */       return; 
/* 366 */     SelectionModel selectionModel = displayer.getSelectionModel();
/* 367 */     ModelTools.selectTrackDownward(selectionModel);
/*     */   }
/*     */ 
/*     */   
/*     */   private void selectTrackUpward() {
/* 372 */     ImagePlus imp = this.parent.imp;
/* 373 */     if (imp == null)
/*     */       return; 
/* 375 */     HyperStackDisplayer displayer = this.parent.displayers.get(imp);
/* 376 */     if (null == displayer)
/*     */       return; 
/* 378 */     SelectionModel selectionModel = displayer.getSelectionModel();
/* 379 */     ModelTools.selectTrackUpward(selectionModel);
/*     */   }
/*     */ 
/*     */   
/*     */   private void selectTrack() {
/* 384 */     ImagePlus imp = this.parent.imp;
/* 385 */     if (imp == null)
/*     */       return; 
/* 387 */     HyperStackDisplayer displayer = this.parent.displayers.get(imp);
/* 388 */     if (null == displayer)
/*     */       return; 
/* 390 */     SelectionModel selectionModel = displayer.getSelectionModel();
/* 391 */     ModelTools.selectTrack(selectionModel);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Logger getLogger() {
/* 401 */     return this.logger;
/*     */   }
/*     */ 
/*     */   
/*     */   private void updateParamsFromTextFields() {
/* 406 */     this.parent.params.distanceTolerance = ((Number)this.jNFDistanceTolerance.getValue()).doubleValue();
/* 407 */     this.parent.params.qualityThreshold = ((Number)this.jNFQualityThreshold.getValue()).doubleValue();
/* 408 */     this.parent.params.nFrames = ((Number)this.jNFNFrames.getValue()).intValue();
/* 409 */     this.parent.params.stepwiseTimeBrowsing = ((Number)this.jNFNStepwiseTime.getValue()).intValue();
/*     */   }
/*     */ 
/*     */   
/*     */   private void semiAutoTracking() {
/* 414 */     ImagePlus imp = this.parent.imp;
/* 415 */     if (imp == null)
/*     */       return; 
/* 417 */     HyperStackDisplayer displayer = this.parent.displayers.get(imp);
/* 418 */     if (null == displayer)
/*     */       return; 
/* 420 */     Model model = displayer.getModel();
/* 421 */     SelectionModel selectionModel = displayer.getSelectionModel();
/* 422 */     this.parent.semiAutoTracking(model, selectionModel, imp);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/visualization/hyperstack/SpotEditToolConfigPanel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */