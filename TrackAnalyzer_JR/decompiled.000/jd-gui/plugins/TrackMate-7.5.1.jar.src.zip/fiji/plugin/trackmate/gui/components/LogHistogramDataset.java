/*    */ package fiji.plugin.trackmate.gui.components;
/*    */ 
/*    */ import org.jfree.data.statistics.HistogramDataset;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LogHistogramDataset
/*    */   extends HistogramDataset
/*    */ {
/*    */   private static final long serialVersionUID = 6012084169414194555L;
/*    */   
/*    */   public Number getY(int series, int item) {
/* 38 */     Number val = super.getY(series, item);
/* 39 */     return Double.valueOf(Math.log(1.0D + val.doubleValue()));
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/gui/components/LogHistogramDataset.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */