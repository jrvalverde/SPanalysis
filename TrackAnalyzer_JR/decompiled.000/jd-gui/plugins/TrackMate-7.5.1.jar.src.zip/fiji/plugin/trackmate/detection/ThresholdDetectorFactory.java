/*     */ package fiji.plugin.trackmate.detection;
/*     */ 
/*     */ import fiji.plugin.trackmate.Model;
/*     */ import fiji.plugin.trackmate.Settings;
/*     */ import fiji.plugin.trackmate.gui.components.ConfigurationPanel;
/*     */ import fiji.plugin.trackmate.gui.components.detector.ThresholdDetectorConfigurationPanel;
/*     */ import fiji.plugin.trackmate.io.IOUtils;
/*     */ import fiji.plugin.trackmate.util.TMUtils;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.swing.ImageIcon;
/*     */ import net.imagej.ImgPlus;
/*     */ import net.imagej.ImgPlusMetadata;
/*     */ import net.imglib2.Interval;
/*     */ import net.imglib2.RandomAccessible;
/*     */ import net.imglib2.RandomAccessibleInterval;
/*     */ import net.imglib2.type.NativeType;
/*     */ import net.imglib2.type.Type;
/*     */ import net.imglib2.type.numeric.RealType;
/*     */ import org.jdom2.Element;
/*     */ import org.scijava.plugin.Plugin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Plugin(type = SpotDetectorFactory.class)
/*     */ public class ThresholdDetectorFactory<T extends RealType<T> & NativeType<T>>
/*     */   implements SpotDetectorFactory<T>
/*     */ {
/*     */   public static final String DETECTOR_KEY = "THRESHOLD_DETECTOR";
/*     */   public static final String NAME = "Thresholding detector";
/*     */   public static final String INFO_TEXT = "<html>This detector creates spots by thresholding a grayscale image.<p>Pixels in the designated channel that have a value larger than the threshold are considered as part of the foreground, and used to build connected regions. In 2D, spots are created with the (possibly simplified) contour of the region. In 3D, a spherical spot is created for each region in its center, with a volume equal to the region volume.</html>";
/*     */   public static final String KEY_SIMPLIFY_CONTOURS = "SIMPLIFY_CONTOURS";
/*     */   public static final String KEY_INTENSITY_THRESHOLD = "INTENSITY_THRESHOLD";
/*     */   protected ImgPlus<T> img;
/*     */   protected Map<String, Object> settings;
/*     */   protected String errorMessage;
/*     */   
/*     */   public boolean setTarget(ImgPlus<T> img, Map<String, Object> settings) {
/* 103 */     this.img = img;
/* 104 */     this.settings = settings;
/* 105 */     return checkSettings(settings);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public SpotDetector<T> getDetector(Interval interval, int frame) {
/* 111 */     double intensityThreshold = ((Double)this.settings.get("INTENSITY_THRESHOLD")).doubleValue();
/* 112 */     boolean simplifyContours = ((Boolean)this.settings.get("SIMPLIFY_CONTOURS")).booleanValue();
/* 113 */     double[] calibration = TMUtils.getSpatialCalibration((ImgPlusMetadata)this.img);
/* 114 */     int channel = ((Integer)this.settings.get("TARGET_CHANNEL")).intValue() - 1;
/* 115 */     RandomAccessibleInterval<Type> randomAccessibleInterval = DetectionUtils.prepareFrameImg((ImgPlus)this.img, channel, frame);
/*     */     
/* 117 */     ThresholdDetector<T> detector = new ThresholdDetector<>((RandomAccessible)randomAccessibleInterval, interval, calibration, intensityThreshold, simplifyContours);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 123 */     detector.setNumThreads(1);
/* 124 */     return detector;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean has2Dsegmentation() {
/* 130 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getKey() {
/* 136 */     return "THRESHOLD_DETECTOR";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getErrorMessage() {
/* 142 */     return this.errorMessage;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean checkSettings(Map<String, Object> lSettings) {
/* 148 */     boolean ok = true;
/* 149 */     StringBuilder errorHolder = new StringBuilder();
/* 150 */     ok &= TMUtils.checkParameter(lSettings, "TARGET_CHANNEL", Integer.class, errorHolder);
/* 151 */     ok &= TMUtils.checkParameter(lSettings, "INTENSITY_THRESHOLD", Double.class, errorHolder);
/* 152 */     ok &= TMUtils.checkParameter(lSettings, "SIMPLIFY_CONTOURS", Boolean.class, errorHolder);
/* 153 */     List<String> mandatoryKeys = new ArrayList<>();
/* 154 */     mandatoryKeys.add("TARGET_CHANNEL");
/* 155 */     mandatoryKeys.add("INTENSITY_THRESHOLD");
/* 156 */     mandatoryKeys.add("SIMPLIFY_CONTOURS");
/* 157 */     ok &= TMUtils.checkMapKeys(lSettings, mandatoryKeys, null, errorHolder);
/* 158 */     if (!ok)
/*     */     {
/* 160 */       this.errorMessage = errorHolder.toString();
/*     */     }
/* 162 */     return ok;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean marshall(Map<String, Object> lSettings, Element element) {
/* 168 */     StringBuilder errorHolder = new StringBuilder();
/*     */ 
/*     */     
/* 171 */     boolean ok = (IOUtils.writeTargetChannel(lSettings, element, errorHolder) && IOUtils.writeAttribute(lSettings, element, "INTENSITY_THRESHOLD", Double.class, errorHolder) && IOUtils.writeAttribute(lSettings, element, "SIMPLIFY_CONTOURS", Boolean.class, errorHolder));
/*     */     
/* 173 */     if (!ok) {
/* 174 */       this.errorMessage = errorHolder.toString();
/*     */     }
/* 176 */     return ok;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean unmarshall(Element element, Map<String, Object> lSettings) {
/* 182 */     lSettings.clear();
/* 183 */     StringBuilder errorHolder = new StringBuilder();
/* 184 */     boolean ok = true;
/* 185 */     ok &= IOUtils.readIntegerAttribute(element, lSettings, "TARGET_CHANNEL", errorHolder);
/* 186 */     ok &= IOUtils.readDoubleAttribute(element, lSettings, "INTENSITY_THRESHOLD", errorHolder);
/* 187 */     ok &= IOUtils.readBooleanAttribute(element, lSettings, "SIMPLIFY_CONTOURS", errorHolder);
/* 188 */     if (!ok) {
/*     */       
/* 190 */       this.errorMessage = errorHolder.toString();
/* 191 */       return false;
/*     */     } 
/* 193 */     return checkSettings(lSettings);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ConfigurationPanel getDetectorConfigurationPanel(Settings lSettings, Model model) {
/* 199 */     return (ConfigurationPanel)new ThresholdDetectorConfigurationPanel(lSettings, model);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getInfoText() {
/* 205 */     return "<html>This detector creates spots by thresholding a grayscale image.<p>Pixels in the designated channel that have a value larger than the threshold are considered as part of the foreground, and used to build connected regions. In 2D, spots are created with the (possibly simplified) contour of the region. In 3D, a spherical spot is created for each region in its center, with a volume equal to the region volume.</html>";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/* 211 */     return "Thresholding detector";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, Object> getDefaultSettings() {
/* 217 */     Map<String, Object> lSettings = new HashMap<>();
/* 218 */     lSettings.put("TARGET_CHANNEL", Integer.valueOf(1));
/* 219 */     lSettings.put("INTENSITY_THRESHOLD", Double.valueOf(0.0D));
/* 220 */     lSettings.put("SIMPLIFY_CONTOURS", Boolean.valueOf(true));
/* 221 */     return lSettings;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ImageIcon getIcon() {
/* 227 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ThresholdDetectorFactory<T> copy() {
/* 233 */     return new ThresholdDetectorFactory();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/detection/ThresholdDetectorFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */