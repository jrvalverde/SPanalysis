/*     */ package fiji.plugin.trackmate;
/*     */ 
/*     */ import fiji.plugin.trackmate.util.AlphanumComparator;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Comparator;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ import net.imglib2.AbstractEuclideanSpace;
/*     */ import net.imglib2.RealLocalizable;
/*     */ import net.imglib2.util.Util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Spot
/*     */   extends AbstractEuclideanSpace
/*     */   implements RealLocalizable, Comparable<Spot>
/*     */ {
/*  65 */   public static AtomicInteger IDcounter = new AtomicInteger(-1);
/*     */ 
/*     */   
/*  68 */   private final ConcurrentHashMap<String, Double> features = new ConcurrentHashMap<>();
/*     */ 
/*     */ 
/*     */   
/*     */   private String name;
/*     */ 
/*     */ 
/*     */   
/*     */   private final int ID;
/*     */ 
/*     */   
/*     */   private SpotRoi roi;
/*     */ 
/*     */   
/*     */   public static final String QUALITY = "QUALITY";
/*     */ 
/*     */   
/*     */   public static final String RADIUS = "RADIUS";
/*     */ 
/*     */   
/*     */   public static final String POSITION_X = "POSITION_X";
/*     */ 
/*     */   
/*     */   public static final String POSITION_Y = "POSITION_Y";
/*     */ 
/*     */   
/*     */   public static final String POSITION_Z = "POSITION_Z";
/*     */ 
/*     */   
/*     */   public static final String POSITION_T = "POSITION_T";
/*     */ 
/*     */   
/*     */   public static final String FRAME = "FRAME";
/*     */ 
/*     */ 
/*     */   
/*     */   public Spot(double x, double y, double z, double radius, double quality, String name) {
/* 105 */     super(3);
/* 106 */     this.ID = IDcounter.incrementAndGet();
/* 107 */     putFeature("POSITION_X", Double.valueOf(x));
/* 108 */     putFeature("POSITION_Y", Double.valueOf(y));
/* 109 */     putFeature("POSITION_Z", Double.valueOf(z));
/* 110 */     putFeature("RADIUS", Double.valueOf(radius));
/* 111 */     putFeature("QUALITY", Double.valueOf(quality));
/* 112 */     if (null == name) {
/*     */       
/* 114 */       this.name = "ID" + this.ID;
/*     */     }
/*     */     else {
/*     */       
/* 118 */       this.name = name;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Spot(double x, double y, double z, double radius, double quality) {
/* 138 */     this(x, y, z, radius, quality, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Spot(RealLocalizable location, double radius, double quality, String name) {
/* 157 */     this(location.getDoublePosition(0), location.getDoublePosition(1), location.getDoublePosition(2), radius, quality, name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Spot(RealLocalizable location, double radius, double quality) {
/* 175 */     this(location, radius, quality, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Spot(Spot spot) {
/* 187 */     this(spot, spot.getFeature("RADIUS").doubleValue(), spot.getFeature("QUALITY").doubleValue(), spot.getName());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Spot(int ID) {
/* 200 */     super(3);
/* 201 */     this.ID = ID;
/* 202 */     synchronized (IDcounter) {
/*     */       
/* 204 */       if (IDcounter.get() < ID)
/*     */       {
/* 206 */         IDcounter.set(ID);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 218 */     return this.ID;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int compareTo(Spot o) {
/* 224 */     return this.ID - o.ID;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object other) {
/* 230 */     if (other == null)
/* 231 */       return false; 
/* 232 */     if (other == this)
/* 233 */       return true; 
/* 234 */     if (!(other instanceof Spot))
/* 235 */       return false; 
/* 236 */     Spot os = (Spot)other;
/* 237 */     return (os.ID == this.ID);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setRoi(SpotRoi roi) {
/* 242 */     this.roi = roi;
/*     */   }
/*     */ 
/*     */   
/*     */   public SpotRoi getRoi() {
/* 247 */     return this.roi;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/* 255 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setName(String name) {
/* 266 */     this.name = name;
/*     */   }
/*     */ 
/*     */   
/*     */   public int ID() {
/* 271 */     return this.ID;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/*     */     String str;
/* 278 */     if (null == this.name || this.name.equals("")) {
/* 279 */       str = "ID" + this.ID;
/*     */     } else {
/* 281 */       str = this.name;
/* 282 */     }  return str;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String echo() {
/* 292 */     StringBuilder s = new StringBuilder();
/*     */ 
/*     */     
/* 295 */     if (null == this.name) {
/* 296 */       s.append("Spot: <no name>\n");
/*     */     } else {
/* 298 */       s.append("Spot: " + this.name + "\n");
/*     */     } 
/*     */     
/* 301 */     s.append("Time: " + getFeature("POSITION_T") + '\n');
/*     */ 
/*     */     
/* 304 */     double[] coordinates = new double[3];
/* 305 */     localize(coordinates);
/* 306 */     s.append("Position: " + Util.printCoordinates(coordinates) + "\n");
/*     */ 
/*     */     
/* 309 */     if (null == this.features || this.features.size() < 1) {
/* 310 */       s.append("No features calculated\n");
/*     */     } else {
/*     */       
/* 313 */       s.append("Feature list:\n");
/*     */       
/* 315 */       for (String key : this.features.keySet()) {
/*     */         
/* 317 */         s.append("\t" + key.toString() + ": ");
/* 318 */         double val = ((Double)this.features.get(key)).doubleValue();
/* 319 */         if (val >= 10000.0D) {
/* 320 */           s.append(String.format("%.1g", new Object[] { Double.valueOf(val) }));
/*     */         } else {
/* 322 */           s.append(String.format("%.1f", new Object[] { Double.valueOf(val) }));
/* 323 */         }  s.append('\n');
/*     */       } 
/*     */     } 
/* 326 */     return s.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, Double> getFeatures() {
/* 341 */     return this.features;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Double getFeature(String feature) {
/* 354 */     return this.features.get(feature);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void putFeature(String feature, Double value) {
/* 368 */     this.features.put(feature, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double diffTo(Spot s, String feature) {
/* 387 */     double f1 = ((Double)this.features.get(feature)).doubleValue();
/* 388 */     double f2 = s.getFeature(feature).doubleValue();
/* 389 */     return f1 - f2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double normalizeDiffTo(Spot s, String feature) {
/* 415 */     double a = ((Double)this.features.get(feature)).doubleValue();
/* 416 */     double b = s.getFeature(feature).doubleValue();
/* 417 */     if (a == -b) {
/* 418 */       return 0.0D;
/*     */     }
/* 420 */     return Math.abs(a - b) / (a + b) / 2.0D;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double squareDistanceTo(RealLocalizable s) {
/* 432 */     double sumSquared = 0.0D;
/* 433 */     for (int d = 0; d < 3; d++) {
/*     */       
/* 435 */       double dx = getDoublePosition(d) - s.getDoublePosition(d);
/* 436 */       sumSquared += dx * dx;
/*     */     } 
/* 438 */     return sumSquared;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 471 */   public static final String[] POSITION_FEATURES = new String[] { "POSITION_X", "POSITION_Y", "POSITION_Z" };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 479 */   public static final Collection<String> FEATURES = new ArrayList<>(7);
/*     */ 
/*     */   
/* 482 */   public static final Map<String, String> FEATURE_NAMES = new HashMap<>(7);
/*     */ 
/*     */   
/* 485 */   public static final Map<String, String> FEATURE_SHORT_NAMES = new HashMap<>(7);
/*     */ 
/*     */   
/* 488 */   public static final Map<String, Dimension> FEATURE_DIMENSIONS = new HashMap<>(7);
/*     */ 
/*     */   
/* 491 */   public static final Map<String, Boolean> IS_INT = new HashMap<>(7);
/*     */ 
/*     */   
/*     */   static {
/* 495 */     FEATURES.add("QUALITY");
/* 496 */     FEATURES.add("POSITION_X");
/* 497 */     FEATURES.add("POSITION_Y");
/* 498 */     FEATURES.add("POSITION_Z");
/* 499 */     FEATURES.add("POSITION_T");
/* 500 */     FEATURES.add("FRAME");
/* 501 */     FEATURES.add("RADIUS");
/* 502 */     FEATURES.add("VISIBILITY");
/*     */     
/* 504 */     FEATURE_NAMES.put("POSITION_X", "X");
/* 505 */     FEATURE_NAMES.put("POSITION_Y", "Y");
/* 506 */     FEATURE_NAMES.put("POSITION_Z", "Z");
/* 507 */     FEATURE_NAMES.put("POSITION_T", "T");
/* 508 */     FEATURE_NAMES.put("FRAME", "Frame");
/* 509 */     FEATURE_NAMES.put("RADIUS", "Radius");
/* 510 */     FEATURE_NAMES.put("QUALITY", "Quality");
/* 511 */     FEATURE_NAMES.put("VISIBILITY", "Visibility");
/*     */     
/* 513 */     FEATURE_SHORT_NAMES.put("POSITION_X", "X");
/* 514 */     FEATURE_SHORT_NAMES.put("POSITION_Y", "Y");
/* 515 */     FEATURE_SHORT_NAMES.put("POSITION_Z", "Z");
/* 516 */     FEATURE_SHORT_NAMES.put("POSITION_T", "T");
/* 517 */     FEATURE_SHORT_NAMES.put("FRAME", "Frame");
/* 518 */     FEATURE_SHORT_NAMES.put("RADIUS", "R");
/* 519 */     FEATURE_SHORT_NAMES.put("QUALITY", "Quality");
/* 520 */     FEATURE_SHORT_NAMES.put("VISIBILITY", "Visibility");
/*     */     
/* 522 */     FEATURE_DIMENSIONS.put("POSITION_X", Dimension.POSITION);
/* 523 */     FEATURE_DIMENSIONS.put("POSITION_Y", Dimension.POSITION);
/* 524 */     FEATURE_DIMENSIONS.put("POSITION_Z", Dimension.POSITION);
/* 525 */     FEATURE_DIMENSIONS.put("POSITION_T", Dimension.TIME);
/* 526 */     FEATURE_DIMENSIONS.put("FRAME", Dimension.NONE);
/* 527 */     FEATURE_DIMENSIONS.put("RADIUS", Dimension.LENGTH);
/* 528 */     FEATURE_DIMENSIONS.put("QUALITY", Dimension.QUALITY);
/* 529 */     FEATURE_DIMENSIONS.put("VISIBILITY", Dimension.NONE);
/*     */     
/* 531 */     IS_INT.put("POSITION_X", Boolean.FALSE);
/* 532 */     IS_INT.put("POSITION_Y", Boolean.FALSE);
/* 533 */     IS_INT.put("POSITION_Z", Boolean.FALSE);
/* 534 */     IS_INT.put("POSITION_T", Boolean.FALSE);
/* 535 */     IS_INT.put("FRAME", Boolean.TRUE);
/* 536 */     IS_INT.put("RADIUS", Boolean.FALSE);
/* 537 */     IS_INT.put("QUALITY", Boolean.FALSE);
/* 538 */     IS_INT.put("VISIBILITY", Boolean.TRUE);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void localize(float[] position) {
/* 544 */     assert position.length >= this.n;
/* 545 */     for (int d = 0; d < this.n; d++) {
/* 546 */       position[d] = getFloatPosition(d);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void localize(double[] position) {
/* 552 */     assert position.length >= this.n;
/* 553 */     for (int d = 0; d < this.n; d++) {
/* 554 */       position[d] = getDoublePosition(d);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public float getFloatPosition(int d) {
/* 560 */     return (float)getDoublePosition(d);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public double getDoublePosition(int d) {
/* 566 */     return getFeature(POSITION_FEATURES[d]).doubleValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final Comparator<Spot> featureComparator(final String feature) {
/* 584 */     Comparator<Spot> comparator = new Comparator<Spot>()
/*     */       {
/*     */         
/*     */         public int compare(Spot o1, Spot o2)
/*     */         {
/* 589 */           double diff = o2.diffTo(o1, feature);
/* 590 */           if (diff == 0.0D)
/* 591 */             return 0; 
/* 592 */           if (diff < 0.0D) {
/* 593 */             return 1;
/*     */           }
/* 595 */           return -1;
/*     */         }
/*     */       };
/* 598 */     return comparator;
/*     */   }
/*     */ 
/*     */   
/* 602 */   public static final Comparator<Spot> timeComparator = featureComparator("POSITION_T");
/*     */ 
/*     */   
/* 605 */   public static final Comparator<Spot> frameComparator = featureComparator("FRAME");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 611 */   public static final Comparator<Spot> nameComparator = new Comparator<Spot>()
/*     */     {
/* 613 */       private final Comparator<String> comparator = AlphanumComparator.instance;
/*     */ 
/*     */ 
/*     */       
/*     */       public int compare(Spot o1, Spot o2) {
/* 618 */         return this.comparator.compare(o1.getName(), o2.getName());
/*     */       }
/*     */     };
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/Spot.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */