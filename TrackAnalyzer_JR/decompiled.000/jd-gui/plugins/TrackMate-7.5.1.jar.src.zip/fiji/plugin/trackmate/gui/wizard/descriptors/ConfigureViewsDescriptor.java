/*    */ package fiji.plugin.trackmate.gui.wizard.descriptors;
/*    */ 
/*    */ import fiji.plugin.trackmate.gui.components.ConfigureViewsPanel;
/*    */ import fiji.plugin.trackmate.gui.components.FeatureDisplaySelector;
/*    */ import fiji.plugin.trackmate.gui.displaysettings.DisplaySettings;
/*    */ import fiji.plugin.trackmate.gui.wizard.WizardPanelDescriptor;
/*    */ import java.awt.Component;
/*    */ import javax.swing.Action;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ConfigureViewsDescriptor
/*    */   extends WizardPanelDescriptor
/*    */ {
/*    */   public static final String KEY = "ConfigureViews";
/*    */   
/*    */   public ConfigureViewsDescriptor(DisplaySettings ds, FeatureDisplaySelector featureSelector, Action launchTrackSchemeAction, Action showTrackTablesAction, Action showSpotTableAction, String spaceUnits) {
/* 44 */     super("ConfigureViews");
/* 45 */     this.targetPanel = (Component)new ConfigureViewsPanel(ds, featureSelector, spaceUnits, launchTrackSchemeAction, showTrackTablesAction, showSpotTableAction);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/gui/wizard/descriptors/ConfigureViewsDescriptor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */