/*     */ package fiji.plugin.trackmate.visualization.trackscheme.utils;
/*     */ 
/*     */ import fiji.plugin.trackmate.Model;
/*     */ import fiji.plugin.trackmate.Spot;
/*     */ import fiji.plugin.trackmate.gui.Fonts;
/*     */ import fiji.plugin.trackmate.visualization.TrackMateModelView;
/*     */ import java.awt.Color;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Font;
/*     */ import java.awt.event.FocusAdapter;
/*     */ import java.awt.event.FocusEvent;
/*     */ import java.awt.event.KeyAdapter;
/*     */ import java.awt.event.KeyEvent;
/*     */ import java.awt.font.TextAttribute;
/*     */ import java.beans.PropertyChangeEvent;
/*     */ import java.beans.PropertyChangeListener;
/*     */ import java.beans.PropertyChangeSupport;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.swing.JTextField;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SearchBar
/*     */   extends JTextField
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  52 */   private static final Font NORMAL_FONT = Fonts.FONT.deriveFont(10.0F);
/*     */   
/*     */   private static final Font NOTFOUND_FONT;
/*     */ 
/*     */   
/*     */   static {
/*  58 */     Map<TextAttribute, ?> attributes = NORMAL_FONT.getAttributes();
/*  59 */     attributes.put(TextAttribute.STRIKETHROUGH, TextAttribute.STRIKETHROUGH_ON);
/*  60 */     attributes.put(TextAttribute.FOREGROUND, Color.RED.darker());
/*  61 */     NOTFOUND_FONT = new Font((Map)attributes);
/*     */   }
/*     */   
/*  64 */   private final PropertyChangeSupport observer = new PropertyChangeSupport(this);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final Model model;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final TrackMateModelView view;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SearchBar(Model model, TrackMateModelView view) {
/*  81 */     this.model = model;
/*  82 */     this.view = view;
/*  83 */     putClientProperty("JTextField.variant", "search");
/*  84 */     putClientProperty("JTextField.Search.Prompt", "Search");
/*  85 */     setPreferredSize(new Dimension(80, 25));
/*  86 */     setFont(NORMAL_FONT);
/*     */     
/*  88 */     addFocusListener(new FocusAdapter()
/*     */         {
/*     */           
/*     */           public void focusGained(FocusEvent evt)
/*     */           {
/*  93 */             SearchBar.this.searchBoxFocusGained(evt);
/*     */           }
/*     */ 
/*     */ 
/*     */           
/*     */           public void focusLost(FocusEvent evt) {
/*  99 */             SearchBar.this.searchBoxFocusLost(evt);
/*     */           }
/*     */         });
/* 102 */     addKeyListener(new KeyAdapter()
/*     */         {
/*     */           
/*     */           public void keyReleased(KeyEvent e)
/*     */           {
/* 107 */             SearchBar.this.searchBoxKey(e);
/*     */           }
/*     */         });
/* 110 */     this.observer.addPropertyChangeListener(new SearchAction());
/*     */   }
/*     */ 
/*     */   
/*     */   private void searchBoxKey(KeyEvent e) {
/* 115 */     setFont(NORMAL_FONT);
/* 116 */     if (getText().length() > 1 || e.getKeyCode() == 10)
/*     */     {
/* 118 */       this.observer.firePropertyChange("Searching started", (Object)null, getText());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void searchBoxFocusGained(FocusEvent evt) {
/* 127 */     setFont(NORMAL_FONT);
/* 128 */     setFont(getFont().deriveFont(0));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void searchBoxFocusLost(FocusEvent evt) {
/* 137 */     setFont(NORMAL_FONT);
/* 138 */     setFont(getFont().deriveFont(2));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private class SearchAction
/*     */     implements PropertyChangeListener, Iterator<Spot>
/*     */   {
/*     */     private Iterator<Spot> iterator;
/*     */ 
/*     */ 
/*     */     
/* 151 */     private Iterator<Integer> trackIterator = SearchBar.this.model.getTrackModel().trackIDs(true).iterator(); public SearchAction() {
/* 152 */       if (this.trackIterator.hasNext()) {
/*     */         
/* 154 */         Integer currentTrackID = this.trackIterator.next();
/* 155 */         Spot trackStart = firstSpotOf(currentTrackID);
/* 156 */         this.iterator = (Iterator<Spot>)SearchBar.this.model.getTrackModel().getSortedDepthFirstIterator(trackStart, Spot.nameComparator, false);
/*     */       }
/*     */       else {
/*     */         
/* 160 */         this.iterator = Collections.EMPTY_LIST.iterator();
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void propertyChange(PropertyChangeEvent evt) {
/* 167 */       String text = (String)evt.getNewValue();
/* 168 */       if (!text.isEmpty())
/*     */       {
/* 170 */         search(text);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     private void search(String text) {
/* 176 */       Spot start = null;
/*     */       Spot spot;
/* 178 */       while ((spot = next()) != start) {
/*     */         
/* 180 */         if (start == null)
/*     */         {
/* 182 */           start = spot;
/*     */         }
/* 184 */         if (spot.getName().contains(text)) {
/*     */           
/* 186 */           SearchBar.this.view.centerViewOn(spot);
/*     */           return;
/*     */         } 
/*     */       } 
/* 190 */       SearchBar.this.setFont(SearchBar.NOTFOUND_FONT);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean hasNext() {
/* 196 */       return true;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Spot next() {
/* 202 */       if (null == this.iterator || !this.iterator.hasNext()) {
/*     */         
/* 204 */         if (null == this.trackIterator || !this.trackIterator.hasNext())
/*     */         {
/* 206 */           this.trackIterator = SearchBar.this.model.getTrackModel().trackIDs(true).iterator();
/*     */         }
/* 208 */         Integer currentTrackID = this.trackIterator.next();
/* 209 */         Spot trackStart = firstSpotOf(currentTrackID);
/* 210 */         this.iterator = (Iterator<Spot>)SearchBar.this.model.getTrackModel().getSortedDepthFirstIterator(trackStart, Spot.nameComparator, false);
/*     */       } 
/* 212 */       return this.iterator.next();
/*     */     }
/*     */ 
/*     */     
/*     */     private Spot firstSpotOf(Integer trackID) {
/* 217 */       List<Spot> trackSpots = new ArrayList<>(SearchBar.this.model.getTrackModel().trackSpots(trackID));
/* 218 */       Collections.sort(trackSpots, Spot.frameComparator);
/* 219 */       return trackSpots.get(0);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void remove() {
/* 225 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/visualization/trackscheme/utils/SearchBar.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */