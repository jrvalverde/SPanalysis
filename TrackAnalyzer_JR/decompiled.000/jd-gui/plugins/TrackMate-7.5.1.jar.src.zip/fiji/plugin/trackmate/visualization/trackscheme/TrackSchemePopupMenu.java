/*     */ package fiji.plugin.trackmate.visualization.trackscheme;
/*     */ 
/*     */ import com.mxgraph.model.mxCell;
/*     */ import com.mxgraph.model.mxICell;
/*     */ import com.mxgraph.swing.mxGraphComponent;
/*     */ import com.mxgraph.util.mxEventObject;
/*     */ import com.mxgraph.util.mxEventSource;
/*     */ import fiji.plugin.trackmate.Spot;
/*     */ import java.awt.Color;
/*     */ import java.awt.Point;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.util.ArrayList;
/*     */ import java.util.EventObject;
/*     */ import javax.swing.AbstractAction;
/*     */ import javax.swing.Action;
/*     */ import javax.swing.JColorChooser;
/*     */ import javax.swing.JPopupMenu;
/*     */ import javax.swing.SwingUtilities;
/*     */ import org.jgrapht.graph.DefaultWeightedEdge;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TrackSchemePopupMenu
/*     */   extends JPopupMenu
/*     */ {
/*     */   private static final long serialVersionUID = -1L;
/*     */   private final Object cell;
/*     */   private final TrackScheme trackScheme;
/*     */   private final Point point;
/*  65 */   private static Color previousColor = Color.RED;
/*     */ 
/*     */   
/*     */   public TrackSchemePopupMenu(TrackScheme trackScheme, Object cell, Point point) {
/*  69 */     this.trackScheme = trackScheme;
/*  70 */     this.cell = cell;
/*  71 */     this.point = point;
/*  72 */     init();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void manualColorEdges(ArrayList<mxCell> edges) {
/*  81 */     for (mxCell mxCell : edges) {
/*     */       
/*  83 */       DefaultWeightedEdge edge = this.trackScheme.getGraph().getEdgeFor((mxICell)mxCell);
/*  84 */       Double value = Double.valueOf(previousColor.getRGB());
/*  85 */       this.trackScheme.getModel().getFeatureModel().putEdgeFeature(edge, "MANUAL_EGE_COLOR", value);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void manualColorVertices(ArrayList<mxCell> vertices) {
/*  91 */     for (mxCell mxCell : vertices) {
/*     */       
/*  93 */       Spot spot = this.trackScheme.getGraph().getSpotFor((mxICell)mxCell);
/*  94 */       Double value = Double.valueOf(previousColor.getRGB());
/*  95 */       spot.putFeature("MANUAL_SPOT_COLOR", value);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void selectWholeTrack(ArrayList<mxCell> vertices, ArrayList<mxCell> edges) {
/* 102 */     this.trackScheme.selectTrack(vertices, edges, 0);
/*     */   }
/*     */ 
/*     */   
/*     */   private void selectTrackDownwards(ArrayList<mxCell> vertices, ArrayList<mxCell> edges) {
/* 107 */     this.trackScheme.selectTrack(vertices, edges, -1);
/*     */   }
/*     */ 
/*     */   
/*     */   private void selectTrackUpwards(ArrayList<mxCell> vertices, ArrayList<mxCell> edges) {
/* 112 */     this.trackScheme.selectTrack(vertices, edges, 1);
/*     */   }
/*     */ 
/*     */   
/*     */   private void editSpotName() {
/* 117 */     (this.trackScheme.getGUI()).graphComponent.startEditingAtCell(this.cell);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void toggleBranchFolding() {
/*     */     Object parent;
/* 124 */     if (this.trackScheme.getGraph().isCellFoldable(this.cell, true)) {
/*     */       
/* 126 */       parent = this.cell;
/*     */     }
/*     */     else {
/*     */       
/* 130 */       parent = this.trackScheme.getGraph().getModel().getParent(this.cell);
/*     */     } 
/* 132 */     this.trackScheme.getGraph().foldCells(!this.trackScheme.getGraph().isCellCollapsed(parent), false, new Object[] { parent });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void multiEditSpotName(final ArrayList<mxCell> vertices, EventObject triggerEvent) {
/* 145 */     final mxCell tc = getClosestCell(vertices);
/* 146 */     vertices.remove(tc);
/* 147 */     final mxGraphComponent graphComponent = (this.trackScheme.getGUI()).graphComponent;
/* 148 */     graphComponent.startEditingAtCell(tc, triggerEvent);
/* 149 */     graphComponent.addListener("labelChanged", new mxEventSource.mxIEventListener()
/*     */         {
/*     */ 
/*     */           
/*     */           public void invoke(Object sender, mxEventObject evt)
/*     */           {
/* 155 */             for (mxCell lCell : vertices) {
/*     */               
/* 157 */               lCell.setValue(tc.getValue());
/* 158 */               TrackSchemePopupMenu.this.trackScheme.getGraph().getSpotFor((mxICell)lCell).setName(tc.getValue().toString());
/*     */             } 
/* 160 */             graphComponent.refresh();
/* 161 */             graphComponent.removeListener(this);
/*     */           }
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private mxCell getClosestCell(Iterable<mxCell> vertices) {
/* 172 */     double min_dist = Double.POSITIVE_INFINITY;
/* 173 */     mxCell target_cell = null;
/* 174 */     for (mxCell lCell : vertices) {
/*     */       
/* 176 */       Point location = lCell.getGeometry().getPoint();
/* 177 */       double dist = location.distanceSq(this.point);
/* 178 */       if (dist < min_dist) {
/*     */         
/* 180 */         min_dist = dist;
/* 181 */         target_cell = lCell;
/*     */       } 
/*     */     } 
/* 184 */     return target_cell;
/*     */   }
/*     */ 
/*     */   
/*     */   private void linkSpots() {
/* 189 */     this.trackScheme.linkSpots();
/*     */   }
/*     */ 
/*     */   
/*     */   private void remove() {
/* 194 */     this.trackScheme.removeSelectedCells();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void init() {
/* 206 */     Object[] selection = this.trackScheme.getGraph().getSelectionCells();
/* 207 */     final ArrayList<mxCell> vertices = new ArrayList<>();
/* 208 */     final ArrayList<mxCell> edges = new ArrayList<>();
/* 209 */     for (Object obj : selection) {
/*     */       
/* 211 */       mxCell lCell = (mxCell)obj;
/* 212 */       if (lCell.isVertex()) {
/* 213 */         vertices.add(lCell);
/* 214 */       } else if (lCell.isEdge()) {
/* 215 */         edges.add(lCell);
/*     */       } 
/*     */     } 
/*     */     
/* 219 */     if (vertices.size() > 0 || edges.size() > 0) {
/*     */ 
/*     */       
/* 222 */       add(new AbstractAction("Select whole track")
/*     */           {
/*     */             
/*     */             public void actionPerformed(ActionEvent e)
/*     */             {
/* 227 */               TrackSchemePopupMenu.this.selectWholeTrack(vertices, edges);
/*     */             }
/*     */           });
/*     */       
/* 231 */       add(new AbstractAction("Select track downwards")
/*     */           {
/*     */             
/*     */             public void actionPerformed(ActionEvent e)
/*     */             {
/* 236 */               TrackSchemePopupMenu.this.selectTrackDownwards(vertices, edges);
/*     */             }
/*     */           });
/*     */       
/* 240 */       add(new AbstractAction("Select track upwards")
/*     */           {
/*     */             
/*     */             public void actionPerformed(ActionEvent e)
/*     */             {
/* 245 */               TrackSchemePopupMenu.this.selectTrackUpwards(vertices, edges);
/*     */             }
/*     */           });
/*     */     } 
/*     */     
/* 250 */     if (this.cell != null) {
/*     */ 
/*     */       
/* 253 */       add(new AbstractAction("Edit spot name")
/*     */           {
/*     */             
/*     */             public void actionPerformed(ActionEvent e)
/*     */             {
/* 258 */               TrackSchemePopupMenu.this.editSpotName();
/*     */             }
/*     */           });
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */       
/* 266 */       if (vertices.size() > 1)
/*     */       {
/*     */ 
/*     */         
/* 270 */         add(new AbstractAction("Edit " + vertices.size() + " spot names")
/*     */             {
/*     */               
/*     */               public void actionPerformed(ActionEvent e)
/*     */               {
/* 275 */                 TrackSchemePopupMenu.this.multiEditSpotName(vertices, e);
/*     */               }
/*     */             });
/*     */       }
/*     */ 
/*     */       
/* 281 */       Action linkAction = new AbstractAction("Link " + this.trackScheme.getSelectionModel().getSpotSelection().size() + " spots")
/*     */         {
/*     */           
/*     */           public void actionPerformed(ActionEvent e)
/*     */           {
/* 286 */             TrackSchemePopupMenu.this.linkSpots();
/*     */           }
/*     */         };
/* 289 */       if (this.trackScheme.getSelectionModel().getSpotSelection().size() > 1)
/*     */       {
/* 291 */         add(linkAction);
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 299 */     if (edges.size() > 0 || vertices.size() > 0)
/*     */     {
/* 301 */       addSeparator();
/*     */     }
/*     */     
/* 304 */     if (vertices.size() > 0) {
/*     */       
/* 306 */       String str = "Manual color for " + ((vertices.size() == 1) ? " one spot" : (vertices.size() + " spots"));
/* 307 */       add(new AbstractAction(str)
/*     */           {
/*     */             
/*     */             public void actionPerformed(ActionEvent e)
/*     */             {
/* 312 */               TrackSchemePopupMenu.previousColor = JColorChooser.showDialog(TrackSchemePopupMenu.this.trackScheme.getGUI(), "Choose Color", TrackSchemePopupMenu.previousColor);
/* 313 */               TrackSchemePopupMenu.this.manualColorVertices(vertices);
/* 314 */               SwingUtilities.invokeLater(new Runnable()
/*     */                   {
/*     */                     
/*     */                     public void run()
/*     */                     {
/* 319 */                       TrackSchemePopupMenu.this.trackScheme.doTrackStyle();
/*     */                     }
/*     */                   });
/*     */             }
/*     */           });
/*     */     } 
/*     */     
/* 326 */     if (edges.size() > 0) {
/*     */       
/* 328 */       String str = "Manual color for " + ((edges.size() == 1) ? " one edge" : (edges.size() + " edges"));
/* 329 */       add(new AbstractAction(str)
/*     */           {
/*     */             
/*     */             public void actionPerformed(ActionEvent e)
/*     */             {
/* 334 */               TrackSchemePopupMenu.previousColor = JColorChooser.showDialog(TrackSchemePopupMenu.this.trackScheme.getGUI(), "Choose Color", TrackSchemePopupMenu.previousColor);
/* 335 */               TrackSchemePopupMenu.this.manualColorEdges(edges);
/* 336 */               SwingUtilities.invokeLater(new Runnable()
/*     */                   {
/*     */                     
/*     */                     public void run()
/*     */                     {
/* 341 */                       TrackSchemePopupMenu.this.trackScheme.doTrackStyle();
/*     */                     }
/*     */                   });
/*     */             }
/*     */           });
/*     */     } 
/*     */ 
/*     */     
/* 349 */     if (edges.size() > 0 && vertices.size() > 0) {
/*     */       
/* 351 */       String str = "Manual color for " + ((vertices.size() == 1) ? " one spot and " : (vertices.size() + " spots and ")) + ((edges.size() == 1) ? " one edge" : (edges.size() + " edges"));
/* 352 */       add(new AbstractAction(str)
/*     */           {
/*     */             
/*     */             public void actionPerformed(ActionEvent e)
/*     */             {
/* 357 */               TrackSchemePopupMenu.previousColor = JColorChooser.showDialog(TrackSchemePopupMenu.this.trackScheme.getGUI(), "Choose Color", TrackSchemePopupMenu.previousColor);
/* 358 */               TrackSchemePopupMenu.this.manualColorVertices(vertices);
/* 359 */               TrackSchemePopupMenu.this.manualColorEdges(edges);
/* 360 */               SwingUtilities.invokeLater(new Runnable()
/*     */                   {
/*     */                     
/*     */                     public void run()
/*     */                     {
/* 365 */                       TrackSchemePopupMenu.this.trackScheme.doTrackStyle();
/*     */                     }
/*     */                   });
/*     */             }
/*     */           });
/*     */     } 
/*     */ 
/*     */     
/* 373 */     add(new AbstractAction("Clear manual color of selection")
/*     */         {
/*     */           
/*     */           public void actionPerformed(ActionEvent e)
/*     */           {
/* 378 */             for (mxCell mxCell : vertices) {
/*     */               
/* 380 */               Spot spot = TrackSchemePopupMenu.this.trackScheme.getGraph().getSpotFor((mxICell)mxCell);
/* 381 */               spot.getFeatures().remove("MANUAL_SPOT_COLOR");
/*     */             } 
/* 383 */             for (mxCell mxCell : edges) {
/*     */               
/* 385 */               DefaultWeightedEdge edge = TrackSchemePopupMenu.this.trackScheme.getGraph().getEdgeFor((mxICell)mxCell);
/* 386 */               TrackSchemePopupMenu.this.trackScheme.getModel().getFeatureModel().removeEdgeFeature(edge, "MANUAL_EGE_COLOR");
/*     */             } 
/*     */             
/* 389 */             SwingUtilities.invokeLater(new Runnable()
/*     */                 {
/*     */                   
/*     */                   public void run()
/*     */                   {
/* 394 */                     TrackSchemePopupMenu.this.trackScheme.doTrackStyle();
/*     */                   }
/*     */                 });
/*     */           }
/*     */         });
/*     */ 
/*     */ 
/*     */     
/* 402 */     if (selection.length > 0) {
/*     */       
/* 404 */       addSeparator();
/* 405 */       Action removeAction = new AbstractAction("Remove spots and links")
/*     */         {
/*     */           
/*     */           public void actionPerformed(ActionEvent e)
/*     */           {
/* 410 */             TrackSchemePopupMenu.this.remove();
/*     */           }
/*     */         };
/* 413 */       add(removeAction);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/visualization/trackscheme/TrackSchemePopupMenu.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */