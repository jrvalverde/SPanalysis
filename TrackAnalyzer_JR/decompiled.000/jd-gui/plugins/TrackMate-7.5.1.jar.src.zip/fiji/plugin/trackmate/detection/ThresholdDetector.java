/*     */ package fiji.plugin.trackmate.detection;
/*     */ 
/*     */ import fiji.plugin.trackmate.Spot;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import net.imglib2.Interval;
/*     */ import net.imglib2.RandomAccessible;
/*     */ import net.imglib2.algorithm.MultiThreaded;
/*     */ import net.imglib2.type.NativeType;
/*     */ import net.imglib2.type.numeric.RealType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ThresholdDetector<T extends RealType<T> & NativeType<T>>
/*     */   implements SpotDetector<T>, MultiThreaded
/*     */ {
/*     */   private static final String BASE_ERROR_MESSAGE = "ThresholdDetector: ";
/*     */   protected RandomAccessible<T> input;
/*  46 */   protected String baseErrorMessage = "ThresholdDetector: ";
/*     */ 
/*     */   
/*     */   protected String errorMessage;
/*     */   
/*  51 */   protected List<Spot> spots = new ArrayList<>();
/*     */ 
/*     */ 
/*     */   
/*     */   protected long processingTime;
/*     */ 
/*     */ 
/*     */   
/*     */   protected int numThreads;
/*     */ 
/*     */ 
/*     */   
/*     */   protected final Interval interval;
/*     */ 
/*     */ 
/*     */   
/*     */   protected final double[] calibration;
/*     */ 
/*     */ 
/*     */   
/*     */   protected final double threshold;
/*     */ 
/*     */ 
/*     */   
/*     */   protected final boolean simplify;
/*     */ 
/*     */ 
/*     */   
/*     */   public ThresholdDetector(RandomAccessible<T> input, Interval interval, double[] calibration, double threshold, boolean simplify) {
/*  80 */     this.input = input;
/*  81 */     this.interval = DetectionUtils.squeeze(interval);
/*  82 */     this.calibration = calibration;
/*  83 */     this.threshold = threshold;
/*  84 */     this.simplify = simplify;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Spot> getResult() {
/*  90 */     return this.spots;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean checkInput() {
/*  96 */     if (null == this.input) {
/*     */       
/*  98 */       this.errorMessage = this.baseErrorMessage + "Image is null.";
/*  99 */       return false;
/*     */     } 
/* 101 */     if (this.input.numDimensions() > 3 || this.input.numDimensions() < 2) {
/*     */       
/* 103 */       this.errorMessage = this.baseErrorMessage + "Image must be 2D or 3D, got " + this.input.numDimensions() + "D.";
/* 104 */       return false;
/*     */     } 
/* 106 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean process() {
/* 112 */     long start = System.currentTimeMillis();
/* 113 */     if (this.input.numDimensions() == 2) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 118 */       this.spots = MaskUtils.fromThresholdWithROI(this.input, this.interval, this.calibration, this.threshold, this.simplify, this.numThreads, null);
/*     */     
/*     */     }
/* 121 */     else if (this.input.numDimensions() == 3) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 126 */       this.spots = MaskUtils.fromThreshold(this.input, this.interval, this.calibration, this.threshold, this.numThreads);
/*     */     }
/*     */     else {
/*     */       
/* 130 */       this.errorMessage = this.baseErrorMessage + "Required a 2D or 3D input, got " + this.input.numDimensions() + "D.";
/* 131 */       return false;
/*     */     } 
/*     */     
/* 134 */     long end = System.currentTimeMillis();
/* 135 */     this.processingTime = end - start;
/*     */     
/* 137 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getErrorMessage() {
/* 143 */     return this.errorMessage;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public long getProcessingTime() {
/* 149 */     return this.processingTime;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setNumThreads() {
/* 155 */     this.numThreads = Runtime.getRuntime().availableProcessors();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setNumThreads(int numThreads) {
/* 161 */     this.numThreads = numThreads;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getNumThreads() {
/* 167 */     return this.numThreads;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/detection/ThresholdDetector.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */