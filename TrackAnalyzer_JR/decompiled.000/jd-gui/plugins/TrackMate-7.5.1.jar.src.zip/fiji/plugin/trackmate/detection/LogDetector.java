/*     */ package fiji.plugin.trackmate.detection;
/*     */ 
/*     */ import fiji.plugin.trackmate.Spot;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.Executors;
/*     */ import net.imglib2.Dimensions;
/*     */ import net.imglib2.FinalInterval;
/*     */ import net.imglib2.Interval;
/*     */ import net.imglib2.RandomAccessible;
/*     */ import net.imglib2.RandomAccessibleInterval;
/*     */ import net.imglib2.algorithm.MultiThreaded;
/*     */ import net.imglib2.algorithm.fft2.FFTConvolution;
/*     */ import net.imglib2.img.Img;
/*     */ import net.imglib2.img.ImgFactory;
/*     */ import net.imglib2.type.NativeType;
/*     */ import net.imglib2.type.numeric.RealType;
/*     */ import net.imglib2.type.numeric.complex.ComplexFloatType;
/*     */ import net.imglib2.type.numeric.real.FloatType;
/*     */ import net.imglib2.util.Intervals;
/*     */ import net.imglib2.util.Util;
/*     */ import net.imglib2.view.IntervalView;
/*     */ import net.imglib2.view.Views;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LogDetector<T extends RealType<T> & NativeType<T>>
/*     */   implements SpotDetector<T>, MultiThreaded
/*     */ {
/*     */   private static final String BASE_ERROR_MESSAGE = "LogDetector: ";
/*     */   protected RandomAccessible<T> img;
/*     */   protected double radius;
/*     */   protected double threshold;
/*     */   protected boolean doSubPixelLocalization;
/*     */   protected boolean doMedianFilter;
/*     */   protected String baseErrorMessage;
/*     */   protected String errorMessage;
/*  70 */   protected List<Spot> spots = new ArrayList<>();
/*     */ 
/*     */   
/*     */   protected long processingTime;
/*     */ 
/*     */   
/*     */   protected int numThreads;
/*     */ 
/*     */   
/*     */   protected final Interval interval;
/*     */ 
/*     */   
/*     */   protected final double[] calibration;
/*     */ 
/*     */ 
/*     */   
/*     */   public LogDetector(RandomAccessible<T> img, Interval interval, double[] calibration, double radius, double threshold, boolean doSubPixelLocalization, boolean doMedianFilter) {
/*  87 */     this.img = img;
/*  88 */     this.interval = DetectionUtils.squeeze(interval);
/*  89 */     this.calibration = calibration;
/*  90 */     this.radius = radius;
/*  91 */     this.threshold = threshold;
/*  92 */     this.doSubPixelLocalization = doSubPixelLocalization;
/*  93 */     this.doMedianFilter = doMedianFilter;
/*  94 */     this.baseErrorMessage = "LogDetector: ";
/*  95 */     setNumThreads();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean checkInput() {
/* 105 */     if (null == this.img) {
/*     */       
/* 107 */       this.errorMessage = this.baseErrorMessage + "Image is null.";
/* 108 */       return false;
/*     */     } 
/* 110 */     if (this.img.numDimensions() > 3) {
/*     */       
/* 112 */       this.errorMessage = this.baseErrorMessage + "Image must be 1D, 2D or 3D, got " + this.img.numDimensions() + "D.";
/* 113 */       return false;
/*     */     } 
/* 115 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean process() {
/*     */     FinalInterval finalInterval;
/* 121 */     long start = System.currentTimeMillis();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 127 */     ImgFactory<FloatType> factory = Util.getArrayOrCellImgFactory((Dimensions)this.interval, (NativeType)new FloatType());
/* 128 */     Img<FloatType> floatImg = DetectionUtils.copyToFloatImg(this.img, this.interval, factory);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 134 */     if (this.doMedianFilter) {
/*     */       
/* 136 */       floatImg = DetectionUtils.applyMedianFilter((RandomAccessibleInterval<FloatType>)floatImg);
/* 137 */       if (null == floatImg) {
/*     */         
/* 139 */         this.errorMessage = "LogDetector: Failed to apply median filter.";
/* 140 */         return false;
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 146 */     int ndims = this.interval.numDimensions();
/* 147 */     for (int d = 0; d < this.interval.numDimensions(); d++) {
/* 148 */       if (this.interval.dimension(d) <= 1L)
/* 149 */         ndims--; 
/*     */     } 
/* 151 */     Img<FloatType> kernel = DetectionUtils.createLoGKernel(this.radius, ndims, this.calibration);
/* 152 */     FFTConvolution<FloatType> fftconv = new FFTConvolution(floatImg, kernel);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 157 */     Img<FloatType> img1 = floatImg;
/* 158 */     for (int i = 0; i < kernel.numDimensions(); i++)
/* 159 */       finalInterval = Intervals.expand((Interval)img1, kernel.dimension(i), i); 
/* 160 */     ImgFactory<ComplexFloatType> imgFactory = Util.getArrayOrCellImgFactory((Dimensions)finalInterval, (NativeType)new ComplexFloatType());
/* 161 */     fftconv.setFFTImgFactory(imgFactory);
/*     */     
/* 163 */     ExecutorService service = Executors.newFixedThreadPool(this.numThreads);
/* 164 */     fftconv.setExecutorService(service);
/*     */     
/* 166 */     fftconv.convolve();
/* 167 */     service.shutdown();
/*     */     
/* 169 */     long[] minopposite = new long[this.interval.numDimensions()];
/* 170 */     this.interval.min(minopposite);
/* 171 */     IntervalView<FloatType> to = Views.translate((RandomAccessibleInterval)floatImg, minopposite);
/* 172 */     this.spots = DetectionUtils.findLocalMaxima((RandomAccessibleInterval<FloatType>)to, this.threshold, this.calibration, this.radius, this.doSubPixelLocalization, this.numThreads);
/*     */     
/* 174 */     long end = System.currentTimeMillis();
/* 175 */     this.processingTime = end - start;
/*     */     
/* 177 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Spot> getResult() {
/* 183 */     return this.spots;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getErrorMessage() {
/* 189 */     return this.errorMessage;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public long getProcessingTime() {
/* 195 */     return this.processingTime;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setNumThreads() {
/* 201 */     this.numThreads = Runtime.getRuntime().availableProcessors();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setNumThreads(int numThreads) {
/* 207 */     this.numThreads = numThreads;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getNumThreads() {
/* 213 */     return this.numThreads;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/detection/LogDetector.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */