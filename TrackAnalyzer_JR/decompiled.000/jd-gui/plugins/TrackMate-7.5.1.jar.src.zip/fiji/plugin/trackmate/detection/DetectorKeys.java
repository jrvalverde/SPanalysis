package fiji.plugin.trackmate.detection;

public class DetectorKeys {
  public static final String XML_ATTRIBUTE_DETECTOR_NAME = "DETECTOR_NAME";
  
  public static final String KEY_TARGET_CHANNEL = "TARGET_CHANNEL";
  
  public static final int DEFAULT_TARGET_CHANNEL = 1;
  
  public static final String KEY_RADIUS = "RADIUS";
  
  public static final double DEFAULT_RADIUS = 5.0D;
  
  public static final String KEY_THRESHOLD = "THRESHOLD";
  
  public static final double DEFAULT_THRESHOLD = 0.0D;
  
  public static final String KEY_DOWNSAMPLE_FACTOR = "DOWNSAMPLE_FACTOR";
  
  public static final int DEFAULT_DOWNSAMPLE_FACTOR = 4;
  
  public static final String KEY_DO_MEDIAN_FILTERING = "DO_MEDIAN_FILTERING";
  
  public static final boolean DEFAULT_DO_MEDIAN_FILTERING = false;
  
  public static final String KEY_DO_SUBPIXEL_LOCALIZATION = "DO_SUBPIXEL_LOCALIZATION";
  
  public static final boolean DEFAULT_DO_SUBPIXEL_LOCALIZATION = true;
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/detection/DetectorKeys.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */