/*     */ package fiji.plugin.trackmate.features;
/*     */ 
/*     */ import fiji.plugin.trackmate.Model;
/*     */ import fiji.plugin.trackmate.SelectionModel;
/*     */ import fiji.plugin.trackmate.Spot;
/*     */ import fiji.plugin.trackmate.TrackModel;
/*     */ import fiji.plugin.trackmate.gui.displaysettings.DisplaySettings;
/*     */ import fiji.plugin.trackmate.visualization.FeatureColorGenerator;
/*     */ import java.awt.Color;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.Paint;
/*     */ import java.awt.Stroke;
/*     */ import java.awt.geom.Rectangle2D;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.jfree.chart.LegendItem;
/*     */ import org.jfree.chart.axis.ValueAxis;
/*     */ import org.jfree.chart.plot.PlotOrientation;
/*     */ import org.jfree.chart.plot.XYPlot;
/*     */ import org.jfree.chart.renderer.xy.XYItemRenderer;
/*     */ import org.jfree.chart.renderer.xy.XYItemRendererState;
/*     */ import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
/*     */ import org.jfree.chart.ui.RectangleEdge;
/*     */ import org.jfree.chart.util.LineUtils;
/*     */ import org.jfree.data.xy.XYDataset;
/*     */ import org.jgrapht.graph.DefaultWeightedEdge;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SpotCollectionDataset
/*     */   extends ModelDataset
/*     */   implements XYDataset
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private final List<Spot> spots;
/*     */   private final Map<Integer, Set<DefaultWeightedEdge>> edgeMap;
/*     */   
/*     */   public SpotCollectionDataset(Model model, SelectionModel selectionModel, DisplaySettings ds, String xFeature, List<String> yFeatures, List<Spot> spots, boolean addLines) {
/*  72 */     super(model, selectionModel, ds, xFeature, yFeatures);
/*  73 */     this.spots = spots;
/*  74 */     this.edgeMap = addLines ? createEdgeMap(spots, model.getTrackModel()) : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Map<Integer, Set<DefaultWeightedEdge>> createEdgeMap(List<Spot> spots, TrackModel trackModel) {
/*  88 */     Map<Integer, Set<DefaultWeightedEdge>> edgeMap = new HashMap<>();
/*  89 */     for (int i = 0; i < spots.size(); i++) {
/*     */       
/*  91 */       Spot source = spots.get(i);
/*  92 */       Set<DefaultWeightedEdge> edges = new HashSet<>();
/*  93 */       for (Spot target : spots) {
/*     */         
/*  95 */         if (source.getFeature("FRAME").intValue() > target.getFeature("FRAME").intValue()) {
/*     */           continue;
/*     */         }
/*  98 */         if (!trackModel.containsEdge(source, target)) {
/*     */           continue;
/*     */         }
/* 101 */         edges.add(trackModel.getEdge(source, target));
/*     */       } 
/* 103 */       if (!edges.isEmpty())
/* 104 */         edgeMap.put(Integer.valueOf(i), edges); 
/*     */     } 
/* 106 */     return edgeMap;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getItemCount(int series) {
/* 112 */     return this.spots.size();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getItemLabel(int item) {
/* 118 */     return ((Spot)this.spots.get(item)).getName();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setItemLabel(int item, String label) {
/* 124 */     ((Spot)this.spots.get(item)).setName(label);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getSeriesKey(int series) {
/* 130 */     if (series < 0 || series >= getSeriesCount())
/* 131 */       throw new IllegalArgumentException("Series index out of bounds"); 
/* 132 */     return (String)this.model.getFeatureModel().getSpotFeatureShortNames().get(this.yFeatures.get(series));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Number getX(int series, int item) {
/* 138 */     return ((Spot)this.spots.get(item)).getFeature(this.xFeature);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Number getY(int series, int item) {
/* 144 */     return ((Spot)this.spots.get(item)).getFeature(this.yFeatures.get(series));
/*     */   }
/*     */ 
/*     */   
/*     */   public XYItemRenderer getRenderer() {
/* 149 */     return (XYItemRenderer)new MyXYItemRenderer();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final class MyXYItemRenderer
/*     */     extends XYLineAndShapeRenderer
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private MyXYItemRenderer() {}
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected void drawPrimaryLine(XYItemRendererState state, Graphics2D g2, XYPlot plot, XYDataset dataset, int pass, int series, int item, ValueAxis domainAxis, ValueAxis rangeAxis, Rectangle2D dataArea) {
/* 170 */       if (SpotCollectionDataset.this.edgeMap == null || !SpotCollectionDataset.this.edgeMap.containsKey(Integer.valueOf(item))) {
/*     */         return;
/*     */       }
/* 173 */       RectangleEdge xAxisLocation = plot.getDomainAxisEdge();
/* 174 */       RectangleEdge yAxisLocation = plot.getRangeAxisEdge();
/* 175 */       PlotOrientation orientation = plot.getOrientation();
/* 176 */       String yFeature = SpotCollectionDataset.this.yFeatures.get(series);
/* 177 */       Spot sourceSpot = SpotCollectionDataset.this.spots.get(item);
/* 178 */       Set<DefaultWeightedEdge> edges = (Set<DefaultWeightedEdge>)SpotCollectionDataset.this.edgeMap.get(Integer.valueOf(item));
/* 179 */       for (DefaultWeightedEdge edge : edges) {
/*     */         
/* 181 */         Spot targetSpot = SpotCollectionDataset.this.model.getTrackModel().getEdgeTarget(edge);
/*     */         
/* 183 */         Double x1 = targetSpot.getFeature(SpotCollectionDataset.this.xFeature);
/* 184 */         Double y1 = targetSpot.getFeature(yFeature);
/* 185 */         if (x1 == null || y1 == null || x1.isNaN() || y1.isNaN()) {
/*     */           continue;
/*     */         }
/* 188 */         Double x0 = sourceSpot.getFeature(SpotCollectionDataset.this.xFeature);
/* 189 */         Double y0 = sourceSpot.getFeature(yFeature);
/* 190 */         if (x0 == null || y0 == null || x0.isNaN() || y0.isNaN()) {
/*     */           continue;
/*     */         }
/*     */         
/* 194 */         double transX0 = domainAxis.valueToJava2D(x0.doubleValue(), dataArea, xAxisLocation);
/* 195 */         double transY0 = rangeAxis.valueToJava2D(y0.doubleValue(), dataArea, yAxisLocation);
/*     */         
/* 197 */         double transX1 = domainAxis.valueToJava2D(x1.doubleValue(), dataArea, xAxisLocation);
/* 198 */         double transY1 = rangeAxis.valueToJava2D(y1.doubleValue(), dataArea, yAxisLocation);
/*     */         
/* 200 */         if (Double.isNaN(transX0) || Double.isNaN(transY0) || Double.isNaN(transX1) || Double.isNaN(transY1)) {
/*     */           continue;
/*     */         }
/* 203 */         if (orientation == PlotOrientation.HORIZONTAL) {
/* 204 */           state.workingLine.setLine(transY0, transX0, transY1, transX1);
/* 205 */         } else if (orientation == PlotOrientation.VERTICAL) {
/* 206 */           state.workingLine.setLine(transX0, transY0, transX1, transY1);
/* 207 */         }  boolean visible = LineUtils.clipLine(state.workingLine, dataArea);
/* 208 */         if (visible) {
/* 209 */           drawFirstPassShape(g2, pass, series, item, state.workingLine);
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public Paint getItemPaint(int series, int item) {
/* 216 */       Spot spot = SpotCollectionDataset.this.spots.get(item);
/* 217 */       if (SpotCollectionDataset.this.selectionModel != null && SpotCollectionDataset.this.selectionModel.getSpotSelection().contains(spot)) {
/* 218 */         return SpotCollectionDataset.this.ds.getHighlightColor();
/*     */       }
/* 220 */       FeatureColorGenerator<Spot> spotColorGenerator = FeatureUtils.createSpotColorGenerator(SpotCollectionDataset.this.model, SpotCollectionDataset.this.ds);
/* 221 */       return spotColorGenerator.color(SpotCollectionDataset.this.spots.get(item));
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Stroke getItemStroke(int series, int item) {
/* 227 */       Spot spot = SpotCollectionDataset.this.spots.get(item);
/* 228 */       if (SpotCollectionDataset.this.selectionModel != null && SpotCollectionDataset.this.selectionModel.getSpotSelection().contains(spot))
/* 229 */         return SpotCollectionDataset.this.selectionStroke; 
/* 230 */       return SpotCollectionDataset.this.stroke;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public LegendItem getLegendItem(int datasetIndex, int series) {
/* 236 */       LegendItem legendItem = super.getLegendItem(datasetIndex, series);
/* 237 */       legendItem.setFillPaint(Color.BLACK);
/* 238 */       legendItem.setLinePaint(Color.BLACK);
/* 239 */       legendItem.setOutlinePaint(Color.BLACK);
/* 240 */       return legendItem;
/*     */     }
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/features/SpotCollectionDataset.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */