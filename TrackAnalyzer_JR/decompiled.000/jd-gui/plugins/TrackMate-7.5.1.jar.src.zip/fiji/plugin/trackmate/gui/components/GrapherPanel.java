/*     */ package fiji.plugin.trackmate.gui.components;
/*     */ 
/*     */ import fiji.plugin.trackmate.SelectionModel;
/*     */ import fiji.plugin.trackmate.Spot;
/*     */ import fiji.plugin.trackmate.TrackMate;
/*     */ import fiji.plugin.trackmate.features.EdgeFeatureGrapher;
/*     */ import fiji.plugin.trackmate.features.FeatureUtils;
/*     */ import fiji.plugin.trackmate.features.SpotFeatureGrapher;
/*     */ import fiji.plugin.trackmate.features.TrackFeatureGrapher;
/*     */ import fiji.plugin.trackmate.gui.GuiUtils;
/*     */ import fiji.plugin.trackmate.gui.Icons;
/*     */ import fiji.plugin.trackmate.gui.displaysettings.DisplaySettings;
/*     */ import fiji.plugin.trackmate.util.EverythingDisablerAndReenabler;
/*     */ import java.awt.BorderLayout;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javax.swing.BoxLayout;
/*     */ import javax.swing.ButtonGroup;
/*     */ import javax.swing.JCheckBox;
/*     */ import javax.swing.JFrame;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JRadioButton;
/*     */ import javax.swing.JSeparator;
/*     */ import javax.swing.JTabbedPane;
/*     */ import javax.swing.SwingUtilities;
/*     */ import org.jgrapht.graph.DefaultWeightedEdge;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GrapherPanel
/*     */   extends JPanel
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private final TrackMate trackmate;
/*     */   private final JPanel panelSpot;
/*     */   private final JPanel panelEdges;
/*     */   private final JPanel panelTracks;
/*     */   private final FeaturePlotSelectionPanel spotFeatureSelectionPanel;
/*     */   private final FeaturePlotSelectionPanel edgeFeatureSelectionPanel;
/*     */   private final FeaturePlotSelectionPanel trackFeatureSelectionPanel;
/*     */   private final DisplaySettings displaySettings;
/*     */   private final SelectionModel selectionModel;
/*     */   private final JPanel panelSelection;
/*     */   private final JRadioButton rdbtnAll;
/*     */   private final JRadioButton rdbtnSelection;
/*     */   private final JRadioButton rdbtnTracks;
/*     */   private final JCheckBox chkboxConnectDots;
/*     */   
/*     */   public GrapherPanel(TrackMate trackmate, SelectionModel selectionModel, DisplaySettings displaySettings) {
/* 101 */     this.trackmate = trackmate;
/* 102 */     this.selectionModel = selectionModel;
/* 103 */     this.displaySettings = displaySettings;
/*     */     
/* 105 */     setLayout(new BorderLayout(0, 0));
/*     */     
/* 107 */     JTabbedPane tabbedPane = new JTabbedPane(1);
/* 108 */     add(tabbedPane, "Center");
/*     */     
/* 110 */     this.panelSpot = new JPanel();
/* 111 */     tabbedPane.addTab("Spots", Icons.SPOT_ICON_64x64, this.panelSpot, null);
/* 112 */     this.panelSpot.setLayout(new BorderLayout(0, 0));
/*     */     
/* 114 */     this.panelEdges = new JPanel();
/* 115 */     tabbedPane.addTab("Links", Icons.EDGE_ICON_64x64, this.panelEdges, null);
/* 116 */     this.panelEdges.setLayout(new BorderLayout(0, 0));
/*     */     
/* 118 */     this.panelTracks = new JPanel();
/* 119 */     tabbedPane.addTab("Tracks", Icons.TRACK_ICON_64x64, this.panelTracks, null);
/* 120 */     this.panelTracks.setLayout(new BorderLayout(0, 0));
/*     */     
/* 122 */     Map<String, String> spotFeatureNames = FeatureUtils.collectFeatureKeys(DisplaySettings.TrackMateObject.SPOTS, trackmate.getModel(), trackmate.getSettings());
/* 123 */     Set<String> spotFeatures = spotFeatureNames.keySet();
/* 124 */     this.spotFeatureSelectionPanel = new FeaturePlotSelectionPanel("T", "Mean intensity ch1", spotFeatures, spotFeatureNames, (xKey, yKeys) -> (new Thread(())).start());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 130 */     this.panelSpot.add(this.spotFeatureSelectionPanel);
/*     */ 
/*     */     
/* 133 */     this.panelEdges.removeAll();
/* 134 */     Map<String, String> edgeFeatureNames = FeatureUtils.collectFeatureKeys(DisplaySettings.TrackMateObject.EDGES, trackmate.getModel(), trackmate.getSettings());
/* 135 */     Set<String> edgeFeatures = edgeFeatureNames.keySet();
/* 136 */     this.edgeFeatureSelectionPanel = new FeaturePlotSelectionPanel("Edge time", "Speed", edgeFeatures, edgeFeatureNames, (xKey, yKeys) -> (new Thread(())).start());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 142 */     this.panelEdges.add(this.edgeFeatureSelectionPanel);
/*     */ 
/*     */     
/* 145 */     this.panelTracks.removeAll();
/* 146 */     Map<String, String> trackFeatureNames = FeatureUtils.collectFeatureKeys(DisplaySettings.TrackMateObject.TRACKS, trackmate.getModel(), trackmate.getSettings());
/* 147 */     Set<String> trackFeatures = trackFeatureNames.keySet();
/* 148 */     this.trackFeatureSelectionPanel = new FeaturePlotSelectionPanel("Track index", "Number of spots in track", trackFeatures, trackFeatureNames, (xKey, yKeys) -> (new Thread(())).start());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 154 */     this.panelTracks.add(this.trackFeatureSelectionPanel);
/*     */     
/* 156 */     this.panelSelection = new JPanel();
/* 157 */     this.panelSelection.setLayout(new BoxLayout(this.panelSelection, 2));
/* 158 */     add(this.panelSelection, "South");
/*     */     
/* 160 */     this.rdbtnAll = new JRadioButton("All");
/* 161 */     this.rdbtnAll.setFont(this.rdbtnAll.getFont().deriveFont(this.rdbtnAll.getFont().getSize() - 2.0F));
/* 162 */     this.panelSelection.add(this.rdbtnAll);
/*     */     
/* 164 */     this.rdbtnSelection = new JRadioButton("Selection");
/* 165 */     this.rdbtnSelection.setFont(this.rdbtnSelection.getFont().deriveFont(this.rdbtnSelection.getFont().getSize() - 2.0F));
/* 166 */     this.panelSelection.add(this.rdbtnSelection);
/*     */     
/* 168 */     this.rdbtnTracks = new JRadioButton("Tracks of selection");
/* 169 */     this.rdbtnTracks.setFont(this.rdbtnTracks.getFont().deriveFont(this.rdbtnTracks.getFont().getSize() - 2.0F));
/* 170 */     this.panelSelection.add(this.rdbtnTracks);
/*     */     
/* 172 */     ButtonGroup btngrp = new ButtonGroup();
/* 173 */     btngrp.add(this.rdbtnAll);
/* 174 */     btngrp.add(this.rdbtnSelection);
/* 175 */     btngrp.add(this.rdbtnTracks);
/* 176 */     this.rdbtnAll.setSelected(true);
/*     */     
/* 178 */     this.panelSelection.add(new JSeparator(1));
/*     */     
/* 180 */     this.chkboxConnectDots = new JCheckBox("Connect");
/* 181 */     this.chkboxConnectDots.setFont(this.chkboxConnectDots.getFont().deriveFont(this.chkboxConnectDots.getFont().getSize() - 2.0F));
/* 182 */     this.chkboxConnectDots.setSelected(true);
/* 183 */     this.panelSelection.add(this.chkboxConnectDots);
/*     */   }
/*     */ 
/*     */   
/*     */   public FeaturePlotSelectionPanel getSpotFeatureSelectionPanel() {
/* 188 */     return this.spotFeatureSelectionPanel;
/*     */   }
/*     */ 
/*     */   
/*     */   public FeaturePlotSelectionPanel getEdgeFeatureSelectionPanel() {
/* 193 */     return this.edgeFeatureSelectionPanel;
/*     */   }
/*     */ 
/*     */   
/*     */   public FeaturePlotSelectionPanel getTrackFeatureSelectionPanel() {
/* 198 */     return this.trackFeatureSelectionPanel;
/*     */   }
/*     */ 
/*     */   
/*     */   private void plotSpotFeatures(String xFeature, List<String> yFeatures) {
/* 203 */     EverythingDisablerAndReenabler enabler = new EverythingDisablerAndReenabler(this, new Class[] { JLabel.class });
/* 204 */     enabler.disable();
/*     */     
/*     */     try {
/*     */       List<Spot> spots;
/* 208 */       if (this.rdbtnAll.isSelected()) {
/*     */         
/* 210 */         spots = new ArrayList<>(this.trackmate.getModel().getSpots().getNSpots(true));
/* 211 */         for (Integer trackID : this.trackmate.getModel().getTrackModel().trackIDs(true)) {
/* 212 */           spots.addAll(this.trackmate.getModel().getTrackModel().trackSpots(trackID));
/*     */         }
/* 214 */       } else if (this.rdbtnSelection.isSelected()) {
/*     */         
/* 216 */         spots = new ArrayList<>(this.selectionModel.getSpotSelection());
/*     */       }
/*     */       else {
/*     */         
/* 220 */         this.selectionModel.selectTrack(this.selectionModel
/* 221 */             .getSpotSelection(), this.selectionModel
/* 222 */             .getEdgeSelection(), 0);
/* 223 */         spots = new ArrayList<>(this.selectionModel.getSpotSelection());
/*     */       } 
/* 225 */       boolean addLines = this.chkboxConnectDots.isSelected();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 231 */       SpotFeatureGrapher grapher = new SpotFeatureGrapher(spots, xFeature, yFeatures, this.trackmate.getModel(), this.selectionModel, this.displaySettings, addLines);
/*     */ 
/*     */ 
/*     */       
/* 235 */       JFrame frame = grapher.render();
/* 236 */       frame.setIconImage(Icons.PLOT_ICON.getImage());
/* 237 */       frame.setTitle((this.trackmate.getSettings()).imp.getShortTitle() + " spot features");
/* 238 */       GuiUtils.positionWindow(frame, SwingUtilities.getWindowAncestor(this));
/* 239 */       frame.setVisible(true);
/*     */     }
/*     */     finally {
/*     */       
/* 243 */       enabler.reenable();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void plotEdgeFeatures(String xFeature, List<String> yFeatures) {
/* 249 */     EverythingDisablerAndReenabler enabler = new EverythingDisablerAndReenabler(this, new Class[] { JLabel.class });
/* 250 */     enabler.disable();
/*     */     
/*     */     try {
/*     */       List<DefaultWeightedEdge> edges;
/* 254 */       if (this.rdbtnAll.isSelected()) {
/*     */         
/* 256 */         edges = new ArrayList<>();
/* 257 */         for (Integer trackID : this.trackmate.getModel().getTrackModel().trackIDs(true)) {
/* 258 */           edges.addAll(this.trackmate.getModel().getTrackModel().trackEdges(trackID));
/*     */         }
/* 260 */       } else if (this.rdbtnSelection.isSelected()) {
/*     */         
/* 262 */         edges = new ArrayList<>(this.selectionModel.getEdgeSelection());
/*     */       }
/*     */       else {
/*     */         
/* 266 */         this.selectionModel.selectTrack(this.selectionModel
/* 267 */             .getSpotSelection(), this.selectionModel
/* 268 */             .getEdgeSelection(), 0);
/* 269 */         edges = new ArrayList<>(this.selectionModel.getEdgeSelection());
/*     */       } 
/* 271 */       boolean addLines = this.chkboxConnectDots.isSelected();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 277 */       EdgeFeatureGrapher grapher = new EdgeFeatureGrapher(edges, xFeature, yFeatures, this.trackmate.getModel(), this.selectionModel, this.displaySettings, addLines);
/*     */ 
/*     */ 
/*     */       
/* 281 */       JFrame frame = grapher.render();
/* 282 */       frame.setIconImage(Icons.PLOT_ICON.getImage());
/* 283 */       frame.setTitle((this.trackmate.getSettings()).imp.getShortTitle() + " edge features");
/* 284 */       GuiUtils.positionWindow(frame, SwingUtilities.getWindowAncestor(this));
/* 285 */       frame.setVisible(true);
/* 286 */       this.edgeFeatureSelectionPanel.setEnabled(true);
/*     */     }
/*     */     finally {
/*     */       
/* 290 */       enabler.reenable();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void plotTrackFeatures(String xFeature, List<String> yFeatures) {
/* 296 */     EverythingDisablerAndReenabler enabler = new EverythingDisablerAndReenabler(this, new Class[] { JLabel.class });
/* 297 */     enabler.disable();
/*     */     
/*     */     try {
/*     */       List<Integer> trackIDs;
/* 301 */       if (this.rdbtnAll.isSelected()) {
/*     */         
/* 303 */         trackIDs = new ArrayList<>(this.trackmate.getModel().getTrackModel().unsortedTrackIDs(true));
/*     */       }
/*     */       else {
/*     */         
/* 307 */         Set<Integer> set = new HashSet<>();
/* 308 */         for (Spot spot : this.selectionModel.getSpotSelection())
/* 309 */           set.add(this.trackmate.getModel().getTrackModel().trackIDOf(spot)); 
/* 310 */         for (DefaultWeightedEdge edge : this.selectionModel.getEdgeSelection())
/* 311 */           set.add(this.trackmate.getModel().getTrackModel().trackIDOf(edge)); 
/* 312 */         trackIDs = new ArrayList<>(set);
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 319 */       TrackFeatureGrapher grapher = new TrackFeatureGrapher(trackIDs, xFeature, yFeatures, this.trackmate.getModel(), this.selectionModel, this.displaySettings);
/*     */ 
/*     */       
/* 322 */       JFrame frame = grapher.render();
/* 323 */       frame.setIconImage(Icons.PLOT_ICON.getImage());
/* 324 */       frame.setTitle((this.trackmate.getSettings()).imp.getShortTitle() + " track features");
/* 325 */       GuiUtils.positionWindow(frame, SwingUtilities.getWindowAncestor(this));
/* 326 */       frame.setVisible(true);
/*     */     }
/*     */     finally {
/*     */       
/* 330 */       enabler.reenable();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/gui/components/GrapherPanel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */