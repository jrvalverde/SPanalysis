/*     */ package fiji.plugin.trackmate.gui.displaysettings;
/*     */ 
/*     */ import fiji.plugin.trackmate.gui.Icons;
/*     */ import ij.ImageJ;
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.event.ActionEvent;
/*     */ import javax.swing.BorderFactory;
/*     */ import javax.swing.Box;
/*     */ import javax.swing.BoxLayout;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JFrame;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JScrollPane;
/*     */ import javax.swing.UIManager;
/*     */ import javax.swing.UnsupportedLookAndFeelException;
/*     */ import org.scijava.command.Command;
/*     */ import org.scijava.plugin.Plugin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Plugin(type = Command.class, label = "Configure TrackMate display settings...", iconPath = "/icons/commands/information.png", menuPath = "Edit >  Options > Configure TrackMate display settings...")
/*     */ public class ConfigTrackMateDisplaySettings
/*     */   implements Command
/*     */ {
/*     */   private static final String APPLY_TOOLTIP = "<html>Save the current settings to the user default settings. They will be used in all the following TrackMate sessions.</html>";
/*     */   private static final String REVERT_TOOLTIP = "<html>Revert the current settings to the ones saved in the user default settings file.</html>";
/*     */   private static final String RESET_TOOLTIP = "<html>Reset the current settings to the built-in defaults.</html>";
/*     */   
/*     */   public void run() {
/*  64 */     editor(DisplaySettingsIO.readUserDefault(), "Configure the default settings to be used by TrackMate.", "TrackMate user default settings")
/*     */       
/*  66 */       .setVisible(true);
/*     */   }
/*     */ 
/*     */   
/*     */   public static JFrame editor(DisplaySettings ds, String titleStr, String frameName) {
/*  71 */     JPanel configPanel = new JPanel();
/*  72 */     configPanel.setLayout(new BorderLayout());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  78 */     JLabel title = new JLabel("<html><i>" + titleStr + "</i></html>");
/*     */ 
/*     */     
/*  81 */     title.setBorder(BorderFactory.createEmptyBorder(10, 5, 10, 5));
/*  82 */     configPanel.add(title, "North");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  88 */     JPanel panelButton = new JPanel();
/*  89 */     BoxLayout panelButtonLayout = new BoxLayout(panelButton, 2);
/*  90 */     panelButton.setLayout(panelButtonLayout);
/*  91 */     JButton btnReset = new JButton("Reset", Icons.RESET_ICON);
/*  92 */     btnReset.setToolTipText("<html>Reset the current settings to the built-in defaults.</html>");
/*  93 */     JButton btnRevert = new JButton("Revert", Icons.REVERT_ICON);
/*  94 */     btnRevert.setToolTipText("<html>Revert the current settings to the ones saved in the user default settings file.</html>");
/*  95 */     JButton btnApply = new JButton("Save to user defaults", Icons.APPLY_ICON);
/*  96 */     btnApply.setToolTipText("<html>Save the current settings to the user default settings. They will be used in all the following TrackMate sessions.</html>");
/*  97 */     panelButton.add(btnReset);
/*  98 */     panelButton.add(Box.createHorizontalStrut(5));
/*  99 */     panelButton.add(btnRevert);
/* 100 */     panelButton.add(Box.createHorizontalGlue());
/* 101 */     panelButton.add(btnApply);
/* 102 */     panelButton.setBorder(BorderFactory.createEmptyBorder(10, 5, 10, 5));
/* 103 */     configPanel.add(panelButton, "South");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 109 */     DisplaySettingsPanel editor = new DisplaySettingsPanel(ds);
/* 110 */     JScrollPane scrollPane = new JScrollPane(editor, 22, 31);
/* 111 */     scrollPane.setPreferredSize(new Dimension(350, 500));
/* 112 */     scrollPane.getVerticalScrollBar().setUnitIncrement(16);
/* 113 */     configPanel.add(scrollPane, "Center");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 119 */     btnReset.addActionListener(e -> {
/*     */           ds.set(DisplaySettings.defaultStyle().copy("User-default"));
/*     */           title.setText("Reset the current settings to the built-in defaults.");
/*     */         });
/* 123 */     btnRevert.addActionListener(e -> {
/*     */           ds.set(DisplaySettingsIO.readUserDefault());
/*     */           title.setText("Reverted the current settings to the user defaults.");
/*     */         });
/* 127 */     btnApply.addActionListener(e -> {
/*     */           DisplaySettingsIO.saveToUserDefault(ds);
/*     */ 
/*     */ 
/*     */           
/*     */           title.setText("Saved the current settings to the user defaults file.");
/*     */         });
/*     */ 
/*     */     
/* 136 */     JFrame frame = new JFrame(frameName);
/* 137 */     frame.setIconImage(Icons.TRACKMATE_ICON.getImage());
/* 138 */     frame.getContentPane().add(configPanel);
/* 139 */     frame.pack();
/* 140 */     frame.setLocationRelativeTo(null);
/* 141 */     return frame;
/*     */   }
/*     */ 
/*     */   
/*     */   public static void main(String[] args) throws ClassNotFoundException, InstantiationException, IllegalAccessException, UnsupportedLookAndFeelException {
/* 146 */     UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
/* 147 */     ImageJ.main(args);
/* 148 */     (new ConfigTrackMateDisplaySettings()).run();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/gui/displaysettings/ConfigTrackMateDisplaySettings.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */