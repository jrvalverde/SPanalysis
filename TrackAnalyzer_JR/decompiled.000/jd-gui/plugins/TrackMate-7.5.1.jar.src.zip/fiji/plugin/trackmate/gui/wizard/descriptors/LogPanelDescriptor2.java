/*    */ package fiji.plugin.trackmate.gui.wizard.descriptors;
/*    */ 
/*    */ import fiji.plugin.trackmate.gui.components.LogPanel;
/*    */ import fiji.plugin.trackmate.gui.wizard.WizardPanelDescriptor;
/*    */ import java.awt.Component;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LogPanelDescriptor2
/*    */   extends WizardPanelDescriptor
/*    */ {
/*    */   public static final String KEY = "LogPanel";
/*    */   
/*    */   public LogPanelDescriptor2(LogPanel logPanel) {
/* 34 */     super("LogPanel");
/* 35 */     this.targetPanel = (Component)logPanel;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/gui/wizard/descriptors/LogPanelDescriptor2.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */