/*     */ package fiji.plugin.trackmate.util;
/*     */ 
/*     */ import java.awt.Component;
/*     */ import java.awt.Dialog;
/*     */ import java.awt.FileDialog;
/*     */ import java.awt.Frame;
/*     */ import java.io.File;
/*     */ import java.io.FilenameFilter;
/*     */ import java.util.Locale;
/*     */ import java.util.concurrent.atomic.AtomicBoolean;
/*     */ import javax.swing.JFileChooser;
/*     */ import javax.swing.filechooser.FileFilter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FileChooser
/*     */ {
/*  38 */   public static boolean useJFileChooser = !isMac();
/*     */   
/*     */   public enum DialogType
/*     */   {
/*  42 */     LOAD, SAVE;
/*     */   }
/*     */   
/*     */   public enum SelectionMode
/*     */   {
/*  47 */     FILES_ONLY, DIRECTORIES_ONLY, FILES_AND_DIRECTORIES;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static File chooseFile(Component parent, String selectedFile, DialogType dialogType) {
/*  55 */     return chooseFile(parent, selectedFile, null, null, dialogType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static File chooseFile(Component parent, String selectedFile, FileFilter fileFilter, String dialogTitle, DialogType dialogType) {
/*  65 */     return chooseFile(parent, selectedFile, fileFilter, dialogTitle, dialogType, SelectionMode.FILES_ONLY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static File chooseFile(Component parent, String selectedFile, FileFilter fileFilter, String dialogTitle, DialogType dialogType, SelectionMode selectionMode) {
/*  76 */     return chooseFile(useJFileChooser, parent, selectedFile, fileFilter, dialogTitle, dialogType, selectionMode);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static File chooseFile(boolean useJFileChooser, Component parent, String selectedFile, final FileFilter fileFilter, String dialogTitle, DialogType dialogType, SelectionMode selectionMode) {
/*  88 */     boolean isSaveDialog = (dialogType == DialogType.SAVE);
/*  89 */     boolean isDirectoriesOnly = (selectionMode == SelectionMode.DIRECTORIES_ONLY);
/*     */     
/*  91 */     if (isSaveDialog && isDirectoriesOnly) {
/*  92 */       useJFileChooser = true;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 103 */     String title = dialogTitle;
/* 104 */     if (title == null)
/*     */     {
/* 106 */       title = (isSaveDialog ? "Save" : "Open") + ((fileFilter == null) ? "" : (" " + fileFilter.getDescription()));
/*     */     }
/* 108 */     File file = null;
/* 109 */     if (useJFileChooser) {
/*     */       
/* 111 */       JFileChooser fileChooser = new JFileChooser();
/*     */       
/* 113 */       fileChooser.setDialogTitle(title);
/*     */       
/* 115 */       if (selectedFile != null) {
/* 116 */         fileChooser.setSelectedFile(new File(selectedFile));
/*     */       }
/* 118 */       switch (selectionMode) {
/*     */         
/*     */         case FILES_ONLY:
/* 121 */           fileChooser.setFileSelectionMode(0);
/*     */           break;
/*     */         case DIRECTORIES_ONLY:
/* 124 */           fileChooser.setFileSelectionMode(1);
/*     */           break;
/*     */         case FILES_AND_DIRECTORIES:
/* 127 */           fileChooser.setFileSelectionMode(2);
/*     */           break;
/*     */       } 
/*     */       
/* 131 */       fileChooser.setFileFilter(fileFilter);
/*     */ 
/*     */ 
/*     */       
/* 135 */       int returnVal = isSaveDialog ? fileChooser.showSaveDialog(parent) : fileChooser.showOpenDialog(parent);
/* 136 */       if (returnVal == 0) {
/* 137 */         file = fileChooser.getSelectedFile();
/*     */       }
/*     */     } else {
/*     */       FileDialog fd;
/* 141 */       int fdMode = isSaveDialog ? 1 : 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 148 */       if (parent != null && parent instanceof Frame) {
/* 149 */         fd = new FileDialog((Frame)parent, title, fdMode);
/* 150 */       } else if (parent != null && parent instanceof Dialog) {
/* 151 */         fd = new FileDialog((Dialog)parent, title, fdMode);
/*     */       } else {
/* 153 */         fd = new FileDialog((Frame)null, title, fdMode);
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 158 */       if (selectedFile != null)
/*     */       {
/* 160 */         if (isDirectoriesOnly) {
/*     */           
/* 162 */           fd.setDirectory(selectedFile);
/* 163 */           fd.setFile((String)null);
/*     */         }
/*     */         else {
/*     */           
/* 167 */           fd.setDirectory((new File(selectedFile)).getParent());
/* 168 */           fd.setFile((new File(selectedFile)).getName());
/*     */         } 
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 175 */       System.setProperty("apple.awt.fileDialogForDirectories", isDirectoriesOnly ? "true" : "false");
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 180 */       final AtomicBoolean workedWithFilenameFilter = new AtomicBoolean(false);
/* 181 */       if (fileFilter != null) {
/*     */         
/* 183 */         FilenameFilter filenameFilter = new FilenameFilter()
/*     */           {
/*     */             private boolean firstTime = true;
/*     */ 
/*     */ 
/*     */             
/*     */             public boolean accept(File dir, String name) {
/* 190 */               if (this.firstTime) {
/*     */                 
/* 192 */                 workedWithFilenameFilter.set(true);
/* 193 */                 this.firstTime = false;
/*     */               } 
/*     */               
/* 196 */               return fileFilter.accept(new File(dir, name));
/*     */             }
/*     */           };
/* 199 */         fd.setFilenameFilter(filenameFilter);
/* 200 */         fd.setVisible(true);
/*     */       } 
/* 202 */       if (fileFilter == null || (isMac() && !workedWithFilenameFilter.get())) {
/*     */         
/* 204 */         fd.setFilenameFilter((FilenameFilter)null);
/* 205 */         fd.setVisible(true);
/*     */       } 
/*     */       
/* 208 */       String filename = fd.getFile();
/* 209 */       if (filename != null)
/*     */       {
/* 211 */         file = new File(fd.getDirectory() + filename);
/*     */       }
/*     */     } 
/*     */     
/* 215 */     return file;
/*     */   }
/*     */ 
/*     */   
/*     */   private static boolean isMac() {
/* 220 */     String OS = System.getProperty("os.name", "generic").toLowerCase(Locale.ENGLISH);
/* 221 */     return (OS.indexOf("mac") >= 0 || OS.indexOf("darwin") >= 0);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/util/FileChooser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */