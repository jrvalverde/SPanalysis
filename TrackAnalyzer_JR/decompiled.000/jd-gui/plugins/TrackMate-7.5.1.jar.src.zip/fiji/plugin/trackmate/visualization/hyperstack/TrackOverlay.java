/*     */ package fiji.plugin.trackmate.visualization.hyperstack;
/*     */ 
/*     */ import fiji.plugin.trackmate.Model;
/*     */ import fiji.plugin.trackmate.Spot;
/*     */ import fiji.plugin.trackmate.features.FeatureUtils;
/*     */ import fiji.plugin.trackmate.gui.displaysettings.DisplaySettings;
/*     */ import fiji.plugin.trackmate.util.TMUtils;
/*     */ import fiji.plugin.trackmate.visualization.FeatureColorGenerator;
/*     */ import ij.ImagePlus;
/*     */ import ij.gui.Roi;
/*     */ import java.awt.AlphaComposite;
/*     */ import java.awt.BasicStroke;
/*     */ import java.awt.Color;
/*     */ import java.awt.Composite;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.RenderingHints;
/*     */ import java.awt.Stroke;
/*     */ import java.awt.geom.AffineTransform;
/*     */ import java.util.Collection;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import org.jgrapht.graph.DefaultWeightedEdge;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TrackOverlay
/*     */   extends Roi
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   protected final double[] calibration;
/*  60 */   protected Collection<DefaultWeightedEdge> highlight = new HashSet<>();
/*     */ 
/*     */ 
/*     */   
/*     */   protected DisplaySettings displaySettings;
/*     */ 
/*     */   
/*     */   protected final Model model;
/*     */ 
/*     */ 
/*     */   
/*     */   public TrackOverlay(Model model, ImagePlus imp, DisplaySettings displaySettings) {
/*  72 */     super(0, 0, imp);
/*  73 */     this.model = model;
/*  74 */     this.calibration = TMUtils.getSpatialCalibration(imp);
/*  75 */     this.imp = imp;
/*  76 */     this.displaySettings = displaySettings;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setHighlight(Collection<DefaultWeightedEdge> edges) {
/*  85 */     this.highlight = edges;
/*     */   }
/*     */ 
/*     */   
/*     */   public final synchronized void drawOverlay(Graphics g) {
/*     */     int minT, maxT;
/*  91 */     Graphics2D g2d = (Graphics2D)g;
/*     */     
/*  93 */     double magnification = getMagnification();
/*     */ 
/*     */     
/*  96 */     int xcorner = this.ic.offScreenX(0);
/*  97 */     int ycorner = this.ic.offScreenY(0);
/*  98 */     double minx = xcorner;
/*  99 */     double miny = ycorner;
/* 100 */     double maxx = minx + this.ic.getWidth() / magnification;
/* 101 */     double maxy = miny + this.ic.getHeight() / magnification;
/*     */     
/* 103 */     if (!this.displaySettings.isTrackVisible() || this.model.getTrackModel().nTracks(true) == 0) {
/*     */       return;
/*     */     }
/* 106 */     boolean doLimitDrawingDepth = this.displaySettings.isZDrawingDepthLimited();
/* 107 */     double drawingDepth = this.displaySettings.getZDrawingDepth();
/* 108 */     double zslice = (this.imp.getSlice() - 1) * this.calibration[2];
/*     */ 
/*     */     
/* 111 */     AffineTransform originalTransform = g2d.getTransform();
/* 112 */     Composite originalComposite = g2d.getComposite();
/* 113 */     Stroke originalStroke = g2d.getStroke();
/* 114 */     Color originalColor = g2d.getColor();
/*     */ 
/*     */     
/* 117 */     int currentFrame = this.imp.getFrame() - 1;
/* 118 */     DisplaySettings.TrackDisplayMode trackDisplayMode = this.displaySettings.getTrackDisplayMode();
/* 119 */     int trackDisplayDepth = this.displaySettings.isFadeTracks() ? this.displaySettings.getFadeTrackRange() : 1000000000;
/* 120 */     Set<Integer> filteredTrackKeys = this.model.getTrackModel().unsortedTrackIDs(true);
/*     */     
/* 122 */     g2d.setStroke(new BasicStroke((float)this.displaySettings.getLineThickness()));
/* 123 */     if (trackDisplayMode == DisplaySettings.TrackDisplayMode.LOCAL) {
/* 124 */       g2d.setComposite(AlphaComposite.getInstance(3));
/*     */     }
/* 126 */     g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, 
/* 127 */         this.displaySettings.getUseAntialiasing() ? RenderingHints.VALUE_ANTIALIAS_ON : RenderingHints.VALUE_ANTIALIAS_OFF);
/*     */ 
/*     */     
/* 130 */     FeatureColorGenerator<DefaultWeightedEdge> colorGenerator = FeatureUtils.createTrackColorGenerator(this.model, this.displaySettings);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 135 */     switch (trackDisplayMode) {
/*     */ 
/*     */ 
/*     */       
/*     */       default:
/* 140 */         minT = currentFrame - trackDisplayDepth;
/* 141 */         maxT = currentFrame + trackDisplayDepth;
/*     */         break;
/*     */       case LOCAL_FORWARD:
/* 144 */         minT = currentFrame;
/* 145 */         maxT = currentFrame + trackDisplayDepth;
/*     */         break;
/*     */       case LOCAL_BACKWARD:
/* 148 */         minT = currentFrame - trackDisplayDepth;
/* 149 */         maxT = currentFrame;
/*     */         break;
/*     */     } 
/*     */     
/* 153 */     switch (trackDisplayMode) {
/*     */ 
/*     */ 
/*     */       
/*     */       case SELECTION_ONLY:
/* 158 */         for (DefaultWeightedEdge edge : this.highlight) {
/*     */           
/* 160 */           Spot source = this.model.getTrackModel().getEdgeSource(edge);
/* 161 */           Spot target = this.model.getTrackModel().getEdgeTarget(edge);
/* 162 */           if (!isOnClip(source, target, minx, miny, maxx, maxy, this.calibration)) {
/*     */             continue;
/*     */           }
/* 165 */           int sourceFrame = source.getFeature("FRAME").intValue();
/* 166 */           if (sourceFrame < minT || sourceFrame >= maxT) {
/*     */             continue;
/*     */           }
/* 169 */           double zs = source.getFeature("POSITION_Z").doubleValue();
/* 170 */           double zt = target.getFeature("POSITION_Z").doubleValue();
/* 171 */           if (doLimitDrawingDepth && Math.abs(zs - zslice) > drawingDepth && Math.abs(zt - zslice) > drawingDepth) {
/*     */             continue;
/*     */           }
/* 174 */           g2d.setColor(colorGenerator.color(edge));
/* 175 */           float transparency = (float)(1.0D - Math.abs(sourceFrame - currentFrame) / trackDisplayDepth);
/* 176 */           drawEdge(g2d, source, target, xcorner, ycorner, magnification, transparency);
/*     */         } 
/*     */         break;
/*     */ 
/*     */ 
/*     */       
/*     */       case FULL:
/* 183 */         for (Integer trackID : filteredTrackKeys) {
/*     */           
/* 185 */           Set<DefaultWeightedEdge> track = new HashSet<>(this.model.getTrackModel().trackEdges(trackID));
/* 186 */           for (DefaultWeightedEdge edge : track) {
/*     */             
/* 188 */             Spot source = this.model.getTrackModel().getEdgeSource(edge);
/* 189 */             Spot target = this.model.getTrackModel().getEdgeTarget(edge);
/* 190 */             if (!isOnClip(source, target, minx, miny, maxx, maxy, this.calibration)) {
/*     */               continue;
/*     */             }
/* 193 */             double zs = source.getFeature("POSITION_Z").doubleValue();
/* 194 */             double zt = target.getFeature("POSITION_Z").doubleValue();
/* 195 */             if (doLimitDrawingDepth && Math.abs(zs - zslice) > drawingDepth && Math.abs(zt - zslice) > drawingDepth) {
/*     */               continue;
/*     */             }
/* 198 */             g2d.setColor(colorGenerator.color(edge));
/* 199 */             drawEdge(g2d, source, target, xcorner, ycorner, magnification);
/*     */           } 
/*     */         } 
/*     */         break;
/*     */ 
/*     */ 
/*     */       
/*     */       case LOCAL:
/*     */       case LOCAL_FORWARD:
/*     */       case LOCAL_BACKWARD:
/* 209 */         for (Integer trackID : filteredTrackKeys) {
/*     */           Set<DefaultWeightedEdge> track;
/*     */           
/* 212 */           synchronized (this.model) {
/*     */             
/* 214 */             track = new HashSet<>(this.model.getTrackModel().trackEdges(trackID));
/*     */           } 
/* 216 */           for (DefaultWeightedEdge edge : track) {
/*     */             
/* 218 */             Spot source = this.model.getTrackModel().getEdgeSource(edge);
/* 219 */             int sourceFrame = source.getFeature("FRAME").intValue();
/* 220 */             if (sourceFrame < minT || sourceFrame >= maxT) {
/*     */               continue;
/*     */             }
/* 223 */             float transparency = (float)(1.0D - Math.abs(sourceFrame - currentFrame) / trackDisplayDepth);
/* 224 */             Spot target = this.model.getTrackModel().getEdgeTarget(edge);
/* 225 */             if (!isOnClip(source, target, minx, miny, maxx, maxy, this.calibration)) {
/*     */               continue;
/*     */             }
/* 228 */             double zs = source.getFeature("POSITION_Z").doubleValue();
/* 229 */             double zt = target.getFeature("POSITION_Z").doubleValue();
/* 230 */             if (doLimitDrawingDepth && Math.abs(zs - zslice) > drawingDepth && Math.abs(zt - zslice) > drawingDepth) {
/*     */               continue;
/*     */             }
/* 233 */             g2d.setColor(colorGenerator.color(edge));
/* 234 */             drawEdge(g2d, source, target, xcorner, ycorner, magnification, transparency);
/*     */           } 
/*     */         } 
/*     */         break;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 242 */     if (trackDisplayMode != DisplaySettings.TrackDisplayMode.SELECTION_ONLY) {
/*     */ 
/*     */       
/* 245 */       g2d.setStroke(new BasicStroke((float)this.displaySettings.getSelectionLineThickness()));
/* 246 */       g2d.setColor(this.displaySettings.getHighlightColor());
/* 247 */       g2d.setComposite(AlphaComposite.getInstance(3));
/* 248 */       for (DefaultWeightedEdge edge : this.highlight) {
/*     */         
/* 250 */         Spot source = this.model.getTrackModel().getEdgeSource(edge);
/* 251 */         Spot target = this.model.getTrackModel().getEdgeTarget(edge);
/* 252 */         if (!isOnClip(source, target, minx, miny, maxx, maxy, this.calibration))
/*     */           continue; 
/* 254 */         drawEdge(g2d, source, target, xcorner, ycorner, magnification);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 259 */     g2d.setTransform(originalTransform);
/* 260 */     g2d.setComposite(originalComposite);
/* 261 */     g2d.setStroke(originalStroke);
/* 262 */     g2d.setColor(originalColor);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static final boolean isOnClip(Spot source, Spot target, double minx, double miny, double maxx, double maxy, double[] calibration) {
/* 268 */     double x0i = source.getFeature("POSITION_X").doubleValue();
/* 269 */     double y0i = source.getFeature("POSITION_Y").doubleValue();
/* 270 */     double x1i = target.getFeature("POSITION_X").doubleValue();
/* 271 */     double y1i = target.getFeature("POSITION_Y").doubleValue();
/*     */     
/* 273 */     double x0p = x0i / calibration[0] + 0.5D;
/* 274 */     double y0p = y0i / calibration[1] + 0.5D;
/* 275 */     double x1p = x1i / calibration[0] + 0.5D;
/* 276 */     double y1p = y1i / calibration[1] + 0.5D;
/*     */ 
/*     */     
/* 279 */     if ((x0p > minx && x0p < maxx && y0p > miny && y0p < maxy) || (x1p > minx && x1p < maxx && y1p > miny && y1p < maxy))
/*     */     {
/* 281 */       return true;
/*     */     }
/*     */     
/* 284 */     if (segmentsCross(x0p, y0p, x1p, y1p, minx, miny, maxx, miny))
/* 285 */       return true; 
/* 286 */     if (segmentsCross(x0p, y0p, x1p, y1p, maxx, miny, maxx, maxy))
/* 287 */       return true; 
/* 288 */     if (segmentsCross(x0p, y0p, x1p, y1p, minx, maxy, maxx, maxy))
/* 289 */       return true; 
/* 290 */     if (segmentsCross(x0p, y0p, x1p, y1p, minx, miny, minx, maxy)) {
/* 291 */       return true;
/*     */     }
/* 293 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final boolean segmentsCross(double x0, double y0, double x1, double y1, double x2, double y2, double x3, double y3) {
/* 302 */     double s1_x = x1 - x0;
/* 303 */     double s1_y = y1 - y0;
/* 304 */     double s2_x = x3 - x2;
/* 305 */     double s2_y = y3 - y2;
/*     */     
/* 307 */     double det = -s2_x * s1_y + s1_x * s2_y;
/* 308 */     if (det < 1.1754943508222875E-38D) {
/* 309 */       return false;
/*     */     }
/* 311 */     double s = -s1_y * (x0 - x2) + s1_x * (y0 - y2);
/* 312 */     double t = s2_x * (y0 - y2) - s2_y * (x0 - x2);
/*     */     
/* 314 */     return (s >= 0.0D && s <= det && t >= 0.0D && t <= det);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void drawEdge(Graphics2D g2d, Spot source, Spot target, int xcorner, int ycorner, double magnification, float transparency) {
/* 320 */     double x0i = source.getFeature("POSITION_X").doubleValue();
/* 321 */     double y0i = source.getFeature("POSITION_Y").doubleValue();
/* 322 */     double x1i = target.getFeature("POSITION_X").doubleValue();
/* 323 */     double y1i = target.getFeature("POSITION_Y").doubleValue();
/*     */     
/* 325 */     double x0p = x0i / this.calibration[0] + 0.5D;
/* 326 */     double y0p = y0i / this.calibration[1] + 0.5D;
/* 327 */     double x1p = x1i / this.calibration[0] + 0.5D;
/* 328 */     double y1p = y1i / this.calibration[1] + 0.5D;
/*     */     
/* 330 */     double x0s = (x0p - xcorner) * magnification;
/* 331 */     double y0s = (y0p - ycorner) * magnification;
/* 332 */     double x1s = (x1p - xcorner) * magnification;
/* 333 */     double y1s = (y1p - ycorner) * magnification;
/*     */     
/* 335 */     int x0 = (int)Math.round(x0s);
/* 336 */     int y0 = (int)Math.round(y0s);
/* 337 */     int x1 = (int)Math.round(x1s);
/* 338 */     int y1 = (int)Math.round(y1s);
/*     */     
/* 340 */     g2d.setComposite(AlphaComposite.getInstance(3, transparency));
/* 341 */     g2d.drawLine(x0, y0, x1, y1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void drawEdge(Graphics2D g2d, Spot source, Spot target, int xcorner, int ycorner, double magnification) {
/* 348 */     double x0i = source.getFeature("POSITION_X").doubleValue();
/* 349 */     double y0i = source.getFeature("POSITION_Y").doubleValue();
/* 350 */     double x1i = target.getFeature("POSITION_X").doubleValue();
/* 351 */     double y1i = target.getFeature("POSITION_Y").doubleValue();
/*     */     
/* 353 */     double x0p = x0i / this.calibration[0] + 0.5D;
/* 354 */     double y0p = y0i / this.calibration[1] + 0.5D;
/* 355 */     double x1p = x1i / this.calibration[0] + 0.5D;
/* 356 */     double y1p = y1i / this.calibration[1] + 0.5D;
/*     */     
/* 358 */     double x0s = (x0p - xcorner) * magnification;
/* 359 */     double y0s = (y0p - ycorner) * magnification;
/* 360 */     double x1s = (x1p - xcorner) * magnification;
/* 361 */     double y1s = (y1p - ycorner) * magnification;
/*     */     
/* 363 */     int x0 = (int)Math.round(x0s);
/* 364 */     int y0 = (int)Math.round(y0s);
/* 365 */     int x1 = (int)Math.round(x1s);
/* 366 */     int y1 = (int)Math.round(y1s);
/*     */     
/* 368 */     g2d.drawLine(x0, y0, x1, y1);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/visualization/hyperstack/TrackOverlay.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */