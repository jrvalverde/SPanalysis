/*     */ package fiji.plugin.trackmate.util;
/*     */ 
/*     */ import java.util.concurrent.RejectedExecutionException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PainterThread
/*     */   extends Thread
/*     */ {
/*     */   private final Paintable paintable;
/*     */   private boolean pleaseRepaint;
/*     */   
/*     */   public PainterThread(Paintable paintable) {
/*  48 */     this(null, "PainterThread", paintable);
/*     */   }
/*     */ 
/*     */   
/*     */   public PainterThread(ThreadGroup group, Paintable paintable) {
/*  53 */     this(group, "PainterThread", paintable);
/*     */   }
/*     */ 
/*     */   
/*     */   public PainterThread(ThreadGroup group, String name, Paintable paintable) {
/*  58 */     super(group, name);
/*  59 */     this.paintable = paintable;
/*  60 */     this.pleaseRepaint = false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void run() {
/*  66 */     while (!isInterrupted()) {
/*     */       boolean b;
/*     */       
/*  69 */       synchronized (this) {
/*     */         
/*  71 */         b = this.pleaseRepaint;
/*  72 */         this.pleaseRepaint = false;
/*     */       } 
/*  74 */       if (b) {
/*     */         
/*     */         try {
/*  77 */           this.paintable.paint();
/*     */         }
/*  79 */         catch (RejectedExecutionException rejectedExecutionException) {}
/*     */       }
/*     */ 
/*     */ 
/*     */       
/*  84 */       synchronized (this) {
/*     */ 
/*     */         
/*     */         try {
/*  88 */           if (!this.pleaseRepaint) {
/*  89 */             wait();
/*     */           }
/*  91 */         } catch (InterruptedException e) {
/*     */           break;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void requestRepaint() {
/* 105 */     synchronized (this) {
/*     */       
/* 107 */       this.pleaseRepaint = true;
/* 108 */       notify();
/*     */     } 
/*     */   }
/*     */   
/*     */   public static interface Paintable {
/*     */     void paint();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/util/PainterThread.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */