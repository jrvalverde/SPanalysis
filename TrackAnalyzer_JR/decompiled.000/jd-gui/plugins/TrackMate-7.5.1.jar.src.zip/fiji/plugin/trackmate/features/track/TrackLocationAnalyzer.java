/*     */ package fiji.plugin.trackmate.features.track;
/*     */ 
/*     */ import fiji.plugin.trackmate.Dimension;
/*     */ import fiji.plugin.trackmate.FeatureModel;
/*     */ import fiji.plugin.trackmate.Model;
/*     */ import fiji.plugin.trackmate.Spot;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.scijava.plugin.Plugin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Plugin(type = TrackAnalyzer.class)
/*     */ public class TrackLocationAnalyzer
/*     */   extends AbstractTrackAnalyzer
/*     */ {
/*     */   public static final String KEY = "Track location";
/*     */   public static final String X_LOCATION = "TRACK_X_LOCATION";
/*     */   public static final String Y_LOCATION = "TRACK_Y_LOCATION";
/*     */   public static final String Z_LOCATION = "TRACK_Z_LOCATION";
/*  46 */   public static final List<String> FEATURES = new ArrayList<>(3);
/*  47 */   public static final Map<String, String> FEATURE_NAMES = new HashMap<>(3);
/*  48 */   public static final Map<String, String> FEATURE_SHORT_NAMES = new HashMap<>(3);
/*  49 */   public static final Map<String, Dimension> FEATURE_DIMENSIONS = new HashMap<>(3);
/*  50 */   public static final Map<String, Boolean> IS_INT = new HashMap<>(3);
/*     */ 
/*     */   
/*     */   static {
/*  54 */     FEATURES.add("TRACK_X_LOCATION");
/*  55 */     FEATURES.add("TRACK_Y_LOCATION");
/*  56 */     FEATURES.add("TRACK_Z_LOCATION");
/*     */     
/*  58 */     FEATURE_NAMES.put("TRACK_X_LOCATION", "Track mean X");
/*  59 */     FEATURE_NAMES.put("TRACK_Y_LOCATION", "Track mean Y");
/*  60 */     FEATURE_NAMES.put("TRACK_Z_LOCATION", "Track mean Z");
/*     */     
/*  62 */     FEATURE_SHORT_NAMES.put("TRACK_X_LOCATION", "Track X");
/*  63 */     FEATURE_SHORT_NAMES.put("TRACK_Y_LOCATION", "Track Y");
/*  64 */     FEATURE_SHORT_NAMES.put("TRACK_Z_LOCATION", "Track Z");
/*     */     
/*  66 */     FEATURE_DIMENSIONS.put("TRACK_X_LOCATION", Dimension.POSITION);
/*  67 */     FEATURE_DIMENSIONS.put("TRACK_Y_LOCATION", Dimension.POSITION);
/*  68 */     FEATURE_DIMENSIONS.put("TRACK_Z_LOCATION", Dimension.POSITION);
/*     */     
/*  70 */     IS_INT.put("TRACK_X_LOCATION", Boolean.FALSE);
/*  71 */     IS_INT.put("TRACK_Y_LOCATION", Boolean.FALSE);
/*  72 */     IS_INT.put("TRACK_Z_LOCATION", Boolean.FALSE);
/*     */   }
/*     */ 
/*     */   
/*     */   public TrackLocationAnalyzer() {
/*  77 */     super("Track location", "Track location", FEATURES, FEATURE_NAMES, FEATURE_SHORT_NAMES, FEATURE_DIMENSIONS, IS_INT);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void analyze(Integer trackID, Model model) {
/*  83 */     FeatureModel fm = model.getFeatureModel();
/*  84 */     Set<Spot> track = model.getTrackModel().trackSpots(trackID);
/*     */     
/*  86 */     double x = 0.0D;
/*  87 */     double y = 0.0D;
/*  88 */     double z = 0.0D;
/*     */     
/*  90 */     for (Spot spot : track) {
/*     */       
/*  92 */       x += spot.getFeature("POSITION_X").doubleValue();
/*  93 */       y += spot.getFeature("POSITION_Y").doubleValue();
/*  94 */       z += spot.getFeature("POSITION_Z").doubleValue();
/*     */     } 
/*  96 */     int nspots = track.size();
/*  97 */     x /= nspots;
/*  98 */     y /= nspots;
/*  99 */     z /= nspots;
/*     */     
/* 101 */     fm.putTrackFeature(trackID, "TRACK_X_LOCATION", Double.valueOf(x));
/* 102 */     fm.putTrackFeature(trackID, "TRACK_Y_LOCATION", Double.valueOf(y));
/* 103 */     fm.putTrackFeature(trackID, "TRACK_Z_LOCATION", Double.valueOf(z));
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/features/track/TrackLocationAnalyzer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */