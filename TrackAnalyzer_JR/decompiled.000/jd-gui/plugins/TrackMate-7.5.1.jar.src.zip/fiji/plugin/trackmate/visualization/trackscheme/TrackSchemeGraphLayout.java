/*     */ package fiji.plugin.trackmate.visualization.trackscheme;
/*     */ 
/*     */ import com.mxgraph.layout.mxGraphLayout;
/*     */ import com.mxgraph.model.mxCell;
/*     */ import com.mxgraph.model.mxGeometry;
/*     */ import com.mxgraph.model.mxICell;
/*     */ import fiji.plugin.trackmate.Model;
/*     */ import fiji.plugin.trackmate.Spot;
/*     */ import fiji.plugin.trackmate.graph.ConvexBranchesDecomposition;
/*     */ import fiji.plugin.trackmate.graph.GraphUtils;
/*     */ import fiji.plugin.trackmate.graph.SortedDepthFirstIterator;
/*     */ import fiji.plugin.trackmate.graph.TimeDirectedNeighborIndex;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.TreeSet;
/*     */ import net.imglib2.algorithm.Benchmark;
/*     */ import org.jgrapht.Graph;
/*     */ import org.jgrapht.graph.DefaultEdge;
/*     */ import org.jgrapht.graph.DefaultWeightedEdge;
/*     */ import org.jgrapht.graph.SimpleDirectedGraph;
/*     */ import org.jgrapht.traverse.DepthFirstIterator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TrackSchemeGraphLayout
/*     */   extends mxGraphLayout
/*     */   implements Benchmark
/*     */ {
/*     */   private static final int START_COLUMN = 1;
/*     */   private final Model model;
/*     */   private final JGraphXAdapter graphAdapter;
/*     */   private final TrackSchemeGraphComponent component;
/*     */   private Map<Integer, Integer> rowLengths;
/*     */   private long processingTime;
/*     */   
/*     */   public TrackSchemeGraphLayout(JGraphXAdapter graph, Model model, TrackSchemeGraphComponent component) {
/*  93 */     super(graph);
/*  94 */     this.graphAdapter = graph;
/*  95 */     this.model = model;
/*  96 */     this.component = component;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void execute(Object lParent) {
/* 107 */     long start = System.currentTimeMillis();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 113 */     Object[] objs = this.graphAdapter.getChildVertices(this.graphAdapter.getDefaultParent());
/* 114 */     ArrayList<mxCell> lonelyCells = new ArrayList<>(objs.length);
/* 115 */     for (Object obj : objs)
/*     */     {
/* 117 */       lonelyCells.add((mxCell)obj);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 123 */     TimeDirectedNeighborIndex neighborCache = this.model.getTrackModel().getDirectedNeighborIndex();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 128 */     Map<Spot, Integer> cumulativeBranchWidth = GraphUtils.cumulativeBranchWidth(this.model.getTrackModel());
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 133 */     int maxFrame = this.model.getSpots().lastKey().intValue();
/*     */     
/* 135 */     this.graphAdapter.getModel().beginUpdate();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 142 */       int ntracks = this.model.getTrackModel().nTracks(true);
/* 143 */       this.component.columnWidths = new int[ntracks];
/* 144 */       this.component.columnTrackIDs = new Integer[ntracks];
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 149 */       int[] columns = new int[maxFrame + 1];
/* 150 */       for (int i = 0; i < columns.length; i++)
/*     */       {
/* 152 */         columns[i] = 1;
/*     */       }
/*     */       
/* 155 */       int trackIndex = 0;
/* 156 */       for (Integer trackID : this.model.getTrackModel().trackIDs(true)) {
/*     */ 
/*     */ 
/*     */         
/* 160 */         Set<Spot> track = this.model.getTrackModel().trackSpots(trackID);
/*     */ 
/*     */         
/* 163 */         this.component.columnTrackIDs[trackIndex] = trackID;
/*     */ 
/*     */         
/* 166 */         TreeSet<Spot> sortedTrack = new TreeSet<>(Spot.frameComparator);
/* 167 */         sortedTrack.addAll(track);
/* 168 */         Spot first = sortedTrack.first();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 177 */         boolean isTree = GraphUtils.isTree(track, neighborCache);
/*     */         
/* 179 */         if (isTree) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 187 */           SortedDepthFirstIterator<Spot, DefaultWeightedEdge> iterator = this.model.getTrackModel().getSortedDepthFirstIterator(first, Spot.nameComparator, false);
/*     */           
/* 189 */           while (iterator.hasNext())
/*     */           {
/*     */             
/* 192 */             Spot spot = (Spot)iterator.next();
/*     */ 
/*     */ 
/*     */             
/* 196 */             mxCell mxCell = this.graphAdapter.getCellFor(spot);
/*     */ 
/*     */ 
/*     */             
/* 200 */             lonelyCells.remove(mxCell);
/*     */ 
/*     */             
/* 203 */             int frame = spot.getFeature("FRAME").intValue();
/*     */ 
/*     */             
/* 206 */             int cellPos = columns[frame] + ((Integer)cumulativeBranchWidth.get(spot)).intValue() / 2;
/* 207 */             setCellGeometry((mxICell)mxCell, frame, cellPos);
/* 208 */             columns[frame] = columns[frame] + ((Integer)cumulativeBranchWidth.get(spot)).intValue();
/*     */ 
/*     */ 
/*     */             
/* 212 */             if (neighborCache.successorsOf(spot).size() == 0)
/*     */             {
/* 214 */               int target = columns[frame];
/* 215 */               for (int i1 = 0; i1 <= maxFrame; i1++)
/*     */               {
/* 217 */                 columns[i1] = target;
/*     */               
/*     */               }
/*     */             
/*     */             }
/*     */ 
/*     */           
/*     */           }
/*     */ 
/*     */         
/*     */         }
/*     */         else {
/*     */ 
/*     */           
/* 231 */           ConvexBranchesDecomposition.TrackBranchDecomposition branchDecomposition = ConvexBranchesDecomposition.processTrack(trackID, this.model.getTrackModel(), neighborCache, false, false);
/* 232 */           SimpleDirectedGraph<List<Spot>, DefaultEdge> branchGraph = ConvexBranchesDecomposition.buildBranchGraph(branchDecomposition);
/* 233 */           DepthFirstIterator<List<Spot>, DefaultEdge> depthFirstIterator = new DepthFirstIterator((Graph)branchGraph);
/*     */           
/* 235 */           while (depthFirstIterator.hasNext()) {
/*     */             
/* 237 */             List<Spot> branch = (List<Spot>)depthFirstIterator.next();
/*     */             
/* 239 */             int firstFrame = ((Spot)branch.get(0)).getFeature("FRAME").intValue();
/* 240 */             int lastFrame = ((Spot)branch.get(branch.size() - 1)).getFeature("FRAME").intValue();
/*     */ 
/*     */             
/* 243 */             int targetColumn = columns[firstFrame];
/* 244 */             for (Spot spot : branch) {
/*     */               
/* 246 */               int sFrame = spot.getFeature("FRAME").intValue();
/* 247 */               if (columns[sFrame] > targetColumn)
/*     */               {
/* 249 */                 targetColumn = columns[sFrame];
/*     */               }
/*     */             } 
/*     */ 
/*     */             
/* 254 */             for (Spot spot : branch) {
/*     */ 
/*     */ 
/*     */               
/* 258 */               mxCell mxCell = this.graphAdapter.getCellFor(spot);
/*     */ 
/*     */ 
/*     */               
/* 262 */               lonelyCells.remove(mxCell);
/*     */ 
/*     */               
/* 265 */               int i1 = spot.getFeature("FRAME").intValue();
/*     */ 
/*     */               
/* 268 */               setCellGeometry((mxICell)mxCell, i1, targetColumn);
/*     */             } 
/*     */ 
/*     */             
/* 272 */             for (int frame = firstFrame; frame <= lastFrame; frame++)
/*     */             {
/* 274 */               columns[frame] = targetColumn + 1;
/*     */             }
/*     */           } 
/*     */         } 
/*     */ 
/*     */ 
/*     */         
/* 281 */         int maxCol = 0;
/* 282 */         for (int m = 0; m < columns.length; m++) {
/*     */           
/* 284 */           if (columns[m] > maxCol)
/*     */           {
/* 286 */             maxCol = columns[m];
/*     */           }
/*     */         } 
/* 289 */         for (int k = 0; k < columns.length; k++)
/*     */         {
/* 291 */           columns[k] = maxCol + 1;
/*     */         }
/*     */ 
/*     */         
/* 295 */         int sumWidth = 1;
/* 296 */         for (int n = 0; n < trackIndex; n++)
/*     */         {
/* 298 */           sumWidth += this.component.columnWidths[n];
/*     */         }
/* 300 */         this.component.columnWidths[trackIndex] = maxCol - sumWidth;
/*     */         
/* 302 */         trackIndex++;
/*     */       } 
/*     */ 
/*     */       
/* 306 */       for (mxCell cell : lonelyCells) {
/*     */         
/* 308 */         Spot spot = this.graphAdapter.getSpotFor((mxICell)cell);
/* 309 */         int frame = spot.getFeature("FRAME").intValue();
/* 310 */         columns[frame] = columns[frame] + 1; setCellGeometry((mxICell)cell, frame, columns[frame]);
/*     */       } 
/*     */ 
/*     */       
/* 314 */       this.rowLengths = new HashMap<>(columns.length);
/* 315 */       for (int j = 0; j < columns.length; j++)
/*     */       {
/* 317 */         this.rowLengths.put(Integer.valueOf(j), Integer.valueOf(columns[j]));
/*     */       }
/*     */ 
/*     */       
/* 321 */       Object[] verticesCells = this.graphAdapter.getVertexCells().toArray();
/* 322 */       this.graphAdapter.cellsOrdered(verticesCells, false);
/*     */     
/*     */     }
/*     */     finally {
/*     */       
/* 327 */       this.graphAdapter.getModel().endUpdate();
/*     */     } 
/*     */     
/* 330 */     long end = System.currentTimeMillis();
/* 331 */     this.processingTime = end - start;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private final void setCellGeometry(mxICell cell, int row, int targetColumn) {
/* 337 */     double x = (targetColumn * 160 - 64);
/* 338 */     double y = (0.5D + row) * 96.0D - 20.0D;
/* 339 */     mxGeometry geometry = cell.getGeometry();
/* 340 */     geometry.setX(x);
/* 341 */     geometry.setY(y);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<Integer, Integer> getRowLengths() {
/* 352 */     return this.rowLengths;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public long getProcessingTime() {
/* 358 */     return this.processingTime;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/visualization/trackscheme/TrackSchemeGraphLayout.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */