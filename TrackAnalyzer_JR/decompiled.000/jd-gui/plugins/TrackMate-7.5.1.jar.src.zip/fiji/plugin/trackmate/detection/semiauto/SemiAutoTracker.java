/*     */ package fiji.plugin.trackmate.detection.semiauto;
/*     */ 
/*     */ import fiji.plugin.trackmate.Logger;
/*     */ import fiji.plugin.trackmate.Model;
/*     */ import fiji.plugin.trackmate.SelectionModel;
/*     */ import fiji.plugin.trackmate.Spot;
/*     */ import fiji.plugin.trackmate.util.TMUtils;
/*     */ import ij.ImagePlus;
/*     */ import net.imagej.ImgPlus;
/*     */ import net.imagej.ImgPlusMetadata;
/*     */ import net.imagej.axis.Axes;
/*     */ import net.imglib2.FinalInterval;
/*     */ import net.imglib2.Interval;
/*     */ import net.imglib2.RandomAccessible;
/*     */ import net.imglib2.realtransform.AffineTransform3D;
/*     */ import net.imglib2.type.NativeType;
/*     */ import net.imglib2.type.numeric.RealType;
/*     */ import net.imglib2.view.MixedTransformView;
/*     */ import net.imglib2.view.Views;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SemiAutoTracker<T extends RealType<T> & NativeType<T>>
/*     */   extends AbstractSemiAutoTracker<T>
/*     */ {
/*     */   protected final ImgPlus<T> img;
/*     */   private final double dt;
/*     */   private final ImagePlus imp;
/*     */   
/*     */   public SemiAutoTracker(Model model, SelectionModel selectionModel, ImagePlus imp, Logger logger) {
/*  51 */     super(model, selectionModel, logger);
/*  52 */     this.imp = imp;
/*  53 */     this.img = TMUtils.rawWraps(imp);
/*  54 */     double ldt = (imp.getCalibration()).frameInterval;
/*  55 */     if (ldt == 0.0D) {
/*     */       
/*  57 */       this.dt = 1.0D;
/*     */     }
/*     */     else {
/*     */       
/*  61 */       this.dt = ldt;
/*     */     } 
/*     */   }
/*     */   
/*     */   protected AbstractSemiAutoTracker.SearchRegion<T> getNeighborhood(Spot spot, int frame) {
/*     */     long[] min, max;
/*     */     MixedTransformView mixedTransformView;
/*  68 */     double radius = spot.getFeature("RADIUS").doubleValue();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  74 */     int tindex = this.img.dimensionIndex(Axes.TIME);
/*  75 */     int cindex = this.img.dimensionIndex(Axes.CHANNEL);
/*  76 */     if (frame >= this.img.dimension(tindex)) {
/*     */       
/*  78 */       this.logger.log("Spot: " + spot + ": No more time-points.\n");
/*  79 */       return null;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  86 */     double[] cal = TMUtils.getSpatialCalibration((ImgPlusMetadata)this.img);
/*  87 */     double dx = cal[0];
/*  88 */     double dy = cal[1];
/*  89 */     double dz = cal[2];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  95 */     double neighborhoodFactor = Math.max(2.0D, this.distanceTolerance + 1.0D);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 101 */     double[] location = new double[3];
/* 102 */     spot.localize(location);
/*     */     
/* 104 */     long x = Math.round(location[0] / dx);
/* 105 */     long y = Math.round(location[1] / dy);
/* 106 */     long z = Math.round(location[2] / dz);
/* 107 */     long r = (long)Math.ceil(neighborhoodFactor * radius / dx);
/* 108 */     long rz = (long)Math.abs(Math.ceil(neighborhoodFactor * radius / dz));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 114 */     int targetChannel = this.imp.getC() - 1;
/*     */     
/* 116 */     long width = this.img.dimension(0);
/* 117 */     long height = this.img.dimension(1);
/* 118 */     long x0 = Math.max(0L, x - r);
/* 119 */     long y0 = Math.max(0L, y - r);
/* 120 */     long x1 = Math.min(width - 1L, x + r);
/* 121 */     long y1 = Math.min(height - 1L, y + r);
/*     */ 
/*     */ 
/*     */     
/* 125 */     if (this.img.dimensionIndex(Axes.Z) >= 0) {
/*     */ 
/*     */       
/* 128 */       long depth = this.img.dimension(this.img.dimensionIndex(Axes.Z));
/* 129 */       long z0 = Math.max(0L, z - rz);
/* 130 */       long z1 = Math.min(depth - 1L, z + rz);
/* 131 */       min = new long[] { x0, y0, z0 };
/* 132 */       max = new long[] { x1, y1, z1 };
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 137 */       min = new long[] { x0, y0 };
/* 138 */       max = new long[] { x1, y1 };
/*     */     } 
/* 140 */     FinalInterval interval = new FinalInterval(min, max);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 147 */     AffineTransform3D transform = new AffineTransform3D();
/*     */     
/* 149 */     AbstractSemiAutoTracker.SearchRegion<T> sn = new AbstractSemiAutoTracker.SearchRegion<>();
/* 150 */     ImgPlus<T> imgPlus = this.img;
/* 151 */     if (tindex >= 0) {
/* 152 */       mixedTransformView = Views.hyperSlice((RandomAccessible)imgPlus, tindex, frame);
/*     */     }
/* 154 */     if (cindex >= 0) {
/* 155 */       mixedTransformView = Views.hyperSlice((RandomAccessible)mixedTransformView, cindex, targetChannel);
/*     */     }
/* 157 */     sn.source = (RandomAccessible<T>)mixedTransformView;
/* 158 */     sn.transform = transform;
/* 159 */     sn.interval = (Interval)interval;
/* 160 */     sn.calibration = cal;
/*     */     
/* 162 */     return sn;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void exposeSpot(Spot newSpot, Spot previousSpot) {
/* 168 */     int frame = previousSpot.getFeature("FRAME").intValue() + 1;
/* 169 */     newSpot.putFeature("POSITION_T", Double.valueOf(frame * this.dt));
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/detection/semiauto/SemiAutoTracker.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */