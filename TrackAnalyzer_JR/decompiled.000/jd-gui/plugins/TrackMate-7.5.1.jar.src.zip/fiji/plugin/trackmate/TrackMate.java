/*     */ package fiji.plugin.trackmate;
/*     */ 
/*     */ import fiji.plugin.trackmate.detection.SpotDetector;
/*     */ import fiji.plugin.trackmate.detection.SpotDetectorFactory;
/*     */ import fiji.plugin.trackmate.detection.SpotDetectorFactoryBase;
/*     */ import fiji.plugin.trackmate.detection.SpotGlobalDetector;
/*     */ import fiji.plugin.trackmate.detection.SpotGlobalDetectorFactory;
/*     */ import fiji.plugin.trackmate.features.EdgeFeatureCalculator;
/*     */ import fiji.plugin.trackmate.features.FeatureFilter;
/*     */ import fiji.plugin.trackmate.features.SpotFeatureCalculator;
/*     */ import fiji.plugin.trackmate.features.TrackFeatureCalculator;
/*     */ import fiji.plugin.trackmate.tracking.SpotTracker;
/*     */ import fiji.plugin.trackmate.util.TMUtils;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.Callable;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.Executors;
/*     */ import java.util.concurrent.Future;
/*     */ import java.util.concurrent.atomic.AtomicBoolean;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ import net.imagej.ImgPlus;
/*     */ import net.imagej.axis.Axes;
/*     */ import net.imglib2.Interval;
/*     */ import net.imglib2.algorithm.Algorithm;
/*     */ import net.imglib2.algorithm.Benchmark;
/*     */ import net.imglib2.algorithm.MultiThreaded;
/*     */ import org.jgrapht.graph.DefaultWeightedEdge;
/*     */ import org.jgrapht.graph.SimpleWeightedGraph;
/*     */ import org.scijava.Cancelable;
/*     */ import org.scijava.Named;
/*     */ import org.scijava.util.VersionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TrackMate
/*     */   implements Benchmark, MultiThreaded, Algorithm, Named, Cancelable
/*     */ {
/*     */   public static final String PLUGIN_NAME_STR = "TrackMate";
/*  78 */   public static final String PLUGIN_NAME_VERSION = VersionUtils.getVersion(TrackMate.class);
/*     */ 
/*     */   
/*     */   protected final Model model;
/*     */ 
/*     */   
/*     */   protected final Settings settings;
/*     */ 
/*     */   
/*     */   protected long processingTime;
/*     */   
/*     */   protected String errorMessage;
/*     */   
/*  91 */   protected int numThreads = Runtime.getRuntime().availableProcessors();
/*     */   
/*     */   private String name;
/*     */   
/*     */   private boolean isCanceled;
/*     */   
/*     */   private String cancelReason;
/*     */   
/*  99 */   private final List<Cancelable> cancelables = Collections.synchronizedList(new ArrayList<>());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TrackMate(Settings settings) {
/* 107 */     this(new Model(), settings);
/*     */   }
/*     */ 
/*     */   
/*     */   public TrackMate(Model model, Settings settings) {
/* 112 */     this.model = model;
/* 113 */     this.settings = settings;
/* 114 */     this.name = "TrackMate_v" + PLUGIN_NAME_VERSION;
/* 115 */     if (settings.imp != null)
/* 116 */       this.name += "_(" + settings.imp.getTitle().replace(' ', '_') + ")"; 
/* 117 */     this.name += "_[" + Integer.toHexString(hashCode()) + "]";
/*     */   }
/*     */ 
/*     */   
/*     */   public TrackMate() {
/* 122 */     this(new Model(), new Settings());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Model getModel() {
/* 131 */     return this.model;
/*     */   }
/*     */ 
/*     */   
/*     */   public Settings getSettings() {
/* 136 */     return this.settings;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean computeSpotFeatures(boolean doLogIt) {
/* 158 */     this.isCanceled = false;
/* 159 */     this.cancelReason = null;
/* 160 */     this.cancelables.clear();
/*     */     
/* 162 */     Logger logger = this.model.getLogger();
/* 163 */     SpotFeatureCalculator calculator = new SpotFeatureCalculator(this.model, this.settings, doLogIt);
/* 164 */     this.cancelables.add(calculator);
/* 165 */     calculator.setNumThreads(this.numThreads);
/* 166 */     if (calculator.checkInput() && calculator.process()) {
/*     */       
/* 168 */       if (doLogIt) {
/*     */         
/* 170 */         if (isCanceled()) {
/* 171 */           logger.log("Spot feature calculation canceled. Reason:\n" + getCancelReason() + "\n");
/*     */         }
/* 173 */         logger.log("Computation done in " + calculator.getProcessingTime() + " ms.\n");
/*     */       } 
/*     */       
/* 176 */       this.model.notifyFeaturesComputed();
/* 177 */       return true;
/*     */     } 
/*     */     
/* 180 */     this.errorMessage = "Spot features calculation failed:\n" + calculator.getErrorMessage();
/* 181 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean computeEdgeFeatures(boolean doLogIt) {
/* 199 */     this.isCanceled = false;
/* 200 */     this.cancelReason = null;
/* 201 */     this.cancelables.clear();
/*     */     
/* 203 */     Logger logger = this.model.getLogger();
/* 204 */     EdgeFeatureCalculator calculator = new EdgeFeatureCalculator(this.model, this.settings, doLogIt);
/* 205 */     this.cancelables.add(calculator);
/* 206 */     calculator.setNumThreads(this.numThreads);
/* 207 */     if (!calculator.checkInput() || !calculator.process()) {
/*     */       
/* 209 */       this.errorMessage = "Edge features calculation failed:\n" + calculator.getErrorMessage();
/* 210 */       return false;
/*     */     } 
/* 212 */     if (doLogIt) {
/*     */       
/* 214 */       if (isCanceled()) {
/* 215 */         logger.log("Spot feature calculation canceled. Reason:\n" + getCancelReason() + "\n");
/*     */       }
/* 217 */       logger.log("Computation done in " + calculator.getProcessingTime() + " ms.\n");
/*     */     } 
/*     */     
/* 220 */     this.model.notifyFeaturesComputed();
/* 221 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean computeTrackFeatures(boolean doLogIt) {
/* 233 */     this.isCanceled = false;
/* 234 */     this.cancelReason = null;
/* 235 */     this.cancelables.clear();
/*     */     
/* 237 */     Logger logger = this.model.getLogger();
/* 238 */     TrackFeatureCalculator calculator = new TrackFeatureCalculator(this.model, this.settings, doLogIt);
/* 239 */     this.cancelables.add(calculator);
/* 240 */     calculator.setNumThreads(this.numThreads);
/* 241 */     if (calculator.checkInput() && calculator.process()) {
/*     */       
/* 243 */       if (doLogIt) {
/*     */         
/* 245 */         if (isCanceled()) {
/* 246 */           logger.log("Spot feature calculation canceled. Reason:\n" + getCancelReason() + "\n");
/*     */         }
/* 248 */         logger.log("Computation done in " + calculator.getProcessingTime() + " ms.\n");
/*     */       } 
/*     */       
/* 251 */       this.model.notifyFeaturesComputed();
/* 252 */       return true;
/*     */     } 
/*     */     
/* 255 */     this.errorMessage = "Track features calculation failed:\n" + calculator.getErrorMessage();
/* 256 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean execTracking() {
/* 275 */     this.isCanceled = false;
/* 276 */     this.cancelReason = null;
/* 277 */     this.cancelables.clear();
/*     */     
/* 279 */     Logger logger = this.model.getLogger();
/* 280 */     logger.log("Starting tracking process.\n", Logger.BLUE_COLOR);
/*     */     
/* 282 */     if (this.settings.trackerFactory == null) {
/*     */       
/* 284 */       logger.log("Tracker factory is not defined. Skipping tracking.\n");
/* 285 */       return true;
/*     */     } 
/*     */     
/* 288 */     SpotTracker tracker = this.settings.trackerFactory.create(this.model.getSpots(), this.settings.trackerSettings);
/* 289 */     if (tracker == null) {
/*     */       
/* 291 */       logger.log("Tracker return by factory is null. Skipping tracking.\n");
/* 292 */       return true;
/*     */     } 
/*     */     
/* 295 */     if (tracker instanceof Cancelable)
/* 296 */       this.cancelables.add((Cancelable)tracker); 
/* 297 */     tracker.setNumThreads(this.numThreads);
/* 298 */     tracker.setLogger(logger);
/* 299 */     if (tracker.checkInput() && tracker.process()) {
/*     */       
/* 301 */       if (isCanceled()) {
/* 302 */         logger.log("Tracking canceled. Reason:\n" + getCancelReason() + "\n");
/*     */       }
/* 304 */       this.model.setTracks((SimpleWeightedGraph<Spot, DefaultWeightedEdge>)tracker.getResult(), true);
/* 305 */       return true;
/*     */     } 
/*     */     
/* 308 */     this.errorMessage = "Tracking process failed:\n" + tracker.getErrorMessage();
/* 309 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean execDetection() {
/* 325 */     this.isCanceled = false;
/* 326 */     this.cancelReason = null;
/* 327 */     this.cancelables.clear();
/*     */     
/* 329 */     Logger logger = this.model.getLogger();
/* 330 */     logger.log("Starting detection process using " + ((this.numThreads > 1) ? (this.numThreads + " threads") : "1 thread") + ".\n", Logger.BLUE_COLOR);
/*     */ 
/*     */ 
/*     */     
/* 334 */     SpotDetectorFactoryBase<?> factory = this.settings.detectorFactory;
/* 335 */     if (null == factory) {
/*     */       
/* 337 */       this.errorMessage = "Detector factory is null.\n";
/* 338 */       return false;
/*     */     } 
/* 340 */     if (null == this.settings.detectorSettings) {
/*     */       
/* 342 */       this.errorMessage = "Detector settings is null.\n";
/* 343 */       return false;
/*     */     } 
/* 345 */     if (factory instanceof fiji.plugin.trackmate.detection.ManualDetectorFactory)
/*     */     {
/*     */ 
/*     */       
/* 349 */       return true;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 355 */     ImgPlus img = TMUtils.rawWraps(this.settings.imp);
/*     */     
/* 357 */     if (!factory.setTarget(img, this.settings.detectorSettings)) {
/*     */       
/* 359 */       this.errorMessage = factory.getErrorMessage();
/* 360 */       return false;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 368 */     if (factory instanceof SpotGlobalDetectorFactory)
/*     */     {
/* 370 */       return processGlobal((SpotGlobalDetectorFactory)factory, img, logger);
/*     */     }
/* 372 */     if (factory instanceof SpotDetectorFactory)
/*     */     {
/* 374 */       return processFrameByFrame((SpotDetectorFactory)factory, img, logger);
/*     */     }
/*     */     
/* 377 */     this.errorMessage = "Don't know how to handle detector factory of type: " + factory.getClass();
/* 378 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean processGlobal(SpotGlobalDetectorFactory factory, ImgPlus img, Logger logger) {
/* 384 */     Interval interval = TMUtils.getIntervalWithTime(img, this.settings);
/*     */ 
/*     */     
/* 387 */     double[] calibration = TMUtils.getSpatialCalibration(this.settings.imp);
/*     */     
/* 389 */     SpotGlobalDetector<?> detector = factory.getDetector(interval);
/* 390 */     if (detector instanceof MultiThreaded) {
/*     */       
/* 392 */       MultiThreaded md = (MultiThreaded)detector;
/* 393 */       md.setNumThreads(this.numThreads);
/*     */     } 
/*     */     
/* 396 */     if (detector instanceof Cancelable) {
/* 397 */       this.cancelables.add((Cancelable)detector);
/*     */     }
/*     */     
/* 400 */     logger.setStatus("Detection...");
/* 401 */     if (detector.checkInput() && detector.process()) {
/*     */       
/* 403 */       SpotCollection spots, rawSpots = (SpotCollection)detector.getResult();
/* 404 */       rawSpots.setNumThreads(this.numThreads);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 410 */       if (this.settings.roi != null) {
/*     */         
/* 412 */         spots = new SpotCollection();
/* 413 */         spots.setNumThreads(this.numThreads);
/* 414 */         for (int frame = this.settings.tstart; frame <= this.settings.tend; frame++) {
/*     */           
/* 416 */           List<Spot> spotsThisFrame = new ArrayList<>();
/* 417 */           Iterable<Spot> spotsIt = rawSpots.iterable(frame, false);
/* 418 */           if (spotsIt != null) {
/*     */ 
/*     */             
/* 421 */             for (Spot spot : spotsIt) {
/*     */               
/* 423 */               if (this.settings.roi.contains(
/* 424 */                   (int)Math.round(spot.getFeature("POSITION_X").doubleValue() / calibration[0]), 
/* 425 */                   (int)Math.round(spot.getFeature("POSITION_Y").doubleValue() / calibration[1])))
/*     */               {
/* 427 */                 spotsThisFrame.add(spot);
/*     */               }
/*     */             } 
/* 430 */             spots.put(frame, spotsThisFrame);
/*     */           } 
/*     */         } 
/*     */       } else {
/*     */         
/* 435 */         spots = rawSpots;
/*     */       } 
/*     */ 
/*     */       
/* 439 */       for (Spot spot : spots.iterable(false)) {
/* 440 */         spot.putFeature("POSITION_T", Double.valueOf(spot.getFeature("FRAME").doubleValue() * this.settings.dt));
/*     */       }
/* 442 */       this.model.setSpots(spots, true);
/* 443 */       logger.setStatus("");
/* 444 */       if (isCanceled())
/* 445 */         logger.log("Detection canceled. Reason:\n" + getCancelReason() + "\n"); 
/* 446 */       logger.log("Found " + spots.getNSpots(false) + " spots.\n");
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 451 */       this.errorMessage = detector.getErrorMessage();
/* 452 */       return false;
/*     */     } 
/*     */     
/* 455 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean processFrameByFrame(final SpotDetectorFactory factory, final ImgPlus img, final Logger logger) {
/* 461 */     final Interval interval = TMUtils.getInterval(img, this.settings);
/* 462 */     final int zindex = img.dimensionIndex(Axes.Z);
/* 463 */     final int numFrames = this.settings.tend - this.settings.tstart + 1;
/*     */     
/* 465 */     final SpotCollection spots = new SpotCollection();
/* 466 */     spots.setNumThreads(this.numThreads);
/*     */     
/* 468 */     final AtomicInteger spotFound = new AtomicInteger(0);
/* 469 */     final AtomicInteger progress = new AtomicInteger(0);
/*     */     
/* 471 */     final double[] calibration = TMUtils.getSpatialCalibration(this.settings.imp);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 481 */     int nSimultaneousFrames = factory.forbidMultithreading() ? 1 : Math.min(this.numThreads, numFrames);
/* 482 */     final int threadsPerFrame = Math.max(1, this.numThreads / nSimultaneousFrames);
/*     */     
/* 484 */     logger.log("Detection processes " + ((nSimultaneousFrames > 1) ? (nSimultaneousFrames + " frames") : "1 frame") + " simultaneously and allocates " + ((threadsPerFrame > 1) ? (threadsPerFrame + " threads") : "1 thread") + " per frame.\n");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 490 */     ExecutorService executorService = Executors.newFixedThreadPool(nSimultaneousFrames);
/* 491 */     List<Future<Boolean>> tasks = new ArrayList<>(numFrames);
/* 492 */     for (int i = this.settings.tstart; i <= this.settings.tend; i++) {
/*     */       
/* 494 */       final int frame = i;
/* 495 */       Callable<Boolean> callable = new Callable<Boolean>()
/*     */         {
/*     */ 
/*     */           
/*     */           public Boolean call() throws Exception
/*     */           {
/* 501 */             if (TrackMate.this.isCanceled()) {
/* 502 */               return Boolean.TRUE;
/*     */             }
/*     */             
/* 505 */             SpotDetector<?> detector = factory.getDetector(interval, frame);
/* 506 */             if (detector instanceof MultiThreaded) {
/*     */               
/* 508 */               MultiThreaded md = (MultiThreaded)detector;
/* 509 */               md.setNumThreads(threadsPerFrame);
/*     */             } 
/*     */             
/* 512 */             if (detector instanceof Cancelable) {
/* 513 */               TrackMate.this.cancelables.add((Cancelable)detector);
/*     */             }
/*     */             
/* 516 */             if (detector.checkInput() && detector.process()) {
/*     */ 
/*     */               
/* 519 */               List<Spot> prunedSpots, spotsThisFrame = (List<Spot>)detector.getResult();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */               
/* 527 */               if (img.dimension(0) < 2L && zindex < 0)
/*     */               {
/* 529 */                 for (Spot spot : spotsThisFrame) {
/*     */                   
/* 531 */                   spot.putFeature("POSITION_Y", Double.valueOf(spot.getDoublePosition(0)));
/* 532 */                   spot.putFeature("POSITION_X", Double.valueOf(0.0D));
/*     */                 } 
/*     */               }
/*     */ 
/*     */               
/* 537 */               if (TrackMate.this.settings.roi != null) {
/*     */                 
/* 539 */                 prunedSpots = new ArrayList<>();
/* 540 */                 for (Spot spot : spotsThisFrame) {
/*     */                   
/* 542 */                   if (TrackMate.this.settings.roi.contains(
/* 543 */                       (int)Math.round(spot.getFeature("POSITION_X").doubleValue() / calibration[0]), 
/* 544 */                       (int)Math.round(spot.getFeature("POSITION_Y").doubleValue() / calibration[1]))) {
/* 545 */                     prunedSpots.add(spot);
/*     */                   }
/*     */                 } 
/*     */               } else {
/*     */                 
/* 550 */                 prunedSpots = spotsThisFrame;
/*     */               } 
/*     */               
/* 553 */               for (Spot spot : prunedSpots)
/*     */               {
/*     */ 
/*     */                 
/* 557 */                 spot.putFeature("POSITION_T", Double.valueOf(frame * TrackMate.this.settings.dt));
/*     */               }
/*     */               
/* 560 */               spots.put(frame, prunedSpots);
/*     */               
/* 562 */               spotFound.addAndGet(prunedSpots.size());
/* 563 */               logger.setProgress(progress.incrementAndGet() / numFrames);
/*     */             
/*     */             }
/*     */             else {
/*     */ 
/*     */               
/* 569 */               TrackMate.this.errorMessage = detector.getErrorMessage();
/* 570 */               return Boolean.FALSE;
/*     */             } 
/* 572 */             return Boolean.TRUE;
/*     */           }
/*     */         };
/* 575 */       Future<Boolean> task = executorService.submit(callable);
/* 576 */       tasks.add(task);
/*     */     } 
/* 578 */     logger.setStatus("Detection...");
/* 579 */     logger.setProgress(0.0D);
/*     */     
/* 581 */     AtomicBoolean reportOk = new AtomicBoolean(true);
/*     */     
/*     */     try {
/* 584 */       for (Future<Boolean> task : tasks) {
/*     */         
/* 586 */         Boolean ok = task.get();
/* 587 */         if (!ok.booleanValue()) {
/*     */           
/* 589 */           reportOk.set(false);
/*     */           
/*     */           break;
/*     */         } 
/*     */       } 
/* 594 */     } catch (InterruptedException|java.util.concurrent.ExecutionException e) {
/*     */       
/* 596 */       this.errorMessage = "Problem during detection: " + e.getMessage();
/* 597 */       reportOk.set(false);
/* 598 */       e.printStackTrace();
/*     */     } 
/*     */     
/* 601 */     this.model.setSpots(spots, true);
/*     */     
/* 603 */     if (reportOk.get()) {
/*     */       
/* 605 */       if (isCanceled())
/* 606 */         logger.log("Detection canceled after " + (progress.get() + 1) + " frames. Reason:\n" + getCancelReason() + "\n"); 
/* 607 */       logger.log("Found " + spotFound.get() + " spots.\n");
/*     */     }
/*     */     else {
/*     */       
/* 611 */       logger.error("Detection failed after " + progress.get() + " frames:\n" + this.errorMessage);
/* 612 */       logger.log("Found " + spotFound.get() + " spots prior failure.\n");
/*     */     } 
/* 614 */     logger.setProgress(1.0D);
/* 615 */     logger.setStatus("");
/* 616 */     return reportOk.get();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean execInitialSpotFiltering() {
/* 646 */     Logger logger = this.model.getLogger();
/* 647 */     logger.log("Starting initial filtering process.\n");
/*     */     
/* 649 */     Double initialSpotFilterValue = this.settings.initialSpotFilterValue;
/* 650 */     FeatureFilter featureFilter = new FeatureFilter("QUALITY", initialSpotFilterValue.doubleValue(), true);
/*     */     
/* 652 */     SpotCollection spots = this.model.getSpots();
/* 653 */     spots.filter(featureFilter);
/* 654 */     spots.crop();
/* 655 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean execSpotFiltering(boolean doLogIt) {
/* 680 */     if (doLogIt) {
/*     */       
/* 682 */       Logger logger = this.model.getLogger();
/* 683 */       logger.log("Starting spot filtering process.\n");
/*     */     } 
/* 685 */     this.model.filterSpots(this.settings.getSpotFilters(), true);
/* 686 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean execTrackFiltering(boolean doLogIt) {
/* 693 */     if (doLogIt) {
/*     */       
/* 695 */       Logger logger = this.model.getLogger();
/* 696 */       logger.log("Starting track filtering process.\n");
/*     */     } 
/*     */     
/* 699 */     this.model.beginUpdate();
/*     */     
/*     */     try {
/* 702 */       for (Integer trackID : this.model.getTrackModel().trackIDs(false))
/*     */       {
/* 704 */         boolean trackIsOk = true;
/* 705 */         for (FeatureFilter filter : this.settings.getTrackFilters()) {
/*     */           
/* 707 */           Double tval = Double.valueOf(filter.value);
/* 708 */           Double val = this.model.getFeatureModel().getTrackFeature(trackID, filter.feature);
/* 709 */           if (null == val) {
/*     */             continue;
/*     */           }
/* 712 */           if (filter.isAbove) {
/*     */             
/* 714 */             if (val.doubleValue() < tval.doubleValue()) {
/*     */               
/* 716 */               trackIsOk = false;
/*     */               
/*     */               break;
/*     */             } 
/*     */             continue;
/*     */           } 
/* 722 */           if (val.doubleValue() > tval.doubleValue()) {
/*     */             
/* 724 */             trackIsOk = false;
/*     */             
/*     */             break;
/*     */           } 
/*     */         } 
/* 729 */         this.model.setTrackVisibility(trackID, trackIsOk);
/*     */       }
/*     */     
/*     */     } finally {
/*     */       
/* 734 */       this.model.endUpdate();
/*     */     } 
/* 736 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 742 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean checkInput() {
/* 752 */     if (null == this.model) {
/*     */       
/* 754 */       this.errorMessage = "The model is null.\n";
/* 755 */       return false;
/*     */     } 
/* 757 */     if (null == this.settings) {
/*     */       
/* 759 */       this.errorMessage = "Settings are null";
/* 760 */       return false;
/*     */     } 
/* 762 */     if (!this.settings.checkValidity()) {
/*     */       
/* 764 */       this.errorMessage = this.settings.getErrorMessage();
/* 765 */       return false;
/*     */     } 
/* 767 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getErrorMessage() {
/* 773 */     return this.errorMessage;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean process() {
/* 779 */     if (!execDetection())
/* 780 */       return false; 
/* 781 */     if (isCanceled()) {
/* 782 */       return true;
/*     */     }
/* 784 */     if (!execInitialSpotFiltering())
/* 785 */       return false; 
/* 786 */     if (isCanceled()) {
/* 787 */       return true;
/*     */     }
/* 789 */     if (!computeSpotFeatures(true))
/* 790 */       return false; 
/* 791 */     if (isCanceled()) {
/* 792 */       return true;
/*     */     }
/* 794 */     if (!execSpotFiltering(true))
/* 795 */       return false; 
/* 796 */     if (isCanceled()) {
/* 797 */       return true;
/*     */     }
/* 799 */     if (!execTracking())
/* 800 */       return false; 
/* 801 */     if (isCanceled()) {
/* 802 */       return true;
/*     */     }
/* 804 */     if (!computeEdgeFeatures(true))
/* 805 */       return false; 
/* 806 */     if (isCanceled()) {
/* 807 */       return true;
/*     */     }
/* 809 */     if (!computeTrackFeatures(true))
/* 810 */       return false; 
/* 811 */     if (isCanceled()) {
/* 812 */       return true;
/*     */     }
/* 814 */     if (!execTrackFiltering(true)) {
/* 815 */       return false;
/*     */     }
/* 817 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getNumThreads() {
/* 823 */     return this.numThreads;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setNumThreads() {
/* 829 */     this.numThreads = Runtime.getRuntime().availableProcessors();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setNumThreads(int numThreads) {
/* 835 */     this.numThreads = numThreads;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public long getProcessingTime() {
/* 841 */     return this.processingTime;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/* 849 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setName(String name) {
/* 855 */     this.name = name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isCanceled() {
/* 863 */     return this.isCanceled;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void cancel(String reason) {
/* 869 */     this.isCanceled = true;
/* 870 */     this.cancelReason = reason;
/* 871 */     this.cancelables.forEach(c -> c.cancel(reason));
/* 872 */     this.cancelables.clear();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getCancelReason() {
/* 878 */     return this.cancelReason;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/TrackMate.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */