/*     */ package fiji.plugin.trackmate.action;
/*     */ 
/*     */ import fiji.plugin.trackmate.Model;
/*     */ import fiji.plugin.trackmate.SelectionModel;
/*     */ import fiji.plugin.trackmate.Spot;
/*     */ import fiji.plugin.trackmate.SpotCollection;
/*     */ import fiji.plugin.trackmate.TrackMate;
/*     */ import fiji.plugin.trackmate.TrackModel;
/*     */ import fiji.plugin.trackmate.gui.Icons;
/*     */ import fiji.plugin.trackmate.gui.displaysettings.DisplaySettings;
/*     */ import java.awt.Frame;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import javax.swing.ImageIcon;
/*     */ import org.scijava.plugin.Plugin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TrimNotVisibleAction
/*     */   extends AbstractTMAction
/*     */ {
/*     */   public static final String INFO_TEXT = "<html>This action trims the tracking data by removing anything that is not marked as visible. <p>The spots that do not belong to a visible track will be removed. The tracks that are not marked as visible will be removed as well. <p>This action is irreversible. It helps limiting the memory and disk space of tracking data that has been properly curated.</html>";
/*     */   public static final String KEY = "TRIM_NOT_VISIBLE";
/*     */   public static final String NAME = "Trim non-visible data";
/*     */   
/*     */   public void execute(TrackMate trackmate, SelectionModel selectionModel, DisplaySettings displaySettings, Frame parent) {
/*  65 */     Model model = trackmate.getModel();
/*  66 */     TrackModel tm = model.getTrackModel();
/*     */     
/*  68 */     SpotCollection spots = new SpotCollection();
/*  69 */     spots.setNumThreads(trackmate.getNumThreads());
/*  70 */     Collection<Spot> toRemove = new ArrayList<>();
/*     */     
/*  72 */     for (Integer trackID : tm.unsortedTrackIDs(false)) {
/*     */       
/*  74 */       if (!tm.isVisible(trackID)) {
/*     */         
/*  76 */         for (Spot spot : tm.trackSpots(trackID)) {
/*  77 */           toRemove.add(spot);
/*     */         }
/*     */         continue;
/*     */       } 
/*  81 */       for (Spot spot : tm.trackSpots(trackID)) {
/*  82 */         spots.add(spot, Integer.valueOf(spot.getFeature("FRAME").intValue()));
/*     */       }
/*     */     } 
/*     */     
/*  86 */     model.beginUpdate();
/*     */     
/*     */     try {
/*  89 */       for (Spot spot : toRemove) {
/*  90 */         model.removeSpot(spot);
/*     */       }
/*  92 */       model.setSpots(spots, false);
/*     */     }
/*     */     finally {
/*     */       
/*  96 */       model.endUpdate();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Plugin(type = TrackMateActionFactory.class)
/*     */   public static class Factory
/*     */     implements TrackMateActionFactory
/*     */   {
/*     */     public String getInfoText() {
/* 107 */       return "<html>This action trims the tracking data by removing anything that is not marked as visible. <p>The spots that do not belong to a visible track will be removed. The tracks that are not marked as visible will be removed as well. <p>This action is irreversible. It helps limiting the memory and disk space of tracking data that has been properly curated.</html>";
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public String getKey() {
/* 113 */       return "TRIM_NOT_VISIBLE";
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public TrackMateAction create() {
/* 119 */       return new TrimNotVisibleAction();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public ImageIcon getIcon() {
/* 125 */       return Icons.BIN_ICON;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public String getName() {
/* 131 */       return "Trim non-visible data";
/*     */     }
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/action/TrimNotVisibleAction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */