/*     */ package fiji.plugin.trackmate.gui.displaysettings;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Font;
/*     */ import java.util.Objects;
/*     */ import org.scijava.listeners.Listeners;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DisplaySettings
/*     */ {
/*     */   private String name;
/*     */   private Color spotUniformColor;
/*     */   private TrackMateObject spotColorByType;
/*     */   private String spotColorByFeature;
/*     */   private double spotDisplayRadius;
/*     */   private boolean spotDisplayedAsRoi;
/*     */   private double spotMin;
/*     */   private double spotMax;
/*     */   private boolean spotShowName;
/*     */   private double trackMin;
/*     */   private double trackMax;
/*     */   private TrackMateObject trackColorByType;
/*     */   private String trackColorByFeature;
/*     */   private Color trackUniformColor;
/*     */   private Color undefinedValueColor;
/*     */   private Color missingValueColor;
/*     */   private Color highlightColor;
/*     */   private TrackDisplayMode trackDisplayMode;
/*     */   private Colormap colormap;
/*     */   private boolean limitZDrawingDepth;
/*     */   private double drawingZDepth;
/*     */   private boolean fadeTracks;
/*     */   private int fadeTrackRange;
/*     */   private boolean useAntialiasing;
/*     */   private boolean spotVisible;
/*     */   private boolean trackVisible;
/*     */   private Font font;
/*     */   private double lineThickness;
/*     */   private double selectionLineThickness;
/*     */   private Color trackschemeBackgroundColor1;
/*     */   private Color trackschemeBackgroundColor2;
/*     */   private Color trackschemeForegroundColor;
/*     */   private Color trackschemeDecorationColor;
/*     */   private boolean trackschemeFillBox;
/*     */   private boolean spotFilled;
/*     */   private double spotTransparencyAlpha;
/*     */   private final transient Listeners.List<UpdateListener> updateListeners;
/*     */   
/*     */   public DisplaySettings() {
/* 135 */     this.updateListeners = (Listeners.List<UpdateListener>)new Listeners.SynchronizedList();
/* 136 */     set(df);
/*     */   }
/*     */ 
/*     */   
/*     */   private DisplaySettings(String name) {
/* 141 */     this.name = name;
/* 142 */     this.updateListeners = (Listeners.List<UpdateListener>)new Listeners.SynchronizedList();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DisplaySettings copy(String name) {
/* 154 */     DisplaySettings rs = new DisplaySettings();
/* 155 */     rs.set(this);
/* 156 */     if (name != null)
/* 157 */       rs.setName(name); 
/* 158 */     return rs;
/*     */   }
/*     */ 
/*     */   
/*     */   public DisplaySettings copy() {
/* 163 */     return copy(null);
/*     */   }
/*     */ 
/*     */   
/*     */   synchronized void set(DisplaySettings ds) {
/* 168 */     this.name = ds.name;
/*     */     
/* 170 */     this.spotVisible = ds.spotVisible;
/* 171 */     this.spotDisplayedAsRoi = ds.spotDisplayedAsRoi;
/* 172 */     this.spotShowName = ds.spotShowName;
/* 173 */     this.spotDisplayRadius = ds.spotDisplayRadius;
/* 174 */     this.spotColorByType = ds.spotColorByType;
/* 175 */     this.spotColorByFeature = ds.spotColorByFeature;
/* 176 */     this.spotMin = ds.spotMin;
/* 177 */     this.spotMax = ds.spotMax;
/* 178 */     this.spotUniformColor = ds.spotUniformColor;
/* 179 */     this.spotFilled = ds.spotFilled;
/* 180 */     this.spotTransparencyAlpha = ds.spotTransparencyAlpha;
/*     */     
/* 182 */     this.trackVisible = ds.trackVisible;
/* 183 */     this.trackColorByFeature = ds.trackColorByFeature;
/* 184 */     this.trackColorByType = ds.trackColorByType;
/* 185 */     this.trackDisplayMode = ds.trackDisplayMode;
/* 186 */     this.trackMin = ds.trackMin;
/* 187 */     this.trackMax = ds.trackMax;
/* 188 */     this.fadeTracks = ds.fadeTracks;
/* 189 */     this.fadeTrackRange = ds.fadeTrackRange;
/* 190 */     this.trackUniformColor = ds.trackUniformColor;
/*     */     
/* 192 */     this.colormap = ds.colormap;
/* 193 */     this.limitZDrawingDepth = ds.limitZDrawingDepth;
/* 194 */     this.drawingZDepth = ds.drawingZDepth;
/* 195 */     this.highlightColor = ds.highlightColor;
/* 196 */     this.missingValueColor = ds.missingValueColor;
/* 197 */     this.undefinedValueColor = ds.undefinedValueColor;
/* 198 */     this.useAntialiasing = ds.useAntialiasing;
/*     */     
/* 200 */     this.font = ds.font;
/* 201 */     this.lineThickness = ds.lineThickness;
/* 202 */     this.selectionLineThickness = ds.selectionLineThickness;
/* 203 */     this.trackschemeBackgroundColor1 = ds.trackschemeBackgroundColor1;
/* 204 */     this.trackschemeBackgroundColor2 = ds.trackschemeBackgroundColor2;
/* 205 */     this.trackschemeDecorationColor = ds.trackschemeDecorationColor;
/* 206 */     this.trackschemeForegroundColor = ds.trackschemeForegroundColor;
/* 207 */     this.trackschemeFillBox = ds.trackschemeFillBox;
/*     */     
/* 209 */     notifyListeners();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getName() {
/* 214 */     return this.name;
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized void setName(String name) {
/* 219 */     if (!Objects.equals(this.name, name)) {
/*     */       
/* 221 */       this.name = name;
/* 222 */       notifyListeners();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Colormap getColormap() {
/* 228 */     return this.colormap;
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized void setColormap(Colormap colormap) {
/* 233 */     if (this.colormap != colormap) {
/*     */       
/* 235 */       this.colormap = colormap;
/* 236 */       notifyListeners();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isZDrawingDepthLimited() {
/* 242 */     return this.limitZDrawingDepth;
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized void setZDrawingDepthLimited(boolean limitZDrawingDepth) {
/* 247 */     if (this.limitZDrawingDepth != limitZDrawingDepth) {
/*     */       
/* 249 */       this.limitZDrawingDepth = limitZDrawingDepth;
/* 250 */       notifyListeners();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public double getZDrawingDepth() {
/* 256 */     return this.drawingZDepth;
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized void setZDrawingDepth(double drawingZDepth) {
/* 261 */     if (this.drawingZDepth != drawingZDepth) {
/*     */       
/* 263 */       this.drawingZDepth = drawingZDepth;
/* 264 */       notifyListeners();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Color getHighlightColor() {
/* 270 */     return this.highlightColor;
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized void setHighlightColor(Color highlightColor) {
/* 275 */     if (this.highlightColor != highlightColor) {
/*     */       
/* 277 */       this.highlightColor = highlightColor;
/* 278 */       notifyListeners();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isFadeTracks() {
/* 284 */     return this.fadeTracks;
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized void setFadeTracks(boolean fadeTracks) {
/* 289 */     if (this.fadeTracks != fadeTracks) {
/*     */       
/* 291 */       this.fadeTracks = fadeTracks;
/* 292 */       notifyListeners();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Color getMissingValueColor() {
/* 298 */     return this.missingValueColor;
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized void setMissingValueColor(Color missingValueColor) {
/* 303 */     if (this.missingValueColor != missingValueColor) {
/*     */       
/* 305 */       this.missingValueColor = missingValueColor;
/* 306 */       notifyListeners();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public String getSpotColorByFeature() {
/* 312 */     return this.spotColorByFeature;
/*     */   }
/*     */ 
/*     */   
/*     */   public TrackMateObject getSpotColorByType() {
/* 317 */     return this.spotColorByType;
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized void setSpotColorBy(TrackMateObject spotColorByType, String spotColorByFeature) {
/* 322 */     boolean fire = false;
/* 323 */     if (this.spotColorByType != spotColorByType) {
/*     */       
/* 325 */       this.spotColorByType = spotColorByType;
/* 326 */       fire = true;
/*     */     } 
/* 328 */     if (this.spotColorByFeature != spotColorByFeature) {
/*     */       
/* 330 */       this.spotColorByFeature = spotColorByFeature;
/* 331 */       fire = true;
/*     */     } 
/* 333 */     if (fire) {
/* 334 */       notifyListeners();
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean isSpotDisplayedAsRoi() {
/* 339 */     return this.spotDisplayedAsRoi;
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized void setSpotDisplayedAsRoi(boolean spotDisplayedAsRoi) {
/* 344 */     if (this.spotDisplayedAsRoi != spotDisplayedAsRoi) {
/*     */       
/* 346 */       this.spotDisplayedAsRoi = spotDisplayedAsRoi;
/* 347 */       notifyListeners();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public double getSpotDisplayRadius() {
/* 353 */     return this.spotDisplayRadius;
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized void setSpotDisplayRadius(double spotDisplayRadius) {
/* 358 */     if (this.spotDisplayRadius != spotDisplayRadius) {
/*     */       
/* 360 */       this.spotDisplayRadius = spotDisplayRadius;
/* 361 */       notifyListeners();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public double getSpotMax() {
/* 367 */     return this.spotMax;
/*     */   }
/*     */ 
/*     */   
/*     */   public double getSpotMin() {
/* 372 */     return this.spotMin;
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized void setSpotMinMax(double spotMin, double spotMax) {
/* 377 */     double smin = Math.min(spotMin, spotMax);
/* 378 */     double smax = Math.max(spotMin, spotMax);
/*     */     
/* 380 */     boolean notify = false;
/* 381 */     if (this.spotMin != smin) {
/*     */       
/* 383 */       this.spotMin = smin;
/* 384 */       notify = true;
/*     */     } 
/* 386 */     if (this.spotMax != smax) {
/*     */       
/* 388 */       this.spotMax = smax;
/* 389 */       notify = true;
/*     */     } 
/* 391 */     if (notify) {
/* 392 */       notifyListeners();
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean isSpotShowName() {
/* 397 */     return this.spotShowName;
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized void setSpotShowName(boolean spotShowName) {
/* 402 */     if (this.spotShowName != spotShowName) {
/*     */       
/* 404 */       this.spotShowName = spotShowName;
/* 405 */       notifyListeners();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isSpotVisible() {
/* 411 */     return this.spotVisible;
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized void setSpotVisible(boolean spotsVisible) {
/* 416 */     if (this.spotVisible != spotsVisible) {
/*     */       
/* 418 */       this.spotVisible = spotsVisible;
/* 419 */       notifyListeners();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Color getSpotUniformColor() {
/* 425 */     return this.spotUniformColor;
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized void setSpotUniformColor(Color spotUniformColor) {
/* 430 */     if (this.spotUniformColor != spotUniformColor) {
/*     */       
/* 432 */       this.spotUniformColor = spotUniformColor;
/* 433 */       notifyListeners();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public int getFadeTrackRange() {
/* 439 */     return this.fadeTrackRange;
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized void setFadeTrackRange(int fadeTrackRange) {
/* 444 */     if (this.fadeTrackRange != fadeTrackRange) {
/*     */       
/* 446 */       this.fadeTrackRange = fadeTrackRange;
/* 447 */       notifyListeners();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public TrackDisplayMode getTrackDisplayMode() {
/* 453 */     return this.trackDisplayMode;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getTrackColorByFeature() {
/* 458 */     return this.trackColorByFeature;
/*     */   }
/*     */ 
/*     */   
/*     */   public TrackMateObject getTrackColorByType() {
/* 463 */     return this.trackColorByType;
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized void setTrackColorBy(TrackMateObject trackColorByType, String trackColorByFeature) {
/* 468 */     boolean fire = false;
/* 469 */     if (this.trackColorByType != trackColorByType) {
/*     */       
/* 471 */       this.trackColorByType = trackColorByType;
/* 472 */       fire = true;
/*     */     } 
/* 474 */     if (this.trackColorByFeature != trackColorByFeature) {
/*     */       
/* 476 */       this.trackColorByFeature = trackColorByFeature;
/* 477 */       fire = true;
/*     */     } 
/* 479 */     if (fire) {
/* 480 */       notifyListeners();
/*     */     }
/*     */   }
/*     */   
/*     */   public double getTrackMax() {
/* 485 */     return this.trackMax;
/*     */   }
/*     */ 
/*     */   
/*     */   public double getTrackMin() {
/* 490 */     return this.trackMin;
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized void setTrackMinMax(double trackMin, double trackMax) {
/* 495 */     double tmin = Math.min(trackMin, trackMax);
/* 496 */     double tmax = Math.max(trackMin, trackMax);
/*     */     
/* 498 */     boolean notify = false;
/* 499 */     if (this.trackMin != tmin) {
/*     */       
/* 501 */       this.trackMin = tmin;
/* 502 */       notify = true;
/*     */     } 
/* 504 */     if (this.trackMax != tmax) {
/*     */       
/* 506 */       this.trackMax = tmax;
/* 507 */       notify = true;
/*     */     } 
/* 509 */     if (notify) {
/* 510 */       notifyListeners();
/*     */     }
/*     */   }
/*     */   
/*     */   public synchronized void setTrackDisplayMode(TrackDisplayMode trackDisplayMode) {
/* 515 */     if (this.trackDisplayMode != trackDisplayMode) {
/*     */       
/* 517 */       this.trackDisplayMode = trackDisplayMode;
/* 518 */       notifyListeners();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isTrackVisible() {
/* 524 */     return this.trackVisible;
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized void setTrackVisible(boolean trackVisible) {
/* 529 */     if (this.trackVisible != trackVisible) {
/*     */       
/* 531 */       this.trackVisible = trackVisible;
/* 532 */       notifyListeners();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Color getTrackUniformColor() {
/* 538 */     return this.trackUniformColor;
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized void setTrackUniformColor(Color trackUniformColor) {
/* 543 */     if (this.trackUniformColor != trackUniformColor) {
/*     */       
/* 545 */       this.trackUniformColor = trackUniformColor;
/* 546 */       notifyListeners();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Color getUndefinedValueColor() {
/* 552 */     return this.undefinedValueColor;
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized void setUndefinedValueColor(Color undefinedValueColor) {
/* 557 */     if (this.undefinedValueColor != undefinedValueColor) {
/*     */       
/* 559 */       this.undefinedValueColor = undefinedValueColor;
/* 560 */       notifyListeners();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getUseAntialiasing() {
/* 571 */     return this.useAntialiasing;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void setUseAntialiasing(boolean useAntialiasing) {
/* 582 */     if (this.useAntialiasing != useAntialiasing) {
/*     */       
/* 584 */       this.useAntialiasing = useAntialiasing;
/* 585 */       notifyListeners();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Font getFont() {
/* 591 */     return this.font;
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized void setFont(Font font) {
/* 596 */     if (this.font != font) {
/*     */       
/* 598 */       this.font = font;
/* 599 */       notifyListeners();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public double getLineThickness() {
/* 605 */     return this.lineThickness;
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized void setLineThickness(double lineThickness) {
/* 610 */     if (this.lineThickness != lineThickness) {
/*     */       
/* 612 */       this.lineThickness = lineThickness;
/* 613 */       notifyListeners();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public double getSelectionLineThickness() {
/* 619 */     return this.selectionLineThickness;
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized void setSelectionLineThickness(double selectionLineThickness) {
/* 624 */     if (this.selectionLineThickness != selectionLineThickness) {
/*     */       
/* 626 */       this.selectionLineThickness = selectionLineThickness;
/* 627 */       notifyListeners();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isSpotFilled() {
/* 633 */     return this.spotFilled;
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized void setSpotFilled(boolean isSpotFilled) {
/* 638 */     if (this.spotFilled != isSpotFilled) {
/*     */       
/* 640 */       this.spotFilled = isSpotFilled;
/* 641 */       notifyListeners();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public double getSpotTransparencyAlpha() {
/* 647 */     return this.spotTransparencyAlpha;
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized void setSpotTransparencyAlpha(double spotTransparencyAlpha) {
/* 652 */     if (this.spotTransparencyAlpha != spotTransparencyAlpha) {
/*     */       
/* 654 */       this.spotTransparencyAlpha = spotTransparencyAlpha;
/* 655 */       notifyListeners();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Color getTrackSchemeBackgroundColor1() {
/* 661 */     return this.trackschemeBackgroundColor1;
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized void setTrackSchemeBackgroundColor1(Color trackschemeBackgroundColor1) {
/* 666 */     if (this.trackschemeBackgroundColor1 != trackschemeBackgroundColor1) {
/*     */       
/* 668 */       this.trackschemeBackgroundColor1 = trackschemeBackgroundColor1;
/* 669 */       notifyListeners();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Color getTrackSchemeBackgroundColor2() {
/* 675 */     return this.trackschemeBackgroundColor2;
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized void setTrackSchemeBackgroundColor2(Color trackschemeBackgroundColor2) {
/* 680 */     if (this.trackschemeBackgroundColor2 != trackschemeBackgroundColor2) {
/*     */       
/* 682 */       this.trackschemeBackgroundColor2 = trackschemeBackgroundColor2;
/* 683 */       notifyListeners();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Color getTrackSchemeDecorationColor() {
/* 689 */     return this.trackschemeDecorationColor;
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized void setTrackSchemeDecorationColor(Color trackschemeDecorationColor) {
/* 694 */     if (this.trackschemeDecorationColor != trackschemeDecorationColor) {
/*     */       
/* 696 */       this.trackschemeDecorationColor = trackschemeDecorationColor;
/* 697 */       notifyListeners();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Color getTrackSchemeForegroundColor() {
/* 703 */     return this.trackschemeForegroundColor;
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized void setTrackSchemeForegroundColor(Color trackschemeForegroundColor) {
/* 708 */     if (this.trackschemeForegroundColor != trackschemeForegroundColor) {
/*     */       
/* 710 */       this.trackschemeForegroundColor = trackschemeForegroundColor;
/* 711 */       notifyListeners();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isTrackSchemeFillBox() {
/* 717 */     return this.trackschemeFillBox;
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized void setTrackschemeFillBox(boolean trackschemeFillBox) {
/* 722 */     if (this.trackschemeFillBox != trackschemeFillBox) {
/*     */       
/* 724 */       this.trackschemeFillBox = trackschemeFillBox;
/* 725 */       notifyListeners();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void notifyListeners() {
/* 735 */     for (UpdateListener l : this.updateListeners.list) {
/* 736 */       l.displaySettingsChanged();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public enum TrackDisplayMode
/*     */   {
/* 744 */     FULL("Show entire tracks"),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 752 */     LOCAL("Show tracks local in time"),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 759 */     LOCAL_BACKWARD("Show tracks backward in time"),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 766 */     LOCAL_FORWARD("Show tracks forward in time"),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 772 */     SELECTION_ONLY("Show selection only");
/*     */     
/*     */     private final String name;
/*     */ 
/*     */     
/*     */     TrackDisplayMode(String name) {
/* 778 */       this.name = name;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public String toString() {
/* 784 */       return this.name;
/*     */     }
/*     */   }
/*     */   
/*     */   public enum TrackMateObject
/*     */   {
/* 790 */     DEFAULT("Default"), SPOTS("spots"), EDGES("edges"), TRACKS("tracks");
/*     */     
/*     */     private String name;
/*     */ 
/*     */     
/*     */     TrackMateObject(String name) {
/* 796 */       this.name = name;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public String toString() {
/* 802 */       return this.name;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Listeners.List<UpdateListener> listeners() {
/* 813 */     return this.updateListeners;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 823 */   private static final DisplaySettings df = new DisplaySettings("Default"); static {
/* 824 */     df.useAntialiasing = true;
/* 825 */     df.colormap = Colormap.Jet;
/* 826 */     df.limitZDrawingDepth = false;
/* 827 */     df.drawingZDepth = 10.0D;
/* 828 */     df.fadeTracks = true;
/* 829 */     df.fadeTrackRange = 30;
/* 830 */     df.highlightColor = new Color(0.2F, 0.9F, 0.2F);
/* 831 */     df.missingValueColor = Color.GRAY.darker();
/* 832 */     df.spotColorByFeature = "UNIFORM_COLOR";
/* 833 */     df.spotColorByType = TrackMateObject.DEFAULT;
/* 834 */     df.spotDisplayedAsRoi = true;
/* 835 */     df.spotDisplayRadius = 1.0D;
/* 836 */     df.spotFilled = false;
/* 837 */     df.spotMin = 0.0D;
/* 838 */     df.spotMax = 10.0D;
/* 839 */     df.spotShowName = false;
/* 840 */     df.spotTransparencyAlpha = 1.0D;
/* 841 */     df.spotUniformColor = new Color(0.8F, 0.2F, 0.8F);
/* 842 */     df.spotVisible = true;
/* 843 */     df.trackDisplayMode = TrackDisplayMode.FULL;
/* 844 */     df.trackColorByFeature = "TRACK_INDEX";
/* 845 */     df.trackColorByType = TrackMateObject.DEFAULT;
/* 846 */     df.trackUniformColor = new Color(0.8F, 0.8F, 0.2F);
/* 847 */     df.trackMin = 0.0D;
/* 848 */     df.trackMax = 10.0D;
/* 849 */     df.trackVisible = true;
/* 850 */     df.undefinedValueColor = Color.BLACK;
/*     */     
/* 852 */     df.font = new Font("Arial", 1, 12);
/* 853 */     df.lineThickness = 1.0D;
/* 854 */     df.selectionLineThickness = 4.0D;
/*     */     
/* 856 */     df.trackschemeBackgroundColor1 = Color.GRAY;
/* 857 */     df.trackschemeBackgroundColor2 = Color.LIGHT_GRAY;
/* 858 */     df.trackschemeForegroundColor = Color.BLACK;
/* 859 */     df.trackschemeDecorationColor = Color.BLACK;
/* 860 */     df.trackschemeFillBox = false;
/*     */   }
/*     */ 
/*     */   
/*     */   public static DisplaySettings defaultStyle() {
/* 865 */     return df;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 871 */     return DisplaySettingsIO.toJson(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public static void main(String[] args) {
/* 876 */     System.out.println(df.toString());
/*     */   }
/*     */   
/*     */   public static interface UpdateListener {
/*     */     void displaySettingsChanged();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/gui/displaysettings/DisplaySettings.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */