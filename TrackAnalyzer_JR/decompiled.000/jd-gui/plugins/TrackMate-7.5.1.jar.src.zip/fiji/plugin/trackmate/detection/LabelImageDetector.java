/*     */ package fiji.plugin.trackmate.detection;
/*     */ 
/*     */ import fiji.plugin.trackmate.Spot;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ import net.imglib2.Dimensions;
/*     */ import net.imglib2.Interval;
/*     */ import net.imglib2.RandomAccessible;
/*     */ import net.imglib2.RandomAccessibleInterval;
/*     */ import net.imglib2.img.Img;
/*     */ import net.imglib2.img.ImgFactory;
/*     */ import net.imglib2.loops.LoopBuilder;
/*     */ import net.imglib2.roi.labeling.ImgLabeling;
/*     */ import net.imglib2.type.NativeType;
/*     */ import net.imglib2.type.numeric.IntegerType;
/*     */ import net.imglib2.type.numeric.RealType;
/*     */ import net.imglib2.type.numeric.integer.IntType;
/*     */ import net.imglib2.util.Util;
/*     */ import net.imglib2.view.IntervalView;
/*     */ import net.imglib2.view.Views;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LabelImageDetector<T extends RealType<T> & NativeType<T>>
/*     */   implements SpotDetector<T>
/*     */ {
/*     */   private static final String BASE_ERROR_MESSAGE = "ThresholdDetector: ";
/*     */   protected RandomAccessible<T> input;
/*  55 */   protected String baseErrorMessage = "ThresholdDetector: ";
/*     */ 
/*     */   
/*     */   protected String errorMessage;
/*     */   
/*  60 */   protected List<Spot> spots = new ArrayList<>();
/*     */ 
/*     */ 
/*     */   
/*     */   protected long processingTime;
/*     */ 
/*     */ 
/*     */   
/*     */   protected int numThreads;
/*     */ 
/*     */ 
/*     */   
/*     */   protected final Interval interval;
/*     */ 
/*     */ 
/*     */   
/*     */   protected final double[] calibration;
/*     */ 
/*     */ 
/*     */   
/*     */   protected final boolean simplify;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LabelImageDetector(RandomAccessible<T> input, Interval interval, double[] calibration, boolean simplify) {
/*  86 */     this.input = input;
/*  87 */     this.interval = DetectionUtils.squeeze(interval);
/*  88 */     this.calibration = calibration;
/*  89 */     this.simplify = simplify;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean checkInput() {
/*  95 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean process() {
/* 102 */     long start = System.currentTimeMillis();
/* 103 */     IntervalView intervalView = Views.interval(this.input, this.interval);
/* 104 */     RealType realType = (RealType)Util.getTypeFromInterval((Interval)intervalView);
/*     */     
/* 106 */     if (realType instanceof IntegerType) {
/*     */       
/* 108 */       processIntegerImg((RandomAccessibleInterval<IntegerType>)Views.zeroMin((RandomAccessibleInterval)intervalView));
/*     */     }
/*     */     else {
/*     */       
/* 112 */       ImgFactory<IntType> factory = Util.getArrayOrCellImgFactory((Dimensions)this.interval, (NativeType)new IntType());
/* 113 */       Img<IntType> img = factory.create((Dimensions)this.interval);
/*     */       
/* 115 */       LoopBuilder.setImages((RandomAccessibleInterval)Views.zeroMin((RandomAccessibleInterval)intervalView), (RandomAccessibleInterval)img)
/* 116 */         .multiThreaded(false)
/* 117 */         .forEachPixel((i, o) -> o.setReal(i.getRealDouble()));
/* 118 */       processIntegerImg((RandomAccessibleInterval<IntType>)img);
/*     */     } 
/* 120 */     long end = System.currentTimeMillis();
/* 121 */     this.processingTime = end - start;
/* 122 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private <R extends IntegerType<R>> void processIntegerImg(RandomAccessibleInterval<R> rai) {
/* 128 */     AtomicInteger max = new AtomicInteger(0);
/* 129 */     Views.iterable(rai).forEach(p -> {
/*     */           int val = p.getInteger();
/*     */           if (val != 0 && val > max.get())
/*     */             max.set(val); 
/*     */         });
/* 134 */     List<Integer> indices = new ArrayList<>(max.get());
/* 135 */     for (int i = 0; i < max.get(); i++) {
/* 136 */       indices.add(Integer.valueOf(i + 1));
/*     */     }
/* 138 */     ImgLabeling<Integer, R> labeling = ImgLabeling.fromImageAndLabels(rai, indices);
/* 139 */     if (this.input.numDimensions() == 2) {
/* 140 */       this.spots = MaskUtils.fromLabelingWithROI(labeling, this.interval, this.calibration, this.simplify, null);
/*     */     } else {
/* 142 */       this.spots = MaskUtils.fromLabeling(labeling, this.interval, this.calibration);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public List<Spot> getResult() {
/* 148 */     return this.spots;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getErrorMessage() {
/* 154 */     return this.errorMessage;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public long getProcessingTime() {
/* 160 */     return this.processingTime;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/detection/LabelImageDetector.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */