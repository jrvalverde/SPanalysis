/*     */ package fiji.plugin.trackmate.features;
/*     */ 
/*     */ import fiji.plugin.trackmate.Model;
/*     */ import fiji.plugin.trackmate.SelectionModel;
/*     */ import fiji.plugin.trackmate.Spot;
/*     */ import fiji.plugin.trackmate.TrackModel;
/*     */ import fiji.plugin.trackmate.gui.displaysettings.DisplaySettings;
/*     */ import fiji.plugin.trackmate.visualization.FeatureColorGenerator;
/*     */ import java.awt.Color;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.Paint;
/*     */ import java.awt.Stroke;
/*     */ import java.awt.geom.Rectangle2D;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.function.Function;
/*     */ import org.jfree.chart.LegendItem;
/*     */ import org.jfree.chart.axis.ValueAxis;
/*     */ import org.jfree.chart.plot.PlotOrientation;
/*     */ import org.jfree.chart.plot.XYPlot;
/*     */ import org.jfree.chart.renderer.xy.XYItemRenderer;
/*     */ import org.jfree.chart.renderer.xy.XYItemRendererState;
/*     */ import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
/*     */ import org.jfree.chart.ui.RectangleEdge;
/*     */ import org.jfree.chart.util.LineUtils;
/*     */ import org.jfree.data.xy.XYDataset;
/*     */ import org.jgrapht.graph.DefaultWeightedEdge;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EdgeCollectionDataset
/*     */   extends ModelDataset
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private final List<DefaultWeightedEdge> edges;
/*     */   private final Map<Integer, Set<DefaultWeightedEdge>> edgeMap;
/*     */   private final Function<DefaultWeightedEdge, String> labelGenerator;
/*     */   
/*     */   public EdgeCollectionDataset(Model model, SelectionModel selectionModel, DisplaySettings ds, String xFeature, List<String> yFeatures, List<DefaultWeightedEdge> edges, boolean addLines) {
/*  76 */     super(model, selectionModel, ds, xFeature, yFeatures);
/*  77 */     this.edges = edges;
/*  78 */     this.edgeMap = addLines ? createEdgeMap(edges, model.getTrackModel()) : null;
/*  79 */     this.labelGenerator = (edge -> String.format("%s → %s", new Object[] { model.getTrackModel().getEdgeSource(edge).getName(), model.getTrackModel().getEdgeTarget(edge).getName() }));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Map<Integer, Set<DefaultWeightedEdge>> createEdgeMap(List<DefaultWeightedEdge> edges, TrackModel trackModel) {
/*  94 */     Map<Integer, Set<DefaultWeightedEdge>> edgeMap = new HashMap<>();
/*  95 */     for (int i = 0; i < edges.size(); i++) {
/*     */       
/*  97 */       Set<DefaultWeightedEdge> successors = new HashSet<>();
/*  98 */       DefaultWeightedEdge edge = edges.get(i);
/*  99 */       Spot target = trackModel.getEdgeTarget(edge);
/* 100 */       for (DefaultWeightedEdge edgeCandidate : edges) {
/*     */         
/* 102 */         Spot source = trackModel.getEdgeSource(edgeCandidate);
/* 103 */         if (source == target) {
/* 104 */           successors.add(edgeCandidate);
/*     */         }
/*     */       } 
/* 107 */       if (!successors.isEmpty())
/* 108 */         edgeMap.put(Integer.valueOf(i), successors); 
/*     */     } 
/* 110 */     return edgeMap;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getItemCount(int series) {
/* 116 */     return this.edges.size();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getSeriesKey(int series) {
/* 122 */     if (series < 0 || series >= getSeriesCount())
/* 123 */       throw new IllegalArgumentException("Series index out of bounds"); 
/* 124 */     return (String)this.model.getFeatureModel().getEdgeFeatureShortNames().get(this.yFeatures.get(series));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Number getX(int series, int item) {
/* 130 */     return this.model.getFeatureModel().getEdgeFeature(this.edges.get(item), this.xFeature);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Number getY(int series, int item) {
/* 136 */     return this.model.getFeatureModel().getEdgeFeature(this.edges.get(item), this.yFeatures.get(series));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public XYItemRenderer getRenderer() {
/* 142 */     return (XYItemRenderer)new MyXYItemRenderer();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getItemLabel(int item) {
/* 148 */     DefaultWeightedEdge edge = this.edges.get(item);
/* 149 */     return this.labelGenerator.apply(edge);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setItemLabel(int item, String label) {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final class MyXYItemRenderer
/*     */     extends XYLineAndShapeRenderer
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private MyXYItemRenderer() {}
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected void drawPrimaryLine(XYItemRendererState state, Graphics2D g2, XYPlot plot, XYDataset dataset, int pass, int series, int item, ValueAxis domainAxis, ValueAxis rangeAxis, Rectangle2D dataArea) {
/* 174 */       if (EdgeCollectionDataset.this.edgeMap == null || !EdgeCollectionDataset.this.edgeMap.containsKey(Integer.valueOf(item))) {
/*     */         return;
/*     */       }
/* 177 */       RectangleEdge xAxisLocation = plot.getDomainAxisEdge();
/* 178 */       RectangleEdge yAxisLocation = plot.getRangeAxisEdge();
/* 179 */       PlotOrientation orientation = plot.getOrientation();
/* 180 */       String yFeature = EdgeCollectionDataset.this.yFeatures.get(series);
/* 181 */       DefaultWeightedEdge sourceEdge = EdgeCollectionDataset.this.edges.get(item);
/* 182 */       Set<DefaultWeightedEdge> edges = (Set<DefaultWeightedEdge>)EdgeCollectionDataset.this.edgeMap.get(Integer.valueOf(item));
/* 183 */       for (DefaultWeightedEdge targetEdge : edges) {
/*     */ 
/*     */         
/* 186 */         Double x1 = EdgeCollectionDataset.this.model.getFeatureModel().getEdgeFeature(targetEdge, EdgeCollectionDataset.this.xFeature);
/* 187 */         Double y1 = EdgeCollectionDataset.this.model.getFeatureModel().getEdgeFeature(targetEdge, yFeature);
/* 188 */         if (x1 == null || y1 == null || x1.isNaN() || y1.isNaN()) {
/*     */           continue;
/*     */         }
/* 191 */         Double x0 = EdgeCollectionDataset.this.model.getFeatureModel().getEdgeFeature(sourceEdge, EdgeCollectionDataset.this.xFeature);
/* 192 */         Double y0 = EdgeCollectionDataset.this.model.getFeatureModel().getEdgeFeature(sourceEdge, yFeature);
/* 193 */         if (x0 == null || y0 == null || x0.isNaN() || y0.isNaN()) {
/*     */           continue;
/*     */         }
/* 196 */         double transX0 = domainAxis.valueToJava2D(x0.doubleValue(), dataArea, xAxisLocation);
/* 197 */         double transY0 = rangeAxis.valueToJava2D(y0.doubleValue(), dataArea, yAxisLocation);
/*     */         
/* 199 */         double transX1 = domainAxis.valueToJava2D(x1.doubleValue(), dataArea, xAxisLocation);
/* 200 */         double transY1 = rangeAxis.valueToJava2D(y1.doubleValue(), dataArea, yAxisLocation);
/*     */         
/* 202 */         if (Double.isNaN(transX0) || Double.isNaN(transY0) || Double.isNaN(transX1) || Double.isNaN(transY1)) {
/*     */           continue;
/*     */         }
/* 205 */         if (orientation == PlotOrientation.HORIZONTAL) {
/* 206 */           state.workingLine.setLine(transY0, transX0, transY1, transX1);
/* 207 */         } else if (orientation == PlotOrientation.VERTICAL) {
/* 208 */           state.workingLine.setLine(transX0, transY0, transX1, transY1);
/* 209 */         }  boolean visible = LineUtils.clipLine(state.workingLine, dataArea);
/* 210 */         if (visible) {
/* 211 */           drawFirstPassShape(g2, pass, series, item, state.workingLine);
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public Paint getItemPaint(int series, int item) {
/* 218 */       DefaultWeightedEdge edge = EdgeCollectionDataset.this.edges.get(item);
/* 219 */       if (EdgeCollectionDataset.this.selectionModel != null && EdgeCollectionDataset.this.selectionModel.getEdgeSelection().contains(edge)) {
/* 220 */         return EdgeCollectionDataset.this.ds.getHighlightColor();
/*     */       }
/* 222 */       FeatureColorGenerator<DefaultWeightedEdge> edgeColorGenerator = FeatureUtils.createTrackColorGenerator(EdgeCollectionDataset.this.model, EdgeCollectionDataset.this.ds);
/* 223 */       return edgeColorGenerator.color(EdgeCollectionDataset.this.edges.get(item));
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Stroke getItemStroke(int series, int item) {
/* 229 */       DefaultWeightedEdge edge = EdgeCollectionDataset.this.edges.get(item);
/* 230 */       if (EdgeCollectionDataset.this.selectionModel != null && EdgeCollectionDataset.this.selectionModel.getEdgeSelection().contains(edge))
/* 231 */         return EdgeCollectionDataset.this.selectionStroke; 
/* 232 */       return EdgeCollectionDataset.this.stroke;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public LegendItem getLegendItem(int datasetIndex, int series) {
/* 238 */       LegendItem legendItem = super.getLegendItem(datasetIndex, series);
/* 239 */       legendItem.setFillPaint(Color.BLACK);
/* 240 */       legendItem.setLinePaint(Color.BLACK);
/* 241 */       legendItem.setOutlinePaint(Color.BLACK);
/* 242 */       return legendItem;
/*     */     }
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/features/EdgeCollectionDataset.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */