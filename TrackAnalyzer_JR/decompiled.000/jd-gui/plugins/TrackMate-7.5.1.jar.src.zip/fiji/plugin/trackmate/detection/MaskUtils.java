/*      */ package fiji.plugin.trackmate.detection;
/*      */ 
/*      */ import fiji.plugin.trackmate.Spot;
/*      */ import fiji.plugin.trackmate.SpotRoi;
/*      */ import ij.ImagePlus;
/*      */ import ij.gui.PolygonRoi;
/*      */ import ij.gui.Roi;
/*      */ import ij.process.FloatPolygon;
/*      */ import java.awt.Polygon;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.concurrent.ExecutorService;
/*      */ import java.util.concurrent.Executors;
/*      */ import net.imglib2.Dimensions;
/*      */ import net.imglib2.Interval;
/*      */ import net.imglib2.Localizable;
/*      */ import net.imglib2.RandomAccess;
/*      */ import net.imglib2.RandomAccessible;
/*      */ import net.imglib2.RandomAccessibleInterval;
/*      */ import net.imglib2.algorithm.labeling.ConnectedComponents;
/*      */ import net.imglib2.converter.Converter;
/*      */ import net.imglib2.converter.Converters;
/*      */ import net.imglib2.histogram.BinMapper1d;
/*      */ import net.imglib2.histogram.Histogram1d;
/*      */ import net.imglib2.histogram.Real1dBinMapper;
/*      */ import net.imglib2.img.Img;
/*      */ import net.imglib2.img.ImgFactory;
/*      */ import net.imglib2.img.display.imagej.ImageJFunctions;
/*      */ import net.imglib2.roi.labeling.ImgLabeling;
/*      */ import net.imglib2.roi.labeling.LabelRegion;
/*      */ import net.imglib2.roi.labeling.LabelRegionCursor;
/*      */ import net.imglib2.roi.labeling.LabelRegions;
/*      */ import net.imglib2.type.BooleanType;
/*      */ import net.imglib2.type.NativeType;
/*      */ import net.imglib2.type.Type;
/*      */ import net.imglib2.type.logic.BitType;
/*      */ import net.imglib2.type.numeric.RealType;
/*      */ import net.imglib2.type.numeric.integer.IntType;
/*      */ import net.imglib2.util.Util;
/*      */ import net.imglib2.view.IntervalView;
/*      */ import net.imglib2.view.Views;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class MaskUtils
/*      */ {
/*      */   private static final double SMOOTH_INTERVAL = 2.0D;
/*      */   private static final double DOUGLAS_PEUCKER_MAX_DISTANCE = 0.5D;
/*      */   
/*      */   public static final <T extends RealType<T>> double otsuThreshold(RandomAccessibleInterval<T> img) {
/*   80 */     RealType realType1 = (RealType)Util.getTypeFromInterval((Interval)img);
/*   81 */     RealType realType2 = (RealType)realType1.createVariable();
/*   82 */     realType2.setReal(Double.NEGATIVE_INFINITY);
/*   83 */     RealType realType3 = (RealType)realType1.createVariable();
/*   84 */     realType3.setReal(Double.POSITIVE_INFINITY);
/*      */     
/*   86 */     for (RealType realType : Views.iterable(img)) {
/*      */       
/*   88 */       if (realType.compareTo(realType3) < 0) {
/*   89 */         realType3.set((Type)realType);
/*      */       }
/*   91 */       if (realType.compareTo(realType2) > 0) {
/*   92 */         realType2.set((Type)realType);
/*      */       }
/*      */     } 
/*      */     
/*   96 */     Real1dBinMapper<T> mapper = new Real1dBinMapper(realType3.getRealDouble(), realType2.getRealDouble(), 256L, false);
/*   97 */     Histogram1d<T> histogram = new Histogram1d((Iterable)Views.iterable(img), (BinMapper1d)mapper);
/*      */ 
/*      */     
/*  100 */     long k = getThreshold(histogram);
/*  101 */     RealType realType4 = (RealType)realType1.createVariable();
/*  102 */     mapper.getCenterValue(k, realType4);
/*  103 */     return realType4.getRealDouble();
/*      */   }
/*      */ 
/*      */   
/*      */   public static final long getThreshold(Histogram1d<?> hist) {
/*  108 */     long[] histogram = hist.toLongArray();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  113 */     int L = histogram.length;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  123 */     long S = 0L;
/*  124 */     long N = 0L; int k;
/*  125 */     for (k = 0; k < L; k++) {
/*      */       
/*  127 */       S += k * histogram[k];
/*  128 */       N += histogram[k];
/*      */     } 
/*      */     
/*  131 */     long Sk = 0L;
/*  132 */     long N1 = histogram[0];
/*  133 */     double BCV = 0.0D;
/*  134 */     double BCVmax = 0.0D;
/*  135 */     int kStar = 0;
/*      */ 
/*      */ 
/*      */     
/*  139 */     for (k = 1; k < L - 1; k++) {
/*      */       
/*  141 */       Sk += k * histogram[k];
/*  142 */       N1 += histogram[k];
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  147 */       double denom = N1 * (N - N1);
/*      */ 
/*      */ 
/*      */       
/*  151 */       if (denom != 0.0D) {
/*      */ 
/*      */         
/*  154 */         double num = N1 / N * S - Sk;
/*      */ 
/*      */         
/*  157 */         BCV = num * num / denom;
/*      */       } else {
/*      */         
/*  160 */         BCV = 0.0D;
/*      */       } 
/*  162 */       if (BCV >= BCVmax) {
/*      */         
/*  164 */         BCVmax = BCV;
/*  165 */         kStar = k;
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  171 */     return kStar;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final <T extends RealType<T>> ImgLabeling<Integer, IntType> toLabeling(RandomAccessible<T> input, Interval interval, double threshold, int numThreads) {
/*  196 */     IntervalView<T> crop = Views.interval(input, interval);
/*  197 */     IntervalView<T> in = Views.zeroMin((RandomAccessibleInterval)crop);
/*  198 */     Converter<T, BitType> converter = (a, b) -> b.set((a.getRealDouble() > threshold));
/*  199 */     RandomAccessibleInterval randomAccessibleInterval = Converters.convertRAI((RandomAccessibleInterval)in, converter, (Type)new BitType());
/*      */ 
/*      */     
/*  202 */     ImgFactory<IntType> factory = Util.getArrayOrCellImgFactory((Dimensions)in, (NativeType)new IntType());
/*  203 */     Img<IntType> out = factory.create((Dimensions)in);
/*  204 */     ImgLabeling<Integer, IntType> labeling = new ImgLabeling((RandomAccessibleInterval)out);
/*      */ 
/*      */     
/*  207 */     ConnectedComponents.StructuringElement se = ConnectedComponents.StructuringElement.FOUR_CONNECTED;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  212 */     ExecutorService executorService = (numThreads > 1) ? Executors.newFixedThreadPool(numThreads) : Executors.newSingleThreadExecutor();
/*      */     
/*  214 */     ConnectedComponents.labelAllConnectedComponents((RandomAccessible)randomAccessibleInterval, labeling, 
/*      */ 
/*      */         
/*  217 */         labelGenerator(), se, executorService);
/*      */ 
/*      */     
/*  220 */     executorService.shutdown();
/*  221 */     return labeling;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends RealType<T>> List<Spot> fromThreshold(RandomAccessible<T> input, Interval interval, double[] calibration, double threshold, int numThreads) {
/*  251 */     ImgLabeling<Integer, IntType> labeling = toLabeling(input, interval, threshold, numThreads);
/*  252 */     return fromLabeling(labeling, interval, calibration);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <R extends net.imglib2.type.numeric.IntegerType<R>> List<Spot> fromLabeling(ImgLabeling<Integer, R> labeling, Interval interval, double[] calibration) {
/*  278 */     LabelRegions<Integer> regions = new LabelRegions((RandomAccessibleInterval)labeling);
/*  279 */     Iterator<LabelRegion<Integer>> iterator = regions.iterator();
/*  280 */     List<Spot> spots = new ArrayList<>(regions.getExistingLabels().size());
/*  281 */     while (iterator.hasNext()) {
/*      */       
/*  283 */       LabelRegion<Integer> region = iterator.next();
/*  284 */       LabelRegionCursor cursor = region.localizingCursor();
/*  285 */       int[] cursorPos = new int[labeling.numDimensions()];
/*  286 */       long[] sum = new long[3];
/*  287 */       while (cursor.hasNext()) {
/*      */         
/*  289 */         cursor.fwd();
/*  290 */         cursor.localize(cursorPos);
/*  291 */         for (int j = 0; j < sum.length; j++) {
/*  292 */           sum[j] = sum[j] + cursorPos[j];
/*      */         }
/*      */       } 
/*  295 */       double[] pos = new double[3];
/*  296 */       for (int d = 0; d < pos.length; d++) {
/*  297 */         pos[d] = sum[d] / region.size();
/*      */       }
/*  299 */       double x = calibration[0] * (interval.min(0) + pos[0]);
/*  300 */       double y = calibration[1] * (interval.min(1) + pos[1]);
/*  301 */       double z = calibration[2] * (interval.min(2) + pos[2]);
/*      */       
/*  303 */       double volume = region.size();
/*  304 */       for (int i = 0; i < calibration.length; i++) {
/*  305 */         if (calibration[i] > 0.0D) {
/*  306 */           volume *= calibration[i];
/*      */         }
/*      */       } 
/*  309 */       double radius = (labeling.numDimensions() == 2) ? Math.sqrt(volume / Math.PI) : Math.pow(3.0D * volume / 12.566370614359172D, 0.3333333333333333D);
/*  310 */       double quality = region.size();
/*  311 */       spots.add(new Spot(x, y, z, radius, quality));
/*      */     } 
/*      */     
/*  314 */     return spots;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends RealType<T>, R extends RealType<R>> List<Spot> fromThreshold(RandomAccessible<T> input, Interval interval, double[] calibration, double threshold, int numThreads, RandomAccessibleInterval<R> qualityImage) {
/*  348 */     ImgLabeling<Integer, IntType> labeling = toLabeling(input, interval, threshold, numThreads);
/*      */ 
/*      */     
/*  351 */     IntervalView<R> cropQuality = Views.interval((RandomAccessible)qualityImage, interval);
/*  352 */     IntervalView<R> inQuality = Views.zeroMin((RandomAccessibleInterval)cropQuality);
/*  353 */     RandomAccess<R> raQuality = inQuality.randomAccess((Interval)inQuality);
/*      */ 
/*      */     
/*  356 */     LabelRegions<Integer> regions = new LabelRegions((RandomAccessibleInterval)labeling);
/*  357 */     Iterator<LabelRegion<Integer>> iterator = regions.iterator();
/*  358 */     List<Spot> spots = new ArrayList<>(regions.getExistingLabels().size());
/*  359 */     while (iterator.hasNext()) {
/*      */       
/*  361 */       LabelRegion<Integer> region = iterator.next();
/*  362 */       LabelRegionCursor cursor = region.localizingCursor();
/*  363 */       int[] cursorPos = new int[labeling.numDimensions()];
/*  364 */       long[] sum = new long[3];
/*  365 */       double quality = Double.NEGATIVE_INFINITY;
/*  366 */       while (cursor.hasNext()) {
/*      */         
/*  368 */         cursor.fwd();
/*      */ 
/*      */         
/*  371 */         cursor.localize(cursorPos);
/*  372 */         for (int j = 0; j < sum.length; j++) {
/*  373 */           sum[j] = sum[j] + cursorPos[j];
/*      */         }
/*      */         
/*  376 */         raQuality.setPosition((Localizable)cursor);
/*  377 */         double q = ((RealType)raQuality.get()).getRealDouble();
/*  378 */         if (q > quality) {
/*  379 */           quality = q;
/*      */         }
/*      */       } 
/*  382 */       double[] pos = new double[3];
/*  383 */       for (int d = 0; d < pos.length; d++) {
/*  384 */         pos[d] = sum[d] / region.size();
/*      */       }
/*  386 */       double x = calibration[0] * (interval.min(0) + pos[0]);
/*  387 */       double y = calibration[1] * (interval.min(1) + pos[1]);
/*  388 */       double z = calibration[2] * (interval.min(2) + pos[2]);
/*      */       
/*  390 */       double volume = region.size();
/*  391 */       for (int i = 0; i < calibration.length; i++) {
/*  392 */         if (calibration[i] > 0.0D) {
/*  393 */           volume *= calibration[i];
/*      */         }
/*      */       } 
/*      */       
/*  397 */       double radius = (labeling.numDimensions() == 2) ? Math.sqrt(volume / Math.PI) : Math.pow(3.0D * volume / 12.566370614359172D, 0.3333333333333333D);
/*  398 */       spots.add(new Spot(x, y, z, radius, quality));
/*      */     } 
/*      */     
/*  401 */     return spots;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final <T extends RealType<T>, S extends net.imglib2.type.numeric.NumericType<S>> List<Spot> fromThresholdWithROI(RandomAccessible<T> input, Interval interval, double[] calibration, double threshold, boolean simplify, int numThreads, RandomAccessibleInterval<S> qualityImage) {
/*  441 */     if (input.numDimensions() != 2) {
/*  442 */       throw new IllegalArgumentException("Can only process 2D images with this method, but got " + input.numDimensions() + "D.");
/*      */     }
/*      */     
/*  445 */     ImgLabeling<Integer, IntType> labeling = toLabeling(input, interval, threshold, numThreads);
/*  446 */     return fromLabelingWithROI(labeling, interval, calibration, simplify, qualityImage);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <R extends net.imglib2.type.numeric.IntegerType<R>, S extends net.imglib2.type.numeric.NumericType<S>> List<Spot> fromLabelingWithROI(ImgLabeling<Integer, R> labeling, Interval interval, double[] calibration, boolean simplify, RandomAccessibleInterval<S> qualityImage) {
/*  479 */     if (labeling.numDimensions() != 2) {
/*  480 */       throw new IllegalArgumentException("Can only process 2D images with this method, but got " + labeling.numDimensions() + "D.");
/*      */     }
/*  482 */     LabelRegions<Integer> regions = new LabelRegions((RandomAccessibleInterval)labeling);
/*      */ 
/*      */     
/*  485 */     List<Polygon> polygons = new ArrayList<>(regions.getExistingLabels().size());
/*  486 */     Iterator<LabelRegion<Integer>> iterator = regions.iterator();
/*  487 */     while (iterator.hasNext()) {
/*      */       
/*  489 */       LabelRegion<Integer> region = iterator.next();
/*      */       
/*  491 */       List<Polygon> pp = maskToPolygons((RandomAccessibleInterval<BooleanType>)Views.zeroMin((RandomAccessibleInterval)region));
/*      */       
/*  493 */       for (Polygon polygon : pp) {
/*  494 */         polygon.translate((int)region.min(0), (int)region.min(1));
/*      */       }
/*  496 */       polygons.addAll(pp);
/*      */     } 
/*      */ 
/*      */     
/*  500 */     List<Spot> spots = new ArrayList<>(polygons.size());
/*      */ 
/*      */     
/*  503 */     ImagePlus qualityImp = (null == qualityImage) ? null : ImageJFunctions.wrap(qualityImage, "QualityImage");
/*      */ 
/*      */     
/*  506 */     for (Polygon polygon : polygons) {
/*      */       PolygonRoi fRoi; double quality;
/*  508 */       PolygonRoi roi = new PolygonRoi(polygon, 2);
/*      */ 
/*      */ 
/*      */       
/*  512 */       if (simplify) {
/*  513 */         fRoi = simplify(roi, 2.0D, 0.5D);
/*      */       } else {
/*  515 */         fRoi = roi;
/*      */       } 
/*      */       
/*  518 */       if (fRoi.getNCoordinates() < 3 || (fRoi.getStatistics()).area <= 0.0D) {
/*      */         continue;
/*      */       }
/*      */ 
/*      */       
/*  523 */       if (null == qualityImp) {
/*      */         
/*  525 */         quality = (fRoi.getStatistics()).area;
/*      */       }
/*      */       else {
/*      */         
/*  529 */         qualityImp.setRoi((Roi)fRoi);
/*  530 */         quality = (qualityImp.getStatistics(16)).max;
/*      */       } 
/*      */       
/*  533 */       Polygon fPolygon = fRoi.getPolygon();
/*  534 */       double[] xpoly = new double[fPolygon.npoints];
/*  535 */       double[] ypoly = new double[fPolygon.npoints];
/*  536 */       for (int i = 0; i < fPolygon.npoints; i++) {
/*      */         
/*  538 */         xpoly[i] = calibration[0] * ((interval.min(0) + fPolygon.xpoints[i]) - 0.5D);
/*  539 */         ypoly[i] = calibration[1] * ((interval.min(1) + fPolygon.ypoints[i]) - 0.5D);
/*      */       } 
/*      */       
/*  542 */       spots.add(SpotRoi.createSpot(xpoly, ypoly, quality));
/*      */     } 
/*  544 */     return spots;
/*      */   }
/*      */ 
/*      */   
/*      */   private static final double distanceSquaredBetweenPoints(double vx, double vy, double wx, double wy) {
/*  549 */     double deltax = vx - wx;
/*  550 */     double deltay = vy - wy;
/*  551 */     return deltax * deltax + deltay * deltay;
/*      */   }
/*      */ 
/*      */   
/*      */   private static final double distanceToSegmentSquared(double px, double py, double vx, double vy, double wx, double wy) {
/*  556 */     double l2 = distanceSquaredBetweenPoints(vx, vy, wx, wy);
/*  557 */     if (l2 == 0.0D)
/*  558 */       return distanceSquaredBetweenPoints(px, py, vx, vy); 
/*  559 */     double t = ((px - vx) * (wx - vx) + (py - vy) * (wy - vy)) / l2;
/*  560 */     if (t < 0.0D)
/*  561 */       return distanceSquaredBetweenPoints(px, py, vx, vy); 
/*  562 */     if (t > 1.0D)
/*  563 */       return distanceSquaredBetweenPoints(px, py, wx, wy); 
/*  564 */     return distanceSquaredBetweenPoints(px, py, vx + t * (wx - vx), vy + t * (wy - vy));
/*      */   }
/*      */ 
/*      */   
/*      */   private static final double perpendicularDistance(double px, double py, double vx, double vy, double wx, double wy) {
/*  569 */     return Math.sqrt(distanceToSegmentSquared(px, py, vx, vy, wx, wy));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static final void douglasPeucker(List<double[]> list, int s, int e, double epsilon, List<double[]> resultList) {
/*  575 */     double dmax = 0.0D;
/*  576 */     int index = 0;
/*      */     
/*  578 */     int start = s;
/*  579 */     int end = e - 1;
/*  580 */     for (int i = start + 1; i < end; i++) {
/*      */ 
/*      */       
/*  583 */       double px = ((double[])list.get(i))[0];
/*  584 */       double py = ((double[])list.get(i))[1];
/*      */       
/*  586 */       double vx = ((double[])list.get(start))[0];
/*  587 */       double vy = ((double[])list.get(start))[1];
/*      */       
/*  589 */       double wx = ((double[])list.get(end))[0];
/*  590 */       double wy = ((double[])list.get(end))[1];
/*  591 */       double d = perpendicularDistance(px, py, vx, vy, wx, wy);
/*  592 */       if (d > dmax) {
/*      */         
/*  594 */         index = i;
/*  595 */         dmax = d;
/*      */       } 
/*      */     } 
/*      */     
/*  599 */     if (dmax > epsilon) {
/*      */ 
/*      */       
/*  602 */       douglasPeucker(list, s, index, epsilon, resultList);
/*  603 */       douglasPeucker(list, index, e, epsilon, resultList);
/*      */ 
/*      */     
/*      */     }
/*  607 */     else if (end - start > 0) {
/*      */       
/*  609 */       resultList.add(list.get(start));
/*  610 */       resultList.add(list.get(end));
/*      */     }
/*      */     else {
/*      */       
/*  614 */       resultList.add(list.get(start));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final List<double[]> douglasPeucker(List<double[]> list, double epsilon) {
/*  640 */     List<double[]> resultList = (List)new ArrayList<>();
/*  641 */     douglasPeucker(list, 0, list.size(), epsilon, resultList);
/*  642 */     return resultList;
/*      */   }
/*      */ 
/*      */   
/*      */   public static final PolygonRoi simplify(PolygonRoi roi, double smoothInterval, double epsilon) {
/*  647 */     FloatPolygon fPoly = roi.getInterpolatedPolygon(smoothInterval, true);
/*      */     
/*  649 */     List<double[]> points = (List)new ArrayList<>(fPoly.npoints);
/*  650 */     for (int i = 0; i < fPoly.npoints; i++) {
/*  651 */       points.add(new double[] { fPoly.xpoints[i], fPoly.ypoints[i] });
/*      */     } 
/*  653 */     List<double[]> simplifiedPoints = douglasPeucker(points, epsilon);
/*  654 */     float[] sX = new float[simplifiedPoints.size()];
/*  655 */     float[] sY = new float[simplifiedPoints.size()];
/*  656 */     for (int j = 0; j < sX.length; j++) {
/*      */       
/*  658 */       sX[j] = (float)((double[])simplifiedPoints.get(j))[0];
/*  659 */       sY[j] = (float)((double[])simplifiedPoints.get(j))[1];
/*      */     } 
/*  661 */     FloatPolygon simplifiedPolygon = new FloatPolygon(sX, sY);
/*  662 */     PolygonRoi fRoi = new PolygonRoi(simplifiedPolygon, 2);
/*  663 */     return fRoi;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final Iterator<Integer> labelGenerator() {
/*  673 */     return new Iterator<Integer>()
/*      */       {
/*      */         
/*  676 */         private int currentVal = 0;
/*      */ 
/*      */ 
/*      */         
/*      */         public Integer next() {
/*  681 */           this.currentVal++;
/*  682 */           return Integer.valueOf(this.currentVal);
/*      */         }
/*      */ 
/*      */ 
/*      */         
/*      */         public boolean hasNext() {
/*  688 */           return true;
/*      */         }
/*      */       };
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final <T extends BooleanType<T>> List<Polygon> maskToPolygons(RandomAccessibleInterval<T> mask) {
/*  709 */     int w = (int)mask.dimension(0);
/*  710 */     int h = (int)mask.dimension(1);
/*  711 */     RandomAccess<T> ra = mask.randomAccess((Interval)mask);
/*      */     
/*  713 */     List<Polygon> polygons = new ArrayList<>();
/*  714 */     boolean[] prevRow = new boolean[w + 2];
/*  715 */     boolean[] thisRow = new boolean[w + 2];
/*  716 */     Outline[] outline = new Outline[w + 1];
/*      */     
/*  718 */     for (int y = 0; y <= h; y++) {
/*      */       
/*  720 */       ra.setPosition(y, 1);
/*      */       
/*  722 */       boolean[] b = prevRow;
/*  723 */       prevRow = thisRow;
/*  724 */       thisRow = b;
/*  725 */       int xAfterLowerRightCorner = -1;
/*  726 */       Outline oAfterLowerRightCorner = null;
/*      */       
/*  728 */       ra.setPosition(0, 0);
/*  729 */       thisRow[1] = (y < h) ? ((BooleanType)ra.get()).get() : false;
/*      */       
/*  731 */       for (int x = 0; x <= w; x++) {
/*      */ 
/*      */         
/*  734 */         ra.setPosition(x + 1, 0);
/*  735 */         if (y < h && x < w - 1) {
/*  736 */           thisRow[x + 2] = ((BooleanType)ra.get()).get();
/*  737 */         } else if (x < w - 1) {
/*  738 */           thisRow[x + 2] = false;
/*      */         } 
/*  740 */         if (thisRow[x + 1]) {
/*      */           
/*  742 */           if (!prevRow[x + 1])
/*      */           {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  754 */             if (outline[x] == null) {
/*      */               
/*  756 */               if (outline[x + 1] == null)
/*      */               {
/*  758 */                 outline[x] = new Outline(); outline[x + 1] = new Outline();
/*  759 */                 outline[x].append(x + 1, y);
/*  760 */                 outline[x].append(x, y);
/*      */               }
/*      */               else
/*      */               {
/*  764 */                 outline[x] = outline[x + 1];
/*  765 */                 outline[x + 1] = null;
/*  766 */                 outline[x].append(x, y);
/*      */               }
/*      */             
/*  769 */             } else if (outline[x + 1] == null) {
/*      */               
/*  771 */               if (x == xAfterLowerRightCorner)
/*      */               {
/*  773 */                 outline[x + 1] = outline[x];
/*  774 */                 outline[x] = oAfterLowerRightCorner;
/*  775 */                 outline[x].append(x, y);
/*  776 */                 outline[x + 1].prepend(x + 1, y);
/*      */               }
/*      */               else
/*      */               {
/*  780 */                 outline[x + 1] = outline[x];
/*  781 */                 outline[x] = null;
/*  782 */                 outline[x + 1].prepend(x + 1, y);
/*      */               }
/*      */             
/*  785 */             } else if (outline[x + 1] == outline[x]) {
/*      */               
/*  787 */               if (x < w - 1 && y < h && x != xAfterLowerRightCorner && !thisRow[x + 2] && prevRow[x + 2])
/*      */               {
/*      */                 
/*  790 */                 outline[x] = null;
/*      */                 
/*  792 */                 outline[x + 1].prepend(x + 1, y);
/*  793 */                 xAfterLowerRightCorner = x + 1;
/*  794 */                 oAfterLowerRightCorner = outline[x + 1];
/*      */ 
/*      */               
/*      */               }
/*      */               else
/*      */               {
/*      */                 
/*  801 */                 outline[x + 1] = null;
/*  802 */                 outline[x] = (x == xAfterLowerRightCorner) ? oAfterLowerRightCorner : null;
/*      */               }
/*      */             
/*      */             } else {
/*      */               
/*  807 */               outline[x].prepend(outline[x + 1]);
/*  808 */               for (int x1 = 0; x1 <= w; x1++) {
/*  809 */                 if (x1 != x + 1 && outline[x1] == outline[x + 1]) {
/*      */                   
/*  811 */                   outline[x1] = outline[x];
/*  812 */                   outline[x + 1] = null;
/*  813 */                   outline[x] = (x == xAfterLowerRightCorner) ? oAfterLowerRightCorner : null; break;
/*      */                 } 
/*      */               } 
/*  816 */               if (outline[x + 1] != null)
/*  817 */                 throw new RuntimeException("assertion failed"); 
/*      */             } 
/*      */           }
/*  820 */           if (!thisRow[x])
/*      */           {
/*      */             
/*  823 */             if (outline[x] == null)
/*  824 */               throw new RuntimeException("assertion failed"); 
/*  825 */             outline[x].append(x, y + 1);
/*      */           }
/*      */         
/*      */         } else {
/*      */           
/*  830 */           if (prevRow[x + 1])
/*      */           {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  841 */             if (outline[x] == null) {
/*      */               
/*  843 */               if (outline[x + 1] == null)
/*      */               {
/*  845 */                 outline[x + 1] = new Outline(); outline[x] = new Outline();
/*  846 */                 outline[x].append(x, y);
/*  847 */                 outline[x].append(x + 1, y);
/*      */               }
/*      */               else
/*      */               {
/*  851 */                 outline[x] = outline[x + 1];
/*  852 */                 outline[x + 1] = null;
/*  853 */                 outline[x].prepend(x, y);
/*      */               }
/*      */             
/*  856 */             } else if (outline[x + 1] == null) {
/*      */               
/*  858 */               if (x == xAfterLowerRightCorner)
/*      */               {
/*  860 */                 outline[x + 1] = outline[x];
/*  861 */                 outline[x] = oAfterLowerRightCorner;
/*  862 */                 outline[x].prepend(x, y);
/*  863 */                 outline[x + 1].append(x + 1, y);
/*      */               }
/*      */               else
/*      */               {
/*  867 */                 outline[x + 1] = outline[x];
/*  868 */                 outline[x] = null;
/*  869 */                 outline[x + 1].append(x + 1, y);
/*      */               }
/*      */             
/*  872 */             } else if (outline[x + 1] == outline[x]) {
/*      */ 
/*      */               
/*  875 */               if (x < w - 1 && y < h && x != xAfterLowerRightCorner && thisRow[x + 2] && !prevRow[x + 2])
/*      */               {
/*      */                 
/*  878 */                 outline[x] = null;
/*      */                 
/*  880 */                 outline[x + 1].append(x + 1, y);
/*  881 */                 xAfterLowerRightCorner = x + 1;
/*  882 */                 oAfterLowerRightCorner = outline[x + 1];
/*      */               }
/*      */               else
/*      */               {
/*  886 */                 polygons.add(outline[x].getPolygon());
/*  887 */                 outline[x + 1] = null;
/*  888 */                 outline[x] = (x == xAfterLowerRightCorner) ? oAfterLowerRightCorner : null;
/*      */               
/*      */               }
/*      */             
/*      */             }
/*  893 */             else if (x < w - 1 && y < h && x != xAfterLowerRightCorner && thisRow[x + 2] && !prevRow[x + 2]) {
/*      */ 
/*      */               
/*  896 */               outline[x].append(x + 1, y);
/*  897 */               outline[x + 1].prepend(x + 1, y);
/*  898 */               xAfterLowerRightCorner = x + 1;
/*  899 */               oAfterLowerRightCorner = outline[x];
/*      */ 
/*      */               
/*  902 */               outline[x] = null;
/*      */             }
/*      */             else {
/*      */               
/*  906 */               outline[x].append(outline[x + 1]);
/*  907 */               for (int x1 = 0; x1 <= w; x1++) {
/*  908 */                 if (x1 != x + 1 && outline[x1] == outline[x + 1]) {
/*      */                   
/*  910 */                   outline[x1] = outline[x];
/*  911 */                   outline[x + 1] = null;
/*  912 */                   outline[x] = (x == xAfterLowerRightCorner) ? oAfterLowerRightCorner : null; break;
/*      */                 } 
/*      */               } 
/*  915 */               if (outline[x + 1] != null) {
/*  916 */                 throw new RuntimeException("assertion failed");
/*      */               }
/*      */             } 
/*      */           }
/*  920 */           if (thisRow[x]) {
/*      */ 
/*      */             
/*  923 */             if (outline[x] == null)
/*  924 */               throw new RuntimeException("assertion failed"); 
/*  925 */             outline[x].prepend(x, y + 1);
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*  930 */     return polygons;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static class Outline
/*      */   {
/*      */     private int[] x;
/*      */ 
/*      */     
/*      */     private int[] y;
/*      */ 
/*      */     
/*      */     private int first;
/*      */     
/*      */     private int last;
/*      */     
/*      */     private int reserved;
/*      */     
/*  949 */     private final int GROW = 10;
/*      */ 
/*      */     
/*      */     public Outline() {
/*  953 */       this.reserved = 10;
/*  954 */       this.x = new int[this.reserved];
/*  955 */       this.y = new int[this.reserved];
/*  956 */       this.first = this.last = 5;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private void needs(int neededAtBegin, int neededAtEnd) {
/*  965 */       if (neededAtBegin > this.first || neededAtEnd > this.reserved - this.last) {
/*      */         
/*  967 */         int extraSpace = Math.max(10, Math.abs(this.x[this.last - 1] - this.x[this.first]));
/*  968 */         int newSize = this.reserved + neededAtBegin + neededAtEnd + extraSpace;
/*  969 */         int newFirst = neededAtBegin + extraSpace / 2;
/*  970 */         int[] newX = new int[newSize];
/*  971 */         int[] newY = new int[newSize];
/*  972 */         System.arraycopy(this.x, this.first, newX, newFirst, this.last - this.first);
/*  973 */         System.arraycopy(this.y, this.first, newY, newFirst, this.last - this.first);
/*  974 */         this.x = newX;
/*  975 */         this.y = newY;
/*  976 */         this.last += newFirst - this.first;
/*  977 */         this.first = newFirst;
/*  978 */         this.reserved = newSize;
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public void append(int x, int y) {
/*  985 */       if (this.last - this.first >= 2 && collinear(this.x[this.last - 2], this.y[this.last - 2], this.x[this.last - 1], this.y[this.last - 1], x, y)) {
/*      */         
/*  987 */         this.x[this.last - 1] = x;
/*  988 */         this.y[this.last - 1] = y;
/*      */       }
/*      */       else {
/*      */         
/*  992 */         needs(0, 1);
/*  993 */         this.x[this.last] = x;
/*  994 */         this.y[this.last] = y;
/*  995 */         this.last++;
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public void prepend(int x, int y) {
/* 1002 */       if (this.last - this.first >= 2 && collinear(this.x[this.first + 1], this.y[this.first + 1], this.x[this.first], this.y[this.first], x, y)) {
/*      */         
/* 1004 */         this.x[this.first] = x;
/* 1005 */         this.y[this.first] = y;
/*      */       }
/*      */       else {
/*      */         
/* 1009 */         needs(1, 0);
/* 1010 */         this.first--;
/* 1011 */         this.x[this.first] = x;
/* 1012 */         this.y[this.first] = y;
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void append(Outline o) {
/* 1022 */       int size = this.last - this.first;
/* 1023 */       int oSize = o.last - o.first;
/* 1024 */       if (size <= o.first && oSize > this.reserved - this.last) {
/*      */         
/* 1026 */         System.arraycopy(this.x, this.first, o.x, o.first - size, size);
/* 1027 */         System.arraycopy(this.y, this.first, o.y, o.first - size, size);
/* 1028 */         this.x = o.x;
/* 1029 */         this.y = o.y;
/* 1030 */         o.first -= size;
/* 1031 */         this.last = o.last;
/* 1032 */         this.reserved = o.reserved;
/*      */       }
/*      */       else {
/*      */         
/* 1036 */         needs(0, oSize);
/* 1037 */         System.arraycopy(o.x, o.first, this.x, this.last, oSize);
/* 1038 */         System.arraycopy(o.y, o.first, this.y, this.last, oSize);
/* 1039 */         this.last += oSize;
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void prepend(Outline o) {
/* 1049 */       int size = this.last - this.first;
/* 1050 */       int oSize = o.last - o.first;
/* 1051 */       if (size <= o.reserved - o.last && oSize > this.first) {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1056 */         System.arraycopy(this.x, this.first, o.x, o.last, size);
/* 1057 */         System.arraycopy(this.y, this.first, o.y, o.last, size);
/* 1058 */         this.x = o.x;
/* 1059 */         this.y = o.y;
/* 1060 */         this.first = o.first;
/* 1061 */         o.last += size;
/* 1062 */         this.reserved = o.reserved;
/*      */       }
/*      */       else {
/*      */         
/* 1066 */         needs(oSize, 0);
/* 1067 */         this.first -= oSize;
/* 1068 */         System.arraycopy(o.x, o.first, this.x, this.first, oSize);
/* 1069 */         System.arraycopy(o.y, o.first, this.y, this.first, oSize);
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Polygon getPolygon() {
/* 1079 */       int j = this.first + 1; int i;
/* 1080 */       for (i = this.first + 1; i + 1 < this.last; j++) {
/*      */         
/* 1082 */         if (collinear(this.x[j - 1], this.y[j - 1], this.x[j], this.y[j], this.x[j + 1], this.y[j + 1])) {
/*      */ 
/*      */           
/* 1085 */           this.last--;
/*      */         } else {
/*      */           
/* 1088 */           if (i != j) {
/*      */             
/* 1090 */             this.x[i] = this.x[j];
/* 1091 */             this.y[i] = this.y[j];
/*      */           } 
/* 1093 */           i++;
/*      */         } 
/*      */       } 
/* 1096 */       if (collinear(this.x[j - 1], this.y[j - 1], this.x[j], this.y[j], this.x[this.first], this.y[this.first])) {
/* 1097 */         this.last--;
/*      */       } else {
/*      */         
/* 1100 */         this.x[i] = this.x[j];
/* 1101 */         this.y[i] = this.y[j];
/*      */       } 
/* 1103 */       if (this.last - this.first > 2 && collinear(this.x[this.last - 1], this.y[this.last - 1], this.x[this.first], this.y[this.first], this.x[this.first + 1], this.y[this.first + 1])) {
/* 1104 */         this.first++;
/*      */       }
/* 1106 */       int count = this.last - this.first;
/* 1107 */       int[] xNew = new int[count];
/* 1108 */       int[] yNew = new int[count];
/* 1109 */       System.arraycopy(this.x, this.first, xNew, 0, count);
/* 1110 */       System.arraycopy(this.y, this.first, yNew, 0, count);
/* 1111 */       return new Polygon(xNew, yNew, count);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean collinear(int x1, int y1, int x2, int y2, int x3, int y3) {
/* 1117 */       return ((x2 - x1) * (y3 - y2) == (y2 - y1) * (x3 - x2));
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public String toString() {
/* 1123 */       String res = "[first:" + this.first + ",last:" + this.last + ",reserved:" + this.reserved + ":";
/*      */       
/* 1125 */       if (this.last > this.x.length)
/* 1126 */         System.err.println("ERROR!"); 
/* 1127 */       int nmax = 10;
/* 1128 */       for (int i = this.first; i < this.last && i < this.x.length; i++) {
/*      */         
/* 1130 */         if (this.last - this.first > nmax && i - this.first > nmax / 2) {
/*      */           
/* 1132 */           i = this.last - nmax / 2;
/* 1133 */           res = res + "...";
/* 1134 */           nmax = this.last - this.first;
/*      */         } else {
/*      */           
/* 1137 */           res = res + "(" + this.x[i] + "," + this.y[i] + ")";
/*      */         } 
/* 1139 */       }  return res + "]";
/*      */     }
/*      */   }
/*      */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/detection/MaskUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */