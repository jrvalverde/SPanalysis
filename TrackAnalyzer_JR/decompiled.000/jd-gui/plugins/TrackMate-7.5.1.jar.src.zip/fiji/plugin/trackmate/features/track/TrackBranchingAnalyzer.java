/*     */ package fiji.plugin.trackmate.features.track;
/*     */ 
/*     */ import fiji.plugin.trackmate.Dimension;
/*     */ import fiji.plugin.trackmate.Model;
/*     */ import fiji.plugin.trackmate.Spot;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.jgrapht.graph.DefaultWeightedEdge;
/*     */ import org.scijava.plugin.Plugin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Plugin(type = TrackAnalyzer.class)
/*     */ public class TrackBranchingAnalyzer
/*     */   extends AbstractTrackAnalyzer
/*     */ {
/*     */   public static final String KEY = "Branching analyzer";
/*     */   public static final String NUMBER_GAPS = "NUMBER_GAPS";
/*     */   public static final String LONGEST_GAP = "LONGEST_GAP";
/*     */   public static final String NUMBER_SPLITS = "NUMBER_SPLITS";
/*     */   public static final String NUMBER_MERGES = "NUMBER_MERGES";
/*     */   public static final String NUMBER_COMPLEX = "NUMBER_COMPLEX";
/*     */   public static final String NUMBER_SPOTS = "NUMBER_SPOTS";
/*  50 */   public static final List<String> FEATURES = new ArrayList<>(6);
/*  51 */   public static final Map<String, String> FEATURE_NAMES = new HashMap<>(6);
/*  52 */   public static final Map<String, String> FEATURE_SHORT_NAMES = new HashMap<>(6);
/*  53 */   public static final Map<String, Dimension> FEATURE_DIMENSIONS = new HashMap<>(6);
/*  54 */   public static final Map<String, Boolean> IS_INT = new HashMap<>(6);
/*     */ 
/*     */   
/*     */   static {
/*  58 */     FEATURES.add("NUMBER_SPOTS");
/*  59 */     FEATURES.add("NUMBER_GAPS");
/*  60 */     FEATURES.add("NUMBER_SPLITS");
/*  61 */     FEATURES.add("NUMBER_MERGES");
/*  62 */     FEATURES.add("NUMBER_COMPLEX");
/*  63 */     FEATURES.add("LONGEST_GAP");
/*     */     
/*  65 */     FEATURE_NAMES.put("NUMBER_SPOTS", "Number of spots in track");
/*  66 */     FEATURE_NAMES.put("NUMBER_GAPS", "Number of gaps");
/*  67 */     FEATURE_NAMES.put("LONGEST_GAP", "Longest gap");
/*  68 */     FEATURE_NAMES.put("NUMBER_SPLITS", "Number of split events");
/*  69 */     FEATURE_NAMES.put("NUMBER_MERGES", "Number of merge events");
/*  70 */     FEATURE_NAMES.put("NUMBER_COMPLEX", "Number of complex points");
/*     */     
/*  72 */     FEATURE_SHORT_NAMES.put("NUMBER_SPOTS", "N spots");
/*  73 */     FEATURE_SHORT_NAMES.put("NUMBER_GAPS", "N gaps");
/*  74 */     FEATURE_SHORT_NAMES.put("NUMBER_SPLITS", "N splits");
/*  75 */     FEATURE_SHORT_NAMES.put("NUMBER_MERGES", "N merges");
/*  76 */     FEATURE_SHORT_NAMES.put("NUMBER_COMPLEX", "N complex");
/*  77 */     FEATURE_SHORT_NAMES.put("LONGEST_GAP", "Lgst gap");
/*     */     
/*  79 */     FEATURE_DIMENSIONS.put("NUMBER_SPOTS", Dimension.NONE);
/*  80 */     FEATURE_DIMENSIONS.put("NUMBER_GAPS", Dimension.NONE);
/*  81 */     FEATURE_DIMENSIONS.put("LONGEST_GAP", Dimension.NONE);
/*  82 */     FEATURE_DIMENSIONS.put("NUMBER_SPLITS", Dimension.NONE);
/*  83 */     FEATURE_DIMENSIONS.put("NUMBER_MERGES", Dimension.NONE);
/*  84 */     FEATURE_DIMENSIONS.put("NUMBER_COMPLEX", Dimension.NONE);
/*     */     
/*  86 */     IS_INT.put("NUMBER_SPOTS", Boolean.TRUE);
/*  87 */     IS_INT.put("NUMBER_GAPS", Boolean.TRUE);
/*  88 */     IS_INT.put("LONGEST_GAP", Boolean.TRUE);
/*  89 */     IS_INT.put("NUMBER_SPLITS", Boolean.TRUE);
/*  90 */     IS_INT.put("NUMBER_MERGES", Boolean.TRUE);
/*  91 */     IS_INT.put("NUMBER_COMPLEX", Boolean.TRUE);
/*     */   }
/*     */ 
/*     */   
/*     */   public TrackBranchingAnalyzer() {
/*  96 */     super("Branching analyzer", "Branching analyzer", FEATURES, FEATURE_NAMES, FEATURE_SHORT_NAMES, FEATURE_DIMENSIONS, IS_INT);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void analyze(Integer trackID, Model model) {
/* 102 */     Set<Spot> track = model.getTrackModel().trackSpots(trackID);
/*     */     
/* 104 */     int nmerges = 0;
/* 105 */     int nsplits = 0;
/* 106 */     int ncomplex = 0;
/* 107 */     for (Spot spot : track) {
/*     */       
/* 109 */       Set<DefaultWeightedEdge> edges = model.getTrackModel().edgesOf(spot);
/*     */ 
/*     */       
/* 112 */       Set<Spot> neighbors = new HashSet<>();
/* 113 */       for (DefaultWeightedEdge edge : edges) {
/*     */         
/* 115 */         neighbors.add(model.getTrackModel().getEdgeSource(edge));
/* 116 */         neighbors.add(model.getTrackModel().getEdgeTarget(edge));
/*     */       } 
/* 118 */       neighbors.remove(spot);
/*     */ 
/*     */       
/* 121 */       int earlier = 0;
/* 122 */       int later = 0;
/* 123 */       for (Spot neighbor : neighbors) {
/*     */         
/* 125 */         if (spot.diffTo(neighbor, "FRAME") > 0.0D) {
/* 126 */           earlier++; continue;
/*     */         } 
/* 128 */         later++;
/*     */       } 
/*     */ 
/*     */       
/* 132 */       if (earlier == 1 && later == 1) {
/*     */         continue;
/*     */       }
/*     */       
/* 136 */       if (earlier <= 1 && later > 1) {
/* 137 */         nsplits++; continue;
/* 138 */       }  if (later <= 1 && earlier > 1) {
/* 139 */         nmerges++; continue;
/* 140 */       }  if (later > 1 && earlier > 1) {
/* 141 */         ncomplex++;
/*     */       }
/*     */     } 
/* 144 */     int ngaps = 0, longestgap = 0;
/* 145 */     for (DefaultWeightedEdge edge : model.getTrackModel().trackEdges(trackID)) {
/*     */       
/* 147 */       Spot source = model.getTrackModel().getEdgeSource(edge);
/* 148 */       Spot target = model.getTrackModel().getEdgeTarget(edge);
/* 149 */       int gaplength = (int)Math.abs(target.diffTo(source, "FRAME")) - 1;
/* 150 */       if (gaplength > 0) {
/*     */         
/* 152 */         ngaps++;
/* 153 */         if (longestgap < gaplength) {
/* 154 */           longestgap = gaplength;
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 159 */     model.getFeatureModel().putTrackFeature(trackID, "NUMBER_GAPS", Double.valueOf(ngaps));
/* 160 */     model.getFeatureModel().putTrackFeature(trackID, "LONGEST_GAP", Double.valueOf(longestgap));
/* 161 */     model.getFeatureModel().putTrackFeature(trackID, "NUMBER_SPLITS", Double.valueOf(nsplits));
/* 162 */     model.getFeatureModel().putTrackFeature(trackID, "NUMBER_MERGES", Double.valueOf(nmerges));
/* 163 */     model.getFeatureModel().putTrackFeature(trackID, "NUMBER_COMPLEX", Double.valueOf(ncomplex));
/* 164 */     model.getFeatureModel().putTrackFeature(trackID, "NUMBER_SPOTS", Double.valueOf(track.size()));
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/features/track/TrackBranchingAnalyzer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */