/*     */ package fiji.plugin.trackmate.features;
/*     */ 
/*     */ import fiji.plugin.trackmate.Dimension;
/*     */ import fiji.plugin.trackmate.Logger;
/*     */ import fiji.plugin.trackmate.Model;
/*     */ import fiji.plugin.trackmate.Settings;
/*     */ import fiji.plugin.trackmate.SpotCollection;
/*     */ import fiji.plugin.trackmate.features.spot.SpotAnalyzer;
/*     */ import fiji.plugin.trackmate.features.spot.SpotAnalyzerFactoryBase;
/*     */ import fiji.plugin.trackmate.util.TMUtils;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.Callable;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.Executors;
/*     */ import java.util.concurrent.Future;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ import net.imagej.ImgPlus;
/*     */ import net.imglib2.algorithm.MultiThreaded;
/*     */ import net.imglib2.algorithm.MultiThreadedBenchmarkAlgorithm;
/*     */ import org.scijava.Cancelable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SpotFeatureCalculator
/*     */   extends MultiThreadedBenchmarkAlgorithm
/*     */   implements Cancelable
/*     */ {
/*     */   private static final String BASE_ERROR_MSG = "[SpotFeatureCalculator] ";
/*     */   private final Settings settings;
/*     */   private final Model model;
/*     */   private boolean isCanceled;
/*     */   private String cancelReason;
/*     */   private final boolean doLogIt;
/*     */   
/*     */   public SpotFeatureCalculator(Model model, Settings settings, boolean doLogIt) {
/*  73 */     this.settings = settings;
/*  74 */     this.model = model;
/*  75 */     this.doLogIt = doLogIt;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean checkInput() {
/*  85 */     if (null == this.model) {
/*     */       
/*  87 */       this.errorMessage = "[SpotFeatureCalculator] Model object is null.";
/*  88 */       return false;
/*     */     } 
/*  90 */     if (null == this.settings) {
/*     */       
/*  92 */       this.errorMessage = "[SpotFeatureCalculator] Settings object is null.";
/*  93 */       return false;
/*     */     } 
/*  95 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean process() {
/* 111 */     for (SpotAnalyzerFactoryBase<?> factory : (Iterable<SpotAnalyzerFactoryBase<?>>)this.settings.getSpotAnalyzerFactories()) {
/*     */       
/* 113 */       Collection<String> features = factory.getFeatures();
/* 114 */       Map<String, String> featureNames = factory.getFeatureNames();
/* 115 */       Map<String, String> featureShortNames = factory.getFeatureShortNames();
/* 116 */       Map<String, Dimension> featureDimensions = factory.getFeatureDimensions();
/* 117 */       Map<String, Boolean> isIntFeature = factory.getIsIntFeature();
/* 118 */       this.model.getFeatureModel().declareSpotFeatures(features, featureNames, featureShortNames, featureDimensions, isIntFeature);
/*     */     } 
/*     */ 
/*     */     
/* 122 */     computeSpotFeaturesAgent(this.model.getSpots(), this.settings.getSpotAnalyzerFactories(), this.doLogIt);
/* 123 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void computeSpotFeatures(SpotCollection toCompute, boolean doLogIt) {
/* 133 */     List<SpotAnalyzerFactoryBase<?>> spotFeatureAnalyzers = this.settings.getSpotAnalyzerFactories();
/* 134 */     computeSpotFeaturesAgent(toCompute, spotFeatureAnalyzers, doLogIt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void computeSpotFeaturesAgent(final SpotCollection toCompute, final List<SpotAnalyzerFactoryBase<?>> analyzerFactories, boolean doLogIt) {
/* 150 */     this.isCanceled = false;
/* 151 */     this.cancelReason = null;
/* 152 */     long start = System.currentTimeMillis();
/* 153 */     final Logger logger = doLogIt ? this.model.getLogger() : Logger.VOID_LOGGER;
/*     */ 
/*     */ 
/*     */     
/* 157 */     if (this.settings.imp == null) {
/*     */       return;
/*     */     }
/*     */     
/* 161 */     final ImgPlus img = TMUtils.rawWraps(this.settings.imp);
/*     */ 
/*     */     
/* 164 */     final List<Integer> frameSet = new ArrayList<>(toCompute.keySet());
/* 165 */     int numFrames = frameSet.size();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 173 */     int nSimultaneousFrames = Math.max(1, Math.min(this.numThreads, numFrames));
/* 174 */     final int threadsPerFrame = Math.max(1, this.numThreads / nSimultaneousFrames);
/*     */     
/* 176 */     if (doLogIt) {
/*     */       
/* 178 */       logger.log("Computing spot features over " + ((nSimultaneousFrames > 1) ? (nSimultaneousFrames + " frames") : "1 frame") + " simultaneously and allocating " + ((threadsPerFrame > 1) ? (threadsPerFrame + " threads") : "1 thread") + " per frame.\n");
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 183 */       logger.setStatus("Calculating " + toCompute.getNSpots(false) + " spots features...");
/*     */     } 
/*     */     
/* 186 */     final AtomicInteger progress = new AtomicInteger(0);
/* 187 */     List<Callable<Void>> tasks = new ArrayList<>(numFrames);
/* 188 */     final int workToDo = numFrames * analyzerFactories.size() * this.settings.imp.getNChannels();
/* 189 */     for (int iFrame = 0; iFrame < numFrames; iFrame++) {
/*     */       
/* 191 */       final int index = iFrame;
/*     */       
/* 193 */       Callable<Void> frameTask = new Callable<Void>()
/*     */         {
/*     */           
/*     */           public Void call() throws Exception
/*     */           {
/* 198 */             int frame = ((Integer)frameSet.get(index)).intValue();
/*     */             
/* 200 */             for (int channel = 0; channel < SpotFeatureCalculator.this.settings.imp.getNChannels(); ) {
/*     */               
/* 202 */               for (SpotAnalyzerFactoryBase<?> factory : (Iterable<SpotAnalyzerFactoryBase<?>>)analyzerFactories) {
/*     */                 
/* 204 */                 if (SpotFeatureCalculator.this.isCanceled()) {
/* 205 */                   return null;
/*     */                 }
/*     */ 
/*     */                 
/* 209 */                 SpotAnalyzer<?> analyzer = factory.getAnalyzer(img, frame, channel);
/*     */                 
/* 211 */                 if (analyzer instanceof MultiThreaded) {
/* 212 */                   ((MultiThreaded)analyzer).setNumThreads(threadsPerFrame);
/*     */                 }
/* 214 */                 analyzer.process(toCompute.iterable(frame, false));
/*     */                 
/* 216 */                 logger.setProgress(progress.incrementAndGet() / workToDo);
/*     */               } 
/*     */               channel++;
/*     */             } 
/* 220 */             return null;
/*     */           }
/*     */         };
/* 223 */       tasks.add(frameTask);
/*     */     } 
/*     */     
/* 226 */     ExecutorService executorService = Executors.newFixedThreadPool(nSimultaneousFrames);
/*     */ 
/*     */     
/*     */     try {
/* 230 */       List<Future<Void>> futures = executorService.invokeAll(tasks);
/* 231 */       for (Future<Void> future : futures) {
/* 232 */         future.get();
/*     */       }
/* 234 */     } catch (InterruptedException|java.util.concurrent.ExecutionException e) {
/*     */       
/* 236 */       e.printStackTrace();
/*     */     } 
/*     */     
/* 239 */     executorService.shutdown();
/* 240 */     logger.setProgress(1.0D);
/* 241 */     logger.setStatus("");
/*     */     
/* 243 */     long end = System.currentTimeMillis();
/* 244 */     this.processingTime = end - start;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isCanceled() {
/* 252 */     return this.isCanceled;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void cancel(String reason) {
/* 258 */     this.isCanceled = true;
/* 259 */     this.cancelReason = reason;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getCancelReason() {
/* 265 */     return this.cancelReason;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/features/SpotFeatureCalculator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */