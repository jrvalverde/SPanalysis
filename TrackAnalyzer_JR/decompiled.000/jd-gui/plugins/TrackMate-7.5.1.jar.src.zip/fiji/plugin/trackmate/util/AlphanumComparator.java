/*    */ package fiji.plugin.trackmate.util;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ import java.util.Comparator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AlphanumComparator
/*    */ {
/*    */   private static final Comparator<Object> raw;
/*    */   
/*    */   static {
/* 37 */     raw = Comparator.comparingInt(s -> Integer.parseInt(((String)s).replaceAll("\\D", ""))).thenComparing(s -> ((String)s).replaceAll("\\d", ""));
/*    */   }
/*    */   
/* 40 */   public static final Comparator<String> instance = (Comparator)raw;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static void main(String[] args) {
/* 48 */     String[] names = { "Track_0", "track_11", "track_2", "track_3", "track_4", "track_5", "track_6" };
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 57 */     Arrays.sort(names, instance);
/* 58 */     Arrays.<String>stream(names).forEach(System.out::println);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/util/AlphanumComparator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */