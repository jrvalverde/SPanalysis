/*     */ package fiji.plugin.trackmate.tracking.sparselap.costmatrix;
/*     */ 
/*     */ import fiji.plugin.trackmate.tracking.sparselap.costfunction.CostFunction;
/*     */ import fiji.plugin.trackmate.tracking.sparselap.linker.SparseCostMatrix;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JaqamanLinkingCostMatrixCreator<K extends Comparable<K>, J extends Comparable<J>>
/*     */   implements CostMatrixCreator<K, J>
/*     */ {
/*     */   private static final String BASE_ERROR_MSG = "[JaqamanLinkingCostMatrixCreator] ";
/*     */   private final Iterable<K> sources;
/*     */   private final Iterable<J> targets;
/*     */   private final CostFunction<K, J> costFunction;
/*     */   private SparseCostMatrix scm;
/*     */   private long processingTime;
/*     */   private String errorMessage;
/*     */   private final double costThreshold;
/*     */   private List<K> sourceList;
/*     */   private List<J> targetList;
/*     */   private double alternativeCost;
/*     */   private final double alternativeCostFactor;
/*     */   private final double percentile;
/*     */   
/*     */   public JaqamanLinkingCostMatrixCreator(Iterable<K> sources, Iterable<J> targets, CostFunction<K, J> costFunction, double costThreshold, double alternativeCostFactor, double percentile) {
/*  72 */     this.sources = sources;
/*  73 */     this.targets = targets;
/*  74 */     this.costFunction = costFunction;
/*  75 */     this.costThreshold = costThreshold;
/*  76 */     this.alternativeCostFactor = alternativeCostFactor;
/*  77 */     this.percentile = percentile;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean checkInput() {
/*  83 */     if (null == this.sources || !this.sources.iterator().hasNext()) {
/*     */       
/*  85 */       this.errorMessage = "[JaqamanLinkingCostMatrixCreator] The source list is empty or null.";
/*  86 */       return false;
/*     */     } 
/*  88 */     if (null == this.targets || !this.targets.iterator().hasNext()) {
/*     */       
/*  90 */       this.errorMessage = "[JaqamanLinkingCostMatrixCreator] The target list is empty or null.";
/*  91 */       return false;
/*     */     } 
/*  93 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean process() {
/*  99 */     long start = System.currentTimeMillis();
/*     */     
/* 101 */     List<K> accSources = new ArrayList<>();
/* 102 */     List<J> accTargets = new ArrayList<>();
/* 103 */     ResizableDoubleArray costs = new ResizableDoubleArray();
/*     */     
/* 105 */     for (Comparable comparable : this.sources) {
/*     */       
/* 107 */       for (Comparable comparable1 : this.targets) {
/*     */ 
/*     */         
/* 110 */         double cost = this.costFunction.linkingCost(comparable, comparable1);
/* 111 */         if (cost < this.costThreshold) {
/*     */           
/* 113 */           accSources.add((K)comparable);
/* 114 */           accTargets.add((J)comparable1);
/* 115 */           costs.add(cost);
/*     */         } 
/*     */       } 
/*     */     } 
/* 119 */     costs.trimToSize();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 125 */     if (accSources.isEmpty() || accTargets.isEmpty()) {
/*     */ 
/*     */       
/* 128 */       this.sourceList = Collections.emptyList();
/* 129 */       this.targetList = Collections.emptyList();
/* 130 */       this.alternativeCost = Double.NaN;
/* 131 */       this.scm = null;
/*     */ 
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */ 
/*     */       
/* 139 */       DefaultCostMatrixCreator<K, J> cmCreator = new DefaultCostMatrixCreator<>(accSources, accTargets, costs.data, this.alternativeCostFactor, this.percentile);
/* 140 */       if (!cmCreator.checkInput() || !cmCreator.process()) {
/*     */         
/* 142 */         this.errorMessage = cmCreator.getErrorMessage();
/* 143 */         return false;
/*     */       } 
/*     */       
/* 146 */       this.scm = cmCreator.getResult();
/* 147 */       this.sourceList = cmCreator.getSourceList();
/* 148 */       this.targetList = cmCreator.getTargetList();
/* 149 */       this.alternativeCost = cmCreator.computeAlternativeCosts();
/*     */     } 
/*     */ 
/*     */     
/* 153 */     long end = System.currentTimeMillis();
/* 154 */     this.processingTime = end - start;
/* 155 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getErrorMessage() {
/* 161 */     return this.errorMessage;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SparseCostMatrix getResult() {
/* 176 */     return this.scm;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public List<K> getSourceList() {
/* 182 */     return this.sourceList;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public List<J> getTargetList() {
/* 188 */     return this.targetList;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public long getProcessingTime() {
/* 194 */     return this.processingTime;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public double getAlternativeCostForSource(K source) {
/* 200 */     return this.alternativeCost;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public double getAlternativeCostForTarget(J target) {
/* 206 */     return this.alternativeCost;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/tracking/sparselap/costmatrix/JaqamanLinkingCostMatrixCreator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */