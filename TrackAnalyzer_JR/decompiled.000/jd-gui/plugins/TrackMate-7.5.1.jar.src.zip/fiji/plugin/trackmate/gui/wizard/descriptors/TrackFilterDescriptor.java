/*     */ package fiji.plugin.trackmate.gui.wizard.descriptors;
/*     */ 
/*     */ import fiji.plugin.trackmate.Logger;
/*     */ import fiji.plugin.trackmate.Model;
/*     */ import fiji.plugin.trackmate.TrackMate;
/*     */ import fiji.plugin.trackmate.features.FeatureFilter;
/*     */ import fiji.plugin.trackmate.gui.components.FeatureDisplaySelector;
/*     */ import fiji.plugin.trackmate.gui.components.FilterGuiPanel;
/*     */ import fiji.plugin.trackmate.gui.displaysettings.DisplaySettings;
/*     */ import fiji.plugin.trackmate.gui.wizard.WizardPanelDescriptor;
/*     */ import fiji.plugin.trackmate.io.SettingsPersistence;
/*     */ import fiji.plugin.trackmate.util.EverythingDisablerAndReenabler;
/*     */ import java.awt.Component;
/*     */ import java.awt.Container;
/*     */ import java.util.List;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.event.ChangeEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TrackFilterDescriptor
/*     */   extends WizardPanelDescriptor
/*     */ {
/*     */   private static final String KEY = "TrackFilter";
/*     */   private final TrackMate trackmate;
/*     */   
/*     */   public TrackFilterDescriptor(TrackMate trackmate, List<FeatureFilter> filters, FeatureDisplaySelector featureSelector) {
/*  53 */     super("TrackFilter");
/*  54 */     this.trackmate = trackmate;
/*     */ 
/*     */     
/*  57 */     FilterGuiPanel component = new FilterGuiPanel(trackmate.getModel(), trackmate.getSettings(), DisplaySettings.TrackMateObject.TRACKS, filters, "NUMBER_SPOTS", featureSelector);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  63 */     component.addChangeListener(e -> filterTracks());
/*  64 */     this.targetPanel = (Component)component;
/*     */   }
/*     */ 
/*     */   
/*     */   private void filterTracks() {
/*  69 */     FilterGuiPanel component = (FilterGuiPanel)this.targetPanel;
/*  70 */     this.trackmate.getSettings().setTrackFilters(component.getFeatureFilters());
/*  71 */     this.trackmate.execTrackFiltering(false);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Runnable getForwardRunnable() {
/*  77 */     return new Runnable()
/*     */       {
/*     */         
/*     */         public void run()
/*     */         {
/*  82 */           EverythingDisablerAndReenabler disabler = new EverythingDisablerAndReenabler((Container)TrackFilterDescriptor.this.targetPanel, new Class[] { JLabel.class });
/*  83 */           disabler.disable();
/*     */           
/*     */           try {
/*  86 */             Model model = TrackFilterDescriptor.this.trackmate.getModel();
/*  87 */             Logger logger = model.getLogger();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/*  93 */             FilterGuiPanel panel = (FilterGuiPanel)TrackFilterDescriptor.this.targetPanel;
/*  94 */             panel.showProgressBar(true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 100 */             logger.log("\n");
/*     */             
/* 102 */             long start = System.currentTimeMillis();
/* 103 */             Logger oldLogger = TrackFilterDescriptor.this.trackmate.getModel().getLogger();
/* 104 */             TrackFilterDescriptor.this.trackmate.getModel().setLogger(panel.getLogger());
/* 105 */             TrackFilterDescriptor.this.trackmate.computeEdgeFeatures(true);
/* 106 */             TrackFilterDescriptor.this.trackmate.computeTrackFeatures(true);
/* 107 */             long end = System.currentTimeMillis();
/* 108 */             TrackFilterDescriptor.this.trackmate.getModel().setLogger(oldLogger);
/* 109 */             if (TrackFilterDescriptor.this.trackmate.isCanceled())
/* 110 */               logger.log("Spot feature calculation canceled.\nSome spots will have missing feature values.\n"); 
/* 111 */             logger.log(String.format("Calculating features done in %.1f s.\n", new Object[] { Float.valueOf((float)(end - start) / 1000.0F) }));
/* 112 */             panel.showProgressBar(false);
/*     */ 
/*     */             
/* 115 */             panel.refreshValues();
/* 116 */             TrackFilterDescriptor.this.filterTracks();
/*     */           }
/*     */           finally {
/*     */             
/* 120 */             disabler.reenable();
/*     */           } 
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void displayingPanel() {
/* 129 */     FilterGuiPanel component = (FilterGuiPanel)this.targetPanel;
/* 130 */     this.trackmate.getSettings().setTrackFilters(component.getFeatureFilters());
/* 131 */     this.trackmate.execTrackFiltering(false);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void aboutToHidePanel() {
/* 137 */     Logger logger = this.trackmate.getModel().getLogger();
/* 138 */     logger.log("\nPerforming track filtering on the following features:\n", Logger.BLUE_COLOR);
/* 139 */     Model model = this.trackmate.getModel();
/* 140 */     FilterGuiPanel component = (FilterGuiPanel)this.targetPanel;
/* 141 */     List<FeatureFilter> featureFilters = component.getFeatureFilters();
/* 142 */     this.trackmate.getSettings().setTrackFilters(featureFilters);
/* 143 */     this.trackmate.execTrackFiltering(false);
/*     */     
/* 145 */     int ntotal = model.getTrackModel().nTracks(false);
/* 146 */     if (featureFilters == null || featureFilters.isEmpty()) {
/*     */       
/* 148 */       logger.log("No feature threshold set, kept the " + ntotal + " tracks.\n");
/*     */     }
/*     */     else {
/*     */       
/* 152 */       for (FeatureFilter ft : featureFilters) {
/*     */         
/* 154 */         String str = "  - on " + (String)this.trackmate.getModel().getFeatureModel().getTrackFeatureNames().get(ft.feature);
/* 155 */         if (ft.isAbove) {
/* 156 */           str = str + " above ";
/*     */         } else {
/* 158 */           str = str + " below ";
/* 159 */         }  str = str + String.format("%.1f", new Object[] { Double.valueOf(ft.value) });
/* 160 */         str = str + '\n';
/* 161 */         logger.log(str);
/*     */       } 
/* 163 */       int nselected = model.getTrackModel().nTracks(true);
/* 164 */       logger.log("Kept " + nselected + " spots out of " + ntotal + ".\n");
/*     */     } 
/*     */ 
/*     */     
/* 168 */     SettingsPersistence.saveLastUsedSettings(this.trackmate.getSettings(), logger);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/gui/wizard/descriptors/TrackFilterDescriptor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */