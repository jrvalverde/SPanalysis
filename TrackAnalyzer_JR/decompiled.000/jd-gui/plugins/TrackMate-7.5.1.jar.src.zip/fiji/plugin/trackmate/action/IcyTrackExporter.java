/*     */ package fiji.plugin.trackmate.action;
/*     */ 
/*     */ import fiji.plugin.trackmate.Model;
/*     */ import fiji.plugin.trackmate.SelectionModel;
/*     */ import fiji.plugin.trackmate.TrackMate;
/*     */ import fiji.plugin.trackmate.gui.Icons;
/*     */ import fiji.plugin.trackmate.gui.displaysettings.DisplaySettings;
/*     */ import fiji.plugin.trackmate.io.IOUtils;
/*     */ import fiji.plugin.trackmate.io.IcyTrackFormatWriter;
/*     */ import java.awt.Frame;
/*     */ import java.io.File;
/*     */ import javax.swing.ImageIcon;
/*     */ import org.scijava.plugin.Plugin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IcyTrackExporter
/*     */   extends AbstractTMAction
/*     */ {
/*     */   private static final String INFO_TEXT = "<html>Export the visible tracks in the current model to a XML file that can be read by the TrackManager plugin of the <a href='http://icy.bioimageanalysis.org/'>Icy software</a>.</html>";
/*     */   private static final String NAME = "Export tracks to Icy";
/*     */   private static final String KEY = "ICY_EXPORTER";
/*     */   
/*     */   public void execute(TrackMate trackmate, SelectionModel selectionModel, DisplaySettings displaySettings, Frame parent) {
/*     */     File folder;
/*  57 */     this.logger.log("Exporting tracks to Icy format.\n");
/*  58 */     Model model = trackmate.getModel();
/*  59 */     int ntracks = model.getTrackModel().nTracks(true);
/*  60 */     if (ntracks == 0) {
/*     */       
/*  62 */       this.logger.log("No visible track found. Aborting.\n");
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/*     */     try {
/*  69 */       folder = new File(((trackmate.getSettings()).imp.getOriginalFileInfo()).directory);
/*     */     }
/*  71 */     catch (NullPointerException npe) {
/*     */       
/*  73 */       folder = (new File(System.getProperty("user.dir"))).getParentFile().getParentFile();
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/*  79 */       String filename = (trackmate.getSettings()).imageFileName;
/*  80 */       int dotLoca = filename.indexOf(".");
/*  81 */       if (dotLoca > 0)
/*  82 */         filename = filename.substring(0, dotLoca); 
/*  83 */       file = new File(folder.getPath() + File.separator + filename + "_Icy.xml");
/*     */     }
/*  85 */     catch (NullPointerException npe) {
/*     */       
/*  87 */       file = new File(folder.getPath() + File.separator + "IcyTracks.xml");
/*     */     } 
/*  89 */     File file = IOUtils.askForFileForSaving(file, parent, this.logger);
/*  90 */     if (null == file) {
/*     */       return;
/*     */     }
/*  93 */     this.logger.log("  Writing to file.\n");
/*     */     
/*  95 */     double[] calibration = new double[3];
/*  96 */     calibration[0] = (trackmate.getSettings()).dx;
/*  97 */     calibration[1] = (trackmate.getSettings()).dy;
/*  98 */     calibration[2] = (trackmate.getSettings()).dz;
/*  99 */     IcyTrackFormatWriter writer = new IcyTrackFormatWriter(file, model, calibration);
/*     */     
/* 101 */     if (!writer.checkInput() || !writer.process()) {
/*     */       
/* 103 */       this.logger.error(writer.getErrorMessage());
/*     */     }
/*     */     else {
/*     */       
/* 107 */       this.logger.log("Done.\n");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Plugin(type = TrackMateActionFactory.class, enabled = true)
/*     */   public static class Factory
/*     */     implements TrackMateActionFactory
/*     */   {
/*     */     public String getInfoText() {
/* 118 */       return "<html>Export the visible tracks in the current model to a XML file that can be read by the TrackManager plugin of the <a href='http://icy.bioimageanalysis.org/'>Icy software</a>.</html>";
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public String getName() {
/* 124 */       return "Export tracks to Icy";
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public String getKey() {
/* 130 */       return "ICY_EXPORTER";
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public TrackMateAction create() {
/* 136 */       return new IcyTrackExporter();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public ImageIcon getIcon() {
/* 142 */       return Icons.ICY_ICON;
/*     */     }
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/action/IcyTrackExporter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */