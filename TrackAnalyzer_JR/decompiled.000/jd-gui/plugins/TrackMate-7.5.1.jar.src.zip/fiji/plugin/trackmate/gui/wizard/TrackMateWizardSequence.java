/*     */ package fiji.plugin.trackmate.gui.wizard;
/*     */ 
/*     */ import fiji.plugin.trackmate.Logger;
/*     */ import fiji.plugin.trackmate.Model;
/*     */ import fiji.plugin.trackmate.SelectionModel;
/*     */ import fiji.plugin.trackmate.Settings;
/*     */ import fiji.plugin.trackmate.TrackMate;
/*     */ import fiji.plugin.trackmate.action.ExportAllSpotsStatsAction;
/*     */ import fiji.plugin.trackmate.action.ExportStatsTablesAction;
/*     */ import fiji.plugin.trackmate.detection.SpotDetectorFactoryBase;
/*     */ import fiji.plugin.trackmate.features.FeatureFilter;
/*     */ import fiji.plugin.trackmate.features.ModelFeatureUpdater;
/*     */ import fiji.plugin.trackmate.gui.Icons;
/*     */ import fiji.plugin.trackmate.gui.components.ConfigurationPanel;
/*     */ import fiji.plugin.trackmate.gui.components.FeatureDisplaySelector;
/*     */ import fiji.plugin.trackmate.gui.components.LogPanel;
/*     */ import fiji.plugin.trackmate.gui.displaysettings.DisplaySettings;
/*     */ import fiji.plugin.trackmate.gui.wizard.descriptors.ActionChooserDescriptor;
/*     */ import fiji.plugin.trackmate.gui.wizard.descriptors.ChooseDetectorDescriptor;
/*     */ import fiji.plugin.trackmate.gui.wizard.descriptors.ChooseTrackerDescriptor;
/*     */ import fiji.plugin.trackmate.gui.wizard.descriptors.ConfigureViewsDescriptor;
/*     */ import fiji.plugin.trackmate.gui.wizard.descriptors.ExecuteDetectionDescriptor;
/*     */ import fiji.plugin.trackmate.gui.wizard.descriptors.ExecuteTrackingDescriptor;
/*     */ import fiji.plugin.trackmate.gui.wizard.descriptors.GrapherDescriptor;
/*     */ import fiji.plugin.trackmate.gui.wizard.descriptors.InitFilterDescriptor;
/*     */ import fiji.plugin.trackmate.gui.wizard.descriptors.LogPanelDescriptor2;
/*     */ import fiji.plugin.trackmate.gui.wizard.descriptors.SaveDescriptor;
/*     */ import fiji.plugin.trackmate.gui.wizard.descriptors.SpotDetectorDescriptor;
/*     */ import fiji.plugin.trackmate.gui.wizard.descriptors.SpotFilterDescriptor;
/*     */ import fiji.plugin.trackmate.gui.wizard.descriptors.SpotTrackerDescriptor;
/*     */ import fiji.plugin.trackmate.gui.wizard.descriptors.StartDialogDescriptor;
/*     */ import fiji.plugin.trackmate.gui.wizard.descriptors.TrackFilterDescriptor;
/*     */ import fiji.plugin.trackmate.providers.ActionProvider;
/*     */ import fiji.plugin.trackmate.providers.DetectorProvider;
/*     */ import fiji.plugin.trackmate.providers.TrackerProvider;
/*     */ import fiji.plugin.trackmate.tracking.SpotTrackerFactory;
/*     */ import fiji.plugin.trackmate.visualization.trackscheme.SpotImageUpdater;
/*     */ import fiji.plugin.trackmate.visualization.trackscheme.TrackScheme;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.swing.AbstractAction;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TrackMateWizardSequence
/*     */   implements WizardSequence
/*     */ {
/*     */   private final TrackMate trackmate;
/*     */   private final SelectionModel selectionModel;
/*     */   private final DisplaySettings displaySettings;
/*     */   private WizardPanelDescriptor current;
/*     */   private final StartDialogDescriptor startDialogDescriptor;
/*     */   private final Map<WizardPanelDescriptor, WizardPanelDescriptor> next;
/*     */   private final Map<WizardPanelDescriptor, WizardPanelDescriptor> previous;
/*     */   private final LogPanelDescriptor2 logDescriptor;
/*     */   private final ChooseDetectorDescriptor chooseDetectorDescriptor;
/*     */   private final ExecuteDetectionDescriptor executeDetectionDescriptor;
/*     */   private final InitFilterDescriptor initFilterDescriptor;
/*     */   private final SpotFilterDescriptor spotFilterDescriptor;
/*     */   private final ChooseTrackerDescriptor chooseTrackerDescriptor;
/*     */   private final ExecuteTrackingDescriptor executeTrackingDescriptor;
/*     */   private final TrackFilterDescriptor trackFilterDescriptor;
/*     */   private final ConfigureViewsDescriptor configureViewsDescriptor;
/*     */   private final GrapherDescriptor grapherDescriptor;
/*     */   private final ActionChooserDescriptor actionChooserDescriptor;
/*     */   private final SaveDescriptor saveDescriptor;
/*     */   private static final String TRACK_TABLES_BUTTON_TOOLTIP = "<html>Export the features of all tracks, edges and all <br>spots belonging to a track to ImageJ tables.</html>";
/*     */   private static final String SPOT_TABLE_BUTTON_TOOLTIP = "Export the features of all spots to ImageJ tables.";
/*     */   private static final String TRACKSCHEME_BUTTON_TOOLTIP = "<html>Launch a new instance of TrackScheme.</html>";
/*     */   
/*     */   public TrackMateWizardSequence(TrackMate trackmate, SelectionModel selectionModel, DisplaySettings displaySettings) {
/* 119 */     this.trackmate = trackmate;
/* 120 */     this.selectionModel = selectionModel;
/* 121 */     this.displaySettings = displaySettings;
/* 122 */     Settings settings = trackmate.getSettings();
/* 123 */     Model model = trackmate.getModel();
/*     */ 
/*     */     
/* 126 */     ModelFeatureUpdater modelFeatureUpdater = new ModelFeatureUpdater(model, settings);
/* 127 */     modelFeatureUpdater.setNumThreads(trackmate.getNumThreads());
/*     */     
/* 129 */     LogPanel logPanel = new LogPanel();
/* 130 */     Logger logger = logPanel.getLogger();
/* 131 */     model.setLogger(logger);
/*     */     
/* 133 */     FeatureDisplaySelector featureSelector = new FeatureDisplaySelector(model, settings, displaySettings);
/* 134 */     FeatureFilter initialFilter = new FeatureFilter("QUALITY", settings.initialSpotFilterValue.doubleValue(), true);
/* 135 */     List<FeatureFilter> spotFilters = settings.getSpotFilters();
/* 136 */     List<FeatureFilter> trackFilters = settings.getTrackFilters();
/*     */     
/* 138 */     this.logDescriptor = new LogPanelDescriptor2(logPanel);
/* 139 */     this.startDialogDescriptor = new StartDialogDescriptor(settings, logger);
/* 140 */     this.chooseDetectorDescriptor = new ChooseDetectorDescriptor(new DetectorProvider(), trackmate);
/* 141 */     this.executeDetectionDescriptor = new ExecuteDetectionDescriptor(trackmate, logPanel);
/* 142 */     this.initFilterDescriptor = new InitFilterDescriptor(trackmate, initialFilter);
/* 143 */     this.spotFilterDescriptor = new SpotFilterDescriptor(trackmate, spotFilters, featureSelector);
/* 144 */     this.chooseTrackerDescriptor = new ChooseTrackerDescriptor(new TrackerProvider(), trackmate);
/* 145 */     this.executeTrackingDescriptor = new ExecuteTrackingDescriptor(trackmate, logPanel);
/* 146 */     this.trackFilterDescriptor = new TrackFilterDescriptor(trackmate, trackFilters, featureSelector);
/* 147 */     this.configureViewsDescriptor = new ConfigureViewsDescriptor(displaySettings, featureSelector, new LaunchTrackSchemeAction(), new ShowTrackTablesAction(), new ShowSpotTableAction(), model.getSpaceUnits());
/* 148 */     this.grapherDescriptor = new GrapherDescriptor(trackmate, selectionModel, displaySettings);
/* 149 */     this.actionChooserDescriptor = new ActionChooserDescriptor(new ActionProvider(), trackmate, selectionModel, displaySettings);
/* 150 */     this.saveDescriptor = new SaveDescriptor(trackmate, displaySettings, this);
/*     */     
/* 152 */     this.next = getForwardSequence();
/* 153 */     this.previous = getBackwardSequence();
/* 154 */     this.current = (WizardPanelDescriptor)this.startDialogDescriptor;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void onClose() {
/* 160 */     this.trackmate.getModel().setLogger(Logger.IJ_LOGGER);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public WizardPanelDescriptor next() {
/* 166 */     if (this.current == this.chooseDetectorDescriptor) {
/* 167 */       getDetectorConfigDescriptor();
/*     */     }
/* 169 */     if (this.current == this.chooseTrackerDescriptor) {
/* 170 */       getTrackerConfigDescriptor();
/*     */     }
/* 172 */     this.current = this.next.get(this.current);
/* 173 */     return this.current;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WizardPanelDescriptor previous() {
/* 180 */     if (this.current == this.trackFilterDescriptor) {
/* 181 */       getTrackerConfigDescriptor();
/*     */     }
/* 183 */     if (this.current == this.spotFilterDescriptor) {
/* 184 */       getDetectorConfigDescriptor();
/*     */     }
/* 186 */     this.current = this.previous.get(this.current);
/* 187 */     return this.current;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasNext() {
/* 193 */     return (this.current != this.actionChooserDescriptor);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public WizardPanelDescriptor current() {
/* 199 */     return this.current;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WizardPanelDescriptor logDescriptor() {
/* 206 */     return (WizardPanelDescriptor)this.logDescriptor;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public WizardPanelDescriptor configDescriptor() {
/* 212 */     return (WizardPanelDescriptor)this.configureViewsDescriptor;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public WizardPanelDescriptor save() {
/* 218 */     return (WizardPanelDescriptor)this.saveDescriptor;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasPrevious() {
/* 224 */     return (this.current != this.startDialogDescriptor);
/*     */   }
/*     */ 
/*     */   
/*     */   private Map<WizardPanelDescriptor, WizardPanelDescriptor> getBackwardSequence() {
/* 229 */     Map<WizardPanelDescriptor, WizardPanelDescriptor> map = new HashMap<>();
/* 230 */     map.put(this.startDialogDescriptor, null);
/* 231 */     map.put(this.chooseDetectorDescriptor, this.startDialogDescriptor);
/* 232 */     map.put(this.chooseTrackerDescriptor, this.spotFilterDescriptor);
/* 233 */     map.put(this.configureViewsDescriptor, this.trackFilterDescriptor);
/* 234 */     map.put(this.grapherDescriptor, this.configureViewsDescriptor);
/* 235 */     map.put(this.actionChooserDescriptor, this.grapherDescriptor);
/* 236 */     return map;
/*     */   }
/*     */ 
/*     */   
/*     */   private Map<WizardPanelDescriptor, WizardPanelDescriptor> getForwardSequence() {
/* 241 */     Map<WizardPanelDescriptor, WizardPanelDescriptor> map = new HashMap<>();
/* 242 */     map.put(this.startDialogDescriptor, this.chooseDetectorDescriptor);
/* 243 */     map.put(this.executeDetectionDescriptor, this.initFilterDescriptor);
/* 244 */     map.put(this.initFilterDescriptor, this.spotFilterDescriptor);
/* 245 */     map.put(this.spotFilterDescriptor, this.chooseTrackerDescriptor);
/* 246 */     map.put(this.executeTrackingDescriptor, this.trackFilterDescriptor);
/* 247 */     map.put(this.trackFilterDescriptor, this.configureViewsDescriptor);
/* 248 */     map.put(this.configureViewsDescriptor, this.grapherDescriptor);
/* 249 */     map.put(this.grapherDescriptor, this.actionChooserDescriptor);
/* 250 */     return map;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCurrent(String panelIdentifier) {
/* 256 */     if (panelIdentifier.equals("ConfigureDetector")) {
/*     */       
/* 258 */       this.current = (WizardPanelDescriptor)getDetectorConfigDescriptor();
/*     */       
/*     */       return;
/*     */     } 
/* 262 */     if (panelIdentifier.equals("ConfigureTracker")) {
/*     */       
/* 264 */       this.current = (WizardPanelDescriptor)getTrackerConfigDescriptor();
/*     */       
/*     */       return;
/*     */     } 
/* 268 */     if (panelIdentifier.equals("InitialFiltering")) {
/*     */       
/* 270 */       getDetectorConfigDescriptor();
/* 271 */       this.current = (WizardPanelDescriptor)this.initFilterDescriptor;
/*     */       
/*     */       return;
/*     */     } 
/* 275 */     List<WizardPanelDescriptor> descriptors = Arrays.asList(new WizardPanelDescriptor[] { (WizardPanelDescriptor)this.logDescriptor, (WizardPanelDescriptor)this.chooseDetectorDescriptor, (WizardPanelDescriptor)this.executeDetectionDescriptor, (WizardPanelDescriptor)this.initFilterDescriptor, (WizardPanelDescriptor)this.spotFilterDescriptor, (WizardPanelDescriptor)this.chooseTrackerDescriptor, (WizardPanelDescriptor)this.executeTrackingDescriptor, (WizardPanelDescriptor)this.trackFilterDescriptor, (WizardPanelDescriptor)this.configureViewsDescriptor, (WizardPanelDescriptor)this.grapherDescriptor, (WizardPanelDescriptor)this.actionChooserDescriptor, (WizardPanelDescriptor)this.saveDescriptor });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 289 */     for (WizardPanelDescriptor w : descriptors) {
/*     */       
/* 291 */       if (w.getPanelDescriptorIdentifier().equals(panelIdentifier)) {
/*     */         
/* 293 */         this.current = w;
/*     */         break;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private SpotDetectorDescriptor getDetectorConfigDescriptor() {
/* 307 */     SpotDetectorFactoryBase<?> detectorFactory = (this.trackmate.getSettings()).detectorFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 313 */     if (detectorFactory.getKey().equals("MANUAL_DETECTOR")) {
/*     */ 
/*     */       
/* 316 */       this.next.put(this.chooseDetectorDescriptor, this.spotFilterDescriptor);
/* 317 */       this.previous.put(this.spotFilterDescriptor, this.chooseDetectorDescriptor);
/* 318 */       this.previous.put(this.executeDetectionDescriptor, this.chooseDetectorDescriptor);
/* 319 */       this.previous.put(this.initFilterDescriptor, this.chooseDetectorDescriptor);
/* 320 */       return null;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 328 */     Map<String, Object> oldSettings1 = new HashMap<>((this.trackmate.getSettings()).detectorSettings);
/*     */     
/* 330 */     Map<String, Object> oldSettings2 = new HashMap<>();
/* 331 */     WizardPanelDescriptor previousDescriptor = this.next.get(this.chooseDetectorDescriptor);
/* 332 */     if (previousDescriptor != null && previousDescriptor instanceof SpotDetectorDescriptor) {
/*     */       
/* 334 */       SpotDetectorDescriptor previousSpotDetectorDescriptor = (SpotDetectorDescriptor)previousDescriptor;
/* 335 */       ConfigurationPanel detectorConfigPanel = (ConfigurationPanel)previousSpotDetectorDescriptor.targetPanel;
/* 336 */       oldSettings2.putAll(detectorConfigPanel.getSettings());
/*     */     } 
/*     */     
/* 339 */     Map<String, Object> defaultSettings = detectorFactory.getDefaultSettings();
/* 340 */     for (String skey : defaultSettings.keySet()) {
/*     */       
/* 342 */       Object previousValue = oldSettings2.get(skey);
/* 343 */       if (previousValue == null) {
/* 344 */         previousValue = oldSettings1.get(skey);
/*     */       }
/* 346 */       defaultSettings.put(skey, previousValue);
/*     */     } 
/*     */     
/* 349 */     ConfigurationPanel detectorConfigurationPanel = detectorFactory.getDetectorConfigurationPanel(this.trackmate.getSettings(), this.trackmate.getModel());
/* 350 */     detectorConfigurationPanel.setSettings(defaultSettings);
/* 351 */     (this.trackmate.getSettings()).detectorSettings = defaultSettings;
/* 352 */     SpotDetectorDescriptor configDescriptor = new SpotDetectorDescriptor(this.trackmate.getSettings(), detectorConfigurationPanel, this.trackmate.getModel().getLogger());
/*     */ 
/*     */     
/* 355 */     this.next.put(this.chooseDetectorDescriptor, configDescriptor);
/* 356 */     this.next.put(configDescriptor, this.executeDetectionDescriptor);
/* 357 */     this.previous.put(configDescriptor, this.chooseDetectorDescriptor);
/* 358 */     this.previous.put(this.executeDetectionDescriptor, configDescriptor);
/* 359 */     this.previous.put(this.initFilterDescriptor, configDescriptor);
/* 360 */     this.previous.put(this.spotFilterDescriptor, configDescriptor);
/*     */     
/* 362 */     return configDescriptor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private SpotTrackerDescriptor getTrackerConfigDescriptor() {
/* 373 */     SpotTrackerFactory trackerFactory = (this.trackmate.getSettings()).trackerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 379 */     if (trackerFactory.getKey().equals("MANUAL_TRACKER")) {
/*     */ 
/*     */       
/* 382 */       this.next.put(this.chooseTrackerDescriptor, this.trackFilterDescriptor);
/* 383 */       this.previous.put(this.executeTrackingDescriptor, this.chooseTrackerDescriptor);
/* 384 */       this.previous.put(this.trackFilterDescriptor, this.chooseTrackerDescriptor);
/* 385 */       return null;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 392 */     Map<String, Object> oldSettings1 = new HashMap<>((this.trackmate.getSettings()).trackerSettings);
/*     */     
/* 394 */     Map<String, Object> oldSettings2 = new HashMap<>();
/* 395 */     WizardPanelDescriptor previousDescriptor = this.next.get(this.chooseTrackerDescriptor);
/* 396 */     if (previousDescriptor != null && previousDescriptor instanceof SpotTrackerDescriptor) {
/*     */       
/* 398 */       SpotTrackerDescriptor previousTrackerDetectorDescriptor = (SpotTrackerDescriptor)previousDescriptor;
/* 399 */       ConfigurationPanel detectorConfigPanel = (ConfigurationPanel)previousTrackerDetectorDescriptor.targetPanel;
/* 400 */       oldSettings2.putAll(detectorConfigPanel.getSettings());
/*     */     } 
/*     */     
/* 403 */     Map<String, Object> defaultSettings = trackerFactory.getDefaultSettings();
/* 404 */     for (String skey : defaultSettings.keySet()) {
/*     */       
/* 406 */       Object previousValue = oldSettings2.get(skey);
/* 407 */       if (previousValue == null) {
/* 408 */         previousValue = oldSettings1.get(skey);
/*     */       }
/* 410 */       defaultSettings.put(skey, previousValue);
/*     */     } 
/*     */     
/* 413 */     ConfigurationPanel trackerConfigurationPanel = trackerFactory.getTrackerConfigurationPanel(this.trackmate.getModel());
/* 414 */     trackerConfigurationPanel.setSettings(defaultSettings);
/* 415 */     (this.trackmate.getSettings()).trackerSettings = defaultSettings;
/* 416 */     SpotTrackerDescriptor configDescriptor = new SpotTrackerDescriptor(this.trackmate.getSettings(), trackerConfigurationPanel, this.trackmate.getModel().getLogger());
/*     */ 
/*     */     
/* 419 */     this.next.put(this.chooseTrackerDescriptor, configDescriptor);
/* 420 */     this.next.put(configDescriptor, this.executeTrackingDescriptor);
/* 421 */     this.previous.put(configDescriptor, this.chooseTrackerDescriptor);
/* 422 */     this.previous.put(this.executeTrackingDescriptor, configDescriptor);
/* 423 */     this.previous.put(this.trackFilterDescriptor, configDescriptor);
/*     */     
/* 425 */     return configDescriptor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private class LaunchTrackSchemeAction
/*     */     extends AbstractAction
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private LaunchTrackSchemeAction() {
/* 443 */       super("TrackScheme", Icons.TRACK_SCHEME_ICON_16x16);
/* 444 */       putValue("ShortDescription", "<html>Launch a new instance of TrackScheme.</html>");
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void actionPerformed(ActionEvent e) {
/* 450 */       (new Thread("Launching TrackScheme thread")
/*     */         {
/*     */           
/*     */           public void run()
/*     */           {
/* 455 */             TrackScheme trackscheme = new TrackScheme(TrackMateWizardSequence.this.trackmate.getModel(), TrackMateWizardSequence.this.selectionModel, TrackMateWizardSequence.this.displaySettings);
/* 456 */             SpotImageUpdater thumbnailUpdater = new SpotImageUpdater(TrackMateWizardSequence.this.trackmate.getSettings());
/* 457 */             trackscheme.setSpotImageUpdater(thumbnailUpdater);
/* 458 */             trackscheme.render();
/*     */           }
/* 460 */         }).start();
/*     */     }
/*     */   }
/*     */   
/*     */   private class ShowTrackTablesAction
/*     */     extends AbstractAction
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */     
/*     */     private ShowTrackTablesAction() {
/* 470 */       super("Tracks", Icons.TRACK_TABLES_ICON);
/* 471 */       putValue("ShortDescription", "<html>Export the features of all tracks, edges and all <br>spots belonging to a track to ImageJ tables.</html>");
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void actionPerformed(ActionEvent e) {
/* 477 */       TrackMateWizardSequence.this.showTables(false);
/*     */     }
/*     */   }
/*     */   
/*     */   private class ShowSpotTableAction
/*     */     extends AbstractAction
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */     
/*     */     private ShowSpotTableAction() {
/* 487 */       super("Spots", Icons.SPOT_TABLE_ICON);
/* 488 */       putValue("ShortDescription", "Export the features of all spots to ImageJ tables.");
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void actionPerformed(ActionEvent e) {
/* 494 */       TrackMateWizardSequence.this.showTables(true);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private void showTables(final boolean showSpotTable) {
/* 500 */     (new Thread("TrackMate table thread.")
/*     */       {
/*     */         public void run()
/*     */         {
/*     */           ExportStatsTablesAction exportStatsTablesAction;
/*     */           
/* 506 */           if (showSpotTable) {
/* 507 */             ExportAllSpotsStatsAction exportAllSpotsStatsAction = new ExportAllSpotsStatsAction();
/*     */           } else {
/* 509 */             exportStatsTablesAction = new ExportStatsTablesAction();
/*     */           } 
/* 511 */           exportStatsTablesAction.execute(TrackMateWizardSequence.this.trackmate, TrackMateWizardSequence.this.selectionModel, TrackMateWizardSequence.this.displaySettings, null);
/*     */         }
/* 513 */       }).start();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/gui/wizard/TrackMateWizardSequence.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */