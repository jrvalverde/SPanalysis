/*     */ package fiji.plugin.trackmate.graph;
/*     */ 
/*     */ import fiji.plugin.trackmate.Spot;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import net.imglib2.algorithm.Benchmark;
/*     */ import net.imglib2.algorithm.OutputAlgorithm;
/*     */ import org.jgrapht.graph.DefaultWeightedEdge;
/*     */ import org.jgrapht.graph.SimpleWeightedGraph;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FromContinuousBranches
/*     */   implements OutputAlgorithm<SimpleWeightedGraph<Spot, DefaultWeightedEdge>>, Benchmark
/*     */ {
/*     */   private static final String BASE_ERROR_MSG = "[FromContinuousBranches] ";
/*     */   private long processingTime;
/*     */   private final Collection<List<Spot>> branches;
/*     */   private final Collection<List<Spot>> links;
/*     */   private String errorMessage;
/*     */   private SimpleWeightedGraph<Spot, DefaultWeightedEdge> graph;
/*     */   
/*     */   public FromContinuousBranches(Collection<List<Spot>> branches, Collection<List<Spot>> links) {
/*  53 */     this.branches = branches;
/*  54 */     this.links = links;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public long getProcessingTime() {
/*  60 */     return this.processingTime;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean checkInput() {
/*  66 */     long start = System.currentTimeMillis();
/*  67 */     if (null == this.branches) {
/*     */       
/*  69 */       this.errorMessage = "[FromContinuousBranches] branches are null.";
/*  70 */       return false;
/*     */     } 
/*  72 */     if (null == this.links) {
/*     */       
/*  74 */       this.errorMessage = "[FromContinuousBranches] links are null.";
/*  75 */       return false;
/*     */     } 
/*  77 */     for (List<Spot> link : this.links) {
/*     */       
/*  79 */       if (link.size() != 2) {
/*     */         
/*  81 */         this.errorMessage = "[FromContinuousBranches] A link is not made of two spots.";
/*  82 */         return false;
/*     */       } 
/*  84 */       if (!checkIfInBranches(link.get(0))) {
/*     */         
/*  86 */         this.errorMessage = "[FromContinuousBranches] A spot in a link is not present in the branch collection: " + link.get(0) + " in the link " + link.get(0) + "-" + link.get(1) + ".";
/*  87 */         return false;
/*     */       } 
/*  89 */       if (!checkIfInBranches(link.get(1))) {
/*     */         
/*  91 */         this.errorMessage = "[FromContinuousBranches] A spot in a link is not present in the branch collection: " + link.get(1) + " in the link " + link.get(0) + "-" + link.get(1) + ".";
/*  92 */         return false;
/*     */       } 
/*     */     } 
/*  95 */     long end = System.currentTimeMillis();
/*  96 */     this.processingTime = end - start;
/*  97 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean process() {
/* 103 */     long start = System.currentTimeMillis();
/*     */     
/* 105 */     this.graph = new SimpleWeightedGraph(DefaultWeightedEdge.class);
/* 106 */     for (List<Spot> branch : this.branches) {
/*     */       
/* 108 */       for (Spot spot : branch)
/*     */       {
/* 110 */         this.graph.addVertex(spot);
/*     */       }
/*     */     } 
/*     */     
/* 114 */     for (List<Spot> branch : this.branches) {
/*     */       
/* 116 */       Iterator<Spot> it = branch.iterator();
/* 117 */       Spot previous = it.next();
/* 118 */       while (it.hasNext()) {
/*     */         
/* 120 */         Spot spot = it.next();
/* 121 */         this.graph.addEdge(previous, spot);
/* 122 */         previous = spot;
/*     */       } 
/*     */     } 
/*     */     
/* 126 */     for (List<Spot> link : this.links)
/*     */     {
/* 128 */       this.graph.addEdge(link.get(0), link.get(1));
/*     */     }
/*     */     
/* 131 */     long end = System.currentTimeMillis();
/* 132 */     this.processingTime = end - start;
/* 133 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getErrorMessage() {
/* 139 */     return this.errorMessage;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public SimpleWeightedGraph<Spot, DefaultWeightedEdge> getResult() {
/* 145 */     return this.graph;
/*     */   }
/*     */ 
/*     */   
/*     */   private final boolean checkIfInBranches(Spot spot) {
/* 150 */     for (List<Spot> branch : this.branches) {
/*     */       
/* 152 */       if (branch.contains(spot)) return true; 
/*     */     } 
/* 154 */     return false;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/graph/FromContinuousBranches.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */