/*     */ package fiji.plugin.trackmate.features;
/*     */ 
/*     */ import fiji.plugin.trackmate.FeatureModel;
/*     */ import fiji.plugin.trackmate.Model;
/*     */ import fiji.plugin.trackmate.Settings;
/*     */ import fiji.plugin.trackmate.Spot;
/*     */ import fiji.plugin.trackmate.features.edges.EdgeAnalyzer;
/*     */ import fiji.plugin.trackmate.features.spot.SpotAnalyzerFactoryBase;
/*     */ import fiji.plugin.trackmate.features.track.TrackAnalyzer;
/*     */ import fiji.plugin.trackmate.gui.displaysettings.DisplaySettings;
/*     */ import fiji.plugin.trackmate.visualization.FeatureColorGenerator;
/*     */ import fiji.plugin.trackmate.visualization.ManualEdgeColorGenerator;
/*     */ import fiji.plugin.trackmate.visualization.ManualEdgePerSpotColorGenerator;
/*     */ import fiji.plugin.trackmate.visualization.ManualSpotColorGenerator;
/*     */ import fiji.plugin.trackmate.visualization.ManualSpotPerEdgeColorGenerator;
/*     */ import fiji.plugin.trackmate.visualization.PerEdgeFeatureColorGenerator;
/*     */ import fiji.plugin.trackmate.visualization.PerSpotFeatureColorGenerator;
/*     */ import fiji.plugin.trackmate.visualization.PerTrackFeatureColorGenerator;
/*     */ import fiji.plugin.trackmate.visualization.SpotColorGenerator;
/*     */ import fiji.plugin.trackmate.visualization.SpotColorGeneratorPerEdgeFeature;
/*     */ import fiji.plugin.trackmate.visualization.SpotColorGeneratorPerTrackFeature;
/*     */ import fiji.plugin.trackmate.visualization.UniformSpotColorGenerator;
/*     */ import fiji.plugin.trackmate.visualization.UniformTrackColorGenerator;
/*     */ import fiji.plugin.trackmate.visualization.WholeTrackFeatureColorGenerator;
/*     */ import java.awt.Color;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Random;
/*     */ import org.jgrapht.graph.DefaultWeightedEdge;
/*     */ import org.scijava.util.DoubleArray;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FeatureUtils
/*     */ {
/*     */   private static final String USE_UNIFORM_COLOR_NAME = "Uniform color";
/*     */   public static final String USE_UNIFORM_COLOR_KEY = "UNIFORM_COLOR";
/*     */   
/*     */   public static final Map<String, String> collectFeatureKeys(DisplaySettings.TrackMateObject target, Model model, Settings settings) {
/*  70 */     Map<String, String> inverseMap = new HashMap<>();
/*     */ 
/*     */     
/*  73 */     switch (target) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case SPOTS:
/*  79 */         if (model != null) {
/*     */           
/*  81 */           for (String featureKey : model.getFeatureModel().getSpotFeatureNames().keySet()) {
/*  82 */             inverseMap.put((String)model.getFeatureModel().getSpotFeatureNames().get(featureKey), featureKey);
/*     */           }
/*     */         }
/*     */         else {
/*     */           
/*  87 */           for (String featureKey : Spot.FEATURE_NAMES.keySet())
/*  88 */             inverseMap.put((String)Spot.FEATURE_NAMES.get(featureKey), featureKey); 
/*     */         } 
/*  90 */         if (settings != null)
/*     */         {
/*  92 */           for (SpotAnalyzerFactoryBase<?> sf : (Iterable<SpotAnalyzerFactoryBase<?>>)settings.getSpotAnalyzerFactories()) {
/*  93 */             for (String featureKey : sf.getFeatureNames().keySet()) {
/*  94 */               inverseMap.put((String)sf.getFeatureNames().get(featureKey), featureKey);
/*     */             }
/*     */           } 
/*     */         }
/*     */         break;
/*     */       
/*     */       case EDGES:
/* 101 */         if (model != null)
/*     */         {
/* 103 */           for (String featureKey : model.getFeatureModel().getEdgeFeatureNames().keySet())
/* 104 */             inverseMap.put((String)model.getFeatureModel().getEdgeFeatureNames().get(featureKey), featureKey); 
/*     */         }
/* 106 */         if (settings != null)
/*     */         {
/* 108 */           for (EdgeAnalyzer ea : settings.getEdgeAnalyzers()) {
/* 109 */             for (String featureKey : ea.getFeatureNames().keySet()) {
/* 110 */               inverseMap.put((String)ea.getFeatureNames().get(featureKey), featureKey);
/*     */             }
/*     */           } 
/*     */         }
/*     */         break;
/*     */       
/*     */       case TRACKS:
/* 117 */         if (model != null)
/*     */         {
/* 119 */           for (String featureKey : model.getFeatureModel().getTrackFeatureNames().keySet())
/* 120 */             inverseMap.put((String)model.getFeatureModel().getTrackFeatureNames().get(featureKey), featureKey); 
/*     */         }
/* 122 */         if (settings != null)
/*     */         {
/* 124 */           for (TrackAnalyzer ta : settings.getTrackAnalyzers()) {
/* 125 */             for (String featureKey : ta.getFeatureNames().keySet()) {
/* 126 */               inverseMap.put((String)ta.getFeatureNames().get(featureKey), featureKey);
/*     */             }
/*     */           } 
/*     */         }
/*     */         break;
/*     */       
/*     */       case DEFAULT:
/* 133 */         inverseMap.put("Uniform color", "UNIFORM_COLOR");
/*     */         break;
/*     */ 
/*     */       
/*     */       default:
/* 138 */         throw new IllegalArgumentException("Unknown object type: " + target);
/*     */     } 
/*     */ 
/*     */     
/* 142 */     List<String> featureNameList = new ArrayList<>(inverseMap.keySet());
/* 143 */     featureNameList.sort(null);
/*     */     
/* 145 */     Map<String, String> featureNames = new LinkedHashMap<>(featureNameList.size());
/* 146 */     for (String featureName : featureNameList) {
/* 147 */       featureNames.put(inverseMap.get(featureName), featureName);
/*     */     }
/* 149 */     return featureNames;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static double[] collectFeatureValues(String featureKey, DisplaySettings.TrackMateObject target, Model model, boolean visibleOnly) {
/*     */     DoubleArray val;
/* 168 */     FeatureModel fm = model.getFeatureModel();
/* 169 */     switch (target) {
/*     */       
/*     */       case DEFAULT:
/* 172 */         return new double[0];
/*     */ 
/*     */       
/*     */       case EDGES:
/* 176 */         val = new DoubleArray();
/* 177 */         for (Integer trackID : model.getTrackModel().trackIDs(visibleOnly)) {
/*     */           
/* 179 */           for (DefaultWeightedEdge edge : model.getTrackModel().trackEdges(trackID)) {
/*     */             
/* 181 */             Double ef = fm.getEdgeFeature(edge, featureKey);
/* 182 */             if (ef != null && !ef.isNaN())
/* 183 */               val.add(Double.valueOf(ef.doubleValue())); 
/*     */           } 
/*     */         } 
/* 186 */         return (double[])val.copyArray();
/*     */ 
/*     */ 
/*     */       
/*     */       case SPOTS:
/* 191 */         val = new DoubleArray();
/* 192 */         for (Spot spot : model.getSpots().iterable(visibleOnly)) {
/*     */           
/* 194 */           Double sf = spot.getFeature(featureKey);
/* 195 */           if (sf != null && !sf.isNaN())
/* 196 */             val.add(Double.valueOf(sf.doubleValue())); 
/*     */         } 
/* 198 */         return (double[])val.copyArray();
/*     */ 
/*     */       
/*     */       case TRACKS:
/* 202 */         val = new DoubleArray();
/* 203 */         for (Integer trackID : model.getTrackModel().trackIDs(visibleOnly)) {
/*     */           
/* 205 */           Double tf = fm.getTrackFeature(trackID, featureKey);
/* 206 */           if (tf != null && !tf.isNaN())
/* 207 */             val.add(Double.valueOf(tf.doubleValue())); 
/*     */         } 
/* 209 */         return (double[])val.copyArray();
/*     */     } 
/*     */     
/* 212 */     throw new IllegalArgumentException("Unknown object type: " + target);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static final FeatureColorGenerator<Spot> createSpotColorGenerator(Model model, DisplaySettings displaySettings) {
/* 218 */     switch (displaySettings.getSpotColorByType()) {
/*     */       
/*     */       case DEFAULT:
/* 221 */         return (FeatureColorGenerator<Spot>)new UniformSpotColorGenerator(displaySettings.getSpotUniformColor());
/*     */ 
/*     */       
/*     */       case EDGES:
/* 225 */         if (displaySettings.getSpotColorByFeature().equals("MANUAL_EGE_COLOR")) {
/* 226 */           return (FeatureColorGenerator<Spot>)new ManualSpotPerEdgeColorGenerator(model, displaySettings.getMissingValueColor());
/*     */         }
/* 228 */         return (FeatureColorGenerator<Spot>)new SpotColorGeneratorPerEdgeFeature(model, displaySettings
/*     */             
/* 230 */             .getSpotColorByFeature(), displaySettings
/* 231 */             .getMissingValueColor(), displaySettings
/* 232 */             .getUndefinedValueColor(), displaySettings
/* 233 */             .getColormap(), displaySettings
/* 234 */             .getSpotMin(), displaySettings
/* 235 */             .getSpotMax());
/*     */ 
/*     */       
/*     */       case SPOTS:
/* 239 */         if (displaySettings.getSpotColorByFeature().equals("MANUAL_SPOT_COLOR")) {
/* 240 */           return (FeatureColorGenerator<Spot>)new ManualSpotColorGenerator(displaySettings.getMissingValueColor());
/*     */         }
/* 242 */         return (FeatureColorGenerator<Spot>)new SpotColorGenerator(displaySettings
/* 243 */             .getSpotColorByFeature(), displaySettings
/* 244 */             .getMissingValueColor(), displaySettings
/* 245 */             .getUndefinedValueColor(), displaySettings
/* 246 */             .getColormap(), displaySettings
/* 247 */             .getSpotMin(), displaySettings
/* 248 */             .getSpotMax());
/*     */       
/*     */       case TRACKS:
/* 251 */         return (FeatureColorGenerator<Spot>)new SpotColorGeneratorPerTrackFeature(model, displaySettings
/*     */             
/* 253 */             .getSpotColorByFeature(), displaySettings
/* 254 */             .getMissingValueColor(), displaySettings
/* 255 */             .getUndefinedValueColor(), displaySettings
/* 256 */             .getColormap(), displaySettings
/* 257 */             .getSpotMin(), displaySettings
/* 258 */             .getSpotMax());
/*     */     } 
/*     */     
/* 261 */     throw new IllegalArgumentException("Unknown type: " + displaySettings.getSpotColorByType());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static final FeatureColorGenerator<DefaultWeightedEdge> createTrackColorGenerator(Model model, DisplaySettings displaySettings) {
/* 267 */     switch (displaySettings.getTrackColorByType()) {
/*     */       
/*     */       case DEFAULT:
/* 270 */         return (FeatureColorGenerator<DefaultWeightedEdge>)new UniformTrackColorGenerator(displaySettings.getTrackUniformColor());
/*     */ 
/*     */       
/*     */       case EDGES:
/* 274 */         if (displaySettings.getTrackColorByFeature().equals("MANUAL_EGE_COLOR")) {
/* 275 */           return (FeatureColorGenerator<DefaultWeightedEdge>)new ManualEdgeColorGenerator(model, displaySettings.getMissingValueColor());
/*     */         }
/* 277 */         return (FeatureColorGenerator<DefaultWeightedEdge>)new PerEdgeFeatureColorGenerator(model, displaySettings
/*     */             
/* 279 */             .getTrackColorByFeature(), displaySettings
/* 280 */             .getMissingValueColor(), displaySettings
/* 281 */             .getUndefinedValueColor(), displaySettings
/* 282 */             .getColormap(), displaySettings
/* 283 */             .getTrackMin(), displaySettings
/* 284 */             .getTrackMax());
/*     */ 
/*     */       
/*     */       case SPOTS:
/* 288 */         if (displaySettings.getTrackColorByFeature().equals("MANUAL_SPOT_COLOR")) {
/* 289 */           return (FeatureColorGenerator<DefaultWeightedEdge>)new ManualEdgePerSpotColorGenerator(model, displaySettings.getMissingValueColor());
/*     */         }
/* 291 */         return (FeatureColorGenerator<DefaultWeightedEdge>)new PerSpotFeatureColorGenerator(model, displaySettings
/*     */             
/* 293 */             .getTrackColorByFeature(), displaySettings
/* 294 */             .getMissingValueColor(), displaySettings
/* 295 */             .getUndefinedValueColor(), displaySettings
/* 296 */             .getColormap(), displaySettings
/* 297 */             .getTrackMin(), displaySettings
/* 298 */             .getTrackMax());
/*     */       
/*     */       case TRACKS:
/* 301 */         return (FeatureColorGenerator<DefaultWeightedEdge>)new PerTrackFeatureColorGenerator(model, displaySettings
/*     */             
/* 303 */             .getTrackColorByFeature(), displaySettings
/* 304 */             .getMissingValueColor(), displaySettings
/* 305 */             .getUndefinedValueColor(), displaySettings
/* 306 */             .getColormap(), displaySettings
/* 307 */             .getTrackMin(), displaySettings
/* 308 */             .getTrackMax());
/*     */     } 
/*     */     
/* 311 */     throw new IllegalArgumentException("Unknown type: " + displaySettings.getTrackColorByType());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static final FeatureColorGenerator<Integer> createWholeTrackColorGenerator(Model model, DisplaySettings displaySettings) {
/* 317 */     switch (displaySettings.getTrackColorByType()) {
/*     */       
/*     */       case SPOTS:
/*     */       case DEFAULT:
/* 321 */         return id -> Color.WHITE;
/*     */       
/*     */       case EDGES:
/*     */       case TRACKS:
/* 325 */         return (FeatureColorGenerator<Integer>)new WholeTrackFeatureColorGenerator(model, displaySettings
/*     */             
/* 327 */             .getTrackColorByFeature(), displaySettings
/* 328 */             .getMissingValueColor(), displaySettings
/* 329 */             .getUndefinedValueColor(), displaySettings
/* 330 */             .getColormap(), displaySettings
/* 331 */             .getTrackMin(), displaySettings
/* 332 */             .getTrackMax());
/*     */     } 
/*     */     
/* 335 */     throw new IllegalArgumentException("Unknown type: " + displaySettings.getTrackColorByType());
/*     */   }
/*     */ 
/*     */   
/* 339 */   public static final Model DUMMY_MODEL = new Model();
/*     */   
/*     */   static {
/* 342 */     Random ran = new Random();
/* 343 */     DUMMY_MODEL.beginUpdate();
/*     */ 
/*     */     
/*     */     try {
/* 347 */       for (int i = 0; i < 100; i++) {
/*     */         
/* 349 */         Spot previous = null;
/* 350 */         for (int t = 0; t < 20; t++)
/*     */         {
/*     */           
/* 353 */           double x = ran.nextDouble();
/* 354 */           double y = ran.nextDouble();
/* 355 */           double z = ran.nextDouble();
/* 356 */           double r = ran.nextDouble();
/* 357 */           double q = ran.nextDouble();
/* 358 */           Spot spot = new Spot(x, y, z, r, q);
/* 359 */           DUMMY_MODEL.addSpotTo(spot, Integer.valueOf(t));
/* 360 */           if (previous != null) {
/* 361 */             DUMMY_MODEL.addEdge(previous, spot, ran.nextDouble());
/*     */           }
/* 363 */           previous = spot;
/*     */         }
/*     */       
/*     */       } 
/*     */     } finally {
/*     */       
/* 369 */       DUMMY_MODEL.endUpdate();
/*     */     } 
/*     */   } public static final double[] autoMinMax(Model model, DisplaySettings.TrackMateObject type, String feature) {
/*     */     double[] values;
/*     */     double min;
/*     */     double max;
/* 375 */     switch (type) {
/*     */       
/*     */       case DEFAULT:
/* 378 */         return new double[] { 0.0D, 0.0D };
/*     */ 
/*     */       
/*     */       case SPOTS:
/*     */       case EDGES:
/*     */       case TRACKS:
/* 384 */         values = collectFeatureValues(feature, type, model, true);
/* 385 */         min = Double.POSITIVE_INFINITY;
/* 386 */         max = Double.NEGATIVE_INFINITY;
/* 387 */         for (double val : values) {
/*     */           
/* 389 */           if (val < min) {
/* 390 */             min = val;
/*     */           }
/* 392 */           if (val > max)
/* 393 */             max = val; 
/*     */         } 
/* 395 */         return new double[] { min, max };
/*     */     } 
/*     */ 
/*     */     
/* 399 */     throw new IllegalArgumentException("Unexpected TrackMate object type: " + type);
/*     */   }
/*     */ 
/*     */   
/*     */   public static final int nObjects(Model model, DisplaySettings.TrackMateObject target, boolean visibleOnly) {
/*     */     int nEdges;
/* 405 */     switch (target) {
/*     */       
/*     */       case DEFAULT:
/* 408 */         throw new UnsupportedOperationException("Cannot return the number of objects for type DEFAULT.");
/*     */       
/*     */       case EDGES:
/* 411 */         nEdges = 0;
/* 412 */         for (Integer trackID : model.getTrackModel().unsortedTrackIDs(visibleOnly))
/* 413 */           nEdges += model.getTrackModel().trackEdges(trackID).size(); 
/* 414 */         return nEdges;
/*     */       
/*     */       case SPOTS:
/* 417 */         return model.getSpots().getNSpots(visibleOnly);
/*     */       case TRACKS:
/* 419 */         return model.getTrackModel().nTracks(visibleOnly);
/*     */     } 
/* 421 */     throw new IllegalArgumentException("Unknown TrackMate object: " + target);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/features/FeatureUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */