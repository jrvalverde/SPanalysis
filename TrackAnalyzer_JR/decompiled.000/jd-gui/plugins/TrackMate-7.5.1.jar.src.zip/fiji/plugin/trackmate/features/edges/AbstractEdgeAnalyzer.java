/*     */ package fiji.plugin.trackmate.features.edges;
/*     */ 
/*     */ import fiji.plugin.trackmate.Dimension;
/*     */ import fiji.plugin.trackmate.Model;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.Callable;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.Executors;
/*     */ import java.util.concurrent.Future;
/*     */ import javax.swing.ImageIcon;
/*     */ import org.jgrapht.graph.DefaultWeightedEdge;
/*     */ import org.scijava.plugin.Plugin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Plugin(type = EdgeAnalyzer.class, enabled = false)
/*     */ public abstract class AbstractEdgeAnalyzer
/*     */   implements EdgeAnalyzer
/*     */ {
/*     */   private int numThreads;
/*     */   private long processingTime;
/*     */   private final String key;
/*     */   private final String name;
/*     */   private final List<String> features;
/*     */   private final Map<String, String> featureNames;
/*     */   private final Map<String, String> featureShortNames;
/*     */   private final Map<String, Dimension> featureDimensions;
/*     */   private final Map<String, Boolean> isInts;
/*     */   
/*     */   public AbstractEdgeAnalyzer(String key, String name, List<String> features, Map<String, String> featureNames, Map<String, String> featureShortNames, Map<String, Dimension> featureDimensions, Map<String, Boolean> isInts) {
/*  77 */     this.key = key;
/*  78 */     this.name = name;
/*  79 */     this.features = features;
/*  80 */     this.featureNames = featureNames;
/*  81 */     this.featureShortNames = featureShortNames;
/*  82 */     this.featureDimensions = featureDimensions;
/*  83 */     this.isInts = isInts;
/*  84 */     setNumThreads();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public long getProcessingTime() {
/*  90 */     return this.processingTime;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isManualFeature() {
/*  96 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ImageIcon getIcon() {
/* 102 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getInfoText() {
/* 108 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getNumThreads() {
/* 114 */     return this.numThreads;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setNumThreads() {
/* 120 */     setNumThreads(Runtime.getRuntime().availableProcessors() / 2);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setNumThreads(int numThreads) {
/* 126 */     this.numThreads = numThreads;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isLocal() {
/* 132 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getKey() {
/* 138 */     return this.key;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/* 144 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, Dimension> getFeatureDimensions() {
/* 150 */     return this.featureDimensions;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, String> getFeatureNames() {
/* 156 */     return this.featureNames;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public List<String> getFeatures() {
/* 162 */     return this.features;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, String> getFeatureShortNames() {
/* 168 */     return this.featureShortNames;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, Boolean> getIsIntFeature() {
/* 174 */     return this.isInts;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void process(Collection<DefaultWeightedEdge> edges, final Model model) {
/* 180 */     if (edges.isEmpty()) {
/*     */       return;
/*     */     }
/* 183 */     long start = System.currentTimeMillis();
/*     */ 
/*     */     
/* 186 */     List<Callable<Void>> tasks = new ArrayList<>(edges.size());
/* 187 */     for (DefaultWeightedEdge edge : edges) {
/*     */       
/* 189 */       Callable<Void> task = new Callable<Void>()
/*     */         {
/*     */ 
/*     */           
/*     */           public Void call() throws Exception
/*     */           {
/* 195 */             AbstractEdgeAnalyzer.this.analyze(edge, model);
/* 196 */             return null;
/*     */           }
/*     */         };
/* 199 */       tasks.add(task);
/*     */     } 
/*     */     
/* 202 */     ExecutorService executorService = Executors.newFixedThreadPool(this.numThreads);
/*     */ 
/*     */     
/*     */     try {
/* 206 */       List<Future<Void>> futures = executorService.invokeAll(tasks);
/* 207 */       for (Future<Void> future : futures) {
/* 208 */         future.get();
/*     */       }
/* 210 */     } catch (InterruptedException|java.util.concurrent.ExecutionException e) {
/*     */       
/* 212 */       e.printStackTrace();
/*     */     } 
/* 214 */     executorService.shutdown();
/*     */     
/* 216 */     long end = System.currentTimeMillis();
/* 217 */     this.processingTime = end - start;
/*     */   }
/*     */   
/*     */   protected abstract void analyze(DefaultWeightedEdge paramDefaultWeightedEdge, Model paramModel);
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/features/edges/AbstractEdgeAnalyzer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */