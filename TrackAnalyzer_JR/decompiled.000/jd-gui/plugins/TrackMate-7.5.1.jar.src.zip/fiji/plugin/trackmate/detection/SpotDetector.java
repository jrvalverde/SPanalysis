package fiji.plugin.trackmate.detection;

import fiji.plugin.trackmate.Spot;
import java.util.List;
import net.imglib2.algorithm.Benchmark;
import net.imglib2.algorithm.OutputAlgorithm;

public interface SpotDetector<T extends net.imglib2.type.numeric.RealType<T> & net.imglib2.type.NativeType<T>> extends OutputAlgorithm<List<Spot>>, Benchmark {}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/detection/SpotDetector.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */