/*     */ package fiji.plugin.trackmate;
/*     */ 
/*     */ import fiji.plugin.trackmate.action.ExportTracksToXML;
/*     */ import fiji.plugin.trackmate.features.FeatureFilter;
/*     */ import fiji.plugin.trackmate.gui.GuiUtils;
/*     */ import fiji.plugin.trackmate.gui.Icons;
/*     */ import fiji.plugin.trackmate.gui.components.LogPanel;
/*     */ import fiji.plugin.trackmate.gui.displaysettings.DisplaySettings;
/*     */ import fiji.plugin.trackmate.gui.wizard.WizardSequence;
/*     */ import fiji.plugin.trackmate.gui.wizard.descriptors.LogPanelDescriptor2;
/*     */ import fiji.plugin.trackmate.io.TmXmlWriter;
/*     */ import fiji.plugin.trackmate.util.LogRecorder;
/*     */ import fiji.plugin.trackmate.util.TMUtils;
/*     */ import fiji.plugin.trackmate.visualization.hyperstack.HyperStackDisplayer;
/*     */ import fiji.util.SplitString;
/*     */ import ij.ImageJ;
/*     */ import ij.ImagePlus;
/*     */ import ij.Macro;
/*     */ import ij.WindowManager;
/*     */ import java.awt.Component;
/*     */ import java.io.File;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.text.ParseException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javax.swing.JFrame;
/*     */ import net.imglib2.util.ValuePair;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TrackMateRunner
/*     */   extends TrackMatePlugIn
/*     */ {
/*     */   private static final String ARG_RADIUS = "radius";
/*     */   private static final String ARG_THRESHOLD = "threshold";
/*     */   private static final String ARG_SUBPIXEL = "subpixel";
/*     */   private static final String ARG_MEDIAN = "median";
/*     */   private static final String ARG_CHANNEL = "channel";
/*     */   private static final String ARG_MAX_DISTANCE = "max_distance";
/*     */   private static final String ARG_MAX_GAP_DISTANCE = "max_gap_distance";
/*     */   private static final String ARG_MAX_GAP_FRAMES = "max_frame_gap";
/*     */   private static final String ARG_USE_GUI = "use_gui";
/*     */   private static final String ARG_INPUT_IMAGE_ID = "image_id";
/*     */   private static final String ARG_INPUT_IMAGE_NAME = "image_name";
/*     */   private static final String ARG_INPUT_IMAGE_PATH = "image_path";
/*     */   private static final String ARG_SAVE_TO = "save_to";
/*     */   private static final String ARG_EXPORT_TO = "export_to";
/*     */   private static final String ARG_DISPLAY_RESULTS = "display_results";
/*     */   private static final String ARG_FILTER_TRACKS_NSPOTS_ABOVE = "filter_tracks_nspots_above";
/* 177 */   private static final Collection<String> SUPPORTED_ARGS = new ArrayList<>();
/*     */ 
/*     */   
/*     */   static {
/* 181 */     SUPPORTED_ARGS.add("channel");
/* 182 */     SUPPORTED_ARGS.add("display_results");
/* 183 */     SUPPORTED_ARGS.add("export_to");
/* 184 */     SUPPORTED_ARGS.add("image_id");
/* 185 */     SUPPORTED_ARGS.add("image_name");
/* 186 */     SUPPORTED_ARGS.add("image_path");
/* 187 */     SUPPORTED_ARGS.add("max_distance");
/* 188 */     SUPPORTED_ARGS.add("max_gap_distance");
/* 189 */     SUPPORTED_ARGS.add("max_frame_gap");
/* 190 */     SUPPORTED_ARGS.add("median");
/* 191 */     SUPPORTED_ARGS.add("save_to");
/* 192 */     SUPPORTED_ARGS.add("subpixel");
/* 193 */     SUPPORTED_ARGS.add("threshold");
/* 194 */     SUPPORTED_ARGS.add("use_gui");
/* 195 */     SUPPORTED_ARGS.add("radius");
/* 196 */     SUPPORTED_ARGS.add("filter_tracks_nspots_above");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 203 */   private Logger logger = (Logger)new LogRecorder(Logger.DEFAULT_LOGGER);
/*     */ 
/*     */ 
/*     */   
/*     */   public void run(String arg) {
/* 208 */     GuiUtils.setSystemLookAndFeel();
/* 209 */     this.logger = (Logger)new LogRecorder(Logger.IJ_LOGGER);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 216 */     if (null == arg || arg.isEmpty()) {
/*     */       
/* 218 */       String macroOption = Macro.getOptions();
/* 219 */       if (null != macroOption) {
/* 220 */         arg = macroOption;
/*     */       }
/*     */     } 
/* 223 */     if (null != arg && !arg.isEmpty()) {
/*     */       try {
/*     */         ImagePlus imp;
/*     */ 
/*     */         
/* 228 */         Map<String, String> macroOptions = SplitString.splitMacroOptions(arg);
/*     */ 
/*     */         
/* 231 */         Set<String> unknownParameters = new HashSet<>(macroOptions.keySet());
/* 232 */         unknownParameters.removeAll(SUPPORTED_ARGS);
/* 233 */         if (!unknownParameters.isEmpty()) {
/*     */           
/* 235 */           this.logger.error("The following parameters are unkown and were ignored:\n");
/* 236 */           for (String unknownParameter : unknownParameters) {
/* 237 */             this.logger.error("  " + unknownParameter);
/*     */           }
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 245 */         if (macroOptions.containsKey("image_id")) {
/*     */           
/* 247 */           String val = macroOptions.get("image_id");
/*     */           
/*     */           try {
/* 250 */             int id = Integer.parseInt(val);
/* 251 */             imp = WindowManager.getImage(id);
/* 252 */             if (null == imp) {
/*     */               
/* 254 */               this.logger.error("There is not an opened image with ID " + id + ".\n");
/*     */               
/*     */               return;
/*     */             } 
/* 258 */           } catch (NumberFormatException nfe) {
/*     */             
/* 260 */             this.logger.error("Could not parse the image ID set by the image_id paramter. Got " + val + ", expected an integer.\n");
/*     */ 
/*     */ 
/*     */             
/*     */             return;
/*     */           } 
/* 266 */         } else if (macroOptions.containsKey("image_name")) {
/*     */           
/* 268 */           String imageName = macroOptions.get("image_name");
/* 269 */           imp = WindowManager.getImage(imageName);
/* 270 */           if (null == imp) {
/*     */             
/* 272 */             this.logger.error("There is not an opened image with name " + imageName + ".\n");
/*     */             
/*     */             return;
/*     */           } 
/* 276 */         } else if (macroOptions.containsKey("image_path")) {
/*     */           
/* 278 */           String imagePath = macroOptions.get("image_path");
/* 279 */           imp = new ImagePlus(imagePath);
/* 280 */           if (null == imp.getOriginalFileInfo()) {
/*     */             
/* 282 */             this.logger.error("Could not load image with path " + imagePath + ".\n");
/*     */ 
/*     */             
/*     */             return;
/*     */           } 
/*     */         } else {
/* 288 */           imp = WindowManager.getCurrentImage();
/* 289 */           if (null == imp) {
/*     */             
/* 291 */             this.logger.error("Please open an image before running TrackMate.");
/*     */ 
/*     */ 
/*     */             
/*     */             return;
/*     */           } 
/*     */         } 
/*     */ 
/*     */         
/* 300 */         Settings settings = createSettings(imp);
/* 301 */         Model model = createModel(imp);
/* 302 */         SelectionModel selectionModel = new SelectionModel(model);
/* 303 */         model.setLogger(this.logger);
/* 304 */         TrackMate trackmate = createTrackMate(model, settings);
/* 305 */         DisplaySettings displaySettings = createDisplaySettings();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 311 */         Map<String, ValuePair<String, MacroArgumentConverter>> detectorParsers = prepareDetectorParsableArguments();
/* 312 */         Map<String, ValuePair<String, MacroArgumentConverter>> trackerParsers = prepareTrackerParsableArguments();
/* 313 */         Map<String, FilterGenerator> trackFiltersParsers = prepareTrackFiltersParsableArguments();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 319 */         for (String parameter : macroOptions.keySet()) {
/*     */           
/* 321 */           String value = macroOptions.get(parameter);
/* 322 */           ValuePair<String, MacroArgumentConverter> parser = detectorParsers.get(parameter);
/* 323 */           if (parser == null) {
/*     */             continue;
/*     */           }
/* 326 */           String key = (String)parser.getA();
/* 327 */           MacroArgumentConverter converter = (MacroArgumentConverter)parser.getB();
/*     */           
/*     */           try {
/* 330 */             Object val = converter.convert(value);
/* 331 */             settings.detectorSettings.put(key, val);
/*     */           }
/* 333 */           catch (NumberFormatException nfe) {
/*     */             
/* 335 */             this.logger.error("Cannot interprete value for parameter " + parameter + ": " + value + ". Skipping.\n");
/*     */           } 
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 344 */         for (String parameter : macroOptions.keySet()) {
/*     */           
/* 346 */           String value = macroOptions.get(parameter);
/* 347 */           ValuePair<String, MacroArgumentConverter> parser = trackerParsers.get(parameter);
/* 348 */           if (parser == null) {
/*     */             continue;
/*     */           }
/* 351 */           String key = (String)parser.getA();
/* 352 */           MacroArgumentConverter converter = (MacroArgumentConverter)parser.getB();
/*     */           
/*     */           try {
/* 355 */             Object val = converter.convert(value);
/* 356 */             settings.trackerSettings.put(key, val);
/*     */           }
/* 358 */           catch (NumberFormatException nfe) {
/*     */             
/* 360 */             this.logger.error("Cannot interprete value for parameter " + parameter + ": " + value + ". Skipping.\n");
/*     */           } 
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 370 */         for (String parameter : macroOptions.keySet()) {
/*     */           
/* 372 */           String value = macroOptions.get(parameter);
/* 373 */           FilterGenerator converter = trackFiltersParsers.get(parameter);
/* 374 */           if (converter == null) {
/*     */             continue;
/*     */           }
/*     */           
/*     */           try {
/* 379 */             FeatureFilter featureFilter = converter.get(value);
/* 380 */             settings.addTrackFilter(featureFilter);
/*     */           }
/* 382 */           catch (NumberFormatException nfe) {
/*     */             
/* 384 */             this.logger.error("Cannot interprete value for parameter " + parameter + ": " + value + ". Skipping.\n");
/*     */           } 
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 394 */         if (macroOptions.containsKey("use_gui") && ((String)macroOptions.get("use_gui")).equalsIgnoreCase("true")) {
/*     */ 
/*     */           
/* 397 */           if (!imp.isVisible()) {
/*     */             
/* 399 */             imp.setOpenAsHyperStack(true);
/* 400 */             imp.show();
/*     */           } 
/* 402 */           GuiUtils.userCheckImpDimensions(imp);
/*     */           
/* 404 */           HyperStackDisplayer hyperStackDisplayer = new HyperStackDisplayer(model, selectionModel, imp, displaySettings);
/* 405 */           hyperStackDisplayer.render();
/*     */ 
/*     */           
/* 408 */           WizardSequence sequence = createSequence(trackmate, selectionModel, displaySettings);
/* 409 */           JFrame frame = sequence.run("TrackMate on " + imp.getShortTitle());
/* 410 */           frame.setIconImage(Icons.TRACKMATE_ICON.getImage());
/* 411 */           GuiUtils.positionWindow(frame, (Component)imp.getWindow());
/* 412 */           frame.setVisible(true);
/*     */           
/*     */           return;
/*     */         } 
/* 416 */         String welcomeMessage = "TrackMate v" + TrackMate.PLUGIN_NAME_VERSION + " started on:\n" + TMUtils.getCurrentTimeString() + '\n';
/* 417 */         this.logger.log(welcomeMessage);
/* 418 */         if (!trackmate.checkInput() || !trackmate.process()) {
/*     */           
/* 420 */           this.logger.error("Error while performing tracking:\n" + trackmate.getErrorMessage());
/*     */ 
/*     */ 
/*     */           
/*     */           return;
/*     */         } 
/*     */ 
/*     */         
/* 428 */         if (macroOptions.containsKey("save_to")) {
/*     */           
/* 430 */           String save_path_str = macroOptions.get("save_to");
/* 431 */           File save_path = new File(save_path_str);
/* 432 */           TmXmlWriter writer = new TmXmlWriter(save_path, this.logger);
/*     */           
/* 434 */           writer.appendLog(this.logger.toString());
/* 435 */           writer.appendModel(trackmate.getModel());
/* 436 */           writer.appendSettings(trackmate.getSettings());
/*     */ 
/*     */           
/*     */           try {
/* 440 */             writer.writeToFile();
/* 441 */             this.logger.log("Data saved to: " + save_path.toString() + '\n');
/*     */           }
/* 443 */           catch (FileNotFoundException e) {
/*     */             
/* 445 */             this.logger.error("When saving to " + save_path + ", file not found:\n" + e.getMessage() + '\n');
/*     */             
/*     */             return;
/* 448 */           } catch (IOException e) {
/*     */             
/* 450 */             this.logger.error("When saving to " + save_path + ", Input/Output error:\n" + e.getMessage() + '\n');
/*     */ 
/*     */ 
/*     */             
/*     */             return;
/*     */           } 
/*     */         } 
/*     */ 
/*     */ 
/*     */         
/* 460 */         if (macroOptions.containsKey("export_to")) {
/*     */           
/* 462 */           String export_path_str = macroOptions.get("export_to");
/* 463 */           File export_path = new File(export_path_str);
/*     */ 
/*     */           
/*     */           try {
/* 467 */             ExportTracksToXML.export(model, settings, export_path);
/* 468 */             this.logger.log("Data exported to: " + export_path.toString() + '\n');
/*     */           }
/* 470 */           catch (FileNotFoundException e) {
/*     */             
/* 472 */             this.logger.error("When exporting to " + export_path + ", file not found:\n" + e.getMessage() + '\n');
/*     */             
/*     */             return;
/* 475 */           } catch (IOException e) {
/*     */             
/* 477 */             this.logger.error("When exporting to " + export_path + ", Input/Output error:\n" + e.getMessage() + '\n');
/*     */ 
/*     */ 
/*     */ 
/*     */             
/*     */             return;
/*     */           } 
/*     */         } 
/*     */ 
/*     */ 
/*     */         
/* 488 */         if (macroOptions.containsKey("display_results") && ((String)macroOptions.get("display_results")).equalsIgnoreCase("true"))
/*     */         {
/*     */           
/* 491 */           if (!settings.imp.isVisible()) {
/*     */             
/* 493 */             settings.imp.setOpenAsHyperStack(true);
/* 494 */             settings.imp.show();
/*     */           } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 502 */           HyperStackDisplayer hyperStackDisplayer = new HyperStackDisplayer(model, selectionModel, imp, displaySettings);
/* 503 */           hyperStackDisplayer.render();
/*     */ 
/*     */           
/* 506 */           WizardSequence sequence = createSequence(trackmate, selectionModel, displaySettings);
/* 507 */           sequence.setCurrent("ConfigureViews");
/* 508 */           JFrame frame = sequence.run("TrackMate on " + imp.getShortTitle());
/* 509 */           frame.setIconImage(Icons.TRACKMATE_ICON.getImage());
/* 510 */           GuiUtils.positionWindow(frame, (Component)imp.getWindow());
/* 511 */           frame.setVisible(true);
/*     */ 
/*     */           
/* 514 */           LogPanelDescriptor2 logDescriptor = (LogPanelDescriptor2)sequence.logDescriptor();
/* 515 */           LogPanel logPanel = (LogPanel)logDescriptor.getPanelComponent();
/* 516 */           logPanel.setTextContent(this.logger.toString());
/*     */         }
/*     */       
/* 519 */       } catch (ParseException e) {
/*     */         
/* 521 */         this.logger.error("Could not parse plugin option string: " + e.getMessage() + ".\n");
/* 522 */         e.printStackTrace();
/*     */       
/*     */       }
/*     */ 
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 530 */       super.run(arg);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Map<String, ValuePair<String, MacroArgumentConverter>> prepareDetectorParsableArguments() {
/* 543 */     Map<String, ValuePair<String, MacroArgumentConverter>> parsers = new HashMap<>();
/*     */ 
/*     */     
/* 546 */     DoubleMacroArgumentConverter doubleConverter = new DoubleMacroArgumentConverter();
/* 547 */     IntegerMacroArgumentConverter integerConverter = new IntegerMacroArgumentConverter();
/* 548 */     BooleanMacroArgumentConverter booleanConverter = new BooleanMacroArgumentConverter();
/*     */ 
/*     */     
/* 551 */     ValuePair<String, MacroArgumentConverter> radiusPair = new ValuePair("RADIUS", doubleConverter);
/*     */     
/* 553 */     parsers.put("radius", radiusPair);
/*     */ 
/*     */     
/* 556 */     ValuePair<String, MacroArgumentConverter> thresholdPair = new ValuePair("THRESHOLD", doubleConverter);
/*     */     
/* 558 */     parsers.put("threshold", thresholdPair);
/*     */ 
/*     */     
/* 561 */     ValuePair<String, MacroArgumentConverter> subpixelPair = new ValuePair("DO_SUBPIXEL_LOCALIZATION", booleanConverter);
/*     */     
/* 563 */     parsers.put("subpixel", subpixelPair);
/*     */ 
/*     */     
/* 566 */     ValuePair<String, MacroArgumentConverter> medianPair = new ValuePair("DO_MEDIAN_FILTERING", booleanConverter);
/*     */     
/* 568 */     parsers.put("median", medianPair);
/*     */ 
/*     */     
/* 571 */     ValuePair<String, MacroArgumentConverter> channelPair = new ValuePair("TARGET_CHANNEL", integerConverter);
/*     */     
/* 573 */     parsers.put("channel", channelPair);
/*     */     
/* 575 */     return parsers;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Map<String, ValuePair<String, MacroArgumentConverter>> prepareTrackerParsableArguments() {
/* 587 */     Map<String, ValuePair<String, MacroArgumentConverter>> parsers = new HashMap<>();
/*     */ 
/*     */     
/* 590 */     DoubleMacroArgumentConverter doubleConverter = new DoubleMacroArgumentConverter();
/* 591 */     IntegerMacroArgumentConverter integerConverter = new IntegerMacroArgumentConverter();
/*     */ 
/*     */     
/* 594 */     ValuePair<String, MacroArgumentConverter> maxDistancePair = new ValuePair("LINKING_MAX_DISTANCE", doubleConverter);
/*     */     
/* 596 */     parsers.put("max_distance", maxDistancePair);
/*     */ 
/*     */     
/* 599 */     ValuePair<String, MacroArgumentConverter> maxGapDistancePair = new ValuePair("GAP_CLOSING_MAX_DISTANCE", doubleConverter);
/*     */     
/* 601 */     parsers.put("max_gap_distance", maxGapDistancePair);
/*     */ 
/*     */     
/* 604 */     ValuePair<String, MacroArgumentConverter> maxGapFramesPair = new ValuePair("MAX_FRAME_GAP", integerConverter);
/*     */     
/* 606 */     parsers.put("max_frame_gap", maxGapFramesPair);
/*     */     
/* 608 */     return parsers;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private Map<String, FilterGenerator> prepareTrackFiltersParsableArguments() {
/* 614 */     Map<String, FilterGenerator> parsers = new HashMap<>();
/*     */ 
/*     */     
/* 617 */     FilterGenerator nSpotsFilter = new FilterAboveGenerator("NUMBER_SPOTS");
/*     */     
/* 619 */     parsers.put("filter_tracks_nspots_above", nSpotsFilter);
/* 620 */     return parsers;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static interface FilterGenerator
/*     */   {
/*     */     FeatureFilter get(String param1String) throws NumberFormatException;
/*     */   }
/*     */ 
/*     */   
/*     */   private static class FilterAboveGenerator
/*     */     implements FilterGenerator
/*     */   {
/*     */     private final String feature;
/*     */ 
/*     */     
/*     */     public FilterAboveGenerator(String feature) {
/* 638 */       this.feature = feature;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public FeatureFilter get(String valStr) throws NumberFormatException {
/* 644 */       double value = Double.parseDouble(valStr);
/* 645 */       FeatureFilter ff = new FeatureFilter(this.feature, value, true);
/* 646 */       return ff;
/*     */     }
/*     */   }
/*     */   
/*     */   private static interface MacroArgumentConverter
/*     */   {
/*     */     Object convert(String param1String) throws NumberFormatException;
/*     */   }
/*     */   
/*     */   private static final class DoubleMacroArgumentConverter
/*     */     implements MacroArgumentConverter {
/*     */     private DoubleMacroArgumentConverter() {}
/*     */     
/*     */     public Object convert(String valStr) throws NumberFormatException {
/* 660 */       return Double.valueOf(valStr);
/*     */     }
/*     */   }
/*     */   
/*     */   private static final class IntegerMacroArgumentConverter
/*     */     implements MacroArgumentConverter {
/*     */     private IntegerMacroArgumentConverter() {}
/*     */     
/*     */     public Object convert(String valStr) throws NumberFormatException {
/* 669 */       return Integer.valueOf(valStr);
/*     */     }
/*     */   }
/*     */   
/*     */   private static final class BooleanMacroArgumentConverter
/*     */     implements MacroArgumentConverter {
/*     */     private BooleanMacroArgumentConverter() {}
/*     */     
/*     */     public Object convert(String valStr) throws NumberFormatException {
/* 678 */       return Boolean.valueOf(valStr);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void main(String[] args) {
/* 688 */     ImageJ.main(args);
/* 689 */     (new TrackMateRunner()).run("use_gui=false save_to=[/Users/tinevez/Desktop/TrackMateSaveTest.xml] export_to=[/Users/tinevez/Desktop/TrackMateExportTest.xml] image_path=[samples/FakeTracks.tif] display_results=true radius=2.5 threshold=50.1 subpixel=false median=false channel=1 max_frame_gap=0 paf!=pif!");
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/TrackMateRunner.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */