/*    */ package fiji.plugin.trackmate.gui;
/*    */ 
/*    */ import java.awt.Dimension;
/*    */ import java.awt.Font;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Fonts
/*    */ {
/* 29 */   public static final Font FONT = new Font("Arial", 0, 10);
/*    */   
/* 31 */   public static final Font BIG_FONT = new Font("Arial", 0, 14);
/*    */   
/* 33 */   public static final Font SMALL_FONT = FONT.deriveFont(8);
/*    */   
/* 35 */   public static final Font SMALL_FONT_MONOSPACED = new Font("Courier New", 0, 11);
/*    */   
/* 37 */   public static final Dimension TEXTFIELD_DIMENSION = new Dimension(40, 18);
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/gui/Fonts.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */