/*     */ package fiji.plugin.trackmate.features.spot;
/*     */ 
/*     */ import fiji.plugin.trackmate.SpotRoi;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ConvexHull
/*     */ {
/*     */   private static List<Point> makeHull(List<Point> points) {
/*  39 */     List<Point> newPoints = new ArrayList<>(points);
/*  40 */     Collections.sort(newPoints);
/*  41 */     return makeHullPresorted(newPoints);
/*     */   }
/*     */ 
/*     */   
/*     */   private static List<Point> makeHullPresorted(List<Point> points) {
/*  46 */     if (points.size() <= 1) {
/*  47 */       return new ArrayList<>(points);
/*     */     }
/*  49 */     List<Point> upperHull = new ArrayList<>();
/*  50 */     for (Point p : points) {
/*     */       
/*  52 */       while (upperHull.size() >= 2) {
/*     */         
/*  54 */         Point q = upperHull.get(upperHull.size() - 1);
/*  55 */         Point r = upperHull.get(upperHull.size() - 2);
/*  56 */         if ((q.x - r.x) * (p.y - r.y) >= (q.y - r.y) * (p.x - r.x)) {
/*  57 */           upperHull.remove(upperHull.size() - 1);
/*     */         }
/*     */       } 
/*     */       
/*  61 */       upperHull.add(p);
/*     */     } 
/*  63 */     upperHull.remove(upperHull.size() - 1);
/*     */     
/*  65 */     List<Point> lowerHull = new ArrayList<>();
/*  66 */     for (int i = points.size() - 1; i >= 0; i--) {
/*     */       
/*  68 */       Point p = points.get(i);
/*  69 */       while (lowerHull.size() >= 2) {
/*     */         
/*  71 */         Point q = lowerHull.get(lowerHull.size() - 1);
/*  72 */         Point r = lowerHull.get(lowerHull.size() - 2);
/*  73 */         if ((q.x - r.x) * (p.y - r.y) >= (q.y - r.y) * (p.x - r.x)) {
/*  74 */           lowerHull.remove(lowerHull.size() - 1);
/*     */         }
/*     */       } 
/*     */       
/*  78 */       lowerHull.add(p);
/*     */     } 
/*  80 */     lowerHull.remove(lowerHull.size() - 1);
/*     */     
/*  82 */     if (upperHull.size() != 1 || !upperHull.equals(lowerHull))
/*  83 */       upperHull.addAll(lowerHull); 
/*  84 */     return upperHull;
/*     */   }
/*     */ 
/*     */   
/*     */   private static final class Point
/*     */     implements Comparable<Point>
/*     */   {
/*     */     public final double x;
/*     */     
/*     */     public final double y;
/*     */     
/*     */     public Point(double x, double y) {
/*  96 */       this.x = x;
/*  97 */       this.y = y;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean equals(Object obj) {
/* 103 */       if (!(obj instanceof Point)) {
/* 104 */         return false;
/*     */       }
/*     */       
/* 107 */       Point other = (Point)obj;
/* 108 */       return (this.x == other.x && this.y == other.y);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public int compareTo(Point other) {
/* 114 */       if (this.x != other.x) {
/* 115 */         return Double.compare(this.x, other.x);
/*     */       }
/* 117 */       return Double.compare(this.y, other.y);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static SpotRoi convexHull(SpotRoi roi) {
/* 123 */     List<Point> points = new ArrayList<>(roi.x.length);
/* 124 */     for (int i = 0; i < roi.x.length; i++) {
/* 125 */       points.add(new Point(roi.x[i], roi.y[i]));
/*     */     }
/* 127 */     List<Point> hull = makeHull(points);
/* 128 */     double[] xhull = new double[hull.size()];
/* 129 */     double[] yhull = new double[hull.size()];
/* 130 */     for (int j = 0; j < yhull.length; j++) {
/*     */       
/* 132 */       xhull[j] = ((Point)hull.get(j)).x;
/* 133 */       yhull[j] = ((Point)hull.get(j)).y;
/*     */     } 
/* 135 */     return new SpotRoi(xhull, yhull);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/features/spot/ConvexHull.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */