/*    */ package fiji.plugin.trackmate.features;
/*    */ 
/*    */ import fiji.plugin.trackmate.Dimension;
/*    */ import fiji.plugin.trackmate.Model;
/*    */ import fiji.plugin.trackmate.SelectionModel;
/*    */ import fiji.plugin.trackmate.gui.displaysettings.DisplaySettings;
/*    */ import java.util.List;
/*    */ import org.jgrapht.graph.DefaultWeightedEdge;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EdgeFeatureGrapher
/*    */   extends AbstractFeatureGrapher
/*    */ {
/*    */   private final List<DefaultWeightedEdge> edges;
/*    */   private final Model model;
/*    */   private final SelectionModel selectionModel;
/*    */   private final DisplaySettings ds;
/*    */   private final boolean addLines;
/*    */   
/*    */   public EdgeFeatureGrapher(List<DefaultWeightedEdge> edges, String xFeature, List<String> yFeatures, Model model, SelectionModel selectionModel, DisplaySettings displaySettings, boolean addLines) {
/* 54 */     super(xFeature, yFeatures, (Dimension)model
/*    */ 
/*    */         
/* 57 */         .getFeatureModel().getEdgeFeatureDimensions().get(xFeature), model
/* 58 */         .getFeatureModel().getEdgeFeatureDimensions(), model
/* 59 */         .getFeatureModel().getEdgeFeatureNames(), model
/* 60 */         .getSpaceUnits(), model
/* 61 */         .getTimeUnits());
/* 62 */     this.edges = edges;
/* 63 */     this.model = model;
/* 64 */     this.selectionModel = selectionModel;
/* 65 */     this.ds = displaySettings;
/* 66 */     this.addLines = addLines;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected ModelDataset buildMainDataSet(List<String> targetYFeatures) {
/* 72 */     return new EdgeCollectionDataset(this.model, this.selectionModel, this.ds, this.xFeature, targetYFeatures, this.edges, this.addLines);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/features/EdgeFeatureGrapher.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */