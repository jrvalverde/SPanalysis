package fiji.plugin.trackmate.tracking;

import fiji.plugin.trackmate.Logger;
import fiji.plugin.trackmate.Spot;
import net.imglib2.algorithm.MultiThreaded;
import net.imglib2.algorithm.OutputAlgorithm;
import org.jgrapht.graph.DefaultWeightedEdge;
import org.jgrapht.graph.SimpleWeightedGraph;

public interface SpotTracker extends OutputAlgorithm<SimpleWeightedGraph<Spot, DefaultWeightedEdge>>, MultiThreaded {
  void setLogger(Logger paramLogger);
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/tracking/SpotTracker.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */