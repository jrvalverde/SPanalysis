/*     */ package fiji.plugin.trackmate.tracking.sparselap.costmatrix;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ResizableDoubleArray
/*     */ {
/*     */   public double[] data;
/*     */   public int size;
/*     */   
/*     */   public ResizableDoubleArray(double[] data) {
/*  44 */     this.data = data;
/*  45 */     this.size = data.length;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ResizableDoubleArray(int initialCapacity) {
/*  51 */     this.data = new double[initialCapacity];
/*  52 */     this.size = 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResizableDoubleArray() {
/*  60 */     this(10);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void trimToSize() {
/*  69 */     int oldCapacity = this.data.length;
/*  70 */     if (this.size < oldCapacity)
/*     */     {
/*  72 */       this.data = Arrays.copyOf(this.data, this.size);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void ensureCapacity(int minCapacity) {
/*  78 */     int oldCapacity = this.data.length;
/*  79 */     if (minCapacity > oldCapacity) {
/*     */ 
/*     */       
/*  82 */       int newCapacity = oldCapacity * 3 / 2 + 1;
/*  83 */       if (newCapacity < minCapacity)
/*     */       {
/*  85 */         newCapacity = minCapacity;
/*     */       }
/*  87 */       this.data = Arrays.copyOf(this.data, newCapacity);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/*  98 */     return (this.size == 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public void add(double val) {
/* 103 */     ensureCapacity(this.size + 1);
/* 104 */     this.data[this.size] = val;
/* 105 */     this.size++;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 111 */     if (isEmpty()) return "()"; 
/* 112 */     StringBuilder str = new StringBuilder();
/* 113 */     str.append('(');
/* 114 */     for (int i = 0; i < this.size - 1; i++)
/*     */     {
/* 116 */       str.append(this.data[i] + ", ");
/*     */     }
/* 118 */     str.append(this.data[this.size - 1] + "), size = " + this.size);
/* 119 */     return str.toString();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/tracking/sparselap/costmatrix/ResizableDoubleArray.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */