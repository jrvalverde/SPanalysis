/*     */ package fiji.plugin.trackmate.gui.displaysettings;
/*     */ 
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.event.ComponentAdapter;
/*     */ import java.awt.event.ComponentEvent;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JSlider;
/*     */ import javax.swing.JSpinner;
/*     */ import javax.swing.SpinnerNumberModel;
/*     */ import javax.swing.event.ChangeEvent;
/*     */ import javax.swing.event.ChangeListener;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SliderPanelDouble
/*     */   extends JPanel
/*     */   implements BoundedValueDouble.UpdateListener
/*     */ {
/*     */   private static final long serialVersionUID = 6444334522127424416L;
/*     */   private static final int sliderLength = 50;
/*     */   private final JSlider slider;
/*     */   private final JSpinner spinner;
/*     */   private final BoundedValueDouble model;
/*     */   private double dmin;
/*     */   private double dmax;
/*     */   private boolean userDefinedNumberFormat = false;
/*     */   private RangeListener rangeListener;
/*     */   
/*     */   public SliderPanelDouble(String name, final BoundedValueDouble model, double spinnerStepSize) {
/*  83 */     setLayout(new BorderLayout(10, 10));
/*  84 */     setPreferredSize(SliderPanel.PANEL_SIZE);
/*     */     
/*  86 */     this.dmin = model.getRangeMin();
/*  87 */     this.dmax = model.getRangeMax();
/*     */     
/*  89 */     this.slider = new JSlider(0, 0, 50, toSlider(model.getCurrentValue()));
/*  90 */     this.spinner = new JSpinner();
/*  91 */     this.spinner.setModel(new SpinnerNumberModel(model.getCurrentValue(), this.dmin, this.dmax, spinnerStepSize));
/*     */     
/*  93 */     this.slider.addChangeListener(new ChangeListener()
/*     */         {
/*     */           
/*     */           public void stateChanged(ChangeEvent e)
/*     */           {
/*  98 */             int value = SliderPanelDouble.this.slider.getValue();
/*  99 */             model.setCurrentValue(SliderPanelDouble.this.fromSlider(value));
/*     */           }
/*     */         });
/*     */     
/* 103 */     this.slider.addComponentListener(new ComponentAdapter()
/*     */         {
/*     */           
/*     */           public void componentResized(ComponentEvent e)
/*     */           {
/* 108 */             SliderPanelDouble.this.updateNumberFormat();
/*     */           }
/*     */         });
/*     */     
/* 112 */     this.spinner.addChangeListener(new ChangeListener()
/*     */         {
/*     */           
/*     */           public void stateChanged(ChangeEvent e)
/*     */           {
/* 117 */             double value = ((Double)SliderPanelDouble.this.spinner.getValue()).doubleValue();
/* 118 */             model.setCurrentValue(value);
/*     */           }
/*     */         });
/*     */     
/* 122 */     if (name != null) {
/*     */       
/* 124 */       JLabel label = new JLabel(name, 0);
/* 125 */       label.setAlignmentX(0.5F);
/* 126 */       add(label, "West");
/*     */     } 
/*     */     
/* 129 */     add(this.slider, "Center");
/* 130 */     add(this.spinner, "East");
/*     */     
/* 132 */     this.model = model;
/* 133 */     model.setUpdateListener(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setDecimalFormat(String pattern) {
/* 138 */     if (pattern == null) {
/*     */       
/* 140 */       this.userDefinedNumberFormat = false;
/* 141 */       updateNumberFormat();
/*     */     }
/*     */     else {
/*     */       
/* 145 */       this.userDefinedNumberFormat = true;
/* 146 */       ((JSpinner.NumberEditor)this.spinner.getEditor()).getFormat().applyPattern(pattern);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void setNumColummns(int cols) {
/* 152 */     ((JSpinner.NumberEditor)this.spinner.getEditor()).getTextField().setColumns(cols);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void update() {
/* 158 */     double value = this.model.getCurrentValue();
/* 159 */     double min = this.model.getRangeMin();
/* 160 */     double max = this.model.getRangeMax();
/*     */     
/* 162 */     boolean rangeChanged = (this.dmax != max || this.dmin != min);
/* 163 */     if (rangeChanged) {
/*     */       
/* 165 */       this.dmin = min;
/* 166 */       this.dmax = max;
/* 167 */       SpinnerNumberModel spinnerModel = (SpinnerNumberModel)this.spinner.getModel();
/* 168 */       spinnerModel.setMinimum(Double.valueOf(min));
/* 169 */       spinnerModel.setMaximum(Double.valueOf(max));
/*     */     } 
/* 171 */     this.slider.setValue(toSlider(value));
/* 172 */     this.spinner.setValue(Double.valueOf(value));
/*     */     
/* 174 */     if (rangeChanged) {
/* 175 */       updateNumberFormat();
/*     */     }
/* 177 */     if (rangeChanged && this.rangeListener != null) {
/* 178 */       this.rangeListener.rangeChanged();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void setRangeListener(RangeListener listener) {
/* 184 */     this.rangeListener = listener;
/*     */   }
/*     */ 
/*     */   
/*     */   private void updateNumberFormat() {
/* 189 */     if (this.userDefinedNumberFormat) {
/*     */       return;
/*     */     }
/* 192 */     int sw = this.slider.getWidth();
/* 193 */     if (sw > 0) {
/*     */       
/* 195 */       double range = this.dmax - this.dmin;
/* 196 */       int digits = (int)Math.ceil(Math.log10(sw / range));
/* 197 */       JSpinner.NumberEditor numberEditor = (JSpinner.NumberEditor)this.spinner.getEditor();
/* 198 */       numberEditor.getFormat().setMaximumFractionDigits(digits);
/* 199 */       numberEditor.stateChanged(new ChangeEvent(this.spinner));
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private int toSlider(double value) {
/* 205 */     return (int)Math.round((value - this.dmin) * 50.0D / (this.dmax - this.dmin));
/*     */   }
/*     */ 
/*     */   
/*     */   private double fromSlider(int value) {
/* 210 */     return value * (this.dmax - this.dmin) / 50.0D + this.dmin;
/*     */   }
/*     */   
/*     */   public static interface RangeListener {
/*     */     void rangeChanged();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/gui/displaysettings/SliderPanelDouble.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */