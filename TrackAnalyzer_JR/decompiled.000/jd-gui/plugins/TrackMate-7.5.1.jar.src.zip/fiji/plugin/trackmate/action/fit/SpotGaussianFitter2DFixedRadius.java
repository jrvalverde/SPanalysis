/*     */ package fiji.plugin.trackmate.action.fit;
/*     */ 
/*     */ import fiji.plugin.trackmate.Logger;
/*     */ import fiji.plugin.trackmate.Spot;
/*     */ import fiji.plugin.trackmate.detection.DetectionUtils;
/*     */ import ij.ImagePlus;
/*     */ import net.imglib2.Point;
/*     */ import net.imglib2.util.Util;
/*     */ import org.apache.commons.math3.exception.TooManyEvaluationsException;
/*     */ import org.apache.commons.math3.fitting.leastsquares.LeastSquaresBuilder;
/*     */ import org.apache.commons.math3.fitting.leastsquares.LeastSquaresOptimizer;
/*     */ import org.apache.commons.math3.fitting.leastsquares.LeastSquaresProblem;
/*     */ import org.apache.commons.math3.fitting.leastsquares.MultivariateJacobianFunction;
/*     */ import org.apache.commons.math3.fitting.leastsquares.ParameterValidator;
/*     */ import org.apache.commons.math3.linear.Array2DRowRealMatrix;
/*     */ import org.apache.commons.math3.linear.ArrayRealVector;
/*     */ import org.apache.commons.math3.linear.RealMatrix;
/*     */ import org.apache.commons.math3.linear.RealVector;
/*     */ import org.apache.commons.math3.util.Pair;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SpotGaussianFitter2DFixedRadius
/*     */   extends AbstractSpotFitter
/*     */ {
/*     */   public SpotGaussianFitter2DFixedRadius(ImagePlus imp, int channel) {
/*  51 */     super(imp, channel);
/*  52 */     assert DetectionUtils.is2D(imp);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void process(Iterable<Spot> spots, Logger logger) {
/*  58 */     super.process(spots, logger);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void fit(Spot spot) {
/*  64 */     int frame = spot.getFeature("FRAME").intValue();
/*  65 */     double sigma = spot.getFeature("RADIUS").doubleValue() / Math.sqrt(2.0D);
/*  66 */     double pixelSigma = sigma / this.calibration[0];
/*  67 */     double x0 = spot.getDoublePosition(0) / this.calibration[0];
/*  68 */     double y0 = spot.getDoublePosition(1) / this.calibration[1];
/*  69 */     long span = (long)Math.ceil(2.0D * pixelSigma) + 1L;
/*  70 */     AbstractSpotFitter.Observation obs = gatherObservationData(new Point(new long[] {
/*     */             
/*  72 */             Math.round(x0), 
/*  73 */             Math.round(y0) }, ), new long[] { span, span }, frame);
/*     */ 
/*     */     
/*  76 */     clipBackground(obs);
/*     */     
/*  78 */     double b = 1.0D / 2.0D * pixelSigma * pixelSigma;
/*  79 */     MyGaussian2D gauss = new MyGaussian2D(obs.pos, b);
/*  80 */     double ampstart = Util.max(obs.values);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  89 */     LeastSquaresProblem lsq = (new LeastSquaresBuilder()).start(new double[] { x0, y0, ampstart }).model(gauss).parameterValidator(gauss).target(obs.values).lazyEvaluation(false).maxEvaluations(1000).maxIterations(1000).build();
/*     */ 
/*     */     
/*     */     try {
/*  93 */       LeastSquaresOptimizer.Optimum optimum = this.optimizer.optimize(lsq);
/*  94 */       RealVector fit = optimum.getPoint();
/*     */       
/*  96 */       double fitX = fit.getEntry(0) * this.calibration[0];
/*  97 */       double fitY = fit.getEntry(1) * this.calibration[1];
/*  98 */       spot.putFeature("POSITION_X", Double.valueOf(fitX));
/*  99 */       spot.putFeature("POSITION_Y", Double.valueOf(fitY));
/*     */     }
/* 101 */     catch (TooManyEvaluationsException tooManyEvaluationsException) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class MyGaussian2D
/*     */     implements MultivariateJacobianFunction, ParameterValidator
/*     */   {
/*     */     private final long[][] pos;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final double b;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public MyGaussian2D(long[][] pos, double b) {
/* 123 */       this.pos = pos;
/* 124 */       this.b = b;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Pair<RealVector, RealMatrix> value(RealVector point) {
/* 131 */       double x0 = point.getEntry(0);
/* 132 */       double y0 = point.getEntry(1);
/* 133 */       double A = point.getEntry(2);
/*     */ 
/*     */       
/* 136 */       double[] vals = new double[(this.pos[0]).length];
/* 137 */       double[][] grad = new double[(this.pos[0]).length][3];
/* 138 */       for (int i = 0; i < vals.length; i++) {
/*     */         
/* 140 */         long x = this.pos[0][i];
/* 141 */         long y = this.pos[1][i];
/* 142 */         double dx = x - x0;
/* 143 */         double dy = y - y0;
/* 144 */         double sumSq = dx * dx + dy * dy;
/* 145 */         double E = Math.exp(-this.b * sumSq);
/* 146 */         vals[i] = A * E;
/*     */ 
/*     */         
/* 149 */         grad[i][0] = A * this.b * E * 2.0D * dx;
/*     */         
/* 151 */         grad[i][1] = A * this.b * E * 2.0D * dy;
/*     */         
/* 153 */         grad[i][2] = E;
/*     */       } 
/* 155 */       ArrayRealVector out = new ArrayRealVector(vals);
/* 156 */       Array2DRowRealMatrix jacobian = new Array2DRowRealMatrix(grad, false);
/* 157 */       return new Pair(out, jacobian);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public RealVector validate(RealVector params) {
/* 163 */       params.setEntry(2, Math.abs(params.getEntry(2)));
/* 164 */       return params;
/*     */     }
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/action/fit/SpotGaussianFitter2DFixedRadius.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */