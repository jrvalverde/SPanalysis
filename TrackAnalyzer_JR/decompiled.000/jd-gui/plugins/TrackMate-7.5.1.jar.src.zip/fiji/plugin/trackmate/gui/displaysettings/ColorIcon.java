/*    */ package fiji.plugin.trackmate.gui.displaysettings;
/*    */ 
/*    */ import java.awt.Color;
/*    */ import java.awt.Component;
/*    */ import java.awt.Graphics;
/*    */ import java.awt.Graphics2D;
/*    */ import java.awt.RenderingHints;
/*    */ import java.awt.geom.RoundRectangle2D;
/*    */ import javax.swing.Icon;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ColorIcon
/*    */   implements Icon
/*    */ {
/*    */   private static final int DEFAULT_PAD = 0;
/*    */   private static final int DEFAUL_SIZE = 16;
/*    */   private final int size;
/*    */   private Color color;
/*    */   private final int pad;
/*    */   
/*    */   public ColorIcon(Color color, int size, int pad) {
/* 50 */     this.color = color;
/* 51 */     this.size = size;
/* 52 */     this.pad = pad;
/*    */   }
/*    */ 
/*    */   
/*    */   public ColorIcon(Color color, int size) {
/* 57 */     this(color, size, 0);
/*    */   }
/*    */ 
/*    */   
/*    */   public ColorIcon(Color color) {
/* 62 */     this(color, 16);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void paintIcon(Component c, Graphics g, int x, int y) {
/* 68 */     Graphics2D g2d = (Graphics2D)g;
/* 69 */     g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
/* 70 */     g2d.setColor(this.color);
/* 71 */     RoundRectangle2D.Float shape = new RoundRectangle2D.Float((x + this.pad), (y + this.pad), this.size, this.size, 5.0F, 5.0F);
/* 72 */     g2d.fill(shape);
/* 73 */     g2d.setColor(Color.BLACK);
/* 74 */     g2d.draw(shape);
/*    */   }
/*    */ 
/*    */   
/*    */   public void setColor(Color color) {
/* 79 */     this.color = color;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public int getIconWidth() {
/* 85 */     return this.size + 2 * this.pad;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public int getIconHeight() {
/* 91 */     return this.size + 2 * this.pad;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/gui/displaysettings/ColorIcon.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */