/*     */ package fiji.plugin.trackmate.features;
/*     */ 
/*     */ import fiji.plugin.trackmate.Dimension;
/*     */ import fiji.plugin.trackmate.gui.Fonts;
/*     */ import fiji.plugin.trackmate.util.ExportableChartPanel;
/*     */ import fiji.plugin.trackmate.util.TMUtils;
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Dimension;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javax.swing.Box;
/*     */ import javax.swing.BoxLayout;
/*     */ import javax.swing.JFrame;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JScrollPane;
/*     */ import org.jfree.chart.ChartFactory;
/*     */ import org.jfree.chart.JFreeChart;
/*     */ import org.jfree.chart.axis.NumberAxis;
/*     */ import org.jfree.chart.plot.PlotOrientation;
/*     */ import org.jfree.chart.plot.XYPlot;
/*     */ import org.jfree.chart.renderer.xy.XYItemRenderer;
/*     */ import org.jfree.chart.ui.RectangleInsets;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractFeatureGrapher
/*     */ {
/*     */   protected final String xFeature;
/*     */   protected final List<String> yFeatures;
/*  61 */   private final Color bgColor = new Color(220, 220, 220);
/*     */ 
/*     */ 
/*     */   
/*     */   private final Dimension xDimension;
/*     */ 
/*     */   
/*     */   private final Map<String, Dimension> yDimensions;
/*     */ 
/*     */   
/*     */   private final Map<String, String> featureNames;
/*     */ 
/*     */   
/*     */   private final String spaceUnits;
/*     */ 
/*     */   
/*     */   private final String timeUnits;
/*     */ 
/*     */ 
/*     */   
/*     */   public AbstractFeatureGrapher(String xFeature, List<String> yFeatures, Dimension xDimension, Map<String, Dimension> yDimensions, Map<String, String> featureNames, String spaceUnits, String timeUnits) {
/*  82 */     this.xFeature = xFeature;
/*  83 */     this.yFeatures = yFeatures;
/*  84 */     this.xDimension = xDimension;
/*  85 */     this.yDimensions = yDimensions;
/*  86 */     this.featureNames = featureNames;
/*  87 */     this.spaceUnits = spaceUnits;
/*  88 */     this.timeUnits = timeUnits;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JFrame render() {
/*  99 */     String xAxisLabel = (String)this.featureNames.get(this.xFeature) + " (" + TMUtils.getUnitsFor(this.xDimension, this.spaceUnits, this.timeUnits) + ")";
/*     */ 
/*     */     
/* 102 */     Set<Dimension> dimensions = getUniqueValues(this.yFeatures, this.yDimensions);
/*     */ 
/*     */     
/* 105 */     ArrayList<ExportableChartPanel> chartPanels = new ArrayList<>(dimensions.size());
/* 106 */     for (Dimension dimension : dimensions) {
/*     */ 
/*     */ 
/*     */       
/* 110 */       String yAxisLabel = TMUtils.getUnitsFor(dimension, this.spaceUnits, this.timeUnits);
/*     */ 
/*     */       
/* 113 */       List<String> featuresThisDimension = getCommonKeys(dimension, this.yFeatures, this.yDimensions);
/*     */ 
/*     */       
/* 116 */       String title = buildPlotTitle(featuresThisDimension, this.featureNames);
/*     */ 
/*     */       
/* 119 */       ModelDataset dataset = buildMainDataSet(featuresThisDimension);
/* 120 */       XYItemRenderer renderer = dataset.getRenderer();
/*     */ 
/*     */       
/* 123 */       JFreeChart chart = ChartFactory.createXYLineChart(title, xAxisLabel, yAxisLabel, dataset, PlotOrientation.VERTICAL, true, true, false);
/* 124 */       chart.getTitle().setFont(Fonts.FONT);
/* 125 */       chart.getLegend().setItemFont(Fonts.SMALL_FONT);
/* 126 */       chart.setBackgroundPaint(this.bgColor);
/* 127 */       chart.setBorderVisible(false);
/* 128 */       chart.getLegend().setBackgroundPaint(this.bgColor);
/*     */ 
/*     */       
/* 131 */       XYPlot plot = chart.getXYPlot();
/* 132 */       plot.setRenderer(renderer);
/* 133 */       plot.getRangeAxis().setLabelFont(Fonts.FONT);
/* 134 */       plot.getRangeAxis().setTickLabelFont(Fonts.SMALL_FONT);
/* 135 */       plot.getDomainAxis().setLabelFont(Fonts.FONT);
/* 136 */       plot.getDomainAxis().setTickLabelFont(Fonts.SMALL_FONT);
/* 137 */       plot.setOutlineVisible(false);
/* 138 */       plot.setDomainCrosshairVisible(false);
/* 139 */       plot.setDomainGridlinesVisible(false);
/* 140 */       plot.setRangeCrosshairVisible(false);
/* 141 */       plot.setRangeGridlinesVisible(false);
/* 142 */       plot.setBackgroundAlpha(0.0F);
/*     */ 
/*     */       
/* 145 */       ((NumberAxis)plot.getRangeAxis()).setAutoRangeIncludesZero(false);
/*     */ 
/*     */       
/* 148 */       plot.getRangeAxis().setTickLabelInsets(new RectangleInsets(20.0D, 10.0D, 20.0D, 10.0D));
/* 149 */       plot.getDomainAxis().setTickLabelInsets(new RectangleInsets(10.0D, 20.0D, 10.0D, 20.0D));
/*     */ 
/*     */       
/* 152 */       ExportableChartPanel chartPanel = new ExportableChartPanel(chart);
/* 153 */       chartPanel.setPreferredSize(new Dimension(500, 270));
/* 154 */       chartPanels.add(chartPanel);
/*     */     } 
/*     */     
/* 157 */     return renderCharts(chartPanels);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract ModelDataset buildMainDataSet(List<String> paramList);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final JFrame renderCharts(List<ExportableChartPanel> chartPanels) {
/* 175 */     JPanel panel = new JPanel();
/* 176 */     BoxLayout panelLayout = new BoxLayout(panel, 1);
/* 177 */     panel.setLayout(panelLayout);
/* 178 */     for (ExportableChartPanel chartPanel : chartPanels) {
/*     */       
/* 180 */       panel.add((Component)chartPanel);
/* 181 */       panel.add(Box.createVerticalStrut(5));
/*     */     } 
/*     */ 
/*     */     
/* 185 */     JScrollPane scrollPane = new JScrollPane();
/* 186 */     scrollPane.setHorizontalScrollBarPolicy(31);
/* 187 */     scrollPane.setViewportView(panel);
/* 188 */     scrollPane.getVerticalScrollBar().setUnitIncrement(16);
/*     */ 
/*     */     
/* 191 */     JFrame frame = new JFrame();
/* 192 */     frame.getContentPane().add(scrollPane);
/* 193 */     frame.validate();
/* 194 */     frame.setSize(new Dimension(520, 320));
/* 195 */     return frame;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final <K, V> Set<V> getUniqueValues(Iterable<K> keys, Map<K, V> map) {
/* 206 */     Set<V> mapping = new LinkedHashSet<>();
/* 207 */     for (K key : keys) {
/* 208 */       mapping.add(map.get(key));
/*     */     }
/* 210 */     return mapping;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final <K, V> List<K> getCommonKeys(V targetValue, Iterable<K> keys, Map<K, V> map) {
/* 227 */     ArrayList<K> foundKeys = new ArrayList<>();
/* 228 */     for (K key : keys) {
/*     */       
/* 230 */       if (map.get(key).equals(targetValue))
/* 231 */         foundKeys.add(key); 
/*     */     } 
/* 233 */     return foundKeys;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final String buildPlotTitle(Iterable<String> lYFeatures, Map<String, String> featureNames) {
/* 243 */     StringBuilder sb = new StringBuilder("Plot of ");
/* 244 */     Iterator<String> it = lYFeatures.iterator();
/* 245 */     sb.append(featureNames.get(it.next()));
/* 246 */     while (it.hasNext()) {
/*     */       
/* 248 */       sb.append(", ");
/* 249 */       sb.append(featureNames.get(it.next()));
/*     */     } 
/* 251 */     sb.append(" vs ");
/* 252 */     sb.append(featureNames.get(this.xFeature));
/* 253 */     sb.append(".");
/* 254 */     return sb.toString();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/features/AbstractFeatureGrapher.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */