package fiji.plugin.trackmate.detection;

import fiji.plugin.trackmate.SpotCollection;
import net.imglib2.algorithm.Benchmark;
import net.imglib2.algorithm.OutputAlgorithm;

public interface SpotGlobalDetector<T extends net.imglib2.type.numeric.RealType<T> & net.imglib2.type.NativeType<T>> extends OutputAlgorithm<SpotCollection>, Benchmark {}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/detection/SpotGlobalDetector.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */