/*     */ package fiji.plugin.trackmate.gui.components.tracker;
/*     */ 
/*     */ import fiji.plugin.trackmate.gui.Fonts;
/*     */ import fiji.plugin.trackmate.gui.GuiUtils;
/*     */ import fiji.plugin.trackmate.tracking.LAPUtils;
/*     */ import java.awt.Component;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.GridBagConstraints;
/*     */ import java.awt.GridBagLayout;
/*     */ import java.awt.Insets;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.MouseWheelListener;
/*     */ import java.text.DecimalFormat;
/*     */ import java.util.Collection;
/*     */ import java.util.Map;
/*     */ import javax.swing.JCheckBox;
/*     */ import javax.swing.JFormattedTextField;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JScrollPane;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JPanelTrackerSettingsMain
/*     */   extends JPanel
/*     */ {
/*     */   private static final long serialVersionUID = -1L;
/*     */   private final JLabel lblSplittingMaxDistanceUnit;
/*     */   private final JFormattedTextField txtfldSplittingMaxDistance;
/*     */   private final JCheckBox chkboxAllowSplitting;
/*     */   private final JPanelFeatureSelectionGui panelGapClosing;
/*     */   private final JPanelFeatureSelectionGui panelMergingFeatures;
/*     */   private final JPanelFeatureSelectionGui panelLinkingFeatures;
/*     */   private final JPanelFeatureSelectionGui panelSplittingFeatures;
/*     */   private final JScrollPane scrpneMergingFeatures;
/*     */   private final JLabel lblMergingMaxDistanceUnit;
/*     */   private final JFormattedTextField txtfldMergingMaxDistance;
/*     */   private final JCheckBox chkboxAllowMerging;
/*     */   private final JScrollPane scrpneSplittingFeatures;
/*     */   private final JScrollPane scrpneGapClosingFeatures;
/*     */   private final JFormattedTextField txtfldGapClosingMaxFrameInterval;
/*     */   private final JLabel lblGapClosingMaxDistanceUnit;
/*     */   private final JFormattedTextField txtfldGapClosingMaxDistance;
/*     */   private final JCheckBox chkboxAllowGapClosing;
/*     */   private final JLabel lblLinkingMaxDistanceUnits;
/*     */   private final JFormattedTextField txtfldLinkingMaxDistance;
/*     */   private final JLabel lbl6;
/*     */   private final JLabel lbl7;
/*     */   private final JLabel lbl8;
/*     */   private final JLabel lbl10;
/*     */   private final JLabel lbl15;
/*     */   private final JLabel lbl13;
/*     */   private final JLabel lbl16;
/*     */   
/*     */   public JPanelTrackerSettingsMain(String trackerName, String spaceUnits, Collection<String> features, Map<String, String> featureNames) {
/* 121 */     DecimalFormat decimalFormat = new DecimalFormat("0.0");
/*     */     
/* 123 */     setPreferredSize(new Dimension(280, 1000));
/* 124 */     GridBagLayout thisLayout = new GridBagLayout();
/* 125 */     thisLayout.columnWidths = new int[] { 180, 50, 50 };
/* 126 */     thisLayout.columnWeights = new double[] { 0.1D, 0.8D, 0.1D };
/* 127 */     thisLayout.rowHeights = new int[] { 15, 20, 0, 15, 10, 15, 95, 15, 15, 15, 15, 15, 95, 15, 15, 15, 15, 15, 95, 15, 15, 15, 15, 15, 95 };
/* 128 */     thisLayout.rowWeights = new double[] { 0.0D, 0.1D, 0.25D, 0.1D, 0.0D, 0.0D, 0.25D, 0.1D, 0.0D, 0.0D, 0.0D, 0.0D, 0.25D, 0.1D, 0.0D, 0.0D, 0.0D, 0.0D, 0.25D, 0.1D, 0.0D, 0.0D, 0.0D, 0.0D, 0.0D };
/* 129 */     setLayout(thisLayout);
/*     */     
/* 131 */     JLabel jLabel1 = new JLabel();
/* 132 */     add(jLabel1, new GridBagConstraints(0, 0, 3, 1, 0.0D, 0.0D, 17, 2, new Insets(10, 10, 0, 10), 0, 0));
/* 133 */     jLabel1.setText("Settings for tracker:");
/* 134 */     jLabel1.setFont(Fonts.FONT);
/*     */     
/* 136 */     JLabel lblTrackerName = new JLabel();
/* 137 */     add(lblTrackerName, new GridBagConstraints(0, 1, 3, 1, 0.0D, 0.0D, 21, 0, new Insets(10, 20, 0, 0), 0, 0));
/* 138 */     lblTrackerName.setHorizontalTextPosition(0);
/* 139 */     lblTrackerName.setHorizontalAlignment(0);
/* 140 */     lblTrackerName.setFont(Fonts.BIG_FONT);
/* 141 */     lblTrackerName.setText(trackerName);
/*     */     
/* 143 */     JLabel lbl2 = new JLabel();
/* 144 */     add(lbl2, new GridBagConstraints(0, 3, 3, 1, 0.0D, 0.0D, 17, 2, new Insets(0, 10, 0, 10), 0, 0));
/* 145 */     lbl2.setText("Frame to frame linking:");
/* 146 */     lbl2.setFont(Fonts.BIG_FONT.deriveFont(1));
/*     */     
/* 148 */     JLabel lbl3 = new JLabel();
/* 149 */     add(lbl3, new GridBagConstraints(0, 4, 1, 1, 0.0D, 0.0D, 10, 2, new Insets(0, 10, 0, 10), 0, 0));
/* 150 */     lbl3.setText("Max distance:");
/* 151 */     lbl3.setFont(Fonts.SMALL_FONT);
/*     */     
/* 153 */     this.txtfldLinkingMaxDistance = new JFormattedTextField(decimalFormat);
/* 154 */     add(this.txtfldLinkingMaxDistance, new GridBagConstraints(1, 4, 1, 1, 0.0D, 0.0D, 10, 2, new Insets(0, 0, 0, 0), 0, 0));
/* 155 */     this.txtfldLinkingMaxDistance.setFont(Fonts.SMALL_FONT);
/* 156 */     this.txtfldLinkingMaxDistance.setSize(Fonts.TEXTFIELD_DIMENSION);
/* 157 */     this.txtfldLinkingMaxDistance.setHorizontalAlignment(0);
/*     */     
/* 159 */     this.lblLinkingMaxDistanceUnits = new JLabel();
/* 160 */     add(this.lblLinkingMaxDistanceUnits, new GridBagConstraints(2, 4, 1, 1, 0.0D, 0.0D, 17, 2, new Insets(0, 5, 0, 0), 0, 0));
/* 161 */     this.lblLinkingMaxDistanceUnits.setFont(Fonts.SMALL_FONT);
/* 162 */     this.lblLinkingMaxDistanceUnits.setText(spaceUnits);
/*     */     
/* 164 */     JLabel lbl4 = new JLabel();
/* 165 */     add(lbl4, new GridBagConstraints(0, 5, 3, 1, 0.0D, 0.0D, 10, 2, new Insets(0, 10, 0, 10), 0, 0));
/* 166 */     lbl4.setText("Feature penalties");
/* 167 */     lbl4.setFont(Fonts.SMALL_FONT);
/*     */     
/* 169 */     JScrollPane scrpneLinkingFeatures = new JScrollPane();
/* 170 */     MouseWheelListener[] l = scrpneLinkingFeatures.getMouseWheelListeners();
/* 171 */     scrpneLinkingFeatures.removeMouseWheelListener(l[0]);
/* 172 */     add(scrpneLinkingFeatures, new GridBagConstraints(0, 6, 3, 1, 0.0D, 0.0D, 10, 1, new Insets(0, 0, 0, 0), 0, 0));
/* 173 */     scrpneLinkingFeatures.setHorizontalScrollBarPolicy(31);
/* 174 */     scrpneLinkingFeatures.setVerticalScrollBarPolicy(22);
/* 175 */     this.panelLinkingFeatures = new JPanelFeatureSelectionGui();
/* 176 */     this.panelLinkingFeatures.setDisplayFeatures(features, featureNames);
/* 177 */     scrpneLinkingFeatures.setViewportView(this.panelLinkingFeatures);
/*     */ 
/*     */ 
/*     */     
/* 181 */     JLabel lbl5 = new JLabel();
/* 182 */     add(lbl5, new GridBagConstraints(0, 7, 3, 1, 0.0D, 0.0D, 10, 2, new Insets(20, 10, 0, 10), 0, 0));
/* 183 */     lbl5.setText("Track segment gap closing:");
/* 184 */     lbl5.setFont(Fonts.BIG_FONT.deriveFont(1));
/*     */     
/* 186 */     this.chkboxAllowGapClosing = new JCheckBox();
/* 187 */     add(this.chkboxAllowGapClosing, new GridBagConstraints(0, 8, 3, 1, 0.0D, 0.0D, 10, 2, new Insets(0, 10, 0, 10), 0, 0));
/* 188 */     this.chkboxAllowGapClosing.setText("Allow gap closing");
/* 189 */     this.chkboxAllowGapClosing.setFont(Fonts.SMALL_FONT);
/*     */     
/* 191 */     this.lbl6 = new JLabel();
/* 192 */     add(this.lbl6, new GridBagConstraints(0, 9, 1, 1, 0.0D, 0.0D, 10, 2, new Insets(0, 10, 0, 10), 0, 0));
/* 193 */     this.lbl6.setText("Max distance:");
/* 194 */     this.lbl6.setFont(Fonts.SMALL_FONT);
/*     */     
/* 196 */     this.txtfldGapClosingMaxDistance = new JFormattedTextField(decimalFormat);
/* 197 */     add(this.txtfldGapClosingMaxDistance, new GridBagConstraints(1, 9, 1, 1, 0.0D, 0.0D, 10, 2, new Insets(0, 0, 0, 0), 0, 0));
/* 198 */     this.txtfldGapClosingMaxDistance.setSize(Fonts.TEXTFIELD_DIMENSION);
/* 199 */     this.txtfldGapClosingMaxDistance.setFont(Fonts.SMALL_FONT);
/* 200 */     this.txtfldGapClosingMaxDistance.setHorizontalAlignment(0);
/*     */     
/* 202 */     this.lblGapClosingMaxDistanceUnit = new JLabel();
/* 203 */     add(this.lblGapClosingMaxDistanceUnit, new GridBagConstraints(2, 9, 1, 1, 0.0D, 0.0D, 17, 2, new Insets(0, 5, 0, 0), 0, 0));
/* 204 */     this.lblGapClosingMaxDistanceUnit.setFont(Fonts.SMALL_FONT);
/* 205 */     this.lblGapClosingMaxDistanceUnit.setText(spaceUnits);
/*     */     
/* 207 */     this.lbl7 = new JLabel();
/* 208 */     add(this.lbl7, new GridBagConstraints(0, 10, 1, 1, 0.0D, 0.0D, 17, 2, new Insets(0, 10, 0, 10), 0, 0));
/* 209 */     this.lbl7.setText("Max frame gap:");
/* 210 */     this.lbl7.setFont(Fonts.SMALL_FONT);
/*     */     
/* 212 */     this.txtfldGapClosingMaxFrameInterval = new JFormattedTextField(Integer.valueOf(2));
/* 213 */     add(this.txtfldGapClosingMaxFrameInterval, new GridBagConstraints(1, 10, 1, 1, 0.0D, 0.0D, 10, 2, new Insets(0, 0, 0, 0), 0, 0));
/* 214 */     this.txtfldGapClosingMaxFrameInterval.setSize(Fonts.TEXTFIELD_DIMENSION);
/* 215 */     this.txtfldGapClosingMaxFrameInterval.setFont(Fonts.SMALL_FONT);
/* 216 */     this.txtfldGapClosingMaxFrameInterval.setHorizontalAlignment(0);
/*     */     
/* 218 */     this.lbl8 = new JLabel();
/* 219 */     add(this.lbl8, new GridBagConstraints(0, 11, 3, 1, 0.0D, 0.0D, 17, 2, new Insets(0, 10, 0, 10), 0, 0));
/* 220 */     this.lbl8.setText("Feature penalties:");
/* 221 */     this.lbl8.setFont(Fonts.SMALL_FONT);
/*     */     
/* 223 */     this.scrpneGapClosingFeatures = new JScrollPane();
/* 224 */     MouseWheelListener[] l1 = this.scrpneGapClosingFeatures.getMouseWheelListeners();
/* 225 */     this.scrpneGapClosingFeatures.removeMouseWheelListener(l1[0]);
/* 226 */     add(this.scrpneGapClosingFeatures, new GridBagConstraints(0, 12, 3, 1, 0.0D, 0.0D, 10, 1, new Insets(0, 0, 0, 0), 0, 0));
/* 227 */     this.scrpneGapClosingFeatures.setHorizontalScrollBarPolicy(31);
/* 228 */     this.scrpneGapClosingFeatures.setVerticalScrollBarPolicy(22);
/* 229 */     this.panelGapClosing = new JPanelFeatureSelectionGui();
/* 230 */     this.panelGapClosing.setDisplayFeatures(features, featureNames);
/* 231 */     this.scrpneGapClosingFeatures.setViewportView(this.panelGapClosing);
/*     */ 
/*     */ 
/*     */     
/* 235 */     JLabel lbl9 = new JLabel();
/* 236 */     add(lbl9, new GridBagConstraints(0, 13, 3, 1, 0.0D, 0.0D, 10, 2, new Insets(20, 10, 0, 10), 0, 0));
/* 237 */     lbl9.setText("Track segment splitting:");
/* 238 */     lbl9.setFont(Fonts.BIG_FONT.deriveFont(1));
/*     */     
/* 240 */     this.chkboxAllowSplitting = new JCheckBox();
/* 241 */     add(this.chkboxAllowSplitting, new GridBagConstraints(0, 14, 3, 1, 0.0D, 0.0D, 10, 2, new Insets(0, 10, 0, 10), 0, 0));
/* 242 */     this.chkboxAllowSplitting.setText("Allow track segment splitting");
/* 243 */     this.chkboxAllowSplitting.setFont(Fonts.SMALL_FONT);
/*     */     
/* 245 */     this.lbl10 = new JLabel();
/* 246 */     add(this.lbl10, new GridBagConstraints(0, 15, 1, 1, 0.0D, 0.0D, 10, 2, new Insets(0, 10, 0, 0), 0, 0));
/* 247 */     this.lbl10.setText("Max distance:");
/* 248 */     this.lbl10.setFont(Fonts.SMALL_FONT);
/*     */     
/* 250 */     this.txtfldSplittingMaxDistance = new JFormattedTextField(decimalFormat);
/* 251 */     add(this.txtfldSplittingMaxDistance, new GridBagConstraints(1, 15, 1, 1, 0.0D, 0.0D, 10, 2, new Insets(0, 0, 0, 0), 0, 0));
/* 252 */     this.txtfldSplittingMaxDistance.setSize(Fonts.TEXTFIELD_DIMENSION);
/* 253 */     this.txtfldSplittingMaxDistance.setFont(Fonts.SMALL_FONT);
/* 254 */     this.txtfldSplittingMaxDistance.setHorizontalAlignment(0);
/*     */     
/* 256 */     this.lblSplittingMaxDistanceUnit = new JLabel();
/* 257 */     add(this.lblSplittingMaxDistanceUnit, new GridBagConstraints(2, 15, 1, 1, 0.0D, 0.0D, 17, 2, new Insets(0, 5, 0, 0), 0, 0));
/* 258 */     this.lblSplittingMaxDistanceUnit.setFont(Fonts.SMALL_FONT);
/* 259 */     this.lblSplittingMaxDistanceUnit.setText(spaceUnits);
/*     */     
/* 261 */     this.lbl15 = new JLabel();
/* 262 */     add(this.lbl15, new GridBagConstraints(0, 17, 1, 1, 0.0D, 0.0D, 10, 2, new Insets(0, 10, 0, 10), 0, 0));
/* 263 */     this.lbl15.setText("Feature penalties:");
/* 264 */     this.lbl15.setFont(Fonts.SMALL_FONT);
/*     */     
/* 266 */     this.scrpneSplittingFeatures = new JScrollPane();
/* 267 */     MouseWheelListener[] l2 = this.scrpneSplittingFeatures.getMouseWheelListeners();
/* 268 */     this.scrpneSplittingFeatures.removeMouseWheelListener(l2[0]);
/* 269 */     add(this.scrpneSplittingFeatures, new GridBagConstraints(0, 18, 3, 1, 0.0D, 0.0D, 10, 1, new Insets(0, 0, 0, 0), 0, 0));
/* 270 */     this.scrpneSplittingFeatures.setHorizontalScrollBarPolicy(31);
/* 271 */     this.scrpneSplittingFeatures.setVerticalScrollBarPolicy(22);
/* 272 */     this.panelSplittingFeatures = new JPanelFeatureSelectionGui();
/* 273 */     this.panelSplittingFeatures.setDisplayFeatures(features, featureNames);
/* 274 */     this.scrpneSplittingFeatures.setViewportView(this.panelSplittingFeatures);
/*     */ 
/*     */ 
/*     */     
/* 278 */     JLabel lbl12 = new JLabel();
/* 279 */     add(lbl12, new GridBagConstraints(0, 19, 3, 1, 0.0D, 0.0D, 10, 2, new Insets(20, 10, 0, 10), 0, 0));
/* 280 */     lbl12.setText("Track segment merging:");
/* 281 */     lbl12.setFont(Fonts.BIG_FONT.deriveFont(1));
/*     */     
/* 283 */     this.chkboxAllowMerging = new JCheckBox();
/* 284 */     add(this.chkboxAllowMerging, new GridBagConstraints(0, 20, 3, 1, 0.0D, 0.0D, 10, 2, new Insets(0, 10, 0, 10), 0, 0));
/* 285 */     this.chkboxAllowMerging.setText("Allow track segment merging");
/* 286 */     this.chkboxAllowMerging.setFont(Fonts.SMALL_FONT);
/*     */     
/* 288 */     this.lbl13 = new JLabel();
/* 289 */     add(this.lbl13, new GridBagConstraints(0, 21, 1, 1, 0.0D, 0.0D, 17, 2, new Insets(0, 10, 0, 0), 0, 0));
/* 290 */     this.lbl13.setText("Max distance:");
/* 291 */     this.lbl13.setFont(Fonts.SMALL_FONT);
/*     */     
/* 293 */     this.txtfldMergingMaxDistance = new JFormattedTextField(decimalFormat);
/* 294 */     add(this.txtfldMergingMaxDistance, new GridBagConstraints(1, 21, 1, 1, 0.0D, 0.0D, 10, 2, new Insets(0, 0, 0, 0), 0, 0));
/* 295 */     this.txtfldMergingMaxDistance.setSize(Fonts.TEXTFIELD_DIMENSION);
/* 296 */     this.txtfldMergingMaxDistance.setFont(Fonts.SMALL_FONT);
/* 297 */     this.txtfldMergingMaxDistance.setHorizontalAlignment(0);
/*     */     
/* 299 */     this.lblMergingMaxDistanceUnit = new JLabel();
/* 300 */     add(this.lblMergingMaxDistanceUnit, new GridBagConstraints(2, 21, 1, 1, 0.0D, 0.0D, 17, 2, new Insets(0, 5, 0, 0), 0, 0));
/* 301 */     this.lblMergingMaxDistanceUnit.setFont(Fonts.SMALL_FONT);
/* 302 */     this.lblMergingMaxDistanceUnit.setText(spaceUnits);
/*     */     
/* 304 */     this.lbl16 = new JLabel();
/* 305 */     add(this.lbl16, new GridBagConstraints(0, 23, 1, 1, 0.0D, 0.0D, 10, 2, new Insets(0, 10, 0, 10), 0, 0));
/* 306 */     this.lbl16.setText("Feature penalties:");
/* 307 */     this.lbl16.setFont(Fonts.SMALL_FONT);
/*     */     
/* 309 */     this.scrpneMergingFeatures = new JScrollPane();
/* 310 */     MouseWheelListener[] l3 = this.scrpneMergingFeatures.getMouseWheelListeners();
/* 311 */     this.scrpneMergingFeatures.removeMouseWheelListener(l3[0]);
/* 312 */     add(this.scrpneMergingFeatures, new GridBagConstraints(0, 24, 3, 1, 0.0D, 0.0D, 10, 1, new Insets(0, 0, 0, 0), 0, 0));
/* 313 */     this.scrpneMergingFeatures.setHorizontalScrollBarPolicy(31);
/* 314 */     this.scrpneMergingFeatures.setVerticalScrollBarPolicy(22);
/* 315 */     this.panelMergingFeatures = new JPanelFeatureSelectionGui();
/* 316 */     this.panelMergingFeatures.setDisplayFeatures(features, featureNames);
/* 317 */     this.scrpneMergingFeatures.setViewportView(this.panelMergingFeatures);
/*     */ 
/*     */     
/* 320 */     GuiUtils.selectAllOnFocus(this.txtfldGapClosingMaxDistance);
/* 321 */     GuiUtils.selectAllOnFocus(this.txtfldGapClosingMaxFrameInterval);
/* 322 */     GuiUtils.selectAllOnFocus(this.txtfldLinkingMaxDistance);
/* 323 */     GuiUtils.selectAllOnFocus(this.txtfldMergingMaxDistance);
/* 324 */     GuiUtils.selectAllOnFocus(this.txtfldSplittingMaxDistance);
/*     */ 
/*     */     
/* 327 */     this.chkboxAllowGapClosing.addActionListener(e -> setEnabled(new Component[] { this.lbl6, this.txtfldGapClosingMaxDistance, this.lblGapClosingMaxDistanceUnit, this.lbl7, this.txtfldGapClosingMaxFrameInterval, this.txtfldGapClosingMaxFrameInterval, this.lbl8, this.scrpneGapClosingFeatures, this.panelGapClosing }, this.chkboxAllowGapClosing.isSelected()));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 333 */     this.chkboxAllowSplitting.addActionListener(e -> setEnabled(new Component[] { this.lbl10, this.txtfldSplittingMaxDistance, this.lblSplittingMaxDistanceUnit, this.lbl15, this.scrpneSplittingFeatures, this.panelSplittingFeatures }, this.chkboxAllowSplitting.isSelected()));
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 338 */     this.chkboxAllowMerging.addActionListener(e -> setEnabled(new Component[] { this.lbl13, this.txtfldMergingMaxDistance, this.lblMergingMaxDistanceUnit, this.lbl16, this.scrpneMergingFeatures, this.panelMergingFeatures }, this.chkboxAllowMerging.isSelected()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void echoSettings(Map<String, Object> settings) {
/* 352 */     this.txtfldLinkingMaxDistance.setValue(settings.get("LINKING_MAX_DISTANCE"));
/* 353 */     this.panelLinkingFeatures.setSelectedFeaturePenalties((Map<String, Double>)settings.get("LINKING_FEATURE_PENALTIES"));
/*     */     
/* 355 */     this.chkboxAllowGapClosing.setSelected(((Boolean)settings.get("ALLOW_GAP_CLOSING")).booleanValue());
/* 356 */     this.txtfldGapClosingMaxDistance.setValue(settings.get("GAP_CLOSING_MAX_DISTANCE"));
/* 357 */     this.txtfldGapClosingMaxFrameInterval.setValue(settings.get("MAX_FRAME_GAP"));
/* 358 */     this.panelGapClosing.setSelectedFeaturePenalties((Map<String, Double>)settings.get("GAP_CLOSING_FEATURE_PENALTIES"));
/*     */     
/* 360 */     this.chkboxAllowSplitting.setSelected(((Boolean)settings.get("ALLOW_TRACK_SPLITTING")).booleanValue());
/* 361 */     this.txtfldSplittingMaxDistance.setValue(settings.get("SPLITTING_MAX_DISTANCE"));
/* 362 */     this.panelSplittingFeatures.setSelectedFeaturePenalties((Map<String, Double>)settings.get("SPLITTING_FEATURE_PENALTIES"));
/*     */     
/* 364 */     this.chkboxAllowMerging.setSelected(((Boolean)settings.get("ALLOW_TRACK_MERGING")).booleanValue());
/* 365 */     this.txtfldMergingMaxDistance.setValue(settings.get("SPLITTING_MAX_DISTANCE"));
/* 366 */     this.panelMergingFeatures.setSelectedFeaturePenalties((Map<String, Double>)settings.get("MERGING_FEATURE_PENALTIES"));
/*     */     
/* 368 */     setEnabled(new Component[] { this.lbl6, this.txtfldGapClosingMaxDistance, this.lblGapClosingMaxDistanceUnit, this.lbl7, this.txtfldGapClosingMaxFrameInterval, this.txtfldGapClosingMaxFrameInterval, this.lbl8, this.scrpneGapClosingFeatures, this.panelGapClosing }, this.chkboxAllowGapClosing
/*     */ 
/*     */ 
/*     */         
/* 372 */         .isSelected());
/*     */     
/* 374 */     setEnabled(new Component[] { this.lbl10, this.txtfldSplittingMaxDistance, this.lblSplittingMaxDistanceUnit, this.lbl15, this.scrpneSplittingFeatures, this.panelSplittingFeatures }, this.chkboxAllowSplitting
/*     */ 
/*     */         
/* 377 */         .isSelected());
/*     */     
/* 379 */     setEnabled(new Component[] { this.lbl13, this.txtfldMergingMaxDistance, this.lblMergingMaxDistanceUnit, this.lbl16, this.scrpneMergingFeatures, this.panelMergingFeatures }, this.chkboxAllowMerging
/*     */ 
/*     */         
/* 382 */         .isSelected());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, Object> getSettings() {
/* 390 */     Map<String, Object> settings = LAPUtils.getDefaultLAPSettingsMap();
/*     */     
/* 392 */     settings.put("LINKING_MAX_DISTANCE", Double.valueOf(((Number)this.txtfldLinkingMaxDistance.getValue()).doubleValue()));
/* 393 */     settings.put("LINKING_FEATURE_PENALTIES", this.panelLinkingFeatures.getFeaturePenalties());
/*     */     
/* 395 */     settings.put("ALLOW_GAP_CLOSING", Boolean.valueOf(this.chkboxAllowGapClosing.isSelected()));
/* 396 */     settings.put("GAP_CLOSING_MAX_DISTANCE", Double.valueOf(((Number)this.txtfldGapClosingMaxDistance.getValue()).doubleValue()));
/* 397 */     settings.put("MAX_FRAME_GAP", Integer.valueOf(((Number)this.txtfldGapClosingMaxFrameInterval.getValue()).intValue()));
/* 398 */     settings.put("GAP_CLOSING_FEATURE_PENALTIES", this.panelGapClosing.getFeaturePenalties());
/*     */     
/* 400 */     settings.put("ALLOW_TRACK_SPLITTING", Boolean.valueOf(this.chkboxAllowSplitting.isSelected()));
/* 401 */     settings.put("SPLITTING_MAX_DISTANCE", Double.valueOf(((Number)this.txtfldSplittingMaxDistance.getValue()).doubleValue()));
/* 402 */     settings.put("SPLITTING_FEATURE_PENALTIES", this.panelSplittingFeatures.getFeaturePenalties());
/*     */     
/* 404 */     settings.put("ALLOW_TRACK_MERGING", Boolean.valueOf(this.chkboxAllowMerging.isSelected()));
/* 405 */     settings.put("MERGING_MAX_DISTANCE", Double.valueOf(((Number)this.txtfldMergingMaxDistance.getValue()).doubleValue()));
/* 406 */     settings.put("MERGING_FEATURE_PENALTIES", this.panelMergingFeatures.getFeaturePenalties());
/*     */     
/* 408 */     return settings;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void setEnabled(Component[] components, boolean enable) {
/* 417 */     for (Component component : components)
/* 418 */       component.setEnabled(enable); 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/gui/components/tracker/JPanelTrackerSettingsMain.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */