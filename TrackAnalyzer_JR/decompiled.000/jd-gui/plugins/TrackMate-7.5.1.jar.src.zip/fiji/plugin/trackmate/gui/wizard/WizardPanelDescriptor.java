/*    */ package fiji.plugin.trackmate.gui.wizard;
/*    */ 
/*    */ import java.awt.Component;
/*    */ import org.scijava.Cancelable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WizardPanelDescriptor
/*    */ {
/*    */   protected Component targetPanel;
/*    */   protected final String panelIdentifier;
/*    */   
/*    */   public WizardPanelDescriptor(String panelIdentifier) {
/* 37 */     this.panelIdentifier = panelIdentifier;
/*    */   }
/*    */ 
/*    */   
/*    */   public final Component getPanelComponent() {
/* 42 */     return this.targetPanel;
/*    */   }
/*    */ 
/*    */   
/*    */   public final String getPanelDescriptorIdentifier() {
/* 47 */     return this.panelIdentifier;
/*    */   }
/*    */ 
/*    */   
/*    */   public void aboutToHidePanel() {}
/*    */ 
/*    */   
/*    */   public void aboutToDisplayPanel() {}
/*    */ 
/*    */   
/*    */   public void displayingPanel() {}
/*    */ 
/*    */   
/*    */   public Runnable getForwardRunnable() {
/* 61 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public Runnable getBackwardRunnable() {
/* 66 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public Cancelable getCancelable() {
/* 71 */     return null;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/gui/wizard/WizardPanelDescriptor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */