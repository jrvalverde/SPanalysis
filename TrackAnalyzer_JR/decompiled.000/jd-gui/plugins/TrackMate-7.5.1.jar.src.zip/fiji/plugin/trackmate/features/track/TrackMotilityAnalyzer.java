/*     */ package fiji.plugin.trackmate.features.track;
/*     */ 
/*     */ import fiji.plugin.trackmate.Dimension;
/*     */ import fiji.plugin.trackmate.FeatureModel;
/*     */ import fiji.plugin.trackmate.Model;
/*     */ import fiji.plugin.trackmate.Spot;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.Callable;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.Executors;
/*     */ import java.util.concurrent.Future;
/*     */ import javax.swing.ImageIcon;
/*     */ import net.imglib2.RealLocalizable;
/*     */ import org.jgrapht.graph.DefaultWeightedEdge;
/*     */ import org.scijava.plugin.Plugin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Plugin(type = TrackAnalyzer.class, priority = -100.0D)
/*     */ public class TrackMotilityAnalyzer
/*     */   implements TrackAnalyzer
/*     */ {
/*     */   public static final String KEY = "Track motility analysis";
/*     */   public static final String TRACK_TOTAL_DISTANCE_TRAVELED = "TOTAL_DISTANCE_TRAVELED";
/*     */   public static final String TRACK_MAX_DISTANCE_TRAVELED = "MAX_DISTANCE_TRAVELED";
/*     */   public static final String TRACK_CONFINMENT_RATIO = "CONFINMENT_RATIO";
/*     */   public static final String TRACK_MEAN_STRAIGHT_LINE_SPEED = "MEAN_STRAIGHT_LINE_SPEED";
/*     */   public static final String TRACK_LINEARITY_OF_FORWARD_PROGRESSION = "LINEARITY_OF_FORWARD_PROGRESSION";
/*     */   public static final String TRACK_MEAN_DIRECTIONAL_CHANGE_RATE = "MEAN_DIRECTIONAL_CHANGE_RATE";
/*  67 */   public static final List<String> FEATURES = new ArrayList<>(6);
/*     */   
/*  69 */   public static final Map<String, String> FEATURE_NAMES = new HashMap<>(FEATURES.size());
/*     */   
/*  71 */   public static final Map<String, String> FEATURE_SHORT_NAMES = new HashMap<>(FEATURES.size());
/*     */   
/*  73 */   public static final Map<String, Dimension> FEATURE_DIMENSIONS = new HashMap<>(FEATURES.size());
/*     */   
/*  75 */   public static final Map<String, Boolean> IS_INT = new HashMap<>(FEATURES.size());
/*     */   private int numThreads;
/*     */   
/*     */   static {
/*  79 */     FEATURES.add("TOTAL_DISTANCE_TRAVELED");
/*  80 */     FEATURES.add("MAX_DISTANCE_TRAVELED");
/*  81 */     FEATURES.add("CONFINMENT_RATIO");
/*  82 */     FEATURES.add("MEAN_STRAIGHT_LINE_SPEED");
/*  83 */     FEATURES.add("LINEARITY_OF_FORWARD_PROGRESSION");
/*  84 */     FEATURES.add("MEAN_DIRECTIONAL_CHANGE_RATE");
/*     */     
/*  86 */     FEATURE_NAMES.put("TOTAL_DISTANCE_TRAVELED", "Total distance traveled");
/*  87 */     FEATURE_NAMES.put("MAX_DISTANCE_TRAVELED", "Max distance traveled");
/*  88 */     FEATURE_NAMES.put("CONFINMENT_RATIO", "Confinment ratio");
/*  89 */     FEATURE_NAMES.put("MEAN_STRAIGHT_LINE_SPEED", "Mean straight line speed");
/*  90 */     FEATURE_NAMES.put("LINEARITY_OF_FORWARD_PROGRESSION", "Linearity of forward progression");
/*  91 */     FEATURE_NAMES.put("MEAN_DIRECTIONAL_CHANGE_RATE", "Mean directional change rate");
/*     */     
/*  93 */     FEATURE_SHORT_NAMES.put("TOTAL_DISTANCE_TRAVELED", "Total dist.");
/*  94 */     FEATURE_SHORT_NAMES.put("MAX_DISTANCE_TRAVELED", "Max dist.");
/*  95 */     FEATURE_SHORT_NAMES.put("CONFINMENT_RATIO", "Cfn. ratio");
/*  96 */     FEATURE_SHORT_NAMES.put("MEAN_STRAIGHT_LINE_SPEED", "Mn. v. line");
/*  97 */     FEATURE_SHORT_NAMES.put("LINEARITY_OF_FORWARD_PROGRESSION", "Fwd. progr.");
/*  98 */     FEATURE_SHORT_NAMES.put("MEAN_DIRECTIONAL_CHANGE_RATE", "Mn. γ rate");
/*     */     
/* 100 */     FEATURE_DIMENSIONS.put("TOTAL_DISTANCE_TRAVELED", Dimension.LENGTH);
/* 101 */     FEATURE_DIMENSIONS.put("MAX_DISTANCE_TRAVELED", Dimension.LENGTH);
/* 102 */     FEATURE_DIMENSIONS.put("CONFINMENT_RATIO", Dimension.NONE);
/* 103 */     FEATURE_DIMENSIONS.put("MEAN_STRAIGHT_LINE_SPEED", Dimension.VELOCITY);
/* 104 */     FEATURE_DIMENSIONS.put("LINEARITY_OF_FORWARD_PROGRESSION", Dimension.NONE);
/* 105 */     FEATURE_DIMENSIONS.put("MEAN_DIRECTIONAL_CHANGE_RATE", Dimension.ANGLE_RATE);
/*     */     
/* 107 */     IS_INT.put("TOTAL_DISTANCE_TRAVELED", Boolean.FALSE);
/* 108 */     IS_INT.put("MAX_DISTANCE_TRAVELED", Boolean.FALSE);
/* 109 */     IS_INT.put("CONFINMENT_RATIO", Boolean.FALSE);
/* 110 */     IS_INT.put("MEAN_STRAIGHT_LINE_SPEED", Boolean.FALSE);
/* 111 */     IS_INT.put("LINEARITY_OF_FORWARD_PROGRESSION", Boolean.FALSE);
/* 112 */     IS_INT.put("MEAN_DIRECTIONAL_CHANGE_RATE", Boolean.FALSE);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private long processingTime;
/*     */ 
/*     */   
/*     */   public TrackMotilityAnalyzer() {
/* 121 */     setNumThreads();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public long getProcessingTime() {
/* 127 */     return this.processingTime;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, Dimension> getFeatureDimensions() {
/* 133 */     return FEATURE_DIMENSIONS;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, String> getFeatureNames() {
/* 139 */     return FEATURE_NAMES;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, String> getFeatureShortNames() {
/* 145 */     return FEATURE_SHORT_NAMES;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public List<String> getFeatures() {
/* 151 */     return FEATURES;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, Boolean> getIsIntFeature() {
/* 157 */     return IS_INT;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isManualFeature() {
/* 163 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ImageIcon getIcon() {
/* 169 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getInfoText() {
/* 175 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getKey() {
/* 181 */     return "Track motility analysis";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/* 187 */     return "Track motility analysis";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getNumThreads() {
/* 193 */     return this.numThreads;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setNumThreads() {
/* 199 */     this.numThreads = Runtime.getRuntime().availableProcessors();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setNumThreads(int numThreads) {
/* 205 */     this.numThreads = numThreads;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isLocal() {
/* 212 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void process(Collection<Integer> trackIDs, final Model model) {
/* 218 */     if (trackIDs.isEmpty()) {
/*     */       return;
/*     */     }
/* 221 */     long start = System.currentTimeMillis();
/*     */ 
/*     */     
/* 224 */     List<Callable<Void>> tasks = new ArrayList<>(trackIDs.size());
/* 225 */     for (Integer trackID : trackIDs) {
/*     */       
/* 227 */       Callable<Void> task = new Callable<Void>()
/*     */         {
/*     */ 
/*     */           
/*     */           public Void call() throws Exception
/*     */           {
/* 233 */             TrackMotilityAnalyzer.analyze(trackID, model);
/* 234 */             return null;
/*     */           }
/*     */         };
/* 237 */       tasks.add(task);
/*     */     } 
/*     */     
/* 240 */     ExecutorService executorService = Executors.newFixedThreadPool(this.numThreads);
/*     */ 
/*     */     
/*     */     try {
/* 244 */       List<Future<Void>> futures = executorService.invokeAll(tasks);
/* 245 */       for (Future<Void> future : futures) {
/* 246 */         future.get();
/*     */       }
/* 248 */     } catch (InterruptedException|java.util.concurrent.ExecutionException e) {
/*     */       
/* 250 */       e.printStackTrace();
/*     */     } 
/* 252 */     executorService.shutdown();
/*     */     
/* 254 */     long end = System.currentTimeMillis();
/* 255 */     this.processingTime = end - start;
/*     */   }
/*     */ 
/*     */   
/*     */   private static final void analyze(Integer trackID, Model model) {
/* 260 */     FeatureModel fm = model.getFeatureModel();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 266 */     List<Spot> spots = new ArrayList<>(model.getTrackModel().trackSpots(trackID));
/* 267 */     Collections.sort(spots, Spot.frameComparator);
/* 268 */     Spot first = spots.get(0);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 274 */     Set<DefaultWeightedEdge> edges = model.getTrackModel().trackEdges(trackID);
/*     */     
/* 276 */     double totalDistance = 0.0D;
/* 277 */     double maxDistanceSq = Double.NEGATIVE_INFINITY;
/* 278 */     double maxDistance = 0.0D;
/* 279 */     double sumAngleSpeed = 0.0D;
/* 280 */     int nAngleSpeed = 0;
/*     */     
/* 282 */     for (DefaultWeightedEdge edge : edges) {
/*     */ 
/*     */       
/* 285 */       Spot source = model.getTrackModel().getEdgeSource(edge);
/* 286 */       Spot target = model.getTrackModel().getEdgeTarget(edge);
/* 287 */       double d = Math.sqrt(source.squareDistanceTo((RealLocalizable)target));
/* 288 */       totalDistance += d;
/*     */ 
/*     */       
/* 291 */       double dToFirstSq = first.squareDistanceTo((RealLocalizable)target);
/* 292 */       if (dToFirstSq > maxDistanceSq) {
/*     */         
/* 294 */         maxDistanceSq = dToFirstSq;
/* 295 */         maxDistance = Math.sqrt(maxDistanceSq);
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 302 */       Double val = fm.getEdgeFeature(edge, "DIRECTIONAL_CHANGE_RATE");
/* 303 */       if (null != val && !val.isNaN()) {
/*     */         
/* 305 */         sumAngleSpeed += val.doubleValue();
/* 306 */         nAngleSpeed++;
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 315 */     double netDistance = fm.getTrackFeature(trackID, "TRACK_DISPLACEMENT").doubleValue();
/* 316 */     double tTotal = fm.getTrackFeature(trackID, "TRACK_DURATION").doubleValue();
/* 317 */     double vMean = fm.getTrackFeature(trackID, "TRACK_MEAN_SPEED").doubleValue();
/*     */ 
/*     */     
/* 320 */     double confinmentRatio = netDistance / totalDistance;
/* 321 */     double meanStraightLineSpeed = netDistance / tTotal;
/* 322 */     double linearityForwardProgression = meanStraightLineSpeed / vMean;
/* 323 */     double meanAngleSpeed = sumAngleSpeed / nAngleSpeed;
/*     */ 
/*     */     
/* 326 */     fm.putTrackFeature(trackID, "TOTAL_DISTANCE_TRAVELED", Double.valueOf(totalDistance));
/* 327 */     fm.putTrackFeature(trackID, "MAX_DISTANCE_TRAVELED", Double.valueOf(maxDistance));
/* 328 */     fm.putTrackFeature(trackID, "CONFINMENT_RATIO", Double.valueOf(confinmentRatio));
/* 329 */     fm.putTrackFeature(trackID, "MEAN_STRAIGHT_LINE_SPEED", Double.valueOf(meanStraightLineSpeed));
/* 330 */     fm.putTrackFeature(trackID, "LINEARITY_OF_FORWARD_PROGRESSION", Double.valueOf(linearityForwardProgression));
/* 331 */     fm.putTrackFeature(trackID, "MEAN_DIRECTIONAL_CHANGE_RATE", Double.valueOf(meanAngleSpeed));
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/features/track/TrackMotilityAnalyzer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */