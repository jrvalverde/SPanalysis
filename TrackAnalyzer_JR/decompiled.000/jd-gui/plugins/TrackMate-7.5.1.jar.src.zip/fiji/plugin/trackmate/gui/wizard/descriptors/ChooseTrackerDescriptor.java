/*     */ package fiji.plugin.trackmate.gui.wizard.descriptors;
/*     */ 
/*     */ import fiji.plugin.trackmate.TrackMate;
/*     */ import fiji.plugin.trackmate.gui.components.ModuleChooserPanel;
/*     */ import fiji.plugin.trackmate.gui.wizard.WizardPanelDescriptor;
/*     */ import fiji.plugin.trackmate.io.SettingsPersistence;
/*     */ import fiji.plugin.trackmate.providers.AbstractProvider;
/*     */ import fiji.plugin.trackmate.providers.TrackerProvider;
/*     */ import fiji.plugin.trackmate.tracking.SpotTrackerFactory;
/*     */ import java.awt.Component;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ChooseTrackerDescriptor
/*     */   extends WizardPanelDescriptor
/*     */ {
/*     */   private static final String KEY = "ChooseTracker";
/*     */   private final TrackMate trackmate;
/*     */   private final TrackerProvider trackerProvider;
/*     */   
/*     */   public ChooseTrackerDescriptor(TrackerProvider trackerProvider, TrackMate trackmate) {
/*  45 */     super("ChooseTracker");
/*  46 */     this.trackmate = trackmate;
/*  47 */     this.trackerProvider = trackerProvider;
/*     */     
/*  49 */     String selectedTracker = "SIMPLE_SPARSE_LAP_TRACKER";
/*  50 */     if (null != (trackmate.getSettings()).trackerFactory) {
/*  51 */       selectedTracker = (trackmate.getSettings()).trackerFactory.getKey();
/*     */     }
/*  53 */     this.targetPanel = (Component)new ModuleChooserPanel((AbstractProvider)trackerProvider, "tracker", selectedTracker);
/*     */   }
/*     */ 
/*     */   
/*     */   private void setCurrentChoiceFromPlugin() {
/*  58 */     String key = "SIMPLE_SPARSE_LAP_TRACKER";
/*  59 */     if (null != (this.trackmate.getSettings()).trackerFactory) {
/*  60 */       key = (this.trackmate.getSettings()).trackerFactory.getKey();
/*     */     }
/*     */     
/*  63 */     ModuleChooserPanel<SpotTrackerFactory> component = (ModuleChooserPanel<SpotTrackerFactory>)this.targetPanel;
/*  64 */     component.setSelectedModuleKey(key);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void displayingPanel() {
/*  70 */     setCurrentChoiceFromPlugin();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void aboutToHidePanel() {
/*  78 */     ModuleChooserPanel<SpotTrackerFactory> component = (ModuleChooserPanel<SpotTrackerFactory>)this.targetPanel;
/*  79 */     String trackerKey = component.getSelectedModuleKey();
/*     */ 
/*     */     
/*  82 */     SpotTrackerFactory factory = (SpotTrackerFactory)this.trackerProvider.getFactory(trackerKey);
/*     */     
/*  84 */     if (null == factory) {
/*     */       
/*  86 */       this.trackmate.getModel().getLogger().error("[ChooseTrackerDescriptor] Cannot find tracker named " + trackerKey + " in current TrackMate modules.");
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/*  91 */     (this.trackmate.getSettings()).trackerFactory = factory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  97 */     Map<String, Object> currentSettings = (this.trackmate.getSettings()).trackerSettings;
/*  98 */     if (!factory.checkSettingsValidity(currentSettings)) {
/*     */       
/* 100 */       Map<String, Object> defaultSettings = factory.getDefaultSettings();
/* 101 */       (this.trackmate.getSettings()).trackerSettings = defaultSettings;
/*     */     } 
/*     */ 
/*     */     
/* 105 */     SettingsPersistence.saveLastUsedSettings(this.trackmate.getSettings(), this.trackmate.getModel().getLogger());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Runnable getBackwardRunnable() {
/* 112 */     return () -> this.trackmate.getModel().clearTracks(true);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/gui/wizard/descriptors/ChooseTrackerDescriptor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */