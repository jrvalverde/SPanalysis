/*    */ package fiji.plugin.trackmate.action.fit;
/*    */ 
/*    */ import fiji.plugin.trackmate.SelectionModel;
/*    */ import fiji.plugin.trackmate.TrackMate;
/*    */ import fiji.plugin.trackmate.action.AbstractTMAction;
/*    */ import fiji.plugin.trackmate.action.TrackMateAction;
/*    */ import fiji.plugin.trackmate.action.TrackMateActionFactory;
/*    */ import fiji.plugin.trackmate.gui.Icons;
/*    */ import fiji.plugin.trackmate.gui.displaysettings.DisplaySettings;
/*    */ import java.awt.Frame;
/*    */ import javax.swing.ImageIcon;
/*    */ import org.scijava.plugin.Plugin;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SpotGaussianFittingAction
/*    */   extends AbstractTMAction
/*    */ {
/*    */   public void execute(TrackMate trackmate, SelectionModel selectionModel, DisplaySettings displaySettings, Frame parent) {
/* 42 */     SpotFitterController controller = new SpotFitterController(trackmate, selectionModel, this.logger);
/* 43 */     controller.show();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Plugin(type = TrackMateActionFactory.class)
/*    */   public static class Factory
/*    */     implements TrackMateActionFactory
/*    */   {
/*    */     public static final String NAME = "Refine spot position with gaussian fitting";
/*    */ 
/*    */ 
/*    */ 
/*    */     
/*    */     public static final String KEY = "GAUSS_FIT";
/*    */ 
/*    */ 
/*    */ 
/*    */     
/*    */     public static final String INFO_TEXT = "<html>This action launches a GUI for the sub-localization of spots using gaussian peak fitting. <p>The fit process will update the spot position and their radius, using the results from the gaussian fit. Of course it works best when the peaks in the image ressemble gaussian functions. The fitting process uses the spots information (position and radius) as initial values for the fit.<p>It works for both 2D and 3D images. In 3D it accounts for non-isotropic calibration (and possible PSF deformation in the Z direction) thanks to an elliptic gaussian function, with axes constrained to be along X, Y and Z. In 2D we use an isotropic gaussian.</html>";
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/*    */     public String getInfoText() {
/* 72 */       return "<html>This action launches a GUI for the sub-localization of spots using gaussian peak fitting. <p>The fit process will update the spot position and their radius, using the results from the gaussian fit. Of course it works best when the peaks in the image ressemble gaussian functions. The fitting process uses the spots information (position and radius) as initial values for the fit.<p>It works for both 2D and 3D images. In 3D it accounts for non-isotropic calibration (and possible PSF deformation in the Z direction) thanks to an elliptic gaussian function, with axes constrained to be along X, Y and Z. In 2D we use an isotropic gaussian.</html>";
/*    */     }
/*    */ 
/*    */ 
/*    */     
/*    */     public String getKey() {
/* 78 */       return "GAUSS_FIT";
/*    */     }
/*    */ 
/*    */ 
/*    */     
/*    */     public TrackMateAction create() {
/* 84 */       return (TrackMateAction)new SpotGaussianFittingAction();
/*    */     }
/*    */ 
/*    */ 
/*    */     
/*    */     public ImageIcon getIcon() {
/* 90 */       return Icons.SPOT_ICON_16x16;
/*    */     }
/*    */ 
/*    */ 
/*    */     
/*    */     public String getName() {
/* 96 */       return "Refine spot position with gaussian fitting";
/*    */     }
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/action/fit/SpotGaussianFittingAction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */