package fiji.plugin.trackmate.visualization;

import fiji.plugin.trackmate.Model;
import fiji.plugin.trackmate.Spot;

public interface TrackMateModelView {
  void render();
  
  void refresh();
  
  void clear();
  
  void centerViewOn(Spot paramSpot);
  
  Model getModel();
  
  String getKey();
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/visualization/TrackMateModelView.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */