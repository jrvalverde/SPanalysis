/*     */ package fiji.plugin.trackmate.gui.components;
/*     */ 
/*     */ import fiji.plugin.trackmate.Logger;
/*     */ import fiji.plugin.trackmate.gui.Fonts;
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.Color;
/*     */ import java.awt.Dimension;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JProgressBar;
/*     */ import javax.swing.JScrollPane;
/*     */ import javax.swing.JTextPane;
/*     */ import javax.swing.SwingUtilities;
/*     */ import javax.swing.text.AttributeSet;
/*     */ import javax.swing.text.SimpleAttributeSet;
/*     */ import javax.swing.text.StyleConstants;
/*     */ import javax.swing.text.StyleContext;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LogPanel
/*     */   extends JPanel
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   public static final String DESCRIPTOR = "LogPanel";
/*     */   private final JTextPane textPane;
/*     */   private final JProgressBar progressBar;
/*     */   private final Logger logger;
/*     */   
/*     */   public LogPanel() {
/*  62 */     BorderLayout layout = new BorderLayout();
/*  63 */     setLayout(layout);
/*  64 */     setPreferredSize(new Dimension(270, 500));
/*     */     
/*  66 */     JPanel panelProgressBar = new JPanel();
/*  67 */     BorderLayout jPanelProgressBarLayout = new BorderLayout();
/*  68 */     panelProgressBar.setLayout(jPanelProgressBarLayout);
/*  69 */     add(panelProgressBar, "North");
/*  70 */     panelProgressBar.setPreferredSize(new Dimension(270, 32));
/*     */     
/*  72 */     this.progressBar = new JProgressBar();
/*  73 */     panelProgressBar.add(this.progressBar, "Center");
/*  74 */     this.progressBar.setPreferredSize(new Dimension(270, 20));
/*  75 */     this.progressBar.setStringPainted(true);
/*  76 */     this.progressBar.setFont(Fonts.SMALL_FONT);
/*     */     
/*  78 */     JScrollPane scrollPane = new JScrollPane();
/*  79 */     add(scrollPane);
/*  80 */     scrollPane.setPreferredSize(new Dimension(262, 136));
/*     */     
/*  82 */     this.textPane = new JTextPane();
/*  83 */     this.textPane.setEditable(true);
/*  84 */     this.textPane.setFont(Fonts.SMALL_FONT);
/*  85 */     scrollPane.setViewportView(this.textPane);
/*  86 */     this.textPane.setBackground(getBackground());
/*     */     
/*  88 */     this.logger = new LogPanelLogger();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JTextPane getTextPane() {
/* 102 */     return this.textPane;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Logger getLogger() {
/* 111 */     return this.logger;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getTextContent() {
/* 119 */     return this.textPane.getText();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTextContent(String log) {
/* 130 */     this.textPane.setText(log);
/*     */   }
/*     */   
/*     */   private class LogPanelLogger
/*     */     extends Logger
/*     */   {
/*     */     private LogPanelLogger() {}
/*     */     
/*     */     public void error(String message) {
/* 139 */       log(message, Logger.ERROR_COLOR);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void log(final String message, final Color color) {
/* 145 */       SwingUtilities.invokeLater(new Runnable()
/*     */           {
/*     */             
/*     */             public void run()
/*     */             {
/* 150 */               StyleContext sc = StyleContext.getDefaultStyleContext();
/* 151 */               AttributeSet aset = sc.addAttribute(SimpleAttributeSet.EMPTY, StyleConstants.Foreground, color);
/* 152 */               int len = LogPanel.this.textPane.getDocument().getLength();
/* 153 */               LogPanel.this.textPane.setCaretPosition(len);
/* 154 */               LogPanel.this.textPane.setCharacterAttributes(aset, false);
/* 155 */               LogPanel.this.textPane.replaceSelection(message);
/*     */             }
/*     */           });
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void setStatus(final String status) {
/* 163 */       SwingUtilities.invokeLater(new Runnable()
/*     */           {
/*     */             
/*     */             public void run()
/*     */             {
/* 168 */               LogPanel.this.progressBar.setString(status);
/*     */             }
/*     */           });
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void setProgress(double val) {
/* 176 */       if (val < 0.0D)
/* 177 */         val = 0.0D; 
/* 178 */       if (val > 1.0D)
/* 179 */         val = 1.0D; 
/* 180 */       final int intVal = (int)(val * 100.0D);
/* 181 */       SwingUtilities.invokeLater(new Runnable()
/*     */           {
/*     */             
/*     */             public void run()
/*     */             {
/* 186 */               LogPanel.this.progressBar.setValue(intVal);
/*     */             }
/*     */           });
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public String toString() {
/* 194 */       return LogPanel.this.getTextContent();
/*     */     }
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/gui/components/LogPanel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */