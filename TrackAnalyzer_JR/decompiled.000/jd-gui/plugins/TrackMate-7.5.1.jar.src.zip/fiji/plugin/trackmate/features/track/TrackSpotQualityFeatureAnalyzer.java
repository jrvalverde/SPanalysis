/*    */ package fiji.plugin.trackmate.features.track;
/*    */ 
/*    */ import fiji.plugin.trackmate.Dimension;
/*    */ import fiji.plugin.trackmate.FeatureModel;
/*    */ import fiji.plugin.trackmate.Model;
/*    */ import fiji.plugin.trackmate.Spot;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import java.util.Objects;
/*    */ import java.util.Set;
/*    */ import org.scijava.plugin.Plugin;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Plugin(type = TrackAnalyzer.class)
/*    */ public class TrackSpotQualityFeatureAnalyzer
/*    */   extends AbstractTrackAnalyzer
/*    */ {
/*    */   public static final String KEY = "Track quality";
/*    */   public static final String TRACK_MEAN_QUALITY = "TRACK_MEAN_QUALITY";
/* 44 */   public static final List<String> FEATURES = Collections.singletonList("TRACK_MEAN_QUALITY");
/* 45 */   public static final Map<String, String> FEATURE_NAMES = Collections.singletonMap("TRACK_MEAN_QUALITY", "Track mean quality");
/* 46 */   public static final Map<String, String> FEATURE_SHORT_NAMES = Collections.singletonMap("TRACK_MEAN_QUALITY", "Mean Q");
/* 47 */   public static final Map<String, Dimension> FEATURE_DIMENSIONS = Collections.singletonMap("TRACK_MEAN_QUALITY", Dimension.QUALITY);
/* 48 */   public static final Map<String, Boolean> IS_INT = Collections.singletonMap("TRACK_MEAN_QUALITY", Boolean.FALSE);
/*    */ 
/*    */   
/*    */   public TrackSpotQualityFeatureAnalyzer() {
/* 52 */     super("Track quality", "Track quality", FEATURES, FEATURE_NAMES, FEATURE_SHORT_NAMES, FEATURE_DIMENSIONS, IS_INT);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected void analyze(Integer trackID, Model model) {
/* 58 */     FeatureModel fm = model.getFeatureModel();
/* 59 */     Set<Spot> track = model.getTrackModel().trackSpots(trackID);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 65 */     double mean = track.stream().filter(Objects::nonNull).mapToDouble(s -> s.getFeature("QUALITY").doubleValue()).average().getAsDouble();
/* 66 */     fm.putTrackFeature(trackID, "TRACK_MEAN_QUALITY", Double.valueOf(mean));
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/features/track/TrackSpotQualityFeatureAnalyzer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */