/*     */ package fiji.plugin.trackmate.util;
/*     */ 
/*     */ import fiji.plugin.trackmate.Model;
/*     */ import fiji.plugin.trackmate.SelectionModel;
/*     */ import fiji.plugin.trackmate.Spot;
/*     */ import fiji.plugin.trackmate.graph.TimeDirectedNeighborIndex;
/*     */ import java.util.Iterator;
/*     */ import java.util.Set;
/*     */ import java.util.TreeSet;
/*     */ import org.jgrapht.graph.DefaultWeightedEdge;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TrackNavigator
/*     */ {
/*     */   private final Model model;
/*     */   private final SelectionModel selectionModel;
/*     */   private final TimeDirectedNeighborIndex neighborIndex;
/*     */   
/*     */   public TrackNavigator(Model model, SelectionModel selectionModel) {
/*  42 */     this.model = model;
/*  43 */     this.selectionModel = selectionModel;
/*  44 */     this.neighborIndex = model.getTrackModel().getDirectedNeighborIndex();
/*     */   }
/*     */   
/*     */   public synchronized void nextTrack() {
/*  48 */     Spot spot = getASpot();
/*  49 */     if (null == spot) {
/*     */       return;
/*     */     }
/*     */     
/*  53 */     Set<Integer> trackIDs = this.model.getTrackModel().trackIDs(true);
/*  54 */     if (trackIDs.isEmpty()) {
/*     */       return;
/*     */     }
/*     */     
/*  58 */     Integer trackID = this.model.getTrackModel().trackIDOf(spot);
/*  59 */     if (null == trackID)
/*     */     {
/*  61 */       trackID = this.model.getTrackModel().trackIDs(true).iterator().next();
/*     */     }
/*     */     
/*  64 */     Iterator<Integer> it = trackIDs.iterator();
/*  65 */     Integer nextTrackID = null;
/*  66 */     while (it.hasNext()) {
/*  67 */       Integer id = it.next();
/*  68 */       if (id.equals(trackID)) {
/*  69 */         if (it.hasNext()) {
/*  70 */           nextTrackID = it.next();
/*     */           break;
/*     */         } 
/*  73 */         nextTrackID = trackIDs.iterator().next();
/*     */       } 
/*     */     } 
/*     */     
/*  77 */     Set<Spot> spots = this.model.getTrackModel().trackSpots(nextTrackID);
/*  78 */     TreeSet<Spot> ring = new TreeSet<>(Spot.frameComparator);
/*  79 */     ring.addAll(spots);
/*  80 */     Spot target = ring.ceiling(spot);
/*  81 */     if (null == target) {
/*  82 */       target = ring.floor(spot);
/*     */     }
/*     */     
/*  85 */     this.selectionModel.clearSelection();
/*  86 */     this.selectionModel.addSpotToSelection(target);
/*     */   }
/*     */   
/*     */   public synchronized void previousTrack() {
/*  90 */     Spot spot = getASpot();
/*  91 */     if (null == spot) {
/*     */       return;
/*     */     }
/*     */     
/*  95 */     Integer trackID = this.model.getTrackModel().trackIDOf(spot);
/*  96 */     Set<Integer> trackIDs = this.model.getTrackModel().trackIDs(true);
/*  97 */     if (trackIDs.isEmpty()) {
/*     */       return;
/*     */     }
/*     */     
/* 101 */     Integer lastID = null;
/* 102 */     for (Integer id : trackIDs) {
/* 103 */       lastID = id;
/*     */     }
/*     */     
/* 106 */     if (null == trackID)
/*     */     {
/* 108 */       trackID = lastID;
/*     */     }
/*     */     
/* 111 */     Iterator<Integer> it = trackIDs.iterator();
/* 112 */     Integer previousTrackID = null;
/* 113 */     while (it.hasNext()) {
/* 114 */       Integer id = it.next();
/* 115 */       if (id.equals(trackID)) {
/* 116 */         if (previousTrackID != null) {
/*     */           break;
/*     */         }
/* 119 */         previousTrackID = lastID;
/*     */         break;
/*     */       } 
/* 122 */       previousTrackID = id;
/*     */     } 
/*     */     
/* 125 */     Set<Spot> spots = this.model.getTrackModel().trackSpots(previousTrackID);
/* 126 */     TreeSet<Spot> ring = new TreeSet<>(Spot.frameComparator);
/* 127 */     ring.addAll(spots);
/* 128 */     Spot target = ring.ceiling(spot);
/* 129 */     if (null == target) {
/* 130 */       target = ring.floor(spot);
/*     */     }
/*     */     
/* 133 */     this.selectionModel.clearSelection();
/* 134 */     this.selectionModel.addSpotToSelection(target);
/*     */   }
/*     */   
/*     */   public synchronized void nextSibling() {
/* 138 */     Spot spot = getASpot();
/* 139 */     if (null == spot) {
/*     */       return;
/*     */     }
/*     */     
/* 143 */     Integer trackID = this.model.getTrackModel().trackIDOf(spot);
/* 144 */     if (null == trackID) {
/*     */       return;
/*     */     }
/*     */     
/* 148 */     int frame = spot.getFeature("FRAME").intValue();
/* 149 */     TreeSet<Spot> ring = new TreeSet<>(Spot.nameComparator);
/*     */     
/* 151 */     Set<Spot> spots = this.model.getTrackModel().trackSpots(trackID);
/* 152 */     for (Spot s : spots) {
/* 153 */       int fs = s.getFeature("FRAME").intValue();
/* 154 */       if (frame == fs && s != spot) {
/* 155 */         ring.add(s);
/*     */       }
/*     */     } 
/*     */     
/* 159 */     if (!ring.isEmpty()) {
/* 160 */       Spot nextSibling = ring.ceiling(spot);
/* 161 */       if (null == nextSibling) {
/* 162 */         nextSibling = ring.first();
/*     */       }
/* 164 */       this.selectionModel.clearSelection();
/* 165 */       this.selectionModel.addSpotToSelection(nextSibling);
/*     */     } 
/*     */   }
/*     */   
/*     */   public synchronized void previousSibling() {
/* 170 */     Spot spot = getASpot();
/* 171 */     if (null == spot) {
/*     */       return;
/*     */     }
/*     */     
/* 175 */     Integer trackID = this.model.getTrackModel().trackIDOf(spot);
/* 176 */     if (null == trackID) {
/*     */       return;
/*     */     }
/*     */     
/* 180 */     int frame = spot.getFeature("FRAME").intValue();
/* 181 */     TreeSet<Spot> ring = new TreeSet<>(Spot.nameComparator);
/*     */     
/* 183 */     Set<Spot> spots = this.model.getTrackModel().trackSpots(trackID);
/* 184 */     for (Spot s : spots) {
/* 185 */       int fs = s.getFeature("FRAME").intValue();
/* 186 */       if (frame == fs && s != spot) {
/* 187 */         ring.add(s);
/*     */       }
/*     */     } 
/*     */     
/* 191 */     if (!ring.isEmpty()) {
/* 192 */       Spot previousSibling = ring.floor(spot);
/* 193 */       if (null == previousSibling) {
/* 194 */         previousSibling = ring.last();
/*     */       }
/* 196 */       this.selectionModel.clearSelection();
/* 197 */       this.selectionModel.addSpotToSelection(previousSibling);
/*     */     } 
/*     */   }
/*     */   
/*     */   public synchronized void previousInTime() {
/* 202 */     Spot spot = getASpot();
/* 203 */     if (null == spot) {
/*     */       return;
/*     */     }
/*     */     
/* 207 */     Set<Spot> predecessors = this.neighborIndex.predecessorsOf(spot);
/* 208 */     if (!predecessors.isEmpty()) {
/* 209 */       Spot next = predecessors.iterator().next();
/* 210 */       this.selectionModel.clearSelection();
/* 211 */       this.selectionModel.addSpotToSelection(next);
/*     */     } 
/*     */   }
/*     */   
/*     */   public synchronized void nextInTime() {
/* 216 */     Spot spot = getASpot();
/* 217 */     if (null == spot) {
/*     */       return;
/*     */     }
/*     */     
/* 221 */     Set<Spot> successors = this.neighborIndex.successorsOf(spot);
/* 222 */     if (!successors.isEmpty()) {
/* 223 */       Spot next = successors.iterator().next();
/* 224 */       this.selectionModel.clearSelection();
/* 225 */       this.selectionModel.addSpotToSelection(next);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Spot getASpot() {
/* 239 */     Set<Spot> spotSelection = this.selectionModel.getSpotSelection();
/* 240 */     if (!spotSelection.isEmpty()) {
/* 241 */       Iterator<Spot> it = spotSelection.iterator();
/* 242 */       Spot spot = it.next();
/* 243 */       int minFrame = spot.getFeature("FRAME").intValue();
/* 244 */       while (it.hasNext()) {
/* 245 */         Spot s = it.next();
/* 246 */         int frame = s.getFeature("FRAME").intValue();
/* 247 */         if (frame < minFrame) {
/* 248 */           minFrame = frame;
/* 249 */           spot = s;
/*     */         } 
/*     */       } 
/* 252 */       return spot;
/*     */     } 
/*     */ 
/*     */     
/* 256 */     Set<DefaultWeightedEdge> edgeSelection = this.selectionModel.getEdgeSelection();
/* 257 */     if (!edgeSelection.isEmpty()) {
/* 258 */       Iterator<DefaultWeightedEdge> it = edgeSelection.iterator();
/* 259 */       DefaultWeightedEdge edge = it.next();
/* 260 */       Spot spot = this.model.getTrackModel().getEdgeSource(edge);
/* 261 */       int minFrame = spot.getFeature("FRAME").intValue();
/* 262 */       while (it.hasNext()) {
/* 263 */         DefaultWeightedEdge e = it.next();
/* 264 */         Spot s = this.model.getTrackModel().getEdgeSource(e);
/* 265 */         int frame = s.getFeature("FRAME").intValue();
/* 266 */         if (frame < minFrame) {
/* 267 */           minFrame = frame;
/* 268 */           spot = s;
/*     */         } 
/*     */       } 
/* 271 */       return spot;
/*     */     } 
/*     */ 
/*     */     
/* 275 */     return null;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/util/TrackNavigator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */