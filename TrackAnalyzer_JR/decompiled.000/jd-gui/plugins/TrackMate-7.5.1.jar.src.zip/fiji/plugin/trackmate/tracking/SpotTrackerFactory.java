package fiji.plugin.trackmate.tracking;

import fiji.plugin.trackmate.Model;
import fiji.plugin.trackmate.SpotCollection;
import fiji.plugin.trackmate.TrackMateModule;
import fiji.plugin.trackmate.gui.components.ConfigurationPanel;
import java.util.Map;
import org.jdom2.Element;

public interface SpotTrackerFactory extends TrackMateModule {
  SpotTracker create(SpotCollection paramSpotCollection, Map<String, Object> paramMap);
  
  ConfigurationPanel getTrackerConfigurationPanel(Model paramModel);
  
  boolean marshall(Map<String, Object> paramMap, Element paramElement);
  
  boolean unmarshall(Element paramElement, Map<String, Object> paramMap);
  
  String toString(Map<String, Object> paramMap);
  
  Map<String, Object> getDefaultSettings();
  
  boolean checkSettingsValidity(Map<String, Object> paramMap);
  
  String getErrorMessage();
  
  SpotTrackerFactory copy();
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/tracking/SpotTrackerFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */