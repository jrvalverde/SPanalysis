/*     */ package fiji.plugin.trackmate.visualization;
/*     */ 
/*     */ import fiji.plugin.trackmate.Model;
/*     */ import fiji.plugin.trackmate.Spot;
/*     */ import ij.ImagePlus;
/*     */ import net.imglib2.FinalInterval;
/*     */ import net.imglib2.Interval;
/*     */ import net.imglib2.RandomAccessible;
/*     */ import net.imglib2.RandomAccessibleInterval;
/*     */ import net.imglib2.img.array.ArrayImgs;
/*     */ import net.imglib2.img.display.imagej.ImageJFunctions;
/*     */ import net.imglib2.view.ExtendedRandomAccessibleInterval;
/*     */ import net.imglib2.view.IntervalView;
/*     */ import net.imglib2.view.Views;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ViewUtils
/*     */ {
/*     */   private static final double TARGET_X_IMAGE_SIZE = 512.0D;
/*     */   private static final double TARGET_Z_IMAGE_SIZE = 128.0D;
/*     */   
/*     */   public static final ImagePlus makeEmptyImagePlus(int width, int height, int nslices, int nframes, double[] calibration) {
/*  50 */     ExtendedRandomAccessibleInterval extendedRandomAccessibleInterval = Views.extendBorder((RandomAccessibleInterval)ArrayImgs.unsignedBytes(new long[] { 1L, 1L, 1L, 1L }));
/*  51 */     FinalInterval finalInterval = new FinalInterval(new long[] { width, height, nslices, nframes });
/*  52 */     IntervalView intervalView = Views.interval((RandomAccessible)extendedRandomAccessibleInterval, (Interval)finalInterval);
/*     */     
/*  54 */     ImagePlus imp = ImageJFunctions.wrap((RandomAccessibleInterval)intervalView, "blank");
/*  55 */     (imp.getCalibration()).pixelWidth = calibration[0];
/*  56 */     (imp.getCalibration()).pixelHeight = calibration[1];
/*  57 */     (imp.getCalibration()).pixelDepth = calibration[2];
/*  58 */     imp.setDimensions(1, nslices, nframes);
/*  59 */     imp.setOpenAsHyperStack(true);
/*     */     
/*  61 */     return imp;
/*     */   }
/*     */   
/*     */   public static final ImagePlus makeEmpytImagePlus(Model model) {
/*     */     int nslices;
/*  66 */     double maxX = 0.0D;
/*  67 */     double maxY = 0.0D;
/*  68 */     double maxZ = 0.0D;
/*  69 */     int nframes = 0;
/*     */     
/*  71 */     for (Spot spot : model.getSpots().iterable(true)) {
/*  72 */       double r = spot.getFeature("RADIUS").doubleValue();
/*  73 */       double x = Math.ceil(r + spot.getFeature("POSITION_X").doubleValue());
/*  74 */       double y = Math.ceil(r + spot.getFeature("POSITION_Y").doubleValue());
/*  75 */       double z = Math.ceil(spot.getFeature("POSITION_Z").doubleValue());
/*  76 */       int t = spot.getFeature("FRAME").intValue();
/*     */       
/*  78 */       if (x > maxX) {
/*  79 */         maxX = x;
/*     */       }
/*  81 */       if (y > maxY) {
/*  82 */         maxY = y;
/*     */       }
/*  84 */       if (z > maxZ) {
/*  85 */         maxZ = z;
/*     */       }
/*  87 */       if (t > nframes) {
/*  88 */         nframes = t;
/*     */       }
/*     */     } 
/*     */     
/*  92 */     double calX = maxX / 512.0D;
/*  93 */     double calY = maxY / 512.0D;
/*  94 */     double calxy = Math.max(calX, calY);
/*  95 */     double calZ = maxZ / 128.0D;
/*     */     
/*  97 */     int width = (int)Math.ceil(maxX / calxy);
/*  98 */     int height = (int)Math.ceil(maxY / calxy);
/*     */     
/* 100 */     if (maxZ == 0.0D) {
/* 101 */       nslices = 1;
/*     */     } else {
/* 103 */       nslices = (int)Math.ceil(maxZ / calZ);
/*     */     } 
/* 105 */     double[] calibration = { calxy, calxy, calZ };
/*     */     
/* 107 */     ImagePlus imp = makeEmptyImagePlus(width, height, nslices, nframes + 1, calibration);
/* 108 */     imp.getCalibration().setUnit(model.getSpaceUnits());
/* 109 */     imp.getCalibration().setTimeUnit(model.getTimeUnits());
/* 110 */     return imp;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/visualization/ViewUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */