/*    */ package fiji.plugin.trackmate.providers;
/*    */ 
/*    */ import fiji.plugin.trackmate.TrackMateModule;
/*    */ import fiji.plugin.trackmate.features.spot.SpotMorphologyAnalyzerFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SpotMorphologyAnalyzerProvider
/*    */   extends AbstractProvider<SpotMorphologyAnalyzerFactory>
/*    */ {
/*    */   private final int nChannels;
/*    */   
/*    */   public SpotMorphologyAnalyzerProvider(int nChannels) {
/* 34 */     super(SpotMorphologyAnalyzerFactory.class);
/* 35 */     this.nChannels = nChannels;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public SpotMorphologyAnalyzerFactory getFactory(String key) {
/* 41 */     SpotMorphologyAnalyzerFactory factory = super.getFactory(key);
/* 42 */     if (factory == null) {
/* 43 */       return null;
/*    */     }
/* 45 */     factory.setNChannels(this.nChannels);
/* 46 */     return factory;
/*    */   }
/*    */ 
/*    */   
/*    */   public static void main(String[] args) {
/* 51 */     SpotMorphologyAnalyzerProvider provider = new SpotMorphologyAnalyzerProvider(2);
/* 52 */     System.out.println(provider.echo());
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/providers/SpotMorphologyAnalyzerProvider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */