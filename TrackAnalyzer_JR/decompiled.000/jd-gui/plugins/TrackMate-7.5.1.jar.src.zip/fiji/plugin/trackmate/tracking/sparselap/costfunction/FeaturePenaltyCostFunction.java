/*    */ package fiji.plugin.trackmate.tracking.sparselap.costfunction;
/*    */ 
/*    */ import fiji.plugin.trackmate.Spot;
/*    */ import java.util.Map;
/*    */ import net.imglib2.RealLocalizable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FeaturePenaltyCostFunction
/*    */   implements CostFunction<Spot, Spot>
/*    */ {
/*    */   private final Map<String, Double> featurePenalties;
/*    */   
/*    */   public FeaturePenaltyCostFunction(Map<String, Double> featurePenalties) {
/* 62 */     this.featurePenalties = featurePenalties;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public double linkingCost(Spot source, Spot target) {
/* 68 */     double d1 = source.squareDistanceTo((RealLocalizable)target);
/* 69 */     double d2 = (d1 == 0.0D) ? 2.2250738585072014E-308D : d1;
/*    */     
/* 71 */     double penalty = 1.0D;
/* 72 */     for (String feature : this.featurePenalties.keySet()) {
/*    */       
/* 74 */       double ndiff = source.normalizeDiffTo(target, feature);
/* 75 */       if (Double.isNaN(ndiff)) {
/*    */         continue;
/*    */       }
/*    */       
/* 79 */       double factor = ((Double)this.featurePenalties.get(feature)).doubleValue();
/* 80 */       penalty += factor * 1.5D * ndiff;
/*    */     } 
/*    */     
/* 83 */     return d2 * penalty * penalty;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/tracking/sparselap/costfunction/FeaturePenaltyCostFunction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */