/*     */ package fiji.plugin.trackmate;
/*     */ 
/*     */ import fiji.plugin.trackmate.gui.GuiUtils;
/*     */ import fiji.plugin.trackmate.gui.Icons;
/*     */ import fiji.plugin.trackmate.gui.displaysettings.DisplaySettings;
/*     */ import fiji.plugin.trackmate.gui.displaysettings.DisplaySettingsIO;
/*     */ import fiji.plugin.trackmate.gui.wizard.TrackMateWizardSequence;
/*     */ import fiji.plugin.trackmate.gui.wizard.WizardSequence;
/*     */ import fiji.plugin.trackmate.io.SettingsPersistence;
/*     */ import fiji.plugin.trackmate.visualization.hyperstack.HyperStackDisplayer;
/*     */ import ij.IJ;
/*     */ import ij.ImageJ;
/*     */ import ij.ImagePlus;
/*     */ import ij.Prefs;
/*     */ import ij.WindowManager;
/*     */ import ij.plugin.PlugIn;
/*     */ import java.awt.Component;
/*     */ import javax.swing.JFrame;
/*     */ import javax.swing.UIManager;
/*     */ import javax.swing.UnsupportedLookAndFeelException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TrackMatePlugIn
/*     */   implements PlugIn
/*     */ {
/*     */   public void run(String imagePath) {
/*     */     ImagePlus imp;
/*  51 */     GuiUtils.setSystemLookAndFeel();
/*     */     
/*  53 */     if (imagePath != null && imagePath.length() > 0) {
/*     */       
/*  55 */       imp = IJ.openImage(imagePath);
/*  56 */       if (imp == null || null == imp.getOriginalFileInfo()) {
/*     */         
/*  58 */         IJ.error("TrackMate v" + TrackMate.PLUGIN_NAME_VERSION, "Could not load image with path " + imagePath + ".");
/*     */ 
/*     */         
/*     */         return;
/*     */       } 
/*     */     } else {
/*  64 */       imp = WindowManager.getCurrentImage();
/*  65 */       if (null == imp) {
/*     */         
/*  67 */         IJ.error("TrackMate v" + TrackMate.PLUGIN_NAME_VERSION, "Please open an image before running TrackMate.");
/*     */         
/*     */         return;
/*     */       } 
/*  71 */       if (imp.getType() == 4) {
/*     */         
/*  73 */         IJ.error("TrackMate v" + TrackMate.PLUGIN_NAME_VERSION, "TrackMate does not work on RGB images.");
/*     */         
/*     */         return;
/*     */       } 
/*     */     } 
/*     */     
/*  79 */     imp.setOpenAsHyperStack(true);
/*  80 */     imp.setDisplayMode(1);
/*  81 */     if (!imp.isVisible()) {
/*  82 */       imp.show();
/*     */     }
/*  84 */     GuiUtils.userCheckImpDimensions(imp);
/*     */ 
/*     */     
/*  87 */     Settings settings = createSettings(imp);
/*  88 */     Model model = createModel(imp);
/*  89 */     TrackMate trackmate = createTrackMate(model, settings);
/*  90 */     SelectionModel selectionModel = new SelectionModel(model);
/*  91 */     DisplaySettings displaySettings = createDisplaySettings();
/*     */ 
/*     */     
/*  94 */     HyperStackDisplayer hyperStackDisplayer = new HyperStackDisplayer(model, selectionModel, imp, displaySettings);
/*  95 */     hyperStackDisplayer.render();
/*     */ 
/*     */     
/*  98 */     WizardSequence sequence = createSequence(trackmate, selectionModel, displaySettings);
/*  99 */     JFrame frame = sequence.run("TrackMate on " + imp.getShortTitle());
/* 100 */     frame.setIconImage(Icons.TRACKMATE_ICON.getImage());
/* 101 */     GuiUtils.positionWindow(frame, (Component)imp.getWindow());
/* 102 */     frame.setVisible(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected WizardSequence createSequence(TrackMate trackmate, SelectionModel selectionModel, DisplaySettings displaySettings) {
/* 117 */     return (WizardSequence)new TrackMateWizardSequence(trackmate, selectionModel, displaySettings);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Model createModel(ImagePlus imp) {
/* 131 */     Model model = new Model();
/* 132 */     model.setPhysicalUnits(imp
/* 133 */         .getCalibration().getUnit(), imp
/* 134 */         .getCalibration().getTimeUnit());
/* 135 */     return model;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Settings createSettings(ImagePlus imp) {
/* 151 */     Settings ls = SettingsPersistence.readLastUsedSettings(imp, Logger.DEFAULT_LOGGER);
/*     */     
/* 153 */     ls.addAllAnalyzers();
/* 154 */     return ls;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected TrackMate createTrackMate(Model model, Settings settings) {
/* 169 */     String spaceUnits = settings.imp.getCalibration().getXUnit();
/* 170 */     String timeUnits = settings.imp.getCalibration().getTimeUnit();
/* 171 */     model.setPhysicalUnits(spaceUnits, timeUnits);
/*     */     
/* 173 */     TrackMate trackmate = new TrackMate(model, settings);
/*     */ 
/*     */     
/* 176 */     trackmate.setNumThreads(Prefs.getThreads());
/*     */     
/* 178 */     return trackmate;
/*     */   }
/*     */ 
/*     */   
/*     */   protected DisplaySettings createDisplaySettings() {
/* 183 */     return DisplaySettingsIO.readUserDefault().copy("CurrentDisplaySettings");
/*     */   }
/*     */ 
/*     */   
/*     */   public static void main(String[] args) throws ClassNotFoundException, InstantiationException, IllegalAccessException, UnsupportedLookAndFeelException {
/* 188 */     UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
/* 189 */     ImageJ.main(args);
/*     */ 
/*     */     
/* 192 */     (new TrackMatePlugIn()).run("samples/MAX_Merged.tif");
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/TrackMatePlugIn.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */