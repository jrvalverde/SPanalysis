/*     */ package fiji.plugin.trackmate.action;
/*     */ 
/*     */ import fiji.plugin.trackmate.Logger;
/*     */ import fiji.plugin.trackmate.Model;
/*     */ import fiji.plugin.trackmate.SelectionModel;
/*     */ import fiji.plugin.trackmate.Spot;
/*     */ import fiji.plugin.trackmate.TrackMate;
/*     */ import fiji.plugin.trackmate.gui.Icons;
/*     */ import fiji.plugin.trackmate.gui.displaysettings.DisplaySettings;
/*     */ import fiji.plugin.trackmate.util.SpotUtil;
/*     */ import fiji.plugin.trackmate.util.TMUtils;
/*     */ import ij.ImagePlus;
/*     */ import java.awt.Frame;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ import javax.swing.ImageIcon;
/*     */ import javax.swing.JOptionPane;
/*     */ import net.imagej.ImgPlus;
/*     */ import net.imagej.ImgPlusMetadata;
/*     */ import net.imagej.axis.Axes;
/*     */ import net.imagej.axis.AxisType;
/*     */ import net.imglib2.Dimensions;
/*     */ import net.imglib2.FinalDimensions;
/*     */ import net.imglib2.RandomAccess;
/*     */ import net.imglib2.RandomAccessibleInterval;
/*     */ import net.imglib2.img.Img;
/*     */ import net.imglib2.img.display.imagej.ImageJFunctions;
/*     */ import net.imglib2.type.NativeType;
/*     */ import net.imglib2.type.numeric.integer.UnsignedShortType;
/*     */ import net.imglib2.util.Util;
/*     */ import net.imglib2.view.Views;
/*     */ import org.scijava.plugin.Plugin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LabelImgExporter
/*     */   extends AbstractTMAction
/*     */ {
/*     */   public static final String INFO_TEXT = "<html>This action creates a label image from the tracking results. <p> A new 16-bit image is generated, of same dimension and size that of the input image. The label image has one channel, with black baground (0 value) everywhere, except where there are spots. Each spot is painted with a uniform integer value equal to the trackID it belongs to. Spots that do not belong to tracks are painted with a unique integer larger than the last trackID in the dataset. <p> Only visible spots are painted. </html>";
/*     */   public static final String KEY = "EXPORT_LABEL_IMG";
/*     */   public static final String NAME = "Export label image";
/*     */   
/*     */   public void execute(TrackMate trackmate, SelectionModel selectionModel, DisplaySettings displaySettings, Frame gui) {
/*     */     boolean exportSpotsAsDots, exportTracksOnly;
/*  86 */     if (gui != null) {
/*     */       
/*  88 */       LabelImgExporterPanel panel = new LabelImgExporterPanel();
/*  89 */       int userInput = JOptionPane.showConfirmDialog(gui, panel, "Export to label image", 2, 3, Icons.TRACKMATE_ICON);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  97 */       if (userInput != 0) {
/*     */         return;
/*     */       }
/* 100 */       exportSpotsAsDots = panel.isExportSpotsAsDots();
/* 101 */       exportTracksOnly = panel.isExportTracksOnly();
/*     */     }
/*     */     else {
/*     */       
/* 105 */       exportSpotsAsDots = false;
/* 106 */       exportTracksOnly = false;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 113 */     createLabelImagePlus(trackmate, exportSpotsAsDots, exportTracksOnly, this.logger).show();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final ImagePlus createLabelImagePlus(TrackMate trackmate, boolean exportSpotsAsDots, boolean exportTracksOnly) {
/* 144 */     return createLabelImagePlus(trackmate, exportSpotsAsDots, exportTracksOnly, Logger.VOID_LOGGER);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final ImagePlus createLabelImagePlus(TrackMate trackmate, boolean exportSpotsAsDots, boolean exportTracksOnly, Logger logger) {
/* 179 */     return createLabelImagePlus(trackmate.getModel(), (trackmate.getSettings()).imp, exportSpotsAsDots, exportTracksOnly, logger);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final ImagePlus createLabelImagePlus(Model model, ImagePlus imp, boolean exportSpotsAsDots, boolean exportTracksOnly) {
/* 211 */     return createLabelImagePlus(model, imp, exportSpotsAsDots, exportTracksOnly, Logger.VOID_LOGGER);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final ImagePlus createLabelImagePlus(Model model, ImagePlus imp, boolean exportSpotsAsDots, boolean exportTracksOnly, Logger logger) {
/* 247 */     int[] dimensions = imp.getDimensions();
/* 248 */     int[] dims = { dimensions[0], dimensions[1], dimensions[3], dimensions[4] };
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 253 */     double[] calibration = { (imp.getCalibration()).pixelWidth, (imp.getCalibration()).pixelHeight, (imp.getCalibration()).pixelDepth, (imp.getCalibration()).frameInterval };
/*     */     
/* 255 */     ImagePlus lblImp = createLabelImagePlus(model, dims, calibration, exportSpotsAsDots, exportTracksOnly, logger);
/* 256 */     lblImp.setCalibration(imp.getCalibration().copy());
/* 257 */     lblImp.setTitle("LblImg_" + imp.getTitle());
/* 258 */     return lblImp;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final ImagePlus createLabelImagePlus(Model model, int[] dimensions, double[] calibration, boolean exportSpotsAsDots, boolean exportTracksOnly) {
/* 291 */     return createLabelImagePlus(model, dimensions, calibration, exportSpotsAsDots, exportTracksOnly, Logger.VOID_LOGGER);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final ImagePlus createLabelImagePlus(Model model, int[] dimensions, double[] calibration, boolean exportSpotsAsDots, boolean exportTracksOnly, Logger logger) {
/* 327 */     long[] dims = new long[4];
/* 328 */     for (int d = 0; d < dims.length; d++) {
/* 329 */       dims[d] = dimensions[d];
/*     */     }
/* 331 */     ImagePlus lblImp = ImageJFunctions.wrap((RandomAccessibleInterval)createLabelImg(model, dims, calibration, exportSpotsAsDots, exportTracksOnly, logger), "LblImage");
/* 332 */     lblImp.setDimensions(1, dimensions[2], dimensions[3]);
/* 333 */     lblImp.setOpenAsHyperStack(true);
/* 334 */     lblImp.resetDisplayRange();
/* 335 */     return lblImp;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final Img<UnsignedShortType> createLabelImg(Model model, long[] dimensions, double[] calibration, boolean exportSpotsAsDots, boolean exportTracksOnly) {
/* 367 */     return createLabelImg(model, dimensions, calibration, exportSpotsAsDots, exportTracksOnly, Logger.VOID_LOGGER);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final Img<UnsignedShortType> createLabelImg(Model model, long[] dimensions, double[] calibration, boolean exportSpotsAsDots, boolean exportTracksOnly, Logger logger) {
/* 406 */     FinalDimensions finalDimensions = FinalDimensions.wrap(dimensions);
/* 407 */     Img<UnsignedShortType> lblImg = Util.getArrayOrCellImgFactory((Dimensions)finalDimensions, (NativeType)new UnsignedShortType()).create((Dimensions)finalDimensions);
/* 408 */     AxisType[] axes = { Axes.X, Axes.Y, Axes.Z, Axes.TIME };
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 413 */     ImgPlus<UnsignedShortType> imgPlus = new ImgPlus(lblImg, "LblImg", axes, calibration);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 419 */     int maxTrackID = -1;
/* 420 */     Set<Integer> trackIDs = model.getTrackModel().trackIDs(false);
/* 421 */     if (null != trackIDs)
/* 422 */       for (Integer trackID : trackIDs) {
/* 423 */         if (trackID.intValue() > maxTrackID)
/* 424 */           maxTrackID = trackID.intValue(); 
/* 425 */       }   AtomicInteger lonelySpotID = new AtomicInteger(maxTrackID + 2);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 431 */     logger.log("Writing label image.\n");
/* 432 */     for (int frame = 0; frame < dimensions[3]; frame++) {
/*     */       
/* 434 */       ImgPlus<UnsignedShortType> imgCT = TMUtils.hyperSlice(imgPlus, 0L, frame);
/* 435 */       SpotWriter spotWriter = exportSpotsAsDots ? new SpotAsDotWriter(imgCT) : new SpotRoiWriter(imgCT);
/*     */ 
/*     */ 
/*     */       
/* 439 */       for (Spot spot : model.getSpots().iterable(frame, true)) {
/*     */         int id;
/*     */         
/* 442 */         Integer trackID = model.getTrackModel().trackIDOf(spot);
/* 443 */         if (null == trackID || !model.getTrackModel().isVisible(trackID)) {
/*     */           
/* 445 */           if (exportTracksOnly) {
/*     */             continue;
/*     */           }
/* 448 */           id = lonelySpotID.getAndIncrement();
/*     */         }
/*     */         else {
/*     */           
/* 452 */           id = 1 + trackID.intValue();
/*     */         } 
/*     */         
/* 455 */         spotWriter.write(spot, id);
/*     */       } 
/* 457 */       logger.setProgress((1 + frame) / dimensions[3]);
/*     */     } 
/* 459 */     logger.log("Done.\n");
/*     */     
/* 461 */     return lblImg;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Plugin(type = TrackMateActionFactory.class)
/*     */   public static class Factory
/*     */     implements TrackMateActionFactory
/*     */   {
/*     */     public String getInfoText() {
/* 471 */       return "<html>This action creates a label image from the tracking results. <p> A new 16-bit image is generated, of same dimension and size that of the input image. The label image has one channel, with black baground (0 value) everywhere, except where there are spots. Each spot is painted with a uniform integer value equal to the trackID it belongs to. Spots that do not belong to tracks are painted with a unique integer larger than the last trackID in the dataset. <p> Only visible spots are painted. </html>";
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public String getKey() {
/* 477 */       return "EXPORT_LABEL_IMG";
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public TrackMateAction create() {
/* 483 */       return new LabelImgExporter();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public ImageIcon getIcon() {
/* 489 */       return Icons.LABEL_IMG_ICON;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public String getName() {
/* 495 */       return "Export label image";
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static interface SpotWriter
/*     */   {
/*     */     void write(Spot param1Spot, int param1Int);
/*     */   }
/*     */ 
/*     */   
/*     */   public static final class SpotRoiWriter
/*     */     implements SpotWriter
/*     */   {
/*     */     private final ImgPlus<UnsignedShortType> img;
/*     */ 
/*     */     
/*     */     public SpotRoiWriter(ImgPlus<UnsignedShortType> img) {
/* 514 */       this.img = img;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void write(Spot spot, int id) {
/* 520 */       for (UnsignedShortType pixel : SpotUtil.iterable(spot, this.img)) {
/* 521 */         pixel.set(id);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static final class SpotAsDotWriter
/*     */     implements SpotWriter
/*     */   {
/*     */     private final double[] calibration;
/*     */     
/*     */     private final long[] center;
/*     */     private final RandomAccess<UnsignedShortType> ra;
/*     */     
/*     */     public SpotAsDotWriter(ImgPlus<UnsignedShortType> img) {
/* 536 */       this.calibration = TMUtils.getSpatialCalibration((ImgPlusMetadata)img);
/* 537 */       this.center = new long[img.numDimensions()];
/* 538 */       this.ra = (RandomAccess<UnsignedShortType>)Views.extendZero((RandomAccessibleInterval)img).randomAccess();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void write(Spot spot, int id) {
/* 544 */       for (int d = 0; d < this.center.length; d++) {
/* 545 */         this.center[d] = Math.round(spot.getFeature(Spot.POSITION_FEATURES[d]).doubleValue() / this.calibration[d]);
/*     */       }
/* 547 */       this.ra.setPosition(this.center);
/* 548 */       ((UnsignedShortType)this.ra.get()).set(id);
/*     */     }
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/action/LabelImgExporter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */