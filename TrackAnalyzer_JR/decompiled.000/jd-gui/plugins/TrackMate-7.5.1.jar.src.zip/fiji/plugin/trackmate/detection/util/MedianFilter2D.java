/*     */ package fiji.plugin.trackmate.detection.util;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import net.imglib2.Cursor;
/*     */ import net.imglib2.Dimensions;
/*     */ import net.imglib2.Interval;
/*     */ import net.imglib2.IterableInterval;
/*     */ import net.imglib2.Localizable;
/*     */ import net.imglib2.RandomAccess;
/*     */ import net.imglib2.RandomAccessible;
/*     */ import net.imglib2.RandomAccessibleInterval;
/*     */ import net.imglib2.algorithm.BenchmarkAlgorithm;
/*     */ import net.imglib2.algorithm.OutputAlgorithm;
/*     */ import net.imglib2.algorithm.neighborhood.Neighborhood;
/*     */ import net.imglib2.algorithm.neighborhood.RectangleShape;
/*     */ import net.imglib2.img.Img;
/*     */ import net.imglib2.img.ImgFactory;
/*     */ import net.imglib2.type.NativeType;
/*     */ import net.imglib2.type.numeric.RealType;
/*     */ import net.imglib2.util.Util;
/*     */ import net.imglib2.view.IntervalView;
/*     */ import net.imglib2.view.Views;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MedianFilter2D<T extends RealType<T> & NativeType<T>>
/*     */   extends BenchmarkAlgorithm
/*     */   implements OutputAlgorithm<Img<T>>
/*     */ {
/*     */   private static final String BASE_ERROR_MSG = "[MedianFiler2D] ";
/*     */   private final RandomAccessibleInterval<T> source;
/*     */   private Img<T> output;
/*     */   private final int radius;
/*     */   
/*     */   public MedianFilter2D(RandomAccessibleInterval<T> source, int radius) {
/*  77 */     this.source = source;
/*  78 */     this.radius = radius;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean checkInput() {
/*  84 */     if (this.source.numDimensions() > 3) {
/*     */       
/*  86 */       this.errorMessage = "[MedianFiler2D]  Can only operate on 1D, 2D or 3D images. Got " + this.source.numDimensions() + "D.";
/*  87 */       return false;
/*     */     } 
/*  89 */     if (this.radius < 1) {
/*     */       
/*  91 */       this.errorMessage = "[MedianFiler2D] Radius cannot be smaller than 1. Got " + this.radius + ".";
/*  92 */       return false;
/*     */     } 
/*  94 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean process() {
/* 100 */     long start = System.currentTimeMillis();
/*     */     
/* 102 */     RealType realType = (RealType)((RealType)this.source.randomAccess().get()).createVariable();
/* 103 */     ImgFactory<T> factory = Util.getArrayOrCellImgFactory((Dimensions)this.source, (NativeType)realType);
/* 104 */     this.output = factory.create((Dimensions)this.source);
/*     */     
/* 106 */     if (this.source.numDimensions() > 2) {
/*     */       
/* 108 */       long nz = this.source.dimension(2); long z;
/* 109 */       for (z = 0L; z < nz; z++)
/*     */       {
/* 111 */         IntervalView<T> slice = Views.hyperSlice(this.source, 2, z);
/* 112 */         IntervalView<T> outputSlice = Views.hyperSlice((RandomAccessibleInterval)this.output, 2, z);
/* 113 */         processSlice((RandomAccessibleInterval<T>)slice, (IterableInterval<T>)outputSlice);
/*     */       }
/*     */     
/*     */     } else {
/*     */       
/* 118 */       processSlice(this.source, (IterableInterval<T>)this.output);
/*     */     } 
/*     */     
/* 121 */     this.processingTime = System.currentTimeMillis() - start;
/* 122 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   private void processSlice(RandomAccessibleInterval<T> in, IterableInterval<T> out) {
/* 127 */     Cursor<T> cursor = out.localizingCursor();
/*     */     
/* 129 */     RectangleShape shape = new RectangleShape(this.radius, false);
/* 130 */     RectangleShape.NeighborhoodsAccessible<T> nracessible = shape.neighborhoodsRandomAccessible((RandomAccessible)Views.extendZero(in));
/* 131 */     RandomAccess<Neighborhood<T>> nra = nracessible.randomAccess((Interval)in);
/*     */     
/* 133 */     int size = (int)((Neighborhood)nra.get()).size();
/* 134 */     double[] values = new double[size];
/*     */ 
/*     */     
/* 137 */     while (cursor.hasNext()) {
/*     */       
/* 139 */       cursor.fwd();
/* 140 */       nra.setPosition((Localizable)cursor);
/* 141 */       int index = 0;
/* 142 */       for (RealType realType : nra.get())
/*     */       {
/* 144 */         values[index++] = realType.getRealDouble();
/*     */       }
/*     */       
/* 147 */       Arrays.sort(values, 0, index);
/* 148 */       ((RealType)cursor.get()).setReal(values[(index - 1) / 2]);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Img<T> getResult() {
/* 155 */     return this.output;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/detection/util/MedianFilter2D.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */