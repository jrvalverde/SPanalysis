/*     */ package fiji.plugin.trackmate.detection.util;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import net.imglib2.Cursor;
/*     */ import net.imglib2.IterableInterval;
/*     */ import net.imglib2.Localizable;
/*     */ import net.imglib2.Positionable;
/*     */ import net.imglib2.RandomAccess;
/*     */ import net.imglib2.RandomAccessibleInterval;
/*     */ import net.imglib2.RealCursor;
/*     */ import net.imglib2.RealPositionable;
/*     */ import net.imglib2.outofbounds.OutOfBoundsFactory;
/*     */ import net.imglib2.view.ExtendedRandomAccessibleInterval;
/*     */ import net.imglib2.view.Views;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SquareNeighborhood3x3<T>
/*     */   implements Positionable, IterableInterval<T>
/*     */ {
/*     */   private RandomAccessibleInterval<T> source;
/*     */   private final long[] center;
/*     */   private final ExtendedRandomAccessibleInterval<T, RandomAccessibleInterval<T>> extendedSource;
/*     */   
/*     */   public SquareNeighborhood3x3(RandomAccessibleInterval<T> source, OutOfBoundsFactory<T, RandomAccessibleInterval<T>> outOfBounds) {
/*  48 */     this.source = source;
/*  49 */     this.center = new long[source.numDimensions()];
/*  50 */     this.extendedSource = Views.extend(source, outOfBounds);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int numDimensions() {
/*  60 */     return this.source.numDimensions();
/*     */   }
/*     */ 
/*     */   
/*     */   public void fwd(int d) {
/*  65 */     this.center[d] = this.center[d] + 1L;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void bck(int d) {
/*  72 */     this.center[d] = this.center[d] - 1L;
/*     */   }
/*     */ 
/*     */   
/*     */   public void move(int distance, int d) {
/*  77 */     this.center[d] = this.center[d] + distance;
/*     */   }
/*     */ 
/*     */   
/*     */   public void move(long distance, int d) {
/*  82 */     this.center[d] = this.center[d] + distance;
/*     */   }
/*     */ 
/*     */   
/*     */   public void move(Localizable localizable) {
/*  87 */     for (int i = 0; i < this.source.numDimensions(); i++) {
/*  88 */       this.center[i] = this.center[i] + localizable.getLongPosition(i);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void move(int[] distance) {
/*  94 */     for (int i = 0; i < distance.length; i++) {
/*  95 */       this.center[i] = this.center[i] + distance[i];
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void move(long[] distance) {
/* 101 */     for (int i = 0; i < distance.length; i++) {
/* 102 */       this.center[i] = this.center[i] + distance[i];
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void setPosition(Localizable localizable) {
/* 108 */     localizable.localize(this.center);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setPosition(int[] position) {
/* 113 */     for (int i = 0; i < position.length; i++) {
/* 114 */       this.center[i] = position[i];
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void setPosition(long[] position) {
/* 120 */     System.arraycopy(position, 0, this.center, 0, this.center.length);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setPosition(int position, int d) {
/* 125 */     this.center[d] = position;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setPosition(long position, int d) {
/* 130 */     this.center[d] = position;
/*     */   }
/*     */ 
/*     */   
/*     */   public long size() {
/* 135 */     return 9L;
/*     */   }
/*     */ 
/*     */   
/*     */   public T firstElement() {
/* 140 */     RandomAccess<T> ra = this.source.randomAccess();
/* 141 */     ra.setPosition(this.center);
/* 142 */     return (T)ra.get();
/*     */   }
/*     */ 
/*     */   
/*     */   public Object iterationOrder() {
/* 147 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public double realMin(int d) {
/* 152 */     return (this.center[d] - 1L);
/*     */   }
/*     */ 
/*     */   
/*     */   public void realMin(double[] min) {
/* 157 */     for (int d = 0; d < min.length; d++) {
/* 158 */       min[d] = (this.center[d] - 1L);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void realMin(RealPositionable min) {
/* 164 */     for (int d = 0; d < this.center.length; d++) {
/* 165 */       min.setPosition(this.center[d] - 1L, d);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public double realMax(int d) {
/* 171 */     return (this.center[d] + 1L);
/*     */   }
/*     */ 
/*     */   
/*     */   public void realMax(double[] max) {
/* 176 */     for (int d = 0; d < max.length; d++) {
/* 177 */       max[d] = (this.center[d] + 1L);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void realMax(RealPositionable max) {
/* 183 */     for (int d = 0; d < this.center.length; d++) {
/* 184 */       max.setPosition(this.center[d] + 1L, d);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public long min(int d) {
/* 190 */     return this.center[d] - 1L;
/*     */   }
/*     */ 
/*     */   
/*     */   public void min(long[] min) {
/* 195 */     for (int d = 0; d < min.length; d++) {
/* 196 */       min[d] = this.center[d] - 1L;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void min(Positionable min) {
/* 202 */     for (int d = 0; d < this.center.length; d++) {
/* 203 */       min.setPosition(this.center[d] - 1L, d);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public long max(int d) {
/* 209 */     return this.center[d] + 1L;
/*     */   }
/*     */ 
/*     */   
/*     */   public void max(long[] max) {
/* 214 */     for (int d = 0; d < max.length; d++) {
/* 215 */       max[d] = this.center[d] + 1L;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void max(Positionable max) {
/* 221 */     for (int d = 0; d < this.center.length; d++) {
/* 222 */       max.setPosition(this.center[d] + 1L, d);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void dimensions(long[] dimensions) {
/* 228 */     dimensions[0] = 3L;
/* 229 */     dimensions[1] = 3L;
/* 230 */     for (int d = 2; d < dimensions.length; d++) {
/* 231 */       dimensions[d] = 1L;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public long dimension(int d) {
/* 238 */     if (d < 2)
/* 239 */       return 3L; 
/* 240 */     return 1L;
/*     */   }
/*     */ 
/*     */   
/*     */   public SquareNeighborhoodCursor3x3<T> cursor() {
/* 245 */     return new SquareNeighborhoodCursor3x3<>(this.extendedSource, this.center);
/*     */   }
/*     */ 
/*     */   
/*     */   public SquareNeighborhoodCursor3x3<T> localizingCursor() {
/* 250 */     return new SquareNeighborhoodCursor3x3<>(this.extendedSource, this.center);
/*     */   }
/*     */ 
/*     */   
/*     */   public Iterator<T> iterator() {
/* 255 */     return (Iterator<T>)new SquareNeighborhoodCursor3x3<>(this.extendedSource, this.center);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/detection/util/SquareNeighborhood3x3.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */