/*     */ package fiji.plugin.trackmate.action.fit;
/*     */ 
/*     */ import fiji.plugin.trackmate.Logger;
/*     */ import fiji.plugin.trackmate.Spot;
/*     */ import fiji.plugin.trackmate.detection.DetectionUtils;
/*     */ import ij.ImagePlus;
/*     */ import net.imglib2.Point;
/*     */ import net.imglib2.util.Util;
/*     */ import org.apache.commons.math3.exception.TooManyEvaluationsException;
/*     */ import org.apache.commons.math3.fitting.leastsquares.LeastSquaresBuilder;
/*     */ import org.apache.commons.math3.fitting.leastsquares.LeastSquaresOptimizer;
/*     */ import org.apache.commons.math3.fitting.leastsquares.LeastSquaresProblem;
/*     */ import org.apache.commons.math3.fitting.leastsquares.MultivariateJacobianFunction;
/*     */ import org.apache.commons.math3.fitting.leastsquares.ParameterValidator;
/*     */ import org.apache.commons.math3.linear.Array2DRowRealMatrix;
/*     */ import org.apache.commons.math3.linear.ArrayRealVector;
/*     */ import org.apache.commons.math3.linear.RealMatrix;
/*     */ import org.apache.commons.math3.linear.RealVector;
/*     */ import org.apache.commons.math3.util.Pair;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SpotGaussianFitter2D
/*     */   extends AbstractSpotFitter
/*     */ {
/*     */   public SpotGaussianFitter2D(ImagePlus imp, int channel) {
/*  51 */     super(imp, channel);
/*  52 */     assert DetectionUtils.is2D(imp);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void process(Iterable<Spot> spots, Logger logger) {
/*  58 */     super.process(spots, logger);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void fit(Spot spot) {
/*  64 */     int frame = spot.getFeature("FRAME").intValue();
/*  65 */     double sigma = spot.getFeature("RADIUS").doubleValue() / Math.sqrt(2.0D);
/*  66 */     double pixelSigma = sigma / this.calibration[0];
/*  67 */     double x0 = spot.getDoublePosition(0) / this.calibration[0];
/*  68 */     double y0 = spot.getDoublePosition(1) / this.calibration[1];
/*  69 */     long span = (long)Math.ceil(2.0D * pixelSigma) + 1L;
/*  70 */     AbstractSpotFitter.Observation obs = gatherObservationData(new Point(new long[] {
/*     */             
/*  72 */             Math.round(x0), 
/*  73 */             Math.round(y0) }, ), new long[] { span, span }, frame);
/*     */ 
/*     */     
/*  76 */     clipBackground(obs);
/*     */     
/*  78 */     double bstart = 1.0D / 2.0D * pixelSigma * pixelSigma;
/*  79 */     double maxSigma = 2.0D * pixelSigma;
/*  80 */     double minB = 1.0D / 2.0D * maxSigma * maxSigma;
/*  81 */     MyGaussian2D gauss = new MyGaussian2D(obs.pos, minB);
/*  82 */     double ampstart = Util.max(obs.values);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  91 */     LeastSquaresProblem lsq = (new LeastSquaresBuilder()).start(new double[] { x0, y0, ampstart, bstart }).model(gauss).parameterValidator(gauss).target(obs.values).lazyEvaluation(false).maxEvaluations(1000).maxIterations(1000).build();
/*     */ 
/*     */     
/*     */     try {
/*  95 */       LeastSquaresOptimizer.Optimum optimum = this.optimizer.optimize(lsq);
/*  96 */       RealVector fit = optimum.getPoint();
/*     */       
/*  98 */       double fitX = fit.getEntry(0) * this.calibration[0];
/*  99 */       double fitY = fit.getEntry(1) * this.calibration[1];
/* 100 */       double fitSigma = 1.0D / Math.sqrt(2.0D * fit.getEntry(3));
/* 101 */       double fitRadius = fitSigma * Math.sqrt(2.0D) * this.calibration[0];
/*     */       
/* 103 */       spot.putFeature("POSITION_X", Double.valueOf(fitX));
/* 104 */       spot.putFeature("POSITION_Y", Double.valueOf(fitY));
/* 105 */       spot.putFeature("RADIUS", Double.valueOf(fitRadius));
/*     */     }
/* 107 */     catch (TooManyEvaluationsException tooManyEvaluationsException) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class MyGaussian2D
/*     */     implements MultivariateJacobianFunction, ParameterValidator
/*     */   {
/*     */     private final long[][] pos;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final double minB;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public MyGaussian2D(long[][] pos, double minB) {
/* 131 */       this.pos = pos;
/* 132 */       this.minB = minB;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Pair<RealVector, RealMatrix> value(RealVector point) {
/* 139 */       double x0 = point.getEntry(0);
/* 140 */       double y0 = point.getEntry(1);
/* 141 */       double A = point.getEntry(2);
/* 142 */       double b = point.getEntry(3);
/*     */ 
/*     */       
/* 145 */       double[] vals = new double[(this.pos[0]).length];
/* 146 */       double[][] grad = new double[(this.pos[0]).length][4];
/* 147 */       for (int i = 0; i < vals.length; i++) {
/*     */         
/* 149 */         long x = this.pos[0][i];
/* 150 */         long y = this.pos[1][i];
/* 151 */         double dx = x - x0;
/* 152 */         double dy = y - y0;
/* 153 */         double sumSq = dx * dx + dy * dy;
/* 154 */         double E = Math.exp(-b * sumSq);
/* 155 */         vals[i] = A * E;
/*     */ 
/*     */         
/* 158 */         grad[i][0] = A * b * E * 2.0D * dx;
/*     */         
/* 160 */         grad[i][1] = A * b * E * 2.0D * dy;
/*     */         
/* 162 */         grad[i][2] = E;
/*     */         
/* 164 */         grad[i][3] = -A * E * sumSq;
/*     */       } 
/* 166 */       ArrayRealVector out = new ArrayRealVector(vals);
/* 167 */       Array2DRowRealMatrix jacobian = new Array2DRowRealMatrix(grad, false);
/* 168 */       return new Pair(out, jacobian);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public RealVector validate(RealVector params) {
/* 174 */       params.setEntry(2, Math.abs(params.getEntry(2)));
/* 175 */       double b = Math.max(this.minB, Math.abs(params.getEntry(3)));
/* 176 */       params.setEntry(3, b);
/* 177 */       return params;
/*     */     }
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/action/fit/SpotGaussianFitter2D.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */