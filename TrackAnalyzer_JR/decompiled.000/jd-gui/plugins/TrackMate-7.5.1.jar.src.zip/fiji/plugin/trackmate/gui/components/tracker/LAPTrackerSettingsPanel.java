/*    */ package fiji.plugin.trackmate.gui.components.tracker;
/*    */ 
/*    */ import fiji.plugin.trackmate.gui.components.ConfigurationPanel;
/*    */ import java.awt.BorderLayout;
/*    */ import java.awt.Dimension;
/*    */ import java.util.Collection;
/*    */ import java.util.Map;
/*    */ import javax.swing.JScrollPane;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LAPTrackerSettingsPanel
/*    */   extends ConfigurationPanel
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private JPanelTrackerSettingsMain jPanelMain;
/*    */   private final String trackerName;
/*    */   private final String spaceUnits;
/*    */   private final Collection<String> features;
/*    */   private final Map<String, String> featureNames;
/*    */   
/*    */   public LAPTrackerSettingsPanel(String trackerName, String spaceUnits, Collection<String> features, Map<String, String> featureNames) {
/* 49 */     this.trackerName = trackerName;
/* 50 */     this.spaceUnits = spaceUnits;
/* 51 */     this.features = features;
/* 52 */     this.featureNames = featureNames;
/* 53 */     initGUI();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Map<String, Object> getSettings() {
/* 62 */     return this.jPanelMain.getSettings();
/*    */   }
/*    */ 
/*    */   
/*    */   public void setSettings(Map<String, Object> settings) {
/* 67 */     this.jPanelMain.echoSettings(settings);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private void initGUI() {
/*    */     try {
/* 76 */       BorderLayout thisLayout = new BorderLayout();
/* 77 */       setPreferredSize(new Dimension(300, 500));
/* 78 */       setLayout(thisLayout);
/*    */       
/* 80 */       JScrollPane jScrollPaneMain = new JScrollPane();
/* 81 */       add(jScrollPaneMain, "Center");
/* 82 */       jScrollPaneMain.setVerticalScrollBarPolicy(22);
/* 83 */       jScrollPaneMain.setHorizontalScrollBarPolicy(31);
/* 84 */       jScrollPaneMain.getVerticalScrollBar().setUnitIncrement(24);
/*    */       
/* 86 */       this.jPanelMain = new JPanelTrackerSettingsMain(this.trackerName, this.spaceUnits, this.features, this.featureNames);
/* 87 */       jScrollPaneMain.setViewportView(this.jPanelMain);
/*    */     
/*    */     }
/* 90 */     catch (Exception e) {
/* 91 */       e.printStackTrace();
/*    */     } 
/*    */   }
/*    */   
/*    */   public void clean() {}
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/gui/components/tracker/LAPTrackerSettingsPanel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */