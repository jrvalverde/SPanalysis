package fiji.plugin.trackmate.tracking.sparselap.costfunction;

public interface CostFunction<K, J> {
  double linkingCost(K paramK, J paramJ);
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/tracking/sparselap/costfunction/CostFunction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */