/*     */ package fiji.plugin.trackmate.visualization.trackscheme;
/*     */ 
/*     */ import com.mxgraph.model.mxCell;
/*     */ import com.mxgraph.model.mxICell;
/*     */ import com.mxgraph.swing.util.mxGraphActions;
/*     */ import com.mxgraph.util.mxEventObject;
/*     */ import com.mxgraph.util.mxEventSource;
/*     */ import com.mxgraph.view.mxGraph;
/*     */ import fiji.plugin.trackmate.gui.Icons;
/*     */ import java.awt.Point;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.geom.Point2D;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import javax.swing.AbstractAction;
/*     */ import javax.swing.Action;
/*     */ import javax.swing.Icon;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TrackSchemeActions
/*     */ {
/*     */   private static final int PAN_AMOUNT = 100;
/*  72 */   private static Action zoomInAction = mxGraphActions.getZoomInAction(); static {
/*  73 */     zoomInAction.putValue("SmallIcon", Icons.ZOOM_IN_ICON);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  80 */   private static Action zoomOutAction = mxGraphActions.getZoomOutAction(); static {
/*  81 */     zoomOutAction.putValue("SmallIcon", Icons.ZOOM_OUT_ICON);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Action getEditAction(TrackSchemeGraphComponent graphComponent) {
/*  89 */     return new EditAction("edit", Icons.EDIT_ICON, graphComponent);
/*     */   }
/*     */ 
/*     */   
/*     */   public static Action getHomeAction(TrackSchemeGraphComponent graphComponent) {
/*  94 */     return new HomeAction("home", Icons.HOME_ICON, graphComponent);
/*     */   }
/*     */ 
/*     */   
/*     */   public static Action getEndAction(TrackSchemeGraphComponent graphComponent) {
/*  99 */     return new EndAction("end", Icons.END_ICON, graphComponent);
/*     */   }
/*     */ 
/*     */   
/*     */   public static Action getResetZoomAction(TrackSchemeGraphComponent graphComponent) {
/* 104 */     return new ResetZoomAction("resetZoom", Icons.RESET_ZOOM_ICON, graphComponent);
/*     */   }
/*     */ 
/*     */   
/*     */   public static Action getZoomInAction(final TrackSchemeGraphComponent graphComponent) {
/* 109 */     return new AbstractAction("zoomIn", Icons.ZOOM_IN_ICON)
/*     */       {
/*     */         private static final long serialVersionUID = 1L;
/*     */ 
/*     */ 
/*     */         
/*     */         public void actionPerformed(ActionEvent e) {
/* 116 */           graphComponent.zoomIn();
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */   
/*     */   public static Action getZoomOutAction(final TrackSchemeGraphComponent graphComponent) {
/* 123 */     return new AbstractAction("zoomOut", Icons.ZOOM_OUT_ICON)
/*     */       {
/*     */         private static final long serialVersionUID = 1L;
/*     */ 
/*     */ 
/*     */         
/*     */         public void actionPerformed(ActionEvent e) {
/* 130 */           graphComponent.zoomOut();
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */   
/*     */   public static Action getSelectNoneAction() {
/* 137 */     return mxGraphActions.getSelectNoneAction();
/*     */   }
/*     */ 
/*     */   
/*     */   public static Action getSelectAllAction() {
/* 142 */     return mxGraphActions.getSelectAllAction();
/*     */   }
/*     */ 
/*     */   
/*     */   public static Action getPanDownAction(TrackSchemeGraphComponent graphComponent) {
/* 147 */     return new PanAction("panDown", Icons.ARROW_DOWN_ICON, graphComponent, 0, 100);
/*     */   }
/*     */ 
/*     */   
/*     */   public static Action getPanLeftAction(TrackSchemeGraphComponent graphComponent) {
/* 152 */     return new PanAction("panLeft", Icons.ARROW_LEFT_ICON, graphComponent, -100, 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public static Action getPanRightAction(TrackSchemeGraphComponent graphComponent) {
/* 157 */     return new PanAction("panRight", Icons.ARROW_RIGHT_ICON, graphComponent, 100, 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public static Action getPanUpAction(TrackSchemeGraphComponent graphComponent) {
/* 162 */     return new PanAction("panUp", Icons.ARROW_UP_ICON, graphComponent, 0, -100);
/*     */   }
/*     */ 
/*     */   
/*     */   public static Action getPanDownLeftAction(TrackSchemeGraphComponent graphComponent) {
/* 167 */     return new PanAction("panDownLeft", Icons.ARROW_DOWNLEFT_ICON, graphComponent, -100, 100);
/*     */   }
/*     */ 
/*     */   
/*     */   public static Action getPanDownRightAction(TrackSchemeGraphComponent graphComponent) {
/* 172 */     return new PanAction("panDownRight", Icons.ARROW_DOWNRIGHT_ICON, graphComponent, 100, 100);
/*     */   }
/*     */ 
/*     */   
/*     */   public static Action getPanUpLeftAction(TrackSchemeGraphComponent graphComponent) {
/* 177 */     return new PanAction("panUpLeft", Icons.ARROW_UPLEFT_ICON, graphComponent, -100, -100);
/*     */   }
/*     */ 
/*     */   
/*     */   public static Action getPanUpRightAction(TrackSchemeGraphComponent graphComponent) {
/* 182 */     return new PanAction("panUpRight", Icons.ARROW_UPRIGHT_ICON, graphComponent, 100, -100);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class PanAction
/*     */     extends AbstractAction
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */ 
/*     */     
/*     */     private final int amountx;
/*     */ 
/*     */     
/*     */     private final int amounty;
/*     */     
/*     */     private final TrackSchemeGraphComponent graphComponent;
/*     */ 
/*     */     
/*     */     public PanAction(String name, Icon icon, TrackSchemeGraphComponent graphComponent, int amountx, int amounty) {
/* 202 */       super(name, icon);
/* 203 */       this.graphComponent = graphComponent;
/* 204 */       this.amountx = amountx;
/* 205 */       this.amounty = amounty;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void actionPerformed(ActionEvent e) {
/* 211 */       Rectangle r = this.graphComponent.getViewport().getViewRect();
/* 212 */       int right = r.x + ((this.amountx < 0) ? 0 : r.width) + this.amountx;
/* 213 */       int bottom = r.y + ((this.amounty < 0) ? 0 : r.height) + this.amounty;
/* 214 */       this.graphComponent.getGraphControl().scrollRectToVisible(new Rectangle(right, bottom, 0, 0));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static class ResetZoomAction
/*     */     extends AbstractAction
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */     
/*     */     private final TrackSchemeGraphComponent graphComponent;
/*     */     
/*     */     public ResetZoomAction(String name, Icon icon, TrackSchemeGraphComponent graphComponent) {
/* 227 */       super(name, icon);
/* 228 */       this.graphComponent = graphComponent;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void actionPerformed(ActionEvent e) {
/* 234 */       this.graphComponent.zoomTo(1.0D, false);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class HomeAction
/*     */     extends AbstractAction
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */ 
/*     */ 
/*     */     
/*     */     private final TrackSchemeGraphComponent graphComponent;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public HomeAction(String name, Icon icon, TrackSchemeGraphComponent graphComponent) {
/* 254 */       super(name, icon);
/* 255 */       this.graphComponent = graphComponent;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void actionPerformed(ActionEvent e) {
/* 262 */       mxCell cell = null;
/* 263 */       JGraphXAdapter graph = this.graphComponent.getGraph();
/* 264 */       List<mxCell> vertices = TrackSchemeActions.getSelectionVertices(graph);
/* 265 */       if (!vertices.isEmpty()) {
/*     */         
/* 267 */         int minFrame = Integer.MAX_VALUE;
/* 268 */         for (mxCell mxCell : vertices) {
/*     */           
/* 270 */           int frame = graph.getSpotFor((mxICell)mxCell).getFeature("FRAME").intValue();
/* 271 */           if (frame < minFrame)
/*     */           {
/* 273 */             minFrame = frame;
/* 274 */             cell = mxCell;
/*     */           }
/*     */         
/*     */         } 
/*     */       } else {
/*     */         
/* 280 */         List<mxCell> edges = TrackSchemeActions.getSelectionEdges(graph);
/* 281 */         if (!edges.isEmpty()) {
/*     */           
/* 283 */           int minFrame = Integer.MAX_VALUE;
/* 284 */           for (mxCell mxCell : edges) {
/*     */             
/* 286 */             mxICell target = mxCell.getTarget();
/* 287 */             int frame = graph.getSpotFor(target).getFeature("FRAME").intValue();
/* 288 */             if (frame < minFrame) {
/*     */               
/* 290 */               minFrame = frame;
/* 291 */               cell = mxCell;
/*     */             } 
/*     */           } 
/* 294 */           cell = edges.get(edges.size() - 1);
/*     */         } else {
/*     */           return;
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 301 */       this.graphComponent.scrollCellToVisible(cell, true);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class EndAction
/*     */     extends AbstractAction
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */ 
/*     */ 
/*     */     
/*     */     private final TrackSchemeGraphComponent graphComponent;
/*     */ 
/*     */ 
/*     */     
/*     */     public EndAction(String name, Icon icon, TrackSchemeGraphComponent graphComponent) {
/* 320 */       super(name, icon);
/* 321 */       this.graphComponent = graphComponent;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void actionPerformed(ActionEvent e) {
/* 327 */       mxCell cell = null;
/* 328 */       JGraphXAdapter graph = this.graphComponent.getGraph();
/* 329 */       List<mxCell> vertices = TrackSchemeActions.getSelectionVertices(graph);
/*     */       
/* 331 */       if (!vertices.isEmpty()) {
/*     */         
/* 333 */         int maxFrame = Integer.MIN_VALUE;
/* 334 */         for (mxCell mxCell : vertices) {
/*     */           
/* 336 */           int frame = graph.getSpotFor((mxICell)mxCell).getFeature("FRAME").intValue();
/* 337 */           if (frame > maxFrame)
/*     */           {
/* 339 */             maxFrame = frame;
/* 340 */             cell = mxCell;
/*     */           }
/*     */         
/*     */         } 
/*     */       } else {
/*     */         
/* 346 */         List<mxCell> edges = TrackSchemeActions.getSelectionEdges(graph);
/* 347 */         if (!edges.isEmpty()) {
/*     */           
/* 349 */           int maxFrame = Integer.MIN_VALUE;
/* 350 */           for (mxCell mxCell : edges) {
/*     */             
/* 352 */             mxICell target = mxCell.getTarget();
/* 353 */             int frame = graph.getSpotFor(target).getFeature("FRAME").intValue();
/* 354 */             if (frame > maxFrame) {
/*     */               
/* 356 */               maxFrame = frame;
/* 357 */               cell = mxCell;
/*     */             } 
/*     */           } 
/* 360 */           cell = edges.get(edges.size() - 1);
/*     */         } else {
/*     */           return;
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 367 */       this.graphComponent.scrollCellToVisible(cell, true);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static class EditAction
/*     */     extends AbstractAction
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */     
/*     */     private final TrackSchemeGraphComponent graphComponent;
/*     */     
/*     */     public EditAction(String name, Icon icon, TrackSchemeGraphComponent graphComponent) {
/* 380 */       super(name, icon);
/* 381 */       this.graphComponent = graphComponent;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void actionPerformed(ActionEvent e) {
/* 387 */       multiEditSpotName(this.graphComponent, e);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private void multiEditSpotName(final TrackSchemeGraphComponent lGraphComponent, ActionEvent triggerEvent) {
/*     */       final mxCell tc;
/* 400 */       final JGraphXAdapter graph = lGraphComponent.getGraph();
/* 401 */       final List<mxCell> vertices = TrackSchemeActions.getSelectionVertices(graph);
/* 402 */       if (vertices.isEmpty())
/*     */         return; 
/* 404 */       Point mousePosition = lGraphComponent.getMousePosition();
/*     */       
/* 406 */       if (null != mousePosition) {
/* 407 */         tc = getClosestCell(vertices, mousePosition);
/*     */       } else {
/* 409 */         tc = vertices.get(0);
/* 410 */       }  vertices.remove(tc);
/*     */       
/* 412 */       lGraphComponent.startEditingAtCell(tc, triggerEvent);
/* 413 */       lGraphComponent.addListener("labelChanged", new mxEventSource.mxIEventListener()
/*     */           {
/*     */ 
/*     */             
/*     */             public void invoke(Object sender, mxEventObject evt)
/*     */             {
/* 419 */               for (mxCell cell : vertices) {
/*     */                 
/* 421 */                 cell.setValue(tc.getValue());
/* 422 */                 graph.getSpotFor((mxICell)cell).setName(tc.getValue().toString());
/*     */               } 
/* 424 */               lGraphComponent.refresh();
/* 425 */               lGraphComponent.removeListener(this);
/*     */             }
/*     */           });
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private mxCell getClosestCell(Iterable<mxCell> vertices, Point2D point) {
/* 438 */       double min_dist = Double.POSITIVE_INFINITY;
/* 439 */       mxCell target_cell = null;
/* 440 */       for (mxCell cell : vertices) {
/*     */         
/* 442 */         Point location = cell.getGeometry().getPoint();
/* 443 */         double dist = location.distanceSq(point);
/* 444 */         if (dist < min_dist) {
/*     */           
/* 446 */           min_dist = dist;
/* 447 */           target_cell = cell;
/*     */         } 
/*     */       } 
/* 450 */       return target_cell;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static List<mxCell> getSelectionVertices(mxGraph graph) {
/* 461 */     Object[] selection = graph.getSelectionCells();
/* 462 */     ArrayList<mxCell> vertices = new ArrayList<>();
/* 463 */     for (Object obj : selection) {
/*     */       
/* 465 */       mxCell cell = (mxCell)obj;
/* 466 */       if (cell.isVertex())
/* 467 */         vertices.add(cell); 
/*     */     } 
/* 469 */     return vertices;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static List<mxCell> getSelectionEdges(mxGraph graph) {
/* 475 */     Object[] selection = graph.getSelectionCells();
/* 476 */     ArrayList<mxCell> edges = new ArrayList<>();
/* 477 */     for (Object obj : selection) {
/*     */       
/* 479 */       mxCell cell = (mxCell)obj;
/* 480 */       if (cell.isEdge())
/* 481 */         edges.add(cell); 
/*     */     } 
/* 483 */     return edges;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/visualization/trackscheme/TrackSchemeActions.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */