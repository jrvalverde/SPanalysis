/*    */ package fiji.plugin.trackmate.visualization;
/*    */ 
/*    */ import fiji.plugin.trackmate.Model;
/*    */ import fiji.plugin.trackmate.ModelChangeListener;
/*    */ import fiji.plugin.trackmate.SelectionChangeEvent;
/*    */ import fiji.plugin.trackmate.SelectionChangeListener;
/*    */ import fiji.plugin.trackmate.SelectionModel;
/*    */ import fiji.plugin.trackmate.Spot;
/*    */ import fiji.plugin.trackmate.gui.displaysettings.DisplaySettings;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractTrackMateModelView
/*    */   implements SelectionChangeListener, TrackMateModelView, ModelChangeListener
/*    */ {
/*    */   protected final Model model;
/*    */   protected final SelectionModel selectionModel;
/*    */   protected final DisplaySettings displaySettings;
/*    */   
/*    */   protected AbstractTrackMateModelView(Model model, SelectionModel selectionModel, DisplaySettings displaySettings) {
/* 61 */     this.selectionModel = selectionModel;
/* 62 */     this.model = model;
/* 63 */     this.displaySettings = displaySettings;
/* 64 */     model.addModelChangeListener(this);
/* 65 */     selectionModel.addSelectionChangeListener(this);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void selectionChanged(SelectionChangeEvent event) {
/* 80 */     Map<Spot, Boolean> spotsAdded = event.getSpots();
/* 81 */     if (spotsAdded != null && spotsAdded.size() == 1) {
/*    */       
/* 83 */       boolean added = ((Boolean)spotsAdded.values().iterator().next()).booleanValue();
/* 84 */       if (added) {
/*    */         
/* 86 */         Spot spot = spotsAdded.keySet().iterator().next();
/* 87 */         centerViewOn(spot);
/*    */       } 
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Model getModel() {
/* 95 */     return this.model;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/visualization/AbstractTrackMateModelView.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */