/*     */ package fiji.plugin.trackmate.gui.components;
/*     */ 
/*     */ import fiji.plugin.trackmate.Spot;
/*     */ import fiji.plugin.trackmate.features.FeatureFilter;
/*     */ import fiji.plugin.trackmate.gui.Fonts;
/*     */ import fiji.plugin.trackmate.util.OnRequestUpdater;
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.LayoutManager;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.function.Function;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.SpringLayout;
/*     */ import javax.swing.event.ChangeEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class InitFilterPanel
/*     */   extends JPanel
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private static final String EXPLANATION_TEXT = "<html><p align=\"justify\">Set here a threshold on the quality feature to restrict the number of spots before calculating other features and rendering. This step can help save time in the case of a very large number of spots. <br/> Warning: the spot filtered here will be discarded: they will not be saved and cannot be retrieved by any other means than re-doing the detection step.</html>";
/*     */   private static final String SELECTED_SPOT_STRING = "Selected spots: %d out of %d";
/*     */   private final OnRequestUpdater updater;
/*     */   private final Function<String, double[]> valueCollector;
/*     */   private final FilterPanel filterPanel;
/*     */   private final JLabel lblSelectedSpots;
/*     */   private double[] values;
/*     */   
/*     */   public InitFilterPanel(FeatureFilter filter, Function<String, double[]> valueCollector) {
/*  70 */     this.valueCollector = valueCollector;
/*  71 */     this.updater = new OnRequestUpdater(() -> thresholdChanged());
/*     */     
/*  73 */     BorderLayout thisLayout = new BorderLayout();
/*  74 */     setLayout(thisLayout);
/*  75 */     setPreferredSize(new Dimension(300, 500));
/*     */     
/*  77 */     JPanel panelFields = new JPanel();
/*  78 */     add(panelFields, "South");
/*  79 */     panelFields.setPreferredSize(new Dimension(300, 100));
/*  80 */     panelFields.setLayout((LayoutManager)null);
/*     */     
/*  82 */     this.lblSelectedSpots = new JLabel("Please wait...");
/*  83 */     panelFields.add(this.lblSelectedSpots);
/*  84 */     this.lblSelectedSpots.setBounds(12, 12, 276, 15);
/*  85 */     this.lblSelectedSpots.setFont(Fonts.FONT);
/*     */     
/*  87 */     JPanel panelText = new JPanel();
/*  88 */     add(panelText, "North");
/*  89 */     panelText.setPreferredSize(new Dimension(300, 200));
/*  90 */     SpringLayout slPanelText = new SpringLayout();
/*  91 */     panelText.setLayout(slPanelText);
/*     */     
/*  93 */     JLabel lblInitialThreshold = new JLabel();
/*  94 */     slPanelText.putConstraint("North", lblInitialThreshold, 12, "North", panelText);
/*  95 */     slPanelText.putConstraint("West", lblInitialThreshold, 12, "West", panelText);
/*  96 */     slPanelText.putConstraint("South", lblInitialThreshold, 27, "North", panelText);
/*  97 */     slPanelText.putConstraint("East", lblInitialThreshold, -12, "East", panelText);
/*  98 */     panelText.add(lblInitialThreshold);
/*  99 */     lblInitialThreshold.setText("Initial thresholding");
/* 100 */     lblInitialThreshold.setFont(Fonts.BIG_FONT);
/*     */     
/* 102 */     JLabel lblExplanation = new JLabel();
/* 103 */     slPanelText.putConstraint("North", lblExplanation, 39, "North", panelText);
/* 104 */     slPanelText.putConstraint("West", lblExplanation, 12, "West", panelText);
/* 105 */     slPanelText.putConstraint("South", lblExplanation, -39, "South", panelText);
/* 106 */     slPanelText.putConstraint("East", lblExplanation, -12, "East", panelText);
/* 107 */     panelText.add(lblExplanation);
/* 108 */     lblExplanation.setText("<html><p align=\"justify\">Set here a threshold on the quality feature to restrict the number of spots before calculating other features and rendering. This step can help save time in the case of a very large number of spots. <br/> Warning: the spot filtered here will be discarded: they will not be saved and cannot be retrieved by any other means than re-doing the detection step.</html>");
/* 109 */     lblExplanation.setFont(Fonts.FONT.deriveFont(2));
/*     */     
/* 111 */     ArrayList<String> keys = new ArrayList<>(1);
/* 112 */     keys.add("QUALITY");
/* 113 */     HashMap<String, String> keyNames = new HashMap<>(1);
/* 114 */     keyNames.put("QUALITY", (String)Spot.FEATURE_NAMES.get("QUALITY"));
/*     */     
/* 116 */     this.filterPanel = new FilterPanel(keyNames, valueCollector, filter);
/* 117 */     this.filterPanel.cmbboxFeatureKeys.setEnabled(false);
/* 118 */     this.filterPanel.rdbtnAbove.setEnabled(false);
/* 119 */     this.filterPanel.rdbtnBelow.setEnabled(false);
/* 120 */     add(this.filterPanel, "Center");
/* 121 */     this.filterPanel.setPreferredSize(new Dimension(300, 200));
/* 122 */     this.filterPanel.addChangeListener(e -> this.updater.doUpdate());
/*     */     
/* 124 */     refresh();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void refresh() {
/* 133 */     this.values = this.valueCollector.apply("QUALITY");
/* 134 */     this.filterPanel.refresh();
/* 135 */     this.updater.doUpdate();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FeatureFilter getFeatureThreshold() {
/* 143 */     return this.filterPanel.getFilter();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void thresholdChanged() {
/* 152 */     FeatureFilter filter = this.filterPanel.getFilter();
/* 153 */     double threshold = filter.value;
/* 154 */     boolean isAbove = filter.isAbove;
/*     */     
/* 156 */     if (null == this.values)
/*     */       return; 
/* 158 */     int nspots = this.values.length;
/* 159 */     int nselected = 0;
/* 160 */     if (isAbove) {
/*     */       
/* 162 */       for (double val : this.values) {
/* 163 */         if (val > threshold) {
/* 164 */           nselected++;
/*     */         }
/*     */       } 
/*     */     } else {
/* 168 */       for (double val : this.values) {
/* 169 */         if (val < threshold)
/* 170 */           nselected++; 
/*     */       } 
/* 172 */     }  this.lblSelectedSpots.setText(String.format("Selected spots: %d out of %d", new Object[] { Integer.valueOf(nselected), Integer.valueOf(nspots) }));
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/gui/components/InitFilterPanel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */