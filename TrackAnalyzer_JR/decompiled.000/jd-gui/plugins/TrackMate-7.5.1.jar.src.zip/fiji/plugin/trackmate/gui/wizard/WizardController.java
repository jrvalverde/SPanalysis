/*     */ package fiji.plugin.trackmate.gui.wizard;
/*     */ 
/*     */ import fiji.plugin.trackmate.gui.Icons;
/*     */ import fiji.plugin.trackmate.util.EverythingDisablerAndReenabler;
/*     */ import java.awt.Container;
/*     */ import java.awt.Frame;
/*     */ import java.awt.event.ActionEvent;
/*     */ import javax.swing.AbstractAction;
/*     */ import javax.swing.Action;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.SwingUtilities;
/*     */ import org.scijava.Cancelable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WizardController
/*     */ {
/*     */   private final WizardSequence sequence;
/*     */   private final WizardPanel wizardPanel;
/*     */   
/*     */   public WizardController(WizardSequence sequence) {
/*  55 */     this.sequence = sequence;
/*  56 */     this.wizardPanel = new WizardPanel();
/*  57 */     this.wizardPanel.btnSave.setAction(getSaveAction());
/*  58 */     this.wizardPanel.btnLog.setAction(getLogAction());
/*  59 */     this.wizardPanel.btnDisplayConfig.setAction(getDisplayConfigAction());
/*  60 */     this.wizardPanel.btnNext.setAction(getNextAction());
/*  61 */     this.wizardPanel.btnPrevious.setAction(getPreviousAction());
/*  62 */     this.wizardPanel.btnCancel.setAction(getCancelAction());
/*  63 */     this.wizardPanel.btnResume.setAction(getResumeAction());
/*  64 */     this.wizardPanel.btnCancel.setVisible(false);
/*  65 */     this.wizardPanel.btnResume.setVisible(false);
/*     */   }
/*     */ 
/*     */   
/*     */   public WizardPanel getWizardPanel() {
/*  70 */     return this.wizardPanel;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void log(boolean show) {
/*  75 */     if (show) {
/*     */       
/*  77 */       (this.sequence.logDescriptor()).targetPanel.setSize((this.sequence.current()).targetPanel.getSize());
/*  78 */       display(this.sequence.logDescriptor(), this.sequence.current(), TransitionAnimator.Direction.TOP);
/*  79 */       this.wizardPanel.btnNext.setEnabled(false);
/*  80 */       this.wizardPanel.btnPrevious.setEnabled(false);
/*  81 */       this.wizardPanel.btnDisplayConfig.setEnabled(false);
/*  82 */       this.wizardPanel.btnCancel.setEnabled(false);
/*  83 */       this.wizardPanel.btnSave.setEnabled(false);
/*     */     
/*     */     }
/*     */     else {
/*     */       
/*  88 */       (this.sequence.current()).targetPanel.setSize((this.sequence.logDescriptor()).targetPanel.getSize());
/*  89 */       display(this.sequence.current(), this.sequence.logDescriptor(), TransitionAnimator.Direction.BOTTOM);
/*  90 */       this.wizardPanel.btnDisplayConfig.setEnabled(true);
/*  91 */       this.wizardPanel.btnCancel.setEnabled(true);
/*  92 */       this.wizardPanel.btnSave.setEnabled(true);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void displayConfig(boolean show) {
/*  98 */     if (show) {
/*     */       
/* 100 */       (this.sequence.configDescriptor()).targetPanel.setSize((this.sequence.current()).targetPanel.getSize());
/* 101 */       display(this.sequence.configDescriptor(), this.sequence.current(), TransitionAnimator.Direction.BOTTOM);
/* 102 */       this.wizardPanel.btnNext.setEnabled(false);
/* 103 */       this.wizardPanel.btnPrevious.setEnabled(false);
/* 104 */       this.wizardPanel.btnLog.setEnabled(false);
/* 105 */       this.wizardPanel.btnCancel.setEnabled(false);
/* 106 */       this.wizardPanel.btnSave.setEnabled(false);
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 111 */       (this.sequence.current()).targetPanel.setSize((this.sequence.configDescriptor()).targetPanel.getSize());
/* 112 */       display(this.sequence.current(), this.sequence.configDescriptor(), TransitionAnimator.Direction.TOP);
/* 113 */       this.wizardPanel.btnLog.setEnabled(true);
/* 114 */       this.wizardPanel.btnCancel.setEnabled(true);
/* 115 */       this.wizardPanel.btnSave.setEnabled(true);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected synchronized void previous() {
/* 122 */     WizardPanelDescriptor current = this.sequence.current();
/* 123 */     if (current == null) {
/*     */       return;
/*     */     }
/* 126 */     current.aboutToHidePanel();
/* 127 */     WizardPanelDescriptor back = this.sequence.previous();
/* 128 */     if (null == back) {
/*     */       return;
/*     */     }
/* 131 */     back.targetPanel.setSize(current.targetPanel.getSize());
/* 132 */     back.aboutToDisplayPanel();
/* 133 */     display(back, current, TransitionAnimator.Direction.LEFT);
/* 134 */     back.displayingPanel();
/* 135 */     exec(back.getBackwardRunnable());
/*     */   }
/*     */ 
/*     */   
/*     */   protected synchronized void next() {
/* 140 */     WizardPanelDescriptor current = this.sequence.current();
/* 141 */     if (current == null) {
/*     */       return;
/*     */     }
/* 144 */     current.aboutToHidePanel();
/* 145 */     WizardPanelDescriptor next = this.sequence.next();
/* 146 */     if (null == next) {
/*     */       return;
/*     */     }
/* 149 */     next.targetPanel.setSize(current.targetPanel.getSize());
/* 150 */     next.aboutToDisplayPanel();
/* 151 */     display(next, current, TransitionAnimator.Direction.RIGHT);
/* 152 */     next.displayingPanel();
/* 153 */     exec(next.getForwardRunnable());
/*     */   }
/*     */ 
/*     */   
/*     */   protected void cancel() {
/* 158 */     Cancelable cancelable = this.sequence.current().getCancelable();
/* 159 */     if (null != cancelable) {
/* 160 */       cancelable.cancel("User pressed cancel button.");
/*     */     }
/*     */   }
/*     */   
/*     */   protected void finish() {
/* 165 */     Container container = this.wizardPanel;
/* 166 */     while (!(container instanceof Frame)) {
/* 167 */       container = container.getParent();
/*     */     }
/* 169 */     ((Frame)container).dispose();
/*     */   }
/*     */ 
/*     */   
/*     */   private void exec(final Runnable runnable) {
/* 174 */     if (null == runnable) {
/*     */       return;
/*     */     }
/* 177 */     final EverythingDisablerAndReenabler reenabler = new EverythingDisablerAndReenabler(this.wizardPanel.panelButtons, new Class[] { JLabel.class });
/*     */     
/* 179 */     (new Thread("Wizard exec thread")
/*     */       {
/*     */ 
/*     */         
/*     */         public void run()
/*     */         {
/*     */           try {
/* 186 */             reenabler.disable();
/*     */             
/* 188 */             Thread.sleep(200L);
/* 189 */             WizardController.this.wizardPanel.btnNext.setVisible(false);
/* 190 */             WizardController.this.wizardPanel.btnCancel.setVisible(true);
/* 191 */             WizardController.this.wizardPanel.btnCancel.setEnabled(true);
/* 192 */             runnable.run();
/*     */           }
/* 194 */           catch (InterruptedException e) {
/*     */             
/* 196 */             e.printStackTrace();
/*     */           }
/*     */           finally {
/*     */             
/* 200 */             WizardController.this.wizardPanel.btnCancel.setVisible(false);
/* 201 */             WizardController.this.wizardPanel.btnNext.setVisible(true);
/* 202 */             WizardController.this.wizardPanel.btnNext.requestFocusInWindow();
/* 203 */             reenabler.reenable();
/*     */           } 
/*     */         }
/* 206 */       }).start();
/*     */   }
/*     */ 
/*     */   
/*     */   public void init() {
/* 211 */     WizardPanelDescriptor descriptor = this.sequence.current();
/* 212 */     this.wizardPanel.btnPrevious.setEnabled(this.sequence.hasPrevious());
/* 213 */     this.wizardPanel.btnNext.setEnabled(this.sequence.hasNext());
/* 214 */     descriptor.aboutToDisplayPanel();
/* 215 */     this.wizardPanel.display(descriptor);
/* 216 */     descriptor.displayingPanel();
/* 217 */     SwingUtilities.invokeLater(() -> this.wizardPanel.btnNext.requestFocusInWindow());
/*     */   }
/*     */ 
/*     */   
/*     */   protected void save() {
/* 222 */     WizardPanelDescriptor saveDescriptor = this.sequence.save();
/* 223 */     saveDescriptor.targetPanel.setSize((this.sequence.current()).targetPanel.getSize());
/* 224 */     this.wizardPanel.btnSave.setVisible(false);
/* 225 */     this.wizardPanel.btnPrevious.setVisible(false);
/* 226 */     this.wizardPanel.btnDisplayConfig.setVisible(false);
/* 227 */     this.wizardPanel.btnLog.setVisible(false);
/* 228 */     this.wizardPanel.btnNext.setVisible(false);
/* 229 */     this.wizardPanel.btnResume.setVisible(true);
/*     */     
/* 231 */     display(saveDescriptor, this.sequence.current(), TransitionAnimator.Direction.BOTTOM);
/* 232 */     (new Thread(() -> {
/*     */ 
/*     */           
/*     */           try {
/*     */             Thread.sleep(250L);
/* 237 */           } catch (InterruptedException e) {
/*     */             e.printStackTrace();
/*     */           } 
/*     */           
/*     */           saveDescriptor.aboutToDisplayPanel();
/*     */           saveDescriptor.displayingPanel();
/* 243 */         })).start();
/*     */   }
/*     */ 
/*     */   
/*     */   protected void resume() {
/* 248 */     WizardPanelDescriptor saveDescriptor = this.sequence.save();
/*     */     
/*     */     try {
/* 251 */       saveDescriptor.aboutToHidePanel();
/*     */     }
/*     */     finally {
/*     */       
/* 255 */       this.wizardPanel.btnResume.setVisible(false);
/* 256 */       this.wizardPanel.btnSave.setVisible(true);
/* 257 */       this.wizardPanel.btnPrevious.setVisible(true);
/* 258 */       this.wizardPanel.btnDisplayConfig.setVisible(true);
/* 259 */       this.wizardPanel.btnLog.setVisible(true);
/* 260 */       this.wizardPanel.btnNext.setVisible(true);
/* 261 */       (this.sequence.current()).targetPanel.setSize(saveDescriptor.targetPanel.getSize());
/* 262 */       display(this.sequence.current(), saveDescriptor, TransitionAnimator.Direction.TOP);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void display(WizardPanelDescriptor to, WizardPanelDescriptor from, TransitionAnimator.Direction direction) {
/* 268 */     if (null == to) {
/*     */       return;
/*     */     }
/* 271 */     this.wizardPanel.btnPrevious.setEnabled(this.sequence.hasPrevious());
/* 272 */     this.wizardPanel.btnNext.setEnabled(this.sequence.hasNext());
/* 273 */     this.wizardPanel.transition(to, from, direction);
/*     */   }
/*     */ 
/*     */   
/*     */   private Action getNextAction() {
/* 278 */     AbstractAction nextAction = new AbstractAction("Next")
/*     */       {
/*     */         private static final long serialVersionUID = 1L;
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         public void actionPerformed(ActionEvent e) {
/* 286 */           WizardController.this.next();
/*     */         }
/*     */       };
/* 289 */     nextAction.putValue("SmallIcon", Icons.NEXT_ICON);
/* 290 */     return nextAction;
/*     */   }
/*     */ 
/*     */   
/*     */   private Action getPreviousAction() {
/* 295 */     AbstractAction previousAction = new AbstractAction("Previous")
/*     */       {
/*     */         private static final long serialVersionUID = 1L;
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         public void actionPerformed(ActionEvent e) {
/* 303 */           WizardController.this.previous();
/*     */         }
/*     */       };
/* 306 */     previousAction.putValue("Name", "");
/* 307 */     previousAction.putValue("SmallIcon", Icons.PREVIOUS_ICON);
/* 308 */     return previousAction;
/*     */   }
/*     */ 
/*     */   
/*     */   private Action getLogAction() {
/* 313 */     AbstractAction logAction = new AbstractAction("Log")
/*     */       {
/*     */         private static final long serialVersionUID = 1L;
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         public void actionPerformed(ActionEvent e) {
/* 321 */           WizardController.this.log(WizardController.this.wizardPanel.btnLog.isSelected());
/*     */         }
/*     */       };
/* 324 */     logAction.putValue("SmallIcon", Icons.LOG_ICON);
/* 325 */     logAction.putValue("Name", "");
/* 326 */     return logAction;
/*     */   }
/*     */ 
/*     */   
/*     */   private Action getCancelAction() {
/* 331 */     AbstractAction cancelAction = new AbstractAction("Cancel")
/*     */       {
/*     */         private static final long serialVersionUID = 1L;
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         public void actionPerformed(ActionEvent e) {
/* 339 */           WizardController.this.cancel();
/*     */         }
/*     */       };
/* 342 */     cancelAction.putValue("SmallIcon", Icons.CANCEL_ICON);
/* 343 */     return cancelAction;
/*     */   }
/*     */ 
/*     */   
/*     */   private Action getSaveAction() {
/* 348 */     AbstractAction saveAction = new AbstractAction("Save")
/*     */       {
/*     */         private static final long serialVersionUID = 1L;
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         public void actionPerformed(ActionEvent e) {
/* 356 */           WizardController.this.save();
/*     */         }
/*     */       };
/* 359 */     saveAction.putValue("SmallIcon", Icons.SAVE_ICON);
/* 360 */     return saveAction;
/*     */   }
/*     */ 
/*     */   
/*     */   private Action getResumeAction() {
/* 365 */     AbstractAction resumeAction = new AbstractAction("Resume")
/*     */       {
/*     */         private static final long serialVersionUID = 1L;
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         public void actionPerformed(ActionEvent e) {
/* 373 */           WizardController.this.resume();
/*     */         }
/*     */       };
/* 376 */     resumeAction.putValue("SmallIcon", Icons.REVERT_ICON);
/* 377 */     return resumeAction;
/*     */   }
/*     */ 
/*     */   
/*     */   private Action getDisplayConfigAction() {
/* 382 */     AbstractAction configAction = new AbstractAction("DisplayConfig")
/*     */       {
/*     */         private static final long serialVersionUID = 1L;
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         public void actionPerformed(ActionEvent e) {
/* 390 */           WizardController.this.displayConfig(WizardController.this.wizardPanel.btnDisplayConfig.isSelected());
/*     */         }
/*     */       };
/* 393 */     configAction.putValue("SmallIcon", Icons.DISPLAY_CONFIG_ICON);
/* 394 */     configAction.putValue("Name", "");
/* 395 */     return configAction;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/gui/wizard/WizardController.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */