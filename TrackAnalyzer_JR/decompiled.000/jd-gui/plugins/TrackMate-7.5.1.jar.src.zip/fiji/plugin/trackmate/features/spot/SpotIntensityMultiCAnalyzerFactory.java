/*     */ package fiji.plugin.trackmate.features.spot;
/*     */ 
/*     */ import fiji.plugin.trackmate.Dimension;
/*     */ import fiji.plugin.trackmate.util.TMUtils;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.swing.ImageIcon;
/*     */ import net.imagej.ImgPlus;
/*     */ import net.imglib2.type.NativeType;
/*     */ import net.imglib2.type.numeric.RealType;
/*     */ import org.scijava.plugin.Plugin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Plugin(type = SpotAnalyzerFactory.class)
/*     */ public class SpotIntensityMultiCAnalyzerFactory<T extends RealType<T> & NativeType<T>>
/*     */   implements SpotAnalyzerFactory<T>
/*     */ {
/*     */   private static final String KEY = "Spot intensity";
/*     */   static final String MEAN_INTENSITY = "MEAN_INTENSITY_CH";
/*     */   static final String MEDIAN_INTENSITY = "MEDIAN_INTENSITY_CH";
/*     */   static final String MIN_INTENSITY = "MIN_INTENSITY_CH";
/*     */   static final String MAX_INTENSITY = "MAX_INTENSITY_CH";
/*     */   static final String TOTAL_INTENSITY = "TOTAL_INTENSITY_CH";
/*     */   static final String STD_INTENSITY = "STD_INTENSITY_CH";
/*     */   private static final String MEAN_SHORT_NAME = "Mean ch";
/*     */   private static final String MEAN_NAME = "Mean intensity ch";
/*     */   private static final String MEDIAN_SHORT_NAME = "Median ch";
/*     */   private static final String MEDIAN_NAME = "Median intensity ch";
/*     */   private static final String MIN_SHORT_NAME = "Min ch";
/*     */   private static final String MIN_NAME = "Min intensity ch";
/*     */   private static final String MAX_SHORT_NAME = "Max ch";
/*     */   private static final String MAX_NAME = "Max intensity ch";
/*     */   private static final String SUM_SHORT_NAME = "Sum ch";
/*     */   private static final String SUM_NAME = "Sum intensity ch";
/*     */   private static final String STD_SHORT_NAME = "Std ch";
/*     */   private static final String STD_NAME = "Std intensity ch";
/*  66 */   private static final List<String> FEATURES = Arrays.asList(new String[] { "MEAN_INTENSITY_CH", "MEDIAN_INTENSITY_CH", "MIN_INTENSITY_CH", "MAX_INTENSITY_CH", "TOTAL_INTENSITY_CH", "STD_INTENSITY_CH" });
/*     */   
/*  68 */   private static final List<String> FEATURE_SHORTNAMES = Arrays.asList(new String[] { "Mean ch", "Median ch", "Min ch", "Max ch", "Sum ch", "Std ch" });
/*     */   
/*  70 */   private static final List<String> FEATURE_NAMES = Arrays.asList(new String[] { "Mean intensity ch", "Median intensity ch", "Min intensity ch", "Max intensity ch", "Sum intensity ch", "Std intensity ch" });
/*     */ 
/*     */   
/*  73 */   private int nChannels = 1;
/*     */ 
/*     */ 
/*     */   
/*     */   public void setNChannels(int nChannels) {
/*  78 */     this.nChannels = nChannels;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SpotAnalyzer<T> getAnalyzer(ImgPlus<T> img, int frame, int channel) {
/*  85 */     ImgPlus<T> imgTC = TMUtils.hyperSlice(img, channel, frame);
/*  86 */     return (SpotAnalyzer)new SpotIntensityMultiCAnalyzer<>(imgTC, channel);
/*     */   }
/*     */ 
/*     */   
/*     */   static final String makeFeatureKey(String feature, int c) {
/*  91 */     return feature + (c + 1);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public List<String> getFeatures() {
/*  97 */     List<String> features = new ArrayList<>(this.nChannels * FEATURES.size());
/*  98 */     for (int c = 0; c < this.nChannels; c++) {
/*  99 */       for (String feature : FEATURES)
/* 100 */         features.add(makeFeatureKey(feature, c)); 
/*     */     } 
/* 102 */     return features;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, String> getFeatureShortNames() {
/* 108 */     Map<String, String> names = new LinkedHashMap<>(this.nChannels * FEATURES.size());
/* 109 */     for (int c = 0; c < this.nChannels; c++) {
/* 110 */       for (int i = 0; i < FEATURES.size(); i++) {
/*     */         
/* 112 */         String feature = FEATURES.get(i);
/* 113 */         String shortName = FEATURE_SHORTNAMES.get(i);
/* 114 */         names.put(makeFeatureKey(feature, c), makeFeatureKey(shortName, c));
/*     */       } 
/*     */     } 
/* 117 */     return names;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, String> getFeatureNames() {
/* 123 */     Map<String, String> names = new LinkedHashMap<>(this.nChannels * FEATURES.size());
/* 124 */     for (int c = 0; c < this.nChannels; c++) {
/* 125 */       for (int i = 0; i < FEATURES.size(); i++) {
/*     */         
/* 127 */         String feature = FEATURES.get(i);
/* 128 */         String shortName = FEATURE_NAMES.get(i);
/* 129 */         names.put(makeFeatureKey(feature, c), makeFeatureKey(shortName, c));
/*     */       } 
/*     */     } 
/* 132 */     return names;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, Dimension> getFeatureDimensions() {
/* 138 */     List<String> features = getFeatures();
/* 139 */     Map<String, Dimension> dimensions = new LinkedHashMap<>(features.size());
/* 140 */     for (String feature : features) {
/* 141 */       dimensions.put(feature, Dimension.INTENSITY);
/*     */     }
/* 143 */     return dimensions;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, Boolean> getIsIntFeature() {
/* 149 */     List<String> features = getFeatures();
/* 150 */     Map<String, Boolean> isints = new LinkedHashMap<>(features.size());
/* 151 */     for (String feature : features) {
/* 152 */       isints.put(feature, Boolean.FALSE);
/*     */     }
/* 154 */     return isints;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isManualFeature() {
/* 160 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getInfoText() {
/* 166 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ImageIcon getIcon() {
/* 172 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getKey() {
/* 178 */     return "Spot intensity";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/* 184 */     return "Spot intensity";
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/features/spot/SpotIntensityMultiCAnalyzerFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */