/*     */ package fiji.plugin.trackmate.action;
/*     */ 
/*     */ import fiji.plugin.trackmate.Logger;
/*     */ import fiji.plugin.trackmate.SelectionModel;
/*     */ import fiji.plugin.trackmate.Spot;
/*     */ import fiji.plugin.trackmate.SpotRoi;
/*     */ import fiji.plugin.trackmate.TrackMate;
/*     */ import fiji.plugin.trackmate.detection.DetectionUtils;
/*     */ import fiji.plugin.trackmate.gui.Icons;
/*     */ import fiji.plugin.trackmate.gui.displaysettings.DisplaySettings;
/*     */ import ij.ImagePlus;
/*     */ import ij.gui.GenericDialog;
/*     */ import ij.gui.OvalRoi;
/*     */ import ij.gui.PolygonRoi;
/*     */ import ij.gui.Roi;
/*     */ import ij.plugin.frame.RoiManager;
/*     */ import java.awt.Frame;
/*     */ import java.util.Arrays;
/*     */ import javax.swing.ImageIcon;
/*     */ import org.scijava.plugin.Plugin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IJRoiExporter
/*     */ {
/*     */   private final Logger logger;
/*     */   private final RoiManager roiManager;
/*     */   private final double dx;
/*     */   private final double dy;
/*     */   private final double dz;
/*     */   private final boolean is2D;
/*     */   
/*     */   public IJRoiExporter(ImagePlus imp, Logger logger) {
/*  63 */     this.dx = (imp.getCalibration()).pixelWidth;
/*  64 */     this.dy = (imp.getCalibration()).pixelHeight;
/*  65 */     this.dz = (imp.getCalibration()).pixelDepth;
/*  66 */     this.is2D = DetectionUtils.is2D(imp);
/*  67 */     this.logger = logger;
/*  68 */     this.roiManager = RoiManager.getRoiManager();
/*     */   }
/*     */ 
/*     */   
/*     */   public void export(Iterable<Spot> spots) {
/*  73 */     int nspots = count(spots);
/*  74 */     this.logger.log("Exporting " + nspots + " spots to ImageJ ROIs.\n");
/*  75 */     this.logger.setStatus("Exporting");
/*  76 */     int index = 0;
/*  77 */     for (Spot spot : spots) {
/*     */       
/*  79 */       export(spot);
/*  80 */       this.logger.setProgress(index++ / nspots);
/*     */     } 
/*  82 */     this.logger.setProgress(1.0D);
/*  83 */     this.logger.setStatus("");
/*  84 */     this.logger.log("Done.\n");
/*     */   }
/*     */   
/*     */   public void export(Spot spot) {
/*     */     OvalRoi ovalRoi;
/*  89 */     SpotRoi sroi = spot.getRoi();
/*     */     
/*  91 */     if (sroi != null) {
/*     */       
/*  93 */       double[] xs = sroi.toPolygonX(this.dx, 0.0D, spot.getDoublePosition(0), 1.0D);
/*  94 */       double[] ys = sroi.toPolygonY(this.dy, 0.0D, spot.getDoublePosition(1), 1.0D);
/*  95 */       float[] xp = toFloat(xs);
/*  96 */       float[] yp = toFloat(ys);
/*  97 */       PolygonRoi polygonRoi = new PolygonRoi(xp, yp, 2);
/*     */     }
/*     */     else {
/*     */       
/* 101 */       double diameter = 2.0D * spot.getFeature("RADIUS").doubleValue() / this.dx;
/* 102 */       double xs = spot.getDoublePosition(0) / this.dx - diameter / 2.0D + 0.5D;
/* 103 */       double ys = spot.getDoublePosition(1) / this.dy - diameter / 2.0D + 0.5D;
/* 104 */       ovalRoi = new OvalRoi(xs, ys, diameter, diameter);
/*     */     } 
/*     */     
/* 107 */     int z = this.is2D ? 0 : (1 + (int)Math.round(spot.getDoublePosition(2) / this.dz));
/* 108 */     int frame = 1 + spot.getFeature("FRAME").intValue();
/* 109 */     ovalRoi.setPosition(0, z, frame);
/* 110 */     ovalRoi.setName(spot.getName());
/* 111 */     this.roiManager.addRoi((Roi)ovalRoi);
/*     */   }
/*     */ 
/*     */   
/*     */   private static final float[] toFloat(double[] d) {
/* 116 */     float[] f = new float[d.length];
/* 117 */     for (int i = 0; i < f.length; i++)
/* 118 */       f[i] = (float)d[i]; 
/* 119 */     return f;
/*     */   }
/*     */ 
/*     */   
/*     */   private static final int count(Iterable<Spot> spots) {
/* 124 */     int count = 0;
/*     */     
/* 126 */     for (Spot spot : spots)
/* 127 */       count++; 
/* 128 */     return count;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static class IJRoiExporterAction
/*     */     extends AbstractTMAction
/*     */   {
/*     */     public void execute(TrackMate trackmate, SelectionModel selectionModel, DisplaySettings displaySettings, Frame parent) {
/*     */       Iterable<Spot> spots;
/* 138 */       GenericDialog dialog = new GenericDialog("Export spots to IJ ROIs", parent);
/*     */       
/* 140 */       dialog.addMessage("Export to IJ ROIs for:");
/* 141 */       String[] choices = { "All spots", "Selection", "Tracks of selection" };
/* 142 */       dialog.addRadioButtonGroup("Dimensionality:", choices, 2, 1, choices[1]);
/*     */ 
/*     */       
/* 145 */       dialog.showDialog();
/* 146 */       if (dialog.wasCanceled()) {
/*     */         return;
/*     */       }
/*     */ 
/*     */       
/* 151 */       int choice = Arrays.<String>asList(choices).indexOf(dialog.getNextRadioButton());
/* 152 */       if (choice == 0) {
/* 153 */         spots = trackmate.getModel().getSpots().iterable(true);
/* 154 */       } else if (choice == 1) {
/* 155 */         spots = selectionModel.getSpotSelection();
/*     */       } else {
/*     */         
/* 158 */         selectionModel.selectTrack(selectionModel
/* 159 */             .getSpotSelection(), selectionModel
/* 160 */             .getEdgeSelection(), 0);
/* 161 */         spots = selectionModel.getSpotSelection();
/*     */       } 
/*     */       
/* 164 */       IJRoiExporter exporter = new IJRoiExporter((trackmate.getSettings()).imp, this.logger);
/* 165 */       exporter.export(spots);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Plugin(type = TrackMateActionFactory.class)
/*     */   public static class IJRoiExporterActionFactory
/*     */     implements TrackMateActionFactory
/*     */   {
/*     */     private static final String INFO_TEXT = "<html>Export the spots to ImageJ ROIs and store them in the ROI manager. <p>Spots with ROIs are exported as polygon-ROIs. Other spots are exported as an oval spot, located in a single Z-plane at the spot center. </html>";
/*     */ 
/*     */     
/*     */     private static final String NAME = "Export spots to IJ ROIs";
/*     */ 
/*     */     
/*     */     private static final String KEY = "EXPORT_TO_ROIS";
/*     */ 
/*     */ 
/*     */     
/*     */     public String getInfoText() {
/* 187 */       return "<html>Export the spots to ImageJ ROIs and store them in the ROI manager. <p>Spots with ROIs are exported as polygon-ROIs. Other spots are exported as an oval spot, located in a single Z-plane at the spot center. </html>";
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public String getName() {
/* 193 */       return "Export spots to IJ ROIs";
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public String getKey() {
/* 199 */       return "EXPORT_TO_ROIS";
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public ImageIcon getIcon() {
/* 205 */       return Icons.ORANGE_ASTERISK_ICON;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public TrackMateAction create() {
/* 211 */       return new IJRoiExporter.IJRoiExporterAction();
/*     */     }
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/action/IJRoiExporter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */