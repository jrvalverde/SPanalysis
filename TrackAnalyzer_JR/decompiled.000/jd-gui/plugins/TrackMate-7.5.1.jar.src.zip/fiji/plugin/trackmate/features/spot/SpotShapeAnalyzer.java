/*    */ package fiji.plugin.trackmate.features.spot;
/*    */ 
/*    */ import fiji.plugin.trackmate.Spot;
/*    */ import fiji.plugin.trackmate.SpotRoi;
/*    */ import net.imglib2.type.numeric.RealType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SpotShapeAnalyzer<T extends RealType<T>>
/*    */   extends AbstractSpotFeatureAnalyzer<T>
/*    */ {
/*    */   private final boolean is2D;
/*    */   
/*    */   public SpotShapeAnalyzer(boolean is2D) {
/* 35 */     this.is2D = is2D;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void process(Spot spot) {
/*    */     double area, convexArea, perimeter;
/* 45 */     if (this.is2D) {
/*    */       
/* 47 */       SpotRoi roi = spot.getRoi();
/* 48 */       if (roi != null)
/*    */       {
/* 50 */         area = roi.area();
/* 51 */         perimeter = getLength(roi);
/* 52 */         SpotRoi convexHull = ConvexHull.convexHull(roi);
/* 53 */         convexArea = convexHull.area();
/*    */       }
/*    */       else
/*    */       {
/* 57 */         double radius = spot.getFeature("RADIUS").doubleValue();
/* 58 */         area = Math.PI * radius * radius;
/* 59 */         convexArea = area;
/* 60 */         perimeter = 6.283185307179586D * radius;
/*    */       }
/*    */     
/*    */     } else {
/*    */       
/* 65 */       double radius = spot.getFeature("RADIUS").doubleValue();
/* 66 */       area = 12.566370614359172D * radius * radius;
/* 67 */       convexArea = area;
/* 68 */       perimeter = Double.NaN;
/*    */     } 
/* 70 */     double circularity = 12.566370614359172D * area / perimeter * perimeter;
/* 71 */     double solidity = area / convexArea;
/*    */     
/* 73 */     spot.putFeature("AREA", Double.valueOf(area));
/* 74 */     spot.putFeature("PERIMETER", Double.valueOf(perimeter));
/* 75 */     spot.putFeature("CIRCULARITY", Double.valueOf(circularity));
/* 76 */     spot.putFeature("SOLIDITY", Double.valueOf(solidity));
/*    */   }
/*    */ 
/*    */   
/*    */   private static final double getLength(SpotRoi roi) {
/* 81 */     double[] x = roi.x;
/* 82 */     double[] y = roi.y;
/* 83 */     int npoints = x.length;
/* 84 */     if (npoints < 2) {
/* 85 */       return 0.0D;
/*    */     }
/* 87 */     double length = 0.0D;
/* 88 */     for (int i = 0; i < npoints - 1; i++) {
/*    */       
/* 90 */       double dx = x[i + 1] - x[i];
/* 91 */       double dy = y[i + 1] - y[i];
/* 92 */       length += Math.sqrt(dx * dx + dy * dy);
/*    */     } 
/*    */     
/* 95 */     double dx0 = x[0] - x[npoints - 1];
/* 96 */     double dy0 = y[0] - y[npoints - 1];
/* 97 */     length += Math.sqrt(dx0 * dx0 + dy0 * dy0);
/*    */     
/* 99 */     return length;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/features/spot/SpotShapeAnalyzer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */