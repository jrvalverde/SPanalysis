/*     */ package fiji.plugin.trackmate;
/*     */ 
/*     */ import fiji.plugin.trackmate.features.edges.EdgeTargetAnalyzer;
/*     */ import fiji.plugin.trackmate.features.track.TrackIndexAnalyzer;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import org.jgrapht.graph.DefaultWeightedEdge;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FeatureModel
/*     */ {
/*  49 */   private final Collection<String> trackFeatures = new LinkedHashSet<>();
/*     */   
/*  51 */   private final Map<String, String> trackFeatureNames = new HashMap<>();
/*     */   
/*  53 */   private final Map<String, String> trackFeatureShortNames = new HashMap<>();
/*     */   
/*  55 */   private final Map<String, Dimension> trackFeatureDimensions = new HashMap<>();
/*     */   
/*  57 */   private final Map<String, Boolean> trackFeatureIsInt = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  64 */   Map<Integer, Map<String, Double>> trackFeatureValues = new ConcurrentHashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  69 */   private final ConcurrentHashMap<DefaultWeightedEdge, ConcurrentHashMap<String, Double>> edgeFeatureValues = new ConcurrentHashMap<>();
/*     */   
/*  71 */   private final Collection<String> edgeFeatures = new LinkedHashSet<>();
/*     */   
/*  73 */   private final Map<String, String> edgeFeatureNames = new HashMap<>();
/*     */   
/*  75 */   private final Map<String, String> edgeFeatureShortNames = new HashMap<>();
/*     */   
/*  77 */   private final Map<String, Dimension> edgeFeatureDimensions = new HashMap<>();
/*     */   
/*  79 */   private final Map<String, Boolean> edgeFeatureIsInt = new HashMap<>();
/*     */   
/*  81 */   private final Collection<String> spotFeatures = new LinkedHashSet<>();
/*     */   
/*  83 */   private final Map<String, String> spotFeatureNames = new HashMap<>();
/*     */   
/*  85 */   private final Map<String, String> spotFeatureShortNames = new HashMap<>();
/*     */   
/*  87 */   private final Map<String, Dimension> spotFeatureDimensions = new HashMap<>();
/*     */   
/*  89 */   private final Map<String, Boolean> spotFeatureIsInt = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final Model model;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected FeatureModel(Model model) {
/* 107 */     this.model = model;
/*     */     
/* 109 */     declareSpotFeatures(Spot.FEATURES, Spot.FEATURE_NAMES, Spot.FEATURE_SHORT_NAMES, Spot.FEATURE_DIMENSIONS, Spot.IS_INT);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 115 */     declareEdgeFeatures(EdgeTargetAnalyzer.FEATURES, EdgeTargetAnalyzer.FEATURE_NAMES, EdgeTargetAnalyzer.FEATURE_SHORT_NAMES, EdgeTargetAnalyzer.FEATURE_DIMENSIONS, EdgeTargetAnalyzer.IS_INT);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 121 */     declareTrackFeatures(TrackIndexAnalyzer.FEATURES, TrackIndexAnalyzer.FEATURE_NAMES, TrackIndexAnalyzer.FEATURE_SHORT_NAMES, TrackIndexAnalyzer.FEATURE_DIMENSIONS, TrackIndexAnalyzer.IS_INT);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void putEdgeFeature(DefaultWeightedEdge edge, String feature, Double value) {
/* 149 */     ConcurrentHashMap<String, Double> map = this.edgeFeatureValues.get(edge);
/* 150 */     if (null == map) {
/*     */       
/* 152 */       map = new ConcurrentHashMap<>();
/* 153 */       this.edgeFeatureValues.put(edge, map);
/*     */     } 
/* 155 */     map.put(feature, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public Double getEdgeFeature(DefaultWeightedEdge edge, String featureName) {
/* 160 */     ConcurrentHashMap<String, Double> map = this.edgeFeatureValues.get(edge);
/* 161 */     if (null == map)
/* 162 */       return null; 
/* 163 */     return map.get(featureName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeEdgeFeature(DefaultWeightedEdge edge, String feature) {
/* 176 */     ConcurrentHashMap<String, Double> map = this.edgeFeatureValues.get(edge);
/* 177 */     if (null == map)
/*     */       return; 
/* 179 */     map.remove(feature);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection<String> getEdgeFeatures() {
/* 189 */     return this.edgeFeatures;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void declareEdgeFeatures(Collection<String> features, Map<String, String> featureNames, Map<String, String> featureShortNames, Map<String, Dimension> featureDimensions, Map<String, Boolean> isIntFeature) {
/* 212 */     this.edgeFeatures.addAll(features);
/* 213 */     for (String feature : features) {
/*     */       
/* 215 */       String name = featureNames.get(feature);
/* 216 */       if (null == name)
/* 217 */         throw new IllegalArgumentException("Feature " + feature + " misses a name."); 
/* 218 */       this.edgeFeatureNames.put(feature, name);
/*     */       
/* 220 */       String shortName = featureShortNames.get(feature);
/* 221 */       if (null == shortName)
/* 222 */         throw new IllegalArgumentException("Feature " + feature + " misses a short name."); 
/* 223 */       this.edgeFeatureShortNames.put(feature, shortName);
/*     */       
/* 225 */       Dimension dimension = featureDimensions.get(feature);
/* 226 */       if (null == dimension)
/* 227 */         throw new IllegalArgumentException("Feature " + feature + " misses a dimension."); 
/* 228 */       this.edgeFeatureDimensions.put(feature, dimension);
/*     */       
/* 230 */       Boolean isInt = isIntFeature.get(feature);
/* 231 */       if (null == isInt)
/* 232 */         throw new IllegalArgumentException("Feature " + feature + " misses the isInt flag."); 
/* 233 */       this.edgeFeatureIsInt.put(feature, isInt);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, String> getEdgeFeatureNames() {
/* 245 */     return this.edgeFeatureNames;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, String> getEdgeFeatureShortNames() {
/* 256 */     return this.edgeFeatureShortNames;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, Dimension> getEdgeFeatureDimensions() {
/* 267 */     return this.edgeFeatureDimensions;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, Boolean> getEdgeFeatureIsInt() {
/* 278 */     return this.edgeFeatureIsInt;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection<String> getTrackFeatures() {
/* 292 */     return this.trackFeatures;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void declareTrackFeatures(Collection<String> features, Map<String, String> featureNames, Map<String, String> featureShortNames, Map<String, Dimension> featureDimensions, Map<String, Boolean> isIntFeature) {
/* 315 */     this.trackFeatures.addAll(features);
/* 316 */     for (String feature : features) {
/*     */ 
/*     */       
/* 319 */       String name = featureNames.get(feature);
/* 320 */       if (null == name)
/* 321 */         throw new IllegalArgumentException("Feature " + feature + " misses a name."); 
/* 322 */       this.trackFeatureNames.put(feature, name);
/*     */       
/* 324 */       String shortName = featureShortNames.get(feature);
/* 325 */       if (null == shortName)
/* 326 */         throw new IllegalArgumentException("Feature " + feature + " misses a short name."); 
/* 327 */       this.trackFeatureShortNames.put(feature, shortName);
/*     */       
/* 329 */       Dimension dimension = featureDimensions.get(feature);
/* 330 */       if (null == dimension)
/* 331 */         throw new IllegalArgumentException("Feature " + feature + " misses a dimension."); 
/* 332 */       this.trackFeatureDimensions.put(feature, dimension);
/*     */       
/* 334 */       Boolean isInt = isIntFeature.get(feature);
/* 335 */       if (null == isInt)
/* 336 */         throw new IllegalArgumentException("Feature " + feature + " misses the isInt flag."); 
/* 337 */       this.trackFeatureIsInt.put(feature, isInt);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, String> getTrackFeatureNames() {
/* 349 */     return this.trackFeatureNames;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, String> getTrackFeatureShortNames() {
/* 360 */     return this.trackFeatureShortNames;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, Dimension> getTrackFeatureDimensions() {
/* 371 */     return this.trackFeatureDimensions;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, Boolean> getTrackFeatureIsInt() {
/* 382 */     return this.trackFeatureIsInt;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void putTrackFeature(Integer trackID, String feature, Double value) {
/* 401 */     Map<String, Double> trackFeatureMap = this.trackFeatureValues.get(trackID);
/* 402 */     if (null == trackFeatureMap) {
/*     */       
/* 404 */       trackFeatureMap = new HashMap<>(this.trackFeatures.size());
/* 405 */       this.trackFeatureValues.put(trackID, trackFeatureMap);
/*     */     } 
/* 407 */     trackFeatureMap.put(feature, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeTrackFeature(Integer trackID, String feature) {
/* 421 */     Map<String, Double> map = this.trackFeatureValues.get(trackID);
/* 422 */     if (null == map)
/*     */       return; 
/* 424 */     map.remove(feature);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Double getTrackFeature(Integer trackID, String feature) {
/* 439 */     Map<String, Double> valueMap = this.trackFeatureValues.get(trackID);
/* 440 */     return (valueMap == null) ? null : valueMap.get(feature);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, double[]> getTrackFeatureValues() {
/* 451 */     Map<String, double[]> featureValues = (Map)new HashMap<>();
/*     */     
/* 453 */     int nTracks = this.model.getTrackModel().nTracks(false);
/* 454 */     for (String feature : this.trackFeatures) {
/*     */ 
/*     */       
/* 457 */       boolean noDataFlag = true;
/* 458 */       double[] values = new double[nTracks];
/* 459 */       int index = 0;
/* 460 */       for (Integer trackID : this.model.getTrackModel().trackIDs(false)) {
/*     */         
/* 462 */         Double val = getTrackFeature(trackID, feature);
/* 463 */         if (null == val) {
/*     */           continue;
/*     */         }
/* 466 */         values[index++] = val.doubleValue();
/* 467 */         noDataFlag = false;
/*     */       } 
/*     */       
/* 470 */       if (noDataFlag)
/* 471 */         featureValues.put(feature, noDataFlag ? new double[0] : values); 
/*     */     } 
/* 473 */     return featureValues;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void declareSpotFeatures(Collection<String> features, Map<String, String> featureNames, Map<String, String> featureShortNames, Map<String, Dimension> featureDimensions, Map<String, Boolean> isIntFeature) {
/* 501 */     this.spotFeatures.addAll(features);
/* 502 */     for (String feature : features) {
/*     */ 
/*     */       
/* 505 */       String name = featureNames.get(feature);
/* 506 */       if (null == name)
/* 507 */         throw new IllegalArgumentException("Feature " + feature + " misses a name."); 
/* 508 */       this.spotFeatureNames.put(feature, name);
/*     */       
/* 510 */       String shortName = featureShortNames.get(feature);
/* 511 */       if (null == shortName)
/* 512 */         throw new IllegalArgumentException("Feature " + feature + " misses a short name."); 
/* 513 */       this.spotFeatureShortNames.put(feature, shortName);
/*     */       
/* 515 */       Dimension dimension = featureDimensions.get(feature);
/* 516 */       if (null == dimension)
/* 517 */         throw new IllegalArgumentException("Feature " + feature + " misses a dimension."); 
/* 518 */       this.spotFeatureDimensions.put(feature, dimension);
/*     */       
/* 520 */       Boolean isInt = isIntFeature.get(feature);
/* 521 */       if (null == isInt)
/* 522 */         throw new IllegalArgumentException("Feature " + feature + " misses the isInt flag."); 
/* 523 */       this.spotFeatureIsInt.put(feature, isInt);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection<String> getSpotFeatures() {
/* 535 */     return this.spotFeatures;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, String> getSpotFeatureNames() {
/* 546 */     return this.spotFeatureNames;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, String> getSpotFeatureShortNames() {
/* 557 */     return this.spotFeatureShortNames;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, Dimension> getSpotFeatureDimensions() {
/* 568 */     return this.spotFeatureDimensions;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, Boolean> getSpotFeatureIsInt() {
/* 579 */     return this.spotFeatureIsInt;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 585 */     StringBuilder str = new StringBuilder();
/*     */ 
/*     */     
/* 588 */     str.append("Spot features declared:\n");
/* 589 */     appendFeatureDeclarations(str, this.spotFeatures, this.spotFeatureNames, this.spotFeatureShortNames, this.spotFeatureDimensions, this.spotFeatureIsInt);
/* 590 */     str.append('\n');
/*     */ 
/*     */     
/* 593 */     str.append("Edge features declared:\n");
/* 594 */     appendFeatureDeclarations(str, this.edgeFeatures, this.edgeFeatureNames, this.edgeFeatureShortNames, this.edgeFeatureDimensions, this.edgeFeatureIsInt);
/* 595 */     str.append('\n');
/*     */ 
/*     */     
/* 598 */     str.append("Track features declared:\n");
/* 599 */     appendFeatureDeclarations(str, this.trackFeatures, this.trackFeatureNames, this.trackFeatureShortNames, this.trackFeatureDimensions, this.trackFeatureIsInt);
/* 600 */     str.append('\n');
/*     */     
/* 602 */     return str.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String echo() {
/* 612 */     StringBuilder str = new StringBuilder();
/*     */ 
/*     */     
/* 615 */     str.append("Spot features:\n");
/* 616 */     str.append(" - Declared:\n");
/* 617 */     appendFeatureDeclarations(str, this.spotFeatures, this.spotFeatureNames, this.spotFeatureShortNames, this.spotFeatureDimensions, this.spotFeatureIsInt);
/* 618 */     str.append('\n');
/*     */ 
/*     */     
/* 621 */     str.append("Edge features:\n");
/* 622 */     str.append(" - Declared:\n");
/* 623 */     appendFeatureDeclarations(str, this.edgeFeatures, this.edgeFeatureNames, this.edgeFeatureShortNames, this.edgeFeatureDimensions, this.edgeFeatureIsInt);
/* 624 */     str.append('\n');
/* 625 */     str.append(" - Values:\n");
/* 626 */     appendFeatureValues(str, (Map)this.edgeFeatureValues);
/*     */ 
/*     */     
/* 629 */     str.append("Track features:\n");
/* 630 */     str.append(" - Declared:\n");
/* 631 */     appendFeatureDeclarations(str, this.trackFeatures, this.trackFeatureNames, this.trackFeatureShortNames, this.trackFeatureDimensions, this.trackFeatureIsInt);
/* 632 */     str.append('\n');
/* 633 */     str.append(" - Values:\n");
/* 634 */     appendFeatureValues(str, this.trackFeatureValues);
/*     */     
/* 636 */     return str.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final <K> void appendFeatureValues(StringBuilder str, Map<K, ? extends Map<String, Double>> values) {
/* 645 */     for (K key : values.keySet()) {
/*     */       
/* 647 */       String header = "   - " + key.toString() + ":\n";
/* 648 */       str.append(header);
/* 649 */       Map<String, Double> map = values.get(key);
/* 650 */       for (String feature : map.keySet()) {
/* 651 */         str.append("     - " + feature + " = " + map.get(feature) + '\n');
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private static final void appendFeatureDeclarations(StringBuilder str, Collection<String> features, Map<String, String> featureNames, Map<String, String> featureShortNames, Map<String, Dimension> featureDimensions, Map<String, Boolean> isIntFeature) {
/* 657 */     for (String feature : features) {
/*     */       
/* 659 */       str.append("   - " + feature + ": " + (String)featureNames.get(feature) + ", '" + (String)featureShortNames.get(feature) + "' (" + featureDimensions.get(feature) + ")");
/* 660 */       if (((Boolean)isIntFeature.get(feature)).booleanValue()) {
/* 661 */         str.append(" - integer valued.\n"); continue;
/*     */       } 
/* 663 */       str.append(" - double valued.\n");
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/FeatureModel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */