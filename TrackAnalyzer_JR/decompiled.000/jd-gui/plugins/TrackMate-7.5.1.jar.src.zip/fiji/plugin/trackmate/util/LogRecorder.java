/*    */ package fiji.plugin.trackmate.util;
/*    */ 
/*    */ import fiji.plugin.trackmate.Logger;
/*    */ import java.awt.Color;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LogRecorder
/*    */   extends Logger
/*    */ {
/*    */   private final Logger source;
/*    */   private final StringBuilder str;
/*    */   
/*    */   public LogRecorder(Logger source) {
/* 37 */     this.source = source;
/* 38 */     this.str = new StringBuilder();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void log(String message, Color color) {
/* 44 */     this.str.append(message);
/* 45 */     this.source.log(message, color);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void error(String message) {
/* 52 */     this.str.append(message);
/* 53 */     this.source.error(message);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void setProgress(double val) {
/* 59 */     this.source.setProgress(val);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void setStatus(String status) {
/* 65 */     this.source.setStatus(status);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String toString() {
/* 71 */     return this.str.toString();
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/util/LogRecorder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */