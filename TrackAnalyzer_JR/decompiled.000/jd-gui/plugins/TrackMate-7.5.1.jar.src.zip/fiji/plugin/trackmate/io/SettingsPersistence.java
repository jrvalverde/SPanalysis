/*    */ package fiji.plugin.trackmate.io;
/*    */ 
/*    */ import fiji.plugin.trackmate.Logger;
/*    */ import fiji.plugin.trackmate.Settings;
/*    */ import fiji.plugin.trackmate.detection.LogDetectorFactory;
/*    */ import fiji.plugin.trackmate.detection.SpotDetectorFactoryBase;
/*    */ import fiji.plugin.trackmate.tracking.SpotTrackerFactory;
/*    */ import fiji.plugin.trackmate.tracking.sparselap.SimpleSparseLAPTrackerFactory;
/*    */ import ij.ImagePlus;
/*    */ import java.io.File;
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SettingsPersistence
/*    */ {
/* 39 */   private static File lastSettingsFile = new File(new File(System.getProperty("user.home"), ".trackmate"), "lastusedsettings.xml");
/*    */ 
/*    */   
/*    */   public static final Settings readLastUsedSettings(ImagePlus imp, Logger logger) {
/* 43 */     TmXmlReader reader = new TmXmlReader(lastSettingsFile);
/* 44 */     if (!reader.isReadingOk()) {
/*    */       
/* 46 */       logger.error("Could not read the last used settings file at " + lastSettingsFile + ".\n");
/* 47 */       logger.error("Using built-in defaults.\n");
/* 48 */       return getDefaultSettings(imp);
/*    */     } 
/*    */     
/* 51 */     Settings settings = reader.readSettings(null);
/* 52 */     Settings newSettings = settings.copyOn(imp);
/* 53 */     return newSettings;
/*    */   }
/*    */ 
/*    */   
/*    */   public static final void saveLastUsedSettings(Settings settings, Logger logger) {
/* 58 */     if (!lastSettingsFile.exists()) {
/* 59 */       lastSettingsFile.getParentFile().mkdirs();
/*    */     }
/* 61 */     TmXmlWriter writer = new TmXmlWriter(lastSettingsFile);
/* 62 */     writer.appendSettings(settings);
/*    */     
/*    */     try {
/* 65 */       writer.writeToFile();
/*    */     }
/* 67 */     catch (IOException e) {
/*    */       
/* 69 */       logger.error("Problem writing to the last used settings file at " + lastSettingsFile + ".\n");
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public static Settings getDefaultSettings(ImagePlus imp) {
/* 75 */     Settings settings = new Settings(imp);
/* 76 */     settings.detectorFactory = (SpotDetectorFactoryBase)new LogDetectorFactory();
/* 77 */     settings.detectorSettings = settings.detectorFactory.getDefaultSettings();
/* 78 */     settings.trackerFactory = (SpotTrackerFactory)new SimpleSparseLAPTrackerFactory();
/* 79 */     settings.trackerSettings = settings.trackerFactory.getDefaultSettings();
/* 80 */     settings.addAllAnalyzers();
/* 81 */     return settings;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/io/SettingsPersistence.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */