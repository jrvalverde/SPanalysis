/*     */ package fiji.plugin.trackmate.tracking;
/*     */ 
/*     */ import fiji.plugin.trackmate.Model;
/*     */ import fiji.plugin.trackmate.SpotCollection;
/*     */ import fiji.plugin.trackmate.gui.components.ConfigurationPanel;
/*     */ import java.util.Map;
/*     */ import javax.swing.ImageIcon;
/*     */ import org.jdom2.Element;
/*     */ import org.scijava.plugin.Plugin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Plugin(type = SpotTrackerFactory.class, priority = 100.0D)
/*     */ public class ManualTrackerFactory
/*     */   implements SpotTrackerFactory
/*     */ {
/*     */   public static final String TRACKER_KEY = "MANUAL_TRACKER";
/*     */   public static final String NAME = "Manual tracking";
/*     */   public static final String INFO_TEXT = "<html>Choosing this tracker skips the automated tracking step <br>and keeps the current annotation.</html>";
/*     */   private String errorMessage;
/*     */   
/*     */   public String getInfoText() {
/*  50 */     return "<html>Choosing this tracker skips the automated tracking step <br>and keeps the current annotation.</html>";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ImageIcon getIcon() {
/*  56 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getKey() {
/*  62 */     return "MANUAL_TRACKER";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/*  68 */     return "Manual tracking";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public SpotTracker create(SpotCollection spots, Map<String, Object> settings) {
/*  74 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ConfigurationPanel getTrackerConfigurationPanel(Model model) {
/*  80 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean marshall(Map<String, Object> settings, Element element) {
/*  86 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean unmarshall(Element element, Map<String, Object> settings) {
/*  92 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString(Map<String, Object> sm) {
/*  98 */     if (!checkSettingsValidity(sm)) return this.errorMessage; 
/*  99 */     return "  Manual tracking.\n";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, Object> getDefaultSettings() {
/* 105 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean checkSettingsValidity(Map<String, Object> settings) {
/* 111 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getErrorMessage() {
/* 117 */     return this.errorMessage;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ManualTrackerFactory copy() {
/* 123 */     return new ManualTrackerFactory();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/tracking/ManualTrackerFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */