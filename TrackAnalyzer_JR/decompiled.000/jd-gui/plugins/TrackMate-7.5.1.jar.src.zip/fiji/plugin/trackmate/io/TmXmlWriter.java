/*     */ package fiji.plugin.trackmate.io;
/*     */ 
/*     */ import fiji.plugin.trackmate.Dimension;
/*     */ import fiji.plugin.trackmate.FeatureModel;
/*     */ import fiji.plugin.trackmate.Logger;
/*     */ import fiji.plugin.trackmate.Model;
/*     */ import fiji.plugin.trackmate.Settings;
/*     */ import fiji.plugin.trackmate.Spot;
/*     */ import fiji.plugin.trackmate.SpotCollection;
/*     */ import fiji.plugin.trackmate.SpotRoi;
/*     */ import fiji.plugin.trackmate.TrackMate;
/*     */ import fiji.plugin.trackmate.features.FeatureFilter;
/*     */ import fiji.plugin.trackmate.features.edges.EdgeAnalyzer;
/*     */ import fiji.plugin.trackmate.features.spot.SpotAnalyzerFactoryBase;
/*     */ import fiji.plugin.trackmate.features.track.TrackAnalyzer;
/*     */ import fiji.plugin.trackmate.gui.displaysettings.DisplaySettings;
/*     */ import fiji.plugin.trackmate.gui.displaysettings.DisplaySettingsIO;
/*     */ import java.io.File;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.StringWriter;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.jdom2.Attribute;
/*     */ import org.jdom2.Content;
/*     */ import org.jdom2.Document;
/*     */ import org.jdom2.Element;
/*     */ import org.jdom2.output.Format;
/*     */ import org.jdom2.output.XMLOutputter;
/*     */ import org.jgrapht.graph.DefaultWeightedEdge;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TmXmlWriter
/*     */ {
/*     */   protected final Element root;
/*     */   protected final Logger logger;
/*     */   private final File file;
/*     */   
/*     */   public TmXmlWriter(File file) {
/* 157 */     this(file, (Logger)new Logger.StringBuilderLogger());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TmXmlWriter(File file, Logger logger) {
/* 168 */     this.root = new Element("TrackMate");
/* 169 */     this.root.setAttribute("version", TrackMate.PLUGIN_NAME_VERSION);
/* 170 */     this.logger = logger;
/* 171 */     this.file = file;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeToFile() throws FileNotFoundException, IOException {
/* 187 */     try (FileOutputStream fos = new FileOutputStream(this.file)) {
/*     */       
/* 189 */       this.logger.log("  Writing to file.\n");
/* 190 */       Document document = new Document(this.root);
/* 191 */       XMLOutputter outputter = new XMLOutputter(Format.getPrettyFormat());
/* 192 */       outputter.output(document, fos);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 199 */     Document document = new Document(this.root);
/* 200 */     XMLOutputter outputter = new XMLOutputter(Format.getPrettyFormat());
/* 201 */     StringWriter writer = new StringWriter();
/*     */     
/*     */     try {
/* 204 */       outputter.output(document, writer);
/*     */     }
/* 206 */     catch (IOException e) {
/*     */       
/* 208 */       e.printStackTrace();
/*     */     } 
/* 210 */     return writer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void appendModel(Model model) {
/* 222 */     Element modelElement = new Element("Model");
/* 223 */     modelElement.setAttribute("spatialunits", model.getSpaceUnits());
/* 224 */     modelElement.setAttribute("timeunits", model.getTimeUnits());
/*     */     
/* 226 */     Element featureDeclarationElement = echoFeaturesDeclaration(model);
/* 227 */     modelElement.addContent((Content)featureDeclarationElement);
/*     */     
/* 229 */     Element spotElement = echoSpots(model);
/* 230 */     modelElement.addContent((Content)spotElement);
/*     */     
/* 232 */     Element trackElement = echoTracks(model);
/* 233 */     modelElement.addContent((Content)trackElement);
/*     */     
/* 235 */     Element filteredTrackElement = echoFilteredTracks(model);
/* 236 */     modelElement.addContent((Content)filteredTrackElement);
/*     */     
/* 238 */     this.root.addContent((Content)modelElement);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void appendSettings(Settings settings) {
/* 249 */     Element settingsElement = new Element("Settings");
/*     */     
/* 251 */     Element imageInfoElement = echoImageInfo(settings);
/* 252 */     settingsElement.addContent((Content)imageInfoElement);
/*     */     
/* 254 */     Element cropElement = echoCropSettings(settings);
/* 255 */     settingsElement.addContent((Content)cropElement);
/*     */     
/* 257 */     Element detectorElement = echoDetectorSettings(settings);
/* 258 */     settingsElement.addContent((Content)detectorElement);
/*     */     
/* 260 */     Element initFilter = echoInitialSpotFilter(settings);
/* 261 */     settingsElement.addContent((Content)initFilter);
/*     */     
/* 263 */     Element spotFiltersElement = echoSpotFilters(settings);
/* 264 */     settingsElement.addContent((Content)spotFiltersElement);
/*     */     
/* 266 */     Element trackerElement = echoTrackerSettings(settings);
/* 267 */     settingsElement.addContent((Content)trackerElement);
/*     */     
/* 269 */     Element trackFiltersElement = echoTrackFilters(settings);
/* 270 */     settingsElement.addContent((Content)trackFiltersElement);
/*     */     
/* 272 */     Element analyzersElement = echoAnalyzers(settings);
/* 273 */     settingsElement.addContent((Content)analyzersElement);
/*     */     
/* 275 */     this.root.addContent((Content)settingsElement);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void appendLog(String log) {
/* 286 */     if (null != log) {
/*     */       
/* 288 */       Element logElement = new Element("Log");
/* 289 */       logElement.addContent(log);
/* 290 */       this.root.addContent((Content)logElement);
/* 291 */       this.logger.log("  Added log.\n");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void appendGUIState(String currentPanelIdentifier) {
/* 303 */     Element guiel = new Element("GUIState");
/* 304 */     guiel.setAttribute("state", currentPanelIdentifier);
/* 305 */     this.root.addContent((Content)guiel);
/* 306 */     this.logger.log("  Added GUI current state.\n");
/*     */   }
/*     */ 
/*     */   
/*     */   public void appendDisplaySettings(DisplaySettings ds) {
/* 311 */     Element dsel = new Element("DisplaySettings");
/* 312 */     DisplaySettingsIO.toXML(ds, dsel);
/* 313 */     this.root.addContent((Content)dsel);
/* 314 */     this.logger.log("  Added display settings.\n");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Element echoCropSettings(Settings settings) {
/* 323 */     Element settingsElement = new Element("BasicSettings");
/* 324 */     settingsElement.setAttribute("xstart", "" + settings.xstart);
/* 325 */     settingsElement.setAttribute("xend", "" + settings.xend);
/* 326 */     settingsElement.setAttribute("ystart", "" + settings.ystart);
/* 327 */     settingsElement.setAttribute("yend", "" + settings.yend);
/* 328 */     settingsElement.setAttribute("zstart", "" + settings.zstart);
/* 329 */     settingsElement.setAttribute("zend", "" + settings.zend);
/* 330 */     settingsElement.setAttribute("tstart", "" + settings.tstart);
/* 331 */     settingsElement.setAttribute("tend", "" + settings.tend);
/* 332 */     this.logger.log("  Added crop settings.\n");
/* 333 */     return settingsElement;
/*     */   }
/*     */ 
/*     */   
/*     */   protected Element echoDetectorSettings(Settings settings) {
/* 338 */     Element el = new Element("DetectorSettings");
/*     */     
/* 340 */     if (null == settings.detectorFactory) {
/* 341 */       return el;
/*     */     }
/*     */     
/* 344 */     el.setAttribute("DETECTOR_NAME", settings.detectorFactory.getKey());
/*     */ 
/*     */     
/* 347 */     if (null != settings.detectorFactory) {
/*     */       
/* 349 */       boolean ok = settings.detectorFactory.marshall(settings.detectorSettings, el);
/* 350 */       if (!ok) {
/* 351 */         this.logger.error(settings.detectorFactory.getErrorMessage());
/*     */       } else {
/* 353 */         this.logger.log("  Added detector settings.\n");
/*     */       } 
/*     */     } 
/* 356 */     return el;
/*     */   }
/*     */ 
/*     */   
/*     */   protected Element echoTrackerSettings(Settings settings) {
/* 361 */     Element el = new Element("TrackerSettings");
/*     */     
/* 363 */     if (null == settings.trackerFactory) {
/* 364 */       return el;
/*     */     }
/*     */     
/* 367 */     el.setAttribute("TRACKER_NAME", settings.trackerFactory.getKey());
/*     */ 
/*     */     
/* 370 */     if (null != settings.trackerFactory) {
/*     */       
/* 372 */       boolean ok = settings.trackerFactory.marshall(settings.trackerSettings, el);
/* 373 */       if (!ok) {
/* 374 */         this.logger.error(settings.trackerFactory.getErrorMessage());
/*     */       } else {
/* 376 */         this.logger.log("  Added tracker settings.\n");
/*     */       } 
/*     */     } 
/* 379 */     return el;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Element echoTracks(Model model) {
/* 392 */     Element allTracksElement = new Element("AllTracks");
/*     */ 
/*     */     
/* 395 */     List<String> trackFeatures = new ArrayList<>(model.getFeatureModel().getTrackFeatures());
/*     */     
/* 397 */     trackFeatures.remove("TRACK_ID");
/*     */ 
/*     */     
/* 400 */     List<String> edgeFeatures = new ArrayList<>(model.getFeatureModel().getEdgeFeatures());
/*     */     
/* 402 */     edgeFeatures.remove("SPOT_SOURCE_ID");
/* 403 */     edgeFeatures.remove("SPOT_TARGET_ID");
/*     */     
/* 405 */     Set<Integer> trackIDs = model.getTrackModel().trackIDs(false);
/* 406 */     for (Iterator<Integer> iterator = trackIDs.iterator(); iterator.hasNext(); ) { int trackID = ((Integer)iterator.next()).intValue();
/*     */ 
/*     */       
/* 409 */       Element trackElement = new Element("Track");
/*     */ 
/*     */       
/* 412 */       trackElement.setAttribute("name", model.getTrackModel().name(Integer.valueOf(trackID)));
/*     */       
/* 414 */       trackElement.setAttribute("TRACK_ID", Integer.toString(trackID));
/*     */       
/* 416 */       for (String feature : trackFeatures) {
/*     */         String str;
/* 418 */         Double val = model.getFeatureModel().getTrackFeature(Integer.valueOf(trackID), feature);
/* 419 */         if (null == val) {
/*     */           continue;
/*     */         }
/*     */         
/* 423 */         if (((Boolean)model.getFeatureModel().getTrackFeatureIsInt().get(feature)).booleanValue()) {
/* 424 */           str = Integer.toString(val.intValue());
/*     */         } else {
/* 426 */           str = val.toString();
/* 427 */         }  trackElement.setAttribute(feature, str);
/*     */       } 
/*     */ 
/*     */       
/* 431 */       Set<DefaultWeightedEdge> track = model.getTrackModel().trackEdges(Integer.valueOf(trackID));
/* 432 */       if (track.isEmpty()) {
/*     */         continue;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 442 */       for (DefaultWeightedEdge edge : track) {
/*     */         int sourceID, targetID;
/* 444 */         Element edgeElement = new Element("Edge");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 450 */         int sourceFrame = model.getTrackModel().getEdgeSource(edge).getFeature("FRAME").intValue();
/* 451 */         int targetFrame = model.getTrackModel().getEdgeTarget(edge).getFeature("FRAME").intValue();
/*     */ 
/*     */         
/* 454 */         if (targetFrame >= sourceFrame) {
/*     */           
/* 456 */           sourceID = model.getTrackModel().getEdgeSource(edge).ID();
/* 457 */           targetID = model.getTrackModel().getEdgeTarget(edge).ID();
/*     */         }
/*     */         else {
/*     */           
/* 461 */           sourceID = model.getTrackModel().getEdgeTarget(edge).ID();
/* 462 */           targetID = model.getTrackModel().getEdgeSource(edge).ID();
/*     */         } 
/* 464 */         edgeElement.setAttribute("SPOT_SOURCE_ID", Integer.toString(sourceID));
/* 465 */         edgeElement.setAttribute("SPOT_TARGET_ID", Integer.toString(targetID));
/*     */         
/* 467 */         for (String feature : edgeFeatures) {
/*     */           String str;
/* 469 */           Double val = model.getFeatureModel().getEdgeFeature(edge, feature);
/* 470 */           if (null == val) {
/*     */             continue;
/*     */           }
/*     */           
/* 474 */           if (((Boolean)model.getFeatureModel().getEdgeFeatureIsInt().get(feature)).booleanValue()) {
/* 475 */             str = Integer.toString(val.intValue());
/*     */           } else {
/* 477 */             str = val.toString();
/*     */           } 
/* 479 */           edgeElement.setAttribute(feature, str);
/*     */         } 
/*     */         
/* 482 */         trackElement.addContent((Content)edgeElement);
/*     */       } 
/* 484 */       allTracksElement.addContent((Content)trackElement); }
/*     */     
/* 486 */     this.logger.log("  Added tracks.\n");
/* 487 */     return allTracksElement;
/*     */   }
/*     */ 
/*     */   
/*     */   private Element echoFilteredTracks(Model model) {
/* 492 */     Element filteredTracksElement = new Element("FilteredTracks");
/* 493 */     Set<Integer> filteredTrackKeys = model.getTrackModel().trackIDs(true);
/* 494 */     for (Iterator<Integer> iterator = filteredTrackKeys.iterator(); iterator.hasNext(); ) { int trackID = ((Integer)iterator.next()).intValue();
/*     */       
/* 496 */       Element trackIDElement = new Element("TrackID");
/* 497 */       trackIDElement.setAttribute("TRACK_ID", "" + trackID);
/* 498 */       filteredTracksElement.addContent((Content)trackIDElement); }
/*     */     
/* 500 */     this.logger.log("  Added filtered tracks.\n");
/* 501 */     return filteredTracksElement;
/*     */   }
/*     */ 
/*     */   
/*     */   protected Element echoImageInfo(Settings settings) {
/* 506 */     Element imEl = new Element("ImageData");
/*     */     
/* 508 */     String imFileName = (settings.imageFileName == null) ? "" : settings.imageFileName;
/* 509 */     imEl.setAttribute("filename", imFileName);
/* 510 */     String imFolder = (settings.imageFolder == null) ? "" : settings.imageFolder;
/* 511 */     imEl.setAttribute("folder", imFolder);
/* 512 */     imEl.setAttribute("width", "" + settings.width);
/* 513 */     imEl.setAttribute("height", "" + settings.height);
/* 514 */     imEl.setAttribute("nslices", "" + settings.nslices);
/* 515 */     imEl.setAttribute("nframes", "" + settings.nframes);
/* 516 */     imEl.setAttribute("pixelwidth", "" + settings.dx);
/* 517 */     imEl.setAttribute("pixelheight", "" + settings.dy);
/* 518 */     imEl.setAttribute("voxeldepth", "" + settings.dz);
/* 519 */     imEl.setAttribute("timeinterval", "" + settings.dt);
/* 520 */     this.logger.log("  Added image information.\n");
/* 521 */     return imEl;
/*     */   }
/*     */ 
/*     */   
/*     */   private Element echoSpots(Model model) {
/* 526 */     SpotCollection spots = model.getSpots();
/*     */     
/* 528 */     Element spotCollectionElement = new Element("AllSpots");
/*     */     
/* 530 */     spotCollectionElement.setAttribute("nspots", "" + spots.getNSpots(false));
/*     */     
/* 532 */     for (Iterator<Integer> iterator = spots.keySet().iterator(); iterator.hasNext(); ) { int frame = ((Integer)iterator.next()).intValue();
/*     */ 
/*     */       
/* 535 */       Element frameSpotsElement = new Element("SpotsInFrame");
/* 536 */       frameSpotsElement.setAttribute("frame", "" + frame);
/*     */       
/* 538 */       for (Iterator<Spot> it = spots.iterator(Integer.valueOf(frame), false); it.hasNext(); ) {
/*     */         
/* 540 */         Element spotElement = marshalSpot(it.next(), model.getFeatureModel());
/* 541 */         frameSpotsElement.addContent((Content)spotElement);
/*     */       } 
/* 543 */       spotCollectionElement.addContent((Content)frameSpotsElement); }
/*     */     
/* 545 */     this.logger.log("  Added " + spots.getNSpots(false) + " spots.\n");
/* 546 */     return spotCollectionElement;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private Element echoFeaturesDeclaration(Model model) {
/* 552 */     FeatureModel fm = model.getFeatureModel();
/* 553 */     Element featuresElement = new Element("FeatureDeclarations");
/*     */ 
/*     */     
/* 556 */     Element spotFeaturesElement = new Element("SpotFeatures");
/* 557 */     Collection<String> features = fm.getSpotFeatures();
/* 558 */     Map<String, String> featureNames = fm.getSpotFeatureNames();
/* 559 */     Map<String, String> featureShortNames = fm.getSpotFeatureShortNames();
/* 560 */     Map<String, Dimension> featureDimensions = fm.getSpotFeatureDimensions();
/* 561 */     Map<String, Boolean> featureIsInt = fm.getSpotFeatureIsInt();
/* 562 */     for (String feature : features) {
/*     */       
/* 564 */       Element fel = new Element("Feature");
/* 565 */       fel.setAttribute("feature", feature);
/* 566 */       fel.setAttribute("name", featureNames.get(feature));
/* 567 */       fel.setAttribute("shortname", featureShortNames.get(feature));
/* 568 */       fel.setAttribute("dimension", ((Dimension)featureDimensions.get(feature)).name());
/* 569 */       fel.setAttribute("isint", ((Boolean)featureIsInt.get(feature)).toString());
/* 570 */       spotFeaturesElement.addContent((Content)fel);
/*     */     } 
/* 572 */     featuresElement.addContent((Content)spotFeaturesElement);
/*     */ 
/*     */     
/* 575 */     Element edgeFeaturesElement = new Element("EdgeFeatures");
/* 576 */     features = fm.getEdgeFeatures();
/* 577 */     featureNames = fm.getEdgeFeatureNames();
/* 578 */     featureShortNames = fm.getEdgeFeatureShortNames();
/* 579 */     featureDimensions = fm.getEdgeFeatureDimensions();
/* 580 */     featureIsInt = fm.getEdgeFeatureIsInt();
/* 581 */     for (String feature : features) {
/*     */       
/* 583 */       Element fel = new Element("Feature");
/* 584 */       fel.setAttribute("feature", feature);
/* 585 */       fel.setAttribute("name", featureNames.get(feature));
/* 586 */       fel.setAttribute("shortname", featureShortNames.get(feature));
/* 587 */       fel.setAttribute("dimension", ((Dimension)featureDimensions.get(feature)).name());
/* 588 */       fel.setAttribute("isint", ((Boolean)featureIsInt.get(feature)).toString());
/* 589 */       edgeFeaturesElement.addContent((Content)fel);
/*     */     } 
/* 591 */     featuresElement.addContent((Content)edgeFeaturesElement);
/*     */ 
/*     */     
/* 594 */     Element trackFeaturesElement = new Element("TrackFeatures");
/* 595 */     features = fm.getTrackFeatures();
/* 596 */     featureNames = fm.getTrackFeatureNames();
/* 597 */     featureShortNames = fm.getTrackFeatureShortNames();
/* 598 */     featureDimensions = fm.getTrackFeatureDimensions();
/* 599 */     featureIsInt = fm.getTrackFeatureIsInt();
/* 600 */     for (String feature : features) {
/*     */       
/* 602 */       Element fel = new Element("Feature");
/* 603 */       fel.setAttribute("feature", feature);
/* 604 */       fel.setAttribute("name", featureNames.get(feature));
/* 605 */       fel.setAttribute("shortname", featureShortNames.get(feature));
/* 606 */       fel.setAttribute("dimension", ((Dimension)featureDimensions.get(feature)).name());
/* 607 */       fel.setAttribute("isint", ((Boolean)featureIsInt.get(feature)).toString());
/* 608 */       trackFeaturesElement.addContent((Content)fel);
/*     */     } 
/* 610 */     featuresElement.addContent((Content)trackFeaturesElement);
/*     */     
/* 612 */     this.logger.log("  Added spot, edge and track feature declarations.\n");
/* 613 */     return featuresElement;
/*     */   }
/*     */ 
/*     */   
/*     */   protected Element echoInitialSpotFilter(Settings settings) {
/* 618 */     Element itElement = new Element("InitialSpotFilter");
/* 619 */     itElement.setAttribute("feature", "QUALITY");
/* 620 */     itElement.setAttribute("value", "" + settings.initialSpotFilterValue);
/* 621 */     itElement.setAttribute("isabove", "true");
/* 622 */     this.logger.log("  Added initial spot filter.\n");
/* 623 */     return itElement;
/*     */   }
/*     */ 
/*     */   
/*     */   protected Element echoSpotFilters(Settings settings) {
/* 628 */     List<FeatureFilter> featureThresholds = settings.getSpotFilters();
/*     */     
/* 630 */     Element filtersElement = new Element("SpotFilterCollection");
/* 631 */     for (FeatureFilter threshold : featureThresholds) {
/*     */       
/* 633 */       Element thresholdElement = new Element("Filter");
/* 634 */       thresholdElement.setAttribute("feature", threshold.feature);
/* 635 */       thresholdElement.setAttribute("value", Double.toString(threshold.value));
/* 636 */       thresholdElement.setAttribute("isabove", "" + threshold.isAbove);
/* 637 */       filtersElement.addContent((Content)thresholdElement);
/*     */     } 
/* 639 */     this.logger.log("  Added spot feature filters.\n");
/* 640 */     return filtersElement;
/*     */   }
/*     */ 
/*     */   
/*     */   protected Element echoTrackFilters(Settings settings) {
/* 645 */     List<FeatureFilter> filters = settings.getTrackFilters();
/*     */     
/* 647 */     Element trackFiltersElement = new Element("TrackFilterCollection");
/* 648 */     for (FeatureFilter filter : filters) {
/*     */       
/* 650 */       Element thresholdElement = new Element("Filter");
/* 651 */       thresholdElement.setAttribute("feature", filter.feature);
/* 652 */       thresholdElement.setAttribute("value", Double.toString(filter.value));
/* 653 */       thresholdElement.setAttribute("isabove", "" + filter.isAbove);
/* 654 */       trackFiltersElement.addContent((Content)thresholdElement);
/*     */     } 
/* 656 */     this.logger.log("  Added track feature filters.\n");
/* 657 */     return trackFiltersElement;
/*     */   }
/*     */ 
/*     */   
/*     */   protected Element echoAnalyzers(Settings settings) {
/* 662 */     Element analyzersElement = new Element("AnalyzerCollection");
/*     */ 
/*     */     
/* 665 */     Element spotAnalyzersEl = new Element("SpotAnalyzers");
/* 666 */     for (SpotAnalyzerFactoryBase<?> analyzer : (Iterable<SpotAnalyzerFactoryBase<?>>)settings.getSpotAnalyzerFactories()) {
/*     */       
/* 668 */       Element el = new Element("Analyzer");
/* 669 */       el.setAttribute("key", analyzer.getKey());
/* 670 */       spotAnalyzersEl.addContent((Content)el);
/*     */     } 
/* 672 */     analyzersElement.addContent((Content)spotAnalyzersEl);
/*     */ 
/*     */     
/* 675 */     Element edgeAnalyzersEl = new Element("EdgeAnalyzers");
/* 676 */     for (EdgeAnalyzer analyzer : settings.getEdgeAnalyzers()) {
/*     */       
/* 678 */       Element el = new Element("Analyzer");
/* 679 */       el.setAttribute("key", analyzer.getKey());
/* 680 */       edgeAnalyzersEl.addContent((Content)el);
/*     */     } 
/* 682 */     analyzersElement.addContent((Content)edgeAnalyzersEl);
/*     */ 
/*     */     
/* 685 */     Element trackAnalyzersEl = new Element("TrackAnalyzers");
/* 686 */     for (TrackAnalyzer analyzer : settings.getTrackAnalyzers()) {
/*     */       
/* 688 */       Element el = new Element("Analyzer");
/* 689 */       el.setAttribute("key", analyzer.getKey());
/* 690 */       trackAnalyzersEl.addContent((Content)el);
/*     */     } 
/* 692 */     analyzersElement.addContent((Content)trackAnalyzersEl);
/*     */     
/* 694 */     this.logger.log("  Added spot, edge and track analyzers.\n");
/* 695 */     return analyzersElement;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final Element marshalSpot(Spot spot, FeatureModel fm) {
/* 704 */     Collection<Attribute> attributes = new ArrayList<>();
/* 705 */     Attribute IDattribute = new Attribute("ID", "" + spot.ID());
/* 706 */     attributes.add(IDattribute);
/* 707 */     Attribute nameAttribute = new Attribute("name", spot.getName());
/* 708 */     attributes.add(nameAttribute);
/*     */     
/* 710 */     for (String feature : spot.getFeatures().keySet()) {
/*     */       String str;
/* 712 */       Double val = spot.getFeature(feature);
/* 713 */       if (null == val) {
/*     */         continue;
/*     */       }
/*     */       
/* 717 */       if (((Boolean)fm.getSpotFeatureIsInt().getOrDefault(feature, Boolean.FALSE)).booleanValue()) {
/* 718 */         str = Integer.toString(val.intValue());
/*     */       } else {
/* 720 */         str = val.toString();
/*     */       } 
/* 722 */       attributes.add(new Attribute(feature, str));
/*     */     } 
/* 724 */     Element spotElement = new Element("Spot");
/*     */     
/* 726 */     SpotRoi roi = spot.getRoi();
/* 727 */     if (roi != null) {
/*     */       
/* 729 */       int nPoints = roi.x.length;
/* 730 */       attributes.add(new Attribute("ROI_N_POINTS", Integer.toString(nPoints)));
/* 731 */       StringBuilder str = new StringBuilder();
/* 732 */       for (int i = 0; i < nPoints; i++) {
/*     */         
/* 734 */         str.append(Double.toString(roi.x[i]));
/* 735 */         str.append(' ');
/* 736 */         str.append(Double.toString(roi.y[i]));
/* 737 */         str.append(' ');
/*     */       } 
/* 739 */       spotElement.setText(str.toString());
/*     */     } 
/*     */     
/* 742 */     spotElement.setAttributes(attributes);
/* 743 */     return spotElement;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/io/TmXmlWriter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */