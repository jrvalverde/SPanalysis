/*     */ package fiji.plugin.trackmate.features.spot;
/*     */ 
/*     */ import fiji.plugin.trackmate.Dimension;
/*     */ import fiji.plugin.trackmate.detection.DetectionUtils;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.swing.ImageIcon;
/*     */ import net.imagej.ImgPlus;
/*     */ import net.imglib2.type.NativeType;
/*     */ import net.imglib2.type.numeric.RealType;
/*     */ import org.scijava.plugin.Plugin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Plugin(type = SpotMorphologyAnalyzerFactory.class)
/*     */ public class SpotFitEllipseAnalyzerFactory<T extends RealType<T> & NativeType<T>>
/*     */   implements SpotMorphologyAnalyzerFactory<T>
/*     */ {
/*     */   public static final String KEY = "Spot fit 2D ellipse";
/*     */   public static final String X0 = "ELLIPSE_X0";
/*     */   public static final String Y0 = "ELLIPSE_Y0";
/*     */   public static final String MAJOR = "ELLIPSE_MAJOR";
/*     */   public static final String MINOR = "ELLIPSE_MINOR";
/*     */   public static final String THETA = "ELLIPSE_THETA";
/*     */   public static final String ASPECTRATIO = "ELLIPSE_ASPECTRATIO";
/*  52 */   private static final List<String> FEATURES = Arrays.asList(new String[] { "ELLIPSE_X0", "ELLIPSE_Y0", "ELLIPSE_MAJOR", "ELLIPSE_MINOR", "ELLIPSE_THETA", "ELLIPSE_ASPECTRATIO" });
/*     */   
/*  54 */   private static final Map<String, String> FEATURE_SHORTNAMES = new HashMap<>();
/*  55 */   private static final Map<String, String> FEATURE_NAMES = new HashMap<>();
/*  56 */   private static final Map<String, Dimension> FEATURE_DIMENSIONS = new HashMap<>();
/*  57 */   private static final Map<String, Boolean> FEATURE_ISINTS = new HashMap<>();
/*     */   
/*     */   static {
/*  60 */     FEATURE_SHORTNAMES.put("ELLIPSE_X0", "El. x0");
/*  61 */     FEATURE_SHORTNAMES.put("ELLIPSE_Y0", "El. y0");
/*  62 */     FEATURE_SHORTNAMES.put("ELLIPSE_MAJOR", "El. long axis");
/*  63 */     FEATURE_SHORTNAMES.put("ELLIPSE_MINOR", "El. sh. axis");
/*  64 */     FEATURE_SHORTNAMES.put("ELLIPSE_THETA", "El. angle");
/*  65 */     FEATURE_SHORTNAMES.put("ELLIPSE_ASPECTRATIO", "El. a.r.");
/*     */     
/*  67 */     FEATURE_NAMES.put("ELLIPSE_X0", "Ellipse center x0");
/*  68 */     FEATURE_NAMES.put("ELLIPSE_Y0", "Ellipse center y0");
/*  69 */     FEATURE_NAMES.put("ELLIPSE_MAJOR", "Ellipse long axis");
/*  70 */     FEATURE_NAMES.put("ELLIPSE_MINOR", "Ellipse short axis");
/*  71 */     FEATURE_NAMES.put("ELLIPSE_THETA", "Ellipse angle");
/*  72 */     FEATURE_NAMES.put("ELLIPSE_ASPECTRATIO", "Ellipse aspect ratio");
/*     */     
/*  74 */     FEATURE_DIMENSIONS.put("ELLIPSE_X0", Dimension.LENGTH);
/*  75 */     FEATURE_DIMENSIONS.put("ELLIPSE_Y0", Dimension.LENGTH);
/*  76 */     FEATURE_DIMENSIONS.put("ELLIPSE_MAJOR", Dimension.LENGTH);
/*  77 */     FEATURE_DIMENSIONS.put("ELLIPSE_MINOR", Dimension.LENGTH);
/*  78 */     FEATURE_DIMENSIONS.put("ELLIPSE_THETA", Dimension.ANGLE);
/*  79 */     FEATURE_DIMENSIONS.put("ELLIPSE_ASPECTRATIO", Dimension.NONE);
/*     */     
/*  81 */     FEATURE_ISINTS.put("ELLIPSE_X0", Boolean.FALSE);
/*  82 */     FEATURE_ISINTS.put("ELLIPSE_Y0", Boolean.FALSE);
/*  83 */     FEATURE_ISINTS.put("ELLIPSE_MAJOR", Boolean.FALSE);
/*  84 */     FEATURE_ISINTS.put("ELLIPSE_MINOR", Boolean.FALSE);
/*  85 */     FEATURE_ISINTS.put("ELLIPSE_THETA", Boolean.FALSE);
/*  86 */     FEATURE_ISINTS.put("ELLIPSE_ASPECTRATIO", Boolean.FALSE);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SpotAnalyzer<T> getAnalyzer(ImgPlus<T> img, int frame, int channel) {
/*  94 */     if (channel != 0) {
/*  95 */       return SpotAnalyzer.dummyAnalyzer();
/*     */     }
/*  97 */     return (SpotAnalyzer)new SpotFitEllipseAnalyzer<>(DetectionUtils.is2D(img));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public List<String> getFeatures() {
/* 103 */     return FEATURES;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, String> getFeatureShortNames() {
/* 109 */     return FEATURE_SHORTNAMES;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, String> getFeatureNames() {
/* 115 */     return FEATURE_NAMES;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, Dimension> getFeatureDimensions() {
/* 121 */     return FEATURE_DIMENSIONS;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, Boolean> getIsIntFeature() {
/* 127 */     return FEATURE_ISINTS;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isManualFeature() {
/* 133 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getInfoText() {
/* 139 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ImageIcon getIcon() {
/* 145 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getKey() {
/* 151 */     return "Spot fit 2D ellipse";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/* 157 */     return "Spot fit 2D ellipse";
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/features/spot/SpotFitEllipseAnalyzerFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */