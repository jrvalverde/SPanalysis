/*     */ package fiji.plugin.trackmate.gui.wizard;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AbstractAnimator
/*     */ {
/*     */   private final long duration;
/*     */   private long startTime;
/*     */   private boolean started;
/*     */   private double complete;
/*     */   
/*     */   public AbstractAnimator(long duration) {
/*  59 */     this.duration = duration;
/*  60 */     this.started = false;
/*  61 */     this.complete = 0.0D;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private double cos(double t) {
/*  69 */     return 0.5D - 0.5D * Math.cos(Math.PI * t);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTime(long time) {
/*  81 */     if (!this.started) {
/*     */       
/*  83 */       this.started = true;
/*  84 */       this.startTime = time;
/*     */     } 
/*     */     
/*  87 */     this.complete = (time - this.startTime) / this.duration;
/*  88 */     if (this.complete >= 1.0D) {
/*  89 */       this.complete = 1.0D;
/*     */     } else {
/*  91 */       this.complete = cos(cos(this.complete));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isComplete() {
/* 102 */     return (this.complete == 1.0D);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double ratioComplete() {
/* 114 */     return this.complete;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/gui/wizard/AbstractAnimator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */