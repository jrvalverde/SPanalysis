/*    */ package fiji.plugin.trackmate.visualization;
/*    */ 
/*    */ import fiji.plugin.trackmate.Model;
/*    */ import fiji.plugin.trackmate.gui.displaysettings.Colormap;
/*    */ import java.awt.Color;
/*    */ import org.jgrapht.graph.DefaultWeightedEdge;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PerEdgeFeatureColorGenerator
/*    */   implements TrackColorGenerator
/*    */ {
/*    */   private final Model model;
/*    */   private final String edgeFeature;
/*    */   private final Color missingValueColor;
/*    */   private final Color undefinedValueColor;
/*    */   private final Colormap colormap;
/*    */   private final double min;
/*    */   private final double max;
/*    */   
/*    */   public PerEdgeFeatureColorGenerator(Model model, String edgeFeature, Color missingValueColor, Color undefinedValueColor, Colormap colormap, double min, double max) {
/* 57 */     this.model = model;
/* 58 */     this.edgeFeature = edgeFeature;
/* 59 */     this.missingValueColor = missingValueColor;
/* 60 */     this.undefinedValueColor = undefinedValueColor;
/* 61 */     this.colormap = colormap;
/* 62 */     this.min = min;
/* 63 */     this.max = max;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Color color(DefaultWeightedEdge edge) {
/* 69 */     Double feat = this.model.getFeatureModel().getEdgeFeature(edge, this.edgeFeature);
/* 70 */     if (null == feat) {
/* 71 */       return this.missingValueColor;
/*    */     }
/* 73 */     if (feat.isNaN()) {
/* 74 */       return this.undefinedValueColor;
/*    */     }
/* 76 */     double val = feat.doubleValue();
/* 77 */     return this.colormap.getPaint((val - this.min) / (this.max - this.min));
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/visualization/PerEdgeFeatureColorGenerator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */