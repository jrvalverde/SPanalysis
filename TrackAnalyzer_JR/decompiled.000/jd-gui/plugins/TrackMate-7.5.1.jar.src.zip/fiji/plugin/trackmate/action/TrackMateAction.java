package fiji.plugin.trackmate.action;

import fiji.plugin.trackmate.Logger;
import fiji.plugin.trackmate.SelectionModel;
import fiji.plugin.trackmate.TrackMate;
import fiji.plugin.trackmate.gui.displaysettings.DisplaySettings;
import java.awt.Frame;

public interface TrackMateAction {
  void execute(TrackMate paramTrackMate, SelectionModel paramSelectionModel, DisplaySettings paramDisplaySettings, Frame paramFrame);
  
  void setLogger(Logger paramLogger);
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/action/TrackMateAction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */