/*      */ package fiji.plugin.trackmate.gui.displaysettings;
/*      */ 
/*      */ import fiji.plugin.trackmate.Settings;
/*      */ import fiji.plugin.trackmate.gui.Fonts;
/*      */ import fiji.plugin.trackmate.gui.GuiUtils;
/*      */ import fiji.plugin.trackmate.gui.Icons;
/*      */ import fiji.plugin.trackmate.gui.components.CategoryJComboBox;
/*      */ import fiji.plugin.trackmate.gui.components.FeatureDisplaySelector;
/*      */ import java.awt.Color;
/*      */ import java.awt.Component;
/*      */ import java.awt.Dialog;
/*      */ import java.awt.Dimension;
/*      */ import java.awt.Font;
/*      */ import java.awt.Graphics;
/*      */ import java.awt.Insets;
/*      */ import java.awt.Window;
/*      */ import java.awt.event.ActionEvent;
/*      */ import java.awt.event.ActionListener;
/*      */ import java.beans.PropertyChangeEvent;
/*      */ import java.text.DecimalFormat;
/*      */ import java.util.ArrayList;
/*      */ import java.util.function.BiConsumer;
/*      */ import java.util.function.BooleanSupplier;
/*      */ import java.util.function.Consumer;
/*      */ import java.util.function.DoubleSupplier;
/*      */ import java.util.function.IntSupplier;
/*      */ import java.util.function.Supplier;
/*      */ import javax.swing.Box;
/*      */ import javax.swing.BoxLayout;
/*      */ import javax.swing.DefaultComboBoxModel;
/*      */ import javax.swing.DefaultListCellRenderer;
/*      */ import javax.swing.JButton;
/*      */ import javax.swing.JCheckBox;
/*      */ import javax.swing.JColorChooser;
/*      */ import javax.swing.JComboBox;
/*      */ import javax.swing.JComponent;
/*      */ import javax.swing.JDialog;
/*      */ import javax.swing.JFormattedTextField;
/*      */ import javax.swing.JLabel;
/*      */ import javax.swing.JList;
/*      */ import javax.swing.JPanel;
/*      */ import javax.swing.JSpinner;
/*      */ import javax.swing.ListCellRenderer;
/*      */ import javax.swing.SpinnerListModel;
/*      */ import javax.swing.border.EmptyBorder;
/*      */ import javax.swing.event.ChangeEvent;
/*      */ import org.drjekyll.fontchooser.FontDialog;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class StyleElements
/*      */ {
/*   77 */   private static final DecimalFormat format = new DecimalFormat("#.###");
/*      */ 
/*      */   
/*      */   public static Separator separator() {
/*   81 */     return new Separator();
/*      */   }
/*      */ 
/*      */   
/*      */   public static LabelElement label(String label) {
/*   86 */     return new LabelElement(label);
/*      */   }
/*      */ 
/*      */   
/*      */   public static BooleanElement booleanElement(String label, final BooleanSupplier get, final Consumer<Boolean> set) {
/*   91 */     return new BooleanElement(label)
/*      */       {
/*      */         
/*      */         public boolean get()
/*      */         {
/*   96 */           return get.getAsBoolean();
/*      */         }
/*      */ 
/*      */ 
/*      */         
/*      */         public void set(boolean b) {
/*  102 */           set.accept(Boolean.valueOf(b));
/*      */         }
/*      */       };
/*      */   }
/*      */ 
/*      */   
/*      */   public static ColorElement colorElement(String label, final Supplier<Color> get, final Consumer<Color> set) {
/*  109 */     return new ColorElement(label)
/*      */       {
/*      */         
/*      */         public Color getColor()
/*      */         {
/*  114 */           return get.get();
/*      */         }
/*      */ 
/*      */ 
/*      */         
/*      */         public void setColor(Color c) {
/*  120 */           set.accept(c);
/*      */         }
/*      */       };
/*      */   }
/*      */ 
/*      */   
/*      */   public static ColormapElement colormapElement(String label, final Supplier<Colormap> get, final Consumer<Colormap> set) {
/*  127 */     return new ColormapElement(label)
/*      */       {
/*      */ 
/*      */         
/*      */         public Colormap get()
/*      */         {
/*  133 */           return get.get();
/*      */         }
/*      */ 
/*      */ 
/*      */         
/*      */         public void set(Colormap v) {
/*  139 */           set.accept(v);
/*      */         }
/*      */       };
/*      */   }
/*      */ 
/*      */   
/*      */   public static BoundedDoubleElement boundedDoubleElement(String label, double rangeMin, double rangeMax, final DoubleSupplier get, final Consumer<Double> set) {
/*  146 */     return new BoundedDoubleElement(label, rangeMin, rangeMax)
/*      */       {
/*      */         
/*      */         public double get()
/*      */         {
/*  151 */           return get.getAsDouble();
/*      */         }
/*      */ 
/*      */ 
/*      */         
/*      */         public void set(double v) {
/*  157 */           set.accept(Double.valueOf(v));
/*      */         }
/*      */       };
/*      */   }
/*      */ 
/*      */   
/*      */   public static DoubleElement doubleElement(String label, final DoubleSupplier get, final Consumer<Double> set) {
/*  164 */     return new DoubleElement(label)
/*      */       {
/*      */         
/*      */         public double get()
/*      */         {
/*  169 */           return get.getAsDouble();
/*      */         }
/*      */ 
/*      */ 
/*      */         
/*      */         public void set(double v) {
/*  175 */           set.accept(Double.valueOf(v));
/*      */         }
/*      */       };
/*      */   }
/*      */ 
/*      */   
/*      */   public static IntElement intElement(String label, int rangeMin, int rangeMax, final IntSupplier get, final Consumer<Integer> set) {
/*  182 */     return new IntElement(label, rangeMin, rangeMax)
/*      */       {
/*      */         
/*      */         public int get()
/*      */         {
/*  187 */           return get.getAsInt();
/*      */         }
/*      */ 
/*      */ 
/*      */         
/*      */         public void set(int v) {
/*  193 */           set.accept(Integer.valueOf(v));
/*      */         }
/*      */       };
/*      */   }
/*      */ 
/*      */   
/*      */   public static <E> EnumElement<E> enumElement(String label, E[] values, final Supplier<E> get, final Consumer<E> set) {
/*  200 */     return new EnumElement<E>(label, (Object[])values)
/*      */       {
/*      */ 
/*      */         
/*      */         public E getValue()
/*      */         {
/*  206 */           return get.get();
/*      */         }
/*      */ 
/*      */ 
/*      */         
/*      */         public void setValue(E e) {
/*  212 */           set.accept(e);
/*      */         }
/*      */       };
/*      */   }
/*      */ 
/*      */   
/*      */   public static FeatureElement featureElement(String label, final Supplier<DisplaySettings.TrackMateObject> typeGet, final Supplier<String> featureGet, final BiConsumer<DisplaySettings.TrackMateObject, String> set) {
/*  219 */     return new FeatureElement(label)
/*      */       {
/*      */ 
/*      */         
/*      */         public void setValue(DisplaySettings.TrackMateObject type, String feature)
/*      */         {
/*  225 */           set.accept(type, feature);
/*      */         }
/*      */ 
/*      */ 
/*      */         
/*      */         public DisplaySettings.TrackMateObject getType() {
/*  231 */           return typeGet.get();
/*      */         }
/*      */ 
/*      */ 
/*      */         
/*      */         public String getFeature() {
/*  237 */           return featureGet.get();
/*      */         }
/*      */       };
/*      */   }
/*      */ 
/*      */   
/*      */   public static FontElement fontElement(String label, final Supplier<Font> get, final Consumer<Font> set) {
/*  244 */     return new FontElement(label)
/*      */       {
/*      */ 
/*      */         
/*      */         public void set(Font font)
/*      */         {
/*  250 */           set.accept(font);
/*      */         }
/*      */ 
/*      */ 
/*      */         
/*      */         public Font get() {
/*  256 */           return get.get();
/*      */         }
/*      */       };
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static interface StyleElementVisitor
/*      */   {
/*      */     default void visit(StyleElements.Separator element) {
/*  269 */       throw new UnsupportedOperationException();
/*      */     }
/*      */ 
/*      */     
/*      */     default void visit(StyleElements.LabelElement label) {
/*  274 */       throw new UnsupportedOperationException();
/*      */     }
/*      */ 
/*      */     
/*      */     default void visit(StyleElements.ColorElement colorElement) {
/*  279 */       throw new UnsupportedOperationException();
/*      */     }
/*      */ 
/*      */     
/*      */     default void visit(StyleElements.BooleanElement booleanElement) {
/*  284 */       throw new UnsupportedOperationException();
/*      */     }
/*      */ 
/*      */     
/*      */     default void visit(StyleElements.BoundedDoubleElement doubleElement) {
/*  289 */       throw new UnsupportedOperationException();
/*      */     }
/*      */ 
/*      */     
/*      */     default void visit(StyleElements.DoubleElement doubleElement) {
/*  294 */       throw new UnsupportedOperationException();
/*      */     }
/*      */ 
/*      */     
/*      */     default void visit(StyleElements.IntElement intElement) {
/*  299 */       throw new UnsupportedOperationException();
/*      */     }
/*      */ 
/*      */     
/*      */     default <E> void visit(StyleElements.EnumElement<E> enumElement) {
/*  304 */       throw new UnsupportedOperationException();
/*      */     }
/*      */ 
/*      */     
/*      */     default void visit(StyleElements.FeatureElement featureElement) {
/*  309 */       throw new UnsupportedOperationException();
/*      */     }
/*      */ 
/*      */     
/*      */     default void visit(StyleElements.ColormapElement element) {
/*  314 */       throw new UnsupportedOperationException();
/*      */     }
/*      */ 
/*      */     
/*      */     default void visit(StyleElements.FontElement fontElement) {
/*  319 */       throw new UnsupportedOperationException();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static interface StyleElement
/*      */   {
/*      */     default void update() {}
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     void accept(StyleElements.StyleElementVisitor param1StyleElementVisitor);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class Separator
/*      */     implements StyleElement
/*      */   {
/*      */     public void accept(StyleElements.StyleElementVisitor visitor) {
/*  343 */       visitor.visit(this);
/*      */     }
/*      */   }
/*      */   
/*      */   public static class LabelElement
/*      */     implements StyleElement
/*      */   {
/*      */     private final String label;
/*      */     
/*      */     public LabelElement(String label) {
/*  353 */       this.label = label;
/*      */     }
/*      */ 
/*      */     
/*      */     public String getLabel() {
/*  358 */       return this.label;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public void accept(StyleElements.StyleElementVisitor visitor) {
/*  364 */       visitor.visit(this);
/*      */     }
/*      */   }
/*      */   
/*      */   public static abstract class EnumElement<E>
/*      */     implements StyleElement {
/*  370 */     private final ArrayList<Consumer<E>> onSet = new ArrayList<>();
/*      */     
/*      */     private final String label;
/*      */     
/*      */     private final E[] values;
/*      */ 
/*      */     
/*      */     public EnumElement(String label, E[] values) {
/*  378 */       this.label = label;
/*  379 */       this.values = values;
/*      */     }
/*      */ 
/*      */     
/*      */     public String getLabel() {
/*  384 */       return this.label;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public void accept(StyleElements.StyleElementVisitor visitor) {
/*  390 */       visitor.visit(this);
/*      */     }
/*      */ 
/*      */     
/*      */     public void onSet(Consumer<E> set) {
/*  395 */       this.onSet.add(set);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public void update() {
/*  401 */       this.onSet.forEach(c -> c.accept(getValue()));
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public abstract E getValue();
/*      */ 
/*      */     
/*      */     public E[] getValues() {
/*  410 */       return this.values;
/*      */     }
/*      */     
/*      */     public abstract void setValue(E param1E); }
/*      */   
/*      */   public static abstract class FeatureElement implements StyleElement {
/*  416 */     private final ArrayList<BiConsumer<DisplaySettings.TrackMateObject, String>> onSet = new ArrayList<>();
/*      */     
/*      */     private final String label;
/*      */ 
/*      */     
/*      */     public FeatureElement(String label) {
/*  422 */       this.label = label;
/*      */     }
/*      */ 
/*      */     
/*      */     public String getLabel() {
/*  427 */       return this.label;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public void accept(StyleElements.StyleElementVisitor visitor) {
/*  433 */       visitor.visit(this);
/*      */     }
/*      */ 
/*      */     
/*      */     public void onSet(BiConsumer<DisplaySettings.TrackMateObject, String> set) {
/*  438 */       this.onSet.add(set);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public void update() {
/*  444 */       this.onSet.forEach(c -> c.accept(getType(), getFeature()));
/*      */     }
/*      */     
/*      */     public abstract DisplaySettings.TrackMateObject getType();
/*      */     
/*      */     public abstract String getFeature();
/*      */     
/*      */     public abstract void setValue(DisplaySettings.TrackMateObject param1TrackMateObject, String param1String);
/*      */   }
/*      */   
/*      */   public static abstract class ColorElement
/*      */     implements StyleElement {
/*  456 */     private final ArrayList<Consumer<Color>> onSet = new ArrayList<>();
/*      */     
/*      */     private final String label;
/*      */ 
/*      */     
/*      */     public ColorElement(String label) {
/*  462 */       this.label = label;
/*      */     }
/*      */ 
/*      */     
/*      */     public String getLabel() {
/*  467 */       return this.label;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public void accept(StyleElements.StyleElementVisitor visitor) {
/*  473 */       visitor.visit(this);
/*      */     }
/*      */ 
/*      */     
/*      */     public void onSet(Consumer<Color> set) {
/*  478 */       this.onSet.add(set);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public void update() {
/*  484 */       this.onSet.forEach(c -> c.accept(getColor()));
/*      */     }
/*      */     
/*      */     public abstract Color getColor();
/*      */     
/*      */     public abstract void setColor(Color param1Color);
/*      */   }
/*      */   
/*      */   public static abstract class BooleanElement
/*      */     implements StyleElement
/*      */   {
/*      */     private final String label;
/*  496 */     private final ArrayList<Consumer<Boolean>> onSet = new ArrayList<>();
/*      */ 
/*      */     
/*      */     public BooleanElement(String label) {
/*  500 */       this.label = label;
/*      */     }
/*      */ 
/*      */     
/*      */     public String getLabel() {
/*  505 */       return this.label;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public void accept(StyleElements.StyleElementVisitor visitor) {
/*  511 */       visitor.visit(this);
/*      */     }
/*      */ 
/*      */     
/*      */     public void onSet(Consumer<Boolean> set) {
/*  516 */       this.onSet.add(set);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public void update() {
/*  522 */       this.onSet.forEach(c -> c.accept(Boolean.valueOf(get())));
/*      */     }
/*      */ 
/*      */     
/*      */     public abstract boolean get();
/*      */     
/*      */     public abstract void set(boolean param1Boolean);
/*      */   }
/*      */   
/*      */   public static abstract class BoundedDoubleElement
/*      */     implements StyleElement
/*      */   {
/*      */     private final BoundedValueDouble value;
/*      */     private final String label;
/*      */     
/*      */     public BoundedDoubleElement(String label, double rangeMin, double rangeMax) {
/*  538 */       double currentValue = Math.max(rangeMin, Math.min(rangeMax, get()));
/*  539 */       this.value = new BoundedValueDouble(rangeMin, rangeMax, currentValue)
/*      */         {
/*      */           
/*      */           public void setCurrentValue(double value)
/*      */           {
/*  544 */             super.setCurrentValue(value);
/*  545 */             if (StyleElements.BoundedDoubleElement.this.get() != getCurrentValue())
/*  546 */               StyleElements.BoundedDoubleElement.this.set(getCurrentValue()); 
/*      */           }
/*      */         };
/*  549 */       this.label = label;
/*      */     }
/*      */ 
/*      */     
/*      */     public BoundedValueDouble getValue() {
/*  554 */       return this.value;
/*      */     }
/*      */ 
/*      */     
/*      */     public String getLabel() {
/*  559 */       return this.label;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public void accept(StyleElements.StyleElementVisitor visitor) {
/*  565 */       visitor.visit(this);
/*      */     }
/*      */ 
/*      */     
/*      */     public abstract double get();
/*      */ 
/*      */     
/*      */     public abstract void set(double param1Double);
/*      */     
/*      */     public void update() {
/*  575 */       if (get() != this.value.getCurrentValue())
/*  576 */         this.value.setCurrentValue(get()); 
/*      */     }
/*      */   }
/*      */   
/*      */   public static abstract class DoubleElement
/*      */     implements StyleElement
/*      */   {
/*  583 */     private final ArrayList<Consumer<Double>> onSet = new ArrayList<>();
/*      */     
/*      */     private double value;
/*      */     
/*      */     private final String label;
/*      */ 
/*      */     
/*      */     public DoubleElement(String label) {
/*  591 */       this.value = 0.0D;
/*  592 */       this.label = label;
/*      */     }
/*      */ 
/*      */     
/*      */     public double getValue() {
/*  597 */       return this.value;
/*      */     }
/*      */ 
/*      */     
/*      */     public String getLabel() {
/*  602 */       return this.label;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public void accept(StyleElements.StyleElementVisitor visitor) {
/*  608 */       visitor.visit(this);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void onSet(Consumer<Double> set) {
/*  617 */       this.onSet.add(set);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public void update() {
/*  623 */       if (get() != this.value)
/*  624 */         this.value = get(); 
/*      */     }
/*      */     
/*      */     public abstract double get();
/*      */     
/*      */     public abstract void set(double param1Double); }
/*      */   
/*      */   public static abstract class IntElement implements StyleElement {
/*      */     private final BoundedValue value;
/*      */     private final String label;
/*      */     
/*      */     public IntElement(String label, int rangeMin, int rangeMax) {
/*  636 */       int currentValue = Math.max(rangeMin, Math.min(rangeMax, get()));
/*  637 */       this.value = new BoundedValue(rangeMin, rangeMax, currentValue)
/*      */         {
/*      */           
/*      */           public void setCurrentValue(int value)
/*      */           {
/*  642 */             super.setCurrentValue(value);
/*  643 */             if (StyleElements.IntElement.this.get() != getCurrentValue())
/*  644 */               StyleElements.IntElement.this.set(getCurrentValue()); 
/*      */           }
/*      */         };
/*  647 */       this.label = label;
/*      */     }
/*      */ 
/*      */     
/*      */     public BoundedValue getValue() {
/*  652 */       return this.value;
/*      */     }
/*      */ 
/*      */     
/*      */     public String getLabel() {
/*  657 */       return this.label;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public void accept(StyleElements.StyleElementVisitor visitor) {
/*  663 */       visitor.visit(this);
/*      */     }
/*      */ 
/*      */     
/*      */     public abstract int get();
/*      */ 
/*      */     
/*      */     public abstract void set(int param1Int);
/*      */     
/*      */     public void update() {
/*  673 */       if (get() != this.value.getCurrentValue())
/*  674 */         this.value.setCurrentValue(get()); 
/*      */     }
/*      */   }
/*      */   
/*      */   public static abstract class ColormapElement
/*      */     implements StyleElement {
/*  680 */     private final ArrayList<Consumer<Colormap>> onSet = new ArrayList<>();
/*      */     
/*      */     private final String label;
/*      */ 
/*      */     
/*      */     public ColormapElement(String label) {
/*  686 */       this.label = label;
/*      */     }
/*      */ 
/*      */     
/*      */     public String getLabel() {
/*  691 */       return this.label;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public void accept(StyleElements.StyleElementVisitor visitor) {
/*  697 */       visitor.visit(this);
/*      */     }
/*      */ 
/*      */     
/*      */     public abstract Colormap get();
/*      */     
/*      */     public abstract void set(Colormap param1Colormap);
/*      */     
/*      */     public void onSet(Consumer<Colormap> set) {
/*  706 */       this.onSet.add(set);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public void update() {
/*  712 */       this.onSet.forEach(c -> c.accept(get()));
/*      */     }
/*      */   }
/*      */   
/*      */   public static abstract class FontElement
/*      */     implements StyleElement
/*      */   {
/*  719 */     private final ArrayList<Consumer<Font>> onSet = new ArrayList<>();
/*      */     
/*      */     private Font value;
/*      */     
/*      */     private final String label;
/*      */ 
/*      */     
/*      */     public FontElement(String label) {
/*  727 */       this.label = label;
/*      */     }
/*      */ 
/*      */     
/*      */     public Font getValue() {
/*  732 */       return this.value;
/*      */     }
/*      */ 
/*      */     
/*      */     public String getLabel() {
/*  737 */       return this.label;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public void accept(StyleElements.StyleElementVisitor visitor) {
/*  743 */       visitor.visit(this);
/*      */     }
/*      */ 
/*      */     
/*      */     public abstract Font get();
/*      */     
/*      */     public abstract void set(Font param1Font);
/*      */     
/*      */     public void onSet(Consumer<Font> set) {
/*  752 */       this.onSet.add(set);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public void update() {
/*  758 */       if (get() != this.value) {
/*  759 */         this.value = get();
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static JLabel linkedLabel(LabelElement element) {
/*  771 */     return new JLabel(element.getLabel());
/*      */   }
/*      */ 
/*      */   
/*      */   public static CategoryJComboBox<DisplaySettings.TrackMateObject, String> linkedFeatureSelector(FeatureElement element) {
/*  776 */     Settings settings = new Settings();
/*  777 */     settings.addAllAnalyzers();
/*  778 */     CategoryJComboBox<DisplaySettings.TrackMateObject, String> selector = FeatureDisplaySelector.createComboBoxSelector(null, settings);
/*  779 */     selector.setSelectedItem(element.getFeature());
/*  780 */     selector.addActionListener(e -> element.setValue((DisplaySettings.TrackMateObject)selector.getSelectedCategory(), (String)selector.getSelectedItem()));
/*  781 */     element.onSet((type, feature) -> {
/*      */           if (!feature.equals(selector.getSelectedItem()))
/*      */             selector.setSelectedItem(feature); 
/*      */         });
/*  785 */     return selector;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static JComboBox<Colormap> linkedColormapChooser(ColormapElement element) {
/*  791 */     JComboBox<Colormap> cb = new JComboBox<>(Colormap.getAvailableLUTs().toArray(new Colormap[0]));
/*  792 */     cb.setRenderer(new ColormapRenderer());
/*  793 */     cb.setSelectedItem(element.get());
/*  794 */     cb.addActionListener(e -> element.set((Colormap)cb.getSelectedItem()));
/*  795 */     element.onSet(cm -> {
/*      */           if (cm != cb.getSelectedItem())
/*      */             cb.setSelectedItem(cm); 
/*      */         });
/*  799 */     return cb;
/*      */   }
/*      */   
/*      */   private static final class ColormapRenderer
/*      */     extends JPanel
/*      */     implements ListCellRenderer<Colormap>
/*      */   {
/*      */     private static final long serialVersionUID = 1L;
/*  807 */     private Colormap lut = Colormap.Jet;
/*      */     
/*      */     private final DefaultListCellRenderer lbl;
/*      */ 
/*      */     
/*      */     public ColormapRenderer() {
/*  813 */       setPreferredSize(new Dimension(150, 20));
/*  814 */       BoxLayout itemlayout = new BoxLayout(this, 2);
/*  815 */       this.lbl = new DefaultListCellRenderer();
/*  816 */       setLayout(itemlayout);
/*  817 */       add(this.lbl);
/*  818 */       add(Box.createHorizontalGlue());
/*  819 */       add(new JComponent()
/*      */           {
/*      */             private static final long serialVersionUID = 1L;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             public void paint(Graphics g) {
/*  828 */               int width = getWidth();
/*  829 */               int height = getHeight();
/*  830 */               for (int i = 0; i < width; i++) {
/*      */                 
/*  832 */                 double beta = i / (width - 1);
/*  833 */                 g.setColor(StyleElements.ColormapRenderer.this.lut.getPaint(beta));
/*  834 */                 g.drawLine(i, 0, i, height);
/*      */               } 
/*  836 */               g.setColor(getParent().getBackground());
/*  837 */               g.drawRect(0, 0, width, height);
/*      */             }
/*      */ 
/*      */ 
/*      */             
/*      */             public Dimension getMaximumSize() {
/*  843 */               return new Dimension(100, 20);
/*      */             }
/*      */ 
/*      */ 
/*      */             
/*      */             public Dimension getPreferredSize() {
/*  849 */               return getMaximumSize();
/*      */             }
/*      */           });
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Component getListCellRendererComponent(JList<? extends Colormap> list, Colormap value, int index, boolean isSelected, boolean cellHasFocus) {
/*  862 */       this.lut = value;
/*  863 */       this.lbl.getListCellRendererComponent(list, value.getName(), index, isSelected, cellHasFocus);
/*  864 */       setBackground(this.lbl.getBackground());
/*  865 */       return this;
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public static JCheckBox linkedCheckBox(BooleanElement element, String label) {
/*  871 */     JCheckBox checkbox = new JCheckBox(label, element.get());
/*  872 */     checkbox.addActionListener(e -> element.set(checkbox.isSelected()));
/*  873 */     element.onSet(b -> {
/*      */           if (b.booleanValue() != checkbox.isSelected())
/*      */             checkbox.setSelected(b.booleanValue()); 
/*      */         });
/*  877 */     return checkbox;
/*      */   }
/*      */ 
/*      */   
/*      */   public static JButton linkedColorButton(final ColorElement element, final JColorChooser colorChooser) {
/*  882 */     final ColorIcon icon = new ColorIcon(element.getColor(), 16, 0);
/*  883 */     final JButton button = new JButton(icon);
/*  884 */     button.setOpaque(false);
/*  885 */     button.setContentAreaFilled(false);
/*  886 */     button.setBorderPainted(false);
/*  887 */     button.setFont((new JButton()).getFont());
/*  888 */     button.setMargin(new Insets(0, 0, 0, 0));
/*  889 */     button.setBorder(new EmptyBorder(2, 5, 2, 2));
/*  890 */     button.setHorizontalAlignment(2);
/*  891 */     button.addActionListener(e -> {
/*      */           colorChooser.setColor(element.getColor());
/*      */           
/*      */           JDialog d = JColorChooser.createDialog(button, "Choose a color", true, colorChooser, new ActionListener()
/*      */               {
/*      */                 public void actionPerformed(ActionEvent arg0)
/*      */                 {
/*  898 */                   Color c = colorChooser.getColor();
/*  899 */                   if (c != null) {
/*      */                     
/*  901 */                     icon.setColor(c);
/*  902 */                     button.repaint();
/*  903 */                     element.setColor(c);
/*      */                   } 
/*      */                 }
/*      */               },  null);
/*      */           d.setVisible(true);
/*      */         });
/*  909 */     element.onSet(icon::setColor);
/*  910 */     return button;
/*      */   }
/*      */ 
/*      */   
/*      */   public static SliderPanel linkedSliderPanel(IntElement element, int tfCols) {
/*  915 */     SliderPanel slider = new SliderPanel(null, element.getValue(), 1);
/*  916 */     slider.setNumColummns(tfCols);
/*  917 */     slider.setBorder(new EmptyBorder(0, 0, 0, 0));
/*  918 */     return slider;
/*      */   }
/*      */ 
/*      */   
/*      */   public static SliderPanelDouble linkedSliderPanel(BoundedDoubleElement element, int tfCols) {
/*  923 */     return linkedSliderPanel(element, tfCols, 1.0D);
/*      */   }
/*      */ 
/*      */   
/*      */   public static SliderPanelDouble linkedSliderPanel(BoundedDoubleElement element, int tfCols, double stepSize) {
/*  928 */     SliderPanelDouble slider = new SliderPanelDouble(null, element.getValue(), stepSize);
/*  929 */     slider.setDecimalFormat("0.####");
/*  930 */     slider.setNumColummns(tfCols);
/*  931 */     slider.setBorder(new EmptyBorder(0, 0, 0, 0));
/*  932 */     return slider;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static <E> JSpinner linkedSpinnerEnumSelector(EnumElement<E> element) {
/*  938 */     SpinnerListModel model = new SpinnerListModel((Object[])element.getValues());
/*  939 */     JSpinner spinner = new JSpinner(model);
/*  940 */     spinner.setFont(Fonts.SMALL_FONT);
/*  941 */     ((JSpinner.DefaultEditor)spinner.getEditor()).getTextField().setEditable(false);
/*  942 */     model.setValue(element.getValue());
/*  943 */     model.addChangeListener(e -> element.setValue(model.getValue()));
/*  944 */     element.onSet(e -> {
/*      */           if (e != model.getValue())
/*      */             model.setValue(e); 
/*      */         });
/*  948 */     return spinner;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static <E> JComboBox<E> linkedComboBoxEnumSelector(EnumElement<E> element) {
/*  954 */     DefaultComboBoxModel<E> model = new DefaultComboBoxModel<>(element.values);
/*  955 */     JComboBox<E> cb = new JComboBox<>(model);
/*  956 */     cb.setFont(Fonts.SMALL_FONT);
/*  957 */     cb.addActionListener(e -> element.setValue(model.getSelectedItem()));
/*  958 */     element.onSet(e -> {
/*      */           if (e != model.getSelectedItem())
/*      */             model.setSelectedItem(e); 
/*      */         });
/*  962 */     return cb;
/*      */   }
/*      */ 
/*      */   
/*      */   public static JFormattedTextField linkedFormattedTextField(DoubleElement element) {
/*  967 */     JFormattedTextField ftf = new JFormattedTextField(format);
/*  968 */     ftf.setHorizontalAlignment(4);
/*  969 */     ftf.setValue(Double.valueOf(element.get()));
/*  970 */     GuiUtils.selectAllOnFocus(ftf);
/*      */     
/*  972 */     ftf.addActionListener(e -> element.set(((Number)ftf.getValue()).doubleValue()));
/*  973 */     element.onSet(d -> {
/*      */           if (d.doubleValue() != ((Number)ftf.getValue()).doubleValue()) {
/*      */             ftf.setValue(Double.valueOf(element.value));
/*      */           }
/*      */         });
/*  978 */     return ftf;
/*      */   }
/*      */ 
/*      */   
/*      */   public static JButton linkedFontButton(FontElement element, Window parent) {
/*  983 */     JButton btn = new JButton("Select font");
/*  984 */     btn.setFont(element.get());
/*  985 */     btn.addPropertyChangeListener("font", e -> element.set(btn.getFont()));
/*  986 */     element.onSet(font -> {
/*      */           if (!font.equals(btn.getFont()))
/*      */             btn.setFont(font); 
/*      */         });
/*  990 */     btn.addActionListener(e -> {
/*      */           FontDialog dialog = new FontDialog(parent, "Select font for TrackMate display", Dialog.ModalityType.APPLICATION_MODAL);
/*      */           dialog.setDefaultCloseOperation(2);
/*      */           dialog.setSelectedFont(btn.getFont());
/*      */           GuiUtils.positionWindow((Window)dialog, parent);
/*      */           dialog.setIconImage(Icons.TRACKMATE_ICON.getImage());
/*      */           dialog.setVisible(true);
/*      */           if (!dialog.isCancelSelected())
/*      */             btn.setFont(dialog.getSelectedFont()); 
/*      */         });
/* 1000 */     return btn;
/*      */   }
/*      */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/gui/displaysettings/StyleElements.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */