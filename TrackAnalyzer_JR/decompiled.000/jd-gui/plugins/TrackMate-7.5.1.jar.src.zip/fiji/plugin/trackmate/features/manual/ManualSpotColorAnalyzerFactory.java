/*     */ package fiji.plugin.trackmate.features.manual;
/*     */ 
/*     */ import fiji.plugin.trackmate.Dimension;
/*     */ import fiji.plugin.trackmate.features.spot.SpotAnalyzer;
/*     */ import fiji.plugin.trackmate.features.spot.SpotAnalyzerFactory;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.swing.ImageIcon;
/*     */ import net.imagej.ImgPlus;
/*     */ import net.imglib2.type.NativeType;
/*     */ import net.imglib2.type.numeric.RealType;
/*     */ import org.scijava.plugin.Plugin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Plugin(type = SpotAnalyzerFactory.class)
/*     */ public class ManualSpotColorAnalyzerFactory<T extends RealType<T> & NativeType<T>>
/*     */   implements SpotAnalyzerFactory<T>
/*     */ {
/*     */   public static final String FEATURE = "MANUAL_SPOT_COLOR";
/*     */   public static final String KEY = "Manual spot color";
/*  48 */   static final List<String> FEATURES = new ArrayList<>(1);
/*     */   
/*  50 */   static final Map<String, String> FEATURE_SHORT_NAMES = new HashMap<>(1);
/*     */   
/*  52 */   static final Map<String, String> FEATURE_NAMES = new HashMap<>(1);
/*     */   
/*  54 */   static final Map<String, Dimension> FEATURE_DIMENSIONS = new HashMap<>(1);
/*     */   
/*  56 */   static final Map<String, Boolean> IS_INT = new HashMap<>(1);
/*     */   
/*     */   static final String INFO_TEXT = "<html>A dummy analyzer for the feature that stores the color manually assigned to each spot.</html>";
/*     */   
/*     */   static final String NAME = "Manual spot color";
/*     */ 
/*     */   
/*     */   static {
/*  64 */     FEATURES.add("MANUAL_SPOT_COLOR");
/*  65 */     FEATURE_SHORT_NAMES.put("MANUAL_SPOT_COLOR", "Spot color");
/*  66 */     FEATURE_NAMES.put("MANUAL_SPOT_COLOR", "Manual spot color");
/*  67 */     FEATURE_DIMENSIONS.put("MANUAL_SPOT_COLOR", Dimension.NONE);
/*  68 */     IS_INT.put("MANUAL_SPOT_COLOR", Boolean.TRUE);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getKey() {
/*  74 */     return "Manual spot color";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public List<String> getFeatures() {
/*  80 */     return FEATURES;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, String> getFeatureShortNames() {
/*  86 */     return FEATURE_SHORT_NAMES;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, String> getFeatureNames() {
/*  92 */     return FEATURE_NAMES;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, Dimension> getFeatureDimensions() {
/*  98 */     return FEATURE_DIMENSIONS;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getInfoText() {
/* 104 */     return "<html>A dummy analyzer for the feature that stores the color manually assigned to each spot.</html>";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, Boolean> getIsIntFeature() {
/* 110 */     return IS_INT;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isManualFeature() {
/* 116 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ImageIcon getIcon() {
/* 122 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/* 128 */     return "Manual spot color";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public SpotAnalyzer<T> getAnalyzer(ImgPlus<T> img, int frame, int channel) {
/* 134 */     return SpotAnalyzer.dummyAnalyzer();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/features/manual/ManualSpotColorAnalyzerFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */