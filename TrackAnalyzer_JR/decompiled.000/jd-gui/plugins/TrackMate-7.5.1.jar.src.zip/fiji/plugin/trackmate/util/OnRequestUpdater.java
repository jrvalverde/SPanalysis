/*     */ package fiji.plugin.trackmate.util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OnRequestUpdater
/*     */   extends Thread
/*     */ {
/*  76 */   private long request = 0L;
/*     */ 
/*     */   
/*     */   private final Refreshable refreshable;
/*     */ 
/*     */   
/*     */   public OnRequestUpdater(Refreshable refreshable) {
/*  83 */     super("OnRequestUpdater for " + refreshable.toString());
/*  84 */     this.refreshable = refreshable;
/*  85 */     setPriority(5);
/*  86 */     start();
/*     */   }
/*     */   
/*     */   public void doUpdate() {
/*  90 */     if (isInterrupted())
/*     */       return; 
/*  92 */     synchronized (this) {
/*  93 */       this.request++;
/*  94 */       notify();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void quit() {
/*  99 */     interrupt();
/* 100 */     synchronized (this) {
/* 101 */       notify();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void run() {
/* 107 */     while (!isInterrupted()) {
/*     */       try {
/*     */         long r;
/* 110 */         synchronized (this) {
/* 111 */           r = this.request;
/*     */         } 
/*     */         
/* 114 */         if (r > 0L)
/* 115 */           this.refreshable.refresh(); 
/* 116 */         synchronized (this) {
/* 117 */           if (r == this.request) {
/* 118 */             this.request = 0L;
/* 119 */             wait();
/*     */           }
/*     */         
/*     */         } 
/* 123 */       } catch (Exception e) {
/* 124 */         Exception exception1; exception1.printStackTrace();
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public static interface Refreshable {
/*     */     void refresh();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/util/OnRequestUpdater.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */