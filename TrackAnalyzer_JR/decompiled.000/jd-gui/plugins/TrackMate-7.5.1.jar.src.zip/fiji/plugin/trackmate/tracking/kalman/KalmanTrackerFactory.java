/*     */ package fiji.plugin.trackmate.tracking.kalman;
/*     */ 
/*     */ import fiji.plugin.trackmate.Model;
/*     */ import fiji.plugin.trackmate.SpotCollection;
/*     */ import fiji.plugin.trackmate.gui.components.ConfigurationPanel;
/*     */ import fiji.plugin.trackmate.gui.components.tracker.KalmanTrackerConfigPanel;
/*     */ import fiji.plugin.trackmate.io.IOUtils;
/*     */ import fiji.plugin.trackmate.tracking.SpotTracker;
/*     */ import fiji.plugin.trackmate.tracking.SpotTrackerFactory;
/*     */ import fiji.plugin.trackmate.util.TMUtils;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import javax.swing.ImageIcon;
/*     */ import org.jdom2.Element;
/*     */ import org.scijava.plugin.Plugin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Plugin(type = SpotTrackerFactory.class)
/*     */ public class KalmanTrackerFactory
/*     */   implements SpotTrackerFactory
/*     */ {
/*     */   private static final String INFO_TEXT_PART2 = "This tracker needs two parameters (on top of the maximal frame gap tolerated): <br/>\t - the max search radius defines how far from a predicted position it should look for candidate spots;<br/>\t - the initial search radius defines how far two spots can be apart when initiating a new track.<br/></html>";
/*     */   private static final String INFO_TEXT = "<html>This tracker is best suited for objects that move with a roughly constant velocity vector.<p>It relies on the Kalman filter to predict the next most likely position of a spot. The predictions for all current tracks are linked to the spots actually found in the next frame, thanks to the LAP framework already present in the LAP tracker. Predictions are continuously refined and the tracker can accommodate moderate velocity direction and magnitude changes. <p>This tracker can bridge gaps: If a spot is not found close enough to a prediction, then the Kalman filter will make another prediction in the next frame and re-iterate the search. <p>The first frames of a track are critical for this tracker to work properly: Tracksare initiated by looking for close neighbors (again via the LAP tracker). Spurious spots in the beginning of each track can confuse the tracker.<p>This tracker needs two parameters (on top of the maximal frame gap tolerated): <br/>\t - the max search radius defines how far from a predicted position it should look for candidate spots;<br/>\t - the initial search radius defines how far two spots can be apart when initiating a new track.<br/></html>";
/*     */   public static final String KEY = "KALMAN_TRACKER";
/*     */   public static final String NAME = "Kalman tracker";
/*     */   public static final String KEY_KALMAN_SEARCH_RADIUS = "KALMAN_SEARCH_RADIUS";
/*     */   private static final double DEFAULT_MAX_SEARCH_RADIUS = 10.0D;
/*     */   private String errorMessage;
/*     */   
/*     */   public String getInfoText() {
/*  93 */     return "<html>This tracker is best suited for objects that move with a roughly constant velocity vector.<p>It relies on the Kalman filter to predict the next most likely position of a spot. The predictions for all current tracks are linked to the spots actually found in the next frame, thanks to the LAP framework already present in the LAP tracker. Predictions are continuously refined and the tracker can accommodate moderate velocity direction and magnitude changes. <p>This tracker can bridge gaps: If a spot is not found close enough to a prediction, then the Kalman filter will make another prediction in the next frame and re-iterate the search. <p>The first frames of a track are critical for this tracker to work properly: Tracksare initiated by looking for close neighbors (again via the LAP tracker). Spurious spots in the beginning of each track can confuse the tracker.<p>This tracker needs two parameters (on top of the maximal frame gap tolerated): <br/>\t - the max search radius defines how far from a predicted position it should look for candidate spots;<br/>\t - the initial search radius defines how far two spots can be apart when initiating a new track.<br/></html>";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ImageIcon getIcon() {
/*  99 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getKey() {
/* 105 */     return "KALMAN_TRACKER";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/* 111 */     return "Kalman tracker";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public SpotTracker create(SpotCollection spots, Map<String, Object> settings) {
/* 117 */     double maxSearchRadius = ((Double)settings.get("KALMAN_SEARCH_RADIUS")).doubleValue();
/* 118 */     int maxFrameGap = ((Integer)settings.get("MAX_FRAME_GAP")).intValue();
/* 119 */     double initialSearchRadius = ((Double)settings.get("LINKING_MAX_DISTANCE")).doubleValue();
/* 120 */     return new KalmanTracker(spots, maxSearchRadius, maxFrameGap, initialSearchRadius);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ConfigurationPanel getTrackerConfigurationPanel(Model model) {
/* 126 */     String spaceUnits = model.getSpaceUnits();
/* 127 */     return (ConfigurationPanel)new KalmanTrackerConfigPanel(getName(), "<html>This tracker needs two parameters (on top of the maximal frame gap tolerated): <br/>\t - the max search radius defines how far from a predicted position it should look for candidate spots;<br/>\t - the initial search radius defines how far two spots can be apart when initiating a new track.<br/></html>", spaceUnits);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean marshall(Map<String, Object> settings, Element element) {
/* 133 */     boolean ok = true;
/* 134 */     StringBuilder str = new StringBuilder();
/*     */     
/* 136 */     ok &= IOUtils.writeAttribute(settings, element, "LINKING_MAX_DISTANCE", Double.class, str);
/* 137 */     ok &= IOUtils.writeAttribute(settings, element, "KALMAN_SEARCH_RADIUS", Double.class, str);
/* 138 */     ok &= IOUtils.writeAttribute(settings, element, "MAX_FRAME_GAP", Integer.class, str);
/* 139 */     return ok;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean unmarshall(Element element, Map<String, Object> settings) {
/* 145 */     settings.clear();
/* 146 */     StringBuilder errorHolder = new StringBuilder();
/* 147 */     boolean ok = true;
/*     */     
/* 149 */     ok &= IOUtils.readDoubleAttribute(element, settings, "LINKING_MAX_DISTANCE", errorHolder);
/* 150 */     ok &= IOUtils.readDoubleAttribute(element, settings, "KALMAN_SEARCH_RADIUS", errorHolder);
/* 151 */     ok &= IOUtils.readIntegerAttribute(element, settings, "MAX_FRAME_GAP", errorHolder);
/* 152 */     return ok;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString(Map<String, Object> settings) {
/* 158 */     if (!checkSettingsValidity(settings)) return this.errorMessage;
/*     */     
/* 160 */     double maxSearchRadius = ((Double)settings.get("KALMAN_SEARCH_RADIUS")).doubleValue();
/* 161 */     int maxFrameGap = ((Integer)settings.get("MAX_FRAME_GAP")).intValue();
/* 162 */     double initialSearchRadius = ((Double)settings.get("LINKING_MAX_DISTANCE")).doubleValue();
/* 163 */     StringBuilder str = new StringBuilder();
/*     */     
/* 165 */     str.append(String.format("  - initial search radius: %.1f\n", new Object[] { Double.valueOf(initialSearchRadius) }));
/* 166 */     str.append(String.format("  - max search radius: %.1f\n", new Object[] { Double.valueOf(maxSearchRadius) }));
/* 167 */     str.append(String.format("  - max frame gap: %d\n", new Object[] { Integer.valueOf(maxFrameGap) }));
/*     */     
/* 169 */     return str.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, Object> getDefaultSettings() {
/* 175 */     Map<String, Object> sm = new HashMap<>(3);
/* 176 */     sm.put("KALMAN_SEARCH_RADIUS", Double.valueOf(10.0D));
/* 177 */     sm.put("LINKING_MAX_DISTANCE", Double.valueOf(15.0D));
/* 178 */     sm.put("MAX_FRAME_GAP", Integer.valueOf(2));
/* 179 */     return sm;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean checkSettingsValidity(Map<String, Object> settings) {
/* 185 */     if (null == settings) {
/*     */       
/* 187 */       this.errorMessage = "Settings map is null.\n";
/* 188 */       return false;
/*     */     } 
/*     */     
/* 191 */     boolean ok = true;
/* 192 */     StringBuilder str = new StringBuilder();
/*     */     
/* 194 */     ok &= TMUtils.checkParameter(settings, "LINKING_MAX_DISTANCE", Double.class, str);
/* 195 */     ok &= TMUtils.checkParameter(settings, "KALMAN_SEARCH_RADIUS", Double.class, str);
/* 196 */     ok &= TMUtils.checkParameter(settings, "MAX_FRAME_GAP", Integer.class, str);
/*     */     
/* 198 */     if (!ok)
/*     */     {
/* 200 */       this.errorMessage = str.toString();
/*     */     }
/* 202 */     return ok;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getErrorMessage() {
/* 208 */     return this.errorMessage;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public KalmanTrackerFactory copy() {
/* 214 */     return new KalmanTrackerFactory();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/tracking/kalman/KalmanTrackerFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */