/*    */ package fiji.plugin.trackmate.visualization;
/*    */ 
/*    */ import fiji.plugin.trackmate.Model;
/*    */ import fiji.plugin.trackmate.gui.displaysettings.Colormap;
/*    */ import java.awt.Color;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WholeTrackFeatureColorGenerator
/*    */   implements FeatureColorGenerator<Integer>
/*    */ {
/*    */   private final Model model;
/*    */   private final String trackFeature;
/*    */   private final Color missingValueColor;
/*    */   private final Color undefinedValueColor;
/*    */   private final Colormap colormap;
/*    */   private final double min;
/*    */   private final double max;
/*    */   
/*    */   public WholeTrackFeatureColorGenerator(Model model, String trackFeature, Color missingValueColor, Color undefinedValueColor, Colormap colormap, double min, double max) {
/* 55 */     this.model = model;
/* 56 */     this.trackFeature = trackFeature;
/* 57 */     this.missingValueColor = missingValueColor;
/* 58 */     this.undefinedValueColor = undefinedValueColor;
/* 59 */     this.colormap = colormap;
/* 60 */     this.min = min;
/* 61 */     this.max = max;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Color color(Integer trackID) {
/* 67 */     Double feat = this.model.getFeatureModel().getTrackFeature(trackID, this.trackFeature);
/* 68 */     if (null == feat) {
/* 69 */       return this.missingValueColor;
/*    */     }
/* 71 */     if (feat.isNaN()) {
/* 72 */       return this.undefinedValueColor;
/*    */     }
/* 74 */     double val = feat.doubleValue();
/* 75 */     return this.colormap.getPaint((val - this.min) / (this.max - this.min));
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/visualization/WholeTrackFeatureColorGenerator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */