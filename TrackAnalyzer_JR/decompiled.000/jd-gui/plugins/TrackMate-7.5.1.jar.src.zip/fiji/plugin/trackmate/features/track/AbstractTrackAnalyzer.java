/*     */ package fiji.plugin.trackmate.features.track;
/*     */ 
/*     */ import fiji.plugin.trackmate.Dimension;
/*     */ import fiji.plugin.trackmate.Model;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.Callable;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.Executors;
/*     */ import java.util.concurrent.Future;
/*     */ import javax.swing.ImageIcon;
/*     */ import org.scijava.plugin.Plugin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Plugin(type = TrackAnalyzer.class, enabled = false)
/*     */ public abstract class AbstractTrackAnalyzer
/*     */   implements TrackAnalyzer
/*     */ {
/*     */   private int numThreads;
/*     */   private long processingTime;
/*     */   private final String key;
/*     */   private final String name;
/*     */   private final List<String> features;
/*     */   private final Map<String, String> featureNames;
/*     */   private final Map<String, String> featureShortNames;
/*     */   private final Map<String, Dimension> featureDimensions;
/*     */   private final Map<String, Boolean> isInts;
/*     */   
/*     */   public AbstractTrackAnalyzer(String key, String name, List<String> features, Map<String, String> featureNames, Map<String, String> featureShortNames, Map<String, Dimension> featureDimensions, Map<String, Boolean> isInts) {
/*  76 */     this.key = key;
/*  77 */     this.name = name;
/*  78 */     this.features = features;
/*  79 */     this.featureNames = featureNames;
/*  80 */     this.featureShortNames = featureShortNames;
/*  81 */     this.featureDimensions = featureDimensions;
/*  82 */     this.isInts = isInts;
/*  83 */     setNumThreads();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public long getProcessingTime() {
/*  89 */     return this.processingTime;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isManualFeature() {
/*  95 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ImageIcon getIcon() {
/* 101 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getInfoText() {
/* 107 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getNumThreads() {
/* 113 */     return this.numThreads;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setNumThreads() {
/* 119 */     setNumThreads(Runtime.getRuntime().availableProcessors() / 2);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setNumThreads(int numThreads) {
/* 125 */     this.numThreads = numThreads;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isLocal() {
/* 131 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getKey() {
/* 137 */     return this.key;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/* 143 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, Dimension> getFeatureDimensions() {
/* 149 */     return this.featureDimensions;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, String> getFeatureNames() {
/* 155 */     return this.featureNames;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public List<String> getFeatures() {
/* 161 */     return this.features;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, String> getFeatureShortNames() {
/* 167 */     return this.featureShortNames;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, Boolean> getIsIntFeature() {
/* 173 */     return this.isInts;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void process(Collection<Integer> trackIDs, final Model model) {
/* 179 */     if (trackIDs.isEmpty()) {
/*     */       return;
/*     */     }
/* 182 */     long start = System.currentTimeMillis();
/*     */ 
/*     */     
/* 185 */     List<Callable<Void>> tasks = new ArrayList<>(trackIDs.size());
/* 186 */     for (Integer trackID : trackIDs) {
/*     */       
/* 188 */       Callable<Void> task = new Callable<Void>()
/*     */         {
/*     */ 
/*     */           
/*     */           public Void call() throws Exception
/*     */           {
/* 194 */             AbstractTrackAnalyzer.this.analyze(trackID, model);
/* 195 */             return null;
/*     */           }
/*     */         };
/* 198 */       tasks.add(task);
/*     */     } 
/*     */     
/* 201 */     ExecutorService executorService = Executors.newFixedThreadPool(this.numThreads);
/*     */ 
/*     */     
/*     */     try {
/* 205 */       List<Future<Void>> futures = executorService.invokeAll(tasks);
/* 206 */       for (Future<Void> future : futures) {
/* 207 */         future.get();
/*     */       }
/* 209 */     } catch (InterruptedException|java.util.concurrent.ExecutionException e) {
/*     */       
/* 211 */       e.printStackTrace();
/*     */     } 
/* 213 */     executorService.shutdown();
/*     */     
/* 215 */     long end = System.currentTimeMillis();
/* 216 */     this.processingTime = end - start;
/*     */   }
/*     */   
/*     */   protected abstract void analyze(Integer paramInteger, Model paramModel);
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/features/track/AbstractTrackAnalyzer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */