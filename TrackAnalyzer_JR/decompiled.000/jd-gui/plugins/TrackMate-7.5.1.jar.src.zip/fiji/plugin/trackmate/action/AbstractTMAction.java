/*    */ package fiji.plugin.trackmate.action;
/*    */ 
/*    */ import fiji.plugin.trackmate.Logger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractTMAction
/*    */   implements TrackMateAction
/*    */ {
/* 28 */   protected Logger logger = Logger.VOID_LOGGER;
/*    */ 
/*    */   
/*    */   public void setLogger(Logger logger) {
/* 32 */     this.logger = logger;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/action/AbstractTMAction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */