/*     */ package fiji.plugin.trackmate.visualization.table;
/*     */ 
/*     */ import fiji.plugin.trackmate.Dimension;
/*     */ import fiji.plugin.trackmate.Model;
/*     */ import fiji.plugin.trackmate.ModelChangeEvent;
/*     */ import fiji.plugin.trackmate.ModelChangeListener;
/*     */ import fiji.plugin.trackmate.SelectionChangeEvent;
/*     */ import fiji.plugin.trackmate.SelectionChangeListener;
/*     */ import fiji.plugin.trackmate.SelectionModel;
/*     */ import fiji.plugin.trackmate.Spot;
/*     */ import fiji.plugin.trackmate.features.FeatureUtils;
/*     */ import fiji.plugin.trackmate.gui.Icons;
/*     */ import fiji.plugin.trackmate.gui.displaysettings.DisplaySettings;
/*     */ import fiji.plugin.trackmate.util.FileChooser;
/*     */ import fiji.plugin.trackmate.util.TMUtils;
/*     */ import fiji.plugin.trackmate.visualization.FeatureColorGenerator;
/*     */ import fiji.plugin.trackmate.visualization.TrackMateModelView;
/*     */ import fiji.plugin.trackmate.visualization.trackscheme.utils.SearchBar;
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.WindowAdapter;
/*     */ import java.awt.event.WindowEvent;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.atomic.AtomicBoolean;
/*     */ import java.util.function.BiConsumer;
/*     */ import java.util.function.BiFunction;
/*     */ import java.util.function.Function;
/*     */ import java.util.function.Supplier;
/*     */ import javax.swing.Box;
/*     */ import javax.swing.BoxLayout;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JFrame;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JTable;
/*     */ import javax.swing.JToggleButton;
/*     */ import javax.swing.event.ListSelectionEvent;
/*     */ import javax.swing.event.ListSelectionListener;
/*     */ import javax.swing.filechooser.FileNameExtensionFilter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AllSpotsTableView
/*     */   extends JFrame
/*     */   implements TrackMateModelView, ModelChangeListener, SelectionChangeListener
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private static final String KEY = "SPOT_TABLE";
/*  81 */   public static String selectedFile = TrackTableView.selectedFile;
/*     */   
/*     */   private final Model model;
/*     */   
/*     */   private final TablePanel<Spot> spotTable;
/*     */   
/*  87 */   private final AtomicBoolean ignoreSelectionChange = new AtomicBoolean(false);
/*     */   
/*     */   private final SelectionModel selectionModel;
/*     */ 
/*     */   
/*     */   public AllSpotsTableView(final Model model, final SelectionModel selectionModel, final DisplaySettings ds) {
/*  93 */     super("All spots table");
/*  94 */     setIconImage(Icons.TRACKMATE_ICON.getImage());
/*  95 */     this.model = model;
/*  96 */     this.selectionModel = selectionModel;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 102 */     JPanel mainPanel = new JPanel();
/* 103 */     mainPanel.setLayout(new BorderLayout());
/*     */ 
/*     */     
/* 106 */     this.spotTable = createSpotTable(model, ds);
/*     */     
/* 108 */     mainPanel.add(this.spotTable.getPanel(), "Center");
/*     */ 
/*     */     
/* 111 */     JPanel toolbar = new JPanel();
/* 112 */     BoxLayout layout = new BoxLayout(toolbar, 2);
/* 113 */     toolbar.setLayout(layout);
/* 114 */     JButton exportBtn = new JButton("Export to CSV", Icons.CSV_ICON);
/* 115 */     exportBtn.addActionListener(e -> exportToCsv());
/* 116 */     toolbar.add(exportBtn);
/* 117 */     toolbar.add(Box.createHorizontalGlue());
/* 118 */     SearchBar searchBar = new SearchBar(model, this);
/* 119 */     searchBar.setMaximumSize(new Dimension(160, 30));
/* 120 */     toolbar.add((Component)searchBar);
/* 121 */     JToggleButton tglColoring = new JToggleButton("coloring");
/* 122 */     tglColoring.addActionListener(e -> {
/*     */           this.spotTable.setUseColoring(tglColoring.isSelected());
/*     */           refresh();
/*     */         });
/* 126 */     toolbar.add(tglColoring);
/* 127 */     mainPanel.add(toolbar, "North");
/*     */     
/* 129 */     getContentPane().add(mainPanel);
/* 130 */     pack();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 136 */     this.spotTable.getTable().getSelectionModel().addListSelectionListener(new SpotTableSelectionListener());
/*     */ 
/*     */     
/* 139 */     final DisplaySettings.UpdateListener refresher = () -> refresh();
/* 140 */     ds.listeners().add(refresher);
/* 141 */     selectionModel.addSelectionChangeListener(this);
/* 142 */     model.addModelChangeListener(this);
/* 143 */     addWindowListener(new WindowAdapter()
/*     */         {
/*     */           
/*     */           public void windowClosing(WindowEvent e)
/*     */           {
/* 148 */             selectionModel.removeSelectionChangeListener(AllSpotsTableView.this);
/* 149 */             model.removeModelChangeListener(AllSpotsTableView.this);
/* 150 */             ds.listeners().remove(refresher);
/*     */           }
/*     */         });
/*     */   }
/*     */ 
/*     */   
/*     */   public void exportToCsv() {
/* 157 */     File file = FileChooser.chooseFile(this, selectedFile, new FileNameExtensionFilter("CSV files", new String[] { "csv" }), "Export table to CSV", FileChooser.DialogType.SAVE, FileChooser.SelectionMode.FILES_ONLY);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 164 */     if (null == file) {
/*     */       return;
/*     */     }
/* 167 */     selectedFile = file.getAbsolutePath();
/* 168 */     exportToCsv(selectedFile);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void exportToCsv(String csvFile) {
/*     */     try {
/* 175 */       this.spotTable.exportToCsv(new File(csvFile));
/*     */     }
/* 177 */     catch (IOException e) {
/*     */       
/* 179 */       this.model.getLogger().error("Problem exporting to file " + csvFile + "\n" + e
/* 180 */           .getMessage());
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static final TablePanel<Spot> createSpotTable(Model model, DisplaySettings ds) {
/* 186 */     List<String> features = new ArrayList<>(model.getFeatureModel().getSpotFeatures());
/* 187 */     Map<String, String> featureNames = model.getFeatureModel().getSpotFeatureNames();
/* 188 */     Map<String, String> featureShortNames = model.getFeatureModel().getSpotFeatureShortNames();
/* 189 */     Map<String, String> featureUnits = new HashMap<>();
/* 190 */     for (String feature : features) {
/*     */       
/* 192 */       Dimension dimension = (Dimension)model.getFeatureModel().getSpotFeatureDimensions().get(feature);
/* 193 */       String units = TMUtils.getUnitsFor(dimension, model.getSpaceUnits(), model.getTimeUnits());
/* 194 */       featureUnits.put(feature, units);
/*     */     } 
/* 196 */     Map<String, Boolean> isInts = model.getFeatureModel().getSpotFeatureIsInt();
/* 197 */     Map<String, String> infoTexts = new HashMap<>();
/* 198 */     Function<Spot, String> labelGenerator = spot -> spot.getName();
/* 199 */     BiConsumer<Spot, String> labelSetter = (spot, label) -> spot.setName(label);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 204 */     String SPOT_ID = "ID";
/* 205 */     features.add(0, "ID");
/* 206 */     featureNames.put("ID", "Spot ID");
/* 207 */     featureShortNames.put("ID", "Spot ID");
/* 208 */     featureUnits.put("ID", "");
/* 209 */     isInts.put("ID", Boolean.TRUE);
/* 210 */     infoTexts.put("ID", "The id of the spot.");
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 215 */     String TRACK_ID = "TRACK_ID";
/* 216 */     features.add(1, "TRACK_ID");
/* 217 */     featureNames.put("TRACK_ID", "Track ID");
/* 218 */     featureShortNames.put("TRACK_ID", "Track ID");
/* 219 */     featureUnits.put("TRACK_ID", "");
/* 220 */     isInts.put("TRACK_ID", Boolean.TRUE);
/* 221 */     infoTexts.put("TRACK_ID", "The id of the track this spot belongs to.");
/*     */     
/* 223 */     BiFunction<Spot, String, Double> featureFun = (spot, feature) -> {
/*     */         if (feature.equals("TRACK_ID")) {
/*     */           Integer trackID = model.getTrackModel().trackIDOf(spot);
/*     */ 
/*     */           
/*     */           return (trackID == null) ? null : Double.valueOf(trackID.doubleValue());
/*     */         } 
/*     */ 
/*     */         
/*     */         return feature.equals("ID") ? Double.valueOf(spot.ID()) : spot.getFeature(feature);
/*     */       };
/*     */     
/* 235 */     Supplier<FeatureColorGenerator<Spot>> coloring = () -> FeatureUtils.createSpotColorGenerator(model, ds);
/*     */ 
/*     */     
/* 238 */     BiConsumer<Spot, Color> colorSetter = (spot, color) -> spot.putFeature("MANUAL_SPOT_COLOR", Double.valueOf(color.getRGB()));
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 243 */     TablePanel<Spot> table = new TablePanel<>(model.getSpots().iterable(true), features, featureFun, featureNames, featureShortNames, featureUnits, isInts, infoTexts, coloring, labelGenerator, labelSetter, "MANUAL_SPOT_COLOR", colorSetter);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 256 */     return table;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void render() {
/* 262 */     setLocationRelativeTo((Component)null);
/* 263 */     setVisible(true);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void refresh() {
/* 269 */     repaint();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void modelChanged(ModelChangeEvent event) {
/* 275 */     if (event.getEventID() == 9) {
/*     */       
/* 277 */       refresh();
/*     */       
/*     */       return;
/*     */     } 
/* 281 */     List<Spot> spots = new ArrayList<>();
/* 282 */     for (Spot spot : this.model.getSpots().iterable(true))
/* 283 */       spots.add(spot); 
/* 284 */     this.spotTable.setObjects(spots);
/*     */     
/* 286 */     refresh();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void selectionChanged(SelectionChangeEvent event) {
/* 295 */     if (this.ignoreSelectionChange.get())
/*     */       return; 
/* 297 */     this.ignoreSelectionChange.set(true);
/*     */ 
/*     */     
/* 300 */     Set<Spot> selectedVertices = this.selectionModel.getSpotSelection();
/* 301 */     JTable vt = this.spotTable.getTable();
/* 302 */     vt.getSelectionModel().clearSelection();
/* 303 */     for (Spot spot : selectedVertices) {
/*     */       
/* 305 */       int row = this.spotTable.getViewRowForObject(spot);
/* 306 */       vt.getSelectionModel().addSelectionInterval(row, row);
/*     */     } 
/*     */ 
/*     */     
/* 310 */     Map<Spot, Boolean> spotsAdded = event.getSpots();
/* 311 */     if (spotsAdded != null && spotsAdded.size() == 1) {
/*     */       
/* 313 */       boolean added = ((Boolean)spotsAdded.values().iterator().next()).booleanValue();
/* 314 */       if (added) {
/*     */         
/* 316 */         Spot spot = spotsAdded.keySet().iterator().next();
/* 317 */         centerViewOn(spot);
/*     */       } 
/*     */     } 
/*     */     
/* 321 */     refresh();
/* 322 */     this.ignoreSelectionChange.set(false);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void centerViewOn(Spot spot) {
/* 328 */     this.spotTable.scrollToObject(spot);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Model getModel() {
/* 334 */     return this.model;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getKey() {
/* 340 */     return "SPOT_TABLE";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void clear() {}
/*     */ 
/*     */ 
/*     */   
/*     */   private final class SpotTableSelectionListener
/*     */     implements ListSelectionListener
/*     */   {
/*     */     private SpotTableSelectionListener() {}
/*     */ 
/*     */     
/*     */     public void valueChanged(ListSelectionEvent event) {
/* 356 */       if (event.getValueIsAdjusting() || AllSpotsTableView.this.ignoreSelectionChange.get()) {
/*     */         return;
/*     */       }
/* 359 */       AllSpotsTableView.this.ignoreSelectionChange.set(true);
/*     */       
/* 361 */       int[] selectedRows = AllSpotsTableView.this.spotTable.getTable().getSelectedRows();
/* 362 */       List<Spot> toSelect = new ArrayList<>(selectedRows.length);
/* 363 */       for (int row : selectedRows) {
/* 364 */         toSelect.add(AllSpotsTableView.this.spotTable.getObjectForViewRow(row));
/*     */       }
/* 366 */       AllSpotsTableView.this.selectionModel.clearSelection();
/* 367 */       AllSpotsTableView.this.selectionModel.addSpotToSelection(toSelect);
/* 368 */       AllSpotsTableView.this.refresh();
/*     */       
/* 370 */       AllSpotsTableView.this.ignoreSelectionChange.set(false);
/*     */     }
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/visualization/table/AllSpotsTableView.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */