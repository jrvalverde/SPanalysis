/*     */ package fiji.plugin.trackmate.tracking.overlap;
/*     */ 
/*     */ import fiji.plugin.trackmate.Logger;
/*     */ import fiji.plugin.trackmate.Spot;
/*     */ import fiji.plugin.trackmate.SpotCollection;
/*     */ import fiji.plugin.trackmate.SpotRoi;
/*     */ import fiji.plugin.trackmate.tracking.SpotTracker;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.Callable;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.Executors;
/*     */ import java.util.concurrent.Future;
/*     */ import java.util.concurrent.atomic.AtomicBoolean;
/*     */ import math.geom2d.AffineTransform2D;
/*     */ import math.geom2d.Point2D;
/*     */ import math.geom2d.conic.Circle2D;
/*     */ import math.geom2d.polygon.Polygon2D;
/*     */ import math.geom2d.polygon.Polygons2D;
/*     */ import math.geom2d.polygon.Rectangle2D;
/*     */ import math.geom2d.polygon.SimplePolygon2D;
/*     */ import net.imglib2.algorithm.MultiThreadedBenchmarkAlgorithm;
/*     */ import org.jgrapht.graph.DefaultWeightedEdge;
/*     */ import org.jgrapht.graph.SimpleWeightedGraph;
/*     */ import org.scijava.Cancelable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OverlapTracker
/*     */   extends MultiThreadedBenchmarkAlgorithm
/*     */   implements SpotTracker, Cancelable
/*     */ {
/*     */   private SimpleWeightedGraph<Spot, DefaultWeightedEdge> graph;
/*     */   
/*     */   public enum IoUCalculation
/*     */   {
/*  63 */     FAST("Fast", "IoU is calculated using the bounding box of the spot."),
/*  64 */     PRECISE("Precise", "IoU is calculated over the shape of the spot ROI.");
/*     */     
/*     */     private final String str;
/*     */     
/*     */     private final String infoText;
/*     */ 
/*     */     
/*     */     IoUCalculation(String str, String infoText) {
/*  72 */       this.str = str;
/*  73 */       this.infoText = infoText;
/*     */     }
/*     */ 
/*     */     
/*     */     public String getInfoText() {
/*  78 */       return this.infoText;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public String toString() {
/*  84 */       return this.str;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*  90 */   private Logger logger = Logger.VOID_LOGGER;
/*     */ 
/*     */   
/*     */   private final SpotCollection spots;
/*     */ 
/*     */   
/*     */   private final double enlargeFactor;
/*     */ 
/*     */   
/*     */   private final IoUCalculation method;
/*     */ 
/*     */   
/*     */   private final double minIoU;
/*     */   
/*     */   private boolean isCanceled;
/*     */   
/*     */   private String cancelReason;
/*     */ 
/*     */   
/*     */   public OverlapTracker(SpotCollection spots, IoUCalculation method, double minIoU, double enlargeFactor) {
/* 110 */     this.spots = spots;
/* 111 */     this.method = method;
/* 112 */     this.minIoU = minIoU;
/* 113 */     this.enlargeFactor = enlargeFactor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SimpleWeightedGraph<Spot, DefaultWeightedEdge> getResult() {
/* 123 */     return this.graph;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean checkInput() {
/* 129 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean process() {
/* 135 */     this.isCanceled = false;
/* 136 */     this.cancelReason = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 143 */     if (null == this.spots) {
/*     */       
/* 145 */       this.errorMessage = "[IoUTracker] The spot collection is null.";
/* 146 */       return false;
/*     */     } 
/*     */ 
/*     */     
/* 150 */     if (this.spots.keySet().isEmpty()) {
/*     */       
/* 152 */       this.errorMessage = "[IoUTracker] The spot collection is empty.";
/* 153 */       return false;
/*     */     } 
/*     */     
/* 156 */     if (this.enlargeFactor <= 0.0D) {
/*     */       
/* 158 */       this.errorMessage = "[IoUTracker] The enlargement factor must be strictly positive, was " + this.enlargeFactor;
/* 159 */       return false;
/*     */     } 
/*     */ 
/*     */     
/* 163 */     boolean empty = true;
/* 164 */     for (Iterator<Integer> iterator1 = this.spots.keySet().iterator(); iterator1.hasNext(); ) { int frame = ((Integer)iterator1.next()).intValue();
/*     */       
/* 166 */       if (this.spots.getNSpots(frame, true) > 0) {
/*     */         
/* 168 */         empty = false;
/*     */         break;
/*     */       }  }
/*     */     
/* 172 */     if (empty) {
/*     */       
/* 174 */       this.errorMessage = "[IoUTracker] The spot collection is empty.";
/* 175 */       return false;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 182 */     long start = System.currentTimeMillis();
/*     */ 
/*     */     
/* 185 */     this.graph = new SimpleWeightedGraph(DefaultWeightedEdge.class);
/*     */ 
/*     */     
/* 188 */     AtomicBoolean ok = new AtomicBoolean(true);
/*     */ 
/*     */     
/* 191 */     Iterator<Integer> frameIterator = this.spots.keySet().iterator();
/*     */ 
/*     */     
/* 194 */     int sourceFrame = ((Integer)frameIterator.next()).intValue();
/* 195 */     Map<Spot, Polygon2D> sourceGeometries = createGeometry(this.spots.iterable(sourceFrame, true), this.method, this.enlargeFactor);
/*     */     
/* 197 */     this.logger.setStatus("Frame to frame linking...");
/* 198 */     int progress = 0;
/* 199 */     while (frameIterator.hasNext()) {
/*     */       
/* 201 */       if (!ok.get() || isCanceled()) {
/*     */         break;
/*     */       }
/* 204 */       int targetFrame = ((Integer)frameIterator.next()).intValue();
/* 205 */       Map<Spot, Polygon2D> targetGeometries = createGeometry(this.spots.iterable(targetFrame, true), this.method, this.enlargeFactor);
/*     */       
/* 207 */       if (sourceGeometries.isEmpty() || targetGeometries.isEmpty()) {
/*     */         continue;
/*     */       }
/* 210 */       ExecutorService executors = Executors.newFixedThreadPool(this.numThreads);
/* 211 */       List<Future<IoULink>> futures = new ArrayList<>();
/*     */ 
/*     */       
/* 214 */       for (Spot target : targetGeometries.keySet()) {
/*     */         
/* 216 */         Polygon2D targetPoly = targetGeometries.get(target);
/* 217 */         futures.add(executors.submit(new FindBestSourceTask(target, targetPoly, sourceGeometries, this.minIoU)));
/*     */       } 
/*     */ 
/*     */       
/* 221 */       for (Future<IoULink> future : futures) {
/*     */         
/* 223 */         if (!ok.get() || isCanceled()) {
/*     */           break;
/*     */         }
/*     */         
/*     */         try {
/* 228 */           IoULink link = future.get();
/* 229 */           if (link.source == null) {
/*     */             continue;
/*     */           }
/* 232 */           this.graph.addVertex(link.source);
/* 233 */           this.graph.addVertex(link.target);
/* 234 */           DefaultWeightedEdge edge = (DefaultWeightedEdge)this.graph.addEdge(link.source, link.target);
/* 235 */           this.graph.setEdgeWeight(edge, 1.0D - link.iou);
/*     */         
/*     */         }
/* 238 */         catch (InterruptedException|java.util.concurrent.ExecutionException e) {
/*     */           
/* 240 */           this.errorMessage = e.getMessage();
/* 241 */           ok.set(false);
/*     */         } 
/*     */       } 
/* 244 */       executors.shutdown();
/*     */       
/* 246 */       sourceGeometries = targetGeometries;
/* 247 */       this.logger.setProgress(progress++ / this.spots.keySet().size());
/*     */     } 
/*     */     
/* 250 */     this.logger.setProgress(1.0D);
/* 251 */     this.logger.setStatus("");
/*     */     
/* 253 */     long end = System.currentTimeMillis();
/* 254 */     this.processingTime = end - start;
/*     */     
/* 256 */     return ok.get();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLogger(Logger logger) {
/* 262 */     this.logger = logger;
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean checkSettingsValidity(Map<String, Object> settings, StringBuilder str) {
/* 267 */     if (null == settings) {
/*     */       
/* 269 */       str.append("Settings map is null.\n");
/* 270 */       return false;
/*     */     } 
/*     */     
/* 273 */     boolean ok = true;
/* 274 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   private static Map<Spot, Polygon2D> createGeometry(Iterable<Spot> spots, IoUCalculation method, double scale) {
/* 279 */     Map<Spot, Polygon2D> geometries = new HashMap<>();
/* 280 */     switch (method) {
/*     */       
/*     */       case FAST:
/* 283 */         for (Spot spot : spots) {
/* 284 */           geometries.put(spot, toBoundingBox(spot, scale));
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 295 */         return Collections.unmodifiableMap(geometries);case PRECISE: for (Spot spot : spots) geometries.put(spot, toPolygon(spot, scale));  return Collections.unmodifiableMap(geometries);
/*     */     } 
/*     */     throw new IllegalArgumentException("Do not know how to compute IoU for method " + method);
/*     */   } private static SimplePolygon2D toPolygon(Spot spot, double scale) {
/*     */     SimplePolygon2D poly;
/* 300 */     double xc = spot.getDoublePosition(0);
/* 301 */     double yc = spot.getDoublePosition(1);
/* 302 */     SpotRoi roi = spot.getRoi();
/*     */     
/* 304 */     if (roi == null) {
/*     */       
/* 306 */       double radius = spot.getFeature("RADIUS").doubleValue();
/* 307 */       poly = new SimplePolygon2D((new Circle2D(xc, yc, radius)).asPolyline(32));
/*     */     }
/*     */     else {
/*     */       
/* 311 */       double[] xcoords = roi.toPolygonX(1.0D, 0.0D, xc, 1.0D);
/* 312 */       double[] ycoords = roi.toPolygonY(1.0D, 0.0D, yc, 1.0D);
/* 313 */       poly = new SimplePolygon2D(xcoords, ycoords);
/*     */     } 
/* 315 */     return poly.transform(AffineTransform2D.createScaling(new Point2D(xc, yc), scale, scale));
/*     */   }
/*     */ 
/*     */   
/*     */   private static Rectangle2D toBoundingBox(Spot spot, double scale) {
/* 320 */     double xc = spot.getDoublePosition(0);
/* 321 */     double yc = spot.getDoublePosition(1);
/* 322 */     SpotRoi roi = spot.getRoi();
/* 323 */     if (roi == null) {
/*     */       
/* 325 */       double radius = spot.getFeature("RADIUS").doubleValue() * scale;
/* 326 */       return new Rectangle2D(xc - radius, yc - radius, 2.0D * radius, 2.0D * radius);
/*     */     } 
/*     */ 
/*     */     
/* 330 */     double minX = Arrays.stream(roi.x).min().getAsDouble() * scale;
/* 331 */     double maxX = Arrays.stream(roi.x).max().getAsDouble() * scale;
/* 332 */     double minY = Arrays.stream(roi.y).min().getAsDouble() * scale;
/* 333 */     double maxY = Arrays.stream(roi.y).max().getAsDouble() * scale;
/* 334 */     return new Rectangle2D(xc + minX, yc + minY, maxX - minX, maxY - minY);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class FindBestSourceTask
/*     */     implements Callable<IoULink>
/*     */   {
/*     */     private final Spot target;
/*     */     
/*     */     private final Polygon2D targetPoly;
/*     */     
/*     */     private final Map<Spot, Polygon2D> sourceGeometries;
/*     */     
/*     */     private final double minIoU;
/*     */ 
/*     */     
/*     */     public FindBestSourceTask(Spot target, Polygon2D targetPoly, Map<Spot, Polygon2D> sourceGeometries, double minIoU) {
/* 352 */       this.target = target;
/* 353 */       this.targetPoly = targetPoly;
/* 354 */       this.sourceGeometries = sourceGeometries;
/* 355 */       this.minIoU = minIoU;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public OverlapTracker.IoULink call() throws Exception {
/* 361 */       double targetArea = Math.abs(this.targetPoly.area());
/* 362 */       double maxIoU = this.minIoU;
/* 363 */       Spot bestSpot = null;
/* 364 */       for (Spot spot : this.sourceGeometries.keySet()) {
/*     */         
/* 366 */         Polygon2D sourcePoly = this.sourceGeometries.get(spot);
/* 367 */         double intersection = Math.abs(Polygons2D.intersection(this.targetPoly, sourcePoly).area());
/* 368 */         if (intersection == 0.0D) {
/*     */           continue;
/*     */         }
/* 371 */         double union = Math.abs(sourcePoly.area()) + targetArea - intersection;
/* 372 */         double iou = intersection / union;
/* 373 */         if (iou > maxIoU) {
/*     */           
/* 375 */           maxIoU = iou;
/* 376 */           bestSpot = spot;
/*     */         } 
/*     */       } 
/* 379 */       return new OverlapTracker.IoULink(bestSpot, this.target, maxIoU);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static final class IoULink
/*     */   {
/*     */     public final Spot source;
/*     */     
/*     */     public final Spot target;
/*     */     
/*     */     public final double iou;
/*     */     
/*     */     public IoULink(Spot source, Spot target, double iou) {
/* 393 */       this.source = source;
/* 394 */       this.target = target;
/* 395 */       this.iou = iou;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isCanceled() {
/* 404 */     return this.isCanceled;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void cancel(String reason) {
/* 410 */     this.isCanceled = true;
/* 411 */     this.cancelReason = reason;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getCancelReason() {
/* 417 */     return this.cancelReason;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/tracking/overlap/OverlapTracker.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */