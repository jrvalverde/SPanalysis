/*     */ package fiji.plugin.trackmate.action;
/*     */ 
/*     */ import fiji.plugin.trackmate.Logger;
/*     */ import fiji.plugin.trackmate.Model;
/*     */ import fiji.plugin.trackmate.SelectionModel;
/*     */ import fiji.plugin.trackmate.Settings;
/*     */ import fiji.plugin.trackmate.Spot;
/*     */ import fiji.plugin.trackmate.TrackMate;
/*     */ import fiji.plugin.trackmate.gui.Icons;
/*     */ import fiji.plugin.trackmate.gui.displaysettings.DisplaySettings;
/*     */ import java.awt.Frame;
/*     */ import javax.swing.ImageIcon;
/*     */ import org.scijava.plugin.Plugin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RecomputeFeatureAction
/*     */   extends AbstractTMAction
/*     */ {
/*     */   public static final String NAME = "Recompute all features";
/*     */   public static final String KEY = "RECOMPUTE_FEATURES";
/*     */   public static final String INFO_TEXT = "<html>Calling this action causes the model to recompute all the features values for all spots, edges and tracks. All the feature analyzers discovered when running this action are added and computed. </html>";
/*     */   
/*     */   public void execute(TrackMate trackmate, SelectionModel selectionModel, DisplaySettings displaySettings, Frame parent) {
/*  57 */     recompute(trackmate, this.logger);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Plugin(type = TrackMateActionFactory.class)
/*     */   public static class Factory
/*     */     implements TrackMateActionFactory
/*     */   {
/*     */     public String getInfoText() {
/*  67 */       return "<html>Calling this action causes the model to recompute all the features values for all spots, edges and tracks. All the feature analyzers discovered when running this action are added and computed. </html>";
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public String getName() {
/*  73 */       return "Recompute all features";
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public String getKey() {
/*  79 */       return "RECOMPUTE_FEATURES";
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public ImageIcon getIcon() {
/*  85 */       return Icons.CALCULATOR_ICON;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public TrackMateAction create() {
/*  91 */       return new RecomputeFeatureAction();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static void recompute(TrackMate trackmate, Logger logger) {
/*  97 */     logger.log("Recalculating all features.\n");
/*  98 */     Model model = trackmate.getModel();
/*  99 */     Logger oldLogger = model.getLogger();
/* 100 */     model.setLogger(logger);
/* 101 */     Settings settings = trackmate.getSettings();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 107 */     double dt = 0.0D;
/* 108 */     if (null != settings && null != settings.imp && null != settings.imp.getCalibration())
/* 109 */       dt = (settings.imp.getCalibration()).frameInterval; 
/* 110 */     if (dt <= 0.0D && settings != null)
/* 111 */       dt = settings.dt; 
/* 112 */     if (dt <= 0.0D) {
/* 113 */       dt = 1.0D;
/*     */     }
/* 115 */     settings.dt = dt;
/* 116 */     for (Spot spot : model.getSpots().iterable(false)) {
/* 117 */       spot.putFeature("POSITION_T", Double.valueOf(spot.getFeature("FRAME").intValue() * dt));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 124 */     settings.addAllAnalyzers();
/* 125 */     trackmate.computeSpotFeatures(true);
/* 126 */     trackmate.computeEdgeFeatures(true);
/* 127 */     trackmate.computeTrackFeatures(true);
/*     */     
/* 129 */     model.setLogger(oldLogger);
/* 130 */     logger.log("Done.\n");
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/action/RecomputeFeatureAction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */