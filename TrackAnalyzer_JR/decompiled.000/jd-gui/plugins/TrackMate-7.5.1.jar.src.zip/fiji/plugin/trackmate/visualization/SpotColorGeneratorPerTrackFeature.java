/*    */ package fiji.plugin.trackmate.visualization;
/*    */ 
/*    */ import fiji.plugin.trackmate.Model;
/*    */ import fiji.plugin.trackmate.Spot;
/*    */ import fiji.plugin.trackmate.gui.displaysettings.Colormap;
/*    */ import java.awt.Color;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SpotColorGeneratorPerTrackFeature
/*    */   implements FeatureColorGenerator<Spot>
/*    */ {
/*    */   private final Model model;
/*    */   private final Color missingValueColor;
/*    */   private final PerTrackFeatureColorGenerator colorGenerator;
/*    */   
/*    */   public SpotColorGeneratorPerTrackFeature(Model model, String trackFeature, Color missingValueColor, Color undefinedValueColor, Colormap colormap, double min, double max) {
/* 48 */     this.model = model;
/* 49 */     this.missingValueColor = missingValueColor;
/* 50 */     this.colorGenerator = new PerTrackFeatureColorGenerator(model, trackFeature, missingValueColor, undefinedValueColor, colormap, min, max);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Color color(Spot spot) {
/* 56 */     Integer trackID = this.model.getTrackModel().trackIDOf(spot);
/* 57 */     if (null == trackID || !this.model.getTrackModel().isVisible(trackID)) {
/* 58 */       return this.missingValueColor;
/*    */     }
/* 60 */     return this.colorGenerator.colorOf(trackID);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/visualization/SpotColorGeneratorPerTrackFeature.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */