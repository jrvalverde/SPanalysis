/*     */ package fiji.plugin.trackmate.visualization.hyperstack;
/*     */ 
/*     */ import fiji.plugin.trackmate.Logger;
/*     */ import fiji.plugin.trackmate.Model;
/*     */ import fiji.plugin.trackmate.SelectionModel;
/*     */ import fiji.plugin.trackmate.Spot;
/*     */ import fiji.plugin.trackmate.SpotRoi;
/*     */ import fiji.plugin.trackmate.detection.semiauto.SemiAutoTracker;
/*     */ import fiji.plugin.trackmate.util.TMUtils;
/*     */ import fiji.tool.AbstractTool;
/*     */ import fiji.tool.ToolWithOptions;
/*     */ import ij.IJ;
/*     */ import ij.ImagePlus;
/*     */ import ij.gui.FreehandRoi;
/*     */ import ij.gui.ImageCanvas;
/*     */ import ij.gui.Roi;
/*     */ import ij.gui.Toolbar;
/*     */ import java.awt.Component;
/*     */ import java.awt.MouseInfo;
/*     */ import java.awt.Point;
/*     */ import java.awt.event.ComponentEvent;
/*     */ import java.awt.event.KeyEvent;
/*     */ import java.awt.event.KeyListener;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.awt.event.MouseListener;
/*     */ import java.awt.event.MouseMotionListener;
/*     */ import java.awt.event.WindowAdapter;
/*     */ import java.awt.event.WindowEvent;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Locale;
/*     */ import java.util.Set;
/*     */ import javax.swing.SwingUtilities;
/*     */ import org.jgrapht.graph.DefaultWeightedEdge;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SpotEditTool
/*     */   extends AbstractTool
/*     */   implements MouseMotionListener, MouseListener, KeyListener, ToolWithOptions
/*     */ {
/*     */   private static final double COARSE_STEP = 2.0D;
/*     */   private static final double FINE_STEP = 0.20000000298023224D;
/*     */   private static final String TOOL_NAME = "Spot edit tool";
/*     */   private static final String TOOL_ICON = "CeacD70Cd8bD80D71Cc69D81CfefD91CdbcD72Cb9bD82Cd9bD73Cc8aD83CfefD93CdddD54CbaaD64Cb69D74Cb59D84Cb9aD94CdddDa4CfefD25Cd9bD35Cb8aD45CaaaD55CcccD65CfdeL7585CdccD95CaaaDa5Cb8aDb5Cd7aDc5CfceDd5CfeeD26Cc69D36Cc8aD46CdacDb6Cb59Dc6CecdDd6Cb9aD37CdcdD47CeeeDb7Ca89Dc7CfefD28Cc7aD38Cd9cD48CecdDb8Cb79Dc8CfdeDd8CcabD29Cb59D39Cb69D49CedeD59CeacDb9Cc59Dc9CebdDd9CfdeD0aCc7aD1aCb8aD2aCedeD3aCcbcD4aCb7aD5aCe9cD6aCeeeDbaCa89DcaCfefDdaCebdD0bCc59D1bCebdD2bCfefD4bCc7aL5b6bCeceDbbCb79DcbCfdeDdbCfeeD0cCa89D1cCfefD2cCcabL5c6cCc9bDbcCc59DccCdabDdcCedeD0dCb79D1dCedeD2dCc9bL5d6dCecdD9dCc8aDadCb9aDbdCdbcDcdCb8aDddCd8bDedCfceDfdCebdD0eCc59D1eCebdD2eCfeeD4eCc7aD5eCc6aD6eCfeeD7eCd9bD9eCc59DaeCfdeDbeCebdDdeCc59DeeCeacDfeCfefD0fCdbcD1fCdddD4fCdcdL5f6fCdddD7fCfdeD9fCdbdDafCebdDefCfefDff";
/*     */   private static final double FALL_BACK_RADIUS = 5.0D;
/*     */   private static SpotEditTool instance;
/*  97 */   HashMap<ImagePlus, HyperStackDisplayer> displayers = new HashMap<>();
/*     */ 
/*     */   
/* 100 */   private double previousRadius = 5.0D;
/*     */ 
/*     */   
/*     */   private Spot quickEditedSpot;
/*     */   
/*     */   private boolean autolinkingmode = false;
/*     */   
/* 107 */   SpotEditToolParams params = new SpotEditToolParams();
/*     */   
/* 109 */   private Logger logger = Logger.IJTOOLBAR_LOGGER;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private SpotEditToolConfigPanel configPanel;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ImagePlus imp;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private FreehandRoi roiedit;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static SpotEditTool getInstance() {
/* 136 */     if (null == instance) {
/* 137 */       instance = new SpotEditTool();
/*     */     }
/* 139 */     return instance;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isLaunched() {
/* 147 */     Toolbar toolbar = Toolbar.getInstance();
/* 148 */     if (null != toolbar && toolbar.getToolId("Spot edit tool") >= 0)
/* 149 */       return true; 
/* 150 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getToolName() {
/* 160 */     return "Spot edit tool";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getToolIcon() {
/* 166 */     return "CeacD70Cd8bD80D71Cc69D81CfefD91CdbcD72Cb9bD82Cd9bD73Cc8aD83CfefD93CdddD54CbaaD64Cb69D74Cb59D84Cb9aD94CdddDa4CfefD25Cd9bD35Cb8aD45CaaaD55CcccD65CfdeL7585CdccD95CaaaDa5Cb8aDb5Cd7aDc5CfceDd5CfeeD26Cc69D36Cc8aD46CdacDb6Cb59Dc6CecdDd6Cb9aD37CdcdD47CeeeDb7Ca89Dc7CfefD28Cc7aD38Cd9cD48CecdDb8Cb79Dc8CfdeDd8CcabD29Cb59D39Cb69D49CedeD59CeacDb9Cc59Dc9CebdDd9CfdeD0aCc7aD1aCb8aD2aCedeD3aCcbcD4aCb7aD5aCe9cD6aCeeeDbaCa89DcaCfefDdaCebdD0bCc59D1bCebdD2bCfefD4bCc7aL5b6bCeceDbbCb79DcbCfdeDdbCfeeD0cCa89D1cCfefD2cCcabL5c6cCc9bDbcCc59DccCdabDdcCedeD0dCb79D1dCedeD2dCc9bL5d6dCecdD9dCc8aDadCb9aDbdCdbcDcdCb8aDddCd8bDedCfceDfdCebdD0eCc59D1eCebdD2eCfeeD4eCc7aD5eCc6aD6eCfeeD7eCd9bD9eCc59DaeCfdeDbeCebdDdeCc59DeeCeacDfeCfefD0fCdbcD1fCdddD4fCdcdL5f6fCdddD7fCfdeD9fCdbdDafCebdDefCfefDff";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ImagePlus getImagePlus(ComponentEvent e) {
/* 176 */     this.imp = super.getImagePlus(e);
/* 177 */     return this.imp;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void registerTool(ImageCanvas canvas) {
/* 202 */     MouseListener[] listeners = canvas.getMouseListeners();
/* 203 */     for (MouseListener listener : listeners) {
/*     */       
/* 205 */       if (listener == this.mouseProxy) {
/*     */         return;
/*     */       }
/*     */     } 
/* 209 */     super.registerTool(canvas);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void register(ImagePlus lImp, HyperStackDisplayer displayer) {
/* 218 */     if (this.displayers.containsKey(lImp)) {
/* 219 */       unregisterTool(lImp);
/*     */     }
/* 221 */     this.displayers.put(lImp, displayer);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void mouseClicked(MouseEvent e) {
/* 231 */     ImagePlus lImp = getImagePlus(e);
/* 232 */     HyperStackDisplayer displayer = this.displayers.get(lImp);
/* 233 */     if (null == displayer) {
/*     */       return;
/*     */     }
/* 236 */     Spot clickLocation = makeSpot(lImp, displayer, getImageCanvas(e), e.getPoint());
/* 237 */     int frame = displayer.imp.getFrame() - 1;
/* 238 */     Model model = displayer.getModel();
/* 239 */     Spot target = model.getSpots().getSpotAt(clickLocation, frame, true);
/* 240 */     SelectionModel selectionModel = displayer.getSelectionModel();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 245 */     if (null == target) {
/*     */       
/* 247 */       if (!this.autolinkingmode) {
/*     */         
/* 249 */         selectionModel.clearSelection();
/* 250 */         this.logger.log("Cleared selection.\n");
/*     */       } 
/* 252 */       this.roiedit = null;
/* 253 */       lImp.setRoi((Roi)this.roiedit);
/*     */     }
/*     */     else {
/*     */       
/* 257 */       updateStatusBar(target, lImp.getCalibration().getUnits());
/* 258 */       int addToSelectionMask = 64;
/* 259 */       if ((e.getModifiersEx() & 0x40) == 64) {
/*     */         
/* 261 */         if (selectionModel.getSpotSelection().contains(target)) {
/* 262 */           selectionModel.removeSpotFromSelection(target);
/*     */         } else {
/* 264 */           selectionModel.addSpotToSelection(target);
/*     */         } 
/*     */       } else {
/*     */         
/* 268 */         selectionModel.clearSpotSelection();
/* 269 */         selectionModel.addSpotToSelection(target);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void mousePressed(MouseEvent e) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void mouseReleased(final MouseEvent e) {
/* 281 */     if (null != this.roiedit)
/*     */     {
/* 283 */       (new Thread("SpotEditTool roiedit processing")
/*     */         {
/*     */           public void run()
/*     */           {
/*     */             Iterator<Spot> it;
/* 288 */             SpotEditTool.this.roiedit.mouseReleased(e);
/* 289 */             ImagePlus lImp = SpotEditTool.this.getImagePlus(e);
/* 290 */             HyperStackDisplayer displayer = SpotEditTool.this.displayers.get(lImp);
/* 291 */             int frame = displayer.imp.getFrame() - 1;
/* 292 */             Model model = displayer.getModel();
/* 293 */             SelectionModel selectionModel = displayer.getSelectionModel();
/*     */ 
/*     */             
/* 296 */             if (IJ.shiftKeyDown()) {
/* 297 */               it = model.getSpots().iterator(true);
/*     */             } else {
/* 299 */               it = model.getSpots().iterator(Integer.valueOf(frame), true);
/*     */             } 
/* 301 */             Collection<Spot> added = new ArrayList<>();
/* 302 */             double[] calibration = TMUtils.getSpatialCalibration(lImp);
/*     */             
/* 304 */             while (it.hasNext()) {
/*     */               
/* 306 */               Spot spot = it.next();
/* 307 */               double x = spot.getFeature("POSITION_X").doubleValue();
/* 308 */               double y = spot.getFeature("POSITION_Y").doubleValue();
/*     */               
/* 310 */               int xp = (int)(x / calibration[0] + 0.5D);
/* 311 */               int yp = (int)(y / calibration[1] + 0.5D);
/*     */               
/* 313 */               if (null != SpotEditTool.this.roiedit && SpotEditTool.this.roiedit.contains(xp, yp)) {
/* 314 */                 added.add(spot);
/*     */               }
/*     */             } 
/* 317 */             if (!added.isEmpty()) {
/*     */               
/* 319 */               selectionModel.addSpotToSelection(added);
/* 320 */               if (added.size() == 1) {
/* 321 */                 SpotEditTool.this.logger.log("Added one spot to selection.\n");
/*     */               } else {
/* 323 */                 SpotEditTool.this.logger.log("Added " + added.size() + " spots to selection.\n");
/*     */               } 
/* 325 */             }  SpotEditTool.this.roiedit = null;
/*     */           }
/* 327 */         }).start();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void mouseEntered(MouseEvent e) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void mouseExited(MouseEvent e) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void mouseDragged(MouseEvent e) {
/* 342 */     ImagePlus lImp = getImagePlus(e);
/* 343 */     HyperStackDisplayer displayer = this.displayers.get(lImp);
/* 344 */     if (null == displayer) {
/*     */       return;
/*     */     }
/* 347 */     if (null == this.roiedit) {
/*     */       
/* 349 */       if (!IJ.spaceBarDown())
/*     */       {
/* 351 */         this.roiedit = new FreehandRoi(e.getX(), e.getY(), lImp)
/*     */           {
/*     */             private static final long serialVersionUID = 1L;
/*     */ 
/*     */ 
/*     */             
/*     */             protected void handleMouseUp(int screenX, int screenY) {
/* 358 */               this.type = 3;
/* 359 */               super.handleMouseUp(screenX, screenY);
/*     */             }
/*     */           };
/* 362 */         lImp.setRoi((Roi)this.roiedit);
/*     */       }
/*     */     
/*     */     } else {
/*     */       
/* 367 */       this.roiedit.mouseDragged(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void mouseMoved(MouseEvent e) {
/* 374 */     if (this.quickEditedSpot == null)
/*     */       return; 
/* 376 */     ImagePlus lImp = getImagePlus(e);
/* 377 */     double[] calibration = TMUtils.getSpatialCalibration(lImp);
/* 378 */     HyperStackDisplayer displayer = this.displayers.get(lImp);
/* 379 */     if (null == displayer) {
/*     */       return;
/*     */     }
/* 382 */     Point mouseLocation = e.getPoint();
/* 383 */     ImageCanvas canvas = getImageCanvas(e);
/* 384 */     double x = (-0.5D + canvas.offScreenXD(mouseLocation.x)) * calibration[0];
/* 385 */     double y = (-0.5D + canvas.offScreenYD(mouseLocation.y)) * calibration[1];
/* 386 */     double z = (lImp.getSlice() - 1) * calibration[2];
/*     */     
/* 388 */     this.quickEditedSpot.putFeature("POSITION_X", Double.valueOf(x));
/* 389 */     this.quickEditedSpot.putFeature("POSITION_Y", Double.valueOf(y));
/* 390 */     this.quickEditedSpot.putFeature("POSITION_Z", Double.valueOf(z));
/* 391 */     displayer.imp.updateAndDraw();
/*     */   } public void keyPressed(KeyEvent e) {
/*     */     ArrayList<Spot> spotSelection;
/*     */     double radius;
/*     */     int frame, currentT;
/*     */     ArrayList<DefaultWeightedEdge> edgeSelection;
/*     */     Spot clickLocation;
/*     */     int prevStep;
/*     */     Spot newSpot, target;
/*     */     int tp;
/*     */     double dt, d1;
/*     */     int i, factor;
/*     */     double dx, newRadius;
/*     */     SpotRoi roi;
/* 405 */     ImagePlus lImp = getImagePlus(e);
/* 406 */     if (lImp == null)
/*     */       return; 
/* 408 */     HyperStackDisplayer displayer = this.displayers.get(lImp);
/* 409 */     if (null == displayer) {
/*     */       return;
/*     */     }
/* 412 */     Model model = displayer.getModel();
/* 413 */     SelectionModel selectionModel = displayer.getSelectionModel();
/* 414 */     ImageCanvas canvas = lImp.getCanvas();
/*     */     
/* 416 */     int keycode = e.getKeyCode();
/*     */     
/* 418 */     switch (keycode) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case 127:
/* 424 */         spotSelection = new ArrayList<>(selectionModel.getSpotSelection());
/* 425 */         edgeSelection = new ArrayList<>(selectionModel.getEdgeSelection());
/* 426 */         model.beginUpdate();
/*     */         
/*     */         try {
/* 429 */           selectionModel.clearSelection();
/* 430 */           for (DefaultWeightedEdge edge : edgeSelection) {
/*     */             
/* 432 */             model.removeEdge(edge);
/* 433 */             this.logger.log("Removed edge " + edge + ".\n");
/*     */           } 
/* 435 */           for (Spot spot : spotSelection)
/*     */           {
/* 437 */             model.removeSpot(spot);
/* 438 */             this.logger.log("Removed spot " + spot + ".\n");
/*     */           }
/*     */         
/*     */         } finally {
/*     */           
/* 443 */           model.endUpdate();
/*     */         } 
/*     */         
/* 446 */         lImp.updateAndDraw();
/* 447 */         e.consume();
/*     */         break;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case 65:
/* 454 */         if (e.isShiftDown()) {
/*     */           
/* 456 */           this.logger.log("Semi-automatic tracking.\n");
/*     */           
/* 458 */           semiAutoTracking(model, selectionModel, lImp);
/*     */ 
/*     */           
/*     */           break;
/*     */         } 
/*     */         
/* 464 */         radius = this.previousRadius;
/* 465 */         newSpot = makeSpot(lImp, displayer, canvas, (Point)null);
/* 466 */         dt = (lImp.getCalibration()).frameInterval;
/* 467 */         i = displayer.imp.getFrame() - 1;
/* 468 */         newSpot.putFeature("POSITION_T", Double.valueOf(i * dt));
/* 469 */         newSpot.putFeature("FRAME", Double.valueOf(i));
/* 470 */         newSpot.putFeature("RADIUS", Double.valueOf(radius));
/* 471 */         newSpot.putFeature("QUALITY", Double.valueOf(-1.0D));
/*     */         
/* 473 */         model.beginUpdate();
/*     */         
/*     */         try {
/* 476 */           model.addSpotTo(newSpot, Integer.valueOf(i));
/* 477 */           this.logger.log("Added spot " + newSpot + " to frame " + i + ".\n");
/*     */         }
/*     */         finally {
/*     */           
/* 481 */           model.endUpdate();
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 489 */         if (this.autolinkingmode) {
/*     */           
/* 491 */           Set<Spot> set = selectionModel.getSpotSelection();
/* 492 */           if (set.size() == 1) {
/*     */             
/* 494 */             Spot source = set.iterator().next();
/* 495 */             if (newSpot.diffTo(source, "FRAME") != 0.0D) {
/*     */               
/* 497 */               model.beginUpdate();
/*     */               
/*     */               try {
/* 500 */                 model.addEdge(source, newSpot, -1.0D);
/* 501 */                 this.logger.log("Created a link between " + source + " and " + newSpot + ".\n");
/*     */               }
/*     */               finally {
/*     */                 
/* 505 */                 model.endUpdate();
/*     */               } 
/*     */             } 
/*     */           } 
/* 509 */           selectionModel.clearSpotSelection();
/* 510 */           selectionModel.addSpotToSelection(newSpot);
/*     */         } 
/*     */         
/* 513 */         lImp.updateAndDraw();
/* 514 */         e.consume();
/*     */         break;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case 68:
/* 523 */         frame = displayer.imp.getFrame() - 1;
/* 524 */         clickLocation = makeSpot(lImp, displayer, canvas, (Point)null);
/* 525 */         target = model.getSpots().getSpotAt(clickLocation, frame, true);
/* 526 */         if (null == target) {
/*     */ 
/*     */           
/* 529 */           e.consume();
/*     */           
/*     */           return;
/*     */         } 
/* 533 */         selectionModel.removeSpotFromSelection(target);
/* 534 */         model.beginUpdate();
/*     */         
/*     */         try {
/* 537 */           model.removeSpot(target);
/* 538 */           this.logger.log("Removed spot " + target + ".\n");
/*     */         }
/*     */         finally {
/*     */           
/* 542 */           model.endUpdate();
/*     */         } 
/*     */         
/* 545 */         lImp.updateAndDraw();
/*     */         
/* 547 */         e.consume();
/*     */         break;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case 32:
/* 555 */         if (null == this.quickEditedSpot) {
/*     */           
/* 557 */           frame = displayer.imp.getFrame() - 1;
/* 558 */           clickLocation = makeSpot(lImp, displayer, canvas, (Point)null);
/* 559 */           this.quickEditedSpot = model.getSpots().getSpotAt(clickLocation, frame, true);
/* 560 */           if (null == this.quickEditedSpot)
/*     */             return; 
/*     */         } 
/* 563 */         e.consume();
/*     */         break;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case 69:
/*     */       case 81:
/* 573 */         e.consume();
/* 574 */         frame = displayer.imp.getFrame() - 1;
/* 575 */         clickLocation = makeSpot(lImp, displayer, canvas, (Point)null);
/* 576 */         target = model.getSpots().getSpotAt(clickLocation, frame, true);
/* 577 */         if (null == target) {
/*     */           return;
/*     */         }
/* 580 */         d1 = target.getFeature("RADIUS").doubleValue();
/* 581 */         factor = (e.getKeyCode() == 81) ? -1 : 1;
/* 582 */         dx = (lImp.getCalibration()).pixelWidth;
/*     */         
/* 584 */         newRadius = e.isShiftDown() ? (d1 + factor * dx * 2.0D) : (d1 + factor * dx * 0.20000000298023224D);
/*     */ 
/*     */ 
/*     */         
/* 588 */         if (newRadius <= dx) {
/*     */           return;
/*     */         }
/*     */         
/* 592 */         this.previousRadius = newRadius;
/*     */         
/* 594 */         roi = target.getRoi();
/* 595 */         if (null == roi) {
/*     */           
/* 597 */           target.putFeature("RADIUS", Double.valueOf(newRadius));
/*     */         }
/*     */         else {
/*     */           
/* 601 */           double alpha = newRadius / d1;
/* 602 */           roi.scale(alpha);
/* 603 */           target.putFeature("RADIUS", Double.valueOf(roi.radius()));
/*     */         } 
/*     */         
/* 606 */         model.beginUpdate();
/*     */         
/*     */         try {
/* 609 */           model.updateFeatures(target);
/* 610 */           this.logger.log(String.format(Locale.US, "Changed spot " + target + " radius to %.1f " + model.getSpaceUnits() + ".\n", new Object[] { Double.valueOf(d1) }));
/*     */         }
/*     */         finally {
/*     */           
/* 614 */           model.endUpdate();
/*     */         } 
/* 616 */         lImp.updateAndDraw();
/*     */         break;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case 76:
/* 623 */         if (e.isShiftDown()) {
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 628 */           this.autolinkingmode = !this.autolinkingmode;
/* 629 */           this.logger.log("Toggled auto-linking mode " + (this.autolinkingmode ? "on.\n" : "off.\n"));
/*     */ 
/*     */         
/*     */         }
/*     */         else {
/*     */ 
/*     */ 
/*     */           
/* 637 */           Set<Spot> selectedSpots = selectionModel.getSpotSelection();
/* 638 */           if (selectedSpots.size() == 2) {
/*     */             
/* 640 */             Iterator<Spot> it = selectedSpots.iterator();
/* 641 */             Spot sourceTmp = it.next();
/* 642 */             Spot targetTmp = it.next();
/*     */             
/* 644 */             Spot source = (sourceTmp.diffTo(targetTmp, "FRAME") < 0.0D) ? sourceTmp : targetTmp;
/* 645 */             Spot spot1 = (sourceTmp.diffTo(targetTmp, "FRAME") < 0.0D) ? targetTmp : sourceTmp;
/*     */             
/* 647 */             if (model.getTrackModel().containsEdge(source, spot1))
/*     */             {
/*     */ 
/*     */ 
/*     */               
/* 652 */               model.beginUpdate();
/*     */               
/*     */               try {
/* 655 */                 model.removeEdge(source, spot1);
/* 656 */                 this.logger.log("Removed edge between " + source + " and " + spot1 + ".\n");
/*     */               }
/*     */               finally {
/*     */                 
/* 660 */                 model.endUpdate();
/*     */               
/*     */               }
/*     */ 
/*     */             
/*     */             }
/*     */             else
/*     */             {
/*     */               
/* 669 */               int ts = source.getFeature("FRAME").intValue();
/* 670 */               int tt = spot1.getFeature("FRAME").intValue();
/*     */               
/* 672 */               if (tt != ts)
/*     */               {
/* 674 */                 model.beginUpdate();
/*     */                 
/*     */                 try {
/* 677 */                   model.addEdge(source, spot1, -1.0D);
/* 678 */                   this.logger.log("Created an edge between " + source + " and " + spot1 + ".\n");
/*     */                 }
/*     */                 finally {
/*     */                   
/* 682 */                   model.endUpdate();
/*     */                 } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */                 
/* 690 */                 Spot single = (tt > ts) ? spot1 : source;
/* 691 */                 selectionModel.clearSpotSelection();
/* 692 */                 selectionModel.addSpotToSelection(single);
/*     */               }
/*     */               else
/*     */               {
/* 696 */                 this.logger.error("Cannot create an edge between two spots belonging to the same frame.\n");
/*     */               }
/*     */             
/*     */             }
/*     */           
/*     */           } else {
/*     */             
/* 703 */             this.logger.error("Expected selection to contain 2 spots, found " + selectedSpots.size() + ".\n");
/*     */           } 
/*     */         } 
/*     */         
/* 707 */         e.consume();
/*     */         break;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case 70:
/*     */       case 71:
/* 716 */         currentT = lImp.getT() - 1;
/* 717 */         prevStep = currentT / this.params.stepwiseTimeBrowsing * this.params.stepwiseTimeBrowsing;
/*     */         
/* 719 */         if (keycode == 71) {
/*     */           
/* 721 */           tp = prevStep + this.params.stepwiseTimeBrowsing;
/*     */ 
/*     */         
/*     */         }
/* 725 */         else if (currentT == prevStep) {
/* 726 */           tp = currentT - this.params.stepwiseTimeBrowsing;
/*     */         } else {
/* 728 */           tp = prevStep;
/*     */         } 
/* 730 */         lImp.setT(tp + 1);
/*     */         
/* 732 */         e.consume();
/*     */         break;
/*     */ 
/*     */ 
/*     */       
/*     */       case 87:
/* 738 */         e.consume();
/*     */         break;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void keyTyped(KeyEvent e) {}
/*     */ 
/*     */   
/*     */   private Spot makeSpot(ImagePlus lImp, HyperStackDisplayer displayer, ImageCanvas canvas, Point mouseLocation) {
/* 748 */     if (displayer == null)
/*     */     {
/* 750 */       displayer = this.displayers.get(lImp);
/*     */     }
/* 752 */     if (mouseLocation == null) {
/*     */       
/* 754 */       mouseLocation = MouseInfo.getPointerInfo().getLocation();
/* 755 */       SwingUtilities.convertPointFromScreen(mouseLocation, (Component)canvas);
/*     */     } 
/* 757 */     double[] calibration = TMUtils.getSpatialCalibration(lImp);
/* 758 */     return new Spot((-0.5D + canvas
/* 759 */         .offScreenXD(mouseLocation.x)) * calibration[0], (-0.5D + canvas
/* 760 */         .offScreenYD(mouseLocation.y)) * calibration[1], (lImp
/* 761 */         .getSlice() - 1) * calibration[2], 5.0D, -1.0D);
/*     */   }
/*     */ 
/*     */   
/*     */   public void keyReleased(KeyEvent e) {
/*     */     ImagePlus lImp;
/*     */     HyperStackDisplayer displayer;
/*     */     Model model;
/* 769 */     switch (e.getKeyCode()) {
/*     */ 
/*     */       
/*     */       case 32:
/* 773 */         if (null == this.quickEditedSpot)
/*     */           return; 
/* 775 */         lImp = getImagePlus(e);
/* 776 */         if (lImp == null)
/*     */           return; 
/* 778 */         displayer = this.displayers.get(lImp);
/* 779 */         if (null == displayer)
/*     */           return; 
/* 781 */         model = displayer.getModel();
/* 782 */         model.beginUpdate();
/*     */         
/*     */         try {
/* 785 */           model.updateFeatures(this.quickEditedSpot);
/*     */         }
/*     */         finally {
/*     */           
/* 789 */           model.endUpdate();
/*     */         } 
/* 791 */         this.quickEditedSpot = null;
/*     */         break;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void updateStatusBar(Spot spot, String units) {
/* 804 */     if (null == spot)
/*     */       return; 
/* 806 */     String statusString = "";
/* 807 */     if (null == spot.getName() || spot.getName().equals("")) {
/* 808 */       statusString = String.format(Locale.US, "Spot ID%d, x = %.1f, y = %.1f, z = %.1f, r = %.1f %s", new Object[] { Integer.valueOf(spot.ID()), spot.getFeature("POSITION_X"), spot.getFeature("POSITION_Y"), spot.getFeature("POSITION_Z"), spot.getFeature("RADIUS"), units });
/*     */     } else {
/* 810 */       statusString = String.format(Locale.US, "Spot %s, x = %.1f, y = %.1f, z = %.1f, r = %.1f %s", new Object[] { spot.getName(), spot.getFeature("POSITION_X"), spot.getFeature("POSITION_Y"), spot.getFeature("POSITION_Z"), spot.getFeature("RADIUS"), units });
/* 811 */     }  IJ.showStatus(statusString);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   void semiAutoTracking(Model model, SelectionModel selectionModel, ImagePlus lImp) {
/* 817 */     final SemiAutoTracker autotracker = new SemiAutoTracker(model, selectionModel, lImp, this.logger);
/* 818 */     autotracker.setParameters(this.params.qualityThreshold, this.params.distanceTolerance, this.params.nFrames);
/* 819 */     autotracker.setNumThreads(4);
/* 820 */     (new Thread("TrackMate semi-automated tracking thread")
/*     */       {
/*     */         
/*     */         public void run()
/*     */         {
/* 825 */           boolean ok = (autotracker.checkInput() && autotracker.process());
/* 826 */           if (!ok)
/* 827 */             SpotEditTool.this.logger.error(autotracker.getErrorMessage()); 
/*     */         }
/* 829 */       }).start();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void showOptionDialog() {
/* 835 */     if (null == this.configPanel) {
/*     */       
/* 837 */       this.configPanel = new SpotEditToolConfigPanel(this);
/* 838 */       this.configPanel.addWindowListener(new WindowAdapter()
/*     */           {
/*     */             
/*     */             public void windowClosing(WindowEvent e)
/*     */             {
/* 843 */               SpotEditTool.this.logger = Logger.IJTOOLBAR_LOGGER;
/*     */             }
/*     */           });
/*     */     } 
/* 847 */     this.configPanel.setLocation(this.toolbar.getLocationOnScreen());
/* 848 */     this.configPanel.setVisible(true);
/* 849 */     this.logger = this.configPanel.getLogger();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static class SpotEditToolParams
/*     */   {
/* 866 */     double qualityThreshold = 0.5D;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 871 */     double distanceTolerance = 2.0D;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 876 */     int nFrames = 10;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 881 */     int stepwiseTimeBrowsing = 5;
/*     */ 
/*     */ 
/*     */     
/*     */     public String toString() {
/* 886 */       return super.toString() + ": QualityThreshold = " + this.qualityThreshold + ", DistanceTolerance = " + this.distanceTolerance + ", nFrames = " + this.nFrames;
/*     */     }
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/visualization/hyperstack/SpotEditTool.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */