/*     */ package fiji.plugin.trackmate.tracking.sparselap;
/*     */ 
/*     */ import fiji.plugin.trackmate.Logger;
/*     */ import fiji.plugin.trackmate.Spot;
/*     */ import fiji.plugin.trackmate.SpotCollection;
/*     */ import fiji.plugin.trackmate.tracking.LAPUtils;
/*     */ import fiji.plugin.trackmate.tracking.SpotTracker;
/*     */ import fiji.plugin.trackmate.util.TMUtils;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import net.imglib2.algorithm.MultiThreadedBenchmarkAlgorithm;
/*     */ import org.jgrapht.graph.DefaultWeightedEdge;
/*     */ import org.jgrapht.graph.SimpleWeightedGraph;
/*     */ import org.scijava.Cancelable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SparseLAPTracker
/*     */   extends MultiThreadedBenchmarkAlgorithm
/*     */   implements SpotTracker, Cancelable
/*     */ {
/*     */   private static final String BASE_ERROR_MESSAGE = "[SparseLAPTracker] ";
/*     */   private SimpleWeightedGraph<Spot, DefaultWeightedEdge> graph;
/*  65 */   private Logger logger = Logger.VOID_LOGGER;
/*     */ 
/*     */   
/*     */   private final SpotCollection spots;
/*     */ 
/*     */   
/*     */   private final Map<String, Object> settings;
/*     */ 
/*     */   
/*     */   private boolean isCanceled;
/*     */ 
/*     */   
/*     */   private String cancelReason;
/*     */   
/*     */   private Cancelable cancelable;
/*     */ 
/*     */   
/*     */   public SparseLAPTracker(SpotCollection spots, Map<String, Object> settings) {
/*  83 */     this.spots = spots;
/*  84 */     this.settings = settings;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SimpleWeightedGraph<Spot, DefaultWeightedEdge> getResult() {
/*  94 */     return this.graph;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean checkInput() {
/* 100 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean process() {
/* 106 */     this.isCanceled = false;
/* 107 */     this.cancelReason = null;
/* 108 */     this.cancelable = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 115 */     if (null == this.spots) {
/*     */       
/* 117 */       this.errorMessage = "[SparseLAPTracker] The spot collection is null.";
/* 118 */       return false;
/*     */     } 
/*     */ 
/*     */     
/* 122 */     if (this.spots.keySet().isEmpty()) {
/*     */       
/* 124 */       this.errorMessage = "[SparseLAPTracker] The spot collection is empty.";
/* 125 */       return false;
/*     */     } 
/*     */ 
/*     */     
/* 129 */     boolean empty = true;
/* 130 */     for (Iterator<Integer> iterator = this.spots.keySet().iterator(); iterator.hasNext(); ) { int frame = ((Integer)iterator.next()).intValue();
/*     */       
/* 132 */       if (this.spots.getNSpots(frame, true) > 0) {
/*     */         
/* 134 */         empty = false;
/*     */         break;
/*     */       }  }
/*     */     
/* 138 */     if (empty) {
/*     */       
/* 140 */       this.errorMessage = "[SparseLAPTracker] The spot collection is empty.";
/* 141 */       return false;
/*     */     } 
/*     */     
/* 144 */     StringBuilder errorHolder = new StringBuilder();
/* 145 */     if (!checkSettingsValidity(this.settings, errorHolder)) {
/*     */       
/* 147 */       this.errorMessage = "[SparseLAPTracker] Incorrect settings map:\n" + errorHolder.toString();
/* 148 */       return false;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 155 */     long start = System.currentTimeMillis();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 163 */     Map<String, Object> ftfSettings = new HashMap<>();
/* 164 */     ftfSettings.put("LINKING_MAX_DISTANCE", this.settings.get("LINKING_MAX_DISTANCE"));
/* 165 */     ftfSettings.put("ALTERNATIVE_LINKING_COST_FACTOR", this.settings.get("ALTERNATIVE_LINKING_COST_FACTOR"));
/* 166 */     ftfSettings.put("LINKING_FEATURE_PENALTIES", this.settings.get("LINKING_FEATURE_PENALTIES"));
/*     */     
/* 168 */     SparseLAPFrameToFrameTracker frameToFrameLinker = new SparseLAPFrameToFrameTracker(this.spots, ftfSettings);
/* 169 */     this.cancelable = frameToFrameLinker;
/* 170 */     frameToFrameLinker.setNumThreads(this.numThreads);
/* 171 */     Logger.SlaveLogger ftfLogger = new Logger.SlaveLogger(this.logger, 0.0D, 0.5D);
/* 172 */     frameToFrameLinker.setLogger((Logger)ftfLogger);
/*     */     
/* 174 */     if (!frameToFrameLinker.checkInput() || !frameToFrameLinker.process()) {
/*     */       
/* 176 */       this.errorMessage = frameToFrameLinker.getErrorMessage();
/* 177 */       return false;
/*     */     } 
/*     */     
/* 180 */     this.graph = frameToFrameLinker.getResult();
/* 181 */     this.cancelable = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 188 */     Map<String, Object> slSettings = new HashMap<>();
/*     */     
/* 190 */     slSettings.put("ALLOW_GAP_CLOSING", this.settings.get("ALLOW_GAP_CLOSING"));
/* 191 */     slSettings.put("GAP_CLOSING_FEATURE_PENALTIES", this.settings.get("GAP_CLOSING_FEATURE_PENALTIES"));
/* 192 */     slSettings.put("GAP_CLOSING_MAX_DISTANCE", this.settings.get("GAP_CLOSING_MAX_DISTANCE"));
/* 193 */     slSettings.put("MAX_FRAME_GAP", this.settings.get("MAX_FRAME_GAP"));
/*     */     
/* 195 */     slSettings.put("ALLOW_TRACK_SPLITTING", this.settings.get("ALLOW_TRACK_SPLITTING"));
/* 196 */     slSettings.put("SPLITTING_FEATURE_PENALTIES", this.settings.get("SPLITTING_FEATURE_PENALTIES"));
/* 197 */     slSettings.put("SPLITTING_MAX_DISTANCE", this.settings.get("SPLITTING_MAX_DISTANCE"));
/*     */     
/* 199 */     slSettings.put("ALLOW_TRACK_MERGING", this.settings.get("ALLOW_TRACK_MERGING"));
/* 200 */     slSettings.put("MERGING_FEATURE_PENALTIES", this.settings.get("MERGING_FEATURE_PENALTIES"));
/* 201 */     slSettings.put("MERGING_MAX_DISTANCE", this.settings.get("MERGING_MAX_DISTANCE"));
/*     */     
/* 203 */     slSettings.put("ALTERNATIVE_LINKING_COST_FACTOR", this.settings.get("ALTERNATIVE_LINKING_COST_FACTOR"));
/* 204 */     slSettings.put("CUTOFF_PERCENTILE", this.settings.get("CUTOFF_PERCENTILE"));
/*     */ 
/*     */     
/* 207 */     SparseLAPSegmentTracker segmentLinker = new SparseLAPSegmentTracker(this.graph, slSettings);
/* 208 */     segmentLinker.setNumThreads(this.numThreads);
/* 209 */     Logger.SlaveLogger slLogger = new Logger.SlaveLogger(this.logger, 0.5D, 0.5D);
/* 210 */     segmentLinker.setLogger((Logger)slLogger);
/*     */     
/* 212 */     if (!segmentLinker.checkInput() || !segmentLinker.process()) {
/*     */       
/* 214 */       this.errorMessage = segmentLinker.getErrorMessage();
/* 215 */       return false;
/*     */     } 
/*     */     
/* 218 */     this.logger.setStatus("");
/* 219 */     this.logger.setProgress(1.0D);
/* 220 */     long end = System.currentTimeMillis();
/* 221 */     this.processingTime = end - start;
/*     */ 
/*     */     
/* 224 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLogger(Logger logger) {
/* 230 */     this.logger = logger;
/*     */   }
/*     */ 
/*     */   
/*     */   private static final boolean checkSettingsValidity(Map<String, Object> settings, StringBuilder str) {
/* 235 */     if (null == settings) {
/*     */       
/* 237 */       str.append("Settings map is null.\n");
/* 238 */       return false;
/*     */     } 
/*     */     
/* 241 */     boolean ok = true;
/*     */     
/* 243 */     ok &= TMUtils.checkParameter(settings, "LINKING_MAX_DISTANCE", Double.class, str);
/* 244 */     ok &= LAPUtils.checkFeatureMap(settings, "LINKING_FEATURE_PENALTIES", str);
/*     */     
/* 246 */     ok &= TMUtils.checkParameter(settings, "ALLOW_GAP_CLOSING", Boolean.class, str);
/* 247 */     ok &= TMUtils.checkParameter(settings, "GAP_CLOSING_MAX_DISTANCE", Double.class, str);
/* 248 */     ok &= TMUtils.checkParameter(settings, "MAX_FRAME_GAP", Integer.class, str);
/* 249 */     ok &= LAPUtils.checkFeatureMap(settings, "GAP_CLOSING_FEATURE_PENALTIES", str);
/*     */     
/* 251 */     ok &= TMUtils.checkParameter(settings, "ALLOW_TRACK_SPLITTING", Boolean.class, str);
/* 252 */     ok &= TMUtils.checkParameter(settings, "SPLITTING_MAX_DISTANCE", Double.class, str);
/* 253 */     ok &= LAPUtils.checkFeatureMap(settings, "SPLITTING_FEATURE_PENALTIES", str);
/*     */     
/* 255 */     ok &= TMUtils.checkParameter(settings, "ALLOW_TRACK_MERGING", Boolean.class, str);
/* 256 */     ok &= TMUtils.checkParameter(settings, "MERGING_MAX_DISTANCE", Double.class, str);
/* 257 */     ok &= LAPUtils.checkFeatureMap(settings, "MERGING_FEATURE_PENALTIES", str);
/*     */     
/* 259 */     ok &= TMUtils.checkParameter(settings, "CUTOFF_PERCENTILE", Double.class, str);
/* 260 */     ok &= TMUtils.checkParameter(settings, "ALTERNATIVE_LINKING_COST_FACTOR", Double.class, str);
/*     */ 
/*     */     
/* 263 */     List<String> mandatoryKeys = new ArrayList<>();
/* 264 */     mandatoryKeys.add("LINKING_MAX_DISTANCE");
/* 265 */     mandatoryKeys.add("ALLOW_GAP_CLOSING");
/* 266 */     mandatoryKeys.add("GAP_CLOSING_MAX_DISTANCE");
/* 267 */     mandatoryKeys.add("MAX_FRAME_GAP");
/* 268 */     mandatoryKeys.add("ALLOW_TRACK_SPLITTING");
/* 269 */     mandatoryKeys.add("SPLITTING_MAX_DISTANCE");
/* 270 */     mandatoryKeys.add("ALLOW_TRACK_MERGING");
/* 271 */     mandatoryKeys.add("MERGING_MAX_DISTANCE");
/* 272 */     mandatoryKeys.add("ALTERNATIVE_LINKING_COST_FACTOR");
/* 273 */     mandatoryKeys.add("CUTOFF_PERCENTILE");
/* 274 */     List<String> optionalKeys = new ArrayList<>();
/* 275 */     optionalKeys.add("LINKING_FEATURE_PENALTIES");
/* 276 */     optionalKeys.add("GAP_CLOSING_FEATURE_PENALTIES");
/* 277 */     optionalKeys.add("SPLITTING_FEATURE_PENALTIES");
/* 278 */     optionalKeys.add("MERGING_FEATURE_PENALTIES");
/* 279 */     optionalKeys.add("BLOCKING_VALUE");
/* 280 */     ok &= TMUtils.checkMapKeys(settings, mandatoryKeys, optionalKeys, str);
/*     */     
/* 282 */     return ok;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isCanceled() {
/* 290 */     return this.isCanceled;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void cancel(String reason) {
/* 296 */     this.isCanceled = true;
/* 297 */     this.cancelReason = reason;
/* 298 */     if (this.cancelable != null) {
/* 299 */       this.cancelable.cancel(reason);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public String getCancelReason() {
/* 305 */     return this.cancelReason;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/tracking/sparselap/SparseLAPTracker.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */