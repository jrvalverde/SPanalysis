/*     */ package fiji.plugin.trackmate.visualization;
/*     */ 
/*     */ import fiji.plugin.trackmate.FeatureModel;
/*     */ import fiji.plugin.trackmate.Model;
/*     */ import fiji.plugin.trackmate.TrackModel;
/*     */ import fiji.plugin.trackmate.gui.displaysettings.Colormap;
/*     */ import java.awt.Color;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.jgrapht.graph.DefaultWeightedEdge;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PerTrackFeatureColorGenerator
/*     */   implements TrackColorGenerator
/*     */ {
/*     */   private Map<Integer, Color> colorIndex;
/*     */   private final Model model;
/*     */   private final String feature;
/*     */   private final Colormap cmap;
/*     */   private final Color missingValueColor;
/*     */   
/*     */   public PerTrackFeatureColorGenerator(Model model, String trackFeature, Color missingValueColor, Color undefinedValueColor, Colormap colormap, double min, double max) {
/*  69 */     this.model = model;
/*  70 */     this.feature = trackFeature;
/*  71 */     this.missingValueColor = missingValueColor;
/*  72 */     this.cmap = colormap;
/*  73 */     this.colorIndex = new HashMap<>();
/*     */     
/*  75 */     TrackModel trackModel = model.getTrackModel();
/*  76 */     Set<Integer> trackIDs = trackModel.trackIDs(true);
/*     */     
/*  78 */     if (this.feature.equals("TRACK_INDEX")) {
/*     */ 
/*     */       
/*  81 */       GlasbeyLut.reset();
/*  82 */       for (Integer trackID : trackIDs) {
/*  83 */         this.colorIndex.put(trackID, GlasbeyLut.next());
/*     */       }
/*     */     }
/*     */     else {
/*     */       
/*  88 */       FeatureModel fm = model.getFeatureModel();
/*  89 */       this.colorIndex = new HashMap<>(trackIDs.size());
/*  90 */       for (Integer trackID : trackIDs) {
/*     */         Color col;
/*  92 */         Double val = fm.getTrackFeature(trackID, this.feature);
/*     */         
/*  94 */         if (null == val) {
/*  95 */           col = missingValueColor;
/*  96 */         } else if (val.isNaN()) {
/*  97 */           col = undefinedValueColor;
/*     */         } else {
/*  99 */           col = this.cmap.getPaint((val.doubleValue() - min) / (max - min));
/*     */         } 
/* 101 */         this.colorIndex.put(trackID, col);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Color colorOf(Integer trackID) {
/* 108 */     return this.colorIndex.get(trackID);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Color color(DefaultWeightedEdge edge) {
/* 114 */     Integer id = this.model.getTrackModel().trackIDOf(edge);
/* 115 */     if (id == null) {
/* 116 */       return this.missingValueColor;
/*     */     }
/* 118 */     return this.colorIndex.get(id);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/visualization/PerTrackFeatureColorGenerator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */