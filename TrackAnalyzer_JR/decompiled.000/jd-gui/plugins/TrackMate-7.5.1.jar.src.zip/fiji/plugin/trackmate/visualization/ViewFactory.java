package fiji.plugin.trackmate.visualization;

import fiji.plugin.trackmate.Model;
import fiji.plugin.trackmate.SelectionModel;
import fiji.plugin.trackmate.Settings;
import fiji.plugin.trackmate.TrackMateModule;
import fiji.plugin.trackmate.gui.displaysettings.DisplaySettings;

public interface ViewFactory extends TrackMateModule {
  TrackMateModelView create(Model paramModel, Settings paramSettings, SelectionModel paramSelectionModel, DisplaySettings paramDisplaySettings);
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/visualization/ViewFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */