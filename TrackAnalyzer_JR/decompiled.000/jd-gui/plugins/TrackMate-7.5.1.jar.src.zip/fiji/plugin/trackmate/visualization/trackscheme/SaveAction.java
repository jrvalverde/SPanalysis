/*     */ package fiji.plugin.trackmate.visualization.trackscheme;
/*     */ 
/*     */ import com.itextpdf.awt.PdfGraphics2D;
/*     */ import com.itextpdf.text.Document;
/*     */ import com.itextpdf.text.DocumentException;
/*     */ import com.itextpdf.text.Rectangle;
/*     */ import com.itextpdf.text.pdf.PdfContentByte;
/*     */ import com.itextpdf.text.pdf.PdfWriter;
/*     */ import com.mxgraph.canvas.mxGraphics2DCanvas;
/*     */ import com.mxgraph.canvas.mxICanvas;
/*     */ import com.mxgraph.canvas.mxSvgCanvas;
/*     */ import com.mxgraph.io.mxCodec;
/*     */ import com.mxgraph.io.mxGdCodec;
/*     */ import com.mxgraph.swing.mxGraphComponent;
/*     */ import com.mxgraph.util.mxCellRenderer;
/*     */ import com.mxgraph.util.mxDomUtils;
/*     */ import com.mxgraph.util.mxUtils;
/*     */ import com.mxgraph.util.mxXmlUtils;
/*     */ import com.mxgraph.util.png.mxPngEncodeParam;
/*     */ import com.mxgraph.util.png.mxPngImageEncoder;
/*     */ import com.mxgraph.view.mxGraph;
/*     */ import fiji.plugin.trackmate.gui.Icons;
/*     */ import fiji.plugin.trackmate.util.DefaultFileFilter;
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.io.File;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.net.URLEncoder;
/*     */ import java.util.HashSet;
/*     */ import javax.imageio.ImageIO;
/*     */ import javax.swing.AbstractAction;
/*     */ import javax.swing.JFileChooser;
/*     */ import javax.swing.JOptionPane;
/*     */ import javax.swing.filechooser.FileFilter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SaveAction
/*     */   extends AbstractAction
/*     */ {
/*     */   private static final long serialVersionUID = 7672151690754466760L;
/*  68 */   protected String lastDir = null;
/*     */   private final TrackScheme trackScheme;
/*     */   
/*     */   public SaveAction(TrackScheme trackScheme) {
/*  72 */     putValue("SmallIcon", Icons.CAMERA_EXPORT_ICON);
/*  73 */     this.trackScheme = trackScheme;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void saveXmlPng(TrackSchemeFrame frame, String filename, Color bg) throws IOException {
/*  81 */     mxGraphComponent graphComponent = (this.trackScheme.getGUI()).graphComponent;
/*  82 */     mxGraph graph = this.trackScheme.getGraph();
/*     */ 
/*     */     
/*  85 */     BufferedImage image = mxCellRenderer.createBufferedImage(graph, null, 1.0D, bg, graphComponent.isAntiAlias(), null, (mxGraphics2DCanvas)graphComponent.getCanvas());
/*     */ 
/*     */     
/*  88 */     mxCodec codec = new mxCodec();
/*  89 */     String xml = URLEncoder.encode(mxXmlUtils.getXml(codec.encode(graph.getModel())), "UTF-8");
/*  90 */     mxPngEncodeParam param = mxPngEncodeParam.getDefaultEncodeParam(image);
/*  91 */     param.setCompressedText(new String[] { "mxGraphModel", xml });
/*     */ 
/*     */     
/*  94 */     try (FileOutputStream outputStream = new FileOutputStream(new File(filename))) {
/*     */       
/*  96 */       mxPngImageEncoder encoder = new mxPngImageEncoder(outputStream, param);
/*  97 */       if (image != null) {
/*  98 */         encoder.encode(image);
/*     */       } else {
/* 100 */         JOptionPane.showMessageDialog((Component)graphComponent, "No Image Data");
/*     */       } 
/*     */     } 
/*     */   }
/*     */   public void actionPerformed(ActionEvent e) {
/*     */     String wd;
/* 106 */     mxGraphComponent graphComponent = (this.trackScheme.getGUI()).graphComponent;
/* 107 */     mxGraph graph = this.trackScheme.getGraph();
/* 108 */     FileFilter selectedFilter = null;
/* 109 */     DefaultFileFilter xmlPngFilter = new DefaultFileFilter(".png", "PNG+XML file (.png)");
/* 110 */     DefaultFileFilter defaultFileFilter1 = new DefaultFileFilter(".html", "VML file (.html)");
/* 111 */     String filename = null;
/* 112 */     boolean dialogShown = false;
/*     */ 
/*     */     
/* 115 */     if (this.lastDir != null) {
/* 116 */       wd = this.lastDir;
/*     */     } else {
/* 118 */       wd = System.getProperty("user.dir");
/*     */     } 
/*     */     
/* 121 */     JFileChooser fc = new JFileChooser(wd);
/*     */ 
/*     */     
/* 124 */     DefaultFileFilter defaultFileFilter2 = xmlPngFilter;
/* 125 */     fc.addChoosableFileFilter((FileFilter)defaultFileFilter2);
/*     */ 
/*     */     
/* 128 */     fc.addChoosableFileFilter((FileFilter)new DefaultFileFilter(".pdf", "PDF file (.pdf)"));
/* 129 */     fc.addChoosableFileFilter((FileFilter)new DefaultFileFilter(".svg", "SVG file (.svg)"));
/* 130 */     fc.addChoosableFileFilter((FileFilter)new DefaultFileFilter(".html", "HTML file (.html)"));
/* 131 */     fc.addChoosableFileFilter((FileFilter)defaultFileFilter1);
/* 132 */     fc.addChoosableFileFilter((FileFilter)new DefaultFileFilter(".txt", "Graph Drawing file (.txt)"));
/* 133 */     fc.addChoosableFileFilter((FileFilter)new DefaultFileFilter(".mxe", "mxGraph Editor file (.mxe)"));
/*     */ 
/*     */     
/* 136 */     String[] arrayOfString = ImageIO.getReaderFormatNames();
/*     */ 
/*     */     
/* 139 */     HashSet<String> formats = new HashSet<>();
/*     */     int i;
/* 141 */     for (i = 0; i < arrayOfString.length; i++) {
/* 142 */       String ext = arrayOfString[i].toString().toLowerCase();
/* 143 */       formats.add(ext);
/*     */     } 
/*     */     
/* 146 */     Object[] arrayOfObject = formats.toArray();
/*     */     
/* 148 */     for (i = 0; i < arrayOfObject.length; i++) {
/* 149 */       String ext = arrayOfObject[i].toString();
/* 150 */       fc.addChoosableFileFilter((FileFilter)new DefaultFileFilter("." + ext, ext.toUpperCase() + " File  (." + ext + ")"));
/*     */     } 
/*     */ 
/*     */     
/* 154 */     fc.addChoosableFileFilter((FileFilter)new DefaultFileFilter.ImageFileFilter("All Images"));
/* 155 */     fc.setFileFilter((FileFilter)defaultFileFilter2);
/* 156 */     int rc = fc.showDialog(null, "Save");
/* 157 */     dialogShown = true;
/*     */     
/* 159 */     if (rc != 0) {
/*     */       return;
/*     */     }
/* 162 */     this.lastDir = fc.getSelectedFile().getParent();
/*     */     
/* 164 */     filename = fc.getSelectedFile().getAbsolutePath();
/* 165 */     selectedFilter = fc.getFileFilter();
/*     */     
/* 167 */     if (selectedFilter instanceof DefaultFileFilter) {
/* 168 */       String ext = ((DefaultFileFilter)selectedFilter).getExtension();
/*     */       
/* 170 */       if (!filename.toLowerCase().endsWith(ext)) {
/* 171 */         filename = filename + ext;
/*     */       }
/*     */     } 
/*     */     
/* 175 */     if ((new File(filename)).exists() && JOptionPane.showConfirmDialog((Component)graphComponent, "Overwrite existing file?") != 0) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/*     */     try {
/* 181 */       String ext = filename.substring(filename.lastIndexOf('.') + 1);
/*     */       
/* 183 */       if (ext.equalsIgnoreCase("svg")) {
/* 184 */         mxSvgCanvas canvas = (mxSvgCanvas)mxCellRenderer.drawCells(graph, null, 1.0D, null, new mxCellRenderer.CanvasFactory()
/*     */             {
/*     */               public mxICanvas createCanvas(int width, int height) {
/* 187 */                 TrackSchemeSvgCanvas lCanvas = new TrackSchemeSvgCanvas(mxDomUtils.createSvgDocument(width, height));
/* 188 */                 lCanvas.setEmbedded(true);
/* 189 */                 return (mxICanvas)lCanvas;
/*     */               }
/*     */             });
/*     */         
/* 193 */         mxUtils.writeFile(mxXmlUtils.getXml(canvas.getDocument()), filename);
/*     */       }
/* 195 */       else if (selectedFilter == defaultFileFilter1) {
/* 196 */         mxUtils.writeFile(mxXmlUtils.getXml(mxCellRenderer.createVmlDocument(graph, null, 1.0D, null, null).getDocumentElement()), filename);
/*     */       }
/* 198 */       else if (ext.equalsIgnoreCase("html")) {
/* 199 */         mxUtils.writeFile(mxXmlUtils.getXml(mxCellRenderer.createHtmlDocument(graph, null, 1.0D, null, null).getDocumentElement()), filename);
/*     */       }
/* 201 */       else if (ext.equalsIgnoreCase("mxe") || ext.equalsIgnoreCase("xml")) {
/* 202 */         mxCodec codec = new mxCodec();
/* 203 */         String xml = mxXmlUtils.getXml(codec.encode(graph.getModel()));
/* 204 */         mxUtils.writeFile(xml, filename);
/*     */       }
/* 206 */       else if (ext.equalsIgnoreCase("txt")) {
/* 207 */         String content = mxGdCodec.encode(graph);
/* 208 */         mxUtils.writeFile(content, filename);
/*     */       }
/* 210 */       else if (ext.equalsIgnoreCase("pdf")) {
/* 211 */         exportGraphToPdf(filename);
/*     */       } else {
/*     */         
/* 214 */         Color bg = null;
/*     */         
/* 216 */         if ((!ext.equalsIgnoreCase("gif") && !ext.equalsIgnoreCase("png")) || 
/* 217 */           JOptionPane.showConfirmDialog((Component)graphComponent, "Transparent Background?") != 0) {
/* 218 */           bg = graphComponent.getBackground();
/*     */         }
/*     */         
/* 221 */         if (selectedFilter == xmlPngFilter || (ext.equalsIgnoreCase("png") && !dialogShown)) {
/* 222 */           saveXmlPng(this.trackScheme.getGUI(), filename, bg);
/*     */         } else {
/* 224 */           BufferedImage image = mxCellRenderer.createBufferedImage(graph, null, 1.0D, bg, graphComponent.isAntiAlias(), null, (mxGraphics2DCanvas)graphComponent.getCanvas());
/*     */           
/* 226 */           if (image != null) {
/* 227 */             ImageIO.write(image, ext, new File(filename));
/*     */           } else {
/* 229 */             JOptionPane.showMessageDialog((Component)graphComponent, "No Image Data");
/*     */           }
/*     */         
/*     */         } 
/*     */       } 
/* 234 */     } catch (Throwable ex) {
/* 235 */       ex.printStackTrace();
/* 236 */       JOptionPane.showMessageDialog((Component)graphComponent, ex.toString(), "Error", 0);
/*     */     } 
/*     */   }
/*     */   private void exportGraphToPdf(String filename) {
/*     */     PdfGraphics2D pdfGraphics2D;
/* 241 */     Rectangle bounds = new Rectangle((this.trackScheme.getGUI()).graphComponent.getViewport().getViewSize());
/*     */     
/* 243 */     Rectangle pageSize = new Rectangle(bounds.x, bounds.y, bounds.width, bounds.height);
/* 244 */     Document document = new Document(pageSize);
/*     */     
/* 246 */     PdfWriter writer = null;
/* 247 */     Graphics2D g2 = null;
/*     */     
/*     */     try {
/* 250 */       writer = PdfWriter.getInstance(document, new FileOutputStream(filename));
/*     */       
/* 252 */       document.open();
/*     */       
/* 254 */       PdfContentByte canvas = writer.getDirectContent();
/* 255 */       pdfGraphics2D = new PdfGraphics2D(canvas, pageSize.getWidth(), pageSize.getHeight());
/* 256 */       (this.trackScheme.getGUI()).graphComponent.getViewport().paintComponents((Graphics)pdfGraphics2D);
/*     */     }
/* 258 */     catch (FileNotFoundException e) {
/*     */       
/* 260 */       e.printStackTrace();
/*     */     }
/* 262 */     catch (DocumentException e) {
/*     */       
/* 264 */       e.printStackTrace();
/*     */     }
/*     */     finally {
/*     */       
/* 268 */       if (null != pdfGraphics2D)
/* 269 */         pdfGraphics2D.dispose(); 
/* 270 */       document.close();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/visualization/trackscheme/SaveAction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */