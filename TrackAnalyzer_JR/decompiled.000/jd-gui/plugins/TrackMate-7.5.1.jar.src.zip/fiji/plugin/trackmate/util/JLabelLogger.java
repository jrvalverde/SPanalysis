/*    */ package fiji.plugin.trackmate.util;
/*    */ 
/*    */ import fiji.plugin.trackmate.Logger;
/*    */ import fiji.plugin.trackmate.gui.Fonts;
/*    */ import java.awt.Color;
/*    */ import javax.swing.JLabel;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JLabelLogger
/*    */   extends JLabel
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private final LoggerInJLabel logger;
/*    */   
/*    */   public JLabelLogger() {
/* 42 */     this.logger = new LoggerInJLabel(this);
/* 43 */     setHorizontalAlignment(0);
/* 44 */     setFont(Fonts.SMALL_FONT);
/*    */   }
/*    */ 
/*    */   
/*    */   public Logger getLogger() {
/* 49 */     return this.logger;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private static class LoggerInJLabel
/*    */     extends Logger
/*    */   {
/*    */     private final JLabel label;
/*    */ 
/*    */ 
/*    */     
/*    */     public LoggerInJLabel(JLabel label) {
/* 63 */       this.label = label;
/*    */     }
/*    */ 
/*    */ 
/*    */ 
/*    */     
/*    */     public void log(String message, Color color) {
/*    */       String msg;
/* 71 */       if (null == message) {
/* 72 */         msg = "null";
/* 73 */       } else if (message.startsWith("<html>")) {
/* 74 */         msg = message;
/*    */       } else {
/* 76 */         msg = "<html>" + message + "</html>";
/*    */       } 
/* 78 */       this.label.setText(msg);
/* 79 */       this.label.setForeground(color);
/*    */     }
/*    */ 
/*    */ 
/*    */     
/*    */     public void error(String message) {
/* 85 */       log(message, Logger.ERROR_COLOR);
/*    */     }
/*    */ 
/*    */ 
/*    */ 
/*    */     
/*    */     public void setProgress(double val) {}
/*    */ 
/*    */ 
/*    */     
/*    */     public void setStatus(String status) {
/* 96 */       log(status, Logger.BLUE_COLOR);
/*    */     }
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/util/JLabelLogger.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */