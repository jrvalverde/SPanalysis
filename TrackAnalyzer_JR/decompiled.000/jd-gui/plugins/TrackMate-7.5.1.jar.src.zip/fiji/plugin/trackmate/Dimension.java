/*    */ package fiji.plugin.trackmate;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum Dimension
/*    */ {
/* 25 */   NONE,
/* 26 */   QUALITY,
/* 27 */   COST,
/* 28 */   INTENSITY,
/* 29 */   INTENSITY_SQUARED,
/* 30 */   POSITION,
/* 31 */   VELOCITY,
/* 32 */   LENGTH,
/* 33 */   AREA,
/* 34 */   TIME,
/* 35 */   ANGLE,
/* 36 */   RATE,
/* 37 */   ANGLE_RATE,
/* 38 */   STRING;
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/Dimension.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */