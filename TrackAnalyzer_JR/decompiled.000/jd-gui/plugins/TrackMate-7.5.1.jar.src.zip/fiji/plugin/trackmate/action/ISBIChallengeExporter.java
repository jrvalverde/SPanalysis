/*     */ package fiji.plugin.trackmate.action;
/*     */ 
/*     */ import fiji.plugin.trackmate.Logger;
/*     */ import fiji.plugin.trackmate.Model;
/*     */ import fiji.plugin.trackmate.SelectionModel;
/*     */ import fiji.plugin.trackmate.Settings;
/*     */ import fiji.plugin.trackmate.Spot;
/*     */ import fiji.plugin.trackmate.TrackMate;
/*     */ import fiji.plugin.trackmate.gui.Icons;
/*     */ import fiji.plugin.trackmate.gui.displaysettings.DisplaySettings;
/*     */ import fiji.plugin.trackmate.io.IOUtils;
/*     */ import java.awt.Frame;
/*     */ import java.io.File;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.util.Date;
/*     */ import java.util.Set;
/*     */ import java.util.TreeSet;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import javax.swing.ImageIcon;
/*     */ import org.jdom2.Content;
/*     */ import org.jdom2.Document;
/*     */ import org.jdom2.Element;
/*     */ import org.jdom2.output.Format;
/*     */ import org.jdom2.output.XMLOutputter;
/*     */ import org.scijava.plugin.Plugin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ISBIChallengeExporter
/*     */   extends AbstractTMAction
/*     */ {
/*     */   public static final String NAME = "Export to ISBI challenge format";
/*     */   public static final String KEY = "EXPORT_TO_ISBI_CHALLENGE_FORMAT";
/*     */   public static final String INFO_TEXT = "<html>Export the current model content to a XML file following the ISBI 2012 particle tracking challenge format, as specified on <a href='http://bioimageanalysis.org/track/'></a>. <p> Only tracks are exported. If there is no track, this action does nothing. </html>";
/*     */   private static final String CONTENT_KEY = "TrackContestISBI2012";
/*     */   private static final String DATE_ATT = "generationDateTime";
/*     */   private static final String SNR_ATT = "snr";
/*     */   private static final String DENSITY_ATT = "density";
/*     */   private static final String SCENARIO_ATT = "scenario";
/*     */   private static final String TRACK_KEY = "particle";
/*     */   private static final String SPOT_KEY = "detection";
/*     */   private static final String X_ATT = "x";
/*     */   private static final String Y_ATT = "y";
/*     */   private static final String Z_ATT = "z";
/*     */   private static final String T_ATT = "t";
/*     */   
/*     */   public void execute(TrackMate trackmate, SelectionModel selectionModel, DisplaySettings displaySettings, Frame parent) {
/*  71 */     Model model = trackmate.getModel();
/*     */     
/*  73 */     File folder = (new File(System.getProperty("user.dir"))).getParentFile().getParentFile();
/*     */     try {
/*  75 */       String filename = (trackmate.getSettings()).imageFileName;
/*  76 */       filename = filename.substring(0, filename.indexOf("."));
/*  77 */       file = new File(folder.getPath() + File.separator + filename + "_ISBI.xml");
/*  78 */     } catch (NullPointerException npe) {
/*  79 */       file = new File(folder.getPath() + File.separator + "ISBIChallenge2012Result.xml");
/*     */     } 
/*  81 */     File file = IOUtils.askForFileForSaving(file, parent, this.logger);
/*     */     
/*  83 */     exportToFile(model, trackmate.getSettings(), file, this.logger);
/*     */   }
/*     */ 
/*     */   
/*     */   public static void exportToFile(Model model, Settings settings, File file) {
/*  88 */     exportToFile(model, settings, file, model.getLogger());
/*     */   }
/*     */ 
/*     */   
/*     */   public static void exportToFile(Model model, Settings settings, File file, Logger logger) {
/*  93 */     logger.log("Exporting to ISBI 2012 particle tracking challenge format.\n");
/*  94 */     int ntracks = model.getTrackModel().nTracks(true);
/*  95 */     if (ntracks == 0) {
/*  96 */       logger.log("No visible track found. Aborting.\n");
/*     */       
/*     */       return;
/*     */     } 
/* 100 */     logger.log("  Preparing XML data.\n");
/* 101 */     Element root = marshall(model, settings);
/*     */     
/* 103 */     logger.log("  Writing to file.\n");
/* 104 */     Document document = new Document(root);
/* 105 */     XMLOutputter outputter = new XMLOutputter(Format.getPrettyFormat());
/*     */     try {
/* 107 */       outputter.output(document, new FileOutputStream(file));
/* 108 */     } catch (FileNotFoundException e) {
/* 109 */       logger.error("Trouble writing to " + file + ":\n" + e.getMessage());
/* 110 */     } catch (IOException e) {
/* 111 */       logger.error("Trouble writing to " + file + ":\n" + e.getMessage());
/*     */     } 
/* 113 */     logger.log("Done.\n");
/*     */   }
/*     */   private static final Element marshall(Model model, Settings settings) {
/*     */     String snr_val, density_val, scenario_val;
/* 117 */     Logger logger = model.getLogger();
/*     */     
/* 119 */     Element root = new Element("root");
/* 120 */     Element content = new Element("TrackContestISBI2012");
/*     */ 
/*     */     
/* 123 */     String filename = settings.imageFileName;
/* 124 */     String pattern = "^(\\w+) snr (\\d+) density (\\w+)\\.";
/* 125 */     Pattern r = Pattern.compile("^(\\w+) snr (\\d+) density (\\w+)\\.");
/* 126 */     Matcher m = r.matcher(filename);
/*     */ 
/*     */ 
/*     */     
/* 130 */     if (m.find()) {
/* 131 */       scenario_val = m.group(1);
/* 132 */       snr_val = m.group(2);
/* 133 */       density_val = m.group(3);
/*     */     } else {
/* 135 */       scenario_val = filename;
/* 136 */       snr_val = "?";
/* 137 */       density_val = "?";
/*     */     } 
/* 139 */     content.setAttribute("snr", snr_val);
/* 140 */     content.setAttribute("density", density_val);
/* 141 */     content.setAttribute("scenario", scenario_val);
/* 142 */     content.setAttribute("generationDateTime", (new Date()).toString());
/*     */     
/* 144 */     logger.setStatus("Marshalling...");
/* 145 */     Integer[] visibleTracks = (Integer[])model.getTrackModel().trackIDs(true).toArray((Object[])new Integer[0]);
/* 146 */     for (int i = 0; i < model.getTrackModel().nTracks(true); i++) {
/*     */       
/* 148 */       Element trackElement = new Element("particle");
/* 149 */       int trackindex = visibleTracks[i].intValue();
/* 150 */       Set<Spot> track = model.getTrackModel().trackSpots(Integer.valueOf(trackindex));
/*     */       
/* 152 */       TreeSet<Spot> sortedTrack = new TreeSet<>(Spot.timeComparator);
/* 153 */       sortedTrack.addAll(track);
/*     */       
/* 155 */       for (Spot spot : sortedTrack) {
/* 156 */         int t = spot.getFeature("FRAME").intValue();
/* 157 */         double x = spot.getFeature("POSITION_X").doubleValue();
/* 158 */         double y = spot.getFeature("POSITION_Y").doubleValue();
/* 159 */         double z = spot.getFeature("POSITION_Z").doubleValue();
/*     */         
/* 161 */         Element spotElement = new Element("detection");
/* 162 */         spotElement.setAttribute("t", "" + t);
/* 163 */         spotElement.setAttribute("x", "" + x);
/* 164 */         spotElement.setAttribute("y", "" + y);
/* 165 */         spotElement.setAttribute("z", "" + z);
/* 166 */         trackElement.addContent((Content)spotElement);
/*     */       } 
/* 168 */       content.addContent((Content)trackElement);
/* 169 */       logger.setProgress(i / (0.0D + model.getTrackModel().nTracks(true)));
/*     */     } 
/*     */     
/* 172 */     logger.setStatus("");
/* 173 */     logger.setProgress(1.0D);
/* 174 */     root.addContent((Content)content);
/* 175 */     return root;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Plugin(type = TrackMateActionFactory.class, visible = true)
/*     */   public static class Factory
/*     */     implements TrackMateActionFactory
/*     */   {
/*     */     public String getInfoText() {
/* 201 */       return "<html>Export the current model content to a XML file following the ISBI 2012 particle tracking challenge format, as specified on <a href='http://bioimageanalysis.org/track/'></a>. <p> Only tracks are exported. If there is no track, this action does nothing. </html>";
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public String getName() {
/* 207 */       return "Export to ISBI challenge format";
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public String getKey() {
/* 213 */       return "EXPORT_TO_ISBI_CHALLENGE_FORMAT";
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public ImageIcon getIcon() {
/* 219 */       return Icons.ISBI_ICON;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public TrackMateAction create() {
/* 225 */       return new ISBIChallengeExporter();
/*     */     }
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/action/ISBIChallengeExporter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */