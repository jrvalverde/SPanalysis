/*     */ package fiji.plugin.trackmate.visualization.hyperstack;
/*     */ 
/*     */ import fiji.plugin.trackmate.Model;
/*     */ import fiji.plugin.trackmate.Spot;
/*     */ import fiji.plugin.trackmate.SpotCollection;
/*     */ import fiji.plugin.trackmate.SpotRoi;
/*     */ import fiji.plugin.trackmate.features.FeatureUtils;
/*     */ import fiji.plugin.trackmate.gui.displaysettings.DisplaySettings;
/*     */ import fiji.plugin.trackmate.util.TMUtils;
/*     */ import fiji.plugin.trackmate.visualization.FeatureColorGenerator;
/*     */ import ij.ImagePlus;
/*     */ import ij.gui.Roi;
/*     */ import java.awt.AlphaComposite;
/*     */ import java.awt.BasicStroke;
/*     */ import java.awt.Color;
/*     */ import java.awt.Composite;
/*     */ import java.awt.Font;
/*     */ import java.awt.FontMetrics;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.RenderingHints;
/*     */ import java.awt.Stroke;
/*     */ import java.awt.geom.AffineTransform;
/*     */ import java.awt.geom.Path2D;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SpotOverlay
/*     */   extends Roi
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   protected Spot editingSpot;
/*     */   protected final double[] calibration;
/*     */   protected FontMetrics fm;
/*  70 */   protected Collection<Spot> spotSelection = new ArrayList<>();
/*     */ 
/*     */ 
/*     */   
/*     */   protected DisplaySettings displaySettings;
/*     */ 
/*     */   
/*     */   protected final Model model;
/*     */ 
/*     */ 
/*     */   
/*     */   public SpotOverlay(Model model, ImagePlus imp, DisplaySettings displaySettings) {
/*  82 */     super(0, 0, imp);
/*  83 */     this.model = model;
/*  84 */     this.imp = imp;
/*  85 */     this.calibration = TMUtils.getSpatialCalibration(imp);
/*  86 */     this.displaySettings = displaySettings;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void drawOverlay(Graphics g) {
/*  96 */     int xcorner = this.ic.offScreenX(0);
/*  97 */     int ycorner = this.ic.offScreenY(0);
/*  98 */     double magnification = getMagnification();
/*  99 */     SpotCollection spots = this.model.getSpots();
/*     */     
/* 101 */     if (!this.displaySettings.isSpotVisible()) {
/*     */       return;
/*     */     }
/* 104 */     boolean doLimitDrawingDepth = this.displaySettings.isZDrawingDepthLimited();
/* 105 */     double drawingDepth = this.displaySettings.getZDrawingDepth();
/* 106 */     DisplaySettings.TrackDisplayMode trackDisplayMode = this.displaySettings.getTrackDisplayMode();
/* 107 */     boolean selectionOnly = (trackDisplayMode == DisplaySettings.TrackDisplayMode.SELECTION_ONLY);
/* 108 */     boolean filled = this.displaySettings.isSpotFilled();
/* 109 */     float alpha = (float)this.displaySettings.getSpotTransparencyAlpha();
/*     */     
/* 111 */     Graphics2D g2d = (Graphics2D)g;
/*     */ 
/*     */     
/* 114 */     AffineTransform originalTransform = g2d.getTransform();
/* 115 */     Composite originalComposite = g2d.getComposite();
/* 116 */     Stroke originalStroke = g2d.getStroke();
/* 117 */     Color originalColor = g2d.getColor();
/* 118 */     Font originalFont = g2d.getFont();
/*     */     
/* 120 */     g2d.setComposite(AlphaComposite.getInstance(3, alpha));
/* 121 */     g2d.setFont(this.displaySettings.getFont());
/* 122 */     g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, 
/* 123 */         this.displaySettings.getUseAntialiasing() ? RenderingHints.VALUE_ANTIALIAS_ON : RenderingHints.VALUE_ANTIALIAS_OFF);
/* 124 */     this.fm = g2d.getFontMetrics();
/*     */     
/* 126 */     double zslice = (this.imp.getSlice() - 1) * this.calibration[2];
/* 127 */     double lMag = magnification;
/* 128 */     int frame = this.imp.getFrame() - 1;
/*     */ 
/*     */     
/* 131 */     FeatureColorGenerator<Spot> colorGenerator = FeatureUtils.createSpotColorGenerator(this.model, this.displaySettings);
/*     */     
/* 133 */     g2d.setStroke(new BasicStroke((float)this.displaySettings.getLineThickness()));
/*     */     
/* 135 */     if (selectionOnly && null != this.spotSelection) {
/*     */ 
/*     */       
/* 138 */       for (Spot spot : this.spotSelection) {
/*     */         
/* 140 */         if (spot == this.editingSpot) {
/*     */           continue;
/*     */         }
/* 143 */         int sFrame = spot.getFeature("FRAME").intValue();
/* 144 */         if (sFrame != frame) {
/*     */           continue;
/*     */         }
/* 147 */         double z = spot.getFeature("POSITION_Z").doubleValue();
/* 148 */         if (doLimitDrawingDepth && Math.abs(z - zslice) > drawingDepth) {
/*     */           continue;
/*     */         }
/* 151 */         Color color = colorGenerator.color(spot);
/* 152 */         g2d.setColor(color);
/* 153 */         drawSpot(g2d, spot, zslice, xcorner, ycorner, lMag, filled);
/*     */       } 
/*     */     } else {
/*     */       Iterator<Spot> iterator;
/*     */ 
/*     */ 
/*     */       
/* 160 */       for (iterator = spots.iterator(Integer.valueOf(frame), true); iterator.hasNext(); ) {
/*     */         
/* 162 */         Spot spot = iterator.next();
/*     */         
/* 164 */         if (this.editingSpot == spot || (this.spotSelection != null && this.spotSelection.contains(spot))) {
/*     */           continue;
/*     */         }
/* 167 */         Color color = colorGenerator.color(spot);
/* 168 */         g2d.setColor(color);
/*     */         
/* 170 */         double z = spot.getFeature("POSITION_Z").doubleValue();
/* 171 */         if (doLimitDrawingDepth && Math.abs(z - zslice) > drawingDepth) {
/*     */           continue;
/*     */         }
/* 174 */         drawSpot(g2d, spot, zslice, xcorner, ycorner, lMag, filled);
/*     */       } 
/*     */ 
/*     */       
/* 178 */       if (null != this.spotSelection) {
/*     */         
/* 180 */         g2d.setStroke(new BasicStroke((float)this.displaySettings.getSelectionLineThickness()));
/* 181 */         g2d.setColor(this.displaySettings.getHighlightColor());
/* 182 */         for (iterator = this.spotSelection.iterator(); iterator.hasNext(); ) { Spot spot = iterator.next();
/*     */           
/* 184 */           if (spot == this.editingSpot) {
/*     */             continue;
/*     */           }
/* 187 */           int sFrame = spot.getFeature("FRAME").intValue();
/* 188 */           if (sFrame != frame) {
/*     */             continue;
/*     */           }
/* 191 */           drawSpot(g2d, spot, zslice, xcorner, ycorner, lMag, filled); }
/*     */       
/*     */       } 
/*     */     } 
/*     */     
/* 196 */     drawExtraLayer(g2d, frame);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 202 */     if (null != this.editingSpot) {
/*     */       
/* 204 */       g2d.setColor(this.displaySettings.getHighlightColor());
/* 205 */       g2d.setStroke(new BasicStroke(
/* 206 */             (float)this.displaySettings.getLineThickness(), 1, 1, 1.0F, new float[] { 5.0F, 5.0F }, 0.0F));
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 211 */       double x = this.editingSpot.getFeature("POSITION_X").doubleValue();
/* 212 */       double y = this.editingSpot.getFeature("POSITION_Y").doubleValue();
/* 213 */       double radius = this.editingSpot.getFeature("RADIUS").doubleValue() / this.calibration[0] * lMag;
/*     */       
/* 215 */       double xp = x / this.calibration[0] + 0.5D;
/* 216 */       double yp = y / this.calibration[1] + 0.5D;
/*     */       
/* 218 */       double xs = (xp - xcorner) * lMag;
/* 219 */       double ys = (yp - ycorner) * lMag;
/* 220 */       double radiusRatio = this.displaySettings.getSpotDisplayRadius();
/* 221 */       g2d.drawOval((int)Math.round(xs - radius * radiusRatio), (int)Math.round(ys - radius * radiusRatio), (int)Math.round(2.0D * radius * radiusRatio), (int)Math.round(2.0D * radius * radiusRatio));
/*     */     } 
/*     */ 
/*     */     
/* 225 */     g2d.setTransform(originalTransform);
/* 226 */     g2d.setComposite(originalComposite);
/* 227 */     g2d.setStroke(originalStroke);
/* 228 */     g2d.setColor(originalColor);
/* 229 */     g2d.setFont(originalFont);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void drawExtraLayer(Graphics2D g2d, int frame) {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSpotSelection(Collection<Spot> spots) {
/* 241 */     this.spotSelection = spots;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void drawSpot(Graphics2D g2d, Spot spot, double zslice, int xcorner, int ycorner, double magnification, boolean filled) {
/* 246 */     double x = spot.getFeature("POSITION_X").doubleValue();
/* 247 */     double y = spot.getFeature("POSITION_Y").doubleValue();
/* 248 */     double z = spot.getFeature("POSITION_Z").doubleValue();
/* 249 */     double dz2 = (z - zslice) * (z - zslice);
/* 250 */     double radiusRatio = this.displaySettings.getSpotDisplayRadius();
/* 251 */     double radius = spot.getFeature("RADIUS").doubleValue() * radiusRatio;
/*     */     
/* 253 */     double xp = x / this.calibration[0] + 0.5D;
/* 254 */     double yp = y / this.calibration[1] + 0.5D;
/*     */ 
/*     */ 
/*     */     
/* 258 */     double xs = (xp - xcorner) * magnification;
/* 259 */     double ys = (yp - ycorner) * magnification;
/*     */     
/* 261 */     if (dz2 >= radius * radius) {
/*     */       
/* 263 */       g2d.fillOval((int)Math.round(xs - 2.0D * magnification), (int)Math.round(ys - 2.0D * magnification), (int)Math.round(4.0D * magnification), (int)Math.round(4.0D * magnification));
/*     */       
/*     */       return;
/*     */     } 
/* 267 */     SpotRoi roi = spot.getRoi();
/* 268 */     if (!this.displaySettings.isSpotDisplayedAsRoi() || roi == null || roi.x.length < 2) {
/*     */       
/* 270 */       double apparentRadius = Math.sqrt(radius * radius - dz2) / this.calibration[0] * magnification;
/* 271 */       int textPos = (int)apparentRadius;
/* 272 */       if (this.displaySettings.isSpotShowName())
/* 273 */         drawSpotName(g2d, spot, xs, ys, textPos); 
/* 274 */       if (filled) {
/* 275 */         g2d.fillOval(
/* 276 */             (int)Math.round(xs - apparentRadius), 
/* 277 */             (int)Math.round(ys - apparentRadius), 
/* 278 */             (int)Math.round(2.0D * apparentRadius), 
/* 279 */             (int)Math.round(2.0D * apparentRadius));
/*     */       } else {
/* 281 */         g2d.drawOval(
/* 282 */             (int)Math.round(xs - apparentRadius), 
/* 283 */             (int)Math.round(ys - apparentRadius), 
/* 284 */             (int)Math.round(2.0D * apparentRadius), 
/* 285 */             (int)Math.round(2.0D * apparentRadius));
/*     */       } 
/*     */     } else {
/*     */       
/* 289 */       double[] polygonX = roi.toPolygonX(this.calibration[0], xcorner - 0.5D, x, magnification);
/* 290 */       double[] polygonY = roi.toPolygonY(this.calibration[1], ycorner - 0.5D, y, magnification);
/*     */       
/* 292 */       Path2D polygon = new Path2D.Double();
/* 293 */       polygon.moveTo(polygonX[0], polygonY[0]);
/* 294 */       for (int i = 1; i < polygonX.length; i++)
/* 295 */         polygon.lineTo(polygonX[i], polygonY[i]); 
/* 296 */       polygon.closePath();
/* 297 */       int textPos = (int)(Arrays.stream(polygonX).max().getAsDouble() - xs);
/*     */       
/* 299 */       if (filled) {
/*     */         
/* 301 */         if (this.displaySettings.isSpotShowName())
/* 302 */           drawSpotName(g2d, spot, xs, ys, textPos); 
/* 303 */         g2d.fill(polygon);
/* 304 */         g2d.setColor(Color.BLACK);
/* 305 */         g2d.draw(polygon);
/*     */       }
/*     */       else {
/*     */         
/* 309 */         if (this.displaySettings.isSpotShowName())
/* 310 */           drawSpotName(g2d, spot, xs, ys, textPos); 
/* 311 */         g2d.draw(polygon);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private final void drawSpotName(Graphics2D g2d, Spot spot, double xs, double ys, int textPos) {
/* 318 */     String str = spot.toString();
/* 319 */     int xindent = this.fm.stringWidth(str);
/* 320 */     int xtext = (int)(xs + textPos + 5.0D);
/* 321 */     if (xtext + xindent > this.imp.getWindow().getWidth()) {
/* 322 */       xtext = (int)(xs - textPos - 5.0D - xindent);
/*     */     }
/* 324 */     int yindent = this.fm.getAscent() / 2;
/* 325 */     int ytext = (int)ys + yindent;
/* 326 */     g2d.drawString(spot.toString(), xtext, ytext);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/visualization/hyperstack/SpotOverlay.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */