/*    */ package fiji.plugin.trackmate.visualization;
/*    */ 
/*    */ import fiji.plugin.trackmate.Model;
/*    */ import java.awt.Color;
/*    */ import org.jgrapht.graph.DefaultWeightedEdge;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ManualEdgeColorGenerator
/*    */   implements TrackColorGenerator
/*    */ {
/*    */   private final Model model;
/*    */   private final Color missingValueColor;
/*    */   
/*    */   public ManualEdgeColorGenerator(Model model, Color missingValueColor) {
/* 40 */     this.model = model;
/* 41 */     this.missingValueColor = missingValueColor;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Color color(DefaultWeightedEdge edge) {
/* 47 */     Double val = this.model.getFeatureModel().getEdgeFeature(edge, "MANUAL_EGE_COLOR");
/* 48 */     if (null == val)
/* 49 */       return this.missingValueColor; 
/* 50 */     return new Color(val.intValue());
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/visualization/ManualEdgeColorGenerator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */