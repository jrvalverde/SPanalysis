/*    */ package fiji.plugin.trackmate.tracking.sparselap.costmatrix;
/*    */ 
/*    */ import fiji.plugin.trackmate.Spot;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collections;
/*    */ import java.util.Comparator;
/*    */ import java.util.List;
/*    */ import java.util.Set;
/*    */ import org.jgrapht.Graph;
/*    */ import org.jgrapht.alg.connectivity.ConnectivityInspector;
/*    */ import org.jgrapht.graph.DefaultWeightedEdge;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GraphSegmentSplitter
/*    */ {
/*    */   private final List<Spot> segmentStarts;
/*    */   private final List<Spot> segmentEnds;
/*    */   private final List<List<Spot>> segmentMiddles;
/*    */   
/*    */   public GraphSegmentSplitter(Graph<Spot, DefaultWeightedEdge> graph, boolean findMiddlePoints) {
/* 45 */     ConnectivityInspector<Spot, DefaultWeightedEdge> connectivity = new ConnectivityInspector(graph);
/* 46 */     List<Set<Spot>> connectedSets = connectivity.connectedSets();
/* 47 */     Comparator<Spot> framecomparator = Spot.frameComparator;
/*    */     
/* 49 */     this.segmentStarts = new ArrayList<>(connectedSets.size());
/* 50 */     this.segmentEnds = new ArrayList<>(connectedSets.size());
/* 51 */     if (findMiddlePoints) {
/*    */       
/* 53 */       this.segmentMiddles = new ArrayList<>(connectedSets.size());
/*    */     }
/*    */     else {
/*    */       
/* 57 */       this.segmentMiddles = Collections.emptyList();
/*    */     } 
/*    */     
/* 60 */     for (Set<Spot> set : connectedSets) {
/*    */       
/* 62 */       if (set.size() < 2) {
/*    */         continue;
/*    */       }
/*    */ 
/*    */       
/* 67 */       List<Spot> list = new ArrayList<>(set);
/* 68 */       Collections.sort(list, framecomparator);
/*    */       
/* 70 */       this.segmentEnds.add(list.remove(list.size() - 1));
/* 71 */       this.segmentStarts.add(list.remove(0));
/* 72 */       if (findMiddlePoints)
/*    */       {
/* 74 */         this.segmentMiddles.add(list);
/*    */       }
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public List<Spot> getSegmentEnds() {
/* 81 */     return this.segmentEnds;
/*    */   }
/*    */ 
/*    */   
/*    */   public List<List<Spot>> getSegmentMiddles() {
/* 86 */     return this.segmentMiddles;
/*    */   }
/*    */ 
/*    */   
/*    */   public List<Spot> getSegmentStarts() {
/* 91 */     return this.segmentStarts;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/tracking/sparselap/costmatrix/GraphSegmentSplitter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */