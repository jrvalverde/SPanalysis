/*     */ package fiji.plugin.trackmate.gui.wizard.descriptors;
/*     */ 
/*     */ import fiji.plugin.trackmate.Logger;
/*     */ import fiji.plugin.trackmate.Model;
/*     */ import fiji.plugin.trackmate.Settings;
/*     */ import fiji.plugin.trackmate.TrackMate;
/*     */ import fiji.plugin.trackmate.detection.DetectionUtils;
/*     */ import fiji.plugin.trackmate.features.FeatureFilter;
/*     */ import fiji.plugin.trackmate.features.spot.SpotMorphologyAnalyzerFactory;
/*     */ import fiji.plugin.trackmate.gui.components.FeatureDisplaySelector;
/*     */ import fiji.plugin.trackmate.gui.components.FilterGuiPanel;
/*     */ import fiji.plugin.trackmate.gui.displaysettings.DisplaySettings;
/*     */ import fiji.plugin.trackmate.gui.wizard.WizardPanelDescriptor;
/*     */ import fiji.plugin.trackmate.io.SettingsPersistence;
/*     */ import fiji.plugin.trackmate.providers.SpotMorphologyAnalyzerProvider;
/*     */ import fiji.plugin.trackmate.util.EverythingDisablerAndReenabler;
/*     */ import java.awt.Component;
/*     */ import java.awt.Container;
/*     */ import java.util.List;
/*     */ import java.util.stream.Collectors;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.event.ChangeEvent;
/*     */ import org.scijava.Cancelable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SpotFilterDescriptor
/*     */   extends WizardPanelDescriptor
/*     */ {
/*     */   private static final String KEY = "SpotFilter";
/*     */   private final TrackMate trackmate;
/*     */   
/*     */   public SpotFilterDescriptor(TrackMate trackmate, List<FeatureFilter> filters, FeatureDisplaySelector featureSelector) {
/*  60 */     super("SpotFilter");
/*  61 */     this.trackmate = trackmate;
/*     */ 
/*     */     
/*  64 */     FilterGuiPanel component = new FilterGuiPanel(trackmate.getModel(), trackmate.getSettings(), DisplaySettings.TrackMateObject.SPOTS, filters, "QUALITY", featureSelector);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  70 */     component.addChangeListener(e -> filterSpots());
/*  71 */     this.targetPanel = (Component)component;
/*     */   }
/*     */ 
/*     */   
/*     */   private void filterSpots() {
/*  76 */     FilterGuiPanel component = (FilterGuiPanel)this.targetPanel;
/*  77 */     this.trackmate.getSettings().setSpotFilters(component.getFeatureFilters());
/*  78 */     this.trackmate.execSpotFiltering(false);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Runnable getForwardRunnable() {
/*  84 */     return new Runnable()
/*     */       {
/*     */         
/*     */         public void run()
/*     */         {
/*  89 */           EverythingDisablerAndReenabler disabler = new EverythingDisablerAndReenabler((Container)SpotFilterDescriptor.this.targetPanel, new Class[] { JLabel.class });
/*  90 */           disabler.disable();
/*     */ 
/*     */           
/*     */           try {
/*  94 */             Model model = SpotFilterDescriptor.this.trackmate.getModel();
/*  95 */             Logger logger = model.getLogger();
/*     */             
/*  97 */             String str = "Initial thresholding with a quality threshold above " + String.format("%.1f", new Object[] { (SpotFilterDescriptor.access$100(this.this$0).getSettings()).initialSpotFilterValue }) + " ...\n";
/*     */             
/*  99 */             logger.log(str, Logger.BLUE_COLOR);
/* 100 */             int ntotal = model.getSpots().getNSpots(false);
/* 101 */             SpotFilterDescriptor.this.trackmate.execInitialSpotFiltering();
/* 102 */             int nselected = model.getSpots().getNSpots(false);
/* 103 */             logger.log(String.format("Retained %d spots out of %d.\n", new Object[] { Integer.valueOf(nselected), Integer.valueOf(ntotal) }));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 109 */             if ((SpotFilterDescriptor.this.trackmate.getSettings()).detectorFactory != null && 
/* 110 */               (SpotFilterDescriptor.this.trackmate.getSettings()).detectorFactory.has2Dsegmentation() && 
/* 111 */               DetectionUtils.is2D((SpotFilterDescriptor.this.trackmate.getSettings()).imp)) {
/*     */               
/* 113 */               logger.log("\nAdding morphology analyzers...\n", Logger.BLUE_COLOR);
/* 114 */               Settings settings = SpotFilterDescriptor.this.trackmate.getSettings();
/* 115 */               SpotMorphologyAnalyzerProvider spotMorphologyAnalyzerProvider = new SpotMorphologyAnalyzerProvider(settings.imp.getNChannels());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */               
/* 121 */               List<SpotMorphologyAnalyzerFactory> factories = (List<SpotMorphologyAnalyzerFactory>)spotMorphologyAnalyzerProvider.getKeys().stream().map(key -> spotMorphologyAnalyzerProvider.getFactory(key)).collect(Collectors.toList());
/* 122 */               factories.forEach(settings::addSpotAnalyzerFactory);
/* 123 */               StringBuilder strb = new StringBuilder();
/* 124 */               Settings.prettyPrintFeatureAnalyzer(factories, strb);
/* 125 */               logger.log(strb.toString());
/*     */             } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 132 */             FilterGuiPanel panel = (FilterGuiPanel)SpotFilterDescriptor.this.targetPanel;
/* 133 */             panel.showProgressBar(true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 139 */             logger.log("\nCalculating spot features...\n", Logger.BLUE_COLOR);
/*     */             
/* 141 */             long start = System.currentTimeMillis();
/*     */             
/* 143 */             Logger oldLogger = SpotFilterDescriptor.this.trackmate.getModel().getLogger();
/* 144 */             SpotFilterDescriptor.this.trackmate.getModel().setLogger(panel.getLogger());
/* 145 */             SpotFilterDescriptor.this.trackmate.computeSpotFeatures(true);
/* 146 */             long end = System.currentTimeMillis();
/* 147 */             SpotFilterDescriptor.this.trackmate.getModel().setLogger(oldLogger);
/* 148 */             if (SpotFilterDescriptor.this.trackmate.isCanceled())
/* 149 */               logger.log("Spot feature calculation canceled.\nSome spots will have missing feature values.\n"); 
/* 150 */             logger.log(String.format("Calculating features done in %.1f s.\n", new Object[] { Float.valueOf((float)(end - start) / 1000.0F) }));
/* 151 */             panel.showProgressBar(false);
/*     */ 
/*     */             
/* 154 */             panel.refreshValues();
/* 155 */             SpotFilterDescriptor.this.filterSpots();
/*     */           }
/*     */           finally {
/*     */             
/* 159 */             disabler.reenable();
/*     */           } 
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void displayingPanel() {
/* 168 */     FilterGuiPanel component = (FilterGuiPanel)this.targetPanel;
/* 169 */     this.trackmate.getSettings().setSpotFilters(component.getFeatureFilters());
/* 170 */     this.trackmate.execSpotFiltering(false);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void aboutToHidePanel() {
/* 176 */     Logger logger = this.trackmate.getModel().getLogger();
/* 177 */     logger.log("\nPerforming spot filtering on the following features:\n", Logger.BLUE_COLOR);
/* 178 */     Model model = this.trackmate.getModel();
/* 179 */     FilterGuiPanel component = (FilterGuiPanel)this.targetPanel;
/* 180 */     List<FeatureFilter> featureFilters = component.getFeatureFilters();
/* 181 */     this.trackmate.getSettings().setSpotFilters(featureFilters);
/* 182 */     this.trackmate.execSpotFiltering(false);
/*     */     
/* 184 */     int ntotal = model.getSpots().getNSpots(false);
/* 185 */     if (featureFilters == null || featureFilters.isEmpty()) {
/*     */       
/* 187 */       logger.log("No feature threshold set, kept the " + ntotal + " spots.\n");
/*     */     }
/*     */     else {
/*     */       
/* 191 */       for (FeatureFilter ft : featureFilters) {
/*     */         
/* 193 */         String str = "  - on " + (String)this.trackmate.getModel().getFeatureModel().getSpotFeatureNames().get(ft.feature);
/* 194 */         if (ft.isAbove) {
/* 195 */           str = str + " above ";
/*     */         } else {
/* 197 */           str = str + " below ";
/* 198 */         }  str = str + String.format("%.1f", new Object[] { Double.valueOf(ft.value) });
/* 199 */         str = str + '\n';
/* 200 */         logger.log(str);
/*     */       } 
/* 202 */       int nselected = model.getSpots().getNSpots(true);
/* 203 */       logger.log("Kept " + nselected + " spots out of " + ntotal + ".\n");
/*     */     } 
/*     */ 
/*     */     
/* 207 */     SettingsPersistence.saveLastUsedSettings(this.trackmate.getSettings(), logger);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Cancelable getCancelable() {
/* 213 */     return (Cancelable)this.trackmate;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/gui/wizard/descriptors/SpotFilterDescriptor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */