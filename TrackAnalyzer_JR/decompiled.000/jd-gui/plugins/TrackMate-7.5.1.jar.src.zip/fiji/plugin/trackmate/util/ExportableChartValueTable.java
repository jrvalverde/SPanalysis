/*     */ package fiji.plugin.trackmate.util;
/*     */ 
/*     */ import fiji.plugin.trackmate.features.ModelDataset;
/*     */ import fiji.plugin.trackmate.gui.Icons;
/*     */ import fiji.plugin.trackmate.visualization.FeatureColorGenerator;
/*     */ import fiji.plugin.trackmate.visualization.table.TablePanel;
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.Color;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.function.BiConsumer;
/*     */ import java.util.function.BiFunction;
/*     */ import java.util.function.Function;
/*     */ import java.util.function.Supplier;
/*     */ import javax.swing.Box;
/*     */ import javax.swing.BoxLayout;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JFrame;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JToggleButton;
/*     */ import javax.swing.filechooser.FileNameExtensionFilter;
/*     */ import org.jfree.chart.renderer.xy.XYItemRenderer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ExportableChartValueTable
/*     */   extends JFrame
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  62 */   public static String selectedFile = System.getProperty("user.home") + File.separator + "export.csv";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final TablePanel<ModelDataset.DataItem> table;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ExportableChartValueTable(ModelDataset dataset, String xFeature, String xFeatureName, String xUnits, String tableTitle, String yUnits) {
/*  74 */     super(tableTitle);
/*  75 */     setName(tableTitle);
/*  76 */     setIconImage(Icons.PLOT_ICON.getImage());
/*  77 */     selectedFile = (new File((new File(selectedFile)).getParent(), tableTitle.replaceAll("\\.+$", "") + ".csv")).getAbsolutePath();
/*     */     
/*  79 */     JPanel mainPanel = new JPanel();
/*  80 */     mainPanel.setLayout(new BorderLayout());
/*     */ 
/*     */     
/*  83 */     this.table = createDatasetTable(dataset, xFeature, xFeatureName, xUnits, yUnits);
/*  84 */     mainPanel.add(this.table.getPanel(), "Center");
/*     */ 
/*     */     
/*  87 */     JPanel toolbar = new JPanel();
/*  88 */     BoxLayout layout = new BoxLayout(toolbar, 2);
/*  89 */     toolbar.setLayout(layout);
/*  90 */     JButton exportBtn = new JButton("Export to CSV", Icons.CSV_ICON);
/*  91 */     exportBtn.addActionListener(e -> exportToCsv());
/*  92 */     toolbar.add(exportBtn);
/*  93 */     toolbar.add(Box.createHorizontalGlue());
/*     */     
/*  95 */     JToggleButton tglColoring = new JToggleButton("coloring");
/*  96 */     tglColoring.addActionListener(e -> {
/*     */           this.table.setUseColoring(tglColoring.isSelected());
/*     */           repaint();
/*     */         });
/* 100 */     toolbar.add(tglColoring);
/*     */     
/* 102 */     mainPanel.add(toolbar, "North");
/*     */     
/* 104 */     getContentPane().add(mainPanel);
/* 105 */     pack();
/*     */   }
/*     */ 
/*     */   
/*     */   public void exportToCsv() {
/* 110 */     File file = FileChooser.chooseFile(this, selectedFile, new FileNameExtensionFilter("CSV files", new String[] { "csv" }), "Export table to CSV", FileChooser.DialogType.SAVE, FileChooser.SelectionMode.FILES_ONLY);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 117 */     if (null == file) {
/*     */       return;
/*     */     }
/* 120 */     selectedFile = file.getAbsolutePath();
/* 121 */     exportToCsv(selectedFile);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void exportToCsv(String csvFile) {
/*     */     try {
/* 128 */       this.table.exportToCsv(new File(csvFile));
/*     */     }
/* 130 */     catch (IOException e) {
/*     */       
/* 132 */       System.err.println("Problem exporting to file " + csvFile + "\n" + e.getMessage());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final TablePanel<ModelDataset.DataItem> createDatasetTable(ModelDataset dataset, String xFeature, String xFeatureName, String xUnits, String yUnits) {
/* 143 */     int nSeries = dataset.getSeriesCount();
/*     */ 
/*     */     
/* 146 */     List<String> features = new ArrayList<>(nSeries + 1);
/* 147 */     Map<String, String> featureNames = new HashMap<>(nSeries + 1);
/* 148 */     Map<String, String> featureUnits = new HashMap<>(nSeries + 1);
/* 149 */     Map<String, Boolean> isInts = new HashMap<>(nSeries + 1);
/* 150 */     Map<String, String> infoTexts = new HashMap<>();
/* 151 */     features.add(xFeature);
/* 152 */     featureNames.put(xFeature, xFeatureName);
/* 153 */     featureUnits.put(xFeature, xUnits);
/* 154 */     isInts.put(xFeature, Boolean.FALSE);
/* 155 */     for (int i = 0; i < nSeries; i++) {
/*     */       
/* 157 */       String str = dataset.getSeriesKey(i).toString();
/* 158 */       features.add(str);
/* 159 */       featureNames.put(str, str);
/* 160 */       featureUnits.put(str, yUnits);
/* 161 */       isInts.put(str, Boolean.FALSE);
/*     */     } 
/*     */ 
/*     */     
/* 165 */     BiFunction<ModelDataset.DataItem, String, Double> featureFun = (row, feature) -> row.get(feature);
/*     */ 
/*     */     
/* 168 */     Function<ModelDataset.DataItem, String> labelGenerator = row -> dataset.getItemLabel(row.item);
/* 169 */     BiConsumer<ModelDataset.DataItem, String> labelSetter = (row, label) -> dataset.setItemLabel(row.item, label);
/*     */ 
/*     */     
/* 172 */     XYItemRenderer renderer = dataset.getRenderer();
/* 173 */     Supplier<FeatureColorGenerator<ModelDataset.DataItem>> coloring = () -> ();
/*     */ 
/*     */ 
/*     */     
/* 177 */     TablePanel<ModelDataset.DataItem> table = new TablePanel((Iterable)dataset, features, featureFun, featureNames, featureNames, featureUnits, isInts, infoTexts, coloring, labelGenerator, labelSetter);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 189 */     return table;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/util/ExportableChartValueTable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */