/*     */ package fiji.plugin.trackmate.gui.components;
/*     */ 
/*     */ import fiji.plugin.trackmate.Logger;
/*     */ import fiji.plugin.trackmate.SelectionModel;
/*     */ import fiji.plugin.trackmate.TrackMate;
/*     */ import fiji.plugin.trackmate.action.TrackMateAction;
/*     */ import fiji.plugin.trackmate.action.TrackMateActionFactory;
/*     */ import fiji.plugin.trackmate.gui.Fonts;
/*     */ import fiji.plugin.trackmate.gui.Icons;
/*     */ import fiji.plugin.trackmate.gui.displaysettings.DisplaySettings;
/*     */ import fiji.plugin.trackmate.providers.AbstractProvider;
/*     */ import fiji.plugin.trackmate.providers.ActionProvider;
/*     */ import java.awt.GridBagConstraints;
/*     */ import java.awt.Insets;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JFrame;
/*     */ import javax.swing.SwingUtilities;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ActionChooserPanel
/*     */   extends ModuleChooserPanel<TrackMateActionFactory>
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   
/*     */   public ActionChooserPanel(final ActionProvider actionProvider, final TrackMate trackmate, final SelectionModel selectionModel, final DisplaySettings displaySettings) {
/*  52 */     super((AbstractProvider<TrackMateActionFactory>)actionProvider, "action", "CAPTURE_OVERLAY");
/*     */     
/*  54 */     LogPanel logPanel = new LogPanel();
/*  55 */     GridBagConstraints gbcLogPanel = new GridBagConstraints();
/*  56 */     gbcLogPanel.insets = new Insets(5, 5, 5, 5);
/*  57 */     gbcLogPanel.fill = 1;
/*  58 */     gbcLogPanel.gridx = 0;
/*  59 */     gbcLogPanel.gridy = 3;
/*  60 */     add(logPanel, gbcLogPanel);
/*     */     
/*  62 */     final JButton executeButton = new JButton("Execute", Icons.EXECUTE_ICON);
/*  63 */     executeButton.setFont(Fonts.FONT);
/*  64 */     GridBagConstraints gbcExecBtn = new GridBagConstraints();
/*  65 */     gbcExecBtn.insets = new Insets(5, 5, 5, 5);
/*  66 */     gbcExecBtn.fill = 0;
/*  67 */     gbcExecBtn.anchor = 13;
/*  68 */     gbcExecBtn.gridx = 0;
/*  69 */     gbcExecBtn.gridy = 4;
/*  70 */     add(executeButton, gbcExecBtn);
/*     */     
/*  72 */     final Logger logger = logPanel.getLogger();
/*  73 */     executeButton.addActionListener(new ActionListener()
/*     */         {
/*     */           
/*     */           public void actionPerformed(ActionEvent e)
/*     */           {
/*  78 */             (new Thread("TrackMate action thread")
/*     */               {
/*     */ 
/*     */                 
/*     */                 public void run()
/*     */                 {
/*     */                   try {
/*  85 */                     executeButton.setEnabled(false);
/*  86 */                     String actionKey = ActionChooserPanel.this.getSelectedModuleKey();
/*  87 */                     TrackMateAction action = ((TrackMateActionFactory)actionProvider.getFactory(actionKey)).create();
/*  88 */                     if (null == action)
/*     */                     {
/*  90 */                       logger.error("Unknown action: " + actionKey + ".\n");
/*     */                     }
/*     */                     else
/*     */                     {
/*  94 */                       action.setLogger(logger);
/*  95 */                       action.execute(trackmate, selectionModel, displaySettings, 
/*     */ 
/*     */ 
/*     */                           
/*  99 */                           (JFrame)SwingUtilities.getWindowAncestor(ActionChooserPanel.this));
/*     */                     }
/*     */                   
/*     */                   } finally {
/*     */                     
/* 104 */                     executeButton.setEnabled(true);
/*     */                   } 
/*     */                 }
/* 107 */               }).start();
/*     */           }
/*     */         });
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/gui/components/ActionChooserPanel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */