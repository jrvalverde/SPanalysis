/*    */ package fiji.plugin.trackmate.features.edges;
/*    */ 
/*    */ import fiji.plugin.trackmate.Dimension;
/*    */ import fiji.plugin.trackmate.FeatureModel;
/*    */ import fiji.plugin.trackmate.Model;
/*    */ import fiji.plugin.trackmate.Spot;
/*    */ import java.util.ArrayList;
/*    */ import java.util.HashMap;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import org.jgrapht.graph.DefaultWeightedEdge;
/*    */ import org.scijava.plugin.Plugin;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Plugin(type = EdgeAnalyzer.class)
/*    */ public class EdgeSpeedAnalyzer
/*    */   extends AbstractEdgeAnalyzer
/*    */ {
/*    */   public static final String KEY = "Edge speed";
/*    */   public static final String SPEED = "SPEED";
/*    */   public static final String DISPLACEMENT = "DISPLACEMENT";
/* 45 */   public static final List<String> FEATURES = new ArrayList<>(2);
/* 46 */   public static final Map<String, String> FEATURE_NAMES = new HashMap<>(2);
/* 47 */   public static final Map<String, String> FEATURE_SHORT_NAMES = new HashMap<>(2);
/* 48 */   public static final Map<String, Dimension> FEATURE_DIMENSIONS = new HashMap<>(2);
/* 49 */   public static final Map<String, Boolean> IS_INT = new HashMap<>(2);
/*    */ 
/*    */   
/*    */   static {
/* 53 */     FEATURES.add("SPEED");
/* 54 */     FEATURES.add("DISPLACEMENT");
/*    */     
/* 56 */     FEATURE_NAMES.put("SPEED", "Speed");
/* 57 */     FEATURE_NAMES.put("DISPLACEMENT", "Displacement");
/*    */     
/* 59 */     FEATURE_SHORT_NAMES.put("SPEED", "Speed");
/* 60 */     FEATURE_SHORT_NAMES.put("DISPLACEMENT", "Disp.");
/*    */     
/* 62 */     FEATURE_DIMENSIONS.put("SPEED", Dimension.VELOCITY);
/* 63 */     FEATURE_DIMENSIONS.put("DISPLACEMENT", Dimension.LENGTH);
/*    */     
/* 65 */     IS_INT.put("SPEED", Boolean.FALSE);
/* 66 */     IS_INT.put("DISPLACEMENT", Boolean.FALSE);
/*    */   }
/*    */ 
/*    */   
/*    */   public EdgeSpeedAnalyzer() {
/* 71 */     super("Edge speed", "Edge speed", FEATURES, FEATURE_NAMES, FEATURE_SHORT_NAMES, FEATURE_DIMENSIONS, IS_INT);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected void analyze(DefaultWeightedEdge edge, Model model) {
/* 77 */     FeatureModel featureModel = model.getFeatureModel();
/* 78 */     Spot source = model.getTrackModel().getEdgeSource(edge);
/* 79 */     Spot target = model.getTrackModel().getEdgeTarget(edge);
/*    */     
/* 81 */     double dx = target.diffTo(source, "POSITION_X");
/* 82 */     double dy = target.diffTo(source, "POSITION_Y");
/* 83 */     double dz = target.diffTo(source, "POSITION_Z");
/* 84 */     double dt = target.diffTo(source, "POSITION_T");
/* 85 */     double D = Math.sqrt(dx * dx + dy * dy + dz * dz);
/* 86 */     double S = D / Math.abs(dt);
/*    */     
/* 88 */     featureModel.putEdgeFeature(edge, "SPEED", Double.valueOf(S));
/* 89 */     featureModel.putEdgeFeature(edge, "DISPLACEMENT", Double.valueOf(D));
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/features/edges/EdgeSpeedAnalyzer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */