/*    */ package fiji.plugin.trackmate.util;
/*    */ 
/*    */ import java.awt.Component;
/*    */ import java.awt.Graphics;
/*    */ import java.awt.image.BufferedImage;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ImageHelper
/*    */ {
/*    */   public static final int SIDE_BY_SIDE = 0;
/*    */   public static final int BOTTOM_TO_TOP = 1;
/*    */   
/*    */   public static BufferedImage captureComponent(Component component) {
/* 46 */     BufferedImage image = new BufferedImage(component.getWidth(), component.getHeight(), 1);
/*    */     
/* 48 */     component.paint(image.getGraphics());
/* 49 */     return image;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static BufferedImage combineImages(BufferedImage img1, BufferedImage img2, int renderHint) {
/* 73 */     switch (renderHint) {
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */       
/*    */       default:
/* 83 */         combined = new BufferedImage(img1.getWidth() + img2.getWidth(), Math.max(img1.getHeight(), img2.getHeight()), 1);
/* 84 */         g = combined.getGraphics();
/* 85 */         g.drawImage(img1, 0, 0, null);
/* 86 */         g.drawImage(img2, img1.getWidth(), 0, null);
/* 87 */         return combined;
/*    */       
/*    */       case 1:
/*    */         break;
/*    */     } 
/*    */     
/* 93 */     BufferedImage combined = new BufferedImage(Math.max(img1.getWidth(), img2.getWidth()), img1.getHeight() + img2.getHeight(), 1);
/*    */     
/* 95 */     Graphics g = combined.getGraphics();
/* 96 */     g.drawImage(img1, 0, 0, null);
/* 97 */     g.drawImage(img2, 0, img1.getHeight(), null);
/* 98 */     return combined;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/util/ImageHelper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */