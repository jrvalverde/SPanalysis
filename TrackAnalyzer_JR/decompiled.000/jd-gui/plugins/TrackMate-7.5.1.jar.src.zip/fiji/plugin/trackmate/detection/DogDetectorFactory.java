/*     */ package fiji.plugin.trackmate.detection;
/*     */ 
/*     */ import fiji.plugin.trackmate.Model;
/*     */ import fiji.plugin.trackmate.Settings;
/*     */ import fiji.plugin.trackmate.gui.components.ConfigurationPanel;
/*     */ import fiji.plugin.trackmate.gui.components.detector.DogDetectorConfigurationPanel;
/*     */ import fiji.plugin.trackmate.util.TMUtils;
/*     */ import net.imagej.ImgPlusMetadata;
/*     */ import net.imglib2.Interval;
/*     */ import net.imglib2.RandomAccessible;
/*     */ import net.imglib2.type.NativeType;
/*     */ import net.imglib2.type.numeric.RealType;
/*     */ import org.scijava.plugin.Plugin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Plugin(type = SpotDetectorFactory.class)
/*     */ public class DogDetectorFactory<T extends RealType<T> & NativeType<T>>
/*     */   extends LogDetectorFactory<T>
/*     */ {
/*     */   public static final String THIS_DETECTOR_KEY = "DOG_DETECTOR";
/*     */   public static final String THIS_NAME = "DoG detector";
/*     */   public static final String THIS_INFO_TEXT = "<html>This segmenter is based on an approximation of the LoG operator <br> by differences of gaussian (DoG). Computations are made in direct space. <br>It is the quickest for small spot sizes (< ~5 pixels). <p> Spots found too close are suppressed. This segmenter can do sub-pixel <br>localization of spots using a quadratic fitting scheme. It is based on <br>the scale-space framework made by Stephan Preibisch for ImgLib. </html>";
/*     */   
/*     */   public SpotDetector<T> getDetector(Interval interval, int frame) {
/*  65 */     double radius = ((Double)this.settings.get("RADIUS")).doubleValue();
/*  66 */     double threshold = ((Double)this.settings.get("THRESHOLD")).doubleValue();
/*  67 */     boolean doMedian = ((Boolean)this.settings.get("DO_MEDIAN_FILTERING")).booleanValue();
/*  68 */     boolean doSubpixel = ((Boolean)this.settings.get("DO_SUBPIXEL_LOCALIZATION")).booleanValue();
/*  69 */     double[] calibration = TMUtils.getSpatialCalibration((ImgPlusMetadata)this.img);
/*     */     
/*  71 */     RandomAccessible<T> imFrame = prepareFrameImg(frame);
/*  72 */     DogDetector<T> detector = new DogDetector<>(imFrame, interval, calibration, radius, threshold, doSubpixel, doMedian);
/*  73 */     detector.setNumThreads(1);
/*  74 */     return detector;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getKey() {
/*  80 */     return "DOG_DETECTOR";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/*  86 */     return "DoG detector";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getInfoText() {
/*  92 */     return "<html>This segmenter is based on an approximation of the LoG operator <br> by differences of gaussian (DoG). Computations are made in direct space. <br>It is the quickest for small spot sizes (< ~5 pixels). <p> Spots found too close are suppressed. This segmenter can do sub-pixel <br>localization of spots using a quadratic fitting scheme. It is based on <br>the scale-space framework made by Stephan Preibisch for ImgLib. </html>";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ConfigurationPanel getDetectorConfigurationPanel(Settings lSettings, Model model) {
/*  98 */     return (ConfigurationPanel)new DogDetectorConfigurationPanel(lSettings, model, "<html>This segmenter is based on an approximation of the LoG operator <br> by differences of gaussian (DoG). Computations are made in direct space. <br>It is the quickest for small spot sizes (< ~5 pixels). <p> Spots found too close are suppressed. This segmenter can do sub-pixel <br>localization of spots using a quadratic fitting scheme. It is based on <br>the scale-space framework made by Stephan Preibisch for ImgLib. </html>", "DoG detector");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public DogDetectorFactory<T> copy() {
/* 104 */     return new DogDetectorFactory();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/detection/DogDetectorFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */