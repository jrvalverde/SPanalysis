/*     */ package fiji.plugin.trackmate.gui.components.detector;
/*     */ 
/*     */ import fiji.plugin.trackmate.Logger;
/*     */ import fiji.plugin.trackmate.Model;
/*     */ import fiji.plugin.trackmate.Settings;
/*     */ import fiji.plugin.trackmate.detection.DetectionUtils;
/*     */ import fiji.plugin.trackmate.detection.LogDetectorFactory;
/*     */ import fiji.plugin.trackmate.detection.SpotDetectorFactory;
/*     */ import fiji.plugin.trackmate.detection.SpotDetectorFactoryBase;
/*     */ import fiji.plugin.trackmate.gui.Fonts;
/*     */ import fiji.plugin.trackmate.gui.GuiUtils;
/*     */ import fiji.plugin.trackmate.gui.Icons;
/*     */ import fiji.plugin.trackmate.gui.components.ConfigurationPanel;
/*     */ import fiji.plugin.trackmate.util.JLabelLogger;
/*     */ import ij.ImagePlus;
/*     */ import ij.measure.Calibration;
/*     */ import java.awt.Component;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.GridBagConstraints;
/*     */ import java.awt.GridBagLayout;
/*     */ import java.awt.Insets;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.text.DecimalFormat;
/*     */ import java.text.NumberFormat;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JCheckBox;
/*     */ import javax.swing.JFormattedTextField;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JSlider;
/*     */ import javax.swing.event.ChangeEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LogDetectorConfigurationPanel
/*     */   extends ConfigurationPanel
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private static final String TOOLTIP_PREVIEW = "<html>Preview the current settings on the current frame.<p>Advice: change the settings until you get at least <br><b>all</b> the spots you want, and do not mind the <br>spurious spots too much. You will get a chance to <br>get rid of them later.</html>";
/*  81 */   private static final NumberFormat FORMAT = new DecimalFormat("#.###");
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected JFormattedTextField ftfQualityThreshold;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected JCheckBox jCheckBoxMedianFilter;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected JFormattedTextField ftfDiameter;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected JCheckBox jCheckSubPixel;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected JSlider sliderChannel;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final ImagePlus imp;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LogDetectorConfigurationPanel(Settings settings, Model model, String infoText, String detectorName) {
/* 118 */     this.imp = settings.imp;
/*     */     
/* 120 */     setPreferredSize(new Dimension(300, 461));
/* 121 */     GridBagLayout gridBagLayout = new GridBagLayout();
/* 122 */     gridBagLayout.columnWeights = new double[] { 0.0D, 0.0D, 1.0D, 0.0D };
/* 123 */     gridBagLayout.rowWeights = new double[] { 0.0D, 0.0D, 1.0D, 0.0D, 0.0D, 0.0D, 0.0D, 0.0D, 0.0D, 1.0D, 0.0D, 0.0D };
/* 124 */     setLayout(gridBagLayout);
/*     */     
/* 126 */     JLabel jLabelPreTitle = new JLabel();
/* 127 */     GridBagConstraints gbcLabelPreTitle = new GridBagConstraints();
/* 128 */     gbcLabelPreTitle.anchor = 11;
/* 129 */     gbcLabelPreTitle.fill = 2;
/* 130 */     gbcLabelPreTitle.insets = new Insets(5, 5, 5, 5);
/* 131 */     gbcLabelPreTitle.gridwidth = 4;
/* 132 */     gbcLabelPreTitle.gridx = 0;
/* 133 */     gbcLabelPreTitle.gridy = 0;
/* 134 */     add(jLabelPreTitle, gbcLabelPreTitle);
/* 135 */     jLabelPreTitle.setText("Settings for detector:");
/* 136 */     jLabelPreTitle.setFont(Fonts.FONT);
/*     */     
/* 138 */     JLabel jLabelSegmenterName = new JLabel();
/* 139 */     GridBagConstraints gbcLabelSegmenterName = new GridBagConstraints();
/* 140 */     gbcLabelSegmenterName.anchor = 11;
/* 141 */     gbcLabelSegmenterName.fill = 2;
/* 142 */     gbcLabelSegmenterName.insets = new Insets(5, 5, 5, 5);
/* 143 */     gbcLabelSegmenterName.gridwidth = 4;
/* 144 */     gbcLabelSegmenterName.gridx = 0;
/* 145 */     gbcLabelSegmenterName.gridy = 1;
/* 146 */     add(jLabelSegmenterName, gbcLabelSegmenterName);
/* 147 */     jLabelSegmenterName.setFont(Fonts.BIG_FONT);
/* 148 */     jLabelSegmenterName.setText(detectorName);
/*     */     
/* 150 */     JLabel jLabelHelpText = new JLabel();
/* 151 */     GridBagConstraints gbcLabelHelpText = new GridBagConstraints();
/* 152 */     gbcLabelHelpText.fill = 1;
/* 153 */     gbcLabelHelpText.insets = new Insets(5, 5, 5, 5);
/* 154 */     gbcLabelHelpText.gridwidth = 4;
/* 155 */     gbcLabelHelpText.gridx = 0;
/* 156 */     gbcLabelHelpText.gridy = 2;
/* 157 */     add(jLabelHelpText, gbcLabelHelpText);
/* 158 */     jLabelHelpText.setFont(Fonts.FONT.deriveFont(2));
/* 159 */     jLabelHelpText.setText(infoText.replace("<br>", "").replace("<p>", "<p align=\"justify\">").replace("<html>", "<html><p align=\"justify\">"));
/*     */     
/* 161 */     JLabel lblSegmentInChannel = new JLabel("Detect in channel:");
/* 162 */     lblSegmentInChannel.setFont(Fonts.SMALL_FONT);
/* 163 */     GridBagConstraints gbcSegmentInChannel = new GridBagConstraints();
/* 164 */     gbcSegmentInChannel.gridwidth = 2;
/* 165 */     gbcSegmentInChannel.anchor = 13;
/* 166 */     gbcSegmentInChannel.insets = new Insets(5, 5, 5, 5);
/* 167 */     gbcSegmentInChannel.gridx = 0;
/* 168 */     gbcSegmentInChannel.gridy = 4;
/* 169 */     add(lblSegmentInChannel, gbcSegmentInChannel);
/*     */     
/* 171 */     this.sliderChannel = new JSlider();
/* 172 */     GridBagConstraints gbc_sliderChannel = new GridBagConstraints();
/* 173 */     gbc_sliderChannel.fill = 1;
/* 174 */     gbc_sliderChannel.insets = new Insets(5, 5, 5, 5);
/* 175 */     gbc_sliderChannel.gridx = 2;
/* 176 */     gbc_sliderChannel.gridy = 4;
/* 177 */     add(this.sliderChannel, gbc_sliderChannel);
/*     */     
/* 179 */     JLabel labelChannel = new JLabel("1");
/* 180 */     labelChannel.setHorizontalAlignment(0);
/* 181 */     labelChannel.setFont(Fonts.SMALL_FONT);
/* 182 */     GridBagConstraints gbcLabelChannel = new GridBagConstraints();
/* 183 */     gbcLabelChannel.anchor = 17;
/* 184 */     gbcLabelChannel.fill = 3;
/* 185 */     gbcLabelChannel.insets = new Insets(5, 5, 5, 5);
/* 186 */     gbcLabelChannel.gridx = 3;
/* 187 */     gbcLabelChannel.gridy = 4;
/* 188 */     add(labelChannel, gbcLabelChannel);
/*     */     
/* 190 */     JLabel jLabelEstimDiameter = new JLabel();
/* 191 */     GridBagConstraints gbc_jLabel2 = new GridBagConstraints();
/* 192 */     gbc_jLabel2.anchor = 13;
/* 193 */     gbc_jLabel2.insets = new Insets(5, 5, 5, 5);
/* 194 */     gbc_jLabel2.gridwidth = 2;
/* 195 */     gbc_jLabel2.gridx = 0;
/* 196 */     gbc_jLabel2.gridy = 5;
/* 197 */     add(jLabelEstimDiameter, gbc_jLabel2);
/* 198 */     jLabelEstimDiameter.setText("Estimated object diameter:");
/* 199 */     jLabelEstimDiameter.setFont(Fonts.SMALL_FONT);
/*     */     
/* 201 */     this.ftfDiameter = new JFormattedTextField(FORMAT);
/* 202 */     this.ftfDiameter.setHorizontalAlignment(0);
/* 203 */     this.ftfDiameter.setValue(Double.valueOf(10.0D));
/* 204 */     GridBagConstraints gbcTextFieldBlobDiameter = new GridBagConstraints();
/* 205 */     gbcTextFieldBlobDiameter.anchor = 15;
/* 206 */     gbcTextFieldBlobDiameter.fill = 2;
/* 207 */     gbcTextFieldBlobDiameter.insets = new Insets(5, 5, 5, 5);
/* 208 */     gbcTextFieldBlobDiameter.gridx = 2;
/* 209 */     gbcTextFieldBlobDiameter.gridy = 5;
/* 210 */     add(this.ftfDiameter, gbcTextFieldBlobDiameter);
/* 211 */     this.ftfDiameter.setFont(Fonts.SMALL_FONT);
/*     */     
/* 213 */     JLabel jLabelBlobDiameterUnit = new JLabel();
/* 214 */     GridBagConstraints gbcLabelBlobDiameterUnit = new GridBagConstraints();
/* 215 */     gbcLabelBlobDiameterUnit.fill = 1;
/* 216 */     gbcLabelBlobDiameterUnit.insets = new Insets(5, 5, 5, 5);
/* 217 */     gbcLabelBlobDiameterUnit.gridx = 3;
/* 218 */     gbcLabelBlobDiameterUnit.gridy = 5;
/* 219 */     add(jLabelBlobDiameterUnit, gbcLabelBlobDiameterUnit);
/* 220 */     jLabelBlobDiameterUnit.setFont(Fonts.SMALL_FONT);
/* 221 */     jLabelBlobDiameterUnit.setText(model.getSpaceUnits());
/*     */     
/* 223 */     JLabel jLabelThreshold = new JLabel();
/* 224 */     GridBagConstraints gbcLabelThreshold = new GridBagConstraints();
/* 225 */     gbcLabelThreshold.anchor = 13;
/* 226 */     gbcLabelThreshold.insets = new Insets(5, 5, 5, 5);
/* 227 */     gbcLabelThreshold.gridwidth = 2;
/* 228 */     gbcLabelThreshold.gridx = 0;
/* 229 */     gbcLabelThreshold.gridy = 6;
/* 230 */     add(jLabelThreshold, gbcLabelThreshold);
/* 231 */     jLabelThreshold.setText("Quality threshold:");
/* 232 */     jLabelThreshold.setFont(Fonts.SMALL_FONT);
/*     */     
/* 234 */     this.ftfQualityThreshold = new JFormattedTextField(FORMAT);
/* 235 */     this.ftfQualityThreshold.setHorizontalAlignment(0);
/* 236 */     this.ftfQualityThreshold.setValue(Double.valueOf(0.0D));
/* 237 */     GridBagConstraints gbcTextFieldThreshold = new GridBagConstraints();
/* 238 */     gbcTextFieldThreshold.fill = 1;
/* 239 */     gbcTextFieldThreshold.insets = new Insets(5, 5, 5, 5);
/* 240 */     gbcTextFieldThreshold.gridx = 2;
/* 241 */     gbcTextFieldThreshold.gridy = 6;
/* 242 */     add(this.ftfQualityThreshold, gbcTextFieldThreshold);
/* 243 */     this.ftfQualityThreshold.setFont(Fonts.SMALL_FONT);
/*     */     
/* 245 */     JLabel lblPreProcess = new JLabel("Pre-process with median filter:");
/* 246 */     lblPreProcess.setFont(Fonts.SMALL_FONT);
/* 247 */     GridBagConstraints gbcPreProcess = new GridBagConstraints();
/* 248 */     gbcPreProcess.gridwidth = 2;
/* 249 */     gbcPreProcess.anchor = 13;
/* 250 */     gbcPreProcess.insets = new Insets(5, 5, 5, 5);
/* 251 */     gbcPreProcess.gridx = 0;
/* 252 */     gbcPreProcess.gridy = 7;
/* 253 */     add(lblPreProcess, gbcPreProcess);
/*     */     
/* 255 */     this.jCheckBoxMedianFilter = new JCheckBox();
/* 256 */     GridBagConstraints gbcCheckBoxMedianFilter = new GridBagConstraints();
/* 257 */     gbcCheckBoxMedianFilter.anchor = 11;
/* 258 */     gbcCheckBoxMedianFilter.fill = 2;
/* 259 */     gbcCheckBoxMedianFilter.insets = new Insets(5, 5, 5, 5);
/* 260 */     gbcCheckBoxMedianFilter.gridwidth = 2;
/* 261 */     gbcCheckBoxMedianFilter.gridx = 2;
/* 262 */     gbcCheckBoxMedianFilter.gridy = 7;
/* 263 */     add(this.jCheckBoxMedianFilter, gbcCheckBoxMedianFilter);
/* 264 */     this.jCheckBoxMedianFilter.setFont(Fonts.FONT);
/*     */     
/* 266 */     JLabel lblSubPixelLoc = new JLabel("Sub-pixel localization:");
/* 267 */     lblSubPixelLoc.setFont(Fonts.SMALL_FONT);
/* 268 */     GridBagConstraints gbcSubPixelLoc = new GridBagConstraints();
/* 269 */     gbcSubPixelLoc.anchor = 13;
/* 270 */     gbcSubPixelLoc.gridwidth = 2;
/* 271 */     gbcSubPixelLoc.insets = new Insets(5, 5, 5, 5);
/* 272 */     gbcSubPixelLoc.gridx = 0;
/* 273 */     gbcSubPixelLoc.gridy = 8;
/* 274 */     add(lblSubPixelLoc, gbcSubPixelLoc);
/*     */ 
/*     */     
/* 277 */     this.jCheckSubPixel = new JCheckBox();
/* 278 */     GridBagConstraints gbcCheckSubPixel = new GridBagConstraints();
/* 279 */     gbcCheckSubPixel.anchor = 11;
/* 280 */     gbcCheckSubPixel.fill = 2;
/* 281 */     gbcCheckSubPixel.insets = new Insets(5, 5, 5, 5);
/* 282 */     gbcCheckSubPixel.gridwidth = 2;
/* 283 */     gbcCheckSubPixel.gridx = 2;
/* 284 */     gbcCheckSubPixel.gridy = 8;
/* 285 */     add(this.jCheckSubPixel, gbcCheckSubPixel);
/* 286 */     this.jCheckSubPixel.setFont(Fonts.SMALL_FONT);
/*     */     
/* 288 */     JButton btnPreview = new JButton("Preview", Icons.PREVIEW_ICON);
/* 289 */     btnPreview.setToolTipText("<html>Preview the current settings on the current frame.<p>Advice: change the settings until you get at least <br><b>all</b> the spots you want, and do not mind the <br>spurious spots too much. You will get a chance to <br>get rid of them later.</html>");
/* 290 */     GridBagConstraints gbcBtnPreview = new GridBagConstraints();
/* 291 */     gbcBtnPreview.anchor = 12;
/* 292 */     gbcBtnPreview.insets = new Insets(5, 5, 5, 5);
/* 293 */     gbcBtnPreview.gridwidth = 3;
/* 294 */     gbcBtnPreview.gridx = 1;
/* 295 */     gbcBtnPreview.gridy = 10;
/* 296 */     add(btnPreview, gbcBtnPreview);
/* 297 */     btnPreview.setFont(Fonts.SMALL_FONT);
/*     */     
/* 299 */     JLabelLogger labelLogger = new JLabelLogger();
/* 300 */     labelLogger.setText("   ");
/* 301 */     GridBagConstraints gbcLabelLogger = new GridBagConstraints();
/* 302 */     gbcLabelLogger.insets = new Insets(5, 5, 5, 5);
/* 303 */     gbcLabelLogger.fill = 1;
/* 304 */     gbcLabelLogger.gridwidth = 4;
/* 305 */     gbcLabelLogger.gridx = 0;
/* 306 */     gbcLabelLogger.gridy = 11;
/* 307 */     add((Component)labelLogger, gbcLabelLogger);
/* 308 */     Logger localLogger = labelLogger.getLogger();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 314 */     int nChannels = settings.imp.getNChannels();
/* 315 */     this.sliderChannel.setMaximum(nChannels);
/* 316 */     this.sliderChannel.setMinimum(1);
/* 317 */     this.sliderChannel.setValue(settings.imp.getChannel());
/*     */     
/* 319 */     if (nChannels <= 1) {
/*     */       
/* 321 */       labelChannel.setVisible(false);
/* 322 */       lblSegmentInChannel.setVisible(false);
/* 323 */       this.sliderChannel.setVisible(false);
/*     */     }
/*     */     else {
/*     */       
/* 327 */       labelChannel.setVisible(true);
/* 328 */       lblSegmentInChannel.setVisible(true);
/* 329 */       this.sliderChannel.setVisible(true);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 336 */     this.sliderChannel.addChangeListener(e -> labelChannel.setText("" + this.sliderChannel.getValue()));
/* 337 */     btnPreview.addActionListener(e -> DetectionUtils.preview(model, settings, (SpotDetectorFactoryBase)getDetectorFactory(), getSettings(), settings.imp.getFrame() - 1, localLogger, ()));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 345 */     GuiUtils.selectAllOnFocus(this.ftfDiameter);
/* 346 */     GuiUtils.selectAllOnFocus(this.ftfQualityThreshold);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, Object> getSettings() {
/* 356 */     HashMap<String, Object> lSettings = new HashMap<>(5);
/* 357 */     int targetChannel = this.sliderChannel.getValue();
/* 358 */     double expectedRadius = ((Number)this.ftfDiameter.getValue()).doubleValue() / 2.0D;
/* 359 */     double threshold = ((Number)this.ftfQualityThreshold.getValue()).doubleValue();
/* 360 */     boolean useMedianFilter = this.jCheckBoxMedianFilter.isSelected();
/* 361 */     boolean doSubPixelLocalization = this.jCheckSubPixel.isSelected();
/* 362 */     lSettings.put("TARGET_CHANNEL", Integer.valueOf(targetChannel));
/* 363 */     lSettings.put("RADIUS", Double.valueOf(expectedRadius));
/* 364 */     lSettings.put("THRESHOLD", Double.valueOf(threshold));
/* 365 */     lSettings.put("DO_MEDIAN_FILTERING", Boolean.valueOf(useMedianFilter));
/* 366 */     lSettings.put("DO_SUBPIXEL_LOCALIZATION", Boolean.valueOf(doSubPixelLocalization));
/* 367 */     return lSettings;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSettings(Map<String, Object> settings) {
/* 373 */     this.sliderChannel.setValue(((Integer)settings.get("TARGET_CHANNEL")).intValue());
/* 374 */     double radius = ((Double)settings.get("RADIUS")).doubleValue();
/* 375 */     if (this.imp != null) {
/*     */ 
/*     */       
/* 378 */       Calibration calibration = this.imp.getCalibration();
/*     */ 
/*     */       
/* 381 */       double maxWidth = this.imp.getWidth() * 0.5D * ((calibration == null) ? 1.0D : calibration.pixelWidth);
/* 382 */       double maxHeight = this.imp.getHeight() * 0.5D * ((calibration == null) ? 1.0D : calibration.pixelHeight);
/* 383 */       double max = (maxWidth < maxHeight) ? maxWidth : maxHeight;
/* 384 */       if (radius > max) {
/* 385 */         radius *= max * 4.0D / (this.imp.getWidth() + this.imp.getHeight());
/*     */       }
/*     */       
/* 388 */       double pw = (calibration == null) ? 1.0D : calibration.pixelWidth;
/* 389 */       radius = Math.max(radius / pw, 1.5D) * pw;
/*     */     } 
/* 391 */     this.ftfDiameter.setValue(Double.valueOf(2.0D * radius));
/* 392 */     this.jCheckBoxMedianFilter.setSelected(((Boolean)settings.get("DO_MEDIAN_FILTERING")).booleanValue());
/* 393 */     this.ftfQualityThreshold.setValue(Double.valueOf(((Number)settings.get("THRESHOLD")).doubleValue()));
/* 394 */     this.jCheckSubPixel.setSelected(((Boolean)settings.get("DO_SUBPIXEL_LOCALIZATION")).booleanValue());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected SpotDetectorFactory<?> getDetectorFactory() {
/* 408 */     return (SpotDetectorFactory<?>)new LogDetectorFactory();
/*     */   }
/*     */   
/*     */   public void clean() {}
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/gui/components/detector/LogDetectorConfigurationPanel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */