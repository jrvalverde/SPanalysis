/*     */ package fiji.plugin.trackmate.util;
/*     */ 
/*     */ import fiji.plugin.trackmate.FeatureModel;
/*     */ import fiji.plugin.trackmate.Model;
/*     */ import fiji.plugin.trackmate.SelectionModel;
/*     */ import fiji.plugin.trackmate.Spot;
/*     */ import fiji.plugin.trackmate.SpotCollection;
/*     */ import fiji.plugin.trackmate.tracking.kdtree.NearestNeighborTracker;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.jgrapht.graph.DefaultWeightedEdge;
/*     */ import org.jgrapht.graph.SimpleWeightedGraph;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ModelTools
/*     */ {
/*     */   public static void selectTrack(SelectionModel selectionModel) {
/*  63 */     selectionModel.clearEdgeSelection();
/*  64 */     selectionModel.selectTrack(selectionModel.getSpotSelection(), Collections.emptyList(), 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void selectTrackDownward(SelectionModel selectionModel) {
/*  77 */     selectionModel.clearEdgeSelection();
/*  78 */     selectionModel.selectTrack(selectionModel.getSpotSelection(), Collections.emptyList(), -1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void selectTrackUpward(SelectionModel selectionModel) {
/*  91 */     selectionModel.clearEdgeSelection();
/*  92 */     selectionModel.selectTrack(selectionModel.getSpotSelection(), Collections.emptyList(), 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void linkSpots(Model model, SelectionModel selectionModel) {
/* 110 */     SpotCollection spots = SpotCollection.fromCollection(selectionModel.getSpotSelection());
/* 111 */     Map<String, Object> settings = new HashMap<>(1);
/* 112 */     settings.put("LINKING_MAX_DISTANCE", Double.valueOf(Double.POSITIVE_INFINITY));
/* 113 */     NearestNeighborTracker tracker = new NearestNeighborTracker(spots, settings);
/* 114 */     tracker.setNumThreads(1);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 120 */     if (!tracker.checkInput() || !tracker.process()) {
/*     */       
/* 122 */       System.err.println("Problem while computing spot links: " + tracker.getErrorMessage());
/*     */       return;
/*     */     } 
/* 125 */     SimpleWeightedGraph<Spot, DefaultWeightedEdge> graph = tracker.getResult();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 131 */     model.beginUpdate();
/*     */     
/*     */     try {
/* 134 */       for (DefaultWeightedEdge edge : graph.edgeSet())
/*     */       {
/* 136 */         Spot source = (Spot)graph.getEdgeSource(edge);
/* 137 */         Spot target = (Spot)graph.getEdgeTarget(edge);
/* 138 */         model.addEdge(source, target, graph.getEdgeWeight(edge));
/*     */       }
/*     */     
/*     */     } finally {
/*     */       
/* 143 */       model.endUpdate();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final Comparator<DefaultWeightedEdge> featureEdgeComparator(final String feature, final FeatureModel fm) {
/* 160 */     Comparator<DefaultWeightedEdge> comparator = new Comparator<DefaultWeightedEdge>()
/*     */       {
/*     */         
/*     */         public int compare(DefaultWeightedEdge e1, DefaultWeightedEdge e2)
/*     */         {
/* 165 */           double t1 = fm.getEdgeFeature(e1, feature).doubleValue();
/* 166 */           double t2 = fm.getEdgeFeature(e2, feature).doubleValue();
/*     */           
/* 168 */           if (t1 < t2) return -1; 
/* 169 */           if (t1 > t2) return 1; 
/* 170 */           return 0;
/*     */         }
/*     */       };
/* 173 */     return comparator;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final Comparator<Integer> featureTrackComparator(final String feature, final FeatureModel fm) {
/* 189 */     Comparator<Integer> comparator = new Comparator<Integer>()
/*     */       {
/*     */         
/*     */         public int compare(Integer e1, Integer e2)
/*     */         {
/* 194 */           double t1 = fm.getTrackFeature(e1, feature).doubleValue();
/* 195 */           double t2 = fm.getTrackFeature(e2, feature).doubleValue();
/*     */           
/* 197 */           if (t1 < t2) return -1; 
/* 198 */           if (t1 > t2) return 1; 
/* 199 */           return 0;
/*     */         }
/*     */       };
/* 202 */     return comparator;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/util/ModelTools.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */