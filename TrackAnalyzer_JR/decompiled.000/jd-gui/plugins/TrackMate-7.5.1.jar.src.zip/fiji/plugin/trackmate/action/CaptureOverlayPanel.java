/*     */ package fiji.plugin.trackmate.action;
/*     */ 
/*     */ import java.awt.GridBagConstraints;
/*     */ import java.awt.GridBagLayout;
/*     */ import java.awt.Insets;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.FocusAdapter;
/*     */ import java.awt.event.FocusEvent;
/*     */ import java.awt.event.FocusListener;
/*     */ import java.beans.PropertyChangeEvent;
/*     */ import java.text.NumberFormat;
/*     */ import javax.swing.JCheckBox;
/*     */ import javax.swing.JFormattedTextField;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.SwingUtilities;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CaptureOverlayPanel
/*     */   extends JPanel
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private int firstFrame;
/*     */   private int lastFrame;
/*     */   private boolean hideImage;
/*     */   
/*     */   public CaptureOverlayPanel(int firstFrame, int lastFrame, boolean hideImage) {
/*  51 */     this.firstFrame = firstFrame;
/*  52 */     this.lastFrame = lastFrame;
/*  53 */     this.hideImage = hideImage;
/*     */     
/*  55 */     GridBagLayout gridBagLayout = new GridBagLayout();
/*  56 */     gridBagLayout.columnWidths = new int[] { 0, 0, 0 };
/*  57 */     gridBagLayout.rowHeights = new int[] { 0, 0, 0, 0, 0 };
/*  58 */     gridBagLayout.columnWeights = new double[] { 1.0D, 1.0D, Double.MIN_VALUE };
/*  59 */     gridBagLayout.rowWeights = new double[] { 0.0D, 0.0D, 0.0D, 1.0D, Double.MIN_VALUE };
/*  60 */     setLayout(gridBagLayout);
/*     */     
/*  62 */     JLabel lblFirstFrame = new JLabel("First frame:");
/*  63 */     GridBagConstraints gbc_lblFirstFrame = new GridBagConstraints();
/*  64 */     gbc_lblFirstFrame.anchor = 13;
/*  65 */     gbc_lblFirstFrame.insets = new Insets(0, 0, 5, 5);
/*  66 */     gbc_lblFirstFrame.gridx = 0;
/*  67 */     gbc_lblFirstFrame.gridy = 0;
/*  68 */     add(lblFirstFrame, gbc_lblFirstFrame);
/*     */     
/*  70 */     JFormattedTextField tftFirst = new JFormattedTextField(NumberFormat.getIntegerInstance());
/*  71 */     tftFirst.setValue(Integer.valueOf(firstFrame));
/*  72 */     tftFirst.setColumns(5);
/*  73 */     GridBagConstraints gbc_tftFirst = new GridBagConstraints();
/*  74 */     gbc_tftFirst.anchor = 11;
/*  75 */     gbc_tftFirst.insets = new Insets(0, 0, 5, 0);
/*  76 */     gbc_tftFirst.fill = 2;
/*  77 */     gbc_tftFirst.gridx = 1;
/*  78 */     gbc_tftFirst.gridy = 0;
/*  79 */     add(tftFirst, gbc_tftFirst);
/*     */     
/*  81 */     JLabel lblLastFrame = new JLabel("Last frame:");
/*  82 */     GridBagConstraints gbc_lblLastFrame = new GridBagConstraints();
/*  83 */     gbc_lblLastFrame.anchor = 13;
/*  84 */     gbc_lblLastFrame.insets = new Insets(0, 0, 5, 5);
/*  85 */     gbc_lblLastFrame.gridx = 0;
/*  86 */     gbc_lblLastFrame.gridy = 1;
/*  87 */     add(lblLastFrame, gbc_lblLastFrame);
/*     */     
/*  89 */     JFormattedTextField tftLast = new JFormattedTextField(NumberFormat.getIntegerInstance());
/*  90 */     tftLast.setValue(Integer.valueOf(lastFrame));
/*  91 */     tftLast.setColumns(5);
/*  92 */     GridBagConstraints gbc_tftLast = new GridBagConstraints();
/*  93 */     gbc_tftLast.insets = new Insets(0, 0, 5, 0);
/*  94 */     gbc_tftLast.fill = 2;
/*  95 */     gbc_tftLast.gridx = 1;
/*  96 */     gbc_tftLast.gridy = 1;
/*  97 */     add(tftLast, gbc_tftLast);
/*     */     
/*  99 */     JLabel lblNewLabel = new JLabel("Hide image:");
/* 100 */     GridBagConstraints gbc_lblNewLabel = new GridBagConstraints();
/* 101 */     gbc_lblNewLabel.anchor = 13;
/* 102 */     gbc_lblNewLabel.insets = new Insets(0, 0, 5, 5);
/* 103 */     gbc_lblNewLabel.gridx = 0;
/* 104 */     gbc_lblNewLabel.gridy = 2;
/* 105 */     add(lblNewLabel, gbc_lblNewLabel);
/*     */     
/* 107 */     JCheckBox chckbxHideImage = new JCheckBox();
/* 108 */     chckbxHideImage.setSelected(hideImage);
/* 109 */     GridBagConstraints gbc_chckbxHideImage = new GridBagConstraints();
/* 110 */     gbc_chckbxHideImage.anchor = 17;
/* 111 */     gbc_chckbxHideImage.insets = new Insets(0, 0, 5, 0);
/* 112 */     gbc_chckbxHideImage.gridx = 1;
/* 113 */     gbc_chckbxHideImage.gridy = 2;
/* 114 */     add(chckbxHideImage, gbc_chckbxHideImage);
/*     */     
/* 116 */     FocusListener fl = new FocusAdapter()
/*     */       {
/*     */         
/*     */         public void focusGained(final FocusEvent e)
/*     */         {
/* 121 */           SwingUtilities.invokeLater(new Runnable()
/*     */               {
/*     */                 
/*     */                 public void run()
/*     */                 {
/* 126 */                   ((JFormattedTextField)e.getSource()).selectAll();
/*     */                 }
/*     */               });
/*     */         }
/*     */       };
/* 131 */     tftFirst.addFocusListener(fl);
/* 132 */     tftLast.addFocusListener(fl);
/*     */     
/* 134 */     tftFirst.addPropertyChangeListener("value", e -> this.firstFrame = ((Number)tftFirst.getValue()).intValue());
/* 135 */     tftLast.addPropertyChangeListener("value", e -> this.lastFrame = ((Number)tftLast.getValue()).intValue());
/* 136 */     chckbxHideImage.addActionListener(e -> this.hideImage = chckbxHideImage.isSelected());
/*     */   }
/*     */ 
/*     */   
/*     */   public int getFirstFrame() {
/* 141 */     return this.firstFrame;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getLastFrame() {
/* 146 */     return this.lastFrame;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isHideImage() {
/* 151 */     return this.hideImage;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/action/CaptureOverlayPanel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */