/*    */ package fiji.plugin.trackmate.graph;
/*    */ 
/*    */ import java.util.Set;
/*    */ import org.jgrapht.Graph;
/*    */ import org.jgrapht.alg.util.NeighborCache;
/*    */ import org.jgrapht.graph.SimpleDirectedGraph;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RecursiveCumSum<V, E>
/*    */ {
/*    */   private final NeighborCache<V, E> cache;
/*    */   private final Function2<V, V> function;
/*    */   
/*    */   public RecursiveCumSum(SimpleDirectedGraph<V, E> graph, Function2<V, V> function) {
/* 35 */     this.cache = new NeighborCache((Graph)graph);
/* 36 */     this.function = function;
/*    */   }
/*    */ 
/*    */   
/*    */   public V apply(V current) {
/* 41 */     Set<V> children = this.cache.successorsOf(current);
/*    */     
/* 43 */     if (children.size() == 0)
/*    */     {
/* 45 */       return current;
/*    */     }
/*    */     
/* 48 */     V val = current;
/* 49 */     for (V child : children) {
/* 50 */       this.function.compute(val, apply(child), val);
/*    */     }
/* 52 */     return val;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/graph/RecursiveCumSum.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */