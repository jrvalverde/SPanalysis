/*     */ package fiji.plugin.trackmate;
/*     */ 
/*     */ import ij.IJ;
/*     */ import java.awt.Color;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintWriter;
/*     */ import java.io.Writer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Logger
/*     */   extends PrintWriter
/*     */ {
/*     */   public Logger() {
/*  40 */     super(new Writer()
/*     */         {
/*     */           public void write(char[] cbuf, int off, int len) throws IOException {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           public void flush() throws IOException {}
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           public void close() throws IOException {}
/*     */         });
/*  55 */     this.out = new Writer()
/*     */       {
/*     */         public void close() throws IOException {}
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         public void flush() throws IOException {}
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         public void write(char[] cbuf, int off, int len) throws IOException {
/*  68 */           String str = "";
/*  69 */           for (int i = off; i < len; i++)
/*  70 */             str = str + cbuf[i]; 
/*  71 */           Logger.this.log(str);
/*     */         }
/*     */       };
/*     */   }
/*     */   
/*  76 */   public static final Color NORMAL_COLOR = Color.BLACK;
/*     */   
/*  78 */   public static final Color ERROR_COLOR = new Color(0.8F, 0.0F, 0.0F);
/*     */   
/*  80 */   public static final Color GREEN_COLOR = new Color(0.0F, 0.6F, 0.0F);
/*     */   
/*  82 */   public static final Color BLUE_COLOR = new Color(0.0F, 0.0F, 0.7F);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void log(String paramString, Color paramColor);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void error(String paramString);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void log(String message) {
/* 110 */     log(message, NORMAL_COLOR);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 133 */   public static final Logger VOID_LOGGER = new VoidLogger();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 140 */   public static Logger DEFAULT_LOGGER = new DefaultLogger();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 146 */   public static final Logger IJ_LOGGER = new ImageJLogger();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 152 */   public static final Logger IJTOOLBAR_LOGGER = new ImageJToolbarLogger();
/*     */ 
/*     */   
/*     */   public abstract void setProgress(double paramDouble);
/*     */   
/*     */   public abstract void setStatus(String paramString);
/*     */   
/*     */   public static class StringBuilderLogger
/*     */     extends Logger
/*     */   {
/*     */     private final StringBuilder sb;
/*     */     
/*     */     public StringBuilderLogger(StringBuilder sb) {
/* 165 */       this.sb = sb;
/*     */     }
/*     */ 
/*     */     
/*     */     public StringBuilderLogger() {
/* 170 */       this(new StringBuilder());
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void log(String message, Color color) {
/* 180 */       this.sb.append(message);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void error(String message) {
/* 186 */       this.sb.append(message);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void setProgress(double val) {}
/*     */ 
/*     */ 
/*     */     
/*     */     public void setStatus(String status) {
/* 196 */       this.sb.append(status);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public String toString() {
/* 202 */       return this.sb.toString();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class SlaveLogger
/*     */     extends Logger
/*     */   {
/*     */     private final Logger master;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final double progressStart;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final double progressRange;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public SlaveLogger(Logger master, double progressStart, double progressRange) {
/* 239 */       this.master = master;
/* 240 */       this.progressStart = progressStart;
/* 241 */       this.progressRange = progressRange;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void log(String message, Color color) {
/* 247 */       this.master.log(message, color);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void error(String message) {
/* 253 */       this.master.error(message);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void setProgress(double val) {
/* 259 */       this.master.setProgress(this.progressStart + this.progressRange * val);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void setStatus(String status) {
/* 265 */       this.master.setStatus(status);
/*     */     }
/*     */   }
/*     */   
/*     */   private static class ImageJLogger
/*     */     extends Logger
/*     */   {
/*     */     private ImageJLogger() {}
/*     */     
/*     */     public void log(String message, Color color) {
/* 275 */       IJ.log(message);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void error(String message) {
/* 281 */       IJ.log(message);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void setProgress(double val) {
/* 287 */       IJ.showProgress(val);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void setStatus(String status) {
/* 293 */       IJ.showStatus(status);
/*     */     }
/*     */   }
/*     */   
/*     */   private static class ImageJToolbarLogger
/*     */     extends Logger {
/*     */     private ImageJToolbarLogger() {}
/*     */     
/*     */     public void log(String message, Color color) {
/* 302 */       IJ.showStatus(message);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void error(String message) {
/* 308 */       IJ.showStatus(message);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void setProgress(double val) {
/* 314 */       IJ.showProgress(val);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void setStatus(String status) {
/* 320 */       IJ.showStatus(status);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static class VoidLogger
/*     */     extends Logger
/*     */   {
/*     */     private VoidLogger() {}
/*     */ 
/*     */     
/*     */     public void setStatus(String status) {}
/*     */ 
/*     */     
/*     */     public void setProgress(double val) {}
/*     */ 
/*     */     
/*     */     public void log(String message, Color color) {}
/*     */ 
/*     */     
/*     */     public void error(String message) {}
/*     */   }
/*     */ 
/*     */   
/*     */   private static class DefaultLogger
/*     */     extends Logger
/*     */   {
/*     */     private DefaultLogger() {}
/*     */     
/*     */     public void log(String message, Color color) {
/* 350 */       System.out.print(message);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void error(String message) {
/* 356 */       System.err.print(message);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void setProgress(double val) {}
/*     */ 
/*     */ 
/*     */     
/*     */     public void setStatus(String status) {
/* 366 */       System.out.println(status);
/*     */     }
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/Logger.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */