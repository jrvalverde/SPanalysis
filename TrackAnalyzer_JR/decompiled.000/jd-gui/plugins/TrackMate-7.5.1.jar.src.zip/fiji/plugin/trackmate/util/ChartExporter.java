/*     */ package fiji.plugin.trackmate.util;
/*     */ 
/*     */ import com.itextpdf.awt.PdfGraphics2D;
/*     */ import com.itextpdf.text.Document;
/*     */ import com.itextpdf.text.DocumentException;
/*     */ import com.itextpdf.text.Rectangle;
/*     */ import com.itextpdf.text.pdf.PdfContentByte;
/*     */ import com.itextpdf.text.pdf.PdfWriter;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.Rectangle;
/*     */ import java.io.File;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.io.Writer;
/*     */ import org.apache.batik.dom.GenericDOMImplementation;
/*     */ import org.apache.batik.svggen.SVGGraphics2D;
/*     */ import org.jfree.chart.JFreeChart;
/*     */ import org.w3c.dom.DOMImplementation;
/*     */ import org.w3c.dom.Document;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ChartExporter
/*     */ {
/*     */   public static void exportChartAsSVG(File svgFile, JFreeChart chart, int width, int height) throws UnsupportedEncodingException, IOException {
/*  69 */     DOMImplementation domImpl = GenericDOMImplementation.getDOMImplementation();
/*  70 */     Document document = domImpl.createDocument(null, "svg", null);
/*     */ 
/*     */     
/*  73 */     SVGGraphics2D svgGenerator = new SVGGraphics2D(document);
/*     */     
/*  75 */     chart.draw((Graphics2D)svgGenerator, new Rectangle(width, height));
/*     */ 
/*     */     
/*  78 */     try(OutputStream outputStream = new FileOutputStream(svgFile); 
/*  79 */         Writer out = new OutputStreamWriter(outputStream, "UTF-8")) {
/*     */       
/*  81 */       svgGenerator.stream(out, true);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void exportChartAsPDF(File pdfFile, JFreeChart chart, int width, int height) throws FileNotFoundException, DocumentException {
/* 104 */     Rectangle pageSize = new Rectangle(0.0F, 0.0F, width, height);
/* 105 */     Document document = new Document(pageSize);
/*     */     
/* 107 */     PdfWriter writer = PdfWriter.getInstance(document, new FileOutputStream(pdfFile));
/*     */     
/* 109 */     document.open();
/*     */     
/* 111 */     PdfContentByte cb = writer.getDirectContent();
/* 112 */     PdfGraphics2D g2 = new PdfGraphics2D(cb, width, height);
/* 113 */     chart.draw((Graphics2D)g2, new Rectangle(0, 0, width, height));
/* 114 */     g2.dispose();
/*     */     
/* 116 */     document.close();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/util/ChartExporter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */