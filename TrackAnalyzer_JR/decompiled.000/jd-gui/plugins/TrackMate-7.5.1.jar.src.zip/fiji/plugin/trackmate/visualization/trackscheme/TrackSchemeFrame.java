/*     */ package fiji.plugin.trackmate.visualization.trackscheme;
/*     */ 
/*     */ import com.mxgraph.model.mxICell;
/*     */ import com.mxgraph.swing.handler.mxRubberband;
/*     */ import com.mxgraph.swing.mxGraphOutline;
/*     */ import fiji.plugin.trackmate.Logger;
/*     */ import fiji.plugin.trackmate.gui.Icons;
/*     */ import fiji.plugin.trackmate.gui.displaysettings.DisplaySettings;
/*     */ import fiji.plugin.trackmate.util.TrackNavigator;
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.Component;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Point;
/*     */ import java.awt.event.MouseAdapter;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.awt.event.MouseWheelEvent;
/*     */ import java.awt.event.MouseWheelListener;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JFrame;
/*     */ import javax.swing.JSplitPane;
/*     */ import javax.swing.JToolBar;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TrackSchemeFrame
/*     */   extends JFrame
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private InfoPane infoPane;
/*     */   private JGraphXAdapter graph;
/*     */   private final TrackScheme trackScheme;
/*     */   TrackSchemeGraphComponent graphComponent;
/*  69 */   protected final Logger logger = Logger.IJTOOLBAR_LOGGER;
/*     */ 
/*     */ 
/*     */   
/*     */   private final DisplaySettings displaySettings;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TrackSchemeFrame(TrackScheme trackScheme, DisplaySettings displaySettings) {
/*  79 */     this.trackScheme = trackScheme;
/*  80 */     this.displaySettings = displaySettings;
/*  81 */     this.graph = trackScheme.getGraph();
/*     */ 
/*     */     
/*  84 */     setIconImage(Icons.TRACK_SCHEME_ICON.getImage());
/*     */ 
/*     */     
/*  87 */     getContentPane().setLayout(new BorderLayout());
/*     */ 
/*     */     
/*  90 */     getContentPane().add(createToolBar(), "North");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void init(JGraphXAdapter lGraph) {
/*  99 */     this.graph = lGraph;
/*     */     
/* 101 */     this.graphComponent = createGraphComponent();
/*     */ 
/*     */     
/* 104 */     this.infoPane = new InfoPane(this.trackScheme.getModel(), this.trackScheme.getSelectionModel());
/*     */ 
/*     */     
/* 107 */     mxGraphOutline graphOutline = new mxGraphOutline(this.graphComponent);
/*     */     
/* 109 */     JSplitPane inner = new JSplitPane(0, (Component)graphOutline, this.infoPane);
/* 110 */     inner.setDividerLocation(120);
/* 111 */     inner.setMinimumSize(new Dimension(0, 0));
/*     */     
/* 113 */     JSplitPane splitPane = new JSplitPane(1, inner, (Component)this.graphComponent);
/* 114 */     splitPane.setDividerLocation(170);
/* 115 */     getContentPane().add(splitPane, "Center");
/*     */     
/* 117 */     TrackSchemeKeyboardHandler keyboardHandler = new TrackSchemeKeyboardHandler(this.graphComponent, new TrackNavigator(this.trackScheme.getModel(), this.trackScheme.getSelectionModel()));
/* 118 */     keyboardHandler.installKeyboardActions((JComponent)this.graphComponent);
/* 119 */     keyboardHandler.installKeyboardActions(this.infoPane);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void centerViewOn(mxICell cell) {
/* 128 */     this.graphComponent.scrollCellToVisible(cell, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private TrackSchemeGraphComponent createGraphComponent() {
/* 137 */     final TrackSchemeGraphComponent gc = new TrackSchemeGraphComponent(this.graph, this.trackScheme, this.displaySettings);
/* 138 */     gc.getVerticalScrollBar().setUnitIncrement(16);
/* 139 */     gc.getHorizontalScrollBar().setUnitIncrement(16);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 146 */     gc.getConnectionHandler().setEnabled(false);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 151 */     new mxRubberband(gc);
/*     */ 
/*     */     
/* 154 */     gc.getGraphControl().addMouseListener(new MouseAdapter()
/*     */         {
/*     */           
/*     */           public void mousePressed(MouseEvent e)
/*     */           {
/* 159 */             if (e.isPopupTrigger())
/*     */             {
/* 161 */               TrackSchemeFrame.this.displayPopupMenu(gc.getCellAt(e.getX(), e.getY(), false), e.getPoint());
/*     */             }
/*     */           }
/*     */ 
/*     */ 
/*     */           
/*     */           public void mouseReleased(MouseEvent e) {
/* 168 */             if (e.isPopupTrigger())
/*     */             {
/* 170 */               TrackSchemeFrame.this.displayPopupMenu(gc.getCellAt(e.getX(), e.getY(), false), e.getPoint());
/*     */             }
/*     */           }
/*     */         });
/*     */     
/* 175 */     gc.addMouseWheelListener(new MouseWheelListener()
/*     */         {
/*     */ 
/*     */           
/*     */           public void mouseWheelMoved(MouseWheelEvent e)
/*     */           {
/* 181 */             if (gc.isPanningEvent(e)) {
/*     */               
/* 183 */               boolean in = (e.getWheelRotation() < 0);
/* 184 */               if (in) {
/* 185 */                 gc.zoomIn();
/*     */               } else {
/* 187 */                 gc.zoomOut();
/*     */               } 
/*     */             } 
/*     */           }
/*     */         });
/* 192 */     gc.setKeepSelectionVisibleOnZoom(true);
/* 193 */     gc.setPanning(true);
/* 194 */     return gc;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private JToolBar createToolBar() {
/* 202 */     return new TrackSchemeToolbar(this.trackScheme);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void displayPopupMenu(Object cell, Point point) {
/* 210 */     TrackSchemePopupMenu menu = new TrackSchemePopupMenu(this.trackScheme, cell, point);
/* 211 */     menu.show(this.graphComponent.getViewport().getView(), (int)point.getX(), (int)point.getY());
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/visualization/trackscheme/TrackSchemeFrame.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */