package fiji.plugin.trackmate.features.spot;

import fiji.plugin.trackmate.features.FeatureAnalyzer;
import net.imagej.ImgPlus;

public interface SpotAnalyzerFactoryBase<T extends net.imglib2.type.numeric.RealType<T> & net.imglib2.type.NativeType<T>> extends FeatureAnalyzer {
  SpotAnalyzer<T> getAnalyzer(ImgPlus<T> paramImgPlus, int paramInt1, int paramInt2);
  
  default void setNChannels(int nChannels) {}
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/features/spot/SpotAnalyzerFactoryBase.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */