/*    */ package fiji.plugin.trackmate.visualization;
/*    */ 
/*    */ import fiji.plugin.trackmate.Spot;
/*    */ import fiji.plugin.trackmate.gui.displaysettings.Colormap;
/*    */ import java.awt.Color;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SpotColorGenerator
/*    */   implements FeatureColorGenerator<Spot>
/*    */ {
/*    */   private final String feature;
/*    */   private final Color missingValueColor;
/*    */   private final Color undefinedValueColor;
/*    */   private final Colormap colormap;
/*    */   private final double min;
/*    */   private final double max;
/*    */   
/*    */   public SpotColorGenerator(String feature, Color missingValueColor, Color undefinedValueColor, Colormap colormap, double min, double max) {
/* 52 */     this.feature = feature;
/* 53 */     this.missingValueColor = missingValueColor;
/* 54 */     this.undefinedValueColor = undefinedValueColor;
/* 55 */     this.colormap = colormap;
/* 56 */     this.min = min;
/* 57 */     this.max = max;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Color color(Spot spot) {
/* 63 */     Double feat = spot.getFeature(this.feature);
/* 64 */     if (null == feat)
/* 65 */       return this.missingValueColor; 
/* 66 */     if (feat.isNaN()) {
/* 67 */       return this.undefinedValueColor;
/*    */     }
/* 69 */     return this.colormap.getPaint((feat.doubleValue() - this.min) / (this.max - this.min));
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/visualization/SpotColorGenerator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */