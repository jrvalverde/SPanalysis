/*     */ package fiji.plugin.trackmate;
/*     */ 
/*     */ import fiji.plugin.trackmate.features.edges.EdgeAnalyzer;
/*     */ import fiji.plugin.trackmate.features.spot.SpotAnalyzerFactoryBase;
/*     */ import fiji.plugin.trackmate.features.track.TrackAnalyzer;
/*     */ import fiji.plugin.trackmate.gui.GuiUtils;
/*     */ import fiji.plugin.trackmate.gui.Icons;
/*     */ import fiji.plugin.trackmate.gui.components.LogPanel;
/*     */ import fiji.plugin.trackmate.gui.displaysettings.DisplaySettings;
/*     */ import fiji.plugin.trackmate.gui.wizard.WizardSequence;
/*     */ import fiji.plugin.trackmate.gui.wizard.descriptors.LogPanelDescriptor2;
/*     */ import fiji.plugin.trackmate.gui.wizard.descriptors.SomeDialogDescriptor;
/*     */ import fiji.plugin.trackmate.io.IOUtils;
/*     */ import fiji.plugin.trackmate.io.TmXmlReader;
/*     */ import fiji.plugin.trackmate.util.TMUtils;
/*     */ import fiji.plugin.trackmate.visualization.ViewUtils;
/*     */ import fiji.plugin.trackmate.visualization.hyperstack.HyperStackDisplayer;
/*     */ import ij.IJ;
/*     */ import ij.ImageJ;
/*     */ import ij.ImagePlus;
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.io.File;
/*     */ import javax.swing.JFrame;
/*     */ import org.scijava.util.VersionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LoadTrackMatePlugIn
/*     */   extends TrackMatePlugIn
/*     */ {
/*     */   public void run(String filePath) {
/*  71 */     GuiUtils.setSystemLookAndFeel();
/*     */     
/*  73 */     Logger logger = Logger.IJ_LOGGER;
/*  74 */     File file = SomeDialogDescriptor.file;
/*  75 */     if (null == filePath || filePath.length() == 0) {
/*     */ 
/*     */       
/*  78 */       if (null == file || file.length() == 0L) {
/*     */         
/*  80 */         File folder = new File(System.getProperty("user.dir"));
/*  81 */         File parent = folder.getParentFile();
/*  82 */         File parent2 = (parent == null) ? null : parent.getParentFile();
/*  83 */         file = new File((parent2 != null) ? parent2 : ((parent != null) ? parent : folder), "TrackMateData.xml");
/*     */       } 
/*  85 */       File tmpFile = IOUtils.askForFileForLoading(file, "Load a TrackMate XML file", null, logger);
/*  86 */       if (null == tmpFile)
/*     */         return; 
/*  88 */       file = tmpFile;
/*     */     }
/*     */     else {
/*     */       
/*  92 */       file = new File(filePath);
/*  93 */       if (!file.exists()) {
/*     */         
/*  95 */         IJ.error("TrackMate v" + TrackMate.PLUGIN_NAME_VERSION, "Could not find file with path " + filePath + ".");
/*     */         
/*     */         return;
/*     */       } 
/*  99 */       if (!file.canRead()) {
/*     */         
/* 101 */         IJ.error("TrackMate v" + TrackMate.PLUGIN_NAME_VERSION, "Could not read file with path " + filePath + ".");
/*     */ 
/*     */         
/*     */         return;
/*     */       } 
/*     */     } 
/*     */     
/* 108 */     TmXmlReader reader = createReader(file);
/* 109 */     if (!reader.isReadingOk()) {
/*     */       
/* 111 */       IJ.error("TrackMate v" + TrackMate.PLUGIN_NAME_VERSION, reader.getErrorMessage());
/*     */       
/*     */       return;
/*     */     } 
/* 115 */     String version = reader.getVersion();
/* 116 */     if (VersionUtils.compare(version, "2.1.0") < 0) {
/*     */ 
/*     */       
/* 119 */       logger.error("Cannot read TrackMate file version lower than 2.1.0.\nAborting.\n");
/*     */       return;
/*     */     } 
/* 122 */     if (!reader.isReadingOk()) {
/*     */       
/* 124 */       logger.error(reader.getErrorMessage());
/* 125 */       logger.error("Aborting.\n");
/*     */ 
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */ 
/*     */     
/* 133 */     String logText = reader.getLog() + '\n';
/*     */ 
/*     */     
/* 136 */     Model model = reader.getModel();
/* 137 */     if (!reader.isReadingOk()) {
/* 138 */       logger.error("Problem reading the model:\n" + reader.getErrorMessage());
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 144 */     ImagePlus imp = reader.readImage();
/* 145 */     if (null == imp) {
/* 146 */       imp = ViewUtils.makeEmpytImagePlus(model);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 152 */     Settings settings = reader.readSettings(imp);
/* 153 */     if (!reader.isReadingOk()) {
/* 154 */       logger.error("Problem reading the settings:\n" + reader.getErrorMessage());
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 161 */     for (SpotAnalyzerFactoryBase<?> analyzer : settings.getSpotAnalyzerFactories()) {
/* 162 */       model.getFeatureModel().declareSpotFeatures(analyzer
/* 163 */           .getFeatures(), analyzer
/* 164 */           .getFeatureNames(), analyzer
/* 165 */           .getFeatureShortNames(), analyzer
/* 166 */           .getFeatureDimensions(), analyzer
/* 167 */           .getIsIntFeature());
/*     */     }
/* 169 */     for (EdgeAnalyzer analyzer : settings.getEdgeAnalyzers())
/* 170 */       model.getFeatureModel().declareEdgeFeatures(analyzer
/* 171 */           .getFeatures(), analyzer
/* 172 */           .getFeatureNames(), analyzer
/* 173 */           .getFeatureShortNames(), analyzer
/* 174 */           .getFeatureDimensions(), analyzer
/* 175 */           .getIsIntFeature()); 
/* 176 */     for (TrackAnalyzer analyzer : settings.getTrackAnalyzers()) {
/* 177 */       model.getFeatureModel().declareTrackFeatures(analyzer
/* 178 */           .getFeatures(), analyzer
/* 179 */           .getFeatureNames(), analyzer
/* 180 */           .getFeatureShortNames(), analyzer
/* 181 */           .getFeatureDimensions(), analyzer
/* 182 */           .getIsIntFeature());
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 188 */     TrackMate trackmate = createTrackMate(model, settings);
/*     */ 
/*     */     
/* 191 */     postRead(trackmate);
/*     */ 
/*     */     
/* 194 */     DisplaySettings displaySettings = reader.getDisplaySettings();
/*     */ 
/*     */     
/* 197 */     SelectionModel selectionModel = new SelectionModel(model);
/*     */     
/* 199 */     if (!reader.isReadingOk()) {
/*     */       
/* 201 */       logger.error("Some errors occurred while reading file:\n");
/* 202 */       logger.error(reader.getErrorMessage());
/*     */     } 
/*     */ 
/*     */     
/* 206 */     HyperStackDisplayer hyperStackDisplayer = new HyperStackDisplayer(model, selectionModel, settings.imp, displaySettings);
/* 207 */     hyperStackDisplayer.render();
/*     */ 
/*     */     
/* 210 */     String panelIdentifier = reader.getGUIState();
/*     */     
/* 212 */     if (null == panelIdentifier) {
/* 213 */       panelIdentifier = "ConfigureViews";
/*     */     }
/*     */     
/* 216 */     WizardSequence sequence = createSequence(trackmate, selectionModel, displaySettings);
/* 217 */     sequence.setCurrent(panelIdentifier);
/* 218 */     JFrame frame = sequence.run("TrackMate on " + settings.imp.getShortTitle());
/* 219 */     frame.setIconImage(Icons.TRACKMATE_ICON.getImage());
/* 220 */     GuiUtils.positionWindow(frame, (Component)settings.imp.getWindow());
/* 221 */     frame.setVisible(true);
/*     */ 
/*     */     
/* 224 */     LogPanelDescriptor2 logDescriptor = (LogPanelDescriptor2)sequence.logDescriptor();
/* 225 */     LogPanel logPanel = (LogPanel)logDescriptor.getPanelComponent();
/* 226 */     Logger logger2 = logPanel.getLogger();
/*     */     
/* 228 */     logger2.log("Session log saved in the file:\n--------------------\n" + logText + "--------------------\n", Color.GRAY);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 233 */     logger2.log("File loaded on " + TMUtils.getCurrentTimeString() + '\n', Logger.BLUE_COLOR);
/*     */     
/* 235 */     if (!reader.isReadingOk()) {
/*     */       
/* 237 */       logger2.error("Some errors occurred while reading file:\n");
/* 238 */       logger2.error(reader.getErrorMessage());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void postRead(TrackMate trackmate) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected TmXmlReader createReader(File lFile) {
/* 268 */     return new TmXmlReader(lFile);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void main(String[] args) {
/* 277 */     ImageJ.main(args);
/* 278 */     LoadTrackMatePlugIn plugIn = new LoadTrackMatePlugIn();
/*     */     
/* 280 */     plugIn.run("samples/MAX_Merged.xml");
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/LoadTrackMatePlugIn.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */