/*     */ package fiji.plugin.trackmate.providers;
/*     */ 
/*     */ import fiji.plugin.trackmate.TrackMateModule;
/*     */ import fiji.plugin.trackmate.util.TMUtils;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.scijava.Context;
/*     */ import org.scijava.InstantiableException;
/*     */ import org.scijava.log.LogService;
/*     */ import org.scijava.plugin.PluginInfo;
/*     */ import org.scijava.plugin.PluginService;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractProvider<K extends TrackMateModule>
/*     */ {
/*     */   private final Class<K> cl;
/*     */   protected List<String> keys;
/*     */   protected List<String> visibleKeys;
/*     */   protected List<String> disabled;
/*     */   protected Map<String, K> implementations;
/*     */   
/*     */   public AbstractProvider(Class<K> cl) {
/*  44 */     this.cl = cl;
/*  45 */     registerModules();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void registerModules() {
/*  58 */     Context context = TMUtils.getContext();
/*  59 */     LogService log = (LogService)context.getService(LogService.class);
/*  60 */     PluginService pluginService = (PluginService)context.getService(PluginService.class);
/*  61 */     List<PluginInfo<K>> infos = pluginService.getPluginsOfType(this.cl);
/*     */     
/*  63 */     this.keys = new ArrayList<>(infos.size());
/*  64 */     this.visibleKeys = new ArrayList<>(infos.size());
/*  65 */     this.disabled = new ArrayList<>(infos.size());
/*  66 */     this.implementations = new HashMap<>();
/*     */     
/*  68 */     for (PluginInfo<K> info : infos) {
/*     */       
/*  70 */       if (!info.isEnabled()) {
/*     */         
/*  72 */         this.disabled.add(info.getClassName());
/*     */         
/*     */         continue;
/*     */       } 
/*     */       try {
/*  77 */         TrackMateModule trackMateModule = (TrackMateModule)info.createInstance();
/*  78 */         String key = trackMateModule.getKey();
/*     */         
/*  80 */         this.implementations.put(key, (K)trackMateModule);
/*  81 */         this.keys.add(key);
/*  82 */         if (info.isVisible()) {
/*  83 */           this.visibleKeys.add(key);
/*     */         }
/*     */       }
/*  86 */       catch (InstantiableException e) {
/*     */         
/*  88 */         log.error("Could not instantiate " + info.getClassName(), (Throwable)e);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public List<String> getKeys() {
/*  95 */     return new ArrayList<>(this.keys);
/*     */   }
/*     */ 
/*     */   
/*     */   public List<String> getVisibleKeys() {
/* 100 */     return new ArrayList<>(this.visibleKeys);
/*     */   }
/*     */ 
/*     */   
/*     */   public List<String> getDisabled() {
/* 105 */     return new ArrayList<>(this.disabled);
/*     */   }
/*     */ 
/*     */   
/*     */   public K getFactory(String key) {
/* 110 */     return this.implementations.get(key);
/*     */   }
/*     */ 
/*     */   
/*     */   public String echo() {
/* 115 */     StringBuilder str = new StringBuilder();
/* 116 */     str.append("Discovered modules for " + this.cl.getSimpleName() + ":\n");
/* 117 */     str.append("  Enabled & visible:");
/* 118 */     if (getVisibleKeys().isEmpty()) {
/*     */       
/* 120 */       str.append(" none.\n");
/*     */     }
/*     */     else {
/*     */       
/* 124 */       str.append('\n');
/* 125 */       for (String key : getVisibleKeys())
/* 126 */         str.append("  - " + key + "\t-->\t" + getFactory(key).getName() + '\n'); 
/*     */     } 
/* 128 */     str.append("  Enabled & not visible:");
/* 129 */     List<String> invisibleKeys = getKeys();
/* 130 */     invisibleKeys.removeAll(getVisibleKeys());
/* 131 */     if (invisibleKeys.isEmpty()) {
/*     */       
/* 133 */       str.append(" none.\n");
/*     */     }
/*     */     else {
/*     */       
/* 137 */       str.append('\n');
/* 138 */       for (String key : invisibleKeys)
/* 139 */         str.append("  - " + key + "\t-->\t" + getFactory(key).getName() + '\n'); 
/*     */     } 
/* 141 */     str.append("  Disabled:");
/* 142 */     if (getDisabled().isEmpty()) {
/*     */       
/* 144 */       str.append(" none.\n");
/*     */     }
/*     */     else {
/*     */       
/* 148 */       str.append('\n');
/* 149 */       for (String cn : getDisabled())
/* 150 */         str.append("  - " + cn + '\n'); 
/*     */     } 
/* 152 */     return str.toString();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/providers/AbstractProvider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */