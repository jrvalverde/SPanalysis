/*     */ package fiji.plugin.trackmate.detection;
/*     */ 
/*     */ import fiji.plugin.trackmate.Model;
/*     */ import fiji.plugin.trackmate.Settings;
/*     */ import fiji.plugin.trackmate.gui.components.ConfigurationPanel;
/*     */ import fiji.plugin.trackmate.gui.components.detector.MaskDetectorConfigurationPanel;
/*     */ import fiji.plugin.trackmate.io.IOUtils;
/*     */ import fiji.plugin.trackmate.util.TMUtils;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.swing.ImageIcon;
/*     */ import net.imagej.ImgPlus;
/*     */ import net.imagej.ImgPlusMetadata;
/*     */ import net.imglib2.Interval;
/*     */ import net.imglib2.RandomAccessible;
/*     */ import net.imglib2.RandomAccessibleInterval;
/*     */ import net.imglib2.type.NativeType;
/*     */ import net.imglib2.type.Type;
/*     */ import net.imglib2.type.numeric.RealType;
/*     */ import org.jdom2.Element;
/*     */ import org.scijava.plugin.Plugin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Plugin(type = SpotDetectorFactory.class)
/*     */ public class MaskDetectorFactory<T extends RealType<T> & NativeType<T>>
/*     */   extends ThresholdDetectorFactory<T>
/*     */ {
/*     */   public static final String DETECTOR_KEY = "MASK_DETECTOR";
/*     */   public static final String NAME = "Mask detector";
/*     */   public static final String INFO_TEXT = "<html>This detector creates spots from a black and white mask.<p>More precisely, all the pixels in the designated channel that have a value strictly larger than 0 are considered as part of the foreground, and used to build connected regions. In 2D, spots are created with the (possibly simplified) contour of the region. In 3D, a spherical spot is created for each region in its center, with a volume equal to the region volume.</html>";
/*     */   
/*     */   public boolean has2Dsegmentation() {
/*  83 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public SpotDetector<T> getDetector(Interval interval, int frame) {
/*  89 */     double intensityThreshold = 0.0D;
/*  90 */     boolean simplifyContours = ((Boolean)this.settings.get("SIMPLIFY_CONTOURS")).booleanValue();
/*  91 */     double[] calibration = TMUtils.getSpatialCalibration((ImgPlusMetadata)this.img);
/*  92 */     int channel = ((Integer)this.settings.get("TARGET_CHANNEL")).intValue() - 1;
/*  93 */     RandomAccessibleInterval<Type> randomAccessibleInterval = DetectionUtils.prepareFrameImg((ImgPlus)this.img, channel, frame);
/*     */     
/*  95 */     ThresholdDetector<T> detector = new ThresholdDetector<>((RandomAccessible)randomAccessibleInterval, interval, calibration, 0.0D, simplifyContours);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 101 */     detector.setNumThreads(1);
/* 102 */     return detector;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getKey() {
/* 108 */     return "MASK_DETECTOR";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean checkSettings(Map<String, Object> lSettings) {
/* 114 */     boolean ok = true;
/* 115 */     StringBuilder errorHolder = new StringBuilder();
/* 116 */     ok &= TMUtils.checkParameter(lSettings, "TARGET_CHANNEL", Integer.class, errorHolder);
/* 117 */     ok &= TMUtils.checkParameter(lSettings, "SIMPLIFY_CONTOURS", Boolean.class, errorHolder);
/* 118 */     List<String> mandatoryKeys = new ArrayList<>();
/* 119 */     mandatoryKeys.add("TARGET_CHANNEL");
/* 120 */     mandatoryKeys.add("SIMPLIFY_CONTOURS");
/* 121 */     ok &= TMUtils.checkMapKeys(lSettings, mandatoryKeys, null, errorHolder);
/* 122 */     if (!ok)
/*     */     {
/* 124 */       this.errorMessage = errorHolder.toString();
/*     */     }
/* 126 */     return ok;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean marshall(Map<String, Object> lSettings, Element element) {
/* 132 */     StringBuilder errorHolder = new StringBuilder();
/*     */     
/* 134 */     boolean ok = (IOUtils.writeTargetChannel(lSettings, element, errorHolder) && IOUtils.writeAttribute(lSettings, element, "SIMPLIFY_CONTOURS", Boolean.class, errorHolder));
/*     */     
/* 136 */     if (!ok) {
/* 137 */       this.errorMessage = errorHolder.toString();
/*     */     }
/* 139 */     return ok;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean unmarshall(Element element, Map<String, Object> lSettings) {
/* 145 */     lSettings.clear();
/* 146 */     StringBuilder errorHolder = new StringBuilder();
/* 147 */     boolean ok = true;
/* 148 */     ok &= IOUtils.readIntegerAttribute(element, lSettings, "TARGET_CHANNEL", errorHolder);
/* 149 */     ok &= IOUtils.readBooleanAttribute(element, lSettings, "SIMPLIFY_CONTOURS", errorHolder);
/* 150 */     if (!ok) {
/*     */       
/* 152 */       this.errorMessage = errorHolder.toString();
/* 153 */       return false;
/*     */     } 
/* 155 */     return checkSettings(lSettings);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ConfigurationPanel getDetectorConfigurationPanel(Settings lSettings, Model model) {
/* 161 */     return (ConfigurationPanel)new MaskDetectorConfigurationPanel(lSettings, model);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getInfoText() {
/* 167 */     return "<html>This detector creates spots from a black and white mask.<p>More precisely, all the pixels in the designated channel that have a value strictly larger than 0 are considered as part of the foreground, and used to build connected regions. In 2D, spots are created with the (possibly simplified) contour of the region. In 3D, a spherical spot is created for each region in its center, with a volume equal to the region volume.</html>";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/* 173 */     return "Mask detector";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, Object> getDefaultSettings() {
/* 179 */     Map<String, Object> lSettings = new HashMap<>();
/* 180 */     lSettings.put("TARGET_CHANNEL", Integer.valueOf(1));
/* 181 */     lSettings.put("SIMPLIFY_CONTOURS", Boolean.valueOf(true));
/* 182 */     return lSettings;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ImageIcon getIcon() {
/* 188 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public MaskDetectorFactory<T> copy() {
/* 194 */     return new MaskDetectorFactory();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/detection/MaskDetectorFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */