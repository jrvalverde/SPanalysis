/*    */ package fiji.plugin.trackmate.features.spot;
/*    */ 
/*    */ import fiji.plugin.trackmate.Spot;
/*    */ import fiji.plugin.trackmate.util.SpotUtil;
/*    */ import fiji.plugin.trackmate.util.TMUtils;
/*    */ import net.imagej.ImgPlus;
/*    */ import net.imglib2.IterableInterval;
/*    */ import net.imglib2.type.numeric.RealType;
/*    */ import net.imglib2.util.Util;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SpotIntensityMultiCAnalyzer<T extends RealType<T>>
/*    */   extends AbstractSpotFeatureAnalyzer<T>
/*    */ {
/*    */   private final int channel;
/*    */   private final ImgPlus<T> imgCT;
/*    */   
/*    */   public SpotIntensityMultiCAnalyzer(ImgPlus<T> imgCT, int channel) {
/* 48 */     this.imgCT = imgCT;
/* 49 */     this.channel = channel;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void process(Spot spot) {
/* 55 */     IterableInterval<T> neighborhood = SpotUtil.iterable(spot, this.imgCT);
/* 56 */     double[] intensities = new double[(int)neighborhood.size()];
/* 57 */     int n = 0;
/* 58 */     for (RealType realType : neighborhood) {
/*    */       
/* 60 */       double val = realType.getRealDouble();
/* 61 */       intensities[n++] = val;
/*    */     } 
/* 63 */     Util.quicksort(intensities);
/* 64 */     spot.putFeature(SpotIntensityMultiCAnalyzerFactory.makeFeatureKey("MEAN_INTENSITY_CH", this.channel), Double.valueOf(Util.average(intensities)));
/* 65 */     spot.putFeature(SpotIntensityMultiCAnalyzerFactory.makeFeatureKey("MEDIAN_INTENSITY_CH", this.channel), Double.valueOf(intensities[intensities.length / 2]));
/* 66 */     spot.putFeature(SpotIntensityMultiCAnalyzerFactory.makeFeatureKey("MIN_INTENSITY_CH", this.channel), Double.valueOf(intensities[0]));
/* 67 */     spot.putFeature(SpotIntensityMultiCAnalyzerFactory.makeFeatureKey("MAX_INTENSITY_CH", this.channel), Double.valueOf(intensities[intensities.length - 1]));
/* 68 */     spot.putFeature(SpotIntensityMultiCAnalyzerFactory.makeFeatureKey("TOTAL_INTENSITY_CH", this.channel), Double.valueOf(TMUtils.sum(intensities)));
/* 69 */     spot.putFeature(SpotIntensityMultiCAnalyzerFactory.makeFeatureKey("STD_INTENSITY_CH", this.channel), Double.valueOf(TMUtils.standardDeviation(intensities)));
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/features/spot/SpotIntensityMultiCAnalyzer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */