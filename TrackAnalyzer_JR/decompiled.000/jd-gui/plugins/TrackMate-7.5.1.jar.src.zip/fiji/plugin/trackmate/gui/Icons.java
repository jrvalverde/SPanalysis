/*     */ package fiji.plugin.trackmate.gui;
/*     */ 
/*     */ import java.awt.Image;
/*     */ import javax.swing.ImageIcon;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Icons
/*     */ {
/*  30 */   public static final ImageIcon SPOT_ICON = new ImageIcon(Icons.class.getResource("images/Icon1_print_transparency.png"));
/*     */   
/*  32 */   public static final ImageIcon EDGE_ICON = new ImageIcon(Icons.class.getResource("images/Icon2_print_transparency.png"));
/*     */   
/*  34 */   public static final ImageIcon TRACK_ICON = new ImageIcon(Icons.class.getResource("images/Icon3b_print_transparency.png"));
/*     */   
/*  36 */   public static final ImageIcon BRANCH_ICON = new ImageIcon(Icons.class.getResource("images/Icons4_print_transparency.png"));
/*     */   
/*  38 */   public static final ImageIcon TRACK_SCHEME_ICON = new ImageIcon(Icons.class.getResource("images/Icon3a_print_transparency.png"));
/*     */   
/*  40 */   public static final ImageIcon TRACKMATE_ICON = new ImageIcon(Icons.class.getResource("images/Logo50x50-color-nofont-72p.png"));
/*     */   
/*     */   public static final ImageIcon TRACKMATE_ICON_16x16;
/*     */   
/*     */   public static final ImageIcon TRACK_SCHEME_ICON_16x16;
/*     */   
/*     */   public static final ImageIcon SPOT_ICON_64x64;
/*     */   
/*     */   public static final ImageIcon EDGE_ICON_64x64;
/*     */   
/*     */   public static final ImageIcon EDGE_ICON_16x16;
/*     */   
/*     */   public static final ImageIcon TRACK_ICON_64x64;
/*     */   public static final ImageIcon BRANCH_ICON_16x16;
/*     */   public static final ImageIcon SPOT_ICON_16x16;
/*     */   
/*     */   static {
/*  57 */     Image image1 = SPOT_ICON.getImage();
/*  58 */     Image newimg1 = image1.getScaledInstance(32, 32, 4);
/*  59 */     SPOT_ICON_64x64 = new ImageIcon(newimg1);
/*     */     
/*  61 */     Image image2 = EDGE_ICON.getImage();
/*  62 */     Image newimg2 = image2.getScaledInstance(32, 32, 4);
/*  63 */     EDGE_ICON_64x64 = new ImageIcon(newimg2);
/*     */     
/*  65 */     Image image3 = TRACK_ICON.getImage();
/*  66 */     Image newimg3 = image3.getScaledInstance(32, 32, 4);
/*  67 */     TRACK_ICON_64x64 = new ImageIcon(newimg3);
/*     */     
/*  69 */     Image image4 = BRANCH_ICON.getImage();
/*  70 */     Image newimg4 = image4.getScaledInstance(16, 16, 4);
/*  71 */     BRANCH_ICON_16x16 = new ImageIcon(newimg4);
/*     */     
/*  73 */     Image image5 = TRACK_SCHEME_ICON.getImage();
/*  74 */     Image newimg5 = image5.getScaledInstance(16, 16, 4);
/*  75 */     TRACK_SCHEME_ICON_16x16 = new ImageIcon(newimg5);
/*     */     
/*  77 */     Image image6 = TRACKMATE_ICON.getImage();
/*  78 */     Image newimg6 = image6.getScaledInstance(16, 16, 4);
/*  79 */     TRACKMATE_ICON_16x16 = new ImageIcon(newimg6);
/*     */     
/*  81 */     Image image7 = EDGE_ICON.getImage();
/*  82 */     Image newimg7 = image7.getScaledInstance(16, 16, 4);
/*  83 */     EDGE_ICON_16x16 = new ImageIcon(newimg7);
/*     */ 
/*     */     
/*  86 */     SPOT_ICON_16x16 = new ImageIcon(Icons.class.getResource("images/spot_icon_16x16.png"));
/*     */     
/*  88 */     TRACK_TABLES_ICON = new ImageIcon(Icons.class.getResource("images/table_multiple.png"));
/*     */     
/*  90 */     SPOT_TABLE_ICON = new ImageIcon(Icons.class.getResource("images/table.png"));
/*     */     
/*  92 */     NEXT_ICON = new ImageIcon(Icons.class.getResource("images/arrow_right.png"));
/*     */     
/*  94 */     PREVIOUS_ICON = new ImageIcon(Icons.class.getResource("images/arrow_left.png"));
/*     */     
/*  96 */     SAVE_ICON = new ImageIcon(Icons.class.getResource("images/page_save.png"));
/*     */     
/*  98 */     LOG_ICON = new ImageIcon(Icons.class.getResource("images/information.png"));
/*     */     
/* 100 */     DISPLAY_CONFIG_ICON = new ImageIcon(Icons.class.getResource("images/wrench_orange.png"));
/*     */     
/* 102 */     CANCEL_ICON = new ImageIcon(Icons.class.getResource("images/cancel.png"));
/*     */     
/* 104 */     EXECUTE_ICON = new ImageIcon(Icons.class.getResource("images/control_play_blue.png"));
/*     */     
/* 106 */     EDIT_SETTINGS_ICON = new ImageIcon(Icons.class.getResource("images/cog_edit.png"));
/*     */     
/* 108 */     COG_ICON = new ImageIcon(Icons.class.getResource("images/cog.png"));
/*     */     
/* 110 */     PLOT_ICON = new ImageIcon(Icons.class.getResource("images/plots.png"));
/*     */     
/* 112 */     ADD_ICON = new ImageIcon(Icons.class.getResource("images/add.png"));
/*     */     
/* 114 */     REMOVE_ICON = new ImageIcon(Icons.class.getResource("images/delete.png"));
/*     */     
/* 116 */     PREVIEW_ICON = new ImageIcon(Icons.class.getResource("images/flag_checked.png"));
/*     */     
/* 118 */     CSV_ICON = new ImageIcon(Icons.class.getResource("images/page_save.png"));
/*     */     
/* 120 */     MAGNIFIER_ICON = new ImageIcon(Icons.class.getResource("images/magnifier.png"));
/*     */     
/* 122 */     ORANGE_ASTERISK_ICON = new ImageIcon(Icons.class.getResource("images/spot_icon.png"));
/*     */     
/* 124 */     CALCULATOR_ICON = new ImageIcon(Icons.class.getResource("images/calculator.png"));
/*     */     
/* 126 */     ICY_ICON = new ImageIcon(Icons.class.getResource("images/icy16.png"));
/*     */     
/* 128 */     ISBI_ICON = new ImageIcon(Icons.class.getResource("images/ISBIlogo.png"));
/*     */     
/* 130 */     LABEL_IMG_ICON = new ImageIcon(Icons.class.getResource("images/picture_key.png"));
/*     */     
/* 132 */     MERGE_ICON = new ImageIcon(Icons.class.getResource("images/arrow_merge.png"));
/*     */     
/* 134 */     TIME_ICON = new ImageIcon(Icons.class.getResource("images/time.png"));
/*     */     
/* 136 */     BIN_ICON = new ImageIcon(Icons.class.getResource("images/bin_empty.png"));
/*     */     
/* 138 */     CAMERA_ICON = new ImageIcon(Icons.class.getResource("images/camera_go.png"));
/*     */     
/* 140 */     APPLY_ICON = new ImageIcon(Icons.class.getResource("images/page_save.png"));
/*     */     
/* 142 */     REVERT_ICON = new ImageIcon(Icons.class.getResource("images/page_refresh.png"));
/*     */     
/* 144 */     RESET_ICON = new ImageIcon(Icons.class.getResource("images/page_white.png"));
/*     */     
/* 146 */     SELECT_TRACK_ICON = new ImageIcon(Icons.class.getResource("images/arrow_updown.png"));
/*     */     
/* 148 */     SELECT_TRACK_ICON_UPWARDS = new ImageIcon(Icons.class.getResource("images/arrow_up.png"));
/*     */     
/* 150 */     SELECT_TRACK_ICON_DOWNWARDS = new ImageIcon(Icons.class.getResource("images/arrow_down.png"));
/*     */     
/* 152 */     CAMERA_EXPORT_ICON = new ImageIcon(Icons.class.getResource("images/camera_export.png"));
/*     */     
/* 154 */     RESET_ZOOM_ICON = new ImageIcon(Icons.class.getResource("images/zoom.png"));
/*     */     
/* 156 */     ZOOM_IN_ICON = new ImageIcon(Icons.class.getResource("images/zoom_in.png"));
/*     */     
/* 158 */     ZOOM_OUT_ICON = new ImageIcon(Icons.class.getResource("images/zoom_out.png"));
/*     */     
/* 160 */     EDIT_ICON = new ImageIcon(Icons.class.getResource("images/tag_blue_edit.png"));
/*     */     
/* 162 */     HOME_ICON = new ImageIcon(Icons.class.getResource("images/control_start.png"));
/*     */     
/* 164 */     END_ICON = new ImageIcon(Icons.class.getResource("images/control_end.png"));
/*     */     
/* 166 */     ARROW_UP_ICON = new ImageIcon(Icons.class.getResource("images/arrow_up.png"));
/*     */     
/* 168 */     ARROW_DOWN_ICON = new ImageIcon(Icons.class.getResource("images/arrow_down.png"));
/*     */     
/* 170 */     ARROW_LEFT_ICON = new ImageIcon(Icons.class.getResource("images/arrow_left.png"));
/*     */     
/* 172 */     ARROW_RIGHT_ICON = new ImageIcon(Icons.class.getResource("images/arrow_right.png"));
/*     */     
/* 174 */     ARROW_UPLEFT_ICON = new ImageIcon(Icons.class.getResource("images/arrow_nw.png"));
/*     */     
/* 176 */     ARROW_DOWNLEFT_ICON = new ImageIcon(Icons.class.getResource("images/arrow_sw.png"));
/*     */     
/* 178 */     ARROW_UPRIGHT_ICON = new ImageIcon(Icons.class.getResource("images/arrow_ne.png"));
/*     */     
/* 180 */     ARROW_DOWNRIGHT_ICON = new ImageIcon(Icons.class.getResource("images/arrow_se.png"));
/*     */     
/* 182 */     LINKING_ON_ICON = new ImageIcon(Icons.class.getResource("images/connect.png"));
/*     */     
/* 184 */     LINKING_OFF_ICON = new ImageIcon(Icons.class.getResource("images/connect_bw.png"));
/*     */     
/* 186 */     THUMBNAIL_ON_ICON = new ImageIcon(Icons.class.getResource("images/images.png"));
/*     */     
/* 188 */     THUMBNAIL_OFF_ICON = new ImageIcon(Icons.class.getResource("images/images_bw.png"));
/*     */     
/* 190 */     REFRESH_ICON = new ImageIcon(Icons.class.getResource("images/refresh.png"));
/*     */     
/* 192 */     CAPTURE_UNDECORATED_ICON = new ImageIcon(Icons.class.getResource("images/camera_go.png"));
/*     */     
/* 194 */     CAPTURE_DECORATED_ICON = new ImageIcon(Icons.class.getResource("images/camera_edit.png"));
/*     */     
/* 196 */     DISPLAY_DECORATIONS_ON_ICON = new ImageIcon(Icons.class.getResource("images/application_view_columns.png"));
/*     */     
/* 198 */     SELECT_STYLE_ICON = new ImageIcon(Icons.class.getResource("images/theme.png"));
/*     */   }
/*     */   
/*     */   public static final ImageIcon TRACK_TABLES_ICON;
/*     */   public static final ImageIcon SPOT_TABLE_ICON;
/*     */   public static final ImageIcon NEXT_ICON;
/*     */   public static final ImageIcon PREVIOUS_ICON;
/*     */   public static final ImageIcon SAVE_ICON;
/*     */   public static final ImageIcon LOG_ICON;
/*     */   public static final ImageIcon DISPLAY_CONFIG_ICON;
/*     */   public static final ImageIcon CANCEL_ICON;
/*     */   public static final ImageIcon EXECUTE_ICON;
/*     */   public static final ImageIcon EDIT_SETTINGS_ICON;
/*     */   public static final ImageIcon COG_ICON;
/*     */   public static final ImageIcon PLOT_ICON;
/*     */   public static final ImageIcon ADD_ICON;
/*     */   public static final ImageIcon REMOVE_ICON;
/*     */   public static final ImageIcon PREVIEW_ICON;
/*     */   public static final ImageIcon CSV_ICON;
/*     */   public static final ImageIcon MAGNIFIER_ICON;
/*     */   public static final ImageIcon ORANGE_ASTERISK_ICON;
/*     */   public static final ImageIcon CALCULATOR_ICON;
/*     */   public static final ImageIcon ICY_ICON;
/*     */   public static final ImageIcon ISBI_ICON;
/*     */   public static final ImageIcon LABEL_IMG_ICON;
/*     */   public static final ImageIcon MERGE_ICON;
/*     */   public static final ImageIcon TIME_ICON;
/*     */   public static final ImageIcon BIN_ICON;
/*     */   public static final ImageIcon CAMERA_ICON;
/*     */   public static final ImageIcon APPLY_ICON;
/*     */   public static final ImageIcon REVERT_ICON;
/*     */   public static final ImageIcon RESET_ICON;
/*     */   public static final ImageIcon SELECT_TRACK_ICON;
/*     */   public static final ImageIcon SELECT_TRACK_ICON_UPWARDS;
/*     */   public static final ImageIcon SELECT_TRACK_ICON_DOWNWARDS;
/*     */   public static final ImageIcon CAMERA_EXPORT_ICON;
/*     */   public static final ImageIcon RESET_ZOOM_ICON;
/*     */   public static final ImageIcon ZOOM_IN_ICON;
/*     */   public static final ImageIcon ZOOM_OUT_ICON;
/*     */   public static final ImageIcon EDIT_ICON;
/*     */   public static final ImageIcon HOME_ICON;
/*     */   public static final ImageIcon END_ICON;
/*     */   public static final ImageIcon ARROW_UP_ICON;
/*     */   public static final ImageIcon ARROW_DOWN_ICON;
/*     */   public static final ImageIcon ARROW_LEFT_ICON;
/*     */   public static final ImageIcon ARROW_RIGHT_ICON;
/*     */   public static final ImageIcon ARROW_UPLEFT_ICON;
/*     */   public static final ImageIcon ARROW_DOWNLEFT_ICON;
/*     */   public static final ImageIcon ARROW_UPRIGHT_ICON;
/*     */   public static final ImageIcon ARROW_DOWNRIGHT_ICON;
/*     */   public static final ImageIcon LINKING_ON_ICON;
/*     */   public static final ImageIcon LINKING_OFF_ICON;
/*     */   public static final ImageIcon THUMBNAIL_ON_ICON;
/*     */   public static final ImageIcon THUMBNAIL_OFF_ICON;
/*     */   public static final ImageIcon REFRESH_ICON;
/*     */   public static final ImageIcon CAPTURE_UNDECORATED_ICON;
/*     */   public static final ImageIcon CAPTURE_DECORATED_ICON;
/*     */   public static final ImageIcon DISPLAY_DECORATIONS_ON_ICON;
/*     */   public static final ImageIcon SELECT_STYLE_ICON;
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/gui/Icons.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */