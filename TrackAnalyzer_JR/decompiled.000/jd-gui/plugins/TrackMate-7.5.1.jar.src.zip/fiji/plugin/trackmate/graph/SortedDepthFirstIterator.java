/*     */ package fiji.plugin.trackmate.graph;
/*     */ 
/*     */ import java.util.ArrayDeque;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.Deque;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.NoSuchElementException;
/*     */ import java.util.Set;
/*     */ import org.jgrapht.Graph;
/*     */ import org.jgrapht.Graphs;
/*     */ import org.jgrapht.event.ConnectedComponentTraversalEvent;
/*     */ import org.jgrapht.traverse.AbstractGraphIterator;
/*     */ import org.jgrapht.util.TypeUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SortedDepthFirstIterator<V, E>
/*     */   extends AbstractGraphIterator<V, E>
/*     */ {
/*     */   private static final int CCS_BEFORE_COMPONENT = 1;
/*     */   private static final int CCS_WITHIN_COMPONENT = 2;
/*     */   private static final int CCS_AFTER_COMPONENT = 3;
/*  72 */   private static final Object SENTINEL = new Object();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private enum VisitColor
/*     */   {
/*  82 */     WHITE,
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  88 */     GRAY,
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  94 */     BLACK;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 100 */   private final Deque<Object> stack = new ArrayDeque();
/*     */   
/* 102 */   private final ConnectedComponentTraversalEvent ccFinishedEvent = new ConnectedComponentTraversalEvent(this, 32);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 107 */   private final ConnectedComponentTraversalEvent ccStartedEvent = new ConnectedComponentTraversalEvent(this, 31);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 112 */   private Iterator<V> vertexIterator = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 118 */   protected Map<V, VisitColor> seen = new HashMap<>();
/*     */ 
/*     */   
/*     */   private V startVertex;
/*     */   
/*     */   protected Specifics<V, E> specifics;
/*     */   
/*     */   protected final Comparator<V> comparator;
/*     */   
/* 127 */   private int state = 1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SortedDepthFirstIterator(Graph<V, E> g, V startVertex, Comparator<V> comparator) {
/* 148 */     super(g);
/* 149 */     this.comparator = comparator;
/*     */     
/* 151 */     this.specifics = createGraphSpecifics(g);
/* 152 */     this.vertexIterator = g.vertexSet().iterator();
/* 153 */     setCrossComponentTraversal((startVertex == null));
/*     */     
/* 155 */     if (startVertex == null) {
/*     */ 
/*     */       
/* 158 */       if (this.vertexIterator.hasNext())
/*     */       {
/* 160 */         this.startVertex = this.vertexIterator.next();
/*     */       }
/*     */       else
/*     */       {
/* 164 */         this.startVertex = null;
/*     */       }
/*     */     
/* 167 */     } else if (g.containsVertex(startVertex)) {
/*     */       
/* 169 */       this.startVertex = startVertex;
/*     */     }
/*     */     else {
/*     */       
/* 173 */       throw new IllegalArgumentException("graph must contain the start vertex");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasNext() {
/* 187 */     if (this.startVertex != null)
/*     */     {
/* 189 */       encounterStartVertex();
/*     */     }
/*     */     
/* 192 */     if (isConnectedComponentExhausted()) {
/*     */       
/* 194 */       if (this.state == 2) {
/*     */         
/* 196 */         this.state = 3;
/* 197 */         if (this.nListeners != 0)
/*     */         {
/* 199 */           fireConnectedComponentFinished(this.ccFinishedEvent);
/*     */         }
/*     */       } 
/*     */       
/* 203 */       if (isCrossComponentTraversal()) {
/*     */         
/* 205 */         while (this.vertexIterator.hasNext()) {
/*     */           
/* 207 */           V v = this.vertexIterator.next();
/*     */           
/* 209 */           if (!this.seen.containsKey(v)) {
/*     */             
/* 211 */             encounterVertex(v, (E)null);
/* 212 */             this.state = 1;
/*     */             
/* 214 */             return true;
/*     */           } 
/*     */         } 
/*     */         
/* 218 */         return false;
/*     */       } 
/* 220 */       return false;
/*     */     } 
/* 222 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public V next() {
/* 232 */     if (this.startVertex != null)
/*     */     {
/* 234 */       encounterStartVertex();
/*     */     }
/*     */     
/* 237 */     if (hasNext()) {
/*     */       
/* 239 */       if (this.state == 1) {
/*     */         
/* 241 */         this.state = 2;
/* 242 */         if (this.nListeners != 0)
/*     */         {
/* 244 */           fireConnectedComponentStarted(this.ccStartedEvent);
/*     */         }
/*     */       } 
/*     */       
/* 248 */       V nextVertex = provideNextVertex();
/* 249 */       if (this.nListeners != 0)
/*     */       {
/* 251 */         fireVertexTraversed(createVertexTraversalEvent(nextVertex));
/*     */       }
/*     */       
/* 254 */       addUnseenChildrenOf(nextVertex);
/*     */       
/* 256 */       return nextVertex;
/*     */     } 
/* 258 */     throw new NoSuchElementException();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void finishVertex(V vertex) {
/* 270 */     if (this.nListeners != 0)
/*     */     {
/* 272 */       fireVertexFinished(createVertexTraversalEvent(vertex));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static <V, E> Specifics<V, E> createGraphSpecifics(Graph<V, E> g) {
/* 280 */     if (g.getType().isDirected()) {
/* 281 */       return new DirectedSpecifics<>(g);
/*     */     }
/* 283 */     return new UndirectedSpecifics<>(g);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void addUnseenChildrenOf(V vertex) {
/* 293 */     List<V> sortedChildren = new ArrayList<>();
/*     */ 
/*     */     
/* 296 */     Map<V, E> localEdges = new HashMap<>();
/*     */     
/* 298 */     for (E edge : this.specifics.edgesOf(vertex)) {
/*     */       
/* 300 */       V oppositeV = (V)Graphs.getOppositeVertex(this.graph, edge, vertex);
/* 301 */       if (!this.seen.containsKey(oppositeV))
/*     */       {
/* 303 */         sortedChildren.add(oppositeV);
/*     */       }
/* 305 */       localEdges.put(oppositeV, edge);
/*     */     } 
/* 307 */     Collections.sort(sortedChildren, Collections.reverseOrder(this.comparator));
/*     */     
/* 309 */     Iterator<V> it = sortedChildren.iterator();
/* 310 */     while (it.hasNext()) {
/*     */       
/* 312 */       V child = it.next();
/*     */       
/* 314 */       if (this.nListeners != 0)
/*     */       {
/* 316 */         fireEdgeTraversed(createEdgeTraversalEvent(localEdges.get(child)));
/*     */       }
/*     */       
/* 319 */       if (this.seen.containsKey(child)) {
/*     */         
/* 321 */         encounterVertexAgain(child, localEdges.get(child));
/*     */         
/*     */         continue;
/*     */       } 
/* 325 */       encounterVertex(child, localEdges.get(child));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void encounterStartVertex() {
/* 332 */     encounterVertex(this.startVertex, (E)null);
/* 333 */     this.startVertex = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isConnectedComponentExhausted() {
/*     */     while (true) {
/* 343 */       if (this.stack.isEmpty()) return true; 
/* 344 */       if (this.stack.getLast() != SENTINEL)
/*     */       {
/*     */         
/* 347 */         return false;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 354 */       this.stack.removeLast();
/*     */ 
/*     */       
/* 357 */       recordFinish();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void encounterVertex(V vertex, E edge) {
/* 366 */     this.seen.put(vertex, VisitColor.WHITE);
/* 367 */     this.stack.addLast(vertex);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void encounterVertexAgain(V vertex, E edge) {
/* 375 */     VisitColor color = this.seen.get(vertex);
/* 376 */     if (color != VisitColor.WHITE) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 389 */     boolean found = this.stack.removeLastOccurrence(vertex);
/* 390 */     assert found;
/* 391 */     this.stack.addLast(vertex);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private V provideNextVertex() {
/*     */     Object o;
/*     */     while (true) {
/* 399 */       o = this.stack.removeLast();
/* 400 */       if (o == SENTINEL) {
/*     */ 
/*     */         
/* 403 */         recordFinish();
/*     */         
/*     */         continue;
/*     */       } 
/*     */       break;
/*     */     } 
/* 409 */     V v = (V)TypeUtil.uncheckedCast(o);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 416 */     this.stack.addLast(v);
/* 417 */     this.stack.addLast(SENTINEL);
/* 418 */     this.seen.put(v, VisitColor.GRAY);
/* 419 */     return v;
/*     */   }
/*     */ 
/*     */   
/*     */   private void recordFinish() {
/* 424 */     V v = (V)TypeUtil.uncheckedCast(this.stack.removeLast());
/* 425 */     this.seen.put(v, VisitColor.BLACK);
/* 426 */     finishVertex(v);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static abstract class Specifics<VV, EE>
/*     */   {
/*     */     public abstract Set<? extends EE> edgesOf(VV param1VV);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class DirectedSpecifics<VV, EE>
/*     */     extends Specifics<VV, EE>
/*     */   {
/*     */     private final Graph<VV, EE> graph;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public DirectedSpecifics(Graph<VV, EE> g) {
/* 465 */       this.graph = g;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Set<? extends EE> edgesOf(VV vertex) {
/* 471 */       return this.graph.outgoingEdgesOf(vertex);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class UndirectedSpecifics<VV, EE>
/*     */     extends Specifics<VV, EE>
/*     */   {
/*     */     private final Graph<VV, EE> graph;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public UndirectedSpecifics(Graph<VV, EE> g) {
/* 487 */       this.graph = g;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Set<EE> edgesOf(VV vertex) {
/* 493 */       return this.graph.edgesOf(vertex);
/*     */     }
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/graph/SortedDepthFirstIterator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */