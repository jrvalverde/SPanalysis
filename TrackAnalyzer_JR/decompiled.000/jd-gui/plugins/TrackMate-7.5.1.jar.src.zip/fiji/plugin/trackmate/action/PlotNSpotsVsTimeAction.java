/*     */ package fiji.plugin.trackmate.action;
/*     */ 
/*     */ import fiji.plugin.trackmate.Dimension;
/*     */ import fiji.plugin.trackmate.Model;
/*     */ import fiji.plugin.trackmate.SelectionModel;
/*     */ import fiji.plugin.trackmate.Settings;
/*     */ import fiji.plugin.trackmate.SpotCollection;
/*     */ import fiji.plugin.trackmate.TrackMate;
/*     */ import fiji.plugin.trackmate.features.AbstractFeatureGrapher;
/*     */ import fiji.plugin.trackmate.features.ModelDataset;
/*     */ import fiji.plugin.trackmate.gui.GuiUtils;
/*     */ import fiji.plugin.trackmate.gui.Icons;
/*     */ import fiji.plugin.trackmate.gui.displaysettings.DisplaySettings;
/*     */ import java.awt.Frame;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.swing.ImageIcon;
/*     */ import javax.swing.JFrame;
/*     */ import javax.swing.SwingUtilities;
/*     */ import org.jfree.chart.renderer.xy.XYItemRenderer;
/*     */ import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
/*     */ import org.scijava.plugin.Plugin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PlotNSpotsVsTimeAction
/*     */   extends AbstractTMAction
/*     */ {
/*     */   public static final String NAME = "Plot N spots vs time";
/*     */   public static final String KEY = "PLOT_NSPOTS_VS_TIME";
/*     */   public static final String INFO_TEXT = "<html>Plot the number of spots in each frame as a function <br>of time. Only the filtered spots are taken into account. </html>";
/*     */   
/*     */   public void execute(TrackMate trackmate, SelectionModel selectionModel, DisplaySettings displaySettings, Frame parent) {
/*  73 */     Model model = trackmate.getModel();
/*  74 */     Settings settings = trackmate.getSettings();
/*  75 */     SpotCollection spots = model.getSpots();
/*     */     
/*  77 */     int maxFrame = spots.keySet().stream().mapToInt(Integer::intValue).max().getAsInt();
/*  78 */     int[] nSpots = new int[maxFrame + 1];
/*  79 */     double[] time = new double[maxFrame + 1];
/*     */     
/*  81 */     for (int frame = 0; frame <= maxFrame; frame++) {
/*     */       
/*  83 */       nSpots[frame] = spots.getNSpots(frame, true);
/*  84 */       time[frame] = frame * settings.dt;
/*     */     } 
/*  86 */     NSpotPerFrameDataset dataset = new NSpotPerFrameDataset(model, selectionModel, displaySettings, time, nSpots);
/*  87 */     String yFeature = "N spots";
/*  88 */     Map<String, Dimension> dimMap = new HashMap<>(2);
/*  89 */     dimMap.put("N spots", Dimension.NONE);
/*  90 */     dimMap.put("POSITION_T", Dimension.TIME);
/*  91 */     Map<String, String> nameMap = new HashMap<>(2);
/*  92 */     nameMap.put("N spots", "N spots");
/*  93 */     nameMap.put("POSITION_T", "T");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 102 */     NSpotPerFrameGrapher grapher = new NSpotPerFrameGrapher("POSITION_T", Collections.singletonList("N spots"), Dimension.TIME, dimMap, nameMap, model.getSpaceUnits(), model.getTimeUnits(), dataset);
/*     */     
/* 104 */     JFrame jFrame = grapher.render();
/* 105 */     jFrame.setIconImage(Icons.PLOT_ICON.getImage());
/* 106 */     jFrame.setTitle("N spots per time-point");
/* 107 */     GuiUtils.positionWindow(jFrame, SwingUtilities.getWindowAncestor(parent));
/* 108 */     jFrame.setVisible(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class NSpotPerFrameGrapher
/*     */     extends AbstractFeatureGrapher
/*     */   {
/*     */     private final PlotNSpotsVsTimeAction.NSpotPerFrameDataset dataset;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public NSpotPerFrameGrapher(String xFeature, List<String> yFeatures, Dimension xDimension, Map<String, Dimension> yDimensions, Map<String, String> featureNames, String spaceUnits, String timeUnits, PlotNSpotsVsTimeAction.NSpotPerFrameDataset dataset) {
/* 126 */       super(xFeature, yFeatures, xDimension, yDimensions, featureNames, spaceUnits, timeUnits);
/* 127 */       this.dataset = dataset;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     protected ModelDataset buildMainDataSet(List<String> targetYFeatures) {
/* 133 */       return this.dataset;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class NSpotPerFrameDataset
/*     */     extends ModelDataset
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */ 
/*     */     
/*     */     private final double[] time;
/*     */ 
/*     */     
/*     */     private final int[] nspots;
/*     */ 
/*     */ 
/*     */     
/*     */     public NSpotPerFrameDataset(Model model, SelectionModel selectionModel, DisplaySettings ds, double[] time, int[] nspots) {
/* 153 */       super(model, selectionModel, ds, "POSITION_T", Collections.singletonList("N spots"));
/* 154 */       this.time = time;
/* 155 */       this.nspots = nspots;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public int getItemCount(int series) {
/* 161 */       return this.nspots.length;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Number getX(int series, int item) {
/* 167 */       return Double.valueOf(this.time[item]);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Number getY(int series, int item) {
/* 173 */       return Double.valueOf(this.nspots[item]);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public String getSeriesKey(int series) {
/* 179 */       return this.yFeatures.get(series);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public String getItemLabel(int item) {
/* 185 */       return "" + item;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void setItemLabel(int item, String label) {}
/*     */ 
/*     */ 
/*     */     
/*     */     public XYItemRenderer getRenderer() {
/* 195 */       return (XYItemRenderer)new XYLineAndShapeRenderer(true, true);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Plugin(type = TrackMateActionFactory.class)
/*     */   public static class Factory
/*     */     implements TrackMateActionFactory
/*     */   {
/*     */     public String getInfoText() {
/* 206 */       return "<html>Plot the number of spots in each frame as a function <br>of time. Only the filtered spots are taken into account. </html>";
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public String getName() {
/* 212 */       return "Plot N spots vs time";
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public String getKey() {
/* 218 */       return "PLOT_NSPOTS_VS_TIME";
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public ImageIcon getIcon() {
/* 224 */       return Icons.PLOT_ICON;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public TrackMateAction create() {
/* 230 */       return new PlotNSpotsVsTimeAction();
/*     */     }
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/action/PlotNSpotsVsTimeAction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */