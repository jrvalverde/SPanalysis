/*     */ package fiji.plugin.trackmate.gui.components.tracker;
/*     */ 
/*     */ import fiji.plugin.trackmate.gui.Fonts;
/*     */ import fiji.plugin.trackmate.gui.GuiUtils;
/*     */ import fiji.plugin.trackmate.gui.components.ConfigurationPanel;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import javax.swing.JFormattedTextField;
/*     */ import javax.swing.JLabel;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class KalmanTrackerConfigPanel
/*     */   extends ConfigurationPanel
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private final JFormattedTextField tfInitSearchRadius;
/*     */   private final JFormattedTextField tfSearchRadius;
/*     */   private final JFormattedTextField tfMaxFrameGap;
/*     */   
/*     */   public KalmanTrackerConfigPanel(String trackerName, String infoText, String spaceUnits) {
/*  54 */     setLayout(null);
/*     */     
/*  56 */     JLabel lbl1 = new JLabel("Settings for tracker:");
/*  57 */     lbl1.setBounds(6, 6, 288, 16);
/*  58 */     lbl1.setFont(Fonts.FONT);
/*  59 */     add(lbl1);
/*     */     
/*  61 */     JLabel lblTrackerName = new JLabel(trackerName);
/*  62 */     lblTrackerName.setFont(Fonts.BIG_FONT);
/*  63 */     lblTrackerName.setHorizontalAlignment(0);
/*  64 */     lblTrackerName.setBounds(6, 34, 288, 32);
/*  65 */     add(lblTrackerName);
/*     */     
/*  67 */     JLabel lblTrackerDescription = new JLabel("<tracker description>");
/*  68 */     lblTrackerDescription.setFont(Fonts.FONT.deriveFont(2));
/*  69 */     lblTrackerDescription.setVerticalAlignment(1);
/*  70 */     lblTrackerDescription.setBounds(6, 81, 288, 175);
/*  71 */     lblTrackerDescription.setText(infoText
/*  72 */         .replace("<br>", "")
/*  73 */         .replace("<p>", "<p align=\"justify\">")
/*  74 */         .replace("<html>", "<html><p align=\"justify\">"));
/*  75 */     add(lblTrackerDescription);
/*     */     
/*  77 */     JLabel lblInitSearchRadius = new JLabel("Initial search radius:");
/*  78 */     lblInitSearchRadius.setFont(Fonts.FONT);
/*  79 */     lblInitSearchRadius.setBounds(6, 348, 173, 16);
/*  80 */     add(lblInitSearchRadius);
/*     */     
/*  82 */     JLabel lblSearchRadius = new JLabel("Search radius:");
/*  83 */     lblSearchRadius.setFont(Fonts.FONT);
/*  84 */     lblSearchRadius.setBounds(6, 376, 173, 16);
/*  85 */     add(lblSearchRadius);
/*     */     
/*  87 */     JLabel lblMaxFrameGap = new JLabel("Max frame gap:");
/*  88 */     lblMaxFrameGap.setFont(Fonts.FONT);
/*  89 */     lblMaxFrameGap.setBounds(6, 404, 173, 16);
/*  90 */     add(lblMaxFrameGap);
/*     */     
/*  92 */     this.tfInitSearchRadius = new JFormattedTextField(Double.valueOf(15.0D));
/*  93 */     this.tfInitSearchRadius.setHorizontalAlignment(0);
/*  94 */     this.tfInitSearchRadius.setFont(Fonts.FONT);
/*  95 */     this.tfInitSearchRadius.setBounds(167, 348, 60, 28);
/*  96 */     add(this.tfInitSearchRadius);
/*  97 */     this.tfInitSearchRadius.setSize(Fonts.TEXTFIELD_DIMENSION);
/*     */     
/*  99 */     this.tfSearchRadius = new JFormattedTextField(Double.valueOf(15.0D));
/* 100 */     this.tfSearchRadius.setHorizontalAlignment(0);
/* 101 */     this.tfSearchRadius.setFont(Fonts.FONT);
/* 102 */     this.tfSearchRadius.setBounds(167, 376, 60, 28);
/* 103 */     add(this.tfSearchRadius);
/* 104 */     this.tfSearchRadius.setSize(Fonts.TEXTFIELD_DIMENSION);
/*     */     
/* 106 */     this.tfMaxFrameGap = new JFormattedTextField(Integer.valueOf(2));
/* 107 */     this.tfMaxFrameGap.setHorizontalAlignment(0);
/* 108 */     this.tfMaxFrameGap.setFont(Fonts.FONT);
/* 109 */     this.tfMaxFrameGap.setBounds(167, 404, 60, 28);
/* 110 */     add(this.tfMaxFrameGap);
/* 111 */     this.tfMaxFrameGap.setSize(Fonts.TEXTFIELD_DIMENSION);
/*     */     
/* 113 */     JLabel lblSpaceUnits1 = new JLabel(spaceUnits);
/* 114 */     lblSpaceUnits1.setFont(Fonts.FONT);
/* 115 */     lblSpaceUnits1.setBounds(219, 348, 51, 16);
/* 116 */     add(lblSpaceUnits1);
/*     */     
/* 118 */     JLabel lblSpaceUnits2 = new JLabel(spaceUnits);
/* 119 */     lblSpaceUnits2.setFont(Fonts.FONT);
/* 120 */     lblSpaceUnits2.setBounds(219, 376, 51, 16);
/* 121 */     add(lblSpaceUnits2);
/*     */     
/* 123 */     JLabel lblFrameUnits = new JLabel("frames");
/* 124 */     lblFrameUnits.setFont(Fonts.FONT);
/* 125 */     lblFrameUnits.setBounds(219, 404, 51, 16);
/* 126 */     add(lblFrameUnits);
/*     */ 
/*     */     
/* 129 */     GuiUtils.selectAllOnFocus(this.tfInitSearchRadius);
/* 130 */     GuiUtils.selectAllOnFocus(this.tfMaxFrameGap);
/* 131 */     GuiUtils.selectAllOnFocus(this.tfSearchRadius);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSettings(Map<String, Object> settings) {
/* 137 */     this.tfInitSearchRadius.setValue(settings.get("LINKING_MAX_DISTANCE"));
/* 138 */     this.tfSearchRadius.setValue(settings.get("KALMAN_SEARCH_RADIUS"));
/* 139 */     this.tfMaxFrameGap.setValue(settings.get("MAX_FRAME_GAP"));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, Object> getSettings() {
/* 145 */     Map<String, Object> settings = new HashMap<>();
/* 146 */     settings.put("LINKING_MAX_DISTANCE", Double.valueOf(((Number)this.tfInitSearchRadius.getValue()).doubleValue()));
/* 147 */     settings.put("KALMAN_SEARCH_RADIUS", Double.valueOf(((Number)this.tfSearchRadius.getValue()).doubleValue()));
/* 148 */     settings.put("MAX_FRAME_GAP", Integer.valueOf(((Number)this.tfMaxFrameGap.getValue()).intValue()));
/* 149 */     return settings;
/*     */   }
/*     */   
/*     */   public void clean() {}
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/gui/components/tracker/KalmanTrackerConfigPanel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */