/*     */ package fiji.plugin.trackmate.gui.wizard.descriptors;
/*     */ 
/*     */ import fiji.plugin.trackmate.Logger;
/*     */ import fiji.plugin.trackmate.TrackMate;
/*     */ import fiji.plugin.trackmate.gui.components.LogPanel;
/*     */ import fiji.plugin.trackmate.gui.displaysettings.DisplaySettings;
/*     */ import fiji.plugin.trackmate.gui.wizard.WizardSequence;
/*     */ import fiji.plugin.trackmate.io.IOUtils;
/*     */ import fiji.plugin.trackmate.io.TmXmlWriter;
/*     */ import fiji.plugin.trackmate.util.TMUtils;
/*     */ import java.awt.Component;
/*     */ import java.awt.Frame;
/*     */ import java.io.File;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import javax.swing.SwingUtilities;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SaveDescriptor
/*     */   extends SomeDialogDescriptor
/*     */ {
/*     */   private static final String KEY = "Saving";
/*     */   private final TrackMate trackmate;
/*     */   private final DisplaySettings displaySettings;
/*     */   private final WizardSequence sequence;
/*     */   
/*     */   public SaveDescriptor(TrackMate trackmate, DisplaySettings displaySettings, WizardSequence sequence) {
/*  53 */     super("Saving", (LogPanel)sequence.logDescriptor().getPanelComponent());
/*  54 */     this.trackmate = trackmate;
/*  55 */     this.displaySettings = displaySettings;
/*  56 */     this.sequence = sequence;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void displayingPanel() {
/*  62 */     LogPanel logPanel = (LogPanel)this.targetPanel;
/*  63 */     Logger logger = logPanel.getLogger();
/*  64 */     logger.log("Saving data...\n", Logger.BLUE_COLOR);
/*  65 */     if (null == file) {
/*  66 */       file = TMUtils.proposeTrackMateSaveFile(this.trackmate.getSettings(), logger);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  72 */     if (this.trackmate.getModel().getTrackModel().nTracks(false) > 0) {
/*     */       
/*  74 */       this.trackmate.computeEdgeFeatures(true);
/*  75 */       this.trackmate.computeTrackFeatures(true);
/*     */     } 
/*     */     
/*  78 */     File tmpFile = IOUtils.askForFileForSaving(file, (Frame)SwingUtilities.getWindowAncestor((Component)logPanel), logger);
/*  79 */     if (null == tmpFile)
/*     */       return; 
/*  81 */     file = tmpFile;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  87 */     TmXmlWriter writer = new TmXmlWriter(file, logger);
/*     */     
/*  89 */     writer.appendLog(logPanel.getTextContent());
/*  90 */     writer.appendModel(this.trackmate.getModel());
/*  91 */     writer.appendSettings(this.trackmate.getSettings());
/*  92 */     writer.appendGUIState(this.sequence.current().getPanelDescriptorIdentifier());
/*  93 */     writer.appendDisplaySettings(this.displaySettings);
/*     */ 
/*     */     
/*     */     try {
/*  97 */       writer.writeToFile();
/*  98 */       logger.log("Data saved to: " + file.toString() + '\n');
/*     */     }
/* 100 */     catch (FileNotFoundException e) {
/*     */       
/* 102 */       logger.error("File not found:\n" + e.getMessage() + '\n');
/*     */       
/*     */       return;
/* 105 */     } catch (IOException e) {
/*     */       
/* 107 */       logger.error("Input/Output error:\n" + e.getMessage() + '\n');
/*     */       return;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/gui/wizard/descriptors/SaveDescriptor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */