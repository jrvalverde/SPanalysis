/*     */ package fiji.plugin.trackmate.gui.components;
/*     */ 
/*     */ import fiji.plugin.trackmate.gui.Fonts;
/*     */ import fiji.plugin.trackmate.gui.Icons;
/*     */ import fiji.plugin.trackmate.util.TMUtils;
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.Component;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.LayoutManager;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Stack;
/*     */ import javax.swing.Box;
/*     */ import javax.swing.BoxLayout;
/*     */ import javax.swing.ComboBoxModel;
/*     */ import javax.swing.DefaultComboBoxModel;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JComboBox;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JScrollPane;
/*     */ import javax.swing.border.Border;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FeaturePlotSelectionPanel
/*     */   extends JPanel
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  72 */   private static final Dimension BUTTON_SIZE = new Dimension(24, 24);
/*  73 */   private static final Dimension COMBO_BOX_MAX_SIZE = new Dimension(220, 22);
/*     */   
/*     */   private static final int MAX_FEATURE_ALLOWED = 10;
/*     */   
/*     */   private final JPanel panelYFeatures;
/*     */   
/*     */   private final JComboBox<String> cmbboxXFeature;
/*  80 */   private final Stack<JComboBox<String>> comboBoxes = new Stack<>();
/*     */   
/*  82 */   private final Stack<Component> struts = new Stack<>();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private List<String> features;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Map<String, String> featureNames;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FeaturePlotSelectionPanel(String xKey, String yKey, Collection<String> features, Map<String, String> featureNames, PlotAction plotAction) {
/*  99 */     this.features = new ArrayList<>(features);
/* 100 */     this.featureNames = featureNames;
/*     */     
/* 102 */     setPreferredSize(new Dimension(300, 450));
/* 103 */     setLayout(new BorderLayout(0, 0));
/* 104 */     JPanel topPanel = new JPanel();
/* 105 */     topPanel.setPreferredSize(new Dimension(300, 180));
/* 106 */     topPanel.setMinimumSize(new Dimension(300, 100));
/* 107 */     add(topPanel, "North");
/* 108 */     topPanel.setLayout((LayoutManager)null);
/* 109 */     JButton plotButton = new JButton("Plot features", Icons.PLOT_ICON);
/* 110 */     plotButton.setBounds(80, 27, 140, 40);
/* 111 */     topPanel.add(plotButton);
/* 112 */     plotButton.setFont(Fonts.FONT.deriveFont(1));
/*     */     
/* 114 */     JLabel jLabelXFeature = new JLabel();
/* 115 */     jLabelXFeature.setBounds(10, 93, 170, 13);
/* 116 */     topPanel.add(jLabelXFeature);
/* 117 */     jLabelXFeature.setText("Feature for X axis:");
/* 118 */     jLabelXFeature.setFont(Fonts.FONT.deriveFont(12));
/*     */ 
/*     */     
/* 121 */     ComboBoxModel<String> cmbboxXFeatureModel = new DefaultComboBoxModel<>((String[])TMUtils.getArrayFromMaping(features, featureNames).toArray((Object[])new String[0]));
/* 122 */     this.cmbboxXFeature = new JComboBox<>();
/* 123 */     this.cmbboxXFeature.setBounds(30, 117, COMBO_BOX_MAX_SIZE.width, COMBO_BOX_MAX_SIZE.height);
/* 124 */     topPanel.add(this.cmbboxXFeature);
/* 125 */     this.cmbboxXFeature.setModel(cmbboxXFeatureModel);
/* 126 */     this.cmbboxXFeature.setFont(Fonts.FONT);
/* 127 */     this.cmbboxXFeature.setSelectedItem(xKey);
/*     */     
/* 129 */     JLabel lblYFeatures = new JLabel();
/* 130 */     lblYFeatures.setBounds(10, 149, 280, 20);
/* 131 */     topPanel.add(lblYFeatures);
/* 132 */     lblYFeatures.setPreferredSize(new Dimension(250, 20));
/* 133 */     lblYFeatures.setText("Features for Y axis:");
/* 134 */     lblYFeatures.setFont(Fonts.FONT.deriveFont(12));
/*     */     
/* 136 */     JPanel centerPanel = new JPanel();
/* 137 */     centerPanel.setBorder((Border)null);
/* 138 */     add(centerPanel, "Center");
/* 139 */     centerPanel.setLayout(new BorderLayout(0, 0));
/*     */     
/* 141 */     JScrollPane scrlpnYFeatures = new JScrollPane();
/* 142 */     scrlpnYFeatures.setBorder((Border)null);
/* 143 */     centerPanel.add(scrlpnYFeatures);
/* 144 */     scrlpnYFeatures.setPreferredSize(new Dimension(169, 137));
/* 145 */     scrlpnYFeatures.setHorizontalScrollBarPolicy(31);
/*     */     
/* 147 */     this.panelYFeatures = new JPanel();
/* 148 */     this.panelYFeatures.setBorder((Border)null);
/* 149 */     this.panelYFeatures.setLayout(new BoxLayout(this.panelYFeatures, 1));
/* 150 */     scrlpnYFeatures.setViewportView(this.panelYFeatures);
/*     */     
/* 152 */     JPanel panelButtons = new JPanel();
/* 153 */     panelButtons.setPreferredSize(new Dimension(250, 50));
/* 154 */     BoxLayout jPanelButtonsLayout = new BoxLayout(panelButtons, 0);
/* 155 */     panelButtons.setLayout(jPanelButtonsLayout);
/* 156 */     add(panelButtons, "South");
/*     */     
/* 158 */     JButton btnAdd = new JButton();
/* 159 */     panelButtons.add(btnAdd);
/* 160 */     btnAdd.setIcon(Icons.ADD_ICON);
/* 161 */     btnAdd.setMaximumSize(BUTTON_SIZE);
/* 162 */     btnAdd.addActionListener(e -> addFeature());
/*     */     
/* 164 */     JButton btnRemove = new JButton();
/* 165 */     panelButtons.add(btnRemove);
/* 166 */     btnRemove.setIcon(Icons.REMOVE_ICON);
/* 167 */     btnRemove.setMaximumSize(BUTTON_SIZE);
/* 168 */     btnRemove.addActionListener(e -> removeFeature());
/*     */ 
/*     */     
/* 171 */     ComboBoxModel<String> jComboBoxYFeatureModel = new DefaultComboBoxModel<>((String[])TMUtils.getArrayFromMaping(features, featureNames).toArray((Object[])new String[0]));
/* 172 */     JComboBox<String> cmbboxYFeature = new JComboBox<>();
/* 173 */     cmbboxYFeature.setModel(jComboBoxYFeatureModel);
/* 174 */     cmbboxYFeature.setPreferredSize(COMBO_BOX_MAX_SIZE);
/* 175 */     cmbboxYFeature.setMaximumSize(COMBO_BOX_MAX_SIZE);
/* 176 */     cmbboxYFeature.setFont(Fonts.FONT);
/*     */ 
/*     */     
/* 179 */     addFeature(yKey);
/*     */ 
/*     */     
/* 182 */     plotButton.addActionListener(e -> {
/*     */           String sKey = this.features.get(this.cmbboxXFeature.getSelectedIndex());
/*     */           List<String> yKeys = new ArrayList<>(this.comboBoxes.size());
/*     */           for (JComboBox<String> box : this.comboBoxes) {
/*     */             yKeys.add(this.features.get(box.getSelectedIndex()));
/*     */           }
/*     */           plotAction.plot(sKey, yKeys);
/*     */         });
/*     */   }
/*     */ 
/*     */   
/*     */   public void setFeatures(Collection<String> features, Map<String, String> featureNames) {
/* 194 */     this.features = new ArrayList<>(features);
/* 195 */     this.featureNames = featureNames;
/* 196 */     Object previousKey = this.cmbboxXFeature.getSelectedItem();
/*     */ 
/*     */     
/* 199 */     ComboBoxModel<String> cmbboxXFeatureModel = new DefaultComboBoxModel<>((String[])TMUtils.getArrayFromMaping(features, featureNames).toArray((Object[])new String[0]));
/* 200 */     this.cmbboxXFeature.setModel(cmbboxXFeatureModel);
/* 201 */     this.cmbboxXFeature.setSelectedItem(previousKey);
/*     */     
/* 203 */     for (JComboBox<String> cb : this.comboBoxes) {
/*     */       
/* 205 */       Object previousYKey = cb.getSelectedItem();
/*     */       
/* 207 */       ComboBoxModel<String> cmbboxYFeatureModel = new DefaultComboBoxModel<>((String[])TMUtils.getArrayFromMaping(features, featureNames).toArray((Object[])new String[0]));
/* 208 */       cb.setModel(cmbboxYFeatureModel);
/* 209 */       cb.setSelectedItem(previousYKey);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void addFeature(String yKey) {
/* 219 */     if (this.comboBoxes.size() > 10) {
/*     */       return;
/*     */     }
/*     */     
/* 223 */     ComboBoxModel<String> cmbboxYFeatureModel = new DefaultComboBoxModel<>((String[])TMUtils.getArrayFromMaping(this.features, this.featureNames).toArray((Object[])new String[0]));
/* 224 */     JComboBox<String> cmbboxYFeature = new JComboBox<>();
/* 225 */     cmbboxYFeature.setModel(cmbboxYFeatureModel);
/* 226 */     cmbboxYFeature.setMaximumSize(COMBO_BOX_MAX_SIZE);
/* 227 */     cmbboxYFeature.setFont(Fonts.FONT);
/* 228 */     cmbboxYFeature.setSelectedItem(yKey);
/*     */     
/* 230 */     Component strut = Box.createVerticalStrut(10);
/* 231 */     this.panelYFeatures.add(strut);
/* 232 */     this.panelYFeatures.add(cmbboxYFeature);
/* 233 */     this.panelYFeatures.revalidate();
/* 234 */     this.comboBoxes.push(cmbboxYFeature);
/* 235 */     this.struts.push(strut);
/*     */   }
/*     */ 
/*     */   
/*     */   private void addFeature() {
/* 240 */     String nextFeature = "";
/* 241 */     if (!this.comboBoxes.isEmpty()) {
/*     */       
/* 243 */       int newIndex = ((JComboBox)this.comboBoxes.get(this.comboBoxes.size() - 1)).getSelectedIndex() + 1;
/* 244 */       if (newIndex >= this.features.size())
/* 245 */         newIndex = 0; 
/* 246 */       nextFeature = this.featureNames.get(this.features.get(newIndex));
/*     */     } 
/* 248 */     addFeature(nextFeature);
/*     */   }
/*     */ 
/*     */   
/*     */   private void removeFeature() {
/* 253 */     if (this.comboBoxes.size() <= 1)
/*     */       return; 
/* 255 */     this.panelYFeatures.remove(this.comboBoxes.pop());
/* 256 */     this.panelYFeatures.remove(this.struts.pop());
/* 257 */     this.panelYFeatures.revalidate();
/* 258 */     this.panelYFeatures.repaint();
/*     */   }
/*     */   
/*     */   public static interface PlotAction {
/*     */     void plot(String param1String, List<String> param1List);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/gui/components/FeaturePlotSelectionPanel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */