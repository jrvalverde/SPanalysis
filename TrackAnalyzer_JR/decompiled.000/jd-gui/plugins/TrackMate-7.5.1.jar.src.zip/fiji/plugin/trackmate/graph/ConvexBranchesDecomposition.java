/*     */ package fiji.plugin.trackmate.graph;
/*     */ 
/*     */ import fiji.plugin.trackmate.Model;
/*     */ import fiji.plugin.trackmate.Spot;
/*     */ import fiji.plugin.trackmate.TrackModel;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import net.imglib2.algorithm.Algorithm;
/*     */ import net.imglib2.algorithm.Benchmark;
/*     */ import org.jgrapht.Graph;
/*     */ import org.jgrapht.alg.connectivity.ConnectivityInspector;
/*     */ import org.jgrapht.graph.DefaultEdge;
/*     */ import org.jgrapht.graph.DefaultWeightedEdge;
/*     */ import org.jgrapht.graph.SimpleDirectedGraph;
/*     */ import org.jgrapht.graph.SimpleGraph;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConvexBranchesDecomposition
/*     */   implements Algorithm, Benchmark
/*     */ {
/*     */   private static final String BASE_ERROR_MSG = "[ConvexBranchesDecomposition] ";
/*     */   private String errorMessage;
/*     */   private Collection<List<Spot>> branches;
/*     */   private Collection<List<Spot>> links;
/*     */   private Map<Integer, Collection<List<Spot>>> branchesPerTrack;
/*     */   private Map<Integer, Collection<List<Spot>>> linksPerTrack;
/*     */   private long processingTime;
/*     */   private final TrackModel tm;
/*     */   private final TimeDirectedNeighborIndex neighborIndex;
/*     */   private final boolean forbidMiddleLinks;
/*     */   private final boolean forbidGaps;
/*     */   
/*     */   public ConvexBranchesDecomposition(Model model, boolean forbidMiddleLinks, boolean forbidGaps) {
/* 211 */     this.forbidMiddleLinks = forbidMiddleLinks;
/* 212 */     this.forbidGaps = forbidGaps;
/* 213 */     this.tm = model.getTrackModel();
/* 214 */     this.neighborIndex = this.tm.getDirectedNeighborIndex();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ConvexBranchesDecomposition(Model model) {
/* 227 */     this(model, true, true);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public long getProcessingTime() {
/* 233 */     return this.processingTime;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean checkInput() {
/* 239 */     long start = System.currentTimeMillis();
/* 240 */     for (DefaultWeightedEdge edge : this.tm.edgeSet()) {
/*     */       
/* 242 */       Spot source = this.tm.getEdgeSource(edge);
/* 243 */       Spot target = this.tm.getEdgeTarget(edge);
/* 244 */       if (source.diffTo(target, "FRAME") == 0.0D) {
/*     */         
/* 246 */         this.errorMessage = "[ConvexBranchesDecomposition] Cannot deal with links between two spots in the same frame (" + source + " & " + target + ").\n";
/* 247 */         return false;
/*     */       } 
/*     */     } 
/* 250 */     long end = System.currentTimeMillis();
/* 251 */     this.processingTime = end - start;
/* 252 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean process() {
/* 258 */     long startT = System.currentTimeMillis();
/*     */     
/* 260 */     Set<Integer> trackIDs = this.tm.trackIDs(true);
/*     */     
/* 262 */     this.branches = new ArrayList<>();
/* 263 */     this.branchesPerTrack = new HashMap<>();
/* 264 */     this.links = new ArrayList<>();
/* 265 */     this.linksPerTrack = new HashMap<>();
/* 266 */     for (Integer trackID : trackIDs) {
/*     */       
/* 268 */       TrackBranchDecomposition branchDecomposition = processTrack(trackID, this.tm, this.neighborIndex, this.forbidMiddleLinks, this.forbidGaps);
/*     */       
/* 270 */       this.branchesPerTrack.put(trackID, branchDecomposition.branches);
/* 271 */       this.linksPerTrack.put(trackID, branchDecomposition.links);
/*     */       
/* 273 */       this.branches.addAll(branchDecomposition.branches);
/* 274 */       this.links.addAll(branchDecomposition.links);
/*     */     } 
/*     */     
/* 277 */     long endT = System.currentTimeMillis();
/* 278 */     this.processingTime = endT - startT;
/*     */     
/* 280 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final TrackBranchDecomposition processTrack(Integer trackID, TrackModel tm, TimeDirectedNeighborIndex neighborIndex, boolean forbidMiddleLinks, boolean forbidGaps) {
/* 310 */     Set<Spot> allSpots = tm.trackSpots(trackID);
/* 311 */     Set<DefaultWeightedEdge> allEdges = tm.trackEdges(trackID);
/* 312 */     SimpleGraph<Spot, DefaultWeightedEdge> graph = new SimpleGraph(DefaultWeightedEdge.class);
/*     */     
/* 314 */     for (Spot spot : allSpots)
/*     */     {
/* 316 */       graph.addVertex(spot);
/*     */     }
/* 318 */     for (DefaultWeightedEdge edge : allEdges)
/*     */     {
/* 320 */       graph.addEdge(tm.getEdgeSource(edge), tm.getEdgeTarget(edge));
/*     */     }
/*     */     
/* 323 */     Collection<List<Spot>> links = new HashSet<>();
/* 324 */     for (Spot spot : allSpots) {
/*     */       
/* 326 */       Set<Spot> successors = neighborIndex.successorsOf(spot);
/* 327 */       Set<Spot> predecessors = neighborIndex.predecessorsOf(spot);
/* 328 */       if (predecessors.size() <= 1 && successors.size() <= 1) {
/*     */         continue;
/*     */       }
/*     */ 
/*     */       
/* 333 */       if (predecessors.size() == 0) {
/*     */         
/* 335 */         boolean bool = false;
/* 336 */         for (Spot successor : successors) {
/*     */           
/* 338 */           if (!forbidMiddleLinks && !bool && successor.diffTo(spot, "FRAME") < 2.0D) {
/*     */             
/* 340 */             bool = true;
/*     */             
/*     */             continue;
/*     */           } 
/* 344 */           graph.removeEdge(spot, successor);
/* 345 */           links.add(makeLink(spot, successor));
/*     */         } 
/*     */         continue;
/*     */       } 
/* 349 */       if (successors.size() == 0) {
/*     */         
/* 351 */         boolean bool = false;
/* 352 */         for (Spot predecessor : predecessors) {
/*     */           
/* 354 */           if (!forbidMiddleLinks && !bool && spot.diffTo(predecessor, "FRAME") < 2.0D) {
/*     */             
/* 356 */             bool = true;
/*     */             
/*     */             continue;
/*     */           } 
/* 360 */           graph.removeEdge(predecessor, spot);
/* 361 */           links.add(makeLink(predecessor, spot));
/*     */         } 
/*     */         continue;
/*     */       } 
/* 365 */       if (predecessors.size() == 1) {
/*     */         
/* 367 */         Spot previous = predecessors.iterator().next();
/* 368 */         if (previous.diffTo(spot, "FRAME") < 2.0D) {
/*     */           
/* 370 */           for (Spot successor : successors) {
/*     */             
/* 372 */             graph.removeEdge(spot, successor);
/* 373 */             links.add(makeLink(spot, successor));
/*     */           } 
/*     */           
/*     */           continue;
/*     */         } 
/* 378 */         graph.removeEdge(previous, spot);
/* 379 */         links.add(makeLink(previous, spot));
/* 380 */         boolean bool = false;
/* 381 */         for (Spot successor : successors) {
/*     */           
/* 383 */           if (!forbidMiddleLinks && !bool && successor.diffTo(spot, "FRAME") < 2.0D) {
/*     */             
/* 385 */             bool = true;
/*     */             
/*     */             continue;
/*     */           } 
/* 389 */           graph.removeEdge(spot, successor);
/* 390 */           links.add(makeLink(spot, successor));
/*     */         } 
/*     */         
/*     */         continue;
/*     */       } 
/* 395 */       if (successors.size() == 1) {
/*     */         
/* 397 */         Spot next = successors.iterator().next();
/* 398 */         if (spot.diffTo(next, "FRAME") < 2.0D) {
/*     */           
/* 400 */           for (Spot predecessor : predecessors) {
/*     */             
/* 402 */             graph.removeEdge(predecessor, spot);
/* 403 */             links.add(makeLink(predecessor, spot));
/*     */           } 
/*     */           
/*     */           continue;
/*     */         } 
/* 408 */         graph.removeEdge(spot, next);
/* 409 */         links.add(makeLink(spot, next));
/* 410 */         boolean bool = false;
/* 411 */         for (Spot predecessor : predecessors) {
/*     */           
/* 413 */           if (!forbidMiddleLinks && !bool && spot.diffTo(predecessor, "FRAME") < 2.0D) {
/*     */             
/* 415 */             bool = true;
/*     */             
/*     */             continue;
/*     */           } 
/* 419 */           graph.removeEdge(predecessor, spot);
/* 420 */           links.add(makeLink(predecessor, spot));
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         continue;
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 431 */       boolean found = false;
/* 432 */       for (Spot predecessor : predecessors) {
/*     */         
/* 434 */         if (!forbidMiddleLinks && !found && spot.diffTo(predecessor, "FRAME") < 2.0D) {
/*     */           
/* 436 */           found = true;
/*     */           
/*     */           continue;
/*     */         } 
/* 440 */         graph.removeEdge(predecessor, spot);
/* 441 */         links.add(makeLink(predecessor, spot));
/*     */       } 
/*     */       
/* 444 */       if (!forbidMiddleLinks)
/*     */       {
/*     */ 
/*     */         
/* 448 */         found = false;
/*     */       }
/* 450 */       for (Spot successor : successors) {
/*     */         
/* 452 */         if (!forbidMiddleLinks && !found && successor.diffTo(spot, "FRAME") < 2.0D) {
/*     */           
/* 454 */           found = true;
/*     */           
/*     */           continue;
/*     */         } 
/* 458 */         graph.removeEdge(spot, successor);
/* 459 */         links.add(makeLink(spot, successor));
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 469 */     if (forbidGaps) {
/*     */       
/* 471 */       Set<DefaultWeightedEdge> newEdges = graph.edgeSet();
/* 472 */       Set<DefaultWeightedEdge> toRemove = new HashSet<>();
/* 473 */       for (DefaultWeightedEdge edge : newEdges) {
/*     */         
/* 475 */         Spot source = (Spot)graph.getEdgeSource(edge);
/* 476 */         Spot target = (Spot)graph.getEdgeTarget(edge);
/* 477 */         if (Math.abs(source.diffTo(target, "FRAME")) > 1.0D) {
/*     */           
/* 479 */           toRemove.add(edge);
/* 480 */           links.add(makeLink(source, target));
/*     */         } 
/*     */       } 
/*     */       
/* 484 */       for (DefaultWeightedEdge edge : toRemove)
/*     */       {
/* 486 */         graph.removeEdge(edge);
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 494 */     ConnectivityInspector<Spot, DefaultWeightedEdge> connectivity = new ConnectivityInspector((Graph)graph);
/* 495 */     List<Set<Spot>> connectedSets = connectivity.connectedSets();
/* 496 */     Collection<List<Spot>> branches = new HashSet<>(connectedSets.size());
/* 497 */     Comparator<Spot> comparator = Spot.frameComparator;
/* 498 */     for (Set<Spot> set : connectedSets) {
/*     */       
/* 500 */       List<Spot> branch = new ArrayList<>(set.size());
/* 501 */       branch.addAll(set);
/* 502 */       Collections.sort(branch, comparator);
/* 503 */       branches.add(branch);
/*     */     } 
/*     */     
/* 506 */     TrackBranchDecomposition output = new TrackBranchDecomposition();
/* 507 */     output.branches = branches;
/* 508 */     output.links = links;
/* 509 */     return output;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final SimpleDirectedGraph<List<Spot>, DefaultEdge> buildBranchGraph(TrackBranchDecomposition branchDecomposition) {
/* 527 */     SimpleDirectedGraph<List<Spot>, DefaultEdge> branchGraph = new SimpleDirectedGraph(DefaultEdge.class);
/*     */     
/* 529 */     Collection<List<Spot>> branches = branchDecomposition.branches;
/* 530 */     Collection<List<Spot>> links = branchDecomposition.links;
/*     */ 
/*     */     
/* 533 */     Map<Spot, List<Spot>> firstSpots = new HashMap<>(branches.size());
/*     */     
/* 535 */     Map<Spot, List<Spot>> lastSpots = new HashMap<>(branches.size());
/* 536 */     for (List<Spot> branch : branches) {
/*     */       
/* 538 */       firstSpots.put(branch.get(0), branch);
/* 539 */       lastSpots.put(branch.get(branch.size() - 1), branch);
/* 540 */       branchGraph.addVertex(branch);
/*     */     } 
/*     */     
/* 543 */     for (List<Spot> link : links) {
/*     */       
/* 545 */       Spot source = link.get(0);
/* 546 */       Spot target = link.get(1);
/*     */       
/* 548 */       List<Spot> targetBranch = firstSpots.get(target);
/* 549 */       if (targetBranch == null)
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 557 */         for (List<Spot> branch : branches) {
/*     */           
/* 559 */           if (branch.contains(target)) {
/*     */             
/* 561 */             targetBranch = branch;
/*     */             
/*     */             break;
/*     */           } 
/*     */         } 
/*     */       }
/* 567 */       List<Spot> sourceBranch = lastSpots.get(source);
/* 568 */       if (sourceBranch == null)
/*     */       {
/* 570 */         for (List<Spot> branch : branches) {
/*     */           
/* 572 */           if (branch.contains(source)) {
/*     */             
/* 574 */             sourceBranch = branch;
/*     */             
/*     */             break;
/*     */           } 
/*     */         } 
/*     */       }
/* 580 */       branchGraph.addEdge(sourceBranch, targetBranch);
/*     */     } 
/*     */     
/* 583 */     return branchGraph;
/*     */   }
/*     */ 
/*     */   
/*     */   private static final List<Spot> makeLink(Spot spotA, Spot spotB) {
/* 588 */     List<Spot> link = new ArrayList<>(2);
/* 589 */     link.add(spotA);
/* 590 */     link.add(spotB);
/* 591 */     return link;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getErrorMessage() {
/* 597 */     return this.errorMessage;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection<List<Spot>> getBranches() {
/* 611 */     return this.branches;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<Integer, Collection<List<Spot>>> getBranchesPerTrack() {
/* 626 */     return this.branchesPerTrack;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection<List<Spot>> getLinks() {
/* 644 */     return this.links;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<Integer, Collection<List<Spot>>> getLinksPerTrack() {
/* 662 */     return this.linksPerTrack;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final class TrackBranchDecomposition
/*     */   {
/*     */     public Collection<List<Spot>> branches;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Collection<List<Spot>> links;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String toString() {
/* 690 */       StringBuilder str = new StringBuilder();
/* 691 */       str.append(super.toString() + ";\n");
/* 692 */       str.append("  Branches:\n");
/* 693 */       int index = 0;
/* 694 */       for (List<Spot> branch : this.branches) {
/*     */         
/* 696 */         str.append(String.format("    % 4d:\t" + branch + '\n', new Object[] { Integer.valueOf(index++) }));
/*     */       } 
/* 698 */       str.append("  Links:\n");
/* 699 */       index = 0;
/* 700 */       for (List<Spot> link : this.links) {
/*     */         
/* 702 */         str.append(String.format("    % 4d:\t" + link.get(0) + "\t→\t" + link.get(1) + '\n', new Object[] { Integer.valueOf(index++) }));
/*     */       } 
/* 704 */       return str.toString();
/*     */     }
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/graph/ConvexBranchesDecomposition.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */