/*     */ package fiji.plugin.trackmate.action;
/*     */ 
/*     */ import fiji.plugin.trackmate.Model;
/*     */ import fiji.plugin.trackmate.SelectionModel;
/*     */ import fiji.plugin.trackmate.Spot;
/*     */ import fiji.plugin.trackmate.TrackMate;
/*     */ import fiji.plugin.trackmate.gui.Icons;
/*     */ import fiji.plugin.trackmate.gui.displaysettings.DisplaySettings;
/*     */ import fiji.plugin.trackmate.gui.wizard.descriptors.SomeDialogDescriptor;
/*     */ import fiji.plugin.trackmate.io.IOUtils;
/*     */ import fiji.plugin.trackmate.io.TmXmlReader;
/*     */ import java.awt.Frame;
/*     */ import java.io.File;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Set;
/*     */ import javax.swing.ImageIcon;
/*     */ import org.jgrapht.graph.DefaultWeightedEdge;
/*     */ import org.scijava.plugin.Plugin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MergeFileAction
/*     */   extends AbstractTMAction
/*     */ {
/*     */   public static final String NAME = "Merge a TrackMate file";
/*     */   public static final String KEY = "MERGE_OTHER_FILE";
/*     */   public static final String INFO_TEXT = "<html>Merge the current model with the data from another <br>file, specified by the user. This is useful <i>e.g.</i> <br>if two operators have been annotating the same datasets <br>and want to merge their work in a single file.<p>Only the spots belonging to visible tracks are imported <br>from the target file, which makes this action non-entirely <br>symmetrical.  Numerical features are re-calculated using <br>the current settings. There is no check that the imported <br>data was generated on the raw source.</html>";
/*     */   
/*     */   public void execute(TrackMate trackmate, SelectionModel selectionModel, DisplaySettings displaySettings, Frame parent) {
/*  71 */     File file = SomeDialogDescriptor.file;
/*  72 */     if (null == file) {
/*     */       
/*  74 */       File folder = (new File(System.getProperty("user.dir"))).getParentFile().getParentFile();
/*  75 */       file = new File(folder.getPath() + File.separator + "TrackMateData.xml");
/*     */     } 
/*     */     
/*  78 */     File tmpFile = IOUtils.askForFileForLoading(file, "Merge a TrackMate XML file", parent, this.logger);
/*  79 */     if (null == tmpFile)
/*     */       return; 
/*  81 */     file = tmpFile;
/*     */ 
/*     */     
/*  84 */     TmXmlReader reader = new TmXmlReader(file);
/*  85 */     if (!reader.isReadingOk()) {
/*     */       
/*  87 */       this.logger.error(reader.getErrorMessage());
/*  88 */       this.logger.error("Aborting.\n");
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/*  93 */     Model modelToMerge = reader.getModel();
/*  94 */     Model model = trackmate.getModel();
/*  95 */     int nNewTracks = modelToMerge.getTrackModel().nTracks(true);
/*     */     
/*  97 */     int progress = 0;
/*  98 */     model.beginUpdate();
/*     */     
/* 100 */     int nNewSpots = 0;
/*     */     
/*     */     try {
/* 103 */       for (Iterator<Integer> iterator = modelToMerge.getTrackModel().trackIDs(true).iterator(); iterator.hasNext(); ) { int id = ((Integer)iterator.next()).intValue();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 110 */         Set<Spot> spots = modelToMerge.getTrackModel().trackSpots(Integer.valueOf(id));
/* 111 */         HashMap<Spot, Spot> mapOldToNew = new HashMap<>(spots.size());
/*     */         
/* 113 */         Spot newSpot = null;
/* 114 */         for (Spot oldSpot : spots) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 120 */           newSpot = new Spot(oldSpot);
/* 121 */           for (String feature : oldSpot.getFeatures().keySet()) {
/* 122 */             newSpot.putFeature(feature, oldSpot.getFeature(feature));
/*     */           }
/* 124 */           mapOldToNew.put(oldSpot, newSpot);
/* 125 */           model.addSpotTo(newSpot, Integer.valueOf(oldSpot.getFeature("FRAME").intValue()));
/* 126 */           nNewSpots++;
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 133 */         Set<DefaultWeightedEdge> edges = modelToMerge.getTrackModel().trackEdges(Integer.valueOf(id));
/* 134 */         for (DefaultWeightedEdge edge : edges) {
/*     */           
/* 136 */           Spot oldSource = modelToMerge.getTrackModel().getEdgeSource(edge);
/* 137 */           Spot oldTarget = modelToMerge.getTrackModel().getEdgeTarget(edge);
/* 138 */           Spot newSource = mapOldToNew.get(oldSource);
/* 139 */           Spot newTarget = mapOldToNew.get(oldTarget);
/* 140 */           double weight = modelToMerge.getTrackModel().getEdgeWeight(edge);
/*     */           
/* 142 */           model.addEdge(newSource, newTarget, weight);
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 149 */         String trackName = modelToMerge.getTrackModel().name(Integer.valueOf(id));
/* 150 */         int newId = model.getTrackModel().trackIDOf(newSpot).intValue();
/* 151 */         model.getTrackModel().setName(Integer.valueOf(newId), trackName);
/*     */         
/* 153 */         progress++;
/* 154 */         this.logger.setProgress(progress / nNewTracks); }
/*     */ 
/*     */     
/*     */     }
/*     */     finally {
/*     */       
/* 160 */       model.endUpdate();
/* 161 */       this.logger.setProgress(0.0D);
/* 162 */       this.logger.log("Imported " + nNewTracks + " tracks made of " + nNewSpots + " spots.\n");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Plugin(type = TrackMateActionFactory.class, visible = true)
/*     */   public static class Factory
/*     */     implements TrackMateActionFactory
/*     */   {
/*     */     public String getInfoText() {
/* 173 */       return "<html>Merge the current model with the data from another <br>file, specified by the user. This is useful <i>e.g.</i> <br>if two operators have been annotating the same datasets <br>and want to merge their work in a single file.<p>Only the spots belonging to visible tracks are imported <br>from the target file, which makes this action non-entirely <br>symmetrical.  Numerical features are re-calculated using <br>the current settings. There is no check that the imported <br>data was generated on the raw source.</html>";
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public String getName() {
/* 179 */       return "Merge a TrackMate file";
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public String getKey() {
/* 185 */       return "MERGE_OTHER_FILE";
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public ImageIcon getIcon() {
/* 191 */       return Icons.MERGE_ICON;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public TrackMateAction create() {
/* 197 */       return new MergeFileAction();
/*     */     }
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/action/MergeFileAction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */