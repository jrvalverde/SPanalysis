/*    */ package fiji.plugin.trackmate.gui.wizard.descriptors;
/*    */ 
/*    */ import fiji.plugin.trackmate.gui.components.LogPanel;
/*    */ import fiji.plugin.trackmate.gui.wizard.WizardPanelDescriptor;
/*    */ import java.awt.Component;
/*    */ import java.io.File;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class SomeDialogDescriptor
/*    */   extends WizardPanelDescriptor
/*    */ {
/*    */   public static File file;
/*    */   
/*    */   public SomeDialogDescriptor(String panelIdentifier, LogPanel logPanel) {
/* 48 */     super(panelIdentifier);
/* 49 */     this.targetPanel = (Component)logPanel;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/gui/wizard/descriptors/SomeDialogDescriptor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */