/*     */ package fiji.plugin.trackmate.tracking.sparselap.linker;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SparseCostMatrix
/*     */ {
/*     */   final double[] cc;
/*     */   final int[] kk;
/*     */   final int[] number;
/*     */   final int nRows;
/*     */   final int nCols;
/*     */   final int cardinality;
/*     */   final int[] start;
/*     */   
/*     */   public SparseCostMatrix(double[] cc, int[] kk, int[] number, int nCols) {
/* 123 */     this.cc = cc;
/* 124 */     this.kk = kk;
/* 125 */     this.number = number;
/* 126 */     this.nCols = nCols;
/*     */ 
/*     */     
/* 129 */     if (cc.length != kk.length) {
/* 130 */       throw new IllegalArgumentException("Cost and column indices arrays must have the same length. Found " + cc.length + " and " + kk.length + ".");
/*     */     }
/*     */     
/* 133 */     this.cardinality = cc.length;
/* 134 */     this.nRows = number.length;
/*     */     
/* 136 */     this.start = new int[this.nRows];
/* 137 */     if (this.nRows > 0)
/*     */     {
/* 139 */       this.start[0] = 0;
/*     */     }
/* 141 */     for (int i = 1; i < this.nRows; i++) {
/*     */       
/* 143 */       if (number[i] == 0) throw new IllegalArgumentException("All the rows must have at least one cost. Row " + i + " have none."); 
/* 144 */       this.start[i] = this.start[i - 1] + number[i - 1];
/*     */     } 
/*     */     
/* 147 */     int[] colHistogram = new int[nCols];
/* 148 */     for (int k = 0; k < this.nRows; k++) {
/*     */ 
/*     */       
/* 151 */       int previousK = -1;
/* 152 */       for (int m = this.start[k]; m < this.start[k] + number[k]; m++) {
/*     */         
/* 154 */         int n = kk[m];
/* 155 */         if (n >= nCols) throw new IllegalArgumentException("At line " + k + ", the column indices array contains a column index (" + n + ") that is larger than or equal to the declared number of column (" + nCols + ")."); 
/* 156 */         colHistogram[n] = colHistogram[n] + 1;
/* 157 */         if (n <= previousK) throw new IllegalArgumentException("The column indices array must be sorted within each row. The column elements at line " + k + " are not properly sorted."); 
/* 158 */         previousK = n;
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 163 */     for (int j = 0; j < colHistogram.length; j++) {
/*     */       
/* 165 */       if (colHistogram[j] == 0) throw new IllegalArgumentException("All the columns must have at least one cost. The column " + j + " has none.");
/*     */     
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 172 */     return toString(Collections.EMPTY_LIST, Collections.EMPTY_LIST);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString(List<?> rows, List<?> columns) {
/* 177 */     String[] colNames = new String[this.nCols];
/*     */     
/* 179 */     for (int j = 0; j < colNames.length; j++)
/*     */     {
/* 181 */       colNames[j] = "" + j;
/*     */     }
/* 183 */     String[] rowNames = new String[this.nRows];
/* 184 */     for (int i = 0; i < rowNames.length; i++)
/*     */     {
/* 186 */       rowNames[i] = "" + i;
/*     */     }
/*     */     
/* 189 */     for (int k = 0; k < columns.size(); k++) {
/*     */       
/* 191 */       Object col = columns.get(k);
/* 192 */       if (null != col) {
/*     */         
/* 194 */         String str1 = col.toString();
/* 195 */         colNames[k] = str1;
/*     */       } 
/*     */     } 
/*     */     
/* 199 */     int colWidth = -1;
/* 200 */     for (String str1 : colNames) {
/*     */       
/* 202 */       if (str1.length() > colWidth)
/*     */       {
/* 204 */         colWidth = str1.length();
/*     */       }
/*     */     } 
/*     */     
/* 208 */     colWidth++;
/* 209 */     colWidth = Math.max(colWidth, 7);
/*     */     
/* 211 */     for (int m = 0; m < rows.size(); m++) {
/*     */       
/* 213 */       Object row = rows.get(m);
/* 214 */       if (null != row) {
/*     */         
/* 216 */         String str1 = row.toString();
/* 217 */         rowNames[m] = str1;
/*     */       } 
/*     */     } 
/*     */     
/* 221 */     int rowWidth = -1;
/* 222 */     for (String str1 : rowNames) {
/*     */       
/* 224 */       if (str1.length() > rowWidth)
/*     */       {
/* 226 */         rowWidth = str1.length();
/*     */       }
/*     */     } 
/*     */     
/* 230 */     rowWidth++;
/* 231 */     rowWidth = Math.max(7, rowWidth);
/*     */     
/* 233 */     StringBuilder str = new StringBuilder();
/* 234 */     str.append(super.toString() + '\n');
/* 235 */     str.append("  " + this.nRows + " × " + this.nCols + " matrix with " + this.cardinality + " non-null elements. ");
/* 236 */     str.append(String.format("Density = %.2f%%.\n", new Object[] { Double.valueOf(this.cardinality / (this.nRows * this.nCols) * 100.0D) }));
/*     */     
/* 238 */     for (int i1 = 0; i1 < rowWidth; i1++)
/*     */     {
/* 240 */       str.append(' ');
/*     */     }
/* 242 */     str.append('|');
/* 243 */     for (int c = 0; c < this.nCols; c++) {
/*     */       
/* 245 */       for (int i2 = 0; i2 < colWidth - colNames[c].length(); i2++)
/*     */       {
/* 247 */         str.append(' ');
/*     */       }
/* 249 */       str.append(colNames[c]);
/*     */     } 
/* 251 */     str.append('\n');
/*     */     
/* 253 */     for (int n = 0; n < rowWidth; n++)
/*     */     {
/* 255 */       str.append('_');
/*     */     }
/* 257 */     str.append('|');
/* 258 */     char[] line = new char[colWidth * this.nCols];
/* 259 */     Arrays.fill(line, '_');
/* 260 */     str.append(line);
/* 261 */     str.append('\n');
/*     */     
/* 263 */     for (int r = 0; r < this.nRows; r++) {
/*     */       
/* 265 */       str.append(rowNames[r]);
/* 266 */       for (int i2 = 0; i2 < rowWidth - rowNames[r].length(); i2++)
/*     */       {
/* 268 */         str.append(' ');
/*     */       }
/* 270 */       str.append('|');
/*     */       
/* 272 */       StringBuilder rowStr = new StringBuilder();
/* 273 */       char[] spaces = new char[colWidth * this.nCols];
/* 274 */       Arrays.fill(spaces, ' ');
/* 275 */       rowStr.append(spaces);
/*     */       
/* 277 */       for (int i3 = this.start[r]; i3 < this.start[r] + this.number[r]; i3++) {
/*     */         
/* 279 */         int col = this.kk[i3];
/* 280 */         double cost = this.cc[i3];
/* 281 */         rowStr.replace(col * colWidth, (col + 1) * colWidth, String.format("% " + colWidth + ".1f", new Object[] { Double.valueOf(cost) }));
/*     */       } 
/* 283 */       rowStr.append('\n');
/* 284 */       str.append(rowStr.toString());
/*     */     } 
/*     */     
/* 287 */     return str.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double totalAssignmentCost(int[] rowAssignment) {
/* 301 */     double sum = 0.0D;
/* 302 */     for (int i = 0; i < rowAssignment.length; i++) {
/*     */       
/* 304 */       int j = rowAssignment[i];
/* 305 */       int kj = Arrays.binarySearch(this.kk, this.start[i], this.start[i] + this.number[i], j);
/* 306 */       sum += this.cc[kj];
/*     */     } 
/* 308 */     return sum;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double[][] toFullMatrix() {
/* 320 */     double[][] cm = new double[this.nRows][this.nCols];
/* 321 */     for (double[] ds : cm)
/*     */     {
/* 323 */       Arrays.fill(ds, Double.MAX_VALUE);
/*     */     }
/*     */     
/* 326 */     for (int r = 0; r < this.nRows; r++) {
/*     */       
/* 328 */       for (int k = this.start[r]; k < this.start[r] + this.number[r]; k++) {
/*     */         
/* 330 */         int c = this.kk[k];
/* 331 */         double cost = this.cc[k];
/* 332 */         cm[r][c] = cost;
/*     */       } 
/*     */     } 
/*     */     
/* 336 */     return cm;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final double get(int i, int j, double missingValue) {
/* 355 */     int k = Arrays.binarySearch(this.kk, this.start[i], this.start[i] + this.number[i], j);
/* 356 */     if (k < 0) {
/* 357 */       return missingValue;
/*     */     }
/* 359 */     return this.cc[k];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double[] getCosts() {
/* 369 */     return this.cc;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getNCols() {
/* 374 */     return this.nCols;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getNRows() {
/* 379 */     return this.nRows;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final SparseCostMatrix vcat(SparseCostMatrix B) {
/* 401 */     if (this.nCols != B.nCols) throw new IllegalArgumentException("Matrices A & B do not have the same number of columns. Found " + this.nCols + " and " + B.nCols + " respectively.");
/*     */     
/* 403 */     double[] cc2 = new double[this.cardinality + B.cardinality];
/* 404 */     int[] kk2 = new int[this.cardinality + B.cardinality];
/* 405 */     int[] number2 = new int[this.nRows + B.nRows];
/*     */ 
/*     */     
/* 408 */     System.arraycopy(this.kk, 0, kk2, 0, this.cardinality);
/* 409 */     System.arraycopy(this.cc, 0, cc2, 0, this.cardinality);
/* 410 */     System.arraycopy(this.number, 0, number2, 0, this.nRows);
/*     */ 
/*     */     
/* 413 */     System.arraycopy(B.kk, 0, kk2, this.cardinality, B.cardinality);
/* 414 */     System.arraycopy(B.cc, 0, cc2, this.cardinality, B.cardinality);
/* 415 */     System.arraycopy(B.number, 0, number2, this.nRows, B.nRows);
/*     */     
/* 417 */     return new SparseCostMatrix(cc2, kk2, number2, this.nCols);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final SparseCostMatrix hcat(SparseCostMatrix B) {
/* 438 */     if (this.nRows != B.nRows) throw new IllegalArgumentException("Matrices A & B do not have the same number of rows. Found " + this.nRows + " and " + B.nRows + " respectively.");
/*     */     
/* 440 */     double[] cc2 = new double[this.cardinality + B.cardinality];
/* 441 */     int[] kk2 = new int[this.cardinality + B.cardinality];
/* 442 */     int[] number2 = new int[this.nRows];
/*     */ 
/*     */     
/* 445 */     int Aindex = 0;
/* 446 */     int Bindex = 0;
/* 447 */     int Cindex = 0;
/* 448 */     for (int i = 0; i < this.nRows; i++) {
/*     */ 
/*     */       
/* 451 */       System.arraycopy(this.cc, Aindex, cc2, Cindex, this.number[i]);
/* 452 */       System.arraycopy(this.kk, Aindex, kk2, Cindex, this.number[i]);
/* 453 */       Aindex += this.number[i];
/* 454 */       Cindex += this.number[i];
/*     */ 
/*     */       
/* 457 */       System.arraycopy(B.cc, Bindex, cc2, Cindex, B.number[i]);
/*     */       
/* 459 */       for (int j = 0; j < B.number[i]; j++)
/*     */       {
/* 461 */         kk2[Cindex + j] = B.kk[Bindex + j] + this.nCols;
/*     */       }
/* 463 */       Bindex += B.number[i];
/* 464 */       Cindex += B.number[i];
/*     */ 
/*     */       
/* 467 */       number2[i] = this.number[i] + B.number[i];
/*     */     } 
/*     */     
/* 470 */     return new SparseCostMatrix(cc2, kk2, number2, this.nCols + B.nCols);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final SparseCostMatrix transpose() {
/* 481 */     int[] number2 = new int[this.nCols];
/* 482 */     for (int m : this.kk)
/*     */     {
/* 484 */       number2[m] = number2[m] + 1;
/*     */     }
/*     */ 
/*     */     
/* 488 */     int[][] cols = new int[this.nCols][];
/* 489 */     double[][] costs = new double[this.nCols][];
/* 490 */     for (int j = 0; j < cols.length; j++) {
/*     */       
/* 492 */       cols[j] = new int[number2[j]];
/* 493 */       costs[j] = new double[number2[j]];
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 498 */     int currentLine = 0;
/* 499 */     int previousJ = -1;
/* 500 */     int walked = 0;
/* 501 */     int[] colIndex = new int[this.nCols];
/* 502 */     for (int k = 0; k < this.cardinality; k++) {
/*     */       
/* 504 */       int m = this.kk[k];
/* 505 */       double c = this.cc[k];
/*     */ 
/*     */       
/* 508 */       if (m <= previousJ || walked >= this.number[currentLine]) {
/*     */         
/* 510 */         currentLine++;
/* 511 */         walked = 0;
/*     */       } 
/* 513 */       walked++;
/* 514 */       previousJ = m;
/*     */       
/* 516 */       cols[m][colIndex[m]] = currentLine;
/* 517 */       costs[m][colIndex[m]] = c;
/*     */       
/* 519 */       colIndex[m] = colIndex[m] + 1;
/*     */     } 
/*     */ 
/*     */     
/* 523 */     double[] cc2 = new double[this.cardinality];
/* 524 */     int[] kk2 = new int[this.cardinality];
/* 525 */     int index = 0;
/* 526 */     for (int i = 0; i < cols.length; i++) {
/*     */       
/* 528 */       System.arraycopy(cols[i], 0, kk2, index, number2[i]);
/* 529 */       System.arraycopy(costs[i], 0, cc2, index, number2[i]);
/* 530 */       index += number2[i];
/*     */     } 
/* 532 */     return new SparseCostMatrix(cc2, kk2, number2, this.nRows);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void fillWith(double value) {
/* 544 */     Arrays.fill(this.cc, value);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/tracking/sparselap/linker/SparseCostMatrix.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */