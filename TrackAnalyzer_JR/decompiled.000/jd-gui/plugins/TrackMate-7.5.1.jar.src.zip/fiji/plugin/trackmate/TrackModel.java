/*      */ package fiji.plugin.trackmate;
/*      */ 
/*      */ import fiji.plugin.trackmate.graph.Function1;
/*      */ import fiji.plugin.trackmate.graph.SortedDepthFirstIterator;
/*      */ import fiji.plugin.trackmate.graph.TimeDirectedDepthFirstIterator;
/*      */ import fiji.plugin.trackmate.graph.TimeDirectedNeighborIndex;
/*      */ import fiji.plugin.trackmate.graph.TimeDirectedSortedDepthFirstIterator;
/*      */ import fiji.plugin.trackmate.util.AlphanumComparator;
/*      */ import fiji.plugin.trackmate.util.TMUtils;
/*      */ import java.util.Collections;
/*      */ import java.util.Comparator;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedHashSet;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import java.util.function.Supplier;
/*      */ import java.util.regex.Pattern;
/*      */ import org.jgrapht.Graph;
/*      */ import org.jgrapht.alg.shortestpath.DijkstraShortestPath;
/*      */ import org.jgrapht.event.ConnectedComponentTraversalEvent;
/*      */ import org.jgrapht.event.EdgeTraversalEvent;
/*      */ import org.jgrapht.event.GraphEdgeChangeEvent;
/*      */ import org.jgrapht.event.GraphListener;
/*      */ import org.jgrapht.event.GraphVertexChangeEvent;
/*      */ import org.jgrapht.event.TraversalListener;
/*      */ import org.jgrapht.event.VertexTraversalEvent;
/*      */ import org.jgrapht.graph.AsUnweightedGraph;
/*      */ import org.jgrapht.graph.DefaultListenableGraph;
/*      */ import org.jgrapht.graph.DefaultWeightedEdge;
/*      */ import org.jgrapht.graph.SimpleDirectedWeightedGraph;
/*      */ import org.jgrapht.graph.SimpleWeightedGraph;
/*      */ import org.jgrapht.traverse.BreadthFirstIterator;
/*      */ import org.jgrapht.traverse.DepthFirstIterator;
/*      */ import org.jgrapht.traverse.GraphIterator;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class TrackModel
/*      */ {
/*      */   DefaultListenableGraph<Spot, DefaultWeightedEdge> graph;
/*      */   private final MyGraphListener mgl;
/*   92 */   final Set<DefaultWeightedEdge> edgesAdded = new HashSet<>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  102 */   final Set<DefaultWeightedEdge> edgesRemoved = new HashSet<>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  112 */   final Set<DefaultWeightedEdge> edgesModified = new HashSet<>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  124 */   final Set<Integer> tracksUpdated = new HashSet<>();
/*      */   
/*  126 */   private static final Boolean DEFAULT_VISIBILITY = Boolean.TRUE;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  131 */   private int IDcounter = 0;
/*      */   
/*      */   Map<Integer, Set<DefaultWeightedEdge>> connectedEdgeSets;
/*      */   
/*      */   Map<DefaultWeightedEdge, Integer> edgeToID;
/*      */   
/*      */   Map<Integer, Set<Spot>> connectedVertexSets;
/*      */   
/*      */   Map<Spot, Integer> vertexToID;
/*      */   
/*      */   Map<Integer, Boolean> visibility;
/*      */   
/*      */   Map<Integer, String> names;
/*      */   
/*  145 */   private final Iterator<String> nameGenerator = new DefaultNameGenerator();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   TrackModel() {
/*  153 */     this(new SimpleWeightedGraph(DefaultWeightedEdge.class));
/*      */   }
/*      */ 
/*      */   
/*      */   private TrackModel(SimpleWeightedGraph<Spot, DefaultWeightedEdge> graph) {
/*  158 */     this.mgl = new MyGraphListener();
/*  159 */     setGraph(graph);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void setGraph(SimpleWeightedGraph<Spot, DefaultWeightedEdge> graph) {
/*  177 */     if (null != this.graph) {
/*  178 */       this.graph.removeGraphListener(this.mgl);
/*      */     }
/*  180 */     this.graph = new DefaultListenableGraph((Graph)graph);
/*  181 */     this.graph.addGraphListener(this.mgl);
/*  182 */     init((Graph<Spot, DefaultWeightedEdge>)graph);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void clear() {
/*  190 */     setGraph(new SimpleWeightedGraph(DefaultWeightedEdge.class));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void from(SimpleWeightedGraph<Spot, DefaultWeightedEdge> lGraph, Map<Integer, Set<Spot>> trackSpots, Map<Integer, Set<DefaultWeightedEdge>> trackEdges, Map<Integer, Boolean> trackVisibility, Map<Integer, String> trackNames) {
/*  219 */     if (null != this.graph) {
/*  220 */       this.graph.removeGraphListener(this.mgl);
/*      */     }
/*  222 */     this.graph = new DefaultListenableGraph((Graph)lGraph);
/*  223 */     this.graph.addGraphListener(this.mgl);
/*      */     
/*  225 */     this.edgesAdded.clear();
/*  226 */     this.edgesModified.clear();
/*  227 */     this.edgesRemoved.clear();
/*  228 */     this.tracksUpdated.clear();
/*      */     
/*  230 */     this.visibility = trackVisibility;
/*  231 */     this.names = trackNames;
/*  232 */     this.connectedVertexSets = trackSpots;
/*  233 */     this.connectedEdgeSets = trackEdges;
/*      */ 
/*      */     
/*  236 */     this.IDcounter = 0;
/*  237 */     this.vertexToID = new HashMap<>();
/*      */     
/*  239 */     int nameIDCounter = -1;
/*  240 */     int prefixLength = "Track_".length();
/*  241 */     Pattern namePattern = Pattern.compile("^Track_[0-9]+$");
/*  242 */     for (Integer id : trackSpots.keySet()) {
/*      */       
/*  244 */       for (Spot spot : trackSpots.get(id)) {
/*  245 */         this.vertexToID.put(spot, id);
/*      */       }
/*  247 */       if (id.intValue() > this.IDcounter) {
/*  248 */         this.IDcounter = id.intValue();
/*      */       }
/*      */ 
/*      */       
/*  252 */       if (namePattern.matcher(name(id)).matches()) {
/*      */         
/*  254 */         int nameID = Integer.parseInt(name(id).substring(prefixLength));
/*  255 */         if (nameID > nameIDCounter)
/*  256 */           nameIDCounter = nameID; 
/*      */       } 
/*      */     } 
/*  259 */     this.IDcounter++;
/*  260 */     ((DefaultNameGenerator)this.nameGenerator).setNameID(++nameIDCounter);
/*      */     
/*  262 */     this.edgeToID = new HashMap<>();
/*  263 */     for (Integer id : trackEdges.keySet()) {
/*      */       
/*  265 */       for (DefaultWeightedEdge edge : trackEdges.get(id)) {
/*  266 */         this.edgeToID.put(edge, id);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void addSpot(Spot spotToAdd) {
/*  277 */     this.graph.addVertex(spotToAdd);
/*      */   }
/*      */ 
/*      */   
/*      */   void removeSpot(Spot spotToRemove) {
/*  282 */     this.graph.removeVertex(spotToRemove);
/*      */   }
/*      */ 
/*      */   
/*      */   DefaultWeightedEdge addEdge(Spot source, Spot target, double weight) {
/*  287 */     if (!this.graph.containsVertex(source)) {
/*  288 */       this.graph.addVertex(source);
/*      */     }
/*  290 */     if (!this.graph.containsVertex(target)) {
/*  291 */       this.graph.addVertex(target);
/*      */     }
/*  293 */     DefaultWeightedEdge edge = (DefaultWeightedEdge)this.graph.addEdge(source, target);
/*  294 */     if (edge != null)
/*  295 */       this.graph.setEdgeWeight(edge, weight); 
/*  296 */     return edge;
/*      */   }
/*      */ 
/*      */   
/*      */   DefaultWeightedEdge removeEdge(Spot source, Spot target) {
/*  301 */     return (DefaultWeightedEdge)this.graph.removeEdge(source, target);
/*      */   }
/*      */ 
/*      */   
/*      */   boolean removeEdge(DefaultWeightedEdge edge) {
/*  306 */     return this.graph.removeEdge(edge);
/*      */   }
/*      */ 
/*      */   
/*      */   void setEdgeWeight(DefaultWeightedEdge edge, double weight) {
/*  311 */     this.graph.setEdgeWeight(edge, weight);
/*  312 */     this.edgesModified.add(edge);
/*      */   }
/*      */ 
/*      */   
/*      */   Boolean setVisibility(Integer trackID, boolean visible) {
/*  317 */     return this.visibility.put(trackID, Boolean.valueOf(visible));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <V> SimpleDirectedWeightedGraph<V, DefaultWeightedEdge> copy(Supplier<V> factory, Function1<Spot, V> function, Map<Spot, V> mappings) {
/*      */     Map<Spot, V> map;
/*  349 */     SimpleDirectedWeightedGraph<V, DefaultWeightedEdge> copy = new SimpleDirectedWeightedGraph(DefaultWeightedEdge.class);
/*  350 */     Set<Spot> spots = this.graph.vertexSet();
/*      */ 
/*      */     
/*  353 */     if (null == mappings) {
/*  354 */       map = new HashMap<>(spots.size());
/*      */     } else {
/*  356 */       map = mappings;
/*      */     } 
/*      */     
/*  359 */     for (Spot spot : Collections.<Spot>unmodifiableCollection(spots)) {
/*      */       
/*  361 */       V vertex = factory.get();
/*  362 */       function.compute(spot, vertex);
/*  363 */       map.put(spot, vertex);
/*  364 */       copy.addVertex(vertex);
/*      */     } 
/*      */ 
/*      */     
/*  368 */     for (DefaultWeightedEdge edge : this.graph.edgeSet()) {
/*      */       
/*  370 */       DefaultWeightedEdge newEdge = (DefaultWeightedEdge)copy.addEdge(map.get(this.graph.getEdgeSource(edge)), map.get(this.graph.getEdgeTarget(edge)));
/*  371 */       copy.setEdgeWeight(newEdge, this.graph.getEdgeWeight(edge));
/*      */     } 
/*      */     
/*  374 */     return copy;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean containsEdge(Spot source, Spot target) {
/*  390 */     return this.graph.containsEdge(source, target);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DefaultWeightedEdge getEdge(Spot source, Spot target) {
/*  406 */     return (DefaultWeightedEdge)this.graph.getEdge(source, target);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Set<DefaultWeightedEdge> edgesOf(Spot spot) {
/*  421 */     if (this.graph.containsVertex(spot)) {
/*  422 */       return this.graph.edgesOf(spot);
/*      */     }
/*  424 */     return Collections.emptySet();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Set<DefaultWeightedEdge> edgeSet() {
/*  439 */     return this.graph.edgeSet();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Set<Spot> vertexSet() {
/*  454 */     return this.graph.vertexSet();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Spot getEdgeSource(DefaultWeightedEdge e) {
/*  468 */     return (Spot)this.graph.getEdgeSource(e);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Spot getEdgeTarget(DefaultWeightedEdge e) {
/*  482 */     return (Spot)this.graph.getEdgeTarget(e);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public double getEdgeWeight(DefaultWeightedEdge edge) {
/*  497 */     return this.graph.getEdgeWeight(edge);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isVisible(Integer ID) {
/*  515 */     return ((Boolean)this.visibility.get(ID)).booleanValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Set<Integer> trackIDs(boolean visibleOnly) {
/*  528 */     Set<Integer> ids = TMUtils.sortByValue(this.names, AlphanumComparator.instance).keySet();
/*  529 */     if (!visibleOnly) {
/*  530 */       return ids;
/*      */     }
/*  532 */     Set<Integer> vids = new LinkedHashSet<>(ids.size());
/*  533 */     for (Integer id : ids) {
/*  534 */       if (((Boolean)this.visibility.get(id)).booleanValue())
/*  535 */         vids.add(id); 
/*      */     } 
/*  537 */     return vids;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Set<Integer> unsortedTrackIDs(boolean visibleOnly) {
/*  551 */     if (!visibleOnly) {
/*  552 */       return this.visibility.keySet();
/*      */     }
/*  554 */     Set<Integer> vids = new LinkedHashSet<>(this.visibility.size());
/*  555 */     for (Integer id : this.visibility.keySet()) {
/*  556 */       if (((Boolean)this.visibility.get(id)).booleanValue())
/*  557 */         vids.add(id); 
/*      */     } 
/*  559 */     return vids;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String name(Integer id) {
/*  571 */     return this.names.get(id);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setName(Integer id, String name) {
/*  584 */     this.names.put(id, name);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Set<DefaultWeightedEdge> trackEdges(Integer trackID) {
/*  596 */     return this.connectedEdgeSets.get(trackID);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Set<Spot> trackSpots(Integer trackID) {
/*  608 */     return this.connectedVertexSets.get(trackID);
/*      */   }
/*      */ 
/*      */   
/*      */   public int nTracks(boolean visibleOnly) {
/*  613 */     if (!visibleOnly) {
/*  614 */       return this.connectedEdgeSets.size();
/*      */     }
/*  616 */     int ntracks = 0;
/*  617 */     for (Boolean visible : this.visibility.values()) {
/*  618 */       if (visible.booleanValue())
/*  619 */         ntracks++; 
/*      */     } 
/*  621 */     return ntracks;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Integer trackIDOf(DefaultWeightedEdge edge) {
/*  634 */     return this.edgeToID.get(edge);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Integer trackIDOf(Spot spot) {
/*  648 */     return this.vertexToID.get(spot);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void init(Graph<Spot, DefaultWeightedEdge> lGraph) {
/*  664 */     this.vertexToID = new HashMap<>();
/*  665 */     this.edgeToID = new HashMap<>();
/*  666 */     this.IDcounter = 0;
/*  667 */     this.visibility = new HashMap<>();
/*  668 */     this.names = new HashMap<>();
/*  669 */     this.connectedVertexSets = new HashMap<>();
/*  670 */     this.connectedEdgeSets = new HashMap<>();
/*      */     
/*  672 */     this.edgesAdded.clear();
/*  673 */     this.edgesModified.clear();
/*  674 */     this.edgesRemoved.clear();
/*  675 */     this.tracksUpdated.clear();
/*      */     
/*  677 */     Set<Spot> vertexSet = lGraph.vertexSet();
/*  678 */     if (vertexSet.size() > 0) {
/*      */       
/*  680 */       BreadthFirstIterator<Spot, DefaultWeightedEdge> i = new BreadthFirstIterator(lGraph);
/*  681 */       i.addTraversalListener(new MyTraversalListener());
/*      */       
/*  683 */       while (i.hasNext()) {
/*  684 */         i.next();
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String echo() {
/*  694 */     if (null == this.connectedVertexSets) {
/*  695 */       return "Uninitialized.\n";
/*      */     }
/*  697 */     StringBuilder str = new StringBuilder();
/*  698 */     Set<Integer> vid = this.connectedVertexSets.keySet();
/*  699 */     HashSet<Integer> eid = new HashSet<>(this.connectedEdgeSets.keySet());
/*      */     
/*  701 */     for (Integer id : vid) {
/*      */       
/*  703 */       str.append(id + ":\n");
/*  704 */       str.append(" - " + this.connectedVertexSets.get(id) + "\n");
/*  705 */       Set<DefaultWeightedEdge> es = this.connectedEdgeSets.get(id);
/*  706 */       if (es == null) {
/*  707 */         str.append(" - no matching edges!\n");
/*      */       } else {
/*  709 */         str.append(" - " + es + "\n");
/*      */       } 
/*  711 */       eid.remove(id);
/*      */     } 
/*      */     
/*  714 */     if (eid.isEmpty()) {
/*      */       
/*  716 */       str.append("No remaining edges ID.\n");
/*      */     }
/*      */     else {
/*      */       
/*  720 */       str.append("Found non-matching edge IDs!\n");
/*  721 */       for (Integer id : eid) {
/*      */         
/*  723 */         str.append(id + ":\n");
/*  724 */         str.append(" - " + this.connectedEdgeSets.get(id) + "\n");
/*      */       } 
/*      */     } 
/*      */     
/*  728 */     return str.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public GraphIterator<Spot, DefaultWeightedEdge> getDepthFirstIterator(Spot start, boolean directed) {
/*  751 */     if (directed) {
/*  752 */       return (GraphIterator<Spot, DefaultWeightedEdge>)new TimeDirectedDepthFirstIterator((Graph)this.graph, start);
/*      */     }
/*  754 */     return (GraphIterator<Spot, DefaultWeightedEdge>)new DepthFirstIterator((Graph)this.graph, start);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SortedDepthFirstIterator<Spot, DefaultWeightedEdge> getSortedDepthFirstIterator(Spot start, Comparator<Spot> comparator, boolean directed) {
/*  777 */     if (directed) {
/*  778 */       return (SortedDepthFirstIterator<Spot, DefaultWeightedEdge>)new TimeDirectedSortedDepthFirstIterator((Graph)this.graph, start, comparator);
/*      */     }
/*  780 */     return new SortedDepthFirstIterator((Graph)this.graph, start, comparator);
/*      */   }
/*      */ 
/*      */   
/*      */   public TimeDirectedNeighborIndex getDirectedNeighborIndex() {
/*  785 */     return new TimeDirectedNeighborIndex((Graph)this.graph);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<DefaultWeightedEdge> dijkstraShortestPath(Spot source, Spot target) {
/*  805 */     if (null == this.graph) {
/*  806 */       return null;
/*      */     }
/*  808 */     AsUnweightedGraph<Spot, DefaultWeightedEdge> unWeightedGrah = new AsUnweightedGraph((Graph)this.graph);
/*  809 */     DijkstraShortestPath<Spot, DefaultWeightedEdge> pathFinder = new DijkstraShortestPath((Graph)unWeightedGrah);
/*  810 */     List<DefaultWeightedEdge> path = pathFinder.getPath(source, target).getEdgeList();
/*  811 */     return path;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private class MyTraversalListener
/*      */     implements TraversalListener<Spot, DefaultWeightedEdge>
/*      */   {
/*      */     private Set<Spot> currentConnectedVertexSet;
/*      */ 
/*      */     
/*      */     private Set<DefaultWeightedEdge> currentConnectedEdgeSet;
/*      */ 
/*      */     
/*      */     private Integer ID;
/*      */ 
/*      */ 
/*      */     
/*      */     private MyTraversalListener() {}
/*      */ 
/*      */ 
/*      */     
/*      */     public void connectedComponentFinished(ConnectedComponentTraversalEvent event) {
/*  834 */       if (this.currentConnectedVertexSet.size() <= 1 || this.currentConnectedEdgeSet.size() == 0) {
/*      */ 
/*      */         
/*  837 */         for (DefaultWeightedEdge e : this.currentConnectedEdgeSet) {
/*  838 */           TrackModel.this.edgeToID.remove(e);
/*      */         }
/*  840 */         for (Spot v : this.currentConnectedVertexSet) {
/*  841 */           TrackModel.this.vertexToID.remove(v);
/*      */         }
/*      */         
/*      */         return;
/*      */       } 
/*  846 */       TrackModel.this.connectedVertexSets.put(this.ID, this.currentConnectedVertexSet);
/*  847 */       TrackModel.this.connectedEdgeSets.put(this.ID, this.currentConnectedEdgeSet);
/*  848 */       TrackModel.this.visibility.put(this.ID, TrackModel.DEFAULT_VISIBILITY);
/*  849 */       TrackModel.this.names.put(this.ID, TrackModel.this.nameGenerator.next());
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public void connectedComponentStarted(ConnectedComponentTraversalEvent e) {
/*  855 */       this.currentConnectedVertexSet = new HashSet<>();
/*  856 */       this.currentConnectedEdgeSet = new HashSet<>();
/*  857 */       this.ID = Integer.valueOf(TrackModel.this.IDcounter++);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public void vertexTraversed(VertexTraversalEvent<Spot> event) {
/*  863 */       Spot v = (Spot)event.getVertex();
/*  864 */       this.currentConnectedVertexSet.add(v);
/*  865 */       TrackModel.this.vertexToID.put(v, this.ID);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public void edgeTraversed(EdgeTraversalEvent<DefaultWeightedEdge> event) {
/*  871 */       DefaultWeightedEdge e = (DefaultWeightedEdge)event.getEdge();
/*  872 */       this.currentConnectedEdgeSet.add(e);
/*  873 */       TrackModel.this.edgeToID.put(e, this.ID);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void vertexFinished(VertexTraversalEvent<Spot> e) {}
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private class MyGraphListener
/*      */     implements GraphListener<Spot, DefaultWeightedEdge>
/*      */   {
/*      */     private MyGraphListener() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void vertexAdded(GraphVertexChangeEvent<Spot> event) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void vertexRemoved(GraphVertexChangeEvent<Spot> event) {
/*  928 */       if (null == TrackModel.this.connectedEdgeSets) {
/*      */         return;
/*      */       }
/*  931 */       Spot v = (Spot)event.getVertex();
/*  932 */       TrackModel.this.vertexToID.remove(v);
/*  933 */       Integer id = TrackModel.this.vertexToID.get(v);
/*  934 */       if (id != null) {
/*      */         
/*  936 */         Set<Spot> set = TrackModel.this.connectedVertexSets.get(id);
/*  937 */         if (null == set) {
/*      */           return;
/*      */         }
/*      */ 
/*      */ 
/*      */         
/*  943 */         set.remove(v);
/*      */         
/*  945 */         if (set.isEmpty()) {
/*      */           
/*  947 */           TrackModel.this.connectedEdgeSets.remove(id);
/*  948 */           TrackModel.this.connectedVertexSets.remove(id);
/*  949 */           TrackModel.this.names.remove(id);
/*  950 */           TrackModel.this.visibility.remove(id);
/*      */         } 
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void edgeAdded(GraphEdgeChangeEvent<Spot, DefaultWeightedEdge> event) {
/*  959 */       TrackModel.this.edgesAdded.add(event.getEdge());
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  968 */       DefaultWeightedEdge e = (DefaultWeightedEdge)event.getEdge();
/*      */ 
/*      */       
/*  971 */       Spot sv = (Spot)TrackModel.this.graph.getEdgeSource(e);
/*  972 */       Integer sid = TrackModel.this.vertexToID.get(sv);
/*  973 */       Spot tv = (Spot)TrackModel.this.graph.getEdgeTarget(e);
/*  974 */       Integer tid = TrackModel.this.vertexToID.get(tv);
/*      */       
/*  976 */       if (null != tid && null != sid) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  985 */         if (tid.equals(sid)) {
/*      */ 
/*      */           
/*  988 */           Set<DefaultWeightedEdge> ses = TrackModel.this.connectedEdgeSets.get(sid);
/*  989 */           ses.add(e);
/*  990 */           TrackModel.this.edgeToID.put(e, sid);
/*      */         } else {
/*      */           Integer nid, rid;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  998 */           Set<DefaultWeightedEdge> ses = TrackModel.this.connectedEdgeSets.get(sid);
/*  999 */           Set<DefaultWeightedEdge> tes = TrackModel.this.connectedEdgeSets.get(tid);
/* 1000 */           HashSet<DefaultWeightedEdge> nes = new HashSet<>(ses.size() + tes.size() + 1);
/* 1001 */           nes.addAll(ses);
/* 1002 */           nes.addAll(tes);
/* 1003 */           nes.add(e);
/*      */ 
/*      */           
/* 1006 */           Set<Spot> svs = TrackModel.this.connectedVertexSets.get(sid);
/* 1007 */           Set<Spot> tvs = TrackModel.this.connectedVertexSets.get(tid);
/* 1008 */           HashSet<Spot> nvs = new HashSet<>(ses.size() + tes.size());
/* 1009 */           nvs.addAll(svs);
/* 1010 */           nvs.addAll(tvs);
/*      */ 
/*      */           
/* 1013 */           if (nvs.size() > tvs.size()) {
/*      */             
/* 1015 */             nid = sid;
/* 1016 */             rid = tid;
/* 1017 */             for (Spot v : tvs)
/*      */             {
/*      */               
/* 1020 */               TrackModel.this.vertexToID.put(v, nid);
/*      */             }
/* 1022 */             for (DefaultWeightedEdge te : tes) {
/* 1023 */               TrackModel.this.edgeToID.put(te, nid);
/*      */             }
/*      */           } else {
/*      */             
/* 1027 */             nid = tid;
/* 1028 */             rid = sid;
/* 1029 */             for (Spot v : svs)
/*      */             {
/*      */               
/* 1032 */               TrackModel.this.vertexToID.put(v, nid);
/*      */             }
/* 1034 */             for (DefaultWeightedEdge se : ses)
/* 1035 */               TrackModel.this.edgeToID.put(se, nid); 
/*      */           } 
/* 1037 */           TrackModel.this.edgeToID.put(e, nid);
/* 1038 */           TrackModel.this.connectedVertexSets.put(nid, nvs);
/* 1039 */           TrackModel.this.connectedVertexSets.remove(rid);
/* 1040 */           TrackModel.this.connectedEdgeSets.put(nid, nes);
/* 1041 */           TrackModel.this.connectedEdgeSets.remove(rid);
/*      */ 
/*      */ 
/*      */           
/* 1045 */           TrackModel.this.tracksUpdated.add(nid);
/* 1046 */           TrackModel.this.tracksUpdated.remove(rid);
/*      */ 
/*      */ 
/*      */           
/* 1050 */           Boolean targetVisibility = Boolean.valueOf((((Boolean)TrackModel.this.visibility.get(sid)).booleanValue() || ((Boolean)TrackModel.this.visibility.get(tid)).booleanValue()));
/* 1051 */           TrackModel.this.visibility.put(nid, targetVisibility);
/* 1052 */           TrackModel.this.visibility.remove(rid);
/*      */ 
/*      */           
/* 1055 */           TrackModel.this.names.remove(rid);
/*      */         }
/*      */       
/*      */       }
/* 1059 */       else if (null == sid && null == tid) {
/*      */ 
/*      */ 
/*      */         
/* 1063 */         HashSet<Spot> nvs = new HashSet<>(2);
/* 1064 */         nvs.add(TrackModel.this.graph.getEdgeSource(e));
/* 1065 */         nvs.add(TrackModel.this.graph.getEdgeTarget(e));
/*      */         
/* 1067 */         HashSet<DefaultWeightedEdge> nes = new HashSet<>(1);
/* 1068 */         nes.add(e);
/*      */         
/* 1070 */         int nid = TrackModel.this.IDcounter++;
/* 1071 */         TrackModel.this.connectedEdgeSets.put(Integer.valueOf(nid), nes);
/* 1072 */         TrackModel.this.connectedVertexSets.put(Integer.valueOf(nid), nvs);
/* 1073 */         TrackModel.this.vertexToID.put(sv, Integer.valueOf(nid));
/* 1074 */         TrackModel.this.vertexToID.put(tv, Integer.valueOf(nid));
/* 1075 */         TrackModel.this.edgeToID.put(e, Integer.valueOf(nid));
/*      */ 
/*      */         
/* 1078 */         TrackModel.this.visibility.put(Integer.valueOf(nid), Boolean.TRUE);
/*      */         
/* 1080 */         TrackModel.this.names.put(Integer.valueOf(nid), TrackModel.this.nameGenerator.next());
/*      */         
/* 1082 */         TrackModel.this.tracksUpdated.add(Integer.valueOf(nid));
/*      */       
/*      */       }
/* 1085 */       else if (null == sid) {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1090 */         ((Set<DefaultWeightedEdge>)TrackModel.this.connectedEdgeSets.get(tid)).add(e);
/* 1091 */         TrackModel.this.edgeToID.put(e, tid);
/* 1092 */         ((Set<Spot>)TrackModel.this.connectedVertexSets.get(tid)).add(sv);
/* 1093 */         TrackModel.this.vertexToID.put(sv, tid);
/*      */ 
/*      */         
/* 1096 */         TrackModel.this.tracksUpdated.add(tid);
/*      */       
/*      */       }
/* 1099 */       else if (null == tid) {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1104 */         ((Set<DefaultWeightedEdge>)TrackModel.this.connectedEdgeSets.get(sid)).add(e);
/* 1105 */         TrackModel.this.edgeToID.put(e, sid);
/* 1106 */         ((Set<Spot>)TrackModel.this.connectedVertexSets.get(sid)).add(tv);
/* 1107 */         TrackModel.this.vertexToID.put(tv, sid);
/*      */ 
/*      */         
/* 1110 */         TrackModel.this.tracksUpdated.add(sid);
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void edgeRemoved(GraphEdgeChangeEvent<Spot, DefaultWeightedEdge> event) {
/* 1120 */       TrackModel.this.edgesRemoved.add(event.getEdge());
/*      */ 
/*      */ 
/*      */       
/* 1124 */       DefaultWeightedEdge e = (DefaultWeightedEdge)event.getEdge();
/* 1125 */       Integer id = TrackModel.this.edgeToID.get(e);
/* 1126 */       if (null == id) {
/* 1127 */         throw new RuntimeException("Edge is unkown to this model: " + e);
/*      */       }
/* 1129 */       Set<DefaultWeightedEdge> set = TrackModel.this.connectedEdgeSets.get(id);
/* 1130 */       if (null == set) {
/* 1131 */         throw new RuntimeException("Unknown set ID: " + id);
/*      */       }
/*      */       
/* 1134 */       boolean removed = set.remove(e);
/* 1135 */       if (!removed) {
/* 1136 */         throw new RuntimeException("Could not removed edge " + e + " from set with ID: " + id);
/*      */       }
/*      */       
/* 1139 */       TrackModel.this.edgeToID.remove(e);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1147 */       if (set.size() == 0) {
/*      */ 
/*      */         
/* 1150 */         TrackModel.this.connectedEdgeSets.remove(id);
/* 1151 */         TrackModel.this.names.remove(id);
/* 1152 */         TrackModel.this.visibility.remove(id);
/*      */         
/* 1154 */         Set<Spot> vertexSet = TrackModel.this.connectedVertexSets.get(id);
/*      */         
/* 1156 */         for (Spot spot : vertexSet) {
/* 1157 */           TrackModel.this.vertexToID.remove(spot);
/*      */         }
/*      */         
/* 1160 */         TrackModel.this.connectedVertexSets.remove(id);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1167 */         TrackModel.this.tracksUpdated.remove(id);
/*      */ 
/*      */       
/*      */       }
/*      */       else {
/*      */ 
/*      */ 
/*      */         
/* 1175 */         HashSet<Spot> sourceVCS = new HashSet<>();
/* 1176 */         HashSet<DefaultWeightedEdge> sourceECS = new HashSet<>();
/*      */         
/* 1178 */         Spot source = (Spot)TrackModel.this.graph.getEdgeSource(e);
/*      */         
/* 1180 */         BreadthFirstIterator<Spot, DefaultWeightedEdge> i = new BreadthFirstIterator((Graph)TrackModel.this.graph, source);
/* 1181 */         while (i.hasNext()) {
/*      */           
/* 1183 */           Spot sv = (Spot)i.next();
/* 1184 */           sourceVCS.add(sv);
/* 1185 */           sourceECS.addAll(TrackModel.this.graph.edgesOf(sv));
/*      */         } 
/*      */ 
/*      */         
/* 1189 */         HashSet<Spot> targetVCS = new HashSet<>();
/* 1190 */         HashSet<DefaultWeightedEdge> targetECS = new HashSet<>();
/*      */         
/* 1192 */         Spot target = (Spot)TrackModel.this.graph.getEdgeTarget(e);
/*      */         
/* 1194 */         BreadthFirstIterator<Spot, DefaultWeightedEdge> breadthFirstIterator1 = new BreadthFirstIterator((Graph)TrackModel.this.graph, target);
/* 1195 */         while (breadthFirstIterator1.hasNext()) {
/*      */           
/* 1197 */           Spot sv = (Spot)breadthFirstIterator1.next();
/* 1198 */           targetVCS.add(sv);
/* 1199 */           targetECS.addAll(TrackModel.this.graph.edgesOf(sv));
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1210 */         if (targetVCS.equals(sourceVCS)) {
/*      */           
/* 1212 */           TrackModel.this.tracksUpdated.add(id);
/* 1213 */           ((Set)TrackModel.this.connectedEdgeSets.get(id)).remove(e);
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           return;
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1224 */         if (targetVCS.size() > sourceVCS.size()) {
/*      */ 
/*      */           
/* 1227 */           TrackModel.this.connectedEdgeSets.put(id, targetECS);
/* 1228 */           TrackModel.this.connectedVertexSets.put(id, targetVCS);
/*      */ 
/*      */ 
/*      */           
/* 1232 */           TrackModel.this.tracksUpdated.add(id);
/*      */           
/* 1234 */           if (sourceECS.size() > 0)
/*      */           {
/*      */             
/* 1237 */             int newid = TrackModel.this.IDcounter++;
/* 1238 */             TrackModel.this.connectedEdgeSets.put(Integer.valueOf(newid), sourceECS);
/*      */             
/* 1240 */             for (DefaultWeightedEdge te : sourceECS) {
/* 1241 */               TrackModel.this.edgeToID.put(te, Integer.valueOf(newid));
/*      */             }
/* 1243 */             TrackModel.this.connectedVertexSets.put(Integer.valueOf(newid), sourceVCS);
/* 1244 */             for (Spot tv : sourceVCS) {
/* 1245 */               TrackModel.this.vertexToID.put(tv, Integer.valueOf(newid));
/*      */             }
/* 1247 */             Boolean targetVisibility = TrackModel.this.visibility.get(id);
/* 1248 */             TrackModel.this.visibility.put(Integer.valueOf(newid), targetVisibility);
/* 1249 */             TrackModel.this.names.put(Integer.valueOf(newid), TrackModel.this.nameGenerator.next());
/*      */ 
/*      */             
/* 1252 */             TrackModel.this.tracksUpdated.add(Integer.valueOf(newid));
/*      */ 
/*      */ 
/*      */           
/*      */           }
/*      */           else
/*      */           {
/*      */ 
/*      */             
/* 1261 */             Spot solitary = sourceVCS.iterator().next();
/* 1262 */             TrackModel.this.vertexToID.remove(solitary);
/*      */ 
/*      */           
/*      */           }
/*      */ 
/*      */         
/*      */         }
/* 1269 */         else if (sourceECS.size() > 0) {
/*      */ 
/*      */ 
/*      */           
/* 1273 */           TrackModel.this.connectedEdgeSets.put(id, sourceECS);
/* 1274 */           TrackModel.this.connectedVertexSets.put(id, sourceVCS);
/* 1275 */           TrackModel.this.tracksUpdated.add(id);
/*      */           
/* 1277 */           if (targetECS.size() > 0)
/*      */           {
/*      */             
/* 1280 */             int newid = TrackModel.this.IDcounter++;
/* 1281 */             TrackModel.this.connectedEdgeSets.put(Integer.valueOf(newid), targetECS);
/* 1282 */             for (DefaultWeightedEdge te : targetECS) {
/* 1283 */               TrackModel.this.edgeToID.put(te, Integer.valueOf(newid));
/*      */             }
/* 1285 */             TrackModel.this.connectedVertexSets.put(Integer.valueOf(newid), targetVCS);
/* 1286 */             for (Spot v : targetVCS) {
/* 1287 */               TrackModel.this.vertexToID.put(v, Integer.valueOf(newid));
/*      */             }
/* 1289 */             Boolean targetVisibility = TrackModel.this.visibility.get(id);
/* 1290 */             TrackModel.this.visibility.put(Integer.valueOf(newid), targetVisibility);
/* 1291 */             TrackModel.this.names.put(Integer.valueOf(newid), TrackModel.this.nameGenerator.next());
/*      */ 
/*      */             
/* 1294 */             TrackModel.this.tracksUpdated.add(Integer.valueOf(newid));
/*      */ 
/*      */ 
/*      */           
/*      */           }
/*      */           else
/*      */           {
/*      */ 
/*      */             
/* 1303 */             Spot solitary = targetVCS.iterator().next();
/* 1304 */             TrackModel.this.vertexToID.remove(solitary);
/*      */           
/*      */           }
/*      */ 
/*      */         
/*      */         }
/*      */         else {
/*      */           
/* 1312 */           TrackModel.this.connectedEdgeSets.remove(id);
/* 1313 */           TrackModel.this.connectedVertexSets.remove(id);
/* 1314 */           TrackModel.this.names.remove(id);
/* 1315 */           TrackModel.this.visibility.remove(id);
/* 1316 */           TrackModel.this.tracksUpdated.remove(id);
/*      */         } 
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static class DefaultNameGenerator
/*      */     implements Iterator<String>
/*      */   {
/*      */     private static final String DEFAULT_NAME_PREFIX = "Track_";
/*      */ 
/*      */     
/* 1330 */     private int nameID = 0;
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean hasNext() {
/* 1335 */       return true;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public String next() {
/* 1341 */       return "Track_" + this.nameID++;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public void remove() {}
/*      */ 
/*      */     
/*      */     public void setNameID(int nameID) {
/* 1350 */       this.nameID = nameID;
/*      */     }
/*      */     
/*      */     private DefaultNameGenerator() {}
/*      */   }
/*      */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/TrackModel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */