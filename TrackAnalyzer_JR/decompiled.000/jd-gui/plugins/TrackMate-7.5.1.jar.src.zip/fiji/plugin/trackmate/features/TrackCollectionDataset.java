/*     */ package fiji.plugin.trackmate.features;
/*     */ 
/*     */ import fiji.plugin.trackmate.Model;
/*     */ import fiji.plugin.trackmate.SelectionModel;
/*     */ import fiji.plugin.trackmate.gui.displaysettings.DisplaySettings;
/*     */ import fiji.plugin.trackmate.visualization.FeatureColorGenerator;
/*     */ import java.awt.Color;
/*     */ import java.awt.Paint;
/*     */ import java.awt.Stroke;
/*     */ import java.util.List;
/*     */ import org.jfree.chart.LegendItem;
/*     */ import org.jfree.chart.renderer.xy.XYItemRenderer;
/*     */ import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TrackCollectionDataset
/*     */   extends ModelDataset
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private final List<Integer> trackIDs;
/*     */   
/*     */   public TrackCollectionDataset(Model model, SelectionModel selectionModel, DisplaySettings ds, String xFeature, List<String> yFeatures, List<Integer> trackIDs) {
/*  53 */     super(model, selectionModel, ds, xFeature, yFeatures);
/*  54 */     this.trackIDs = trackIDs;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getItemCount(int series) {
/*  60 */     return this.trackIDs.size();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getItemLabel(int item) {
/*  66 */     return this.model.getTrackModel().name(this.trackIDs.get(item));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setItemLabel(int item, String label) {
/*  72 */     this.model.getTrackModel().setName(this.trackIDs.get(item), label);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getSeriesKey(int series) {
/*  78 */     if (series < 0 || series >= getSeriesCount())
/*  79 */       throw new IllegalArgumentException("Series index out of bounds"); 
/*  80 */     return (String)this.model.getFeatureModel().getTrackFeatureShortNames().get(this.yFeatures.get(series));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Number getX(int series, int item) {
/*  86 */     return this.model.getFeatureModel().getTrackFeature(this.trackIDs.get(item), this.xFeature);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Number getY(int series, int item) {
/*  92 */     return this.model.getFeatureModel().getTrackFeature(this.trackIDs.get(item), this.yFeatures.get(series));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public XYItemRenderer getRenderer() {
/*  98 */     return (XYItemRenderer)new MyXYItemRenderer();
/*     */   }
/*     */ 
/*     */   
/*     */   private final class MyXYItemRenderer
/*     */     extends XYLineAndShapeRenderer
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */     
/*     */     public MyXYItemRenderer() {
/* 108 */       super(false, true);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Paint getItemPaint(int series, int item) {
/* 114 */       Integer trackID = TrackCollectionDataset.this.trackIDs.get(item);
/* 115 */       if (TrackCollectionDataset.this.selectionModel != null && TrackCollectionDataset.this.selectionModel.getSpotSelection().containsAll(TrackCollectionDataset.this.model.getTrackModel().trackSpots(trackID))) {
/* 116 */         return TrackCollectionDataset.this.ds.getHighlightColor();
/*     */       }
/* 118 */       FeatureColorGenerator<Integer> trackColorGenerator = FeatureUtils.createWholeTrackColorGenerator(TrackCollectionDataset.this.model, TrackCollectionDataset.this.ds);
/* 119 */       return trackColorGenerator.color(TrackCollectionDataset.this.trackIDs.get(item));
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Stroke getItemStroke(int series, int item) {
/* 125 */       Integer trackID = TrackCollectionDataset.this.trackIDs.get(item);
/* 126 */       if (TrackCollectionDataset.this.selectionModel != null && TrackCollectionDataset.this.selectionModel.getSpotSelection().containsAll(TrackCollectionDataset.this.model.getTrackModel().trackSpots(trackID)))
/* 127 */         return TrackCollectionDataset.this.selectionStroke; 
/* 128 */       return TrackCollectionDataset.this.stroke;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public LegendItem getLegendItem(int datasetIndex, int series) {
/* 134 */       LegendItem legendItem = super.getLegendItem(datasetIndex, series);
/* 135 */       legendItem.setFillPaint(Color.BLACK);
/* 136 */       legendItem.setLinePaint(Color.BLACK);
/* 137 */       legendItem.setOutlinePaint(Color.BLACK);
/* 138 */       return legendItem;
/*     */     }
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/features/TrackCollectionDataset.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */