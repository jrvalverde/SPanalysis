/*     */ package fiji.plugin.trackmate.gui.components.tracker;
/*     */ 
/*     */ import fiji.plugin.trackmate.gui.Fonts;
/*     */ import fiji.plugin.trackmate.gui.GuiUtils;
/*     */ import fiji.plugin.trackmate.util.TMUtils;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.LayoutManager;
/*     */ import java.text.DecimalFormat;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.swing.ComboBoxModel;
/*     */ import javax.swing.DefaultComboBoxModel;
/*     */ import javax.swing.JComboBox;
/*     */ import javax.swing.JFormattedTextField;
/*     */ import javax.swing.JPanel;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JPanelFeaturePenalty
/*     */   extends JPanel
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private final JComboBox<String> cmbboxFeature;
/*     */   private final JFormattedTextField txtfldFeatureWeight;
/*     */   private final List<String> features;
/*     */   
/*     */   public JPanelFeaturePenalty(List<String> features, Map<String, String> featureNames, int index) {
/*  52 */     this.features = features;
/*     */     
/*  54 */     setPreferredSize(new Dimension(280, 40));
/*  55 */     setSize(280, 40);
/*  56 */     setLayout((LayoutManager)null);
/*     */ 
/*     */     
/*  59 */     ComboBoxModel<String> jComboBoxFeatureModel = new DefaultComboBoxModel<>((String[])TMUtils.getArrayFromMaping(features, featureNames).toArray((Object[])new String[0]));
/*  60 */     this.cmbboxFeature = new JComboBox<>();
/*  61 */     add(this.cmbboxFeature);
/*  62 */     this.cmbboxFeature.setModel(jComboBoxFeatureModel);
/*  63 */     this.cmbboxFeature.setBounds(2, 4, 205, 22);
/*  64 */     this.cmbboxFeature.setFont(Fonts.SMALL_FONT);
/*     */     
/*  66 */     this.txtfldFeatureWeight = new JFormattedTextField(new DecimalFormat("0.0"));
/*  67 */     this.txtfldFeatureWeight.setHorizontalAlignment(0);
/*  68 */     this.txtfldFeatureWeight.setValue(Double.valueOf(1.0D));
/*  69 */     add(this.txtfldFeatureWeight);
/*  70 */     this.txtfldFeatureWeight.setBounds(220, 4, 30, 22);
/*  71 */     this.txtfldFeatureWeight.setSize(Fonts.TEXTFIELD_DIMENSION);
/*  72 */     this.txtfldFeatureWeight.setFont(Fonts.SMALL_FONT);
/*     */ 
/*     */     
/*  75 */     GuiUtils.selectAllOnFocus(this.txtfldFeatureWeight);
/*     */ 
/*     */     
/*  78 */     this.cmbboxFeature.setSelectedIndex(index);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSelectedFeature(String feature, double weight) {
/*  87 */     int index = this.features.indexOf(feature);
/*  88 */     if (index < 0)
/*     */       return; 
/*  90 */     this.cmbboxFeature.setSelectedIndex(index);
/*  91 */     this.txtfldFeatureWeight.setValue(Double.valueOf(weight));
/*     */   }
/*     */ 
/*     */   
/*     */   public String getSelectedFeature() {
/*  96 */     return this.features.get(this.cmbboxFeature.getSelectedIndex());
/*     */   }
/*     */ 
/*     */   
/*     */   public double getPenaltyWeight() {
/* 101 */     return ((Number)this.txtfldFeatureWeight.getValue()).doubleValue();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setEnabled(boolean enabled) {
/* 107 */     super.setEnabled(enabled);
/* 108 */     this.cmbboxFeature.setEnabled(enabled);
/* 109 */     this.txtfldFeatureWeight.setEnabled(enabled);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/gui/components/tracker/JPanelFeaturePenalty.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */