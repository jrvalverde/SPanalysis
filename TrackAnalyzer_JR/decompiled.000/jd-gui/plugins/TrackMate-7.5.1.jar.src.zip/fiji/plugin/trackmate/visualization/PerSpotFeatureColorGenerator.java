/*    */ package fiji.plugin.trackmate.visualization;
/*    */ 
/*    */ import fiji.plugin.trackmate.Model;
/*    */ import fiji.plugin.trackmate.Spot;
/*    */ import fiji.plugin.trackmate.gui.displaysettings.Colormap;
/*    */ import java.awt.Color;
/*    */ import org.jgrapht.graph.DefaultWeightedEdge;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PerSpotFeatureColorGenerator
/*    */   implements TrackColorGenerator
/*    */ {
/*    */   private final Model model;
/*    */   private final String spotFeature;
/*    */   private final Color missingValueColor;
/*    */   private final Color undefinedValueColor;
/*    */   private final Colormap colormap;
/*    */   private final double min;
/*    */   private final double max;
/*    */   
/*    */   public PerSpotFeatureColorGenerator(Model model, String spotFeature, Color missingValueColor, Color undefinedValueColor, Colormap colormap, double min, double max) {
/* 58 */     this.model = model;
/* 59 */     this.spotFeature = spotFeature;
/* 60 */     this.missingValueColor = missingValueColor;
/* 61 */     this.undefinedValueColor = undefinedValueColor;
/* 62 */     this.colormap = colormap;
/* 63 */     this.min = min;
/* 64 */     this.max = max;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Color color(DefaultWeightedEdge edge) {
/* 70 */     Spot spot = this.model.getTrackModel().getEdgeTarget(edge);
/* 71 */     Double feat = spot.getFeature(this.spotFeature);
/*    */     
/* 73 */     if (null == feat) {
/* 74 */       return this.missingValueColor;
/*    */     }
/* 76 */     if (feat.isNaN()) {
/* 77 */       return this.undefinedValueColor;
/*    */     }
/* 79 */     double val = feat.doubleValue();
/* 80 */     return this.colormap.getPaint((val - this.min) / (this.max - this.min));
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/visualization/PerSpotFeatureColorGenerator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */