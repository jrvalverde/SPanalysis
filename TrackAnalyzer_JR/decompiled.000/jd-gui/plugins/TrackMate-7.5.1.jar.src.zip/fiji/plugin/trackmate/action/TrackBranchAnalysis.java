/*    */ package fiji.plugin.trackmate.action;
/*    */ 
/*    */ import fiji.plugin.trackmate.Model;
/*    */ import fiji.plugin.trackmate.SelectionModel;
/*    */ import fiji.plugin.trackmate.TrackMate;
/*    */ import fiji.plugin.trackmate.gui.Icons;
/*    */ import fiji.plugin.trackmate.gui.displaysettings.DisplaySettings;
/*    */ import fiji.plugin.trackmate.visualization.table.BranchTableView;
/*    */ import java.awt.Frame;
/*    */ import javax.swing.ImageIcon;
/*    */ import org.scijava.plugin.Plugin;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TrackBranchAnalysis
/*    */   extends AbstractTMAction
/*    */ {
/*    */   private static final String INFO_TEXT = "<html>This action analyzes each branch of all tracks, and outputs in an ImageJ results table the number of its predecessors, of successors, and its duration.<p>The results table is in sync with the selection. Clicking on a line will select the target branch.</html>";
/*    */   private static final String KEY = "TRACK_BRANCH_ANALYSIS";
/*    */   private static final String NAME = "Branch hierarchy analysis";
/*    */   
/*    */   public void execute(TrackMate trackmate, SelectionModel selectionModel, DisplaySettings displaySettings, Frame parent) {
/* 58 */     createBranchTable(trackmate.getModel(), selectionModel).render();
/*    */   }
/*    */ 
/*    */   
/*    */   public static final BranchTableView createBranchTable(Model model, SelectionModel selectionModel) {
/* 63 */     return new BranchTableView(model, selectionModel);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   @Plugin(type = TrackMateActionFactory.class, enabled = true)
/*    */   public static class Factory
/*    */     implements TrackMateActionFactory
/*    */   {
/*    */     public String getInfoText() {
/* 73 */       return "<html>This action analyzes each branch of all tracks, and outputs in an ImageJ results table the number of its predecessors, of successors, and its duration.<p>The results table is in sync with the selection. Clicking on a line will select the target branch.</html>";
/*    */     }
/*    */ 
/*    */ 
/*    */     
/*    */     public String getName() {
/* 79 */       return "Branch hierarchy analysis";
/*    */     }
/*    */ 
/*    */ 
/*    */     
/*    */     public String getKey() {
/* 85 */       return "TRACK_BRANCH_ANALYSIS";
/*    */     }
/*    */ 
/*    */ 
/*    */     
/*    */     public TrackMateAction create() {
/* 91 */       return new TrackBranchAnalysis();
/*    */     }
/*    */ 
/*    */ 
/*    */     
/*    */     public ImageIcon getIcon() {
/* 97 */       return Icons.BRANCH_ICON_16x16;
/*    */     }
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/action/TrackBranchAnalysis.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */