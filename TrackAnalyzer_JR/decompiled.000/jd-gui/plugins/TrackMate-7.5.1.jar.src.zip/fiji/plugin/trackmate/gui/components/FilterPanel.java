/*     */ package fiji.plugin.trackmate.gui.components;
/*     */ 
/*     */ import fiji.plugin.trackmate.features.FeatureFilter;
/*     */ import fiji.plugin.trackmate.util.TMUtils;
/*     */ import fiji.util.NumberParser;
/*     */ import java.awt.BasicStroke;
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Font;
/*     */ import java.awt.GridBagConstraints;
/*     */ import java.awt.GridBagLayout;
/*     */ import java.awt.Insets;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.FocusEvent;
/*     */ import java.awt.event.FocusListener;
/*     */ import java.awt.event.KeyEvent;
/*     */ import java.awt.event.KeyListener;
/*     */ import java.awt.event.MouseAdapter;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.awt.event.MouseListener;
/*     */ import java.awt.geom.Rectangle2D;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.Executors;
/*     */ import java.util.concurrent.ScheduledExecutorService;
/*     */ import java.util.concurrent.ScheduledFuture;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.function.Function;
/*     */ import javax.swing.ButtonGroup;
/*     */ import javax.swing.ComboBoxModel;
/*     */ import javax.swing.DefaultComboBoxModel;
/*     */ import javax.swing.DefaultListCellRenderer;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JComboBox;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JList;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JRadioButton;
/*     */ import javax.swing.border.LineBorder;
/*     */ import javax.swing.event.ChangeEvent;
/*     */ import javax.swing.event.ChangeListener;
/*     */ import org.jfree.chart.ChartFactory;
/*     */ import org.jfree.chart.ChartPanel;
/*     */ import org.jfree.chart.JFreeChart;
/*     */ import org.jfree.chart.annotations.XYAnnotation;
/*     */ import org.jfree.chart.plot.IntervalMarker;
/*     */ import org.jfree.chart.plot.Marker;
/*     */ import org.jfree.chart.plot.PlotOrientation;
/*     */ import org.jfree.chart.plot.XYPlot;
/*     */ import org.jfree.chart.renderer.xy.StandardXYBarPainter;
/*     */ import org.jfree.chart.renderer.xy.XYBarPainter;
/*     */ import org.jfree.chart.renderer.xy.XYBarRenderer;
/*     */ import org.jfree.data.xy.IntervalXYDataset;
/*     */ import org.jfree.data.xy.XYDataset;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FilterPanel
/*     */   extends JPanel
/*     */ {
/*  85 */   static final Font FONT = new Font("Arial", 0, 11);
/*     */   
/*  87 */   static final Font SMALL_FONT = FONT.deriveFont(10.0F);
/*     */   
/*  89 */   private static final Color annotationColor = new Color(252, 117, 0);
/*     */   
/*     */   private static final long serialVersionUID = 1L;
/*     */   
/*     */   private static final String DATA_SERIES_NAME = "Data";
/*     */   
/*  95 */   private final ChangeEvent CHANGE_EVENT = new ChangeEvent(this);
/*     */   
/*     */   private final XYPlot plot;
/*     */   
/*     */   private final IntervalMarker intervalMarker;
/*     */   
/*     */   private double threshold;
/*     */   
/*     */   private final Function<String, double[]> valueCollector;
/*     */   
/*     */   private final XYTextSimpleAnnotation annotation;
/*     */   
/* 107 */   private final ArrayList<ChangeListener> listeners = new ArrayList<>();
/*     */ 
/*     */ 
/*     */   
/*     */   final JRadioButton rdbtnAbove;
/*     */ 
/*     */ 
/*     */   
/*     */   final JRadioButton rdbtnBelow;
/*     */ 
/*     */ 
/*     */   
/*     */   final JComboBox<String> cmbboxFeatureKeys;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FilterPanel(final Map<String, String> keyNames, Function<String, double[]> valueCollector, FeatureFilter filter) {
/* 125 */     this.valueCollector = valueCollector;
/*     */     
/* 127 */     Dimension panelSize = new Dimension(250, 140);
/* 128 */     Dimension panelMaxSize = new Dimension(1000, 140);
/* 129 */     GridBagLayout thisLayout = new GridBagLayout();
/* 130 */     thisLayout.rowWeights = new double[] { 0.0D, 1.0D, 0.0D };
/* 131 */     thisLayout.rowHeights = new int[] { 10, 7, 15 };
/* 132 */     thisLayout.columnWeights = new double[] { 0.0D, 0.0D, 1.0D };
/* 133 */     thisLayout.columnWidths = new int[] { 7, 20, 7 };
/* 134 */     setLayout(thisLayout);
/* 135 */     setPreferredSize(panelSize);
/* 136 */     setMaximumSize(panelMaxSize);
/* 137 */     setBorder(new LineBorder(annotationColor, 1, true));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 143 */     ComboBoxModel<String> cmbboxFeatureNameModel = new DefaultComboBoxModel<>((String[])keyNames.keySet().toArray((Object[])new String[0]));
/* 144 */     this.cmbboxFeatureKeys = new JComboBox<>(cmbboxFeatureNameModel);
/* 145 */     this.cmbboxFeatureKeys.setRenderer(new DefaultListCellRenderer()
/*     */         {
/*     */           private static final long serialVersionUID = 1L;
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           public Component getListCellRendererComponent(JList<?> list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
/* 153 */             JLabel lbl = (JLabel)super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
/* 154 */             lbl.setText((String)keyNames.get(value));
/* 155 */             return lbl;
/*     */           }
/*     */         });
/* 158 */     this.cmbboxFeatureKeys.setFont(FONT);
/* 159 */     add(this.cmbboxFeatureKeys, new GridBagConstraints(0, 0, 3, 1, 0.0D, 0.0D, 10, 2, new Insets(2, 5, 2, 5), 0, 0));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 165 */     LogHistogramDataset dataset = new LogHistogramDataset();
/* 166 */     JFreeChart chart = ChartFactory.createHistogram(null, null, null, (IntervalXYDataset)dataset, PlotOrientation.VERTICAL, false, false, false);
/*     */     
/* 168 */     this.plot = chart.getXYPlot();
/* 169 */     XYBarRenderer renderer = (XYBarRenderer)this.plot.getRenderer();
/* 170 */     renderer.setShadowVisible(false);
/* 171 */     renderer.setMargin(0.0D);
/* 172 */     renderer.setBarPainter((XYBarPainter)new StandardXYBarPainter());
/* 173 */     renderer.setDrawBarOutline(true);
/* 174 */     renderer.setSeriesOutlinePaint(0, new Color(0.2F, 0.2F, 0.2F));
/* 175 */     renderer.setSeriesPaint(0, new Color(0.3F, 0.3F, 0.3F, 0.5F));
/*     */     
/* 177 */     this.plot.setBackgroundPaint(new Color(1, 1, 1, 0));
/* 178 */     this.plot.setOutlineVisible(false);
/* 179 */     this.plot.setDomainCrosshairVisible(false);
/* 180 */     this.plot.setDomainGridlinesVisible(false);
/* 181 */     this.plot.setRangeCrosshairVisible(false);
/* 182 */     this.plot.setRangeGridlinesVisible(false);
/*     */     
/* 184 */     this.plot.getRangeAxis().setVisible(false);
/* 185 */     this.plot.getDomainAxis().setVisible(false);
/*     */     
/* 187 */     chart.setBorderVisible(false);
/* 188 */     chart.setBackgroundPaint(new Color(0.6F, 0.6F, 0.7F));
/*     */     
/* 190 */     this.intervalMarker = new IntervalMarker(0.0D, 0.0D, new Color(0.3F, 0.5F, 0.8F), new BasicStroke(), new Color(0.0F, 0.0F, 0.5F), new BasicStroke(1.5F), 0.5F);
/* 191 */     this.plot.addDomainMarker((Marker)this.intervalMarker);
/*     */     
/* 193 */     final ChartPanel chartPanel = new ChartPanel(chart);
/* 194 */     MouseListener[] mls = chartPanel.getMouseListeners();
/* 195 */     for (MouseListener ml : mls) {
/* 196 */       chartPanel.removeMouseListener(ml);
/*     */     }
/* 198 */     chartPanel.addMouseListener(new MouseAdapter()
/*     */         {
/*     */           
/*     */           public void mouseClicked(MouseEvent e)
/*     */           {
/* 203 */             chartPanel.requestFocusInWindow();
/* 204 */             FilterPanel.this.threshold = FilterPanel.this.getXFromChartEvent(e, chartPanel);
/* 205 */             FilterPanel.this.redrawThresholdMarker();
/*     */           }
/*     */         });
/* 208 */     chartPanel.addMouseMotionListener(new MouseAdapter()
/*     */         {
/*     */           
/*     */           public void mouseDragged(MouseEvent e)
/*     */           {
/* 213 */             FilterPanel.this.threshold = FilterPanel.this.getXFromChartEvent(e, chartPanel);
/* 214 */             FilterPanel.this.redrawThresholdMarker();
/*     */           }
/*     */         });
/* 217 */     chartPanel.setFocusable(true);
/* 218 */     chartPanel.addFocusListener(new FocusListener()
/*     */         {
/*     */ 
/*     */           
/*     */           public void focusLost(FocusEvent e)
/*     */           {
/* 224 */             FilterPanel.this.annotation.setColor(FilterPanel.annotationColor.darker());
/*     */           }
/*     */ 
/*     */ 
/*     */           
/*     */           public void focusGained(FocusEvent e) {
/* 230 */             FilterPanel.this.annotation.setColor(Color.RED.darker());
/*     */           }
/*     */         });
/* 233 */     chartPanel.addKeyListener(new MyKeyListener());
/*     */     
/* 235 */     this.annotation = new XYTextSimpleAnnotation(chartPanel);
/* 236 */     this.annotation.setFont(SMALL_FONT.deriveFont(1));
/* 237 */     this.annotation.setColor(annotationColor.darker());
/* 238 */     this.plot.addAnnotation((XYAnnotation)this.annotation);
/*     */     
/* 240 */     chartPanel.setPreferredSize(new Dimension(0, 0));
/* 241 */     add((Component)chartPanel, new GridBagConstraints(0, 1, 3, 1, 0.0D, 0.0D, 10, 1, new Insets(0, 0, 0, 0), 0, 0));
/* 242 */     chartPanel.setOpaque(false);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 248 */     JButton btnAutoThreshold = new JButton();
/* 249 */     add(btnAutoThreshold, new GridBagConstraints(2, 2, 1, 1, 0.0D, 0.0D, 13, 0, new Insets(0, 0, 0, 10), 0, 0));
/* 250 */     btnAutoThreshold.setText("Auto");
/* 251 */     btnAutoThreshold.setFont(SMALL_FONT);
/* 252 */     btnAutoThreshold.addActionListener(e -> autoThreshold());
/*     */     
/* 254 */     this.rdbtnAbove = new JRadioButton();
/* 255 */     add(this.rdbtnAbove, new GridBagConstraints(0, 2, 1, 1, 0.0D, 0.0D, 17, 0, new Insets(0, 10, 0, 0), 0, 0));
/* 256 */     this.rdbtnAbove.setText("Above");
/* 257 */     this.rdbtnAbove.setFont(SMALL_FONT);
/* 258 */     this.rdbtnAbove.addActionListener(e -> redrawThresholdMarker());
/*     */     
/* 260 */     this.rdbtnBelow = new JRadioButton();
/* 261 */     add(this.rdbtnBelow, new GridBagConstraints(1, 2, 1, 1, 0.0D, 0.0D, 10, 0, new Insets(0, 5, 0, 0), 0, 0));
/* 262 */     this.rdbtnBelow.setText("Below");
/* 263 */     this.rdbtnBelow.addActionListener(e -> redrawThresholdMarker());
/* 264 */     this.rdbtnBelow.setFont(SMALL_FONT);
/*     */     
/* 266 */     ButtonGroup buttonGroup = new ButtonGroup();
/* 267 */     buttonGroup.add(this.rdbtnAbove);
/* 268 */     buttonGroup.add(this.rdbtnBelow);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 274 */     this.cmbboxFeatureKeys.addActionListener(e -> comboBoxSelectionChanged());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 280 */     this.cmbboxFeatureKeys.setSelectedItem(filter.feature);
/* 281 */     this.rdbtnAbove.setSelected(filter.isAbove);
/* 282 */     this.rdbtnBelow.setSelected(!filter.isAbove);
/* 283 */     if (Double.isNaN(filter.value)) {
/* 284 */       autoThreshold();
/*     */     } else {
/* 286 */       this.threshold = filter.value;
/* 287 */     }  redrawThresholdMarker();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FeatureFilter getFilter() {
/* 296 */     return new FeatureFilter((String)this.cmbboxFeatureKeys.getSelectedItem(), this.threshold, this.rdbtnAbove.isSelected());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addChangeListener(ChangeListener listener) {
/* 307 */     this.listeners.add(listener);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean removeChangeListener(ChangeListener listener) {
/* 317 */     return this.listeners.remove(listener);
/*     */   }
/*     */ 
/*     */   
/*     */   public Collection<ChangeListener> getChangeListeners() {
/* 322 */     return this.listeners;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void refresh() {
/*     */     LogHistogramDataset dataset;
/* 331 */     double old = this.threshold;
/* 332 */     String key = (String)this.cmbboxFeatureKeys.getSelectedItem();
/* 333 */     double[] values = this.valueCollector.apply(key);
/*     */ 
/*     */     
/* 336 */     if (null == values || 0 == values.length) {
/*     */       
/* 338 */       dataset = new LogHistogramDataset();
/* 339 */       this.annotation.setLocation(0.5F, 0.5F);
/* 340 */       this.annotation.setText("No data");
/*     */     }
/*     */     else {
/*     */       
/* 344 */       int nBins = TMUtils.getNBins(values, 8, 100);
/* 345 */       dataset = new LogHistogramDataset();
/* 346 */       if (nBins > 1)
/* 347 */         dataset.addSeries("Data", values, nBins); 
/*     */     } 
/* 349 */     this.plot.setDataset((XYDataset)dataset);
/* 350 */     this.threshold = old;
/* 351 */     repaint();
/* 352 */     redrawThresholdMarker();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void fireThresholdChanged() {
/* 361 */     for (ChangeListener al : this.listeners)
/* 362 */       al.stateChanged(this.CHANGE_EVENT); 
/*     */   }
/*     */   
/*     */   private void comboBoxSelectionChanged() {
/*     */     LogHistogramDataset dataset;
/* 367 */     String key = (String)this.cmbboxFeatureKeys.getSelectedItem();
/* 368 */     double[] values = this.valueCollector.apply(key);
/*     */ 
/*     */     
/* 371 */     if (null == values || 0 == values.length) {
/*     */       
/* 373 */       dataset = new LogHistogramDataset();
/* 374 */       this.threshold = Double.NaN;
/* 375 */       this.annotation.setLocation(0.5F, 0.5F);
/* 376 */       this.annotation.setText("No data");
/* 377 */       fireThresholdChanged();
/*     */     }
/*     */     else {
/*     */       
/* 381 */       int nBins = TMUtils.getNBins(values, 8, 100);
/* 382 */       dataset = new LogHistogramDataset();
/*     */       
/* 384 */       if (nBins > 1)
/* 385 */         dataset.addSeries("Data", values, nBins); 
/*     */     } 
/* 387 */     this.plot.setDataset((XYDataset)dataset);
/* 388 */     resetAxes();
/* 389 */     autoThreshold();
/*     */   }
/*     */ 
/*     */   
/*     */   private void autoThreshold() {
/* 394 */     String key = (String)this.cmbboxFeatureKeys.getSelectedItem();
/* 395 */     double[] values = this.valueCollector.apply(key);
/* 396 */     if (null != values && values.length > 0) {
/*     */       
/* 398 */       this.threshold = TMUtils.otsuThreshold(values);
/* 399 */       redrawThresholdMarker();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private double getXFromChartEvent(MouseEvent mouseEvent, ChartPanel chartPanel) {
/* 405 */     Rectangle2D plotArea = chartPanel.getScreenDataArea();
/* 406 */     return this.plot.getDomainAxis().java2DToValue(mouseEvent.getX(), plotArea, this.plot.getDomainAxisEdge());
/*     */   }
/*     */   
/*     */   private void redrawThresholdMarker() {
/*     */     float x;
/* 411 */     String key = (String)this.cmbboxFeatureKeys.getSelectedItem();
/* 412 */     double[] values = this.valueCollector.apply(key);
/* 413 */     if (null == values) {
/*     */       return;
/*     */     }
/* 416 */     if (this.rdbtnAbove.isSelected()) {
/*     */       
/* 418 */       this.intervalMarker.setStartValue(this.threshold);
/* 419 */       this.intervalMarker.setEndValue(this.plot.getDomainAxis().getUpperBound());
/*     */     }
/*     */     else {
/*     */       
/* 423 */       this.intervalMarker.setStartValue(this.plot.getDomainAxis().getLowerBound());
/* 424 */       this.intervalMarker.setEndValue(this.threshold);
/*     */     } 
/*     */ 
/*     */     
/* 428 */     if (this.threshold > 0.85D * this.plot.getDomainAxis().getUpperBound()) {
/* 429 */       x = (float)(this.threshold - 0.15D * this.plot.getDomainAxis().getRange().getLength());
/*     */     } else {
/* 431 */       x = (float)(this.threshold + 0.05D * this.plot.getDomainAxis().getRange().getLength());
/*     */     } 
/* 433 */     float y = (float)(0.85D * this.plot.getRangeAxis().getUpperBound());
/* 434 */     this.annotation.setText(String.format("%.2f", new Object[] { Double.valueOf(this.threshold) }));
/* 435 */     this.annotation.setLocation(x, y);
/* 436 */     fireThresholdChanged();
/*     */   }
/*     */ 
/*     */   
/*     */   private void resetAxes() {
/* 441 */     this.plot.getRangeAxis().setLowerMargin(0.0D);
/* 442 */     this.plot.getRangeAxis().setUpperMargin(0.0D);
/* 443 */     this.plot.getDomainAxis().setLowerMargin(0.0D);
/* 444 */     this.plot.getDomainAxis().setUpperMargin(0.0D);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final class MyKeyListener
/*     */     implements KeyListener
/*     */   {
/*     */     private static final long WAIT_DELAY = 1L;
/*     */ 
/*     */ 
/*     */     
/*     */     private static final double INCREASE_FACTOR = 0.1D;
/*     */ 
/*     */ 
/*     */     
/*     */     private static final double SLOW_INCREASE_FACTOR = 0.005D;
/*     */ 
/*     */     
/* 464 */     private String strNumber = "";
/*     */     
/*     */     private ScheduledExecutorService ex;
/*     */     
/*     */     private ScheduledFuture<?> future;
/*     */     
/*     */     private boolean dotAdded = false;
/*     */     
/* 472 */     private final Runnable command = new Runnable()
/*     */       {
/*     */ 
/*     */ 
/*     */         
/*     */         public void run()
/*     */         {
/*     */           try {
/* 480 */             double typedThreshold = NumberParser.parseDouble(FilterPanel.MyKeyListener.this.strNumber);
/* 481 */             FilterPanel.this.threshold = typedThreshold;
/* 482 */             FilterPanel.this.redrawThresholdMarker();
/*     */           }
/* 484 */           catch (NumberFormatException numberFormatException) {}
/*     */ 
/*     */           
/* 487 */           FilterPanel.MyKeyListener.this.ex = null;
/* 488 */           FilterPanel.MyKeyListener.this.strNumber = "";
/* 489 */           FilterPanel.MyKeyListener.this.dotAdded = false;
/*     */         }
/*     */       };
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void keyPressed(KeyEvent e) {
/* 497 */       if (e.getKeyCode() == 37 || e.getKeyCode() == 226) {
/*     */         
/* 499 */         FilterPanel.this.threshold = FilterPanel.this.threshold - (e.isControlDown() ? 0.005D : 0.1D) * FilterPanel.this.plot.getDomainAxis().getRange().getLength();
/* 500 */         FilterPanel.this.redrawThresholdMarker();
/*     */         return;
/*     */       } 
/* 503 */       if (e.getKeyCode() == 39 || e.getKeyCode() == 227) {
/*     */         
/* 505 */         FilterPanel.this.threshold = FilterPanel.this.threshold + (e.isControlDown() ? 0.005D : 0.1D) * FilterPanel.this.plot.getDomainAxis().getRange().getLength();
/* 506 */         FilterPanel.this.redrawThresholdMarker();
/*     */         return;
/*     */       } 
/* 509 */       if (e.getKeyCode() == 38 || e.getKeyCode() == 224) {
/*     */         
/* 511 */         FilterPanel.this.threshold = FilterPanel.this.plot.getDomainAxis().getRange().getUpperBound();
/* 512 */         FilterPanel.this.redrawThresholdMarker();
/*     */         return;
/*     */       } 
/* 515 */       if (e.getKeyCode() == 40 || e.getKeyCode() == 225) {
/*     */         
/* 517 */         FilterPanel.this.threshold = FilterPanel.this.plot.getDomainAxis().getRange().getLowerBound();
/* 518 */         FilterPanel.this.redrawThresholdMarker();
/*     */         return;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void keyReleased(KeyEvent e) {}
/*     */ 
/*     */ 
/*     */     
/*     */     public void keyTyped(KeyEvent e) {
/* 531 */       if (e.getKeyChar() < '0' || e.getKeyChar() > '9')
/*     */       {
/*     */ 
/*     */         
/* 535 */         if (!this.dotAdded && e.getKeyChar() == '.') {
/*     */ 
/*     */           
/* 538 */           this.dotAdded = true;
/*     */         } else {
/*     */           return;
/*     */         } 
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 546 */       if (this.ex == null) {
/*     */ 
/*     */         
/* 549 */         this.ex = Executors.newSingleThreadScheduledExecutor();
/* 550 */         this.future = this.ex.schedule(this.command, 1L, TimeUnit.SECONDS);
/*     */       
/*     */       }
/*     */       else {
/*     */         
/* 555 */         this.future.cancel(false);
/* 556 */         this.future = this.ex.schedule(this.command, 1L, TimeUnit.SECONDS);
/*     */       } 
/* 558 */       this.strNumber += e.getKeyChar();
/*     */     }
/*     */     
/*     */     private MyKeyListener() {}
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/gui/components/FilterPanel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */