/*    */ package fiji.plugin.trackmate.features;
/*    */ 
/*    */ import fiji.plugin.trackmate.Dimension;
/*    */ import fiji.plugin.trackmate.Model;
/*    */ import fiji.plugin.trackmate.SelectionModel;
/*    */ import fiji.plugin.trackmate.Spot;
/*    */ import fiji.plugin.trackmate.gui.displaysettings.DisplaySettings;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SpotFeatureGrapher
/*    */   extends AbstractFeatureGrapher
/*    */ {
/*    */   private final List<Spot> spots;
/*    */   private final SelectionModel selectionModel;
/*    */   private final Model model;
/*    */   private final DisplaySettings ds;
/*    */   private final boolean addLines;
/*    */   
/*    */   public SpotFeatureGrapher(List<Spot> spots, String xFeature, List<String> yFeatures, Model model, SelectionModel selectionModel, DisplaySettings displaySettings, boolean addLines) {
/* 53 */     super(xFeature, yFeatures, (Dimension)model
/*    */ 
/*    */         
/* 56 */         .getFeatureModel().getSpotFeatureDimensions().get(xFeature), model
/* 57 */         .getFeatureModel().getSpotFeatureDimensions(), model
/* 58 */         .getFeatureModel().getSpotFeatureNames(), model
/* 59 */         .getSpaceUnits(), model
/* 60 */         .getTimeUnits());
/* 61 */     this.spots = spots;
/* 62 */     this.model = model;
/* 63 */     this.selectionModel = selectionModel;
/* 64 */     this.ds = displaySettings;
/* 65 */     this.addLines = addLines;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected ModelDataset buildMainDataSet(List<String> targetYFeatures) {
/* 71 */     return new SpotCollectionDataset(this.model, this.selectionModel, this.ds, this.xFeature, targetYFeatures, this.spots, this.addLines);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/features/SpotFeatureGrapher.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */