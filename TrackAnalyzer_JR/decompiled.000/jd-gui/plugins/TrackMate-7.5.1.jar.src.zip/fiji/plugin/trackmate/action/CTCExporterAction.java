/*     */ package fiji.plugin.trackmate.action;
/*     */ 
/*     */ import fiji.plugin.trackmate.SelectionModel;
/*     */ import fiji.plugin.trackmate.TrackMate;
/*     */ import fiji.plugin.trackmate.gui.Icons;
/*     */ import fiji.plugin.trackmate.gui.displaysettings.DisplaySettings;
/*     */ import ij.ImagePlus;
/*     */ import ij.gui.GenericDialog;
/*     */ import java.awt.Frame;
/*     */ import java.io.IOException;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import java.util.stream.Collectors;
/*     */ import javax.swing.ImageIcon;
/*     */ import org.scijava.plugin.Plugin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CTCExporterAction
/*     */   extends AbstractTMAction
/*     */ {
/*     */   public static final String NAME = "Export to CTC format";
/*     */   public static final String KEY = "CTC_EXPORTER";
/*     */   public static final String INFO_TEXT = "<html>Export the current TrackMate session to the Cell-Tracking-Challenge file format.<p>See the <a url=\"http://celltrackingchallenge.net/\">challenge webpage</a> for details: http://celltrackingchallenge.net</html>";
/*     */   
/*     */   public void execute(TrackMate trackmate, SelectionModel selectionModel, DisplaySettings displaySettings, Frame parent) {
/*     */     String defaultPath;
/*  58 */     GenericDialog dialog = new GenericDialog("CTC exporter", parent);
/*     */     
/*  60 */     ImagePlus imp = (trackmate.getSettings()).imp;
/*     */     
/*  62 */     if (imp == null || imp.getOriginalFileInfo() == null) {
/*  63 */       defaultPath = System.getProperty("user.home");
/*     */     } else {
/*  65 */       defaultPath = (imp.getOriginalFileInfo()).directory;
/*     */     } 
/*  67 */     dialog.addDirectoryField("Export to", defaultPath);
/*     */ 
/*     */ 
/*     */     
/*  71 */     String[] valuesStr = (String[])((List)Arrays.<CTCExporter.ExportType>stream(CTCExporter.ExportType.values()).map(CTCExporter.ExportType::toString).collect(Collectors.toList())).toArray((Object[])new String[0]);
/*  72 */     dialog.addChoice("Data is", valuesStr, CTCExporter.ExportType.RESULTS.toString());
/*  73 */     dialog.showDialog();
/*     */     
/*  75 */     if (dialog.wasCanceled()) {
/*     */       return;
/*     */     }
/*  78 */     String exportRootFolder = dialog.getNextString();
/*  79 */     int choiceIndex = dialog.getNextChoiceIndex();
/*     */ 
/*     */     
/*     */     try {
/*  83 */       CTCExporter.exportAll(exportRootFolder, trackmate, CTCExporter.ExportType.values()[choiceIndex], this.logger);
/*     */     }
/*  85 */     catch (IOException e) {
/*     */       
/*  87 */       this.logger.error(e.getMessage());
/*  88 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Plugin(type = TrackMateActionFactory.class)
/*     */   public static class Factory
/*     */     implements TrackMateActionFactory
/*     */   {
/*     */     public String getInfoText() {
/*  99 */       return "<html>Export the current TrackMate session to the Cell-Tracking-Challenge file format.<p>See the <a url=\"http://celltrackingchallenge.net/\">challenge webpage</a> for details: http://celltrackingchallenge.net</html>";
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public String getKey() {
/* 105 */       return "CTC_EXPORTER";
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public TrackMateAction create() {
/* 111 */       return new CTCExporterAction();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public ImageIcon getIcon() {
/* 117 */       return Icons.ISBI_ICON;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public String getName() {
/* 123 */       return "Export to CTC format";
/*     */     }
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/action/CTCExporterAction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */