/*     */ package fiji.plugin.trackmate.tracking.kalman;
/*     */ 
/*     */ import Jama.Matrix;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CVMKalmanFilter
/*     */ {
/*     */   private final Matrix A;
/*     */   private Matrix P;
/*     */   private final Matrix Q;
/*     */   private final Matrix R;
/*     */   private Matrix X;
/*     */   private final Matrix H;
/*     */   private Matrix Xp;
/*     */   private int nOcclusion;
/*     */   
/*     */   public CVMKalmanFilter(double[] X0, double initStateCovariance, double positionProcessStd, double velocityProcessStd, double positionMeasurementStd) {
/* 106 */     this.X = new Matrix(X0, 6);
/*     */ 
/*     */     
/* 109 */     this.A = Matrix.identity(6, 6); int i;
/* 110 */     for (i = 0; i < 3; i++)
/*     */     {
/* 112 */       this.A.set(i, 3 + i, 1.0D);
/*     */     }
/*     */ 
/*     */     
/* 116 */     this.H = Matrix.identity(3, 6);
/*     */ 
/*     */     
/* 119 */     this.P = Matrix.identity(6, 6).times(initStateCovariance);
/*     */ 
/*     */     
/* 122 */     this.Q = Matrix.identity(6, 6);
/* 123 */     for (i = 0; i < 3; i++) {
/*     */       
/* 125 */       this.Q.set(i, i, positionProcessStd * positionProcessStd);
/* 126 */       this.Q.set(3 + i, 3 + i, velocityProcessStd * velocityProcessStd);
/*     */     } 
/*     */     
/* 129 */     this.R = Matrix.identity(3, 3).times(positionMeasurementStd * positionMeasurementStd);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double[] predict() {
/* 143 */     this.Xp = this.A.times(this.X);
/* 144 */     this.P = this.A.times(this.P.times(this.A.transpose())).plus(this.Q);
/* 145 */     return this.Xp.getColumnPackedCopy();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void update(double[] Xm) {
/* 161 */     if (null == Xm) {
/*     */ 
/*     */       
/* 164 */       this.nOcclusion++;
/* 165 */       this.X = this.Xp;
/*     */     }
/*     */     else {
/*     */       
/* 169 */       Matrix XM = new Matrix(Xm, 3);
/* 170 */       Matrix TEMP = this.H.times(this.P.times(this.H.transpose())).plus(this.R);
/* 171 */       Matrix K = this.P.times(this.H.transpose()).times(TEMP.inverse());
/*     */       
/* 173 */       this.X = this.Xp.plus(K.times(XM.minus(this.H.times(this.Xp))));
/*     */       
/* 175 */       this.P = Matrix.identity(6, 6).minus(K.times(this.H)).times(this.P);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getPositionError() {
/* 187 */     return Math.sqrt((this.P.get(0, 0) + this.P.get(1, 1) + this.P.get(2, 2)) / 3.0D);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getVelocityError() {
/* 199 */     return Math.sqrt((this.P.get(3, 3) + this.P.get(4, 4) + this.P.get(5, 5)) / 3.0D);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getNOcclusion() {
/* 211 */     return this.nOcclusion;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/tracking/kalman/CVMKalmanFilter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */