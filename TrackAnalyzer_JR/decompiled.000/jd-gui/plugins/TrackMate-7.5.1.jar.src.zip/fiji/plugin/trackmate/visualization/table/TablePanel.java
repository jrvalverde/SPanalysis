/*     */ package fiji.plugin.trackmate.visualization.table;
/*     */ 
/*     */ import com.opencsv.CSVWriter;
/*     */ import fiji.plugin.trackmate.gui.GuiUtils;
/*     */ import fiji.plugin.trackmate.gui.displaysettings.ColorIcon;
/*     */ import fiji.plugin.trackmate.visualization.FeatureColorGenerator;
/*     */ import gnu.trove.map.hash.TObjectIntHashMap;
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.awt.event.MouseMotionAdapter;
/*     */ import java.io.File;
/*     */ import java.io.FileWriter;
/*     */ import java.io.IOException;
/*     */ import java.text.DecimalFormat;
/*     */ import java.text.DecimalFormatSymbols;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Comparator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.function.BiConsumer;
/*     */ import java.util.function.BiFunction;
/*     */ import java.util.function.Function;
/*     */ import java.util.function.Supplier;
/*     */ import javax.swing.AbstractCellEditor;
/*     */ import javax.swing.DefaultCellEditor;
/*     */ import javax.swing.Icon;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JColorChooser;
/*     */ import javax.swing.JDialog;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JScrollPane;
/*     */ import javax.swing.JTable;
/*     */ import javax.swing.JTextField;
/*     */ import javax.swing.KeyStroke;
/*     */ import javax.swing.RowSorter;
/*     */ import javax.swing.SwingUtilities;
/*     */ import javax.swing.border.Border;
/*     */ import javax.swing.table.AbstractTableModel;
/*     */ import javax.swing.table.DefaultTableCellRenderer;
/*     */ import javax.swing.table.DefaultTableColumnModel;
/*     */ import javax.swing.table.TableCellEditor;
/*     */ import javax.swing.table.TableColumn;
/*     */ import javax.swing.table.TableColumnModel;
/*     */ import javax.swing.table.TableModel;
/*     */ import javax.swing.table.TableRowSorter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TablePanel<O>
/*     */ {
/*     */   private static final int ROW_HEIGHT = 26;
/*     */   private final JTable table;
/*     */   private final List<Class<?>> columnClasses;
/*     */   private final List<String> mapToTooltip;
/*     */   private final Function<O, String> labelGenerator;
/*     */   private final BiConsumer<O, String> labelSetter;
/*     */   private final List<O> objects;
/*     */   private final List<String> features;
/*     */   private final BiFunction<O, String, Double> featureFun;
/*     */   private final Map<String, String> featureNames;
/*     */   private final Map<String, String> featureShortNames;
/*     */   private final Map<String, String> featureUnits;
/*     */   private final TObjectIntHashMap<O> map;
/*     */   private final Supplier<FeatureColorGenerator<O>> colorSupplier;
/*     */   private final String manualColorFeature;
/*     */   private boolean useColoring;
/*     */   private final JPanel panel;
/*     */   
/*     */   public TablePanel(Iterable<O> objects, List<String> features, BiFunction<O, String, Double> featureFun, Map<String, String> featureNames, Map<String, String> featureShortNames, Map<String, String> featureUnits, Map<String, Boolean> isInts, Map<String, String> infoTexts, Supplier<FeatureColorGenerator<O>> colorSupplier, Function<O, String> labelGenerator, BiConsumer<O, String> labelSetter) {
/* 127 */     this(objects, features, featureFun, featureNames, featureShortNames, featureUnits, isInts, infoTexts, colorSupplier, labelGenerator, labelSetter, null, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TablePanel(Iterable<O> objects, final List<String> features, BiFunction<O, String, Double> featureFun, Map<String, String> featureNames, Map<String, String> featureShortNames, Map<String, String> featureUnits, Map<String, Boolean> isInts, Map<String, String> infoTexts, Supplier<FeatureColorGenerator<O>> colorSupplier, Function<O, String> labelGenerator, final BiConsumer<O, String> labelSetter, final String manualColorFeature, final BiConsumer<O, Color> colorSetter) {
/* 157 */     this.panel = new JPanel();
/* 158 */     this.featureFun = featureFun;
/* 159 */     this.featureNames = featureNames;
/* 160 */     this.featureShortNames = featureShortNames;
/* 161 */     this.featureUnits = featureUnits;
/* 162 */     this.colorSupplier = colorSupplier;
/* 163 */     this.manualColorFeature = manualColorFeature;
/* 164 */     this.objects = new ArrayList<>();
/* 165 */     this.map = new TObjectIntHashMap(10, 0.5F, -1);
/* 166 */     this.features = features;
/* 167 */     this.labelGenerator = labelGenerator;
/* 168 */     this.labelSetter = labelSetter;
/* 169 */     this.columnClasses = new ArrayList<>();
/* 170 */     this.mapToTooltip = new ArrayList<>();
/*     */ 
/*     */     
/* 173 */     MyTableModel tableModel = new MyTableModel();
/*     */ 
/*     */     
/* 176 */     boolean skipLabelColumn = (labelGenerator == null);
/* 177 */     final int labelColumnShift = skipLabelColumn ? 0 : 1;
/*     */     
/* 179 */     DefaultTableColumnModel tableColumnModel = new DefaultTableColumnModel();
/* 180 */     this.table = new JTable(tableModel, tableColumnModel)
/*     */       {
/*     */         private static final long serialVersionUID = 1L;
/*     */ 
/*     */ 
/*     */         
/*     */         public boolean isCellEditable(int row, int viewcolumn) {
/* 187 */           int column = convertColumnIndexToModel(viewcolumn);
/*     */           
/* 189 */           return ((labelSetter != null && column == 0) || (colorSetter != null && column >= labelColumnShift && ((String)features
/* 190 */             .get(column - labelColumnShift)).equals(manualColorFeature)));
/*     */         }
/*     */       };
/* 193 */     this.table.setColumnModel(tableColumnModel);
/* 194 */     setObjects(objects);
/*     */     
/* 196 */     this.table.putClientProperty("JTable.autoStartsEdit", Boolean.FALSE);
/* 197 */     this.table.getInputMap().put(KeyStroke.getKeyStroke(10, 0), "startEditing");
/*     */     
/* 199 */     this.table.setRowHeight(26);
/* 200 */     this.table.getSelectionModel().setSelectionMode(2);
/* 201 */     this.table.setGridColor(this.table.getTableHeader().getBackground());
/*     */ 
/*     */     
/* 204 */     this.columnClasses.clear();
/*     */     
/* 206 */     List<String> headerLine = new ArrayList<>();
/*     */     
/* 208 */     this.mapToTooltip.clear();
/*     */ 
/*     */     
/* 211 */     this.table.getTableHeader().addMouseMotionListener(new MyTableToolTipProvider());
/*     */     
/* 213 */     int colIndex = 0;
/*     */     
/* 215 */     if (!skipLabelColumn) {
/*     */       
/* 217 */       headerLine.add("<html><b>Label<br> <br></html>");
/* 218 */       this.mapToTooltip.add("Object name");
/* 219 */       this.columnClasses.add(String.class);
/* 220 */       tableColumnModel.addColumn(new TableColumn(colIndex++));
/*     */     } 
/*     */ 
/*     */     
/* 224 */     for (String feature : features) {
/*     */       Class<?> pclass;
/*     */       
/* 227 */       if (feature.equals(manualColorFeature)) {
/* 228 */         pclass = Color.class;
/* 229 */       } else if (((Boolean)isInts.get(feature)).booleanValue()) {
/* 230 */         pclass = Integer.class;
/*     */       } else {
/* 232 */         pclass = Double.class;
/* 233 */       }  this.columnClasses.add(pclass);
/*     */       
/* 235 */       String tooltipStr = "<html>" + (String)featureNames.get(feature);
/* 236 */       String infoText = infoTexts.get(feature);
/* 237 */       if (infoText != null)
/* 238 */         tooltipStr = tooltipStr + "<p>" + infoText + "</p>"; 
/* 239 */       tooltipStr = tooltipStr + "</html>";
/* 240 */       this.mapToTooltip.add(tooltipStr);
/* 241 */       String units = featureUnits.get(feature);
/*     */ 
/*     */       
/* 244 */       String headerStr = "<html><center><b>" + (String)featureShortNames.get(feature) + "</b><br>";
/*     */       
/* 246 */       headerStr = headerStr + ((units == null || units.isEmpty()) ? "<br> </html>" : ("(" + units + ")</html>"));
/* 247 */       headerLine.add(headerStr);
/* 248 */       tableColumnModel.addColumn(new TableColumn(colIndex++));
/*     */     } 
/*     */ 
/*     */     
/* 252 */     TableRowSorter<MyTableModel> sorter = new TableRowSorter<>(tableModel);
/* 253 */     this.table.setRowSorter((RowSorter)sorter);
/* 254 */     for (int c = 0; c < this.columnClasses.size(); c++) {
/*     */       
/* 256 */       if (((Class)this.columnClasses.get(c)).equals(Integer.class)) {
/* 257 */         sorter.setComparator(c, (i1, i2) -> Integer.compare(((Integer)i1).intValue(), ((Integer)i2).intValue()));
/* 258 */       } else if (((Class)this.columnClasses.get(c)).equals(Double.class)) {
/* 259 */         sorter.setComparator(c, (d1, d2) -> Double.compare(((Double)d1).doubleValue(), ((Double)d2).doubleValue()));
/* 260 */       } else if (((Class)this.columnClasses.get(c)).equals(Color.class)) {
/* 261 */         sorter.setComparator(c, (c1, c2) -> c1.toString().compareTo(c2.toString()));
/*     */       } else {
/* 263 */         sorter.setComparator(c, Comparator.naturalOrder());
/*     */       } 
/*     */     } 
/*     */     
/* 267 */     MyTableCellRenderer cellRenderer = new MyTableCellRenderer();
/* 268 */     int colorcolumn = features.indexOf(manualColorFeature) + 1;
/* 269 */     for (int i = 0; i < tableColumnModel.getColumnCount(); i++) {
/*     */       
/* 271 */       TableColumn column = tableColumnModel.getColumn(i);
/* 272 */       column.setHeaderValue(headerLine.get(i));
/* 273 */       column.setCellRenderer(cellRenderer);
/* 274 */       if (i == colorcolumn && null != colorSetter) {
/* 275 */         column.setCellEditor(new MyColorEditor(colorSetter));
/* 276 */       } else if (i == 0 && null != labelSetter) {
/* 277 */         column.setCellEditor(new MyLabelEditor());
/*     */       } 
/*     */     } 
/* 280 */     JScrollPane scrollPane = new JScrollPane(this.table, 20, 30);
/* 281 */     this.table.setAutoResizeMode(0);
/*     */     
/* 283 */     this.panel.setLayout(new BorderLayout());
/* 284 */     this.panel.add(scrollPane, "Center");
/*     */   }
/*     */ 
/*     */   
/*     */   public void setUseColoring(boolean useColoring) {
/* 289 */     this.useColoring = useColoring;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setObjects(Iterable<O> objects) {
/* 295 */     this.objects.clear();
/* 296 */     this.map.clear();
/* 297 */     int index = 0;
/* 298 */     for (O o : objects) {
/*     */       
/* 300 */       this.objects.add(o);
/* 301 */       this.map.put(o, index++);
/*     */     } 
/* 303 */     ((MyTableModel)this.table.getModel()).fireTableDataChanged();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JPanel getPanel() {
/* 314 */     return this.panel;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JTable getTable() {
/* 324 */     return this.table;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public O getObjectForViewRow(int viewRowIndex) {
/* 337 */     if (viewRowIndex < 0)
/* 338 */       return null; 
/* 339 */     int modelRow = this.table.convertRowIndexToModel(viewRowIndex);
/* 340 */     return this.objects.get(modelRow);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getViewRowForObject(O o) {
/* 345 */     int modelRow = this.map.get(o);
/* 346 */     if (modelRow < 0) {
/* 347 */       return -1;
/*     */     }
/*     */     try {
/* 350 */       return this.table.convertRowIndexToView(modelRow);
/*     */     }
/* 352 */     catch (IndexOutOfBoundsException e) {
/*     */ 
/*     */       
/* 355 */       return -1;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void scrollToObject(O o) {
/* 361 */     Rectangle rect = this.table.getVisibleRect();
/* 362 */     int row = getViewRowForObject(o);
/* 363 */     Rectangle cellRect = this.table.getCellRect(row, 0, true);
/* 364 */     cellRect.setLocation(rect.x, cellRect.y);
/* 365 */     this.table.scrollRectToVisible(cellRect);
/*     */   }
/*     */ 
/*     */   
/*     */   public void exportToCsv(File file) throws IOException {
/* 370 */     try (CSVWriter writer = new CSVWriter(new FileWriter(file), ',', false, '"', "\n")) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 376 */       int nCols = this.table.getColumnCount();
/*     */       
/* 378 */       boolean skipLabelColumn = (this.labelGenerator == null);
/* 379 */       int labelColumnShift = skipLabelColumn ? 0 : 1;
/*     */       
/* 381 */       String[] content = new String[nCols];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 392 */       boolean skipThirdLine = true;
/* 393 */       boolean skipSecondLine = true; int i;
/* 394 */       for (i = labelColumnShift; i < content.length; i++) {
/*     */         
/* 396 */         String feature = this.features.get(i - labelColumnShift);
/* 397 */         String name = this.featureNames.get(this.features.get(i - labelColumnShift));
/* 398 */         String shortName = this.featureShortNames.get(this.features.get(i - labelColumnShift));
/* 399 */         if (!feature.equals(name))
/* 400 */           skipSecondLine = false; 
/* 401 */         if (!name.equals(shortName)) {
/* 402 */           skipThirdLine = false;
/*     */         }
/*     */       } 
/*     */       
/* 406 */       if (!skipLabelColumn)
/* 407 */         content[0] = "LABEL"; 
/* 408 */       for (i = labelColumnShift; i < content.length; i++)
/* 409 */         content[i] = this.features.get(i - labelColumnShift); 
/* 410 */       writer.writeNext(content);
/*     */ 
/*     */       
/* 413 */       if (!skipSecondLine) {
/*     */         
/* 415 */         if (!skipLabelColumn)
/* 416 */           content[0] = "Label"; 
/* 417 */         for (i = labelColumnShift; i < content.length; i++)
/* 418 */           content[i] = this.featureNames.get(this.features.get(i - labelColumnShift)); 
/* 419 */         writer.writeNext(content);
/*     */       } 
/*     */ 
/*     */       
/* 423 */       if (!skipThirdLine) {
/*     */         
/* 425 */         if (!skipLabelColumn)
/* 426 */           content[0] = "Label"; 
/* 427 */         for (i = labelColumnShift; i < content.length; i++)
/* 428 */           content[i] = this.featureShortNames.get(this.features.get(i - labelColumnShift)); 
/* 429 */         writer.writeNext(content);
/*     */       } 
/*     */ 
/*     */       
/* 433 */       if (!skipLabelColumn)
/* 434 */         content[0] = ""; 
/* 435 */       for (i = labelColumnShift; i < content.length; i++) {
/*     */         
/* 437 */         String feature = this.features.get(i - labelColumnShift);
/* 438 */         String units = this.featureUnits.get(feature);
/* 439 */         String unitsStr = (units == null || units.isEmpty()) ? "" : ("(" + units + ")");
/* 440 */         content[i] = unitsStr;
/*     */       } 
/* 442 */       writer.writeNext(content);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 448 */       int nRows = this.table.getRowCount();
/* 449 */       TableModel model = this.table.getModel();
/* 450 */       for (int r = 0; r < nRows; r++) {
/*     */         
/* 452 */         int row = this.table.convertRowIndexToModel(r);
/* 453 */         for (int col = 0; col < nCols; col++) {
/*     */           
/* 455 */           Object obj = model.getValueAt(row, col);
/* 456 */           if (null == obj) {
/* 457 */             content[col] = "";
/* 458 */           } else if (obj instanceof Integer) {
/* 459 */             content[col] = Integer.toString(((Integer)obj).intValue());
/* 460 */           } else if (obj instanceof Double) {
/* 461 */             content[col] = Double.toString(((Double)obj).doubleValue());
/* 462 */           } else if (obj instanceof Boolean) {
/* 463 */             content[col] = ((Boolean)obj).booleanValue() ? "1" : "0";
/* 464 */           } else if (obj instanceof Color) {
/*     */             
/* 466 */             Color color = (Color)obj;
/* 467 */             content[col] = String.format("r=%d;g=%d;b=%d", new Object[] { Integer.valueOf(color.getRed()), Integer.valueOf(color.getGreen()), Integer.valueOf(color.getBlue()) });
/*     */           } else {
/*     */             
/* 470 */             content[col] = obj.toString();
/*     */           } 
/* 472 */         }  writer.writeNext(content);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private class MyTableToolTipProvider
/*     */     extends MouseMotionAdapter
/*     */   {
/* 483 */     private int previousCol = -1;
/*     */ 
/*     */ 
/*     */     
/*     */     public void mouseMoved(MouseEvent evt) {
/* 488 */       TableColumnModel tableColumnModel = TablePanel.this.table.getColumnModel();
/* 489 */       int col = tableColumnModel.getColumnIndexAtX(evt.getX());
/* 490 */       int vColIndex = TablePanel.this.table.convertColumnIndexToModel(col);
/* 491 */       if (vColIndex != this.previousCol)
/*     */       {
/* 493 */         if (vColIndex >= 0 && vColIndex < TablePanel.this.mapToTooltip.size()) {
/*     */           
/* 495 */           TablePanel.this.table.getTableHeader().setToolTipText(TablePanel.this.mapToTooltip.get(vColIndex));
/* 496 */           this.previousCol = vColIndex;
/*     */         }
/*     */         else {
/*     */           
/* 500 */           TablePanel.this.table.getTableHeader().setToolTipText("");
/*     */         } 
/*     */       }
/*     */     }
/*     */     
/*     */     private MyTableToolTipProvider() {}
/*     */   }
/*     */   
/*     */   private class MyTableModel extends AbstractTableModel {
/*     */     private static final long serialVersionUID = 1L;
/*     */     
/*     */     private MyTableModel() {}
/*     */     
/*     */     public int getRowCount() {
/* 514 */       return TablePanel.this.objects.size();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public int getColumnCount() {
/* 520 */       return TablePanel.this.columnClasses.size();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Object getValueAt(int rowIndex, int columnIndex) {
/* 526 */       if (rowIndex < 0) {
/* 527 */         return null;
/*     */       }
/* 529 */       O o = (O)TablePanel.this.objects.get(rowIndex);
/* 530 */       if (null == o) {
/* 531 */         return null;
/*     */       }
/* 533 */       int skipLabelColumn = (TablePanel.this.labelGenerator == null) ? 0 : 1;
/* 534 */       if (columnIndex == 0 && TablePanel.this.labelGenerator != null) {
/* 535 */         return TablePanel.this.labelGenerator.apply(o);
/*     */       }
/*     */       
/* 538 */       String feature = TablePanel.this.features.get(columnIndex - skipLabelColumn);
/* 539 */       Double val = TablePanel.this.featureFun.apply(o, feature);
/*     */       
/* 541 */       if (feature.equals(TablePanel.this.manualColorFeature)) {
/* 542 */         return (val == null) ? null : new Color(val.intValue(), true);
/*     */       }
/* 544 */       if (val == null) {
/* 545 */         return null;
/*     */       }
/* 547 */       if (((Class)TablePanel.this.columnClasses.get(columnIndex)).equals(Integer.class)) {
/* 548 */         return Integer.valueOf(val.intValue());
/*     */       }
/* 550 */       return val;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void setValueAt(Object aValue, int rowIndex, int columnIndex) {
/* 557 */       if (TablePanel.this.labelSetter == null) {
/*     */         return;
/*     */       }
/* 560 */       if (columnIndex == 0) {
/*     */         
/* 562 */         O o = (O)TablePanel.this.objects.get(rowIndex);
/* 563 */         if (null == o)
/*     */           return; 
/* 565 */         TablePanel.this.labelSetter.accept(o, (String)aValue);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private class MyTableCellRenderer
/*     */     extends DefaultTableCellRenderer
/*     */   {
/*     */     private final Border normalBorder;
/*     */     
/*     */     private final DecimalFormat nf;
/*     */     
/*     */     private static final long serialVersionUID = 1L;
/*     */     
/*     */     private final FeatureColorGenerator<O> defaultColoring = o -> Color.WHITE;
/*     */     
/*     */     private final ColorIcon colorIcon;
/*     */     
/*     */     public MyTableCellRenderer() {
/* 585 */       this.normalBorder = ((JLabel)super.getTableCellRendererComponent(TablePanel.this.table, "", false, false, 0, 0)).getBorder();
/* 586 */       this.nf = new DecimalFormat();
/* 587 */       DecimalFormatSymbols formatSymbols = new DecimalFormatSymbols();
/* 588 */       formatSymbols.setNaN("NaN");
/* 589 */       this.nf.setDecimalFormatSymbols(formatSymbols);
/* 590 */       this.colorIcon = new ColorIcon(new Color(0));
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
/* 596 */       FeatureColorGenerator<O> coloring = TablePanel.this.useColoring ? TablePanel.this.colorSupplier.get() : this.defaultColoring;
/* 597 */       JLabel c = (JLabel)super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
/* 598 */       c.setBorder(this.normalBorder);
/*     */       
/* 600 */       O o = TablePanel.this.getObjectForViewRow(row);
/* 601 */       if (isSelected) {
/*     */         
/* 603 */         c.setBackground(table.getSelectionBackground());
/* 604 */         c.setForeground(table.getSelectionForeground());
/*     */       }
/*     */       else {
/*     */         
/* 608 */         Color bgColor = coloring.color(o);
/* 609 */         c.setBackground(bgColor);
/* 610 */         c.setForeground(GuiUtils.textColorForBackground(bgColor));
/*     */       } 
/*     */       
/* 613 */       if (hasFocus) {
/*     */         
/* 615 */         c.setBackground(table.getSelectionBackground().darker().darker());
/* 616 */         c.setForeground(table.getSelectionForeground());
/*     */       } 
/*     */       
/* 619 */       c.setIcon((Icon)null);
/* 620 */       if (value instanceof Double) {
/*     */         
/* 622 */         setHorizontalAlignment(4);
/* 623 */         Double doubleValue = (Double)value;
/* 624 */         setText(this.nf.format(doubleValue.doubleValue()));
/*     */       }
/* 626 */       else if (value instanceof Number) {
/*     */         
/* 628 */         setHorizontalAlignment(4);
/*     */       }
/* 630 */       else if (value instanceof Color) {
/*     */         
/* 632 */         this.colorIcon.setColor((Color)value);
/* 633 */         c.setIcon((Icon)this.colorIcon);
/* 634 */         c.setText((String)null);
/* 635 */         setHorizontalAlignment(0);
/*     */       }
/*     */       else {
/*     */         
/* 639 */         setHorizontalAlignment(2);
/*     */       } 
/*     */       
/* 642 */       return c;
/*     */     }
/*     */   }
/*     */   
/*     */   private class MyColorEditor
/*     */     extends AbstractCellEditor
/*     */     implements TableCellEditor {
/* 649 */     private final JColorChooser colorChooser = new JColorChooser();
/*     */     
/*     */     private static final long serialVersionUID = 1L;
/*     */     
/*     */     private final BiConsumer<O, Color> colorSetter;
/*     */ 
/*     */     
/*     */     public MyColorEditor(BiConsumer<O, Color> colorSetter) {
/* 657 */       this.colorSetter = colorSetter;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Object getCellEditorValue() {
/* 663 */       return null;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected, final int row, int column) {
/* 674 */       final ColorIcon icon = new ColorIcon((Color)value, 16, 0);
/* 675 */       JButton button = new JButton((Icon)icon);
/* 676 */       button.setHorizontalAlignment(0);
/* 677 */       button.addActionListener(e -> {
/*     */             this.colorChooser.setColor((Color)value);
/*     */             
/*     */             JDialog d = JColorChooser.createDialog(button, "Choose a color", true, this.colorChooser, new ActionListener()
/*     */                 {
/*     */                   public void actionPerformed(ActionEvent arg0)
/*     */                   {
/* 684 */                     Color c = TablePanel.MyColorEditor.this.colorChooser.getColor();
/* 685 */                     if (c != null) {
/*     */                       
/* 687 */                       int[] rows = TablePanel.this.getTable().getSelectedRows();
/* 688 */                       if (rows.length > 1) {
/*     */                         
/* 690 */                         for (int r : rows) {
/*     */                           
/* 692 */                           Object o = TablePanel.this.getObjectForViewRow(r);
/* 693 */                           TablePanel.MyColorEditor.this.colorSetter.accept(o, c);
/*     */                         } 
/* 695 */                         TablePanel.this.panel.repaint();
/*     */                       }
/*     */                       else {
/*     */                         
/* 699 */                         Object o = TablePanel.this.getObjectForViewRow(row);
/* 700 */                         TablePanel.MyColorEditor.this.colorSetter.accept(o, c);
/*     */                       } 
/* 702 */                       icon.setColor(c);
/*     */                     } 
/*     */                   }
/*     */                 }null);
/*     */             d.setVisible(true);
/*     */           });
/* 708 */       return button;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class MyLabelEditor
/*     */     extends DefaultCellEditor
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */ 
/*     */ 
/*     */     
/*     */     public MyLabelEditor() {
/* 722 */       super(new JTextField());
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected, int row, int column) {
/* 728 */       JTextField textfield = (JTextField)super.getTableCellEditorComponent(table, value, isSelected, row, column);
/* 729 */       SwingUtilities.invokeLater(() -> textfield.selectAll());
/* 730 */       return textfield;
/*     */     }
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/visualization/table/TablePanel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */