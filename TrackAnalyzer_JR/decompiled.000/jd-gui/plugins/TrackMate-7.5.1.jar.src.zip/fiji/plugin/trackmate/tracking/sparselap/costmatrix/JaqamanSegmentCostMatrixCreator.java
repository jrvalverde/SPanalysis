/*     */ package fiji.plugin.trackmate.tracking.sparselap.costmatrix;
/*     */ 
/*     */ import fiji.plugin.trackmate.Spot;
/*     */ import fiji.plugin.trackmate.tracking.LAPUtils;
/*     */ import fiji.plugin.trackmate.tracking.sparselap.costfunction.CostFunction;
/*     */ import fiji.plugin.trackmate.tracking.sparselap.costfunction.FeaturePenaltyCostFunction;
/*     */ import fiji.plugin.trackmate.tracking.sparselap.costfunction.SquareDistCostFunction;
/*     */ import fiji.plugin.trackmate.tracking.sparselap.linker.SparseCostMatrix;
/*     */ import fiji.plugin.trackmate.util.TMUtils;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.Executors;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import net.imglib2.algorithm.MultiThreaded;
/*     */ import org.jgrapht.Graph;
/*     */ import org.jgrapht.graph.DefaultWeightedEdge;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JaqamanSegmentCostMatrixCreator
/*     */   implements CostMatrixCreator<Spot, Spot>, MultiThreaded
/*     */ {
/*     */   private static final String BASE_ERROR_MESSAGE = "[JaqamanSegmentCostMatrixCreator] ";
/*     */   private final Map<String, Object> settings;
/*     */   private String errorMessage;
/*     */   private SparseCostMatrix scm;
/*     */   private long processingTime;
/*     */   private List<Spot> uniqueSources;
/*     */   private List<Spot> uniqueTargets;
/*     */   private final Graph<Spot, DefaultWeightedEdge> graph;
/*  94 */   private double alternativeCost = -1.0D;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int numThreads;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JaqamanSegmentCostMatrixCreator(Graph<Spot, DefaultWeightedEdge> graph, Map<String, Object> settings) {
/* 105 */     this.graph = graph;
/* 106 */     this.settings = settings;
/* 107 */     setNumThreads();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean checkInput() {
/* 113 */     StringBuilder str = new StringBuilder();
/* 114 */     if (!checkSettingsValidity(this.settings, str)) {
/*     */       
/* 116 */       this.errorMessage = "[JaqamanSegmentCostMatrixCreator] Incorrect settings map:\n" + str.toString();
/* 117 */       return false;
/*     */     } 
/* 119 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getErrorMessage() {
/* 125 */     return this.errorMessage;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean process() {
/*     */     final List<Spot> allMiddles;
/* 131 */     long start = System.currentTimeMillis();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 139 */     Map<String, Double> gcFeaturePenalties = (Map<String, Double>)this.settings.get("GAP_CLOSING_FEATURE_PENALTIES");
/* 140 */     final CostFunction<Spot, Spot> gcCostFunction = getCostFunctionFor(gcFeaturePenalties);
/* 141 */     final int maxFrameInterval = ((Integer)this.settings.get("MAX_FRAME_GAP")).intValue();
/* 142 */     double gcMaxDistance = ((Double)this.settings.get("GAP_CLOSING_MAX_DISTANCE")).doubleValue();
/* 143 */     final double gcCostThreshold = gcMaxDistance * gcMaxDistance;
/* 144 */     final boolean allowGapClosing = ((Boolean)this.settings.get("ALLOW_GAP_CLOSING")).booleanValue();
/*     */ 
/*     */ 
/*     */     
/* 148 */     Map<String, Double> mFeaturePenalties = (Map<String, Double>)this.settings.get("MERGING_FEATURE_PENALTIES");
/* 149 */     final CostFunction<Spot, Spot> mCostFunction = getCostFunctionFor(mFeaturePenalties);
/* 150 */     double mMaxDistance = ((Double)this.settings.get("MERGING_MAX_DISTANCE")).doubleValue();
/* 151 */     final double mCostThreshold = mMaxDistance * mMaxDistance;
/* 152 */     final boolean allowMerging = ((Boolean)this.settings.get("ALLOW_TRACK_MERGING")).booleanValue();
/*     */ 
/*     */ 
/*     */     
/* 156 */     Map<String, Double> sFeaturePenalties = (Map<String, Double>)this.settings.get("SPLITTING_FEATURE_PENALTIES");
/* 157 */     final CostFunction<Spot, Spot> sCostFunction = getCostFunctionFor(sFeaturePenalties);
/* 158 */     boolean allowSplitting = ((Boolean)this.settings.get("ALLOW_TRACK_SPLITTING")).booleanValue();
/* 159 */     double sMaxDistance = ((Double)this.settings.get("SPLITTING_MAX_DISTANCE")).doubleValue();
/* 160 */     final double sCostThreshold = sMaxDistance * sMaxDistance;
/*     */ 
/*     */     
/* 163 */     double alternativeCostFactor = ((Double)this.settings.get("ALTERNATIVE_LINKING_COST_FACTOR")).doubleValue();
/* 164 */     double percentile = ((Double)this.settings.get("CUTOFF_PERCENTILE")).doubleValue();
/*     */ 
/*     */     
/* 167 */     if (!allowGapClosing && !allowSplitting && !allowMerging) {
/*     */       
/* 169 */       this.uniqueSources = Collections.emptyList();
/* 170 */       this.uniqueTargets = Collections.emptyList();
/* 171 */       this.scm = new SparseCostMatrix(new double[0], new int[0], new int[0], 0);
/* 172 */       return true;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 179 */     boolean mergingOrSplitting = (allowMerging || allowSplitting);
/*     */     
/* 181 */     GraphSegmentSplitter segmentSplitter = new GraphSegmentSplitter(this.graph, mergingOrSplitting);
/* 182 */     List<Spot> segmentEnds = segmentSplitter.getSegmentEnds();
/* 183 */     final List<Spot> segmentStarts = segmentSplitter.getSegmentStarts();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 191 */     if (mergingOrSplitting) {
/*     */       
/* 193 */       List<List<Spot>> segmentMiddles = segmentSplitter.getSegmentMiddles();
/* 194 */       allMiddles = new ArrayList<>();
/* 195 */       for (List<Spot> segment : segmentMiddles)
/*     */       {
/* 197 */         allMiddles.addAll(segment);
/*     */       }
/*     */     }
/*     */     else {
/*     */       
/* 202 */       allMiddles = Collections.emptyList();
/*     */     } 
/*     */     
/* 205 */     final Object lock = new Object();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 210 */     final ArrayList<Spot> sources = new ArrayList<>();
/* 211 */     final ArrayList<Spot> targets = new ArrayList<>();
/*     */     
/* 213 */     final ResizableDoubleArray linkCosts = new ResizableDoubleArray();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 220 */     ExecutorService executorGCM = Executors.newFixedThreadPool(this.numThreads);
/* 221 */     for (Spot source : segmentEnds) {
/*     */       
/* 223 */       executorGCM.submit(new Runnable()
/*     */           {
/*     */             
/*     */             public void run()
/*     */             {
/* 228 */               int sourceFrame = source.getFeature("FRAME").intValue();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */               
/* 234 */               if (allowGapClosing)
/*     */               {
/* 236 */                 for (Spot target : segmentStarts) {
/*     */ 
/*     */ 
/*     */                   
/* 240 */                   int targetFrame = target.getFeature("FRAME").intValue();
/* 241 */                   int tdiff = targetFrame - sourceFrame;
/* 242 */                   if (tdiff < 1 || tdiff > maxFrameInterval) {
/*     */                     continue;
/*     */                   }
/*     */ 
/*     */ 
/*     */                   
/* 248 */                   double cost = gcCostFunction.linkingCost(source, target);
/* 249 */                   if (cost > gcCostThreshold) {
/*     */                     continue;
/*     */                   }
/*     */ 
/*     */                   
/* 254 */                   synchronized (lock) {
/*     */                     
/* 256 */                     sources.add(source);
/* 257 */                     targets.add(target);
/* 258 */                     linkCosts.add(cost);
/*     */                   } 
/*     */                 } 
/*     */               }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */               
/* 267 */               if (allowMerging)
/*     */               {
/* 269 */                 for (Spot target : allMiddles) {
/*     */ 
/*     */                   
/* 272 */                   int targetFrame = target.getFeature("FRAME").intValue();
/* 273 */                   int tdiff = targetFrame - sourceFrame;
/* 274 */                   if (tdiff != 1) {
/*     */                     continue;
/*     */                   }
/*     */ 
/*     */ 
/*     */                   
/* 280 */                   double cost = mCostFunction.linkingCost(source, target);
/* 281 */                   if (cost > mCostThreshold) {
/*     */                     continue;
/*     */                   }
/*     */ 
/*     */                   
/* 286 */                   synchronized (lock) {
/*     */                     
/* 288 */                     sources.add(source);
/* 289 */                     targets.add(target);
/* 290 */                     linkCosts.add(cost);
/*     */                   } 
/*     */                 } 
/*     */               }
/*     */             }
/*     */           });
/*     */     } 
/* 297 */     executorGCM.shutdown();
/*     */     
/*     */     try {
/* 300 */       executorGCM.awaitTermination(1L, TimeUnit.DAYS);
/*     */     }
/* 302 */     catch (InterruptedException e) {
/*     */       
/* 304 */       this.errorMessage = "[JaqamanSegmentCostMatrixCreator] " + e.getMessage();
/* 305 */       return false;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 311 */     if (allowSplitting) {
/*     */       
/* 313 */       ExecutorService executorS = Executors.newFixedThreadPool(this.numThreads);
/* 314 */       for (Spot source : allMiddles) {
/*     */         
/* 316 */         executorS.submit(new Runnable()
/*     */             {
/*     */               
/*     */               public void run()
/*     */               {
/* 321 */                 int sourceFrame = source.getFeature("FRAME").intValue();
/* 322 */                 for (Spot target : segmentStarts) {
/*     */ 
/*     */                   
/* 325 */                   int targetFrame = target.getFeature("FRAME").intValue();
/* 326 */                   int tdiff = targetFrame - sourceFrame;
/*     */                   
/* 328 */                   if (tdiff != 1) {
/*     */                     continue;
/*     */                   }
/*     */ 
/*     */ 
/*     */                   
/* 334 */                   double cost = sCostFunction.linkingCost(source, target);
/* 335 */                   if (cost > sCostThreshold) {
/*     */                     continue;
/*     */                   }
/*     */                   
/* 339 */                   synchronized (lock) {
/*     */                     
/* 341 */                     sources.add(source);
/* 342 */                     targets.add(target);
/* 343 */                     linkCosts.add(cost);
/*     */                   } 
/*     */                 } 
/*     */               }
/*     */             });
/*     */       } 
/*     */       
/* 350 */       executorS.shutdown();
/*     */       
/*     */       try {
/* 353 */         executorS.awaitTermination(1L, TimeUnit.DAYS);
/*     */       }
/* 355 */       catch (InterruptedException e) {
/*     */         
/* 357 */         this.errorMessage = "[JaqamanSegmentCostMatrixCreator] " + e.getMessage();
/*     */       } 
/*     */     } 
/* 360 */     linkCosts.trimToSize();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 367 */     if (sources.isEmpty() || targets.isEmpty()) {
/*     */       
/* 369 */       this.uniqueSources = Collections.emptyList();
/* 370 */       this.uniqueTargets = Collections.emptyList();
/* 371 */       this.alternativeCost = Double.NaN;
/* 372 */       this.scm = null;
/*     */ 
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */ 
/*     */       
/* 380 */       DefaultCostMatrixCreator<Spot, Spot> creator = new DefaultCostMatrixCreator<>(sources, targets, linkCosts.data, alternativeCostFactor, percentile);
/* 381 */       if (!creator.checkInput() || !creator.process()) {
/*     */         
/* 383 */         this.errorMessage = "Linking track segments: " + creator.getErrorMessage();
/* 384 */         return false;
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 389 */       this.alternativeCost = creator.computeAlternativeCosts();
/*     */       
/* 391 */       this.scm = creator.getResult();
/* 392 */       this.uniqueSources = creator.getSourceList();
/* 393 */       this.uniqueTargets = creator.getTargetList();
/*     */     } 
/*     */     
/* 396 */     long end = System.currentTimeMillis();
/* 397 */     this.processingTime = end - start;
/* 398 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected CostFunction<Spot, Spot> getCostFunctionFor(Map<String, Double> featurePenalties) {
/*     */     FeaturePenaltyCostFunction featurePenaltyCostFunction;
/* 405 */     if (null == featurePenalties || featurePenalties.isEmpty()) {
/*     */       
/* 407 */       SquareDistCostFunction squareDistCostFunction = new SquareDistCostFunction();
/*     */     }
/*     */     else {
/*     */       
/* 411 */       featurePenaltyCostFunction = new FeaturePenaltyCostFunction(featurePenalties);
/*     */     } 
/* 413 */     return (CostFunction<Spot, Spot>)featurePenaltyCostFunction;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public SparseCostMatrix getResult() {
/* 419 */     return this.scm;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Spot> getSourceList() {
/* 425 */     return this.uniqueSources;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Spot> getTargetList() {
/* 431 */     return this.uniqueTargets;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public double getAlternativeCostForSource(Spot source) {
/* 437 */     return this.alternativeCost;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public double getAlternativeCostForTarget(Spot target) {
/* 443 */     return this.alternativeCost;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public long getProcessingTime() {
/* 449 */     return this.processingTime;
/*     */   }
/*     */ 
/*     */   
/*     */   private static final boolean checkSettingsValidity(Map<String, Object> settings, StringBuilder str) {
/* 454 */     if (null == settings) {
/*     */       
/* 456 */       str.append("Settings map is null.\n");
/* 457 */       return false;
/*     */     } 
/*     */     
/* 460 */     boolean ok = true;
/*     */     
/* 462 */     ok &= TMUtils.checkParameter(settings, "ALLOW_GAP_CLOSING", Boolean.class, str);
/* 463 */     ok &= TMUtils.checkParameter(settings, "GAP_CLOSING_MAX_DISTANCE", Double.class, str);
/* 464 */     ok &= TMUtils.checkParameter(settings, "MAX_FRAME_GAP", Integer.class, str);
/* 465 */     ok &= LAPUtils.checkFeatureMap(settings, "GAP_CLOSING_FEATURE_PENALTIES", str);
/*     */     
/* 467 */     ok &= TMUtils.checkParameter(settings, "ALLOW_TRACK_SPLITTING", Boolean.class, str);
/* 468 */     ok &= TMUtils.checkParameter(settings, "SPLITTING_MAX_DISTANCE", Double.class, str);
/* 469 */     ok &= LAPUtils.checkFeatureMap(settings, "SPLITTING_FEATURE_PENALTIES", str);
/*     */     
/* 471 */     ok &= TMUtils.checkParameter(settings, "ALLOW_TRACK_MERGING", Boolean.class, str);
/* 472 */     ok &= TMUtils.checkParameter(settings, "MERGING_MAX_DISTANCE", Double.class, str);
/* 473 */     ok &= LAPUtils.checkFeatureMap(settings, "MERGING_FEATURE_PENALTIES", str);
/*     */     
/* 475 */     ok &= TMUtils.checkParameter(settings, "ALTERNATIVE_LINKING_COST_FACTOR", Double.class, str);
/* 476 */     ok &= TMUtils.checkParameter(settings, "CUTOFF_PERCENTILE", Double.class, str);
/*     */ 
/*     */     
/* 479 */     List<String> mandatoryKeys = new ArrayList<>();
/* 480 */     mandatoryKeys.add("ALLOW_GAP_CLOSING");
/* 481 */     mandatoryKeys.add("GAP_CLOSING_MAX_DISTANCE");
/* 482 */     mandatoryKeys.add("MAX_FRAME_GAP");
/* 483 */     mandatoryKeys.add("ALLOW_TRACK_SPLITTING");
/* 484 */     mandatoryKeys.add("SPLITTING_MAX_DISTANCE");
/* 485 */     mandatoryKeys.add("ALLOW_TRACK_MERGING");
/* 486 */     mandatoryKeys.add("MERGING_MAX_DISTANCE");
/* 487 */     mandatoryKeys.add("ALTERNATIVE_LINKING_COST_FACTOR");
/* 488 */     mandatoryKeys.add("CUTOFF_PERCENTILE");
/* 489 */     List<String> optionalKeys = new ArrayList<>();
/* 490 */     optionalKeys.add("GAP_CLOSING_FEATURE_PENALTIES");
/* 491 */     optionalKeys.add("SPLITTING_FEATURE_PENALTIES");
/* 492 */     optionalKeys.add("MERGING_FEATURE_PENALTIES");
/* 493 */     ok &= TMUtils.checkMapKeys(settings, mandatoryKeys, optionalKeys, str);
/*     */     
/* 495 */     return ok;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setNumThreads() {
/* 501 */     this.numThreads = Runtime.getRuntime().availableProcessors();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setNumThreads(int numThreads) {
/* 507 */     this.numThreads = numThreads;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getNumThreads() {
/* 513 */     return this.numThreads;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/tracking/sparselap/costmatrix/JaqamanSegmentCostMatrixCreator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */