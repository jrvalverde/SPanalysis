/*    */ package fiji.plugin.trackmate.providers;
/*    */ 
/*    */ import fiji.plugin.trackmate.features.edges.EdgeAnalyzer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EdgeAnalyzerProvider
/*    */   extends AbstractProvider<EdgeAnalyzer>
/*    */ {
/*    */   public EdgeAnalyzerProvider() {
/* 34 */     super(EdgeAnalyzer.class);
/*    */   }
/*    */ 
/*    */   
/*    */   public static void main(String[] args) {
/* 39 */     EdgeAnalyzerProvider provider = new EdgeAnalyzerProvider();
/* 40 */     System.out.println(provider.echo());
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/providers/EdgeAnalyzerProvider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */