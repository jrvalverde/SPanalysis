/*     */ package fiji.plugin.trackmate.features;
/*     */ 
/*     */ import fiji.plugin.trackmate.Model;
/*     */ import fiji.plugin.trackmate.ModelChangeEvent;
/*     */ import fiji.plugin.trackmate.ModelChangeListener;
/*     */ import fiji.plugin.trackmate.Settings;
/*     */ import fiji.plugin.trackmate.Spot;
/*     */ import fiji.plugin.trackmate.SpotCollection;
/*     */ import java.util.ArrayList;
/*     */ import net.imglib2.algorithm.MultiThreaded;
/*     */ import org.jgrapht.graph.DefaultWeightedEdge;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ModelFeatureUpdater
/*     */   implements ModelChangeListener, MultiThreaded
/*     */ {
/*     */   private final SpotFeatureCalculator spotFeatureCalculator;
/*     */   private final EdgeFeatureCalculator edgeFeatureCalculator;
/*     */   private final TrackFeatureCalculator trackFeatureCalculator;
/*     */   private final Model model;
/*     */   private int numThreads;
/*     */   
/*     */   public ModelFeatureUpdater(Model model, Settings settings) {
/*  68 */     this.model = model;
/*     */     
/*  70 */     boolean doLogIt = false;
/*  71 */     this.spotFeatureCalculator = new SpotFeatureCalculator(model, settings, false);
/*  72 */     this.edgeFeatureCalculator = new EdgeFeatureCalculator(model, settings, false);
/*  73 */     this.trackFeatureCalculator = new TrackFeatureCalculator(model, settings, false);
/*  74 */     model.addModelChangeListener(this);
/*  75 */     setNumThreads();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void modelChanged(ModelChangeEvent event) {
/*  85 */     if (event.getEventID() != 8) {
/*     */       return;
/*     */     }
/*     */     
/*  89 */     ArrayList<Spot> spots = new ArrayList<>(event.getSpots().size());
/*  90 */     for (Spot spot : event.getSpots()) {
/*     */       
/*  92 */       if (event.getSpotFlag(spot).intValue() != 1)
/*  93 */         spots.add(spot); 
/*     */     } 
/*  95 */     SpotCollection sc = SpotCollection.fromCollection(spots);
/*     */ 
/*     */     
/*  98 */     ArrayList<DefaultWeightedEdge> edges = new ArrayList<>(event.getEdges().size());
/*  99 */     for (DefaultWeightedEdge edge : event.getEdges()) {
/*     */       
/* 101 */       if (event.getEdgeFlag(edge).intValue() != 5) {
/* 102 */         edges.add(edge);
/*     */       }
/*     */     } 
/*     */     
/* 106 */     this.spotFeatureCalculator.computeSpotFeatures(sc, false);
/*     */ 
/*     */     
/* 109 */     this.edgeFeatureCalculator.computeEdgesFeatures(edges, false);
/*     */ 
/*     */     
/* 112 */     this.trackFeatureCalculator.computeTrackFeatures(event.getTrackUpdated(), false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void quit() {
/* 121 */     this.model.removeModelChangeListener(this);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getNumThreads() {
/* 127 */     return this.numThreads;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setNumThreads() {
/* 133 */     setNumThreads(Runtime.getRuntime().availableProcessors());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setNumThreads(int numThreads) {
/* 139 */     this.numThreads = numThreads;
/* 140 */     this.spotFeatureCalculator.setNumThreads(numThreads);
/* 141 */     this.edgeFeatureCalculator.setNumThreads(numThreads);
/* 142 */     this.trackFeatureCalculator.setNumThreads(numThreads);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/features/ModelFeatureUpdater.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */