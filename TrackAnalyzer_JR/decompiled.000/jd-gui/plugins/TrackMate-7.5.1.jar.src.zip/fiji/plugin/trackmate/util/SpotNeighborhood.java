/*     */ package fiji.plugin.trackmate.util;
/*     */ 
/*     */ import fiji.plugin.trackmate.Spot;
/*     */ import java.util.Iterator;
/*     */ import net.imagej.ImgPlus;
/*     */ import net.imagej.ImgPlusMetadata;
/*     */ import net.imglib2.Cursor;
/*     */ import net.imglib2.FinalInterval;
/*     */ import net.imglib2.Interval;
/*     */ import net.imglib2.Positionable;
/*     */ import net.imglib2.RandomAccessibleInterval;
/*     */ import net.imglib2.RealCursor;
/*     */ import net.imglib2.RealPositionable;
/*     */ import net.imglib2.algorithm.neighborhood.Neighborhood;
/*     */ import net.imglib2.algorithm.region.localneighborhood.AbstractNeighborhood;
/*     */ import net.imglib2.algorithm.region.localneighborhood.EllipseNeighborhood;
/*     */ import net.imglib2.algorithm.region.localneighborhood.EllipsoidNeighborhood;
/*     */ import net.imglib2.algorithm.region.localneighborhood.RectangleNeighborhoodGPL;
/*     */ import net.imglib2.outofbounds.OutOfBoundsFactory;
/*     */ import net.imglib2.outofbounds.OutOfBoundsMirrorExpWindowingFactory;
/*     */ import net.imglib2.type.numeric.RealType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SpotNeighborhood<T extends RealType<T>>
/*     */   implements Neighborhood<T>
/*     */ {
/*     */   protected final double[] calibration;
/*     */   protected final AbstractNeighborhood<T> neighborhood;
/*     */   protected final long[] center;
/*     */   
/*     */   public SpotNeighborhood(Spot spot, ImgPlus<T> img) {
/*  58 */     this.calibration = TMUtils.getSpatialCalibration((ImgPlusMetadata)img);
/*     */     
/*  60 */     this.center = new long[img.numDimensions()];
/*  61 */     for (int d = 0; d < this.center.length; d++)
/*     */     {
/*  63 */       this.center[d] = Math.round(spot.getFeature(Spot.POSITION_FEATURES[d]).doubleValue() / this.calibration[d]);
/*     */     }
/*     */     
/*  66 */     long[] span = new long[img.numDimensions()];
/*  67 */     for (int i = 0; i < span.length; i++)
/*     */     {
/*  69 */       span[i] = Math.round(spot.getFeature("RADIUS").doubleValue() / this.calibration[i]);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  80 */     OutOfBoundsMirrorExpWindowingFactory<T, RandomAccessibleInterval<T>> oob = new OutOfBoundsMirrorExpWindowingFactory();
/*  81 */     if ((img.numDimensions() == 2 && img.dimension(0) < 2L) || img.dimension(1) < 2L) {
/*     */       
/*  83 */       if (img.dimension(0) < 2L) {
/*     */         
/*  85 */         span[0] = 0L;
/*     */       }
/*     */       else {
/*     */         
/*  89 */         span[1] = 0L;
/*     */       } 
/*  91 */       this.neighborhood = (AbstractNeighborhood<T>)new RectangleNeighborhoodGPL((RandomAccessibleInterval)img, (OutOfBoundsFactory)oob);
/*  92 */       this.neighborhood.setPosition(this.center);
/*  93 */       this.neighborhood.setSpan(span);
/*     */     }
/*  95 */     else if (img.numDimensions() == 2) {
/*     */       
/*  97 */       this.neighborhood = (AbstractNeighborhood<T>)new EllipseNeighborhood((RandomAccessibleInterval)img, this.center, span, (OutOfBoundsFactory)oob);
/*     */     }
/*  99 */     else if (img.numDimensions() == 3) {
/*     */       
/* 101 */       this.neighborhood = (AbstractNeighborhood<T>)new EllipsoidNeighborhood((RandomAccessibleInterval)img, this.center, span, (OutOfBoundsFactory)oob);
/*     */     }
/*     */     else {
/*     */       
/* 105 */       throw new IllegalArgumentException("Source input must be 1D, 2D or 3D, got nDims = " + img.numDimensions());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final SpotNeighborhoodCursor<T> cursor() {
/* 117 */     return new SpotNeighborhoodCursor<>(this);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public SpotNeighborhoodCursor<T> localizingCursor() {
/* 123 */     return cursor();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public long size() {
/* 129 */     return this.neighborhood.size();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public T firstElement() {
/* 135 */     return (T)this.neighborhood.firstElement();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object iterationOrder() {
/* 141 */     return this.neighborhood.iterationOrder();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public double realMin(int d) {
/* 147 */     return this.neighborhood.realMin(d);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void realMin(double[] min) {
/* 153 */     this.neighborhood.realMin(min);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void realMin(RealPositionable min) {
/* 160 */     this.neighborhood.realMin(min);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double realMax(int d) {
/* 167 */     return this.neighborhood.realMax(d);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void realMax(double[] max) {
/* 173 */     this.neighborhood.realMax(max);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void realMax(RealPositionable max) {
/* 179 */     this.neighborhood.realMax(max);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int numDimensions() {
/* 185 */     return this.neighborhood.numDimensions();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public SpotNeighborhoodCursor<T> iterator() {
/* 191 */     return cursor();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public long min(int d) {
/* 197 */     return this.neighborhood.min(d);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void min(long[] min) {
/* 203 */     this.neighborhood.min(min);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void min(Positionable min) {
/* 209 */     this.neighborhood.min(min);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public long max(int d) {
/* 215 */     return this.neighborhood.max(d);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void max(long[] max) {
/* 221 */     this.neighborhood.max(max);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void max(Positionable max) {
/* 227 */     this.neighborhood.max(max);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void dimensions(long[] dimensions) {
/* 233 */     this.neighborhood.dimensions(dimensions);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public long dimension(int d) {
/* 239 */     return this.neighborhood.dimension(d);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void localize(int[] position) {
/* 245 */     for (int d = 0; d < position.length; d++)
/*     */     {
/* 247 */       position[d] = (int)this.center[d];
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void localize(long[] position) {
/* 254 */     for (int d = 0; d < position.length; d++)
/*     */     {
/* 256 */       position[d] = this.center[d];
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getIntPosition(int d) {
/* 263 */     return (int)this.center[d];
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public long getLongPosition(int d) {
/* 269 */     return this.center[d];
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void localize(float[] position) {
/* 275 */     for (int d = 0; d < position.length; d++)
/*     */     {
/* 277 */       position[d] = (float)this.center[d];
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void localize(double[] position) {
/* 284 */     for (int d = 0; d < position.length; d++)
/*     */     {
/* 286 */       position[d] = this.center[d];
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public float getFloatPosition(int d) {
/* 293 */     return (float)this.center[d];
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public double getDoublePosition(int d) {
/* 299 */     return this.center[d];
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Interval getStructuringElementBoundingBox() {
/* 305 */     long[] min = new long[numDimensions()];
/* 306 */     long[] max = new long[numDimensions()];
/* 307 */     min(min);
/* 308 */     max(max);
/* 309 */     FinalInterval interval = new FinalInterval(min, max);
/* 310 */     return (Interval)interval;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/util/SpotNeighborhood.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */