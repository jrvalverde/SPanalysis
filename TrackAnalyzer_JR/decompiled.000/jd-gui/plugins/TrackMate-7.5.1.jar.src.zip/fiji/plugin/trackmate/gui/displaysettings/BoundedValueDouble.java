/*    */ package fiji.plugin.trackmate.gui.displaysettings;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BoundedValueDouble
/*    */ {
/*    */   private double rangeMin;
/*    */   private double rangeMax;
/*    */   private double currentValue;
/*    */   private UpdateListener updateListener;
/*    */   
/*    */   public BoundedValueDouble(double rangeMin, double rangeMax, double currentValue) {
/* 48 */     this.rangeMin = rangeMin;
/* 49 */     this.rangeMax = rangeMax;
/* 50 */     this.currentValue = currentValue;
/* 51 */     this.updateListener = null;
/*    */   }
/*    */ 
/*    */   
/*    */   public double getRangeMin() {
/* 56 */     return this.rangeMin;
/*    */   }
/*    */ 
/*    */   
/*    */   public double getRangeMax() {
/* 61 */     return this.rangeMax;
/*    */   }
/*    */ 
/*    */   
/*    */   public double getCurrentValue() {
/* 66 */     return this.currentValue;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setRange(double min, double max) {
/* 71 */     assert min <= max;
/* 72 */     this.rangeMin = min;
/* 73 */     this.rangeMax = max;
/* 74 */     this.currentValue = Math.min(Math.max(this.currentValue, min), max);
/*    */     
/* 76 */     if (this.updateListener != null) {
/* 77 */       this.updateListener.update();
/*    */     }
/*    */   }
/*    */   
/*    */   public void setCurrentValue(double value) {
/* 82 */     this.currentValue = value;
/*    */     
/* 84 */     if (this.currentValue < this.rangeMin) {
/* 85 */       this.currentValue = this.rangeMin;
/* 86 */     } else if (this.currentValue > this.rangeMax) {
/* 87 */       this.currentValue = this.rangeMax;
/*    */     } 
/* 89 */     if (this.updateListener != null) {
/* 90 */       this.updateListener.update();
/*    */     }
/*    */   }
/*    */   
/*    */   public void setUpdateListener(UpdateListener l) {
/* 95 */     this.updateListener = l;
/*    */   }
/*    */   
/*    */   public static interface UpdateListener {
/*    */     void update();
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/gui/displaysettings/BoundedValueDouble.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */