/*     */ package fiji.plugin.trackmate.detection;
/*     */ 
/*     */ import fiji.plugin.trackmate.Model;
/*     */ import fiji.plugin.trackmate.Settings;
/*     */ import fiji.plugin.trackmate.gui.components.ConfigurationPanel;
/*     */ import fiji.plugin.trackmate.gui.components.detector.LabelImageDetectorConfigurationPanel;
/*     */ import fiji.plugin.trackmate.io.IOUtils;
/*     */ import fiji.plugin.trackmate.util.TMUtils;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.swing.ImageIcon;
/*     */ import net.imagej.ImgPlus;
/*     */ import net.imagej.ImgPlusMetadata;
/*     */ import net.imglib2.Interval;
/*     */ import net.imglib2.RandomAccessible;
/*     */ import net.imglib2.RandomAccessibleInterval;
/*     */ import net.imglib2.type.NativeType;
/*     */ import net.imglib2.type.Type;
/*     */ import net.imglib2.type.numeric.RealType;
/*     */ import org.jdom2.Element;
/*     */ import org.scijava.plugin.Plugin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Plugin(type = SpotDetectorFactory.class)
/*     */ public class LabeImageDetectorFactory<T extends RealType<T> & NativeType<T>>
/*     */   implements SpotDetectorFactory<T>
/*     */ {
/*     */   public static final String DETECTOR_KEY = "LABEL_IMAGE_DETECTOR";
/*     */   public static final String NAME = "Label image detector";
/*     */   public static final String INFO_TEXT = "<html>This detector creates spots by importing regions from a label image.<p>A label image is an image where the pixel values are integers. Each object in a label image is represented by a single common pixel value (the label) that is unique to the object.<p>This detector reads such an image and create spots from each object. In 2D the contour of a label is imported. In 3D, spherical spots of the same volume that the label are created.</html>";
/*     */   protected ImgPlus<T> img;
/*     */   protected Map<String, Object> settings;
/*     */   protected String errorMessage;
/*     */   
/*     */   public boolean setTarget(ImgPlus<T> img, Map<String, Object> settings) {
/* 100 */     this.img = img;
/* 101 */     this.settings = settings;
/* 102 */     return checkSettings(settings);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public SpotDetector<T> getDetector(Interval interval, int frame) {
/* 108 */     boolean simplifyContours = ((Boolean)this.settings.get("SIMPLIFY_CONTOURS")).booleanValue();
/* 109 */     double[] calibration = TMUtils.getSpatialCalibration((ImgPlusMetadata)this.img);
/* 110 */     int channel = ((Integer)this.settings.get("TARGET_CHANNEL")).intValue() - 1;
/* 111 */     RandomAccessibleInterval<Type> randomAccessibleInterval = DetectionUtils.prepareFrameImg((ImgPlus)this.img, channel, frame);
/*     */     
/* 113 */     LabelImageDetector<T> detector = new LabelImageDetector<>((RandomAccessible)randomAccessibleInterval, interval, calibration, simplifyContours);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 118 */     return detector;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean has2Dsegmentation() {
/* 124 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getKey() {
/* 130 */     return "LABEL_IMAGE_DETECTOR";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getErrorMessage() {
/* 136 */     return this.errorMessage;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean checkSettings(Map<String, Object> lSettings) {
/* 142 */     boolean ok = true;
/* 143 */     StringBuilder errorHolder = new StringBuilder();
/* 144 */     ok &= TMUtils.checkParameter(lSettings, "TARGET_CHANNEL", Integer.class, errorHolder);
/* 145 */     ok &= TMUtils.checkParameter(lSettings, "SIMPLIFY_CONTOURS", Boolean.class, errorHolder);
/* 146 */     List<String> mandatoryKeys = new ArrayList<>();
/* 147 */     mandatoryKeys.add("TARGET_CHANNEL");
/* 148 */     mandatoryKeys.add("SIMPLIFY_CONTOURS");
/* 149 */     ok &= TMUtils.checkMapKeys(lSettings, mandatoryKeys, null, errorHolder);
/* 150 */     if (!ok)
/*     */     {
/* 152 */       this.errorMessage = errorHolder.toString();
/*     */     }
/* 154 */     return ok;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean marshall(Map<String, Object> lSettings, Element element) {
/* 160 */     StringBuilder errorHolder = new StringBuilder();
/*     */     
/* 162 */     boolean ok = (IOUtils.writeTargetChannel(lSettings, element, errorHolder) && IOUtils.writeAttribute(lSettings, element, "SIMPLIFY_CONTOURS", Boolean.class, errorHolder));
/*     */     
/* 164 */     if (!ok) {
/* 165 */       this.errorMessage = errorHolder.toString();
/*     */     }
/* 167 */     return ok;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean unmarshall(Element element, Map<String, Object> lSettings) {
/* 173 */     lSettings.clear();
/* 174 */     StringBuilder errorHolder = new StringBuilder();
/* 175 */     boolean ok = true;
/* 176 */     ok &= IOUtils.readIntegerAttribute(element, lSettings, "TARGET_CHANNEL", errorHolder);
/* 177 */     ok &= IOUtils.readBooleanAttribute(element, lSettings, "SIMPLIFY_CONTOURS", errorHolder);
/* 178 */     if (!ok) {
/*     */       
/* 180 */       this.errorMessage = errorHolder.toString();
/* 181 */       return false;
/*     */     } 
/* 183 */     return checkSettings(lSettings);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ConfigurationPanel getDetectorConfigurationPanel(Settings lSettings, Model model) {
/* 189 */     return (ConfigurationPanel)new LabelImageDetectorConfigurationPanel(lSettings, model);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getInfoText() {
/* 195 */     return "<html>This detector creates spots by importing regions from a label image.<p>A label image is an image where the pixel values are integers. Each object in a label image is represented by a single common pixel value (the label) that is unique to the object.<p>This detector reads such an image and create spots from each object. In 2D the contour of a label is imported. In 3D, spherical spots of the same volume that the label are created.</html>";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/* 201 */     return "Label image detector";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, Object> getDefaultSettings() {
/* 207 */     Map<String, Object> lSettings = new HashMap<>();
/* 208 */     lSettings.put("TARGET_CHANNEL", Integer.valueOf(1));
/* 209 */     lSettings.put("SIMPLIFY_CONTOURS", Boolean.valueOf(true));
/* 210 */     return lSettings;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ImageIcon getIcon() {
/* 216 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public LabeImageDetectorFactory<T> copy() {
/* 222 */     return new LabeImageDetectorFactory();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/detection/LabeImageDetectorFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */