/*    */ package fiji.plugin.trackmate.gui.components.detector;
/*    */ 
/*    */ import fiji.plugin.trackmate.Model;
/*    */ import fiji.plugin.trackmate.Settings;
/*    */ import fiji.plugin.trackmate.detection.LabeImageDetectorFactory;
/*    */ import fiji.plugin.trackmate.detection.SpotDetectorFactory;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LabelImageDetectorConfigurationPanel
/*    */   extends ThresholdDetectorConfigurationPanel
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   public LabelImageDetectorConfigurationPanel(Settings settings, Model model) {
/* 52 */     super(settings, model, "<html>This detector creates spots by importing regions from a label image.<p>A label image is an image where the pixel values are integers. Each object in a label image is represented by a single common pixel value (the label) that is unique to the object.<p>This detector reads such an image and create spots from each object. In 2D the contour of a label is imported. In 3D, spherical spots of the same volume that the label are created.</html>", "Label image detector");
/* 53 */     this.ftfIntensityThreshold.setVisible(false);
/* 54 */     this.btnAutoThreshold.setVisible(false);
/* 55 */     this.lblIntensityThreshold.setVisible(false);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Map<String, Object> getSettings() {
/* 61 */     Map<String, Object> lSettings = super.getSettings();
/* 62 */     lSettings.remove("INTENSITY_THRESHOLD");
/* 63 */     return lSettings;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void setSettings(Map<String, Object> settings) {
/* 69 */     this.sliderChannel.setValue(((Integer)settings.get("TARGET_CHANNEL")).intValue());
/* 70 */     this.chkboxSimplify.setSelected(((Boolean)settings.get("SIMPLIFY_CONTOURS")).booleanValue());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected SpotDetectorFactory<?> getDetectorFactory() {
/* 85 */     return (SpotDetectorFactory<?>)new LabeImageDetectorFactory();
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/gui/components/detector/LabelImageDetectorConfigurationPanel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */