/*     */ package fiji.plugin.trackmate.tracking.sparselap.linker;
/*     */ 
/*     */ import fiji.plugin.trackmate.Logger;
/*     */ import fiji.plugin.trackmate.tracking.sparselap.costmatrix.CostMatrixCreator;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import net.imglib2.algorithm.BenchmarkAlgorithm;
/*     */ import net.imglib2.algorithm.OutputAlgorithm;
/*     */ import net.imglib2.util.Util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JaqamanLinker<K extends Comparable<K>, J extends Comparable<J>>
/*     */   extends BenchmarkAlgorithm
/*     */   implements OutputAlgorithm<Map<K, J>>
/*     */ {
/*     */   private Map<K, J> assignments;
/*     */   private Map<K, Double> costs;
/*     */   private final CostMatrixCreator<K, J> costMatrixCreator;
/*     */   private final Logger logger;
/*     */   
/*     */   public JaqamanLinker(CostMatrixCreator<K, J> costMatrixCreator, Logger logger) {
/*  69 */     this.costMatrixCreator = costMatrixCreator;
/*  70 */     this.logger = logger;
/*     */   }
/*     */ 
/*     */   
/*     */   public JaqamanLinker(CostMatrixCreator<K, J> costMatrixCreator) {
/*  75 */     this(costMatrixCreator, Logger.VOID_LOGGER);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<K, J> getResult() {
/*  90 */     return this.assignments;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<K, Double> getAssignmentCosts() {
/* 104 */     return this.costs;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean checkInput() {
/* 110 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean process() {
/* 116 */     long start = System.currentTimeMillis();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 122 */     this.logger.setStatus("Creating the main cost matrix...");
/* 123 */     if (!this.costMatrixCreator.checkInput() || !this.costMatrixCreator.process()) {
/*     */       
/* 125 */       this.errorMessage = this.costMatrixCreator.getErrorMessage();
/* 126 */       return false;
/*     */     } 
/* 128 */     this.logger.setProgress(0.5D);
/*     */     
/* 130 */     SparseCostMatrix tl = (SparseCostMatrix)this.costMatrixCreator.getResult();
/* 131 */     List<K> matrixRows = this.costMatrixCreator.getSourceList();
/* 132 */     List<J> matrixCols = this.costMatrixCreator.getTargetList();
/*     */     
/* 134 */     if (matrixCols.isEmpty() || matrixRows.isEmpty()) {
/*     */       
/* 136 */       this.assignments = Collections.emptyMap();
/* 137 */       this.costs = Collections.emptyMap();
/* 138 */       long l = System.currentTimeMillis();
/* 139 */       this.processingTime = l - start;
/* 140 */       return true;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 147 */     this.logger.setStatus("Completing the cost matrix...");
/*     */     
/* 149 */     int nCols = tl.getNCols();
/* 150 */     int nRows = tl.getNRows();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 156 */     double[] cctr = new double[nRows];
/* 157 */     int[] kktr = new int[nRows];
/* 158 */     for (int i = 0; i < nRows; i++) {
/*     */       
/* 160 */       kktr[i] = i;
/* 161 */       cctr[i] = this.costMatrixCreator.getAlternativeCostForSource((Comparable)matrixRows.get(i));
/*     */     } 
/* 163 */     int[] numbertr = new int[nRows];
/* 164 */     Arrays.fill(numbertr, 1);
/* 165 */     SparseCostMatrix tr = new SparseCostMatrix(cctr, kktr, numbertr, nRows);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 170 */     double[] ccbl = new double[nCols];
/* 171 */     int[] kkbl = new int[nCols];
/* 172 */     for (int j = 0; j < kkbl.length; j++) {
/*     */       
/* 174 */       kkbl[j] = j;
/* 175 */       ccbl[j] = this.costMatrixCreator.getAlternativeCostForTarget((Comparable)matrixCols.get(j));
/*     */     } 
/* 177 */     int[] numberbl = new int[nCols];
/* 178 */     Arrays.fill(numberbl, 1);
/* 179 */     SparseCostMatrix bl = new SparseCostMatrix(ccbl, kkbl, numberbl, nCols);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 187 */     double minCost = Math.min(Util.min(ccbl), Util.min(cctr));
/* 188 */     SparseCostMatrix br = tl.transpose();
/* 189 */     br.fillWith(minCost);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 194 */     SparseCostMatrix full = tl.hcat(tr).vcat(bl.hcat(br));
/* 195 */     this.logger.setProgress(0.6D);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 200 */     this.logger.setStatus("Solving the cost matrix...");
/* 201 */     LAPJV solver = new LAPJV(full);
/* 202 */     if (!solver.checkInput() || !solver.process()) {
/*     */       
/* 204 */       this.errorMessage = solver.getErrorMessage();
/* 205 */       return false;
/*     */     } 
/*     */     
/* 208 */     int[] assgn = solver.getResult();
/* 209 */     this.assignments = new HashMap<>();
/* 210 */     this.costs = new HashMap<>();
/* 211 */     for (int k = 0; k < assgn.length; k++) {
/*     */       
/* 213 */       int m = assgn[k];
/* 214 */       if (k < matrixRows.size() && m < matrixCols.size()) {
/*     */         
/* 216 */         Comparable comparable1 = (Comparable)matrixRows.get(k);
/* 217 */         Comparable comparable2 = (Comparable)matrixCols.get(m);
/* 218 */         this.assignments.put((K)comparable1, (J)comparable2);
/*     */         
/* 220 */         double cost = full.get(k, m, Double.POSITIVE_INFINITY);
/* 221 */         this.costs.put((K)comparable1, Double.valueOf(cost));
/*     */       } 
/*     */     } 
/*     */     
/* 225 */     this.logger.setProgress(1.0D);
/* 226 */     this.logger.setStatus("");
/* 227 */     long end = System.currentTimeMillis();
/* 228 */     this.processingTime = end - start;
/*     */     
/* 230 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public String resultToString() {
/* 235 */     if (null == this.assignments) return "Not solved yet. Process the algorithm prior to calling this method.";
/*     */     
/* 237 */     HashSet<K> unassignedSources = new HashSet<>(this.costMatrixCreator.getSourceList());
/* 238 */     HashSet<J> unassignedTargets = new HashSet<>(this.costMatrixCreator.getTargetList());
/*     */     
/* 240 */     int sw = -1;
/* 241 */     for (Comparable comparable : unassignedSources) {
/*     */       
/* 243 */       if (comparable.toString().length() > sw)
/*     */       {
/* 245 */         sw = comparable.toString().length();
/*     */       }
/*     */     } 
/* 248 */     sw++;
/*     */     
/* 250 */     int tw = -1;
/* 251 */     for (Comparable comparable : unassignedTargets) {
/*     */       
/* 253 */       if (comparable.toString().length() > tw)
/*     */       {
/* 255 */         tw = comparable.toString().length();
/*     */       }
/*     */     } 
/* 258 */     tw++;
/*     */     
/* 260 */     int cw = 0;
/* 261 */     for (Comparable comparable : this.assignments.keySet()) {
/*     */       
/* 263 */       double cost = ((Double)this.costs.get(comparable)).doubleValue();
/* 264 */       if (Math.log10(cost) > cw)
/*     */       {
/* 266 */         cw = (int)Math.log10(cost);
/*     */       }
/*     */     } 
/* 269 */     cw++;
/*     */     
/* 271 */     StringBuilder str = new StringBuilder();
/* 272 */     str.append("Found " + this.assignments.size() + " assignments:\n");
/* 273 */     for (Comparable comparable1 : this.assignments.keySet()) {
/*     */       
/* 275 */       Comparable comparable2 = (Comparable)this.assignments.get(comparable1);
/*     */       
/* 277 */       unassignedSources.remove(comparable1);
/* 278 */       unassignedTargets.remove(comparable2);
/*     */       
/* 280 */       double cost = ((Double)this.costs.get(comparable1)).doubleValue();
/* 281 */       str.append(String.format("%1$-" + sw + "s → %2$" + tw + "s, cost = %3$" + cw + ".1f\n", new Object[] { comparable1.toString(), comparable2.toString(), Double.valueOf(cost) }));
/*     */     } 
/*     */     
/* 284 */     if (!unassignedSources.isEmpty()) {
/*     */       
/* 286 */       str.append("Found " + unassignedSources.size() + " unassigned sources:\n");
/* 287 */       for (Comparable comparable : unassignedSources) {
/*     */         
/* 289 */         str.append(String.format("%1$-" + sw + "s → %2$" + tw + "s\n", new Object[] { comparable.toString(), Character.valueOf('ø') }));
/*     */       } 
/*     */     } 
/*     */     
/* 293 */     if (!unassignedTargets.isEmpty()) {
/*     */       
/* 295 */       str.append("Found " + unassignedTargets.size() + " unassigned targets:\n");
/* 296 */       for (Comparable comparable : unassignedTargets) {
/*     */         
/* 298 */         str.append(String.format("%1$-" + sw + "s → %2$" + tw + "s\n", new Object[] { Character.valueOf('ø'), comparable.toString() }));
/*     */       } 
/*     */     } 
/*     */     
/* 302 */     return str.toString();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/tracking/sparselap/linker/JaqamanLinker.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */