/*     */ package fiji.plugin.trackmate.visualization.trackscheme;
/*     */ 
/*     */ import com.mxgraph.model.mxCell;
/*     */ import com.mxgraph.model.mxGeometry;
/*     */ import com.mxgraph.model.mxICell;
/*     */ import com.mxgraph.view.mxGraph;
/*     */ import fiji.plugin.trackmate.Model;
/*     */ import fiji.plugin.trackmate.Spot;
/*     */ import java.util.HashMap;
/*     */ import java.util.Set;
/*     */ import org.jgrapht.event.GraphEdgeChangeEvent;
/*     */ import org.jgrapht.event.GraphListener;
/*     */ import org.jgrapht.event.GraphVertexChangeEvent;
/*     */ import org.jgrapht.graph.DefaultWeightedEdge;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JGraphXAdapter
/*     */   extends mxGraph
/*     */   implements GraphListener<Spot, DefaultWeightedEdge>
/*     */ {
/*  43 */   private final HashMap<Spot, mxCell> vertexToCellMap = new HashMap<>();
/*     */   
/*  45 */   private final HashMap<DefaultWeightedEdge, mxCell> edgeToCellMap = new HashMap<>();
/*     */   
/*  47 */   private final HashMap<mxCell, Spot> cellToVertexMap = new HashMap<>();
/*     */   
/*  49 */   private final HashMap<mxCell, DefaultWeightedEdge> cellToEdgeMap = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final Model tmm;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JGraphXAdapter(Model tmm) {
/*  60 */     this.tmm = tmm;
/*  61 */     insertTrackCollection(tmm);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void cellLabelChanged(Object cell, Object value, boolean autoSize) {
/*  75 */     this.model.beginUpdate();
/*     */     
/*     */     try {
/*  78 */       Spot spot = this.cellToVertexMap.get(cell);
/*  79 */       if (null == spot)
/*     */         return; 
/*  81 */       String str = (String)value;
/*  82 */       spot.setName(str);
/*  83 */       getModel().setValue(cell, str);
/*     */       
/*  85 */       if (autoSize)
/*     */       {
/*  87 */         cellSizeUpdated(cell, false);
/*     */       }
/*     */     }
/*     */     finally {
/*     */       
/*  92 */       this.model.endUpdate();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public mxCell addJGraphTVertex(Spot vertex) {
/*  98 */     if (this.vertexToCellMap.containsKey(vertex))
/*     */     {
/*     */ 
/*     */       
/* 102 */       return this.vertexToCellMap.get(vertex);
/*     */     }
/* 104 */     mxCell cell = null;
/* 105 */     getModel().beginUpdate();
/*     */     
/*     */     try {
/* 108 */       cell = new mxCell(vertex, new mxGeometry(), "");
/* 109 */       cell.setVertex(true);
/* 110 */       cell.setId(null);
/* 111 */       cell.setValue(vertex.getName());
/* 112 */       addCell(cell, this.defaultParent);
/* 113 */       this.vertexToCellMap.put(vertex, cell);
/* 114 */       this.cellToVertexMap.put(cell, vertex);
/*     */     }
/*     */     finally {
/*     */       
/* 118 */       getModel().endUpdate();
/*     */     } 
/* 120 */     return cell;
/*     */   }
/*     */ 
/*     */   
/*     */   public mxCell addJGraphTEdge(DefaultWeightedEdge edge) {
/* 125 */     if (this.edgeToCellMap.containsKey(edge))
/*     */     {
/*     */ 
/*     */       
/* 129 */       return this.edgeToCellMap.get(edge);
/*     */     }
/* 131 */     mxCell cell = null;
/* 132 */     getModel().beginUpdate();
/*     */     
/*     */     try {
/* 135 */       Spot source = this.tmm.getTrackModel().getEdgeSource(edge);
/* 136 */       Spot target = this.tmm.getTrackModel().getEdgeTarget(edge);
/* 137 */       cell = new mxCell(edge);
/* 138 */       cell.setEdge(true);
/* 139 */       cell.setId(null);
/* 140 */       cell.setValue(String.format("%.1f", new Object[] { Double.valueOf(this.tmm.getTrackModel().getEdgeWeight(edge)) }));
/* 141 */       cell.setGeometry(new mxGeometry());
/* 142 */       cell.getGeometry().setRelative(true);
/* 143 */       addEdge(cell, this.defaultParent, this.vertexToCellMap.get(source), this.vertexToCellMap.get(target), null);
/* 144 */       this.edgeToCellMap.put(edge, cell);
/* 145 */       this.cellToEdgeMap.put(cell, edge);
/*     */     }
/*     */     finally {
/*     */       
/* 149 */       getModel().endUpdate();
/*     */     } 
/* 151 */     return cell;
/*     */   }
/*     */ 
/*     */   
/*     */   public void mapEdgeToCell(DefaultWeightedEdge edge, mxCell cell) {
/* 156 */     this.cellToEdgeMap.put(cell, edge);
/* 157 */     this.edgeToCellMap.put(edge, cell);
/*     */   }
/*     */ 
/*     */   
/*     */   public Spot getSpotFor(mxICell cell) {
/* 162 */     return this.cellToVertexMap.get(cell);
/*     */   }
/*     */ 
/*     */   
/*     */   public DefaultWeightedEdge getEdgeFor(mxICell cell) {
/* 167 */     return this.cellToEdgeMap.get(cell);
/*     */   }
/*     */ 
/*     */   
/*     */   public mxCell getCellFor(Spot spot) {
/* 172 */     return this.vertexToCellMap.get(spot);
/*     */   }
/*     */ 
/*     */   
/*     */   public mxCell getCellFor(DefaultWeightedEdge edge) {
/* 177 */     return this.edgeToCellMap.get(edge);
/*     */   }
/*     */ 
/*     */   
/*     */   public Set<mxCell> getVertexCells() {
/* 182 */     return this.cellToVertexMap.keySet();
/*     */   }
/*     */ 
/*     */   
/*     */   public Set<mxCell> getEdgeCells() {
/* 187 */     return this.cellToEdgeMap.keySet();
/*     */   }
/*     */ 
/*     */   
/*     */   public void removeMapping(Spot spot) {
/* 192 */     mxICell cell = (mxICell)this.vertexToCellMap.remove(spot);
/* 193 */     this.cellToVertexMap.remove(cell);
/*     */   }
/*     */ 
/*     */   
/*     */   public void removeMapping(DefaultWeightedEdge edge) {
/* 198 */     mxICell cell = (mxICell)this.edgeToCellMap.remove(edge);
/* 199 */     this.cellToEdgeMap.remove(cell);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void vertexAdded(GraphVertexChangeEvent<Spot> e) {
/* 209 */     addJGraphTVertex((Spot)e.getVertex());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void vertexRemoved(GraphVertexChangeEvent<Spot> e) {
/* 215 */     mxCell cell = this.vertexToCellMap.remove(e.getVertex());
/* 216 */     removeCells(new Object[] { cell });
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void edgeAdded(GraphEdgeChangeEvent<Spot, DefaultWeightedEdge> e) {
/* 222 */     addJGraphTEdge((DefaultWeightedEdge)e.getEdge());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void edgeRemoved(GraphEdgeChangeEvent<Spot, DefaultWeightedEdge> e) {
/* 228 */     mxICell cell = (mxICell)this.edgeToCellMap.remove(e.getEdge());
/* 229 */     removeCells(new Object[] { cell });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void insertTrackCollection(Model lTmm) {
/* 243 */     this.model.beginUpdate();
/*     */     
/*     */     try {
/* 246 */       for (Integer trackID : lTmm.getTrackModel().trackIDs(true)) {
/*     */         
/* 248 */         for (Spot vertex : lTmm.getTrackModel().trackSpots(trackID)) {
/* 249 */           addJGraphTVertex(vertex);
/*     */         }
/* 251 */         for (DefaultWeightedEdge edge : lTmm.getTrackModel().trackEdges(trackID)) {
/* 252 */           addJGraphTEdge(edge);
/*     */         }
/*     */       } 
/*     */     } finally {
/*     */       
/* 257 */       this.model.endUpdate();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/visualization/trackscheme/JGraphXAdapter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */