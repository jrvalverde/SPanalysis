/*     */ package fiji.plugin.trackmate.action;
/*     */ 
/*     */ import fiji.plugin.trackmate.Model;
/*     */ import fiji.plugin.trackmate.SelectionModel;
/*     */ import fiji.plugin.trackmate.Settings;
/*     */ import fiji.plugin.trackmate.Spot;
/*     */ import fiji.plugin.trackmate.TrackMate;
/*     */ import fiji.plugin.trackmate.TrackModel;
/*     */ import fiji.plugin.trackmate.gui.Icons;
/*     */ import fiji.plugin.trackmate.gui.displaysettings.DisplaySettings;
/*     */ import fiji.plugin.trackmate.gui.displaysettings.DisplaySettingsIO;
/*     */ import fiji.plugin.trackmate.io.TmXmlReader;
/*     */ import ij.ImageJ;
/*     */ import ij.ImagePlus;
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Frame;
/*     */ import java.io.File;
/*     */ import java.text.DecimalFormat;
/*     */ import java.text.DecimalFormatSymbols;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Comparator;
/*     */ import java.util.List;
/*     */ import javax.swing.ImageIcon;
/*     */ import javax.swing.JFrame;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JScrollPane;
/*     */ import javax.swing.JTable;
/*     */ import javax.swing.RowSorter;
/*     */ import javax.swing.SortOrder;
/*     */ import javax.swing.table.AbstractTableModel;
/*     */ import javax.swing.table.DefaultTableCellRenderer;
/*     */ import javax.swing.table.TableColumn;
/*     */ import javax.swing.table.TableRowSorter;
/*     */ import org.scijava.plugin.Plugin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MotilityLabExporter
/*     */   extends AbstractTMAction
/*     */ {
/*     */   public static final String NAME = "Export to MotilityLab spreadsheet";
/*     */   public static final String KEY = "MOTILITYLAB_EXPORTER";
/*     */   public static final String INFO_TEXT = "<html>Display the visible tracks in a spreadsheet that can be copy-pasted directly into the <a url=\"http://www.motilitylab.net/import/data-import.php\"> MotilityLab website</a> for further track analysis.";
/*     */   private static final int ROW_HEIGHT = 22;
/*  82 */   private static final List<String> HEADERS = Arrays.asList(new String[] { "Tracking ID", "Timepoint", "Time (sec)", "X pos (µm)", "Y pos (µm)", "Z pos (µm)" });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  90 */   private static final List<Class<?>> CLASSES = Arrays.asList(new Class[] { Integer.class, Integer.class, Double.class, Double.class, Double.class, Double.class });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void execute(TrackMate trackmate, SelectionModel selectionModel, DisplaySettings displaySettings, Frame parent) {
/* 105 */     JPanel panel = createSpotTable(trackmate.getModel());
/*     */     
/* 107 */     JFrame frame = new JFrame("TrackMate MotilityLab table export");
/* 108 */     frame.setIconImage(Icons.TRACK_TABLES_ICON.getImage());
/* 109 */     frame.getContentPane().add(panel);
/* 110 */     frame.setLocationRelativeTo(parent);
/* 111 */     frame.pack();
/* 112 */     frame.setVisible(true);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private final JPanel createSpotTable(Model model) {
/* 118 */     List<Spot> spots = new ArrayList<>(model.getTrackModel().vertexSet());
/*     */ 
/*     */     
/* 121 */     MyTableModel tableModel = new MyTableModel(spots, model.getTrackModel());
/* 122 */     JTable table = new JTable(tableModel);
/*     */ 
/*     */     
/* 125 */     MyTableCellRenderer cellRenderer = new MyTableCellRenderer();
/* 126 */     for (int c = 0; c < table.getColumnModel().getColumnCount(); c++) {
/*     */       
/* 128 */       TableColumn column = table.getColumnModel().getColumn(c);
/* 129 */       column.setCellRenderer(cellRenderer);
/*     */     } 
/*     */ 
/*     */     
/* 133 */     table.setRowHeight(22);
/* 134 */     table.getSelectionModel().setSelectionMode(2);
/* 135 */     table.setGridColor(table.getTableHeader().getBackground());
/* 136 */     table.getTableHeader().setPreferredSize(new Dimension(100, 33));
/*     */ 
/*     */     
/* 139 */     TableRowSorter<MyTableModel> sorter = new TableRowSorter<>(tableModel);
/* 140 */     for (int i = 0; i < CLASSES.size(); i++) {
/*     */       
/* 142 */       if (((Class)CLASSES.get(i)).equals(Integer.class)) {
/* 143 */         sorter.setComparator(i, (i1, i2) -> Integer.compare(((Integer)i1).intValue(), ((Integer)i2).intValue()));
/* 144 */       } else if (((Class)CLASSES.get(i)).equals(Double.class)) {
/* 145 */         sorter.setComparator(i, (d1, d2) -> Double.compare(((Double)d1).doubleValue(), ((Double)d2).doubleValue()));
/* 146 */       } else if (((Class)CLASSES.get(i)).equals(Color.class)) {
/* 147 */         sorter.setComparator(i, (c1, c2) -> c1.toString().compareTo(c2.toString()));
/*     */       } else {
/* 149 */         sorter.setComparator(i, Comparator.naturalOrder());
/*     */       } 
/*     */     } 
/* 152 */     table.setRowSorter((RowSorter)sorter);
/* 153 */     sorter.setSortKeys(Arrays.asList(new RowSorter.SortKey[] { new RowSorter.SortKey(0, SortOrder.ASCENDING), new RowSorter.SortKey(1, SortOrder.ASCENDING) }));
/* 154 */     sorter.sort();
/*     */ 
/*     */     
/* 157 */     JScrollPane scrollPane = new JScrollPane(table, 20, 30);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 162 */     JPanel panel = new JPanel();
/* 163 */     panel.setLayout(new BorderLayout());
/* 164 */     panel.add(scrollPane, "Center");
/* 165 */     return panel;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private class MyTableModel
/*     */     extends AbstractTableModel
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */ 
/*     */     
/*     */     private final List<Spot> spots;
/*     */ 
/*     */     
/*     */     private final TrackModel trackModel;
/*     */ 
/*     */     
/*     */     public MyTableModel(List<Spot> spots, TrackModel trackModel) {
/* 183 */       this.spots = spots;
/* 184 */       this.trackModel = trackModel;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public int getRowCount() {
/* 190 */       return this.spots.size();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public int getColumnCount() {
/* 196 */       return 6;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public String getColumnName(int column) {
/* 202 */       return MotilityLabExporter.HEADERS.get(column);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Object getValueAt(int rowIndex, int columnIndex) {
/* 208 */       if (rowIndex < 0 || rowIndex >= this.spots.size()) {
/* 209 */         return null;
/*     */       }
/* 211 */       Spot spot = this.spots.get(rowIndex);
/* 212 */       if (null == spot) {
/* 213 */         return null;
/*     */       }
/* 215 */       switch (columnIndex) {
/*     */         
/*     */         case 0:
/* 218 */           return this.trackModel.trackIDOf(spot);
/*     */         case 1:
/* 220 */           return Integer.valueOf(spot.getFeature("FRAME").intValue());
/*     */         case 2:
/* 222 */           return spot.getFeature("POSITION_T");
/*     */         case 3:
/* 224 */           return spot.getFeature("POSITION_X");
/*     */         case 4:
/* 226 */           return spot.getFeature("POSITION_Y");
/*     */         case 5:
/* 228 */           return spot.getFeature("POSITION_Z");
/*     */       } 
/* 230 */       throw new IllegalArgumentException("Undefined column index: " + columnIndex);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private class MyTableCellRenderer
/*     */     extends DefaultTableCellRenderer
/*     */   {
/* 244 */     private final DecimalFormat nf = new DecimalFormat(); public MyTableCellRenderer() {
/* 245 */       DecimalFormatSymbols formatSymbols = new DecimalFormatSymbols();
/* 246 */       formatSymbols.setNaN("NaN");
/* 247 */       this.nf.setDecimalFormatSymbols(formatSymbols);
/*     */     }
/*     */     
/*     */     private static final long serialVersionUID = 1L;
/*     */     
/*     */     public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
/* 253 */       JLabel c = (JLabel)super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
/*     */       
/* 255 */       if (value instanceof Double) {
/*     */         
/* 257 */         setHorizontalAlignment(4);
/* 258 */         Double doubleValue = (Double)value;
/* 259 */         setText(this.nf.format(doubleValue.doubleValue()));
/*     */       }
/* 261 */       else if (value instanceof Number) {
/*     */         
/* 263 */         setHorizontalAlignment(4);
/*     */       }
/*     */       else {
/*     */         
/* 267 */         setHorizontalAlignment(2);
/*     */       } 
/* 269 */       return c;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Plugin(type = TrackMateActionFactory.class, enabled = true)
/*     */   public static class Factory
/*     */     implements TrackMateActionFactory
/*     */   {
/*     */     public String getInfoText() {
/* 280 */       return "<html>Display the visible tracks in a spreadsheet that can be copy-pasted directly into the <a url=\"http://www.motilitylab.net/import/data-import.php\"> MotilityLab website</a> for further track analysis.";
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public String getName() {
/* 286 */       return "Export to MotilityLab spreadsheet";
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public String getKey() {
/* 292 */       return "MOTILITYLAB_EXPORTER";
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public TrackMateAction create() {
/* 298 */       return new MotilityLabExporter();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public ImageIcon getIcon() {
/* 304 */       return Icons.TRACK_TABLES_ICON;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static void main(String[] args) {
/* 310 */     ImageJ.main(args);
/*     */     
/* 312 */     TmXmlReader reader = new TmXmlReader(new File("samples/MAX_Merged.xml"));
/* 313 */     Model model = reader.getModel();
/* 314 */     ImagePlus imp = reader.readImage();
/* 315 */     Settings settings = reader.readSettings(imp);
/* 316 */     (new MotilityLabExporter()).execute(new TrackMate(model, settings), new SelectionModel(model), 
/*     */ 
/*     */         
/* 319 */         DisplaySettingsIO.readUserDefault(), null);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/action/MotilityLabExporter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */