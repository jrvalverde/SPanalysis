/*     */ package fiji.plugin.trackmate.features.spot;
/*     */ 
/*     */ import fiji.plugin.trackmate.Spot;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.Callable;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.Executors;
/*     */ import java.util.concurrent.Future;
/*     */ import net.imglib2.algorithm.Benchmark;
/*     */ import net.imglib2.algorithm.MultiThreaded;
/*     */ import net.imglib2.type.numeric.RealType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractSpotFeatureAnalyzer<T extends RealType<T>>
/*     */   implements SpotAnalyzer<T>, MultiThreaded, Benchmark
/*     */ {
/*     */   protected String errorMessage;
/*     */   private long processingTime;
/*     */   private int numThreads;
/*     */   
/*     */   public abstract void process(Spot paramSpot);
/*     */   
/*     */   public AbstractSpotFeatureAnalyzer() {
/*  50 */     setNumThreads();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void process(Iterable<Spot> spots) {
/*  56 */     long start = System.currentTimeMillis();
/*     */     
/*  58 */     List<Callable<Void>> tasks = new ArrayList<>();
/*  59 */     for (Spot spot : spots) {
/*     */       
/*  61 */       Callable<Void> task = new Callable<Void>()
/*     */         {
/*     */ 
/*     */           
/*     */           public Void call() throws Exception
/*     */           {
/*     */             try {
/*  68 */               AbstractSpotFeatureAnalyzer.this.process(spot);
/*     */             }
/*  70 */             catch (Exception e) {
/*     */               
/*  72 */               e.printStackTrace();
/*     */             } 
/*  74 */             return null;
/*     */           }
/*     */         };
/*  77 */       tasks.add(task);
/*     */     } 
/*     */     
/*  80 */     ExecutorService executorService = Executors.newFixedThreadPool(this.numThreads);
/*     */     
/*     */     try {
/*  83 */       List<Future<Void>> futures = executorService.invokeAll(tasks);
/*  84 */       for (Future<Void> future : futures) {
/*  85 */         future.get();
/*     */       }
/*  87 */     } catch (InterruptedException|java.util.concurrent.ExecutionException e) {
/*     */       
/*  89 */       e.printStackTrace();
/*     */     } 
/*     */     
/*  92 */     executorService.shutdown();
/*  93 */     this.processingTime = System.currentTimeMillis() - start;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getNumThreads() {
/*  99 */     return this.numThreads;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setNumThreads() {
/* 105 */     setNumThreads(Runtime.getRuntime().availableProcessors() / 2);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setNumThreads(int numThreads) {
/* 111 */     this.numThreads = numThreads;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public long getProcessingTime() {
/* 117 */     return this.processingTime;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/features/spot/AbstractSpotFeatureAnalyzer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */