/*    */ package fiji.plugin.trackmate.action;
/*    */ 
/*    */ import fiji.plugin.trackmate.Model;
/*    */ import fiji.plugin.trackmate.SelectionModel;
/*    */ import fiji.plugin.trackmate.TrackMate;
/*    */ import fiji.plugin.trackmate.gui.Icons;
/*    */ import fiji.plugin.trackmate.gui.displaysettings.DisplaySettings;
/*    */ import fiji.plugin.trackmate.visualization.table.AllSpotsTableView;
/*    */ import java.awt.Frame;
/*    */ import javax.swing.ImageIcon;
/*    */ import org.scijava.plugin.Plugin;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ExportAllSpotsStatsAction
/*    */   extends AbstractTMAction
/*    */ {
/*    */   public static final String NAME = "Export all spots statistics";
/*    */   public static final String KEY = "EXPORT_ALL_SPOTS_STATS";
/*    */   public static final String INFO_TEXT = "<html>Export the statistics of all spots to a table. The numerical features of all visible spots are exported, regardless of whether they are in a track or not.</html>";
/*    */   
/*    */   public void execute(TrackMate trackmate, SelectionModel selectionModel, DisplaySettings displaySettings, Frame parent) {
/* 54 */     createSpotsTable(trackmate.getModel(), selectionModel, displaySettings).render();
/*    */   }
/*    */ 
/*    */   
/*    */   public static final AllSpotsTableView createSpotsTable(Model model, SelectionModel selectionModel, DisplaySettings displaySettings) {
/* 59 */     return new AllSpotsTableView(model, selectionModel, displaySettings);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Plugin(type = TrackMateActionFactory.class, visible = false)
/*    */   public static class Factory
/*    */     implements TrackMateActionFactory
/*    */   {
/*    */     public String getInfoText() {
/* 70 */       return "<html>Export the statistics of all spots to a table. The numerical features of all visible spots are exported, regardless of whether they are in a track or not.</html>";
/*    */     }
/*    */ 
/*    */ 
/*    */     
/*    */     public String getKey() {
/* 76 */       return "EXPORT_ALL_SPOTS_STATS";
/*    */     }
/*    */ 
/*    */ 
/*    */     
/*    */     public TrackMateAction create() {
/* 82 */       return new ExportAllSpotsStatsAction();
/*    */     }
/*    */ 
/*    */ 
/*    */     
/*    */     public ImageIcon getIcon() {
/* 88 */       return Icons.CALCULATOR_ICON;
/*    */     }
/*    */ 
/*    */ 
/*    */     
/*    */     public String getName() {
/* 94 */       return "Export all spots statistics";
/*    */     }
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/action/ExportAllSpotsStatsAction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */