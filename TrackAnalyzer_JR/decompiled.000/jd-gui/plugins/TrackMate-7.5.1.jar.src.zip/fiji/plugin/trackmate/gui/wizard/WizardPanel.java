/*     */ package fiji.plugin.trackmate.gui.wizard;
/*     */ 
/*     */ import fiji.plugin.trackmate.gui.GuiUtils;
/*     */ import fiji.plugin.trackmate.util.PainterThread;
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.CardLayout;
/*     */ import java.awt.Component;
/*     */ import java.awt.Font;
/*     */ import java.awt.GridLayout;
/*     */ import javax.swing.Box;
/*     */ import javax.swing.BoxLayout;
/*     */ import javax.swing.ImageIcon;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JToggleButton;
/*     */ import javax.swing.border.EmptyBorder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WizardPanel
/*     */   extends JPanel
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  48 */   public static final Font FONT = new Font("Arial", 0, 10);
/*  49 */   public static final Font BIG_FONT = new Font("Arial", 0, 14);
/*  50 */   public static final Font SMALL_FONT = FONT.deriveFont(8);
/*     */ 
/*     */   
/*     */   private final CardLayout cardLayout;
/*     */   
/*     */   private final AnimatorPanel animatorPanel;
/*     */   
/*     */   final JPanel panelMain;
/*     */   
/*     */   final JButton btnSave;
/*     */   
/*     */   final JToggleButton btnLog;
/*     */   
/*     */   final JToggleButton btnDisplayConfig;
/*     */   
/*     */   final JButton btnPrevious;
/*     */   
/*     */   final JButton btnNext;
/*     */   
/*     */   final JButton btnCancel;
/*     */   
/*     */   final JButton btnResume;
/*     */   
/*     */   final JPanel panelButtons;
/*     */ 
/*     */   
/*     */   public WizardPanel() {
/*  77 */     setLayout(new BorderLayout(0, 0));
/*  78 */     this.animatorPanel = new AnimatorPanel();
/*     */     
/*  80 */     this.panelButtons = new JPanel();
/*  81 */     this.panelButtons.setBorder(new EmptyBorder(3, 3, 3, 3));
/*  82 */     add(this.panelButtons, "South");
/*  83 */     this.panelButtons.setLayout(new BoxLayout(this.panelButtons, 0));
/*     */     
/*  85 */     this.btnSave = new JButton();
/*  86 */     this.panelButtons.add(this.btnSave);
/*     */     
/*  88 */     Component horizontalGlue_1 = Box.createHorizontalGlue();
/*  89 */     this.panelButtons.add(horizontalGlue_1);
/*     */     
/*  91 */     this.btnLog = new JToggleButton();
/*  92 */     this.panelButtons.add(this.btnLog);
/*     */     
/*  94 */     this.btnDisplayConfig = new JToggleButton();
/*  95 */     this.panelButtons.add(this.btnDisplayConfig);
/*     */     
/*  97 */     Component horizontalGlue = Box.createHorizontalGlue();
/*  98 */     this.panelButtons.add(horizontalGlue);
/*     */     
/* 100 */     this.btnPrevious = new JButton();
/* 101 */     this.panelButtons.add(this.btnPrevious);
/*     */     
/* 103 */     this.btnNext = new JButton();
/* 104 */     this.panelButtons.add(this.btnNext);
/*     */     
/* 106 */     this.btnCancel = new JButton();
/* 107 */     this.panelButtons.add(this.btnCancel);
/*     */     
/* 109 */     this.btnResume = new JButton();
/* 110 */     this.panelButtons.add(this.btnResume);
/*     */     
/* 112 */     this.panelMain = new JPanel();
/* 113 */     add(this.panelMain, "Center");
/* 114 */     this.cardLayout = new CardLayout(0, 0);
/* 115 */     this.panelMain.setLayout(this.cardLayout);
/*     */   }
/*     */ 
/*     */   
/*     */   public void display(WizardPanelDescriptor current) {
/* 120 */     this.panelMain.add(current.getPanelComponent(), current.getPanelDescriptorIdentifier());
/* 121 */     this.cardLayout.show(this.panelMain, current.getPanelDescriptorIdentifier());
/*     */   }
/*     */ 
/*     */   
/*     */   public void transition(WizardPanelDescriptor to, WizardPanelDescriptor from, TransitionAnimator.Direction direction) {
/* 126 */     this.animatorPanel.start(from, to, direction);
/*     */   }
/*     */ 
/*     */   
/*     */   private class AnimatorPanel
/*     */     extends JPanel
/*     */     implements PainterThread.Paintable
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */     
/*     */     private static final long duration = 200L;
/*     */     
/*     */     private final JLabel label;
/*     */     
/*     */     private TransitionAnimator animator;
/*     */     private WizardPanelDescriptor to;
/*     */     private final PainterThread painterThread;
/*     */     
/*     */     public AnimatorPanel() {
/* 145 */       super(new GridLayout());
/* 146 */       this.label = new JLabel();
/* 147 */       add(this.label);
/* 148 */       this.painterThread = new PainterThread(this);
/* 149 */       this.painterThread.start();
/*     */       
/* 151 */       GuiUtils.addOnClosingEvent(this, () -> WizardPanel.this.animatorPanel.painterThread.interrupt());
/*     */     }
/*     */ 
/*     */     
/*     */     public void start(WizardPanelDescriptor from, WizardPanelDescriptor to, TransitionAnimator.Direction direction) {
/* 156 */       this.to = to;
/* 157 */       this.animator = new TransitionAnimator(from.getPanelComponent(), to.getPanelComponent(), direction, 200L);
/* 158 */       this.label.setIcon(new ImageIcon(this.animator.getCurrent(System.currentTimeMillis())));
/*     */       
/* 160 */       WizardPanel.this.panelMain.add(this, "transitionCard");
/* 161 */       WizardPanel.this.cardLayout.show(WizardPanel.this.panelMain, "transitionCard");
/*     */     }
/*     */ 
/*     */     
/*     */     private void stop() {
/* 166 */       this.animator = null;
/* 167 */       WizardPanel.this.panelMain.remove(this);
/* 168 */       WizardPanel.this.panelMain.add(this.to.getPanelComponent(), this.to.getPanelDescriptorIdentifier());
/* 169 */       WizardPanel.this.cardLayout.show(WizardPanel.this.panelMain, this.to.getPanelDescriptorIdentifier());
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void paint() {
/* 175 */       synchronized (this) {
/*     */         
/* 177 */         if (this.animator != null) {
/*     */           
/* 179 */           this.label.setIcon(new ImageIcon(this.animator.getCurrent(System.currentTimeMillis())));
/* 180 */           if (this.animator.isComplete()) {
/* 181 */             stop();
/*     */           }
/* 183 */           repaint();
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void repaint() {
/* 191 */       if (null != this.painterThread)
/* 192 */         this.painterThread.requestRepaint(); 
/*     */     }
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/gui/wizard/WizardPanel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */