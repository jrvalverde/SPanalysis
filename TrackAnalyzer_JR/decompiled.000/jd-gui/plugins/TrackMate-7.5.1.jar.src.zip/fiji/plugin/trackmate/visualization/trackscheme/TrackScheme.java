/*      */ package fiji.plugin.trackmate.visualization.trackscheme;
/*      */ 
/*      */ import com.mxgraph.canvas.mxGraphics2DCanvas;
/*      */ import com.mxgraph.model.mxCell;
/*      */ import com.mxgraph.model.mxGeometry;
/*      */ import com.mxgraph.model.mxICell;
/*      */ import com.mxgraph.model.mxIGraphModel;
/*      */ import com.mxgraph.util.mxCellRenderer;
/*      */ import com.mxgraph.util.mxConstants;
/*      */ import com.mxgraph.util.mxEventObject;
/*      */ import com.mxgraph.util.mxEventSource;
/*      */ import com.mxgraph.util.mxStyleUtils;
/*      */ import com.mxgraph.view.mxCellState;
/*      */ import com.mxgraph.view.mxGraphSelectionModel;
/*      */ import fiji.plugin.trackmate.Model;
/*      */ import fiji.plugin.trackmate.ModelChangeEvent;
/*      */ import fiji.plugin.trackmate.ModelChangeListener;
/*      */ import fiji.plugin.trackmate.SelectionChangeEvent;
/*      */ import fiji.plugin.trackmate.SelectionModel;
/*      */ import fiji.plugin.trackmate.Spot;
/*      */ import fiji.plugin.trackmate.gui.displaysettings.DisplaySettings;
/*      */ import fiji.plugin.trackmate.visualization.AbstractTrackMateModelView;
/*      */ import ij.ImagePlus;
/*      */ import java.awt.Color;
/*      */ import java.awt.Dimension;
/*      */ import java.awt.Graphics2D;
/*      */ import java.awt.Point;
/*      */ import java.awt.event.WindowAdapter;
/*      */ import java.awt.event.WindowEvent;
/*      */ import java.awt.image.BufferedImage;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import java.util.TreeMap;
/*      */ import javax.swing.JViewport;
/*      */ import javax.swing.SwingUtilities;
/*      */ import org.jgrapht.graph.DefaultWeightedEdge;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class TrackScheme
/*      */   extends AbstractTrackMateModelView
/*      */ {
/*      */   public static final String INFO_TEXT = "<html>TrackScheme displays the tracking results as track lanes, <br>ignoring the spot actual position. <p>Tracks can be edited through link creation and removal.</html>";
/*      */   static final int Y_COLUMN_SIZE = 96;
/*      */   static final int X_COLUMN_SIZE = 160;
/*      */   static final int DEFAULT_CELL_WIDTH = 128;
/*      */   static final int DEFAULT_CELL_HEIGHT = 40;
/*      */   public static final String DEFAULT_COLOR = "#FF00FF";
/*   85 */   private static final Dimension DEFAULT_SIZE = new Dimension(800, 600);
/*      */   
/*      */   static final int TABLE_CELL_WIDTH = 40;
/*      */   
/*   89 */   static final Color GRID_COLOR = Color.GRAY;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final boolean DEFAULT_DO_DISPLAY_COSTS_ON_EDGES = false;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final int DEFAULT_PAINT_DECORATION_LEVEL = 1;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final boolean DEFAULT_LINKING_ENABLED = false;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final boolean DEFAULT_THUMBNAILS_ENABLED = false;
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String KEY = "TRACKSCHEME";
/*      */ 
/*      */ 
/*      */   
/*      */   private final TrackSchemeFrame gui;
/*      */ 
/*      */ 
/*      */   
/*      */   private JGraphXAdapter graph;
/*      */ 
/*      */ 
/*      */   
/*      */   private TrackSchemeGraphLayout graphLayout;
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean doFireSelectionChangeEvent = true;
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean doFireModelChangeEvent = true;
/*      */ 
/*      */ 
/*      */   
/*  137 */   private Map<Integer, Integer> rowLengths = new HashMap<>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  143 */   private int unlaidSpotColumn = 2;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private SpotImageUpdater spotImageUpdater;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   TrackSchemeStylist stylist;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean doThumbnailCapture = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TrackScheme(final Model model, SelectionModel selectionModel, DisplaySettings displaySettings) {
/*  165 */     super(model, selectionModel, displaySettings);
/*  166 */     this.gui = new TrackSchemeFrame(this, displaySettings);
/*  167 */     String title = "TrackScheme";
/*  168 */     this.gui.setTitle("TrackScheme");
/*  169 */     this.gui.setSize(DEFAULT_SIZE);
/*      */     
/*  171 */     displaySettings.listeners().add(() -> doTrackStyle());
/*  172 */     this.gui.addWindowListener(new WindowAdapter()
/*      */         {
/*      */           
/*      */           public void windowClosing(WindowEvent e)
/*      */           {
/*  177 */             model.removeModelChangeListener((ModelChangeListener)TrackScheme.this);
/*      */           }
/*      */         });
/*  180 */     this.gui.setLocationByPlatform(true);
/*  181 */     this.gui.setLocationRelativeTo(null);
/*  182 */     this.gui.setVisible(true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSpotImageUpdater(SpotImageUpdater spotImageUpdater) {
/*  191 */     this.spotImageUpdater = spotImageUpdater;
/*      */   }
/*      */ 
/*      */   
/*      */   public SelectionModel getSelectionModel() {
/*  196 */     return this.selectionModel;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getUnlaidSpotColumn() {
/*  205 */     return this.unlaidSpotColumn;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getNextFreeColumn(int frame) {
/*  213 */     Integer columnIndex = this.rowLengths.get(Integer.valueOf(frame));
/*  214 */     if (null == columnIndex)
/*      */     {
/*  216 */       columnIndex = Integer.valueOf(2);
/*      */     }
/*  218 */     return columnIndex.intValue() + 1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TrackSchemeFrame getGUI() {
/*  226 */     return this.gui;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JGraphXAdapter getGraph() {
/*  235 */     return this.graph;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TrackSchemeGraphLayout getGraphLayout() {
/*  243 */     return this.graphLayout;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private JGraphXAdapter createGraph() {
/*  256 */     this.gui.logger.setStatus("Creating graph adapter.");
/*      */     
/*  258 */     JGraphXAdapter lGraph = new JGraphXAdapter(this.model);
/*  259 */     lGraph.setAllowLoops(false);
/*  260 */     lGraph.setAllowDanglingEdges(false);
/*  261 */     lGraph.setCellsCloneable(false);
/*  262 */     lGraph.setCellsSelectable(true);
/*  263 */     lGraph.setCellsDisconnectable(false);
/*  264 */     lGraph.setCellsMovable(true);
/*  265 */     lGraph.setGridEnabled(false);
/*  266 */     lGraph.setLabelsVisible(true);
/*  267 */     lGraph.setDropEnabled(false);
/*      */ 
/*      */     
/*  270 */     lGraph.addListener("cellsRemoved", new CellRemovalListener());
/*      */ 
/*      */     
/*  273 */     lGraph.getSelectionModel().addListener("change", new SelectionChangeListener());
/*      */ 
/*      */     
/*  276 */     return lGraph;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private mxICell updateCellOf(Spot spot) {
/*      */     mxICell mxICell;
/*  289 */     mxCell mxCell = this.graph.getCellFor(spot);
/*  290 */     this.graph.getModel().beginUpdate();
/*      */     
/*      */     try {
/*  293 */       if (null == mxCell) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  301 */         int row = getUnlaidSpotColumn();
/*  302 */         mxICell = insertSpotInGraph(spot, row);
/*  303 */         int frame = spot.getFeature("FRAME").intValue();
/*  304 */         this.rowLengths.put(Integer.valueOf(frame), Integer.valueOf(row + 1));
/*      */       } 
/*      */ 
/*      */       
/*  308 */       if (this.spotImageUpdater != null && this.doThumbnailCapture)
/*      */       {
/*  310 */         String style = mxICell.getStyle();
/*  311 */         double radiusFactor = this.displaySettings.getSpotDisplayRadius();
/*  312 */         String imageStr = this.spotImageUpdater.getImageString(spot, radiusFactor);
/*  313 */         style = mxStyleUtils.setStyle(style, mxConstants.STYLE_IMAGE, "data:image/base64," + imageStr);
/*  314 */         this.graph.getModel().setStyle(mxICell, style);
/*      */       }
/*      */     
/*      */     } finally {
/*      */       
/*  319 */       this.graph.getModel().endUpdate();
/*      */     } 
/*  321 */     return mxICell;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private mxICell insertSpotInGraph(Spot spot, int targetColumn) {
/*  331 */     mxCell mxCell = this.graph.getCellFor(spot);
/*  332 */     if (mxCell != null)
/*      */     {
/*      */       
/*  335 */       return (mxICell)mxCell;
/*      */     }
/*      */     
/*  338 */     mxCell = this.graph.addJGraphTVertex(spot);
/*      */     
/*  340 */     int row = spot.getFeature("FRAME").intValue();
/*  341 */     double x = ((targetColumn - 1) * 160 - 64);
/*  342 */     double y = (0.5D + row) * 96.0D - 20.0D;
/*  343 */     mxGeometry geometry = new mxGeometry(x, y, 128.0D, 40.0D);
/*  344 */     mxCell.setGeometry(geometry);
/*      */     
/*  346 */     double radiusFactor = this.displaySettings.getSpotDisplayRadius();
/*  347 */     if (null != this.spotImageUpdater && this.doThumbnailCapture) {
/*      */       
/*  349 */       String imageStr = this.spotImageUpdater.getImageString(spot, radiusFactor);
/*  350 */       this.graph.getModel().setStyle(mxCell, mxConstants.STYLE_IMAGE + "=data:image/base64," + imageStr);
/*      */     } 
/*  352 */     return (mxICell)mxCell;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void importTrack(int trackIndex) {
/*  363 */     this.model.beginUpdate();
/*  364 */     this.graph.getModel().beginUpdate();
/*      */ 
/*      */     
/*      */     try {
/*  368 */       this.model.setTrackVisibility(Integer.valueOf(trackIndex), true);
/*      */       
/*  370 */       int targetColumn = getUnlaidSpotColumn();
/*      */       
/*  372 */       Set<Spot> trackSpots = this.model.getTrackModel().trackSpots(Integer.valueOf(trackIndex));
/*  373 */       for (Spot trackSpot : trackSpots) {
/*      */         
/*  375 */         int frame = trackSpot.getFeature("FRAME").intValue();
/*  376 */         int column = Math.max(targetColumn, getNextFreeColumn(frame));
/*  377 */         insertSpotInGraph(trackSpot, column);
/*  378 */         this.rowLengths.put(Integer.valueOf(frame), Integer.valueOf(column));
/*      */       } 
/*  380 */       Set<DefaultWeightedEdge> trackEdges = this.model.getTrackModel().trackEdges(Integer.valueOf(trackIndex));
/*  381 */       for (DefaultWeightedEdge trackEdge : trackEdges)
/*      */       {
/*  383 */         this.graph.addJGraphTEdge(trackEdge);
/*      */       }
/*      */     }
/*      */     finally {
/*      */       
/*  388 */       this.model.endUpdate();
/*  389 */       this.graph.getModel().endUpdate();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void addEdgeManually(mxCell cell) {
/*  404 */     if (cell.isEdge()) {
/*      */       
/*  406 */       mxIGraphModel graphModel = this.graph.getModel();
/*  407 */       cell.setValue("New");
/*  408 */       this.model.beginUpdate();
/*  409 */       graphModel.beginUpdate();
/*      */ 
/*      */       
/*      */       try {
/*  413 */         Spot source = this.graph.getSpotFor(cell.getSource());
/*  414 */         Spot target = this.graph.getSpotFor(cell.getTarget());
/*      */         
/*  416 */         if (Spot.frameComparator.compare(source, target) == 0)
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  422 */           this.graph.removeCells(new Object[] { cell });
/*      */ 
/*      */ 
/*      */         
/*      */         }
/*      */         else
/*      */         {
/*      */ 
/*      */ 
/*      */           
/*  432 */           if (Spot.frameComparator.compare(source, target) > 0) {
/*      */             
/*  434 */             Spot tmp = source;
/*  435 */             source = target;
/*  436 */             target = tmp;
/*      */           } 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  442 */           DefaultWeightedEdge edge = this.model.getTrackModel().getEdge(source, target);
/*  443 */           if (null == edge) {
/*      */             
/*  445 */             edge = this.model.addEdge(source, target, -1.0D);
/*      */ 
/*      */ 
/*      */           
/*      */           }
/*      */           else {
/*      */ 
/*      */ 
/*      */             
/*  454 */             this.graph.removeCells(new Object[] { cell });
/*      */             
/*  456 */             cell = this.graph.addJGraphTEdge(edge);
/*  457 */             cell.setValue(String.format("%.1f", new Object[] { Double.valueOf(this.model.getTrackModel().getEdgeWeight(edge)) }));
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  462 */             int ID = this.model.getTrackModel().trackIDOf(edge).intValue();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  469 */             if (!this.model.getTrackModel().isVisible(Integer.valueOf(ID)))
/*  470 */               importTrack(ID); 
/*      */           } 
/*  472 */           this.graph.mapEdgeToCell(edge, cell);
/*      */         }
/*      */       
/*      */       }
/*      */       finally {
/*      */         
/*  478 */         graphModel.endUpdate();
/*  479 */         this.model.endUpdate();
/*  480 */         this.selectionModel.clearEdgeSelection();
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void selectionChanged(SelectionChangeEvent event) {
/*  492 */     if (!this.doFireSelectionChangeEvent) {
/*      */       return;
/*      */     }
/*  495 */     this.doFireSelectionChangeEvent = false;
/*      */     
/*  497 */     ArrayList<Object> newSelection = new ArrayList(this.selectionModel.getSpotSelection().size() + this.selectionModel.getEdgeSelection().size());
/*  498 */     Iterator<DefaultWeightedEdge> edgeIt = this.selectionModel.getEdgeSelection().iterator();
/*  499 */     while (edgeIt.hasNext()) {
/*      */       
/*  501 */       mxCell mxCell = this.graph.getCellFor(edgeIt.next());
/*  502 */       if (null != mxCell) {
/*  503 */         newSelection.add(mxCell);
/*      */       }
/*      */     } 
/*  506 */     Iterator<Spot> spotIt = this.selectionModel.getSpotSelection().iterator();
/*  507 */     while (spotIt.hasNext()) {
/*      */       
/*  509 */       mxCell mxCell = this.graph.getCellFor(spotIt.next());
/*  510 */       if (null != mxCell)
/*  511 */         newSelection.add(mxCell); 
/*      */     } 
/*  513 */     mxGraphSelectionModel mGSmodel = this.graph.getSelectionModel();
/*  514 */     mGSmodel.setCells(newSelection.toArray());
/*      */ 
/*      */     
/*  517 */     Map<Spot, Boolean> spotsAdded = event.getSpots();
/*  518 */     if (spotsAdded != null && spotsAdded.size() == 1) {
/*      */       
/*  520 */       boolean added = ((Boolean)spotsAdded.values().iterator().next()).booleanValue();
/*  521 */       if (added) {
/*      */         
/*  523 */         Spot spot = spotsAdded.keySet().iterator().next();
/*  524 */         centerViewOn(spot);
/*      */       } 
/*      */     } 
/*  527 */     this.doFireSelectionChangeEvent = true;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void centerViewOn(Spot spot) {
/*  533 */     this.gui.centerViewOn((mxICell)this.graph.getCellFor(spot));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void modelChanged(ModelChangeEvent event) {
/*  548 */     if (event.getEventID() != 8) {
/*      */       return;
/*      */     }
/*  551 */     this.graph.getModel().beginUpdate();
/*      */     
/*      */     try {
/*  554 */       ArrayList<mxICell> cellsToRemove = new ArrayList<>();
/*      */       
/*  556 */       int targetColumn = getUnlaidSpotColumn();
/*      */ 
/*      */       
/*  559 */       if (!event.getSpots().isEmpty())
/*      */       {
/*      */         
/*  562 */         Collection<mxCell> spotsWithStyleToUpdate = new HashSet<>();
/*      */         
/*  564 */         for (Spot spot : event.getSpots()) {
/*      */ 
/*      */           
/*  567 */           if (event.getSpotFlag(spot).intValue() == 0) {
/*      */ 
/*      */             
/*  570 */             int frame = spot.getFeature("FRAME").intValue();
/*      */             
/*  572 */             int column = Math.max(targetColumn, getNextFreeColumn(frame));
/*  573 */             mxICell newCell = insertSpotInGraph(spot, column);
/*  574 */             this.rowLengths.put(Integer.valueOf(frame), Integer.valueOf(column));
/*  575 */             spotsWithStyleToUpdate.add((mxCell)newCell);
/*      */             continue;
/*      */           } 
/*  578 */           if (event.getSpotFlag(spot).intValue() == 2) {
/*      */ 
/*      */ 
/*      */             
/*  582 */             mxICell cell = updateCellOf(spot);
/*  583 */             spotsWithStyleToUpdate.add((mxCell)cell);
/*      */             continue;
/*      */           } 
/*  586 */           if (event.getSpotFlag(spot).intValue() == 1) {
/*      */ 
/*      */             
/*  589 */             mxCell mxCell = this.graph.getCellFor(spot);
/*  590 */             cellsToRemove.add(mxCell);
/*      */           } 
/*      */         } 
/*      */         
/*  594 */         this.graph.removeCells(cellsToRemove.toArray(), true);
/*  595 */         this.stylist.updateVertexStyle(spotsWithStyleToUpdate);
/*      */       }
/*      */     
/*      */     }
/*      */     finally {
/*      */       
/*  601 */       this.graph.getModel().endUpdate();
/*      */     } 
/*      */ 
/*      */     
/*  605 */     if (!event.getEdges().isEmpty()) {
/*      */ 
/*      */       
/*  608 */       this.graph.getModel().beginUpdate();
/*      */ 
/*      */       
/*      */       try {
/*  612 */         if (event.getEdges().size() > 0)
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  619 */           Collection<mxCell> edgesToUpdate = new ArrayList<>();
/*  620 */           Collection<mxCell> spotsWithStyleToUpdate = new ArrayList<>();
/*      */           
/*  622 */           for (DefaultWeightedEdge edge : event.getEdges()) {
/*      */ 
/*      */             
/*  625 */             if (event.getEdgeFlag(edge).intValue() == 4) {
/*      */ 
/*      */               
/*  628 */               mxCell edgeCell = this.graph.getCellFor(edge);
/*  629 */               if (null == edgeCell) {
/*      */ 
/*      */ 
/*      */                 
/*  633 */                 Spot source = this.model.getTrackModel().getEdgeSource(edge);
/*  634 */                 mxCell sourceCell = this.graph.getCellFor(source);
/*  635 */                 Spot target = this.model.getTrackModel().getEdgeTarget(edge);
/*  636 */                 mxCell targetCell = this.graph.getCellFor(target);
/*      */                 
/*  638 */                 if (sourceCell == null || targetCell == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */                   
/*  645 */                   Integer trackID = this.model.getTrackModel().trackIDOf(edge);
/*  646 */                   Set<Spot> trackSpots = this.model.getTrackModel().trackSpots(trackID);
/*  647 */                   for (Spot trackSpot : trackSpots) {
/*      */                     
/*  649 */                     mxCell spotCell = this.graph.getCellFor(trackSpot);
/*  650 */                     if (spotCell == null) {
/*      */                       
/*  652 */                       int frame = trackSpot.getFeature("FRAME").intValue();
/*      */                       
/*  654 */                       int targetColumn = getUnlaidSpotColumn();
/*  655 */                       int column = Math.max(targetColumn, getNextFreeColumn(frame));
/*      */                       
/*  657 */                       mxCell spotCellAdded = (mxCell)insertSpotInGraph(trackSpot, column);
/*  658 */                       this.rowLengths.put(Integer.valueOf(frame), Integer.valueOf(column));
/*  659 */                       spotsWithStyleToUpdate.add(spotCellAdded);
/*      */                     } 
/*      */                   } 
/*      */                   
/*  663 */                   Set<DefaultWeightedEdge> trackEdges = this.model.getTrackModel().trackEdges(trackID);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */                   
/*  673 */                   for (DefaultWeightedEdge trackEdge : trackEdges) {
/*      */                     
/*  675 */                     mxCell edgeCellToAdd = this.graph.getCellFor(trackEdge);
/*  676 */                     if (null == edgeCellToAdd) {
/*      */                       
/*  678 */                       edgeCellToAdd = this.graph.addJGraphTEdge(trackEdge);
/*  679 */                       this.graph.getModel().add(this.graph.getDefaultParent(), edgeCellToAdd, 0);
/*  680 */                       edgesToUpdate.add(edgeCellToAdd);
/*      */                     } 
/*      */                   } 
/*      */                 } 
/*      */ 
/*      */                 
/*  686 */                 edgeCell = this.graph.addJGraphTEdge(edge);
/*      */               } 
/*      */               
/*  689 */               this.graph.getModel().add(this.graph.getDefaultParent(), edgeCell, 0);
/*  690 */               edgesToUpdate.add(edgeCell); continue;
/*      */             } 
/*  692 */             if (event.getEdgeFlag(edge).intValue() == 6) {
/*      */ 
/*      */               
/*  695 */               edgesToUpdate.add(this.graph.getCellFor(edge));
/*      */               continue;
/*      */             } 
/*  698 */             if (event.getEdgeFlag(edge).intValue() == 5) {
/*      */ 
/*      */               
/*  701 */               mxCell cell = this.graph.getCellFor(edge);
/*  702 */               this.graph.removeCells(new Object[] { cell });
/*      */             } 
/*      */           } 
/*      */           
/*  706 */           this.stylist.updateEdgeStyle(edgesToUpdate);
/*  707 */           this.stylist.updateVertexStyle(spotsWithStyleToUpdate);
/*  708 */           SwingUtilities.invokeLater(new Runnable()
/*      */               {
/*      */                 
/*      */                 public void run()
/*      */                 {
/*  713 */                   TrackScheme.this.gui.graphComponent.refresh();
/*  714 */                   TrackScheme.this.gui.graphComponent.repaint();
/*      */                 }
/*      */               });
/*      */         }
/*      */       
/*      */       }
/*      */       finally {
/*      */         
/*  722 */         this.graph.getModel().endUpdate();
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void render() {
/*  730 */     final long start = System.currentTimeMillis();
/*      */     
/*  732 */     this.graph = createGraph();
/*  733 */     this.gui.logger.setProgress(0.5D);
/*      */     
/*  735 */     SwingUtilities.invokeLater(new Runnable()
/*      */         {
/*      */ 
/*      */           
/*      */           public void run()
/*      */           {
/*  741 */             TrackScheme.this.gui.logger.setStatus("Generating GUI components.");
/*  742 */             TrackScheme.this.gui.init(TrackScheme.this.graph);
/*      */ 
/*      */             
/*  745 */             TrackScheme.this.gui.logger.setStatus("Creating style manager.");
/*  746 */             TrackScheme.this.stylist = new TrackSchemeStylist(TrackScheme.this.model, TrackScheme.this.graph, TrackScheme.this.displaySettings);
/*  747 */             TrackScheme.this.gui.logger.setStatus("Creating layout manager.");
/*  748 */             TrackScheme.this.graphLayout = new TrackSchemeGraphLayout(TrackScheme.this.graph, TrackScheme.this.model, TrackScheme.this.gui.graphComponent);
/*      */ 
/*      */             
/*  751 */             TrackScheme.this.gui.logger.setProgress(0.75D);
/*  752 */             TrackScheme.this.doTrackStyle();
/*      */             
/*  754 */             TrackScheme.this.gui.logger.setStatus("Executing layout.");
/*  755 */             TrackScheme.this.doTrackLayout();
/*      */             
/*  757 */             TrackScheme.this.gui.logger.setProgress(0.9D);
/*      */             
/*  759 */             TrackScheme.this.gui.logger.setStatus("Refreshing display.");
/*  760 */             TrackScheme.this.gui.graphComponent.refresh();
/*  761 */             mxCellState mxCellState = TrackScheme.this.graph.getView().validateCellState(TrackScheme.this.graph.getDefaultParent(), false);
/*      */ 
/*      */             
/*  764 */             if (null == mxCellState) {
/*      */               return;
/*      */             }
/*  767 */             Dimension dim = new Dimension();
/*  768 */             dim.setSize((mxCellState.getRectangle()).width + (mxCellState.getRectangle()).x, (mxCellState.getRectangle()).height + (mxCellState.getRectangle()).y);
/*  769 */             TrackScheme.this.gui.graphComponent.getGraphControl().setPreferredSize(dim);
/*  770 */             TrackScheme.this.gui.logger.setStatus("");
/*      */             
/*  772 */             TrackScheme.this.gui.graphComponent.zoomOut();
/*  773 */             TrackScheme.this.gui.graphComponent.zoomOut();
/*      */             
/*  775 */             TrackScheme.this.gui.logger.setProgress(0.0D);
/*  776 */             long end = System.currentTimeMillis();
/*  777 */             TrackScheme.this.gui.logger.log(String.format("TrackScheme rendering done in %.1f s.", new Object[] { Double.valueOf((end - this.val$start) / 1000.0D) }));
/*  778 */             TrackScheme.this.gui.revalidate();
/*      */           }
/*      */         });
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void refresh() {}
/*      */ 
/*      */ 
/*      */   
/*      */   public void clear() {
/*  790 */     System.out.println("[TrackScheme] clear() called");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Model getModel() {
/*  796 */     return this.model;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void userChangedSelection(Collection<Object> added, Collection<Object> removed) {
/*  815 */     if (!this.doFireSelectionChangeEvent)
/*      */       return; 
/*  817 */     Collection<Spot> spotsToAdd = new ArrayList<>();
/*  818 */     Collection<Spot> spotsToRemove = new ArrayList<>();
/*  819 */     Collection<DefaultWeightedEdge> edgesToAdd = new ArrayList<>();
/*  820 */     Collection<DefaultWeightedEdge> edgesToRemove = new ArrayList<>();
/*      */     
/*  822 */     if (null != added)
/*      */     {
/*  824 */       for (Object obj : added) {
/*      */         
/*  826 */         mxCell cell = (mxCell)obj;
/*      */         
/*  828 */         if (cell.getChildCount() > 0) {
/*      */ 
/*      */           
/*  831 */           for (int i = 0; i < cell.getChildCount(); i++) {
/*      */             
/*  833 */             mxICell child = cell.getChildAt(i);
/*  834 */             if (child.isVertex()) {
/*      */               
/*  836 */               Spot spot = this.graph.getSpotFor(child);
/*  837 */               spotsToRemove.add(spot);
/*      */             }
/*      */             else {
/*      */               
/*  841 */               DefaultWeightedEdge defaultWeightedEdge = this.graph.getEdgeFor(child);
/*  842 */               edgesToRemove.add(defaultWeightedEdge);
/*      */             } 
/*      */           } 
/*      */ 
/*      */           
/*      */           continue;
/*      */         } 
/*      */         
/*  850 */         if (cell.isVertex()) {
/*      */           
/*  852 */           Spot spot = this.graph.getSpotFor((mxICell)cell);
/*  853 */           spotsToRemove.add(spot);
/*      */           
/*      */           continue;
/*      */         } 
/*  857 */         DefaultWeightedEdge edge = this.graph.getEdgeFor((mxICell)cell);
/*  858 */         edgesToRemove.add(edge);
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  864 */     if (null != removed)
/*      */     {
/*  866 */       for (Object obj : removed) {
/*      */         
/*  868 */         mxCell cell = (mxCell)obj;
/*      */         
/*  870 */         if (cell.getChildCount() > 0) {
/*      */ 
/*      */           
/*  873 */           for (int i = 0; i < cell.getChildCount(); i++) {
/*      */             
/*  875 */             mxICell child = cell.getChildAt(i);
/*  876 */             if (child.isVertex()) {
/*      */               
/*  878 */               Spot spot = this.graph.getSpotFor(child);
/*  879 */               spotsToAdd.add(spot);
/*      */             }
/*      */             else {
/*      */               
/*  883 */               DefaultWeightedEdge defaultWeightedEdge = this.graph.getEdgeFor(child);
/*  884 */               edgesToAdd.add(defaultWeightedEdge);
/*      */             } 
/*      */           } 
/*      */ 
/*      */           
/*      */           continue;
/*      */         } 
/*      */         
/*  892 */         if (cell.isVertex()) {
/*      */           
/*  894 */           Spot spot = this.graph.getSpotFor((mxICell)cell);
/*  895 */           spotsToAdd.add(spot);
/*      */           
/*      */           continue;
/*      */         } 
/*  899 */         DefaultWeightedEdge edge = this.graph.getEdgeFor((mxICell)cell);
/*  900 */         edgesToAdd.add(edge);
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  906 */     this.doFireSelectionChangeEvent = false;
/*      */     
/*  908 */     if (!edgesToAdd.isEmpty()) {
/*  909 */       this.selectionModel.addEdgeToSelection(edgesToAdd);
/*      */     }
/*  911 */     if (!spotsToAdd.isEmpty()) {
/*  912 */       this.selectionModel.addSpotToSelection(spotsToAdd);
/*      */     }
/*  914 */     if (!edgesToRemove.isEmpty()) {
/*  915 */       this.selectionModel.removeEdgeFromSelection(edgesToRemove);
/*      */     }
/*  917 */     if (!spotsToRemove.isEmpty()) {
/*  918 */       this.selectionModel.removeSpotFromSelection(spotsToRemove);
/*      */     }
/*  920 */     this.doFireSelectionChangeEvent = true;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private class CellRemovalListener
/*      */     implements mxEventSource.mxIEventListener
/*      */   {
/*      */     private CellRemovalListener() {}
/*      */ 
/*      */ 
/*      */     
/*      */     public void invoke(Object sender, mxEventObject evt) {
/*  933 */       if (!TrackScheme.this.doFireModelChangeEvent) {
/*      */         return;
/*      */       }
/*      */       
/*  937 */       Object[] objects = (Object[])evt.getProperty("cells");
/*  938 */       HashSet<Spot> spotsToRemove = new HashSet<>();
/*  939 */       ArrayList<DefaultWeightedEdge> edgesToRemove = new ArrayList<>();
/*  940 */       for (Object obj : objects) {
/*      */         
/*  942 */         mxCell cell = (mxCell)obj;
/*  943 */         if (null != cell)
/*      */         {
/*  945 */           if (cell.isVertex()) {
/*      */ 
/*      */             
/*  948 */             Spot spot = TrackScheme.this.graph.getSpotFor((mxICell)cell);
/*  949 */             spotsToRemove.add(spot);
/*      */             
/*  951 */             TrackScheme.this.graph.removeMapping(spot);
/*      */           }
/*  953 */           else if (cell.isEdge()) {
/*      */ 
/*      */             
/*  956 */             DefaultWeightedEdge edge = TrackScheme.this.graph.getEdgeFor((mxICell)cell);
/*  957 */             if (null != edge) {
/*      */ 
/*      */               
/*  960 */               edgesToRemove.add(edge);
/*      */               
/*  962 */               TrackScheme.this.graph.removeMapping(edge);
/*      */             } 
/*      */           } 
/*      */         }
/*      */       } 
/*  967 */       evt.consume();
/*      */ 
/*      */       
/*  970 */       TrackScheme.this.doFireModelChangeEvent = false;
/*  971 */       TrackScheme.this.model.beginUpdate();
/*      */       
/*      */       try {
/*  974 */         TrackScheme.this.selectionModel.clearSelection();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  980 */         for (DefaultWeightedEdge edge : edgesToRemove) {
/*  981 */           TrackScheme.this.model.removeEdge(edge);
/*      */         }
/*  983 */         for (Spot spot : spotsToRemove) {
/*  984 */           TrackScheme.this.model.removeSpot(spot);
/*      */         }
/*      */       }
/*      */       finally {
/*      */         
/*  989 */         TrackScheme.this.model.endUpdate();
/*      */       } 
/*  991 */       TrackScheme.this.doFireModelChangeEvent = true;
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private class SelectionChangeListener
/*      */     implements mxEventSource.mxIEventListener
/*      */   {
/*      */     private SelectionChangeListener() {}
/*      */     
/*      */     public void invoke(Object sender, mxEventObject evt) {
/* 1002 */       if (!TrackScheme.this.doFireSelectionChangeEvent || sender != TrackScheme.this.graph.getSelectionModel()) {
/*      */         return;
/*      */       }
/* 1005 */       Collection<Object> added = (Collection<Object>)evt.getProperty("added");
/* 1006 */       Collection<Object> removed = (Collection<Object>)evt.getProperty("removed");
/* 1007 */       TrackScheme.this.userChangedSelection(added, removed);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean toggleLinking() {
/* 1022 */     boolean enabled = this.gui.graphComponent.getConnectionHandler().isEnabled();
/* 1023 */     this.gui.graphComponent.getConnectionHandler().setEnabled(!enabled);
/* 1024 */     return !enabled;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean toggleThumbnail() {
/* 1034 */     if (!this.doThumbnailCapture) {
/* 1035 */       createThumbnails();
/*      */     }
/* 1037 */     this.doThumbnailCapture = !this.doThumbnailCapture;
/* 1038 */     return this.doThumbnailCapture;
/*      */   }
/*      */ 
/*      */   
/*      */   public void zoomIn() {
/* 1043 */     this.gui.graphComponent.zoomIn();
/*      */   }
/*      */ 
/*      */   
/*      */   public void zoomOut() {
/* 1048 */     this.gui.graphComponent.zoomOut();
/*      */   }
/*      */ 
/*      */   
/*      */   public void resetZoom() {
/* 1053 */     this.gui.graphComponent.zoomActual();
/*      */   }
/*      */ 
/*      */   
/*      */   public void doTrackStyle() {
/* 1058 */     if (null == this.stylist) {
/*      */       return;
/*      */     }
/* 1061 */     this.gui.logger.setStatus("Setting style.");
/* 1062 */     this.graph.getModel().beginUpdate();
/*      */     
/*      */     try {
/* 1065 */       this.stylist.updateEdgeStyle(this.graph.getEdgeCells());
/* 1066 */       this.stylist.updateVertexStyle(this.graph.getVertexCells());
/*      */     }
/*      */     finally {
/*      */       
/* 1070 */       this.graph.getModel().endUpdate();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void createThumbnails() {
/* 1081 */     Set<Integer> frames = this.model.getSpots().keySet();
/* 1082 */     HashMap<Integer, HashSet<Spot>> spotPerFrame = new HashMap<>(frames.size());
/* 1083 */     for (Integer frame : frames) {
/* 1084 */       spotPerFrame.put(frame, new HashSet<>(this.model.getSpots().getNSpots(frame.intValue(), true)));
/*      */     }
/* 1086 */     for (Integer trackID : this.model.getTrackModel().trackIDs(true)) {
/*      */       
/* 1088 */       for (Spot spot : this.model.getTrackModel().trackSpots(trackID)) {
/*      */         
/* 1090 */         int frame = spot.getFeature("FRAME").intValue();
/* 1091 */         ((HashSet<Spot>)spotPerFrame.get(Integer.valueOf(frame))).add(spot);
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 1096 */     if (null != this.spotImageUpdater) {
/*      */       
/* 1098 */       this.gui.logger.setStatus("Collecting spot thumbnails.");
/* 1099 */       double radiusFactor = this.displaySettings.getSpotDisplayRadius();
/* 1100 */       int index = 0;
/*      */       
/*      */       try {
/* 1103 */         this.graph.getModel().beginUpdate();
/*      */ 
/*      */         
/* 1106 */         for (Integer frame : frames)
/*      */         {
/* 1108 */           for (Spot spot : spotPerFrame.get(frame)) {
/*      */             
/* 1110 */             mxCell mxCell = this.graph.getCellFor(spot);
/* 1111 */             String imageStr = this.spotImageUpdater.getImageString(spot, radiusFactor);
/* 1112 */             String style = mxCell.getStyle();
/* 1113 */             style = mxStyleUtils.setStyle(style, mxConstants.STYLE_IMAGE, "data:image/base64," + imageStr);
/* 1114 */             this.graph.getModel().setStyle(mxCell, style);
/*      */           } 
/*      */           
/* 1117 */           this.gui.logger.setProgress(index++ / frames.size());
/*      */         }
/*      */       
/*      */       } finally {
/*      */         
/* 1122 */         this.graph.getModel().endUpdate();
/* 1123 */         this.gui.logger.setProgress(0.0D);
/* 1124 */         this.gui.logger.setStatus("");
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void doTrackLayout() {
/* 1132 */     this.graphLayout.execute(null);
/* 1133 */     this.rowLengths = this.graphLayout.getRowLengths();
/* 1134 */     int maxLength = 2;
/* 1135 */     for (Iterator<Integer> iterator = this.rowLengths.values().iterator(); iterator.hasNext(); ) { int rowLength = ((Integer)iterator.next()).intValue();
/*      */       
/* 1137 */       if (maxLength < rowLength)
/* 1138 */         maxLength = rowLength;  }
/*      */     
/* 1140 */     this.unlaidSpotColumn = maxLength;
/* 1141 */     this.gui.graphComponent.refresh();
/* 1142 */     this.gui.graphComponent.repaint();
/*      */   }
/*      */ 
/*      */   
/*      */   public void captureUndecorated() {
/* 1147 */     BufferedImage image = mxCellRenderer.createBufferedImage(this.graph, null, 1.0D, Color.WHITE, true, null, (mxGraphics2DCanvas)this.gui.graphComponent.getCanvas());
/* 1148 */     ImagePlus imp = new ImagePlus("TrackScheme capture", image);
/* 1149 */     imp.show();
/*      */   }
/*      */ 
/*      */   
/*      */   public void captureDecorated() {
/* 1154 */     JViewport view = this.gui.graphComponent.getViewport();
/* 1155 */     Point currentPos = view.getViewPosition();
/* 1156 */     view.setViewPosition(new Point(0, 0));
/*      */     
/* 1158 */     Dimension size = view.getViewSize();
/* 1159 */     BufferedImage image = (BufferedImage)view.createImage(size.width, size.height);
/* 1160 */     Graphics2D captureG = image.createGraphics();
/* 1161 */     view.paintComponents(captureG);
/* 1162 */     view.setViewPosition(currentPos);
/* 1163 */     ImagePlus imp = new ImagePlus("TrackScheme capture", image);
/* 1164 */     imp.show();
/*      */   }
/*      */ 
/*      */   
/*      */   public void toggleDisplayDecoration() {
/* 1169 */     this.gui.graphComponent.loopPaintDecorationLevel();
/* 1170 */     this.gui.graphComponent.repaint();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void linkSpots() {
/* 1182 */     TreeMap<Integer, Spot> spotsInTime = new TreeMap<>();
/* 1183 */     for (Spot spot : this.selectionModel.getSpotSelection()) {
/* 1184 */       spotsInTime.put(Integer.valueOf(spot.getFeature("FRAME").intValue()), spot);
/*      */     }
/*      */     
/* 1187 */     int targetColumn = getUnlaidSpotColumn();
/*      */ 
/*      */     
/* 1190 */     this.model.beginUpdate();
/* 1191 */     this.graph.getModel().beginUpdate();
/*      */     
/*      */     try {
/* 1194 */       Iterator<Integer> it = spotsInTime.keySet().iterator();
/* 1195 */       Integer previousTime = it.next();
/* 1196 */       Spot previousSpot = spotsInTime.get(previousTime);
/*      */       
/* 1198 */       Integer ID = this.model.getTrackModel().trackIDOf(previousSpot);
/* 1199 */       if (ID != null && !this.model.getTrackModel().isVisible(ID)) {
/* 1200 */         importTrack(ID.intValue());
/*      */       }
/* 1202 */       while (it.hasNext())
/*      */       {
/* 1204 */         Integer currentTime = it.next();
/* 1205 */         Spot currentSpot = spotsInTime.get(currentTime);
/*      */         
/* 1207 */         ID = this.model.getTrackModel().trackIDOf(currentSpot);
/* 1208 */         if (ID != null && !this.model.getTrackModel().isVisible(ID)) {
/* 1209 */           importTrack(ID.intValue());
/*      */         }
/*      */         
/* 1212 */         mxCell mxCell1 = this.graph.getCellFor(currentSpot);
/* 1213 */         if (null == mxCell1) {
/* 1214 */           mxICell mxICell = insertSpotInGraph(currentSpot, targetColumn);
/*      */         }
/* 1216 */         mxCell mxCell2 = this.graph.getCellFor(previousSpot);
/* 1217 */         if (null == mxCell2) {
/*      */           
/* 1219 */           int frame = previousSpot.getFeature("FRAME").intValue();
/* 1220 */           int column = Math.max(targetColumn, getNextFreeColumn(frame));
/* 1221 */           this.rowLengths.put(Integer.valueOf(frame), Integer.valueOf(column));
/* 1222 */           mxICell mxICell = insertSpotInGraph(previousSpot, column);
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1230 */         DefaultWeightedEdge edge = this.model.getTrackModel().getEdge(previousSpot, currentSpot);
/* 1231 */         if (null == edge) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1237 */           edge = this.model.addEdge(previousSpot, currentSpot, -1.0D);
/* 1238 */           mxCell cell = this.graph.addJGraphTEdge(edge);
/* 1239 */           cell.setValue("New");
/*      */         
/*      */         }
/*      */         else {
/*      */           
/* 1244 */           mxCell cell = this.graph.addJGraphTEdge(edge);
/* 1245 */           cell.setValue(String.format("%.1f", new Object[] { Double.valueOf(this.model.getTrackModel().getEdgeWeight(edge)) }));
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1250 */           ID = this.model.getTrackModel().trackIDOf(edge);
/* 1251 */           if (ID != null && !this.model.getTrackModel().isVisible(ID))
/* 1252 */             importTrack(ID.intValue()); 
/*      */         } 
/* 1254 */         previousSpot = currentSpot;
/*      */       }
/*      */     
/*      */     } finally {
/*      */       
/* 1259 */       this.graph.getModel().endUpdate();
/* 1260 */       this.model.endUpdate();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeSelectedCells() {
/* 1269 */     this.graph.getModel().beginUpdate();
/*      */     
/*      */     try {
/* 1272 */       this.graph.removeCells(this.graph.getSelectionCells());
/*      */     
/*      */     }
/*      */     finally {
/*      */       
/* 1277 */       this.graph.getModel().endUpdate();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void selectTrack(Collection<mxCell> vertices, Collection<mxCell> edges, int direction) {
/* 1284 */     Set<Spot> inspectionSpots = new HashSet<>(vertices.size());
/* 1285 */     for (mxCell cell : vertices) {
/*      */       
/* 1287 */       Spot spot = this.graph.getSpotFor((mxICell)cell);
/* 1288 */       if (null == spot) {
/*      */         continue;
/*      */       }
/* 1291 */       inspectionSpots.add(spot);
/*      */     } 
/* 1293 */     Set<DefaultWeightedEdge> inspectionEdges = new HashSet<>(edges.size());
/* 1294 */     for (mxCell cell : edges) {
/*      */       
/* 1296 */       DefaultWeightedEdge dwe = this.graph.getEdgeFor((mxICell)cell);
/* 1297 */       if (null == dwe) {
/*      */         continue;
/*      */       }
/* 1300 */       inspectionEdges.add(dwe);
/*      */     } 
/*      */     
/* 1303 */     this.selectionModel.selectTrack(inspectionSpots, inspectionEdges, direction);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public String getKey() {
/* 1309 */     return "TRACKSCHEME";
/*      */   }
/*      */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/visualization/trackscheme/TrackScheme.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */