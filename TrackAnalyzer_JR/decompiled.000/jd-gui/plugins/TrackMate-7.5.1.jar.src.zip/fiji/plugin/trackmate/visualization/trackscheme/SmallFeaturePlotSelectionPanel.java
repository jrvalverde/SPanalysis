/*     */ package fiji.plugin.trackmate.visualization.trackscheme;
/*     */ 
/*     */ import fiji.plugin.trackmate.gui.Fonts;
/*     */ import fiji.plugin.trackmate.gui.Icons;
/*     */ import fiji.plugin.trackmate.gui.components.FeaturePlotSelectionPanel;
/*     */ import fiji.plugin.trackmate.util.TMUtils;
/*     */ import java.awt.Component;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.LayoutManager;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Stack;
/*     */ import javax.swing.Box;
/*     */ import javax.swing.BoxLayout;
/*     */ import javax.swing.ComboBoxModel;
/*     */ import javax.swing.DefaultComboBoxModel;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JComboBox;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JScrollPane;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SmallFeaturePlotSelectionPanel
/*     */   extends JPanel
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  68 */   private static final Dimension BUTTON_SIZE = new Dimension(24, 24);
/*     */   
/*  70 */   private static final Dimension COMBO_BOX_SIZE = new Dimension(150, 22);
/*     */   
/*     */   private static final int MAX_FEATURE_ALLOWED = 10;
/*     */   
/*     */   private final JPanel panelYFeatures;
/*     */   
/*  76 */   private final Stack<JComboBox<String>> comboBoxes = new Stack<>();
/*     */   
/*  78 */   private final Stack<Component> struts = new Stack<>();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final List<String> features;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final Map<String, String> featureNames;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SmallFeaturePlotSelectionPanel(String xKey, List<String> features, Map<String, String> featureNames, FeaturePlotSelectionPanel.PlotAction plotAction) {
/*  94 */     this.features = features;
/*  95 */     this.featureNames = featureNames;
/*     */     
/*  97 */     setLayout((LayoutManager)null);
/*  98 */     setPreferredSize(new Dimension(170, 284));
/*     */     
/* 100 */     JLabel jLabelXFeature = new JLabel();
/* 101 */     add(jLabelXFeature);
/* 102 */     jLabelXFeature.setText("Feature for X axis:");
/* 103 */     jLabelXFeature.setFont(Fonts.FONT);
/* 104 */     jLabelXFeature.setBounds(8, 66, 148, 26);
/*     */ 
/*     */     
/* 107 */     ComboBoxModel<String> jComboBoxXFeatureModel = new DefaultComboBoxModel<>((String[])TMUtils.getArrayFromMaping(features, featureNames).toArray((Object[])new String[0]));
/* 108 */     JComboBox<String> jComboBoxXFeature = new JComboBox<>();
/* 109 */     add(jComboBoxXFeature);
/* 110 */     jComboBoxXFeature.setModel(jComboBoxXFeatureModel);
/* 111 */     jComboBoxXFeature.setFont(Fonts.SMALL_FONT);
/* 112 */     jComboBoxXFeature.setBounds(8, 92, COMBO_BOX_SIZE.width, COMBO_BOX_SIZE.height);
/* 113 */     jComboBoxXFeature.setSelectedItem(xKey);
/*     */     
/* 115 */     JLabel jLabelYFeatures = new JLabel();
/* 116 */     add(jLabelYFeatures);
/* 117 */     jLabelYFeatures.setText("Features for Y axis:");
/* 118 */     jLabelYFeatures.setFont(Fonts.FONT);
/* 119 */     jLabelYFeatures.setBounds(8, 114, 148, 22);
/*     */     
/* 121 */     JScrollPane jScrollPaneYFeatures = new JScrollPane();
/* 122 */     add(jScrollPaneYFeatures);
/* 123 */     jScrollPaneYFeatures.setPreferredSize(new Dimension(169, 137));
/* 124 */     jScrollPaneYFeatures.setHorizontalScrollBarPolicy(31);
/* 125 */     jScrollPaneYFeatures.setBounds(0, 139, 168, 105);
/*     */     
/* 127 */     this.panelYFeatures = new JPanel();
/* 128 */     this.panelYFeatures.setLayout(new BoxLayout(this.panelYFeatures, 1));
/* 129 */     jScrollPaneYFeatures.setViewportView(this.panelYFeatures);
/*     */     
/* 131 */     JPanel jPanelButtons = new JPanel();
/* 132 */     BoxLayout jPanelButtonsLayout = new BoxLayout(jPanelButtons, 0);
/* 133 */     jPanelButtons.setLayout(jPanelButtonsLayout);
/* 134 */     add(jPanelButtons);
/* 135 */     jPanelButtons.setBounds(10, 244, 148, 29);
/*     */     
/* 137 */     JButton jButtonAdd = new JButton();
/* 138 */     jPanelButtons.add(jButtonAdd);
/* 139 */     jButtonAdd.setIcon(Icons.ADD_ICON);
/* 140 */     jButtonAdd.setMaximumSize(BUTTON_SIZE);
/* 141 */     jButtonAdd.addActionListener(e -> addFeature());
/*     */     
/* 143 */     JButton jButtonRemove = new JButton();
/* 144 */     jPanelButtons.add(jButtonRemove);
/* 145 */     jButtonRemove.setIcon(Icons.REMOVE_ICON);
/* 146 */     jButtonRemove.setMaximumSize(BUTTON_SIZE);
/* 147 */     jButtonRemove.addActionListener(e -> removeFeature());
/*     */     
/* 149 */     JButton plotButton = new JButton("Plot features", Icons.PLOT_ICON);
/* 150 */     plotButton.setFont(Fonts.FONT.deriveFont(1));
/* 151 */     plotButton.setHorizontalAlignment(4);
/* 152 */     plotButton.setBounds(24, 21, 119, 34);
/* 153 */     add(plotButton);
/*     */ 
/*     */     
/* 156 */     plotButton.addActionListener(e -> {
/*     */           String sKey = features.get(jComboBoxXFeature.getSelectedIndex());
/*     */           
/*     */           List<String> yKeys = new ArrayList<>(this.comboBoxes.size());
/*     */           for (JComboBox<String> box : this.comboBoxes) {
/*     */             yKeys.add(features.get(box.getSelectedIndex()));
/*     */           }
/*     */           plotAction.plot(sKey, yKeys);
/*     */         });
/* 165 */     addFeature();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void addFeature() {
/* 174 */     if (this.comboBoxes.size() > 10) {
/*     */       return;
/*     */     }
/*     */     
/* 178 */     ComboBoxModel<String> jComboBoxYFeatureModel = new DefaultComboBoxModel<>((String[])TMUtils.getArrayFromMaping(this.features, this.featureNames).toArray((Object[])new String[0]));
/* 179 */     JComboBox<String> jComboBoxYFeature = new JComboBox<>();
/* 180 */     jComboBoxYFeature.setModel(jComboBoxYFeatureModel);
/* 181 */     jComboBoxYFeature.setPreferredSize(COMBO_BOX_SIZE);
/* 182 */     jComboBoxYFeature.setMaximumSize(COMBO_BOX_SIZE);
/* 183 */     jComboBoxYFeature.setFont(Fonts.SMALL_FONT);
/*     */     
/* 185 */     if (!this.comboBoxes.isEmpty()) {
/*     */       
/* 187 */       int newIndex = ((JComboBox)this.comboBoxes.get(this.comboBoxes.size() - 1)).getSelectedIndex() + 1;
/* 188 */       if (newIndex >= this.features.size())
/* 189 */         newIndex = 0; 
/* 190 */       jComboBoxYFeature.setSelectedIndex(newIndex);
/*     */     } 
/*     */     
/* 193 */     Component strut = Box.createVerticalStrut(5);
/* 194 */     this.panelYFeatures.add(strut);
/* 195 */     this.panelYFeatures.add(jComboBoxYFeature);
/* 196 */     this.panelYFeatures.revalidate();
/* 197 */     this.comboBoxes.push(jComboBoxYFeature);
/* 198 */     this.struts.push(strut);
/*     */   }
/*     */ 
/*     */   
/*     */   private void removeFeature() {
/* 203 */     if (this.comboBoxes.isEmpty())
/*     */       return; 
/* 205 */     this.panelYFeatures.remove(this.comboBoxes.pop());
/* 206 */     this.panelYFeatures.remove(this.struts.pop());
/* 207 */     this.panelYFeatures.revalidate();
/* 208 */     this.panelYFeatures.repaint();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/visualization/trackscheme/SmallFeaturePlotSelectionPanel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */