/*     */ package fiji.plugin.trackmate.gui.components.detector;
/*     */ 
/*     */ import fiji.plugin.trackmate.gui.Fonts;
/*     */ import fiji.plugin.trackmate.gui.components.ConfigurationPanel;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.GridBagConstraints;
/*     */ import java.awt.GridBagLayout;
/*     */ import java.awt.Insets;
/*     */ import java.text.DecimalFormat;
/*     */ import java.text.NumberFormat;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Optional;
/*     */ import javax.swing.JFormattedTextField;
/*     */ import javax.swing.JLabel;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ManualDetectorConfigurationPanel
/*     */   extends ConfigurationPanel
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  55 */   private static final NumberFormat FORMAT = new DecimalFormat("#.##");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final JFormattedTextField ftfDiameter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ManualDetectorConfigurationPanel(String infoText, String detectorName) {
/*  73 */     setPreferredSize(new Dimension(300, 461));
/*  74 */     GridBagLayout gridBagLayout = new GridBagLayout();
/*  75 */     gridBagLayout.columnWeights = new double[] { 0.0D, 1.0D, 0.0D };
/*  76 */     gridBagLayout.rowWeights = new double[] { 0.0D, 0.0D, 1.0D, 0.0D, 1.0D };
/*  77 */     setLayout(gridBagLayout);
/*     */     
/*  79 */     JLabel jLabelPreTitle = new JLabel();
/*  80 */     GridBagConstraints gbcLabelPreTitle = new GridBagConstraints();
/*  81 */     gbcLabelPreTitle.anchor = 11;
/*  82 */     gbcLabelPreTitle.fill = 2;
/*  83 */     gbcLabelPreTitle.insets = new Insets(5, 5, 5, 5);
/*  84 */     gbcLabelPreTitle.gridwidth = 3;
/*  85 */     gbcLabelPreTitle.gridx = 0;
/*  86 */     gbcLabelPreTitle.gridy = 0;
/*  87 */     add(jLabelPreTitle, gbcLabelPreTitle);
/*  88 */     jLabelPreTitle.setText("Settings for detector:");
/*  89 */     jLabelPreTitle.setFont(Fonts.FONT);
/*     */     
/*  91 */     JLabel jLabelSegmenterName = new JLabel();
/*  92 */     GridBagConstraints gbcLabelSegmenterName = new GridBagConstraints();
/*  93 */     gbcLabelSegmenterName.anchor = 11;
/*  94 */     gbcLabelSegmenterName.fill = 2;
/*  95 */     gbcLabelSegmenterName.insets = new Insets(5, 5, 5, 5);
/*  96 */     gbcLabelSegmenterName.gridwidth = 3;
/*  97 */     gbcLabelSegmenterName.gridx = 0;
/*  98 */     gbcLabelSegmenterName.gridy = 1;
/*  99 */     add(jLabelSegmenterName, gbcLabelSegmenterName);
/* 100 */     jLabelSegmenterName.setFont(Fonts.BIG_FONT);
/* 101 */     jLabelSegmenterName.setText(detectorName);
/*     */     
/* 103 */     JLabel jLabelHelpText = new JLabel();
/* 104 */     GridBagConstraints gbcLabelHelpText = new GridBagConstraints();
/* 105 */     gbcLabelHelpText.fill = 1;
/* 106 */     gbcLabelHelpText.insets = new Insets(5, 5, 5, 5);
/* 107 */     gbcLabelHelpText.gridwidth = 3;
/* 108 */     gbcLabelHelpText.gridx = 0;
/* 109 */     gbcLabelHelpText.gridy = 2;
/* 110 */     add(jLabelHelpText, gbcLabelHelpText);
/* 111 */     jLabelHelpText.setFont(Fonts.FONT.deriveFont(2));
/* 112 */     jLabelHelpText.setText(infoText.replace("<br>", "").replace("<p>", "<p align=\"justify\">").replace("<html>", "<html><p align=\"justify\">"));
/*     */     
/* 114 */     JLabel jLabelEstimDiameter = new JLabel();
/* 115 */     GridBagConstraints gbc_jLabel2 = new GridBagConstraints();
/* 116 */     gbc_jLabel2.anchor = 13;
/* 117 */     gbc_jLabel2.insets = new Insets(5, 5, 5, 5);
/* 118 */     gbc_jLabel2.gridx = 0;
/* 119 */     gbc_jLabel2.gridy = 3;
/* 120 */     add(jLabelEstimDiameter, gbc_jLabel2);
/* 121 */     jLabelEstimDiameter.setText("Spot diameter to use:");
/* 122 */     jLabelEstimDiameter.setFont(Fonts.SMALL_FONT);
/*     */     
/* 124 */     this.ftfDiameter = new JFormattedTextField(FORMAT);
/* 125 */     this.ftfDiameter.setValue(Double.valueOf(10.0D));
/* 126 */     this.ftfDiameter.setHorizontalAlignment(0);
/* 127 */     GridBagConstraints gbcTextFieldBlobDiameter = new GridBagConstraints();
/* 128 */     gbcTextFieldBlobDiameter.anchor = 15;
/* 129 */     gbcTextFieldBlobDiameter.fill = 2;
/* 130 */     gbcTextFieldBlobDiameter.insets = new Insets(5, 5, 5, 5);
/* 131 */     gbcTextFieldBlobDiameter.gridx = 1;
/* 132 */     gbcTextFieldBlobDiameter.gridy = 3;
/* 133 */     add(this.ftfDiameter, gbcTextFieldBlobDiameter);
/* 134 */     this.ftfDiameter.setFont(Fonts.SMALL_FONT);
/*     */     
/* 136 */     JLabel jLabelBlobDiameterUnit = new JLabel();
/* 137 */     GridBagConstraints gbcLabelBlobDiameterUnit = new GridBagConstraints();
/* 138 */     gbcLabelBlobDiameterUnit.anchor = 17;
/* 139 */     gbcLabelBlobDiameterUnit.fill = 3;
/* 140 */     gbcLabelBlobDiameterUnit.insets = new Insets(5, 5, 5, 5);
/* 141 */     gbcLabelBlobDiameterUnit.gridx = 2;
/* 142 */     gbcLabelBlobDiameterUnit.gridy = 3;
/* 143 */     add(jLabelBlobDiameterUnit, gbcLabelBlobDiameterUnit);
/* 144 */     jLabelBlobDiameterUnit.setFont(Fonts.SMALL_FONT);
/* 145 */     jLabelBlobDiameterUnit.setText("pixels");
/*     */     
/* 147 */     JLabel lblSpacer = new JLabel("   ");
/* 148 */     GridBagConstraints gbc_lblSpacer = new GridBagConstraints();
/* 149 */     gbc_lblSpacer.gridwidth = 3;
/* 150 */     gbc_lblSpacer.insets = new Insets(5, 5, 5, 5);
/* 151 */     gbc_lblSpacer.gridx = 0;
/* 152 */     gbc_lblSpacer.gridy = 4;
/* 153 */     add(lblSpacer, gbc_lblSpacer);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, Object> getSettings() {
/* 163 */     Map<String, Object> settings = new HashMap<>(1);
/* 164 */     settings.put("RADIUS", Double.valueOf(((Number)this.ftfDiameter.getValue()).doubleValue()));
/* 165 */     return settings;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSettings(Map<String, Object> settings) {
/* 171 */     this.ftfDiameter.setValue(Double.valueOf(((Double)Optional.<Double>ofNullable((Double)settings.get("RADIUS")).orElse(Double.valueOf(5.0D))).doubleValue() * 2.0D));
/*     */   }
/*     */   
/*     */   public void clean() {}
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/gui/components/detector/ManualDetectorConfigurationPanel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */