/*     */ package fiji.plugin.trackmate.io;
/*     */ 
/*     */ import Jama.EigenvalueDecomposition;
/*     */ import Jama.Matrix;
/*     */ import fiji.plugin.trackmate.Logger;
/*     */ import fiji.plugin.trackmate.Model;
/*     */ import fiji.plugin.trackmate.Spot;
/*     */ import fiji.plugin.trackmate.SpotCollection;
/*     */ import java.io.File;
/*     */ import java.io.FilenameFilter;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import net.imglib2.algorithm.Benchmark;
/*     */ import net.imglib2.algorithm.OutputAlgorithm;
/*     */ import net.imglib2.realtransform.AffineTransform3D;
/*     */ import net.imglib2.util.LinAlgHelpers;
/*     */ import net.imglib2.util.Util;
/*     */ import org.jdom2.Document;
/*     */ import org.jdom2.Element;
/*     */ import org.jdom2.JDOMException;
/*     */ import org.jdom2.input.SAXBuilder;
/*     */ import org.jgrapht.graph.DefaultWeightedEdge;
/*     */ import org.jgrapht.graph.SimpleWeightedGraph;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TGMMImporter
/*     */   implements OutputAlgorithm<Model>, Benchmark
/*     */ {
/*  58 */   private static final FilenameFilter xmlFilter = new FilenameFilter()
/*     */     {
/*     */       
/*     */       public boolean accept(File folder, String name)
/*     */       {
/*  63 */         return name.toLowerCase().endsWith(".xml");
/*     */       }
/*     */     };
/*     */ 
/*     */   
/*     */   private static final String BASE_ERROR_MSG = "[TGMMImporter] ";
/*     */   
/*     */   private static final String XML_DETECTION_NAME = "GaussianMixtureModel";
/*     */   
/*     */   private static final String XML_CENTROID = "m";
/*     */   
/*     */   private static final String XML_ID = "id";
/*     */   
/*     */   private static final String XML_SCORE = "splitScore";
/*     */   
/*     */   private static final String XML_NU = "nu";
/*     */   
/*     */   private static final String XML_PRECISION_MATRIX = "W";
/*     */   
/*     */   private static final String XML_LINEAGE = "lineage";
/*     */   
/*     */   private static final String XML_PARENT = "parent";
/*  85 */   private static final Pattern DEFAULT_PATTERN = Pattern.compile(".+_frame(\\d+)\\.xml");
/*     */ 
/*     */   
/*     */   private final File file;
/*     */ 
/*     */   
/*     */   private String errorMessage;
/*     */ 
/*     */   
/*     */   private final Pattern framePattern;
/*     */ 
/*     */   
/*     */   private Model model;
/*     */   
/*     */   private final List<AffineTransform3D> transforms;
/*     */   
/*     */   private final Logger logger;
/*     */   
/*     */   private long processingTime;
/*     */ 
/*     */   
/*     */   public TGMMImporter(File file, List<AffineTransform3D> transforms, Pattern framePattern, Logger logger) {
/* 107 */     this.file = file;
/* 108 */     this.framePattern = framePattern;
/* 109 */     this.transforms = transforms;
/* 110 */     this.logger = logger;
/*     */   }
/*     */ 
/*     */   
/*     */   public TGMMImporter(File file, List<AffineTransform3D> transforms, Pattern framePattern) {
/* 115 */     this(file, transforms, framePattern, Logger.VOID_LOGGER);
/*     */   }
/*     */ 
/*     */   
/*     */   public TGMMImporter(File file, List<AffineTransform3D> transforms) {
/* 120 */     this(file, transforms, DEFAULT_PATTERN);
/*     */   }
/*     */ 
/*     */   
/*     */   public TGMMImporter(File file, List<AffineTransform3D> transforms, Logger logger) {
/* 125 */     this(file, transforms, DEFAULT_PATTERN, logger);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean checkInput() {
/* 135 */     if (!this.file.exists()) {
/*     */       
/* 137 */       this.errorMessage = "[TGMMImporter] Folder " + this.file + " does not exist.\n";
/* 138 */       return false;
/*     */     } 
/* 140 */     if (!this.file.canRead()) {
/*     */       
/* 142 */       this.errorMessage = "[TGMMImporter] Folder " + this.file + " cannot be read.\n";
/* 143 */       return false;
/*     */     } 
/* 145 */     if (!this.file.isDirectory()) {
/*     */       
/* 147 */       this.errorMessage = "[TGMMImporter] " + this.file + " is not a folder.\n";
/* 148 */       return false;
/*     */     } 
/*     */     
/* 151 */     if ((this.file.listFiles(xmlFilter)).length == 0) {
/*     */       
/* 153 */       this.errorMessage = "[TGMMImporter] Folder " + this.file + " does not contain XML files.\n";
/* 154 */       return false;
/*     */     } 
/* 156 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean process() {
/* 162 */     long start = System.currentTimeMillis();
/*     */     
/* 164 */     this.model = new Model();
/* 165 */     SpotCollection sc = new SpotCollection();
/* 166 */     SimpleWeightedGraph<Spot, DefaultWeightedEdge> graph = new SimpleWeightedGraph(DefaultWeightedEdge.class);
/*     */     
/* 168 */     double[] targetCoordsHolder = new double[3];
/* 169 */     double[] sourceCoordsHolder = new double[3];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 175 */     File[] xmlFiles = this.file.listFiles(xmlFilter);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 182 */     this.logger.setProgress(0.0D);
/* 183 */     this.logger.setStatus("Importing TGMM files.");
/* 184 */     int[] frames = new int[xmlFiles.length];
/* 185 */     this.logger.log("Importing " + frames.length + " TGMM files.\n");
/*     */     
/* 187 */     for (int i = 0; i < frames.length; i++) {
/*     */       
/* 189 */       String name = xmlFiles[i].getName();
/* 190 */       Matcher matcher = this.framePattern.matcher(name);
/* 191 */       if (!matcher.matches()) {
/*     */         
/* 193 */         this.errorMessage = "[TGMMImporter] File " + name + " does not match the name pattern.\n";
/* 194 */         return false;
/*     */       } 
/* 196 */       String strFrame = matcher.group(1);
/*     */       
/*     */       try {
/* 199 */         int frame = Integer.parseInt(strFrame);
/* 200 */         frames[i] = frame;
/*     */       }
/* 202 */       catch (NumberFormatException nfe) {
/*     */         
/* 204 */         this.errorMessage = "[TGMMImporter] Could not retrieve frame number from file " + this.file + ".\n" + nfe.getMessage() + "\n";
/* 205 */         return false;
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 213 */     File xmlFile = null;
/*     */     
/*     */     try {
/* 216 */       SAXBuilder saxBuilder = new SAXBuilder();
/*     */       
/* 218 */       Map<Integer, Spot> previousSpotID = null;
/*     */ 
/*     */       
/* 221 */       for (int t = 0; t < frames.length; t++)
/*     */       {
/* 223 */         this.logger.log("Processing frame " + frames[t] + ". ");
/* 224 */         AffineTransform3D transform = this.transforms.get(frames[t]);
/*     */         
/* 226 */         xmlFile = xmlFiles[t];
/* 227 */         Document doc = saxBuilder.build(xmlFile);
/* 228 */         Element root = doc.getRootElement();
/* 229 */         List<Element> detectionEls = root.getChildren("GaussianMixtureModel");
/*     */         
/* 231 */         Collection<Spot> spots = new ArrayList<>(detectionEls.size());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 237 */         Map<Integer, Spot> currentSpotID = new HashMap<>(detectionEls.size());
/*     */         
/* 239 */         for (Element detectionEl : detectionEls) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 246 */           String pixelPosStr = detectionEl.getAttributeValue("m");
/* 247 */           if (null == pixelPosStr) {
/*     */             
/* 249 */             this.errorMessage = "[TGMMImporter] Element " + detectionEl + " in file " + xmlFile + " misses the centroid attribute (" + "m" + ").\n";
/* 250 */             return false;
/*     */           } 
/* 252 */           String[] pixelPosStrs = pixelPosStr.split(" ");
/*     */           
/* 254 */           String idStr = detectionEl.getAttributeValue("id");
/* 255 */           if (null == idStr) {
/*     */             
/* 257 */             this.errorMessage = "[TGMMImporter] Element " + detectionEl + " in file " + xmlFile + " misses the ID attribute (" + "id" + ").\n";
/* 258 */             return false;
/*     */           } 
/*     */           
/* 261 */           String lineageStr = detectionEl.getAttributeValue("lineage");
/* 262 */           if (null == lineageStr) {
/*     */             
/* 264 */             this.errorMessage = "[TGMMImporter] Element " + detectionEl + " in file " + xmlFile + " misses the lineage attribute (" + "lineage" + ").\n";
/* 265 */             return false;
/*     */           } 
/*     */           
/* 268 */           String parentStr = detectionEl.getAttributeValue("parent");
/* 269 */           if (null == parentStr) {
/*     */             
/* 271 */             this.errorMessage = "[TGMMImporter] Element " + detectionEl + " in file " + xmlFile + " misses the parent attribute (" + "lineage" + ").\n";
/* 272 */             return false;
/*     */           } 
/*     */           
/* 275 */           String scoreStr = detectionEl.getAttributeValue("splitScore");
/* 276 */           if (null == scoreStr) {
/*     */             
/* 278 */             this.errorMessage = "[TGMMImporter] Element " + detectionEl + " in file " + xmlFile + " misses the score attribute (" + "splitScore" + ").\n";
/* 279 */             return false;
/*     */           } 
/*     */           
/* 282 */           String nuStr = detectionEl.getAttributeValue("nu");
/* 283 */           if (null == nuStr) {
/*     */             
/* 285 */             this.errorMessage = "[TGMMImporter] Element " + detectionEl + " in file " + xmlFile + " misses the nu attribute (" + "nu" + ").\n";
/* 286 */             return false;
/*     */           } 
/*     */           
/* 289 */           String precMatStr = detectionEl.getAttributeValue("W");
/* 290 */           if (null == precMatStr) {
/*     */             
/* 292 */             this.errorMessage = "[TGMMImporter] Element " + detectionEl + " in file " + xmlFile + " misses the prevision matrix attribute (" + "W" + ").\n";
/* 293 */             return false;
/*     */           } 
/* 295 */           String[] precMatStrs = precMatStr.split(" ");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           try {
/* 308 */             double x = Double.parseDouble(pixelPosStrs[0]);
/* 309 */             double y = Double.parseDouble(pixelPosStrs[1]);
/* 310 */             double z = Double.parseDouble(pixelPosStrs[2]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 316 */             sourceCoordsHolder[0] = x;
/* 317 */             sourceCoordsHolder[1] = y;
/* 318 */             sourceCoordsHolder[2] = z;
/*     */ 
/*     */             
/* 321 */             transform.apply(sourceCoordsHolder, targetCoordsHolder);
/*     */             
/* 323 */             double mx = targetCoordsHolder[0];
/* 324 */             double my = targetCoordsHolder[1];
/* 325 */             double mz = targetCoordsHolder[2];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 331 */             int id = Integer.parseInt(idStr);
/* 332 */             double score = Double.parseDouble(scoreStr);
/* 333 */             int lineage = Integer.parseInt(lineageStr);
/* 334 */             int parent = Integer.parseInt(parentStr);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 340 */             double nu = Double.parseDouble(nuStr);
/* 341 */             double[] vals = new double[9];
/* 342 */             for (int j = 0; j < vals.length; j++)
/*     */             {
/* 344 */               vals[j] = nu * Double.parseDouble(precMatStrs[j]);
/*     */             }
/* 346 */             Matrix precMat = new Matrix(vals, 3);
/* 347 */             Matrix covMat = precMat.inverse();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 353 */             double[][] S = covMat.getArray();
/* 354 */             double[][] T = new double[3][3];
/* 355 */             for (int r = 0; r < 3; r++) {
/* 356 */               for (int c = 0; c < 3; c++)
/* 357 */                 T[r][c] = transform.get(r, c); 
/* 358 */             }  double[][] TS = new double[3][3];
/* 359 */             LinAlgHelpers.mult(T, S, TS);
/* 360 */             LinAlgHelpers.multABT(TS, T, S);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 368 */             double nSigmas = 2.0D;
/*     */             
/* 370 */             EigenvalueDecomposition eig = covMat.eig();
/* 371 */             double[] radii = eig.getRealEigenvalues();
/* 372 */             for (int k = 0; k < radii.length; k++)
/* 373 */               radii[k] = Math.sqrt(radii[k]); 
/* 374 */             double radius = 2.0D * Util.average(radii);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 380 */             Spot spot = new Spot(mx, my, mz, radius, score, lineage + " (" + id + ")");
/* 381 */             spots.add(spot);
/* 382 */             currentSpotID.put(Integer.valueOf(id), spot);
/*     */             
/* 384 */             graph.addVertex(spot);
/* 385 */             if (parent >= 0 && previousSpotID != null)
/*     */             {
/* 387 */               Spot source = previousSpotID.get(Integer.valueOf(parent));
/* 388 */               if (null == source) {
/*     */                 
/* 390 */                 System.out.println("[TGMMImporter] The parent of the current spot (frame " + frames[t] + ", id = " + id + " could not be found (was expected in frame " + (frames[t] - 1) + " with id = " + parent + ".\n");
/*     */                 continue;
/*     */               } 
/* 393 */               DefaultWeightedEdge edge = (DefaultWeightedEdge)graph.addEdge(source, spot);
/* 394 */               if (null == edge)
/*     */               {
/* 396 */                 System.out.println("[TGMMImporter] Trouble adding edge between " + source + " and " + spot + ". Edge already exists?");
/*     */               }
/*     */             }
/*     */           
/*     */           }
/* 401 */           catch (NumberFormatException nfe) {
/*     */             
/* 403 */             this.errorMessage = "[TGMMImporter] Could not parse attributes of element " + detectionEl + " in xmlFile " + xmlFile + ".\n" + nfe.getMessage() + "\n";
/*     */             
/* 405 */             System.out.println(this.errorMessage);
/*     */           } 
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 414 */         sc.put(frames[t], spots);
/* 415 */         previousSpotID = currentSpotID;
/* 416 */         this.logger.log("Found " + spots.size() + " spots.\n");
/* 417 */         this.logger.setProgress(t / frames.length);
/*     */       }
/*     */     
/* 420 */     } catch (JDOMException e) {
/*     */       
/* 422 */       this.errorMessage = "[TGMMImporter] File " + xmlFile + " is not a poperly formed XML file.\n" + e.getMessage() + "\n";
/* 423 */       return false;
/*     */     }
/* 425 */     catch (IOException e) {
/*     */       
/* 427 */       this.errorMessage = "[TGMMImporter] Could not open file " + xmlFile + " for reading.\n" + e.getMessage() + "\n";
/* 428 */       return false;
/*     */     }
/*     */     finally {
/*     */       
/* 432 */       sc.setVisible(true);
/* 433 */       this.model.setSpots(sc, false);
/* 434 */       this.model.setTracks(graph, false);
/*     */       
/* 436 */       long end = System.currentTimeMillis();
/* 437 */       this.processingTime = end - start;
/* 438 */       this.logger.setProgress(0.0D);
/* 439 */       this.logger.log(String.format("Import completed in %.1f s.\n", new Object[] { Double.valueOf(this.processingTime / 1000.0D) }));
/* 440 */       this.logger.setStatus("");
/*     */     } 
/*     */     
/* 443 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getErrorMessage() {
/* 449 */     return this.errorMessage;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Model getResult() {
/* 455 */     return this.model;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public long getProcessingTime() {
/* 461 */     return this.processingTime;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/io/TGMMImporter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */