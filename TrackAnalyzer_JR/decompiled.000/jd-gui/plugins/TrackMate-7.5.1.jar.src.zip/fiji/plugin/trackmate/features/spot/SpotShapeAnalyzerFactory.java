/*     */ package fiji.plugin.trackmate.features.spot;
/*     */ 
/*     */ import fiji.plugin.trackmate.Dimension;
/*     */ import fiji.plugin.trackmate.detection.DetectionUtils;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.swing.ImageIcon;
/*     */ import net.imagej.ImgPlus;
/*     */ import net.imglib2.type.NativeType;
/*     */ import net.imglib2.type.numeric.RealType;
/*     */ import org.scijava.plugin.Plugin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Plugin(type = SpotMorphologyAnalyzerFactory.class)
/*     */ public class SpotShapeAnalyzerFactory<T extends RealType<T> & NativeType<T>>
/*     */   implements SpotMorphologyAnalyzerFactory<T>
/*     */ {
/*     */   public static final String KEY = "Spot 2D shape descriptors";
/*     */   public static final String AREA = "AREA";
/*     */   public static final String PERIMETER = "PERIMETER";
/*     */   public static final String CIRCULARITY = "CIRCULARITY";
/*     */   public static final String SOLIDITY = "SOLIDITY";
/*  50 */   private static final List<String> FEATURES = Arrays.asList(new String[] { "AREA", "PERIMETER", "CIRCULARITY", "SOLIDITY" });
/*     */   
/*  52 */   private static final Map<String, String> FEATURE_SHORTNAMES = new HashMap<>();
/*  53 */   private static final Map<String, String> FEATURE_NAMES = new HashMap<>();
/*  54 */   private static final Map<String, Dimension> FEATURE_DIMENSIONS = new HashMap<>();
/*  55 */   private static final Map<String, Boolean> FEATURE_ISINTS = new HashMap<>();
/*     */   
/*     */   static {
/*  58 */     FEATURE_SHORTNAMES.put("AREA", "Area");
/*  59 */     FEATURE_SHORTNAMES.put("PERIMETER", "Perim.");
/*  60 */     FEATURE_SHORTNAMES.put("CIRCULARITY", "Circ.");
/*  61 */     FEATURE_SHORTNAMES.put("SOLIDITY", "Solidity");
/*     */     
/*  63 */     FEATURE_NAMES.put("AREA", "Area");
/*  64 */     FEATURE_NAMES.put("PERIMETER", "Perimeter");
/*  65 */     FEATURE_NAMES.put("CIRCULARITY", "Circularity");
/*  66 */     FEATURE_NAMES.put("SOLIDITY", "Solidity");
/*     */     
/*  68 */     FEATURE_DIMENSIONS.put("AREA", Dimension.AREA);
/*  69 */     FEATURE_DIMENSIONS.put("PERIMETER", Dimension.LENGTH);
/*  70 */     FEATURE_DIMENSIONS.put("CIRCULARITY", Dimension.NONE);
/*  71 */     FEATURE_DIMENSIONS.put("SOLIDITY", Dimension.NONE);
/*     */     
/*  73 */     FEATURE_ISINTS.put("AREA", Boolean.FALSE);
/*  74 */     FEATURE_ISINTS.put("PERIMETER", Boolean.FALSE);
/*  75 */     FEATURE_ISINTS.put("CIRCULARITY", Boolean.FALSE);
/*  76 */     FEATURE_ISINTS.put("SOLIDITY", Boolean.FALSE);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SpotAnalyzer<T> getAnalyzer(ImgPlus<T> img, int frame, int channel) {
/*  84 */     if (channel != 0) {
/*  85 */       return SpotAnalyzer.dummyAnalyzer();
/*     */     }
/*  87 */     return (SpotAnalyzer)new SpotShapeAnalyzer<>(DetectionUtils.is2D(img));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public List<String> getFeatures() {
/*  93 */     return FEATURES;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, String> getFeatureShortNames() {
/*  99 */     return FEATURE_SHORTNAMES;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, String> getFeatureNames() {
/* 105 */     return FEATURE_NAMES;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, Dimension> getFeatureDimensions() {
/* 111 */     return FEATURE_DIMENSIONS;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, Boolean> getIsIntFeature() {
/* 117 */     return FEATURE_ISINTS;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isManualFeature() {
/* 123 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getInfoText() {
/* 129 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ImageIcon getIcon() {
/* 135 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getKey() {
/* 141 */     return "Spot 2D shape descriptors";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/* 147 */     return "Spot 2D shape descriptors";
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/features/spot/SpotShapeAnalyzerFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */