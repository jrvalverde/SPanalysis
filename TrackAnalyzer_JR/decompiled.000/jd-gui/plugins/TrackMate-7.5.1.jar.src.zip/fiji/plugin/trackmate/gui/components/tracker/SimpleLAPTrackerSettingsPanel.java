/*     */ package fiji.plugin.trackmate.gui.components.tracker;
/*     */ 
/*     */ import fiji.plugin.trackmate.gui.Fonts;
/*     */ import fiji.plugin.trackmate.gui.GuiUtils;
/*     */ import fiji.plugin.trackmate.gui.components.ConfigurationPanel;
/*     */ import fiji.plugin.trackmate.tracking.TrackerKeys;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.GridBagConstraints;
/*     */ import java.awt.GridBagLayout;
/*     */ import java.awt.Insets;
/*     */ import java.text.DecimalFormat;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import javax.swing.JFormattedTextField;
/*     */ import javax.swing.JLabel;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SimpleLAPTrackerSettingsPanel
/*     */   extends ConfigurationPanel
/*     */ {
/*     */   private static final long serialVersionUID = -1L;
/*     */   private final JFormattedTextField txtfldGapClosingTimeCutoff;
/*     */   private final JFormattedTextField txtfldGapClosingDistanceCutoff;
/*     */   private final JFormattedTextField txtfldLinkingDistance;
/*     */   
/*     */   public SimpleLAPTrackerSettingsPanel(String trackerName, String infoText, String spaceUnits) {
/*  85 */     DecimalFormat decimalFormat = new DecimalFormat("0.0");
/*     */     
/*  87 */     setPreferredSize(new Dimension(300, 500));
/*  88 */     GridBagLayout thisLayout = new GridBagLayout();
/*  89 */     thisLayout.rowWeights = new double[] { 0.0D, 0.0D, 0.0D, 0.0D, 0.0D, 0.0D, 0.0D, 1.0D };
/*  90 */     thisLayout.rowHeights = new int[] { 31, 50, 119, 7, 50, 50, 50, 50 };
/*  91 */     thisLayout.columnWeights = new double[] { 0.0D, 0.0D, 0.1D };
/*  92 */     thisLayout.columnWidths = new int[] { 203, 42, 7 };
/*  93 */     setLayout(thisLayout);
/*     */     
/*  95 */     JLabel lbl1 = new JLabel();
/*  96 */     add(lbl1, new GridBagConstraints(0, 0, 3, 1, 0.0D, 0.0D, 17, 2, new Insets(0, 10, 0, 10), 0, 0));
/*  97 */     lbl1.setFont(Fonts.FONT);
/*  98 */     lbl1.setText("Settings for tracker:");
/*     */     
/* 100 */     JLabel lblTrackerName = new JLabel();
/* 101 */     add(lblTrackerName, new GridBagConstraints(0, 1, 3, 1, 0.0D, 0.0D, 21, 0, new Insets(10, 20, 0, 0), 0, 0));
/* 102 */     lblTrackerName.setHorizontalTextPosition(0);
/* 103 */     lblTrackerName.setHorizontalAlignment(0);
/* 104 */     lblTrackerName.setFont(Fonts.BIG_FONT);
/* 105 */     lblTrackerName.setText(trackerName);
/*     */     
/* 107 */     JLabel lblTrackerDescription = new JLabel();
/* 108 */     add(lblTrackerDescription, new GridBagConstraints(0, 2, 3, 1, 0.0D, 0.0D, 10, 1, new Insets(10, 10, 10, 10), 0, 0));
/* 109 */     lblTrackerDescription.setFont(Fonts.FONT.deriveFont(2));
/* 110 */     lblTrackerDescription.setText(infoText
/* 111 */         .replace("<br>", "")
/* 112 */         .replace("<p>", "<p align=\"justify\">")
/* 113 */         .replace("<html>", "<html><p align=\"justify\">"));
/*     */     
/* 115 */     JLabel lbl2 = new JLabel();
/* 116 */     add(lbl2, new GridBagConstraints(0, 4, 1, 1, 0.0D, 0.0D, 10, 2, new Insets(0, 10, 0, 0), 0, 0));
/* 117 */     lbl2.setFont(Fonts.FONT);
/* 118 */     lbl2.setText("Linking max distance:");
/*     */     
/* 120 */     JLabel lbl3 = new JLabel();
/* 121 */     add(lbl3, new GridBagConstraints(0, 5, 1, 1, 0.0D, 0.0D, 10, 2, new Insets(0, 10, 0, 0), 0, 0));
/* 122 */     lbl3.setFont(Fonts.FONT);
/* 123 */     lbl3.setText("Gap-closing max distance:");
/*     */     
/* 125 */     JLabel lbl4 = new JLabel();
/* 126 */     add(lbl4, new GridBagConstraints(0, 6, 1, 1, 0.0D, 0.0D, 10, 2, new Insets(0, 10, 0, 0), 0, 0));
/* 127 */     lbl4.setFont(Fonts.FONT);
/* 128 */     lbl4.setText("Gap-closing max frame gap:");
/*     */     
/* 130 */     this.txtfldLinkingDistance = new JFormattedTextField(decimalFormat);
/* 131 */     this.txtfldLinkingDistance.setMinimumSize(Fonts.TEXTFIELD_DIMENSION);
/* 132 */     add(this.txtfldLinkingDistance, new GridBagConstraints(1, 4, 1, 1, 0.0D, 0.0D, 10, 0, new Insets(0, 0, 0, 0), 0, 0));
/* 133 */     this.txtfldLinkingDistance.setFont(Fonts.FONT);
/* 134 */     this.txtfldLinkingDistance.setHorizontalAlignment(0);
/*     */     
/* 136 */     this.txtfldGapClosingDistanceCutoff = new JFormattedTextField(decimalFormat);
/* 137 */     this.txtfldGapClosingDistanceCutoff.setMinimumSize(Fonts.TEXTFIELD_DIMENSION);
/* 138 */     add(this.txtfldGapClosingDistanceCutoff, new GridBagConstraints(1, 5, 1, 1, 0.0D, 0.0D, 10, 0, new Insets(0, 0, 0, 0), 0, 0));
/* 139 */     this.txtfldGapClosingDistanceCutoff.setFont(Fonts.FONT);
/* 140 */     this.txtfldGapClosingDistanceCutoff.setHorizontalAlignment(0);
/*     */     
/* 142 */     this.txtfldGapClosingTimeCutoff = new JFormattedTextField(Integer.valueOf(2));
/* 143 */     this.txtfldGapClosingTimeCutoff.setMinimumSize(Fonts.TEXTFIELD_DIMENSION);
/* 144 */     add(this.txtfldGapClosingTimeCutoff, new GridBagConstraints(1, 6, 1, 1, 0.0D, 0.0D, 10, 0, new Insets(0, 0, 0, 0), 0, 0));
/* 145 */     this.txtfldGapClosingTimeCutoff.setFont(Fonts.FONT);
/* 146 */     this.txtfldGapClosingTimeCutoff.setHorizontalAlignment(0);
/*     */     
/* 148 */     JLabel lblMaxDistanceUnit = new JLabel();
/* 149 */     add(lblMaxDistanceUnit, new GridBagConstraints(2, 4, 1, 1, 0.0D, 0.0D, 13, 2, new Insets(0, 0, 0, 10), 0, 0));
/* 150 */     lblMaxDistanceUnit.setFont(Fonts.FONT);
/* 151 */     lblMaxDistanceUnit.setText(" " + spaceUnits);
/*     */     
/* 153 */     JLabel lblGapClosingMaxDistanceUnit = new JLabel();
/* 154 */     add(lblGapClosingMaxDistanceUnit, new GridBagConstraints(2, 5, 1, 1, 0.0D, 0.0D, 13, 2, new Insets(0, 0, 0, 10), 0, 0));
/* 155 */     lblGapClosingMaxDistanceUnit.setFont(Fonts.FONT);
/* 156 */     lblGapClosingMaxDistanceUnit.setText(" " + spaceUnits);
/*     */     
/* 158 */     JLabel lblGapClosingTimeCutoffUnit = new JLabel();
/* 159 */     add(lblGapClosingTimeCutoffUnit, new GridBagConstraints(2, 6, 1, 1, 0.0D, 0.0D, 13, 2, new Insets(0, 0, 0, 10), 0, 0));
/* 160 */     lblGapClosingTimeCutoffUnit.setFont(Fonts.FONT);
/*     */ 
/*     */     
/* 163 */     GuiUtils.selectAllOnFocus(this.txtfldLinkingDistance);
/* 164 */     GuiUtils.selectAllOnFocus(this.txtfldGapClosingDistanceCutoff);
/* 165 */     GuiUtils.selectAllOnFocus(this.txtfldGapClosingTimeCutoff);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSettings(Map<String, Object> settings) {
/* 175 */     echoSettings(settings);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, Object> getSettings() {
/* 181 */     Map<String, Object> settings = new HashMap<>();
/*     */     
/* 183 */     settings.put("LINKING_FEATURE_PENALTIES", TrackerKeys.DEFAULT_LINKING_FEATURE_PENALTIES);
/*     */     
/* 185 */     settings.put("ALLOW_GAP_CLOSING", Boolean.valueOf(true));
/* 186 */     settings.put("GAP_CLOSING_FEATURE_PENALTIES", TrackerKeys.DEFAULT_GAP_CLOSING_FEATURE_PENALTIES);
/*     */     
/* 188 */     settings.put("ALLOW_TRACK_SPLITTING", Boolean.valueOf(false));
/* 189 */     settings.put("SPLITTING_MAX_DISTANCE", Double.valueOf(15.0D));
/* 190 */     settings.put("SPLITTING_FEATURE_PENALTIES", TrackerKeys.DEFAULT_SPLITTING_FEATURE_PENALTIES);
/*     */     
/* 192 */     settings.put("ALLOW_TRACK_MERGING", Boolean.valueOf(false));
/* 193 */     settings.put("MERGING_MAX_DISTANCE", Double.valueOf(15.0D));
/* 194 */     settings.put("MERGING_FEATURE_PENALTIES", TrackerKeys.DEFAULT_MERGING_FEATURE_PENALTIES);
/*     */     
/* 196 */     settings.put("BLOCKING_VALUE", Double.valueOf(Double.POSITIVE_INFINITY));
/* 197 */     settings.put("ALTERNATIVE_LINKING_COST_FACTOR", Double.valueOf(1.05D));
/* 198 */     settings.put("CUTOFF_PERCENTILE", Double.valueOf(0.9D));
/*     */     
/* 200 */     settings.put("LINKING_MAX_DISTANCE", Double.valueOf(((Number)this.txtfldLinkingDistance.getValue()).doubleValue()));
/* 201 */     settings.put("GAP_CLOSING_MAX_DISTANCE", Double.valueOf(((Number)this.txtfldGapClosingDistanceCutoff.getValue()).doubleValue()));
/* 202 */     settings.put("MAX_FRAME_GAP", Integer.valueOf(((Number)this.txtfldGapClosingTimeCutoff.getValue()).intValue()));
/*     */     
/* 204 */     return settings;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void echoSettings(Map<String, Object> settings) {
/* 213 */     this.txtfldLinkingDistance.setValue(settings.get("LINKING_MAX_DISTANCE"));
/* 214 */     this.txtfldGapClosingDistanceCutoff.setValue(settings.get("GAP_CLOSING_MAX_DISTANCE"));
/* 215 */     this.txtfldGapClosingTimeCutoff.setValue(settings.get("MAX_FRAME_GAP"));
/*     */   }
/*     */   
/*     */   public void clean() {}
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/gui/components/tracker/SimpleLAPTrackerSettingsPanel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */