package fiji.plugin.trackmate.features.track;

import fiji.plugin.trackmate.Model;
import fiji.plugin.trackmate.features.FeatureAnalyzer;
import java.util.Collection;
import net.imglib2.algorithm.Benchmark;
import net.imglib2.algorithm.MultiThreaded;

public interface TrackAnalyzer extends Benchmark, FeatureAnalyzer, MultiThreaded {
  void process(Collection<Integer> paramCollection, Model paramModel);
  
  boolean isLocal();
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/features/track/TrackAnalyzer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */