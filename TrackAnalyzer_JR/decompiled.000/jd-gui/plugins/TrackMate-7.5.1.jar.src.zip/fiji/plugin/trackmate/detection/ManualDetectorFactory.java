/*     */ package fiji.plugin.trackmate.detection;
/*     */ 
/*     */ import fiji.plugin.trackmate.Model;
/*     */ import fiji.plugin.trackmate.Settings;
/*     */ import fiji.plugin.trackmate.Spot;
/*     */ import fiji.plugin.trackmate.gui.components.ConfigurationPanel;
/*     */ import fiji.plugin.trackmate.gui.components.detector.ManualDetectorConfigurationPanel;
/*     */ import fiji.plugin.trackmate.io.IOUtils;
/*     */ import fiji.plugin.trackmate.util.TMUtils;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.swing.ImageIcon;
/*     */ import net.imagej.ImgPlus;
/*     */ import net.imglib2.Interval;
/*     */ import net.imglib2.type.NativeType;
/*     */ import net.imglib2.type.numeric.RealType;
/*     */ import org.jdom2.Element;
/*     */ import org.scijava.plugin.Plugin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Plugin(type = SpotDetectorFactory.class)
/*     */ public class ManualDetectorFactory<T extends RealType<T> & NativeType<T>>
/*     */   implements SpotDetectorFactory<T>
/*     */ {
/*     */   public static final String DETECTOR_KEY = "MANUAL_DETECTOR";
/*     */   public static final String NAME = "Manual annotation";
/*     */   public static final String INFO_TEXT = "<html>Selecting this will skip the automatic detection phase, and jump directly <br>to manual segmentation. A default spot size will be asked for. </html>";
/*     */   protected String errorMessage;
/*     */   protected Map<String, Object> settings;
/*     */   
/*     */   public boolean has2Dsegmentation() {
/*  72 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public SpotDetector<T> getDetector(Interval interval, int frame) {
/*  78 */     return new SpotDetector<T>()
/*     */       {
/*     */ 
/*     */         
/*     */         public List<Spot> getResult()
/*     */         {
/*  84 */           return Collections.emptyList();
/*     */         }
/*     */ 
/*     */ 
/*     */         
/*     */         public boolean checkInput() {
/*  90 */           return true;
/*     */         }
/*     */ 
/*     */ 
/*     */         
/*     */         public boolean process() {
/*  96 */           return true;
/*     */         }
/*     */ 
/*     */ 
/*     */         
/*     */         public String getErrorMessage() {
/* 102 */           return null;
/*     */         }
/*     */ 
/*     */ 
/*     */         
/*     */         public long getProcessingTime() {
/* 108 */           return 0L;
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getKey() {
/* 116 */     return "MANUAL_DETECTOR";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 122 */     return "Manual annotation";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getErrorMessage() {
/* 128 */     return this.errorMessage;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean setTarget(ImgPlus<T> img, Map<String, Object> settings) {
/* 134 */     this.settings = settings;
/* 135 */     return checkSettings(settings);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean checkSettings(Map<String, Object> lSettings) {
/* 141 */     StringBuilder errorHolder = new StringBuilder();
/* 142 */     boolean ok = true;
/* 143 */     ok &= TMUtils.checkParameter(lSettings, "RADIUS", Double.class, errorHolder);
/* 144 */     List<String> mandatoryKeys = new ArrayList<>();
/* 145 */     mandatoryKeys.add("RADIUS");
/* 146 */     ok &= TMUtils.checkMapKeys(lSettings, mandatoryKeys, null, errorHolder);
/* 147 */     if (!ok) {
/* 148 */       this.errorMessage = errorHolder.toString();
/*     */     }
/* 150 */     return ok;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean marshall(Map<String, Object> lSettings, Element element) {
/* 156 */     StringBuilder errorHolder = new StringBuilder();
/* 157 */     boolean ok = IOUtils.writeRadius(lSettings, element, errorHolder);
/* 158 */     if (!ok)
/* 159 */       this.errorMessage = errorHolder.toString(); 
/* 160 */     return ok;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean unmarshall(Element element, Map<String, Object> lSettings) {
/* 166 */     lSettings.clear();
/* 167 */     StringBuilder errorHolder = new StringBuilder();
/* 168 */     boolean ok = IOUtils.readDoubleAttribute(element, lSettings, "RADIUS", errorHolder);
/* 169 */     if (!ok) {
/*     */       
/* 171 */       this.errorMessage = errorHolder.toString();
/* 172 */       return false;
/*     */     } 
/* 174 */     return checkSettings(lSettings);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ConfigurationPanel getDetectorConfigurationPanel(Settings settings, Model model) {
/* 180 */     return (ConfigurationPanel)new ManualDetectorConfigurationPanel("<html>Selecting this will skip the automatic detection phase, and jump directly <br>to manual segmentation. A default spot size will be asked for. </html>", "Manual annotation");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getInfoText() {
/* 186 */     return "<html>Selecting this will skip the automatic detection phase, and jump directly <br>to manual segmentation. A default spot size will be asked for. </html>";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/* 192 */     return "Manual annotation";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, Object> getDefaultSettings() {
/* 198 */     Map<String, Object> lSettings = new HashMap<>();
/* 199 */     lSettings.put("RADIUS", Double.valueOf(5.0D));
/* 200 */     return lSettings;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ImageIcon getIcon() {
/* 206 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ManualDetectorFactory<T> copy() {
/* 212 */     return new ManualDetectorFactory();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/detection/ManualDetectorFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */