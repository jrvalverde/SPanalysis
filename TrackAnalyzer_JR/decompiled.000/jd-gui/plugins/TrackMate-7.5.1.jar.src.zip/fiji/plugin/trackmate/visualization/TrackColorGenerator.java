package fiji.plugin.trackmate.visualization;

import org.jgrapht.graph.DefaultWeightedEdge;

public interface TrackColorGenerator extends FeatureColorGenerator<DefaultWeightedEdge> {}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/visualization/TrackColorGenerator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */