/*     */ package fiji.plugin.trackmate.action;
/*     */ 
/*     */ import fiji.plugin.trackmate.Model;
/*     */ import fiji.plugin.trackmate.SelectionModel;
/*     */ import fiji.plugin.trackmate.TrackMate;
/*     */ import fiji.plugin.trackmate.gui.Icons;
/*     */ import fiji.plugin.trackmate.gui.displaysettings.DisplaySettings;
/*     */ import fiji.plugin.trackmate.visualization.table.TrackTableView;
/*     */ import java.awt.Frame;
/*     */ import javax.swing.ImageIcon;
/*     */ import org.scijava.plugin.Plugin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ExportStatsTablesAction
/*     */   extends AbstractTMAction
/*     */ {
/*     */   public static final String NAME = "Export statistics to tables";
/*     */   public static final String KEY = "EXPORT_STATS";
/*     */   public static final String INFO_TEXT = "<html>Compute and export all statistics to 3 tables. Statistics are separated in features computed for: <ol> \t<li> spots in visible tracks; \t<li> edges between those spots; \t<li> visible tracks. </ol> Note that spots and edges that are not in visible tracks won't be displayed in the tables.</html>";
/*     */   
/*     */   public void execute(TrackMate trackmate, SelectionModel selectionModel, DisplaySettings displaySettings, Frame parent) {
/*  60 */     createTrackTables(trackmate.getModel(), selectionModel, displaySettings).render();
/*     */   }
/*     */ 
/*     */   
/*     */   public static TrackTableView createTrackTables(Model model, SelectionModel selectionModel, DisplaySettings displaySettings) {
/*  65 */     return new TrackTableView(model, selectionModel, displaySettings);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Plugin(type = TrackMateActionFactory.class, visible = false)
/*     */   public static class Factory
/*     */     implements TrackMateActionFactory
/*     */   {
/*     */     public String getInfoText() {
/*  76 */       return "<html>Compute and export all statistics to 3 tables. Statistics are separated in features computed for: <ol> \t<li> spots in visible tracks; \t<li> edges between those spots; \t<li> visible tracks. </ol> Note that spots and edges that are not in visible tracks won't be displayed in the tables.</html>";
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public String getKey() {
/*  82 */       return "EXPORT_STATS";
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public TrackMateAction create() {
/*  88 */       return new ExportStatsTablesAction();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public ImageIcon getIcon() {
/*  94 */       return Icons.CALCULATOR_ICON;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public String getName() {
/* 100 */       return "Export statistics to tables";
/*     */     }
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/action/ExportStatsTablesAction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */