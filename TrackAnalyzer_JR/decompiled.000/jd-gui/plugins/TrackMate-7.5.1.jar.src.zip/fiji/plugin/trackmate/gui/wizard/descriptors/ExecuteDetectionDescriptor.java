/*    */ package fiji.plugin.trackmate.gui.wizard.descriptors;
/*    */ 
/*    */ import fiji.plugin.trackmate.TrackMate;
/*    */ import fiji.plugin.trackmate.gui.components.LogPanel;
/*    */ import fiji.plugin.trackmate.gui.wizard.WizardPanelDescriptor;
/*    */ import java.awt.Component;
/*    */ import org.scijava.Cancelable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ExecuteDetectionDescriptor
/*    */   extends WizardPanelDescriptor
/*    */ {
/*    */   public static final String KEY = "ExecuteDetection";
/*    */   private final TrackMate trackmate;
/*    */   
/*    */   public ExecuteDetectionDescriptor(TrackMate trackmate, LogPanel logPanel) {
/* 39 */     super("ExecuteDetection");
/* 40 */     this.trackmate = trackmate;
/* 41 */     this.targetPanel = (Component)logPanel;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Runnable getForwardRunnable() {
/* 47 */     return () -> {
/*    */         long start = System.currentTimeMillis();
/*    */         boolean ok = this.trackmate.execDetection();
/*    */         if (!ok) {
/*    */           this.trackmate.getModel().getLogger().error(this.trackmate.getErrorMessage() + '\n');
/*    */         }
/*    */         long end = System.currentTimeMillis();
/*    */         this.trackmate.getModel().getLogger().log(String.format("Detection done in %.1f s.\n", new Object[] { Float.valueOf((float)(end - start) / 1000.0F) }));
/*    */       };
/*    */   }
/*    */ 
/*    */   
/*    */   public Cancelable getCancelable() {
/* 60 */     return (Cancelable)this.trackmate;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/gui/wizard/descriptors/ExecuteDetectionDescriptor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */