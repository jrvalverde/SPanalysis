/*     */ package fiji.plugin.trackmate.gui.components;
/*     */ 
/*     */ import fiji.plugin.trackmate.Model;
/*     */ import fiji.plugin.trackmate.ModelChangeEvent;
/*     */ import fiji.plugin.trackmate.Settings;
/*     */ import fiji.plugin.trackmate.features.FeatureUtils;
/*     */ import fiji.plugin.trackmate.gui.Fonts;
/*     */ import fiji.plugin.trackmate.gui.GuiUtils;
/*     */ import fiji.plugin.trackmate.gui.displaysettings.Colormap;
/*     */ import fiji.plugin.trackmate.gui.displaysettings.DisplaySettings;
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.Color;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.FontMetrics;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.GridBagConstraints;
/*     */ import java.awt.GridBagLayout;
/*     */ import java.awt.Insets;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.MouseAdapter;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.beans.PropertyChangeEvent;
/*     */ import java.beans.PropertyChangeListener;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import javax.swing.Box;
/*     */ import javax.swing.BoxLayout;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JFormattedTextField;
/*     */ import javax.swing.JFrame;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JMenuItem;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JPopupMenu;
/*     */ import javax.swing.UIManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FeatureDisplaySelector
/*     */ {
/*  80 */   private static final List<String> FEATURES_WITHOUT_MIN_MAX = Arrays.asList(new String[] { "UNIFORM_COLOR", "TRACK_INDEX", "MANUAL_EGE_COLOR", "MANUAL_SPOT_COLOR" });
/*     */ 
/*     */ 
/*     */   
/*     */   private final Model model;
/*     */ 
/*     */   
/*     */   private final Settings settings;
/*     */ 
/*     */   
/*     */   private final DisplaySettings ds;
/*     */ 
/*     */ 
/*     */   
/*     */   public FeatureDisplaySelector(Model model, Settings settings, DisplaySettings displaySettings) {
/*  95 */     this.model = model;
/*  96 */     this.settings = settings;
/*  97 */     this.ds = displaySettings;
/*     */   }
/*     */ 
/*     */   
/*     */   public JPanel createSelectorForSpots() {
/* 102 */     return createSelectorFor(DisplaySettings.TrackMateObject.SPOTS);
/*     */   }
/*     */ 
/*     */   
/*     */   public JPanel createSelectorForTracks() {
/* 107 */     return createSelectorFor(DisplaySettings.TrackMateObject.TRACKS);
/*     */   }
/*     */ 
/*     */   
/*     */   public JPanel createSelectorFor(DisplaySettings.TrackMateObject target) {
/* 112 */     return new FeatureSelectorPanel(target);
/*     */   }
/*     */ 
/*     */   
/*     */   private DisplaySettings.TrackMateObject getColorByType(DisplaySettings.TrackMateObject target) {
/* 117 */     return (target == DisplaySettings.TrackMateObject.SPOTS) ? this.ds.getSpotColorByType() : this.ds.getTrackColorByType();
/*     */   }
/*     */ 
/*     */   
/*     */   private String getColorByFeature(DisplaySettings.TrackMateObject target) {
/* 122 */     return (target == DisplaySettings.TrackMateObject.SPOTS) ? this.ds.getSpotColorByFeature() : this.ds.getTrackColorByFeature();
/*     */   }
/*     */ 
/*     */   
/*     */   private double getMin(DisplaySettings.TrackMateObject target) {
/* 127 */     return (target == DisplaySettings.TrackMateObject.SPOTS) ? this.ds.getSpotMin() : this.ds.getTrackMin();
/*     */   }
/*     */ 
/*     */   
/*     */   private double getMax(DisplaySettings.TrackMateObject target) {
/* 132 */     return (target == DisplaySettings.TrackMateObject.SPOTS) ? this.ds.getSpotMax() : this.ds.getTrackMax();
/*     */   }
/*     */ 
/*     */   
/*     */   private double[] autoMinMax(DisplaySettings.TrackMateObject target) {
/* 137 */     DisplaySettings.TrackMateObject type = getColorByType(target);
/* 138 */     String feature = getColorByFeature(target);
/* 139 */     return FeatureUtils.autoMinMax(this.model, type, feature);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final CategoryJComboBox<DisplaySettings.TrackMateObject, String> createComboBoxSelector(Model model, Settings settings) {
/* 150 */     List<DisplaySettings.TrackMateObject> categoriesIn = Arrays.asList(DisplaySettings.TrackMateObject.values());
/* 151 */     LinkedHashMap<DisplaySettings.TrackMateObject, Collection<String>> features = new LinkedHashMap<>(categoriesIn.size());
/* 152 */     HashMap<DisplaySettings.TrackMateObject, String> categoryNames = new HashMap<>(categoriesIn.size());
/* 153 */     HashMap<String, String> featureNames = new HashMap<>();
/*     */     
/* 155 */     for (DisplaySettings.TrackMateObject category : categoriesIn) {
/*     */       
/* 157 */       Map<String, String> featureKeys = FeatureUtils.collectFeatureKeys(category, model, settings);
/* 158 */       features.put(category, featureKeys.keySet());
/* 159 */       featureNames.putAll(featureKeys);
/*     */       
/* 161 */       switch (category) {
/*     */         
/*     */         case SPOTS:
/* 164 */           categoryNames.put(DisplaySettings.TrackMateObject.SPOTS, "Spot features:");
/*     */           continue;
/*     */         
/*     */         case EDGES:
/* 168 */           categoryNames.put(DisplaySettings.TrackMateObject.EDGES, "Edge features:");
/*     */           continue;
/*     */         
/*     */         case TRACKS:
/* 172 */           categoryNames.put(DisplaySettings.TrackMateObject.TRACKS, "Track features:");
/*     */           continue;
/*     */         
/*     */         case DEFAULT:
/* 176 */           categoryNames.put(DisplaySettings.TrackMateObject.DEFAULT, "Default:");
/*     */           continue;
/*     */       } 
/*     */       
/* 180 */       throw new IllegalArgumentException("Unknown object type: " + category);
/*     */     } 
/*     */     
/* 183 */     CategoryJComboBox<DisplaySettings.TrackMateObject, String> cb = new CategoryJComboBox<>(features, featureNames, categoryNames);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 189 */     if (null != model) {
/* 190 */       model.addModelChangeListener(event -> {
/*     */             if (event.getEventID() == 9) {
/*     */               LinkedHashMap<DisplaySettings.TrackMateObject, Collection<String>> features2 = new LinkedHashMap<>(categoriesIn.size());
/*     */               HashMap<DisplaySettings.TrackMateObject, String> categoryNames2 = new HashMap<>(categoriesIn.size());
/*     */               HashMap<String, String> featureNames2 = new HashMap<>();
/*     */               for (DisplaySettings.TrackMateObject category : categoriesIn) {
/*     */                 Map<String, String> featureKeys = FeatureUtils.collectFeatureKeys(category, model, settings);
/*     */                 features2.put(category, featureKeys.keySet());
/*     */                 featureNames2.putAll(featureKeys);
/*     */                 switch (category) {
/*     */                   case SPOTS:
/*     */                     categoryNames2.put(DisplaySettings.TrackMateObject.SPOTS, "Spot features:");
/*     */                     continue;
/*     */ 
/*     */ 
/*     */                   
/*     */                   case EDGES:
/*     */                     categoryNames2.put(DisplaySettings.TrackMateObject.EDGES, "Edge features:");
/*     */                     continue;
/*     */ 
/*     */ 
/*     */                   
/*     */                   case TRACKS:
/*     */                     categoryNames2.put(DisplaySettings.TrackMateObject.TRACKS, "Track features:");
/*     */                     continue;
/*     */ 
/*     */                   
/*     */                   case DEFAULT:
/*     */                     categoryNames2.put(DisplaySettings.TrackMateObject.DEFAULT, "Default:");
/*     */                     continue;
/*     */                 } 
/*     */ 
/*     */                 
/*     */                 throw new IllegalArgumentException("Unknown object type: " + category);
/*     */               } 
/*     */               cb.setItems(features2, featureNames2, categoryNames2);
/*     */             } 
/*     */           });
/*     */     }
/* 229 */     return cb;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private class FeatureSelectorPanel
/*     */     extends JPanel
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */ 
/*     */ 
/*     */     
/*     */     public FeatureSelectorPanel(DisplaySettings.TrackMateObject target) {
/*     */       PropertyChangeListener pcl;
/* 244 */       GridBagLayout layout = new GridBagLayout();
/* 245 */       layout.rowHeights = new int[] { 0, 0, 20 };
/* 246 */       layout.columnWeights = new double[] { 0.0D, 1.0D };
/* 247 */       layout.rowWeights = new double[] { 0.0D, 0.0D, 0.0D };
/* 248 */       setLayout(layout);
/*     */       
/* 250 */       JLabel lblColorBy = new JLabel("Color " + target.toString() + " by:");
/* 251 */       lblColorBy.setFont(Fonts.SMALL_FONT);
/* 252 */       GridBagConstraints gbcLblColorBy = new GridBagConstraints();
/* 253 */       gbcLblColorBy.anchor = 13;
/* 254 */       gbcLblColorBy.fill = 3;
/* 255 */       gbcLblColorBy.insets = new Insets(0, 0, 5, 5);
/* 256 */       gbcLblColorBy.gridx = 0;
/* 257 */       gbcLblColorBy.gridy = 0;
/* 258 */       add(lblColorBy, gbcLblColorBy);
/*     */       
/* 260 */       CategoryJComboBox<DisplaySettings.TrackMateObject, String> cmbboxColor = FeatureDisplaySelector.createComboBoxSelector(FeatureDisplaySelector.this.model, FeatureDisplaySelector.this.settings);
/* 261 */       GridBagConstraints gbcCmbboxColor = new GridBagConstraints();
/* 262 */       gbcCmbboxColor.fill = 2;
/* 263 */       gbcCmbboxColor.gridx = 1;
/* 264 */       gbcCmbboxColor.gridy = 0;
/* 265 */       add(cmbboxColor, gbcCmbboxColor);
/*     */       
/* 267 */       JPanel panelColorMap = new JPanel();
/* 268 */       GridBagConstraints gbcPanelColorMap = new GridBagConstraints();
/* 269 */       gbcPanelColorMap.gridwidth = 2;
/* 270 */       gbcPanelColorMap.fill = 1;
/* 271 */       gbcPanelColorMap.gridx = 0;
/* 272 */       gbcPanelColorMap.gridy = 2;
/* 273 */       add(panelColorMap, gbcPanelColorMap);
/*     */       
/* 275 */       final FeatureDisplaySelector.CanvasColor canvasColor = new FeatureDisplaySelector.CanvasColor(target);
/* 276 */       panelColorMap.setLayout(new BorderLayout());
/* 277 */       panelColorMap.add(canvasColor, "Center");
/*     */       
/* 279 */       JPanel panelMinMax = new JPanel();
/* 280 */       GridBagConstraints gbcPanelMinMax = new GridBagConstraints();
/* 281 */       gbcPanelMinMax.gridwidth = 2;
/* 282 */       gbcPanelMinMax.fill = 1;
/* 283 */       gbcPanelMinMax.gridx = 0;
/* 284 */       gbcPanelMinMax.gridy = 1;
/* 285 */       gbcPanelMinMax.insets = new Insets(2, 0, 0, 0);
/* 286 */       add(panelMinMax, gbcPanelMinMax);
/* 287 */       panelMinMax.setLayout(new BoxLayout(panelMinMax, 0));
/*     */       
/* 289 */       JButton btnAutoMinMax = new JButton("auto");
/* 290 */       btnAutoMinMax.setFont(Fonts.SMALL_FONT);
/* 291 */       panelMinMax.add(btnAutoMinMax);
/*     */       
/* 293 */       panelMinMax.add(Box.createHorizontalGlue());
/*     */       
/* 295 */       JLabel lblMin = new JLabel("min");
/* 296 */       lblMin.setFont(Fonts.SMALL_FONT);
/* 297 */       panelMinMax.add(lblMin);
/*     */       
/* 299 */       JFormattedTextField ftfMin = new JFormattedTextField(Double.valueOf(FeatureDisplaySelector.this.getMin(target)));
/* 300 */       ftfMin.setMaximumSize(new Dimension(180, 2147483647));
/* 301 */       GuiUtils.selectAllOnFocus(ftfMin);
/* 302 */       ftfMin.setHorizontalAlignment(0);
/* 303 */       ftfMin.setFont(Fonts.SMALL_FONT);
/* 304 */       ftfMin.setColumns(7);
/* 305 */       panelMinMax.add(ftfMin);
/*     */       
/* 307 */       panelMinMax.add(Box.createHorizontalGlue());
/*     */       
/* 309 */       JLabel lblMax = new JLabel("max");
/* 310 */       lblMax.setFont(Fonts.SMALL_FONT);
/* 311 */       panelMinMax.add(lblMax);
/*     */       
/* 313 */       JFormattedTextField ftfMax = new JFormattedTextField(Double.valueOf(FeatureDisplaySelector.this.getMax(target)));
/* 314 */       ftfMax.setMaximumSize(new Dimension(180, 2147483647));
/* 315 */       GuiUtils.selectAllOnFocus(ftfMax);
/* 316 */       ftfMax.setHorizontalAlignment(0);
/* 317 */       ftfMax.setFont(Fonts.SMALL_FONT);
/* 318 */       ftfMax.setColumns(7);
/* 319 */       panelMinMax.add(ftfMax);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 329 */       final JPopupMenu colormapMenu = new JPopupMenu();
/* 330 */       List<Colormap> cmaps = Colormap.getAvailableLUTs();
/* 331 */       for (Colormap cmap : cmaps) {
/*     */         
/* 333 */         final Colormap lut = cmap;
/* 334 */         JMenuItem item = new JMenuItem();
/* 335 */         item.setPreferredSize(new Dimension(100, 20));
/* 336 */         BoxLayout itemlayout = new BoxLayout(item, 2);
/* 337 */         item.setLayout(itemlayout);
/* 338 */         item.add(new JLabel(lut.getName()));
/* 339 */         item.add(Box.createHorizontalGlue());
/* 340 */         item.add(new JComponent()
/*     */             {
/*     */               private static final long serialVersionUID = 1L;
/*     */ 
/*     */ 
/*     */ 
/*     */               
/*     */               public void paint(Graphics g) {
/* 348 */                 int width = getWidth();
/* 349 */                 int height = getHeight();
/* 350 */                 for (int i = 0; i < width; i++) {
/*     */                   
/* 352 */                   double beta = i / (width - 1);
/* 353 */                   g.setColor(lut.getPaint(beta));
/* 354 */                   g.drawLine(i, 0, i, height);
/*     */                 } 
/* 356 */                 g.setColor(getParent().getBackground());
/* 357 */                 g.drawRect(0, 0, width, height);
/*     */               }
/*     */ 
/*     */ 
/*     */               
/*     */               public Dimension getMaximumSize() {
/* 363 */                 return new Dimension(50, 20);
/*     */               }
/*     */ 
/*     */ 
/*     */               
/*     */               public Dimension getPreferredSize() {
/* 369 */                 return getMaximumSize();
/*     */               }
/*     */             });
/*     */         
/* 373 */         item.addActionListener(e -> FeatureDisplaySelector.this.ds.setColormap(cmap));
/* 374 */         colormapMenu.add(item);
/*     */       } 
/* 376 */       canvasColor.addMouseListener(new MouseAdapter()
/*     */           {
/*     */             
/*     */             public void mouseClicked(MouseEvent e)
/*     */             {
/* 381 */               colormapMenu.show(canvasColor, e.getX(), e.getY());
/*     */             }
/*     */           });
/*     */ 
/*     */       
/* 386 */       switch (target) {
/*     */ 
/*     */         
/*     */         case SPOTS:
/* 390 */           cmbboxColor.addActionListener(e -> {
/*     */                 FeatureDisplaySelector.this.ds.setSpotColorBy((DisplaySettings.TrackMateObject)cmbboxColor.getSelectedCategory(), (String)cmbboxColor.getSelectedItem());
/*     */                 
/*     */                 boolean hasMinMax = !FeatureDisplaySelector.FEATURES_WITHOUT_MIN_MAX.contains(FeatureDisplaySelector.this.getColorByFeature(target));
/*     */                 
/*     */                 ftfMin.setEnabled(hasMinMax);
/*     */                 ftfMax.setEnabled(hasMinMax);
/*     */                 btnAutoMinMax.setEnabled(hasMinMax);
/*     */                 if (hasMinMax && !((String)cmbboxColor.getSelectedItem()).equals(FeatureDisplaySelector.this.getColorByFeature(target))) {
/*     */                   double[] minmax = FeatureDisplaySelector.this.autoMinMax(target);
/*     */                   ftfMin.setValue(Double.valueOf(minmax[0]));
/*     */                   ftfMax.setValue(Double.valueOf(minmax[1]));
/*     */                 } 
/*     */               });
/* 404 */           pcl = (e -> {
/*     */               double v1 = ((Number)ftfMin.getValue()).doubleValue();
/*     */               double v2 = ((Number)ftfMax.getValue()).doubleValue();
/*     */               FeatureDisplaySelector.this.ds.setSpotMinMax(v1, v2);
/*     */             });
/* 409 */           ftfMin.addPropertyChangeListener("value", pcl);
/* 410 */           ftfMax.addPropertyChangeListener("value", pcl);
/*     */           break;
/*     */ 
/*     */         
/*     */         case TRACKS:
/* 415 */           cmbboxColor.addActionListener(e -> {
/*     */                 FeatureDisplaySelector.this.ds.setTrackColorBy((DisplaySettings.TrackMateObject)cmbboxColor.getSelectedCategory(), (String)cmbboxColor.getSelectedItem());
/*     */                 
/*     */                 boolean hasMinMax = !FeatureDisplaySelector.FEATURES_WITHOUT_MIN_MAX.contains(FeatureDisplaySelector.this.getColorByFeature(target));
/*     */                 
/*     */                 ftfMin.setEnabled(hasMinMax);
/*     */                 ftfMax.setEnabled(hasMinMax);
/*     */                 btnAutoMinMax.setEnabled(hasMinMax);
/*     */                 if (hasMinMax && !((String)cmbboxColor.getSelectedItem()).equals(FeatureDisplaySelector.this.getColorByFeature(target))) {
/*     */                   double[] minmax = FeatureDisplaySelector.this.autoMinMax(target);
/*     */                   ftfMin.setValue(Double.valueOf(minmax[0]));
/*     */                   ftfMax.setValue(Double.valueOf(minmax[1]));
/*     */                 } 
/*     */               });
/* 429 */           pcl = (e -> {
/*     */               double v1 = ((Number)ftfMin.getValue()).doubleValue();
/*     */               double v2 = ((Number)ftfMax.getValue()).doubleValue();
/*     */               FeatureDisplaySelector.this.ds.setTrackMinMax(v1, v2);
/*     */             });
/* 434 */           ftfMin.addPropertyChangeListener("value", pcl);
/* 435 */           ftfMax.addPropertyChangeListener("value", pcl);
/*     */           break;
/*     */         
/*     */         default:
/* 439 */           throw new IllegalArgumentException("Unexpected selector target: " + target);
/*     */       } 
/*     */       
/* 442 */       btnAutoMinMax.addActionListener(e -> {
/*     */             double[] minmax = FeatureDisplaySelector.this.autoMinMax(target);
/*     */             
/*     */             ftfMin.setValue(Double.valueOf(minmax[0]));
/*     */             ftfMax.setValue(Double.valueOf(minmax[1]));
/*     */           });
/* 448 */       FeatureDisplaySelector.this.ds.listeners().add(() -> {
/*     */             ftfMin.setValue(Double.valueOf(FeatureDisplaySelector.this.getMin(target)));
/*     */             
/*     */             ftfMax.setValue(Double.valueOf(FeatureDisplaySelector.this.getMax(target)));
/*     */             
/*     */             String feature = FeatureDisplaySelector.this.getColorByFeature(target);
/*     */             
/*     */             if (feature != cmbboxColor.getSelectedItem()) {
/*     */               cmbboxColor.setSelectedItem(feature);
/*     */             }
/*     */             
/*     */             canvasColor.repaint();
/*     */           });
/*     */       
/* 462 */       cmbboxColor.setSelectedItem(FeatureDisplaySelector.this.getColorByFeature(target));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private final class CanvasColor
/*     */     extends JComponent
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */     
/*     */     private final DisplaySettings.TrackMateObject target;
/*     */     
/*     */     public CanvasColor(DisplaySettings.TrackMateObject target) {
/* 475 */       this.target = target;
/*     */     }
/*     */ 
/*     */     
/*     */     public void paint(Graphics g) {
/*     */       boolean isInt;
/* 481 */       String dataMinStr, dataMaxStr, minStr, maxStr, feature = FeatureDisplaySelector.this.getColorByFeature(this.target);
/* 482 */       if (!isEnabled() || FeatureDisplaySelector.FEATURES_WITHOUT_MIN_MAX.contains(feature)) {
/*     */         
/* 484 */         g.setColor(getParent().getBackground());
/* 485 */         g.fillRect(0, 0, getWidth(), getHeight());
/*     */ 
/*     */ 
/*     */         
/*     */         return;
/*     */       } 
/*     */ 
/*     */       
/* 493 */       double[] autoMinMax = FeatureDisplaySelector.this.autoMinMax(this.target);
/* 494 */       double min = FeatureDisplaySelector.this.getMin(this.target);
/* 495 */       double max = FeatureDisplaySelector.this.getMax(this.target);
/* 496 */       double dataMin = autoMinMax[0];
/* 497 */       double dataMax = autoMinMax[1];
/* 498 */       Colormap colormap = FeatureDisplaySelector.this.ds.getColormap();
/* 499 */       double alphaMin = (min - dataMin) / (dataMax - dataMin);
/* 500 */       double alphaMax = (max - dataMin) / (dataMax - dataMin);
/* 501 */       int width = getWidth();
/* 502 */       int height = getHeight();
/* 503 */       for (int i = 0; i < width; i++) {
/*     */         
/* 505 */         double alpha = i / (width - 1);
/* 506 */         double beta = (alpha - alphaMin) / (alphaMax - alphaMin);
/*     */         
/* 508 */         g.setColor(colormap.getPaint(beta));
/* 509 */         g.drawLine(i, 0, i, height);
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 516 */       g.setColor(Color.WHITE);
/* 517 */       g.setFont(Fonts.SMALL_FONT.deriveFont(1));
/* 518 */       FontMetrics fm = g.getFontMetrics();
/*     */ 
/*     */       
/* 521 */       switch (FeatureDisplaySelector.this.getColorByType(this.target)) {
/*     */         
/*     */         case TRACKS:
/* 524 */           isInt = ((Boolean)FeatureDisplaySelector.this.model.getFeatureModel().getTrackFeatureIsInt().get(feature)).booleanValue();
/*     */           break;
/*     */         case EDGES:
/* 527 */           isInt = ((Boolean)FeatureDisplaySelector.this.model.getFeatureModel().getEdgeFeatureIsInt().get(feature)).booleanValue();
/*     */           break;
/*     */         case SPOTS:
/* 530 */           isInt = ((Boolean)FeatureDisplaySelector.this.model.getFeatureModel().getSpotFeatureIsInt().get(feature)).booleanValue();
/*     */           break;
/*     */         default:
/* 533 */           isInt = false;
/*     */           break;
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 540 */       if (isInt) {
/*     */         
/* 542 */         dataMinStr = String.format("%d", new Object[] { Integer.valueOf((int)dataMin) });
/* 543 */         dataMaxStr = String.format("%d", new Object[] { Integer.valueOf((int)dataMax) });
/* 544 */         minStr = String.format("%d", new Object[] { Integer.valueOf((int)min) });
/* 545 */         maxStr = String.format("%d", new Object[] { Integer.valueOf((int)max) });
/*     */       }
/*     */       else {
/*     */         
/* 549 */         dataMinStr = String.format("%.1f", new Object[] { Double.valueOf(dataMin) });
/* 550 */         dataMaxStr = String.format("%.1f", new Object[] { Double.valueOf(dataMax) });
/* 551 */         minStr = String.format("%.1f", new Object[] { Double.valueOf(min) });
/* 552 */         maxStr = String.format("%.1f", new Object[] { Double.valueOf(max) });
/*     */       } 
/*     */       
/* 555 */       int dataMinStrWidth = fm.stringWidth(dataMinStr);
/* 556 */       int dataMaxStrWidth = fm.stringWidth(dataMaxStr);
/* 557 */       int minStrWidth = fm.stringWidth(minStr);
/* 558 */       int maxStrWidth = fm.stringWidth(maxStr);
/*     */       
/* 560 */       g.setColor(GuiUtils.textColorForBackground(colormap.getPaint(-alphaMin / (alphaMax - alphaMin))));
/* 561 */       g.drawString(dataMinStr, 1, height / 2 + fm.getHeight() / 2);
/*     */       
/* 563 */       g.setColor(GuiUtils.textColorForBackground(colormap.getPaint((1.0D - alphaMin) / (alphaMax - alphaMin))));
/* 564 */       g.drawString(dataMaxStr, width - dataMaxStrWidth - 1, height / 2 + fm.getHeight() / 2);
/*     */       
/* 566 */       int iMin = (int)((width - 1) * (min - dataMin) / (dataMax - dataMin));
/* 567 */       int iMax = (int)((width - 1) * (max - dataMin) / (dataMax - dataMin));
/*     */       
/* 569 */       if (iMin - minStrWidth > dataMinStrWidth + 2 && iMin < width - dataMaxStrWidth - 2) {
/*     */         
/* 571 */         g.setColor(GuiUtils.textColorForBackground(colormap.getPaint(0.0D)));
/* 572 */         g.drawString(minStr, iMin - minStrWidth, height / 2);
/*     */       } 
/* 574 */       if (iMax + maxStrWidth < width - dataMaxStrWidth - 2 && iMax > dataMinStrWidth + 2) {
/*     */         
/* 576 */         g.setColor(GuiUtils.textColorForBackground(colormap.getPaint(1.0D)));
/* 577 */         g.drawString(maxStr, iMax, height / 2);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void main(String[] args) {
/* 588 */     Locale.setDefault(Locale.ROOT);
/*     */     
/*     */     try {
/* 591 */       UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
/*     */     }
/* 593 */     catch (ClassNotFoundException|InstantiationException|IllegalAccessException|javax.swing.UnsupportedLookAndFeelException e) {
/*     */       
/* 595 */       e.printStackTrace();
/*     */     } 
/*     */     
/* 598 */     DisplaySettings ds = DisplaySettings.defaultStyle().copy();
/*     */     
/* 600 */     FeatureDisplaySelector featureSelector = new FeatureDisplaySelector(FeatureUtils.DUMMY_MODEL, null, ds);
/* 601 */     JFrame frame = new JFrame();
/* 602 */     frame.setDefaultCloseOperation(3);
/* 603 */     frame.getContentPane().add(featureSelector.createSelectorForSpots());
/* 604 */     frame.pack();
/* 605 */     frame.setVisible(true);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/gui/components/FeatureDisplaySelector.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */