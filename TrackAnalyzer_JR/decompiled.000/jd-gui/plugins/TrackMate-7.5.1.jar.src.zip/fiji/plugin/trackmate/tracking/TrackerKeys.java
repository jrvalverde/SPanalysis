/*     */ package fiji.plugin.trackmate.tracking;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TrackerKeys
/*     */ {
/*     */   public static final String TRACKER_SETTINGS_ALLOW_EVENT_ATTNAME = "allowed";
/*     */   public static final String TRACKER_SETTINGS_ALTERNATE_COST_FACTOR_ATTNAME = "alternatecostfactor";
/*     */   public static final String TRACKER_SETTINGS_CUTOFF_PERCENTILE_ATTNAME = "cutoffpercentile";
/*     */   public static final String TRACKER_SETTINGS_BLOCKING_VALUE_ATTNAME = "blockingvalue";
/*     */   public static final String TRACKER_SETTINGS_TIME_CUTOFF_ELEMENT = "TimeCutoff";
/*     */   public static final String TRACKER_SETTINGS_TIME_CUTOFF_ATTNAME = "value";
/*     */   public static final String TRACKER_SETTINGS_DISTANCE_CUTOFF_ELEMENT = "DistanceCutoff";
/*     */   public static final String TRACKER_SETTINGS_DISTANCE_CUTOFF_ATTNAME = "value";
/*     */   public static final String TRACKER_SETTINGS_FEATURE_ELEMENT = "FeatureCondition";
/*     */   public static final String TRACKER_SETTINGS_LINKING_ELEMENT = "LinkingCondition";
/*     */   public static final String TRACKER_SETTINGS_GAP_CLOSING_ELEMENT = "GapClosingCondition";
/*     */   public static final String TRACKER_SETTINGS_MERGING_ELEMENT = "MergingCondition";
/*     */   public static final String TRACKER_SETTINGS_SPLITTING_ELEMENT = "SplittingCondition";
/*     */   public static final String XML_ATTRIBUTE_TRACKER_NAME = "TRACKER_NAME";
/*     */   public static final String KEY_LINKING_MAX_DISTANCE = "LINKING_MAX_DISTANCE";
/*     */   public static final double DEFAULT_LINKING_MAX_DISTANCE = 15.0D;
/*     */   public static final String KEY_LINKING_FEATURE_PENALTIES = "LINKING_FEATURE_PENALTIES";
/*  96 */   public static final Map<String, Double> DEFAULT_LINKING_FEATURE_PENALTIES = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String KEY_ALLOW_GAP_CLOSING = "ALLOW_GAP_CLOSING";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final boolean DEFAULT_ALLOW_GAP_CLOSING = true;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String KEY_GAP_CLOSING_MAX_FRAME_GAP = "MAX_FRAME_GAP";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int DEFAULT_GAP_CLOSING_MAX_FRAME_GAP = 2;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String KEY_GAP_CLOSING_MAX_DISTANCE = "GAP_CLOSING_MAX_DISTANCE";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final double DEFAULT_GAP_CLOSING_MAX_DISTANCE = 15.0D;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String KEY_GAP_CLOSING_FEATURE_PENALTIES = "GAP_CLOSING_FEATURE_PENALTIES";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 148 */   public static final Map<String, Double> DEFAULT_GAP_CLOSING_FEATURE_PENALTIES = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String KEY_ALLOW_TRACK_MERGING = "ALLOW_TRACK_MERGING";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final boolean DEFAULT_ALLOW_TRACK_MERGING = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String KEY_MERGING_MAX_DISTANCE = "MERGING_MAX_DISTANCE";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final double DEFAULT_MERGING_MAX_DISTANCE = 15.0D;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String KEY_MERGING_FEATURE_PENALTIES = "MERGING_FEATURE_PENALTIES";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 184 */   public static final Map<String, Double> DEFAULT_MERGING_FEATURE_PENALTIES = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String KEY_ALLOW_TRACK_SPLITTING = "ALLOW_TRACK_SPLITTING";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final boolean DEFAULT_ALLOW_TRACK_SPLITTING = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String KEY_SPLITTING_MAX_DISTANCE = "SPLITTING_MAX_DISTANCE";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final double DEFAULT_SPLITTING_MAX_DISTANCE = 15.0D;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String KEY_SPLITTING_FEATURE_PENALTIES = "SPLITTING_FEATURE_PENALTIES";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 225 */   public static final Map<String, Double> DEFAULT_SPLITTING_FEATURE_PENALTIES = new HashMap<>();
/*     */   public static final String KEY_ALTERNATIVE_LINKING_COST_FACTOR = "ALTERNATIVE_LINKING_COST_FACTOR";
/*     */   public static final double DEFAULT_ALTERNATIVE_LINKING_COST_FACTOR = 1.05D;
/*     */   public static final String KEY_CUTOFF_PERCENTILE = "CUTOFF_PERCENTILE";
/*     */   public static final double DEFAULT_CUTOFF_PERCENTILE = 0.9D;
/*     */   public static final String KEY_BLOCKING_VALUE = "BLOCKING_VALUE";
/*     */   public static final double DEFAULT_BLOCKING_VALUE = InfinityD;
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/tracking/TrackerKeys.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */