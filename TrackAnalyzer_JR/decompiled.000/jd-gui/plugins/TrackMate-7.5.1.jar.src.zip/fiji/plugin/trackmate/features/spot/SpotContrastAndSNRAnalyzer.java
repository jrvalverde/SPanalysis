/*     */ package fiji.plugin.trackmate.features.spot;
/*     */ 
/*     */ import fiji.plugin.trackmate.Spot;
/*     */ import fiji.plugin.trackmate.SpotRoi;
/*     */ import fiji.plugin.trackmate.detection.DetectionUtils;
/*     */ import fiji.plugin.trackmate.util.SpotNeighborhood;
/*     */ import fiji.plugin.trackmate.util.SpotNeighborhoodCursor;
/*     */ import fiji.plugin.trackmate.util.SpotUtil;
/*     */ import net.imagej.ImgPlus;
/*     */ import net.imglib2.IterableInterval;
/*     */ import net.imglib2.RealLocalizable;
/*     */ import net.imglib2.type.numeric.RealType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SpotContrastAndSNRAnalyzer<T extends RealType<T>>
/*     */   extends AbstractSpotFeatureAnalyzer<T>
/*     */ {
/*     */   protected static final double RAD_PERCENTAGE = 1.0D;
/*     */   private final int channel;
/*     */   private final ImgPlus<T> img;
/*     */   
/*     */   public SpotContrastAndSNRAnalyzer(ImgPlus<T> img, int channel) {
/*  84 */     this.img = img;
/*  85 */     this.channel = channel;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void process(Spot spot) {
/*     */     double meanOut;
/*  95 */     String meanFeature = SpotIntensityMultiCAnalyzerFactory.makeFeatureKey("MEAN_INTENSITY_CH", this.channel);
/*  96 */     String stdFeature = SpotIntensityMultiCAnalyzerFactory.makeFeatureKey("STD_INTENSITY_CH", this.channel);
/*  97 */     double meanIn = spot.getFeature(meanFeature).doubleValue();
/*  98 */     double stdIn = spot.getFeature(stdFeature).doubleValue();
/*  99 */     double radius = spot.getFeature("RADIUS").doubleValue();
/* 100 */     double outterRadius = 2.0D * radius;
/*     */ 
/*     */ 
/*     */     
/* 104 */     SpotRoi roi = spot.getRoi();
/* 105 */     if (null != roi && DetectionUtils.is2D(this.img)) {
/*     */       
/* 107 */       double alpha = outterRadius / radius;
/* 108 */       SpotRoi outterRoi = roi.copy();
/* 109 */       outterRoi.scale(alpha);
/* 110 */       IterableInterval<T> neighborhood = SpotUtil.iterable(outterRoi, (RealLocalizable)spot, this.img);
/* 111 */       double outterSum = 0.0D;
/* 112 */       for (RealType realType : neighborhood) {
/* 113 */         outterSum += realType.getRealDouble();
/*     */       }
/* 115 */       String sumFeature = SpotIntensityMultiCAnalyzerFactory.makeFeatureKey("TOTAL_INTENSITY_CH", this.channel);
/* 116 */       double innterSum = spot.getFeature(sumFeature).doubleValue();
/* 117 */       outterSum -= innterSum;
/* 118 */       meanOut = outterSum / (outterRoi.area() - roi.area());
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 123 */       Spot largeSpot = new Spot(spot);
/* 124 */       largeSpot.putFeature("RADIUS", Double.valueOf(outterRadius));
/* 125 */       SpotNeighborhood<T> neighborhood = new SpotNeighborhood(largeSpot, this.img);
/* 126 */       if (neighborhood.size() <= 1L) {
/*     */         
/* 128 */         spot.putFeature(SpotIntensityMultiCAnalyzerFactory.makeFeatureKey("CONTRAST_CH", this.channel), Double.valueOf(Double.NaN));
/* 129 */         spot.putFeature(SpotIntensityMultiCAnalyzerFactory.makeFeatureKey("SNR_CH", this.channel), Double.valueOf(Double.NaN));
/*     */         
/*     */         return;
/*     */       } 
/* 133 */       double radius2 = radius * radius;
/* 134 */       int nOut = 0;
/* 135 */       double sumOut = 0.0D;
/*     */ 
/*     */       
/* 138 */       SpotNeighborhoodCursor<T> cursor = neighborhood.cursor();
/* 139 */       while (cursor.hasNext()) {
/*     */         
/* 141 */         cursor.fwd();
/* 142 */         double dist2 = cursor.getDistanceSquared();
/* 143 */         if (dist2 > radius2) {
/*     */           
/* 145 */           nOut++;
/* 146 */           sumOut += cursor.get().getRealDouble();
/*     */         } 
/*     */       } 
/* 149 */       meanOut = sumOut / nOut;
/*     */     } 
/*     */ 
/*     */     
/* 153 */     double contrast = (meanIn - meanOut) / (meanIn + meanOut);
/*     */ 
/*     */     
/* 156 */     double snr = (meanIn - meanOut) / stdIn;
/*     */     
/* 158 */     spot.putFeature(SpotIntensityMultiCAnalyzerFactory.makeFeatureKey("CONTRAST_CH", this.channel), Double.valueOf(contrast));
/* 159 */     spot.putFeature(SpotIntensityMultiCAnalyzerFactory.makeFeatureKey("SNR_CH", this.channel), Double.valueOf(snr));
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/features/spot/SpotContrastAndSNRAnalyzer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */