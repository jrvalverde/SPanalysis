/*     */ package fiji.plugin.trackmate.gui.components;
/*     */ 
/*     */ import fiji.plugin.trackmate.gui.Fonts;
/*     */ import fiji.plugin.trackmate.gui.GuiUtils;
/*     */ import fiji.plugin.trackmate.gui.Icons;
/*     */ import fiji.plugin.trackmate.gui.displaysettings.ConfigTrackMateDisplaySettings;
/*     */ import fiji.plugin.trackmate.gui.displaysettings.DisplaySettings;
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Container;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.FlowLayout;
/*     */ import java.awt.GridBagConstraints;
/*     */ import java.awt.GridBagLayout;
/*     */ import java.awt.Insets;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.beans.PropertyChangeEvent;
/*     */ import javax.swing.Action;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JCheckBox;
/*     */ import javax.swing.JComboBox;
/*     */ import javax.swing.JFormattedTextField;
/*     */ import javax.swing.JFrame;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JSpinner;
/*     */ import javax.swing.SpinnerNumberModel;
/*     */ import javax.swing.border.LineBorder;
/*     */ import javax.swing.event.ChangeEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConfigureViewsPanel
/*     */   extends JPanel
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  70 */   private static final Color BORDER_COLOR = new Color(192, 192, 192);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ConfigureViewsPanel(DisplaySettings ds, FeatureDisplaySelector featureSelector, String spaceUnits, Action launchTrackSchemeAction, Action showTrackTablesAction, Action showSpotTableAction) {
/*  84 */     setPreferredSize(new Dimension(300, 521));
/*  85 */     setSize(300, 500);
/*     */     
/*  87 */     GridBagLayout layout = new GridBagLayout();
/*  88 */     layout.columnWeights = new double[] { 1.0D, 1.0D };
/*  89 */     layout.rowWeights = new double[] { 0.0D, 0.0D, 0.0D, 0.0D, 0.0D, 0.0D, 0.0D, 1.0D };
/*  90 */     setLayout(layout);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  96 */     JLabel lblDisplayOptions = new JLabel();
/*  97 */     lblDisplayOptions.setText("Display options");
/*  98 */     lblDisplayOptions.setFont(Fonts.BIG_FONT);
/*  99 */     lblDisplayOptions.setHorizontalAlignment(2);
/* 100 */     GridBagConstraints gbcLabelDisplayOptions = new GridBagConstraints();
/* 101 */     gbcLabelDisplayOptions.gridwidth = 1;
/* 102 */     gbcLabelDisplayOptions.fill = 1;
/* 103 */     gbcLabelDisplayOptions.insets = new Insets(5, 5, 5, 5);
/* 104 */     gbcLabelDisplayOptions.gridx = 0;
/* 105 */     gbcLabelDisplayOptions.gridy = 0;
/* 106 */     add(lblDisplayOptions, gbcLabelDisplayOptions);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 112 */     JFrame editor = ConfigTrackMateDisplaySettings.editor(ds, "Configure the display settings used in this current session.", "TrackMate display settings");
/*     */ 
/*     */     
/* 115 */     editor.setLocationRelativeTo(getParent());
/* 116 */     editor.setDefaultCloseOperation(1);
/*     */     
/* 118 */     JButton btnEditSettings = new JButton("Edit settings", Icons.EDIT_SETTINGS_ICON);
/* 119 */     btnEditSettings.addActionListener(e -> editor.setVisible(!editor.isVisible()));
/*     */     
/* 121 */     GridBagConstraints gbcBtnEditSettings = new GridBagConstraints();
/* 122 */     gbcBtnEditSettings.fill = 0;
/* 123 */     gbcBtnEditSettings.insets = new Insets(5, 5, 5, 5);
/* 124 */     gbcBtnEditSettings.anchor = 13;
/* 125 */     gbcBtnEditSettings.gridx = 1;
/* 126 */     gbcBtnEditSettings.gridy = 0;
/* 127 */     add(btnEditSettings, gbcBtnEditSettings);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 133 */     JCheckBox chkboxDisplaySpots = new JCheckBox();
/* 134 */     chkboxDisplaySpots.setText("Display spots");
/* 135 */     chkboxDisplaySpots.setFont(Fonts.FONT);
/* 136 */     GridBagConstraints gbcCheckBoxDisplaySpots = new GridBagConstraints();
/* 137 */     gbcCheckBoxDisplaySpots.anchor = 11;
/* 138 */     gbcCheckBoxDisplaySpots.fill = 2;
/* 139 */     gbcCheckBoxDisplaySpots.insets = new Insets(0, 5, 0, 5);
/* 140 */     gbcCheckBoxDisplaySpots.gridx = 0;
/* 141 */     gbcCheckBoxDisplaySpots.gridy = 1;
/* 142 */     add(chkboxDisplaySpots, gbcCheckBoxDisplaySpots);
/*     */     
/* 144 */     JCheckBox chkboxDisplaySpotsAsRois = new JCheckBox();
/* 145 */     chkboxDisplaySpotsAsRois.setText("as ROIs");
/* 146 */     GridBagConstraints gbcChkboxDisplaySpotsAsRois = new GridBagConstraints();
/* 147 */     gbcChkboxDisplaySpotsAsRois.insets = new Insets(0, 0, 0, 5);
/* 148 */     gbcChkboxDisplaySpotsAsRois.anchor = 13;
/* 149 */     gbcChkboxDisplaySpotsAsRois.gridx = 1;
/* 150 */     gbcChkboxDisplaySpotsAsRois.gridy = 1;
/* 151 */     add(chkboxDisplaySpotsAsRois, gbcChkboxDisplaySpotsAsRois);
/* 152 */     chkboxDisplaySpotsAsRois.setFont(Fonts.FONT);
/* 153 */     chkboxDisplaySpotsAsRois.addActionListener(e -> ds.setSpotDisplayedAsRoi(chkboxDisplaySpotsAsRois.isSelected()));
/* 154 */     chkboxDisplaySpotsAsRois.setSelected(ds.isSpotDisplayedAsRoi());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 160 */     JPanel panelSpotOptions = new JPanel();
/* 161 */     panelSpotOptions.setBorder(new LineBorder(BORDER_COLOR, 1, true));
/* 162 */     GridBagConstraints gbcPanelSpotOptions = new GridBagConstraints();
/* 163 */     gbcPanelSpotOptions.gridwidth = 2;
/* 164 */     gbcPanelSpotOptions.insets = new Insets(0, 5, 5, 5);
/* 165 */     gbcPanelSpotOptions.fill = 1;
/* 166 */     gbcPanelSpotOptions.gridx = 0;
/* 167 */     gbcPanelSpotOptions.gridy = 2;
/* 168 */     add(panelSpotOptions, gbcPanelSpotOptions);
/* 169 */     GridBagLayout gblPanelSpotOptions = new GridBagLayout();
/* 170 */     gblPanelSpotOptions.columnWeights = new double[] { 0.0D, 1.0D };
/* 171 */     gblPanelSpotOptions.rowWeights = new double[] { 0.0D, 0.0D };
/* 172 */     panelSpotOptions.setLayout(gblPanelSpotOptions);
/*     */     
/* 174 */     JLabel lblSpotRadius = new JLabel("Spot display radius ratio:");
/* 175 */     lblSpotRadius.setFont(Fonts.SMALL_FONT);
/* 176 */     GridBagConstraints gbcLblSpotRadius = new GridBagConstraints();
/* 177 */     gbcLblSpotRadius.anchor = 13;
/* 178 */     gbcLblSpotRadius.insets = new Insets(5, 5, 0, 5);
/* 179 */     gbcLblSpotRadius.gridx = 0;
/* 180 */     gbcLblSpotRadius.gridy = 0;
/* 181 */     panelSpotOptions.add(lblSpotRadius, gbcLblSpotRadius);
/*     */     
/* 183 */     JFormattedTextField ftfSpotRadius = new JFormattedTextField();
/* 184 */     GuiUtils.selectAllOnFocus(ftfSpotRadius);
/* 185 */     ftfSpotRadius.setHorizontalAlignment(0);
/* 186 */     ftfSpotRadius.setFont(Fonts.SMALL_FONT);
/* 187 */     ftfSpotRadius.setMinimumSize(new Dimension(80, 20));
/* 188 */     ftfSpotRadius.setColumns(5);
/* 189 */     GridBagConstraints gbcFtfSpotRadius = new GridBagConstraints();
/* 190 */     gbcFtfSpotRadius.insets = new Insets(5, 0, 0, 0);
/* 191 */     gbcFtfSpotRadius.anchor = 17;
/* 192 */     gbcFtfSpotRadius.gridx = 1;
/* 193 */     gbcFtfSpotRadius.gridy = 0;
/* 194 */     panelSpotOptions.add(ftfSpotRadius, gbcFtfSpotRadius);
/*     */     
/* 196 */     JLabel lblSpotName = new JLabel("Display spot names:");
/* 197 */     lblSpotName.setFont(Fonts.SMALL_FONT);
/* 198 */     GridBagConstraints gbcLblSpotName = new GridBagConstraints();
/* 199 */     gbcLblSpotName.anchor = 13;
/* 200 */     gbcLblSpotName.insets = new Insets(0, 0, 0, 5);
/* 201 */     gbcLblSpotName.gridx = 0;
/* 202 */     gbcLblSpotName.gridy = 1;
/* 203 */     panelSpotOptions.add(lblSpotName, gbcLblSpotName);
/*     */     
/* 205 */     JCheckBox chkboxSpotNames = new JCheckBox();
/* 206 */     GridBagConstraints gbcChkboxSpotNames = new GridBagConstraints();
/* 207 */     gbcChkboxSpotNames.anchor = 17;
/* 208 */     gbcChkboxSpotNames.gridx = 1;
/* 209 */     gbcChkboxSpotNames.gridy = 1;
/* 210 */     panelSpotOptions.add(chkboxSpotNames, gbcChkboxSpotNames);
/*     */     
/* 212 */     JPanel selectorForSpots = featureSelector.createSelectorForSpots();
/* 213 */     GridBagConstraints gbcCmbboxSpotColor = new GridBagConstraints();
/* 214 */     gbcCmbboxSpotColor.insets = new Insets(0, 5, 5, 5);
/* 215 */     gbcCmbboxSpotColor.fill = 1;
/* 216 */     gbcCmbboxSpotColor.gridwidth = 2;
/* 217 */     gbcCmbboxSpotColor.gridx = 0;
/* 218 */     gbcCmbboxSpotColor.gridy = 3;
/* 219 */     panelSpotOptions.add(selectorForSpots, gbcCmbboxSpotColor);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 225 */     JCheckBox chkboxDisplayTracks = new JCheckBox();
/* 226 */     chkboxDisplayTracks.setText("Display tracks");
/* 227 */     chkboxDisplayTracks.setFont(Fonts.FONT);
/* 228 */     GridBagConstraints gbcCheckBoxDisplayTracks = new GridBagConstraints();
/* 229 */     gbcCheckBoxDisplayTracks.anchor = 11;
/* 230 */     gbcCheckBoxDisplayTracks.fill = 2;
/* 231 */     gbcCheckBoxDisplayTracks.insets = new Insets(5, 5, 0, 5);
/* 232 */     gbcCheckBoxDisplayTracks.gridx = 0;
/* 233 */     gbcCheckBoxDisplayTracks.gridy = 3;
/* 234 */     add(chkboxDisplayTracks, gbcCheckBoxDisplayTracks);
/*     */     
/* 236 */     JComboBox<DisplaySettings.TrackDisplayMode> cmbboxTrackDisplayMode = new JComboBox<>(DisplaySettings.TrackDisplayMode.values());
/* 237 */     GridBagConstraints gbc_cmbboxTrackDisplayMode = new GridBagConstraints();
/* 238 */     gbc_cmbboxTrackDisplayMode.fill = 2;
/* 239 */     gbc_cmbboxTrackDisplayMode.insets = new Insets(5, 0, 0, 5);
/* 240 */     gbc_cmbboxTrackDisplayMode.gridx = 1;
/* 241 */     gbc_cmbboxTrackDisplayMode.gridy = 3;
/* 242 */     add(cmbboxTrackDisplayMode, gbc_cmbboxTrackDisplayMode);
/* 243 */     cmbboxTrackDisplayMode.setFont(Fonts.SMALL_FONT);
/* 244 */     cmbboxTrackDisplayMode.addActionListener(e -> ds.setTrackDisplayMode((DisplaySettings.TrackDisplayMode)cmbboxTrackDisplayMode.getSelectedItem()));
/* 245 */     cmbboxTrackDisplayMode.setSelectedItem(ds.getTrackDisplayMode());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 251 */     JPanel panelTrackOptions = new JPanel();
/* 252 */     panelTrackOptions.setBorder(new LineBorder(BORDER_COLOR, 1, true));
/* 253 */     GridBagConstraints gbcPanelTrackOptions = new GridBagConstraints();
/* 254 */     gbcPanelTrackOptions.gridwidth = 2;
/* 255 */     gbcPanelTrackOptions.insets = new Insets(0, 5, 5, 5);
/* 256 */     gbcPanelTrackOptions.fill = 1;
/* 257 */     gbcPanelTrackOptions.gridx = 0;
/* 258 */     gbcPanelTrackOptions.gridy = 4;
/* 259 */     add(panelTrackOptions, gbcPanelTrackOptions);
/* 260 */     GridBagLayout gblPanelTrackOptions = new GridBagLayout();
/* 261 */     gblPanelTrackOptions.columnWeights = new double[] { 0.0D, 0.0D, 1.0D };
/* 262 */     gblPanelTrackOptions.rowWeights = new double[] { 0.0D, 0.0D };
/* 263 */     panelTrackOptions.setLayout(gblPanelTrackOptions);
/*     */     
/* 265 */     JLabel lblFadeTracks = new JLabel("Fade tracks in time:");
/* 266 */     lblFadeTracks.setFont(Fonts.SMALL_FONT);
/* 267 */     GridBagConstraints gbcLblFadeTracks = new GridBagConstraints();
/* 268 */     gbcLblFadeTracks.anchor = 13;
/* 269 */     gbcLblFadeTracks.insets = new Insets(0, 5, 0, 5);
/* 270 */     gbcLblFadeTracks.gridx = 0;
/* 271 */     gbcLblFadeTracks.gridy = 0;
/* 272 */     panelTrackOptions.add(lblFadeTracks, gbcLblFadeTracks);
/*     */     
/* 274 */     JCheckBox chkboxFadeTracks = new JCheckBox();
/* 275 */     GridBagConstraints gbcChckbxFadeTracks = new GridBagConstraints();
/* 276 */     gbcChckbxFadeTracks.insets = new Insets(0, 0, 0, 5);
/* 277 */     gbcChckbxFadeTracks.anchor = 17;
/* 278 */     gbcChckbxFadeTracks.gridx = 1;
/* 279 */     gbcChckbxFadeTracks.gridy = 0;
/* 280 */     panelTrackOptions.add(chkboxFadeTracks, gbcChckbxFadeTracks);
/*     */     
/* 282 */     JLabel lblFadeRange = new JLabel("Fade range:");
/* 283 */     lblFadeRange.setFont(Fonts.SMALL_FONT);
/* 284 */     GridBagConstraints gbcLblFadeRange = new GridBagConstraints();
/* 285 */     gbcLblFadeRange.anchor = 13;
/* 286 */     gbcLblFadeRange.insets = new Insets(0, 0, 0, 5);
/* 287 */     gbcLblFadeRange.gridx = 0;
/* 288 */     gbcLblFadeRange.gridy = 1;
/* 289 */     panelTrackOptions.add(lblFadeRange, gbcLblFadeRange);
/*     */     
/* 291 */     int fadeTrackRange = Math.min(1000, Math.max(1, ds.getFadeTrackRange()));
/* 292 */     SpinnerNumberModel fadeTrackDepthModel = new SpinnerNumberModel(fadeTrackRange, 1, 1000, 1);
/* 293 */     JSpinner spinnerFadeRange = new JSpinner(fadeTrackDepthModel);
/* 294 */     spinnerFadeRange.setFont(Fonts.SMALL_FONT);
/* 295 */     GridBagConstraints gbcSpinnerFadeRange = new GridBagConstraints();
/* 296 */     gbcSpinnerFadeRange.insets = new Insets(0, 0, 0, 5);
/* 297 */     gbcSpinnerFadeRange.anchor = 17;
/* 298 */     gbcSpinnerFadeRange.gridx = 1;
/* 299 */     gbcSpinnerFadeRange.gridy = 1;
/* 300 */     panelTrackOptions.add(spinnerFadeRange, gbcSpinnerFadeRange);
/*     */     
/* 302 */     JLabel lblFadeRangeUnits = new JLabel("time-points");
/* 303 */     lblFadeRangeUnits.setFont(Fonts.SMALL_FONT);
/* 304 */     GridBagConstraints gbcFadeRangeUnit = new GridBagConstraints();
/* 305 */     gbcFadeRangeUnit.anchor = 17;
/* 306 */     gbcFadeRangeUnit.gridx = 2;
/* 307 */     gbcFadeRangeUnit.gridy = 1;
/* 308 */     panelTrackOptions.add(lblFadeRangeUnits, gbcFadeRangeUnit);
/*     */     
/* 310 */     JPanel selectorForTracks = featureSelector.createSelectorForTracks();
/* 311 */     GridBagConstraints gbcCmbboxTrackColor = new GridBagConstraints();
/* 312 */     gbcCmbboxTrackColor.insets = new Insets(5, 5, 5, 5);
/* 313 */     gbcCmbboxTrackColor.fill = 1;
/* 314 */     gbcCmbboxTrackColor.gridwidth = 3;
/* 315 */     gbcCmbboxTrackColor.gridx = 0;
/* 316 */     gbcCmbboxTrackColor.gridy = 3;
/* 317 */     panelTrackOptions.add(selectorForTracks, gbcCmbboxTrackColor);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 323 */     FlowLayout flowLayout = new FlowLayout(0, 5, 2);
/* 324 */     JPanel panelDrawingZDepth = new JPanel(flowLayout);
/* 325 */     panelDrawingZDepth.setBorder(new LineBorder(BORDER_COLOR, 1, true));
/* 326 */     GridBagConstraints gbcPanelDrawingZDepth = new GridBagConstraints();
/* 327 */     gbcPanelDrawingZDepth.gridwidth = 2;
/* 328 */     gbcPanelDrawingZDepth.insets = new Insets(0, 5, 5, 5);
/* 329 */     gbcPanelDrawingZDepth.fill = 1;
/* 330 */     gbcPanelDrawingZDepth.gridx = 0;
/* 331 */     gbcPanelDrawingZDepth.gridy = 5;
/* 332 */     add(panelDrawingZDepth, gbcPanelDrawingZDepth);
/*     */     
/* 334 */     JCheckBox chckbxLimitZDepth = new JCheckBox("Limit drawing Z depth");
/* 335 */     chckbxLimitZDepth.setFont(Fonts.SMALL_FONT);
/* 336 */     panelDrawingZDepth.add(chckbxLimitZDepth);
/*     */     
/* 338 */     SpinnerNumberModel numberModelDrawingZDepth = new SpinnerNumberModel(ds.getZDrawingDepth(), 0.5D, 5000.0D, 0.5D);
/* 339 */     JSpinner spinnerDrawingZDepth = new JSpinner(numberModelDrawingZDepth);
/* 340 */     spinnerDrawingZDepth.setFont(Fonts.SMALL_FONT);
/* 341 */     panelDrawingZDepth.add(spinnerDrawingZDepth);
/*     */     
/* 343 */     JLabel lblDrawingZDepthUnits = new JLabel(spaceUnits);
/* 344 */     lblDrawingZDepthUnits.setFont(Fonts.SMALL_FONT);
/* 345 */     panelDrawingZDepth.add(lblDrawingZDepthUnits);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 351 */     JPanel panelButtons = new JPanel();
/*     */ 
/*     */     
/* 354 */     JButton btnShowTrackScheme = new JButton(launchTrackSchemeAction);
/* 355 */     panelButtons.add(btnShowTrackScheme);
/* 356 */     btnShowTrackScheme.setFont(Fonts.FONT);
/*     */ 
/*     */     
/* 359 */     JButton btnShowTrackTables = new JButton(showTrackTablesAction);
/* 360 */     panelButtons.add(btnShowTrackTables);
/* 361 */     btnShowTrackTables.setFont(Fonts.FONT);
/*     */     
/* 363 */     JButton btnShowSpotTable = new JButton(showSpotTableAction);
/* 364 */     panelButtons.add(btnShowSpotTable);
/* 365 */     btnShowSpotTable.setFont(Fonts.FONT);
/*     */     
/* 367 */     GridBagConstraints gbcPanelButtons = new GridBagConstraints();
/* 368 */     gbcPanelButtons.gridwidth = 2;
/* 369 */     gbcPanelButtons.anchor = 15;
/* 370 */     gbcPanelButtons.fill = 2;
/* 371 */     gbcPanelButtons.gridx = 0;
/* 372 */     gbcPanelButtons.gridy = 7;
/* 373 */     add(panelButtons, gbcPanelButtons);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 379 */     chkboxDisplaySpots.addActionListener(e -> {
/*     */           setEnabled(panelSpotOptions, chkboxDisplaySpots.isSelected());
/*     */           chkboxDisplaySpotsAsRois.setEnabled(chkboxDisplaySpots.isSelected());
/*     */         });
/* 383 */     chkboxDisplayTracks.addActionListener(e -> {
/*     */           setEnabled(panelTrackOptions, chkboxDisplayTracks.isSelected());
/*     */           
/*     */           cmbboxTrackDisplayMode.setEnabled(chkboxDisplayTracks.isSelected());
/*     */         });
/* 388 */     ActionListener fadeTrackBtnEnable = e -> {
/* 389 */         boolean shouldBeEnabled = (chkboxDisplayTracks.isSelected() && cmbboxTrackDisplayMode.getSelectedItem() != DisplaySettings.TrackDisplayMode.FULL);
/*     */         
/*     */         chkboxFadeTracks.setEnabled(shouldBeEnabled);
/*     */       };
/* 393 */     chkboxDisplayTracks.addActionListener(fadeTrackBtnEnable);
/* 394 */     cmbboxTrackDisplayMode.addActionListener(fadeTrackBtnEnable);
/*     */     
/* 396 */     ActionListener fadeTrackRangeEnable = e -> {
/* 397 */         boolean shouldBeEnabled = (chkboxDisplayTracks.isSelected() && cmbboxTrackDisplayMode.getSelectedItem() != DisplaySettings.TrackDisplayMode.FULL && chkboxFadeTracks.isSelected());
/*     */ 
/*     */         
/*     */         spinnerFadeRange.setEnabled(shouldBeEnabled);
/*     */       };
/*     */     
/* 403 */     cmbboxTrackDisplayMode.addActionListener(fadeTrackRangeEnable);
/* 404 */     chkboxDisplayTracks.addActionListener(fadeTrackRangeEnable);
/* 405 */     chkboxFadeTracks.addActionListener(fadeTrackRangeEnable);
/*     */     
/* 407 */     chckbxLimitZDepth.addActionListener(e -> spinnerDrawingZDepth.setEnabled(chckbxLimitZDepth.isSelected()));
/*     */     
/* 409 */     chkboxDisplaySpots.addActionListener(e -> ds.setSpotVisible(chkboxDisplaySpots.isSelected()));
/* 410 */     ftfSpotRadius.addPropertyChangeListener("value", e -> ds.setSpotDisplayRadius(((Number)ftfSpotRadius.getValue()).doubleValue()));
/* 411 */     chkboxSpotNames.addActionListener(e -> ds.setSpotShowName(chkboxSpotNames.isSelected()));
/* 412 */     chkboxDisplayTracks.addActionListener(e -> ds.setTrackVisible(chkboxDisplayTracks.isSelected()));
/* 413 */     chkboxFadeTracks.addActionListener(e -> ds.setFadeTracks(chkboxFadeTracks.isSelected()));
/* 414 */     fadeTrackDepthModel.addChangeListener(e -> ds.setFadeTrackRange(fadeTrackDepthModel.getNumber().intValue()));
/* 415 */     numberModelDrawingZDepth.addChangeListener(e -> ds.setZDrawingDepth(((Number)numberModelDrawingZDepth.getValue()).doubleValue()));
/* 416 */     chckbxLimitZDepth.addActionListener(e -> ds.setZDrawingDepthLimited(chckbxLimitZDepth.isSelected()));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 422 */     DisplaySettings.UpdateListener l = () -> {
/*     */         chkboxDisplaySpots.setSelected(ds.isSpotVisible());
/*     */         
/*     */         chkboxDisplaySpotsAsRois.setSelected(ds.isSpotDisplayedAsRoi());
/*     */         chkboxSpotNames.setSelected(ds.isSpotShowName());
/*     */         chkboxDisplayTracks.setSelected(ds.isTrackVisible());
/*     */         chkboxFadeTracks.setSelected(ds.isFadeTracks());
/*     */         chckbxLimitZDepth.setSelected(ds.isZDrawingDepthLimited());
/*     */         ftfSpotRadius.setValue(Double.valueOf(ds.getSpotDisplayRadius()));
/*     */         fadeTrackDepthModel.setValue(Integer.valueOf(ds.getFadeTrackRange()));
/*     */         numberModelDrawingZDepth.setValue(Double.valueOf(ds.getZDrawingDepth()));
/*     */         cmbboxTrackDisplayMode.setSelectedItem(ds.getTrackDisplayMode());
/*     */         setEnabled(panelSpotOptions, chkboxDisplaySpots.isSelected());
/*     */         setEnabled(panelTrackOptions, chkboxDisplayTracks.isSelected());
/*     */       };
/* 437 */     l.displaySettingsChanged();
/* 438 */     ds.listeners().add(l);
/* 439 */     spinnerDrawingZDepth.setEnabled(chckbxLimitZDepth.isSelected());
/* 440 */     fadeTrackBtnEnable.actionPerformed(null);
/*     */   }
/*     */ 
/*     */   
/*     */   private static final void setEnabled(Container container, boolean enabled) {
/* 445 */     for (Component component : container.getComponents()) {
/*     */       
/* 447 */       if (!(component instanceof JSpinner) && !(component instanceof JCheckBox)) {
/*     */         
/* 449 */         component.setEnabled(enabled);
/* 450 */         if (component instanceof Container)
/* 451 */           setEnabled((Container)component, enabled); 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/gui/components/ConfigureViewsPanel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */