/*     */ package fiji.plugin.trackmate.visualization.trackscheme;
/*     */ 
/*     */ import com.mxgraph.model.mxCell;
/*     */ import com.mxgraph.model.mxICell;
/*     */ import com.mxgraph.util.mxConstants;
/*     */ import com.mxgraph.util.mxStyleUtils;
/*     */ import com.mxgraph.view.mxPerimeter;
/*     */ import com.mxgraph.view.mxStylesheet;
/*     */ import fiji.plugin.trackmate.Model;
/*     */ import fiji.plugin.trackmate.Spot;
/*     */ import fiji.plugin.trackmate.features.FeatureUtils;
/*     */ import fiji.plugin.trackmate.gui.displaysettings.DisplaySettings;
/*     */ import fiji.plugin.trackmate.visualization.FeatureColorGenerator;
/*     */ import java.awt.Color;
/*     */ import java.awt.Font;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.jgrapht.graph.DefaultWeightedEdge;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TrackSchemeStylist
/*     */ {
/*     */   private final Model model;
/*     */   private final DisplaySettings displaySettings;
/*     */   private final JGraphXAdapter graphx;
/*  59 */   private String globalStyle = "simple";
/*     */   
/*     */   private final Map<String, Object> simpleStyle;
/*     */   
/*     */   private final Map<String, Object> fullStyle;
/*     */   
/*     */   private final Map<String, Object> edgeStyle;
/*     */   
/*  67 */   static final List<String> VERTEX_STYLE_NAMES = new ArrayList<>();
/*     */   
/*     */   private static final String FULL_STYLE_NAME = "full";
/*     */   
/*     */   private static final String SIMPLE_STYLE_NAME = "simple";
/*     */   
/*     */   private static final String DEFAULT_STYLE_NAME = "simple";
/*     */   
/*  75 */   private static final Map<String, Object> FULL_VERTEX_STYLE = new HashMap<>();
/*     */   
/*  77 */   private static final Map<String, Object> SIMPLE_VERTEX_STYLE = new HashMap<>();
/*     */   
/*  79 */   private static final Map<String, Object> BASIC_EDGE_STYLE = new HashMap<>();
/*     */ 
/*     */   
/*     */   static {
/*  83 */     FULL_VERTEX_STYLE.put(mxConstants.STYLE_FILLCOLOR, "white");
/*  84 */     FULL_VERTEX_STYLE.put(mxConstants.STYLE_FONTCOLOR, "black");
/*  85 */     FULL_VERTEX_STYLE.put(mxConstants.STYLE_ALIGN, "right");
/*  86 */     FULL_VERTEX_STYLE.put(mxConstants.STYLE_SHAPE, "scaledLabel");
/*  87 */     FULL_VERTEX_STYLE.put(mxConstants.STYLE_IMAGE_ALIGN, "left");
/*  88 */     FULL_VERTEX_STYLE.put(mxConstants.STYLE_ROUNDED, Boolean.valueOf(true));
/*  89 */     FULL_VERTEX_STYLE.put(mxConstants.STYLE_PERIMETER, mxPerimeter.RectanglePerimeter);
/*  90 */     FULL_VERTEX_STYLE.put(mxConstants.STYLE_STROKECOLOR, "#FF00FF");
/*  91 */     FULL_VERTEX_STYLE.put(mxConstants.STYLE_NOLABEL, Boolean.valueOf(false));
/*     */     
/*  93 */     SIMPLE_VERTEX_STYLE.put(mxConstants.STYLE_SHAPE, "ellipse");
/*  94 */     SIMPLE_VERTEX_STYLE.put(mxConstants.STYLE_NOLABEL, Boolean.valueOf(true));
/*     */     
/*  96 */     BASIC_EDGE_STYLE.put(mxConstants.STYLE_SHAPE, "connector");
/*  97 */     BASIC_EDGE_STYLE.put(mxConstants.STYLE_ALIGN, "center");
/*  98 */     BASIC_EDGE_STYLE.put(mxConstants.STYLE_VERTICAL_ALIGN, "middle");
/*  99 */     BASIC_EDGE_STYLE.put(mxConstants.STYLE_STARTARROW, mxConstants.NONE);
/* 100 */     BASIC_EDGE_STYLE.put(mxConstants.STYLE_ENDARROW, mxConstants.NONE);
/* 101 */     BASIC_EDGE_STYLE.put(mxConstants.STYLE_STROKECOLOR, "#FF00FF");
/* 102 */     BASIC_EDGE_STYLE.put(mxConstants.STYLE_NOLABEL, Boolean.valueOf(true));
/*     */     
/* 104 */     VERTEX_STYLE_NAMES.add("simple");
/* 105 */     VERTEX_STYLE_NAMES.add("full");
/*     */   }
/*     */ 
/*     */   
/*     */   public TrackSchemeStylist(Model model, JGraphXAdapter graphx, DisplaySettings displaySettings) {
/* 110 */     this.model = model;
/* 111 */     this.graphx = graphx;
/* 112 */     this.displaySettings = displaySettings;
/*     */     
/* 114 */     this.simpleStyle = new HashMap<>(SIMPLE_VERTEX_STYLE);
/* 115 */     this.fullStyle = new HashMap<>(FULL_VERTEX_STYLE);
/* 116 */     this.edgeStyle = new HashMap<>(BASIC_EDGE_STYLE);
/*     */ 
/*     */     
/* 119 */     mxStylesheet styleSheet = graphx.getStylesheet();
/* 120 */     styleSheet.setDefaultEdgeStyle(this.edgeStyle);
/* 121 */     styleSheet.setDefaultVertexStyle(this.simpleStyle);
/* 122 */     styleSheet.putCellStyle("full", this.fullStyle);
/* 123 */     styleSheet.putCellStyle("simple", this.simpleStyle);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setStyle(String styleName) {
/* 128 */     if (!this.graphx.getStylesheet().getStyles().containsKey(styleName)) {
/* 129 */       throw new IllegalArgumentException("Unknown TrackScheme style: " + styleName);
/*     */     }
/* 131 */     this.globalStyle = styleName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void updateEdgeStyle(Collection<mxCell> edges) {
/* 143 */     FeatureColorGenerator<DefaultWeightedEdge> trackColorGenerator = FeatureUtils.createTrackColorGenerator(this.model, this.displaySettings);
/* 144 */     Color missingValueColor = this.displaySettings.getMissingValueColor();
/* 145 */     this.graphx.getModel().beginUpdate();
/*     */     
/*     */     try {
/* 148 */       for (mxCell cell : edges)
/*     */       {
/* 150 */         DefaultWeightedEdge edge = this.graphx.getEdgeFor((mxICell)cell);
/* 151 */         Color color = trackColorGenerator.color(edge);
/* 152 */         if (color == null) {
/* 153 */           color = missingValueColor;
/*     */         }
/* 155 */         String colorstr = Integer.toHexString(color.getRGB()).substring(2);
/* 156 */         String style = cell.getStyle();
/* 157 */         style = mxStyleUtils.setStyle(style, mxConstants.STYLE_STROKECOLOR, colorstr);
/* 158 */         style = mxStyleUtils.setStyle(style, mxConstants.STYLE_STROKEWIDTH, Float.toString((float)this.displaySettings.getLineThickness()));
/* 159 */         this.graphx.getModel().setStyle(cell, style);
/*     */       }
/*     */     
/*     */     } finally {
/*     */       
/* 164 */       this.graphx.getModel().endUpdate();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void updateVertexStyle(Collection<mxCell> vertices) {
/* 170 */     Font font = this.displaySettings.getFont();
/* 171 */     this.fullStyle.put(mxConstants.STYLE_FONTFAMILY, font.getFamily());
/* 172 */     this.fullStyle.put(mxConstants.STYLE_FONTSIZE, "" + font.getSize());
/* 173 */     this.fullStyle.put(mxConstants.STYLE_FONTSTYLE, "" + font.getStyle());
/*     */     
/* 175 */     FeatureColorGenerator<Spot> spotColorGenerator = FeatureUtils.createSpotColorGenerator(this.model, this.displaySettings);
/* 176 */     Color missingValueColor = this.displaySettings.getMissingValueColor();
/*     */     
/* 178 */     this.graphx.getModel().beginUpdate();
/*     */     
/*     */     try {
/* 181 */       for (mxCell vertex : vertices) {
/*     */         
/* 183 */         Spot spot = this.graphx.getSpotFor((mxICell)vertex);
/* 184 */         if (spot != null)
/*     */         {
/* 186 */           Color color = spotColorGenerator.color(spot);
/* 187 */           if (color == null) {
/* 188 */             color = missingValueColor;
/*     */           }
/* 190 */           String colorstr = Integer.toHexString(color.getRGB()).substring(2);
/* 191 */           String fillcolorstr = this.displaySettings.isTrackSchemeFillBox() ? colorstr : "white";
/* 192 */           setVertexStyle((mxICell)vertex, colorstr, fillcolorstr);
/*     */         }
/*     */       
/*     */       } 
/*     */     } finally {
/*     */       
/* 198 */       this.graphx.getModel().endUpdate();
/*     */     } 
/*     */   }
/*     */   
/*     */   private void setVertexStyle(mxICell vertex, String colorstr, String fillcolorstr) {
/*     */     int width, height;
/* 204 */     String targetStyle = vertex.getStyle();
/* 205 */     targetStyle = mxStyleUtils.removeAllStylenames(targetStyle);
/* 206 */     targetStyle = mxStyleUtils.setStyle(targetStyle, mxConstants.STYLE_STROKECOLOR, colorstr);
/*     */ 
/*     */ 
/*     */     
/* 210 */     if (this.globalStyle.equals("simple")) {
/*     */       
/* 212 */       targetStyle = mxStyleUtils.setStyle(targetStyle, mxConstants.STYLE_FILLCOLOR, colorstr);
/* 213 */       width = 40;
/* 214 */       height = width;
/*     */     }
/*     */     else {
/*     */       
/* 218 */       targetStyle = mxStyleUtils.setStyle(targetStyle, mxConstants.STYLE_FILLCOLOR, fillcolorstr);
/* 219 */       width = 128;
/* 220 */       height = 40;
/*     */     } 
/* 222 */     targetStyle = this.globalStyle + ";" + targetStyle;
/*     */     
/* 224 */     this.graphx.getModel().setStyle(vertex, targetStyle);
/* 225 */     this.graphx.getModel().getGeometry(vertex).setWidth(width);
/* 226 */     this.graphx.getModel().getGeometry(vertex).setHeight(height);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/visualization/trackscheme/TrackSchemeStylist.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */