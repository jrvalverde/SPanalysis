/*     */ package fiji.plugin.trackmate.gui.displaysettings;
/*     */ 
/*     */ import com.google.gson.Gson;
/*     */ import com.google.gson.GsonBuilder;
/*     */ import com.google.gson.JsonDeserializationContext;
/*     */ import com.google.gson.JsonDeserializer;
/*     */ import com.google.gson.JsonElement;
/*     */ import com.google.gson.JsonParseException;
/*     */ import com.google.gson.JsonPrimitive;
/*     */ import com.google.gson.JsonSerializationContext;
/*     */ import com.google.gson.JsonSerializer;
/*     */ import java.awt.Color;
/*     */ import java.io.File;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.FileReader;
/*     */ import java.io.FileWriter;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Type;
/*     */ import java.nio.file.Files;
/*     */ import java.nio.file.Paths;
/*     */ import java.util.stream.Collectors;
/*     */ import org.jdom2.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DisplaySettingsIO
/*     */ {
/*  50 */   private static File userDefaultFile = new File(new File(System.getProperty("user.home"), ".trackmate"), "userdefaultsettings.json");
/*     */ 
/*     */   
/*     */   public static void toXML(DisplaySettings ds, Element dsel) {
/*  54 */     dsel.setText(toJson(ds));
/*     */   }
/*     */ 
/*     */   
/*     */   public static String toJson(DisplaySettings ds) {
/*  59 */     return getGson().toJson(ds);
/*     */   }
/*     */ 
/*     */   
/*     */   public static DisplaySettings fromJson(String str) {
/*  64 */     DisplaySettings ds = (str == null || str.isEmpty()) ? readUserDefault() : (DisplaySettings)getGson().fromJson(str, DisplaySettings.class);
/*     */ 
/*     */     
/*  67 */     double spotMin = ds.getSpotMin();
/*  68 */     double spotMax = ds.getSpotMax();
/*  69 */     ds.setSpotMinMax(Math.min(spotMin, spotMax), Math.max(spotMin, spotMax));
/*  70 */     double trackMin = ds.getTrackMin();
/*  71 */     double trackMax = ds.getTrackMax();
/*  72 */     ds.setTrackMinMax(Math.min(trackMin, trackMax), Math.max(trackMin, trackMax));
/*     */     
/*  74 */     return ds;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static Gson getGson() {
/*  80 */     GsonBuilder builder = new GsonBuilder();
/*  81 */     builder.registerTypeAdapter(Colormap.class, new ColormapSerializer());
/*  82 */     builder.registerTypeAdapter(Color.class, new ColorSerializer());
/*  83 */     return builder.setPrettyPrinting().create();
/*     */   }
/*     */ 
/*     */   
/*     */   public static void saveToUserDefault(DisplaySettings ds) {
/*  88 */     String str = toJson(ds);
/*     */     
/*  90 */     if (!userDefaultFile.exists()) {
/*  91 */       userDefaultFile.getParentFile().mkdirs();
/*     */     }
/*  93 */     try (FileWriter writer = new FileWriter(userDefaultFile)) {
/*     */       
/*  95 */       writer.append(str);
/*     */     }
/*  97 */     catch (IOException e) {
/*     */       
/*  99 */       System.err.println("Could not write the user default settings to " + userDefaultFile);
/* 100 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static DisplaySettings readUserDefault() {
/* 106 */     if (!userDefaultFile.exists()) {
/*     */       
/* 108 */       DisplaySettings ds = DisplaySettings.defaultStyle().copy("User-default");
/* 109 */       saveToUserDefault(ds);
/* 110 */       return ds;
/*     */     } 
/*     */     
/* 113 */     try (FileReader reader = new FileReader(userDefaultFile)) {
/*     */ 
/*     */       
/* 116 */       String str = Files.lines(Paths.get(userDefaultFile.getAbsolutePath(), new String[0])).collect(Collectors.joining(System.lineSeparator()));
/*     */       
/* 118 */       return fromJson(str);
/*     */     }
/* 120 */     catch (FileNotFoundException e) {
/*     */       
/* 122 */       System.err.println("Could not find the user default settings file: " + userDefaultFile + ". Using built-in default setting.");
/*     */       
/* 124 */       e.printStackTrace();
/*     */     }
/* 126 */     catch (IOException e) {
/*     */       
/* 128 */       System.err.println("Could not read the user default settings file: " + userDefaultFile + ". Using built-in default setting.");
/*     */       
/* 130 */       e.printStackTrace();
/*     */     } 
/* 132 */     return DisplaySettings.defaultStyle().copy();
/*     */   }
/*     */   
/*     */   private static final class ColormapSerializer
/*     */     implements JsonSerializer<Colormap>, JsonDeserializer<Colormap>
/*     */   {
/*     */     private ColormapSerializer() {}
/*     */     
/*     */     public JsonElement serialize(Colormap src, Type typeOfSrc, JsonSerializationContext context) {
/* 141 */       JsonPrimitive cmapObj = new JsonPrimitive(src.getName());
/* 142 */       return (JsonElement)cmapObj;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Colormap deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context) throws JsonParseException {
/* 148 */       String name = json.getAsString();
/* 149 */       for (Colormap colormap : Colormap.getAvailableLUTs()) {
/*     */         
/* 151 */         if (colormap.getName().equals(name))
/* 152 */           return colormap; 
/*     */       } 
/* 154 */       return DisplaySettings.defaultStyle().getColormap();
/*     */     }
/*     */   }
/*     */   
/*     */   private static final class ColorSerializer
/*     */     implements JsonSerializer<Color>, JsonDeserializer<Color>
/*     */   {
/*     */     private ColorSerializer() {}
/*     */     
/*     */     public JsonElement serialize(Color src, Type typeOfSrc, JsonSerializationContext context) {
/* 164 */       String colorStr = String.format("%d, %d, %d, %d", new Object[] {
/* 165 */             Integer.valueOf(src.getRed()), 
/* 166 */             Integer.valueOf(src.getGreen()), 
/* 167 */             Integer.valueOf(src.getBlue()), 
/* 168 */             Integer.valueOf(src.getAlpha()) });
/* 169 */       return (JsonElement)new JsonPrimitive(colorStr);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Color deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context) throws JsonParseException {
/* 175 */       String str = json.getAsString();
/* 176 */       String[] split = str.split(",");
/* 177 */       if (split.length != 4) {
/* 178 */         return Color.WHITE;
/*     */       }
/*     */ 
/*     */       
/*     */       try {
/* 183 */         int[] rgba = new int[4];
/* 184 */         for (int i = 0; i < rgba.length; i++) {
/* 185 */           rgba[i] = Integer.parseInt(split[i].trim());
/*     */         }
/* 187 */         return new Color(rgba[0], rgba[1], rgba[2], rgba[3]);
/*     */       }
/* 189 */       catch (NumberFormatException nfe) {
/*     */         
/* 191 */         nfe.printStackTrace();
/* 192 */         return Color.WHITE;
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static void main(String[] args) {
/* 199 */     System.out.println(readUserDefault());
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/gui/displaysettings/DisplaySettingsIO.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */