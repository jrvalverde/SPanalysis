/*     */ package fiji.plugin.trackmate.util;
/*     */ 
/*     */ import fiji.plugin.trackmate.Spot;
/*     */ import fiji.plugin.trackmate.SpotRoi;
/*     */ import fiji.plugin.trackmate.detection.DetectionUtils;
/*     */ import java.util.Iterator;
/*     */ import net.imagej.ImgPlus;
/*     */ import net.imagej.ImgPlusMetadata;
/*     */ import net.imglib2.Cursor;
/*     */ import net.imglib2.FinalInterval;
/*     */ import net.imglib2.Interval;
/*     */ import net.imglib2.IterableInterval;
/*     */ import net.imglib2.Localizable;
/*     */ import net.imglib2.RandomAccess;
/*     */ import net.imglib2.RandomAccessible;
/*     */ import net.imglib2.RandomAccessibleInterval;
/*     */ import net.imglib2.RealCursor;
/*     */ import net.imglib2.RealLocalizable;
/*     */ import net.imglib2.Sampler;
/*     */ import net.imglib2.type.numeric.RealType;
/*     */ import net.imglib2.util.Intervals;
/*     */ import net.imglib2.util.Util;
/*     */ import net.imglib2.view.IntervalView;
/*     */ import net.imglib2.view.Views;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SpotUtil
/*     */ {
/*     */   public static final <T extends RealType<T>> IterableInterval<T> iterable(SpotRoi roi, RealLocalizable center, ImgPlus<T> img) {
/*  49 */     SpotRoiIterable<T> neighborhood = new SpotRoiIterable<>(roi, center, img);
/*  50 */     if (neighborhood.dimension(0) <= 1L && neighborhood.dimension(1) <= 1L) {
/*  51 */       return makeSinglePixelIterable(center, img);
/*     */     }
/*  53 */     return neighborhood;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static final <T extends RealType<T>> IterableInterval<T> iterable(Spot spot, ImgPlus<T> img) {
/*  59 */     SpotRoi roi = spot.getRoi();
/*  60 */     if (null != roi && DetectionUtils.is2D(img))
/*     */     {
/*     */       
/*  63 */       return iterable(roi, (RealLocalizable)spot, img);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*  68 */     SpotNeighborhood<T> neighborhood = new SpotNeighborhood<>(spot, img);
/*     */     
/*  70 */     int npixels = (int)neighborhood.size();
/*  71 */     if (npixels <= 1) {
/*  72 */       return makeSinglePixelIterable((RealLocalizable)spot, img);
/*     */     }
/*  74 */     return (IterableInterval<T>)neighborhood;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static <T> IterableInterval<T> makeSinglePixelIterable(RealLocalizable center, ImgPlus<T> img) {
/*  80 */     double[] calibration = TMUtils.getSpatialCalibration((ImgPlusMetadata)img);
/*  81 */     long[] min = new long[img.numDimensions()];
/*  82 */     long[] max = new long[img.numDimensions()];
/*  83 */     for (int d = 0; d < min.length; d++) {
/*     */       
/*  85 */       long cx = Math.round(center.getDoublePosition(d) / calibration[d]);
/*  86 */       min[d] = cx;
/*  87 */       max[d] = cx + 1L;
/*     */     } 
/*     */     
/*  90 */     FinalInterval finalInterval = new FinalInterval(min, max);
/*  91 */     return (IterableInterval<T>)Views.interval((RandomAccessible)img, (Interval)finalInterval);
/*     */   }
/*     */ 
/*     */   
/*     */   private static final class SpotRoiIterable<T extends RealType<T>>
/*     */     implements IterableInterval<T>
/*     */   {
/*     */     private final SpotRoi roi;
/*     */     
/*     */     private final RealLocalizable center;
/*     */     
/*     */     private final ImgPlus<T> img;
/*     */     
/*     */     private final FinalInterval interval;
/*     */     
/*     */     public SpotRoiIterable(SpotRoi roi, RealLocalizable center, ImgPlus<T> img) {
/* 107 */       this.roi = roi;
/* 108 */       this.center = center;
/* 109 */       this.img = img;
/* 110 */       double[] x = roi.toPolygonX(img.averageScale(0), 0.0D, center.getDoublePosition(0), 1.0D);
/* 111 */       double[] y = roi.toPolygonX(img.averageScale(1), 0.0D, center.getDoublePosition(1), 1.0D);
/* 112 */       long minX = (long)Math.floor(Util.min(x));
/* 113 */       long maxX = (long)Math.ceil(Util.max(x));
/* 114 */       long minY = (long)Math.floor(Util.min(y));
/* 115 */       long maxY = (long)Math.ceil(Util.max(y));
/* 116 */       this.interval = Intervals.createMinMax(new long[] { minX, minY, maxX, maxY });
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public long size() {
/* 122 */       int n = 0;
/* 123 */       Cursor<T> cursor = cursor();
/* 124 */       while (cursor.hasNext()) {
/*     */         
/* 126 */         cursor.fwd();
/* 127 */         n++;
/*     */       } 
/* 129 */       return n;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public T firstElement() {
/* 135 */       return (T)cursor().next();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Object iterationOrder() {
/* 141 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public double realMin(int d) {
/* 147 */       return this.interval.realMin(d);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public double realMax(int d) {
/* 153 */       return this.interval.realMax(d);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public int numDimensions() {
/* 159 */       return 2;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public long min(int d) {
/* 165 */       return this.interval.min(d);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public long max(int d) {
/* 171 */       return this.interval.max(d);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Cursor<T> cursor() {
/* 177 */       return new SpotUtil.MyCursor<>(this.roi, this.center, this.img);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Cursor<T> localizingCursor() {
/* 183 */       return cursor();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Iterator<T> iterator() {
/* 189 */       return (Iterator<T>)cursor();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static final class MyCursor<T extends RealType<T>>
/*     */     implements Cursor<T>
/*     */   {
/*     */     private final SpotRoi roi;
/*     */     
/*     */     private final RealLocalizable center;
/*     */     
/*     */     private final ImgPlus<T> img;
/*     */     
/*     */     private final FinalInterval interval;
/*     */     
/*     */     private Cursor<T> cursor;
/*     */     
/*     */     private final double[] x;
/*     */     
/*     */     private final double[] y;
/*     */     
/*     */     private boolean hasNext;
/*     */     
/*     */     private RandomAccess<T> ra;
/*     */     
/*     */     public MyCursor(SpotRoi roi, RealLocalizable center, ImgPlus<T> img) {
/* 216 */       this.roi = roi;
/* 217 */       this.center = center;
/* 218 */       this.img = img;
/* 219 */       this.x = roi.toPolygonX(img.averageScale(0), 0.0D, center.getDoublePosition(0), 1.0D);
/* 220 */       this.y = roi.toPolygonY(img.averageScale(1), 0.0D, center.getDoublePosition(1), 1.0D);
/* 221 */       long minX = (long)Math.floor(Util.min(this.x));
/* 222 */       long maxX = (long)Math.ceil(Util.max(this.x));
/* 223 */       long minY = (long)Math.floor(Util.min(this.y));
/* 224 */       long maxY = (long)Math.ceil(Util.max(this.y));
/* 225 */       this.interval = Intervals.createMinMax(new long[] { minX, minY, maxX, maxY });
/* 226 */       reset();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public T get() {
/* 232 */       return (T)this.ra.get();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void fwd() {
/* 238 */       this.ra.setPosition((Localizable)this.cursor);
/* 239 */       fetch();
/*     */     }
/*     */ 
/*     */     
/*     */     private void fetch() {
/* 244 */       while (this.cursor.hasNext()) {
/*     */         
/* 246 */         this.cursor.fwd();
/* 247 */         if (isInside((Localizable)this.cursor, this.x, this.y)) {
/*     */           
/* 249 */           this.hasNext = this.cursor.hasNext();
/*     */           return;
/*     */         } 
/*     */       } 
/* 253 */       this.hasNext = false;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     private static final boolean isInside(Localizable localizable, double[] x, double[] y) {
/* 259 */       double xl = localizable.getDoublePosition(0);
/* 260 */       double yl = localizable.getDoublePosition(1);
/*     */ 
/*     */ 
/*     */       
/* 264 */       boolean inside = false; int j;
/* 265 */       for (int i = 0; i < x.length; j = i++) {
/*     */         
/* 267 */         double xj = x[j];
/* 268 */         double yj = y[j];
/*     */         
/* 270 */         double xi = x[i];
/* 271 */         double yi = y[i];
/*     */         
/* 273 */         if (((yi > yl) ? true : false) != ((yj > yl) ? true : false) && xl < (xj - xi) * (yl - yi) / (yj - yi) + xi)
/* 274 */           inside = !inside; 
/*     */       } 
/* 276 */       return inside;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void reset() {
/* 282 */       IntervalView<T> view = Views.interval((RandomAccessible)this.img, (Interval)this.interval);
/* 283 */       this.cursor = view.localizingCursor();
/* 284 */       this.ra = (RandomAccess<T>)Views.extendMirrorSingle((RandomAccessibleInterval)this.img).randomAccess();
/* 285 */       fetch();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public double getDoublePosition(int d) {
/* 291 */       return this.ra.getDoublePosition(d);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public int numDimensions() {
/* 297 */       return 2;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void jumpFwd(long steps) {
/* 303 */       for (int i = 0; i < steps; i++) {
/* 304 */         fwd();
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean hasNext() {
/* 310 */       return this.hasNext;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public T next() {
/* 316 */       fwd();
/* 317 */       return get();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public long getLongPosition(int d) {
/* 323 */       return this.ra.getLongPosition(d);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Cursor<T> copyCursor() {
/* 329 */       return new MyCursor(this.roi, this.center, this.img);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Sampler<T> copy() {
/* 335 */       return (Sampler<T>)copyCursor();
/*     */     }
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/util/SpotUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */