/*     */ package fiji.plugin.trackmate.gui.components;
/*     */ 
/*     */ import fiji.plugin.trackmate.gui.Fonts;
/*     */ import java.awt.Component;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.swing.AbstractAction;
/*     */ import javax.swing.Action;
/*     */ import javax.swing.ActionMap;
/*     */ import javax.swing.DefaultComboBoxModel;
/*     */ import javax.swing.InputMap;
/*     */ import javax.swing.JComboBox;
/*     */ import javax.swing.JFrame;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JList;
/*     */ import javax.swing.KeyStroke;
/*     */ import javax.swing.ListCellRenderer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CategoryJComboBox<K, V>
/*     */   extends JComboBox<Object>
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   protected static final String INDENT = "  ";
/*  76 */   private final HashSet<Integer> categoryIndexSet = new HashSet<>();
/*     */ 
/*     */   
/*     */   private boolean isCategoryIndex = false;
/*     */ 
/*     */   
/*     */   private Map<V, String> itemNames;
/*     */ 
/*     */   
/*     */   private final HashMap<V, K> invertMap;
/*     */ 
/*     */   
/*     */   private Map<K, String> categoryNames;
/*     */ 
/*     */ 
/*     */   
/*     */   public CategoryJComboBox(Map<K, Collection<V>> items, Map<V, String> itemNames, Map<K, String> categoryNames) {
/*  93 */     this.invertMap = new HashMap<>();
/*  94 */     setItems(items, itemNames, categoryNames);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setItems(Map<K, Collection<V>> items, Map<V, String> itemNames, Map<K, String> categoryNames) {
/*  99 */     this.invertMap.clear();
/* 100 */     this.categoryIndexSet.clear();
/*     */     
/* 102 */     this.itemNames = itemNames;
/* 103 */     this.categoryNames = categoryNames;
/*     */     
/* 105 */     V previous = getSelectedItem();
/* 106 */     DefaultComboBoxModel<Object> model = new DefaultComboBoxModel();
/*     */ 
/*     */     
/* 109 */     for (K category : items.keySet()) {
/*     */       
/* 111 */       model.addElement(category);
/* 112 */       this.categoryIndexSet.add(Integer.valueOf(model.getSize() - 1));
/*     */       
/* 114 */       Collection<V> categoryItems = items.get(category);
/* 115 */       for (V item : categoryItems) {
/*     */         
/* 117 */         model.addElement(item);
/* 118 */         this.invertMap.put(item, category);
/*     */       } 
/*     */     } 
/*     */     
/* 122 */     setModel(model);
/* 123 */     init();
/*     */ 
/*     */     
/* 126 */     if (previous != null) {
/*     */       
/* 128 */       setSelectedItem(previous);
/*     */ 
/*     */     
/*     */     }
/* 132 */     else if (items.size() > 0) {
/* 133 */       setSelectedItem(((Collection)items.get(items.keySet().iterator().next())).iterator().next());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public K getSelectedCategory() {
/* 143 */     Object obj = getSelectedItem();
/* 144 */     return this.invertMap.get(obj);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setDisableIndex(HashSet<Integer> set) {
/* 149 */     this.categoryIndexSet.clear();
/* 150 */     for (Integer i : set)
/*     */     {
/* 152 */       this.categoryIndexSet.add(i);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPopupVisible(boolean v) {
/* 159 */     if (!v && this.isCategoryIndex) {
/*     */       
/* 161 */       this.isCategoryIndex = false;
/*     */     }
/*     */     else {
/*     */       
/* 165 */       super.setPopupVisible(v);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public V getSelectedItem() {
/* 173 */     return (V)super.getSelectedItem();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSelectedIndex(int index) {
/* 179 */     if (this.categoryIndexSet.contains(Integer.valueOf(index))) {
/*     */       
/* 181 */       this.isCategoryIndex = true;
/*     */     }
/*     */     else {
/*     */       
/* 185 */       super.setSelectedIndex(index);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void init() {
/* 199 */     setFont(Fonts.SMALL_FONT);
/* 200 */     final ListCellRenderer<Object> r = (ListCellRenderer)getRenderer();
/* 201 */     setRenderer(new ListCellRenderer()
/*     */         {
/*     */           public Component getListCellRendererComponent(JList<? extends Object> list, Object value, int index, boolean isSelected, boolean cellHasFocus)
/*     */           {
/*     */             JLabel c;
/*     */             
/* 207 */             if (CategoryJComboBox.this.categoryIndexSet.contains(Integer.valueOf(index))) {
/*     */               
/* 209 */               c = (JLabel)r.getListCellRendererComponent(list, value, index, false, false);
/* 210 */               c.setEnabled(false);
/* 211 */               c.setFont(Fonts.SMALL_FONT.deriveFont(1));
/* 212 */               c.setText((String)CategoryJComboBox.this.categoryNames.get(value));
/*     */             }
/*     */             else {
/*     */               
/* 216 */               c = (JLabel)r.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
/* 217 */               c.setEnabled(true);
/* 218 */               c.setFont(Fonts.SMALL_FONT);
/* 219 */               c.setText("  " + (String)CategoryJComboBox.this.itemNames.get(value));
/*     */             } 
/* 221 */             return c;
/*     */           }
/*     */         });
/*     */     
/* 225 */     Action up = new AbstractAction()
/*     */       {
/*     */         private static final long serialVersionUID = 1L;
/*     */ 
/*     */ 
/*     */         
/*     */         public void actionPerformed(ActionEvent e) {
/* 232 */           int si = CategoryJComboBox.this.getSelectedIndex();
/* 233 */           for (int i = si - 1; i >= 0; i--) {
/*     */             
/* 235 */             if (!CategoryJComboBox.this.categoryIndexSet.contains(Integer.valueOf(i))) {
/*     */               
/* 237 */               CategoryJComboBox.this.setSelectedIndex(i);
/*     */               break;
/*     */             } 
/*     */           } 
/*     */         }
/*     */       };
/* 243 */     Action down = new AbstractAction()
/*     */       {
/*     */         private static final long serialVersionUID = 1L;
/*     */ 
/*     */ 
/*     */         
/*     */         public void actionPerformed(ActionEvent e) {
/* 250 */           int si = CategoryJComboBox.this.getSelectedIndex();
/* 251 */           for (int i = si + 1; i < CategoryJComboBox.this.getModel().getSize(); i++) {
/*     */             
/* 253 */             if (!CategoryJComboBox.this.categoryIndexSet.contains(Integer.valueOf(i))) {
/*     */               
/* 255 */               CategoryJComboBox.this.setSelectedIndex(i);
/*     */               
/*     */               break;
/*     */             } 
/*     */           } 
/*     */         }
/*     */       };
/* 262 */     ActionMap am = getActionMap();
/* 263 */     am.put("selectPrevious", up);
/* 264 */     am.put("selectNext", down);
/* 265 */     InputMap im = getInputMap();
/* 266 */     im.put(KeyStroke.getKeyStroke(38, 0), "selectPrevious");
/* 267 */     im.put(KeyStroke.getKeyStroke(224, 0), "selectPrevious");
/* 268 */     im.put(KeyStroke.getKeyStroke(40, 0), "selectNext");
/* 269 */     im.put(KeyStroke.getKeyStroke(225, 0), "selectNext");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void main(String[] args) {
/* 278 */     List<String> fruits = new ArrayList<>(5);
/* 279 */     fruits.add("Apple");
/* 280 */     fruits.add("Pear");
/* 281 */     fruits.add("Orange");
/* 282 */     fruits.add("Strawberry");
/*     */     
/* 284 */     List<String> cars = new ArrayList<>(3);
/* 285 */     cars.add("Peugeot");
/* 286 */     cars.add("Ferrari");
/* 287 */     cars.add("Ford");
/*     */     
/* 289 */     List<String> computers = new ArrayList<>(2);
/* 290 */     computers.add("PC");
/* 291 */     computers.add("Mac");
/*     */     
/* 293 */     LinkedHashMap<String, Collection<String>> items = new LinkedHashMap<>(3);
/* 294 */     items.put("Fruits", fruits);
/* 295 */     items.put("Cars", cars);
/* 296 */     items.put("Computers", computers);
/*     */     
/* 298 */     Map<String, String> itemNames = new HashMap<>();
/* 299 */     for (String key : items.keySet()) {
/*     */       
/* 301 */       for (String string : items.get(key))
/*     */       {
/* 303 */         itemNames.put(string, string);
/*     */       }
/*     */     } 
/*     */     
/* 307 */     Map<String, String> categoryNames = new HashMap<>();
/* 308 */     for (String key : items.keySet())
/*     */     {
/* 310 */       categoryNames.put(key, key);
/*     */     }
/*     */ 
/*     */     
/* 314 */     final CategoryJComboBox<String, String> cb = new CategoryJComboBox<>(items, itemNames, categoryNames);
/* 315 */     cb.addActionListener(new ActionListener()
/*     */         {
/*     */           
/*     */           public void actionPerformed(ActionEvent arg0)
/*     */           {
/* 320 */             System.out.println("Selected " + (String)cb.getSelectedItem() + " in category " + (String)cb.getSelectedCategory());
/*     */           }
/*     */         });
/*     */     
/* 324 */     JFrame frame = new JFrame();
/* 325 */     frame.getContentPane().add(cb);
/* 326 */     frame.setVisible(true);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/gui/components/CategoryJComboBox.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */