/*     */ package fiji.plugin.trackmate.features;
/*     */ 
/*     */ import fiji.plugin.trackmate.Dimension;
/*     */ import fiji.plugin.trackmate.Logger;
/*     */ import fiji.plugin.trackmate.Model;
/*     */ import fiji.plugin.trackmate.Settings;
/*     */ import fiji.plugin.trackmate.features.edges.EdgeAnalyzer;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import net.imglib2.algorithm.MultiThreadedBenchmarkAlgorithm;
/*     */ import org.jgrapht.graph.DefaultWeightedEdge;
/*     */ import org.scijava.Cancelable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EdgeFeatureCalculator
/*     */   extends MultiThreadedBenchmarkAlgorithm
/*     */   implements Cancelable
/*     */ {
/*     */   private static final String BASE_ERROR_MSG = "[EdgeFeatureCalculator] ";
/*     */   private final Settings settings;
/*     */   private final Model model;
/*     */   private boolean isCanceled;
/*     */   private String cancelReason;
/*     */   private final boolean doLogIt;
/*     */   
/*     */   public EdgeFeatureCalculator(Model model, Settings settings, boolean doLogIt) {
/*  62 */     this.settings = settings;
/*  63 */     this.model = model;
/*  64 */     this.doLogIt = doLogIt;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean checkInput() {
/*  74 */     if (null == this.model) {
/*     */       
/*  76 */       this.errorMessage = "[EdgeFeatureCalculator] Model object is null.";
/*  77 */       return false;
/*     */     } 
/*  79 */     if (null == this.settings) {
/*     */       
/*  81 */       this.errorMessage = "[EdgeFeatureCalculator] Settings object is null.";
/*  82 */       return false;
/*     */     } 
/*  84 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean process() {
/*  94 */     long start = System.currentTimeMillis();
/*     */ 
/*     */     
/*  97 */     for (EdgeAnalyzer analyzer : this.settings.getEdgeAnalyzers()) {
/*     */       
/*  99 */       Collection<String> features = analyzer.getFeatures();
/* 100 */       Map<String, String> featureNames = analyzer.getFeatureNames();
/* 101 */       Map<String, String> featureShortNames = analyzer.getFeatureShortNames();
/* 102 */       Map<String, Dimension> featureDimensions = analyzer.getFeatureDimensions();
/* 103 */       Map<String, Boolean> isIntFeature = analyzer.getIsIntFeature();
/* 104 */       this.model.getFeatureModel().declareEdgeFeatures(features, featureNames, featureShortNames, featureDimensions, isIntFeature);
/*     */     } 
/*     */ 
/*     */     
/* 108 */     computeEdgeFeaturesAgent(this.model.getTrackModel().edgeSet(), this.settings.getEdgeAnalyzers(), this.doLogIt);
/*     */     
/* 110 */     long end = System.currentTimeMillis();
/* 111 */     this.processingTime = end - start;
/* 112 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void computeEdgesFeatures(Collection<DefaultWeightedEdge> edges, boolean doLogIt) {
/* 127 */     List<EdgeAnalyzer> spotFeatureAnalyzers = this.settings.getEdgeAnalyzers();
/* 128 */     computeEdgeFeaturesAgent(edges, spotFeatureAnalyzers, doLogIt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void computeEdgeFeaturesAgent(Collection<DefaultWeightedEdge> edges, List<EdgeAnalyzer> analyzers, boolean doLogIt) {
/* 137 */     this.isCanceled = false;
/* 138 */     this.cancelReason = null;
/*     */     
/* 140 */     Logger logger = this.model.getLogger();
/* 141 */     if (doLogIt) {
/* 142 */       logger.log("Computing edge features:\n", Logger.BLUE_COLOR);
/*     */     }
/* 144 */     for (EdgeAnalyzer analyzer : analyzers) {
/*     */       
/* 146 */       if (isCanceled()) {
/*     */         return;
/*     */       }
/* 149 */       if (analyzer.isManualFeature()) {
/*     */         continue;
/*     */       }
/*     */ 
/*     */       
/* 154 */       analyzer.setNumThreads(this.numThreads);
/* 155 */       analyzer.process(edges, this.model);
/* 156 */       if (doLogIt) {
/* 157 */         logger.log("  - " + analyzer.getName() + " in " + analyzer.getProcessingTime() + " ms.\n");
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isCanceled() {
/* 166 */     return this.isCanceled;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void cancel(String reason) {
/* 172 */     this.isCanceled = true;
/* 173 */     this.cancelReason = reason;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getCancelReason() {
/* 179 */     return this.cancelReason;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/features/EdgeFeatureCalculator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */