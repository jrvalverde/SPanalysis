/*     */ package fiji.plugin.trackmate.action.fit;
/*     */ 
/*     */ import fiji.plugin.trackmate.Logger;
/*     */ import fiji.plugin.trackmate.Spot;
/*     */ import fiji.plugin.trackmate.util.TMUtils;
/*     */ import ij.ImagePlus;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.Executors;
/*     */ import java.util.concurrent.Future;
/*     */ import net.imagej.ImgPlus;
/*     */ import net.imglib2.Cursor;
/*     */ import net.imglib2.Point;
/*     */ import net.imglib2.RandomAccessible;
/*     */ import net.imglib2.RandomAccessibleInterval;
/*     */ import net.imglib2.img.Img;
/*     */ import net.imglib2.img.array.ArrayImg;
/*     */ import net.imglib2.img.array.ArrayImgs;
/*     */ import net.imglib2.img.basictypeaccess.array.DoubleArray;
/*     */ import net.imglib2.type.numeric.RealType;
/*     */ import net.imglib2.type.numeric.real.DoubleType;
/*     */ import net.imglib2.util.Util;
/*     */ import net.imglib2.view.IntervalView;
/*     */ import net.imglib2.view.Views;
/*     */ import org.apache.commons.math3.fitting.leastsquares.LevenbergMarquardtOptimizer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractSpotFitter
/*     */   implements SpotFitter
/*     */ {
/*     */   protected final ImgPlus<RealType> img;
/*     */   protected final int channel;
/*     */   protected final double[] calibration;
/*     */   protected final LevenbergMarquardtOptimizer optimizer;
/*  65 */   private final ConcurrentHashMap<Integer, RandomAccessibleInterval<RealType>> hyperslices = new ConcurrentHashMap<>();
/*     */ 
/*     */   
/*     */   private int numThreads;
/*     */   
/*  70 */   private long processingTime = -1L;
/*     */ 
/*     */ 
/*     */   
/*     */   public AbstractSpotFitter(ImagePlus imp, int channel) {
/*  75 */     this.channel = channel;
/*  76 */     this.img = TMUtils.rawWraps(imp);
/*  77 */     this.calibration = TMUtils.getSpatialCalibration(imp);
/*     */     
/*  79 */     this
/*     */       
/*  81 */       .optimizer = (new LevenbergMarquardtOptimizer()).withCostRelativeTolerance(1.0E-12D).withParameterRelativeTolerance(1.0E-12D);
/*  82 */     setNumThreads();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void process(Iterable<Spot> spots, Logger logger) {
/*  88 */     logger.log(String.format("Starting fitting with %d threads.\n", new Object[] { Integer.valueOf(this.numThreads) }));
/*  89 */     logger.setStatus("Spot fitting");
/*  90 */     long start = System.currentTimeMillis();
/*  91 */     ExecutorService executorService = Executors.newFixedThreadPool(this.numThreads);
/*  92 */     List<Future<?>> futures = new ArrayList<>();
/*  93 */     for (Spot spot : spots) {
/*  94 */       futures.add(executorService.submit(() -> fit(spot)));
/*     */     }
/*  96 */     int nspots = futures.size();
/*     */     
/*     */     try {
/*  99 */       int i = 0;
/* 100 */       for (Future<?> future : futures)
/*     */       {
/* 102 */         future.get();
/* 103 */         logger.setProgress(i++ / nspots);
/*     */       }
/*     */     
/* 106 */     } catch (InterruptedException|java.util.concurrent.ExecutionException e) {
/*     */       
/* 108 */       e.printStackTrace();
/*     */     } 
/* 110 */     executorService.shutdown();
/*     */     
/* 112 */     long stop = System.currentTimeMillis();
/* 113 */     this.processingTime = stop - start;
/* 114 */     logger.setStatus("");
/* 115 */     logger.setProgress(0.0D);
/* 116 */     logger.log(String.format("Fit completed for %d spots in %.1f s.\n", new Object[] { Integer.valueOf(nspots), Double.valueOf(this.processingTime / 1000.0D) }));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected RandomAccessibleInterval<RealType> getSlice(int frame) {
/* 122 */     return this.hyperslices
/* 123 */       .computeIfAbsent(
/* 124 */         Integer.valueOf(frame), t -> TMUtils.hyperSlice(this.img, this.channel, t.intValue()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setNumThreads() {
/* 134 */     setNumThreads(Math.max(1, Runtime.getRuntime().availableProcessors() / 2));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setNumThreads(int numThreads) {
/* 140 */     this.numThreads = numThreads;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getNumThreads() {
/* 146 */     return this.numThreads;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public long getProcessingTime() {
/* 152 */     return this.processingTime;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected static void clipBackground(Observation obs) {
/* 158 */     double bg = Util.median(obs.values); int i;
/* 159 */     for (i = 0; i < obs.values.length; i++)
/* 160 */       obs.values[i] = obs.values[i] - bg; 
/* 161 */     for (i = 0; i < obs.values.length; i++) {
/* 162 */       obs.values[i] = Math.max(0.0D, obs.values[i]);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected Observation gatherObservationData(Point point, long[] span, int frame) {
/* 168 */     RandomAccessibleInterval<RealType> slice = getSlice(frame);
/* 169 */     int ndims = point.numDimensions();
/*     */     
/* 171 */     long[] min = new long[point.numDimensions()];
/* 172 */     long[] max = new long[point.numDimensions()];
/* 173 */     for (int d = 0; d < max.length; d++) {
/*     */       
/* 175 */       min[d] = Math.max(point.getLongPosition(d) - span[d], slice.min(0));
/* 176 */       max[d] = Math.min(point.getLongPosition(d) + span[d], slice.max(0));
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 181 */     IntervalView<RealType> view = Views.interval((RandomAccessible)slice, min, max);
/* 182 */     int nel = (int)view.size();
/* 183 */     double[] vals = new double[nel];
/* 184 */     long[][] pos = new long[ndims][nel];
/*     */     
/* 186 */     Cursor<RealType> cursor = view.localizingCursor();
/* 187 */     int index = -1;
/* 188 */     while (cursor.hasNext()) {
/*     */       
/* 190 */       index++;
/* 191 */       cursor.fwd();
/* 192 */       vals[index] = ((RealType)cursor.get()).getRealDouble();
/* 193 */       for (int i = 0; i < ndims; i++)
/* 194 */         pos[i][index] = cursor.getLongPosition(i); 
/*     */     } 
/* 196 */     return new Observation(vals, pos);
/*     */   }
/*     */ 
/*     */   
/*     */   public abstract void fit(Spot paramSpot);
/*     */   
/*     */   protected static class Observation
/*     */   {
/*     */     public final double[] values;
/*     */     public final long[][] pos;
/*     */     
/*     */     private Observation(double[] values, long[][] pos) {
/* 208 */       this.values = values;
/* 209 */       this.pos = pos;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public String toString() {
/* 215 */       StringBuilder str = new StringBuilder(super.toString());
/* 216 */       str.append("\nvalues: " + Util.printCoordinates(this.values));
/* 217 */       for (int d = 0; d < this.pos.length; d++)
/* 218 */         str.append("\npos[" + d + "]: " + Util.printCoordinates(this.pos[d])); 
/* 219 */       return str.toString();
/*     */     }
/*     */ 
/*     */     
/*     */     public Img<DoubleType> toImg() {
/* 224 */       long[] dims = new long[this.pos.length];
/* 225 */       for (int d = 0; d < dims.length; d++) {
/*     */         
/* 227 */         long max = Arrays.stream(this.pos[d]).max().getAsLong();
/* 228 */         long min = Arrays.stream(this.pos[d]).min().getAsLong();
/* 229 */         dims[d] = max - min + 1L;
/*     */       } 
/* 231 */       ArrayImg<DoubleType, DoubleArray> img = ArrayImgs.doubles(this.values, dims);
/* 232 */       return (Img)img;
/*     */     }
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/action/fit/AbstractSpotFitter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */