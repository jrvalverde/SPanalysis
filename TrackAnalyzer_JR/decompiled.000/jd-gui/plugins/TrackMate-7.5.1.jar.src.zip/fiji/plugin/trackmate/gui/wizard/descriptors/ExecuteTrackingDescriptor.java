/*    */ package fiji.plugin.trackmate.gui.wizard.descriptors;
/*    */ 
/*    */ import fiji.plugin.trackmate.Logger;
/*    */ import fiji.plugin.trackmate.TrackMate;
/*    */ import fiji.plugin.trackmate.TrackModel;
/*    */ import fiji.plugin.trackmate.gui.components.LogPanel;
/*    */ import fiji.plugin.trackmate.gui.wizard.WizardPanelDescriptor;
/*    */ import java.awt.Component;
/*    */ import java.util.IntSummaryStatistics;
/*    */ import org.scijava.Cancelable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ExecuteTrackingDescriptor
/*    */   extends WizardPanelDescriptor
/*    */ {
/*    */   public static final String KEY = "ExecuteTracking";
/*    */   private final TrackMate trackmate;
/*    */   
/*    */   public ExecuteTrackingDescriptor(TrackMate trackmate, LogPanel logPanel) {
/* 43 */     super("ExecuteTracking");
/* 44 */     this.trackmate = trackmate;
/* 45 */     this.targetPanel = (Component)logPanel;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Runnable getForwardRunnable() {
/* 51 */     return () -> {
/*    */         long start = System.currentTimeMillis();
/*    */         this.trackmate.execTracking();
/*    */         long end = System.currentTimeMillis();
/*    */         Logger logger = this.trackmate.getModel().getLogger();
/*    */         logger.log(String.format("Tracking done in %.1f s.\n", new Object[] { Float.valueOf((float)(end - start) / 1000.0F) }));
/*    */         TrackModel trackModel = this.trackmate.getModel().getTrackModel();
/*    */         int nTracks = trackModel.nTracks(false);
/*    */         IntSummaryStatistics stats = trackModel.unsortedTrackIDs(false).stream().mapToInt(()).summaryStatistics();
/*    */         logger.log("Found " + nTracks + " tracks.\n");
/*    */         logger.log(String.format("  - avg size: %.1f spots.\n", new Object[] { Double.valueOf(stats.getAverage()) }));
/*    */         logger.log(String.format("  - min size: %d spots.\n", new Object[] { Integer.valueOf(stats.getMin()) }));
/*    */         logger.log(String.format("  - max size: %d spots.\n", new Object[] { Integer.valueOf(stats.getMax()) }));
/*    */       };
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Cancelable getCancelable() {
/* 73 */     return (Cancelable)this.trackmate;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/gui/wizard/descriptors/ExecuteTrackingDescriptor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */