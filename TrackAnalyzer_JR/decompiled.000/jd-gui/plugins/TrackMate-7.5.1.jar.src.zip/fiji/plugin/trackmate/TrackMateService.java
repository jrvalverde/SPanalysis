/*    */ package fiji.plugin.trackmate;
/*    */ 
/*    */ import net.imagej.ImageJService;
/*    */ import org.scijava.plugin.Parameter;
/*    */ import org.scijava.plugin.Plugin;
/*    */ import org.scijava.script.ScriptService;
/*    */ import org.scijava.service.AbstractService;
/*    */ import org.scijava.service.Service;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Plugin(type = Service.class)
/*    */ public class TrackMateService
/*    */   extends AbstractService
/*    */   implements ImageJService
/*    */ {
/*    */   @Parameter
/*    */   private ScriptService scriptService;
/*    */   
/*    */   public void initialize() {
/* 42 */     this.scriptService.addAlias(TrackMate.class);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/TrackMateService.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */