/*      */ package fiji.plugin.trackmate.io;
/*      */ 
/*      */ import fiji.plugin.trackmate.Dimension;
/*      */ import fiji.plugin.trackmate.FeatureModel;
/*      */ import fiji.plugin.trackmate.Logger;
/*      */ import fiji.plugin.trackmate.Model;
/*      */ import fiji.plugin.trackmate.SelectionModel;
/*      */ import fiji.plugin.trackmate.Settings;
/*      */ import fiji.plugin.trackmate.Spot;
/*      */ import fiji.plugin.trackmate.SpotCollection;
/*      */ import fiji.plugin.trackmate.SpotRoi;
/*      */ import fiji.plugin.trackmate.detection.SpotDetectorFactoryBase;
/*      */ import fiji.plugin.trackmate.features.FeatureFilter;
/*      */ import fiji.plugin.trackmate.features.edges.EdgeAnalyzer;
/*      */ import fiji.plugin.trackmate.features.spot.SpotAnalyzerFactory;
/*      */ import fiji.plugin.trackmate.features.spot.SpotAnalyzerFactoryBase;
/*      */ import fiji.plugin.trackmate.features.spot.SpotMorphologyAnalyzerFactory;
/*      */ import fiji.plugin.trackmate.features.track.TrackAnalyzer;
/*      */ import fiji.plugin.trackmate.gui.displaysettings.DisplaySettings;
/*      */ import fiji.plugin.trackmate.gui.displaysettings.DisplaySettingsIO;
/*      */ import fiji.plugin.trackmate.providers.DetectorProvider;
/*      */ import fiji.plugin.trackmate.providers.EdgeAnalyzerProvider;
/*      */ import fiji.plugin.trackmate.providers.SpotAnalyzerProvider;
/*      */ import fiji.plugin.trackmate.providers.SpotMorphologyAnalyzerProvider;
/*      */ import fiji.plugin.trackmate.providers.TrackAnalyzerProvider;
/*      */ import fiji.plugin.trackmate.providers.TrackerProvider;
/*      */ import fiji.plugin.trackmate.providers.ViewProvider;
/*      */ import fiji.plugin.trackmate.tracking.SpotTrackerFactory;
/*      */ import fiji.plugin.trackmate.visualization.TrackMateModelView;
/*      */ import fiji.plugin.trackmate.visualization.ViewFactory;
/*      */ import ij.IJ;
/*      */ import ij.ImagePlus;
/*      */ import java.io.File;
/*      */ import java.io.IOException;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import java.util.concurrent.ConcurrentHashMap;
/*      */ import org.jdom2.Attribute;
/*      */ import org.jdom2.DataConversionException;
/*      */ import org.jdom2.Document;
/*      */ import org.jdom2.Element;
/*      */ import org.jdom2.JDOMException;
/*      */ import org.jdom2.input.SAXBuilder;
/*      */ import org.jgrapht.graph.DefaultWeightedEdge;
/*      */ import org.jgrapht.graph.SimpleWeightedGraph;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class TmXmlReader
/*      */ {
/*      */   protected static final boolean DEBUG = true;
/*  160 */   protected Document document = null;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final File file;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ConcurrentHashMap<Integer, Spot> cache;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  175 */   protected Logger.StringBuilderLogger logger = new Logger.StringBuilderLogger();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final Element root;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean ok = true;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TmXmlReader(File file) {
/*  195 */     this.file = file;
/*  196 */     SAXBuilder sb = new SAXBuilder();
/*  197 */     Element r = null;
/*      */     
/*      */     try {
/*  200 */       this.document = sb.build(file);
/*  201 */       r = this.document.getRootElement();
/*      */     }
/*  203 */     catch (JDOMException e) {
/*      */       
/*  205 */       this.ok = false;
/*  206 */       this.logger.error("Problem parsing " + file.getName() + ", it is not a valid TrackMate XML file.\nError message is:\n" + e
/*  207 */           .getLocalizedMessage() + '\n');
/*      */     }
/*  209 */     catch (IOException e) {
/*      */       
/*  211 */       this.logger.error("Problem reading " + file.getName() + ".\nError message is:\n" + e
/*  212 */           .getLocalizedMessage() + '\n');
/*  213 */       this.ok = false;
/*      */     } 
/*  215 */     this.root = r;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getLog() {
/*  228 */     Element logElement = this.root.getChild("Log");
/*  229 */     if (null != logElement) {
/*  230 */       return logElement.getTextTrim();
/*      */     }
/*  232 */     return "";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getGUIState() {
/*  242 */     Element guiel = this.root.getChild("GUIState");
/*  243 */     if (null != guiel) {
/*      */       
/*  245 */       String guiState = guiel.getAttributeValue("state");
/*  246 */       if (null == guiState) {
/*      */         
/*  248 */         this.logger.error("Could not find GUI state attribute. Returning defaults.\n");
/*  249 */         this.ok = false;
/*  250 */         return "ConfigureViews";
/*      */       } 
/*  252 */       return guiState;
/*      */     } 
/*      */     
/*  255 */     this.logger.error("Could not find GUI state element. Returning defaults.\n");
/*  256 */     this.ok = false;
/*  257 */     return "ConfigureViews";
/*      */   }
/*      */ 
/*      */   
/*      */   public DisplaySettings getDisplaySettings() {
/*  262 */     Element dsel = this.root.getChild("DisplaySettings");
/*  263 */     if (null == dsel) {
/*      */       
/*  265 */       this.logger.error("Could not find the display-settings element. Returning user defaults.\n");
/*  266 */       this.ok = false;
/*  267 */       return DisplaySettingsIO.readUserDefault();
/*      */     } 
/*  269 */     return DisplaySettingsIO.fromJson(dsel.getText());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Collection<TrackMateModelView> getViews(ViewProvider provider, Model model, Settings settings, SelectionModel selectionModel, DisplaySettings displaySettings) {
/*  298 */     Element guiel = this.root.getChild("GUIState");
/*  299 */     if (null != guiel) {
/*      */ 
/*      */       
/*  302 */       List<Element> children = guiel.getChildren("View");
/*  303 */       Collection<TrackMateModelView> views = new ArrayList<>(children.size());
/*      */       
/*  305 */       for (Element child : children) {
/*      */         
/*  307 */         String viewKey = child.getAttributeValue("key");
/*  308 */         if (null == viewKey) {
/*      */           
/*  310 */           this.logger.error("Could not find view key attribute for element " + child + ".\n");
/*  311 */           this.ok = false;
/*      */           
/*      */           continue;
/*      */         } 
/*      */         
/*  316 */         if (viewKey.equals("TRACKSCHEME")) {
/*      */           continue;
/*      */         }
/*  319 */         ViewFactory factory = (ViewFactory)provider.getFactory(viewKey);
/*  320 */         if (null == factory) {
/*      */           
/*  322 */           this.logger.error("Unknown view factory for key " + viewKey + ".\n");
/*  323 */           this.ok = false;
/*      */           
/*      */           continue;
/*      */         } 
/*  327 */         TrackMateModelView view = factory.create(model, settings, selectionModel, displaySettings);
/*  328 */         if (null == view) {
/*      */           
/*  330 */           this.logger.error("Unknown view for key " + viewKey + ".\n");
/*  331 */           this.ok = false;
/*      */           
/*      */           continue;
/*      */         } 
/*  335 */         views.add(view);
/*      */       } 
/*      */ 
/*      */       
/*  339 */       return views;
/*      */     } 
/*      */     
/*  342 */     this.logger.error("Could not find GUI state element.\n");
/*  343 */     this.ok = false;
/*  344 */     return new ArrayList<>();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Model getModel() {
/*  355 */     Element modelElement = this.root.getChild("Model");
/*  356 */     if (null == modelElement) {
/*  357 */       return null;
/*      */     }
/*  359 */     Model model = createModel();
/*      */ 
/*      */     
/*  362 */     String spaceUnits = modelElement.getAttributeValue("spatialunits");
/*  363 */     String timeUnits = modelElement.getAttributeValue("timeunits");
/*  364 */     model.setPhysicalUnits(spaceUnits, timeUnits);
/*      */ 
/*      */     
/*  367 */     readFeatureDeclarations(modelElement, model);
/*      */ 
/*      */     
/*  370 */     SpotCollection spots = getSpots(modelElement);
/*  371 */     model.setSpots(spots, false);
/*      */ 
/*      */     
/*  374 */     if (!readTracks(modelElement, model)) {
/*  375 */       this.ok = false;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/*  381 */       Map<Integer, Map<String, Double>> savedFeatureMap = readTrackFeatures(modelElement);
/*  382 */       for (Integer savedKey : savedFeatureMap.keySet()) {
/*      */ 
/*      */         
/*  385 */         Map<String, Double> savedFeatures = savedFeatureMap.get(savedKey);
/*  386 */         for (String feature : savedFeatures.keySet()) {
/*  387 */           model.getFeatureModel().putTrackFeature(savedKey, feature, savedFeatures.get(feature));
/*      */         }
/*      */       } 
/*  390 */     } catch (RuntimeException re) {
/*      */       
/*  392 */       this.logger.error("Problem populating track features:\n");
/*  393 */       this.logger.error(re.getMessage());
/*  394 */       this.ok = false;
/*      */     } 
/*      */ 
/*      */     
/*  398 */     return model;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Model createModel() {
/*  410 */     return new Model();
/*      */   }
/*      */ 
/*      */   
/*      */   public ImagePlus readImage() {
/*  415 */     Element settingsElement = this.root.getChild("Settings");
/*  416 */     if (null == settingsElement) {
/*  417 */       return null;
/*      */     }
/*  419 */     return getImage(settingsElement);
/*      */   }
/*      */ 
/*      */   
/*      */   public Settings readSettings(ImagePlus imp) {
/*  424 */     return readSettings(imp, new DetectorProvider(), new TrackerProvider(), new SpotAnalyzerProvider((imp == null) ? 1 : imp
/*      */ 
/*      */           
/*  427 */           .getNChannels()), new EdgeAnalyzerProvider(), new TrackAnalyzerProvider(), new SpotMorphologyAnalyzerProvider((imp == null) ? 1 : imp
/*      */ 
/*      */           
/*  430 */           .getNChannels()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Settings readSettings(ImagePlus imp, DetectorProvider detectorProvider, TrackerProvider trackerProvider, SpotAnalyzerProvider spotAnalyzerProvider, EdgeAnalyzerProvider edgeAnalyzerProvider, TrackAnalyzerProvider trackAnalyzerProvider, SpotMorphologyAnalyzerProvider spotMorphologyAnalyzerProvider) {
/*  469 */     Element settingsElement = this.root.getChild("Settings");
/*  470 */     if (null == settingsElement) {
/*  471 */       return null;
/*      */     }
/*  473 */     Settings settings = new Settings(imp);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  482 */     settings.addAllAnalyzers();
/*      */ 
/*      */     
/*  485 */     getBaseSettings(settingsElement, settings);
/*      */ 
/*      */     
/*  488 */     if (null != detectorProvider) {
/*  489 */       getDetectorSettings(settingsElement, settings, detectorProvider);
/*      */     }
/*      */     
/*  492 */     if (null != trackerProvider) {
/*  493 */       getTrackerSettings(settingsElement, settings, trackerProvider);
/*      */     }
/*      */     
/*  496 */     FeatureFilter initialFilter = getInitialFilter(settingsElement);
/*  497 */     if (null != initialFilter) {
/*  498 */       settings.initialSpotFilterValue = Double.valueOf(initialFilter.value);
/*      */     }
/*  500 */     List<FeatureFilter> spotFilters = getSpotFeatureFilters(settingsElement);
/*  501 */     settings.setSpotFilters(spotFilters);
/*      */ 
/*      */     
/*  504 */     List<FeatureFilter> trackFilters = getTrackFeatureFilters(settingsElement);
/*  505 */     settings.setTrackFilters(trackFilters);
/*      */ 
/*      */     
/*  508 */     readAnalyzers(settingsElement, settings, spotAnalyzerProvider, edgeAnalyzerProvider, trackAnalyzerProvider, spotMorphologyAnalyzerProvider);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  516 */     return settings;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getVersion() {
/*  524 */     return this.root.getAttribute("version").getValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getErrorMessage() {
/*  535 */     return this.logger.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isReadingOk() {
/*  547 */     return this.ok;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ImagePlus getImage(Element settingsElement) {
/*  556 */     Element imageInfoElement = settingsElement.getChild("ImageData");
/*  557 */     String filename = imageInfoElement.getAttributeValue("filename");
/*  558 */     String folder = imageInfoElement.getAttributeValue("folder");
/*  559 */     if (null == filename || filename.isEmpty()) {
/*      */       
/*  561 */       this.logger.error("Cannot find image file name in xml file.\n");
/*  562 */       this.ok = false;
/*  563 */       return null;
/*      */     } 
/*  565 */     if (null == folder || folder.isEmpty()) {
/*  566 */       folder = this.file.getParent();
/*      */     }
/*  568 */     File imageFile = new File(folder, filename);
/*  569 */     if (!imageFile.exists() || !imageFile.canRead()) {
/*      */ 
/*      */ 
/*      */       
/*  573 */       folder = this.file.getParent();
/*  574 */       imageFile = new File(folder, filename);
/*  575 */       if (!imageFile.exists() || !imageFile.canRead()) {
/*      */         
/*  577 */         this.logger.error("Cannot read image file: " + imageFile + ".\n");
/*  578 */         this.ok = false;
/*  579 */         return null;
/*      */       } 
/*      */     } 
/*  582 */     return IJ.openImage(imageFile.getAbsolutePath());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Map<Integer, Map<String, Double>> readTrackFeatures(Element modelElement) {
/*  591 */     HashMap<Integer, Map<String, Double>> featureMap = new HashMap<>();
/*      */     
/*  593 */     Element allTracksElement = modelElement.getChild("AllTracks");
/*  594 */     if (null == allTracksElement) {
/*      */       
/*  596 */       this.logger.error("Cannot find the track collection in file.\n");
/*  597 */       this.ok = false;
/*  598 */       return null;
/*      */     } 
/*      */ 
/*      */     
/*  602 */     List<Element> trackElements = allTracksElement.getChildren("Track");
/*  603 */     for (Element trackElement : trackElements) {
/*      */ 
/*      */       
/*  606 */       int trackID = -1;
/*      */       
/*      */       try {
/*  609 */         trackID = trackElement.getAttribute("TRACK_ID").getIntValue();
/*      */       }
/*  611 */       catch (DataConversionException e1) {
/*      */         
/*  613 */         this.logger.error("Found a track with invalid trackID for " + trackElement + ". Skipping.\n");
/*  614 */         this.ok = false;
/*      */         
/*      */         continue;
/*      */       } 
/*  618 */       HashMap<String, Double> trackMap = new HashMap<>();
/*      */       
/*  620 */       List<Attribute> attributes = trackElement.getAttributes();
/*  621 */       for (Attribute attribute : attributes) {
/*      */ 
/*      */         
/*  624 */         String attName = attribute.getName();
/*  625 */         if (attName.equals("name")) {
/*      */           continue;
/*      */         }
/*  628 */         Double attVal = Double.valueOf(Double.NaN);
/*      */         
/*      */         try {
/*  631 */           attVal = Double.valueOf(attribute.getDoubleValue());
/*      */         }
/*  633 */         catch (DataConversionException e) {
/*      */           
/*  635 */           this.logger.error("Track " + trackID + ": Cannot read the feature " + attName + " value. Skipping.\n");
/*  636 */           this.ok = false;
/*      */           
/*      */           continue;
/*      */         } 
/*  640 */         trackMap.put(attName, attVal);
/*      */       } 
/*      */ 
/*      */       
/*  644 */       featureMap.put(Integer.valueOf(trackID), trackMap);
/*      */     } 
/*      */     
/*  647 */     return featureMap;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected FeatureFilter getInitialFilter(Element settingsElement) {
/*  662 */     Element itEl = settingsElement.getChild("InitialSpotFilter");
/*  663 */     String feature = itEl.getAttributeValue("feature");
/*  664 */     Double value = Double.valueOf(IOUtils.readDoubleAttribute(itEl, "value", (Logger)this.logger));
/*  665 */     boolean isAbove = IOUtils.readBooleanAttribute(itEl, "isabove", (Logger)this.logger);
/*  666 */     FeatureFilter ft = new FeatureFilter(feature, value.doubleValue(), isAbove);
/*  667 */     return ft;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected List<FeatureFilter> getSpotFeatureFilters(Element settingsElement) {
/*  679 */     List<FeatureFilter> featureThresholds = new ArrayList<>();
/*  680 */     Element ftCollectionEl = settingsElement.getChild("SpotFilterCollection");
/*  681 */     List<Element> ftEls = ftCollectionEl.getChildren("Filter");
/*  682 */     for (Element ftEl : ftEls) {
/*      */       
/*  684 */       String feature = ftEl.getAttributeValue("feature");
/*  685 */       Double value = Double.valueOf(IOUtils.readDoubleAttribute(ftEl, "value", (Logger)this.logger));
/*  686 */       boolean isAbove = IOUtils.readBooleanAttribute(ftEl, "isabove", (Logger)this.logger);
/*  687 */       FeatureFilter ft = new FeatureFilter(feature, value.doubleValue(), isAbove);
/*  688 */       featureThresholds.add(ft);
/*      */     } 
/*  690 */     return featureThresholds;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected List<FeatureFilter> getTrackFeatureFilters(Element settingsElement) {
/*  702 */     List<FeatureFilter> featureThresholds = new ArrayList<>();
/*  703 */     Element ftCollectionEl = settingsElement.getChild("TrackFilterCollection");
/*  704 */     List<Element> ftEls = ftCollectionEl.getChildren("Filter");
/*  705 */     for (Element ftEl : ftEls) {
/*      */       
/*  707 */       String feature = ftEl.getAttributeValue("feature");
/*  708 */       Double value = Double.valueOf(IOUtils.readDoubleAttribute(ftEl, "value", (Logger)this.logger));
/*  709 */       boolean isAbove = IOUtils.readBooleanAttribute(ftEl, "isabove", (Logger)this.logger);
/*  710 */       FeatureFilter ft = new FeatureFilter(feature, value.doubleValue(), isAbove);
/*  711 */       featureThresholds.add(ft);
/*      */     } 
/*  713 */     return featureThresholds;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void getBaseSettings(Element settingsElement, Settings settings) {
/*  728 */     Element settingsEl = settingsElement.getChild("BasicSettings");
/*  729 */     if (null != settingsEl) {
/*      */       
/*  731 */       settings.xstart = IOUtils.readIntAttribute(settingsEl, "xstart", (Logger)this.logger, 1);
/*  732 */       settings.xend = IOUtils.readIntAttribute(settingsEl, "xend", (Logger)this.logger, 512);
/*  733 */       settings.ystart = IOUtils.readIntAttribute(settingsEl, "ystart", (Logger)this.logger, 1);
/*  734 */       settings.yend = IOUtils.readIntAttribute(settingsEl, "yend", (Logger)this.logger, 512);
/*  735 */       settings.zstart = IOUtils.readIntAttribute(settingsEl, "zstart", (Logger)this.logger, 1);
/*  736 */       settings.zend = IOUtils.readIntAttribute(settingsEl, "zend", (Logger)this.logger, 10);
/*  737 */       settings.tstart = IOUtils.readIntAttribute(settingsEl, "tstart", (Logger)this.logger, 1);
/*  738 */       settings.tend = IOUtils.readIntAttribute(settingsEl, "tend", (Logger)this.logger, 10);
/*      */     } 
/*      */     
/*  741 */     Element infoEl = settingsElement.getChild("ImageData");
/*  742 */     if (null != infoEl) {
/*      */       
/*  744 */       settings.dx = IOUtils.readDoubleAttribute(infoEl, "pixelwidth", (Logger)this.logger);
/*  745 */       settings.dy = IOUtils.readDoubleAttribute(infoEl, "pixelheight", (Logger)this.logger);
/*  746 */       settings.dz = IOUtils.readDoubleAttribute(infoEl, "voxeldepth", (Logger)this.logger);
/*  747 */       settings.dt = IOUtils.readDoubleAttribute(infoEl, "timeinterval", (Logger)this.logger);
/*  748 */       settings.width = IOUtils.readIntAttribute(infoEl, "width", (Logger)this.logger, 512);
/*  749 */       settings.height = IOUtils.readIntAttribute(infoEl, "height", (Logger)this.logger, 512);
/*  750 */       settings.nslices = IOUtils.readIntAttribute(infoEl, "nslices", (Logger)this.logger, 1);
/*  751 */       settings.nframes = IOUtils.readIntAttribute(infoEl, "nframes", (Logger)this.logger, 1);
/*  752 */       settings.imageFileName = infoEl.getAttributeValue("filename");
/*  753 */       settings.imageFolder = infoEl.getAttributeValue("folder");
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void getDetectorSettings(Element settingsElement, Settings settings, DetectorProvider provider) {
/*  777 */     Element element = settingsElement.getChild("DetectorSettings");
/*      */     
/*  779 */     if (null == element) {
/*      */       
/*  781 */       this.logger.error("Could not find the detector element in file.\n");
/*  782 */       this.ok = false;
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/*  787 */     String detectorKey = element.getAttributeValue("DETECTOR_NAME");
/*  788 */     if (null == detectorKey) {
/*      */       
/*  790 */       this.logger.error("Could not find the detector key element in file.\n");
/*  791 */       this.ok = false;
/*      */       
/*      */       return;
/*      */     } 
/*  795 */     SpotDetectorFactoryBase<?> factory = (SpotDetectorFactoryBase)provider.getFactory(detectorKey);
/*  796 */     if (null == factory) {
/*      */       
/*  798 */       this.logger.error("The detector identified by the key " + detectorKey + " is unknown to TrackMate.\n");
/*  799 */       this.ok = false;
/*      */       return;
/*      */     } 
/*  802 */     settings.detectorFactory = factory;
/*      */     
/*  804 */     Map<String, Object> ds = new HashMap<>();
/*  805 */     this.ok = factory.unmarshall(element, ds);
/*      */     
/*  807 */     settings.detectorSettings = ds;
/*  808 */     if (!this.ok) {
/*  809 */       this.logger.error(factory.getErrorMessage());
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void getTrackerSettings(Element settingsElement, Settings settings, TrackerProvider provider) {
/*  836 */     Element element = settingsElement.getChild("TrackerSettings");
/*  837 */     if (null == element) {
/*      */       
/*  839 */       this.logger.error("Could not find the tracker element in file.\n");
/*  840 */       this.ok = false;
/*      */       
/*      */       return;
/*      */     } 
/*  844 */     Map<String, Object> ds = new HashMap<>();
/*      */ 
/*      */     
/*  847 */     String trackerKey = element.getAttributeValue("TRACKER_NAME");
/*  848 */     if (null == trackerKey) {
/*      */       
/*  850 */       this.logger.error("Could not find the tracker key element in file.\n");
/*  851 */       this.ok = false;
/*      */       
/*      */       return;
/*      */     } 
/*  855 */     SpotTrackerFactory factory = (SpotTrackerFactory)provider.getFactory(trackerKey);
/*  856 */     if (null == factory) {
/*      */       
/*  858 */       this.logger.error("The tracker identified by the key " + trackerKey + " is unknown to TrackMate.\n");
/*  859 */       this.ok = false;
/*      */       return;
/*      */     } 
/*  862 */     settings.trackerFactory = factory;
/*      */ 
/*      */     
/*  865 */     boolean lOk = factory.unmarshall(element, ds);
/*  866 */     if (lOk) {
/*  867 */       settings.trackerSettings = ds;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private SpotCollection getSpots(Element modelElement) {
/*  887 */     Element spotCollection = modelElement.getChild("AllSpots");
/*      */ 
/*      */     
/*  890 */     List<Element> frameContent = spotCollection.getChildren("SpotsInFrame");
/*      */ 
/*      */     
/*  893 */     int nspots = IOUtils.readIntAttribute(spotCollection, "nspots", Logger.VOID_LOGGER);
/*  894 */     if (nspots == 0)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  900 */       for (Element currentFrameContent : frameContent) {
/*  901 */         nspots += currentFrameContent.getChildren("Spot").size();
/*      */       }
/*      */     }
/*      */     
/*  905 */     this.cache = new ConcurrentHashMap<>(nspots);
/*      */ 
/*      */     
/*  908 */     int currentFrame = 0;
/*  909 */     Map<Integer, Set<Spot>> content = new HashMap<>(frameContent.size());
/*  910 */     for (Element currentFrameContent : frameContent) {
/*      */ 
/*      */       
/*  913 */       currentFrame = IOUtils.readIntAttribute(currentFrameContent, "frame", (Logger)this.logger);
/*  914 */       List<Element> spotContent = currentFrameContent.getChildren("Spot");
/*  915 */       Set<Spot> spotSet = new HashSet<>(spotContent.size());
/*  916 */       for (Element spotElement : spotContent) {
/*      */         
/*  918 */         Spot spot = createSpotFrom(spotElement);
/*  919 */         spotSet.add(spot);
/*  920 */         this.cache.put(Integer.valueOf(spot.ID()), spot);
/*      */       } 
/*  922 */       content.put(Integer.valueOf(currentFrame), spotSet);
/*      */     } 
/*  924 */     SpotCollection allSpots = SpotCollection.fromMap(content);
/*  925 */     return allSpots;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean readTracks(Element modelElement, Model model) {
/*  938 */     Element allTracksElement = modelElement.getChild("AllTracks");
/*  939 */     List<Element> trackElements = allTracksElement.getChildren("Track");
/*      */ 
/*      */     
/*  942 */     SimpleWeightedGraph<Spot, DefaultWeightedEdge> graph = new SimpleWeightedGraph(DefaultWeightedEdge.class);
/*  943 */     Map<Integer, Set<Spot>> connectedVertexSet = new HashMap<>(trackElements.size());
/*  944 */     Map<Integer, Set<DefaultWeightedEdge>> connectedEdgeSet = new HashMap<>(trackElements.size());
/*  945 */     Map<Integer, String> savedTrackNames = new HashMap<>(trackElements.size());
/*      */ 
/*      */     
/*  948 */     FeatureModel fm = model.getFeatureModel();
/*  949 */     Collection<String> edgeFeatures = fm.getEdgeFeatures();
/*  950 */     Map<String, Boolean> edgeFeatureIsInt = fm.getEdgeFeatureIsInt();
/*      */     
/*  952 */     for (Element trackElement : trackElements) {
/*      */ 
/*      */ 
/*      */       
/*  956 */       int trackID = IOUtils.readIntAttribute(trackElement, "TRACK_ID", (Logger)this.logger);
/*  957 */       String trackName = trackElement.getAttributeValue("name");
/*  958 */       if (null == trackName) {
/*  959 */         trackName = "Unnamed";
/*      */       }
/*      */       
/*  962 */       List<Element> edgeElements = trackElement.getChildren("Edge");
/*  963 */       Set<DefaultWeightedEdge> edges = new HashSet<>(edgeElements.size());
/*  964 */       Set<Spot> spots = new HashSet<>(edgeElements.size());
/*      */       
/*  966 */       for (Element edgeElement : edgeElements) {
/*      */ 
/*      */ 
/*      */         
/*  970 */         int sourceID = IOUtils.readIntAttribute(edgeElement, "SPOT_SOURCE_ID", (Logger)this.logger);
/*  971 */         int targetID = IOUtils.readIntAttribute(edgeElement, "SPOT_TARGET_ID", (Logger)this.logger);
/*      */ 
/*      */         
/*  974 */         Spot sourceSpot = this.cache.get(Integer.valueOf(sourceID));
/*  975 */         Spot targetSpot = this.cache.get(Integer.valueOf(targetID));
/*      */ 
/*      */         
/*  978 */         double weight = 0.0D;
/*  979 */         if (null != edgeElement.getAttribute("LINK_COST")) {
/*  980 */           weight = IOUtils.readDoubleAttribute(edgeElement, "LINK_COST", (Logger)this.logger);
/*      */         }
/*      */         
/*  983 */         if (null == sourceSpot) {
/*      */           
/*  985 */           this.logger.error("Unknown spot ID: " + sourceID + "\n");
/*  986 */           return false;
/*      */         } 
/*  988 */         if (null == targetSpot) {
/*      */           
/*  990 */           this.logger.error("Unknown spot ID: " + targetID + "\n");
/*  991 */           return false;
/*      */         } 
/*      */         
/*  994 */         if (sourceSpot.equals(targetSpot)) {
/*      */           
/*  996 */           this.logger.error("Bad link for track " + trackID + ". Source = Target with ID: " + sourceID + "\n");
/*  997 */           return false;
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1005 */         spots.add(sourceSpot);
/* 1006 */         spots.add(targetSpot);
/*      */ 
/*      */         
/* 1009 */         graph.addVertex(sourceSpot);
/* 1010 */         graph.addVertex(targetSpot);
/* 1011 */         DefaultWeightedEdge edge = (DefaultWeightedEdge)graph.addEdge(sourceSpot, targetSpot);
/*      */         
/* 1013 */         if (edge == null) {
/*      */           
/* 1015 */           this.logger.error("Bad edge found for track " + trackID + "\n");
/* 1016 */           return false;
/*      */         } 
/*      */         
/* 1019 */         graph.setEdgeWeight(edge, weight);
/*      */ 
/*      */         
/* 1022 */         for (String feature : edgeFeatures) {
/*      */           double val;
/* 1024 */           if (null == edgeElement.getAttribute(feature)) {
/*      */             continue;
/*      */           }
/*      */           
/* 1028 */           if (((Boolean)edgeFeatureIsInt.get(feature)).booleanValue()) {
/* 1029 */             val = IOUtils.readIntAttribute(edgeElement, feature, (Logger)this.logger);
/*      */           } else {
/* 1031 */             val = IOUtils.readDoubleAttribute(edgeElement, feature, (Logger)this.logger);
/*      */           } 
/* 1033 */           fm.putEdgeFeature(edge, feature, Double.valueOf(val));
/*      */         } 
/*      */ 
/*      */         
/* 1037 */         edges.add(edge);
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 1042 */       connectedVertexSet.put(Integer.valueOf(trackID), spots);
/* 1043 */       connectedEdgeSet.put(Integer.valueOf(trackID), edges);
/* 1044 */       savedTrackNames.put(Integer.valueOf(trackID), trackName);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1050 */     Set<Integer> savedFilteredTrackIDs = readFilteredTrackIDs(modelElement);
/* 1051 */     Map<Integer, Boolean> visibility = new HashMap<>(connectedEdgeSet.size());
/* 1052 */     Set<Integer> ids = new HashSet<>(connectedEdgeSet.keySet());
/* 1053 */     for (Integer id : savedFilteredTrackIDs) {
/* 1054 */       visibility.put(id, Boolean.TRUE);
/*      */     }
/* 1056 */     ids.removeAll(savedFilteredTrackIDs);
/* 1057 */     for (Integer id : ids) {
/* 1058 */       visibility.put(id, Boolean.FALSE);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 1063 */     model.getTrackModel().from(graph, connectedVertexSet, connectedEdgeSet, visibility, savedTrackNames);
/*      */     
/* 1065 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Set<Integer> readFilteredTrackIDs(Element modelElement) {
/* 1074 */     Element filteredTracksElement = modelElement.getChild("FilteredTracks");
/* 1075 */     if (null == filteredTracksElement) {
/*      */       
/* 1077 */       this.logger.error("Could not find the filtered track IDs in file.\n");
/* 1078 */       this.ok = false;
/* 1079 */       return null;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1086 */     Element allTracksElement = modelElement.getChild("AllTracks");
/* 1087 */     if (null == allTracksElement) {
/*      */       
/* 1089 */       this.logger.error("Could not find the track collection in file.\n");
/* 1090 */       this.ok = false;
/* 1091 */       return null;
/*      */     } 
/*      */     
/* 1094 */     List<Element> trackElements = allTracksElement.getChildren("Track");
/* 1095 */     int[] IDs = new int[trackElements.size()];
/* 1096 */     int index = 0;
/* 1097 */     for (Element trackElement : trackElements) {
/*      */       
/* 1099 */       int trackID = IOUtils.readIntAttribute(trackElement, "TRACK_ID", (Logger)this.logger);
/* 1100 */       IDs[index] = trackID;
/* 1101 */       index++;
/*      */     } 
/* 1103 */     Arrays.sort(IDs);
/*      */     
/* 1105 */     List<Element> elements = filteredTracksElement.getChildren("TrackID");
/* 1106 */     HashSet<Integer> filteredTrackIndices = new HashSet<>(elements.size());
/* 1107 */     for (Element indexElement : elements) {
/*      */       
/* 1109 */       int trackID = IOUtils.readIntAttribute(indexElement, "TRACK_ID", (Logger)this.logger);
/*      */ 
/*      */       
/* 1112 */       int search = Arrays.binarySearch(IDs, trackID);
/* 1113 */       if (search < 0) {
/*      */         
/* 1115 */         this.logger.error("Invalid filtered track index: " + trackID + ". Track ID does not exist.\n");
/* 1116 */         this.ok = false;
/*      */         
/*      */         continue;
/*      */       } 
/* 1120 */       filteredTrackIndices.add(Integer.valueOf(trackID));
/*      */     } 
/*      */     
/* 1123 */     return filteredTrackIndices;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private Spot createSpotFrom(Element spotEl) {
/* 1129 */     int ID = IOUtils.readIntAttribute(spotEl, "ID", (Logger)this.logger);
/* 1130 */     Spot spot = new Spot(ID);
/*      */     
/* 1132 */     List<Attribute> atts = spotEl.getAttributes();
/* 1133 */     removeAttributeFromName(atts, "ID");
/*      */ 
/*      */     
/* 1136 */     String name = spotEl.getAttributeValue("name");
/* 1137 */     if (null == name || name.equals("")) {
/* 1138 */       name = "ID" + ID;
/*      */     }
/* 1140 */     spot.setName(name);
/* 1141 */     removeAttributeFromName(atts, "name");
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1146 */     int roiNPoints = IOUtils.readIntAttribute(spotEl, "ROI_N_POINTS", Logger.VOID_LOGGER);
/* 1147 */     if (roiNPoints > 2) {
/*      */       
/* 1149 */       double[] xrois = new double[roiNPoints];
/* 1150 */       double[] yrois = new double[roiNPoints];
/* 1151 */       String str = spotEl.getText();
/* 1152 */       String[] vals = str.split("\\s+");
/* 1153 */       int index = 0;
/* 1154 */       for (int i = 0; i < roiNPoints; i++) {
/*      */         
/* 1156 */         double x = Double.parseDouble(vals[index++]);
/* 1157 */         xrois[i] = x;
/* 1158 */         double y = Double.parseDouble(vals[index++]);
/* 1159 */         yrois[i] = y;
/*      */       } 
/* 1161 */       spot.setRoi(new SpotRoi(xrois, yrois));
/*      */     } 
/* 1163 */     removeAttributeFromName(atts, "ROI_N_POINTS");
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1168 */     for (Attribute att : atts) {
/*      */       
/* 1170 */       if (att.getName().equals("name") || att.getName().equals("ID")) {
/*      */         continue;
/*      */       }
/* 1173 */       spot.putFeature(att.getName(), Double.valueOf(att.getValue()));
/*      */     } 
/* 1175 */     return spot;
/*      */   }
/*      */ 
/*      */   
/*      */   protected static final void removeAttributeFromName(List<Attribute> attributes, String attributeNameToRemove) {
/* 1180 */     List<Attribute> toRemove = new ArrayList<>();
/* 1181 */     for (Attribute attribute : attributes) {
/* 1182 */       if (attribute.getName().equals(attributeNameToRemove))
/* 1183 */         toRemove.add(attribute); 
/*      */     } 
/* 1185 */     attributes.removeAll(toRemove);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void readFeatureDeclarations(Element modelElement, Model model) {
/* 1191 */     FeatureModel fm = model.getFeatureModel();
/* 1192 */     Element featuresElement = modelElement.getChild("FeatureDeclarations");
/* 1193 */     if (null == featuresElement) {
/*      */       
/* 1195 */       this.logger.error("Could not find feature declarations in file.\n");
/* 1196 */       this.ok = false;
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/* 1201 */     Element spotFeaturesElement = featuresElement.getChild("SpotFeatures");
/* 1202 */     if (null == spotFeaturesElement) {
/*      */       
/* 1204 */       this.logger.error("Could not find spot feature declarations in file.\n");
/* 1205 */       this.ok = false;
/*      */     
/*      */     }
/*      */     else {
/*      */ 
/*      */       
/* 1211 */       List<Element> children = spotFeaturesElement.getChildren("Feature");
/* 1212 */       Collection<String> features = new ArrayList<>(children.size());
/* 1213 */       Map<String, String> featureNames = new HashMap<>(children.size());
/* 1214 */       Map<String, String> featureShortNames = new HashMap<>(children.size());
/* 1215 */       Map<String, Dimension> featureDimensions = new HashMap<>(children.size());
/* 1216 */       Map<String, Boolean> isIntFeature = new HashMap<>();
/* 1217 */       for (Element child : children) {
/* 1218 */         readSingleFeatureDeclaration(child, features, featureNames, featureShortNames, featureDimensions, isIntFeature);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1226 */       fm.declareSpotFeatures(features, featureNames, featureShortNames, featureDimensions, isIntFeature);
/*      */     } 
/*      */ 
/*      */     
/* 1230 */     Element edgeFeaturesElement = featuresElement.getChild("EdgeFeatures");
/* 1231 */     if (null == edgeFeaturesElement) {
/*      */       
/* 1233 */       this.logger.error("Could not find edge feature declarations in file.\n");
/* 1234 */       this.ok = false;
/*      */     
/*      */     }
/*      */     else {
/*      */ 
/*      */       
/* 1240 */       List<Element> children = edgeFeaturesElement.getChildren("Feature");
/* 1241 */       Collection<String> features = new ArrayList<>(children.size());
/* 1242 */       Map<String, String> featureNames = new HashMap<>(children.size());
/* 1243 */       Map<String, String> featureShortNames = new HashMap<>(children.size());
/* 1244 */       Map<String, Dimension> featureDimensions = new HashMap<>(children.size());
/* 1245 */       Map<String, Boolean> isIntFeature = new HashMap<>(children.size());
/* 1246 */       for (Element child : children) {
/* 1247 */         readSingleFeatureDeclaration(child, features, featureNames, featureShortNames, featureDimensions, isIntFeature);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1255 */       fm.declareEdgeFeatures(features, featureNames, featureShortNames, featureDimensions, isIntFeature);
/*      */     } 
/*      */ 
/*      */     
/* 1259 */     Element trackFeaturesElement = featuresElement.getChild("TrackFeatures");
/* 1260 */     if (null == trackFeaturesElement) {
/*      */       
/* 1262 */       this.logger.error("Could not find track feature declarations in file.\n");
/* 1263 */       this.ok = false;
/*      */     
/*      */     }
/*      */     else {
/*      */ 
/*      */       
/* 1269 */       List<Element> children = trackFeaturesElement.getChildren("Feature");
/* 1270 */       Collection<String> features = new ArrayList<>(children.size());
/* 1271 */       Map<String, String> featureNames = new HashMap<>(children.size());
/* 1272 */       Map<String, String> featureShortNames = new HashMap<>(children.size());
/* 1273 */       Map<String, Dimension> featureDimensions = new HashMap<>(children.size());
/* 1274 */       Map<String, Boolean> isIntFeature = new HashMap<>();
/* 1275 */       for (Element child : children) {
/* 1276 */         readSingleFeatureDeclaration(child, features, featureNames, featureShortNames, featureDimensions, isIntFeature);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1284 */       fm.declareTrackFeatures(features, featureNames, featureShortNames, featureDimensions, isIntFeature);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void readAnalyzers(Element settingsElement, Settings settings, SpotAnalyzerProvider spotAnalyzerProvider, EdgeAnalyzerProvider edgeAnalyzerProvider, TrackAnalyzerProvider trackAnalyzerProvider, SpotMorphologyAnalyzerProvider spotMorphologyAnalyzerProvider) {
/* 1297 */     Element analyzersEl = settingsElement.getChild("AnalyzerCollection");
/* 1298 */     if (null == analyzersEl) {
/*      */       
/* 1300 */       this.logger.error("Could not find the feature analyzer element.\n");
/* 1301 */       this.ok = false;
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/* 1306 */     if (null != spotAnalyzerProvider) {
/*      */       
/* 1308 */       Element spotAnalyzerEl = analyzersEl.getChild("SpotAnalyzers");
/* 1309 */       if (null == spotAnalyzerEl) {
/*      */         
/* 1311 */         this.logger.error("Could not find the spot analyzer element.\n");
/* 1312 */         this.ok = false;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       }
/* 1318 */       else if (settings.imp == null) {
/*      */         
/* 1320 */         this.logger.error("The source image is not loaded; cannot instantiates spot analyzers.\n");
/* 1321 */         this.ok = false;
/*      */       
/*      */       }
/*      */       else {
/*      */ 
/*      */         
/* 1327 */         List<Element> children = spotAnalyzerEl.getChildren("Analyzer");
/* 1328 */         for (Element child : children) {
/*      */           SpotMorphologyAnalyzerFactory spotMorphologyAnalyzerFactory;
/*      */           
/* 1331 */           String key = child.getAttributeValue("key");
/* 1332 */           if (null == key) {
/*      */             
/* 1334 */             this.logger.error("Could not find analyzer name for element " + child + ".\n");
/* 1335 */             this.ok = false;
/*      */             
/*      */             continue;
/*      */           } 
/* 1339 */           SpotAnalyzerFactory spotAnalyzerFactory = spotAnalyzerProvider.getFactory(key);
/* 1340 */           if (null == spotAnalyzerFactory)
/*      */           {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 1349 */             spotMorphologyAnalyzerFactory = spotMorphologyAnalyzerProvider.getFactory(key);
/*      */           }
/*      */           
/* 1352 */           if (null == spotMorphologyAnalyzerFactory) {
/*      */             
/* 1354 */             this.logger.error("Unknown spot analyzer key: " + key + ".\n");
/* 1355 */             this.ok = false;
/*      */             
/*      */             continue;
/*      */           } 
/* 1359 */           settings.addSpotAnalyzerFactory((SpotAnalyzerFactoryBase)spotMorphologyAnalyzerFactory);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1367 */     if (null != edgeAnalyzerProvider) {
/*      */       
/* 1369 */       Element edgeAnalyzerEl = analyzersEl.getChild("EdgeAnalyzers");
/* 1370 */       if (null == edgeAnalyzerEl) {
/*      */         
/* 1372 */         this.logger.error("Could not find the edge analyzer element.\n");
/* 1373 */         this.ok = false;
/*      */       
/*      */       }
/*      */       else {
/*      */ 
/*      */         
/* 1379 */         List<Element> children = edgeAnalyzerEl.getChildren("Analyzer");
/* 1380 */         for (Element child : children) {
/*      */ 
/*      */           
/* 1383 */           String key = child.getAttributeValue("key");
/* 1384 */           if (null == key) {
/*      */             
/* 1386 */             this.logger.error("Could not find analyzer name for element " + child + ".\n");
/* 1387 */             this.ok = false;
/*      */             
/*      */             continue;
/*      */           } 
/* 1391 */           EdgeAnalyzer edgeAnalyzer = (EdgeAnalyzer)edgeAnalyzerProvider.getFactory(key);
/* 1392 */           if (null == edgeAnalyzer) {
/*      */             
/* 1394 */             this.logger.error("Unknown edge analyzer key: " + key + ".\n");
/* 1395 */             this.ok = false;
/*      */             
/*      */             continue;
/*      */           } 
/* 1399 */           settings.addEdgeAnalyzer(edgeAnalyzer);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1406 */     if (null != trackAnalyzerProvider) {
/*      */       
/* 1408 */       Element trackAnalyzerEl = analyzersEl.getChild("TrackAnalyzers");
/* 1409 */       if (null == trackAnalyzerEl) {
/*      */         
/* 1411 */         this.logger.error("Could not find the track analyzer element.\n");
/* 1412 */         this.ok = false;
/*      */       
/*      */       }
/*      */       else {
/*      */ 
/*      */         
/* 1418 */         List<Element> children = trackAnalyzerEl.getChildren("Analyzer");
/* 1419 */         for (Element child : children) {
/*      */ 
/*      */           
/* 1422 */           String key = child.getAttributeValue("key");
/* 1423 */           if (null == key) {
/*      */             
/* 1425 */             this.logger.error("Could not find analyzer name for element " + child + ".\n");
/* 1426 */             this.ok = false;
/*      */             
/*      */             continue;
/*      */           } 
/* 1430 */           TrackAnalyzer trackAnalyzer = (TrackAnalyzer)trackAnalyzerProvider.getFactory(key);
/* 1431 */           if (null == trackAnalyzer) {
/*      */             
/* 1433 */             this.logger.error("Unknown track analyzer key: " + key + ".\n");
/* 1434 */             this.ok = false;
/*      */             
/*      */             continue;
/*      */           } 
/* 1438 */           settings.addTrackAnalyzer(trackAnalyzer);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void readSingleFeatureDeclaration(Element child, Collection<String> features, Map<String, String> featureNames, Map<String, String> featureShortNames, Map<String, Dimension> featureDimensions, Map<String, Boolean> isIntFeature) {
/* 1454 */     String feature = child.getAttributeValue("feature");
/* 1455 */     if (null == feature) {
/*      */       
/* 1457 */       this.logger.error("Could not find feature declaration for element " + child + ".\n");
/* 1458 */       this.ok = false;
/*      */       return;
/*      */     } 
/* 1461 */     String featureName = child.getAttributeValue("name");
/* 1462 */     if (null == featureName) {
/*      */       
/* 1464 */       this.logger.error("Could not find name for feature " + feature + ".\n");
/* 1465 */       this.ok = false;
/*      */       return;
/*      */     } 
/* 1468 */     String featureShortName = child.getAttributeValue("shortname");
/* 1469 */     if (null == featureShortName) {
/*      */       
/* 1471 */       this.logger.error("Could not find short name for feature " + feature + ".\n");
/* 1472 */       this.ok = false;
/*      */       return;
/*      */     } 
/* 1475 */     Dimension featureDimension = Dimension.valueOf(child.getAttributeValue("dimension"));
/* 1476 */     if (null == featureDimension) {
/*      */       
/* 1478 */       this.logger.error("Could not find dimension for feature " + feature + ".\n");
/* 1479 */       this.ok = false;
/*      */       return;
/*      */     } 
/* 1482 */     boolean isInt = false;
/*      */     
/*      */     try {
/* 1485 */       isInt = child.getAttribute("isint").getBooleanValue();
/*      */     }
/* 1487 */     catch (Exception e) {
/*      */       
/* 1489 */       this.logger.error("Could not read the isInt attribute for feature " + feature + ".\n");
/* 1490 */       this.ok = false;
/*      */     } 
/*      */     
/* 1493 */     features.add(feature);
/* 1494 */     featureNames.put(feature, featureName);
/* 1495 */     featureShortNames.put(feature, featureShortName);
/* 1496 */     featureDimensions.put(feature, featureDimension);
/* 1497 */     isIntFeature.put(feature, Boolean.valueOf(isInt));
/*      */   }
/*      */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/io/TmXmlReader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */