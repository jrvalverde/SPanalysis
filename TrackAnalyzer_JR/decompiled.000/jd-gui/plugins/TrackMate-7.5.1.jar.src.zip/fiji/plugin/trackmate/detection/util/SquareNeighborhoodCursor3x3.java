/*     */ package fiji.plugin.trackmate.detection.util;
/*     */ 
/*     */ import java.util.NoSuchElementException;
/*     */ import net.imglib2.Cursor;
/*     */ import net.imglib2.RandomAccessibleInterval;
/*     */ import net.imglib2.RealCursor;
/*     */ import net.imglib2.Sampler;
/*     */ import net.imglib2.outofbounds.Bounded;
/*     */ import net.imglib2.outofbounds.OutOfBounds;
/*     */ import net.imglib2.view.ExtendedRandomAccessibleInterval;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SquareNeighborhoodCursor3x3<T>
/*     */   implements Cursor<T>, Bounded
/*     */ {
/*     */   private final ExtendedRandomAccessibleInterval<T, RandomAccessibleInterval<T>> source;
/*     */   private final long[] center;
/*     */   private final OutOfBounds<T> ra;
/*  38 */   private int index = -1;
/*     */ 
/*     */   
/*     */   private boolean hasNext;
/*     */ 
/*     */ 
/*     */   
/*     */   public SquareNeighborhoodCursor3x3(ExtendedRandomAccessibleInterval<T, RandomAccessibleInterval<T>> extendedSource, long[] center) {
/*  46 */     this.source = extendedSource;
/*  47 */     this.center = center;
/*  48 */     this.ra = extendedSource.randomAccess();
/*  49 */     reset();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void localize(float[] position) {
/*  58 */     this.ra.localize(position);
/*     */   }
/*     */ 
/*     */   
/*     */   public void localize(double[] position) {
/*  63 */     this.ra.localize(position);
/*     */   }
/*     */ 
/*     */   
/*     */   public float getFloatPosition(int d) {
/*  68 */     return this.ra.getFloatPosition(d);
/*     */   }
/*     */ 
/*     */   
/*     */   public double getDoublePosition(int d) {
/*  73 */     return this.ra.getDoublePosition(d);
/*     */   }
/*     */ 
/*     */   
/*     */   public int numDimensions() {
/*  78 */     return this.source.numDimensions();
/*     */   }
/*     */ 
/*     */   
/*     */   public T get() {
/*  83 */     return (T)this.ra.get();
/*     */   }
/*     */ 
/*     */   
/*     */   public Sampler<T> copy() {
/*  88 */     return (Sampler<T>)this.ra.copy();
/*     */   }
/*     */ 
/*     */   
/*     */   public void jumpFwd(long steps) {
/*  93 */     for (int i = 0; i < steps; i++) {
/*  94 */       fwd();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void fwd() {
/* 100 */     this.index++;
/*     */     
/* 102 */     switch (this.index) {
/*     */       case 0:
/*     */         return;
/*     */ 
/*     */       
/*     */       case 1:
/* 108 */         this.ra.bck(1);
/*     */ 
/*     */       
/*     */       case 2:
/* 112 */         this.ra.bck(0);
/*     */ 
/*     */       
/*     */       case 3:
/* 116 */         this.ra.fwd(1);
/*     */ 
/*     */       
/*     */       case 4:
/* 120 */         this.ra.fwd(1);
/*     */ 
/*     */       
/*     */       case 5:
/* 124 */         this.ra.fwd(0);
/*     */ 
/*     */       
/*     */       case 6:
/* 128 */         this.ra.fwd(0);
/*     */ 
/*     */       
/*     */       case 7:
/* 132 */         this.ra.bck(1);
/*     */ 
/*     */       
/*     */       case 8:
/* 136 */         this.ra.bck(1);
/* 137 */         this.hasNext = false;
/*     */     } 
/*     */ 
/*     */     
/* 141 */     throw new NoSuchElementException("SquareNeighborhood3x3 exhausted");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void reset() {
/* 147 */     this.index = -1;
/* 148 */     this.hasNext = true;
/* 149 */     this.ra.setPosition(this.center);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasNext() {
/* 154 */     return this.hasNext;
/*     */   }
/*     */ 
/*     */   
/*     */   public T next() {
/* 159 */     fwd();
/* 160 */     return (T)this.ra.get();
/*     */   }
/*     */ 
/*     */   
/*     */   public void remove() {
/* 165 */     throw new UnsupportedOperationException("remove() is not implemented for SquareNeighborhoodCursor");
/*     */   }
/*     */ 
/*     */   
/*     */   public void localize(int[] position) {
/* 170 */     this.ra.localize(position);
/*     */   }
/*     */ 
/*     */   
/*     */   public void localize(long[] position) {
/* 175 */     this.ra.localize(position);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getIntPosition(int d) {
/* 180 */     return this.ra.getIntPosition(d);
/*     */   }
/*     */ 
/*     */   
/*     */   public long getLongPosition(int d) {
/* 185 */     return this.ra.getLongPosition(d);
/*     */   }
/*     */ 
/*     */   
/*     */   public Cursor<T> copyCursor() {
/* 190 */     return new SquareNeighborhoodCursor3x3(this.source, this.center);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isOutOfBounds() {
/* 195 */     return this.ra.isOutOfBounds();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/detection/util/SquareNeighborhoodCursor3x3.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */