/*    */ package fiji.plugin.trackmate;
/*    */ 
/*    */ import fiji.plugin.trackmate.detection.ManualDetectorFactory;
/*    */ import fiji.plugin.trackmate.detection.SpotDetectorFactoryBase;
/*    */ import fiji.plugin.trackmate.gui.displaysettings.DisplaySettings;
/*    */ import fiji.plugin.trackmate.gui.wizard.WizardSequence;
/*    */ import fiji.plugin.trackmate.tracking.ManualTrackerFactory;
/*    */ import fiji.plugin.trackmate.tracking.SpotTrackerFactory;
/*    */ import ij.ImageJ;
/*    */ import ij.ImagePlus;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ManualTrackingPlugIn
/*    */   extends TrackMatePlugIn
/*    */ {
/*    */   protected WizardSequence createSequence(TrackMate trackmate, SelectionModel selectionModel, DisplaySettings displaySettings) {
/* 38 */     WizardSequence sequence = super.createSequence(trackmate, selectionModel, displaySettings);
/* 39 */     sequence.setCurrent("ConfigureViews");
/* 40 */     return sequence;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected Settings createSettings(ImagePlus imp) {
/* 47 */     Settings lSettings = super.createSettings(imp);
/*    */     
/* 49 */     lSettings.detectorFactory = (SpotDetectorFactoryBase<?>)new ManualDetectorFactory();
/* 50 */     lSettings.detectorSettings = lSettings.detectorFactory.getDefaultSettings();
/*    */     
/* 52 */     lSettings.trackerFactory = (SpotTrackerFactory)new ManualTrackerFactory();
/* 53 */     lSettings.trackerSettings = lSettings.trackerFactory.getDefaultSettings();
/* 54 */     return lSettings;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected TrackMate createTrackMate(Model model, Settings settings) {
/* 60 */     TrackMate trackmate = super.createTrackMate(model, settings);
/*    */ 
/*    */     
/* 63 */     trackmate.computeSpotFeatures(false);
/* 64 */     trackmate.computeEdgeFeatures(false);
/* 65 */     trackmate.computeTrackFeatures(false);
/* 66 */     return trackmate;
/*    */   }
/*    */ 
/*    */   
/*    */   public static void main(String[] args) {
/* 71 */     ImageJ.main(args);
/* 72 */     (new ManualTrackingPlugIn()).run("samples/Merged.tif");
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/ManualTrackingPlugIn.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */