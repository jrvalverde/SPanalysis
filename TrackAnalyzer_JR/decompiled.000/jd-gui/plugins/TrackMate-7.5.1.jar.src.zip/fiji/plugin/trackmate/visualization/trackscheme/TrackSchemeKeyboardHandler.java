/*     */ package fiji.plugin.trackmate.visualization.trackscheme;
/*     */ 
/*     */ import com.mxgraph.swing.util.mxGraphActions;
/*     */ import fiji.plugin.trackmate.util.TrackNavigator;
/*     */ import java.awt.event.ActionEvent;
/*     */ import javax.swing.AbstractAction;
/*     */ import javax.swing.ActionMap;
/*     */ import javax.swing.InputMap;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.KeyStroke;
/*     */ import javax.swing.SwingUtilities;
/*     */ import javax.swing.UIManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TrackSchemeKeyboardHandler
/*     */ {
/*     */   private final TrackNavigator navigator;
/*     */   private final TrackSchemeGraphComponent graphComponent;
/*     */   
/*     */   public TrackSchemeKeyboardHandler(TrackSchemeGraphComponent graphComponent, TrackNavigator navigator) {
/*  48 */     this.graphComponent = graphComponent;
/*  49 */     this.navigator = navigator;
/*     */   }
/*     */ 
/*     */   
/*     */   public void installKeyboardActions(JComponent component) {
/*  54 */     InputMap inputMap = getInputMap(0);
/*  55 */     SwingUtilities.replaceUIInputMap(component, 0, inputMap);
/*     */     
/*  57 */     SwingUtilities.replaceUIActionMap(component, createActionMap());
/*     */   }
/*     */ 
/*     */   
/*     */   protected InputMap getInputMap(int condition) {
/*     */     InputMap map;
/*  63 */     if (condition == 1) {
/*  64 */       map = (InputMap)UIManager.get("ScrollPane.ancestorInputMap");
/*     */     } else {
/*  66 */       map = new InputMap();
/*     */     } 
/*  68 */     map.put(KeyStroke.getKeyStroke("F2"), "edit");
/*  69 */     map.put(KeyStroke.getKeyStroke("DELETE"), "delete");
/*     */     
/*  71 */     map.put(KeyStroke.getKeyStroke("HOME"), "home");
/*  72 */     map.put(KeyStroke.getKeyStroke("END"), "end");
/*     */     
/*  74 */     map.put(KeyStroke.getKeyStroke("ADD"), "zoomIn");
/*  75 */     map.put(KeyStroke.getKeyStroke("EQUALS"), "zoomIn");
/*  76 */     map.put(KeyStroke.getKeyStroke("SUBTRACT"), "zoomOut");
/*  77 */     map.put(KeyStroke.getKeyStroke("MINUS"), "zoomOut");
/*  78 */     map.put(KeyStroke.getKeyStroke("shift EQUALS"), "resetZoom");
/*     */     
/*  80 */     map.put(KeyStroke.getKeyStroke(100, 0), "panLeft");
/*  81 */     map.put(KeyStroke.getKeyStroke(102, 0), "panRight");
/*  82 */     map.put(KeyStroke.getKeyStroke(104, 0), "panUp");
/*  83 */     map.put(KeyStroke.getKeyStroke(98, 0), "panDown");
/*  84 */     map.put(KeyStroke.getKeyStroke(105, 0), "panUpRight");
/*  85 */     map.put(KeyStroke.getKeyStroke(99, 0), "panDownRight");
/*  86 */     map.put(KeyStroke.getKeyStroke(97, 0), "panDownLeft");
/*  87 */     map.put(KeyStroke.getKeyStroke(103, 0), "panUpLeft");
/*     */     
/*  89 */     map.put(KeyStroke.getKeyStroke("control A"), "selectAll");
/*  90 */     map.put(KeyStroke.getKeyStroke("control shift A"), "selectNone");
/*     */     
/*  92 */     map.put(KeyStroke.getKeyStroke("UP"), "selectPreviousInTime");
/*  93 */     map.put(KeyStroke.getKeyStroke("DOWN"), "selectNextInTime");
/*  94 */     map.put(KeyStroke.getKeyStroke("RIGHT"), "selectNextSibling");
/*  95 */     map.put(KeyStroke.getKeyStroke("LEFT"), "selectPreviousSibling");
/*  96 */     map.put(KeyStroke.getKeyStroke("PAGE_DOWN"), "selectNextTrack");
/*  97 */     map.put(KeyStroke.getKeyStroke("PAGE_UP"), "selectPreviousTrack");
/*     */     
/*  99 */     return map;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ActionMap createActionMap() {
/* 107 */     ActionMap map = (ActionMap)UIManager.get("ScrollPane.actionMap");
/*     */     
/* 109 */     map.put("edit", TrackSchemeActions.getEditAction(this.graphComponent));
/* 110 */     map.put("delete", mxGraphActions.getDeleteAction());
/*     */     
/* 112 */     map.put("home", TrackSchemeActions.getHomeAction(this.graphComponent));
/* 113 */     map.put("end", TrackSchemeActions.getEndAction(this.graphComponent));
/*     */     
/* 115 */     map.put("zoomIn", TrackSchemeActions.getZoomInAction(this.graphComponent));
/* 116 */     map.put("zoomOut", TrackSchemeActions.getZoomOutAction(this.graphComponent));
/* 117 */     map.put("resetZoom", TrackSchemeActions.getResetZoomAction(this.graphComponent));
/*     */     
/* 119 */     map.put("panUp", TrackSchemeActions.getPanUpAction(this.graphComponent));
/* 120 */     map.put("panDown", TrackSchemeActions.getPanDownAction(this.graphComponent));
/* 121 */     map.put("panLeft", TrackSchemeActions.getPanLeftAction(this.graphComponent));
/* 122 */     map.put("panRight", TrackSchemeActions.getPanRightAction(this.graphComponent));
/* 123 */     map.put("panUpLeft", TrackSchemeActions.getPanUpLeftAction(this.graphComponent));
/* 124 */     map.put("panDownLeft", TrackSchemeActions.getPanDownLeftAction(this.graphComponent));
/* 125 */     map.put("panUpRight", TrackSchemeActions.getPanUpRightAction(this.graphComponent));
/* 126 */     map.put("panDownRight", TrackSchemeActions.getPanDownRightAction(this.graphComponent));
/*     */     
/* 128 */     map.put("selectNone", TrackSchemeActions.getSelectNoneAction());
/* 129 */     map.put("selectAll", TrackSchemeActions.getSelectAllAction());
/*     */     
/* 131 */     map.put("selectPreviousInTime", new AbstractAction()
/*     */         {
/*     */           private static final long serialVersionUID = 1L;
/*     */ 
/*     */ 
/*     */           
/*     */           public void actionPerformed(ActionEvent arg0) {
/* 138 */             TrackSchemeKeyboardHandler.this.navigator.previousInTime();
/*     */           }
/*     */         });
/* 141 */     map.put("selectNextInTime", new AbstractAction()
/*     */         {
/*     */           private static final long serialVersionUID = 1L;
/*     */ 
/*     */ 
/*     */           
/*     */           public void actionPerformed(ActionEvent arg0) {
/* 148 */             TrackSchemeKeyboardHandler.this.navigator.nextInTime();
/*     */           }
/*     */         });
/* 151 */     map.put("selectNextSibling", new AbstractAction()
/*     */         {
/*     */           private static final long serialVersionUID = 1L;
/*     */ 
/*     */ 
/*     */           
/*     */           public void actionPerformed(ActionEvent arg0) {
/* 158 */             TrackSchemeKeyboardHandler.this.navigator.nextSibling();
/*     */           }
/*     */         });
/* 161 */     map.put("selectPreviousSibling", new AbstractAction()
/*     */         {
/*     */           private static final long serialVersionUID = 1L;
/*     */ 
/*     */ 
/*     */           
/*     */           public void actionPerformed(ActionEvent arg0) {
/* 168 */             TrackSchemeKeyboardHandler.this.navigator.previousSibling();
/*     */           }
/*     */         });
/* 171 */     map.put("selectNextTrack", new AbstractAction()
/*     */         {
/*     */           private static final long serialVersionUID = 1L;
/*     */ 
/*     */ 
/*     */           
/*     */           public void actionPerformed(ActionEvent arg0) {
/* 178 */             TrackSchemeKeyboardHandler.this.navigator.nextTrack();
/*     */           }
/*     */         });
/* 181 */     map.put("selectPreviousTrack", new AbstractAction()
/*     */         {
/*     */           private static final long serialVersionUID = 1L;
/*     */ 
/*     */ 
/*     */           
/*     */           public void actionPerformed(ActionEvent arg0) {
/* 188 */             TrackSchemeKeyboardHandler.this.navigator.previousTrack();
/*     */           }
/*     */         });
/*     */     
/* 192 */     return map;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/visualization/trackscheme/TrackSchemeKeyboardHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */