/*     */ package fiji.plugin.trackmate;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.Stack;
/*     */ import org.jgrapht.graph.DefaultWeightedEdge;
/*     */ import org.jgrapht.traverse.GraphIterator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SelectionModel
/*     */ {
/*     */   private static final boolean DEBUG = false;
/*  45 */   private Set<Spot> spotSelection = new HashSet<>();
/*     */   
/*  47 */   private Set<DefaultWeightedEdge> edgeSelection = new HashSet<>();
/*     */   
/*  49 */   private List<SelectionChangeListener> selectionChangeListeners = new ArrayList<>();
/*     */ 
/*     */ 
/*     */   
/*     */   private final Model model;
/*     */ 
/*     */ 
/*     */   
/*     */   public SelectionModel(Model parent) {
/*  58 */     this.model = parent;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean addSelectionChangeListener(SelectionChangeListener listener) {
/*  66 */     return this.selectionChangeListeners.add(listener);
/*     */   }
/*     */   
/*     */   public boolean removeSelectionChangeListener(SelectionChangeListener listener) {
/*  70 */     return this.selectionChangeListeners.remove(listener);
/*     */   }
/*     */   
/*     */   public List<SelectionChangeListener> getSelectionChangeListener() {
/*  74 */     return this.selectionChangeListeners;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void clearSelection() {
/*  85 */     Map<Spot, Boolean> spotMap = new HashMap<>(this.spotSelection.size());
/*  86 */     for (Spot spot : this.spotSelection)
/*  87 */       spotMap.put(spot, Boolean.valueOf(false)); 
/*  88 */     Map<DefaultWeightedEdge, Boolean> edgeMap = new HashMap<>(this.edgeSelection.size());
/*  89 */     for (DefaultWeightedEdge edge : this.edgeSelection)
/*  90 */       edgeMap.put(edge, Boolean.valueOf(false)); 
/*  91 */     SelectionChangeEvent event = new SelectionChangeEvent(this, spotMap, edgeMap);
/*     */     
/*  93 */     clearSpotSelection();
/*  94 */     clearEdgeSelection();
/*     */     
/*  96 */     for (SelectionChangeListener listener : this.selectionChangeListeners) {
/*  97 */       listener.selectionChanged(event);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void clearSpotSelection() {
/* 104 */     Map<Spot, Boolean> spotMap = new HashMap<>(this.spotSelection.size());
/* 105 */     for (Spot spot : this.spotSelection)
/* 106 */       spotMap.put(spot, Boolean.valueOf(false)); 
/* 107 */     SelectionChangeEvent event = new SelectionChangeEvent(this, spotMap, null);
/*     */     
/* 109 */     this.spotSelection.clear();
/*     */     
/* 111 */     for (SelectionChangeListener listener : this.selectionChangeListeners) {
/* 112 */       listener.selectionChanged(event);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void clearEdgeSelection() {
/* 119 */     Map<DefaultWeightedEdge, Boolean> edgeMap = new HashMap<>(this.edgeSelection.size());
/* 120 */     for (DefaultWeightedEdge edge : this.edgeSelection)
/* 121 */       edgeMap.put(edge, Boolean.valueOf(false)); 
/* 122 */     SelectionChangeEvent event = new SelectionChangeEvent(this, null, edgeMap);
/*     */     
/* 124 */     this.edgeSelection.clear();
/*     */     
/* 126 */     for (SelectionChangeListener listener : this.selectionChangeListeners)
/* 127 */       listener.selectionChanged(event); 
/*     */   }
/*     */   
/*     */   public void addSpotToSelection(Spot spot) {
/* 131 */     if (!this.spotSelection.add(spot)) {
/*     */       return;
/*     */     }
/*     */     
/* 135 */     Map<Spot, Boolean> spotMap = new HashMap<>(1);
/* 136 */     spotMap.put(spot, Boolean.valueOf(true));
/*     */ 
/*     */     
/* 139 */     SelectionChangeEvent event = new SelectionChangeEvent(this, spotMap, null);
/* 140 */     for (SelectionChangeListener listener : this.selectionChangeListeners)
/* 141 */       listener.selectionChanged(event); 
/*     */   }
/*     */   
/*     */   public void removeSpotFromSelection(Spot spot) {
/* 145 */     if (!this.spotSelection.remove(spot)) {
/*     */       return;
/*     */     }
/*     */     
/* 149 */     Map<Spot, Boolean> spotMap = new HashMap<>(1);
/* 150 */     spotMap.put(spot, Boolean.valueOf(false));
/* 151 */     SelectionChangeEvent event = new SelectionChangeEvent(this, spotMap, null);
/* 152 */     for (SelectionChangeListener listener : this.selectionChangeListeners)
/* 153 */       listener.selectionChanged(event); 
/*     */   }
/*     */   
/*     */   public void addSpotToSelection(Collection<Spot> spots) {
/* 157 */     Map<Spot, Boolean> spotMap = new HashMap<>(spots.size());
/* 158 */     for (Spot spot : spots) {
/* 159 */       if (this.spotSelection.add(spot)) {
/* 160 */         spotMap.put(spot, Boolean.valueOf(true));
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 165 */     SelectionChangeEvent event = new SelectionChangeEvent(this, spotMap, null);
/*     */ 
/*     */     
/* 168 */     for (SelectionChangeListener listener : this.selectionChangeListeners)
/* 169 */       listener.selectionChanged(event); 
/*     */   }
/*     */   
/*     */   public void removeSpotFromSelection(Collection<Spot> spots) {
/* 173 */     Map<Spot, Boolean> spotMap = new HashMap<>(spots.size());
/* 174 */     for (Spot spot : spots) {
/* 175 */       if (this.spotSelection.remove(spot)) {
/* 176 */         spotMap.put(spot, Boolean.valueOf(false));
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 181 */     SelectionChangeEvent event = new SelectionChangeEvent(this, spotMap, null);
/* 182 */     for (SelectionChangeListener listener : this.selectionChangeListeners)
/* 183 */       listener.selectionChanged(event); 
/*     */   }
/*     */   
/*     */   public void addEdgeToSelection(DefaultWeightedEdge edge) {
/* 187 */     if (!this.edgeSelection.add(edge)) {
/*     */       return;
/*     */     }
/*     */     
/* 191 */     Map<DefaultWeightedEdge, Boolean> edgeMap = new HashMap<>(1);
/* 192 */     edgeMap.put(edge, Boolean.valueOf(true));
/* 193 */     SelectionChangeEvent event = new SelectionChangeEvent(this, null, edgeMap);
/* 194 */     for (SelectionChangeListener listener : this.selectionChangeListeners) {
/* 195 */       listener.selectionChanged(event);
/*     */     }
/*     */   }
/*     */   
/*     */   public void removeEdgeFromSelection(DefaultWeightedEdge edge) {
/* 200 */     if (!this.edgeSelection.remove(edge)) {
/*     */       return;
/*     */     }
/*     */     
/* 204 */     Map<DefaultWeightedEdge, Boolean> edgeMap = new HashMap<>(1);
/* 205 */     edgeMap.put(edge, Boolean.valueOf(false));
/* 206 */     SelectionChangeEvent event = new SelectionChangeEvent(this, null, edgeMap);
/* 207 */     for (SelectionChangeListener listener : this.selectionChangeListeners) {
/* 208 */       listener.selectionChanged(event);
/*     */     }
/*     */   }
/*     */   
/*     */   public void addEdgeToSelection(Collection<DefaultWeightedEdge> edges) {
/* 213 */     Map<DefaultWeightedEdge, Boolean> edgeMap = new HashMap<>(edges.size());
/* 214 */     for (DefaultWeightedEdge edge : edges) {
/* 215 */       if (this.edgeSelection.add(edge)) {
/* 216 */         edgeMap.put(edge, Boolean.valueOf(true));
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 221 */     SelectionChangeEvent event = new SelectionChangeEvent(this, null, edgeMap);
/* 222 */     for (SelectionChangeListener listener : this.selectionChangeListeners)
/* 223 */       listener.selectionChanged(event); 
/*     */   }
/*     */   
/*     */   public void removeEdgeFromSelection(Collection<DefaultWeightedEdge> edges) {
/* 227 */     Map<DefaultWeightedEdge, Boolean> edgeMap = new HashMap<>(edges.size());
/* 228 */     for (DefaultWeightedEdge edge : edges) {
/* 229 */       if (this.edgeSelection.remove(edge)) {
/* 230 */         edgeMap.put(edge, Boolean.valueOf(false));
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 235 */     SelectionChangeEvent event = new SelectionChangeEvent(this, null, edgeMap);
/* 236 */     for (SelectionChangeListener listener : this.selectionChangeListeners)
/* 237 */       listener.selectionChanged(event); 
/*     */   }
/*     */   
/*     */   public Set<Spot> getSpotSelection() {
/* 241 */     return this.spotSelection;
/*     */   }
/*     */   
/*     */   public Set<DefaultWeightedEdge> getEdgeSelection() {
/* 245 */     return this.edgeSelection;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void selectTrack(Collection<Spot> spots, Collection<DefaultWeightedEdge> edges, int direction) {
/* 264 */     HashSet<Spot> inspectionSpots = new HashSet<>(spots);
/*     */     
/* 266 */     for (DefaultWeightedEdge edge : edges) {
/*     */       
/* 268 */       inspectionSpots.add(this.model.getTrackModel().getEdgeSource(edge));
/* 269 */       inspectionSpots.add(this.model.getTrackModel().getEdgeTarget(edge));
/*     */     } 
/*     */ 
/*     */     
/* 273 */     HashSet<Spot> lSpotSelection = new HashSet<>();
/* 274 */     HashSet<DefaultWeightedEdge> lEdgeSelection = new HashSet<>();
/*     */     
/* 276 */     if (direction == 0) {
/* 277 */       for (Spot spot : inspectionSpots) {
/* 278 */         lSpotSelection.add(spot);
/* 279 */         GraphIterator<Spot, DefaultWeightedEdge> walker = this.model.getTrackModel().getDepthFirstIterator(spot, false);
/* 280 */         while (walker.hasNext()) {
/* 281 */           Spot target = (Spot)walker.next();
/* 282 */           lSpotSelection.add(target);
/*     */           
/* 284 */           Set<DefaultWeightedEdge> targetEdges = this.model.getTrackModel().edgesOf(target);
/* 285 */           for (DefaultWeightedEdge targetEdge : targetEdges) {
/* 286 */             lEdgeSelection.add(targetEdge);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } else {
/*     */       
/* 292 */       for (Spot spot : inspectionSpots) {
/* 293 */         lSpotSelection.add(spot);
/*     */ 
/*     */ 
/*     */         
/* 297 */         Stack<Spot> stack = new Stack<>();
/* 298 */         stack.add(spot);
/* 299 */         while (!stack.isEmpty()) {
/* 300 */           Spot inspected = stack.pop();
/* 301 */           Set<DefaultWeightedEdge> targetEdges = this.model.getTrackModel().edgesOf(inspected);
/* 302 */           for (DefaultWeightedEdge targetEdge : targetEdges) {
/*     */             Spot other;
/* 304 */             if (direction > 0) {
/*     */               
/* 306 */               other = this.model.getTrackModel().getEdgeSource(targetEdge);
/*     */             } else {
/* 308 */               other = this.model.getTrackModel().getEdgeTarget(targetEdge);
/*     */             } 
/*     */             
/* 311 */             if (other != inspected) {
/* 312 */               lSpotSelection.add(other);
/* 313 */               lEdgeSelection.add(targetEdge);
/* 314 */               stack.add(other);
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 323 */     ArrayList<DefaultWeightedEdge> edgesToRemove = new ArrayList<>();
/* 324 */     for (DefaultWeightedEdge edge : lEdgeSelection) {
/* 325 */       Spot source = this.model.getTrackModel().getEdgeSource(edge);
/* 326 */       Spot target = this.model.getTrackModel().getEdgeTarget(edge);
/* 327 */       if (!lSpotSelection.contains(source) || !lSpotSelection.contains(target)) {
/* 328 */         edgesToRemove.add(edge);
/*     */       }
/*     */     } 
/* 331 */     lEdgeSelection.removeAll(edgesToRemove);
/*     */ 
/*     */     
/* 334 */     addSpotToSelection(lSpotSelection);
/* 335 */     addEdgeToSelection(lEdgeSelection);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/SelectionModel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */