package fiji.plugin.trackmate.features.spot;

public interface SpotMorphologyAnalyzerFactory<T extends net.imglib2.type.numeric.RealType<T> & net.imglib2.type.NativeType<T>> extends SpotAnalyzerFactoryBase<T> {}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/features/spot/SpotMorphologyAnalyzerFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */