/*     */ package fiji.plugin.trackmate.action;
/*     */ 
/*     */ import fiji.plugin.trackmate.Logger;
/*     */ import fiji.plugin.trackmate.Model;
/*     */ import fiji.plugin.trackmate.SelectionModel;
/*     */ import fiji.plugin.trackmate.Settings;
/*     */ import fiji.plugin.trackmate.Spot;
/*     */ import fiji.plugin.trackmate.TrackMate;
/*     */ import fiji.plugin.trackmate.gui.Icons;
/*     */ import fiji.plugin.trackmate.gui.displaysettings.DisplaySettings;
/*     */ import fiji.plugin.trackmate.util.TMUtils;
/*     */ import fiji.plugin.trackmate.visualization.trackscheme.SpotIconGrabber;
/*     */ import ij.CompositeImage;
/*     */ import ij.ImagePlus;
/*     */ import ij.ImageStack;
/*     */ import ij.gui.GenericDialog;
/*     */ import ij.measure.Calibration;
/*     */ import ij.process.ImageProcessor;
/*     */ import java.awt.Frame;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import java.util.TreeSet;
/*     */ import javax.swing.ImageIcon;
/*     */ import net.imagej.ImgPlus;
/*     */ import net.imglib2.RandomAccessibleInterval;
/*     */ import net.imglib2.img.Img;
/*     */ import net.imglib2.img.display.imagej.ImageJFunctions;
/*     */ import net.imglib2.view.Views;
/*     */ import org.jgrapht.graph.DefaultWeightedEdge;
/*     */ import org.scijava.plugin.Plugin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ExtractTrackStackAction
/*     */   extends AbstractTMAction
/*     */ {
/*     */   public static final String NAME = "Extract track stack";
/*     */   public static final String KEY = "EXTRACT_TRACK_STACK";
/*     */   public static final String INFO_TEXT = "<html> Generate a stack of images taken from the track that joins two selected spots. <p> There must be exactly 1 or 2 spots selected for this action to work. If only one spot is selected, then the stack is extracted from the track it belongs to, from the first spot in time to the last in time. If there are two spots selected, they must belong to a track that connects them. A path is then found that joins them and the stack is extracted from this path.<p> A stack of images will be generated from the spots that join them. A GUI allows specifying the size of the extract, in units of the largest spot in the track, and whether to capture a 2D or 3D stack over time. All channels are captured. </html>";
/*  84 */   private static double diameterFactor = 1.5D;
/*     */   
/*  86 */   private static int dimChoice = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final float RESIZE_FACTOR = 1.5F;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void execute(TrackMate trackmate, SelectionModel selectionModel, DisplaySettings displaySettings, Frame parent) {
/* 102 */     GenericDialog dialog = new GenericDialog("Extract track stack", parent);
/*     */ 
/*     */     
/* 105 */     dialog.addSlider("Image size (spot\ndiameter units):", 0.1D, 5.1D, diameterFactor);
/*     */ 
/*     */     
/* 108 */     String[] dimChoices = { "Central slice ", "3D" };
/* 109 */     dialog.addRadioButtonGroup("Dimensionality:", dimChoices, 2, 1, dimChoices[dimChoice]);
/*     */ 
/*     */     
/* 112 */     dialog.showDialog();
/* 113 */     if (dialog.wasCanceled()) {
/*     */       return;
/*     */     }
/* 116 */     diameterFactor = dialog.getNextNumber();
/* 117 */     dimChoice = Arrays.<String>asList(dimChoices).indexOf(dialog.getNextRadioButton());
/* 118 */     boolean do3d = (dimChoice == 1);
/*     */     
/* 120 */     this.logger.log("Capturing " + (do3d ? "3D" : "2D") + " track stack.\n");
/*     */     
/* 122 */     Model model = trackmate.getModel();
/* 123 */     Set<Spot> selection = selectionModel.getSpotSelection();
/* 124 */     int nspots = selection.size();
/* 125 */     if (nspots != 2) {
/*     */       
/* 127 */       if (nspots == 1) {
/*     */         
/* 129 */         Spot spot = selection.iterator().next();
/*     */ 
/*     */         
/* 132 */         Integer trackID = model.getTrackModel().trackIDOf(spot);
/* 133 */         List<Spot> spots = new ArrayList<>(model.getTrackModel().trackSpots(trackID));
/* 134 */         Collections.sort(spots, Spot.frameComparator);
/* 135 */         Spot start = spots.get(0);
/* 136 */         Spot end = spots.get(spots.size() - 1);
/* 137 */         selectionModel.clearSelection();
/* 138 */         selectionModel.addSpotToSelection(start);
/* 139 */         selectionModel.addSpotToSelection(end);
/* 140 */         List<DefaultWeightedEdge> edges = model.getTrackModel().dijkstraShortestPath(start, end);
/* 141 */         if (null == edges) {
/*     */           
/* 143 */           this.logger.error("The 2 spots are not connected.\nAborting\n");
/*     */           return;
/*     */         } 
/* 146 */         selectionModel.addEdgeToSelection(edges);
/*     */ 
/*     */         
/* 149 */         ImagePlus imp = trackStack(trackmate, spot, do3d, this.logger);
/* 150 */         imp.show();
/* 151 */         imp.setZ(imp.getNSlices() / 2 + 1);
/* 152 */         imp.resetDisplayRange();
/*     */       }
/*     */       else {
/*     */         
/* 156 */         this.logger.error("Expected 1 or 2 spots in the selection, got " + nspots + ".\nAborting.\n");
/*     */         
/*     */         return;
/*     */       } 
/*     */     } else {
/*     */       Spot start1, end1;
/* 162 */       Iterator<Spot> it = selection.iterator();
/* 163 */       Spot start = it.next();
/* 164 */       Spot end = it.next();
/*     */ 
/*     */       
/* 167 */       selectionModel.clearSelection();
/* 168 */       selectionModel.addSpotToSelection(start);
/* 169 */       selectionModel.addSpotToSelection(end);
/*     */ 
/*     */       
/* 172 */       if (start.getFeature("POSITION_T").doubleValue() > end.getFeature("POSITION_T").doubleValue()) {
/*     */         
/* 174 */         end1 = start;
/* 175 */         start1 = end;
/*     */       }
/*     */       else {
/*     */         
/* 179 */         end1 = end;
/* 180 */         start1 = start;
/*     */       } 
/* 182 */       List<DefaultWeightedEdge> edges = model.getTrackModel().dijkstraShortestPath(start1, end1);
/* 183 */       if (null == edges) {
/*     */         
/* 185 */         this.logger.error("The 2 spots are not connected.\nAborting\n");
/*     */         return;
/*     */       } 
/* 188 */       selectionModel.addEdgeToSelection(edges);
/*     */ 
/*     */       
/* 191 */       ImagePlus imp = trackStack(trackmate, start1, end1, do3d, this.logger);
/* 192 */       imp.show();
/* 193 */       imp.setZ(imp.getNSlices() / 2 + 1);
/* 194 */       imp.resetDisplayRange();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final ImagePlus trackStack(TrackMate trackmate, Spot spot, boolean do3d, Logger logger) {
/* 204 */     Model model = trackmate.getModel();
/* 205 */     Integer trackID = model.getTrackModel().trackIDOf(spot);
/* 206 */     List<Spot> spots = new ArrayList<>(model.getTrackModel().trackSpots(trackID));
/* 207 */     Collections.sort(spots, Spot.frameComparator);
/* 208 */     Spot start = spots.get(0);
/* 209 */     Spot end = spots.get(spots.size() - 1);
/* 210 */     return trackStack(trackmate, start, end, do3d, logger);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final ImagePlus trackStack(TrackMate trackmate, Spot start, Spot end, boolean do3d, Logger logger) {
/*     */     Spot start1, end1;
/* 220 */     Model model = trackmate.getModel();
/*     */ 
/*     */     
/* 223 */     if (start.getFeature("POSITION_T").doubleValue() > end.getFeature("POSITION_T").doubleValue()) {
/*     */       
/* 225 */       end1 = start;
/* 226 */       start1 = end;
/*     */     }
/*     */     else {
/*     */       
/* 230 */       end1 = end;
/* 231 */       start1 = start;
/*     */     } 
/* 233 */     List<DefaultWeightedEdge> edges = model.getTrackModel().dijkstraShortestPath(start1, end1);
/* 234 */     if (null == edges) {
/*     */       
/* 236 */       logger.error("The 2 spots are not connected.\nAborting\n");
/* 237 */       return null;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 243 */     List<Spot> path = new ArrayList<>(edges.size());
/* 244 */     path.add(start1);
/* 245 */     Spot previous = start1;
/*     */     
/* 247 */     double radius = Math.abs(start1.getFeature("RADIUS").doubleValue()) * diameterFactor;
/* 248 */     for (DefaultWeightedEdge edge : edges) {
/*     */       
/* 250 */       Spot current = model.getTrackModel().getEdgeSource(edge);
/* 251 */       if (current == previous)
/*     */       {
/* 253 */         current = model.getTrackModel().getEdgeTarget(edge);
/*     */       }
/* 255 */       path.add(current);
/* 256 */       double ct = Math.abs(current.getFeature("RADIUS").doubleValue());
/* 257 */       if (ct > radius)
/*     */       {
/* 259 */         radius = ct;
/*     */       }
/* 261 */       previous = current;
/*     */     } 
/* 263 */     path.add(end1);
/*     */ 
/*     */     
/* 266 */     TreeSet<Spot> sortedSpots = new TreeSet<>(Spot.timeComparator);
/* 267 */     sortedSpots.addAll(path);
/* 268 */     return trackStack(trackmate.getSettings(), path, radius, do3d, logger);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final ImagePlus trackStack(Settings settings, List<Spot> path, double radius, boolean do3d, Logger logger) {
/* 279 */     int depth, nspots = path.size();
/*     */ 
/*     */     
/* 282 */     double[] calibration = TMUtils.getSpatialCalibration(settings.imp);
/* 283 */     int width = (int)Math.ceil(2.0D * radius * 1.5D / calibration[0]);
/* 284 */     int height = (int)Math.ceil(2.0D * radius * 1.5D / calibration[1]);
/*     */     
/* 286 */     if (do3d) {
/* 287 */       depth = (int)Math.ceil(2.0D * radius * 1.5D / calibration[2]);
/*     */     } else {
/* 289 */       depth = 1;
/*     */     } 
/*     */     
/* 292 */     ImgPlus img = TMUtils.rawWraps(settings.imp);
/*     */ 
/*     */     
/* 295 */     ImageStack stack = new ImageStack(width, height);
/*     */ 
/*     */     
/* 298 */     int progress = 0;
/* 299 */     int nChannels = settings.imp.getNChannels();
/*     */     
/* 301 */     for (Spot spot : path) {
/*     */ 
/*     */ 
/*     */       
/* 305 */       int frame = spot.getFeature("FRAME").intValue();
/*     */       
/* 307 */       for (int c = 0; c < nChannels; c++) {
/*     */         
/* 309 */         ImgPlus imgCT = TMUtils.hyperSlice(img, c, frame);
/*     */ 
/*     */         
/* 312 */         int x = (int)(Math.round(spot.getFeature("POSITION_X").doubleValue() / calibration[0]) - (width / 2));
/* 313 */         int y = (int)(Math.round(spot.getFeature("POSITION_Y").doubleValue() / calibration[1]) - (height / 2));
/* 314 */         long slice = 0L;
/* 315 */         if (imgCT.numDimensions() > 2) {
/*     */           
/* 317 */           slice = Math.round(spot.getFeature("POSITION_Z").doubleValue() / calibration[2]);
/* 318 */           if (slice < 0L) {
/* 319 */             slice = 0L;
/*     */           }
/* 321 */           if (slice >= imgCT.dimension(2)) {
/* 322 */             slice = imgCT.dimension(2) - 1L;
/*     */           }
/*     */         } 
/* 325 */         SpotIconGrabber<?> grabber = new SpotIconGrabber(imgCT);
/* 326 */         if (do3d) {
/*     */           
/* 328 */           Img crop = grabber.grabImage(x, y, slice, width, height, depth);
/*     */           
/* 330 */           for (int i = 0; i < crop.dimension(2); i++)
/*     */           {
/* 332 */             ImageProcessor processor = ImageJFunctions.wrap((RandomAccessibleInterval)Views.hyperSlice((RandomAccessibleInterval)crop, 2, i), crop.toString()).getProcessor();
/* 333 */             stack.addSlice(spot.toString(), processor);
/*     */           }
/*     */         
/*     */         } else {
/*     */           
/* 338 */           Img crop = grabber.grabImage(x, y, slice, width, height);
/* 339 */           stack.addSlice(spot.toString(), ImageJFunctions.wrap((RandomAccessibleInterval)crop, crop.toString()).getProcessor());
/*     */         } 
/*     */       } 
/* 342 */       logger.setProgress(((progress + 1) / nspots));
/* 343 */       progress++;
/*     */     } 
/*     */ 
/*     */     
/* 347 */     ImagePlus stackTrack = new ImagePlus("", stack);
/* 348 */     stackTrack.setTitle("Path from " + path.get(0) + " to " + path.get(path.size() - 1));
/* 349 */     Calibration impCal = stackTrack.getCalibration();
/* 350 */     impCal.setTimeUnit(settings.imp.getCalibration().getTimeUnit());
/* 351 */     impCal.setUnit(settings.imp.getCalibration().getUnit());
/* 352 */     impCal.pixelWidth = calibration[0];
/* 353 */     impCal.pixelHeight = calibration[1];
/* 354 */     impCal.pixelDepth = calibration[2];
/* 355 */     impCal.frameInterval = settings.dt;
/* 356 */     stackTrack.setDimensions(nChannels, depth, nspots);
/* 357 */     stackTrack.setOpenAsHyperStack(true);
/* 358 */     logger.log("Done.");
/*     */ 
/*     */     
/* 361 */     if (nChannels > 1) {
/*     */       
/* 363 */       CompositeImage cmp = new CompositeImage(stackTrack, 1);
/* 364 */       if (settings.imp instanceof CompositeImage) {
/*     */         
/* 366 */         CompositeImage scmp = (CompositeImage)settings.imp;
/* 367 */         for (int c = 0; c < nChannels; c++)
/* 368 */           cmp.setChannelLut(scmp.getChannelLut(c + 1), c + 1); 
/*     */       } 
/* 370 */       return (ImagePlus)cmp;
/*     */     } 
/* 372 */     return stackTrack;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Plugin(type = TrackMateActionFactory.class)
/*     */   public static class ExtractTrackStackActionFactory
/*     */     implements TrackMateActionFactory
/*     */   {
/*     */     public String getInfoText() {
/* 382 */       return "<html> Generate a stack of images taken from the track that joins two selected spots. <p> There must be exactly 1 or 2 spots selected for this action to work. If only one spot is selected, then the stack is extracted from the track it belongs to, from the first spot in time to the last in time. If there are two spots selected, they must belong to a track that connects them. A path is then found that joins them and the stack is extracted from this path.<p> A stack of images will be generated from the spots that join them. A GUI allows specifying the size of the extract, in units of the largest spot in the track, and whether to capture a 2D or 3D stack over time. All channels are captured. </html>";
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public String getName() {
/* 388 */       return "Extract track stack";
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public String getKey() {
/* 394 */       return "EXTRACT_TRACK_STACK";
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public ImageIcon getIcon() {
/* 400 */       return Icons.MAGNIFIER_ICON;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public TrackMateAction create() {
/* 406 */       return new ExtractTrackStackAction();
/*     */     }
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/action/ExtractTrackStackAction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */