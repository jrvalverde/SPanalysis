/*     */ package fiji.plugin.trackmate.visualization.trackscheme;
/*     */ 
/*     */ import com.mxgraph.canvas.mxSvgCanvas;
/*     */ import com.mxgraph.util.mxConstants;
/*     */ import com.mxgraph.util.mxRectangle;
/*     */ import com.mxgraph.util.mxUtils;
/*     */ import java.util.Map;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TrackSchemeSvgCanvas
/*     */   extends mxSvgCanvas
/*     */ {
/*     */   public TrackSchemeSvgCanvas(Document document) {
/*  37 */     super(document);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Element drawShape(int x, int y, int w, int h, Map<String, Object> style) {
/*  43 */     String fillColor = mxUtils.getString(style, mxConstants.STYLE_FILLCOLOR, "none");
/*  44 */     String gradientColor = mxUtils.getString(style, mxConstants.STYLE_GRADIENTCOLOR, "none");
/*  45 */     String strokeColor = mxUtils.getString(style, mxConstants.STYLE_STROKECOLOR, "none");
/*  46 */     float strokeWidth = (float)(mxUtils.getFloat(style, mxConstants.STYLE_STROKEWIDTH, 1.0F) * this.scale);
/*  47 */     float opacity = mxUtils.getFloat(style, mxConstants.STYLE_OPACITY, 100.0F);
/*     */ 
/*     */     
/*  50 */     String shape = mxUtils.getString(style, mxConstants.STYLE_SHAPE, "");
/*  51 */     Element elem = null;
/*  52 */     Element background = null;
/*     */     
/*  54 */     if (!shape.equals("scaledLabel")) {
/*  55 */       return super.drawShape(x, y, w, h, style);
/*     */     }
/*  57 */     background = this.document.createElement("rect");
/*  58 */     elem = background;
/*     */     
/*  60 */     elem.setAttribute("x", String.valueOf(x));
/*  61 */     elem.setAttribute("y", String.valueOf(y));
/*  62 */     elem.setAttribute("width", String.valueOf(w));
/*  63 */     elem.setAttribute("height", String.valueOf(h));
/*     */     
/*  65 */     if (mxUtils.isTrue(style, mxConstants.STYLE_ROUNDED, false)) {
/*  66 */       String r = String.valueOf(Math.min(w * mxConstants.RECTANGLE_ROUNDING_FACTOR, h * mxConstants.RECTANGLE_ROUNDING_FACTOR));
/*     */ 
/*     */ 
/*     */       
/*  70 */       elem.setAttribute("rx", r);
/*  71 */       elem.setAttribute("ry", r);
/*     */     } 
/*     */     
/*  74 */     String img = getImageForStyle(style);
/*     */     
/*  76 */     if (img != null) {
/*  77 */       String imgAlign = mxUtils.getString(style, mxConstants.STYLE_IMAGE_ALIGN, "left");
/*  78 */       String imgValign = mxUtils.getString(style, mxConstants.STYLE_IMAGE_VERTICAL_ALIGN, "middle");
/*  79 */       int imgWidth = (int)(mxUtils.getInt(style, mxConstants.STYLE_IMAGE_WIDTH, mxConstants.DEFAULT_IMAGESIZE) * this.scale);
/*  80 */       int imgHeight = (int)(mxUtils.getInt(style, mxConstants.STYLE_IMAGE_HEIGHT, mxConstants.DEFAULT_IMAGESIZE) * this.scale);
/*  81 */       int spacing = (int)(mxUtils.getInt(style, mxConstants.STYLE_SPACING, 2) * this.scale);
/*     */       
/*  83 */       mxRectangle imageBounds = getImageBounds(x, y, w, h);
/*     */       
/*  85 */       if (imgAlign.equals("center")) {
/*  86 */         imageBounds.setX(imageBounds.getX() + (imageBounds.getWidth() - imgWidth) / 2.0D);
/*  87 */       } else if (imgAlign.equals("right")) {
/*  88 */         imageBounds.setX(imageBounds.getX() + imageBounds
/*  89 */             .getWidth() - imgWidth - spacing - 2.0D);
/*     */       } else {
/*     */         
/*  92 */         imageBounds.setX(imageBounds.getX() + spacing + 4.0D);
/*     */       } 
/*     */       
/*  95 */       if (imgValign.equals("top")) {
/*  96 */         imageBounds.setY(imageBounds.getY() + spacing);
/*  97 */       } else if (imgValign.equals("bottom")) {
/*  98 */         imageBounds.setY(imageBounds.getY() + imageBounds
/*  99 */             .getHeight() - imgHeight - spacing);
/*     */       } else {
/*     */         
/* 102 */         imageBounds.setY(imageBounds.getY() + (imageBounds.getHeight() - imgHeight) / 2.0D);
/*     */       } 
/*     */       
/* 105 */       imageBounds.setWidth(imgWidth);
/* 106 */       imageBounds.setHeight(imgHeight);
/*     */       
/* 108 */       elem = this.document.createElement("g");
/* 109 */       elem.appendChild(background);
/*     */       
/* 111 */       Element imageElement = createImageElement(imageBounds
/* 112 */           .getX(), imageBounds.getY(), imageBounds
/* 113 */           .getWidth(), imageBounds.getHeight(), img, false, false, false, 
/* 114 */           isEmbedded());
/*     */       
/* 116 */       if (opacity != 100.0F) {
/* 117 */         String value = String.valueOf(opacity / 100.0F);
/* 118 */         imageElement.setAttribute("opacity", value);
/*     */       } 
/*     */       
/* 121 */       elem.appendChild(imageElement);
/*     */     } 
/*     */ 
/*     */     
/* 125 */     if (mxUtils.isTrue(style, mxConstants.STYLE_GLASS, false)) {
/* 126 */       double size = 0.4D;
/*     */ 
/*     */ 
/*     */       
/* 130 */       Element glassOverlay = this.document.createElement("path");
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 135 */       glassOverlay.setAttribute("fill", "url(#" + 
/* 136 */           getGlassGradientElement().getAttribute("id") + ")");
/*     */ 
/*     */       
/* 139 */       String d = "m " + (x - strokeWidth) + "," + (y - strokeWidth) + " L " + (x - strokeWidth) + "," + (y + h * size) + " Q " + (x + w * 0.5D) + "," + (y + h * 0.7D) + " " + ((x + w) + strokeWidth) + "," + (y + h * size) + " L " + ((x + w) + strokeWidth) + "," + (y - strokeWidth) + " z";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 146 */       glassOverlay.setAttribute("stroke-width", 
/* 147 */           String.valueOf(strokeWidth / 2.0F));
/* 148 */       glassOverlay.setAttribute("d", d);
/* 149 */       elem.appendChild(glassOverlay);
/*     */     } 
/*     */     
/* 152 */     double rotation = mxUtils.getDouble(style, mxConstants.STYLE_ROTATION);
/* 153 */     int cx = x + w / 2;
/* 154 */     int cy = y + h / 2;
/*     */     
/* 156 */     Element bg = background;
/*     */     
/* 158 */     if (bg == null) {
/* 159 */       bg = elem;
/*     */     }
/*     */     
/* 162 */     if (!bg.getNodeName().equalsIgnoreCase("use") && !bg.getNodeName().equalsIgnoreCase("image")) {
/* 163 */       if (!fillColor.equalsIgnoreCase("none") && !gradientColor.equalsIgnoreCase("none")) {
/* 164 */         String direction = mxUtils.getString(style, mxConstants.STYLE_GRADIENT_DIRECTION);
/* 165 */         Element gradient = getGradientElement(fillColor, gradientColor, direction);
/*     */         
/* 167 */         if (gradient != null) {
/* 168 */           bg.setAttribute("fill", "url(#" + gradient.getAttribute("id") + ")");
/*     */         }
/*     */       } else {
/* 171 */         bg.setAttribute("fill", fillColor);
/*     */       } 
/*     */       
/* 174 */       bg.setAttribute("stroke", strokeColor);
/* 175 */       bg.setAttribute("stroke-width", String.valueOf(strokeWidth));
/*     */ 
/*     */       
/* 178 */       Element shadowElement = null;
/*     */       
/* 180 */       if (mxUtils.isTrue(style, mxConstants.STYLE_SHADOW, false) && !fillColor.equals("none")) {
/* 181 */         shadowElement = (Element)bg.cloneNode(true);
/*     */         
/* 183 */         shadowElement.setAttribute("transform", mxConstants.SVG_SHADOWTRANSFORM);
/* 184 */         shadowElement.setAttribute("fill", mxConstants.W3C_SHADOWCOLOR);
/* 185 */         shadowElement.setAttribute("stroke", mxConstants.W3C_SHADOWCOLOR);
/* 186 */         shadowElement.setAttribute("stroke-width", String.valueOf(strokeWidth));
/*     */         
/* 188 */         if (rotation != 0.0D) {
/* 189 */           shadowElement.setAttribute("transform", "rotate(" + rotation + "," + cx + "," + cy + ") " + mxConstants.SVG_SHADOWTRANSFORM);
/*     */         }
/*     */ 
/*     */ 
/*     */         
/* 194 */         if (opacity != 100.0F) {
/* 195 */           String value = String.valueOf(opacity / 100.0F);
/* 196 */           shadowElement.setAttribute("fill-opacity", value);
/* 197 */           shadowElement.setAttribute("stroke-opacity", value);
/*     */         } 
/*     */         
/* 200 */         appendSvgElement(shadowElement);
/*     */       } 
/*     */     } 
/*     */     
/* 204 */     if (rotation != 0.0D) {
/* 205 */       elem.setAttribute("transform", elem.getAttribute("transform") + " rotate(" + rotation + "," + cx + "," + cy + ")");
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 210 */     if (opacity != 100.0F) {
/* 211 */       String value = String.valueOf(opacity / 100.0F);
/* 212 */       elem.setAttribute("fill-opacity", value);
/* 213 */       elem.setAttribute("stroke-opacity", value);
/*     */     } 
/*     */     
/* 216 */     if (mxUtils.isTrue(style, mxConstants.STYLE_DASHED)) {
/* 217 */       elem.setAttribute("stroke-dasharray", "3, 3");
/*     */     }
/*     */     
/* 220 */     appendSvgElement(elem);
/*     */     
/* 222 */     return elem;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public mxRectangle getImageBounds(int x, int y, int width, int height) {
/* 228 */     int arc = getArcSize(width, height) / 2;
/* 229 */     int minSize = Math.min(width - arc * 2, height - 4);
/* 230 */     mxRectangle imageBounds = new mxRectangle((x + arc), (y + 2), minSize, minSize);
/* 231 */     return imageBounds;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getArcSize(int w, int h) {
/*     */     int arcSize;
/* 244 */     if (w <= h) {
/* 245 */       arcSize = (int)Math.round(h * mxConstants.RECTANGLE_ROUNDING_FACTOR);
/*     */       
/* 247 */       if (arcSize > w / 2) {
/* 248 */         arcSize = w / 2;
/*     */       }
/*     */     } else {
/* 251 */       arcSize = (int)Math.round(w * mxConstants.RECTANGLE_ROUNDING_FACTOR);
/*     */       
/* 253 */       if (arcSize > h / 2) {
/* 254 */         arcSize = h / 2;
/*     */       }
/*     */     } 
/* 257 */     return arcSize;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/visualization/trackscheme/TrackSchemeSvgCanvas.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */