/*     */ package fiji.plugin.trackmate.detection;
/*     */ 
/*     */ import fiji.plugin.trackmate.Model;
/*     */ import fiji.plugin.trackmate.Settings;
/*     */ import fiji.plugin.trackmate.TrackMateModule;
/*     */ import fiji.plugin.trackmate.gui.components.ConfigurationPanel;
/*     */ import java.util.Map;
/*     */ import net.imagej.ImgPlus;
/*     */ import org.jdom2.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface SpotDetectorFactoryBase<T extends net.imglib2.type.numeric.RealType<T> & net.imglib2.type.NativeType<T>>
/*     */   extends TrackMateModule
/*     */ {
/*     */   boolean setTarget(ImgPlus<T> paramImgPlus, Map<String, Object> paramMap);
/*     */   
/*     */   String getErrorMessage();
/*     */   
/*     */   boolean marshall(Map<String, Object> paramMap, Element paramElement);
/*     */   
/*     */   boolean unmarshall(Element paramElement, Map<String, Object> paramMap);
/*     */   
/*     */   ConfigurationPanel getDetectorConfigurationPanel(Settings paramSettings, Model paramModel);
/*     */   
/*     */   Map<String, Object> getDefaultSettings();
/*     */   
/*     */   boolean checkSettings(Map<String, Object> paramMap);
/*     */   
/*     */   default boolean has2Dsegmentation() {
/* 144 */     return false;
/*     */   }
/*     */   
/*     */   SpotDetectorFactoryBase<T> copy();
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/detection/SpotDetectorFactoryBase.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */