/*    */ package fiji.plugin.trackmate.gui.components;
/*    */ 
/*    */ import java.awt.Color;
/*    */ import java.awt.Font;
/*    */ import java.awt.Graphics2D;
/*    */ import java.awt.geom.AffineTransform;
/*    */ import java.awt.geom.Rectangle2D;
/*    */ import org.jfree.chart.ChartPanel;
/*    */ import org.jfree.chart.annotations.AbstractXYAnnotation;
/*    */ import org.jfree.chart.annotations.Annotation;
/*    */ import org.jfree.chart.axis.ValueAxis;
/*    */ import org.jfree.chart.event.AnnotationChangeEvent;
/*    */ import org.jfree.chart.plot.PlotRenderingInfo;
/*    */ import org.jfree.chart.plot.XYPlot;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class XYTextSimpleAnnotation
/*    */   extends AbstractXYAnnotation
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private float x;
/*    */   private float y;
/*    */   private String text;
/*    */   private Font font;
/*    */   private Color color;
/*    */   private ChartPanel chartPanel;
/*    */   
/*    */   public XYTextSimpleAnnotation(ChartPanel chartPanel) {
/* 48 */     this.chartPanel = chartPanel;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void draw(Graphics2D g2, XYPlot plot, Rectangle2D dataArea, ValueAxis domainAxis, ValueAxis rangeAxis, int rendererIndex, PlotRenderingInfo info) {
/* 61 */     Rectangle2D box = this.chartPanel.getScreenDataArea();
/* 62 */     float sx = (float)plot.getDomainAxis().valueToJava2D(this.x, box, plot.getDomainAxisEdge());
/* 63 */     float maxXLim = (float)box.getWidth() - g2.getFontMetrics().stringWidth(this.text);
/* 64 */     if (sx > maxXLim) {
/* 65 */       sx = maxXLim;
/*    */     }
/* 67 */     if (sx < box.getMinX()) {
/* 68 */       sx = (float)box.getMinX();
/*    */     }
/*    */     
/* 71 */     float sy = (float)plot.getRangeAxis().valueToJava2D(this.y, this.chartPanel.getScreenDataArea(), plot.getRangeAxisEdge());
/* 72 */     g2.setTransform(new AffineTransform());
/* 73 */     g2.setColor(this.color);
/* 74 */     g2.setFont(this.font);
/* 75 */     g2.drawString(this.text, sx, sy);
/*    */   }
/*    */   
/*    */   public void setLocation(float x, float y) {
/* 79 */     this.x = x;
/* 80 */     this.y = y;
/* 81 */     notifyListeners(new AnnotationChangeEvent(this, (Annotation)this));
/*    */   }
/*    */   
/* 84 */   public void setText(String text) { this.text = text; } public void setFont(Font font) {
/* 85 */     this.font = font;
/*    */   } public void setColor(Color color) {
/* 87 */     this.color = color;
/* 88 */     notifyListeners(new AnnotationChangeEvent(this, (Annotation)this));
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/gui/components/XYTextSimpleAnnotation.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */