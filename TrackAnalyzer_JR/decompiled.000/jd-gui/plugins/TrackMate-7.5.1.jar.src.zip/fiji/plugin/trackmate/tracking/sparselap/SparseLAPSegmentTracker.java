/*     */ package fiji.plugin.trackmate.tracking.sparselap;
/*     */ 
/*     */ import fiji.plugin.trackmate.Logger;
/*     */ import fiji.plugin.trackmate.Spot;
/*     */ import fiji.plugin.trackmate.tracking.LAPUtils;
/*     */ import fiji.plugin.trackmate.tracking.SpotTracker;
/*     */ import fiji.plugin.trackmate.tracking.sparselap.costmatrix.CostMatrixCreator;
/*     */ import fiji.plugin.trackmate.tracking.sparselap.costmatrix.JaqamanSegmentCostMatrixCreator;
/*     */ import fiji.plugin.trackmate.tracking.sparselap.linker.JaqamanLinker;
/*     */ import fiji.plugin.trackmate.util.TMUtils;
/*     */ import java.util.Map;
/*     */ import net.imglib2.algorithm.Benchmark;
/*     */ import org.jgrapht.Graph;
/*     */ import org.jgrapht.graph.DefaultWeightedEdge;
/*     */ import org.jgrapht.graph.SimpleWeightedGraph;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SparseLAPSegmentTracker
/*     */   implements SpotTracker, Benchmark
/*     */ {
/*     */   private static final String BASE_ERROR_MESSAGE = "[SparseLAPSegmentTracker] ";
/*     */   private final SimpleWeightedGraph<Spot, DefaultWeightedEdge> graph;
/*     */   private final Map<String, Object> settings;
/*     */   private String errorMessage;
/*  89 */   private Logger logger = Logger.VOID_LOGGER;
/*     */   
/*     */   private long processingTime;
/*     */   
/*     */   private int numThreads;
/*     */ 
/*     */   
/*     */   public SparseLAPSegmentTracker(SimpleWeightedGraph<Spot, DefaultWeightedEdge> graph, Map<String, Object> settings) {
/*  97 */     this.graph = graph;
/*  98 */     this.settings = settings;
/*  99 */     setNumThreads();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public SimpleWeightedGraph<Spot, DefaultWeightedEdge> getResult() {
/* 105 */     return this.graph;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean checkInput() {
/* 111 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean process() {
/* 122 */     if (null == this.graph) {
/*     */       
/* 124 */       this.errorMessage = "[SparseLAPSegmentTracker] The input graph is null.";
/* 125 */       return false;
/*     */     } 
/*     */ 
/*     */     
/* 129 */     StringBuilder errorHolder = new StringBuilder();
/* 130 */     if (!checkSettingsValidity(this.settings, errorHolder)) {
/*     */       
/* 132 */       this.errorMessage = "[SparseLAPSegmentTracker] " + errorHolder.toString();
/* 133 */       return false;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 140 */     long start = System.currentTimeMillis();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 146 */     this.logger.setProgress(0.0D);
/* 147 */     this.logger.setStatus("Creating the segment linking cost matrix...");
/* 148 */     JaqamanSegmentCostMatrixCreator costMatrixCreator = new JaqamanSegmentCostMatrixCreator((Graph)this.graph, this.settings);
/* 149 */     costMatrixCreator.setNumThreads(this.numThreads);
/* 150 */     Logger.SlaveLogger jlLogger = new Logger.SlaveLogger(this.logger, 0.0D, 0.9D);
/* 151 */     JaqamanLinker<Spot, Spot> linker = new JaqamanLinker((CostMatrixCreator)costMatrixCreator, (Logger)jlLogger);
/* 152 */     if (!linker.checkInput() || !linker.process()) {
/*     */       
/* 154 */       this.errorMessage = linker.getErrorMessage();
/* 155 */       return false;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 163 */     this.logger.setProgress(0.9D);
/* 164 */     this.logger.setStatus("Creating links...");
/*     */     
/* 166 */     Map<Spot, Spot> assignment = linker.getResult();
/* 167 */     Map<Spot, Double> costs = linker.getAssignmentCosts();
/*     */     
/* 169 */     for (Spot source : assignment.keySet()) {
/*     */       
/* 171 */       Spot target = assignment.get(source);
/* 172 */       DefaultWeightedEdge edge = (DefaultWeightedEdge)this.graph.addEdge(source, target);
/*     */       
/* 174 */       double cost = ((Double)costs.get(source)).doubleValue();
/* 175 */       this.graph.setEdgeWeight(edge, cost);
/*     */     } 
/*     */     
/* 178 */     this.logger.setProgress(1.0D);
/* 179 */     this.logger.setStatus("");
/* 180 */     long end = System.currentTimeMillis();
/* 181 */     this.processingTime = end - start;
/* 182 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getErrorMessage() {
/* 188 */     return this.errorMessage;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public long getProcessingTime() {
/* 194 */     return this.processingTime;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLogger(Logger logger) {
/* 200 */     this.logger = logger;
/*     */   }
/*     */ 
/*     */   
/*     */   private static final boolean checkSettingsValidity(Map<String, Object> settings, StringBuilder str) {
/* 205 */     if (null == settings) {
/*     */       
/* 207 */       str.append("Settings map is null.\n");
/* 208 */       return false;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 216 */     boolean ok = true;
/*     */     
/* 218 */     ok &= TMUtils.checkParameter(settings, "ALLOW_GAP_CLOSING", Boolean.class, str);
/* 219 */     ok &= TMUtils.checkParameter(settings, "GAP_CLOSING_MAX_DISTANCE", Double.class, str);
/* 220 */     ok &= TMUtils.checkParameter(settings, "MAX_FRAME_GAP", Integer.class, str);
/* 221 */     ok &= LAPUtils.checkFeatureMap(settings, "GAP_CLOSING_FEATURE_PENALTIES", str);
/*     */     
/* 223 */     ok &= TMUtils.checkParameter(settings, "ALLOW_TRACK_SPLITTING", Boolean.class, str);
/*     */     
/* 225 */     ok &= TMUtils.checkParameter(settings, "ALLOW_TRACK_MERGING", Boolean.class, str);
/* 226 */     return ok;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setNumThreads() {
/* 232 */     this.numThreads = Runtime.getRuntime().availableProcessors();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setNumThreads(int numThreads) {
/* 238 */     this.numThreads = numThreads;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getNumThreads() {
/* 244 */     return this.numThreads;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/tracking/sparselap/SparseLAPSegmentTracker.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */