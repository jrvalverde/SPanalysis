/*    */ package fiji.plugin.trackmate.providers;
/*    */ 
/*    */ import fiji.plugin.trackmate.visualization.ViewFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ViewProvider
/*    */   extends AbstractProvider<ViewFactory>
/*    */ {
/*    */   public ViewProvider() {
/* 31 */     super(ViewFactory.class);
/*    */   }
/*    */ 
/*    */   
/*    */   public static void main(String[] args) {
/* 36 */     ViewProvider provider = new ViewProvider();
/* 37 */     System.out.println(provider.echo());
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/providers/ViewProvider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */