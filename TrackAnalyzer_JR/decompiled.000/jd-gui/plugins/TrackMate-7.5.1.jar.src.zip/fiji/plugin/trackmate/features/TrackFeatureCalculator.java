/*     */ package fiji.plugin.trackmate.features;
/*     */ 
/*     */ import fiji.plugin.trackmate.Dimension;
/*     */ import fiji.plugin.trackmate.Logger;
/*     */ import fiji.plugin.trackmate.Model;
/*     */ import fiji.plugin.trackmate.Settings;
/*     */ import fiji.plugin.trackmate.features.track.TrackAnalyzer;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import net.imglib2.algorithm.MultiThreadedBenchmarkAlgorithm;
/*     */ import org.scijava.Cancelable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TrackFeatureCalculator
/*     */   extends MultiThreadedBenchmarkAlgorithm
/*     */   implements Cancelable
/*     */ {
/*     */   private static final String BASE_ERROR_MSG = "[TrackFeatureCalculator] ";
/*     */   private final Settings settings;
/*     */   private final Model model;
/*     */   private boolean isCanceled;
/*     */   private String cancelReason;
/*     */   private final boolean doLogIt;
/*     */   
/*     */   public TrackFeatureCalculator(Model model, Settings settings, boolean doLogIt) {
/*  61 */     this.settings = settings;
/*  62 */     this.model = model;
/*  63 */     this.doLogIt = doLogIt;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean checkInput() {
/*  73 */     if (null == this.model) {
/*     */       
/*  75 */       this.errorMessage = "[TrackFeatureCalculator] Model object is null.";
/*  76 */       return false;
/*     */     } 
/*  78 */     if (null == this.settings) {
/*     */       
/*  80 */       this.errorMessage = "[TrackFeatureCalculator] Settings object is null.";
/*  81 */       return false;
/*     */     } 
/*  83 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean process() {
/*  93 */     long start = System.currentTimeMillis();
/*     */ 
/*     */     
/*  96 */     for (TrackAnalyzer analyzer : this.settings.getTrackAnalyzers()) {
/*     */       
/*  98 */       Collection<String> features = analyzer.getFeatures();
/*  99 */       Map<String, String> featureNames = analyzer.getFeatureNames();
/* 100 */       Map<String, String> featureShortNames = analyzer.getFeatureShortNames();
/* 101 */       Map<String, Dimension> featureDimensions = analyzer.getFeatureDimensions();
/* 102 */       Map<String, Boolean> isIntFeature = analyzer.getIsIntFeature();
/* 103 */       this.model.getFeatureModel().declareTrackFeatures(features, featureNames, featureShortNames, featureDimensions, isIntFeature);
/*     */     } 
/*     */ 
/*     */     
/* 107 */     computeTrackFeaturesAgent(this.model.getTrackModel().trackIDs(false), this.settings.getTrackAnalyzers(), this.doLogIt);
/*     */     
/* 109 */     long end = System.currentTimeMillis();
/* 110 */     this.processingTime = end - start;
/* 111 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void computeTrackFeatures(Collection<Integer> trackIDs, boolean doLogIt) {
/* 120 */     List<TrackAnalyzer> trackFeatureAnalyzers = this.settings.getTrackAnalyzers();
/* 121 */     computeTrackFeaturesAgent(trackIDs, trackFeatureAnalyzers, doLogIt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void computeTrackFeaturesAgent(Collection<Integer> trackIDs, List<TrackAnalyzer> analyzers, boolean doLogIt) {
/* 133 */     this.isCanceled = false;
/* 134 */     this.cancelReason = null;
/*     */     
/* 136 */     Logger logger = this.model.getLogger();
/* 137 */     if (doLogIt)
/*     */     {
/* 139 */       logger.log("Computing track features:\n", Logger.BLUE_COLOR);
/*     */     }
/*     */     
/* 142 */     for (TrackAnalyzer analyzer : analyzers) {
/*     */       
/* 144 */       if (isCanceled()) {
/*     */         return;
/*     */       }
/* 147 */       if (analyzer.isManualFeature()) {
/*     */         continue;
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 153 */       analyzer.setNumThreads(this.numThreads);
/* 154 */       if (analyzer.isLocal()) {
/*     */         
/* 156 */         analyzer.process(trackIDs, this.model);
/*     */       }
/*     */       else {
/*     */         
/* 160 */         analyzer.process(this.model.getTrackModel().trackIDs(false), this.model);
/*     */       } 
/*     */       
/* 163 */       if (doLogIt) {
/* 164 */         logger.log("  - " + analyzer.getName() + " in " + analyzer.getProcessingTime() + " ms.\n");
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isCanceled() {
/* 174 */     return this.isCanceled;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void cancel(String reason) {
/* 180 */     this.isCanceled = true;
/* 181 */     this.cancelReason = reason;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getCancelReason() {
/* 187 */     return this.cancelReason;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/features/TrackFeatureCalculator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */