package fiji.plugin.trackmate.features;

import fiji.plugin.trackmate.Dimension;
import fiji.plugin.trackmate.TrackMateModule;
import java.util.List;
import java.util.Map;

public interface FeatureAnalyzer extends TrackMateModule {
  List<String> getFeatures();
  
  Map<String, String> getFeatureShortNames();
  
  Map<String, String> getFeatureNames();
  
  Map<String, Dimension> getFeatureDimensions();
  
  Map<String, Boolean> getIsIntFeature();
  
  boolean isManualFeature();
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/features/FeatureAnalyzer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */