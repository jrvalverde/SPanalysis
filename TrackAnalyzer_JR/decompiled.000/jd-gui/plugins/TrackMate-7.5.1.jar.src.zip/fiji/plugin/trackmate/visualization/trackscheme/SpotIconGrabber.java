/*     */ package fiji.plugin.trackmate.visualization.trackscheme;
/*     */ 
/*     */ import com.mxgraph.util.mxBase64;
/*     */ import fiji.plugin.trackmate.Spot;
/*     */ import fiji.plugin.trackmate.util.TMUtils;
/*     */ import ij.ImagePlus;
/*     */ import ij.process.ImageProcessor;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import javax.imageio.ImageIO;
/*     */ import net.imagej.ImgPlus;
/*     */ import net.imagej.ImgPlusMetadata;
/*     */ import net.imglib2.Cursor;
/*     */ import net.imglib2.Dimensions;
/*     */ import net.imglib2.FinalInterval;
/*     */ import net.imglib2.Interval;
/*     */ import net.imglib2.Localizable;
/*     */ import net.imglib2.RandomAccess;
/*     */ import net.imglib2.RandomAccessible;
/*     */ import net.imglib2.RandomAccessibleInterval;
/*     */ import net.imglib2.img.Img;
/*     */ import net.imglib2.img.display.imagej.ImageJFunctions;
/*     */ import net.imglib2.outofbounds.OutOfBounds;
/*     */ import net.imglib2.outofbounds.OutOfBoundsConstantValueFactory;
/*     */ import net.imglib2.outofbounds.OutOfBoundsFactory;
/*     */ import net.imglib2.type.Type;
/*     */ import net.imglib2.type.numeric.RealType;
/*     */ import net.imglib2.util.Intervals;
/*     */ import net.imglib2.view.IntervalView;
/*     */ import net.imglib2.view.Views;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SpotIconGrabber<T extends RealType<T>>
/*     */ {
/*     */   private final ImgPlus<T> img;
/*     */   
/*     */   public SpotIconGrabber(ImgPlus<T> img) {
/*  62 */     this.img = img;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getImageString(Spot spot, double radiusFactor) {
/*  81 */     double[] calibration = TMUtils.getSpatialCalibration((ImgPlusMetadata)this.img);
/*  82 */     double radius = spot.getFeature("RADIUS").doubleValue() * radiusFactor;
/*  83 */     long x = Math.round((spot.getFeature("POSITION_X").doubleValue() - radius) / calibration[0]);
/*  84 */     long y = Math.round((spot.getFeature("POSITION_Y").doubleValue() - radius) / calibration[1]);
/*  85 */     long width = Math.max(1L, Math.round(2.0D * radius / calibration[0]));
/*  86 */     long height = Math.max(1L, Math.round(2.0D * radius / calibration[1]));
/*     */ 
/*     */     
/*  89 */     long slice = 0L;
/*  90 */     if (this.img.numDimensions() > 2) {
/*     */       
/*  92 */       slice = Math.round(spot.getFeature("POSITION_Z").doubleValue() / calibration[2]);
/*  93 */       if (slice < 0L)
/*     */       {
/*  95 */         slice = 0L;
/*     */       }
/*  97 */       if (slice >= this.img.dimension(2))
/*     */       {
/*  99 */         slice = this.img.dimension(2) - 1L;
/*     */       }
/*     */     } 
/*     */     
/* 103 */     Img<T> crop = grabImage(x, y, slice, width, height);
/*     */ 
/*     */     
/* 106 */     ImagePlus imp = ImageJFunctions.wrap((RandomAccessibleInterval)crop, crop.toString());
/* 107 */     ImageProcessor ip = imp.getProcessor();
/* 108 */     ip.resetMinAndMax();
/*     */ 
/*     */     
/* 111 */     ByteArrayOutputStream bos = new ByteArrayOutputStream();
/* 112 */     BufferedImage lImg = ip.getBufferedImage();
/*     */     
/*     */     try {
/* 115 */       ImageIO.write(lImg, "png", bos);
/* 116 */       return mxBase64.encodeToString(bos.toByteArray(), false);
/*     */     }
/* 118 */     catch (IOException e) {
/*     */       
/* 120 */       e.printStackTrace();
/* 121 */       return "";
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Img<T> grabImage(long x, long y, long slice, long width, long height) {
/* 145 */     Img<T> crop = this.img.factory().create(new long[] { width, height });
/*     */     
/* 147 */     RealType realType = (RealType)((RealType)this.img.firstElement()).createVariable();
/* 148 */     realType.setZero();
/*     */     
/* 150 */     OutOfBoundsConstantValueFactory<T, Img<T>> oobf = new OutOfBoundsConstantValueFactory(realType);
/* 151 */     OutOfBounds outOfBounds = Views.extend((RandomAccessibleInterval)this.img, (OutOfBoundsFactory)oobf).randomAccess();
/* 152 */     RandomAccess<T> targetCursor = crop.randomAccess();
/*     */     
/* 154 */     if (this.img.numDimensions() > 2)
/*     */     {
/* 156 */       outOfBounds.setPosition(slice, 2);
/*     */     }
/* 158 */     for (int i = 0; i < width; i++) {
/*     */       
/* 160 */       outOfBounds.setPosition(i + x, 0);
/* 161 */       targetCursor.setPosition(i, 0);
/* 162 */       for (int j = 0; j < height; j++) {
/*     */         
/* 164 */         outOfBounds.setPosition(j + y, 1);
/* 165 */         targetCursor.setPosition(j, 1);
/* 166 */         ((RealType)targetCursor.get()).set((Type)outOfBounds.get());
/*     */       } 
/*     */     } 
/* 169 */     return crop;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Img<T> grabImage(long x, long y, long slice, long width, long height, long depth) {
/* 192 */     long[] minsize = { x, y, slice - depth / 2L, width, height, depth };
/* 193 */     FinalInterval finalInterval = Intervals.createMinSize(minsize);
/*     */ 
/*     */     
/* 196 */     Img<T> crop = this.img.factory().create((Dimensions)finalInterval);
/* 197 */     IntervalView<T> view = Views.zeroMin((RandomAccessibleInterval)Views.interval((RandomAccessible)Views.extendZero((RandomAccessibleInterval)this.img), (Interval)finalInterval));
/* 198 */     RandomAccess<T> sourceRA = view.randomAccess((Interval)view);
/* 199 */     Cursor<T> targetCursor = crop.localizingCursor();
/*     */     
/* 201 */     while (targetCursor.hasNext()) {
/*     */       
/* 203 */       targetCursor.fwd();
/* 204 */       sourceRA.setPosition((Localizable)targetCursor);
/* 205 */       ((RealType)targetCursor.get()).set((Type)sourceRA.get());
/*     */     } 
/* 207 */     return crop;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/visualization/trackscheme/SpotIconGrabber.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */