/*     */ package fiji.plugin.trackmate.visualization.table;
/*     */ 
/*     */ import fiji.plugin.trackmate.Dimension;
/*     */ import fiji.plugin.trackmate.Logger;
/*     */ import fiji.plugin.trackmate.Model;
/*     */ import fiji.plugin.trackmate.SelectionModel;
/*     */ import fiji.plugin.trackmate.Spot;
/*     */ import fiji.plugin.trackmate.graph.ConvexBranchesDecomposition;
/*     */ import fiji.plugin.trackmate.graph.TimeDirectedNeighborIndex;
/*     */ import fiji.plugin.trackmate.gui.Icons;
/*     */ import fiji.plugin.trackmate.util.FileChooser;
/*     */ import fiji.plugin.trackmate.util.TMUtils;
/*     */ import fiji.plugin.trackmate.visualization.FeatureColorGenerator;
/*     */ import fiji.plugin.trackmate.visualization.TrackMateModelView;
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.function.BiConsumer;
/*     */ import java.util.function.BiFunction;
/*     */ import java.util.function.Function;
/*     */ import java.util.function.Supplier;
/*     */ import javax.swing.Box;
/*     */ import javax.swing.BoxLayout;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JFrame;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.event.ListSelectionEvent;
/*     */ import javax.swing.event.ListSelectionListener;
/*     */ import javax.swing.filechooser.FileNameExtensionFilter;
/*     */ import net.imglib2.RealLocalizable;
/*     */ import org.jgrapht.graph.DefaultEdge;
/*     */ import org.jgrapht.graph.DefaultWeightedEdge;
/*     */ import org.jgrapht.graph.SimpleDirectedGraph;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BranchTableView
/*     */   extends JFrame
/*     */   implements TrackMateModelView
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private static final String KEY = "SPOT_TABLE";
/*  80 */   public static String selectedFile = TrackTableView.selectedFile;
/*     */   private final Model model;
/*     */   private final TablePanel<Branch> branchTable;
/*     */   private static final String TRACK_ID = "TRACK_ID";
/*     */   private static final String N_PREDECESSORS = "N_PREDECESSORS";
/*     */   private static final String N_SUCCESSORS = "N_SUCCESSORS";
/*     */   
/*     */   public BranchTableView(Model model, SelectionModel selectionModel) {
/*  88 */     super("Branch table");
/*  89 */     setIconImage(Icons.TRACKMATE_ICON.getImage());
/*  90 */     this.model = model;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  96 */     JPanel mainPanel = new JPanel();
/*  97 */     mainPanel.setLayout(new BorderLayout());
/*     */ 
/*     */     
/* 100 */     this.branchTable = createBranchTable(model, selectionModel);
/*     */     
/* 102 */     mainPanel.add(this.branchTable.getPanel(), "Center");
/*     */ 
/*     */     
/* 105 */     JPanel toolbar = new JPanel();
/* 106 */     BoxLayout layout = new BoxLayout(toolbar, 2);
/* 107 */     toolbar.setLayout(layout);
/* 108 */     JButton exportBtn = new JButton("Export to CSV", Icons.CSV_ICON);
/* 109 */     exportBtn.addActionListener(e -> exportToCsv());
/* 110 */     toolbar.add(exportBtn);
/* 111 */     toolbar.add(Box.createHorizontalGlue());
/* 112 */     mainPanel.add(toolbar, "North");
/*     */     
/* 114 */     getContentPane().add(mainPanel);
/* 115 */     pack();
/*     */   }
/*     */   private static final String DELTA_T = "DELTA_T"; private static final String DISTANCE = "DISTANCE"; private static final String MEAN_VELOCITY = "MEAN_VELOCITY"; private static final String FIRST = "FIRST"; private static final String LAST = "LAST";
/*     */   
/*     */   public TablePanel<Branch> getBranchTable() {
/* 120 */     return this.branchTable;
/*     */   }
/*     */ 
/*     */   
/*     */   public void exportToCsv() {
/* 125 */     File file = FileChooser.chooseFile(this, selectedFile, new FileNameExtensionFilter("CSV files", new String[] { "csv" }), "Export table to CSV", FileChooser.DialogType.SAVE, FileChooser.SelectionMode.FILES_ONLY);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 132 */     if (null == file) {
/*     */       return;
/*     */     }
/* 135 */     selectedFile = file.getAbsolutePath();
/* 136 */     exportToCsv(selectedFile);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void exportToCsv(String csvFile) {
/*     */     try {
/* 143 */       this.branchTable.exportToCsv(new File(csvFile));
/*     */     }
/* 145 */     catch (IOException e) {
/*     */       
/* 147 */       this.model.getLogger().error("Problem exporting to file " + csvFile + "\n" + e
/* 148 */           .getMessage());
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static final TablePanel<Branch> createBranchTable(Model model, SelectionModel selectionModel) {
/* 154 */     Logger logger = model.getLogger();
/*     */     
/* 156 */     logger.log("Generating track branches analysis.\n");
/* 157 */     int ntracks = model.getTrackModel().nTracks(true);
/* 158 */     if (ntracks == 0) {
/* 159 */       logger.log("No visible track found. Aborting.\n");
/*     */     }
/* 161 */     TimeDirectedNeighborIndex neighborIndex = model.getTrackModel().getDirectedNeighborIndex();
/*     */     
/* 163 */     List<Branch> brs = new ArrayList<>();
/* 164 */     for (Integer trackID : model.getTrackModel().unsortedTrackIDs(true)) {
/*     */       
/* 166 */       ConvexBranchesDecomposition.TrackBranchDecomposition branchDecomposition = ConvexBranchesDecomposition.processTrack(trackID, model.getTrackModel(), neighborIndex, true, false);
/* 167 */       SimpleDirectedGraph<List<Spot>, DefaultEdge> branchGraph = ConvexBranchesDecomposition.buildBranchGraph(branchDecomposition);
/*     */       
/* 169 */       Map<Branch, Set<List<Spot>>> successorMap = new HashMap<>();
/* 170 */       Map<Branch, Set<List<Spot>>> predecessorMap = new HashMap<>();
/* 171 */       Map<List<Spot>, Branch> branchMap = new HashMap<>();
/*     */       
/* 173 */       for (List<Spot> branch : (Iterable<List<Spot>>)branchGraph.vertexSet()) {
/*     */         double meanV;
/* 175 */         Branch br = new Branch();
/* 176 */         branchMap.put(branch, br);
/*     */ 
/*     */         
/* 179 */         br.trackName = model.getTrackModel().name(trackID);
/* 180 */         br.putFeature("TRACK_ID", Double.valueOf(trackID.intValue()));
/*     */ 
/*     */         
/* 183 */         Spot first = branch.get(0);
/* 184 */         br.first = first;
/* 185 */         br.putFeature("FIRST", Double.valueOf(first.ID()));
/*     */         
/* 187 */         Spot last = branch.get(branch.size() - 1);
/* 188 */         br.last = last;
/* 189 */         br.putFeature("LAST", Double.valueOf(last.ID()));
/*     */ 
/*     */         
/* 192 */         br.putFeature("DELTA_T", Double.valueOf(br.dt()));
/*     */ 
/*     */         
/* 195 */         double distanceTraveled = Math.sqrt(br.last.squareDistanceTo((RealLocalizable)br.first));
/* 196 */         br.putFeature("DISTANCE", Double.valueOf(distanceTraveled));
/*     */ 
/*     */ 
/*     */         
/* 200 */         if (branch.size() < 2) {
/*     */           
/* 202 */           meanV = Double.NaN;
/*     */         }
/*     */         else {
/*     */           
/* 206 */           Iterator<Spot> it = branch.iterator();
/* 207 */           Spot previous = it.next();
/* 208 */           double sum = 0.0D;
/* 209 */           while (it.hasNext()) {
/*     */             
/* 211 */             Spot next = it.next();
/* 212 */             double dr = Math.sqrt(next.squareDistanceTo((RealLocalizable)previous));
/* 213 */             sum += dr;
/* 214 */             previous = next;
/*     */           } 
/* 216 */           meanV = sum / (branch.size() - 1);
/*     */         } 
/* 218 */         br.putFeature("MEAN_VELOCITY", Double.valueOf(meanV));
/*     */ 
/*     */         
/* 221 */         Set<DefaultEdge> incomingEdges = branchGraph.incomingEdgesOf(branch);
/* 222 */         Set<List<Spot>> predecessors = new HashSet<>(incomingEdges.size());
/* 223 */         for (DefaultEdge edge : incomingEdges) {
/*     */           
/* 225 */           List<Spot> predecessorBranch = (List<Spot>)branchGraph.getEdgeSource(edge);
/* 226 */           predecessors.add(predecessorBranch);
/*     */         } 
/*     */ 
/*     */         
/* 230 */         Set<DefaultEdge> outgoingEdges = branchGraph.outgoingEdgesOf(branch);
/* 231 */         Set<List<Spot>> successors = new HashSet<>(outgoingEdges.size());
/* 232 */         for (DefaultEdge edge : outgoingEdges) {
/*     */           
/* 234 */           List<Spot> successorBranch = (List<Spot>)branchGraph.getEdgeTarget(edge);
/* 235 */           successors.add(successorBranch);
/*     */         } 
/*     */         
/* 238 */         successorMap.put(br, successors);
/* 239 */         predecessorMap.put(br, predecessors);
/*     */       } 
/*     */       
/* 242 */       for (Branch br : successorMap.keySet()) {
/*     */         
/* 244 */         Set<List<Spot>> succs = successorMap.get(br);
/* 245 */         Set<Branch> succBrs = new HashSet<>(succs.size());
/* 246 */         for (List<Spot> branch : succs) {
/*     */           
/* 248 */           Branch succBr = branchMap.get(branch);
/* 249 */           succBrs.add(succBr);
/*     */         } 
/* 251 */         br.successors = succBrs;
/* 252 */         br.putFeature("N_SUCCESSORS", Double.valueOf(succBrs.size()));
/*     */         
/* 254 */         Set<List<Spot>> preds = predecessorMap.get(br);
/* 255 */         Set<Branch> predBrs = new HashSet<>(preds.size());
/* 256 */         for (List<Spot> branch : preds) {
/*     */           
/* 258 */           Branch predBr = branchMap.get(branch);
/* 259 */           predBrs.add(predBr);
/*     */         } 
/* 261 */         br.predecessors = predBrs;
/* 262 */         br.putFeature("N_PREDECESSORS", Double.valueOf(predBrs.size()));
/*     */       } 
/*     */       
/* 265 */       brs.addAll(successorMap.keySet());
/*     */     } 
/* 267 */     Collections.sort(brs);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 273 */     Iterable<Branch> objects = brs;
/* 274 */     BiFunction<Branch, String, Double> featureFun = (br, feature) -> br.getFeature(feature);
/* 275 */     Map<String, String> featureUnits = new HashMap<>();
/* 276 */     BRANCH_FEATURES_DIMENSIONS.forEach((f, d) -> (String)featureUnits.put(f, TMUtils.getUnitsFor(d, model.getSpaceUnits(), model.getTimeUnits())));
/*     */     
/* 278 */     Map<String, String> infoTexts = new HashMap<>();
/* 279 */     Function<Branch, String> labelGenerator = b -> b.toString();
/* 280 */     BiConsumer<Branch, String> labelSetter = null;
/* 281 */     Supplier<FeatureColorGenerator<Branch>> colorSupplier = () -> ();
/*     */     
/* 283 */     TablePanel<Branch> table = new TablePanel<>(objects, BRANCH_FEATURES, featureFun, BRANCH_FEATURES_NAMES, BRANCH_FEATURES_SHORTNAMES, featureUnits, BRANCH_FEATURES_ISINTS, infoTexts, colorSupplier, labelGenerator, labelSetter);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 296 */     table.getTable().getSelectionModel().addListSelectionListener(new BranchTableSelectionListener(table, model, selectionModel));
/*     */ 
/*     */     
/* 299 */     return table;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void render() {
/* 305 */     setLocationRelativeTo((Component)null);
/* 306 */     setVisible(true);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void refresh() {
/* 312 */     repaint();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void centerViewOn(Spot spot) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public Model getModel() {
/* 322 */     return this.model;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getKey() {
/* 328 */     return "SPOT_TABLE";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void clear() {}
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class BranchTableSelectionListener
/*     */     implements ListSelectionListener
/*     */   {
/*     */     private final TablePanel<BranchTableView.Branch> branchTable;
/*     */ 
/*     */     
/*     */     private final Model model;
/*     */     
/*     */     private final SelectionModel selectionModel;
/*     */ 
/*     */     
/*     */     public BranchTableSelectionListener(TablePanel<BranchTableView.Branch> branchTable, Model model, SelectionModel selectionModel) {
/* 349 */       this.branchTable = branchTable;
/* 350 */       this.model = model;
/* 351 */       this.selectionModel = selectionModel;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void valueChanged(ListSelectionEvent event) {
/* 357 */       if (event.getValueIsAdjusting()) {
/*     */         return;
/*     */       }
/* 360 */       int[] selectedRows = this.branchTable.getTable().getSelectedRows();
/* 361 */       for (int row : selectedRows) {
/*     */         
/* 363 */         BranchTableView.Branch br = this.branchTable.getObjectForViewRow(row);
/* 364 */         if (null != br) {
/*     */ 
/*     */           
/* 367 */           List<DefaultWeightedEdge> edges = this.model.getTrackModel().dijkstraShortestPath(br.first, br.last);
/* 368 */           Set<Spot> spots = new HashSet<>();
/* 369 */           for (DefaultWeightedEdge edge : edges) {
/*     */             
/* 371 */             spots.add(this.model.getTrackModel().getEdgeSource(edge));
/* 372 */             spots.add(this.model.getTrackModel().getEdgeTarget(edge));
/*     */           } 
/* 374 */           this.selectionModel.clearSelection();
/* 375 */           this.selectionModel.addEdgeToSelection(edges);
/* 376 */           this.selectionModel.addSpotToSelection(spots);
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Branch
/*     */     implements Comparable<Branch>
/*     */   {
/* 391 */     private final Map<String, Double> features = new HashMap<>();
/*     */ 
/*     */     
/*     */     private String trackName;
/*     */     
/*     */     private Spot first;
/*     */     
/*     */     private Spot last;
/*     */     
/*     */     private Set<Branch> predecessors;
/*     */     
/*     */     private Set<Branch> successors;
/*     */ 
/*     */     
/*     */     public String toString() {
/* 406 */       return this.trackName + ": " + this.first + " → " + this.last;
/*     */     }
/*     */ 
/*     */     
/*     */     double dt() {
/* 411 */       return this.last.diffTo(this.first, "POSITION_T");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Double getFeature(String feature) {
/* 424 */       return this.features.get(feature);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final void putFeature(String feature, Double value) {
/* 438 */       this.features.put(feature, value);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int compareTo(Branch o) {
/* 448 */       if (this.predecessors.size() != o.predecessors.size())
/* 449 */         return this.predecessors.size() - o.predecessors.size(); 
/* 450 */       if (this.successors.size() != o.successors.size())
/* 451 */         return this.successors.size() - o.successors.size(); 
/* 452 */       if (this.first.getName().compareTo(o.first.getName()) != 0)
/* 453 */         return this.first.getName().compareTo(o.first.getName()); 
/* 454 */       return this.last.getName().compareTo(o.last.getName());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 466 */   private static final List<String> BRANCH_FEATURES = Arrays.asList(new String[] { "TRACK_ID", "N_PREDECESSORS", "N_SUCCESSORS", "DELTA_T", "DISTANCE", "MEAN_VELOCITY", "FIRST", "LAST" });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 477 */   private static final Map<String, String> BRANCH_FEATURES_NAMES = new HashMap<>();
/* 478 */   private static final Map<String, String> BRANCH_FEATURES_SHORTNAMES = new HashMap<>();
/* 479 */   private static final Map<String, Boolean> BRANCH_FEATURES_ISINTS = new HashMap<>();
/* 480 */   private static final Map<String, Dimension> BRANCH_FEATURES_DIMENSIONS = new HashMap<>();
/*     */   
/*     */   static {
/* 483 */     BRANCH_FEATURES_NAMES.put("TRACK_ID", "Track ID");
/* 484 */     BRANCH_FEATURES_SHORTNAMES.put("TRACK_ID", "Track ID");
/* 485 */     BRANCH_FEATURES_ISINTS.put("TRACK_ID", Boolean.TRUE);
/* 486 */     BRANCH_FEATURES_DIMENSIONS.put("TRACK_ID", Dimension.NONE);
/*     */     
/* 488 */     BRANCH_FEATURES_NAMES.put("N_PREDECESSORS", "Track ID");
/* 489 */     BRANCH_FEATURES_SHORTNAMES.put("N_PREDECESSORS", "N predecessors");
/* 490 */     BRANCH_FEATURES_ISINTS.put("N_PREDECESSORS", Boolean.TRUE);
/* 491 */     BRANCH_FEATURES_DIMENSIONS.put("N_PREDECESSORS", Dimension.NONE);
/*     */     
/* 493 */     BRANCH_FEATURES_NAMES.put("N_SUCCESSORS", "Track ID");
/* 494 */     BRANCH_FEATURES_SHORTNAMES.put("N_SUCCESSORS", "N successors");
/* 495 */     BRANCH_FEATURES_ISINTS.put("N_SUCCESSORS", Boolean.TRUE);
/* 496 */     BRANCH_FEATURES_DIMENSIONS.put("N_SUCCESSORS", Dimension.NONE);
/*     */     
/* 498 */     BRANCH_FEATURES_NAMES.put("DELTA_T", "Branch duration");
/* 499 */     BRANCH_FEATURES_SHORTNAMES.put("DELTA_T", "Delta T");
/* 500 */     BRANCH_FEATURES_ISINTS.put("DELTA_T", Boolean.FALSE);
/* 501 */     BRANCH_FEATURES_DIMENSIONS.put("DELTA_T", Dimension.TIME);
/*     */     
/* 503 */     BRANCH_FEATURES_NAMES.put("DISTANCE", "Distance traveled");
/* 504 */     BRANCH_FEATURES_SHORTNAMES.put("DISTANCE", "Dist");
/* 505 */     BRANCH_FEATURES_ISINTS.put("DISTANCE", Boolean.FALSE);
/* 506 */     BRANCH_FEATURES_DIMENSIONS.put("DISTANCE", Dimension.LENGTH);
/*     */     
/* 508 */     BRANCH_FEATURES_NAMES.put("MEAN_VELOCITY", "Mean velocity");
/* 509 */     BRANCH_FEATURES_SHORTNAMES.put("MEAN_VELOCITY", "Mean V");
/* 510 */     BRANCH_FEATURES_ISINTS.put("MEAN_VELOCITY", Boolean.FALSE);
/* 511 */     BRANCH_FEATURES_DIMENSIONS.put("MEAN_VELOCITY", Dimension.VELOCITY);
/*     */     
/* 513 */     BRANCH_FEATURES_NAMES.put("FIRST", "First spot ID");
/* 514 */     BRANCH_FEATURES_SHORTNAMES.put("FIRST", "First ID");
/* 515 */     BRANCH_FEATURES_ISINTS.put("FIRST", Boolean.TRUE);
/* 516 */     BRANCH_FEATURES_DIMENSIONS.put("FIRST", Dimension.NONE);
/*     */     
/* 518 */     BRANCH_FEATURES_NAMES.put("LAST", "Last spot ID");
/* 519 */     BRANCH_FEATURES_SHORTNAMES.put("LAST", "Last ID");
/* 520 */     BRANCH_FEATURES_ISINTS.put("LAST", Boolean.TRUE);
/* 521 */     BRANCH_FEATURES_DIMENSIONS.put("LAST", Dimension.NONE);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/visualization/table/BranchTableView.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */