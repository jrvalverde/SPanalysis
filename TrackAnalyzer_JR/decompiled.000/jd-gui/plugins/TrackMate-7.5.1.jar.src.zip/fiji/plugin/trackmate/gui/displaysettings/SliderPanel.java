/*     */ package fiji.plugin.trackmate.gui.displaysettings;
/*     */ 
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.Dimension;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JSlider;
/*     */ import javax.swing.JSpinner;
/*     */ import javax.swing.SpinnerNumberModel;
/*     */ import javax.swing.event.ChangeEvent;
/*     */ import javax.swing.event.ChangeListener;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SliderPanel
/*     */   extends JPanel
/*     */   implements BoundedValue.UpdateListener
/*     */ {
/*     */   private static final long serialVersionUID = 6444334522127424416L;
/*  45 */   public static final Dimension PANEL_SIZE = new Dimension(100, 20);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final JSlider slider;
/*     */ 
/*     */ 
/*     */   
/*     */   private final JSpinner spinner;
/*     */ 
/*     */ 
/*     */   
/*     */   private final BoundedValue model;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SliderPanel(String name, final BoundedValue model, int spinnerStepSize) {
/*  64 */     setLayout(new BorderLayout(10, 10));
/*  65 */     setPreferredSize(PANEL_SIZE);
/*     */     
/*  67 */     this.slider = new JSlider(0, model.getRangeMin(), model.getRangeMax(), model.getCurrentValue());
/*  68 */     this.spinner = new JSpinner();
/*  69 */     this.spinner.setModel(new SpinnerNumberModel(model.getCurrentValue(), model.getRangeMin(), model.getRangeMax(), spinnerStepSize));
/*     */     
/*  71 */     this.slider.addChangeListener(new ChangeListener()
/*     */         {
/*     */           
/*     */           public void stateChanged(ChangeEvent e)
/*     */           {
/*  76 */             int value = SliderPanel.this.slider.getValue();
/*  77 */             model.setCurrentValue(value);
/*     */           }
/*     */         });
/*     */     
/*  81 */     this.spinner.addChangeListener(new ChangeListener()
/*     */         {
/*     */           
/*     */           public void stateChanged(ChangeEvent e)
/*     */           {
/*  86 */             int value = ((Integer)SliderPanel.this.spinner.getValue()).intValue();
/*  87 */             model.setCurrentValue(value);
/*     */           }
/*     */         });
/*     */     
/*  91 */     if (name != null) {
/*     */       
/*  93 */       JLabel label = new JLabel(name, 0);
/*  94 */       label.setAlignmentX(0.5F);
/*  95 */       add(label, "West");
/*     */     } 
/*     */     
/*  98 */     add(this.slider, "Center");
/*  99 */     add(this.spinner, "East");
/*     */     
/* 101 */     this.model = model;
/* 102 */     model.setUpdateListener(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setNumColummns(int cols) {
/* 107 */     ((JSpinner.NumberEditor)this.spinner.getEditor()).getTextField().setColumns(cols);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void update() {
/* 113 */     int value = this.model.getCurrentValue();
/* 114 */     int min = this.model.getRangeMin();
/* 115 */     int max = this.model.getRangeMax();
/* 116 */     if (this.slider.getMaximum() != max || this.slider.getMinimum() != min) {
/*     */       
/* 118 */       this.slider.setMinimum(min);
/* 119 */       this.slider.setMaximum(max);
/* 120 */       SpinnerNumberModel spinnerModel = (SpinnerNumberModel)this.spinner.getModel();
/* 121 */       spinnerModel.setMinimum(Integer.valueOf(min));
/* 122 */       spinnerModel.setMaximum(Integer.valueOf(max));
/*     */     } 
/* 124 */     this.slider.setValue(value);
/* 125 */     this.spinner.setValue(Integer.valueOf(value));
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/gui/displaysettings/SliderPanel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */