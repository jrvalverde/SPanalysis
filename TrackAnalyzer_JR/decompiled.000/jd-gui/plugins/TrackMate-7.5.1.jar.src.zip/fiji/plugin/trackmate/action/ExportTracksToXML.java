/*     */ package fiji.plugin.trackmate.action;
/*     */ 
/*     */ import fiji.plugin.trackmate.Logger;
/*     */ import fiji.plugin.trackmate.Model;
/*     */ import fiji.plugin.trackmate.SelectionModel;
/*     */ import fiji.plugin.trackmate.Settings;
/*     */ import fiji.plugin.trackmate.Spot;
/*     */ import fiji.plugin.trackmate.TrackMate;
/*     */ import fiji.plugin.trackmate.gui.Icons;
/*     */ import fiji.plugin.trackmate.gui.displaysettings.DisplaySettings;
/*     */ import fiji.plugin.trackmate.io.IOUtils;
/*     */ import fiji.plugin.trackmate.util.TMUtils;
/*     */ import java.awt.Frame;
/*     */ import java.io.File;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.util.Set;
/*     */ import java.util.TreeSet;
/*     */ import javax.swing.ImageIcon;
/*     */ import org.jdom2.Content;
/*     */ import org.jdom2.Document;
/*     */ import org.jdom2.Element;
/*     */ import org.jdom2.output.Format;
/*     */ import org.jdom2.output.XMLOutputter;
/*     */ import org.scijava.plugin.Plugin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ExportTracksToXML
/*     */   extends AbstractTMAction
/*     */ {
/*     */   public static final String NAME = "Export tracks to XML file";
/*     */   public static final String KEY = "EXPORT_TRACKS_TO_XML_SIMPLE";
/*     */   public static final String INFO_TEXT = "<html>Export the tracks in the current model content to a XML file in a simple format. <p> The file will have one element per track, and each track contains several spot elements. These spots are sorted by frame number, and have 4 numerical attributes: the frame number this spot is in, and its X, Y, Z position in physical units as specified in the image properties. <p>As such, this format <u>cannot</u> handle track merging and splitting properly, and is suited only for non-branching tracks.</html>";
/*     */   private static final String CONTENT_KEY = "Tracks";
/*     */   private static final String DATE_ATT = "generationDateTime";
/*     */   private static final String PHYSUNIT_ATT = "spaceUnits";
/*     */   private static final String FRAMEINTERVAL_ATT = "frameInterval";
/*     */   private static final String FRAMEINTERVALUNIT_ATT = "timeUnits";
/*     */   private static final String FROM_ATT = "from";
/*     */   private static final String NTRACKS_ATT = "nTracks";
/*     */   private static final String NSPOTS_ATT = "nSpots";
/*     */   private static final String TRACK_KEY = "particle";
/*     */   private static final String SPOT_KEY = "detection";
/*     */   private static final String X_ATT = "x";
/*     */   private static final String Y_ATT = "y";
/*     */   private static final String Z_ATT = "z";
/*     */   private static final String T_ATT = "t";
/*     */   
/*     */   public static void export(Model model, Settings settings, File file) throws FileNotFoundException, IOException {
/*  88 */     Element root = marshall(model, settings, Logger.VOID_LOGGER);
/*  89 */     Document document = new Document(root);
/*  90 */     XMLOutputter outputter = new XMLOutputter(Format.getPrettyFormat());
/*  91 */     outputter.output(document, new FileOutputStream(file));
/*     */   }
/*     */ 
/*     */   
/*     */   public void execute(TrackMate trackmate, SelectionModel selectionModel, DisplaySettings displaySettings, Frame parent) {
/*     */     File folder;
/*  97 */     this.logger.log("Exporting tracks to simple XML format.\n");
/*  98 */     Model model = trackmate.getModel();
/*  99 */     int ntracks = model.getTrackModel().nTracks(true);
/* 100 */     if (ntracks == 0) {
/* 101 */       this.logger.log("No visible track found. Aborting.\n");
/*     */       
/*     */       return;
/*     */     } 
/* 105 */     this.logger.log("  Preparing XML data.\n");
/* 106 */     Element root = marshall(model, trackmate.getSettings(), this.logger);
/*     */ 
/*     */     
/*     */     try {
/* 110 */       folder = new File(((trackmate.getSettings()).imp.getOriginalFileInfo()).directory);
/* 111 */     } catch (NullPointerException npe) {
/* 112 */       folder = (new File(System.getProperty("user.dir"))).getParentFile().getParentFile();
/*     */     } 
/*     */ 
/*     */     
/*     */     try {
/* 117 */       String filename = (trackmate.getSettings()).imageFileName;
/* 118 */       int dot = filename.indexOf(".");
/* 119 */       filename = (dot < 0) ? filename : filename.substring(0, dot);
/* 120 */       file = new File(folder.getPath() + File.separator + filename + "_Tracks.xml");
/* 121 */     } catch (NullPointerException npe) {
/* 122 */       file = new File(folder.getPath() + File.separator + "Tracks.xml");
/*     */     } 
/* 124 */     File file = IOUtils.askForFileForSaving(file, parent, this.logger);
/* 125 */     if (null == file) {
/*     */       return;
/*     */     }
/*     */     
/* 129 */     this.logger.log("  Writing to file.\n");
/* 130 */     Document document = new Document(root);
/* 131 */     XMLOutputter outputter = new XMLOutputter(Format.getPrettyFormat());
/*     */     try {
/* 133 */       outputter.output(document, new FileOutputStream(file));
/* 134 */     } catch (FileNotFoundException e) {
/* 135 */       this.logger.error("Trouble writing to " + file + ":\n" + e.getMessage());
/* 136 */     } catch (IOException e) {
/* 137 */       this.logger.error("Trouble writing to " + file + ":\n" + e.getMessage());
/*     */     } 
/* 139 */     this.logger.log("Done.\n");
/*     */   }
/*     */   
/*     */   private static Element marshall(Model model, Settings settings, Logger logger) {
/* 143 */     logger.setStatus("Marshalling...");
/* 144 */     Element content = new Element("Tracks");
/*     */     
/* 146 */     content.setAttribute("nTracks", "" + model.getTrackModel().nTracks(true));
/* 147 */     content.setAttribute("spaceUnits", model.getSpaceUnits());
/* 148 */     content.setAttribute("frameInterval", "" + settings.dt);
/* 149 */     content.setAttribute("timeUnits", "" + model.getTimeUnits());
/* 150 */     content.setAttribute("generationDateTime", TMUtils.getCurrentTimeString());
/* 151 */     content.setAttribute("from", "TrackMate v" + TrackMate.PLUGIN_NAME_VERSION);
/*     */     
/* 153 */     Set<Integer> trackIDs = model.getTrackModel().trackIDs(true);
/* 154 */     int i = 0;
/* 155 */     for (Integer trackID : trackIDs) {
/*     */       
/* 157 */       Set<Spot> track = model.getTrackModel().trackSpots(trackID);
/*     */       
/* 159 */       Element trackElement = new Element("particle");
/* 160 */       trackElement.setAttribute("nSpots", "" + track.size());
/*     */ 
/*     */       
/* 163 */       TreeSet<Spot> sortedTrack = new TreeSet<>(Spot.timeComparator);
/* 164 */       sortedTrack.addAll(track);
/*     */       
/* 166 */       for (Spot spot : sortedTrack) {
/* 167 */         int frame = spot.getFeature("FRAME").intValue();
/* 168 */         double x = spot.getFeature("POSITION_X").doubleValue();
/* 169 */         double y = spot.getFeature("POSITION_Y").doubleValue();
/* 170 */         double z = spot.getFeature("POSITION_Z").doubleValue();
/*     */         
/* 172 */         Element spotElement = new Element("detection");
/* 173 */         spotElement.setAttribute("t", "" + frame);
/* 174 */         spotElement.setAttribute("x", "" + x);
/* 175 */         spotElement.setAttribute("y", "" + y);
/* 176 */         spotElement.setAttribute("z", "" + z);
/* 177 */         trackElement.addContent((Content)spotElement);
/*     */       } 
/* 179 */       content.addContent((Content)trackElement);
/* 180 */       logger.setProgress(i++ / (0.0D + model.getTrackModel().nTracks(true)));
/*     */     } 
/*     */     
/* 183 */     logger.setStatus("");
/* 184 */     logger.setProgress(1.0D);
/* 185 */     return content;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Plugin(type = TrackMateActionFactory.class)
/*     */   public static class Factory
/*     */     implements TrackMateActionFactory
/*     */   {
/*     */     public String getInfoText() {
/* 214 */       return "<html>Export the tracks in the current model content to a XML file in a simple format. <p> The file will have one element per track, and each track contains several spot elements. These spots are sorted by frame number, and have 4 numerical attributes: the frame number this spot is in, and its X, Y, Z position in physical units as specified in the image properties. <p>As such, this format <u>cannot</u> handle track merging and splitting properly, and is suited only for non-branching tracks.</html>";
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public String getName() {
/* 220 */       return "Export tracks to XML file";
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public String getKey() {
/* 226 */       return "EXPORT_TRACKS_TO_XML_SIMPLE";
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public TrackMateAction create() {
/* 232 */       return new ExportTracksToXML();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public ImageIcon getIcon() {
/* 238 */       return Icons.SAVE_ICON;
/*     */     }
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/action/ExportTracksToXML.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */