/*    */ package fiji.plugin.trackmate.visualization.trackscheme;
/*    */ 
/*    */ import fiji.plugin.trackmate.Settings;
/*    */ import fiji.plugin.trackmate.Spot;
/*    */ import fiji.plugin.trackmate.util.TMUtils;
/*    */ import net.imagej.ImgPlus;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SpotImageUpdater
/*    */ {
/*    */   private int previousFrame;
/*    */   private int previousChannel;
/*    */   private SpotIconGrabber<?> grabber;
/*    */   private final Settings settings;
/*    */   
/*    */   public SpotImageUpdater(Settings settings) {
/* 49 */     this.settings = settings;
/* 50 */     this.previousFrame = -1;
/* 51 */     this.previousChannel = -1;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getImageString(Spot spot, double radiusFactor) {
/* 69 */     int frame = spot.getFeature("FRAME").intValue();
/* 70 */     int targetChannel = this.settings.imp.getC() - 1;
/* 71 */     if (frame != this.previousFrame || targetChannel != this.previousChannel) {
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */       
/* 77 */       ImgPlus img = TMUtils.rawWraps(this.settings.imp);
/* 78 */       ImgPlus<?> imgCT = TMUtils.hyperSlice(img, targetChannel, frame);
/*    */       
/* 80 */       this.grabber = new SpotIconGrabber(imgCT);
/* 81 */       this.previousFrame = frame;
/* 82 */       this.previousChannel = targetChannel;
/*    */     } 
/* 84 */     return this.grabber.getImageString(spot, radiusFactor);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/visualization/trackscheme/SpotImageUpdater.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */