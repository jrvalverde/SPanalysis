/*     */ package fiji.plugin.trackmate.gui;
/*     */ 
/*     */ import ij.IJ;
/*     */ import ij.ImagePlus;
/*     */ import ij.measure.Calibration;
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.DisplayMode;
/*     */ import java.awt.GraphicsDevice;
/*     */ import java.awt.GraphicsEnvironment;
/*     */ import java.awt.Point;
/*     */ import java.awt.Window;
/*     */ import java.awt.color.ColorSpace;
/*     */ import java.awt.event.FocusEvent;
/*     */ import java.awt.event.FocusListener;
/*     */ import java.awt.event.WindowAdapter;
/*     */ import java.awt.event.WindowEvent;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JOptionPane;
/*     */ import javax.swing.JTextField;
/*     */ import javax.swing.SwingUtilities;
/*     */ import javax.swing.UIManager;
/*     */ import javax.swing.event.AncestorEvent;
/*     */ import javax.swing.event.AncestorListener;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GuiUtils
/*     */ {
/*  53 */   private static final FocusListener selectAllFocusListener = new FocusListener()
/*     */     {
/*     */       public void focusLost(FocusEvent e) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public void focusGained(FocusEvent fe) {
/*  63 */         if (!(fe.getSource() instanceof JTextField))
/*     */           return; 
/*  65 */         JTextField txt = (JTextField)fe.getSource();
/*  66 */         SwingUtilities.invokeLater(() -> txt.selectAll());
/*     */       }
/*     */     };
/*     */ 
/*     */   
/*     */   public static final void selectAllOnFocus(JTextField tf) {
/*  72 */     tf.addFocusListener(selectAllFocusListener);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Color textColorForBackground(Color backgroundColor) {
/*  86 */     if (backgroundColor.getRed() * 0.299D + backgroundColor
/*  87 */       .getGreen() * 0.587D + backgroundColor
/*  88 */       .getBlue() * 0.114D > 150.0D) {
/*  89 */       return Color.BLACK;
/*     */     }
/*  91 */     return Color.WHITE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static double colorDistance(Color a, Color b) {
/* 108 */     float[] labA = toCIELab(a);
/* 109 */     float[] labB = toCIELab(b);
/* 110 */     float deltaL = labA[0] - labB[0];
/* 111 */     float deltaA = labA[1] - labB[1];
/* 112 */     float deltaB = labA[2] - labB[2];
/* 113 */     double c1 = Math.sqrt((labA[1] * labA[1] + labA[2] * labA[2]));
/* 114 */     double c2 = Math.sqrt((labB[1] * labB[1] + labB[2] * labB[2]));
/* 115 */     double deltaC = c1 - c2;
/* 116 */     double deltaH = (deltaA * deltaA + deltaB * deltaB) - deltaC * deltaC;
/* 117 */     deltaH = (deltaH < 0.0D) ? 0.0D : Math.sqrt(deltaH);
/* 118 */     double sc = 1.0D + 0.045D * c1;
/* 119 */     double sh = 1.0D + 0.015D * c1;
/* 120 */     double deltaLKlsl = deltaL / 1.0D;
/* 121 */     double deltaCkcsc = deltaC / sc;
/* 122 */     double deltaHkhsh = deltaH / sh;
/* 123 */     double i = deltaLKlsl * deltaLKlsl + deltaCkcsc * deltaCkcsc + deltaHkhsh * deltaHkhsh;
/* 124 */     return (i < 0.0D) ? 0.0D : Math.sqrt(i);
/*     */   }
/*     */ 
/*     */   
/*     */   private static final float[] fromCIEXYZ(float[] colorvalue) {
/* 129 */     double l = f(colorvalue[1]);
/* 130 */     double L = 116.0D * l - 16.0D;
/* 131 */     double a = 500.0D * (f(colorvalue[0]) - l);
/* 132 */     double b = 200.0D * (l - f(colorvalue[2]));
/* 133 */     return new float[] { (float)L, (float)a, (float)b };
/*     */   }
/*     */ 
/*     */   
/*     */   private static double f(double x) {
/* 138 */     double N = 0.13793103448275862D;
/* 139 */     if (x > 0.008856451679035631D) {
/* 140 */       return Math.cbrt(x);
/*     */     }
/* 142 */     return 7.787037037037037D * x + 0.13793103448275862D;
/*     */   }
/*     */ 
/*     */   
/*     */   public static final float[] toCIELab(Color color) {
/* 147 */     float[] rgbvalue = color.getColorComponents(null);
/* 148 */     ColorSpace CIEXYZ = ColorSpace.getInstance(1001);
/* 149 */     float[] xyz = CIEXYZ.fromRGB(rgbvalue);
/* 150 */     return fromCIEXYZ(xyz);
/*     */   }
/*     */ 
/*     */   
/*     */   public static final Color invert(Color color) {
/* 155 */     return new Color(255 - color.getRed(), 255 - color
/* 156 */         .getGreen(), 255 - color
/* 157 */         .getBlue());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void positionWindow(Window gui, Component component) {
/* 166 */     if (null != component) {
/*     */ 
/*     */       
/* 169 */       GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
/* 170 */       GraphicsDevice[] gs = ge.getScreenDevices();
/* 171 */       int screenWidth = 0;
/* 172 */       for (int i = 0; i < gs.length; i++) {
/*     */         
/* 174 */         DisplayMode dm = gs[i].getDisplayMode();
/* 175 */         screenWidth += dm.getWidth();
/*     */       } 
/*     */       
/* 178 */       Point windowLoc = component.getLocation();
/* 179 */       Dimension windowSize = component.getSize();
/* 180 */       Dimension guiSize = gui.getSize();
/* 181 */       if (guiSize.width > windowLoc.x)
/*     */       {
/* 183 */         if (guiSize.width > screenWidth - windowLoc.x + windowSize.width)
/*     */         {
/* 185 */           gui.setLocationRelativeTo((Component)null);
/*     */         
/*     */         }
/*     */         else
/*     */         {
/* 190 */           gui.setLocation(windowLoc.x + windowSize.width, windowLoc.y);
/*     */         }
/*     */       
/*     */       }
/*     */       else
/*     */       {
/* 196 */         gui.setLocation(windowLoc.x - guiSize.width, windowLoc.y);
/*     */       }
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 202 */       gui.setLocationRelativeTo((Component)null);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static final void userCheckImpDimensions(ImagePlus imp) {
/* 208 */     int[] dims = imp.getDimensions();
/* 209 */     if (dims[4] == 1 && dims[3] > 1) {
/*     */       Calibration calibration;
/* 211 */       switch (JOptionPane.showConfirmDialog(null, "It appears this image has 1 timepoint but " + dims[3] + " slices.\nDo you want to swap Z and T?", "Z/T swapped?", 1)) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         case 0:
/* 219 */           imp.setDimensions(dims[2], dims[4], dims[3]);
/* 220 */           calibration = imp.getCalibration();
/* 221 */           if (0.0D == calibration.frameInterval) {
/*     */             
/* 223 */             calibration.frameInterval = 1.0D;
/* 224 */             calibration.setTimeUnit("frame");
/*     */           } 
/*     */           break;
/*     */         case 2:
/*     */           return;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setSystemLookAndFeel() {
/* 236 */     if (IJ.isMacOSX() || IJ.isWindows()) {
/*     */       
/*     */       try {
/*     */         
/* 240 */         UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
/*     */       }
/* 242 */       catch (ClassNotFoundException|InstantiationException|IllegalAccessException|javax.swing.UnsupportedLookAndFeelException e) {
/*     */         
/* 244 */         e.printStackTrace();
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void addOnClosingEvent(final JComponent component, final Runnable runnable) {
/* 252 */     component.addAncestorListener(new AncestorListener()
/*     */         {
/*     */           public void ancestorRemoved(AncestorEvent event) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           public void ancestorMoved(AncestorEvent event) {}
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           public void ancestorAdded(AncestorEvent event) {
/* 266 */             SwingUtilities.getWindowAncestor(component).addWindowListener(new WindowAdapter()
/*     */                 {
/*     */                   
/*     */                   public void windowClosing(WindowEvent e)
/*     */                   {
/* 271 */                     runnable.run();
/*     */                   }
/*     */                 });
/*     */           }
/*     */         });
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/gui/GuiUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */