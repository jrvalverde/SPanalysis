/*     */ package fiji.plugin.trackmate.features.manual;
/*     */ 
/*     */ import fiji.plugin.trackmate.Dimension;
/*     */ import fiji.plugin.trackmate.Model;
/*     */ import fiji.plugin.trackmate.features.edges.EdgeAnalyzer;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.swing.ImageIcon;
/*     */ import org.jgrapht.graph.DefaultWeightedEdge;
/*     */ import org.scijava.plugin.Plugin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Plugin(type = EdgeAnalyzer.class)
/*     */ public class ManualEdgeColorAnalyzer
/*     */   implements EdgeAnalyzer
/*     */ {
/*     */   public static final String FEATURE = "MANUAL_EGE_COLOR";
/*     */   public static final String KEY = "Manual edge color";
/*  47 */   static final List<String> FEATURES = new ArrayList<>(1);
/*     */   
/*  49 */   static final Map<String, String> FEATURE_SHORT_NAMES = new HashMap<>(1);
/*     */   
/*  51 */   static final Map<String, String> FEATURE_NAMES = new HashMap<>(1);
/*     */   
/*  53 */   static final Map<String, Dimension> FEATURE_DIMENSIONS = new HashMap<>(1);
/*     */   
/*  55 */   static final Map<String, Boolean> IS_INT = new HashMap<>(1);
/*     */   
/*     */   static final String INFO_TEXT = "<html>A dummy analyzer for the feature that stores the color manually assigned to each edge.</html>";
/*     */   
/*     */   static final String NAME = "Manual edge color";
/*     */   private long processingTime;
/*     */   
/*     */   static {
/*  63 */     FEATURES.add("MANUAL_EGE_COLOR");
/*  64 */     FEATURE_SHORT_NAMES.put("MANUAL_EGE_COLOR", "Edge color");
/*  65 */     FEATURE_NAMES.put("MANUAL_EGE_COLOR", "Manual edge color");
/*  66 */     FEATURE_DIMENSIONS.put("MANUAL_EGE_COLOR", Dimension.NONE);
/*  67 */     IS_INT.put("MANUAL_EGE_COLOR", Boolean.TRUE);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getProcessingTime() {
/*  75 */     return this.processingTime;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getKey() {
/*  81 */     return "Manual edge color";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public List<String> getFeatures() {
/*  87 */     return FEATURES;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, String> getFeatureShortNames() {
/*  93 */     return FEATURE_SHORT_NAMES;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, String> getFeatureNames() {
/*  99 */     return FEATURE_NAMES;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, Dimension> getFeatureDimensions() {
/* 105 */     return FEATURE_DIMENSIONS;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, Boolean> getIsIntFeature() {
/* 111 */     return IS_INT;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setNumThreads() {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void setNumThreads(int numThreads) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public int getNumThreads() {
/* 125 */     return 1;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getInfoText() {
/* 131 */     return "<html>A dummy analyzer for the feature that stores the color manually assigned to each edge.</html>";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ImageIcon getIcon() {
/* 137 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/* 143 */     return "Manual edge color";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void process(Collection<DefaultWeightedEdge> edges, Model model) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isLocal() {
/* 153 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isManualFeature() {
/* 159 */     return true;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/features/manual/ManualEdgeColorAnalyzer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */