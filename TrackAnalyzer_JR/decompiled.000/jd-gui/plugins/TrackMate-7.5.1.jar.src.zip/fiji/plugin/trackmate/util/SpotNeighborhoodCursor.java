/*     */ package fiji.plugin.trackmate.util;
/*     */ 
/*     */ import net.imglib2.Cursor;
/*     */ import net.imglib2.RealCursor;
/*     */ import net.imglib2.Sampler;
/*     */ import net.imglib2.type.numeric.RealType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SpotNeighborhoodCursor<T extends RealType<T>>
/*     */   implements Cursor<T>
/*     */ {
/*     */   protected final Cursor<T> cursor;
/*     */   protected final double[] calibration;
/*     */   protected final long[] center;
/*     */   private final long[] pos;
/*     */   
/*     */   public SpotNeighborhoodCursor(SpotNeighborhood<T> sn) {
/*  45 */     this.cursor = sn.neighborhood.cursor();
/*  46 */     this.calibration = sn.calibration;
/*  47 */     this.center = sn.center;
/*  48 */     this.pos = new long[this.cursor.numDimensions()];
/*  49 */     reset();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void getRelativePosition(double[] position) {
/*  61 */     this.cursor.localize(this.pos);
/*  62 */     for (int d = 0; d < this.center.length; d++) {
/*  63 */       position[d] = this.calibration[d] * (this.pos[d] - this.center[d]);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getDistanceSquared() {
/*  72 */     this.cursor.localize(this.pos);
/*  73 */     double sum = 0.0D;
/*  74 */     double dx = 0.0D;
/*  75 */     for (int d = 0; d < this.pos.length; d++) {
/*  76 */       dx = this.calibration[d] * (this.pos[d] - this.center[d]);
/*  77 */       sum += dx * dx;
/*     */     } 
/*  79 */     return sum;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getTheta() {
/*  91 */     if (numDimensions() < 2)
/*  92 */       return 0.0D; 
/*  93 */     double dx = this.calibration[2] * (this.cursor.getDoublePosition(2) - this.center[2]);
/*  94 */     return Math.acos(dx / Math.sqrt(getDistanceSquared()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getPhi() {
/* 106 */     double dx = this.calibration[0] * (this.cursor.getDoublePosition(0) - this.center[0]);
/* 107 */     double dy = this.calibration[1] * (this.cursor.getDoublePosition(1) - this.center[1]);
/* 108 */     return Math.atan2(dy, dx);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void localize(float[] position) {
/* 118 */     this.cursor.localize(position);
/*     */   }
/*     */ 
/*     */   
/*     */   public void localize(double[] position) {
/* 123 */     this.cursor.localize(position);
/*     */   }
/*     */ 
/*     */   
/*     */   public float getFloatPosition(int d) {
/* 128 */     return this.cursor.getFloatPosition(d);
/*     */   }
/*     */ 
/*     */   
/*     */   public double getDoublePosition(int d) {
/* 133 */     return this.cursor.getDoublePosition(d);
/*     */   }
/*     */ 
/*     */   
/*     */   public int numDimensions() {
/* 138 */     return this.cursor.numDimensions();
/*     */   }
/*     */ 
/*     */   
/*     */   public T get() {
/* 143 */     return (T)this.cursor.get();
/*     */   }
/*     */ 
/*     */   
/*     */   public Sampler<T> copy() {
/* 148 */     return this.cursor.copy();
/*     */   }
/*     */ 
/*     */   
/*     */   public void jumpFwd(long steps) {
/* 153 */     this.cursor.jumpFwd(steps);
/*     */   }
/*     */ 
/*     */   
/*     */   public void fwd() {
/* 158 */     this.cursor.fwd();
/*     */   }
/*     */ 
/*     */   
/*     */   public void reset() {
/* 163 */     this.cursor.reset();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasNext() {
/* 168 */     return this.cursor.hasNext();
/*     */   }
/*     */ 
/*     */   
/*     */   public T next() {
/* 173 */     return (T)this.cursor.next();
/*     */   }
/*     */ 
/*     */   
/*     */   public void remove() {
/* 178 */     this.cursor.remove();
/*     */   }
/*     */ 
/*     */   
/*     */   public void localize(int[] position) {
/* 183 */     this.cursor.localize(position);
/*     */   }
/*     */ 
/*     */   
/*     */   public void localize(long[] position) {
/* 188 */     this.cursor.localize(position);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getIntPosition(int d) {
/* 193 */     return this.cursor.getIntPosition(d);
/*     */   }
/*     */ 
/*     */   
/*     */   public long getLongPosition(int d) {
/* 198 */     return this.cursor.getLongPosition(d);
/*     */   }
/*     */ 
/*     */   
/*     */   public Cursor<T> copyCursor() {
/* 203 */     return this.cursor.copyCursor();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/util/SpotNeighborhoodCursor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */