/*     */ package fiji.plugin.trackmate.tracking.kdtree;
/*     */ 
/*     */ import fiji.plugin.trackmate.Logger;
/*     */ import fiji.plugin.trackmate.Spot;
/*     */ import fiji.plugin.trackmate.SpotCollection;
/*     */ import fiji.plugin.trackmate.tracking.SpotTracker;
/*     */ import fiji.plugin.trackmate.util.TMUtils;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.TreeSet;
/*     */ import java.util.concurrent.Callable;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.Executors;
/*     */ import java.util.concurrent.Future;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ import net.imglib2.KDTree;
/*     */ import net.imglib2.RealLocalizable;
/*     */ import net.imglib2.RealPoint;
/*     */ import net.imglib2.algorithm.MultiThreadedBenchmarkAlgorithm;
/*     */ import org.jgrapht.graph.DefaultWeightedEdge;
/*     */ import org.jgrapht.graph.SimpleWeightedGraph;
/*     */ import org.scijava.Cancelable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NearestNeighborTracker
/*     */   extends MultiThreadedBenchmarkAlgorithm
/*     */   implements SpotTracker, Cancelable
/*     */ {
/*     */   protected final SpotCollection spots;
/*     */   protected final Map<String, Object> settings;
/*  64 */   protected Logger logger = Logger.VOID_LOGGER;
/*     */ 
/*     */   
/*     */   protected SimpleWeightedGraph<Spot, DefaultWeightedEdge> graph;
/*     */ 
/*     */   
/*     */   private boolean isCanceled;
/*     */ 
/*     */   
/*     */   private String cancelReason;
/*     */ 
/*     */ 
/*     */   
/*     */   public NearestNeighborTracker(SpotCollection spots, Map<String, Object> settings) {
/*  78 */     this.spots = spots;
/*  79 */     this.settings = settings;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean checkInput() {
/*  89 */     StringBuilder errrorHolder = new StringBuilder();
/*  90 */     boolean ok = checkInput(this.settings, errrorHolder);
/*  91 */     if (!ok) {
/*  92 */       this.errorMessage = errrorHolder.toString();
/*     */     }
/*  94 */     return ok;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean process() {
/* 100 */     long start = System.currentTimeMillis();
/*     */     
/* 102 */     this.isCanceled = false;
/* 103 */     this.cancelReason = null;
/*     */     
/* 105 */     reset();
/*     */     
/* 107 */     double maxLinkingDistance = ((Double)this.settings.get("LINKING_MAX_DISTANCE")).doubleValue();
/* 108 */     final double maxDistSquare = maxLinkingDistance * maxLinkingDistance;
/* 109 */     final TreeSet<Integer> frames = new TreeSet<>(this.spots.keySet());
/*     */ 
/*     */     
/* 112 */     final AtomicInteger progress = new AtomicInteger(0);
/* 113 */     ExecutorService executors = Executors.newFixedThreadPool(this.numThreads);
/* 114 */     List<Future<Void>> futures = new ArrayList<>(frames.size());
/* 115 */     for (int i = ((Integer)frames.first()).intValue(); i < ((Integer)frames.last()).intValue(); i++) {
/*     */       
/* 117 */       final int frame = i;
/* 118 */       Future<Void> future = executors.submit(new Callable<Void>()
/*     */           {
/*     */ 
/*     */             
/*     */             public Void call() throws Exception
/*     */             {
/* 124 */               if (NearestNeighborTracker.this.isCanceled()) {
/* 125 */                 return null;
/*     */               }
/*     */               
/* 128 */               int sourceFrame = frame;
/* 129 */               int targetFrame = ((Integer)frames.higher(Integer.valueOf(frame))).intValue();
/*     */               
/* 131 */               int nTargetSpots = NearestNeighborTracker.this.spots.getNSpots(targetFrame, true);
/* 132 */               if (nTargetSpots < 1) {
/*     */                 
/* 134 */                 NearestNeighborTracker.this.logger.setProgress(progress.incrementAndGet() / frames.size());
/* 135 */                 return null;
/*     */               } 
/*     */               
/* 138 */               List<RealPoint> targetCoords = new ArrayList<>(nTargetSpots);
/* 139 */               List<FlagNode<Spot>> targetNodes = new ArrayList<>(nTargetSpots);
/* 140 */               Iterator<Spot> targetIt = NearestNeighborTracker.this.spots.iterator(Integer.valueOf(targetFrame), true);
/* 141 */               while (targetIt.hasNext()) {
/*     */                 
/* 143 */                 double[] coords = new double[3];
/* 144 */                 Spot spot = targetIt.next();
/* 145 */                 TMUtils.localize(spot, coords);
/* 146 */                 targetCoords.add(new RealPoint(coords));
/* 147 */                 targetNodes.add(new FlagNode<>(spot));
/*     */               } 
/*     */               
/* 150 */               KDTree<FlagNode<Spot>> tree = new KDTree(targetNodes, targetCoords);
/* 151 */               NearestNeighborFlagSearchOnKDTree<Spot> search = new NearestNeighborFlagSearchOnKDTree<>(tree);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */               
/* 157 */               Iterator<Spot> sourceIt = NearestNeighborTracker.this.spots.iterator(Integer.valueOf(sourceFrame), true);
/* 158 */               while (sourceIt.hasNext()) {
/*     */                 
/* 160 */                 Spot source = sourceIt.next();
/* 161 */                 double[] coords = new double[3];
/* 162 */                 TMUtils.localize(source, coords);
/* 163 */                 RealPoint sourceCoords = new RealPoint(coords);
/* 164 */                 search.search((RealLocalizable)sourceCoords);
/*     */                 
/* 166 */                 double squareDist = search.getSquareDistance();
/* 167 */                 FlagNode<Spot> targetNode = (FlagNode<Spot>)search.getSampler().get();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */                 
/* 173 */                 if (squareDist > maxDistSquare) {
/*     */                   continue;
/*     */                 }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */                 
/* 182 */                 targetNode.setVisited(true);
/* 183 */                 synchronized (NearestNeighborTracker.this.graph) {
/*     */                   
/* 185 */                   DefaultWeightedEdge edge = (DefaultWeightedEdge)NearestNeighborTracker.this.graph.addEdge(source, targetNode.getValue());
/* 186 */                   NearestNeighborTracker.this.graph.setEdgeWeight(edge, squareDist);
/*     */                 } 
/*     */               } 
/* 189 */               NearestNeighborTracker.this.logger.setProgress(progress.incrementAndGet() / frames.size());
/* 190 */               return null;
/*     */             }
/*     */           });
/* 193 */       futures.add(future);
/*     */     } 
/*     */     
/* 196 */     this.logger.setStatus("Tracking...");
/* 197 */     this.logger.setProgress(0.0D);
/*     */ 
/*     */     
/*     */     try {
/* 201 */       for (Future<Void> future : futures) {
/* 202 */         future.get();
/*     */       }
/* 204 */       executors.shutdown();
/*     */     }
/* 206 */     catch (InterruptedException|java.util.concurrent.ExecutionException e) {
/*     */       
/* 208 */       e.printStackTrace();
/* 209 */       this.errorMessage = e.getMessage();
/* 210 */       return false;
/*     */     }
/*     */     finally {
/*     */       
/* 214 */       this.logger.setProgress(1.0D);
/* 215 */       this.logger.setStatus("");
/*     */       
/* 217 */       long end = System.currentTimeMillis();
/* 218 */       this.processingTime = end - start;
/*     */     } 
/* 220 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public SimpleWeightedGraph<Spot, DefaultWeightedEdge> getResult() {
/* 226 */     return this.graph;
/*     */   }
/*     */ 
/*     */   
/*     */   public void reset() {
/* 231 */     this.graph = new SimpleWeightedGraph(DefaultWeightedEdge.class);
/* 232 */     Iterator<Spot> it = this.spots.iterator(true);
/* 233 */     while (it.hasNext()) {
/* 234 */       this.graph.addVertex(it.next());
/*     */     }
/*     */   }
/*     */   
/*     */   public static boolean checkInput(Map<String, Object> settings, StringBuilder errrorHolder) {
/* 239 */     boolean ok = TMUtils.checkParameter(settings, "LINKING_MAX_DISTANCE", Double.class, errrorHolder);
/* 240 */     List<String> mandatoryKeys = new ArrayList<>();
/* 241 */     mandatoryKeys.add("LINKING_MAX_DISTANCE");
/* 242 */     ok &= TMUtils.checkMapKeys(settings, mandatoryKeys, null, errrorHolder);
/* 243 */     return ok;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLogger(Logger logger) {
/* 249 */     this.logger = logger;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isCanceled() {
/* 257 */     return this.isCanceled;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void cancel(String reason) {
/* 263 */     this.isCanceled = true;
/* 264 */     this.cancelReason = reason;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getCancelReason() {
/* 270 */     return this.cancelReason;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/tracking/kdtree/NearestNeighborTracker.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */