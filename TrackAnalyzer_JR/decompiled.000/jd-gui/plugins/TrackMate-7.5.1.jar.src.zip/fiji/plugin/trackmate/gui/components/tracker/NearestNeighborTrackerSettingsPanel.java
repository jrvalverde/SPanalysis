/*     */ package fiji.plugin.trackmate.gui.components.tracker;
/*     */ 
/*     */ import fiji.plugin.trackmate.gui.Fonts;
/*     */ import fiji.plugin.trackmate.gui.GuiUtils;
/*     */ import fiji.plugin.trackmate.gui.components.ConfigurationPanel;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import javax.swing.JFormattedTextField;
/*     */ import javax.swing.JLabel;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NearestNeighborTrackerSettingsPanel
/*     */   extends ConfigurationPanel
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private JFormattedTextField maxDistField;
/*     */   private JLabel labelTrackerDescription;
/*     */   private JLabel labelUnits;
/*     */   private JLabel labelTracker;
/*     */   private final String infoText;
/*     */   private final String trackerName;
/*     */   private final String spaceUnits;
/*     */   
/*     */   public NearestNeighborTrackerSettingsPanel(String trackerName, String infoText, String spaceUnits) {
/*  54 */     this.trackerName = trackerName;
/*  55 */     this.infoText = infoText;
/*  56 */     this.spaceUnits = spaceUnits;
/*  57 */     initGUI();
/*     */   }
/*     */ 
/*     */   
/*     */   public Map<String, Object> getSettings() {
/*  62 */     Map<String, Object> settings = new HashMap<>();
/*  63 */     settings.put("LINKING_MAX_DISTANCE", Double.valueOf(((Number)this.maxDistField.getValue()).doubleValue()));
/*  64 */     return settings;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setSettings(Map<String, Object> settings) {
/*  69 */     this.maxDistField.setValue(settings.get("LINKING_MAX_DISTANCE"));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void initGUI() {
/*  75 */     setLayout(null);
/*     */     
/*  77 */     JLabel lblSettingsForTracker = new JLabel("Settings for tracker:");
/*  78 */     lblSettingsForTracker.setBounds(10, 11, 280, 20);
/*  79 */     lblSettingsForTracker.setFont(Fonts.FONT);
/*  80 */     add(lblSettingsForTracker);
/*     */ 
/*     */     
/*  83 */     this.labelTracker = new JLabel(this.trackerName);
/*  84 */     this.labelTracker.setFont(Fonts.BIG_FONT);
/*  85 */     this.labelTracker.setHorizontalAlignment(0);
/*  86 */     this.labelTracker.setBounds(10, 42, 280, 20);
/*  87 */     add(this.labelTracker);
/*     */     
/*  89 */     this.labelTrackerDescription = new JLabel("<tracker description>");
/*  90 */     this.labelTrackerDescription.setFont(Fonts.FONT.deriveFont(2));
/*  91 */     this.labelTrackerDescription.setBounds(10, 67, 280, 225);
/*  92 */     this.labelTrackerDescription.setText(this.infoText
/*  93 */         .replace("<br>", "")
/*  94 */         .replace("<p>", "<p align=\"justify\">")
/*  95 */         .replace("<html>", "<html><p align=\"justify\">"));
/*  96 */     add(this.labelTrackerDescription);
/*     */     
/*  98 */     JLabel lblMaximalLinkingDistance = new JLabel("Maximal linking distance: ");
/*  99 */     lblMaximalLinkingDistance.setFont(Fonts.FONT);
/* 100 */     lblMaximalLinkingDistance.setBounds(10, 314, 164, 20);
/* 101 */     add(lblMaximalLinkingDistance);
/*     */     
/* 103 */     this.maxDistField = new JFormattedTextField(Double.valueOf(15.0D));
/* 104 */     this.maxDistField.setFont(Fonts.FONT);
/* 105 */     this.maxDistField.setBounds(184, 316, 62, 16);
/* 106 */     this.maxDistField.setSize(Fonts.TEXTFIELD_DIMENSION);
/* 107 */     add(this.maxDistField);
/*     */     
/* 109 */     this.labelUnits = new JLabel(this.spaceUnits);
/* 110 */     this.labelUnits.setFont(Fonts.FONT);
/* 111 */     this.labelUnits.setBounds(236, 314, 34, 20);
/* 112 */     add(this.labelUnits);
/*     */ 
/*     */     
/* 115 */     GuiUtils.selectAllOnFocus(this.maxDistField);
/*     */   }
/*     */   
/*     */   public void clean() {}
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/gui/components/tracker/NearestNeighborTrackerSettingsPanel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */