/*     */ package fiji.plugin.trackmate.tracking.sparselap;
/*     */ 
/*     */ import fiji.plugin.trackmate.Logger;
/*     */ import fiji.plugin.trackmate.Spot;
/*     */ import fiji.plugin.trackmate.SpotCollection;
/*     */ import fiji.plugin.trackmate.tracking.LAPUtils;
/*     */ import fiji.plugin.trackmate.tracking.SpotTracker;
/*     */ import fiji.plugin.trackmate.tracking.sparselap.costfunction.CostFunction;
/*     */ import fiji.plugin.trackmate.tracking.sparselap.costfunction.FeaturePenaltyCostFunction;
/*     */ import fiji.plugin.trackmate.tracking.sparselap.costfunction.SquareDistCostFunction;
/*     */ import fiji.plugin.trackmate.tracking.sparselap.costmatrix.CostMatrixCreator;
/*     */ import fiji.plugin.trackmate.tracking.sparselap.costmatrix.JaqamanLinkingCostMatrixCreator;
/*     */ import fiji.plugin.trackmate.tracking.sparselap.linker.JaqamanLinker;
/*     */ import fiji.plugin.trackmate.util.TMUtils;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.Callable;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.Executors;
/*     */ import java.util.concurrent.Future;
/*     */ import java.util.concurrent.atomic.AtomicBoolean;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ import net.imglib2.algorithm.MultiThreadedBenchmarkAlgorithm;
/*     */ import org.jgrapht.graph.DefaultWeightedEdge;
/*     */ import org.jgrapht.graph.SimpleWeightedGraph;
/*     */ import org.scijava.Cancelable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SparseLAPFrameToFrameTracker
/*     */   extends MultiThreadedBenchmarkAlgorithm
/*     */   implements SpotTracker, Cancelable
/*     */ {
/*     */   private static final String BASE_ERROR_MESSAGE = "[SparseLAPFrameToFrameTracker] ";
/*     */   protected SimpleWeightedGraph<Spot, DefaultWeightedEdge> graph;
/*  64 */   protected Logger logger = Logger.VOID_LOGGER;
/*     */ 
/*     */   
/*     */   protected final SpotCollection spots;
/*     */ 
/*     */   
/*     */   protected final Map<String, Object> settings;
/*     */ 
/*     */   
/*     */   private boolean isCanceled;
/*     */ 
/*     */   
/*     */   private String cancelReason;
/*     */ 
/*     */   
/*     */   public SparseLAPFrameToFrameTracker(SpotCollection spots, Map<String, Object> settings) {
/*  80 */     this.spots = spots;
/*  81 */     this.settings = settings;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SimpleWeightedGraph<Spot, DefaultWeightedEdge> getResult() {
/*  91 */     return this.graph;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean checkInput() {
/*  97 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean process() {
/* 103 */     this.isCanceled = false;
/* 104 */     this.cancelReason = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 111 */     if (null == this.spots) {
/*     */       
/* 113 */       this.errorMessage = "[SparseLAPFrameToFrameTracker] The spot collection is null.";
/* 114 */       return false;
/*     */     } 
/*     */ 
/*     */     
/* 118 */     if (this.spots.keySet().isEmpty()) {
/*     */       
/* 120 */       this.errorMessage = "[SparseLAPFrameToFrameTracker] The spot collection is empty.";
/* 121 */       return false;
/*     */     } 
/*     */ 
/*     */     
/* 125 */     boolean empty = true;
/* 126 */     for (Iterator<Integer> iterator1 = this.spots.keySet().iterator(); iterator1.hasNext(); ) { int frame = ((Integer)iterator1.next()).intValue();
/*     */       
/* 128 */       if (this.spots.getNSpots(frame, true) > 0) {
/*     */         
/* 130 */         empty = false;
/*     */         break;
/*     */       }  }
/*     */     
/* 134 */     if (empty) {
/*     */       
/* 136 */       this.errorMessage = "[SparseLAPFrameToFrameTracker] The spot collection is empty.";
/* 137 */       return false;
/*     */     } 
/*     */     
/* 140 */     StringBuilder errorHolder = new StringBuilder();
/* 141 */     if (!checkSettingsValidity(this.settings, errorHolder)) {
/*     */       
/* 143 */       this.errorMessage = "[SparseLAPFrameToFrameTracker] " + errorHolder.toString();
/* 144 */       return false;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 151 */     long start = System.currentTimeMillis();
/*     */ 
/*     */     
/* 154 */     final ArrayList<int[]> framePairs = (ArrayList)new ArrayList<>(this.spots.keySet().size() - 1);
/* 155 */     Iterator<Integer> frameIterator = this.spots.keySet().iterator();
/* 156 */     int frame0 = ((Integer)frameIterator.next()).intValue();
/*     */     
/* 158 */     while (frameIterator.hasNext()) {
/*     */       
/* 160 */       int frame1 = ((Integer)frameIterator.next()).intValue();
/* 161 */       framePairs.add(new int[] { frame0, frame1 });
/* 162 */       frame0 = frame1;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 167 */     Map<String, Double> featurePenalties = (Map<String, Double>)this.settings.get("LINKING_FEATURE_PENALTIES");
/* 168 */     final CostFunction<Spot, Spot> costFunction = getCostFunction(featurePenalties);
/* 169 */     Double maxDist = (Double)this.settings.get("LINKING_MAX_DISTANCE");
/* 170 */     final double costThreshold = maxDist.doubleValue() * maxDist.doubleValue();
/* 171 */     final double alternativeCostFactor = ((Double)this.settings.get("ALTERNATIVE_LINKING_COST_FACTOR")).doubleValue();
/*     */ 
/*     */     
/* 174 */     this.graph = new SimpleWeightedGraph(DefaultWeightedEdge.class);
/*     */ 
/*     */     
/* 177 */     final AtomicInteger progress = new AtomicInteger(0);
/* 178 */     final AtomicBoolean ok = new AtomicBoolean(true);
/* 179 */     ExecutorService executors = Executors.newFixedThreadPool(this.numThreads);
/* 180 */     List<Future<Void>> futures = new ArrayList<>(framePairs.size());
/* 181 */     for (int[] framePair : framePairs) {
/*     */       
/* 183 */       Future<Void> future = executors.submit(new Callable<Void>()
/*     */           {
/*     */ 
/*     */             
/*     */             public Void call() throws Exception
/*     */             {
/* 189 */               if (!ok.get() || SparseLAPFrameToFrameTracker.this.isCanceled()) {
/* 190 */                 return null;
/*     */               }
/*     */               
/* 193 */               int lFrame0 = framePair[0];
/* 194 */               int lFrame1 = framePair[1];
/*     */ 
/*     */ 
/*     */               
/* 198 */               List<Spot> sources = new ArrayList<>(SparseLAPFrameToFrameTracker.this.spots.getNSpots(lFrame0, true));
/* 199 */               for (Iterator<Spot> iterator = SparseLAPFrameToFrameTracker.this.spots.iterator(Integer.valueOf(lFrame0), true); iterator.hasNext();) {
/* 200 */                 sources.add(iterator.next());
/*     */               }
/* 202 */               List<Spot> targets = new ArrayList<>(SparseLAPFrameToFrameTracker.this.spots.getNSpots(lFrame1, true));
/* 203 */               for (Iterator<Spot> iterator1 = SparseLAPFrameToFrameTracker.this.spots.iterator(Integer.valueOf(lFrame1), true); iterator1.hasNext();) {
/* 204 */                 targets.add(iterator1.next());
/*     */               }
/* 206 */               if (sources.isEmpty() || targets.isEmpty()) {
/* 207 */                 return null;
/*     */               }
/*     */ 
/*     */ 
/*     */ 
/*     */               
/* 213 */               JaqamanLinkingCostMatrixCreator<Spot, Spot> creator = new JaqamanLinkingCostMatrixCreator(sources, targets, costFunction, costThreshold, alternativeCostFactor, 1.0D);
/* 214 */               JaqamanLinker<Spot, Spot> linker = new JaqamanLinker((CostMatrixCreator)creator);
/* 215 */               if (!linker.checkInput() || !linker.process()) {
/*     */                 
/* 217 */                 SparseLAPFrameToFrameTracker.this.errorMessage = "At frame " + lFrame0 + " to " + lFrame1 + ": " + linker.getErrorMessage();
/* 218 */                 ok.set(false);
/* 219 */                 return null;
/*     */               } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */               
/* 226 */               synchronized (SparseLAPFrameToFrameTracker.this.graph) {
/*     */                 
/* 228 */                 Map<Spot, Double> costs = linker.getAssignmentCosts();
/* 229 */                 Map<Spot, Spot> assignment = linker.getResult();
/* 230 */                 for (Spot source : assignment.keySet()) {
/*     */                   
/* 232 */                   double cost = ((Double)costs.get(source)).doubleValue();
/* 233 */                   Spot target = assignment.get(source);
/* 234 */                   SparseLAPFrameToFrameTracker.this.graph.addVertex(source);
/* 235 */                   SparseLAPFrameToFrameTracker.this.graph.addVertex(target);
/* 236 */                   DefaultWeightedEdge edge = (DefaultWeightedEdge)SparseLAPFrameToFrameTracker.this.graph.addEdge(source, target);
/* 237 */                   SparseLAPFrameToFrameTracker.this.graph.setEdgeWeight(edge, cost);
/*     */                 } 
/*     */               } 
/*     */               
/* 241 */               SparseLAPFrameToFrameTracker.this.logger.setProgress((progress.incrementAndGet() / framePairs.size()));
/* 242 */               return null;
/*     */             }
/*     */           });
/* 245 */       futures.add(future);
/*     */     } 
/*     */     
/* 248 */     this.logger.setStatus("Frame to frame linking...");
/*     */     
/*     */     try {
/* 251 */       for (Future<?> future : futures) {
/* 252 */         future.get();
/*     */       }
/* 254 */       executors.shutdown();
/*     */     }
/* 256 */     catch (InterruptedException|java.util.concurrent.ExecutionException e) {
/*     */       
/* 258 */       ok.set(false);
/* 259 */       this.errorMessage = "[SparseLAPFrameToFrameTracker] " + e.getMessage();
/* 260 */       e.printStackTrace();
/*     */     } 
/* 262 */     this.logger.setProgress(1.0D);
/* 263 */     this.logger.setStatus("");
/*     */     
/* 265 */     long end = System.currentTimeMillis();
/* 266 */     this.processingTime = end - start;
/*     */     
/* 268 */     return ok.get();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected CostFunction<Spot, Spot> getCostFunction(Map<String, Double> featurePenalties) {
/* 280 */     if (null == featurePenalties || featurePenalties.isEmpty()) {
/* 281 */       return (CostFunction<Spot, Spot>)new SquareDistCostFunction();
/*     */     }
/* 283 */     return (CostFunction<Spot, Spot>)new FeaturePenaltyCostFunction(featurePenalties);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLogger(Logger logger) {
/* 289 */     this.logger = logger;
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean checkSettingsValidity(Map<String, Object> settings, StringBuilder str) {
/* 294 */     if (null == settings) {
/*     */       
/* 296 */       str.append("Settings map is null.\n");
/* 297 */       return false;
/*     */     } 
/*     */     
/* 300 */     boolean ok = true;
/*     */     
/* 302 */     ok &= TMUtils.checkParameter(settings, "LINKING_MAX_DISTANCE", Double.class, str);
/* 303 */     ok &= LAPUtils.checkFeatureMap(settings, "LINKING_FEATURE_PENALTIES", str);
/*     */     
/* 305 */     ok &= TMUtils.checkParameter(settings, "ALTERNATIVE_LINKING_COST_FACTOR", Double.class, str);
/*     */ 
/*     */     
/* 308 */     List<String> mandatoryKeys = new ArrayList<>();
/* 309 */     mandatoryKeys.add("LINKING_MAX_DISTANCE");
/* 310 */     mandatoryKeys.add("ALTERNATIVE_LINKING_COST_FACTOR");
/* 311 */     List<String> optionalKeys = new ArrayList<>();
/* 312 */     optionalKeys.add("LINKING_FEATURE_PENALTIES");
/* 313 */     ok &= TMUtils.checkMapKeys(settings, mandatoryKeys, optionalKeys, str);
/*     */     
/* 315 */     return ok;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isCanceled() {
/* 323 */     return this.isCanceled;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void cancel(String reason) {
/* 329 */     this.isCanceled = true;
/* 330 */     this.cancelReason = reason;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getCancelReason() {
/* 336 */     return this.cancelReason;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/tracking/sparselap/SparseLAPFrameToFrameTracker.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */