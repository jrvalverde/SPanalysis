/*    */ package fiji.plugin.trackmate.features;
/*    */ 
/*    */ import fiji.plugin.trackmate.Dimension;
/*    */ import fiji.plugin.trackmate.Model;
/*    */ import fiji.plugin.trackmate.SelectionModel;
/*    */ import fiji.plugin.trackmate.gui.displaysettings.DisplaySettings;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TrackFeatureGrapher
/*    */   extends AbstractFeatureGrapher
/*    */ {
/*    */   private final List<Integer> trackIDs;
/*    */   private final Model model;
/*    */   private final SelectionModel selectionModel;
/*    */   private final DisplaySettings ds;
/*    */   
/*    */   public TrackFeatureGrapher(List<Integer> trackIDs, String xFeature, List<String> yFeatures, Model model, SelectionModel selectionModel, DisplaySettings displaySettings) {
/* 49 */     super(xFeature, yFeatures, (Dimension)model
/*    */ 
/*    */         
/* 52 */         .getFeatureModel().getTrackFeatureDimensions().get(xFeature), model
/* 53 */         .getFeatureModel().getTrackFeatureDimensions(), model
/* 54 */         .getFeatureModel().getTrackFeatureNames(), model
/* 55 */         .getSpaceUnits(), model
/* 56 */         .getTimeUnits());
/* 57 */     this.trackIDs = trackIDs;
/* 58 */     this.model = model;
/* 59 */     this.selectionModel = selectionModel;
/* 60 */     this.ds = displaySettings;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected ModelDataset buildMainDataSet(List<String> targetYFeatures) {
/* 66 */     return new TrackCollectionDataset(this.model, this.selectionModel, this.ds, this.xFeature, targetYFeatures, this.trackIDs);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/features/TrackFeatureGrapher.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */