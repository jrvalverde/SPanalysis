/*     */ package fiji.plugin.trackmate;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.EventObject;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.jgrapht.graph.DefaultWeightedEdge;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ModelChangeEvent
/*     */   extends EventObject
/*     */ {
/*     */   private static final long serialVersionUID = -1L;
/*     */   public static final int FLAG_SPOT_ADDED = 0;
/*     */   public static final int FLAG_SPOT_REMOVED = 1;
/*     */   public static final int FLAG_SPOT_MODIFIED = 2;
/*     */   public static final int FLAG_SPOT_FRAME_CHANGED = 3;
/*     */   public static final int FLAG_EDGE_ADDED = 4;
/*     */   public static final int FLAG_EDGE_REMOVED = 5;
/*     */   public static final int FLAG_EDGE_MODIFIED = 6;
/*  62 */   public static final Map<Integer, String> flagsToString = new HashMap<>(7);
/*     */   static {
/*  64 */     flagsToString.put(Integer.valueOf(0), "Spot added");
/*  65 */     flagsToString.put(Integer.valueOf(3), "Spot frame changed");
/*  66 */     flagsToString.put(Integer.valueOf(2), "Spot modified");
/*  67 */     flagsToString.put(Integer.valueOf(1), "Spot removed");
/*  68 */     flagsToString.put(Integer.valueOf(4), "Edge added");
/*  69 */     flagsToString.put(Integer.valueOf(6), "Edge modified");
/*  70 */     flagsToString.put(Integer.valueOf(5), "Edge removed");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int SPOTS_COMPUTED = 4;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int SPOTS_FILTERED = 5;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int TRACKS_COMPUTED = 6;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int TRACKS_VISIBILITY_CHANGED = 7;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int MODEL_MODIFIED = 8;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int FEATURES_COMPUTED = 9;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 111 */   private final HashSet<Spot> spots = new HashSet<>();
/*     */   
/* 113 */   private final HashSet<DefaultWeightedEdge> edges = new HashSet<>();
/*     */   
/* 115 */   private final HashMap<Spot, Integer> fromFrame = new HashMap<>();
/*     */   
/* 117 */   private final HashMap<Spot, Integer> toFrame = new HashMap<>();
/*     */   
/* 119 */   private final HashMap<Spot, Integer> spotFlags = new HashMap<>();
/*     */   
/* 121 */   private final HashMap<DefaultWeightedEdge, Integer> edgeFlags = new HashMap<>();
/*     */   
/*     */   private final int eventID;
/* 124 */   private Set<Integer> trackUpdated = new HashSet<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ModelChangeEvent(Object source, int eventID) {
/* 135 */     super(source);
/* 136 */     this.eventID = eventID;
/*     */   }
/*     */   
/*     */   public int getEventID() {
/* 140 */     return this.eventID;
/*     */   }
/*     */   
/*     */   public boolean addAllSpots(Collection<Spot> lSpots) {
/* 144 */     return this.spots.addAll(lSpots);
/*     */   }
/*     */   
/*     */   public boolean addSpot(Spot spot) {
/* 148 */     return this.spots.add(spot);
/*     */   }
/*     */   
/*     */   public boolean addAllEdges(Collection<DefaultWeightedEdge> lEdges) {
/* 152 */     return this.edges.addAll(lEdges);
/*     */   }
/*     */   public boolean addEdge(DefaultWeightedEdge edge) {
/* 155 */     return this.edges.add(edge);
/*     */   }
/*     */   
/*     */   public Integer putEdgeFlag(DefaultWeightedEdge edge, Integer flag) {
/* 159 */     return this.edgeFlags.put(edge, flag);
/*     */   }
/*     */   
/*     */   public Integer putSpotFlag(Spot spot, Integer flag) {
/* 163 */     return this.spotFlags.put(spot, flag);
/*     */   }
/*     */   
/*     */   public Integer putFromFrame(Spot spot, Integer lFromFrame) {
/* 167 */     return this.fromFrame.put(spot, lFromFrame);
/*     */   }
/*     */   
/*     */   public Integer putToFrame(Spot spot, Integer lToFrame) {
/* 171 */     return this.toFrame.put(spot, lToFrame);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<Spot> getSpots() {
/* 179 */     return this.spots;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<DefaultWeightedEdge> getEdges() {
/* 187 */     return this.edges;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Integer getSpotFlag(Spot spot) {
/* 201 */     return this.spotFlags.get(spot);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Integer getEdgeFlag(DefaultWeightedEdge edge) {
/* 214 */     return this.edgeFlags.get(edge);
/*     */   }
/*     */   
/*     */   public Integer getToFrame(Spot spot) {
/* 218 */     return this.toFrame.get(spot);
/*     */   }
/*     */   
/*     */   public Integer getFromFrame(Spot spot) {
/* 222 */     return this.fromFrame.get(spot);
/*     */   }
/*     */   
/*     */   public void setSource(Object source) {
/* 226 */     this.source = source;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 231 */     StringBuilder str = new StringBuilder("[ModelChangeEvent]:\n");
/* 232 */     str.append(" - source: " + this.source.getClass() + "_" + this.source.hashCode() + "\n");
/* 233 */     str.append(" - event type: ");
/* 234 */     switch (this.eventID) {
/*     */       case 4:
/* 236 */         str.append("Spots computed\n");
/*     */         break;
/*     */       case 5:
/* 239 */         str.append("Spots filtered\n");
/*     */         break;
/*     */       case 6:
/* 242 */         str.append("Tracks computed\n");
/*     */         break;
/*     */       case 7:
/* 245 */         str.append("Track visibility changed\n");
/*     */         break;
/*     */       case 8:
/* 248 */         str.append("Model modified, with:\n");
/* 249 */         str.append("\t- spots modified: " + ((this.spots != null) ? this.spots.size() : 0) + "\n");
/* 250 */         for (Spot spot : this.spots) {
/* 251 */           str.append("\t\t" + spot + ": " + (String)flagsToString.get(this.spotFlags.get(spot)) + "\n");
/*     */         }
/* 253 */         str.append("\t- edges modified: " + ((this.edges != null) ? this.edges.size() : 0) + "\n");
/* 254 */         for (DefaultWeightedEdge edge : this.edges) {
/* 255 */           str.append("\t\t" + edge + ": " + (String)flagsToString.get(this.edgeFlags.get(edge)) + "\n");
/*     */         }
/* 257 */         str.append("\t- tracks to update: " + this.trackUpdated + "\n"); break;
/*     */     } 
/* 259 */     return str.toString();
/*     */   }
/*     */   
/*     */   public void setTracksUpdated(Set<Integer> tracksToUpdate) {
/* 263 */     this.trackUpdated = tracksToUpdate;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<Integer> getTrackUpdated() {
/* 270 */     return this.trackUpdated;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/ModelChangeEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */