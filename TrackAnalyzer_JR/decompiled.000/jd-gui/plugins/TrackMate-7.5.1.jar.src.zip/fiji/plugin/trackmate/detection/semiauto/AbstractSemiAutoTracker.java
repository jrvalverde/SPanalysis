/*     */ package fiji.plugin.trackmate.detection.semiauto;
/*     */ 
/*     */ import fiji.plugin.trackmate.Logger;
/*     */ import fiji.plugin.trackmate.Model;
/*     */ import fiji.plugin.trackmate.SelectionModel;
/*     */ import fiji.plugin.trackmate.Spot;
/*     */ import fiji.plugin.trackmate.detection.LogDetector;
/*     */ import fiji.plugin.trackmate.detection.SpotDetector;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.Executors;
/*     */ import java.util.concurrent.Future;
/*     */ import net.imglib2.Interval;
/*     */ import net.imglib2.RandomAccessible;
/*     */ import net.imglib2.RealLocalizable;
/*     */ import net.imglib2.algorithm.Algorithm;
/*     */ import net.imglib2.algorithm.MultiThreaded;
/*     */ import net.imglib2.realtransform.AffineTransform3D;
/*     */ import net.imglib2.type.NativeType;
/*     */ import net.imglib2.type.numeric.RealType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractSemiAutoTracker<T extends RealType<T> & NativeType<T>>
/*     */   implements Algorithm, MultiThreaded
/*     */ {
/*     */   protected static final double NEIGHBORHOOD_FACTOR = 2.0D;
/*     */   protected static final String BASE_ERROR_MESSAGE = "[SemiAutoTracker] ";
/*     */   private static final double QUALITY_THRESHOLD = 0.2D;
/*     */   private static final double DISTANCE_TOLERANCE = 1.1D;
/*     */   private final Model model;
/*     */   private final SelectionModel selectionModel;
/*     */   protected String errorMessage;
/*     */   private int numThreads;
/*     */   protected boolean ok;
/*     */   protected final Logger logger;
/* 101 */   protected double distanceTolerance = 1.1D;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 107 */   protected double qualityThreshold = 0.2D;
/*     */ 
/*     */ 
/*     */   
/*     */   private int nFrames;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AbstractSemiAutoTracker(Model model, SelectionModel selectionModel, Logger logger) {
/* 117 */     this.model = model;
/* 118 */     this.selectionModel = selectionModel;
/* 119 */     this.logger = logger;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setParameters(double qualityThreshold, double distanceTolerance, int nFrames) {
/* 141 */     this.qualityThreshold = qualityThreshold;
/* 142 */     this.distanceTolerance = distanceTolerance;
/* 143 */     this.nFrames = nFrames;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean process() {
/* 149 */     Set<Spot> spots = new HashSet<>(this.selectionModel.getSpotSelection());
/* 150 */     if (spots.isEmpty()) {
/*     */       
/* 152 */       this.errorMessage = "[SemiAutoTracker] No spots in selection.\n";
/* 153 */       return false;
/*     */     } 
/* 155 */     this.selectionModel.clearSelection();
/*     */     
/* 157 */     this.ok = true;
/* 158 */     int nThreads = Math.min(this.numThreads, spots.size());
/* 159 */     ExecutorService executors = Executors.newFixedThreadPool(nThreads);
/* 160 */     List<Future<?>> futures = new ArrayList<>(spots.size());
/* 161 */     for (Spot spot : spots) {
/*     */       
/* 163 */       Future<?> future = executors.submit(() -> processSpot(spot));
/* 164 */       futures.add(future);
/*     */     } 
/*     */     
/*     */     try {
/* 168 */       for (Future<?> future : futures) {
/* 169 */         future.get();
/*     */       }
/* 171 */       executors.shutdown();
/*     */     }
/* 173 */     catch (InterruptedException|java.util.concurrent.ExecutionException e) {
/*     */       
/* 175 */       this.ok = false;
/* 176 */       this.errorMessage = e.getMessage();
/* 177 */       e.printStackTrace();
/*     */     } 
/* 179 */     return this.ok;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void processSpot(Spot initialSpot) {
/* 202 */     Spot spot = initialSpot;
/* 203 */     int nSpotProcessed = 0;
/*     */     
/* 205 */     while (this.nFrames < 1 || nSpotProcessed < this.nFrames) {
/*     */ 
/*     */       
/* 208 */       nSpotProcessed++;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 215 */       int frame = spot.getFeature("FRAME").intValue() + 1;
/* 216 */       double radius = spot.getFeature("RADIUS").doubleValue();
/* 217 */       double quality = spot.getFeature("QUALITY").doubleValue();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 223 */       SearchRegion<T> sn = getNeighborhood(spot, frame);
/* 224 */       if (null == sn) {
/*     */         return;
/*     */       }
/* 227 */       RandomAccessible<T> source = sn.source;
/* 228 */       Interval interval = sn.interval;
/* 229 */       AffineTransform3D transform = sn.transform;
/* 230 */       double[] calibration = sn.calibration;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 236 */       SpotDetector<T> detector = createDetector(source, interval, calibration, radius, quality * this.qualityThreshold);
/*     */       
/* 238 */       if (!detector.checkInput() || !detector.process()) {
/*     */         
/* 240 */         this.ok = false;
/* 241 */         this.errorMessage = detector.getErrorMessage();
/*     */ 
/*     */ 
/*     */         
/*     */         return;
/*     */       } 
/*     */ 
/*     */       
/* 249 */       List<Spot> detectedSpots = (List<Spot>)detector.getResult();
/* 250 */       if (detectedSpots.isEmpty()) {
/*     */         
/* 252 */         this.logger.log("Spot: " + initialSpot + ": No suitable spot found.\n");
/*     */ 
/*     */ 
/*     */         
/*     */         return;
/*     */       } 
/*     */ 
/*     */       
/* 260 */       String[] features = { "POSITION_X", "POSITION_Y", "POSITION_Z" };
/* 261 */       for (Spot ds : detectedSpots) {
/*     */         
/* 263 */         double[] coords = new double[3];
/* 264 */         ds.localize(coords);
/* 265 */         double[] arrayOfDouble1 = new double[3];
/* 266 */         transform.apply(coords, arrayOfDouble1);
/* 267 */         for (int i = 0; i < arrayOfDouble1.length; i++)
/*     */         {
/* 269 */           ds.putFeature(features[i], Double.valueOf(arrayOfDouble1[i]));
/*     */         }
/*     */       } 
/*     */ 
/*     */       
/* 274 */       Collections.sort(detectedSpots, Spot.featureComparator("QUALITY"));
/* 275 */       Collections.reverse(detectedSpots);
/*     */       
/* 277 */       boolean found = false;
/* 278 */       Spot target = null;
/* 279 */       for (Iterator<Spot> iterator = detectedSpots.iterator(); iterator.hasNext(); ) {
/*     */         
/* 281 */         Spot candidate = iterator.next();
/* 282 */         if (candidate.squareDistanceTo((RealLocalizable)spot) < this.distanceTolerance * this.distanceTolerance * radius * radius) {
/*     */           
/* 284 */           found = true;
/* 285 */           target = candidate;
/*     */           
/*     */           break;
/*     */         } 
/*     */       } 
/* 290 */       if (!found || target == null) {
/*     */         
/* 292 */         this.logger.log("Spot: " + initialSpot + ": Suitable spot found, but outside the tolerance radius.\n");
/*     */ 
/*     */ 
/*     */         
/*     */         return;
/*     */       } 
/*     */ 
/*     */       
/* 300 */       target.putFeature("POSITION_T", Double.valueOf(frame));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 306 */       exposeSpot(target, spot);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 313 */       target.putFeature("RADIUS", Double.valueOf(radius));
/*     */       
/* 315 */       this.model.beginUpdate();
/*     */       
/*     */       try {
/* 318 */         this.model.addSpotTo(target, Integer.valueOf(frame));
/* 319 */         this.model.addEdge(spot, target, spot.squareDistanceTo((RealLocalizable)target));
/*     */       }
/*     */       finally {
/*     */         
/* 323 */         this.model.endUpdate();
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 330 */       spot = target;
/*     */     } 
/*     */     
/* 333 */     if (nSpotProcessed > 0)
/*     */     {
/* 335 */       this.logger.log("Finished semi-auto tracking after processing " + nSpotProcessed + " spots from " + initialSpot + " to " + spot + ".\n");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected SpotDetector<T> createDetector(RandomAccessible<T> img, Interval interval, double[] calibration, double radius, double quality) {
/* 394 */     LogDetector<T> detector = new LogDetector(img, interval, calibration, radius, quality, true, false);
/* 395 */     detector.setNumThreads(1);
/* 396 */     return (SpotDetector<T>)detector;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean checkInput() {
/* 402 */     if (null == this.model) {
/*     */       
/* 404 */       this.errorMessage = "[SemiAutoTracker] model is null.\n";
/* 405 */       return false;
/*     */     } 
/* 407 */     if (null == this.selectionModel) {
/*     */       
/* 409 */       this.errorMessage = "[SemiAutoTracker] selectionModel is null.\n";
/* 410 */       return false;
/*     */     } 
/* 412 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getErrorMessage() {
/* 418 */     return this.errorMessage;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setNumThreads() {
/* 424 */     this.numThreads = Runtime.getRuntime().availableProcessors();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setNumThreads(int numThreads) {
/* 430 */     this.numThreads = numThreads;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getNumThreads() {
/* 436 */     return this.numThreads;
/*     */   }
/*     */   
/*     */   protected abstract void exposeSpot(Spot paramSpot1, Spot paramSpot2);
/*     */   
/*     */   protected abstract SearchRegion<T> getNeighborhood(Spot paramSpot, int paramInt);
/*     */   
/*     */   public static class SearchRegion<R> {
/*     */     public RandomAccessible<R> source;
/*     */     public double[] calibration;
/*     */     public Interval interval;
/*     */     public AffineTransform3D transform;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/detection/semiauto/AbstractSemiAutoTracker.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */