/*    */ package fiji.plugin.trackmate.features.spot;
/*    */ 
/*    */ import fiji.plugin.trackmate.Spot;
/*    */ import net.imglib2.type.NativeType;
/*    */ import net.imglib2.type.numeric.RealType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface SpotAnalyzer<T>
/*    */ {
/*    */   void process(Iterable<Spot> paramIterable);
/*    */   
/*    */   static <T extends RealType<T> & NativeType<T>> SpotAnalyzer<T> dummyAnalyzer() {
/* 53 */     return (SpotAnalyzer)DUMMY_ANALYZER;
/*    */   }
/*    */   
/* 56 */   public static final SpotAnalyzer<?> DUMMY_ANALYZER = new DummySpotAnalyzer();
/*    */   
/*    */   public static class DummySpotAnalyzer<T extends RealType<T> & NativeType<T>> implements SpotAnalyzer<T> {
/*    */     public void process(Iterable<Spot> spots) {}
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/features/spot/SpotAnalyzer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */