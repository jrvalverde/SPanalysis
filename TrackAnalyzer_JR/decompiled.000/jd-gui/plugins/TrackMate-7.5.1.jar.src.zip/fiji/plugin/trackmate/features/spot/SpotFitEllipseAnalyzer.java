/*     */ package fiji.plugin.trackmate.features.spot;
/*     */ 
/*     */ import Jama.EigenvalueDecomposition;
/*     */ import Jama.Matrix;
/*     */ import Jama.SingularValueDecomposition;
/*     */ import fiji.plugin.trackmate.Spot;
/*     */ import fiji.plugin.trackmate.SpotRoi;
/*     */ import net.imglib2.type.numeric.RealType;
/*     */ import net.imglib2.util.Util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SpotFitEllipseAnalyzer<T extends RealType<T>>
/*     */   extends AbstractSpotFeatureAnalyzer<T>
/*     */ {
/*     */   private final boolean is2D;
/*     */   private static final double MACHEPS = 2.2204E-16D;
/*     */   
/*     */   public SpotFitEllipseAnalyzer(boolean is2D) {
/*  39 */     this.is2D = is2D;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void process(Spot spot) {
/*     */     double aspectRatio, major, minor, theta, x0, y0;
/*  52 */     if (this.is2D) {
/*     */       
/*  54 */       SpotRoi roi = spot.getRoi();
/*  55 */       if (roi != null)
/*     */       {
/*  57 */         double[] Q = fitEllipse(roi.x, roi.y);
/*  58 */         double[] A = quadraticToCartesian(Q);
/*  59 */         x0 = A[0];
/*  60 */         y0 = A[1];
/*  61 */         major = A[2];
/*  62 */         minor = A[3];
/*  63 */         theta = A[4];
/*  64 */         aspectRatio = major / minor;
/*     */       }
/*     */       else
/*     */       {
/*  68 */         double radius = spot.getFeature("RADIUS").doubleValue();
/*  69 */         x0 = 0.0D;
/*  70 */         y0 = 0.0D;
/*  71 */         major = radius;
/*  72 */         minor = radius;
/*  73 */         theta = 0.0D;
/*  74 */         aspectRatio = 1.0D;
/*     */       }
/*     */     
/*     */     } else {
/*     */       
/*  79 */       x0 = Double.NaN;
/*  80 */       y0 = Double.NaN;
/*  81 */       major = Double.NaN;
/*  82 */       minor = Double.NaN;
/*  83 */       theta = Double.NaN;
/*  84 */       aspectRatio = Double.NaN;
/*     */     } 
/*  86 */     spot.putFeature("ELLIPSE_X0", Double.valueOf(x0));
/*  87 */     spot.putFeature("ELLIPSE_Y0", Double.valueOf(y0));
/*  88 */     spot.putFeature("ELLIPSE_MAJOR", Double.valueOf(major));
/*  89 */     spot.putFeature("ELLIPSE_MINOR", Double.valueOf(minor));
/*  90 */     spot.putFeature("ELLIPSE_THETA", Double.valueOf(theta));
/*  91 */     spot.putFeature("ELLIPSE_ASPECTRATIO", Double.valueOf(aspectRatio));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static double[] fitEllipse(double[] x, double[] y) {
/* 117 */     int nPoints = x.length;
/* 118 */     double[] centroid = getCentroid(x, y);
/* 119 */     double xC = centroid[0];
/* 120 */     double yC = centroid[1];
/* 121 */     double[][] d1 = new double[nPoints][3];
/* 122 */     for (int i = 0; i < nPoints; i++) {
/*     */       
/* 124 */       double xixC = x[i] - xC;
/* 125 */       double yiyC = y[i] - yC;
/* 126 */       d1[i][0] = xixC * xixC;
/* 127 */       d1[i][1] = xixC * yiyC;
/* 128 */       d1[i][2] = yiyC * yiyC;
/*     */     } 
/* 130 */     Matrix D1 = new Matrix(d1);
/* 131 */     double[][] d2 = new double[nPoints][3];
/* 132 */     for (int j = 0; j < nPoints; j++) {
/*     */       
/* 134 */       d2[j][0] = x[j] - xC;
/* 135 */       d2[j][1] = y[j] - yC;
/* 136 */       d2[j][2] = 1.0D;
/*     */     } 
/* 138 */     Matrix D2 = new Matrix(d2);
/* 139 */     Matrix S1 = D1.transpose().times(D1);
/* 140 */     Matrix S2 = D1.transpose().times(D2);
/* 141 */     Matrix S3 = D2.transpose().times(D2);
/* 142 */     Matrix T = pinv(S3).times(-1.0D).times(S2.transpose());
/* 143 */     Matrix M = S1.plus(S2.times(T));
/*     */     
/* 145 */     double[][] m = M.getArray();
/* 146 */     double[][] n = { { m[2][0] / 2.0D, m[2][1] / 2.0D, m[2][2] / 2.0D }, { -m[1][0], -m[1][1], -m[1][2] }, { m[0][0] / 2.0D, m[0][1] / 2.0D, m[0][2] / 2.0D } };
/*     */ 
/*     */     
/* 149 */     Matrix N = new Matrix(n);
/* 150 */     EigenvalueDecomposition E = N.eig();
/* 151 */     Matrix eVec = E.getV();
/*     */     
/* 153 */     Matrix R1 = eVec.getMatrix(0, 0, 0, 2);
/* 154 */     Matrix R2 = eVec.getMatrix(1, 1, 0, 2);
/* 155 */     Matrix R3 = eVec.getMatrix(2, 2, 0, 2);
/*     */     
/* 157 */     Matrix cond = R1.times(4.0D).arrayTimes(R3).minus(R2.arrayTimes(R2));
/*     */     
/* 159 */     int f = 0;
/* 160 */     for (int k = 0; k < 3; k++) {
/*     */       
/* 162 */       if (cond.get(0, k) > 0.0D) {
/*     */         
/* 164 */         f = k;
/*     */         break;
/*     */       } 
/*     */     } 
/* 168 */     Matrix A1 = eVec.getMatrix(0, 2, f, f);
/*     */     
/* 170 */     Matrix A = new Matrix(6, 1);
/* 171 */     A.setMatrix(0, 2, 0, 0, A1);
/* 172 */     A.setMatrix(3, 5, 0, 0, T.times(A1));
/*     */     
/* 174 */     double[] a = A.getColumnPackedCopy();
/* 175 */     double a4 = a[3] - 2.0D * a[0] * xC - a[1] * yC;
/* 176 */     double a5 = a[4] - 2.0D * a[2] * yC - a[1] * xC;
/* 177 */     double a6 = a[5] + a[0] * xC * xC + a[2] * yC * yC + a[1] * xC * yC - a[3] * xC - a[4] * yC;
/* 178 */     A.set(3, 0, a4);
/* 179 */     A.set(4, 0, a5);
/* 180 */     A.set(5, 0, a6);
/* 181 */     A = A.times(1.0D / A.normF());
/* 182 */     return A.getColumnPackedCopy();
/*     */   }
/*     */ 
/*     */   
/*     */   private static double[] getCentroid(double[] x, double[] y) {
/* 187 */     return new double[] { Util.average(x), Util.average(y) };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final double[] quadraticToCartesian(double[] Q) {
/* 201 */     double theta, A = Q[0];
/* 202 */     double B = Q[1];
/* 203 */     double C = Q[2];
/* 204 */     double D = Q[3];
/* 205 */     double E = Q[4];
/* 206 */     double F = Q[5];
/*     */     
/* 208 */     double term1 = 2.0D * (A * E * E + C * D * D - B * D * E + (B * B - 4.0D * A * C) * F);
/*     */ 
/*     */ 
/*     */     
/* 212 */     double term2 = A + C;
/* 213 */     double term3 = Math.sqrt((A - C) * (A - C) + B * B);
/* 214 */     double term4 = B * B - 4.0D * A * C;
/*     */     
/* 216 */     double a = -Math.sqrt(term1 * (term2 + term3)) / term4;
/* 217 */     double b = -Math.sqrt(term1 * (term2 - term3)) / term4;
/*     */     
/* 219 */     double x0 = (2.0D * C * D - B * E) / term4;
/* 220 */     double y0 = (2.0D * A * E - B * D) / term4;
/*     */ 
/*     */     
/* 223 */     if (B != 0.0D) {
/* 224 */       theta = Math.atan(1.0D / B * (C - A - term3));
/* 225 */     } else if (A < 0.0D) {
/* 226 */       theta = 0.0D;
/*     */     } else {
/* 228 */       theta = 1.5707963267948966D;
/*     */     } 
/* 230 */     if (b > a) {
/*     */       
/* 232 */       double btemp = b;
/* 233 */       b = a;
/* 234 */       a = btemp;
/* 235 */       theta += 1.5707963267948966D;
/* 236 */       if (theta > Math.PI) {
/* 237 */         theta -= Math.PI;
/*     */       }
/*     */     } 
/* 240 */     return new double[] { x0, y0, a, b, theta };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Matrix pinv(Matrix x) {
/* 250 */     int rows = x.getRowDimension();
/* 251 */     int cols = x.getColumnDimension();
/* 252 */     if (rows < cols) {
/*     */       
/* 254 */       Matrix result = pinv(x.transpose());
/* 255 */       if (result != null)
/* 256 */         result = result.transpose(); 
/* 257 */       return result;
/*     */     } 
/* 259 */     SingularValueDecomposition svdX = new SingularValueDecomposition(x);
/* 260 */     if (svdX.rank() < 1)
/* 261 */       return null; 
/* 262 */     double[] singularValues = svdX.getSingularValues();
/* 263 */     double tol = Math.max(rows, cols) * singularValues[0] * 2.2204E-16D;
/* 264 */     double[] singularValueReciprocals = new double[singularValues.length];
/* 265 */     for (int i = 0; i < singularValues.length; i++) {
/* 266 */       if (Math.abs(singularValues[i]) >= tol)
/* 267 */         singularValueReciprocals[i] = 1.0D / singularValues[i]; 
/* 268 */     }  double[][] u = svdX.getU().getArray();
/* 269 */     double[][] v = svdX.getV().getArray();
/* 270 */     int min = Math.min(cols, (u[0]).length);
/* 271 */     double[][] inverse = new double[cols][rows];
/* 272 */     for (int j = 0; j < cols; j++) {
/* 273 */       for (int k = 0; k < u.length; k++)
/* 274 */       { for (int m = 0; m < min; m++)
/* 275 */           inverse[j][k] = inverse[j][k] + v[j][m] * singularValueReciprocals[m] * u[k][m];  } 
/* 276 */     }  return new Matrix(inverse);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/features/spot/SpotFitEllipseAnalyzer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */