/*     */ package fiji.plugin.trackmate.gui.wizard.descriptors;
/*     */ 
/*     */ import fiji.plugin.trackmate.TrackMate;
/*     */ import fiji.plugin.trackmate.detection.SpotDetectorFactoryBase;
/*     */ import fiji.plugin.trackmate.gui.components.ModuleChooserPanel;
/*     */ import fiji.plugin.trackmate.gui.wizard.WizardPanelDescriptor;
/*     */ import fiji.plugin.trackmate.io.SettingsPersistence;
/*     */ import fiji.plugin.trackmate.providers.AbstractProvider;
/*     */ import fiji.plugin.trackmate.providers.DetectorProvider;
/*     */ import java.awt.Component;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ChooseDetectorDescriptor
/*     */   extends WizardPanelDescriptor
/*     */ {
/*     */   private static final String KEY = "ChooseDetector";
/*     */   private final TrackMate trackmate;
/*     */   private final DetectorProvider detectorProvider;
/*     */   
/*     */   public ChooseDetectorDescriptor(DetectorProvider detectorProvider, TrackMate trackmate) {
/*  45 */     super("ChooseDetector");
/*  46 */     this.trackmate = trackmate;
/*  47 */     this.detectorProvider = detectorProvider;
/*     */     
/*  49 */     String selectedDetector = "LOG_DETECTOR";
/*  50 */     if (null != (trackmate.getSettings()).detectorFactory) {
/*  51 */       selectedDetector = (trackmate.getSettings()).detectorFactory.getKey();
/*     */     }
/*  53 */     this.targetPanel = (Component)new ModuleChooserPanel((AbstractProvider)detectorProvider, "detector", selectedDetector);
/*     */   }
/*     */ 
/*     */   
/*     */   private void setCurrentChoiceFromPlugin() {
/*  58 */     String key = "LOG_DETECTOR";
/*  59 */     if (null != (this.trackmate.getSettings()).detectorFactory) {
/*  60 */       key = (this.trackmate.getSettings()).detectorFactory.getKey();
/*     */     }
/*     */     
/*  63 */     ModuleChooserPanel<SpotDetectorFactoryBase> component = (ModuleChooserPanel<SpotDetectorFactoryBase>)this.targetPanel;
/*  64 */     component.setSelectedModuleKey(key);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void displayingPanel() {
/*  70 */     setCurrentChoiceFromPlugin();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void aboutToHidePanel() {
/*  78 */     ModuleChooserPanel<SpotDetectorFactoryBase> component = (ModuleChooserPanel<SpotDetectorFactoryBase>)this.targetPanel;
/*  79 */     String detectorKey = component.getSelectedModuleKey();
/*     */ 
/*     */     
/*  82 */     SpotDetectorFactoryBase<?> factory = (SpotDetectorFactoryBase)this.detectorProvider.getFactory(detectorKey);
/*     */     
/*  84 */     if (null == factory) {
/*     */       
/*  86 */       this.trackmate.getModel().getLogger().error("[ChooseDetectorDescriptor] Cannot find detector named " + detectorKey + " in current TrackMate modules.");
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/*  91 */     (this.trackmate.getSettings()).detectorFactory = factory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  97 */     Map<String, Object> currentSettings = (this.trackmate.getSettings()).detectorSettings;
/*  98 */     if (!factory.checkSettings(currentSettings)) {
/*     */       
/* 100 */       Map<String, Object> defaultSettings = factory.getDefaultSettings();
/* 101 */       (this.trackmate.getSettings()).detectorSettings = defaultSettings;
/*     */     } 
/*     */ 
/*     */     
/* 105 */     SettingsPersistence.saveLastUsedSettings(this.trackmate.getSettings(), this.trackmate.getModel().getLogger());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Runnable getBackwardRunnable() {
/* 111 */     return () -> this.trackmate.getModel().clearSpots(true);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/gui/wizard/descriptors/ChooseDetectorDescriptor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */