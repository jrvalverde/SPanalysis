/*     */ package fiji.plugin.trackmate.tracking.kalman;
/*     */ 
/*     */ import fiji.plugin.trackmate.Logger;
/*     */ import fiji.plugin.trackmate.Spot;
/*     */ import fiji.plugin.trackmate.SpotCollection;
/*     */ import fiji.plugin.trackmate.tracking.SpotTracker;
/*     */ import fiji.plugin.trackmate.tracking.sparselap.costfunction.CostFunction;
/*     */ import fiji.plugin.trackmate.tracking.sparselap.costfunction.SquareDistCostFunction;
/*     */ import fiji.plugin.trackmate.tracking.sparselap.costmatrix.CostMatrixCreator;
/*     */ import fiji.plugin.trackmate.tracking.sparselap.costmatrix.JaqamanLinkingCostMatrixCreator;
/*     */ import fiji.plugin.trackmate.tracking.sparselap.linker.JaqamanLinker;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.NavigableSet;
/*     */ import net.imglib2.RealLocalizable;
/*     */ import net.imglib2.RealPoint;
/*     */ import net.imglib2.algorithm.Benchmark;
/*     */ import org.jgrapht.graph.DefaultWeightedEdge;
/*     */ import org.jgrapht.graph.SimpleWeightedGraph;
/*     */ import org.scijava.Cancelable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class KalmanTracker
/*     */   implements SpotTracker, Benchmark, Cancelable
/*     */ {
/*     */   private static final double ALTERNATIVE_COST_FACTOR = 1.05D;
/*     */   private static final double PERCENTILE = 1.0D;
/*     */   private static final String BASE_ERROR_MSG = "[KalmanTracker] ";
/*     */   private SimpleWeightedGraph<Spot, DefaultWeightedEdge> graph;
/*     */   private String errorMessage;
/*  61 */   private Logger logger = Logger.VOID_LOGGER;
/*     */ 
/*     */ 
/*     */   
/*     */   private final SpotCollection spots;
/*     */ 
/*     */   
/*     */   private final double maxSearchRadius;
/*     */ 
/*     */   
/*     */   private final int maxFrameGap;
/*     */ 
/*     */   
/*     */   private final double initialSearchRadius;
/*     */ 
/*     */   
/*     */   private boolean savePredictions = false;
/*     */ 
/*     */   
/*     */   private SpotCollection predictionsCollection;
/*     */ 
/*     */   
/*     */   private long processingTime;
/*     */ 
/*     */   
/*     */   private boolean isCanceled;
/*     */ 
/*     */   
/*     */   private String cancelReason;
/*     */ 
/*     */ 
/*     */   
/*     */   public KalmanTracker(SpotCollection spots, double maxSearchRadius, int maxFrameGap, double initialSearchRadius) {
/*  94 */     this.spots = spots;
/*  95 */     this.maxSearchRadius = maxSearchRadius;
/*  96 */     this.maxFrameGap = maxFrameGap;
/*  97 */     this.initialSearchRadius = initialSearchRadius;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SimpleWeightedGraph<Spot, DefaultWeightedEdge> getResult() {
/* 107 */     return this.graph;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean checkInput() {
/* 113 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean process() {
/* 119 */     long start = System.currentTimeMillis();
/*     */     
/* 121 */     this.isCanceled = false;
/* 122 */     this.cancelReason = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 128 */     this.graph = new SimpleWeightedGraph(DefaultWeightedEdge.class);
/* 129 */     this.predictionsCollection = new SpotCollection();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 136 */     double maxCost = this.maxSearchRadius * this.maxSearchRadius;
/*     */     
/* 138 */     SquareDistCostFunction squareDistCostFunction = new SquareDistCostFunction();
/*     */     
/* 140 */     double maxInitialCost = this.initialSearchRadius * this.initialSearchRadius;
/*     */ 
/*     */     
/* 143 */     NavigableSet<Integer> keySet = this.spots.keySet();
/* 144 */     Iterator<Integer> frameIterator = keySet.iterator();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 152 */     Collection<Spot> previousOrphanSpots = new ArrayList<>();
/* 153 */     if (!frameIterator.hasNext()) {
/* 154 */       return true;
/*     */     }
/* 156 */     int firstFrame = ((Integer)frameIterator.next()).intValue();
/*     */     
/*     */     while (true) {
/* 159 */       previousOrphanSpots = generateSpotList(this.spots, firstFrame);
/* 160 */       if (!frameIterator.hasNext())
/* 161 */         return true; 
/* 162 */       if (!previousOrphanSpots.isEmpty()) {
/*     */         break;
/*     */       }
/* 165 */       firstFrame = ((Integer)frameIterator.next()).intValue();
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 172 */     Collection<Spot> orphanSpots = new ArrayList<>();
/* 173 */     int secondFrame = ((Integer)frameIterator.next()).intValue();
/*     */     
/*     */     while (true) {
/* 176 */       orphanSpots = generateSpotList(this.spots, secondFrame);
/* 177 */       if (!frameIterator.hasNext())
/* 178 */         return true; 
/* 179 */       if (!orphanSpots.isEmpty()) {
/*     */         break;
/*     */       }
/* 182 */       secondFrame = ((Integer)frameIterator.next()).intValue();
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 193 */     double positionProcessStd = this.maxSearchRadius / 3.0D;
/* 194 */     double velocityProcessStd = this.maxSearchRadius / 3.0D;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 200 */     double meanSpotRadius = 0.0D;
/* 201 */     for (Spot spot : orphanSpots) {
/* 202 */       meanSpotRadius += spot.getFeature("RADIUS").doubleValue();
/*     */     }
/* 204 */     meanSpotRadius /= orphanSpots.size();
/* 205 */     double positionMeasurementStd = meanSpotRadius / 10.0D;
/*     */ 
/*     */     
/* 208 */     Map<CVMKalmanFilter, Spot> kalmanFiltersMap = new HashMap<>(orphanSpots.size());
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 213 */     int p = 1;
/* 214 */     for (int frame = secondFrame; frame <= ((Integer)keySet.last()).intValue(); frame++) {
/*     */       
/* 216 */       if (isCanceled()) {
/* 217 */         return true;
/*     */       }
/* 219 */       p++;
/*     */ 
/*     */       
/* 222 */       List<Spot> measurements = generateSpotList(this.spots, frame);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 228 */       Map<ComparableRealPoint, CVMKalmanFilter> predictionMap = new HashMap<>(kalmanFiltersMap.size());
/* 229 */       for (CVMKalmanFilter kf : kalmanFiltersMap.keySet()) {
/*     */         
/* 231 */         double[] X = kf.predict();
/* 232 */         ComparableRealPoint point = new ComparableRealPoint(X);
/* 233 */         predictionMap.put(new ComparableRealPoint(X), kf);
/*     */         
/* 235 */         if (this.savePredictions) {
/*     */           
/* 237 */           Spot pred = toSpot(point);
/* 238 */           Spot s = kalmanFiltersMap.get(kf);
/* 239 */           pred.setName("Pred_" + s.getName());
/* 240 */           pred.putFeature("RADIUS", s.getFeature("RADIUS"));
/* 241 */           this.predictionsCollection.add(pred, Integer.valueOf(frame));
/*     */         } 
/*     */       } 
/* 244 */       List<ComparableRealPoint> predictions = new ArrayList<>(predictionMap.keySet());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 250 */       Collection<CVMKalmanFilter> childlessKFs = new HashSet<>(kalmanFiltersMap.keySet());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 257 */       orphanSpots = new HashSet<>(measurements);
/* 258 */       if (!predictions.isEmpty() && !measurements.isEmpty()) {
/*     */ 
/*     */ 
/*     */         
/* 262 */         JaqamanLinkingCostMatrixCreator<ComparableRealPoint, Spot> crm = new JaqamanLinkingCostMatrixCreator(predictions, measurements, CF, maxCost, 1.05D, 1.0D);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 269 */         JaqamanLinker<ComparableRealPoint, Spot> linker = new JaqamanLinker((CostMatrixCreator)crm);
/* 270 */         if (!linker.checkInput() || !linker.process()) {
/*     */           
/* 272 */           this.errorMessage = "[KalmanTracker] Error linking candidates in frame " + frame + ": " + linker.getErrorMessage();
/* 273 */           return false;
/*     */         } 
/* 275 */         Map<ComparableRealPoint, Spot> agnts = linker.getResult();
/* 276 */         Map<ComparableRealPoint, Double> costs = linker.getAssignmentCosts();
/*     */ 
/*     */         
/* 279 */         for (ComparableRealPoint cm : agnts.keySet()) {
/*     */           
/* 281 */           CVMKalmanFilter kf = predictionMap.get(cm);
/*     */ 
/*     */           
/* 284 */           Spot source = kalmanFiltersMap.get(kf);
/* 285 */           Spot target = agnts.get(cm);
/*     */           
/* 287 */           this.graph.addVertex(source);
/* 288 */           this.graph.addVertex(target);
/* 289 */           DefaultWeightedEdge edge = (DefaultWeightedEdge)this.graph.addEdge(source, target);
/* 290 */           double cost = ((Double)costs.get(cm)).doubleValue();
/* 291 */           this.graph.setEdgeWeight(edge, cost);
/*     */ 
/*     */           
/* 294 */           kf.update(toMeasurement(target));
/*     */ 
/*     */           
/* 297 */           kalmanFiltersMap.put(kf, target);
/*     */ 
/*     */           
/* 300 */           orphanSpots.remove(target);
/*     */ 
/*     */           
/* 303 */           childlessKFs.remove(kf);
/*     */         } 
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 313 */       if (!previousOrphanSpots.isEmpty() && !orphanSpots.isEmpty()) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 323 */         JaqamanLinkingCostMatrixCreator<Spot, Spot> ic = new JaqamanLinkingCostMatrixCreator(previousOrphanSpots, orphanSpots, (CostFunction)squareDistCostFunction, maxInitialCost, 1.05D, 1.0D);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 330 */         JaqamanLinker<Spot, Spot> newLinker = new JaqamanLinker((CostMatrixCreator)ic);
/* 331 */         if (!newLinker.checkInput() || !newLinker.process()) {
/*     */           
/* 333 */           this.errorMessage = "[KalmanTracker] Error linking spots from frame " + (frame - 1) + " to frame " + frame + ": " + newLinker.getErrorMessage();
/* 334 */           return false;
/*     */         } 
/* 336 */         Map<Spot, Spot> newAssignments = newLinker.getResult();
/* 337 */         Map<Spot, Double> assignmentCosts = newLinker.getAssignmentCosts();
/*     */ 
/*     */         
/* 340 */         for (Spot source : newAssignments.keySet()) {
/*     */           
/* 342 */           Spot target = newAssignments.get(source);
/*     */ 
/*     */           
/* 345 */           orphanSpots.remove(target);
/*     */ 
/*     */           
/* 348 */           double[] XP = estimateInitialState(source, target);
/* 349 */           CVMKalmanFilter kt = new CVMKalmanFilter(XP, 2.2250738585072014E-308D, positionProcessStd, velocityProcessStd, positionMeasurementStd);
/*     */ 
/*     */ 
/*     */           
/* 353 */           kalmanFiltersMap.put(kt, target);
/*     */ 
/*     */           
/* 356 */           this.graph.addVertex(source);
/* 357 */           this.graph.addVertex(target);
/* 358 */           DefaultWeightedEdge edge = (DefaultWeightedEdge)this.graph.addEdge(source, target);
/* 359 */           double cost = ((Double)assignmentCosts.get(source)).doubleValue();
/* 360 */           this.graph.setEdgeWeight(edge, cost);
/*     */         } 
/*     */       } 
/* 363 */       previousOrphanSpots = orphanSpots;
/*     */ 
/*     */       
/* 366 */       for (CVMKalmanFilter kf : childlessKFs) {
/*     */ 
/*     */         
/* 369 */         kf.update(null);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 375 */         if (kf.getNOcclusion() > this.maxFrameGap) {
/* 376 */           kalmanFiltersMap.remove(kf);
/*     */         }
/*     */       } 
/* 379 */       double progress = p / keySet.size();
/* 380 */       this.logger.setProgress(progress);
/*     */     } 
/*     */     
/* 383 */     if (this.savePredictions) {
/* 384 */       this.predictionsCollection.setVisible(true);
/*     */     }
/* 386 */     long end = System.currentTimeMillis();
/* 387 */     this.processingTime = end - start;
/*     */     
/* 389 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getErrorMessage() {
/* 395 */     return this.errorMessage;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SpotCollection getPredictions() {
/* 406 */     return this.predictionsCollection;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSavePredictions(boolean doSave) {
/* 418 */     this.savePredictions = doSave;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setNumThreads() {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void setNumThreads(int numThreads) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public int getNumThreads() {
/* 432 */     return 1;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public long getProcessingTime() {
/* 438 */     return this.processingTime;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLogger(Logger logger) {
/* 444 */     this.logger = logger;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final double[] toMeasurement(Spot spot) {
/* 452 */     double[] d = { spot.getDoublePosition(0), spot.getDoublePosition(1), spot.getDoublePosition(2) };
/*     */     
/* 454 */     return d;
/*     */   }
/*     */ 
/*     */   
/*     */   private static final Spot toSpot(ComparableRealPoint X) {
/* 459 */     Spot spot = new Spot((RealLocalizable)X, 2.0D, -1.0D);
/* 460 */     return spot;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final double[] estimateInitialState(Spot first, Spot second) {
/* 471 */     double[] xp = { second.getDoublePosition(0), second.getDoublePosition(1), second.getDoublePosition(2), second.diffTo(first, "POSITION_X"), second.diffTo(first, "POSITION_Y"), second.diffTo(first, "POSITION_Z") };
/*     */     
/* 473 */     return xp;
/*     */   }
/*     */ 
/*     */   
/*     */   private static final List<Spot> generateSpotList(SpotCollection spots, int frame) {
/* 478 */     List<Spot> list = new ArrayList<>(spots.getNSpots(frame, true));
/* 479 */     for (Iterator<Spot> iterator = spots.iterator(Integer.valueOf(frame), true); iterator.hasNext();) {
/* 480 */       list.add(iterator.next());
/*     */     }
/* 482 */     return list;
/*     */   }
/*     */   
/*     */   private static final class ComparableRealPoint
/*     */     extends RealPoint
/*     */     implements Comparable<ComparableRealPoint>
/*     */   {
/*     */     public ComparableRealPoint(double[] A) {
/* 490 */       super(A, false);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int compareTo(ComparableRealPoint o) {
/* 499 */       int i = 0;
/* 500 */       while (i < this.n) {
/*     */         
/* 502 */         if (getDoublePosition(i) != o.getDoublePosition(i)) return (int)Math.signum(getDoublePosition(i) - o.getDoublePosition(i)); 
/* 503 */         i++;
/*     */       } 
/* 505 */       return hashCode() - o.hashCode();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 513 */   private static final CostFunction<ComparableRealPoint, Spot> CF = new CostFunction<ComparableRealPoint, Spot>()
/*     */     {
/*     */ 
/*     */       
/*     */       public double linkingCost(KalmanTracker.ComparableRealPoint state, Spot spot)
/*     */       {
/* 519 */         double dx = state.getDoublePosition(0) - spot.getDoublePosition(0);
/* 520 */         double dy = state.getDoublePosition(1) - spot.getDoublePosition(1);
/* 521 */         double dz = state.getDoublePosition(2) - spot.getDoublePosition(2);
/* 522 */         return dx * dx + dy * dy + dz * dz + 2.2250738585072014E-308D;
/*     */       }
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isCanceled() {
/* 532 */     return this.isCanceled;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void cancel(String reason) {
/* 538 */     this.isCanceled = true;
/* 539 */     this.cancelReason = reason;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getCancelReason() {
/* 545 */     return this.cancelReason;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/tracking/kalman/KalmanTracker.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */