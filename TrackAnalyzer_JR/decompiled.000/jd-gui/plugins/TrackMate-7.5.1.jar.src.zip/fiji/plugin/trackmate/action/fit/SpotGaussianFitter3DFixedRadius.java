/*     */ package fiji.plugin.trackmate.action.fit;
/*     */ 
/*     */ import fiji.plugin.trackmate.Logger;
/*     */ import fiji.plugin.trackmate.Spot;
/*     */ import fiji.plugin.trackmate.detection.DetectionUtils;
/*     */ import ij.ImagePlus;
/*     */ import net.imglib2.Point;
/*     */ import net.imglib2.util.Util;
/*     */ import org.apache.commons.math3.exception.TooManyEvaluationsException;
/*     */ import org.apache.commons.math3.fitting.leastsquares.LeastSquaresBuilder;
/*     */ import org.apache.commons.math3.fitting.leastsquares.LeastSquaresOptimizer;
/*     */ import org.apache.commons.math3.fitting.leastsquares.LeastSquaresProblem;
/*     */ import org.apache.commons.math3.fitting.leastsquares.MultivariateJacobianFunction;
/*     */ import org.apache.commons.math3.fitting.leastsquares.ParameterValidator;
/*     */ import org.apache.commons.math3.linear.Array2DRowRealMatrix;
/*     */ import org.apache.commons.math3.linear.ArrayRealVector;
/*     */ import org.apache.commons.math3.linear.RealMatrix;
/*     */ import org.apache.commons.math3.linear.RealVector;
/*     */ import org.apache.commons.math3.util.Pair;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SpotGaussianFitter3DFixedRadius
/*     */   extends AbstractSpotFitter
/*     */ {
/*     */   public SpotGaussianFitter3DFixedRadius(ImagePlus imp, int channel) {
/*  51 */     super(imp, channel);
/*  52 */     assert !DetectionUtils.is2D(imp);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void process(Iterable<Spot> spots, Logger logger) {
/*  58 */     super.process(spots, logger);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void fit(Spot spot) {
/*  64 */     int frame = spot.getFeature("FRAME").intValue();
/*  65 */     double sigma = spot.getFeature("RADIUS").doubleValue() / Math.sqrt(2.0D);
/*  66 */     double pixelSigmaXY = sigma / this.calibration[0];
/*  67 */     double pixelSigmaZ = sigma / this.calibration[2];
/*  68 */     double x0 = spot.getDoublePosition(0) / this.calibration[0];
/*  69 */     double y0 = spot.getDoublePosition(1) / this.calibration[1];
/*  70 */     double z0 = spot.getDoublePosition(2) / this.calibration[2];
/*  71 */     long spanXY = (long)Math.ceil(2.0D * pixelSigmaXY) + 1L;
/*  72 */     long spanZ = (long)Math.ceil(2.0D * pixelSigmaZ) + 1L;
/*  73 */     AbstractSpotFitter.Observation obs = gatherObservationData(new Point(new long[] {
/*     */             
/*  75 */             Math.round(x0), 
/*  76 */             Math.round(y0), 
/*  77 */             Math.round(z0) }, ), new long[] { spanXY, spanXY, spanZ }, frame);
/*     */ 
/*     */     
/*  80 */     clipBackground(obs);
/*     */     
/*  82 */     double bXY = 1.0D / 2.0D * pixelSigmaXY * pixelSigmaXY;
/*  83 */     double bZ = 1.0D / 2.0D * pixelSigmaZ * pixelSigmaZ;
/*  84 */     MyGaussian3D gauss = new MyGaussian3D(obs.pos, bXY, bZ);
/*  85 */     double ampstart = Util.max(obs.values);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  94 */     LeastSquaresProblem lsq = (new LeastSquaresBuilder()).start(new double[] { x0, y0, z0, ampstart }).model(gauss).parameterValidator(gauss).target(obs.values).lazyEvaluation(false).maxEvaluations(1000).maxIterations(1000).build();
/*     */ 
/*     */     
/*     */     try {
/*  98 */       LeastSquaresOptimizer.Optimum optimum = this.optimizer.optimize(lsq);
/*  99 */       RealVector fit = optimum.getPoint();
/*     */       
/* 101 */       double fitX = fit.getEntry(0) * this.calibration[0];
/* 102 */       double fitY = fit.getEntry(1) * this.calibration[1];
/* 103 */       double fitZ = fit.getEntry(2) * this.calibration[2];
/* 104 */       spot.putFeature("POSITION_X", Double.valueOf(fitX));
/* 105 */       spot.putFeature("POSITION_Y", Double.valueOf(fitY));
/* 106 */       spot.putFeature("POSITION_Z", Double.valueOf(fitZ));
/*     */     }
/* 108 */     catch (TooManyEvaluationsException tooManyEvaluationsException) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class MyGaussian3D
/*     */     implements MultivariateJacobianFunction, ParameterValidator
/*     */   {
/*     */     private final long[][] pos;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final double bXY;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final double bZ;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public MyGaussian3D(long[][] pos, double bXY, double bZ) {
/* 135 */       this.pos = pos;
/* 136 */       this.bXY = bXY;
/* 137 */       this.bZ = bZ;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Pair<RealVector, RealMatrix> value(RealVector point) {
/* 144 */       double x0 = point.getEntry(0);
/* 145 */       double y0 = point.getEntry(1);
/* 146 */       double z0 = point.getEntry(2);
/* 147 */       double A = point.getEntry(3);
/*     */ 
/*     */       
/* 150 */       double[] vals = new double[(this.pos[0]).length];
/* 151 */       double[][] grad = new double[(this.pos[0]).length][4];
/* 152 */       for (int i = 0; i < vals.length; i++) {
/*     */         
/* 154 */         long x = this.pos[0][i];
/* 155 */         long y = this.pos[1][i];
/* 156 */         long z = this.pos[2][i];
/* 157 */         double dx = x - x0;
/* 158 */         double dy = y - y0;
/* 159 */         double dz = z - z0;
/* 160 */         double sumSq = -this.bXY * (dx * dx + dy * dy) - this.bZ * dz * dz;
/* 161 */         double E = Math.exp(sumSq);
/* 162 */         vals[i] = A * E;
/*     */ 
/*     */         
/* 165 */         grad[i][0] = A * this.bXY * E * 2.0D * dx;
/*     */         
/* 167 */         grad[i][1] = A * this.bXY * E * 2.0D * dy;
/*     */         
/* 169 */         grad[i][2] = A * this.bZ * E * 2.0D * dz;
/*     */         
/* 171 */         grad[i][3] = E;
/*     */       } 
/* 173 */       ArrayRealVector out = new ArrayRealVector(vals);
/* 174 */       Array2DRowRealMatrix jacobian = new Array2DRowRealMatrix(grad, false);
/* 175 */       return new Pair(out, jacobian);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public RealVector validate(RealVector params) {
/* 181 */       params.setEntry(3, Math.abs(params.getEntry(3)));
/* 182 */       return params;
/*     */     }
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/action/fit/SpotGaussianFitter3DFixedRadius.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */