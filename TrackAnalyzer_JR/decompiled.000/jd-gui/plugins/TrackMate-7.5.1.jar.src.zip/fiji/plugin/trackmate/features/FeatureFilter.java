/*    */ package fiji.plugin.trackmate.features;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FeatureFilter
/*    */ {
/*    */   public final String feature;
/*    */   public final double value;
/*    */   public final boolean isAbove;
/*    */   
/*    */   public FeatureFilter(String feature, double value, boolean isAbove) {
/* 41 */     this.feature = feature;
/* 42 */     this.value = value;
/* 43 */     this.isAbove = isAbove;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String toString() {
/* 49 */     String str = this.feature.toString();
/* 50 */     if (this.isAbove) {
/* 51 */       str = str + " > ";
/*    */     } else {
/* 53 */       str = str + " < ";
/* 54 */     }  str = str + "" + this.value;
/* 55 */     return str;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/features/FeatureFilter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */