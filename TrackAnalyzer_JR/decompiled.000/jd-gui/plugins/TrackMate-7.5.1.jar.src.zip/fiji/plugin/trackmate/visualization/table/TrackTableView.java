/*     */ package fiji.plugin.trackmate.visualization.table;
/*     */ 
/*     */ import fiji.plugin.trackmate.Dimension;
/*     */ import fiji.plugin.trackmate.Model;
/*     */ import fiji.plugin.trackmate.ModelChangeEvent;
/*     */ import fiji.plugin.trackmate.ModelChangeListener;
/*     */ import fiji.plugin.trackmate.SelectionChangeEvent;
/*     */ import fiji.plugin.trackmate.SelectionChangeListener;
/*     */ import fiji.plugin.trackmate.SelectionModel;
/*     */ import fiji.plugin.trackmate.Spot;
/*     */ import fiji.plugin.trackmate.features.FeatureUtils;
/*     */ import fiji.plugin.trackmate.gui.Icons;
/*     */ import fiji.plugin.trackmate.gui.displaysettings.DisplaySettings;
/*     */ import fiji.plugin.trackmate.util.FileChooser;
/*     */ import fiji.plugin.trackmate.util.TMUtils;
/*     */ import fiji.plugin.trackmate.visualization.FeatureColorGenerator;
/*     */ import fiji.plugin.trackmate.visualization.TrackMateModelView;
/*     */ import fiji.plugin.trackmate.visualization.trackscheme.utils.SearchBar;
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.WindowAdapter;
/*     */ import java.awt.event.WindowEvent;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.atomic.AtomicBoolean;
/*     */ import java.util.function.BiConsumer;
/*     */ import java.util.function.BiFunction;
/*     */ import java.util.function.Function;
/*     */ import java.util.function.Supplier;
/*     */ import javax.swing.Box;
/*     */ import javax.swing.BoxLayout;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JFrame;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JTabbedPane;
/*     */ import javax.swing.JTable;
/*     */ import javax.swing.JToggleButton;
/*     */ import javax.swing.event.ListSelectionEvent;
/*     */ import javax.swing.event.ListSelectionListener;
/*     */ import javax.swing.filechooser.FileNameExtensionFilter;
/*     */ import org.jgrapht.graph.DefaultWeightedEdge;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TrackTableView
/*     */   extends JFrame
/*     */   implements TrackMateModelView, ModelChangeListener, SelectionChangeListener
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private static final String KEY = "TRACK_TABLES";
/*  86 */   public static String selectedFile = System.getProperty("user.home") + File.separator + "export.csv";
/*     */   
/*     */   private final Model model;
/*     */   
/*     */   private final TablePanel<Spot> spotTable;
/*     */   
/*     */   private final TablePanel<DefaultWeightedEdge> edgeTable;
/*     */   
/*     */   private final TablePanel<Integer> trackTable;
/*     */   
/*  96 */   private final AtomicBoolean ignoreSelectionChange = new AtomicBoolean(false);
/*     */   
/*     */   private final SelectionModel selectionModel;
/*     */ 
/*     */   
/*     */   public TrackTableView(final Model model, final SelectionModel selectionModel, final DisplaySettings ds) {
/* 102 */     super("Track tables");
/* 103 */     setIconImage(Icons.TRACKMATE_ICON.getImage());
/* 104 */     this.model = model;
/* 105 */     this.selectionModel = selectionModel;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 111 */     JPanel mainPanel = new JPanel();
/* 112 */     mainPanel.setLayout(new BorderLayout());
/*     */ 
/*     */     
/* 115 */     this.spotTable = createSpotTable(model, ds);
/* 116 */     this.edgeTable = createEdgeTable(model, ds);
/* 117 */     this.trackTable = createTrackTable(model, ds);
/*     */ 
/*     */     
/* 120 */     JTabbedPane tabbedPane = new JTabbedPane(2);
/* 121 */     tabbedPane.add("Spots", this.spotTable.getPanel());
/* 122 */     tabbedPane.add("Edges", this.edgeTable.getPanel());
/* 123 */     tabbedPane.add("Tracks", this.trackTable.getPanel());
/*     */     
/* 125 */     tabbedPane.setSelectedComponent(this.spotTable.getPanel());
/* 126 */     mainPanel.add(tabbedPane, "Center");
/*     */ 
/*     */     
/* 129 */     JPanel toolbar = new JPanel();
/* 130 */     BoxLayout layout = new BoxLayout(toolbar, 2);
/* 131 */     toolbar.setLayout(layout);
/* 132 */     JButton exportBtn = new JButton("Export to CSV", Icons.CSV_ICON);
/* 133 */     exportBtn.addActionListener(e -> exportToCsv(tabbedPane.getSelectedIndex()));
/* 134 */     toolbar.add(exportBtn);
/* 135 */     toolbar.add(Box.createHorizontalGlue());
/* 136 */     SearchBar searchBar = new SearchBar(model, this);
/* 137 */     searchBar.setMaximumSize(new Dimension(160, 30));
/* 138 */     toolbar.add((Component)searchBar);
/* 139 */     JToggleButton tglColoring = new JToggleButton("coloring");
/* 140 */     tglColoring.addActionListener(e -> {
/*     */           this.spotTable.setUseColoring(tglColoring.isSelected());
/*     */           this.edgeTable.setUseColoring(tglColoring.isSelected());
/*     */           this.trackTable.setUseColoring(tglColoring.isSelected());
/*     */           refresh();
/*     */         });
/* 146 */     toolbar.add(tglColoring);
/* 147 */     mainPanel.add(toolbar, "North");
/*     */     
/* 149 */     getContentPane().add(mainPanel);
/* 150 */     pack();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 156 */     final DisplaySettings.UpdateListener refresher = () -> refresh();
/* 157 */     ds.listeners().add(refresher);
/* 158 */     selectionModel.addSelectionChangeListener(this);
/* 159 */     model.addModelChangeListener(this);
/* 160 */     addWindowListener(new WindowAdapter()
/*     */         {
/*     */           
/*     */           public void windowClosing(WindowEvent e)
/*     */           {
/* 165 */             selectionModel.removeSelectionChangeListener(TrackTableView.this);
/* 166 */             model.removeModelChangeListener(TrackTableView.this);
/* 167 */             ds.listeners().remove(refresher);
/*     */           }
/*     */         });
/*     */   }
/*     */ 
/*     */   
/*     */   private void exportToCsv(int index) {
/*     */     TablePanel<?> table;
/* 175 */     switch (index) {
/*     */       
/*     */       case 0:
/* 178 */         table = this.spotTable;
/*     */         break;
/*     */       case 1:
/* 181 */         table = this.edgeTable;
/*     */         break;
/*     */       case 2:
/* 184 */         table = this.trackTable;
/*     */         break;
/*     */       default:
/* 187 */         throw new IllegalArgumentException("Unknown table with index " + index);
/*     */     } 
/*     */     
/* 190 */     File file = FileChooser.chooseFile(this, selectedFile, new FileNameExtensionFilter("CSV files", new String[] { "csv" }), "Export table to CSV", FileChooser.DialogType.SAVE, FileChooser.SelectionMode.FILES_ONLY);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 197 */     if (null == file) {
/*     */       return;
/*     */     }
/* 200 */     selectedFile = file.getAbsolutePath();
/*     */     
/*     */     try {
/* 203 */       table.exportToCsv(file);
/*     */     }
/* 205 */     catch (IOException e) {
/*     */       
/* 207 */       this.model.getLogger().error("Problem exporting to file " + file + "\n" + e
/* 208 */           .getMessage());
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private final TablePanel<Integer> createTrackTable(Model model, DisplaySettings ds) {
/* 214 */     List<Integer> objects = new ArrayList<>(model.getTrackModel().trackIDs(true));
/* 215 */     List<String> features = new ArrayList<>(model.getFeatureModel().getTrackFeatures());
/* 216 */     BiFunction<Integer, String, Double> featureFun = (trackID, feature) -> model.getFeatureModel().getTrackFeature(trackID, feature);
/* 217 */     Map<String, String> featureNames = model.getFeatureModel().getTrackFeatureNames();
/* 218 */     Map<String, String> featureShortNames = model.getFeatureModel().getTrackFeatureShortNames();
/* 219 */     Map<String, String> featureUnits = new HashMap<>();
/* 220 */     for (String feature : features) {
/*     */       
/* 222 */       Dimension dimension = (Dimension)model.getFeatureModel().getTrackFeatureDimensions().get(feature);
/* 223 */       String units = TMUtils.getUnitsFor(dimension, model.getSpaceUnits(), model.getTimeUnits());
/* 224 */       featureUnits.put(feature, units);
/*     */     } 
/* 226 */     Map<String, Boolean> isInts = model.getFeatureModel().getTrackFeatureIsInt();
/* 227 */     Map<String, String> infoTexts = new HashMap<>();
/* 228 */     Function<Integer, String> labelGenerator = id -> model.getTrackModel().name(id);
/* 229 */     BiConsumer<Integer, String> labelSetter = (id, label) -> model.getTrackModel().setName(id, label);
/*     */     
/* 231 */     Supplier<FeatureColorGenerator<Integer>> coloring = () -> FeatureUtils.createWholeTrackColorGenerator(model, ds);
/*     */ 
/*     */     
/* 234 */     TablePanel<Integer> table = new TablePanel<>(objects, features, featureFun, featureNames, featureShortNames, featureUnits, isInts, infoTexts, coloring, labelGenerator, labelSetter);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 248 */     table.getTable().getSelectionModel().addListSelectionListener(new TrackTableSelectionListener());
/*     */ 
/*     */     
/* 251 */     return table;
/*     */   }
/*     */ 
/*     */   
/*     */   private final TablePanel<DefaultWeightedEdge> createEdgeTable(Model model, DisplaySettings ds) {
/* 256 */     List<DefaultWeightedEdge> objects = new ArrayList<>();
/* 257 */     for (Integer trackID : model.getTrackModel().unsortedTrackIDs(true))
/* 258 */       objects.addAll(model.getTrackModel().trackEdges(trackID)); 
/* 259 */     List<String> features = new ArrayList<>(model.getFeatureModel().getEdgeFeatures());
/* 260 */     Map<String, String> featureNames = model.getFeatureModel().getEdgeFeatureNames();
/* 261 */     Map<String, String> featureShortNames = model.getFeatureModel().getEdgeFeatureShortNames();
/* 262 */     Map<String, String> featureUnits = new HashMap<>();
/* 263 */     for (String feature : features) {
/*     */       
/* 265 */       Dimension dimension = (Dimension)model.getFeatureModel().getEdgeFeatureDimensions().get(feature);
/* 266 */       String units = TMUtils.getUnitsFor(dimension, model.getSpaceUnits(), model.getTimeUnits());
/* 267 */       featureUnits.put(feature, units);
/*     */     } 
/* 269 */     Map<String, Boolean> isInts = model.getFeatureModel().getEdgeFeatureIsInt();
/* 270 */     Map<String, String> infoTexts = new HashMap<>();
/* 271 */     Function<DefaultWeightedEdge, String> labelGenerator = edge -> String.format("%s → %s", new Object[] { model.getTrackModel().getEdgeSource(edge).getName(), model.getTrackModel().getEdgeTarget(edge).getName() });
/*     */     
/* 273 */     BiConsumer<DefaultWeightedEdge, String> labelSetter = null;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 278 */     String TRACK_ID = "TRACK_ID";
/* 279 */     features.add(0, "TRACK_ID");
/* 280 */     featureNames.put("TRACK_ID", "Track ID");
/* 281 */     featureShortNames.put("TRACK_ID", "Track ID");
/* 282 */     featureUnits.put("TRACK_ID", "");
/* 283 */     isInts.put("TRACK_ID", Boolean.TRUE);
/* 284 */     infoTexts.put("TRACK_ID", "The id of the track this spot belongs to.");
/*     */     
/* 286 */     BiFunction<DefaultWeightedEdge, String, Double> featureFun = (edge, feature) -> {
/*     */         if (feature.equals("TRACK_ID")) {
/*     */           Integer trackID = model.getTrackModel().trackIDOf(edge);
/*     */           
/*     */           return (trackID == null) ? null : Double.valueOf(trackID.doubleValue());
/*     */         } 
/*     */         
/*     */         return model.getFeatureModel().getEdgeFeature(edge, feature);
/*     */       };
/* 295 */     BiConsumer<DefaultWeightedEdge, Color> colorSetter = (edge, color) -> model.getFeatureModel().putEdgeFeature(edge, "MANUAL_EGE_COLOR", Double.valueOf(color.getRGB()));
/*     */ 
/*     */     
/* 298 */     Supplier<FeatureColorGenerator<DefaultWeightedEdge>> coloring = () -> FeatureUtils.createTrackColorGenerator(model, ds);
/*     */ 
/*     */     
/* 301 */     TablePanel<DefaultWeightedEdge> table = new TablePanel<>(objects, features, featureFun, featureNames, featureShortNames, featureUnits, isInts, infoTexts, coloring, labelGenerator, labelSetter, "MANUAL_EGE_COLOR", colorSetter);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 317 */     table.getTable().getSelectionModel().addListSelectionListener(new EdgeTableSelectionListener());
/*     */ 
/*     */     
/* 320 */     return table;
/*     */   }
/*     */ 
/*     */   
/*     */   private final TablePanel<Spot> createSpotTable(Model model, DisplaySettings ds) {
/* 325 */     List<Spot> objects = new ArrayList<>();
/* 326 */     for (Integer trackID : model.getTrackModel().unsortedTrackIDs(true))
/* 327 */       objects.addAll(model.getTrackModel().trackSpots(trackID)); 
/* 328 */     List<String> features = new ArrayList<>(model.getFeatureModel().getSpotFeatures());
/* 329 */     Map<String, String> featureNames = model.getFeatureModel().getSpotFeatureNames();
/* 330 */     Map<String, String> featureShortNames = model.getFeatureModel().getSpotFeatureShortNames();
/* 331 */     Map<String, String> featureUnits = new HashMap<>();
/* 332 */     for (String feature : features) {
/*     */       
/* 334 */       Dimension dimension = (Dimension)model.getFeatureModel().getSpotFeatureDimensions().get(feature);
/* 335 */       String units = TMUtils.getUnitsFor(dimension, model.getSpaceUnits(), model.getTimeUnits());
/* 336 */       featureUnits.put(feature, units);
/*     */     } 
/* 338 */     Map<String, Boolean> isInts = model.getFeatureModel().getSpotFeatureIsInt();
/* 339 */     Map<String, String> infoTexts = new HashMap<>();
/* 340 */     Function<Spot, String> labelGenerator = spot -> spot.getName();
/* 341 */     BiConsumer<Spot, String> labelSetter = (spot, label) -> spot.setName(label);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 346 */     String SPOT_ID = "ID";
/* 347 */     features.add(0, "ID");
/* 348 */     featureNames.put("ID", "Spot ID");
/* 349 */     featureShortNames.put("ID", "Spot ID");
/* 350 */     featureUnits.put("ID", "");
/* 351 */     isInts.put("ID", Boolean.TRUE);
/* 352 */     infoTexts.put("ID", "The id of the spot.");
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 357 */     String TRACK_ID = "TRACK_ID";
/* 358 */     features.add(1, "TRACK_ID");
/* 359 */     featureNames.put("TRACK_ID", "Track ID");
/* 360 */     featureShortNames.put("TRACK_ID", "Track ID");
/* 361 */     featureUnits.put("TRACK_ID", "");
/* 362 */     isInts.put("TRACK_ID", Boolean.TRUE);
/* 363 */     infoTexts.put("TRACK_ID", "The id of the track this spot belongs to.");
/*     */     
/* 365 */     BiFunction<Spot, String, Double> featureFun = (spot, feature) -> {
/*     */         if (feature.equals("TRACK_ID")) {
/*     */           Integer trackID = model.getTrackModel().trackIDOf(spot);
/*     */ 
/*     */           
/*     */           return (trackID == null) ? null : Double.valueOf(trackID.doubleValue());
/*     */         } 
/*     */ 
/*     */         
/*     */         return feature.equals("ID") ? Double.valueOf(spot.ID()) : spot.getFeature(feature);
/*     */       };
/*     */     
/* 377 */     BiConsumer<Spot, Color> colorSetter = (spot, color) -> spot.putFeature("MANUAL_SPOT_COLOR", Double.valueOf(color.getRGB()));
/*     */ 
/*     */     
/* 380 */     Supplier<FeatureColorGenerator<Spot>> coloring = () -> FeatureUtils.createSpotColorGenerator(model, ds);
/*     */ 
/*     */     
/* 383 */     TablePanel<Spot> table = new TablePanel<>(objects, features, featureFun, featureNames, featureShortNames, featureUnits, isInts, infoTexts, coloring, labelGenerator, labelSetter, "MANUAL_SPOT_COLOR", colorSetter);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 399 */     table.getTable().getSelectionModel().addListSelectionListener(new SpotTableSelectionListener());
/*     */ 
/*     */     
/* 402 */     return table;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void render() {
/* 408 */     setLocationRelativeTo((Component)null);
/* 409 */     setVisible(true);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void refresh() {
/* 415 */     repaint();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void modelChanged(ModelChangeEvent event) {
/* 421 */     if (event.getEventID() == 9) {
/*     */       
/* 423 */       refresh();
/*     */       
/*     */       return;
/*     */     } 
/* 427 */     List<Spot> spots = new ArrayList<>();
/* 428 */     for (Integer trackID : this.model.getTrackModel().unsortedTrackIDs(true))
/* 429 */       spots.addAll(this.model.getTrackModel().trackSpots(trackID)); 
/* 430 */     this.spotTable.setObjects(spots);
/*     */     
/* 432 */     List<DefaultWeightedEdge> edges = new ArrayList<>();
/* 433 */     for (Integer trackID : this.model.getTrackModel().unsortedTrackIDs(true))
/* 434 */       edges.addAll(this.model.getTrackModel().trackEdges(trackID)); 
/* 435 */     this.edgeTable.setObjects(edges);
/*     */     
/* 437 */     List<Integer> trackIDs = new ArrayList<>(this.model.getTrackModel().trackIDs(true));
/* 438 */     this.trackTable.setObjects(trackIDs);
/*     */     
/* 440 */     refresh();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void selectionChanged(SelectionChangeEvent event) {
/* 449 */     if (this.ignoreSelectionChange.get())
/*     */       return; 
/* 451 */     this.ignoreSelectionChange.set(true);
/*     */ 
/*     */     
/* 454 */     Set<Spot> selectedVertices = this.selectionModel.getSpotSelection();
/* 455 */     JTable vt = this.spotTable.getTable();
/* 456 */     vt.getSelectionModel().clearSelection();
/* 457 */     for (Spot spot : selectedVertices) {
/*     */       
/* 459 */       int row = this.spotTable.getViewRowForObject(spot);
/* 460 */       vt.getSelectionModel().addSelectionInterval(row, row);
/*     */     } 
/*     */ 
/*     */     
/* 464 */     Map<Spot, Boolean> spotsAdded = event.getSpots();
/* 465 */     if (spotsAdded != null && spotsAdded.size() == 1) {
/*     */       
/* 467 */       boolean added = ((Boolean)spotsAdded.values().iterator().next()).booleanValue();
/* 468 */       if (added) {
/*     */         
/* 470 */         Spot spot = spotsAdded.keySet().iterator().next();
/* 471 */         centerViewOn(spot);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 476 */     Set<DefaultWeightedEdge> selectedEdges = this.selectionModel.getEdgeSelection();
/* 477 */     JTable et = this.edgeTable.getTable();
/* 478 */     et.getSelectionModel().clearSelection();
/* 479 */     for (DefaultWeightedEdge e : selectedEdges) {
/*     */       
/* 481 */       int row = this.edgeTable.getViewRowForObject(e);
/* 482 */       et.getSelectionModel().addSelectionInterval(row, row);
/*     */     } 
/*     */ 
/*     */     
/* 486 */     Map<DefaultWeightedEdge, Boolean> edgesAdded = event.getEdges();
/* 487 */     if (edgesAdded != null && edgesAdded.size() == 1) {
/*     */       
/* 489 */       boolean added = ((Boolean)edgesAdded.values().iterator().next()).booleanValue();
/* 490 */       if (added) {
/*     */         
/* 492 */         DefaultWeightedEdge edge = edgesAdded.keySet().iterator().next();
/* 493 */         centerViewOn(edge);
/*     */       } 
/*     */     } 
/*     */     
/* 497 */     refresh();
/* 498 */     this.ignoreSelectionChange.set(false);
/*     */   }
/*     */ 
/*     */   
/*     */   public void centerViewOn(DefaultWeightedEdge edge) {
/* 503 */     this.edgeTable.scrollToObject(edge);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void centerViewOn(Spot spot) {
/* 509 */     this.spotTable.scrollToObject(spot);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Model getModel() {
/* 515 */     return this.model;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getKey() {
/* 521 */     return "TRACK_TABLES";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void clear() {}
/*     */ 
/*     */   
/*     */   public TablePanel<Spot> getSpotTable() {
/* 530 */     return this.spotTable;
/*     */   }
/*     */ 
/*     */   
/*     */   public TablePanel<DefaultWeightedEdge> getEdgeTable() {
/* 535 */     return this.edgeTable;
/*     */   }
/*     */ 
/*     */   
/*     */   public TablePanel<Integer> getTrackTable() {
/* 540 */     return this.trackTable;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private final class SpotTableSelectionListener
/*     */     implements ListSelectionListener
/*     */   {
/*     */     private SpotTableSelectionListener() {}
/*     */ 
/*     */     
/*     */     public void valueChanged(ListSelectionEvent event) {
/* 552 */       if (event.getValueIsAdjusting() || TrackTableView.this.ignoreSelectionChange.get()) {
/*     */         return;
/*     */       }
/* 555 */       TrackTableView.this.ignoreSelectionChange.set(true);
/*     */       
/* 557 */       int[] selectedRows = TrackTableView.this.spotTable.getTable().getSelectedRows();
/* 558 */       List<Spot> toSelect = new ArrayList<>(selectedRows.length);
/* 559 */       for (int row : selectedRows) {
/* 560 */         toSelect.add(TrackTableView.this.spotTable.getObjectForViewRow(row));
/*     */       }
/* 562 */       TrackTableView.this.selectionModel.clearSelection();
/* 563 */       TrackTableView.this.selectionModel.addSpotToSelection(toSelect);
/* 564 */       TrackTableView.this.refresh();
/*     */       
/* 566 */       TrackTableView.this.ignoreSelectionChange.set(false);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private final class EdgeTableSelectionListener
/*     */     implements ListSelectionListener
/*     */   {
/*     */     private EdgeTableSelectionListener() {}
/*     */ 
/*     */     
/*     */     public void valueChanged(ListSelectionEvent event) {
/* 579 */       if (event.getValueIsAdjusting() || TrackTableView.this.ignoreSelectionChange.get()) {
/*     */         return;
/*     */       }
/* 582 */       TrackTableView.this.ignoreSelectionChange.set(true);
/*     */       
/* 584 */       int[] selectedRows = TrackTableView.this.edgeTable.getTable().getSelectedRows();
/* 585 */       List<DefaultWeightedEdge> toSelect = new ArrayList<>(selectedRows.length);
/* 586 */       for (int row : selectedRows) {
/* 587 */         toSelect.add(TrackTableView.this.edgeTable.getObjectForViewRow(row));
/*     */       }
/* 589 */       TrackTableView.this.selectionModel.clearSelection();
/* 590 */       TrackTableView.this.selectionModel.addEdgeToSelection(toSelect);
/* 591 */       TrackTableView.this.refresh();
/*     */       
/* 593 */       TrackTableView.this.ignoreSelectionChange.set(false);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private class TrackTableSelectionListener
/*     */     implements ListSelectionListener
/*     */   {
/*     */     private TrackTableSelectionListener() {}
/*     */ 
/*     */     
/*     */     public void valueChanged(ListSelectionEvent event) {
/* 606 */       if (event.getValueIsAdjusting() || TrackTableView.this.ignoreSelectionChange.get()) {
/*     */         return;
/*     */       }
/* 609 */       TrackTableView.this.ignoreSelectionChange.set(true);
/*     */       
/* 611 */       Set<Spot> spots = new HashSet<>();
/* 612 */       Set<DefaultWeightedEdge> edges = new HashSet<>();
/* 613 */       int[] selectedRows = TrackTableView.this.trackTable.getTable().getSelectedRows();
/* 614 */       for (int row : selectedRows) {
/*     */         
/* 616 */         Integer trackID = TrackTableView.this.trackTable.getObjectForViewRow(row);
/* 617 */         spots.addAll(TrackTableView.this.model.getTrackModel().trackSpots(trackID));
/* 618 */         edges.addAll(TrackTableView.this.model.getTrackModel().trackEdges(trackID));
/*     */       } 
/* 620 */       TrackTableView.this.selectionModel.clearSelection();
/* 621 */       TrackTableView.this.selectionModel.addSpotToSelection(spots);
/* 622 */       TrackTableView.this.selectionModel.addEdgeToSelection(edges);
/*     */       
/* 624 */       TrackTableView.this.refresh();
/*     */       
/* 626 */       TrackTableView.this.ignoreSelectionChange.set(false);
/*     */     }
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/visualization/table/TrackTableView.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */