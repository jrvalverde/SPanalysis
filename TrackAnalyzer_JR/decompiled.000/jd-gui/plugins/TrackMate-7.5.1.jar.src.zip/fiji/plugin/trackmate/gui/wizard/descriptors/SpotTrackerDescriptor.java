/*    */ package fiji.plugin.trackmate.gui.wizard.descriptors;
/*    */ 
/*    */ import fiji.plugin.trackmate.Logger;
/*    */ import fiji.plugin.trackmate.Settings;
/*    */ import fiji.plugin.trackmate.gui.components.ConfigurationPanel;
/*    */ import fiji.plugin.trackmate.gui.wizard.WizardPanelDescriptor;
/*    */ import fiji.plugin.trackmate.io.SettingsPersistence;
/*    */ import fiji.plugin.trackmate.util.TMUtils;
/*    */ import java.awt.Component;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SpotTrackerDescriptor
/*    */   extends WizardPanelDescriptor
/*    */ {
/*    */   public static final String KEY = "ConfigureTracker";
/*    */   private final Settings settings;
/*    */   private final Logger logger;
/*    */   
/*    */   public SpotTrackerDescriptor(Settings settings, ConfigurationPanel configurationPanel, Logger logger) {
/* 43 */     super("ConfigureTracker");
/* 44 */     this.settings = settings;
/* 45 */     this.targetPanel = (Component)configurationPanel;
/* 46 */     this.logger = logger;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void aboutToHidePanel() {
/* 52 */     ConfigurationPanel configurationPanel = (ConfigurationPanel)this.targetPanel;
/* 53 */     this.settings.trackerSettings = configurationPanel.getSettings();
/*    */     
/* 55 */     this.logger.log("\nConfigured tracker ");
/* 56 */     this.logger.log(this.settings.trackerFactory.getName(), Logger.BLUE_COLOR);
/* 57 */     this.logger.log(" with settings:\n");
/* 58 */     this.logger.log(TMUtils.echoMap(this.settings.trackerSettings, 2) + "\n");
/*    */ 
/*    */     
/* 61 */     SettingsPersistence.saveLastUsedSettings(this.settings, this.logger);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/gui/wizard/descriptors/SpotTrackerDescriptor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */