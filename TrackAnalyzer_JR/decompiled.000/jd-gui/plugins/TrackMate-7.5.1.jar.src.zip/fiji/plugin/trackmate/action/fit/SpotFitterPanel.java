/*     */ package fiji.plugin.trackmate.action.fit;
/*     */ 
/*     */ import fiji.plugin.trackmate.gui.Fonts;
/*     */ import java.awt.Component;
/*     */ import java.awt.GridBagConstraints;
/*     */ import java.awt.GridBagLayout;
/*     */ import java.awt.Insets;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.util.List;
/*     */ import javax.swing.Box;
/*     */ import javax.swing.BoxLayout;
/*     */ import javax.swing.ButtonGroup;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JComboBox;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JRadioButton;
/*     */ import javax.swing.JSlider;
/*     */ import javax.swing.event.ChangeEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SpotFitterPanel
/*     */   extends JPanel
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private final JComboBox<String> cmbboxModel;
/*     */   final JButton btnUndo;
/*     */   final JButton btnFit;
/*     */   final JRadioButton rdbtnAll;
/*     */   final JRadioButton rdbtnSelection;
/*     */   final JRadioButton rdbtnTracks;
/*     */   private final JSlider sliderChannel;
/*     */   
/*     */   public SpotFitterPanel(List<String> fits, List<String> docs, int nChannels) {
/*  65 */     GridBagLayout gridBagLayout = new GridBagLayout();
/*  66 */     gridBagLayout.columnWidths = new int[] { 0, 0, 0 };
/*  67 */     gridBagLayout.rowHeights = new int[] { 0, 0, 0, 0, 0, 0, 0 };
/*  68 */     gridBagLayout.columnWeights = new double[] { 0.0D, 1.0D, Double.MIN_VALUE };
/*  69 */     gridBagLayout.rowWeights = new double[] { 0.0D, 0.0D, 0.0D, 1.0D, 0.0D, 0.0D, Double.MIN_VALUE };
/*  70 */     setLayout(gridBagLayout);
/*     */     
/*  72 */     JLabel lblTitle = new JLabel("Refine spot position by fitting");
/*  73 */     lblTitle.setFont(Fonts.BIG_FONT);
/*  74 */     lblTitle.setHorizontalAlignment(0);
/*  75 */     GridBagConstraints gbcLblTitle = new GridBagConstraints();
/*  76 */     gbcLblTitle.gridwidth = 2;
/*  77 */     gbcLblTitle.fill = 1;
/*  78 */     gbcLblTitle.insets = new Insets(5, 5, 5, 5);
/*  79 */     gbcLblTitle.gridx = 0;
/*  80 */     gbcLblTitle.gridy = 0;
/*  81 */     add(lblTitle, gbcLblTitle);
/*     */     
/*  83 */     JLabel lblChannel = new JLabel("Channel:");
/*  84 */     this.sliderChannel = new JSlider(1, nChannels, 1);
/*     */ 
/*     */     
/*  87 */     if (nChannels > 1) {
/*     */       
/*  89 */       GridBagConstraints gbcLblChannel = new GridBagConstraints();
/*  90 */       gbcLblChannel.anchor = 13;
/*  91 */       gbcLblChannel.insets = new Insets(5, 5, 5, 5);
/*  92 */       gbcLblChannel.gridx = 0;
/*  93 */       gbcLblChannel.gridy = 1;
/*  94 */       add(lblChannel, gbcLblChannel);
/*     */       
/*  96 */       JPanel panelSlider = new JPanel();
/*  97 */       GridBagConstraints gbc_panelSlider = new GridBagConstraints();
/*  98 */       gbc_panelSlider.fill = 1;
/*  99 */       gbc_panelSlider.insets = new Insets(5, 5, 5, 5);
/* 100 */       gbc_panelSlider.gridx = 1;
/* 101 */       gbc_panelSlider.gridy = 1;
/* 102 */       add(panelSlider, gbc_panelSlider);
/* 103 */       panelSlider.setLayout(new BoxLayout(panelSlider, 0));
/* 104 */       panelSlider.add(this.sliderChannel);
/* 105 */       this.sliderChannel.setPaintLabels(true);
/* 106 */       this.sliderChannel.setSnapToTicks(true);
/* 107 */       this.sliderChannel.setPaintTicks(true);
/* 108 */       this.sliderChannel.setFont(Fonts.SMALL_FONT);
/*     */       
/* 110 */       JLabel lblChannelIndex = new JLabel("1");
/* 111 */       lblChannelIndex.setFont(Fonts.FONT.deriveFont(1));
/* 112 */       lblChannelIndex.setHorizontalAlignment(0);
/* 113 */       panelSlider.add(lblChannelIndex);
/* 114 */       this.sliderChannel.addChangeListener(e -> lblChannelIndex.setText("" + this.sliderChannel.getValue()));
/*     */     } 
/*     */     
/* 117 */     JLabel lblFitType = new JLabel("Fit type:");
/* 118 */     lblFitType.setFont(Fonts.FONT);
/* 119 */     GridBagConstraints gbcLblFitType = new GridBagConstraints();
/* 120 */     gbcLblFitType.anchor = 13;
/* 121 */     gbcLblFitType.insets = new Insets(5, 5, 5, 5);
/* 122 */     gbcLblFitType.gridx = 0;
/* 123 */     gbcLblFitType.gridy = 2;
/* 124 */     add(lblFitType, gbcLblFitType);
/*     */     
/* 126 */     String[] arr = fits.<String>toArray(new String[0]);
/* 127 */     this.cmbboxModel = new JComboBox<>(arr);
/* 128 */     this.cmbboxModel.setFont(Fonts.FONT);
/* 129 */     GridBagConstraints gbcComboBox = new GridBagConstraints();
/* 130 */     gbcComboBox.insets = new Insets(5, 5, 5, 5);
/* 131 */     gbcComboBox.fill = 2;
/* 132 */     gbcComboBox.gridx = 1;
/* 133 */     gbcComboBox.gridy = 2;
/* 134 */     add(this.cmbboxModel, gbcComboBox);
/*     */     
/* 136 */     JLabel lblDoc = new JLabel(" ");
/* 137 */     lblDoc.setFont(Fonts.SMALL_FONT);
/* 138 */     GridBagConstraints gbcLblDoc = new GridBagConstraints();
/* 139 */     gbcLblDoc.fill = 2;
/* 140 */     gbcLblDoc.gridwidth = 2;
/* 141 */     gbcLblDoc.insets = new Insets(5, 5, 5, 5);
/* 142 */     gbcLblDoc.gridx = 0;
/* 143 */     gbcLblDoc.gridy = 3;
/* 144 */     add(lblDoc, gbcLblDoc);
/*     */     
/* 146 */     JPanel panelSelection = new JPanel();
/* 147 */     GridBagConstraints gbcPanelSelection = new GridBagConstraints();
/* 148 */     gbcPanelSelection.gridwidth = 2;
/* 149 */     gbcPanelSelection.insets = new Insets(5, 5, 5, 5);
/* 150 */     gbcPanelSelection.fill = 2;
/* 151 */     gbcPanelSelection.gridx = 0;
/* 152 */     gbcPanelSelection.gridy = 4;
/* 153 */     add(panelSelection, gbcPanelSelection);
/* 154 */     panelSelection.setLayout(new BoxLayout(panelSelection, 0));
/*     */     
/* 156 */     JLabel lblPerformOn = new JLabel("Fit:");
/* 157 */     lblPerformOn.setFont(Fonts.FONT);
/* 158 */     panelSelection.add(lblPerformOn);
/*     */     
/* 160 */     this.rdbtnAll = new JRadioButton("All spots");
/* 161 */     this.rdbtnSelection = new JRadioButton("Selection");
/* 162 */     this.rdbtnTracks = new JRadioButton("Tracks of selection");
/* 163 */     this.rdbtnAll.setFont(Fonts.FONT);
/* 164 */     this.rdbtnSelection.setFont(Fonts.FONT);
/* 165 */     this.rdbtnTracks.setFont(Fonts.FONT);
/*     */     
/* 167 */     panelSelection.add(Box.createHorizontalGlue());
/* 168 */     panelSelection.add(this.rdbtnAll);
/* 169 */     panelSelection.add(this.rdbtnSelection);
/* 170 */     panelSelection.add(this.rdbtnTracks);
/*     */     
/* 172 */     JPanel panelButtons = new JPanel();
/* 173 */     GridBagConstraints gbcPanelButtons = new GridBagConstraints();
/* 174 */     gbcPanelButtons.gridwidth = 2;
/* 175 */     gbcPanelButtons.fill = 1;
/* 176 */     gbcPanelButtons.gridx = 0;
/* 177 */     gbcPanelButtons.gridy = 5;
/* 178 */     add(panelButtons, gbcPanelButtons);
/* 179 */     panelButtons.setLayout(new BoxLayout(panelButtons, 0));
/*     */     
/* 181 */     this.btnUndo = new JButton("Undo last fit");
/* 182 */     this.btnUndo.setFont(Fonts.FONT);
/* 183 */     panelButtons.add(this.btnUndo);
/*     */     
/* 185 */     Component horizontalGlue = Box.createHorizontalGlue();
/* 186 */     panelButtons.add(horizontalGlue);
/*     */     
/* 188 */     this.btnFit = new JButton("Fit");
/* 189 */     this.btnFit.setFont(Fonts.FONT);
/* 190 */     panelButtons.add(this.btnFit);
/*     */     
/* 192 */     ButtonGroup btngroup = new ButtonGroup();
/* 193 */     btngroup.add(this.rdbtnAll);
/* 194 */     btngroup.add(this.rdbtnSelection);
/* 195 */     btngroup.add(this.rdbtnTracks);
/* 196 */     this.rdbtnSelection.setSelected(true);
/*     */     
/* 198 */     this.cmbboxModel.addActionListener(e -> lblDoc.setText(docs.get(this.cmbboxModel.getSelectedIndex())));
/* 199 */     this.cmbboxModel.setSelectedIndex(0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getSelectedChannel() {
/* 209 */     return this.sliderChannel.getValue();
/*     */   }
/*     */ 
/*     */   
/*     */   public int getSelectedFitIndex() {
/* 214 */     return this.cmbboxModel.getSelectedIndex();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/action/fit/SpotFitterPanel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */