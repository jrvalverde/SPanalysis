/*     */ package fiji.plugin.trackmate.gui.displaysettings;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Paint;
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import java.util.TreeMap;
/*     */ import org.jfree.chart.renderer.PaintScale;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Colormap
/*     */   implements PaintScale, Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 2977884191627862512L;
/*  45 */   private static final Color DEFAULT_COLOR = Color.BLACK;
/*     */   
/*     */   private final double lowerBound;
/*     */   
/*     */   private final double upperBound;
/*     */   
/*  51 */   private final TreeMap<Double, Color> colors = new TreeMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final Color defaultColor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  68 */   public static final Colormap Jet = new Colormap("Jet", 0.0D, 1.0D); static {
/*  69 */     Jet.add(0.0D, new Color(0.0F, 0.0F, 1.0F));
/*  70 */     Jet.add(0.16D, new Color(0.0F, 0.5F, 1.0F));
/*  71 */     Jet.add(0.33D, new Color(0.0F, 1.0F, 1.0F));
/*  72 */     Jet.add(0.5D, new Color(0.5F, 1.0F, 0.5F));
/*  73 */     Jet.add(0.66D, new Color(1.0F, 1.0F, 0.0F));
/*  74 */     Jet.add(0.83D, new Color(1.0F, 0.5F, 0.0F));
/*  75 */     Jet.add(1.0D, new Color(1.0F, 0.0F, 0.0F));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  85 */   public static final Colormap Viridis = new Colormap("Viridis", 0.0D, 1.0D); static {
/*  86 */     Viridis.add(0.0D, new Color(68, 1, 84));
/*  87 */     Viridis.add(0.05D, new Color(71, 18, 101));
/*  88 */     Viridis.add(0.1D, new Color(72, 35, 116));
/*  89 */     Viridis.add(0.15D, new Color(69, 52, 127));
/*  90 */     Viridis.add(0.2D, new Color(64, 67, 135));
/*  91 */     Viridis.add(0.25D, new Color(58, 82, 139));
/*  92 */     Viridis.add(0.3D, new Color(52, 94, 141));
/*  93 */     Viridis.add(0.35D, new Color(46, 107, 142));
/*  94 */     Viridis.add(0.4D, new Color(41, 120, 142));
/*  95 */     Viridis.add(0.45D, new Color(36, 132, 141));
/*  96 */     Viridis.add(0.5D, new Color(32, 144, 140));
/*  97 */     Viridis.add(0.55D, new Color(30, 155, 137));
/*  98 */     Viridis.add(0.6D, new Color(34, 167, 132));
/*  99 */     Viridis.add(0.65D, new Color(47, 179, 123));
/* 100 */     Viridis.add(0.7D, new Color(68, 190, 112));
/* 101 */     Viridis.add(0.75D, new Color(94, 201, 97));
/* 102 */     Viridis.add(0.8D, new Color(121, 209, 81));
/* 103 */     Viridis.add(0.85D, new Color(154, 216, 60));
/* 104 */     Viridis.add(0.9D, new Color(189, 222, 38));
/* 105 */     Viridis.add(0.95D, new Color(223, 227, 24));
/* 106 */     Viridis.add(1.0D, new Color(253, 231, 36));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 118 */     double[][] triplets = { { 0.18995D, 0.07176D, 0.23217D }, { 0.19483D, 0.08339D, 0.26149D }, { 0.19956D, 0.09498D, 0.29024D }, { 0.20415D, 0.10652D, 0.31844D }, { 0.2086D, 0.11802D, 0.34607D }, { 0.21291D, 0.12947D, 0.37314D }, { 0.21708D, 0.14087D, 0.39964D }, { 0.22111D, 0.15223D, 0.42558D }, { 0.225D, 0.16354D, 0.45096D }, { 0.22875D, 0.17481D, 0.47578D }, { 0.23236D, 0.18603D, 0.50004D }, { 0.23582D, 0.1972D, 0.52373D }, { 0.23915D, 0.20833D, 0.54686D }, { 0.24234D, 0.21941D, 0.56942D }, { 0.24539D, 0.23044D, 0.59142D }, { 0.2483D, 0.24143D, 0.61286D }, { 0.25107D, 0.25237D, 0.63374D }, { 0.25369D, 0.26327D, 0.65406D }, { 0.25618D, 0.27412D, 0.67381D }, { 0.25853D, 0.28492D, 0.693D }, { 0.26074D, 0.29568D, 0.71162D }, { 0.2628D, 0.30639D, 0.72968D }, { 0.26473D, 0.31706D, 0.74718D }, { 0.26652D, 0.32768D, 0.76412D }, { 0.26816D, 0.33825D, 0.7805D }, { 0.26967D, 0.34878D, 0.79631D }, { 0.27103D, 0.35926D, 0.81156D }, { 0.27226D, 0.3697D, 0.82624D }, { 0.27334D, 0.38008D, 0.84037D }, { 0.27429D, 0.39043D, 0.85393D }, { 0.27509D, 0.40072D, 0.86692D }, { 0.27576D, 0.41097D, 0.87936D }, { 0.27628D, 0.42118D, 0.89123D }, { 0.27667D, 0.43134D, 0.90254D }, { 0.27691D, 0.44145D, 0.91328D }, { 0.27701D, 0.45152D, 0.92347D }, { 0.27698D, 0.46153D, 0.93309D }, { 0.2768D, 0.47151D, 0.94214D }, { 0.27648D, 0.48144D, 0.95064D }, { 0.27603D, 0.49132D, 0.95857D }, { 0.27543D, 0.50115D, 0.96594D }, { 0.27469D, 0.51094D, 0.97275D }, { 0.27381D, 0.52069D, 0.97899D }, { 0.27273D, 0.5304D, 0.98461D }, { 0.27106D, 0.54015D, 0.9893D }, { 0.26878D, 0.54995D, 0.99303D }, { 0.26592D, 0.55979D, 0.99583D }, { 0.26252D, 0.56967D, 0.99773D }, { 0.25862D, 0.57958D, 0.99876D }, { 0.25425D, 0.5895D, 0.99896D }, { 0.24946D, 0.59943D, 0.99835D }, { 0.24427D, 0.60937D, 0.99697D }, { 0.23874D, 0.61931D, 0.99485D }, { 0.23288D, 0.62923D, 0.99202D }, { 0.22676D, 0.63913D, 0.98851D }, { 0.22039D, 0.64901D, 0.98436D }, { 0.21382D, 0.65886D, 0.97959D }, { 0.20708D, 0.66866D, 0.97423D }, { 0.20021D, 0.67842D, 0.96833D }, { 0.19326D, 0.68812D, 0.9619D }, { 0.18625D, 0.69775D, 0.95498D }, { 0.17923D, 0.70732D, 0.94761D }, { 0.17223D, 0.7168D, 0.93981D }, { 0.16529D, 0.7262D, 0.93161D }, { 0.15844D, 0.73551D, 0.92305D }, { 0.15173D, 0.74472D, 0.91416D }, { 0.14519D, 0.75381D, 0.90496D }, { 0.13886D, 0.76279D, 0.8955D }, { 0.13278D, 0.77165D, 0.8858D }, { 0.12698D, 0.78037D, 0.8759D }, { 0.12151D, 0.78896D, 0.86581D }, { 0.11639D, 0.7974D, 0.85559D }, { 0.11167D, 0.80569D, 0.84525D }, { 0.10738D, 0.81381D, 0.83484D }, { 0.10357D, 0.82177D, 0.82437D }, { 0.10026D, 0.82955D, 0.81389D }, { 0.0975D, 0.83714D, 0.80342D }, { 0.09532D, 0.84455D, 0.79299D }, { 0.09377D, 0.85175D, 0.78264D }, { 0.09287D, 0.85875D, 0.7724D }, { 0.09267D, 0.86554D, 0.7623D }, { 0.0932D, 0.87211D, 0.75237D }, { 0.09451D, 0.87844D, 0.74265D }, { 0.09662D, 0.88454D, 0.73316D }, { 0.09958D, 0.8904D, 0.72393D }, { 0.10342D, 0.896D, 0.715D }, { 0.10815D, 0.90142D, 0.70599D }, { 0.11374D, 0.90673D, 0.69651D }, { 0.12014D, 0.91193D, 0.6866D }, { 0.12733D, 0.91701D, 0.67627D }, { 0.13526D, 0.92197D, 0.66556D }, { 0.14391D, 0.9268D, 0.65448D }, { 0.15323D, 0.93151D, 0.64308D }, { 0.16319D, 0.93609D, 0.63137D }, { 0.17377D, 0.94053D, 0.61938D }, { 0.18491D, 0.94484D, 0.60713D }, { 0.19659D, 0.94901D, 0.59466D }, { 0.20877D, 0.95304D, 0.58199D }, { 0.22142D, 0.95692D, 0.56914D }, { 0.23449D, 0.96065D, 0.55614D }, { 0.24797D, 0.96423D, 0.54303D }, { 0.2618D, 0.96765D, 0.52981D }, { 0.27597D, 0.97092D, 0.51653D }, { 0.29042D, 0.97403D, 0.50321D }, { 0.30513D, 0.97697D, 0.48987D }, { 0.32006D, 0.97974D, 0.47654D }, { 0.33517D, 0.98234D, 0.46325D }, { 0.35043D, 0.98477D, 0.45002D }, { 0.36581D, 0.98702D, 0.43688D }, { 0.38127D, 0.98909D, 0.42386D }, { 0.39678D, 0.99098D, 0.41098D }, { 0.41229D, 0.99268D, 0.39826D }, { 0.42778D, 0.99419D, 0.38575D }, { 0.44321D, 0.99551D, 0.37345D }, { 0.45854D, 0.99663D, 0.3614D }, { 0.47375D, 0.99755D, 0.34963D }, { 0.48879D, 0.99828D, 0.33816D }, { 0.50362D, 0.99879D, 0.32701D }, { 0.51822D, 0.9991D, 0.31622D }, { 0.53255D, 0.99919D, 0.30581D }, { 0.54658D, 0.99907D, 0.29581D }, { 0.56026D, 0.99873D, 0.28623D }, { 0.57357D, 0.99817D, 0.27712D }, { 0.58646D, 0.99739D, 0.26849D }, { 0.59891D, 0.99638D, 0.26038D }, { 0.61088D, 0.99514D, 0.2528D }, { 0.62233D, 0.99366D, 0.24579D }, { 0.63323D, 0.99195D, 0.23937D }, { 0.64362D, 0.98999D, 0.23356D }, { 0.65394D, 0.98775D, 0.22835D }, { 0.66428D, 0.98524D, 0.2237D }, { 0.67462D, 0.98246D, 0.2196D }, { 0.68494D, 0.97941D, 0.21602D }, { 0.69525D, 0.9761D, 0.21294D }, { 0.70553D, 0.97255D, 0.21032D }, { 0.71577D, 0.96875D, 0.20815D }, { 0.72596D, 0.9647D, 0.2064D }, { 0.7361D, 0.96043D, 0.20504D }, { 0.74617D, 0.95593D, 0.20406D }, { 0.75617D, 0.95121D, 0.20343D }, { 0.76608D, 0.94627D, 0.20311D }, { 0.77591D, 0.94113D, 0.2031D }, { 0.78563D, 0.93579D, 0.20336D }, { 0.79524D, 0.93025D, 0.20386D }, { 0.80473D, 0.92452D, 0.20459D }, { 0.8141D, 0.91861D, 0.20552D }, { 0.82333D, 0.91253D, 0.20663D }, { 0.83241D, 0.90627D, 0.20788D }, { 0.84133D, 0.89986D, 0.20926D }, { 0.8501D, 0.89328D, 0.21074D }, { 0.85868D, 0.88655D, 0.2123D }, { 0.86709D, 0.87968D, 0.21391D }, { 0.8753D, 0.87267D, 0.21555D }, { 0.88331D, 0.86553D, 0.21719D }, { 0.89112D, 0.85826D, 0.2188D }, { 0.8987D, 0.85087D, 0.22038D }, { 0.90605D, 0.84337D, 0.22188D }, { 0.91317D, 0.83576D, 0.22328D }, { 0.92004D, 0.82806D, 0.22456D }, { 0.92666D, 0.82025D, 0.2257D }, { 0.93301D, 0.81236D, 0.22667D }, { 0.93909D, 0.80439D, 0.22744D }, { 0.94489D, 0.79634D, 0.228D }, { 0.95039D, 0.78823D, 0.22831D }, { 0.9556D, 0.78005D, 0.22836D }, { 0.96049D, 0.77181D, 0.22811D }, { 0.96507D, 0.76352D, 0.22754D }, { 0.96931D, 0.75519D, 0.22663D }, { 0.97323D, 0.74682D, 0.22536D }, { 0.97679D, 0.73842D, 0.22369D }, { 0.98D, 0.73D, 0.22161D }, { 0.98289D, 0.7214D, 0.21918D }, { 0.98549D, 0.7125D, 0.2165D }, { 0.98781D, 0.7033D, 0.21358D }, { 0.98986D, 0.69382D, 0.21043D }, { 0.99163D, 0.68408D, 0.20706D }, { 0.99314D, 0.67408D, 0.20348D }, { 0.99438D, 0.66386D, 0.19971D }, { 0.99535D, 0.65341D, 0.19577D }, { 0.99607D, 0.64277D, 0.19165D }, { 0.99654D, 0.63193D, 0.18738D }, { 0.99675D, 0.62093D, 0.18297D }, { 0.99672D, 0.60977D, 0.17842D }, { 0.99644D, 0.59846D, 0.17376D }, { 0.99593D, 0.58703D, 0.16899D }, { 0.99517D, 0.57549D, 0.16412D }, { 0.99419D, 0.56386D, 0.15918D }, { 0.99297D, 0.55214D, 0.15417D }, { 0.99153D, 0.54036D, 0.1491D }, { 0.98987D, 0.52854D, 0.14398D }, { 0.98799D, 0.51667D, 0.13883D }, { 0.9859D, 0.50479D, 0.13367D }, { 0.9836D, 0.49291D, 0.12849D }, { 0.98108D, 0.48104D, 0.12332D }, { 0.97837D, 0.4692D, 0.11817D }, { 0.97545D, 0.4574D, 0.11305D }, { 0.97234D, 0.44565D, 0.10797D }, { 0.96904D, 0.43399D, 0.10294D }, { 0.96555D, 0.42241D, 0.09798D }, { 0.96187D, 0.41093D, 0.0931D }, { 0.95801D, 0.39958D, 0.08831D }, { 0.95398D, 0.38836D, 0.08362D }, { 0.94977D, 0.37729D, 0.07905D }, { 0.94538D, 0.36638D, 0.07461D }, { 0.94084D, 0.35566D, 0.07031D }, { 0.93612D, 0.34513D, 0.06616D }, { 0.93125D, 0.33482D, 0.06218D }, { 0.92623D, 0.32473D, 0.05837D }, { 0.92105D, 0.31489D, 0.05475D }, { 0.91572D, 0.3053D, 0.05134D }, { 0.91024D, 0.29599D, 0.04814D }, { 0.90463D, 0.28696D, 0.04516D }, { 0.89888D, 0.27824D, 0.04243D }, { 0.89298D, 0.26981D, 0.03993D }, { 0.88691D, 0.26152D, 0.03753D }, { 0.88066D, 0.25334D, 0.03521D }, { 0.87422D, 0.24526D, 0.03297D }, { 0.8676D, 0.2373D, 0.03082D }, { 0.86079D, 0.22945D, 0.02875D }, { 0.8538D, 0.2217D, 0.02677D }, { 0.84662D, 0.21407D, 0.02487D }, { 0.83926D, 0.20654D, 0.02305D }, { 0.83172D, 0.19912D, 0.02131D }, { 0.82399D, 0.19182D, 0.01966D }, { 0.81608D, 0.18462D, 0.01809D }, { 0.80799D, 0.17753D, 0.0166D }, { 0.79971D, 0.17055D, 0.0152D }, { 0.79125D, 0.16368D, 0.01387D }, { 0.7826D, 0.15693D, 0.01264D }, { 0.77377D, 0.15028D, 0.01148D }, { 0.76476D, 0.14374D, 0.01041D }, { 0.75556D, 0.13731D, 0.00942D }, { 0.74617D, 0.13098D, 0.00851D }, { 0.73661D, 0.12477D, 0.00769D }, { 0.72686D, 0.11867D, 0.00695D }, { 0.71692D, 0.11268D, 0.00629D }, { 0.7068D, 0.1068D, 0.00571D }, { 0.6965D, 0.10102D, 0.00522D }, { 0.68602D, 0.09536D, 0.00481D }, { 0.67535D, 0.0898D, 0.00449D }, { 0.66449D, 0.08436D, 0.00424D }, { 0.65345D, 0.07902D, 0.00408D }, { 0.64223D, 0.0738D, 0.00401D }, { 0.63082D, 0.06868D, 0.00401D }, { 0.61923D, 0.06367D, 0.0041D }, { 0.60746D, 0.05878D, 0.00427D }, { 0.5955D, 0.05399D, 0.00453D }, { 0.58336D, 0.04931D, 0.00486D }, { 0.57103D, 0.04474D, 0.00529D }, { 0.55852D, 0.04028D, 0.00579D }, { 0.54583D, 0.03593D, 0.00638D }, { 0.53295D, 0.03169D, 0.00705D }, { 0.51989D, 0.02756D, 0.0078D }, { 0.50664D, 0.02354D, 0.00863D }, { 0.49321D, 0.01963D, 0.00955D }, { 0.4796D, 0.01583D, 0.01055D } };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 130 */   public static final Colormap Turbo = new Colormap("Turbo", 0.0D, 1.0D); private final String name; static {
/* 131 */     int nTriplets = triplets.length;
/* 132 */     for (int i = 0; i < nTriplets; i++) {
/*     */       
/* 134 */       double alpha = i / (nTriplets - 1.0D);
/* 135 */       double[] triplet = triplets[i];
/* 136 */       Turbo.add(alpha, new Color((float)triplet[0], (float)triplet[1], (float)triplet[2]));
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 143 */     List<Colormap> tmpLUTS = new ArrayList<>();
/* 144 */     tmpLUTS.add(Jet);
/* 145 */     tmpLUTS.add(Turbo);
/* 146 */     tmpLUTS.add(Viridis);
/* 147 */     tmpLUTS.addAll(ColormapIO.getLUTs());
/* 148 */     LUTS = Collections.unmodifiableList(tmpLUTS);
/*     */   }
/*     */   private static final List<Colormap> LUTS;
/*     */   
/*     */   public static List<Colormap> getAvailableLUTs() {
/* 153 */     return LUTS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Colormap(String name, double lowerBound, double upperBound, Color defaultColor) {
/* 166 */     this.name = name;
/* 167 */     this.lowerBound = lowerBound;
/* 168 */     this.upperBound = upperBound;
/* 169 */     this.defaultColor = defaultColor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Colormap(String name, double lowerBound, double upperBound) {
/* 178 */     this(name, lowerBound, upperBound, DEFAULT_COLOR);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Colormap(String name) {
/* 187 */     this(name, 0.0D, 1.0D);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/* 196 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void add(double value, Color color) {
/* 207 */     if (value > this.upperBound)
/*     */       return; 
/* 209 */     if (value < this.lowerBound)
/*     */       return; 
/* 211 */     this.colors.put(Double.valueOf(value), color);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public double getLowerBound() {
/* 217 */     return this.lowerBound;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Color getPaint(double value) {
/*     */     double alpha;
/* 228 */     if (this.colors.isEmpty())
/* 229 */       return this.defaultColor; 
/* 230 */     if (this.colors.size() == 1) {
/* 231 */       return this.colors.get(this.colors.firstKey());
/*     */     }
/* 233 */     if (value > this.upperBound)
/* 234 */       value = this.upperBound; 
/* 235 */     if (value < this.lowerBound)
/* 236 */       value = this.lowerBound; 
/* 237 */     Set<Double> keys = this.colors.keySet();
/* 238 */     double bottom = ((Double)this.colors.firstKey()).doubleValue();
/* 239 */     double top = ((Double)this.colors.lastKey()).doubleValue();
/* 240 */     for (Iterator<Double> iterator = keys.iterator(); iterator.hasNext(); ) { double key = ((Double)iterator.next()).doubleValue();
/*     */       
/* 242 */       top = key;
/* 243 */       if (value < key) {
/*     */         break;
/*     */       }
/* 246 */       bottom = top; }
/*     */ 
/*     */ 
/*     */     
/* 250 */     if (top == bottom) {
/* 251 */       alpha = 0.0D;
/*     */     } else {
/* 253 */       alpha = (value - bottom) / (top - bottom);
/*     */     } 
/* 255 */     Color colorBottom = this.colors.get(Double.valueOf(bottom));
/* 256 */     Color colorTop = this.colors.get(Double.valueOf(top));
/* 257 */     int red = (int)((1.0D - alpha) * colorBottom.getRed() + alpha * colorTop.getRed());
/* 258 */     int green = (int)((1.0D - alpha) * colorBottom.getGreen() + alpha * colorTop.getGreen());
/* 259 */     int blue = (int)((1.0D - alpha) * colorBottom.getBlue() + alpha * colorTop.getBlue());
/* 260 */     return new Color(red, green, blue);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public double getUpperBound() {
/* 266 */     return this.upperBound;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Colormap clone() {
/* 272 */     Colormap ips = new Colormap(this.name, this.lowerBound, this.upperBound);
/* 273 */     for (Iterator<Double> iterator = this.colors.keySet().iterator(); iterator.hasNext(); ) { double key = ((Double)iterator.next()).doubleValue();
/* 274 */       ips.add(key, this.colors.get(Double.valueOf(key))); }
/* 275 */      return ips;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void main(String[] args) {
/* 281 */     StringBuilder str = new StringBuilder();
/* 282 */     str.append("{ ");
/* 283 */     getAvailableLUTs().forEach(cm -> str.append('"' + cm.getName() + "\", "));
/* 284 */     str.deleteCharAt(str.length() - 1);
/* 285 */     str.deleteCharAt(str.length() - 1);
/* 286 */     str.append(" }");
/* 287 */     System.out.println(str);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/gui/displaysettings/Colormap.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */