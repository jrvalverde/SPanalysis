/*     */ package fiji.plugin.trackmate.gui.components;
/*     */ 
/*     */ import fiji.plugin.trackmate.Logger;
/*     */ import fiji.plugin.trackmate.Model;
/*     */ import fiji.plugin.trackmate.Settings;
/*     */ import fiji.plugin.trackmate.features.FeatureFilter;
/*     */ import fiji.plugin.trackmate.features.FeatureUtils;
/*     */ import fiji.plugin.trackmate.gui.Fonts;
/*     */ import fiji.plugin.trackmate.gui.GuiUtils;
/*     */ import fiji.plugin.trackmate.gui.Icons;
/*     */ import fiji.plugin.trackmate.gui.displaysettings.DisplaySettings;
/*     */ import fiji.plugin.trackmate.util.OnRequestUpdater;
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.EmptyStackException;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Stack;
/*     */ import java.util.function.Function;
/*     */ import javax.swing.BorderFactory;
/*     */ import javax.swing.Box;
/*     */ import javax.swing.BoxLayout;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JProgressBar;
/*     */ import javax.swing.JScrollPane;
/*     */ import javax.swing.SwingUtilities;
/*     */ import javax.swing.event.ChangeEvent;
/*     */ import javax.swing.event.ChangeListener;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FilterGuiPanel
/*     */   extends JPanel
/*     */   implements ChangeListener
/*     */ {
/*     */   private static final long serialVersionUID = -1L;
/*  72 */   private final ChangeEvent CHANGE_EVENT = new ChangeEvent(this);
/*     */   
/*  74 */   public ActionEvent COLOR_FEATURE_CHANGED = null;
/*     */   
/*     */   private final OnRequestUpdater updater;
/*     */   
/*  78 */   private final Stack<FilterPanel> filterPanels = new Stack<>();
/*     */   
/*  80 */   private final Stack<Component> struts = new Stack<>();
/*     */   
/*  82 */   private final List<FeatureFilter> featureFilters = new ArrayList<>();
/*     */   
/*  84 */   private final List<ChangeListener> changeListeners = new ArrayList<>();
/*     */ 
/*     */ 
/*     */   
/*     */   private final Model model;
/*     */ 
/*     */   
/*     */   private final JPanel allThresholdsPanel;
/*     */ 
/*     */   
/*     */   private final JLabel lblInfo;
/*     */ 
/*     */   
/*     */   private final DisplaySettings.TrackMateObject target;
/*     */ 
/*     */   
/*     */   private final Settings settings;
/*     */ 
/*     */   
/*     */   private final String defaultFeature;
/*     */ 
/*     */   
/*     */   private final ProgressBarLogger logger;
/*     */ 
/*     */   
/*     */   private final JLabel lblTop;
/*     */ 
/*     */   
/*     */   private final JProgressBar progressBar;
/*     */ 
/*     */ 
/*     */   
/*     */   public FilterGuiPanel(Model model, Settings settings, DisplaySettings.TrackMateObject target, List<FeatureFilter> filters, String defaultFeature, FeatureDisplaySelector featureSelector) {
/* 117 */     this.model = model;
/* 118 */     this.settings = settings;
/* 119 */     this.target = target;
/* 120 */     this.defaultFeature = defaultFeature;
/* 121 */     this.updater = new OnRequestUpdater(() -> refresh());
/*     */     
/* 123 */     setLayout(new BorderLayout());
/* 124 */     setPreferredSize(new Dimension(270, 500));
/*     */     
/* 126 */     JPanel topPanel = new JPanel();
/* 127 */     add(topPanel, "North");
/* 128 */     topPanel.setLayout(new BorderLayout(0, 0));
/*     */     
/* 130 */     this.lblTop = new JLabel("      Set filters on " + target);
/* 131 */     this.lblTop.setFont(Fonts.BIG_FONT);
/* 132 */     this.lblTop.setPreferredSize(new Dimension(300, 40));
/* 133 */     topPanel.add(this.lblTop, "North");
/*     */     
/* 135 */     this.progressBar = new JProgressBar();
/* 136 */     this.progressBar.setStringPainted(true);
/* 137 */     this.progressBar.setPreferredSize(new Dimension(1300, 40));
/* 138 */     topPanel.add(this.progressBar);
/*     */     
/* 140 */     JScrollPane scrollPaneThresholds = new JScrollPane();
/* 141 */     add(scrollPaneThresholds, "Center");
/* 142 */     scrollPaneThresholds.setPreferredSize(new Dimension(250, 389));
/* 143 */     scrollPaneThresholds.setHorizontalScrollBarPolicy(31);
/* 144 */     scrollPaneThresholds.setVerticalScrollBarPolicy(22);
/*     */     
/* 146 */     this.allThresholdsPanel = new JPanel();
/* 147 */     BoxLayout jPanelAllThresholdsLayout = new BoxLayout(this.allThresholdsPanel, 1);
/* 148 */     this.allThresholdsPanel.setLayout(jPanelAllThresholdsLayout);
/* 149 */     scrollPaneThresholds.setViewportView(this.allThresholdsPanel);
/*     */     
/* 151 */     JPanel bottomPanel = new JPanel();
/* 152 */     bottomPanel.setLayout(new BorderLayout());
/* 153 */     add(bottomPanel, "South");
/*     */     
/* 155 */     JPanel buttonsPanel = new JPanel();
/* 156 */     bottomPanel.add(buttonsPanel, "North");
/* 157 */     BoxLayout jPanelButtonsLayout = new BoxLayout(buttonsPanel, 0);
/* 158 */     buttonsPanel.setLayout(jPanelButtonsLayout);
/* 159 */     buttonsPanel.setPreferredSize(new Dimension(270, 22));
/* 160 */     buttonsPanel.setSize(270, 25);
/* 161 */     buttonsPanel.setMaximumSize(new Dimension(32767, 25));
/*     */     
/* 163 */     buttonsPanel.add(Box.createHorizontalStrut(5));
/* 164 */     JButton btnAddThreshold = new JButton();
/* 165 */     buttonsPanel.add(btnAddThreshold);
/* 166 */     btnAddThreshold.setIcon(Icons.ADD_ICON);
/* 167 */     btnAddThreshold.setFont(Fonts.SMALL_FONT);
/* 168 */     btnAddThreshold.setPreferredSize(new Dimension(24, 24));
/* 169 */     btnAddThreshold.setSize(24, 24);
/* 170 */     btnAddThreshold.setMinimumSize(new Dimension(24, 24));
/*     */     
/* 172 */     buttonsPanel.add(Box.createHorizontalStrut(5));
/* 173 */     JButton btnRemoveThreshold = new JButton();
/* 174 */     buttonsPanel.add(btnRemoveThreshold);
/* 175 */     btnRemoveThreshold.setIcon(Icons.REMOVE_ICON);
/* 176 */     btnRemoveThreshold.setFont(Fonts.SMALL_FONT);
/* 177 */     btnRemoveThreshold.setPreferredSize(new Dimension(24, 24));
/* 178 */     btnRemoveThreshold.setSize(24, 24);
/* 179 */     btnRemoveThreshold.setMinimumSize(new Dimension(24, 24));
/*     */     
/* 181 */     buttonsPanel.add(Box.createHorizontalGlue());
/* 182 */     buttonsPanel.add(Box.createHorizontalStrut(5));
/*     */     
/* 184 */     this.lblInfo = new JLabel();
/* 185 */     this.lblInfo.setFont(Fonts.SMALL_FONT);
/* 186 */     buttonsPanel.add(this.lblInfo);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 192 */     JPanel coloringPanel = featureSelector.createSelectorFor(target);
/* 193 */     coloringPanel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
/* 194 */     bottomPanel.add(coloringPanel, "Center");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 200 */     btnAddThreshold.addActionListener(e -> addFilterPanel());
/* 201 */     btnRemoveThreshold.addActionListener(e -> removeThresholdPanel());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 207 */     for (FeatureFilter ft : filters) {
/* 208 */       addFilterPanel(ft);
/*     */     }
/* 210 */     this.lblTop.setVisible(false);
/* 211 */     this.logger = new ProgressBarLogger();
/*     */ 
/*     */     
/* 214 */     GuiUtils.addOnClosingEvent(this, () -> this.updater.quit());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void refreshValues() {
/* 226 */     for (FilterPanel filterPanel : this.filterPanels) {
/* 227 */       filterPanel.refresh();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void stateChanged(ChangeEvent e) {
/* 237 */     this.updater.doUpdate();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<FeatureFilter> getFeatureFilters() {
/* 245 */     return this.featureFilters;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addChangeListener(ChangeListener listener) {
/* 256 */     this.changeListeners.add(listener);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean removeChangeListener(ChangeListener listener) {
/* 266 */     return this.changeListeners.remove(listener);
/*     */   }
/*     */ 
/*     */   
/*     */   public Collection<ChangeListener> getChangeListeners() {
/* 271 */     return this.changeListeners;
/*     */   }
/*     */ 
/*     */   
/*     */   public void addFilterPanel() {
/* 276 */     addFilterPanel(guessNextFeature());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void addFilterPanel(String feature) {
/* 282 */     FeatureFilter filter = new FeatureFilter(feature, Double.NaN, true);
/* 283 */     addFilterPanel(filter);
/*     */   }
/*     */ 
/*     */   
/*     */   public void addFilterPanel(FeatureFilter filter) {
/* 288 */     Map<String, String> featureNames = FeatureUtils.collectFeatureKeys(this.target, this.model, this.settings);
/* 289 */     Function<String, double[]> valueCollector = featureKey -> FeatureUtils.collectFeatureValues(featureKey, this.target, this.model, false);
/* 290 */     FilterPanel tp = new FilterPanel(featureNames, valueCollector, filter);
/*     */     
/* 292 */     tp.addChangeListener(this);
/* 293 */     Component strut = Box.createVerticalStrut(5);
/* 294 */     this.struts.push(strut);
/* 295 */     this.filterPanels.push(tp);
/* 296 */     this.allThresholdsPanel.add(tp);
/* 297 */     this.allThresholdsPanel.add(strut);
/* 298 */     this.allThresholdsPanel.revalidate();
/* 299 */     stateChanged(this.CHANGE_EVENT);
/*     */   }
/*     */ 
/*     */   
/*     */   public void showProgressBar(boolean show) {
/* 304 */     this.progressBar.setVisible(show);
/* 305 */     this.lblTop.setVisible(!show);
/*     */   }
/*     */ 
/*     */   
/*     */   public Logger getLogger() {
/* 310 */     return this.logger;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void fireThresholdChanged(ChangeEvent e) {
/* 325 */     for (ChangeListener cl : this.changeListeners) {
/* 326 */       cl.stateChanged(e);
/*     */     }
/*     */   }
/*     */   
/*     */   private String guessNextFeature() {
/* 331 */     Map<String, String> featureNames = FeatureUtils.collectFeatureKeys(this.target, this.model, this.settings);
/* 332 */     Iterator<String> it = featureNames.keySet().iterator();
/* 333 */     if (!it.hasNext()) {
/* 334 */       return "";
/*     */     }
/* 336 */     if (this.featureFilters.isEmpty()) {
/* 337 */       return (this.defaultFeature == null || !featureNames.keySet().contains(this.defaultFeature)) ? it.next() : this.defaultFeature;
/*     */     }
/* 339 */     FeatureFilter lastFilter = this.featureFilters.get(this.featureFilters.size() - 1);
/* 340 */     String lastFeature = lastFilter.feature;
/* 341 */     while (it.hasNext()) {
/* 342 */       if (((String)it.next()).equals(lastFeature) && it.hasNext())
/* 343 */         return it.next(); 
/*     */     } 
/* 345 */     return featureNames.keySet().iterator().next();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void removeThresholdPanel() {
/*     */     try {
/* 352 */       FilterPanel tp = this.filterPanels.pop();
/* 353 */       tp.removeChangeListener(this);
/* 354 */       Component strut = this.struts.pop();
/* 355 */       this.allThresholdsPanel.remove(strut);
/* 356 */       this.allThresholdsPanel.remove(tp);
/* 357 */       this.allThresholdsPanel.repaint();
/* 358 */       stateChanged(this.CHANGE_EVENT);
/*     */     }
/* 360 */     catch (EmptyStackException emptyStackException) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void refresh() {
/* 370 */     this.featureFilters.clear();
/* 371 */     for (FilterPanel tp : this.filterPanels) {
/* 372 */       this.featureFilters.add(tp.getFilter());
/*     */     }
/* 374 */     fireThresholdChanged((ChangeEvent)null);
/* 375 */     updateInfoText();
/*     */   }
/*     */ 
/*     */   
/*     */   private void updateInfoText() {
/* 380 */     Map<String, String> featureNames = FeatureUtils.collectFeatureKeys(this.target, this.model, this.settings);
/* 381 */     if (featureNames.isEmpty()) {
/*     */       
/* 383 */       this.lblInfo.setText("No features found.");
/*     */       
/*     */       return;
/*     */     } 
/* 387 */     int nobjects = FeatureUtils.nObjects(this.model, this.target, false);
/* 388 */     if (this.featureFilters == null || this.featureFilters.isEmpty()) {
/*     */       
/* 390 */       String str = "Keep all " + nobjects + " " + this.target + ".";
/* 391 */       this.lblInfo.setText(str);
/*     */       
/*     */       return;
/*     */     } 
/* 395 */     int nselected = FeatureUtils.nObjects(this.model, this.target, true);
/* 396 */     String info = "Keep " + nselected + " " + this.target + " out of  " + nobjects + ".";
/* 397 */     this.lblInfo.setText(info);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private final class ProgressBarLogger
/*     */     extends Logger
/*     */   {
/*     */     private ProgressBarLogger() {}
/*     */ 
/*     */ 
/*     */     
/*     */     public void error(String message) {
/* 410 */       log(message, Logger.ERROR_COLOR);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void log(String message, Color color) {
/* 416 */       SwingUtilities.invokeLater(() -> FilterGuiPanel.this.progressBar.setString(message));
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void setStatus(String status) {
/* 422 */       SwingUtilities.invokeLater(() -> FilterGuiPanel.this.progressBar.setString(status));
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void setProgress(double val) {
/* 428 */       if (val < 0.0D)
/* 429 */         val = 0.0D; 
/* 430 */       if (val > 1.0D)
/* 431 */         val = 1.0D; 
/* 432 */       int intVal = (int)(val * 100.0D);
/* 433 */       SwingUtilities.invokeLater(() -> FilterGuiPanel.this.progressBar.setValue(intVal));
/*     */     }
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/gui/components/FilterGuiPanel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */