/*     */ package fiji.plugin.trackmate.features.track;
/*     */ 
/*     */ import fiji.plugin.trackmate.Dimension;
/*     */ import fiji.plugin.trackmate.FeatureModel;
/*     */ import fiji.plugin.trackmate.Model;
/*     */ import fiji.plugin.trackmate.Spot;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import net.imglib2.RealLocalizable;
/*     */ import org.scijava.plugin.Plugin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Plugin(type = TrackAnalyzer.class)
/*     */ public class TrackDurationAnalyzer
/*     */   extends AbstractTrackAnalyzer
/*     */ {
/*     */   public static final String KEY = "Track duration";
/*     */   public static final String TRACK_DURATION = "TRACK_DURATION";
/*     */   public static final String TRACK_START = "TRACK_START";
/*     */   public static final String TRACK_STOP = "TRACK_STOP";
/*     */   public static final String TRACK_DISPLACEMENT = "TRACK_DISPLACEMENT";
/*  47 */   public static final List<String> FEATURES = new ArrayList<>(4);
/*  48 */   public static final Map<String, String> FEATURE_NAMES = new HashMap<>(4);
/*  49 */   public static final Map<String, String> FEATURE_SHORT_NAMES = new HashMap<>(4);
/*  50 */   public static final Map<String, Dimension> FEATURE_DIMENSIONS = new HashMap<>(4);
/*  51 */   public static final Map<String, Boolean> IS_INT = new HashMap<>(4);
/*     */ 
/*     */   
/*     */   static {
/*  55 */     FEATURES.add("TRACK_DURATION");
/*  56 */     FEATURES.add("TRACK_START");
/*  57 */     FEATURES.add("TRACK_STOP");
/*  58 */     FEATURES.add("TRACK_DISPLACEMENT");
/*     */     
/*  60 */     FEATURE_NAMES.put("TRACK_DURATION", "Track duration");
/*  61 */     FEATURE_NAMES.put("TRACK_START", "Track start");
/*  62 */     FEATURE_NAMES.put("TRACK_STOP", "Track stop");
/*  63 */     FEATURE_NAMES.put("TRACK_DISPLACEMENT", "Track displacement");
/*     */     
/*  65 */     FEATURE_SHORT_NAMES.put("TRACK_DURATION", "Duration");
/*  66 */     FEATURE_SHORT_NAMES.put("TRACK_START", "Track start");
/*  67 */     FEATURE_SHORT_NAMES.put("TRACK_STOP", "Track stop");
/*  68 */     FEATURE_SHORT_NAMES.put("TRACK_DISPLACEMENT", "Track disp.");
/*     */     
/*  70 */     FEATURE_DIMENSIONS.put("TRACK_DURATION", Dimension.TIME);
/*  71 */     FEATURE_DIMENSIONS.put("TRACK_START", Dimension.TIME);
/*  72 */     FEATURE_DIMENSIONS.put("TRACK_STOP", Dimension.TIME);
/*  73 */     FEATURE_DIMENSIONS.put("TRACK_DISPLACEMENT", Dimension.LENGTH);
/*     */     
/*  75 */     IS_INT.put("TRACK_DURATION", Boolean.FALSE);
/*  76 */     IS_INT.put("TRACK_START", Boolean.FALSE);
/*  77 */     IS_INT.put("TRACK_STOP", Boolean.FALSE);
/*  78 */     IS_INT.put("TRACK_DISPLACEMENT", Boolean.FALSE);
/*     */   }
/*     */ 
/*     */   
/*     */   public TrackDurationAnalyzer() {
/*  83 */     super("Track duration", "Track duration", FEATURES, FEATURE_NAMES, FEATURE_SHORT_NAMES, FEATURE_DIMENSIONS, IS_INT);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void analyze(Integer trackID, Model model) {
/*  89 */     FeatureModel fm = model.getFeatureModel();
/*     */ 
/*     */     
/*  92 */     Set<Spot> track = model.getTrackModel().trackSpots(trackID);
/*  93 */     double minT = Double.POSITIVE_INFINITY;
/*  94 */     double maxT = Double.NEGATIVE_INFINITY;
/*     */     
/*  96 */     Spot startSpot = null;
/*  97 */     Spot endSpot = null;
/*  98 */     for (Spot spot : track) {
/*     */       
/* 100 */       Double t = spot.getFeature("POSITION_T");
/* 101 */       if (t.doubleValue() < minT) {
/*     */         
/* 103 */         minT = t.doubleValue();
/* 104 */         startSpot = spot;
/*     */       } 
/* 106 */       if (t.doubleValue() > maxT) {
/*     */         
/* 108 */         maxT = t.doubleValue();
/* 109 */         endSpot = spot;
/*     */       } 
/*     */     } 
/* 112 */     if (null == startSpot || null == endSpot) {
/*     */       return;
/*     */     }
/* 115 */     fm.putTrackFeature(trackID, "TRACK_DURATION", Double.valueOf(maxT - minT));
/* 116 */     fm.putTrackFeature(trackID, "TRACK_START", Double.valueOf(minT));
/* 117 */     fm.putTrackFeature(trackID, "TRACK_STOP", Double.valueOf(maxT));
/* 118 */     fm.putTrackFeature(trackID, "TRACK_DISPLACEMENT", Double.valueOf(Math.sqrt(startSpot.squareDistanceTo((RealLocalizable)endSpot))));
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/features/track/TrackDurationAnalyzer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */