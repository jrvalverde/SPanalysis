/*    */ package fiji.plugin.trackmate.graph;
/*    */ 
/*    */ import fiji.plugin.trackmate.Spot;
/*    */ import java.util.Comparator;
/*    */ import org.jgrapht.Graph;
/*    */ import org.jgrapht.Graphs;
/*    */ import org.jgrapht.graph.DefaultWeightedEdge;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TimeDirectedDepthFirstIterator
/*    */   extends SortedDepthFirstIterator<Spot, DefaultWeightedEdge>
/*    */ {
/*    */   public TimeDirectedDepthFirstIterator(Graph<Spot, DefaultWeightedEdge> g, Spot startVertex) {
/* 36 */     super(g, startVertex, (Comparator<Spot>)null);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected void addUnseenChildrenOf(Spot vertex) {
/* 42 */     int ts = vertex.getFeature("FRAME").intValue();
/* 43 */     for (DefaultWeightedEdge edge : this.specifics.edgesOf(vertex)) {
/* 44 */       if (this.nListeners != 0) {
/* 45 */         fireEdgeTraversed(createEdgeTraversalEvent(edge));
/*    */       }
/*    */       
/* 48 */       Spot oppositeV = (Spot)Graphs.getOppositeVertex(this.graph, edge, vertex);
/* 49 */       int tt = oppositeV.getFeature("FRAME").intValue();
/* 50 */       if (tt <= ts) {
/*    */         continue;
/*    */       }
/*    */       
/* 54 */       if (this.seen.containsKey(oppositeV)) {
/* 55 */         encounterVertexAgain(oppositeV, edge); continue;
/*    */       } 
/* 57 */       encounterVertex(oppositeV, edge);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/graph/TimeDirectedDepthFirstIterator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */