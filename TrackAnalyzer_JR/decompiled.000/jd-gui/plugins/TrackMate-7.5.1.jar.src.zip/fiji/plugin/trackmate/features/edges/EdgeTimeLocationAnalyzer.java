/*     */ package fiji.plugin.trackmate.features.edges;
/*     */ 
/*     */ import fiji.plugin.trackmate.Dimension;
/*     */ import fiji.plugin.trackmate.FeatureModel;
/*     */ import fiji.plugin.trackmate.Model;
/*     */ import fiji.plugin.trackmate.Spot;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.jgrapht.graph.DefaultWeightedEdge;
/*     */ import org.scijava.plugin.Plugin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Plugin(type = EdgeAnalyzer.class)
/*     */ public class EdgeTimeLocationAnalyzer
/*     */   extends AbstractEdgeAnalyzer
/*     */ {
/*     */   public static final String KEY = "Edge location";
/*     */   public static final String TIME = "EDGE_TIME";
/*     */   public static final String X_LOCATION = "EDGE_X_LOCATION";
/*     */   public static final String Y_LOCATION = "EDGE_Y_LOCATION";
/*     */   public static final String Z_LOCATION = "EDGE_Z_LOCATION";
/*  47 */   public static final List<String> FEATURES = new ArrayList<>(4);
/*  48 */   public static final Map<String, String> FEATURE_NAMES = new HashMap<>(4);
/*  49 */   public static final Map<String, String> FEATURE_SHORT_NAMES = new HashMap<>(4);
/*  50 */   public static final Map<String, Dimension> FEATURE_DIMENSIONS = new HashMap<>(4);
/*  51 */   public static final Map<String, Boolean> IS_INT = new HashMap<>(4);
/*     */ 
/*     */   
/*     */   static {
/*  55 */     FEATURES.add("EDGE_TIME");
/*  56 */     FEATURES.add("EDGE_X_LOCATION");
/*  57 */     FEATURES.add("EDGE_Y_LOCATION");
/*  58 */     FEATURES.add("EDGE_Z_LOCATION");
/*     */     
/*  60 */     FEATURE_NAMES.put("EDGE_TIME", "Edge time");
/*  61 */     FEATURE_NAMES.put("EDGE_X_LOCATION", "Edge X");
/*  62 */     FEATURE_NAMES.put("EDGE_Y_LOCATION", "Edge Y");
/*  63 */     FEATURE_NAMES.put("EDGE_Z_LOCATION", "Edge Z");
/*     */     
/*  65 */     FEATURE_SHORT_NAMES.put("EDGE_TIME", "Edge T");
/*  66 */     FEATURE_SHORT_NAMES.put("EDGE_X_LOCATION", "Edge X");
/*  67 */     FEATURE_SHORT_NAMES.put("EDGE_Y_LOCATION", "Edge Y");
/*  68 */     FEATURE_SHORT_NAMES.put("EDGE_Z_LOCATION", "Edge Z");
/*     */     
/*  70 */     FEATURE_DIMENSIONS.put("EDGE_TIME", Dimension.TIME);
/*  71 */     FEATURE_DIMENSIONS.put("EDGE_X_LOCATION", Dimension.POSITION);
/*  72 */     FEATURE_DIMENSIONS.put("EDGE_Y_LOCATION", Dimension.POSITION);
/*  73 */     FEATURE_DIMENSIONS.put("EDGE_Z_LOCATION", Dimension.POSITION);
/*     */     
/*  75 */     IS_INT.put("EDGE_TIME", Boolean.FALSE);
/*  76 */     IS_INT.put("EDGE_X_LOCATION", Boolean.FALSE);
/*  77 */     IS_INT.put("EDGE_Y_LOCATION", Boolean.FALSE);
/*  78 */     IS_INT.put("EDGE_Z_LOCATION", Boolean.FALSE);
/*     */   }
/*     */ 
/*     */   
/*     */   public EdgeTimeLocationAnalyzer() {
/*  83 */     super("Edge location", "Edge location", FEATURES, FEATURE_NAMES, FEATURE_SHORT_NAMES, FEATURE_DIMENSIONS, IS_INT);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void analyze(DefaultWeightedEdge edge, Model model) {
/*  89 */     FeatureModel featureModel = model.getFeatureModel();
/*  90 */     Spot source = model.getTrackModel().getEdgeSource(edge);
/*  91 */     Spot target = model.getTrackModel().getEdgeTarget(edge);
/*     */     
/*  93 */     double x = 0.5D * (source.getFeature("POSITION_X").doubleValue() + target.getFeature("POSITION_X").doubleValue());
/*  94 */     double y = 0.5D * (source.getFeature("POSITION_Y").doubleValue() + target.getFeature("POSITION_Y").doubleValue());
/*  95 */     double z = 0.5D * (source.getFeature("POSITION_Z").doubleValue() + target.getFeature("POSITION_Z").doubleValue());
/*  96 */     double t = 0.5D * (source.getFeature("POSITION_T").doubleValue() + target.getFeature("POSITION_T").doubleValue());
/*     */     
/*  98 */     featureModel.putEdgeFeature(edge, "EDGE_TIME", Double.valueOf(t));
/*  99 */     featureModel.putEdgeFeature(edge, "EDGE_X_LOCATION", Double.valueOf(x));
/* 100 */     featureModel.putEdgeFeature(edge, "EDGE_Y_LOCATION", Double.valueOf(y));
/* 101 */     featureModel.putEdgeFeature(edge, "EDGE_Z_LOCATION", Double.valueOf(z));
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/features/edges/EdgeTimeLocationAnalyzer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */