/*     */ package fiji.plugin.trackmate.action.fit;
/*     */ 
/*     */ import fiji.plugin.trackmate.Logger;
/*     */ import fiji.plugin.trackmate.Spot;
/*     */ import fiji.plugin.trackmate.detection.DetectionUtils;
/*     */ import ij.ImagePlus;
/*     */ import net.imglib2.Point;
/*     */ import net.imglib2.util.Util;
/*     */ import org.apache.commons.math3.exception.TooManyEvaluationsException;
/*     */ import org.apache.commons.math3.fitting.leastsquares.LeastSquaresBuilder;
/*     */ import org.apache.commons.math3.fitting.leastsquares.LeastSquaresOptimizer;
/*     */ import org.apache.commons.math3.fitting.leastsquares.LeastSquaresProblem;
/*     */ import org.apache.commons.math3.fitting.leastsquares.MultivariateJacobianFunction;
/*     */ import org.apache.commons.math3.fitting.leastsquares.ParameterValidator;
/*     */ import org.apache.commons.math3.linear.Array2DRowRealMatrix;
/*     */ import org.apache.commons.math3.linear.ArrayRealVector;
/*     */ import org.apache.commons.math3.linear.RealMatrix;
/*     */ import org.apache.commons.math3.linear.RealVector;
/*     */ import org.apache.commons.math3.util.Pair;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SpotGaussianFitter3D
/*     */   extends AbstractSpotFitter
/*     */ {
/*     */   public SpotGaussianFitter3D(ImagePlus imp, int channel) {
/*  51 */     super(imp, channel);
/*  52 */     assert !DetectionUtils.is2D(imp);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void process(Iterable<Spot> spots, Logger logger) {
/*  58 */     super.process(spots, logger);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void fit(Spot spot) {
/*  64 */     int frame = spot.getFeature("FRAME").intValue();
/*  65 */     double sigma = spot.getFeature("RADIUS").doubleValue() / Math.sqrt(2.0D);
/*  66 */     double pixelSigmaXY = sigma / this.calibration[0];
/*  67 */     double pixelSigmaZ = sigma / this.calibration[2];
/*  68 */     double x0 = spot.getDoublePosition(0) / this.calibration[0];
/*  69 */     double y0 = spot.getDoublePosition(1) / this.calibration[1];
/*  70 */     double z0 = spot.getDoublePosition(2) / this.calibration[2];
/*  71 */     long spanXY = (long)Math.ceil(2.0D * pixelSigmaXY) + 1L;
/*  72 */     long spanZ = (long)Math.ceil(2.0D * pixelSigmaZ) + 1L;
/*  73 */     AbstractSpotFitter.Observation obs = gatherObservationData(new Point(new long[] {
/*     */             
/*  75 */             Math.round(x0), 
/*  76 */             Math.round(y0), 
/*  77 */             Math.round(z0) }, ), new long[] { spanXY, spanXY, spanZ }, frame);
/*     */ 
/*     */     
/*  80 */     clipBackground(obs);
/*     */     
/*  82 */     double bstartXY = 1.0D / 2.0D * pixelSigmaXY * pixelSigmaXY;
/*  83 */     double maxSigmaXY = 2.0D * pixelSigmaXY;
/*  84 */     double minBxy = 1.0D / 2.0D * maxSigmaXY * maxSigmaXY;
/*  85 */     double bstartZ = 1.0D / 2.0D * pixelSigmaZ * pixelSigmaZ;
/*  86 */     double maxSigmaZ = 2.0D * pixelSigmaZ;
/*  87 */     double minBz = 1.0D / 2.0D * maxSigmaZ * maxSigmaZ;
/*  88 */     MyGaussian3D gauss = new MyGaussian3D(obs.pos, minBxy, minBz);
/*  89 */     double ampstart = Util.max(obs.values);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  98 */     LeastSquaresProblem lsq = (new LeastSquaresBuilder()).start(new double[] { x0, y0, z0, ampstart, bstartXY, bstartZ }).model(gauss).parameterValidator(gauss).target(obs.values).lazyEvaluation(false).maxEvaluations(1000).maxIterations(1000).build();
/*     */ 
/*     */     
/*     */     try {
/* 102 */       LeastSquaresOptimizer.Optimum optimum = this.optimizer.optimize(lsq);
/* 103 */       RealVector fit = optimum.getPoint();
/*     */       
/* 105 */       double fitX = fit.getEntry(0) * this.calibration[0];
/* 106 */       double fitY = fit.getEntry(1) * this.calibration[1];
/* 107 */       double fitZ = fit.getEntry(2) * this.calibration[2];
/* 108 */       double fitSigmaXY = 1.0D / Math.sqrt(2.0D * fit.getEntry(4));
/* 109 */       double fitRadiusXY = fitSigmaXY * Math.sqrt(2.0D) * this.calibration[0];
/*     */       
/* 111 */       spot.putFeature("POSITION_X", Double.valueOf(fitX));
/* 112 */       spot.putFeature("POSITION_Y", Double.valueOf(fitY));
/* 113 */       spot.putFeature("POSITION_Z", Double.valueOf(fitZ));
/* 114 */       spot.putFeature("RADIUS", Double.valueOf(fitRadiusXY));
/*     */     }
/* 116 */     catch (TooManyEvaluationsException tooManyEvaluationsException) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class MyGaussian3D
/*     */     implements MultivariateJacobianFunction, ParameterValidator
/*     */   {
/*     */     private final long[][] pos;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final double minBxy;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final double minBz;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public MyGaussian3D(long[][] pos, double minBxy, double minBz) {
/* 144 */       this.pos = pos;
/* 145 */       this.minBxy = minBxy;
/* 146 */       this.minBz = minBz;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Pair<RealVector, RealMatrix> value(RealVector point) {
/* 153 */       double x0 = point.getEntry(0);
/* 154 */       double y0 = point.getEntry(1);
/* 155 */       double z0 = point.getEntry(2);
/* 156 */       double A = point.getEntry(3);
/* 157 */       double bXY = point.getEntry(4);
/* 158 */       double bZ = point.getEntry(5);
/*     */ 
/*     */       
/* 161 */       double[] vals = new double[(this.pos[0]).length];
/* 162 */       double[][] grad = new double[(this.pos[0]).length][6];
/* 163 */       for (int i = 0; i < vals.length; i++) {
/*     */         
/* 165 */         long x = this.pos[0][i];
/* 166 */         long y = this.pos[1][i];
/* 167 */         long z = this.pos[2][i];
/* 168 */         double dx = x - x0;
/* 169 */         double dy = y - y0;
/* 170 */         double dz = z - z0;
/* 171 */         double sumSq = -bXY * (dx * dx + dy * dy) - bZ * dz * dz;
/* 172 */         double E = Math.exp(sumSq);
/* 173 */         vals[i] = A * E;
/*     */ 
/*     */         
/* 176 */         grad[i][0] = A * bXY * E * 2.0D * dx;
/*     */         
/* 178 */         grad[i][1] = A * bXY * E * 2.0D * dy;
/*     */         
/* 180 */         grad[i][2] = A * bZ * E * 2.0D * dz;
/*     */         
/* 182 */         grad[i][3] = E;
/*     */         
/* 184 */         grad[i][4] = -A * E * (dx * dx + dy * dy);
/*     */         
/* 186 */         grad[i][5] = -A * E * dz * dz;
/*     */       } 
/* 188 */       ArrayRealVector out = new ArrayRealVector(vals);
/* 189 */       Array2DRowRealMatrix jacobian = new Array2DRowRealMatrix(grad, false);
/* 190 */       return new Pair(out, jacobian);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public RealVector validate(RealVector params) {
/* 196 */       params.setEntry(3, Math.abs(params.getEntry(3)));
/* 197 */       double bXY = Math.max(this.minBxy, Math.abs(params.getEntry(4)));
/* 198 */       params.setEntry(4, bXY);
/* 199 */       double bZ = Math.max(this.minBz, Math.abs(params.getEntry(5)));
/* 200 */       params.setEntry(5, bZ);
/* 201 */       return params;
/*     */     }
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/action/fit/SpotGaussianFitter3D.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */