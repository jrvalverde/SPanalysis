package fiji.plugin.trackmate.action.fit;

import fiji.plugin.trackmate.Logger;
import fiji.plugin.trackmate.Spot;
import net.imglib2.algorithm.Benchmark;
import net.imglib2.algorithm.MultiThreaded;

public interface SpotFitter extends MultiThreaded, Benchmark {
  void process(Iterable<Spot> paramIterable, Logger paramLogger);
  
  void fit(Spot paramSpot);
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/action/fit/SpotFitter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */