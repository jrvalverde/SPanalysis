/*     */ package fiji.plugin.trackmate.visualization.trackscheme;
/*     */ 
/*     */ import fiji.plugin.trackmate.FeatureModel;
/*     */ import fiji.plugin.trackmate.Model;
/*     */ import fiji.plugin.trackmate.SelectionChangeEvent;
/*     */ import fiji.plugin.trackmate.SelectionChangeListener;
/*     */ import fiji.plugin.trackmate.SelectionModel;
/*     */ import fiji.plugin.trackmate.Spot;
/*     */ import fiji.plugin.trackmate.gui.Fonts;
/*     */ import fiji.plugin.trackmate.util.OnRequestUpdater;
/*     */ import fiji.plugin.trackmate.util.TMUtils;
/*     */ import ij.measure.ResultsTable;
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.FontMetrics;
/*     */ import java.awt.Point;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.event.MouseAdapter;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.swing.AbstractListModel;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JList;
/*     */ import javax.swing.JMenuItem;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JPopupMenu;
/*     */ import javax.swing.JScrollPane;
/*     */ import javax.swing.JTable;
/*     */ import javax.swing.ListCellRenderer;
/*     */ import javax.swing.SwingUtilities;
/*     */ import javax.swing.UIManager;
/*     */ import javax.swing.event.AncestorEvent;
/*     */ import javax.swing.event.AncestorListener;
/*     */ import javax.swing.table.DefaultTableCellRenderer;
/*     */ import javax.swing.table.DefaultTableModel;
/*     */ import javax.swing.table.JTableHeader;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class InfoPane
/*     */   extends JPanel
/*     */   implements SelectionChangeListener
/*     */ {
/*     */   private static final long serialVersionUID = -1L;
/*     */   private JTable table;
/*     */   private JScrollPane scrollTable;
/*     */   private final boolean doHighlightSelection = true;
/*     */   private final Model model;
/*     */   private final SelectionModel selectionModel;
/*     */   private Collection<Spot> spotSelection;
/*     */   private final OnRequestUpdater updater;
/*     */   private final String[] headers;
/*     */   
/*     */   public InfoPane(Model model, SelectionModel selectionModel) {
/* 114 */     this.model = model;
/* 115 */     this.selectionModel = selectionModel;
/* 116 */     List<String> features = new ArrayList<>(model.getFeatureModel().getSpotFeatures());
/* 117 */     Map<String, String> featureNames = model.getFeatureModel().getSpotFeatureShortNames();
/* 118 */     List<String> headerList = TMUtils.getArrayFromMaping(features, featureNames);
/* 119 */     headerList.add(0, "Track ID");
/* 120 */     this.headers = headerList.<String>toArray(new String[0]);
/*     */     
/* 122 */     this.updater = new OnRequestUpdater(new OnRequestUpdater.Refreshable()
/*     */         {
/*     */           
/*     */           public void refresh()
/*     */           {
/* 127 */             SwingUtilities.invokeLater(new Runnable()
/*     */                 {
/*     */                   
/*     */                   public void run()
/*     */                   {
/* 132 */                     InfoPane.this.update();
/*     */                   }
/*     */                 });
/*     */           }
/*     */         });
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 141 */     addAncestorListener(new AncestorListener()
/*     */         {
/*     */           
/*     */           public void ancestorRemoved(AncestorEvent event)
/*     */           {
/* 146 */             InfoPane.this.selectionModel.removeSelectionChangeListener(InfoPane.this);
/*     */           }
/*     */ 
/*     */ 
/*     */           
/*     */           public void ancestorMoved(AncestorEvent event) {}
/*     */ 
/*     */ 
/*     */           
/*     */           public void ancestorAdded(AncestorEvent event) {}
/*     */         });
/* 157 */     selectionModel.addSelectionChangeListener(this);
/* 158 */     init();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void selectionChanged(SelectionChangeEvent event) {
/* 169 */     SwingUtilities.invokeLater(() -> highlightSpots(this.selectionModel.getSpotSelection()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void highlightSpots(Collection<Spot> spots) {
/* 180 */     this.spotSelection = spots;
/* 181 */     if (spots.size() == 0) {
/*     */ 
/*     */       
/* 184 */       DefaultTableModel tableModel = (DefaultTableModel)this.table.getModel();
/* 185 */       tableModel.setRowCount(0);
/* 186 */       tableModel.setColumnIdentifiers((Object[])new String[] { "ø" });
/* 187 */       tableModel.setColumnCount(1);
/* 188 */       this.table.getColumnModel().getColumn(0).setPreferredWidth(10);
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 193 */     this.updater.doUpdate();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void update() {
/* 202 */     List<Spot> sortedSpots = new ArrayList<>(this.spotSelection);
/* 203 */     Collections.sort(sortedSpots, Spot.frameComparator);
/*     */ 
/*     */     
/* 206 */     DefaultTableModel dm = new DefaultTableModel()
/*     */       {
/*     */         
/*     */         public boolean isCellEditable(int row, int column)
/*     */         {
/* 211 */           return false;
/*     */         }
/*     */       };
/*     */     
/* 215 */     List<String> features = new ArrayList<>(this.model.getFeatureModel().getSpotFeatures());
/* 216 */     for (Spot spot : sortedSpots) {
/*     */       
/* 218 */       if (null == spot) {
/*     */         continue;
/*     */       }
/* 221 */       Object[] columnData = new Object[features.size() + 1];
/* 222 */       columnData[0] = String.format("%d", new Object[] { this.model.getTrackModel().trackIDOf(spot) });
/* 223 */       for (int j = 1; j < columnData.length; j++) {
/*     */         
/* 225 */         String feature = features.get(j - 1);
/* 226 */         Double feat = spot.getFeature(feature);
/* 227 */         if (null == feat) {
/* 228 */           columnData[j] = "";
/* 229 */         } else if (((Boolean)this.model.getFeatureModel().getSpotFeatureIsInt().get(feature)).booleanValue()) {
/* 230 */           columnData[j] = "" + feat.intValue();
/*     */         } else {
/* 232 */           columnData[j] = String.format("%.4g", new Object[] { Double.valueOf(feat.doubleValue()) });
/*     */         } 
/* 234 */       }  dm.addColumn(spot.toString(), columnData);
/*     */     } 
/* 236 */     this.table.setModel(dm);
/*     */ 
/*     */ 
/*     */     
/* 240 */     DefaultTableCellRenderer headerRenderer = new DefaultTableCellRenderer()
/*     */       {
/*     */         
/*     */         public boolean isOpaque()
/*     */         {
/* 245 */           return false;
/*     */         }
/*     */ 
/*     */ 
/*     */         
/*     */         public Color getBackground() {
/* 251 */           return Color.BLUE;
/*     */         }
/*     */       };
/* 254 */     headerRenderer.setBackground(Color.RED);
/* 255 */     headerRenderer.setFont(Fonts.FONT);
/*     */     
/* 257 */     DefaultTableCellRenderer renderer = new DefaultTableCellRenderer();
/* 258 */     renderer.setOpaque(false);
/* 259 */     renderer.setHorizontalAlignment(4);
/* 260 */     renderer.setFont(Fonts.SMALL_FONT);
/*     */     
/* 262 */     FontMetrics fm = this.table.getGraphics().getFontMetrics(Fonts.FONT);
/* 263 */     for (int i = 0; i < this.table.getColumnCount(); i++) {
/*     */       
/* 265 */       this.table.setDefaultRenderer(this.table.getColumnClass(i), renderer);
/*     */       
/* 267 */       this.table.getColumnModel().getColumn(i).setMinWidth((int)(1.4D * fm.stringWidth(dm.getColumnName(i))));
/*     */     } 
/* 269 */     for (Component c : this.scrollTable.getColumnHeader().getComponents()) {
/* 270 */       c.setBackground(getBackground());
/*     */     }
/* 272 */     this.scrollTable.getColumnHeader().setOpaque(false);
/* 273 */     this.scrollTable.setVisible(true);
/* 274 */     validate();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void displayPopupMenu(Point point) {
/* 284 */     JPopupMenu menu = new JPopupMenu("Selection table");
/* 285 */     JMenuItem exportItem = menu.add("Export to ImageJ table");
/* 286 */     exportItem.addActionListener(new ActionListener()
/*     */         {
/*     */           
/*     */           public void actionPerformed(ActionEvent arg0)
/*     */           {
/* 291 */             InfoPane.this.exportTableToImageJ();
/*     */           }
/*     */         });
/*     */     
/* 295 */     menu.show(this.table, (int)point.getX(), (int)point.getY());
/*     */   }
/*     */ 
/*     */   
/*     */   private void exportTableToImageJ() {
/* 300 */     ResultsTable lTable = new ResultsTable();
/* 301 */     FeatureModel fm = this.model.getFeatureModel();
/* 302 */     List<String> features = new ArrayList<>(fm.getSpotFeatures());
/*     */     
/* 304 */     int ncols = this.spotSelection.size();
/* 305 */     int nrows = this.headers.length;
/* 306 */     Spot[] spotArray = this.spotSelection.<Spot>toArray(new Spot[0]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 312 */     lTable.incrementCounter();
/* 313 */     lTable.setLabel("TRACK_ID", 0);
/* 314 */     for (int i = 0; i < ncols; i++) {
/*     */       
/* 316 */       Spot spot = spotArray[i];
/* 317 */       Integer trackID = this.model.getTrackModel().trackIDOf(spot);
/* 318 */       if (null == trackID) {
/* 319 */         lTable.addValue(spot.getName(), "None");
/*     */       } else {
/* 321 */         lTable.addValue(spot.getName(), "" + trackID.intValue());
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 328 */     for (int j = 0; j < nrows - 1; j++) {
/*     */       
/* 330 */       lTable.incrementCounter();
/* 331 */       String feature = features.get(j);
/* 332 */       lTable.setLabel(feature, j + 1);
/* 333 */       for (int k = 0; k < ncols; k++) {
/*     */         
/* 335 */         Spot spot = spotArray[k];
/* 336 */         Double val = spot.getFeature(feature);
/* 337 */         if (val == null) {
/*     */           
/* 339 */           lTable.addValue(spot.getName(), "None");
/*     */ 
/*     */         
/*     */         }
/* 343 */         else if (((Boolean)fm.getSpotFeatureIsInt().get(feature)).booleanValue()) {
/* 344 */           lTable.addValue(spot.getName(), "" + val.intValue());
/*     */         } else {
/* 346 */           lTable.addValue(spot.getName(), val.doubleValue());
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 351 */     lTable.show("TrackMate Selection");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void init() {
/* 358 */     AbstractListModel<String> lm = new AbstractListModel<String>()
/*     */       {
/*     */         
/*     */         public int getSize()
/*     */         {
/* 363 */           return InfoPane.this.headers.length;
/*     */         }
/*     */ 
/*     */ 
/*     */         
/*     */         public String getElementAt(int index) {
/* 369 */           return InfoPane.this.headers[index];
/*     */         }
/*     */       };
/*     */     
/* 373 */     this.table = new JTable();
/* 374 */     this.table.setAutoResizeMode(0);
/* 375 */     this.table.setOpaque(false);
/* 376 */     this.table.setFont(Fonts.SMALL_FONT);
/* 377 */     this.table.setPreferredScrollableViewportSize(new Dimension(120, 400));
/* 378 */     this.table.getTableHeader().setOpaque(false);
/* 379 */     this.table.setSelectionForeground(Color.YELLOW.darker().darker());
/* 380 */     this.table.setGridColor(TrackScheme.GRID_COLOR);
/*     */     
/* 382 */     DefaultTableModel tableModel = (DefaultTableModel)this.table.getModel();
/* 383 */     tableModel.setColumnIdentifiers((Object[])new String[] { "ø" });
/* 384 */     tableModel.setColumnCount(1);
/* 385 */     this.table.getColumnModel().getColumn(0).setPreferredWidth(10);
/*     */     
/* 387 */     this.table.addMouseListener(new MouseAdapter()
/*     */         {
/*     */           
/*     */           public void mousePressed(MouseEvent e)
/*     */           {
/* 392 */             if (e.isPopupTrigger()) {
/* 393 */               InfoPane.this.displayPopupMenu(e.getPoint());
/*     */             }
/*     */           }
/*     */ 
/*     */           
/*     */           public void mouseReleased(MouseEvent e) {
/* 399 */             if (e.isPopupTrigger()) {
/* 400 */               InfoPane.this.displayPopupMenu(e.getPoint());
/*     */             }
/*     */           }
/*     */         });
/* 404 */     JList<String> rowHeader = new JList<>(lm);
/* 405 */     rowHeader.setFixedCellHeight(this.table.getRowHeight());
/* 406 */     rowHeader.setCellRenderer(new RowHeaderRenderer(this.table));
/* 407 */     rowHeader.setBackground(getBackground());
/*     */     
/* 409 */     this.scrollTable = new JScrollPane(this.table);
/* 410 */     this.scrollTable.setRowHeaderView(rowHeader);
/* 411 */     this.scrollTable.getRowHeader().setOpaque(false);
/* 412 */     this.scrollTable.setOpaque(false);
/* 413 */     this.scrollTable.getViewport().setOpaque(false);
/*     */     
/* 415 */     setLayout(new BorderLayout());
/* 416 */     add(this.scrollTable, "Center");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private class RowHeaderRenderer
/*     */     extends JLabel
/*     */     implements ListCellRenderer<String>
/*     */   {
/*     */     private static final long serialVersionUID = -1L;
/*     */ 
/*     */ 
/*     */     
/*     */     RowHeaderRenderer(JTable table) {
/* 430 */       JTableHeader header = table.getTableHeader();
/* 431 */       setOpaque(false);
/* 432 */       setBorder(UIManager.getBorder("TableHeader.cellBorder"));
/* 433 */       setForeground(header.getForeground());
/* 434 */       setBackground(header.getBackground());
/* 435 */       setFont(Fonts.SMALL_FONT.deriveFont(9.0F));
/* 436 */       setHorizontalAlignment(2);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Component getListCellRendererComponent(JList<? extends String> list, String value, int index, boolean isSelected, boolean cellHasFocus) {
/* 443 */       setText((value == null) ? "" : value);
/* 444 */       return this;
/*     */     }
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/visualization/trackscheme/InfoPane.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */