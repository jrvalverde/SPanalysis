/*     */ package fiji.plugin.trackmate.tracking.kdtree;
/*     */ 
/*     */ import fiji.plugin.trackmate.Model;
/*     */ import fiji.plugin.trackmate.SpotCollection;
/*     */ import fiji.plugin.trackmate.gui.components.ConfigurationPanel;
/*     */ import fiji.plugin.trackmate.gui.components.tracker.NearestNeighborTrackerSettingsPanel;
/*     */ import fiji.plugin.trackmate.io.IOUtils;
/*     */ import fiji.plugin.trackmate.tracking.SpotTracker;
/*     */ import fiji.plugin.trackmate.tracking.SpotTrackerFactory;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import javax.swing.ImageIcon;
/*     */ import org.jdom2.Element;
/*     */ import org.scijava.plugin.Plugin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Plugin(type = SpotTrackerFactory.class, priority = -100.0D)
/*     */ public class NearestNeighborTrackerFactory
/*     */   implements SpotTrackerFactory
/*     */ {
/*     */   public static final String TRACKER_KEY = "NEAREST_NEIGHBOR_TRACKER";
/*     */   public static final String NAME = "Nearest-neighbor tracker";
/*     */   public static final String INFO_TEXT = "<html>This tracker is the most simple one, and is based on nearest neighbor <br>search. The spots in the target frame are searched for the nearest neighbor <br> of each spot in the source frame. If the spots found are closer than the <br>maximal allowed distance, a link between the two is created. <br><p>The nearest neighbor search relies upon the KD-tree technique implemented <br>in imglib by Johannes Schindelin and friends. This ensure a very efficient tracking and makes this tracker suitable for situation where a huge number <br>of particles are to be tracked over a very large number of frames. However, <br>because of the naiveness of its principles, it can result in pathological <br>tracks. It can only do frame-to-frame linking; there cannot be any track <br>merging or splitting, and gaps will not be closed. Also, the end results are non-deterministic. </html>";
/*     */   private String errorMessage;
/*     */   
/*     */   public String getInfoText() {
/*  73 */     return "<html>This tracker is the most simple one, and is based on nearest neighbor <br>search. The spots in the target frame are searched for the nearest neighbor <br> of each spot in the source frame. If the spots found are closer than the <br>maximal allowed distance, a link between the two is created. <br><p>The nearest neighbor search relies upon the KD-tree technique implemented <br>in imglib by Johannes Schindelin and friends. This ensure a very efficient tracking and makes this tracker suitable for situation where a huge number <br>of particles are to be tracked over a very large number of frames. However, <br>because of the naiveness of its principles, it can result in pathological <br>tracks. It can only do frame-to-frame linking; there cannot be any track <br>merging or splitting, and gaps will not be closed. Also, the end results are non-deterministic. </html>";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ImageIcon getIcon() {
/*  79 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getKey() {
/*  85 */     return "NEAREST_NEIGHBOR_TRACKER";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/*  91 */     return "Nearest-neighbor tracker";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public SpotTracker create(SpotCollection spots, Map<String, Object> settings) {
/*  97 */     return new NearestNeighborTracker(spots, settings);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ConfigurationPanel getTrackerConfigurationPanel(Model model) {
/* 103 */     String spaceUnits = model.getSpaceUnits();
/* 104 */     return (ConfigurationPanel)new NearestNeighborTrackerSettingsPanel("Nearest-neighbor tracker", "<html>This tracker is the most simple one, and is based on nearest neighbor <br>search. The spots in the target frame are searched for the nearest neighbor <br> of each spot in the source frame. If the spots found are closer than the <br>maximal allowed distance, a link between the two is created. <br><p>The nearest neighbor search relies upon the KD-tree technique implemented <br>in imglib by Johannes Schindelin and friends. This ensure a very efficient tracking and makes this tracker suitable for situation where a huge number <br>of particles are to be tracked over a very large number of frames. However, <br>because of the naiveness of its principles, it can result in pathological <br>tracks. It can only do frame-to-frame linking; there cannot be any track <br>merging or splitting, and gaps will not be closed. Also, the end results are non-deterministic. </html>", spaceUnits);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean marshall(Map<String, Object> settings, Element element) {
/* 110 */     StringBuilder str = new StringBuilder();
/* 111 */     boolean ok = IOUtils.writeAttribute(settings, element, "LINKING_MAX_DISTANCE", Double.class, str);
/* 112 */     if (!ok) {
/* 113 */       this.errorMessage = str.toString();
/*     */     }
/* 115 */     return ok;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean unmarshall(Element element, Map<String, Object> settings) {
/* 121 */     settings.clear();
/* 122 */     StringBuilder errorHolder = new StringBuilder();
/* 123 */     boolean ok = IOUtils.readDoubleAttribute(element, settings, "LINKING_MAX_DISTANCE", errorHolder);
/* 124 */     if (!ok) {
/* 125 */       this.errorMessage = errorHolder.toString();
/*     */     }
/* 127 */     return ok;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString(Map<String, Object> sm) {
/* 133 */     return String.format("  Max distance: %.1f\n", new Object[] { sm.get("LINKING_MAX_DISTANCE") });
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, Object> getDefaultSettings() {
/* 139 */     Map<String, Object> settings = new HashMap<>();
/* 140 */     settings.put("LINKING_MAX_DISTANCE", Double.valueOf(15.0D));
/* 141 */     return settings;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean checkSettingsValidity(Map<String, Object> settings) {
/* 147 */     StringBuilder str = new StringBuilder();
/* 148 */     boolean ok = NearestNeighborTracker.checkInput(settings, str);
/* 149 */     if (!ok) {
/* 150 */       this.errorMessage = str.toString();
/*     */     }
/* 152 */     return ok;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getErrorMessage() {
/* 158 */     return this.errorMessage;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public NearestNeighborTrackerFactory copy() {
/* 164 */     return new NearestNeighborTrackerFactory();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/tracking/kdtree/NearestNeighborTrackerFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */