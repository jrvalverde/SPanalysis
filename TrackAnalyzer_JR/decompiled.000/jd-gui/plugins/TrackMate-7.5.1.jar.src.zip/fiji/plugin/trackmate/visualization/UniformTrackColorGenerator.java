/*    */ package fiji.plugin.trackmate.visualization;
/*    */ 
/*    */ import java.awt.Color;
/*    */ import org.jgrapht.graph.DefaultWeightedEdge;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class UniformTrackColorGenerator
/*    */   implements TrackColorGenerator
/*    */ {
/*    */   private final Color color;
/*    */   
/*    */   public UniformTrackColorGenerator(Color color) {
/* 40 */     this.color = color;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Color color(DefaultWeightedEdge obj) {
/* 46 */     return this.color;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/visualization/UniformTrackColorGenerator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */