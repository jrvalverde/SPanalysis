/*     */ package fiji.plugin.trackmate.gui.displaysettings;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.io.IOException;
/*     */ import java.net.URI;
/*     */ import java.net.URISyntaxException;
/*     */ import java.nio.file.DirectoryStream;
/*     */ import java.nio.file.FileSystem;
/*     */ import java.nio.file.FileSystems;
/*     */ import java.nio.file.Files;
/*     */ import java.nio.file.Path;
/*     */ import java.nio.file.Paths;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Scanner;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ import org.scijava.util.IntArray;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ColormapIO
/*     */ {
/*  51 */   private static final List<URI> LUT_FOLDERS = new ArrayList<>();
/*     */ 
/*     */   
/*     */   static {
/*     */     try {
/*  56 */       URI BUILTIN_LUT_FOLDER = ColormapIO.class.getResource("luts/").toURI();
/*  57 */       LUT_FOLDERS.add(BUILTIN_LUT_FOLDER);
/*     */     }
/*  59 */     catch (URISyntaxException e) {
/*     */       
/*  61 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   static List<Colormap> getLUTs() {
/*  67 */     return loadLUTs();
/*     */   }
/*     */ 
/*     */   
/*     */   private static List<Colormap> loadLUTs() {
/*  72 */     List<Colormap> luts = new ArrayList<>();
/*  73 */     for (URI lutFolder : LUT_FOLDERS) {
/*     */ 
/*     */       
/*     */       try {
/*  77 */         luts.addAll(loadLUTs(lutFolder));
/*     */       }
/*  79 */       catch (IOException e) {
/*     */         
/*  81 */         e.printStackTrace();
/*     */       } 
/*     */     } 
/*  84 */     return luts;
/*     */   }
/*     */ 
/*     */   
/*     */   private static List<Colormap> loadLUTs(URI folder) throws IOException {
/*  89 */     if (folder.getScheme().equals("jar")) {
/*     */ 
/*     */       
/*  92 */       String[] array = folder.toString().split("!");
/*  93 */       try (FileSystem fileSystem = FileSystems.newFileSystem(URI.create(array[0]), Collections.emptyMap())) {
/*     */         
/*  95 */         Path path = fileSystem.getPath(array[1], new String[0]);
/*  96 */         return loadLUTs(path);
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 102 */     Path folderPath = Paths.get(folder);
/* 103 */     return loadLUTs(folderPath);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static List<Colormap> loadLUTs(Path folderPath) throws IOException {
/* 109 */     List<Colormap> luts = new ArrayList<>();
/* 110 */     if (Files.exists(folderPath, new java.nio.file.LinkOption[0])) {
/*     */       
/* 112 */       String glob = "*.lut";
/* 113 */       try (DirectoryStream<Path> folderStream = Files.newDirectoryStream(folderPath, "*.lut")) {
/*     */         
/* 115 */         for (Path path : folderStream) {
/*     */ 
/*     */           
/* 118 */           Colormap lut = importLUT(path);
/* 119 */           if (null == lut) {
/* 120 */             System.err.println("Could not read LUT file: " + path + ". Skipping.");
/*     */           }
/* 122 */           luts.add(lut);
/*     */         } 
/*     */       } 
/*     */     } 
/* 126 */     return luts;
/*     */   }
/*     */ 
/*     */   
/*     */   private static final Colormap importLUT(Path path) throws IOException {
/* 131 */     String fileName = path.getFileName().toString();
/* 132 */     String lutName = fileName.substring(0, fileName.indexOf('.'));
/*     */     
/* 134 */     try (Scanner scanner = new Scanner(path)) {
/*     */ 
/*     */       
/* 137 */       List<Color> colors = new ArrayList<>();
/* 138 */       IntArray intAlphas = new IntArray();
/* 139 */       AtomicInteger nLines = new AtomicInteger(0);
/*     */       
/* 141 */       Colormap ips = new Colormap(lutName, 0.0D, 1.0D);
/* 142 */       while (scanner.hasNext()) {
/*     */         
/* 144 */         if (!scanner.hasNextInt()) {
/*     */           
/* 146 */           scanner.next();
/*     */           continue;
/*     */         } 
/* 149 */         intAlphas.addValue(scanner.nextInt());
/* 150 */         Color color = new Color(scanner.nextInt(), scanner.nextInt(), scanner.nextInt());
/* 151 */         colors.add(color);
/* 152 */         nLines.incrementAndGet();
/*     */       } 
/*     */       
/* 155 */       if (nLines.get() < 2) {
/* 156 */         return null;
/*     */       }
/* 158 */       double[] alphas = new double[intAlphas.size()];
/* 159 */       for (int i = 0; i < alphas.length; i++) {
/*     */         
/* 161 */         double alpha = intAlphas.get(i).intValue() / (nLines.get() - 1);
/* 162 */         Color color = colors.get(i);
/* 163 */         ips.add(alpha, color);
/*     */       } 
/*     */       
/* 166 */       return ips;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/gui/displaysettings/ColormapIO.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */