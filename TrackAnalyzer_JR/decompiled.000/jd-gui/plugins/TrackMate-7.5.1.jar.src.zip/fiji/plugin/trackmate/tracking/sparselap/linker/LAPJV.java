/*     */ package fiji.plugin.trackmate.tracking.sparselap.linker;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import net.imglib2.algorithm.Benchmark;
/*     */ import net.imglib2.algorithm.OutputAlgorithm;
/*     */ import net.imglib2.util.Util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LAPJV
/*     */   implements OutputAlgorithm<int[]>, Benchmark
/*     */ {
/*     */   private static final String BASE_ERROR_MESSAGE = "[JonkerVolgenantSparseAlgorithm] ";
/*     */   private int[] output;
/*     */   private String errorMessage;
/*     */   private long processingTime;
/*     */   private final SparseCostMatrix cm;
/*     */   
/*     */   public LAPJV(SparseCostMatrix cm) {
/*  87 */     this.cm = cm;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean process() {
/*  93 */     long start = System.currentTimeMillis();
/*     */     
/*  95 */     int[] x = new int[this.cm.nRows];
/*  96 */     int[] y = new int[this.cm.nCols];
/*  97 */     double[] v = new double[this.cm.nCols];
/*     */     
/*  99 */     int[] col = new int[this.cm.nCols];
/* 100 */     for (int k = 0; k < col.length; k++)
/*     */     {
/* 102 */       col[k] = k;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 109 */     Arrays.fill(v, Double.MAX_VALUE);
/* 110 */     for (int i = 0; i < this.cm.nRows; i++) {
/*     */       
/* 112 */       for (int i1 = this.cm.start[i]; i1 < this.cm.start[i] + this.cm.number[i]; i1++) {
/*     */         
/* 114 */         int i2 = this.cm.kk[i1];
/* 115 */         if (this.cm.cc[i1] < v[i2]) {
/*     */           
/* 117 */           v[i2] = this.cm.cc[i1];
/* 118 */           y[i2] = i + 1;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 123 */     for (int j = this.cm.nCols - 1; j >= 0; j--) {
/*     */       
/* 125 */       int i1 = y[j] - 1;
/* 126 */       if (x[i1] == 0) {
/*     */         
/* 128 */         x[i1] = j + 1;
/*     */       }
/*     */       else {
/*     */         
/* 132 */         if (x[i1] > 0)
/*     */         {
/* 134 */           x[i1] = -x[i1];
/*     */         }
/* 136 */         y[j] = 0;
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 144 */     int f = 0;
/* 145 */     int[] free = new int[this.cm.nRows];
/* 146 */     for (int m = 0; m < this.cm.nRows; m++) {
/*     */       
/* 148 */       if (x[m] == 0) {
/*     */ 
/*     */         
/* 151 */         free[f++] = m;
/*     */       
/*     */       }
/* 154 */       else if (x[m] < 0) {
/*     */ 
/*     */         
/* 157 */         x[m] = -x[m];
/*     */       
/*     */       }
/*     */       else {
/*     */         
/* 162 */         int j1 = x[m] - 1;
/* 163 */         double min = Double.MAX_VALUE;
/* 164 */         for (int i1 = this.cm.start[m]; i1 < this.cm.start[m] + this.cm.number[m]; i1++) {
/*     */           
/* 166 */           int i2 = this.cm.kk[i1];
/* 167 */           if (i2 != j1)
/*     */           {
/* 169 */             if (this.cm.cc[i1] - v[i2] < min)
/*     */             {
/* 171 */               min = this.cm.cc[i1] - v[i2];
/*     */             }
/*     */           }
/*     */         } 
/* 175 */         v[j1] = v[j1] - min;
/*     */       } 
/*     */     } 
/*     */     
/* 179 */     if (f == 0) return true;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 185 */     for (int count = 0; count < 2; count++) {
/*     */       
/* 187 */       int i1 = 0;
/* 188 */       int i2 = f;
/* 189 */       f = 0;
/* 190 */       while (i1 < i2) {
/*     */         
/* 192 */         int i3 = free[i1++];
/* 193 */         double v0 = Double.MAX_VALUE;
/* 194 */         int j0 = 0, j1 = -1;
/* 195 */         double vj = Double.MAX_VALUE;
/* 196 */         for (int kj = this.cm.start[i3]; kj < this.cm.start[i3] + this.cm.number[i3]; kj++) {
/*     */           
/* 198 */           int i4 = this.cm.kk[kj];
/* 199 */           double h = this.cm.cc[kj] - v[i4];
/* 200 */           if (h < vj)
/*     */           {
/* 202 */             if (h > v0) {
/*     */               
/* 204 */               vj = h;
/* 205 */               j1 = i4;
/*     */             }
/*     */             else {
/*     */               
/* 209 */               vj = v0;
/* 210 */               v0 = h;
/* 211 */               j1 = j0;
/* 212 */               j0 = i4;
/*     */             } 
/*     */           }
/*     */         } 
/* 216 */         int i0 = y[j0] - 1;
/* 217 */         if (v0 < vj) {
/*     */           
/* 219 */           v[j0] = v[j0] - vj - v0;
/*     */ 
/*     */         
/*     */         }
/* 223 */         else if (i0 >= 0) {
/*     */           
/* 225 */           j0 = j1;
/* 226 */           i0 = y[j1] - 1;
/*     */         } 
/*     */         
/* 229 */         if (i0 >= 0)
/*     */         {
/* 231 */           if (v0 < vj) {
/*     */             
/* 233 */             free[--i1] = i0;
/*     */           }
/*     */           else {
/*     */             
/* 237 */             free[f++] = i0;
/*     */           } 
/*     */         }
/* 240 */         x[i3] = j0 + 1;
/* 241 */         y[j0] = i3 + 1;
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 249 */     int f0 = f;
/* 250 */     double[] d = new double[this.cm.nCols];
/* 251 */     int[] pred = new int[this.cm.nCols];
/* 252 */     for (f = 0; f < f0; ) {
/*     */       
/* 254 */       int i1 = free[f];
/* 255 */       int low = 0, up = 0;
/*     */       
/* 257 */       Arrays.fill(d, Double.MAX_VALUE);
/* 258 */       for (int i2 = this.cm.start[i1]; i2 < this.cm.start[i1] + this.cm.number[i1]; i2++) {
/*     */         
/* 260 */         int i4 = this.cm.kk[i2];
/* 261 */         d[i4] = this.cm.cc[i2] - v[i4];
/* 262 */         pred[i4] = i1;
/*     */       } 
/*     */       
/* 265 */       int i3 = -1;
/* 266 */       double min = Double.MAX_VALUE;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       while (true) {
/* 273 */         int last = low;
/* 274 */         min = d[col[up++]];
/* 275 */         for (int i4 = up; i4 < this.cm.nCols; i4++) {
/*     */           
/* 277 */           i3 = col[i4];
/* 278 */           double d1 = d[i3];
/* 279 */           if (d1 <= min) {
/*     */             
/* 281 */             if (d1 < min) {
/*     */               
/* 283 */               up = low;
/* 284 */               min = d1;
/*     */             } 
/* 286 */             col[i4] = col[up];
/* 287 */             col[up++] = i3;
/*     */           } 
/*     */         } 
/* 290 */         for (int h = low; h < up; i5++)
/*     */         { int i5;
/* 292 */           i3 = col[h];
/* 293 */           if (y[i3] == 0)
/*     */           
/*     */           { 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 343 */             for (i5 = 0; i5 < last; i5++) {
/*     */               
/* 345 */               int j0 = col[i5];
/* 346 */               v[j0] = v[j0] + d[j0] - min;
/*     */             } 
/*     */ 
/*     */ 
/*     */             
/*     */             while (true)
/* 352 */             { int i6 = pred[i3];
/* 353 */               y[i3] = i6 + 1;
/* 354 */               i5 = i3;
/* 355 */               i3 = x[i6] - 1;
/* 356 */               x[i6] = i5 + 1;
/*     */               
/* 358 */               if (i1 == i6)
/*     */                 f++;  }  }  }  while (true) { int j1 = col[low++]; int i5 = y[j1] - 1; int kj1 = Arrays.binarySearch(this.cm.kk, this.cm.start[i5], this.cm.start[i5] + this.cm.number[i5], j1); if (kj1 >= 0) { double u1 = this.cm.cc[kj1] - v[j1] - min; for (int i6 = up; i6 < this.cm.nCols; i6++) { i3 = col[i6]; int kj = Arrays.binarySearch(this.cm.kk, this.cm.start[i5], this.cm.start[i5] + this.cm.number[i5], i3); if (kj >= 0) { double d1 = this.cm.cc[kj] - v[i3] - u1; if (d1 < d[i3]) { d[i3] = d1; pred[i3] = i5; if (d1 == min) { if (y[i3] == 0)
/*     */                       break;  col[i6] = col[up]; col[up++] = i3; }  }  }  }  }  if (low == up)
/*     */             if (low != up)
/*     */               break;   }
/*     */          break;
/*     */       }  continue;
/* 365 */     }  this.output = new int[x.length];
/* 366 */     for (int n = 0; n < x.length; n++)
/*     */     {
/* 368 */       this.output[n] = x[n] - 1;
/*     */     }
/*     */     
/* 371 */     long end = System.currentTimeMillis();
/* 372 */     this.processingTime = end - start;
/* 373 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean checkInput() {
/* 383 */     if (this.cm.nRows > this.cm.nCols) {
/*     */       
/* 385 */       this.errorMessage = "[JonkerVolgenantSparseAlgorithm] This solver converges only if the cost matrix has more rows than column. Found " + this.cm.nRows + " rows and " + this.cm.nCols + " columns.";
/* 386 */       return false;
/*     */     } 
/* 388 */     double minCost = Util.min(this.cm.cc);
/* 389 */     if (minCost <= 0.0D) {
/*     */       
/* 391 */       this.errorMessage = "[JonkerVolgenantSparseAlgorithm] This solver only accept strictly positive costs. Found " + minCost + ".";
/* 392 */       return false;
/*     */     } 
/* 394 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getErrorMessage() {
/* 400 */     return this.errorMessage;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public long getProcessingTime() {
/* 406 */     return this.processingTime;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int[] getResult() {
/* 419 */     return this.output;
/*     */   }
/*     */ 
/*     */   
/*     */   public String resultToString() {
/* 424 */     return resultToString(Collections.emptyList(), Collections.emptyList());
/*     */   }
/*     */ 
/*     */   
/*     */   public String resultToString(List<?> rows, List<?> cols) {
/* 429 */     if (null == this.output) return "Not solved yet. Process the algorithm prior to calling this method.";
/*     */     
/* 431 */     String[] colNames = new String[this.cm.nCols];
/*     */     
/* 433 */     for (int j = 0; j < colNames.length; j++)
/*     */     {
/* 435 */       colNames[j] = "" + j;
/*     */     }
/* 437 */     String[] rowNames = new String[this.cm.nRows];
/* 438 */     for (int i = 0; i < rowNames.length; i++)
/*     */     {
/* 440 */       rowNames[i] = "" + i;
/*     */     }
/*     */     
/* 443 */     for (int k = 0; k < cols.size(); k++) {
/*     */       
/* 445 */       Object col = cols.get(k);
/* 446 */       if (null != col) {
/*     */         
/* 448 */         String str1 = col.toString();
/* 449 */         colNames[k] = str1;
/*     */       } 
/*     */     } 
/*     */     
/* 453 */     int colWidth = -1;
/* 454 */     for (String str1 : colNames) {
/*     */       
/* 456 */       if (str1.length() > colWidth)
/*     */       {
/* 458 */         colWidth = str1.length();
/*     */       }
/*     */     } 
/*     */     
/* 462 */     colWidth++;
/* 463 */     colWidth = Math.max(colWidth, 7);
/*     */     
/* 465 */     Set<String> unassignedColNames = new HashSet<>(Arrays.asList(colNames));
/*     */     
/* 467 */     for (int m = 0; m < rows.size(); m++) {
/*     */       
/* 469 */       Object row = rows.get(m);
/* 470 */       if (null != row) {
/*     */         
/* 472 */         String str1 = row.toString();
/* 473 */         rowNames[m] = str1;
/*     */       } 
/*     */     } 
/*     */     
/* 477 */     int rowWidth = -1;
/* 478 */     for (String str1 : rowNames) {
/*     */       
/* 480 */       if (str1.length() > rowWidth)
/*     */       {
/* 482 */         rowWidth = str1.length();
/*     */       }
/*     */     } 
/*     */     
/* 486 */     rowWidth++;
/* 487 */     rowWidth = Math.max(7, rowWidth);
/*     */     
/* 489 */     StringBuilder str = new StringBuilder();
/* 490 */     double totalCost = this.cm.totalAssignmentCost(this.output);
/* 491 */     int digits = (int)(Math.log10(totalCost) + 2.0D);
/*     */     
/* 493 */     str.append(String.format("Optimal assignment with total cost = %" + digits + ".1f:\n", new Object[] { Double.valueOf(totalCost) }));
/* 494 */     for (int n = 0; n < this.output.length; n++) {
/*     */       
/* 496 */       int i1 = this.output[n];
/* 497 */       double cost = this.cm.get(n, i1, Double.POSITIVE_INFINITY);
/*     */       
/*     */       int i2;
/* 500 */       for (i2 = 0; i2 < rowWidth - rowNames[n].length(); i2++)
/*     */       {
/* 502 */         str.append(' ');
/*     */       }
/* 504 */       str.append(rowNames[n]);
/*     */       
/* 506 */       str.append(" → ");
/*     */       
/* 508 */       str.append(colNames[i1]);
/* 509 */       unassignedColNames.remove(colNames[i1]);
/* 510 */       for (i2 = 0; i2 < colWidth - colNames[i1].length(); i2++)
/*     */       {
/* 512 */         str.append(' ');
/*     */       }
/*     */       
/* 515 */       str.append(String.format(" cost = %" + digits + ".1f\n", new Object[] { Double.valueOf(cost) }));
/*     */     } 
/* 517 */     if (this.cm.nCols > this.cm.nRows) {
/*     */       
/* 519 */       str.append("Unassigned columns:\n");
/* 520 */       for (String ucn : unassignedColNames) {
/*     */         int i1;
/*     */         
/* 523 */         for (i1 = 0; i1 < rowWidth / 2; i1++)
/*     */         {
/* 525 */           str.append(' ');
/*     */         }
/* 527 */         str.append('ø');
/* 528 */         for (i1 = 0; i1 < rowWidth - rowWidth / 2 - 1; i1++)
/*     */         {
/* 530 */           str.append(' ');
/*     */         }
/*     */         
/* 533 */         str.append(" → ");
/*     */         
/* 535 */         str.append(ucn);
/* 536 */         for (i1 = 0; i1 < colWidth - ucn.length(); i1++)
/*     */         {
/* 538 */           str.append(' ');
/*     */         }
/*     */         
/* 541 */         str.append('\n');
/*     */       } 
/*     */     } 
/*     */     
/* 545 */     return str.toString();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/tracking/sparselap/linker/LAPJV.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */