/*     */ package fiji.plugin.trackmate.visualization.trackscheme;
/*     */ 
/*     */ import fiji.plugin.trackmate.gui.Fonts;
/*     */ import fiji.plugin.trackmate.gui.Icons;
/*     */ import fiji.plugin.trackmate.visualization.TrackMateModelView;
/*     */ import fiji.plugin.trackmate.visualization.trackscheme.utils.SearchBar;
/*     */ import java.awt.Component;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import javax.swing.AbstractAction;
/*     */ import javax.swing.Action;
/*     */ import javax.swing.Box;
/*     */ import javax.swing.Icon;
/*     */ import javax.swing.ImageIcon;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JComboBox;
/*     */ import javax.swing.JToolBar;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TrackSchemeToolbar
/*     */   extends JToolBar
/*     */ {
/*     */   private static final long serialVersionUID = 3442140463984241266L;
/*     */   private final TrackScheme trackScheme;
/*     */   
/*     */   public TrackSchemeToolbar(TrackScheme trackScheme) {
/*  62 */     super("Track Scheme toolbar", 0);
/*  63 */     this.trackScheme = trackScheme;
/*  64 */     init();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void init() {
/*  71 */     setFloatable(false);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  77 */     boolean defaultLinkingEnabled = false;
/*  78 */     Action toggleLinkingAction = new AbstractAction(null, Icons.LINKING_OFF_ICON)
/*     */       {
/*     */         public void actionPerformed(ActionEvent e)
/*     */         {
/*     */           ImageIcon connectIcon;
/*  83 */           boolean isEnabled = TrackSchemeToolbar.this.trackScheme.toggleLinking();
/*     */           
/*  85 */           if (!isEnabled) {
/*  86 */             connectIcon = Icons.LINKING_OFF_ICON;
/*     */           } else {
/*  88 */             connectIcon = Icons.LINKING_ON_ICON;
/*     */           } 
/*  90 */           putValue("SmallIcon", connectIcon);
/*     */         }
/*     */       };
/*  93 */     JButton toggleLinkingButton = new JButton(toggleLinkingAction);
/*  94 */     toggleLinkingButton.setToolTipText("Toggle linking");
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  99 */     boolean defaultThumbnailsEnabled = false;
/* 100 */     Action toggleThumbnailAction = new AbstractAction(null, Icons.THUMBNAIL_OFF_ICON)
/*     */       {
/*     */         
/*     */         public void actionPerformed(ActionEvent e)
/*     */         {
/* 105 */           (new Thread("TrackScheme creating thumbnails thread")
/*     */             {
/*     */               public void run()
/*     */               {
/*     */                 ImageIcon thumbnailIcon;
/* 110 */                 boolean isEnabled = TrackSchemeToolbar.this.trackScheme.toggleThumbnail();
/*     */                 
/* 112 */                 if (!isEnabled) {
/* 113 */                   thumbnailIcon = Icons.THUMBNAIL_OFF_ICON;
/*     */                 } else {
/* 115 */                   thumbnailIcon = Icons.THUMBNAIL_ON_ICON;
/*     */                 } 
/* 117 */                 TrackSchemeToolbar.null.this.putValue("SmallIcon", thumbnailIcon);
/*     */               }
/* 119 */             }).start();
/*     */         }
/*     */       };
/* 122 */     JButton toggleThumbnailsButton = new JButton(toggleThumbnailAction);
/* 123 */     toggleThumbnailsButton.setToolTipText("<html>If enabled, spot thumnails will be captured <br/>Can take long for large models.</html>");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 132 */     JButton zoomInButton = new JButton();
/* 133 */     JButton zoomOutButton = new JButton();
/* 134 */     JButton resetZoomButton = new JButton();
/* 135 */     Action zoomInAction = new AbstractAction(null, Icons.ZOOM_IN_ICON)
/*     */       {
/*     */         
/*     */         public void actionPerformed(ActionEvent e)
/*     */         {
/* 140 */           TrackSchemeToolbar.this.trackScheme.zoomIn();
/*     */         }
/*     */       };
/* 143 */     Action zoomOutAction = new AbstractAction(null, Icons.ZOOM_OUT_ICON)
/*     */       {
/*     */         
/*     */         public void actionPerformed(ActionEvent e)
/*     */         {
/* 148 */           TrackSchemeToolbar.this.trackScheme.zoomOut();
/*     */         }
/*     */       };
/* 151 */     Action resetZoomAction = new AbstractAction(null, Icons.RESET_ZOOM_ICON)
/*     */       {
/*     */         
/*     */         public void actionPerformed(ActionEvent e)
/*     */         {
/* 156 */           TrackSchemeToolbar.this.trackScheme.resetZoom();
/*     */         }
/*     */       };
/* 159 */     zoomInButton.setAction(zoomInAction);
/* 160 */     zoomOutButton.setAction(zoomOutAction);
/* 161 */     resetZoomButton.setAction(resetZoomAction);
/* 162 */     zoomInButton.setToolTipText("Zoom in 2x");
/* 163 */     zoomOutButton.setToolTipText("Zoom out 2x");
/* 164 */     resetZoomButton.setToolTipText("Reset zoom");
/*     */ 
/*     */ 
/*     */     
/* 168 */     JButton redoLayoutButton = new JButton("Layout", Icons.REFRESH_ICON);
/* 169 */     redoLayoutButton.setFont(Fonts.FONT);
/* 170 */     redoLayoutButton.setToolTipText("Re-arrange the tracks.");
/* 171 */     redoLayoutButton.addActionListener(new ActionListener()
/*     */         {
/*     */           
/*     */           public void actionPerformed(ActionEvent e)
/*     */           {
/* 176 */             TrackSchemeToolbar.this.trackScheme.doTrackLayout();
/* 177 */             TrackSchemeToolbar.this.trackScheme.refresh();
/*     */           }
/*     */         });
/*     */ 
/*     */     
/* 182 */     Action captureUndecoratedAction = new AbstractAction(null, Icons.CAPTURE_UNDECORATED_ICON)
/*     */       {
/*     */         
/*     */         public void actionPerformed(ActionEvent e)
/*     */         {
/* 187 */           TrackSchemeToolbar.this.trackScheme.captureUndecorated();
/*     */         }
/*     */       };
/* 190 */     Action captureDecoratedAction = new AbstractAction(null, Icons.CAPTURE_DECORATED_ICON)
/*     */       {
/*     */         
/*     */         public void actionPerformed(ActionEvent e)
/*     */         {
/* 195 */           TrackSchemeToolbar.this.trackScheme.captureDecorated();
/*     */         }
/*     */       };
/* 198 */     Action saveAction = new SaveAction(this.trackScheme);
/* 199 */     JButton captureUndecoratedButton = new JButton(captureUndecoratedAction);
/* 200 */     JButton captureDecoratedButton = new JButton(captureDecoratedAction);
/* 201 */     JButton saveButton = new JButton(saveAction);
/* 202 */     captureUndecoratedButton.setToolTipText("Capture undecorated TrackScheme (zoom=1).");
/* 203 */     captureDecoratedButton.setToolTipText("Capture TrackScheme with decorations.");
/* 204 */     saveButton.setToolTipText("Export to...");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 211 */     Action toggleDisplayDecorations = new AbstractAction(null, Icons.DISPLAY_DECORATIONS_ON_ICON)
/*     */       {
/*     */         
/*     */         public void actionPerformed(ActionEvent e)
/*     */         {
/* 216 */           (TrackSchemeToolbar.this.trackScheme.getGUI()).graphComponent.loopPaintDecorationLevel();
/*     */         }
/*     */       };
/*     */     
/* 220 */     JButton loopDisplayDecorationsButton = new JButton(toggleDisplayDecorations);
/* 221 */     loopDisplayDecorationsButton.setToolTipText("Loop display decorations.");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 229 */     JButton selectStyleButton = new JButton("Style:", Icons.SELECT_STYLE_ICON);
/* 230 */     selectStyleButton.setFont(Fonts.FONT);
/* 231 */     selectStyleButton.setToolTipText("Re-apply current style after model changes.");
/* 232 */     selectStyleButton.addActionListener(new ActionListener()
/*     */         {
/*     */ 
/*     */           
/*     */           public void actionPerformed(ActionEvent arg0)
/*     */           {
/* 238 */             (new Thread("TrackScheme re-applying style thread")
/*     */               {
/*     */                 
/*     */                 public void run()
/*     */                 {
/* 243 */                   TrackSchemeToolbar.this.trackScheme.doTrackStyle();
/* 244 */                   TrackSchemeToolbar.this.trackScheme.refresh();
/*     */                 }
/* 246 */               }).start();
/*     */           }
/*     */         });
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 253 */     final JComboBox<String> selectStyleBox = new JComboBox<>(TrackSchemeStylist.VERTEX_STYLE_NAMES.toArray(new String[0]));
/* 254 */     selectStyleBox.setPreferredSize(new Dimension(80, 20));
/* 255 */     selectStyleBox.setSelectedIndex(0);
/* 256 */     selectStyleBox.setMaximumSize(new Dimension(200, 30));
/* 257 */     selectStyleBox.setFont(Fonts.FONT);
/* 258 */     selectStyleBox.addActionListener(new ActionListener()
/*     */         {
/*     */ 
/*     */           
/*     */           public void actionPerformed(ActionEvent e)
/*     */           {
/* 264 */             final String selectedStyle = (String)selectStyleBox.getSelectedItem();
/* 265 */             (new Thread("TrackScheme changing style thread")
/*     */               {
/*     */                 
/*     */                 public void run()
/*     */                 {
/* 270 */                   TrackSchemeToolbar.this.trackScheme.stylist.setStyle(selectedStyle);
/* 271 */                   TrackSchemeToolbar.this.trackScheme.doTrackStyle();
/* 272 */                   TrackSchemeToolbar.this.trackScheme.refresh();
/*     */                 }
/* 274 */               }).start();
/*     */           }
/*     */         });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 285 */     add(redoLayoutButton);
/*     */     
/* 287 */     addSeparator();
/*     */     
/* 289 */     add(selectStyleButton);
/* 290 */     add(selectStyleBox);
/*     */     
/* 292 */     addSeparator();
/*     */     
/* 294 */     add(toggleThumbnailsButton);
/*     */     
/* 296 */     addSeparator();
/*     */     
/* 298 */     add(toggleLinkingButton);
/*     */     
/* 300 */     addSeparator();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 308 */     add(zoomInButton);
/* 309 */     add(zoomOutButton);
/* 310 */     add(resetZoomButton);
/*     */     
/* 312 */     addSeparator();
/*     */     
/* 314 */     add(captureUndecoratedButton);
/* 315 */     add(captureDecoratedButton);
/* 316 */     add(saveButton);
/*     */     
/* 318 */     addSeparator();
/*     */ 
/*     */ 
/*     */     
/* 322 */     add(loopDisplayDecorationsButton);
/*     */     
/* 324 */     addSeparator();
/* 325 */     add((Component)new SearchBar(this.trackScheme.getModel(), (TrackMateModelView)this.trackScheme));
/* 326 */     add(Box.createHorizontalGlue());
/*     */     
/* 328 */     Dimension dim = new Dimension(100, 30);
/* 329 */     setPreferredSize(dim);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/visualization/trackscheme/TrackSchemeToolbar.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */