/*    */ package fiji.plugin.trackmate.gui.wizard;
/*    */ 
/*    */ import java.awt.event.WindowAdapter;
/*    */ import java.awt.event.WindowEvent;
/*    */ import javax.swing.JFrame;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface WizardSequence
/*    */ {
/*    */   default JFrame run(String title) {
/* 45 */     WizardController controller = new WizardController(this);
/* 46 */     JFrame frame = new JFrame();
/* 47 */     frame.getContentPane().add(controller.getWizardPanel());
/* 48 */     frame.setDefaultCloseOperation(2);
/* 49 */     frame.setSize(350, 560);
/* 50 */     frame.setTitle(title);
/* 51 */     controller.init();
/* 52 */     frame.addWindowListener(new WindowAdapter()
/*    */         {
/*    */           
/*    */           public void windowClosing(WindowEvent e)
/*    */           {
/* 57 */             WizardSequence.this.onClose();
/*    */           }
/*    */         });
/* 60 */     return frame;
/*    */   }
/*    */   
/*    */   default void onClose() {}
/*    */   
/*    */   WizardPanelDescriptor current();
/*    */   
/*    */   WizardPanelDescriptor next();
/*    */   
/*    */   WizardPanelDescriptor previous();
/*    */   
/*    */   WizardPanelDescriptor logDescriptor();
/*    */   
/*    */   WizardPanelDescriptor configDescriptor();
/*    */   
/*    */   boolean hasNext();
/*    */   
/*    */   boolean hasPrevious();
/*    */   
/*    */   WizardPanelDescriptor save();
/*    */   
/*    */   void setCurrent(String paramString);
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/gui/wizard/WizardSequence.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */