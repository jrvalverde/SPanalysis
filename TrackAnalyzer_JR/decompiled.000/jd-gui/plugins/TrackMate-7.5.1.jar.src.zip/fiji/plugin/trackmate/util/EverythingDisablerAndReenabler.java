/*     */ package fiji.plugin.trackmate.util;
/*     */ 
/*     */ import java.awt.Component;
/*     */ import java.awt.Container;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class EverythingDisablerAndReenabler
/*     */ {
/*     */   private final Container rootContainerForWhatShouldBeDisabled;
/*     */   private final Class<?>[] componentClassesToBeIgnored;
/*  48 */   private final List<Component> componentsToReenable = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean disableHasBeenCalled = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EverythingDisablerAndReenabler(Container rootContainerForWhatShouldBeDisabled, Class<?>[] componentClassesToBeIgnored) {
/*  71 */     if (rootContainerForWhatShouldBeDisabled == null) throw new IllegalArgumentException(); 
/*  72 */     this.rootContainerForWhatShouldBeDisabled = rootContainerForWhatShouldBeDisabled;
/*  73 */     this.componentClassesToBeIgnored = componentClassesToBeIgnored;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setEnabled(boolean enable) {
/*  86 */     if (enable && this.disableHasBeenCalled) {
/*  87 */       reenable();
/*  88 */     } else if (!enable && !this.disableHasBeenCalled) {
/*  89 */       disable();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void disable() {
/* 101 */     if (this.disableHasBeenCalled) throw new IllegalStateException(); 
/* 102 */     this.disableHasBeenCalled = true;
/* 103 */     this.componentsToReenable.clear();
/* 104 */     disableEverythingInsideThisHierarchically(this.rootContainerForWhatShouldBeDisabled);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void reenable() {
/* 115 */     if (!this.disableHasBeenCalled) throw new IllegalStateException(); 
/* 116 */     this.disableHasBeenCalled = false;
/*     */     
/* 118 */     for (int i = this.componentsToReenable.size() - 1; i >= 0; i--)
/*     */     {
/* 120 */       ((Component)this.componentsToReenable.get(i)).setEnabled(true);
/*     */     }
/* 122 */     this.componentsToReenable.clear();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void disableEverythingInsideThisHierarchically(Container container) {
/* 128 */     Component[] components = container.getComponents();
/* 129 */     for (Component component : components) {
/*     */ 
/*     */       
/* 132 */       if (component != null) {
/*     */ 
/*     */ 
/*     */         
/* 136 */         if (component instanceof Container)
/*     */         {
/* 138 */           disableEverythingInsideThisHierarchically((Container)component);
/*     */         }
/*     */ 
/*     */         
/* 142 */         if (component.isEnabled()) {
/*     */           
/* 144 */           boolean found = false;
/* 145 */           if (this.componentClassesToBeIgnored != null)
/*     */           {
/* 147 */             for (Class<?> cls : this.componentClassesToBeIgnored) {
/*     */               
/* 149 */               if (component.getClass() == cls) {
/*     */                 
/* 151 */                 found = true;
/*     */                 break;
/*     */               } 
/*     */             } 
/*     */           }
/* 156 */           if (!found && component.isEnabled()) {
/*     */             
/* 158 */             component.setEnabled(false);
/* 159 */             this.componentsToReenable.add(component);
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/util/EverythingDisablerAndReenabler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */