/*    */ package fiji.plugin.trackmate.visualization.trackscheme;
/*    */ 
/*    */ import fiji.plugin.trackmate.Model;
/*    */ import fiji.plugin.trackmate.SelectionModel;
/*    */ import fiji.plugin.trackmate.Settings;
/*    */ import fiji.plugin.trackmate.gui.displaysettings.DisplaySettings;
/*    */ import fiji.plugin.trackmate.visualization.TrackMateModelView;
/*    */ import fiji.plugin.trackmate.visualization.ViewFactory;
/*    */ import javax.swing.ImageIcon;
/*    */ import org.scijava.plugin.Plugin;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Plugin(type = ViewFactory.class, visible = false)
/*    */ public class TrackSchemeFactory
/*    */   implements ViewFactory
/*    */ {
/*    */   public TrackMateModelView create(Model model, Settings settings, SelectionModel selectionModel, DisplaySettings displaySettings) {
/* 46 */     return (TrackMateModelView)new TrackScheme(model, selectionModel, displaySettings);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String getName() {
/* 52 */     return "TrackScheme";
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String getKey() {
/* 58 */     return "TRACKSCHEME";
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public ImageIcon getIcon() {
/* 64 */     return null;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String getInfoText() {
/* 70 */     return "<html>Not redacted!</html>";
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/visualization/trackscheme/TrackSchemeFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */