/*     */ package fiji.plugin.trackmate.visualization.trackscheme;
/*     */ 
/*     */ import com.mxgraph.canvas.mxGraphics2DCanvas;
/*     */ import com.mxgraph.model.mxCell;
/*     */ import com.mxgraph.shape.mxIShape;
/*     */ import com.mxgraph.swing.handler.mxGraphHandler;
/*     */ import com.mxgraph.swing.mxGraphComponent;
/*     */ import com.mxgraph.swing.view.mxCellEditor;
/*     */ import com.mxgraph.swing.view.mxICellEditor;
/*     */ import com.mxgraph.util.mxEventObject;
/*     */ import com.mxgraph.util.mxEventSource;
/*     */ import com.mxgraph.util.mxPoint;
/*     */ import com.mxgraph.view.mxCellState;
/*     */ import com.mxgraph.view.mxGraph;
/*     */ import com.mxgraph.view.mxGraphView;
/*     */ import fiji.plugin.trackmate.gui.displaysettings.DisplaySettings;
/*     */ import java.awt.Color;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.LayoutManager;
/*     */ import java.awt.Point;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.RenderingHints;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.event.KeyEvent;
/*     */ import java.awt.event.KeyListener;
/*     */ import java.awt.event.MouseAdapter;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.util.EventObject;
/*     */ import java.util.Map;
/*     */ import javax.swing.BorderFactory;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JScrollPane;
/*     */ import javax.swing.JTextField;
/*     */ import javax.swing.JViewport;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TrackSchemeGraphComponent
/*     */   extends mxGraphComponent
/*     */   implements mxEventSource.mxIEventListener
/*     */ {
/*     */   private static final long serialVersionUID = -1L;
/*     */   private static final int MAX_DECCORATION_LEVELS = 2;
/*  72 */   int[] columnWidths = new int[0];
/*     */ 
/*     */   
/*     */   Integer[] columnTrackIDs;
/*     */   
/*     */   private final TrackScheme trackScheme;
/*     */   
/*  79 */   private int paintDecorationLevel = 1;
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean spaceDown = false;
/*     */ 
/*     */ 
/*     */   
/*     */   private final DisplaySettings ds;
/*     */ 
/*     */ 
/*     */   
/*     */   public TrackSchemeGraphComponent(JGraphXAdapter graph, TrackScheme trackScheme, DisplaySettings ds) {
/*  92 */     super(graph);
/*  93 */     this.trackScheme = trackScheme;
/*  94 */     this.ds = ds;
/*     */     
/*  96 */     getViewport().setOpaque(true);
/*  97 */     getViewport().setBackground(ds.getTrackSchemeBackgroundColor1());
/*  98 */     setZoomFactor(2.0D);
/*     */     
/* 100 */     this.connectionHandler.addListener("connect", this);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 106 */     mxGraphics2DCanvas.putShape("scaledLabel", (mxIShape)new mxScaledLabelShape());
/*     */     
/* 108 */     setRowHeaderView(new RowHeader());
/* 109 */     setColumnHeaderView(new ColumnHeader());
/* 110 */     setCorner("UPPER_LEFT_CORNER", new TopLeftCorner());
/*     */ 
/*     */     
/* 113 */     addKeyListener(new KeyListener()
/*     */         {
/*     */           public void keyTyped(KeyEvent e) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           public void keyReleased(KeyEvent e) {
/* 123 */             if (e.getKeyCode() == 32) {
/* 124 */               TrackSchemeGraphComponent.this.spaceDown = false;
/*     */             }
/*     */           }
/*     */ 
/*     */           
/*     */           public void keyPressed(KeyEvent e) {
/* 130 */             if (e.getKeyCode() == 32 && !TrackSchemeGraphComponent.this.spaceDown) {
/* 131 */               TrackSchemeGraphComponent.this.spaceDown = true;
/*     */             }
/*     */           }
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JGraphXAdapter getGraph() {
/* 143 */     return (JGraphXAdapter)super.getGraph();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isToggleEvent(MouseEvent event) {
/* 149 */     return event.isShiftDown();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isPanningEvent(MouseEvent event) {
/* 155 */     return this.spaceDown;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected mxICellEditor createCellEditor() {
/* 165 */     mxCellEditor editor = new mxCellEditor(this)
/*     */       {
/*     */         
/*     */         public void startEditing(Object cell, EventObject evt)
/*     */         {
/* 170 */           this.textArea.setOpaque(true);
/* 171 */           this.textArea.setBorder(BorderFactory.createLineBorder(Color.ORANGE, 1));
/* 172 */           super.startEditing(cell, evt);
/*     */         }
/*     */       };
/* 175 */     editor.setShiftEnterSubmitsText(true);
/* 176 */     return (mxICellEditor)editor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected mxGraphHandler createGraphHandler() {
/* 187 */     return new mxGraphHandler(this)
/*     */       {
/*     */ 
/*     */         
/*     */         public void mousePressed(MouseEvent e)
/*     */         {
/* 193 */           if (this.graphComponent.isEnabled() && isEnabled() && !e.isConsumed() && !this.graphComponent.isForceMarqueeEvent(e)) {
/*     */             
/* 195 */             this.cell = this.graphComponent.getCellAt(e.getX(), e.getY(), false);
/* 196 */             this.initialCell = this.cell;
/*     */             
/* 198 */             if (this.cell != null) {
/*     */               
/* 200 */               if (isSelectEnabled() && !this.graphComponent.getGraph().isCellSelected(this.cell)) {
/*     */                 
/* 202 */                 this.graphComponent.selectCellForEvent(this.cell, e);
/* 203 */                 this.cell = null;
/*     */               } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */               
/* 210 */               if (isMoveEnabled() && !e.isPopupTrigger()) {
/*     */                 
/* 212 */                 start(e);
/* 213 */                 e.consume();
/*     */               } 
/*     */             } 
/*     */           } 
/*     */         }
/*     */ 
/*     */ 
/*     */         
/*     */         public void mouseReleased(MouseEvent e) {
/* 222 */           if (this.graphComponent.isEnabled() && isEnabled() && !e.isConsumed()) {
/*     */             
/* 224 */             mxGraph lGraph = this.graphComponent.getGraph();
/* 225 */             double dx = 0.0D;
/* 226 */             double dy = 0.0D;
/*     */             
/* 228 */             if (this.first != null && (this.cellBounds != null || this.movePreview.isActive())) {
/*     */               
/* 230 */               double scale = lGraph.getView().getScale();
/* 231 */               mxPoint trans = lGraph.getView().getTranslate();
/*     */               
/* 233 */               dx = (e.getX() - this.first.x);
/* 234 */               dy = (e.getY() - this.first.y);
/*     */               
/* 236 */               if (this.cellBounds != null) {
/*     */                 
/* 238 */                 double dxg = (this.cellBounds.getX() + dx) / scale - trans.getX();
/* 239 */                 double dyg = (this.cellBounds.getY() + dy) / scale - trans.getY();
/*     */                 
/* 241 */                 double x = (dxg + trans.getX()) * scale + this.bbox.getX() - this.cellBounds.getX();
/* 242 */                 double y = (dyg + trans.getY()) * scale + this.bbox.getY() - this.cellBounds.getY();
/*     */                 
/* 244 */                 dx = Math.round((x - this.bbox.getX()) / scale);
/* 245 */                 dy = Math.round((y - this.bbox.getY()) / scale);
/*     */               } 
/*     */             } 
/*     */             
/* 249 */             if (this.first == null || !this.graphComponent.isSignificant((e.getX() - this.first.x), (e.getY() - this.first.y))) {
/*     */ 
/*     */               
/* 252 */               if (this.cell != null && !e.isPopupTrigger() && isSelectEnabled() && (this.first != null || !isMoveEnabled()))
/*     */               {
/* 254 */                 this.graphComponent.selectCellForEvent(this.cell, e);
/*     */               }
/*     */ 
/*     */ 
/*     */               
/* 259 */               if (this.graphComponent.isFoldingEnabled() && this.graphComponent.hitFoldingIcon(this.initialCell, e.getX(), e.getY())) {
/*     */                 
/* 261 */                 fold(this.initialCell);
/*     */               
/*     */               }
/*     */               else {
/*     */ 
/*     */                 
/* 267 */                 Object tmp = this.graphComponent.getCellAt(e.getX(), e.getY(), this.graphComponent.isSwimlaneSelectionEnabled());
/*     */                 
/* 269 */                 if (this.cell == null && this.first == null)
/*     */                 {
/* 271 */                   if (tmp == null && e.getButton() == 1) {
/*     */                     
/* 273 */                     lGraph.clearSelection();
/*     */ 
/*     */ 
/*     */ 
/*     */                   
/*     */                   }
/* 279 */                   else if (lGraph.isSwimlane(tmp) && this.graphComponent.getCanvas().hitSwimlaneContent(this.graphComponent, lGraph.getView().getState(tmp), e.getX(), e.getY())) {
/*     */                     
/* 281 */                     this.graphComponent.selectCellForEvent(tmp, e);
/*     */                   } 
/*     */                 }
/*     */                 
/* 285 */                 if (this.graphComponent.isFoldingEnabled() && this.graphComponent.hitFoldingIcon(tmp, e.getX(), e.getY()))
/*     */                 {
/* 287 */                   fold(tmp);
/* 288 */                   e.consume();
/*     */                 }
/*     */               
/*     */               } 
/* 292 */             } else if (this.movePreview.isActive()) {
/*     */               
/* 294 */               if (this.graphComponent.isConstrainedEvent(e))
/*     */               {
/* 296 */                 if (Math.abs(dx) > Math.abs(dy)) {
/* 297 */                   dy = 0.0D;
/*     */                 } else {
/* 299 */                   dx = 0.0D;
/*     */                 } 
/*     */               }
/* 302 */               mxCellState markedState = this.marker.getMarkedState();
/* 303 */               Object target = (markedState != null) ? markedState.getCell() : null;
/*     */               
/* 305 */               if (target == null && isRemoveCellsFromParent() && shouldRemoveCellFromParent(lGraph.getModel().getParent(this.initialCell), this.cells, e)) {
/* 306 */                 target = lGraph.getDefaultParent();
/*     */               }
/* 308 */               boolean clone = (isCloneEnabled() && this.graphComponent.isCloneEvent(e));
/* 309 */               Object[] result = this.movePreview.stop(true, e, dx, dy, clone, target);
/*     */               
/* 311 */               if (this.cells != result) {
/* 312 */                 lGraph.setSelectionCells(result);
/*     */               }
/* 314 */               e.consume();
/*     */             }
/* 316 */             else if (isVisible()) {
/*     */               
/* 318 */               if (this.constrainedEvent)
/*     */               {
/* 320 */                 if (Math.abs(dx) > Math.abs(dy)) {
/* 321 */                   dy = 0.0D;
/*     */                 } else {
/* 323 */                   dx = 0.0D;
/*     */                 } 
/*     */               }
/* 326 */               mxCellState targetState = this.marker.getValidState();
/* 327 */               Object target = (targetState != null) ? targetState.getCell() : null;
/*     */               
/* 329 */               if (lGraph.isSplitEnabled() && lGraph.isSplitTarget(target, this.cells)) {
/* 330 */                 lGraph.splitEdge(target, this.cells, dx, dy);
/*     */               } else {
/* 332 */                 moveCells(this.cells, dx, dy, target, e);
/*     */               } 
/* 334 */               e.consume();
/*     */             } 
/*     */           } 
/*     */           
/* 338 */           reset();
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void paintBackground(Graphics g) {
/* 351 */     if (this.paintDecorationLevel == 0) {
/*     */       return;
/*     */     }
/* 354 */     int width = (getViewport().getView().getSize()).width;
/* 355 */     int height = (getViewport().getView().getSize()).height;
/* 356 */     double scale = this.graph.getView().getScale();
/*     */     
/* 358 */     Graphics2D g2d = (Graphics2D)g;
/* 359 */     g.setFont(this.ds.getFont().deriveFont((float)(12.0D * scale)));
/* 360 */     g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, this.ds.getUseAntialiasing() ? RenderingHints.VALUE_ANTIALIAS_ON : RenderingHints.VALUE_ANTIALIAS_OFF);
/* 361 */     Rectangle paintBounds = g.getClipBounds();
/*     */ 
/*     */     
/* 364 */     double xcs = 160.0D * scale;
/* 365 */     double ycs = 96.0D * scale;
/*     */     
/* 367 */     if (this.paintDecorationLevel > 1) {
/*     */ 
/*     */       
/* 370 */       g.setColor(this.ds.getTrackSchemeBackgroundColor2());
/* 371 */       double y = 0.0D;
/* 372 */       while (y < height) {
/*     */         
/* 374 */         if (y > paintBounds.y - ycs && y < (paintBounds.y + paintBounds.height)) {
/* 375 */           g.fillRect(0, (int)y, width, (int)ycs);
/*     */         }
/* 377 */         y += 2.0D * ycs;
/*     */       } 
/*     */     } 
/*     */     
/* 381 */     if (this.paintDecorationLevel > 0) {
/*     */       
/* 383 */       double x = xcs;
/*     */       
/* 385 */       if (null != this.columnWidths) {
/*     */         
/* 387 */         g.setColor(this.ds.getTrackSchemeDecorationColor());
/* 388 */         for (int i = 0; i < this.columnWidths.length; i++) {
/*     */           
/* 390 */           int cw = this.columnWidths[i];
/*     */           
/* 392 */           x += cw * xcs;
/* 393 */           g.drawLine((int)x, 0, (int)x, height);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 398 */     getColumnHeader().revalidate();
/* 399 */     getRowHeader().revalidate();
/* 400 */     getCorner("UPPER_LEFT_CORNER").revalidate();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void invoke(Object sender, mxEventObject evt) {
/* 411 */     Map<String, Object> props = evt.getProperties();
/* 412 */     Object obj = props.get("cell");
/* 413 */     mxCell cell = (mxCell)obj;
/* 414 */     this.trackScheme.addEdgeManually(cell);
/* 415 */     evt.consume();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void zoomTo(double newScale, boolean center) {
/* 421 */     mxGraphView view = this.graph.getView();
/* 422 */     double scale = view.getScale();
/*     */     
/* 424 */     mxPoint translate = (this.pageVisible && this.centerPage) ? getPageTranslate(newScale) : new mxPoint();
/* 425 */     this.graph.getView().scaleAndTranslate(newScale, translate.getX(), translate.getY());
/*     */     
/* 427 */     if (this.keepSelectionVisibleOnZoom && !this.graph.isSelectionEmpty()) {
/*     */       
/* 429 */       getGraphControl().scrollRectToVisible(view.getBoundingBox(this.graph.getSelectionCells()).getRectangle());
/*     */     }
/*     */     else {
/*     */       
/* 433 */       maintainScrollBar(true, newScale / scale, center);
/* 434 */       maintainScrollBar(false, newScale / scale, center);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void loopPaintDecorationLevel() {
/* 440 */     if (this.paintDecorationLevel++ >= 2) {
/* 441 */       this.paintDecorationLevel = 0;
/*     */     }
/* 443 */     repaint();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private class TopLeftCorner
/*     */     extends JPanel
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */ 
/*     */ 
/*     */     
/*     */     public TopLeftCorner() {
/* 456 */       setOpaque(true);
/* 457 */       setBackground(TrackSchemeGraphComponent.this.ds.getTrackSchemeBackgroundColor1());
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void paint(Graphics g) {
/* 463 */       double scale = TrackSchemeGraphComponent.this.graph.getView().getScale();
/* 464 */       double xcs = 160.0D * Math.min(1.0D, scale);
/* 465 */       double ycs = 96.0D * Math.min(1.0D, scale);
/* 466 */       g.setColor(TrackSchemeGraphComponent.this.ds.getTrackSchemeBackgroundColor1());
/* 467 */       g.fillRect(0, 0, (int)xcs, (int)ycs);
/* 468 */       g.setColor(TrackSchemeGraphComponent.this.ds.getTrackSchemeDecorationColor());
/* 469 */       g.drawLine(0, (int)ycs, (int)xcs, (int)ycs);
/* 470 */       g.drawLine((int)xcs, 0, (int)xcs, (int)ycs);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private class ColumnHeader
/*     */     extends JPanel
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */     
/*     */     public ColumnHeader() {
/* 481 */       setLayout((LayoutManager)null);
/* 482 */       setOpaque(true);
/* 483 */       setBackground(TrackSchemeGraphComponent.this.ds.getTrackSchemeBackgroundColor1());
/* 484 */       setToolTipText("Column header tool tip");
/* 485 */       addMouseListener(new MouseAdapter()
/*     */           {
/*     */ 
/*     */             
/*     */             public void mouseClicked(MouseEvent event)
/*     */             {
/* 491 */               if (event.getClickCount() != 2) {
/*     */                 return;
/*     */               }
/* 494 */               int x = (event.getPoint()).x;
/* 495 */               float scale = (float)TrackSchemeGraphComponent.this.graph.getView().getScale();
/*     */ 
/*     */               
/* 498 */               int xcs = Math.round(160.0F * scale);
/* 499 */               int ycs = Math.min(96, Math.round(96.0F * scale));
/*     */ 
/*     */               
/* 502 */               if (null != TrackSchemeGraphComponent.this.columnWidths) {
/*     */ 
/*     */                 
/* 505 */                 int xc = xcs; int column;
/* 506 */                 for (column = 0; column < TrackSchemeGraphComponent.this.columnWidths.length; column++) {
/*     */                   
/* 508 */                   int cw = TrackSchemeGraphComponent.this.columnWidths[column];
/* 509 */                   xc += cw * xcs;
/* 510 */                   if (x < xc) {
/*     */                     break;
/*     */                   }
/*     */                 } 
/* 514 */                 if (column >= TrackSchemeGraphComponent.this.columnWidths.length) {
/*     */                   return;
/*     */                 }
/* 517 */                 String oldName = TrackSchemeGraphComponent.this.trackScheme.getModel().getTrackModel().name(TrackSchemeGraphComponent.this.columnTrackIDs[column]);
/* 518 */                 final Integer trackID = TrackSchemeGraphComponent.this.columnTrackIDs[column];
/*     */                 
/* 520 */                 int cwidth = TrackSchemeGraphComponent.this.columnWidths[column] * xcs;
/*     */                 
/* 522 */                 if (column == 0) {
/* 523 */                   cwidth += xcs;
/*     */                 }
/* 525 */                 final JScrollPane scrollPane = new JScrollPane();
/* 526 */                 scrollPane.getViewport().setOpaque(false);
/* 527 */                 scrollPane.setVisible(false);
/* 528 */                 scrollPane.setOpaque(false);
/* 529 */                 scrollPane.setBounds(xc - cwidth, 0, cwidth, ycs);
/* 530 */                 scrollPane.setVisible(true);
/*     */ 
/*     */                 
/* 533 */                 final JTextField textArea = new JTextField(oldName);
/* 534 */                 textArea.setBorder(BorderFactory.createLineBorder(Color.ORANGE, 2));
/* 535 */                 textArea.setOpaque(true);
/* 536 */                 textArea.setBackground(TrackSchemeGraphComponent.this.ds.getTrackSchemeBackgroundColor1());
/* 537 */                 textArea.setHorizontalAlignment(0);
/* 538 */                 textArea.setFont(TrackSchemeGraphComponent.this.ds.getFont().deriveFont(12.0F * scale).deriveFont(1));
/* 539 */                 textArea.addActionListener(new ActionListener()
/*     */                     {
/*     */ 
/*     */ 
/*     */ 
/*     */                       
/*     */                       public void actionPerformed(ActionEvent arg0)
/*     */                       {
/* 547 */                         if (TrackSchemeGraphComponent.this.trackScheme.getModel().getTrackModel().unsortedTrackIDs(false).contains(trackID)) {
/*     */                           
/* 549 */                           String newname = textArea.getText();
/* 550 */                           TrackSchemeGraphComponent.this.trackScheme.getModel().getTrackModel().setName(trackID, newname);
/*     */                         } 
/* 552 */                         scrollPane.remove(textArea);
/* 553 */                         TrackSchemeGraphComponent.ColumnHeader.this.remove(scrollPane);
/* 554 */                         TrackSchemeGraphComponent.this.repaint();
/*     */                       }
/*     */                     });
/*     */                 
/* 558 */                 scrollPane.setViewportView(textArea);
/* 559 */                 TrackSchemeGraphComponent.ColumnHeader.this.add(scrollPane);
/*     */                 
/* 561 */                 textArea.revalidate();
/* 562 */                 textArea.requestFocusInWindow();
/* 563 */                 textArea.selectAll();
/*     */               } 
/*     */             }
/*     */           });
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public String getToolTipText(MouseEvent event) {
/* 572 */       Point point = event.getPoint();
/* 573 */       double scale = TrackSchemeGraphComponent.this.graph.getView().getScale();
/* 574 */       double xcs = 160.0D * scale;
/* 575 */       double x = xcs;
/*     */       
/* 577 */       if (null != TrackSchemeGraphComponent.this.columnWidths) {
/*     */         
/* 579 */         int index = 0;
/* 580 */         while (x < point.x) {
/*     */           
/* 582 */           if (index >= TrackSchemeGraphComponent.this.columnTrackIDs.length) {
/* 583 */             return "Single spots";
/*     */           }
/* 585 */           int cw = TrackSchemeGraphComponent.this.columnWidths[index++];
/* 586 */           x += cw * xcs;
/*     */         } 
/*     */         
/* 589 */         if (index == 0) {
/* 590 */           index = 1;
/*     */         }
/* 592 */         String columnName = TrackSchemeGraphComponent.this.trackScheme.getModel().getTrackModel().name(TrackSchemeGraphComponent.this.columnTrackIDs[index - 1]);
/* 593 */         if (null == columnName) {
/* 594 */           columnName = "Name not set";
/*     */         }
/* 596 */         return columnName;
/*     */       } 
/* 598 */       return "";
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void paint(Graphics g) {
/* 604 */       Graphics2D g2d = (Graphics2D)g;
/* 605 */       double scale = TrackSchemeGraphComponent.this.graph.getView().getScale();
/*     */       
/* 607 */       float fontScale = (float)(12.0D * Math.min(1.0D, scale));
/* 608 */       g.setFont(TrackSchemeGraphComponent.this.ds.getFont().deriveFont(fontScale));
/* 609 */       g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
/* 610 */       Rectangle paintBounds = g.getClipBounds();
/* 611 */       g.setColor(TrackSchemeGraphComponent.this.ds.getTrackSchemeBackgroundColor1());
/* 612 */       g.fillRect(paintBounds.x, paintBounds.y, paintBounds.x + paintBounds.width, paintBounds.height);
/*     */ 
/*     */       
/* 615 */       double xcs = 160.0D * scale;
/* 616 */       double ycs = 96.0D * Math.min(1.0D, scale);
/*     */       
/* 618 */       g.setColor(TrackSchemeGraphComponent.this.ds.getTrackSchemeDecorationColor());
/* 619 */       g.drawLine(paintBounds.x, (int)ycs, paintBounds.x + paintBounds.width, (int)ycs);
/*     */       
/* 621 */       double x = xcs;
/*     */       
/* 623 */       if (null != TrackSchemeGraphComponent.this.columnWidths)
/*     */       {
/* 625 */         for (int i = 0; i < TrackSchemeGraphComponent.this.columnWidths.length; i++) {
/*     */           
/* 627 */           int cw = TrackSchemeGraphComponent.this.columnWidths[i];
/* 628 */           String columnName = TrackSchemeGraphComponent.this.trackScheme.getModel().getTrackModel().name(TrackSchemeGraphComponent.this.columnTrackIDs[i]);
/* 629 */           if (null == columnName) {
/* 630 */             columnName = "Name not set";
/*     */           }
/* 632 */           g.setColor(TrackSchemeGraphComponent.this.ds.getTrackSchemeForegroundColor());
/*     */           
/* 634 */           if (i == 0) {
/* 635 */             g.drawString(columnName, 20, (int)(ycs / 2.0D));
/*     */           } else {
/* 637 */             g.drawString(columnName, (int)(x + 20.0D), (int)(ycs / 2.0D));
/*     */           } 
/* 639 */           x += cw * xcs;
/* 640 */           g.setColor(TrackSchemeGraphComponent.this.ds.getTrackSchemeDecorationColor());
/* 641 */           g.drawLine((int)x, 0, (int)x, (int)ycs);
/*     */         } 
/*     */       }
/*     */ 
/*     */       
/* 646 */       g.setColor(Color.decode("#FF00FF"));
/* 647 */       g.drawString("Single spots", (int)(x + 20.0D), (int)(ycs / 2.0D));
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Dimension getPreferredSize() {
/* 653 */       double scale = Math.min(1.0D, TrackSchemeGraphComponent.this.graph.getView().getScale());
/* 654 */       double ycs = 96.0D * scale + 1.0D;
/* 655 */       int width = (TrackSchemeGraphComponent.this.getViewport().getView().getSize()).width;
/* 656 */       return new Dimension(width, (int)ycs);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private class RowHeader
/*     */     extends JPanel
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */     
/*     */     public RowHeader() {
/* 667 */       setOpaque(true);
/* 668 */       setBackground(TrackSchemeGraphComponent.this.ds.getTrackSchemeBackgroundColor1());
/* 669 */       setToolTipText("Row header tooltip");
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public String getToolTipText(MouseEvent event) {
/* 675 */       Point point = event.getPoint();
/* 676 */       double scale = TrackSchemeGraphComponent.this.graph.getView().getScale();
/* 677 */       int frame = (int)(point.y / 96.0D * scale);
/* 678 */       return "frame " + frame;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void paint(Graphics g) {
/* 685 */       Graphics2D g2d = (Graphics2D)g;
/* 686 */       double scale = TrackSchemeGraphComponent.this.graph.getView().getScale();
/*     */       
/* 688 */       float fontScale = (float)(12.0D * Math.min(1.0D, scale));
/* 689 */       g.setFont(TrackSchemeGraphComponent.this.ds.getFont().deriveFont(fontScale));
/* 690 */       g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, TrackSchemeGraphComponent.this.ds.getUseAntialiasing() ? RenderingHints.VALUE_ANTIALIAS_ON : RenderingHints.VALUE_ANTIALIAS_OFF);
/* 691 */       Rectangle paintBounds = g.getClipBounds();
/*     */       
/* 693 */       int height = (TrackSchemeGraphComponent.this.viewport.getView().getSize()).height;
/*     */ 
/*     */       
/* 696 */       double xcs = 160.0D * Math.min(1.0D, scale);
/* 697 */       double ycs = 96.0D * scale;
/*     */ 
/*     */       
/* 700 */       g.setColor(TrackSchemeGraphComponent.this.ds.getTrackSchemeBackgroundColor1());
/* 701 */       g.fillRect(paintBounds.x, paintBounds.y, paintBounds.width, paintBounds.height);
/*     */       
/* 703 */       double y = 0.0D;
/* 704 */       if (TrackSchemeGraphComponent.this.paintDecorationLevel > 1) {
/*     */         
/* 706 */         g.setColor(TrackSchemeGraphComponent.this.ds.getTrackSchemeBackgroundColor2());
/* 707 */         while (y < height) {
/*     */           
/* 709 */           if (y > paintBounds.y - ycs && y < (paintBounds.y + paintBounds.height)) {
/* 710 */             g.fillRect(0, (int)y, (int)xcs, (int)ycs);
/*     */           }
/* 712 */           y += 2.0D * ycs;
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 717 */       g.setColor(TrackSchemeGraphComponent.this.ds.getTrackSchemeDecorationColor());
/* 718 */       if (xcs > paintBounds.x && xcs < (paintBounds.x + paintBounds.width)) {
/* 719 */         g.drawLine((int)xcs, paintBounds.y, (int)xcs, paintBounds.y + paintBounds.height);
/*     */       }
/*     */       
/* 722 */       g.setColor(TrackSchemeGraphComponent.this.ds.getTrackSchemeForegroundColor());
/* 723 */       double x = xcs / 4.0D;
/* 724 */       y = ycs / 2.0D;
/*     */       
/* 726 */       if (xcs > paintBounds.x)
/*     */       {
/* 728 */         while (y < height) {
/*     */           
/* 730 */           if (y > paintBounds.y - ycs && y < (paintBounds.y + paintBounds.height)) {
/*     */             
/* 732 */             int frame = (int)(y / ycs);
/* 733 */             g.drawString(String.format("frame %d", new Object[] { Integer.valueOf(frame) }), (int)x, (int)Math.round(y + 12.0D * scale));
/*     */           } 
/* 735 */           y += ycs;
/*     */         } 
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Dimension getPreferredSize() {
/* 743 */       double scale = Math.min(1.0D, TrackSchemeGraphComponent.this.graph.getView().getScale());
/* 744 */       double xcs = 160.0D * scale + 1.0D;
/* 745 */       return new Dimension((int)xcs, (int)TrackSchemeGraphComponent.this.viewport.getPreferredSize().getHeight());
/*     */     }
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/visualization/trackscheme/TrackSchemeGraphComponent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */