/*     */ package fiji.plugin.trackmate.gui.displaysettings;
/*     */ 
/*     */ import java.awt.GridBagConstraints;
/*     */ import java.awt.GridBagLayout;
/*     */ import java.awt.Insets;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import javax.swing.Box;
/*     */ import javax.swing.JCheckBox;
/*     */ import javax.swing.JColorChooser;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JSeparator;
/*     */ import javax.swing.SwingUtilities;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DisplaySettingsPanel
/*     */   extends JPanel
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private static final int tfCols = 4;
/*     */   private final JColorChooser colorChooser;
/*     */   private final List<StyleElements.StyleElement> styleElements;
/*     */   
/*     */   public DisplaySettingsPanel(DisplaySettings ds) {
/*  89 */     super(new GridBagLayout());
/*     */     
/*  91 */     this.colorChooser = new JColorChooser();
/*  92 */     this.styleElements = styleElements(ds);
/*     */     
/*  94 */     ds.listeners().add(() -> {
/*     */           this.styleElements.forEach(StyleElements.StyleElement::update);
/*     */           
/*     */           repaint();
/*     */         });
/*  99 */     final GridBagConstraints c = new GridBagConstraints();
/* 100 */     c.fill = 2;
/* 101 */     c.weightx = 1.0D;
/* 102 */     c.gridwidth = 1;
/* 103 */     c.gridx = 0;
/* 104 */     c.gridy = 0;
/*     */     
/* 106 */     c.insets = new Insets(2, 5, 2, 5);
/*     */     
/* 108 */     this.styleElements.forEach(element -> element.accept(new StyleElements.StyleElementVisitor()
/*     */           {
/*     */ 
/*     */             
/*     */             public void visit(StyleElements.Separator element)
/*     */             {
/* 114 */               DisplaySettingsPanel.this.add(Box.createVerticalStrut(10), c);
/* 115 */               c.gridy++;
/* 116 */               addToLayout(new JSeparator(0));
/*     */             }
/*     */ 
/*     */ 
/*     */             
/*     */             public void visit(StyleElements.LabelElement element) {
/* 122 */               JLabel label = new JLabel(element.getLabel());
/* 123 */               label.setFont(DisplaySettingsPanel.this.getFont().deriveFont(1).deriveFont(DisplaySettingsPanel.this.getFont().getSize() + 2.0F));
/* 124 */               addToLayout(label);
/*     */             }
/*     */ 
/*     */ 
/*     */             
/*     */             public void visit(StyleElements.BooleanElement element) {
/* 130 */               JCheckBox checkbox = StyleElements.linkedCheckBox(element, "");
/* 131 */               checkbox.setHorizontalAlignment(11);
/* 132 */               addToLayout(checkbox, new JLabel(element
/*     */                     
/* 134 */                     .getLabel()));
/*     */             }
/*     */ 
/*     */ 
/*     */             
/*     */             public void visit(StyleElements.BoundedDoubleElement element) {
/* 140 */               addToLayout(
/* 141 */                   StyleElements.linkedSliderPanel(element, 4, 0.1D), new JLabel(element
/* 142 */                     .getLabel()));
/*     */             }
/*     */ 
/*     */ 
/*     */             
/*     */             public void visit(StyleElements.DoubleElement element) {
/* 148 */               addToLayout(
/* 149 */                   StyleElements.linkedFormattedTextField(element), new JLabel(element
/* 150 */                     .getLabel()));
/*     */             }
/*     */ 
/*     */ 
/*     */             
/*     */             public void visit(StyleElements.IntElement element) {
/* 156 */               addToLayout(
/* 157 */                   StyleElements.linkedSliderPanel(element, 4), new JLabel(element
/* 158 */                     .getLabel()));
/*     */             }
/*     */ 
/*     */ 
/*     */             
/*     */             public void visit(StyleElements.ColorElement element) {
/* 164 */               addToLayoutFlushRight(
/* 165 */                   StyleElements.linkedColorButton(element, DisplaySettingsPanel.this.colorChooser), new JLabel(element
/* 166 */                     .getLabel()));
/*     */             }
/*     */ 
/*     */ 
/*     */             
/*     */             public void visit(StyleElements.FeatureElement element) {
/* 172 */               addToLayout(
/* 173 */                   (JComponent)StyleElements.linkedFeatureSelector(element), new JLabel(element
/* 174 */                     .getLabel()));
/*     */             }
/*     */ 
/*     */ 
/*     */             
/*     */             public <E> void visit(StyleElements.EnumElement<?> element) {
/* 180 */               addToLayout(
/* 181 */                   StyleElements.linkedComboBoxEnumSelector(element), new JLabel(element
/* 182 */                     .getLabel()));
/*     */             }
/*     */ 
/*     */ 
/*     */             
/*     */             public void visit(StyleElements.ColormapElement element) {
/* 188 */               addToLayout(
/* 189 */                   StyleElements.linkedColormapChooser(element), new JLabel(element
/* 190 */                     .getLabel()));
/*     */             }
/*     */ 
/*     */ 
/*     */             
/*     */             public void visit(StyleElements.FontElement element) {
/* 196 */               addToLayout(
/* 197 */                   StyleElements.linkedFontButton(element, SwingUtilities.getWindowAncestor(DisplaySettingsPanel.this)), new JLabel(element
/* 198 */                     .getLabel()));
/*     */             }
/*     */ 
/*     */             
/*     */             private void addToLayout(JComponent comp1, JComponent comp2) {
/* 203 */               c.gridwidth = 1;
/* 204 */               c.anchor = 22;
/* 205 */               DisplaySettingsPanel.this.add(comp1, c);
/* 206 */               c.gridx++;
/* 207 */               c.weightx = 0.0D;
/* 208 */               c.anchor = 21;
/* 209 */               DisplaySettingsPanel.this.add(comp2, c);
/* 210 */               c.gridx = 0;
/* 211 */               c.weightx = 1.0D;
/* 212 */               c.gridy++;
/*     */             }
/*     */ 
/*     */             
/*     */             private void addToLayoutFlushRight(JComponent comp1, JComponent comp2) {
/* 217 */               c.fill = c.gridwidth = 1;
/*     */               
/* 219 */               c.fill = 0;
/* 220 */               c.anchor = 13;
/* 221 */               DisplaySettingsPanel.this.add(comp1, c);
/* 222 */               c.gridx++;
/* 223 */               c.weightx = 0.0D;
/* 224 */               c.fill = 2;
/* 225 */               c.anchor = 21;
/* 226 */               DisplaySettingsPanel.this.add(comp2, c);
/* 227 */               c.gridx = 0;
/* 228 */               c.weightx = 1.0D;
/* 229 */               c.gridy++;
/*     */             }
/*     */ 
/*     */             
/*     */             private void addToLayout(JComponent comp) {
/* 234 */               c.gridwidth = 2;
/* 235 */               c.anchor = 21;
/* 236 */               c.gridx = 0;
/* 237 */               c.weightx = 1.0D;
/* 238 */               DisplaySettingsPanel.this.add(comp, c);
/* 239 */               c.gridy++;
/*     */             }
/*     */           }));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private List<StyleElements.StyleElement> styleElements(DisplaySettings ds) {
/* 247 */     return Arrays.asList(new StyleElements.StyleElement[] {
/*     */           
/* 249 */           StyleElements.separator(), 
/*     */           
/* 251 */           StyleElements.label("Spots"), 
/* 252 */           StyleElements.booleanElement("draw spots", ds::isSpotVisible, ds::setSpotVisible), 
/* 253 */           StyleElements.booleanElement("draw spots as ROIs", ds::isSpotDisplayedAsRoi, ds::setSpotDisplayedAsRoi), 
/* 254 */           StyleElements.booleanElement("draw spots filled", ds::isSpotFilled, ds::setSpotFilled), 
/* 255 */           StyleElements.boundedDoubleElement("spot alpha transparency", 0.0D, 1.0D, ds::getSpotTransparencyAlpha, ds::setSpotTransparencyAlpha), 
/* 256 */           StyleElements.booleanElement("show spot names", ds::isSpotShowName, ds::setSpotShowName), 
/* 257 */           StyleElements.boundedDoubleElement("spot radius ratio", 0.0D, 20.0D, ds::getSpotDisplayRadius, ds::setSpotDisplayRadius), 
/* 258 */           StyleElements.featureElement("spot color", ds::getSpotColorByType, ds::getSpotColorByFeature, (type, feature) -> ds.setSpotColorBy(type, feature)), 
/* 259 */           StyleElements.doubleElement("spot display min", ds::getSpotMin, m -> ds.setSpotMinMax(m.doubleValue(), ds.getSpotMax())), 
/* 260 */           StyleElements.doubleElement("spot display max", ds::getSpotMax, m -> ds.setSpotMinMax(ds.getSpotMin(), m.doubleValue())), 
/* 261 */           StyleElements.colorElement("spot uniform color", ds::getSpotUniformColor, ds::setSpotUniformColor), 
/*     */           
/* 263 */           StyleElements.separator(), 
/*     */           
/* 265 */           StyleElements.label("Tracks"), 
/* 266 */           StyleElements.booleanElement("draw tracks", ds::isTrackVisible, ds::setTrackVisible), 
/* 267 */           StyleElements.enumElement("track display mode", DisplaySettings.TrackDisplayMode.values(), ds::getTrackDisplayMode, ds::setTrackDisplayMode), 
/* 268 */           StyleElements.featureElement("track color", ds::getTrackColorByType, ds::getTrackColorByFeature, (type, feature) -> ds.setTrackColorBy(type, feature)), 
/* 269 */           StyleElements.doubleElement("track display min", ds::getTrackMin, m -> ds.setTrackMinMax(m.doubleValue(), ds.getTrackMax())), 
/* 270 */           StyleElements.doubleElement("track display max", ds::getTrackMax, m -> ds.setTrackMinMax(ds.getTrackMin(), m.doubleValue())), 
/* 271 */           StyleElements.colorElement("track uniform color", ds::getTrackUniformColor, ds::setTrackUniformColor), 
/* 272 */           StyleElements.booleanElement("fade track in time", ds::isFadeTracks, ds::setFadeTracks), 
/* 273 */           StyleElements.intElement("track fade range", 0, 500, ds::getFadeTrackRange, ds::setFadeTrackRange), 
/*     */           
/* 275 */           StyleElements.separator(), 
/*     */           
/* 277 */           StyleElements.label("General"), 
/*     */           
/* 279 */           StyleElements.colormapElement("colormap", ds::getColormap, ds::setColormap), 
/*     */           
/* 281 */           StyleElements.booleanElement("limit Z-depth", ds::isZDrawingDepthLimited, ds::setZDrawingDepthLimited), 
/* 282 */           StyleElements.boundedDoubleElement("drawing Z-depth", 0.0D, 1000.0D, ds::getZDrawingDepth, ds::setZDrawingDepth), 
/*     */           
/* 284 */           StyleElements.colorElement("selection color", ds::getHighlightColor, ds::setHighlightColor), 
/* 285 */           StyleElements.colorElement("color for missing values", ds::getMissingValueColor, ds::setMissingValueColor), 
/* 286 */           StyleElements.colorElement("color for undefined values", ds::getUndefinedValueColor, ds::setUndefinedValueColor),
/*     */           
/* 288 */           StyleElements.boundedDoubleElement("line thickness", 0.0D, 10.0D, ds::getLineThickness, ds::setLineThickness), 
/* 289 */           StyleElements.boundedDoubleElement("selection line thickness", 0.0D, 10.0D, ds::getSelectionLineThickness, ds::setSelectionLineThickness), 
/* 290 */           StyleElements.fontElement("font", ds::getFont, ds::setFont), 
/*     */           
/* 292 */           StyleElements.booleanElement("anti-aliasing", ds::getUseAntialiasing, ds::setUseAntialiasing), 
/*     */           
/* 294 */           StyleElements.separator(), 
/*     */           
/* 296 */           StyleElements.label("TrackScheme"), 
/*     */           
/* 298 */           StyleElements.colorElement("foreground color", ds::getTrackSchemeForegroundColor, ds::setTrackSchemeForegroundColor), 
/* 299 */           StyleElements.colorElement("background color 1", ds::getTrackSchemeBackgroundColor1, ds::setTrackSchemeBackgroundColor1), 
/* 300 */           StyleElements.colorElement("background color 2", ds::getTrackSchemeBackgroundColor2, ds::setTrackSchemeBackgroundColor2), 
/* 301 */           StyleElements.colorElement("decoration color", ds::getTrackSchemeDecorationColor, ds::setTrackSchemeDecorationColor), 
/* 302 */           StyleElements.booleanElement("fill box", ds::isTrackSchemeFillBox, ds::setTrackschemeFillBox), 
/*     */           
/* 304 */           StyleElements.separator()
/*     */         });
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/gui/displaysettings/DisplaySettingsPanel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */