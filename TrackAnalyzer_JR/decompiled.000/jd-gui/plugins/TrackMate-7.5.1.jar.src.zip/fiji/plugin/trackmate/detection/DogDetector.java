/*     */ package fiji.plugin.trackmate.detection;
/*     */ 
/*     */ import net.imglib2.Cursor;
/*     */ import net.imglib2.Dimensions;
/*     */ import net.imglib2.Interval;
/*     */ import net.imglib2.IterableInterval;
/*     */ import net.imglib2.RandomAccessible;
/*     */ import net.imglib2.RandomAccessibleInterval;
/*     */ import net.imglib2.algorithm.dog.DifferenceOfGaussian;
/*     */ import net.imglib2.algorithm.gauss3.Gauss3;
/*     */ import net.imglib2.exception.IncompatibleTypeException;
/*     */ import net.imglib2.img.Img;
/*     */ import net.imglib2.type.NativeType;
/*     */ import net.imglib2.type.numeric.RealType;
/*     */ import net.imglib2.type.numeric.real.FloatType;
/*     */ import net.imglib2.util.Util;
/*     */ import net.imglib2.view.ExtendedRandomAccessibleInterval;
/*     */ import net.imglib2.view.IntervalView;
/*     */ import net.imglib2.view.Views;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DogDetector<T extends RealType<T> & NativeType<T>>
/*     */   extends LogDetector<T>
/*     */ {
/*     */   public static final String BASE_ERROR_MESSAGE = "DogDetector: ";
/*     */   
/*     */   public DogDetector(RandomAccessible<T> img, Interval interval, double[] calibration, double radius, double threshold, boolean doSubPixelLocalization, boolean doMedianFilter) {
/*  53 */     super(img, interval, calibration, radius, threshold, doSubPixelLocalization, doMedianFilter);
/*  54 */     this.baseErrorMessage = "DogDetector: ";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean process() {
/*     */     Img<RealType> img;
/*  65 */     long start = System.currentTimeMillis();
/*     */     
/*  67 */     IntervalView intervalView1 = Views.interval(this.img, this.interval);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  73 */     if (this.doMedianFilter) {
/*     */       
/*  75 */       img = DetectionUtils.applyMedianFilter((RandomAccessibleInterval<RealType>)intervalView1);
/*  76 */       if (null == img) {
/*     */         
/*  78 */         this.errorMessage = "DogDetector: Failed to apply median filter.";
/*  79 */         return false;
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  87 */     ExtendedRandomAccessibleInterval extendedRandomAccessibleInterval = Views.extendMirrorSingle((RandomAccessibleInterval)img);
/*     */     
/*  89 */     long[] min = new long[this.interval.numDimensions()];
/*  90 */     this.interval.min(min);
/*  91 */     FloatType type = new FloatType();
/*  92 */     IntervalView intervalView2 = Views.translate((RandomAccessibleInterval)Util.getArrayOrCellImgFactory((Dimensions)this.interval, (NativeType)type).create((Dimensions)this.interval), min);
/*  93 */     IntervalView intervalView3 = Views.translate((RandomAccessibleInterval)Util.getArrayOrCellImgFactory((Dimensions)this.interval, (NativeType)type).create((Dimensions)this.interval), min);
/*     */     
/*  95 */     double sigma1 = this.radius / Math.sqrt(this.interval.numDimensions()) * 0.9D;
/*  96 */     double sigma2 = this.radius / Math.sqrt(this.interval.numDimensions()) * 1.1D;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 103 */     double[] cal = new double[this.img.numDimensions()];
/* 104 */     for (int d = 0; d < cal.length; d++)
/* 105 */       cal[d] = this.calibration[d]; 
/* 106 */     double[][] sigmas = DifferenceOfGaussian.computeSigmas(0.5D, 2.0D, cal, sigma1, sigma2);
/*     */     
/*     */     try {
/* 109 */       Gauss3.gauss(sigmas[1], (RandomAccessible)extendedRandomAccessibleInterval, (RandomAccessibleInterval)intervalView3, this.numThreads);
/* 110 */       Gauss3.gauss(sigmas[0], (RandomAccessible)extendedRandomAccessibleInterval, (RandomAccessibleInterval)intervalView2, this.numThreads);
/*     */     }
/* 112 */     catch (IncompatibleTypeException e) {
/*     */       
/* 114 */       e.printStackTrace();
/*     */     } 
/*     */     
/* 117 */     IterableInterval<FloatType> dogIterable = Views.iterable((RandomAccessibleInterval)intervalView2);
/* 118 */     IterableInterval<FloatType> tmpIterable = Views.iterable((RandomAccessibleInterval)intervalView3);
/* 119 */     Cursor<FloatType> dogCursor = dogIterable.cursor();
/* 120 */     Cursor<FloatType> tmpCursor = tmpIterable.cursor();
/* 121 */     while (dogCursor.hasNext()) {
/* 122 */       ((FloatType)dogCursor.next()).sub((FloatType)tmpCursor.next());
/*     */     }
/* 124 */     this.spots = DetectionUtils.findLocalMaxima((RandomAccessibleInterval<FloatType>)intervalView2, this.threshold, this.calibration, this.radius, this.doSubPixelLocalization, this.numThreads);
/*     */     
/* 126 */     long end = System.currentTimeMillis();
/* 127 */     this.processingTime = end - start;
/*     */     
/* 129 */     return true;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/detection/DogDetector.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */