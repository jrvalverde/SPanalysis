/*    */ package fiji.plugin.trackmate.tracking.sparselap;
/*    */ 
/*    */ import fiji.plugin.trackmate.Model;
/*    */ import fiji.plugin.trackmate.gui.components.ConfigurationPanel;
/*    */ import fiji.plugin.trackmate.gui.components.tracker.SimpleLAPTrackerSettingsPanel;
/*    */ import fiji.plugin.trackmate.tracking.SpotTrackerFactory;
/*    */ import org.scijava.plugin.Plugin;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Plugin(type = SpotTrackerFactory.class)
/*    */ public class SimpleSparseLAPTrackerFactory
/*    */   extends SparseLAPTrackerFactory
/*    */ {
/*    */   public static final String THIS2_TRACKER_KEY = "SIMPLE_SPARSE_LAP_TRACKER";
/*    */   public static final String THIS2_NAME = "Simple LAP tracker";
/*    */   public static final String THIS2_INFO_TEXT = "<html>This tracker is identical to the sparse LAP tracker present in this trackmate, except that it <br>proposes fewer tuning options. Namely, only gap closing is allowed, based solely on <br>a distance and time condition. Track splitting and merging are not allowed, resulting <br>in having non-branching tracks. </html>";
/*    */   
/*    */   public String getKey() {
/* 48 */     return "SIMPLE_SPARSE_LAP_TRACKER";
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String getName() {
/* 54 */     return "Simple LAP tracker";
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String getInfoText() {
/* 60 */     return "<html>This tracker is identical to the sparse LAP tracker present in this trackmate, except that it <br>proposes fewer tuning options. Namely, only gap closing is allowed, based solely on <br>a distance and time condition. Track splitting and merging are not allowed, resulting <br>in having non-branching tracks. </html>";
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public ConfigurationPanel getTrackerConfigurationPanel(Model model) {
/* 66 */     String spaceUnits = model.getSpaceUnits();
/* 67 */     return (ConfigurationPanel)new SimpleLAPTrackerSettingsPanel(getName(), "<html>This tracker is identical to the sparse LAP tracker present in this trackmate, except that it <br>proposes fewer tuning options. Namely, only gap closing is allowed, based solely on <br>a distance and time condition. Track splitting and merging are not allowed, resulting <br>in having non-branching tracks. </html>", spaceUnits);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public SimpleSparseLAPTrackerFactory copy() {
/* 73 */     return new SimpleSparseLAPTrackerFactory();
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/tracking/sparselap/SimpleSparseLAPTrackerFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */