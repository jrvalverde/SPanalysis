/*     */ package fiji.plugin.trackmate.gui.components;
/*     */ 
/*     */ import fiji.plugin.trackmate.TrackMateModule;
/*     */ import fiji.plugin.trackmate.gui.Fonts;
/*     */ import fiji.plugin.trackmate.providers.AbstractProvider;
/*     */ import java.awt.Component;
/*     */ import java.awt.GridBagConstraints;
/*     */ import java.awt.GridBagLayout;
/*     */ import java.awt.Insets;
/*     */ import java.awt.event.ActionEvent;
/*     */ import javax.swing.DefaultComboBoxModel;
/*     */ import javax.swing.DefaultListCellRenderer;
/*     */ import javax.swing.JComboBox;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JList;
/*     */ import javax.swing.JPanel;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ModuleChooserPanel<K extends TrackMateModule>
/*     */   extends JPanel
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private final AbstractProvider<K> provider;
/*     */   private final JComboBox<String> cmbbox;
/*     */   
/*     */   public ModuleChooserPanel(AbstractProvider<K> provider, String typeName, String selectedKey) {
/*  54 */     this.provider = provider;
/*     */     
/*  56 */     GridBagLayout gridBagLayout = new GridBagLayout();
/*  57 */     gridBagLayout.columnWidths = new int[] { 430, 0 };
/*  58 */     gridBagLayout.rowHeights = new int[] { 16, 27, 209, 0 };
/*  59 */     gridBagLayout.columnWeights = new double[] { 1.0D, Double.MIN_VALUE };
/*  60 */     gridBagLayout.rowWeights = new double[] { 0.0D, 0.0D, 0.0D, Double.MIN_VALUE };
/*  61 */     setLayout(gridBagLayout);
/*     */     
/*  63 */     JLabel lblHeader = new JLabel();
/*  64 */     GridBagConstraints gbcLblHeader = new GridBagConstraints();
/*  65 */     gbcLblHeader.fill = 1;
/*  66 */     gbcLblHeader.insets = new Insets(5, 5, 5, 5);
/*  67 */     gbcLblHeader.gridx = 0;
/*  68 */     gbcLblHeader.gridy = 0;
/*  69 */     add(lblHeader, gbcLblHeader);
/*  70 */     lblHeader.setFont(Fonts.BIG_FONT);
/*  71 */     lblHeader.setText("<html>Select " + (
/*     */         
/*  73 */         startWithVowel(typeName) ? "an " : "a ") + "<b>" + typeName + "</b></html>");
/*     */ 
/*     */ 
/*     */     
/*  77 */     this.cmbbox = new JComboBox<>();
/*  78 */     this.cmbbox.setModel(new DefaultComboBoxModel<>((String[])provider.getVisibleKeys().toArray((Object[])new String[0])));
/*  79 */     this.cmbbox.setRenderer(new MyListCellRenderer());
/*  80 */     GridBagConstraints gbcCmbbox = new GridBagConstraints();
/*  81 */     gbcCmbbox.fill = 1;
/*  82 */     gbcCmbbox.insets = new Insets(5, 5, 5, 5);
/*  83 */     gbcCmbbox.gridx = 0;
/*  84 */     gbcCmbbox.gridy = 1;
/*  85 */     add(this.cmbbox, gbcCmbbox);
/*  86 */     this.cmbbox.setFont(Fonts.FONT);
/*     */     
/*  88 */     JLabel lblInfo = new JLabel();
/*  89 */     lblInfo.setFont(Fonts.FONT.deriveFont(2));
/*  90 */     GridBagConstraints gbcLblInfo = new GridBagConstraints();
/*  91 */     gbcLblInfo.insets = new Insets(5, 5, 5, 5);
/*  92 */     gbcLblInfo.fill = 1;
/*  93 */     gbcLblInfo.gridx = 0;
/*  94 */     gbcLblInfo.gridy = 2;
/*  95 */     add(lblInfo, gbcLblInfo);
/*     */     
/*  97 */     this.cmbbox.addActionListener(e -> {
/*     */           TrackMateModule trackMateModule = provider.getFactory((String)this.cmbbox.getSelectedItem());
/*     */ 
/*     */           
/*     */           lblInfo.setText(trackMateModule.getInfoText().replace("<br>", "").replace("<p>", "<p align=\"justify\">").replace("<html>", "<html><p align=\"justify\">"));
/*     */         });
/*     */ 
/*     */     
/* 105 */     this.cmbbox.setSelectedItem(selectedKey);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setSelectedModuleKey(String moduleKey) {
/* 110 */     this.cmbbox.setSelectedItem(moduleKey);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getSelectedModuleKey() {
/* 115 */     return (String)this.cmbbox.getSelectedItem();
/*     */   }
/*     */ 
/*     */   
/*     */   private static final boolean startWithVowel(String word) {
/* 120 */     return ("eaiouEAIOU".indexOf(word.charAt(0)) >= 0);
/*     */   }
/*     */   
/*     */   private final class MyListCellRenderer
/*     */     extends DefaultListCellRenderer
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */     
/*     */     private MyListCellRenderer() {}
/*     */     
/*     */     public Component getListCellRendererComponent(JList<?> list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
/* 131 */       JLabel lbl = (JLabel)super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
/* 132 */       String key = (String)value;
/* 133 */       TrackMateModule trackMateModule = ModuleChooserPanel.this.provider.getFactory(key);
/* 134 */       lbl.setIcon(trackMateModule.getIcon());
/* 135 */       lbl.setText(trackMateModule.getName());
/* 136 */       return lbl;
/*     */     }
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/gui/components/ModuleChooserPanel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */