/*     */ package fiji.plugin.trackmate.features;
/*     */ 
/*     */ import fiji.plugin.trackmate.Model;
/*     */ import fiji.plugin.trackmate.SelectionChangeEvent;
/*     */ import fiji.plugin.trackmate.SelectionModel;
/*     */ import fiji.plugin.trackmate.gui.displaysettings.DisplaySettings;
/*     */ import java.awt.BasicStroke;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.jfree.chart.renderer.xy.XYItemRenderer;
/*     */ import org.jfree.data.DomainOrder;
/*     */ import org.jfree.data.general.AbstractDataset;
/*     */ import org.jfree.data.xy.XYDataset;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ModelDataset
/*     */   extends AbstractDataset
/*     */   implements XYDataset, Iterable<ModelDataset.DataItem>
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   protected final Model model;
/*     */   protected final List<String> yFeatures;
/*     */   protected final String xFeature;
/*     */   protected final DisplaySettings ds;
/*     */   protected final SelectionModel selectionModel;
/*     */   protected final BasicStroke stroke;
/*     */   protected final BasicStroke selectionStroke;
/*     */   private final Map<String, Integer> featureNameMap;
/*     */   
/*     */   public ModelDataset(Model model, SelectionModel selectionModel, DisplaySettings ds, String xFeature, List<String> yFeatures) {
/*  68 */     this.model = model;
/*  69 */     this.selectionModel = selectionModel;
/*  70 */     this.xFeature = xFeature;
/*  71 */     this.yFeatures = yFeatures;
/*  72 */     this.ds = ds;
/*  73 */     this.stroke = new BasicStroke((float)ds.getLineThickness(), 1, 1);
/*  74 */     this.selectionStroke = new BasicStroke((float)ds.getSelectionLineThickness(), 1, 1);
/*  75 */     this.featureNameMap = new HashMap<>();
/*  76 */     for (int i = 0; i < yFeatures.size(); i++) {
/*  77 */       this.featureNameMap.put(getSeriesKey(i).toString(), Integer.valueOf(i));
/*     */     }
/*     */     
/*  80 */     if (selectionModel != null) {
/*  81 */       selectionModel.addSelectionChangeListener(l -> fireDatasetChanged());
/*     */     }
/*     */     
/*  84 */     if (ds != null) {
/*  85 */       ds.listeners().add(() -> fireDatasetChanged());
/*     */     }
/*     */   }
/*     */   
/*     */   public String getXFeature() {
/*  90 */     return this.xFeature;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getSeriesCount() {
/*  96 */     return this.yFeatures.size();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int indexOf(Comparable seriesKey) {
/* 103 */     for (int i = 0; i < getSeriesCount(); i++) {
/*     */       
/* 105 */       if (getSeriesKey(i).equals(seriesKey))
/* 106 */         return i; 
/*     */     } 
/* 108 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public DomainOrder getDomainOrder() {
/* 114 */     return DomainOrder.NONE;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public double getXValue(int series, int item) {
/* 120 */     Number val = getX(series, item);
/* 121 */     if (val == null)
/* 122 */       return Double.NaN; 
/* 123 */     return val.doubleValue();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public double getYValue(int series, int item) {
/* 129 */     Number val = getY(series, item);
/* 130 */     if (val == null)
/* 131 */       return Double.NaN; 
/* 132 */     return val.doubleValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Iterator<DataItem> iterator() {
/* 145 */     return new Iterator<DataItem>()
/*     */       {
/*     */         
/* 148 */         int item = 0;
/*     */ 
/*     */ 
/*     */         
/*     */         public boolean hasNext() {
/* 153 */           return (this.item < ModelDataset.this.getItemCount(0));
/*     */         }
/*     */ 
/*     */ 
/*     */         
/*     */         public ModelDataset.DataItem next() {
/* 159 */           return new ModelDataset.DataItem(this.item++);
/*     */         }
/*     */       };
/*     */   }
/*     */   
/*     */   public abstract String getItemLabel(int paramInt);
/*     */   
/*     */   public abstract void setItemLabel(int paramInt, String paramString);
/*     */   
/*     */   public abstract XYItemRenderer getRenderer();
/*     */   
/*     */   public final class DataItem { private DataItem(int item) {
/* 171 */       this.item = item;
/*     */     }
/*     */     public final int item;
/*     */     
/*     */     public Double get(String feature) {
/* 176 */       if (ModelDataset.this.xFeature.equals(feature))
/* 177 */         return (Double)ModelDataset.this.getX(0, this.item); 
/* 178 */       Integer series = (Integer)ModelDataset.this.featureNameMap.get(feature);
/* 179 */       if (series == null)
/* 180 */         return null; 
/* 181 */       return (Double)ModelDataset.this.getY(series.intValue(), this.item);
/*     */     } }
/*     */ 
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/features/ModelDataset.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */