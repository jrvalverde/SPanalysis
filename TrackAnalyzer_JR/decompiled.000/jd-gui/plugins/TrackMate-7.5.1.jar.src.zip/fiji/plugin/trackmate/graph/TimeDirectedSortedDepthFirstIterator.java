/*    */ package fiji.plugin.trackmate.graph;
/*    */ 
/*    */ import fiji.plugin.trackmate.Spot;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collections;
/*    */ import java.util.Comparator;
/*    */ import java.util.HashMap;
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import org.jgrapht.Graph;
/*    */ import org.jgrapht.Graphs;
/*    */ import org.jgrapht.graph.DefaultWeightedEdge;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TimeDirectedSortedDepthFirstIterator
/*    */   extends SortedDepthFirstIterator<Spot, DefaultWeightedEdge>
/*    */ {
/*    */   public TimeDirectedSortedDepthFirstIterator(Graph<Spot, DefaultWeightedEdge> g, Spot startVertex, Comparator<Spot> comparator) {
/* 44 */     super(g, startVertex, comparator);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected void addUnseenChildrenOf(Spot vertex) {
/* 51 */     List<Spot> sortedChildren = new ArrayList<>();
/*    */     
/* 53 */     Map<Spot, DefaultWeightedEdge> localEdges = new HashMap<>();
/*    */     
/* 55 */     int ts = vertex.getFeature("FRAME").intValue();
/* 56 */     for (DefaultWeightedEdge edge : this.specifics.edgesOf(vertex)) {
/*    */       
/* 58 */       Spot oppositeV = (Spot)Graphs.getOppositeVertex(this.graph, edge, vertex);
/* 59 */       int tt = oppositeV.getFeature("FRAME").intValue();
/* 60 */       if (tt <= ts) {
/*    */         continue;
/*    */       }
/*    */       
/* 64 */       if (!this.seen.containsKey(oppositeV)) {
/* 65 */         sortedChildren.add(oppositeV);
/*    */       }
/* 67 */       localEdges.put(oppositeV, edge);
/*    */     } 
/*    */     
/* 70 */     Collections.sort(sortedChildren, Collections.reverseOrder(this.comparator));
/* 71 */     Iterator<Spot> it = sortedChildren.iterator();
/* 72 */     while (it.hasNext()) {
/* 73 */       Spot child = it.next();
/*    */       
/* 75 */       if (this.nListeners != 0) {
/* 76 */         fireEdgeTraversed(createEdgeTraversalEvent(localEdges.get(child)));
/*    */       }
/*    */       
/* 79 */       if (this.seen.containsKey(child)) {
/* 80 */         encounterVertexAgain(child, localEdges.get(child)); continue;
/*    */       } 
/* 82 */       encounterVertex(child, localEdges.get(child));
/*    */     } 
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/graph/TimeDirectedSortedDepthFirstIterator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */