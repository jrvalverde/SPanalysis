/*     */ package fiji.plugin.trackmate.graph;
/*     */ 
/*     */ import fiji.plugin.trackmate.Spot;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.jgrapht.Graph;
/*     */ import org.jgrapht.Graphs;
/*     */ import org.jgrapht.alg.util.NeighborCache;
/*     */ import org.jgrapht.event.GraphEdgeChangeEvent;
/*     */ import org.jgrapht.event.GraphVertexChangeEvent;
/*     */ import org.jgrapht.graph.DefaultWeightedEdge;
/*     */ import org.jgrapht.util.ModifiableInteger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TimeDirectedNeighborIndex
/*     */   extends NeighborCache<Spot, DefaultWeightedEdge>
/*     */ {
/*  49 */   Map<Spot, Neighbors<Spot, DefaultWeightedEdge>> predecessorMap = new HashMap<>();
/*     */   
/*  51 */   Map<Spot, Neighbors<Spot, DefaultWeightedEdge>> successorMap = new HashMap<>();
/*     */ 
/*     */ 
/*     */   
/*     */   private final Graph<Spot, DefaultWeightedEdge> graph;
/*     */ 
/*     */ 
/*     */   
/*     */   public TimeDirectedNeighborIndex(Graph<Spot, DefaultWeightedEdge> g) {
/*  60 */     super(g);
/*  61 */     this.graph = g;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<Spot> predecessorsOf(Spot v) {
/*  81 */     return getPredecessors(v).getNeighbors();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Spot> predecessorListOf(Spot v) {
/*  99 */     return getPredecessors(v).getNeighborList();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<Spot> successorsOf(Spot v) {
/* 116 */     return getSuccessors(v).getNeighbors();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Spot> successorListOf(Spot v) {
/* 134 */     return getSuccessors(v).getNeighborList();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void edgeAdded(GraphEdgeChangeEvent<Spot, DefaultWeightedEdge> e) {
/* 143 */     DefaultWeightedEdge edge = (DefaultWeightedEdge)e.getEdge();
/* 144 */     Spot source = (Spot)this.graph.getEdgeSource(edge);
/* 145 */     Spot target = (Spot)this.graph.getEdgeTarget(edge);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 152 */     if (this.successorMap.containsKey(source)) {
/*     */       
/* 154 */       getSuccessors(source).addNeighbor(target);
/*     */     }
/*     */     else {
/*     */       
/* 158 */       getSuccessors(source);
/*     */     } 
/* 160 */     if (this.predecessorMap.containsKey(target)) {
/*     */       
/* 162 */       getPredecessors(target).addNeighbor(source);
/*     */     }
/*     */     else {
/*     */       
/* 166 */       getPredecessors(target);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void edgeRemoved(GraphEdgeChangeEvent<Spot, DefaultWeightedEdge> e) {
/* 176 */     DefaultWeightedEdge edge = (DefaultWeightedEdge)e.getEdge();
/* 177 */     Spot source = (Spot)this.graph.getEdgeSource(edge);
/* 178 */     Spot target = (Spot)this.graph.getEdgeTarget(edge);
/* 179 */     if (this.successorMap.containsKey(source))
/*     */     {
/* 181 */       ((Neighbors)this.successorMap.get(source)).removeNeighbor(target);
/*     */     }
/* 183 */     if (this.predecessorMap.containsKey(target))
/*     */     {
/* 185 */       ((Neighbors)this.predecessorMap.get(target)).removeNeighbor(source);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void vertexAdded(GraphVertexChangeEvent<Spot> e) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void vertexRemoved(GraphVertexChangeEvent<Spot> e) {
/* 204 */     this.predecessorMap.remove(e.getVertex());
/* 205 */     this.successorMap.remove(e.getVertex());
/*     */   }
/*     */ 
/*     */   
/*     */   private Neighbors<Spot, DefaultWeightedEdge> getPredecessors(Spot v) {
/* 210 */     Neighbors<Spot, DefaultWeightedEdge> neighbors = this.predecessorMap.get(v);
/* 211 */     if (neighbors == null) {
/*     */       
/* 213 */       List<Spot> nl = Graphs.neighborListOf(this.graph, v);
/* 214 */       List<Spot> bnl = new ArrayList<>();
/* 215 */       int ts = v.getFeature("FRAME").intValue();
/* 216 */       for (Spot spot : nl) {
/*     */         
/* 218 */         int tt = spot.getFeature("FRAME").intValue();
/* 219 */         if (tt < ts)
/*     */         {
/* 221 */           bnl.add(spot);
/*     */         }
/*     */       } 
/* 224 */       neighbors = new Neighbors<>(v, bnl);
/* 225 */       this.predecessorMap.put(v, neighbors);
/*     */     } 
/* 227 */     return neighbors;
/*     */   }
/*     */ 
/*     */   
/*     */   private Neighbors<Spot, DefaultWeightedEdge> getSuccessors(Spot v) {
/* 232 */     Neighbors<Spot, DefaultWeightedEdge> neighbors = this.successorMap.get(v);
/* 233 */     if (neighbors == null) {
/*     */       
/* 235 */       List<Spot> nl = Graphs.neighborListOf(this.graph, v);
/* 236 */       List<Spot> bnl = new ArrayList<>();
/* 237 */       int ts = v.getFeature("FRAME").intValue();
/* 238 */       for (Spot spot : nl) {
/*     */         
/* 240 */         int tt = spot.getFeature("FRAME").intValue();
/* 241 */         if (tt > ts)
/*     */         {
/* 243 */           bnl.add(spot);
/*     */         }
/*     */       } 
/* 246 */       neighbors = new Neighbors<>(v, bnl);
/* 247 */       this.successorMap.put(v, neighbors);
/*     */     } 
/* 249 */     return neighbors;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static class Neighbors<V, E>
/*     */   {
/* 261 */     private final Map<V, ModifiableInteger> neighborCounts = new LinkedHashMap<>();
/*     */ 
/*     */ 
/*     */     
/* 265 */     private final Set<V> neighborSet = Collections.unmodifiableSet(this.neighborCounts
/* 266 */         .keySet());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Neighbors(V v, Collection<V> neighbors) {
/* 274 */       for (V neighbor : neighbors)
/*     */       {
/* 276 */         addNeighbor(neighbor);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void addNeighbor(V v) {
/* 282 */       ModifiableInteger count = this.neighborCounts.get(v);
/* 283 */       if (count == null) {
/*     */         
/* 285 */         count = new ModifiableInteger(1);
/* 286 */         this.neighborCounts.put(v, count);
/*     */       }
/*     */       else {
/*     */         
/* 290 */         count.increment();
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void removeNeighbor(V v) {
/* 296 */       ModifiableInteger count = this.neighborCounts.get(v);
/* 297 */       if (count == null) throw new IllegalArgumentException("Attempting to remove a neighbor that wasn't present");
/*     */ 
/*     */       
/* 300 */       count.decrement();
/* 301 */       if (count.getValue() == 0)
/*     */       {
/* 303 */         this.neighborCounts.remove(v);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public Set<V> getNeighbors() {
/* 309 */       return this.neighborSet;
/*     */     }
/*     */ 
/*     */     
/*     */     public List<V> getNeighborList() {
/* 314 */       List<V> neighbors = new ArrayList<>();
/* 315 */       for (Map.Entry<V, ModifiableInteger> entry : this.neighborCounts.entrySet()) {
/*     */         
/* 317 */         V v = entry.getKey();
/* 318 */         int count = ((ModifiableInteger)entry.getValue()).intValue();
/* 319 */         for (int i = 0; i < count; i++)
/*     */         {
/* 321 */           neighbors.add(v);
/*     */         }
/*     */       } 
/* 324 */       return neighbors;
/*     */     }
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/graph/TimeDirectedNeighborIndex.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */