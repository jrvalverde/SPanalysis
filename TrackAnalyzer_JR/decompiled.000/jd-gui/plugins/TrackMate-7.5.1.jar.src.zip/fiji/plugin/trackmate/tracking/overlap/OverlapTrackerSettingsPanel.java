/*     */ package fiji.plugin.trackmate.tracking.overlap;
/*     */ 
/*     */ import fiji.plugin.trackmate.gui.Fonts;
/*     */ import fiji.plugin.trackmate.gui.GuiUtils;
/*     */ import fiji.plugin.trackmate.gui.components.ConfigurationPanel;
/*     */ import java.awt.FlowLayout;
/*     */ import java.awt.GridBagConstraints;
/*     */ import java.awt.GridBagLayout;
/*     */ import java.awt.Insets;
/*     */ import java.text.DecimalFormat;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import javax.swing.ButtonGroup;
/*     */ import javax.swing.JFormattedTextField;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JRadioButton;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OverlapTrackerSettingsPanel
/*     */   extends ConfigurationPanel
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private final JFormattedTextField ftfScaleFactor;
/*     */   private final JFormattedTextField ftfMinIoU;
/*     */   private final JRadioButton rdbtnFast;
/*     */   private final JRadioButton rdbtnPrecise;
/*     */   
/*     */   public OverlapTrackerSettingsPanel() {
/*  67 */     GridBagLayout gridBagLayout = new GridBagLayout();
/*  68 */     gridBagLayout.columnWidths = new int[] { 164, 59, 0 };
/*  69 */     gridBagLayout.rowHeights = new int[] { 20, 20, 225, 0, 0, 20, 0 };
/*  70 */     gridBagLayout.columnWeights = new double[] { 1.0D, 0.0D, Double.MIN_VALUE };
/*  71 */     gridBagLayout.rowWeights = new double[] { 0.0D, 0.0D, 0.0D, 0.0D, 0.0D, 0.0D, Double.MIN_VALUE };
/*  72 */     setLayout(gridBagLayout);
/*     */     
/*  74 */     JLabel lblSettingsForTracker = new JLabel("Settings for tracker:");
/*  75 */     lblSettingsForTracker.setFont(Fonts.FONT);
/*  76 */     GridBagConstraints gbc_lblSettingsForTracker = new GridBagConstraints();
/*  77 */     gbc_lblSettingsForTracker.fill = 1;
/*  78 */     gbc_lblSettingsForTracker.insets = new Insets(5, 5, 5, 5);
/*  79 */     gbc_lblSettingsForTracker.gridwidth = 2;
/*  80 */     gbc_lblSettingsForTracker.gridx = 0;
/*  81 */     gbc_lblSettingsForTracker.gridy = 0;
/*  82 */     add(lblSettingsForTracker, gbc_lblSettingsForTracker);
/*     */     
/*  84 */     JLabel labelTracker = new JLabel("Overlap tracker");
/*  85 */     labelTracker.setFont(Fonts.BIG_FONT);
/*  86 */     labelTracker.setHorizontalAlignment(0);
/*  87 */     GridBagConstraints gbc_labelTracker = new GridBagConstraints();
/*  88 */     gbc_labelTracker.fill = 1;
/*  89 */     gbc_labelTracker.insets = new Insets(5, 5, 5, 5);
/*  90 */     gbc_labelTracker.gridwidth = 2;
/*  91 */     gbc_labelTracker.gridx = 0;
/*  92 */     gbc_labelTracker.gridy = 1;
/*  93 */     add(labelTracker, gbc_labelTracker);
/*     */     
/*  95 */     JLabel labelTrackerDescription = new JLabel("<tracker description>");
/*  96 */     labelTrackerDescription.setFont(Fonts.FONT.deriveFont(2));
/*  97 */     labelTrackerDescription.setText("<html> This tracker is a simple extension of the Intersection - over - Union (IoU) tracker. <p> <p> It generates links between spots whose shapes overlap between consecutive frames. When several spots are eligible as a source for a target, the one with the largest IoU is chosen.<p> <p> The minimal IoU parameter sets a threshold below which links won't be created. The scale factor allows for enlarging (&gt;1) or shrinking (&lt;1) the spot shapes before computing their IoU. Two methods can be used to compute IoU: The <it>Fast</it> one approximates  the spot shapes by their rectangular bounding-box. The <it>Precise</it> one uses the actual spot polygon. <p> <p> Careful: this tracker is only suited to 2D images. It treats all the spots as 2D objects. The Z dimension is ignored. </html>"
/*  98 */         .replace("<br>", "")
/*  99 */         .replace("<p>", "<p align=\"justify\">")
/* 100 */         .replace("<html>", "<html><p align=\"justify\">"));
/* 101 */     GridBagConstraints gbc_labelTrackerDescription = new GridBagConstraints();
/* 102 */     gbc_labelTrackerDescription.fill = 1;
/* 103 */     gbc_labelTrackerDescription.insets = new Insets(5, 5, 5, 5);
/* 104 */     gbc_labelTrackerDescription.gridwidth = 2;
/* 105 */     gbc_labelTrackerDescription.gridx = 0;
/* 106 */     gbc_labelTrackerDescription.gridy = 2;
/* 107 */     add(labelTrackerDescription, gbc_labelTrackerDescription);
/*     */     
/* 109 */     JPanel panelMethod = new JPanel();
/* 110 */     FlowLayout flowLayout = (FlowLayout)panelMethod.getLayout();
/* 111 */     flowLayout.setHgap(10);
/* 112 */     flowLayout.setAlignment(4);
/* 113 */     GridBagConstraints gbc_panel = new GridBagConstraints();
/* 114 */     gbc_panel.gridwidth = 2;
/* 115 */     gbc_panel.insets = new Insets(5, 5, 5, 5);
/* 116 */     gbc_panel.fill = 1;
/* 117 */     gbc_panel.gridx = 0;
/* 118 */     gbc_panel.gridy = 3;
/* 119 */     add(panelMethod, gbc_panel);
/*     */     
/* 121 */     JLabel lblIouCalculation = new JLabel("IoU calculation:");
/* 122 */     lblIouCalculation.setFont(Fonts.FONT);
/* 123 */     panelMethod.add(lblIouCalculation);
/*     */     
/* 125 */     this.rdbtnFast = new JRadioButton(OverlapTracker.IoUCalculation.FAST.toString());
/* 126 */     this.rdbtnFast.setFont(Fonts.FONT);
/* 127 */     this.rdbtnFast.setToolTipText(OverlapTracker.IoUCalculation.FAST.getInfoText());
/* 128 */     panelMethod.add(this.rdbtnFast);
/*     */     
/* 130 */     this.rdbtnPrecise = new JRadioButton(OverlapTracker.IoUCalculation.PRECISE.toString());
/* 131 */     this.rdbtnPrecise.setFont(Fonts.FONT);
/* 132 */     this.rdbtnPrecise.setToolTipText(OverlapTracker.IoUCalculation.PRECISE.getInfoText());
/* 133 */     panelMethod.add(this.rdbtnPrecise);
/*     */     
/* 135 */     ButtonGroup buttonGroup = new ButtonGroup();
/* 136 */     buttonGroup.add(this.rdbtnPrecise);
/* 137 */     buttonGroup.add(this.rdbtnFast);
/*     */     
/* 139 */     JLabel lblMinIoU = new JLabel("Min IoU:");
/* 140 */     lblMinIoU.setFont(Fonts.FONT);
/* 141 */     GridBagConstraints gbc_lblMinIoU = new GridBagConstraints();
/* 142 */     gbc_lblMinIoU.fill = 3;
/* 143 */     gbc_lblMinIoU.anchor = 13;
/* 144 */     gbc_lblMinIoU.insets = new Insets(5, 5, 5, 5);
/* 145 */     gbc_lblMinIoU.gridx = 0;
/* 146 */     gbc_lblMinIoU.gridy = 4;
/* 147 */     add(lblMinIoU, gbc_lblMinIoU);
/*     */     
/* 149 */     this.ftfMinIoU = new JFormattedTextField();
/* 150 */     this.ftfMinIoU.setText("0");
/* 151 */     this.ftfMinIoU.setFont(Fonts.FONT);
/* 152 */     this.ftfMinIoU.setHorizontalAlignment(0);
/* 153 */     GridBagConstraints gbc_ftfMinIoU = new GridBagConstraints();
/* 154 */     gbc_ftfMinIoU.insets = new Insets(5, 5, 5, 5);
/* 155 */     gbc_ftfMinIoU.fill = 1;
/* 156 */     gbc_ftfMinIoU.gridx = 1;
/* 157 */     gbc_ftfMinIoU.gridy = 4;
/* 158 */     add(this.ftfMinIoU, gbc_ftfMinIoU);
/*     */     
/* 160 */     JLabel lblScaleFactor = new JLabel("Scale factor:");
/* 161 */     lblScaleFactor.setFont(Fonts.FONT);
/* 162 */     GridBagConstraints gbc_lblScaleFactor = new GridBagConstraints();
/* 163 */     gbc_lblScaleFactor.anchor = 13;
/* 164 */     gbc_lblScaleFactor.fill = 3;
/* 165 */     gbc_lblScaleFactor.insets = new Insets(5, 5, 5, 5);
/* 166 */     gbc_lblScaleFactor.gridx = 0;
/* 167 */     gbc_lblScaleFactor.gridy = 5;
/* 168 */     add(lblScaleFactor, gbc_lblScaleFactor);
/*     */     
/* 170 */     this.ftfScaleFactor = new JFormattedTextField(new DecimalFormat("#.##"));
/* 171 */     this.ftfScaleFactor.setText("1");
/* 172 */     this.ftfScaleFactor.setHorizontalAlignment(0);
/* 173 */     this.ftfScaleFactor.setValue(Double.valueOf(1.0D));
/* 174 */     this.ftfScaleFactor.setFont(Fonts.FONT);
/* 175 */     GridBagConstraints gbc_ftfScaleFactor = new GridBagConstraints();
/* 176 */     gbc_ftfScaleFactor.fill = 1;
/* 177 */     gbc_ftfScaleFactor.insets = new Insets(5, 5, 5, 5);
/* 178 */     gbc_ftfScaleFactor.gridx = 1;
/* 179 */     gbc_ftfScaleFactor.gridy = 5;
/* 180 */     add(this.ftfScaleFactor, gbc_ftfScaleFactor);
/*     */ 
/*     */     
/* 183 */     GuiUtils.selectAllOnFocus(this.ftfMinIoU);
/* 184 */     GuiUtils.selectAllOnFocus(this.ftfScaleFactor);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, Object> getSettings() {
/* 190 */     Map<String, Object> settings = new HashMap<>();
/* 191 */     settings.put("SCALE_FACTOR", Double.valueOf(((Number)this.ftfScaleFactor.getValue()).doubleValue()));
/* 192 */     settings.put("MIN_IOU", Double.valueOf(((Number)this.ftfMinIoU.getValue()).doubleValue()));
/* 193 */     OverlapTracker.IoUCalculation method = this.rdbtnFast.isSelected() ? OverlapTracker.IoUCalculation.FAST : OverlapTracker.IoUCalculation.PRECISE;
/*     */ 
/*     */     
/* 196 */     settings.put("IOU_CALCULATION", method.name());
/* 197 */     return settings;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setSettings(Map<String, Object> settings) {
/*     */     boolean isFast;
/* 203 */     this.ftfScaleFactor.setValue((settings.get("SCALE_FACTOR") == null) ? OverlapTrackerFactory.DEFAULT_SCALE_FACTOR : settings.get("SCALE_FACTOR"));
/* 204 */     this.ftfMinIoU.setValue((settings.get("MIN_IOU") == null) ? OverlapTrackerFactory.DEFAULT_MIN_IOU : settings.get("MIN_IOU"));
/* 205 */     Object obj = settings.get("IOU_CALCULATION");
/*     */     
/* 207 */     if (obj != null) {
/* 208 */       isFast = ((String)obj).equalsIgnoreCase(OverlapTracker.IoUCalculation.FAST.name());
/*     */     } else {
/* 210 */       isFast = false;
/* 211 */     }  this.rdbtnFast.setSelected(isFast);
/* 212 */     this.rdbtnPrecise.setSelected(!isFast);
/*     */   }
/*     */   
/*     */   public void clean() {}
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/tracking/overlap/OverlapTrackerSettingsPanel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */