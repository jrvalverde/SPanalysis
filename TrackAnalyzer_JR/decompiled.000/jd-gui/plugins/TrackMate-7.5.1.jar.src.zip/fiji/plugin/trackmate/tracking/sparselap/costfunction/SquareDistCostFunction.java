/*    */ package fiji.plugin.trackmate.tracking.sparselap.costfunction;
/*    */ 
/*    */ import fiji.plugin.trackmate.Spot;
/*    */ import net.imglib2.RealLocalizable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SquareDistCostFunction
/*    */   implements CostFunction<Spot, Spot>
/*    */ {
/*    */   public double linkingCost(Spot source, Spot target) {
/* 39 */     double d2 = source.squareDistanceTo((RealLocalizable)target);
/* 40 */     return (d2 == 0.0D) ? 2.2250738585072014E-308D : d2;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/tracking/sparselap/costfunction/SquareDistCostFunction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */