/*     */ package fiji.plugin.trackmate.util;
/*     */ 
/*     */ import fiji.plugin.trackmate.features.ModelDataset;
/*     */ import fiji.plugin.trackmate.gui.GuiUtils;
/*     */ import ij.IJ;
/*     */ import java.awt.Component;
/*     */ import java.awt.Container;
/*     */ import java.awt.FileDialog;
/*     */ import java.awt.Frame;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.io.File;
/*     */ import java.io.FilenameFilter;
/*     */ import java.io.IOException;
/*     */ import javax.swing.JFileChooser;
/*     */ import javax.swing.JMenuItem;
/*     */ import javax.swing.JPopupMenu;
/*     */ import javax.swing.SwingUtilities;
/*     */ import javax.swing.filechooser.FileNameExtensionFilter;
/*     */ import org.jfree.chart.ChartPanel;
/*     */ import org.jfree.chart.ChartUtils;
/*     */ import org.jfree.chart.JFreeChart;
/*     */ import org.jfree.chart.plot.XYPlot;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ExportableChartPanel
/*     */   extends ChartPanel
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private static File currentDir;
/*     */   
/*     */   public ExportableChartPanel(JFreeChart chart) {
/*  61 */     super(chart);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ExportableChartPanel(JFreeChart chart, boolean properties, boolean save, boolean print, boolean zoom, boolean tooltips) {
/*  72 */     super(chart, properties, save, print, zoom, tooltips);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ExportableChartPanel(JFreeChart chart, int width, int height, int minimumDrawWidth, int minimumDrawHeight, int maximumDrawWidth, int maximumDrawHeight, boolean useBuffer, boolean properties, boolean save, boolean print, boolean zoom, boolean tooltips) {
/*  80 */     super(chart, width, height, minimumDrawWidth, minimumDrawHeight, maximumDrawWidth, maximumDrawHeight, useBuffer, properties, save, print, zoom, tooltips);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ExportableChartPanel(JFreeChart chart, int width, int height, int minimumDrawWidth, int minimumDrawHeight, int maximumDrawWidth, int maximumDrawHeight, boolean useBuffer, boolean properties, boolean copy, boolean save, boolean print, boolean zoom, boolean tooltips) {
/*  91 */     super(chart, width, height, minimumDrawWidth, minimumDrawHeight, maximumDrawWidth, maximumDrawHeight, useBuffer, properties, copy, save, print, zoom, tooltips);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected JPopupMenu createPopupMenu(boolean properties, boolean copy, boolean save, boolean print, boolean zoom) {
/* 103 */     JPopupMenu menu = super.createPopupMenu(properties, copy, false, print, zoom);
/*     */     
/* 105 */     menu.addSeparator();
/*     */     
/* 107 */     JMenuItem displayTableItem = new JMenuItem("Display data tables");
/* 108 */     displayTableItem.setActionCommand("TABLES");
/* 109 */     displayTableItem.addActionListener(e -> createDataTable());
/* 110 */     menu.add(displayTableItem);
/*     */     
/* 112 */     JMenuItem exportToFile = new JMenuItem("Export plot to file");
/* 113 */     exportToFile.addActionListener(e -> doSaveAs());
/* 114 */     menu.add(exportToFile);
/*     */     
/* 116 */     return menu;
/*     */   }
/*     */ 
/*     */   
/*     */   private void createDataTable() {
/* 121 */     XYPlot plot = null;
/*     */     
/*     */     try {
/* 124 */       plot = getChart().getXYPlot();
/*     */     }
/* 126 */     catch (ClassCastException e) {
/*     */       return;
/*     */     } 
/*     */ 
/*     */     
/* 131 */     int nSets = plot.getDatasetCount();
/* 132 */     for (int i = 0; i < nSets; i++) {
/*     */       
/* 134 */       ModelDataset dataset = (ModelDataset)plot.getDataset(i);
/* 135 */       String xFeature = dataset.getXFeature();
/* 136 */       String xStr = plot.getDomainAxis().getLabel();
/* 137 */       String xFeatureName = labelFromStr(xStr);
/* 138 */       String xUnits = unitsFromStr(xStr);
/* 139 */       String tableTitle = plot.getChart().getTitle().getText();
/* 140 */       String yUnits = unitsFromStr(plot.getRangeAxis().getLabel());
/*     */       
/* 142 */       ExportableChartValueTable table = new ExportableChartValueTable(dataset, xFeature, xFeatureName, xUnits, tableTitle, yUnits);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 149 */       GuiUtils.positionWindow(table, SwingUtilities.getWindowAncestor((Component)this));
/* 150 */       table.setVisible(true);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static final String unitsFromStr(String str) {
/* 156 */     int i1 = str.lastIndexOf('(');
/* 157 */     int i2 = str.lastIndexOf(')');
/* 158 */     if (i1 >= 0 && i2 >= 0 && i2 > i1 + 1)
/* 159 */       return str.substring(i1 + 1, i2); 
/* 160 */     if (i2 == i1 + 1)
/* 161 */       return ""; 
/* 162 */     return str;
/*     */   }
/*     */ 
/*     */   
/*     */   private static final String labelFromStr(String str) {
/* 167 */     int i = str.indexOf('(');
/* 168 */     if (i <= 0)
/* 169 */       return str; 
/* 170 */     if (i > 1)
/* 171 */       return str.substring(0, i - 1); 
/* 172 */     return str.substring(0, i);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void doSaveAs() {
/*     */     File file;
/* 182 */     if (null == currentDir) {
/* 183 */       currentDir = getDefaultDirectoryForSaveAs();
/*     */     }
/*     */     
/* 186 */     if (IJ.isMacintosh()) {
/*     */       
/* 188 */       Container dialogParent = getParent();
/* 189 */       while (!(dialogParent instanceof Frame)) {
/* 190 */         dialogParent = dialogParent.getParent();
/*     */       }
/* 192 */       Frame frame = (Frame)dialogParent;
/* 193 */       FileDialog dialog = new FileDialog(frame, "Export chart to PNG, PDF or SVG", 1);
/* 194 */       FilenameFilter filter = (dir, name) -> (name.endsWith(".png") || name.endsWith(".pdf") || name.endsWith(".svg"));
/* 195 */       dialog.setFilenameFilter(filter);
/* 196 */       dialog.setDirectory((currentDir == null) ? null : currentDir.getAbsolutePath());
/* 197 */       dialog.setFile(getChart().getTitle().getText().replaceAll("\\.+$", "") + ".pdf");
/* 198 */       dialog.setVisible(true);
/* 199 */       String selectedFile = dialog.getFile();
/* 200 */       if (null == selectedFile) {
/*     */         return;
/*     */       }
/* 203 */       file = new File(dialog.getDirectory(), selectedFile);
/* 204 */       currentDir = new File(dialog.getDirectory());
/*     */     }
/*     */     else {
/*     */       
/* 208 */       JFileChooser fileChooser = new JFileChooser();
/* 209 */       fileChooser.setDialogTitle("Export chart to PNG, PDF or SVG");
/* 210 */       fileChooser.setCurrentDirectory(currentDir);
/* 211 */       fileChooser.addChoosableFileFilter(new FileNameExtensionFilter("PNG Image File", new String[] { "png" }));
/* 212 */       fileChooser.addChoosableFileFilter(new FileNameExtensionFilter("Portable Document File (PDF)", new String[] { "pdf" }));
/* 213 */       fileChooser.addChoosableFileFilter(new FileNameExtensionFilter("Scalable Vector Graphics (SVG)", new String[] { "svg" }));
/* 214 */       fileChooser.setSelectedFile(new File(currentDir, getChart().getTitle().getText().replaceAll("\\.+$", "") + ".pdf"));
/* 215 */       int option = fileChooser.showSaveDialog((Component)this);
/* 216 */       if (option != 0) {
/*     */         return;
/*     */       }
/* 219 */       file = fileChooser.getSelectedFile();
/* 220 */       currentDir = fileChooser.getCurrentDirectory();
/*     */     } 
/*     */     
/*     */     try {
/* 224 */       if (file.getPath().endsWith(".png")) {
/* 225 */         ChartUtils.saveChartAsPNG(file, getChart(), getWidth(), getHeight());
/* 226 */       } else if (file.getPath().endsWith(".pdf")) {
/* 227 */         ChartExporter.exportChartAsPDF(file, getChart(), getWidth(), getHeight());
/* 228 */       } else if (file.getPath().endsWith(".svg")) {
/* 229 */         ChartExporter.exportChartAsSVG(file, getChart(), getWidth(), getHeight());
/*     */       } else {
/* 231 */         IJ.error("Invalid file extension.", "Please choose a filename with one of the 3 supported extension: .png, .pdf or .svg.");
/*     */       } 
/* 233 */     } catch (IOException|com.itextpdf.text.DocumentException e) {
/*     */       
/* 235 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/util/ExportableChartPanel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */