/*     */ package fiji.plugin.trackmate.visualization.hyperstack;
/*     */ 
/*     */ import fiji.plugin.trackmate.Model;
/*     */ import fiji.plugin.trackmate.ModelChangeEvent;
/*     */ import fiji.plugin.trackmate.SelectionChangeEvent;
/*     */ import fiji.plugin.trackmate.SelectionModel;
/*     */ import fiji.plugin.trackmate.Spot;
/*     */ import fiji.plugin.trackmate.gui.displaysettings.DisplaySettings;
/*     */ import fiji.plugin.trackmate.visualization.AbstractTrackMateModelView;
/*     */ import fiji.plugin.trackmate.visualization.ViewUtils;
/*     */ import ij.ImagePlus;
/*     */ import ij.gui.Overlay;
/*     */ import ij.gui.Roi;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HyperStackDisplayer
/*     */   extends AbstractTrackMateModelView
/*     */ {
/*     */   protected final ImagePlus imp;
/*     */   protected SpotOverlay spotOverlay;
/*     */   protected TrackOverlay trackOverlay;
/*     */   private SpotEditTool editTool;
/*     */   private Roi initialROI;
/*     */   public static final String KEY = "HYPERSTACKDISPLAYER";
/*     */   
/*     */   public HyperStackDisplayer(Model model, SelectionModel selectionModel, ImagePlus imp, DisplaySettings displaySettings) {
/*  57 */     super(model, selectionModel, displaySettings);
/*  58 */     if (null != imp) {
/*  59 */       this.imp = imp;
/*     */     } else {
/*  61 */       this.imp = ViewUtils.makeEmpytImagePlus(model);
/*     */     } 
/*  63 */     this.spotOverlay = createSpotOverlay(displaySettings);
/*  64 */     this.trackOverlay = createTrackOverlay(displaySettings);
/*  65 */     displaySettings.listeners().add(() -> refresh());
/*     */   }
/*     */ 
/*     */   
/*     */   public HyperStackDisplayer(Model model, SelectionModel selectionModel, DisplaySettings displaySettings) {
/*  70 */     this(model, selectionModel, (ImagePlus)null, displaySettings);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected SpotOverlay createSpotOverlay(DisplaySettings displaySettings) {
/*  86 */     return new SpotOverlay(this.model, this.imp, displaySettings);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected TrackOverlay createTrackOverlay(DisplaySettings displaySettings) {
/*  98 */     return new TrackOverlay(this.model, this.imp, displaySettings);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ImagePlus getImp() {
/* 112 */     return this.imp;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void modelChanged(ModelChangeEvent event) {
/* 118 */     switch (event.getEventID()) {
/*     */       
/*     */       case 4:
/*     */       case 5:
/*     */       case 6:
/*     */       case 7:
/*     */       case 8:
/* 125 */         refresh();
/*     */         break;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void selectionChanged(SelectionChangeEvent event) {
/* 134 */     this.trackOverlay.setHighlight(this.selectionModel.getEdgeSelection());
/* 135 */     this.spotOverlay.setSpotSelection(this.selectionModel.getSpotSelection());
/*     */     
/* 137 */     super.selectionChanged(event);
/*     */     
/* 139 */     this.imp.updateAndDraw();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void centerViewOn(Spot spot) {
/* 145 */     int frame = spot.getFeature("FRAME").intValue();
/* 146 */     double dz = (this.imp.getCalibration()).pixelDepth;
/* 147 */     long z = Math.round(spot.getFeature("POSITION_Z").doubleValue() / dz) + 1L;
/* 148 */     this.imp.setPosition(this.imp.getC(), (int)z, frame + 1);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void render() {
/* 154 */     this.initialROI = this.imp.getRoi();
/* 155 */     if (this.initialROI != null) {
/* 156 */       this.imp.killRoi();
/*     */     }
/* 158 */     clear();
/* 159 */     this.imp.setOpenAsHyperStack(true);
/* 160 */     if (!this.imp.isVisible()) {
/* 161 */       this.imp.show();
/*     */     }
/* 163 */     addOverlay(this.spotOverlay);
/* 164 */     addOverlay(this.trackOverlay);
/* 165 */     this.imp.updateAndDraw();
/* 166 */     registerEditTool();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void refresh() {
/* 172 */     if (null != this.imp) {
/* 173 */       this.imp.updateAndDraw();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void clear() {
/* 179 */     Overlay overlay = this.imp.getOverlay();
/* 180 */     if (overlay == null) {
/*     */       
/* 182 */       overlay = new Overlay();
/* 183 */       this.imp.setOverlay(overlay);
/*     */     } 
/* 185 */     overlay.clear();
/*     */     
/* 187 */     if (this.initialROI != null) {
/* 188 */       this.imp.getOverlay().add(this.initialROI);
/*     */     }
/* 190 */     refresh();
/*     */   }
/*     */ 
/*     */   
/*     */   public void addOverlay(Roi overlay) {
/* 195 */     this.imp.getOverlay().add(overlay);
/*     */   }
/*     */ 
/*     */   
/*     */   public SelectionModel getSelectionModel() {
/* 200 */     return this.selectionModel;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void registerEditTool() {
/* 209 */     this.editTool = SpotEditTool.getInstance();
/* 210 */     if (!SpotEditTool.isLaunched()) {
/* 211 */       this.editTool.run("");
/*     */     }
/* 213 */     this.editTool.register(this.imp, this);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getKey() {
/* 219 */     return "HYPERSTACKDISPLAYER";
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/visualization/hyperstack/HyperStackDisplayer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */