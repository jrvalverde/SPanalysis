/*    */ package fiji.plugin.trackmate.visualization.trackscheme;
/*    */ 
/*    */ import com.mxgraph.canvas.mxGraphics2DCanvas;
/*    */ import com.mxgraph.shape.mxRectangleShape;
/*    */ import com.mxgraph.util.mxConstants;
/*    */ import com.mxgraph.util.mxUtils;
/*    */ import com.mxgraph.view.mxCellState;
/*    */ import java.awt.Image;
/*    */ import java.awt.Rectangle;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class mxScaledLabelShape
/*    */   extends mxRectangleShape
/*    */ {
/*    */   public static final String SHAPE_NAME = "scaledLabel";
/*    */   
/*    */   public void paintShape(mxGraphics2DCanvas canvas, mxCellState state) {
/* 52 */     super.paintShape(canvas, state);
/*    */     
/* 54 */     String imgStr = mxUtils.getString(state.getStyle(), mxConstants.STYLE_IMAGE);
/* 55 */     if (imgStr != null) {
/*    */       
/* 57 */       Image img = canvas.loadImage(mxUtils.getString(state.getStyle(), mxConstants.STYLE_IMAGE));
/* 58 */       if (img != null) {
/*    */         
/* 60 */         Rectangle bounds = getImageBounds(state);
/* 61 */         int x = bounds.x;
/* 62 */         int y = bounds.y;
/* 63 */         int w = bounds.width;
/* 64 */         int h = bounds.height;
/* 65 */         if (h > 0 && w > 0) {
/*    */           
/* 67 */           Image scaledImage = img.getScaledInstance(w, h, 2);
/* 68 */           canvas.getGraphics().drawImage(scaledImage, x, y, null);
/*    */         } 
/*    */       } 
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   private final Rectangle getImageBounds(mxCellState state) {
/* 76 */     Rectangle cellR = state.getRectangle();
/* 77 */     int arc = getArcSize(state, cellR.width, cellR.height) / 2;
/* 78 */     int minSize = Math.min(cellR.width - arc * 2, cellR.height - 4);
/* 79 */     Rectangle imageBounds = new Rectangle(cellR.x + arc, cellR.y + 2, minSize, minSize);
/* 80 */     return imageBounds;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/visualization/trackscheme/mxScaledLabelShape.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */