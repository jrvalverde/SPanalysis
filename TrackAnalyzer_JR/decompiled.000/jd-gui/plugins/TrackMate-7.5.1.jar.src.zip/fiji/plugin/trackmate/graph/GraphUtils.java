/*     */ package fiji.plugin.trackmate.graph;
/*     */ 
/*     */ import fiji.plugin.trackmate.Spot;
/*     */ import fiji.plugin.trackmate.TrackModel;
/*     */ import java.util.Arrays;
/*     */ import java.util.Comparator;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.SortedSet;
/*     */ import java.util.TreeSet;
/*     */ import java.util.function.Supplier;
/*     */ import org.jgrapht.alg.util.NeighborCache;
/*     */ import org.jgrapht.graph.DefaultWeightedEdge;
/*     */ import org.jgrapht.graph.SimpleDirectedGraph;
/*     */ import org.jgrapht.graph.SimpleDirectedWeightedGraph;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GraphUtils
/*     */ {
/*     */   public static final String toString(TrackModel model) {
/*  57 */     TimeDirectedNeighborIndex cache = model.getDirectedNeighborIndex();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  62 */     if (!isTree(model, cache)) {
/*  63 */       throw new IllegalArgumentException("toString cannot be applied to graphs that are not trees (each vertex must have at most one predecessor).");
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*  68 */     Map<Spot, Integer> widths = cumulativeBranchWidth(model);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  73 */     int largestName = 0;
/*  74 */     for (Spot spot : model.vertexSet()) {
/*     */       
/*  76 */       if (spot.getName().length() > largestName)
/*  77 */         largestName = spot.getName().length(); 
/*     */     } 
/*  79 */     largestName += 2;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  84 */     TreeSet<Integer> frames = new TreeSet<>();
/*  85 */     for (Spot spot : model.vertexSet()) {
/*  86 */       frames.add(Integer.valueOf(spot.getFeature("FRAME").intValue()));
/*     */     }
/*  88 */     int nframes = frames.size();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  93 */     HashMap<Integer, StringBuilder> strings = new HashMap<>(nframes);
/*  94 */     for (Integer frame : frames) {
/*  95 */       strings.put(frame, new StringBuilder());
/*     */     }
/*     */     
/*  98 */     HashMap<Integer, StringBuilder> below = new HashMap<>(nframes);
/*  99 */     for (Integer frame : frames) {
/* 100 */       below.put(frame, new StringBuilder());
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 105 */     Map<Spot, Integer> carretPos = new HashMap<>(model.vertexSet().size());
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 110 */     Comparator<Spot> comparator = Spot.nameComparator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 116 */     for (Integer trackID : model.trackIDs(true)) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 122 */       Set<Spot> track = model.trackSpots(trackID);
/* 123 */       Iterator<Spot> it = track.iterator();
/* 124 */       Spot first = it.next();
/* 125 */       for (Spot spot : track) {
/*     */         
/* 127 */         if (first.diffTo(spot, "FRAME") > 0.0D) {
/* 128 */           first = spot;
/*     */         }
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 134 */       for (Integer frame : frames) {
/*     */         
/* 136 */         int columnWidth = ((Integer)widths.get(first)).intValue();
/* 137 */         ((StringBuilder)below.get(frame)).append(makeSpaces(columnWidth * largestName));
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 143 */       SortedDepthFirstIterator<Spot, DefaultWeightedEdge> iterator = model.getSortedDepthFirstIterator(first, comparator, true);
/* 144 */       while (iterator.hasNext()) {
/*     */ 
/*     */         
/* 147 */         Spot spot = iterator.next();
/* 148 */         int frame = spot.getFeature("FRAME").intValue();
/* 149 */         boolean isLeaf = (cache.successorsOf(spot).size() == 0);
/*     */         
/* 151 */         int columnWidth = ((Integer)widths.get(spot)).intValue();
/* 152 */         String str = spot.getName();
/* 153 */         int nprespaces = largestName / 2 - str.length() / 2;
/* 154 */         ((StringBuilder)strings.get(Integer.valueOf(frame))).append(makeSpaces(columnWidth / 2 * largestName));
/* 155 */         ((StringBuilder)strings.get(Integer.valueOf(frame))).append(makeSpaces(nprespaces));
/* 156 */         ((StringBuilder)strings.get(Integer.valueOf(frame))).append(str);
/*     */         
/* 158 */         int currentBranchingPosition = ((StringBuilder)strings.get(Integer.valueOf(frame))).length() - str.length() / 2;
/* 159 */         carretPos.put(spot, Integer.valueOf(currentBranchingPosition));
/*     */         
/* 161 */         ((StringBuilder)strings.get(Integer.valueOf(frame))).append(makeSpaces(largestName - nprespaces - str.length()));
/* 162 */         ((StringBuilder)strings.get(Integer.valueOf(frame))).append(makeSpaces(columnWidth * largestName - columnWidth / 2 * largestName - largestName));
/*     */ 
/*     */         
/* 165 */         if (isLeaf) {
/*     */           
/* 167 */           SortedSet<Integer> framesToFill = frames.tailSet(Integer.valueOf(frame), false);
/* 168 */           for (Integer subsequentFrame : framesToFill) {
/* 169 */             ((StringBuilder)strings.get(subsequentFrame)).append(makeSpaces(columnWidth * largestName));
/*     */           }
/*     */           
/*     */           continue;
/*     */         } 
/*     */         
/* 175 */         Set<Spot> successors = cache.successorsOf(spot);
/* 176 */         for (Spot successor : successors) {
/*     */           
/* 178 */           if (successor.diffTo(spot, "FRAME") > 1.0D)
/*     */           {
/* 180 */             for (int subFrame = successor.getFeature("FRAME").intValue(); subFrame <= successor.getFeature("FRAME").intValue(); subFrame++) {
/* 181 */               ((StringBuilder)strings.get(Integer.valueOf(subFrame - 1))).append(makeSpaces(columnWidth * largestName));
/*     */             }
/*     */           }
/*     */         } 
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 190 */       for (Integer frame : frames) {
/*     */         
/* 192 */         int columnWidth = ((Integer)widths.get(first)).intValue();
/* 193 */         StringBuilder sb = strings.get(frame);
/* 194 */         int pos = sb.length();
/* 195 */         int nspaces = columnWidth * largestName - pos;
/* 196 */         if (nspaces > 0) {
/* 197 */           sb.append(makeSpaces(nspaces));
/*     */         }
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 206 */     Set<DefaultWeightedEdge> edges = model.edgeSet();
/* 207 */     for (DefaultWeightedEdge edge : edges) {
/*     */ 
/*     */       
/* 210 */       Spot source = model.getEdgeSource(edge);
/* 211 */       Spot target = model.getEdgeTarget(edge);
/*     */       
/* 213 */       int sourceCarret = ((Integer)carretPos.get(source)).intValue() - 1;
/* 214 */       int targetCarret = ((Integer)carretPos.get(target)).intValue() - 1;
/*     */       
/* 216 */       int sourceFrame = source.getFeature("FRAME").intValue();
/* 217 */       int targetFrame = target.getFeature("FRAME").intValue();
/*     */       int frame;
/* 219 */       for (frame = sourceFrame; frame < targetFrame; frame++)
/*     */       {
/* 221 */         ((StringBuilder)below.get(Integer.valueOf(frame))).setCharAt(sourceCarret, '|');
/*     */       }
/* 223 */       for (frame = sourceFrame + 1; frame < targetFrame; frame++)
/*     */       {
/* 225 */         ((StringBuilder)strings.get(Integer.valueOf(frame))).setCharAt(sourceCarret, '|');
/*     */       }
/*     */       
/* 228 */       if (cache.successorsOf(source).size() > 1) {
/*     */ 
/*     */         
/* 231 */         int minC = Math.min(sourceCarret, targetCarret);
/* 232 */         int maxC = Math.max(sourceCarret, targetCarret);
/* 233 */         StringBuilder sb = below.get(Integer.valueOf(sourceFrame));
/* 234 */         for (int i = minC + 1; i < maxC; i++) {
/*     */           
/* 236 */           if (sb.charAt(i) == ' ')
/* 237 */             sb.setCharAt(i, '-'); 
/*     */         } 
/* 239 */         sb.setCharAt(minC, '+');
/* 240 */         sb.setCharAt(maxC, '+');
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 248 */     StringBuilder finalString = new StringBuilder();
/* 249 */     for (Integer frame : frames) {
/*     */       
/* 251 */       finalString.append(((StringBuilder)strings.get(frame)).toString());
/* 252 */       finalString.append('\n');
/* 253 */       finalString.append(((StringBuilder)below.get(frame)).toString());
/* 254 */       finalString.append('\n');
/*     */     } 
/*     */     
/* 257 */     return finalString.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static final boolean isTree(TrackModel model, TimeDirectedNeighborIndex cache) {
/* 263 */     return isTree(model.vertexSet(), cache);
/*     */   }
/*     */ 
/*     */   
/*     */   public static final boolean isTree(Iterable<Spot> spots, TimeDirectedNeighborIndex cache) {
/* 268 */     for (Spot spot : spots) {
/*     */       
/* 270 */       if (cache.predecessorsOf(spot).size() > 1)
/* 271 */         return false; 
/*     */     } 
/* 273 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final Map<Spot, Integer> cumulativeBranchWidth(TrackModel model) {
/* 282 */     Supplier<int[]> factory = new Supplier<int[]>()
/*     */       {
/*     */         
/*     */         public int[] get()
/*     */         {
/* 287 */           return new int[1];
/*     */         }
/*     */       };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 295 */     final TimeDirectedNeighborIndex cache = model.getDirectedNeighborIndex();
/*     */     
/* 297 */     Function1<Spot, int[]> isLeafFun = new Function1<Spot, int[]>()
/*     */       {
/*     */         
/*     */         public void compute(Spot input, int[] output)
/*     */         {
/* 302 */           if (cache.successorsOf(input).size() == 0) {
/* 303 */             output[0] = 1;
/*     */           } else {
/* 305 */             output[0] = 0;
/*     */           } 
/*     */         }
/*     */       };
/* 309 */     Map<Spot, int[]> mappings = (Map)new HashMap<>();
/* 310 */     SimpleDirectedWeightedGraph<int[], DefaultWeightedEdge> leafTree = model.copy(factory, isLeafFun, mappings);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 320 */     Set<Spot> roots = new HashSet<>(model.nTracks(false));
/* 321 */     Set<Spot> firsts = new HashSet<>(model.nTracks(false));
/* 322 */     Set<Integer> ids = model.trackIDs(false);
/* 323 */     for (Integer id : ids) {
/*     */       
/* 325 */       Set<Spot> track = model.trackSpots(id);
/* 326 */       boolean firstFound = false;
/* 327 */       for (Spot spot : track) {
/*     */         
/* 329 */         if (cache.predecessorsOf(spot).size() == 0) {
/*     */           
/* 331 */           if (!firstFound) {
/* 332 */             firsts.add(spot);
/*     */           }
/* 334 */           roots.add(spot);
/* 335 */           firstFound = true;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 344 */     Function2<int[], int[]> cumsumFun = new Function2<int[], int[]>()
/*     */       {
/*     */         
/*     */         public void compute(int[] input1, int[] input2, int[] output)
/*     */         {
/* 349 */           output[0] = input1[0] + input2[0];
/*     */         }
/*     */       };
/*     */     
/* 353 */     RecursiveCumSum<int[], DefaultWeightedEdge> cumsum = (RecursiveCumSum)new RecursiveCumSum<>((SimpleDirectedGraph)leafTree, (Function2)cumsumFun);
/* 354 */     for (Spot root : firsts) {
/*     */       
/* 356 */       int[] current = mappings.get(root);
/* 357 */       cumsum.apply(current);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 363 */     Map<Spot, Integer> widths = new HashMap<>();
/* 364 */     for (Spot spot : model.vertexSet()) {
/* 365 */       widths.put(spot, Integer.valueOf(((int[])mappings.get(spot))[0]));
/*     */     }
/* 367 */     return widths;
/*     */   }
/*     */ 
/*     */   
/*     */   private static char[] makeSpaces(int width) {
/* 372 */     return makeChars(width, ' ');
/*     */   }
/*     */ 
/*     */   
/*     */   private static char[] makeChars(int width, char c) {
/* 377 */     char[] chars = new char[width];
/* 378 */     Arrays.fill(chars, c);
/* 379 */     return chars;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final Set<Spot> getSibblings(NeighborCache<Spot, DefaultWeightedEdge> cache, Spot spot) {
/* 388 */     HashSet<Spot> sibblings = new HashSet<>();
/* 389 */     Set<Spot> predecessors = cache.predecessorsOf(spot);
/* 390 */     for (Spot predecessor : predecessors) {
/* 391 */       sibblings.addAll(cache.successorsOf(predecessor));
/*     */     }
/* 393 */     return sibblings;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/graph/GraphUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */