/*     */ package fiji.plugin.trackmate;
/*     */ 
/*     */ import fiji.plugin.trackmate.features.FeatureFilter;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Set;
/*     */ import org.jgrapht.Graph;
/*     */ import org.jgrapht.Graphs;
/*     */ import org.jgrapht.graph.DefaultWeightedEdge;
/*     */ import org.jgrapht.graph.SimpleWeightedGraph;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Model
/*     */ {
/*     */   private static final boolean DEBUG = false;
/*     */   private final FeatureModel featureModel;
/*     */   private final TrackModel trackModel;
/*  72 */   protected SpotCollection spots = new SpotCollection();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  82 */   private int updateLevel = 0;
/*     */   
/*  84 */   private final HashSet<Spot> spotsAdded = new HashSet<>();
/*     */   
/*  86 */   private final HashSet<Spot> spotsRemoved = new HashSet<>();
/*     */   
/*  88 */   private final HashSet<Spot> spotsMoved = new HashSet<>();
/*     */   
/*  90 */   private final HashSet<Spot> spotsUpdated = new HashSet<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 107 */   private final HashSet<Integer> eventCache = new HashSet<>();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 112 */   private Logger logger = Logger.DEFAULT_LOGGER;
/*     */   
/* 114 */   private String spaceUnits = "pixels";
/*     */   
/* 116 */   private String timeUnits = "frames";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 123 */   Set<ModelChangeListener> modelChangeListeners = new LinkedHashSet<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Model() {
/* 131 */     this.featureModel = createFeatureModel();
/* 132 */     this.trackModel = createTrackModel();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected TrackModel createTrackModel() {
/* 149 */     return new TrackModel();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected FeatureModel createFeatureModel() {
/* 162 */     return new FeatureModel(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 172 */     StringBuilder str = new StringBuilder();
/*     */     
/* 174 */     str.append('\n');
/* 175 */     if (null == this.spots || this.spots.keySet().size() == 0) {
/*     */       
/* 177 */       str.append("No spots.\n");
/*     */     }
/*     */     else {
/*     */       
/* 181 */       str.append("Contains " + this.spots.getNSpots(false) + " spots in total.\n");
/*     */     } 
/* 183 */     if (this.spots.getNSpots(true) == 0) {
/*     */       
/* 185 */       str.append("No filtered spots.\n");
/*     */     }
/*     */     else {
/*     */       
/* 189 */       str.append("Contains " + this.spots.getNSpots(true) + " filtered spots.\n");
/*     */     } 
/*     */     
/* 192 */     str.append('\n');
/* 193 */     if (this.trackModel.nTracks(false) == 0) {
/*     */       
/* 195 */       str.append("No tracks.\n");
/*     */     }
/*     */     else {
/*     */       
/* 199 */       str.append("Contains " + this.trackModel.nTracks(false) + " tracks in total.\n");
/*     */     } 
/* 201 */     if (this.trackModel.nTracks(true) == 0) {
/*     */       
/* 203 */       str.append("No filtered tracks.\n");
/*     */     }
/*     */     else {
/*     */       
/* 207 */       str.append("Contains " + this.trackModel.nTracks(true) + " filtered tracks.\n");
/*     */     } 
/*     */     
/* 210 */     str.append('\n');
/* 211 */     str.append("Physical units:\n  space units: " + this.spaceUnits + "\n  time units: " + this.timeUnits + '\n');
/*     */     
/* 213 */     str.append('\n');
/* 214 */     str.append(this.featureModel.toString());
/*     */     
/* 216 */     return str.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addModelChangeListener(ModelChangeListener listener) {
/* 225 */     this.modelChangeListeners.add(listener);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean removeModelChangeListener(ModelChangeListener listener) {
/* 230 */     return this.modelChangeListeners.remove(listener);
/*     */   }
/*     */ 
/*     */   
/*     */   public Set<ModelChangeListener> getModelChangeListener() {
/* 235 */     return this.modelChangeListeners;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPhysicalUnits(String spaceUnits, String timeUnits) {
/* 252 */     this.spaceUnits = spaceUnits;
/* 253 */     this.timeUnits = timeUnits;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getSpaceUnits() {
/* 263 */     return this.spaceUnits;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getTimeUnits() {
/* 273 */     return this.timeUnits;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void beginUpdate() {
/* 282 */     this.updateLevel++;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void endUpdate() {
/* 289 */     this.updateLevel--;
/*     */ 
/*     */     
/* 292 */     if (this.updateLevel == 0)
/*     */     {
/*     */ 
/*     */       
/* 296 */       flushUpdate();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void clearTracks(boolean doNotify) {
/* 313 */     this.trackModel.clear();
/* 314 */     if (doNotify) {
/*     */       
/* 316 */       ModelChangeEvent event = new ModelChangeEvent(this, 6);
/* 317 */       for (ModelChangeListener listener : this.modelChangeListeners) {
/* 318 */         listener.modelChanged(event);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TrackModel getTrackModel() {
/* 329 */     return this.trackModel;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTracks(SimpleWeightedGraph<Spot, DefaultWeightedEdge> graph, boolean doNotify) {
/* 348 */     this.trackModel.setGraph(graph);
/* 349 */     if (doNotify) {
/*     */       
/* 351 */       ModelChangeEvent event = new ModelChangeEvent(this, 6);
/* 352 */       for (ModelChangeListener listener : this.modelChangeListeners) {
/* 353 */         listener.modelChanged(event);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SpotCollection getSpots() {
/* 368 */     return this.spots;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void clearSpots(boolean doNotify) {
/* 380 */     this.spots.clear();
/* 381 */     if (doNotify) {
/*     */       
/* 383 */       ModelChangeEvent event = new ModelChangeEvent(this, 4);
/* 384 */       for (ModelChangeListener listener : this.modelChangeListeners) {
/* 385 */         listener.modelChanged(event);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSpots(SpotCollection spots, boolean doNotify) {
/* 400 */     this.spots = spots;
/* 401 */     if (doNotify) {
/*     */       
/* 403 */       ModelChangeEvent event = new ModelChangeEvent(this, 4);
/* 404 */       for (ModelChangeListener listener : this.modelChangeListeners) {
/* 405 */         listener.modelChanged(event);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void filterSpots(Collection<FeatureFilter> spotFilters, boolean doNotify) {
/* 421 */     this.spots.filter(spotFilters);
/* 422 */     if (doNotify) {
/*     */       
/* 424 */       ModelChangeEvent event = new ModelChangeEvent(this, 5);
/* 425 */       for (ModelChangeListener listener : this.modelChangeListeners) {
/* 426 */         listener.modelChanged(event);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void notifyFeaturesComputed() {
/* 438 */     ModelChangeEvent event = new ModelChangeEvent(this, 9);
/* 439 */     for (ModelChangeListener listener : this.modelChangeListeners) {
/* 440 */       listener.modelChanged(event);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLogger(Logger logger) {
/* 456 */     this.logger = logger;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Logger getLogger() {
/* 466 */     return this.logger;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FeatureModel getFeatureModel() {
/* 475 */     return this.featureModel;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized Spot moveSpotFrom(Spot spotToMove, Integer fromFrame, Integer toFrame) {
/* 511 */     boolean ok = this.spots.remove(spotToMove, fromFrame);
/* 512 */     if (!ok)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 518 */       return null;
/*     */     }
/* 520 */     this.spots.add(spotToMove, toFrame);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 527 */     this.trackModel.edgesModified.addAll(this.trackModel.edgesOf(spotToMove));
/* 528 */     this.spotsMoved.add(spotToMove);
/* 529 */     return spotToMove;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized Spot addSpotTo(Spot spotToAdd, Integer toFrame) {
/* 557 */     this.spots.add(spotToAdd, toFrame);
/* 558 */     this.spotsAdded.add(spotToAdd);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 563 */     this.trackModel.addSpot(spotToAdd);
/* 564 */     return spotToAdd;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized Spot removeSpot(Spot spotToRemove) {
/* 589 */     int fromFrame = spotToRemove.getFeature("FRAME").intValue();
/* 590 */     if (this.spots.remove(spotToRemove, Integer.valueOf(fromFrame))) {
/*     */       
/* 592 */       this.spotsRemoved.add(spotToRemove);
/*     */ 
/*     */ 
/*     */       
/* 596 */       this.trackModel.removeSpot(spotToRemove);
/*     */       
/* 598 */       return spotToRemove;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 603 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void updateFeatures(Spot spotToUpdate) {
/* 628 */     this.spotsUpdated.add(spotToUpdate);
/*     */     
/* 630 */     Set<DefaultWeightedEdge> touchingEdges = this.trackModel.edgesOf(spotToUpdate);
/* 631 */     if (null != touchingEdges)
/*     */     {
/* 633 */       this.trackModel.edgesModified.addAll(touchingEdges);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized DefaultWeightedEdge addEdge(Spot source, Spot target, double weight) {
/* 662 */     return this.trackModel.addEdge(source, target, weight);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized DefaultWeightedEdge removeEdge(Spot source, Spot target) {
/* 677 */     return this.trackModel.removeEdge(source, target);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized boolean removeEdge(DefaultWeightedEdge edge) {
/* 702 */     return this.trackModel.removeEdge(edge);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void setEdgeWeight(DefaultWeightedEdge edge, double weight) {
/* 727 */     this.trackModel.setEdgeWeight(edge, weight);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized boolean setTrackVisibility(Integer trackID, boolean visible) {
/* 754 */     boolean oldvis = this.trackModel.setVisibility(trackID, visible).booleanValue();
/* 755 */     boolean modified = (oldvis != visible);
/* 756 */     if (modified)
/*     */     {
/* 758 */       this.eventCache.add(Integer.valueOf(7));
/*     */     }
/* 760 */     return oldvis;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Model copy() {
/* 774 */     Model copy = new Model();
/*     */ 
/*     */     
/* 777 */     copy.setPhysicalUnits(this.spaceUnits, this.timeUnits);
/*     */ 
/*     */     
/* 780 */     SpotCollection spots2 = SpotCollection.fromCollection(this.spots.iterable(true));
/* 781 */     copy.setSpots(spots2, false);
/*     */ 
/*     */     
/* 784 */     SimpleWeightedGraph<Spot, DefaultWeightedEdge> graphCopy = new SimpleWeightedGraph(DefaultWeightedEdge.class);
/* 785 */     Graphs.addGraph((Graph)graphCopy, (Graph)this.trackModel.graph);
/* 786 */     copy.getTrackModel().from(graphCopy, new HashMap<>(this.trackModel.connectedVertexSets), new HashMap<>(this.trackModel.connectedEdgeSets), new HashMap<>(this.trackModel.visibility), new HashMap<>(this.trackModel.names));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 794 */     FeatureModel fm2 = copy.getFeatureModel();
/* 795 */     fm2.declareSpotFeatures(this.featureModel
/* 796 */         .getSpotFeatures(), this.featureModel
/* 797 */         .getSpotFeatureNames(), this.featureModel
/* 798 */         .getSpotFeatureShortNames(), this.featureModel
/* 799 */         .getSpotFeatureDimensions(), this.featureModel
/* 800 */         .getSpotFeatureIsInt());
/* 801 */     fm2.declareEdgeFeatures(this.featureModel
/* 802 */         .getEdgeFeatures(), this.featureModel
/* 803 */         .getEdgeFeatureNames(), this.featureModel
/* 804 */         .getEdgeFeatureShortNames(), this.featureModel
/* 805 */         .getEdgeFeatureDimensions(), this.featureModel
/* 806 */         .getEdgeFeatureIsInt());
/* 807 */     fm2.declareTrackFeatures(this.featureModel
/* 808 */         .getTrackFeatures(), this.featureModel
/* 809 */         .getTrackFeatureNames(), this.featureModel
/* 810 */         .getTrackFeatureShortNames(), this.featureModel
/* 811 */         .getTrackFeatureDimensions(), this.featureModel
/* 812 */         .getTrackFeatureIsInt());
/*     */ 
/*     */     
/* 815 */     return copy;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void flushUpdate() {
/* 841 */     int nEdgesToSignal = this.trackModel.edgesAdded.size() + this.trackModel.edgesRemoved.size() + this.trackModel.edgesModified.size();
/*     */ 
/*     */     
/* 844 */     HashSet<Integer> tracksToUpdate = new HashSet<>(this.trackModel.tracksUpdated);
/*     */ 
/*     */     
/* 847 */     for (DefaultWeightedEdge modifiedEdge : this.trackModel.edgesModified)
/*     */     {
/* 849 */       tracksToUpdate.add(this.trackModel.trackIDOf(modifiedEdge));
/*     */     }
/*     */ 
/*     */     
/* 853 */     int nSpotsToUpdate = this.spotsAdded.size() + this.spotsMoved.size() + this.spotsUpdated.size();
/* 854 */     if (nSpotsToUpdate > 0) {
/*     */       
/* 856 */       HashSet<Spot> spotsToUpdate = new HashSet<>(nSpotsToUpdate);
/* 857 */       spotsToUpdate.addAll(this.spotsAdded);
/* 858 */       spotsToUpdate.addAll(this.spotsMoved);
/* 859 */       spotsToUpdate.addAll(this.spotsUpdated);
/*     */     } 
/*     */ 
/*     */     
/* 863 */     ModelChangeEvent event = new ModelChangeEvent(this, 8);
/*     */ 
/*     */     
/* 866 */     int nSpotsToSignal = nSpotsToUpdate + this.spotsRemoved.size();
/* 867 */     if (nSpotsToSignal > 0) {
/*     */       
/* 869 */       event.addAllSpots(this.spotsAdded);
/* 870 */       event.addAllSpots(this.spotsRemoved);
/* 871 */       event.addAllSpots(this.spotsMoved);
/* 872 */       event.addAllSpots(this.spotsUpdated);
/*     */       
/* 874 */       for (Spot spot : this.spotsAdded)
/*     */       {
/* 876 */         event.putSpotFlag(spot, Integer.valueOf(0));
/*     */       }
/* 878 */       for (Spot spot : this.spotsRemoved)
/*     */       {
/* 880 */         event.putSpotFlag(spot, Integer.valueOf(1));
/*     */       }
/* 882 */       for (Spot spot : this.spotsMoved)
/*     */       {
/* 884 */         event.putSpotFlag(spot, Integer.valueOf(3));
/*     */       }
/* 886 */       for (Spot spot : this.spotsUpdated)
/*     */       {
/* 888 */         event.putSpotFlag(spot, Integer.valueOf(2));
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 893 */     if (nEdgesToSignal > 0) {
/*     */       
/* 895 */       event.addAllEdges(this.trackModel.edgesAdded);
/* 896 */       event.addAllEdges(this.trackModel.edgesRemoved);
/* 897 */       event.addAllEdges(this.trackModel.edgesModified);
/*     */       
/* 899 */       for (DefaultWeightedEdge edge : this.trackModel.edgesAdded)
/*     */       {
/* 901 */         event.putEdgeFlag(edge, Integer.valueOf(4));
/*     */       }
/* 903 */       for (DefaultWeightedEdge edge : this.trackModel.edgesRemoved)
/*     */       {
/* 905 */         event.putEdgeFlag(edge, Integer.valueOf(5));
/*     */       }
/* 907 */       for (DefaultWeightedEdge edge : this.trackModel.edgesModified)
/*     */       {
/* 909 */         event.putEdgeFlag(edge, Integer.valueOf(6));
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 914 */     event.setTracksUpdated(tracksToUpdate);
/*     */ 
/*     */     
/*     */     try {
/* 918 */       if (nEdgesToSignal + nSpotsToSignal > 0)
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 926 */         for (ModelChangeListener listener : this.modelChangeListeners)
/*     */         {
/* 928 */           listener.modelChanged(event);
/*     */         }
/*     */       }
/*     */ 
/*     */       
/* 933 */       for (Iterator<Integer> iterator = this.eventCache.iterator(); iterator.hasNext(); ) { int eventID = ((Integer)iterator.next()).intValue();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 939 */         ModelChangeEvent cachedEvent = new ModelChangeEvent(this, eventID);
/* 940 */         for (ModelChangeListener listener : this.modelChangeListeners)
/*     */         {
/* 942 */           listener.modelChanged(cachedEvent);
/*     */         } }
/*     */ 
/*     */     
/*     */     }
/*     */     finally {
/*     */       
/* 949 */       this.spotsAdded.clear();
/* 950 */       this.spotsRemoved.clear();
/* 951 */       this.spotsMoved.clear();
/* 952 */       this.spotsUpdated.clear();
/* 953 */       this.trackModel.edgesAdded.clear();
/* 954 */       this.trackModel.edgesRemoved.clear();
/* 955 */       this.trackModel.edgesModified.clear();
/* 956 */       this.trackModel.tracksUpdated.clear();
/* 957 */       this.eventCache.clear();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/Model.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */