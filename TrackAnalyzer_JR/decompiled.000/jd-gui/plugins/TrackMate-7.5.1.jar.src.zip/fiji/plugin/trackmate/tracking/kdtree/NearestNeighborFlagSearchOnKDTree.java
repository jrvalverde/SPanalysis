/*     */ package fiji.plugin.trackmate.tracking.kdtree;
/*     */ 
/*     */ import net.imglib2.KDTree;
/*     */ import net.imglib2.KDTreeNode;
/*     */ import net.imglib2.RealLocalizable;
/*     */ import net.imglib2.Sampler;
/*     */ import net.imglib2.neighborsearch.NearestNeighborSearch;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NearestNeighborFlagSearchOnKDTree<T>
/*     */   implements NearestNeighborSearch<FlagNode<T>>
/*     */ {
/*     */   protected KDTree<FlagNode<T>> tree;
/*     */   protected final int n;
/*     */   protected final double[] pos;
/*     */   protected KDTreeNode<FlagNode<T>> bestPoint;
/*     */   protected double bestSquDistance;
/*     */   
/*     */   public NearestNeighborFlagSearchOnKDTree(KDTree<FlagNode<T>> tree) {
/*  46 */     this.n = tree.numDimensions();
/*  47 */     this.pos = new double[this.n];
/*  48 */     this.tree = tree;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int numDimensions() {
/*  54 */     return this.n;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void search(RealLocalizable p) {
/*  60 */     p.localize(this.pos);
/*  61 */     this.bestSquDistance = Double.MAX_VALUE;
/*  62 */     searchNode(this.tree.getRoot());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void searchNode(KDTreeNode<FlagNode<T>> current) {
/*  68 */     double distance = current.squDistanceTo(this.pos);
/*  69 */     boolean visited = ((FlagNode)current.get()).isVisited();
/*  70 */     if (distance < this.bestSquDistance && !visited) {
/*     */       
/*  72 */       this.bestSquDistance = distance;
/*  73 */       this.bestPoint = current;
/*     */     } 
/*     */     
/*  76 */     double axisDiff = this.pos[current.getSplitDimension()] - current.getSplitCoordinate();
/*  77 */     double axisSquDistance = axisDiff * axisDiff;
/*  78 */     boolean leftIsNearBranch = (axisDiff < 0.0D);
/*     */ 
/*     */     
/*  81 */     KDTreeNode<FlagNode<T>> nearChild = leftIsNearBranch ? current.left : current.right;
/*  82 */     KDTreeNode<FlagNode<T>> awayChild = leftIsNearBranch ? current.right : current.left;
/*  83 */     if (nearChild != null) {
/*  84 */       searchNode(nearChild);
/*     */     }
/*     */     
/*  87 */     if (axisSquDistance <= this.bestSquDistance && awayChild != null) {
/*  88 */       searchNode(awayChild);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public Sampler<FlagNode<T>> getSampler() {
/*  94 */     return (Sampler<FlagNode<T>>)this.bestPoint;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public RealLocalizable getPosition() {
/* 100 */     return (RealLocalizable)this.bestPoint;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public double getSquareDistance() {
/* 106 */     return this.bestSquDistance;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public double getDistance() {
/* 112 */     return Math.sqrt(this.bestSquDistance);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public NearestNeighborFlagSearchOnKDTree<T> copy() {
/* 118 */     NearestNeighborFlagSearchOnKDTree<T> copy = new NearestNeighborFlagSearchOnKDTree(this.tree);
/* 119 */     System.arraycopy(this.pos, 0, copy.pos, 0, this.pos.length);
/* 120 */     copy.bestPoint = this.bestPoint;
/* 121 */     copy.bestSquDistance = this.bestSquDistance;
/* 122 */     return copy;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/tracking/kdtree/NearestNeighborFlagSearchOnKDTree.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */