/*    */ package fiji.plugin.trackmate.gui.wizard.descriptors;
/*    */ 
/*    */ import fiji.plugin.trackmate.Logger;
/*    */ import fiji.plugin.trackmate.TrackMate;
/*    */ import fiji.plugin.trackmate.features.FeatureFilter;
/*    */ import fiji.plugin.trackmate.features.FeatureUtils;
/*    */ import fiji.plugin.trackmate.gui.components.InitFilterPanel;
/*    */ import fiji.plugin.trackmate.gui.displaysettings.DisplaySettings;
/*    */ import fiji.plugin.trackmate.gui.wizard.WizardPanelDescriptor;
/*    */ import fiji.plugin.trackmate.io.SettingsPersistence;
/*    */ import java.awt.Component;
/*    */ import java.util.function.Function;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InitFilterDescriptor
/*    */   extends WizardPanelDescriptor
/*    */ {
/*    */   public static final String KEY = "InitialFiltering";
/*    */   private final TrackMate trackmate;
/*    */   
/*    */   public InitFilterDescriptor(TrackMate trackmate, FeatureFilter filter) {
/* 45 */     super("InitialFiltering");
/* 46 */     this.trackmate = trackmate;
/* 47 */     Function<String, double[]> valuesCollector = key -> FeatureUtils.collectFeatureValues("QUALITY", DisplaySettings.TrackMateObject.SPOTS, trackmate.getModel(), false);
/*    */     
/* 49 */     this.targetPanel = (Component)new InitFilterPanel(filter, valuesCollector);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Runnable getForwardRunnable() {
/* 55 */     return new Runnable()
/*    */       {
/*    */ 
/*    */         
/*    */         public void run()
/*    */         {
/* 61 */           InitFilterDescriptor.this.trackmate.getModel().getLogger().log("\nComputing spot quality histogram...\n", Logger.BLUE_COLOR);
/* 62 */           InitFilterPanel component = (InitFilterPanel)InitFilterDescriptor.this.targetPanel;
/* 63 */           component.refresh();
/*    */         }
/*    */       };
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void aboutToHidePanel() {
/* 71 */     InitFilterPanel component = (InitFilterPanel)this.targetPanel;
/* 72 */     (this.trackmate.getSettings()).initialSpotFilterValue = Double.valueOf((component.getFeatureThreshold()).value);
/*    */ 
/*    */     
/* 75 */     SettingsPersistence.saveLastUsedSettings(this.trackmate.getSettings(), this.trackmate.getModel().getLogger());
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/gui/wizard/descriptors/InitFilterDescriptor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */