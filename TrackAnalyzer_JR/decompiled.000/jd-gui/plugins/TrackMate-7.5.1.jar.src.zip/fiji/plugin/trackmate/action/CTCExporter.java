/*     */ package fiji.plugin.trackmate.action;
/*     */ 
/*     */ import fiji.plugin.trackmate.Logger;
/*     */ import fiji.plugin.trackmate.Model;
/*     */ import fiji.plugin.trackmate.Settings;
/*     */ import fiji.plugin.trackmate.Spot;
/*     */ import fiji.plugin.trackmate.SpotCollection;
/*     */ import fiji.plugin.trackmate.TrackMate;
/*     */ import fiji.plugin.trackmate.TrackModel;
/*     */ import fiji.plugin.trackmate.graph.ConvexBranchesDecomposition;
/*     */ import fiji.plugin.trackmate.graph.GraphUtils;
/*     */ import fiji.plugin.trackmate.graph.TimeDirectedNeighborIndex;
/*     */ import fiji.plugin.trackmate.io.TmXmlWriter;
/*     */ import fiji.plugin.trackmate.util.TMUtils;
/*     */ import ij.IJ;
/*     */ import ij.ImagePlus;
/*     */ import ij.plugin.Duplicator;
/*     */ import java.io.BufferedWriter;
/*     */ import java.io.File;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.nio.file.Files;
/*     */ import java.nio.file.Path;
/*     */ import java.nio.file.Paths;
/*     */ import java.nio.file.attribute.FileAttribute;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ import java.util.function.Function;
/*     */ import net.imagej.ImgPlus;
/*     */ import net.imagej.axis.Axes;
/*     */ import net.imagej.axis.AxisType;
/*     */ import net.imglib2.Dimensions;
/*     */ import net.imglib2.FinalDimensions;
/*     */ import net.imglib2.RandomAccessibleInterval;
/*     */ import net.imglib2.RealLocalizable;
/*     */ import net.imglib2.img.Img;
/*     */ import net.imglib2.img.display.imagej.ImageJFunctions;
/*     */ import net.imglib2.type.NativeType;
/*     */ import net.imglib2.type.numeric.integer.UnsignedShortType;
/*     */ import net.imglib2.util.Util;
/*     */ import org.jgrapht.Graph;
/*     */ import org.jgrapht.Graphs;
/*     */ import org.jgrapht.graph.DefaultEdge;
/*     */ import org.jgrapht.graph.DefaultWeightedEdge;
/*     */ import org.jgrapht.graph.SimpleDirectedGraph;
/*     */ import org.jgrapht.traverse.BreadthFirstIterator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CTCExporter
/*     */ {
/*     */   private static final Function<Integer, String> nameGen;
/*     */   
/*     */   static {
/*  87 */     nameGen = (i -> String.format("%02d", new Object[] { i }));
/*     */   }
/*     */   
/*     */   public enum ExportType {
/*  91 */     GOLD_TRUTH("Gold truth", "_GT"),
/*  92 */     SILVER_TRUTH("Silver truth", "_ST"),
/*  93 */     RESULTS("Results", "_RES");
/*     */     
/*     */     private final String label;
/*     */     
/*     */     private final String suffix;
/*     */ 
/*     */     
/*     */     ExportType(String label, String suffix) {
/* 101 */       this.label = label;
/* 102 */       this.suffix = suffix;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public String toString() {
/* 108 */       return this.label;
/*     */     }
/*     */ 
/*     */     
/*     */     public String suffix() {
/* 113 */       return this.suffix;
/*     */     }
/*     */ 
/*     */     
/*     */     public Path getTrackTextFilePath(String exportRootFolder, int saveId) {
/* 118 */       switch (this) {
/*     */         
/*     */         case GOLD_TRUTH:
/*     */         case SILVER_TRUTH:
/* 122 */           return Paths.get(exportRootFolder, new String[] { (String)CTCExporter.access$000().apply(Integer.valueOf(saveId)) + this.suffix, "TRA", "man_track.txt" });
/*     */         case RESULTS:
/* 124 */           return Paths.get(exportRootFolder, new String[] { (String)CTCExporter.access$000().apply(Integer.valueOf(saveId)) + this.suffix, "res_track.txt" });
/*     */       } 
/* 126 */       throw new IllegalArgumentException("Unknown export type: " + this);
/*     */     }
/*     */     
/*     */     public Path getTrackTifFilePath(String exportRootFolder, int saveId, long frame, int nFrames) {
/*     */       Function<Long, String> tifNameGen;
/*     */       String name;
/* 132 */       switch (this) {
/*     */ 
/*     */         
/*     */         case GOLD_TRUTH:
/*     */         case SILVER_TRUTH:
/* 137 */           tifNameGen = (nFrames > 999) ? (i -> String.format("man_track%04d.tif", new Object[] { i })) : (i -> String.format("man_track%03d.tif", new Object[] { i }));
/*     */ 
/*     */           
/* 140 */           name = tifNameGen.apply(Long.valueOf(frame));
/* 141 */           return Paths.get(exportRootFolder, new String[] { (String)CTCExporter.access$000().apply(Integer.valueOf(saveId)) + this.suffix, "TRA", name });
/*     */ 
/*     */         
/*     */         case RESULTS:
/* 145 */           tifNameGen = (nFrames > 999) ? (i -> String.format("mask%04d.tif", new Object[] { i })) : (i -> String.format("mask%03d.tif", new Object[] { i }));
/*     */ 
/*     */           
/* 148 */           name = tifNameGen.apply(Long.valueOf(frame));
/* 149 */           return Paths.get(exportRootFolder, new String[] { (String)CTCExporter.access$000().apply(Integer.valueOf(saveId)) + this.suffix, name });
/*     */       } 
/*     */       
/* 152 */       throw new IllegalArgumentException("Unknown export type: " + this);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static String exportAll(String exportRootFolder, TrackMate trackmate, ExportType exportType, Logger logger) throws IOException {
/* 159 */     if (!(new File(exportRootFolder)).exists()) {
/* 160 */       (new File(exportRootFolder)).mkdirs();
/*     */     }
/* 162 */     logger.log("Exporting as CTC type: " + exportType.toString() + '\n');
/* 163 */     int id = getAvailableDatasetID(exportRootFolder);
/* 164 */     exportOriginalImageData(exportRootFolder, id, trackmate, logger);
/* 165 */     String resultsFolder = exportTrackingData(exportRootFolder, id, exportType, trackmate, logger);
/* 166 */     if (exportType != ExportType.RESULTS) {
/* 167 */       exportSegmentationData(exportRootFolder, id, exportType, trackmate, logger);
/*     */     } else {
/* 169 */       exportSettingsFile(exportRootFolder, id, trackmate, logger);
/* 170 */     }  logger.log("Export done.\n");
/* 171 */     return resultsFolder;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void exportSettingsFile(String exportRootFolder, int saveId, TrackMate trackmate, Logger logger) throws IOException {
/* 189 */     Path path = ExportType.RESULTS.getTrackTextFilePath(exportRootFolder, saveId);
/* 190 */     Files.createDirectories(path.getParent(), (FileAttribute<?>[])new FileAttribute[0]);
/* 191 */     File settingsPath = new File(path.getParent().toFile(), "TrackMateSettings.xml");
/* 192 */     logger.log("Exporting TrackMate settings file to " + settingsPath + '\n');
/* 193 */     TmXmlWriter writer = new TmXmlWriter(settingsPath, logger);
/* 194 */     writer.appendSettings(trackmate.getSettings());
/* 195 */     writer.writeToFile();
/* 196 */     logger.log("Done.\n");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int getAvailableDatasetID(String exportRootFolder) {
/* 213 */     int i = 1;
/* 214 */     Path savePath1 = Paths.get(exportRootFolder, new String[] { nameGen.apply(Integer.valueOf(i)) });
/* 215 */     Path savePath2 = Paths.get(exportRootFolder, new String[] { (String)nameGen.apply(Integer.valueOf(i)) + ExportType.access$100(ExportType.GOLD_TRUTH) });
/* 216 */     Path savePath3 = Paths.get(exportRootFolder, new String[] { (String)nameGen.apply(Integer.valueOf(i)) + ExportType.access$100(ExportType.SILVER_TRUTH) });
/* 217 */     Path savePath4 = Paths.get(exportRootFolder, new String[] { (String)nameGen.apply(Integer.valueOf(i)) + ExportType.access$100(ExportType.RESULTS) });
/* 218 */     while (Files.exists(savePath1, new java.nio.file.LinkOption[0]) || Files.exists(savePath2, new java.nio.file.LinkOption[0]) || Files.exists(savePath3, new java.nio.file.LinkOption[0]) || Files.exists(savePath4, new java.nio.file.LinkOption[0])) {
/*     */       
/* 220 */       i++;
/* 221 */       savePath1 = Paths.get(exportRootFolder, new String[] { nameGen.apply(Integer.valueOf(i)) });
/* 222 */       savePath2 = Paths.get(exportRootFolder, new String[] { (String)nameGen.apply(Integer.valueOf(i)) + ExportType.access$100(ExportType.GOLD_TRUTH) });
/* 223 */       savePath3 = Paths.get(exportRootFolder, new String[] { (String)nameGen.apply(Integer.valueOf(i)) + ExportType.access$100(ExportType.SILVER_TRUTH) });
/* 224 */       savePath4 = Paths.get(exportRootFolder, new String[] { (String)nameGen.apply(Integer.valueOf(i)) + ExportType.access$100(ExportType.RESULTS) });
/*     */     } 
/* 226 */     return i;
/*     */   }
/*     */ 
/*     */   
/*     */   public static void exportOriginalImageData(String exportRootFolder, int saveId, TrackMate trackmate, Logger logger) throws IOException {
/* 231 */     exportOriginalImageData(exportRootFolder, saveId, (trackmate.getSettings()).imp, logger);
/*     */   }
/*     */ 
/*     */   
/*     */   public static void exportOriginalImageData(String exportRootFolder, int saveId, ImagePlus imp, Logger logger) throws IOException {
/* 236 */     if (imp == null) {
/*     */       return;
/*     */     }
/* 239 */     Path savePath = Paths.get(exportRootFolder, new String[] { String.format("%02d", new Object[] { Integer.valueOf(saveId) }) });
/* 240 */     if (Files.exists(savePath, new java.nio.file.LinkOption[0])) {
/*     */       
/* 242 */       String msg = "Cannot save to " + savePath + ". Folder already exists.";
/* 243 */       logger.error(msg);
/*     */       
/*     */       return;
/*     */     } 
/* 247 */     Files.createDirectory(savePath, (FileAttribute<?>[])new FileAttribute[0]);
/* 248 */     logger.log("Exporting original image to " + savePath.toString());
/*     */ 
/*     */     
/* 251 */     int nFrames = imp.getNFrames();
/* 252 */     String format = (nFrames > 999) ? "t%04d.tif" : "t%03d.tif";
/* 253 */     Duplicator duplicator = new Duplicator();
/* 254 */     int firstC = 1;
/* 255 */     int lastC = imp.getNChannels();
/* 256 */     int firstZ = 1;
/* 257 */     int lastZ = imp.getNSlices();
/*     */     
/* 259 */     for (int frame = 0; frame < nFrames; frame++) {
/*     */       
/* 261 */       ImagePlus tp = duplicator.run(imp, 1, lastC, 1, lastZ, frame + 1, frame + 1);
/* 262 */       IJ.saveAsTiff(tp, Paths.get(savePath.toString(), new String[] { String.format(format, new Object[] { Integer.valueOf(frame) }) }).toString());
/*     */     } 
/* 264 */     logger.log(". Done.\n");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void exportSegmentationData(String exportRootFolder, int saveId, ExportType exportType, TrackMate trackmate, Logger logger) throws IOException {
/*     */     long[] dims;
/* 290 */     ImagePlus imp = (trackmate.getSettings()).imp;
/*     */     
/* 292 */     if (imp != null) {
/*     */       
/* 294 */       int[] dimensions = imp.getDimensions();
/* 295 */       dims = new long[] { dimensions[0], dimensions[1], dimensions[3], dimensions[4] };
/*     */     }
/*     */     else {
/*     */       
/* 299 */       Settings s = trackmate.getSettings();
/* 300 */       dims = new long[] { s.width, s.height, s.nslices, s.nframes };
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 306 */     double[] calibration = { (imp.getCalibration()).pixelWidth, (imp.getCalibration()).pixelHeight, (imp.getCalibration()).pixelDepth, (imp.getCalibration()).frameInterval };
/*     */     
/* 308 */     ImgPlus<UnsignedShortType> labelImg = createLabelImg(dims, calibration);
/*     */ 
/*     */     
/* 311 */     Model model = trackmate.getModel();
/* 312 */     AtomicInteger idGen = new AtomicInteger(1);
/* 313 */     Set<Integer> framesToWrite = new HashSet<>();
/* 314 */     for (int frame = 0; frame < dims[3]; frame++) {
/*     */       
/* 316 */       ImgPlus<UnsignedShortType> imgCT = TMUtils.hyperSlice(labelImg, 0L, frame);
/* 317 */       LabelImgExporter.SpotRoiWriter spotWriter = new LabelImgExporter.SpotRoiWriter(imgCT);
/*     */       
/* 319 */       for (Spot spot : model.getSpots().iterable(frame, true)) {
/*     */         
/* 321 */         if (spot.getRoi() == null)
/*     */           continue; 
/* 323 */         int id = idGen.getAndIncrement();
/* 324 */         spotWriter.write(spot, id);
/* 325 */         framesToWrite.add(Integer.valueOf(frame));
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 333 */     Path path = Paths.get(exportRootFolder, new String[] { (String)nameGen.apply(Integer.valueOf(saveId)) + exportType.suffix(), "SEG" });
/* 334 */     Files.createDirectories(path, (FileAttribute<?>[])new FileAttribute[0]);
/* 335 */     logger.log("Exporting segmentation mask files to " + path.toString());
/*     */     
/* 337 */     int nFrames = imp.getNFrames();
/* 338 */     Function<Long, String> tifNameGen = (nFrames > 999) ? (i -> String.format("man_seg%04d.tif", new Object[] { i })) : (i -> String.format("man_seg%03d.tif", new Object[] { i }));
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 343 */     for (Iterator<Integer> iterator = framesToWrite.iterator(); iterator.hasNext(); ) { int i = ((Integer)iterator.next()).intValue();
/*     */       
/* 345 */       ImgPlus<UnsignedShortType> imgCT = TMUtils.hyperSlice(labelImg, 0L, i);
/* 346 */       String name = tifNameGen.apply(Long.valueOf(i));
/* 347 */       ImagePlus tp = ImageJFunctions.wrapUnsignedShort((RandomAccessibleInterval)imgCT, name);
/*     */       
/* 349 */       Path pathTif = Paths.get(exportRootFolder, new String[] { (String)nameGen.apply(Integer.valueOf(saveId)) + exportType.suffix(), "SEG", name });
/* 350 */       IJ.saveAsTiff(tp, pathTif.toString()); }
/*     */     
/* 352 */     logger.log(". Done.\n");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String exportTrackingData(String exportRootFolder, int saveId, ExportType exportType, TrackMate trackmate, Logger logger) throws FileNotFoundException, IOException {
/*     */     long[] dims;
/* 365 */     Model model2 = sanitizeAndCopy(trackmate.getModel());
/*     */ 
/*     */     
/* 368 */     TrackModel trackModel = model2.getTrackModel();
/* 369 */     TimeDirectedNeighborIndex neighborIndex = model2.getTrackModel().getDirectedNeighborIndex();
/*     */ 
/*     */     
/* 372 */     if (!GraphUtils.isTree(trackModel, neighborIndex)) {
/*     */       
/* 374 */       String msg = "Cannot perform CTC export of tracks that have fusion events.";
/* 375 */       logger.error("Cannot perform CTC export of tracks that have fusion events.");
/* 376 */       return null;
/*     */     } 
/*     */ 
/*     */     
/* 380 */     ImagePlus imp = (trackmate.getSettings()).imp;
/*     */     
/* 382 */     if (imp != null) {
/*     */       
/* 384 */       int[] dimensions = imp.getDimensions();
/* 385 */       dims = new long[] { dimensions[0], dimensions[1], dimensions[3], dimensions[4] };
/*     */     }
/*     */     else {
/*     */       
/* 389 */       Settings s = trackmate.getSettings();
/* 390 */       dims = new long[] { s.width, s.height, s.nslices, s.nframes };
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 396 */     double[] calibration = { (imp.getCalibration()).pixelWidth, (imp.getCalibration()).pixelHeight, (imp.getCalibration()).pixelDepth, (imp.getCalibration()).frameInterval };
/*     */     
/* 398 */     ImgPlus<UnsignedShortType> labelImg = createLabelImg(dims, calibration);
/*     */ 
/*     */     
/* 401 */     boolean forbidMiddleLinks = true;
/* 402 */     boolean forbidGaps = true;
/* 403 */     AtomicInteger branchIDGen = new AtomicInteger(1);
/*     */ 
/*     */     
/* 406 */     Map<List<Spot>, Integer> branchID = new HashMap<>();
/*     */     
/* 408 */     Path path = exportType.getTrackTextFilePath(exportRootFolder, saveId);
/* 409 */     Files.createDirectories(path.getParent(), (FileAttribute<?>[])new FileAttribute[0]);
/* 410 */     logger.log("Exporting tracking text file to " + path.toString());
/*     */     
/* 412 */     try(FileOutputStream fos = new FileOutputStream(path.toFile()); 
/* 413 */         BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(fos))) {
/*     */ 
/*     */       
/* 416 */       for (Integer trackID : trackModel.trackIDs(true)) {
/*     */ 
/*     */         
/* 419 */         ConvexBranchesDecomposition.TrackBranchDecomposition decomposition = ConvexBranchesDecomposition.processTrack(trackID, trackModel, neighborIndex, true, true);
/* 420 */         SimpleDirectedGraph<List<Spot>, DefaultEdge> branchGraph = ConvexBranchesDecomposition.buildBranchGraph(decomposition);
/*     */ 
/*     */         
/* 423 */         List<Spot> start = null;
/* 424 */         for (List<Spot> vertex : (Iterable<List<Spot>>)branchGraph.vertexSet()) {
/*     */           
/* 426 */           if (branchGraph.incomingEdgesOf(vertex).isEmpty()) {
/*     */             
/* 428 */             start = vertex;
/*     */             
/*     */             break;
/*     */           } 
/*     */         } 
/*     */         
/* 434 */         BreadthFirstIterator<List<Spot>, DefaultEdge> bfi = new BreadthFirstIterator((Graph)branchGraph, start);
/* 435 */         while (bfi.hasNext()) {
/*     */           int parentID;
/* 437 */           List<Spot> current = (List<Spot>)bfi.next();
/* 438 */           int currentID = branchIDGen.getAndIncrement();
/* 439 */           branchID.put(current, Integer.valueOf(currentID));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 445 */           for (Spot spot : current) {
/*     */             
/* 447 */             long l = spot.getFeature("FRAME").longValue();
/* 448 */             ImgPlus<UnsignedShortType> imgCT = TMUtils.hyperSlice(labelImg, 0L, l);
/* 449 */             LabelImgExporter.SpotRoiWriter spotRoiWriter = new LabelImgExporter.SpotRoiWriter(imgCT);
/* 450 */             spotRoiWriter.write(spot, currentID);
/*     */           } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 459 */           if (branchGraph.incomingEdgesOf(current).isEmpty()) {
/*     */             
/* 461 */             parentID = 0;
/*     */           }
/*     */           else {
/*     */             
/* 465 */             DefaultEdge edge = branchGraph.incomingEdgesOf(current).iterator().next();
/* 466 */             List<Spot> parent = (List<Spot>)Graphs.getOppositeVertex((Graph)branchGraph, edge, current);
/* 467 */             Integer obj = branchID.get(parent);
/* 468 */             parentID = (obj == null) ? 0 : obj.intValue();
/*     */           } 
/*     */ 
/*     */           
/* 472 */           int startFrame = ((Spot)current.get(0)).getFeature("FRAME").intValue();
/* 473 */           int endFrame = ((Spot)current.get(current.size() - 1)).getFeature("FRAME").intValue();
/*     */ 
/*     */           
/* 476 */           int L = currentID;
/* 477 */           int B = startFrame;
/* 478 */           int E = endFrame;
/* 479 */           int P = parentID;
/* 480 */           bw.write(String.format("%d %d %d %d", new Object[] { Integer.valueOf(L), Integer.valueOf(B), Integer.valueOf(E), Integer.valueOf(P) }));
/* 481 */           bw.newLine();
/*     */         } 
/*     */       } 
/*     */     } 
/* 485 */     logger.log(". Done.\n");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 491 */     int nFrames = imp.getNFrames();
/* 492 */     Path pathTif0 = exportType.getTrackTifFilePath(exportRootFolder, saveId, 0L, nFrames);
/* 493 */     logger.log("Exporting tracking mask files to " + pathTif0.getParent().toString());
/*     */     long frame;
/* 495 */     for (frame = 0L; frame < dims[3]; frame++) {
/*     */       
/* 497 */       ImgPlus<UnsignedShortType> imgCT = TMUtils.hyperSlice(labelImg, 0L, frame);
/* 498 */       Path pathTif = exportType.getTrackTifFilePath(exportRootFolder, saveId, frame, nFrames);
/* 499 */       String name = pathTif.getFileName().toString();
/* 500 */       ImagePlus tp = ImageJFunctions.wrapUnsignedShort((RandomAccessibleInterval)imgCT, name);
/* 501 */       IJ.saveAsTiff(tp, pathTif.toString());
/*     */     } 
/* 503 */     logger.log(". Done.\n");
/*     */ 
/*     */     
/* 506 */     return pathTif0.getParent().toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String getExportTrackingDataPath(String exportRootFolder, int saveId, ExportType exportType, TrackMate trackmate) {
/* 525 */     Path pathTif0 = exportType.getTrackTifFilePath(exportRootFolder, saveId, 0L, (trackmate.getSettings()).imp.getNFrames());
/* 526 */     return pathTif0.getParent().toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final Model sanitizeAndCopy(Model model) {
/* 543 */     double fudgeFactor = 1.2D;
/* 544 */     Model copy = model.copy();
/*     */     
/* 546 */     SpotCollection allSpots = copy.getSpots();
/* 547 */     TrackModel trackModel = copy.getTrackModel();
/* 548 */     for (Integer frame : allSpots.keySet()) {
/*     */       
/* 550 */       List<Spot> spots = new ArrayList<>();
/* 551 */       allSpots.iterable(frame.intValue(), true).forEach(spots::add);
/* 552 */       int nSpots = spots.size();
/* 553 */       for (int i = 0; i < nSpots; i++) {
/*     */         
/* 555 */         Spot s1 = spots.get(i);
/* 556 */         double r1 = s1.getFeature("RADIUS").doubleValue();
/* 557 */         for (int j = i + 1; j < nSpots; j++) {
/*     */           
/* 559 */           Spot s2 = spots.get(j);
/* 560 */           double r2 = s2.getFeature("RADIUS").doubleValue();
/* 561 */           double d = Math.sqrt(s1.squareDistanceTo((RealLocalizable)s2));
/*     */           
/* 563 */           if (1.2D * r1 > d + r2 || 1.2D * r2 > d + r1) {
/*     */ 
/*     */             
/* 566 */             Integer id1 = trackModel.trackIDOf(s1);
/* 567 */             Set<Spot> track1 = trackModel.trackSpots(id1);
/* 568 */             if (track1 == null) {
/*     */ 
/*     */ 
/*     */               
/* 572 */               try { model.removeSpot(s1);
/*     */ 
/*     */ 
/*     */                 
/* 576 */                 model.endUpdate(); } finally { model.endUpdate(); }
/*     */             
/*     */             } else {
/*     */               
/* 580 */               int n1 = track1.size();
/*     */               
/* 582 */               Integer id2 = trackModel.trackIDOf(s2);
/* 583 */               Set<Spot> track2 = trackModel.trackSpots(id2);
/* 584 */               if (track2 == null) {
/*     */ 
/*     */ 
/*     */                 
/* 588 */                 try { model.removeSpot(s2);
/*     */ 
/*     */ 
/*     */                   
/* 592 */                   model.endUpdate(); } finally { model.endUpdate(); }
/*     */               
/*     */               } else {
/*     */                 
/* 596 */                 int n2 = track2.size();
/*     */                 
/* 598 */                 Spot toRemove = (n2 > n1) ? s1 : s2;
/*     */ 
/*     */                 
/* 601 */                 List<Spot> sources = new ArrayList<>();
/* 602 */                 List<Spot> targets = new ArrayList<>();
/* 603 */                 Set<DefaultWeightedEdge> edges = trackModel.edgesOf(toRemove);
/* 604 */                 for (DefaultWeightedEdge edge : edges) {
/*     */                   
/* 606 */                   Spot source = trackModel.getEdgeSource(edge);
/* 607 */                   if (source == toRemove) {
/* 608 */                     targets.add(trackModel.getEdgeTarget(edge)); continue;
/*     */                   } 
/* 610 */                   sources.add(trackModel.getEdgeSource(edge));
/*     */                 } 
/*     */                 
/* 613 */                 model.beginUpdate();
/*     */               } 
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 630 */     return copy;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final ImgPlus<UnsignedShortType> createLabelImg(long[] dimensions, double[] calibration) {
/* 648 */     FinalDimensions finalDimensions = FinalDimensions.wrap(dimensions);
/* 649 */     Img<UnsignedShortType> lblImg = Util.getArrayOrCellImgFactory((Dimensions)finalDimensions, (NativeType)new UnsignedShortType()).create((Dimensions)finalDimensions);
/* 650 */     AxisType[] axes = { Axes.X, Axes.Y, Axes.Z, Axes.TIME };
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 655 */     ImgPlus<UnsignedShortType> imgPlus = new ImgPlus(lblImg, "LblImg", axes, calibration);
/* 656 */     return imgPlus;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/action/CTCExporter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */