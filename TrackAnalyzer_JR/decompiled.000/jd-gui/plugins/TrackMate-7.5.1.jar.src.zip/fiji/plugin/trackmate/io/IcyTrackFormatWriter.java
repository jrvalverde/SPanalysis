/*     */ package fiji.plugin.trackmate.io;
/*     */ 
/*     */ import fiji.plugin.trackmate.Model;
/*     */ import fiji.plugin.trackmate.Spot;
/*     */ import fiji.plugin.trackmate.graph.ConvexBranchesDecomposition;
/*     */ import java.io.File;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import net.imglib2.algorithm.Algorithm;
/*     */ import net.imglib2.algorithm.Benchmark;
/*     */ import org.jdom2.Content;
/*     */ import org.jdom2.Document;
/*     */ import org.jdom2.Element;
/*     */ import org.jdom2.JDOMException;
/*     */ import org.jdom2.input.SAXBuilder;
/*     */ import org.jdom2.output.Format;
/*     */ import org.jdom2.output.XMLOutputter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IcyTrackFormatWriter
/*     */   implements Algorithm, Benchmark
/*     */ {
/*     */   private static final String BASE_ERROR_MSG = "[ICYTrackFormatWriter] ";
/*     */   private static final String ROOT_ELEMENT = "root";
/*     */   private static final String TRACK_FILE = "trackfile";
/*     */   private static final String TRACK_GROUP = "trackgroup";
/*     */   private static final String TRACK = "track";
/*     */   private static final String DETECTION = "detection";
/*     */   private static final String LINK_LIST = "linklist";
/*     */   private static final String LINK = "link";
/*     */   private static final String DESCRIPTION_ATTRIBUTE = "description";
/*     */   private final File file;
/*     */   private final Model model;
/*     */   private long processingTime;
/*     */   private String errorMessage;
/*     */   private final double[] calibration;
/*     */   private final String description;
/*     */   
/*     */   public IcyTrackFormatWriter(File file, Model model, double[] calibration) {
/*  81 */     this(file, model, calibration, null);
/*     */   }
/*     */ 
/*     */   
/*     */   public IcyTrackFormatWriter(File file, Model model, double[] calibration, String description) {
/*  86 */     this.file = file;
/*  87 */     this.model = model;
/*  88 */     this.calibration = calibration;
/*  89 */     this.description = description;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public long getProcessingTime() {
/*  95 */     return this.processingTime;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean checkInput() {
/* 101 */     if (!this.file.exists()) {
/*     */       
/*     */       try {
/*     */         
/* 105 */         this.file.createNewFile();
/*     */       }
/* 107 */       catch (IOException e) {
/*     */         
/* 109 */         this.errorMessage = "[ICYTrackFormatWriter] " + e.getMessage();
/* 110 */         return false;
/*     */       } 
/*     */     }
/*     */     
/* 114 */     if (!this.file.canWrite()) {
/*     */       
/* 116 */       this.errorMessage = "[ICYTrackFormatWriter] Cannot write to " + this.file + ".\n";
/* 117 */       return false;
/*     */     } 
/* 119 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean process() {
/* 125 */     long start = System.currentTimeMillis();
/*     */ 
/*     */     
/* 128 */     ConvexBranchesDecomposition splitter = new ConvexBranchesDecomposition(this.model, true, true);
/* 129 */     if (!splitter.checkInput() || !splitter.process()) {
/*     */       
/* 131 */       this.errorMessage = splitter.getErrorMessage();
/* 132 */       return false;
/*     */     } 
/*     */     
/* 135 */     Element root = new Element("root");
/*     */     
/* 137 */     Element trackFile = new Element("trackfile");
/* 138 */     trackFile.setAttribute("version", "1");
/* 139 */     root.addContent((Content)trackFile);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 145 */     Element trackGroup = new Element("trackgroup");
/* 146 */     if (null != this.description && !this.description.isEmpty()) {
/* 147 */       trackGroup.setAttribute("description", this.description);
/*     */     }
/* 149 */     Map<Spot, Integer> beginnings = new HashMap<>();
/* 150 */     Map<Spot, Integer> endings = new HashMap<>();
/*     */     
/* 152 */     Collection<List<Spot>> branches = splitter.getBranches();
/* 153 */     for (List<Spot> branch : branches) {
/*     */       
/* 155 */       int branchID = branch.hashCode();
/*     */ 
/*     */       
/* 158 */       beginnings.put(branch.get(0), Integer.valueOf(branchID));
/* 159 */       endings.put(branch.get(branch.size() - 1), Integer.valueOf(branchID));
/*     */ 
/*     */       
/* 162 */       Element track = new Element("track");
/* 163 */       track.setAttribute("id", "" + branchID);
/* 164 */       for (Spot spot : branch) {
/*     */         
/* 166 */         double x = spot.getDoublePosition(0) / this.calibration[0];
/* 167 */         double y = spot.getDoublePosition(1) / this.calibration[1];
/* 168 */         int z = (int)(spot.getDoublePosition(2) / this.calibration[2]);
/* 169 */         int t = spot.getFeature("FRAME").intValue();
/* 170 */         Element detection = new Element("detection");
/* 171 */         detection.setAttribute("t", Integer.toString(t));
/* 172 */         detection.setAttribute("x", "" + x);
/* 173 */         detection.setAttribute("y", "" + y);
/* 174 */         detection.setAttribute("z", Integer.toString(z));
/* 175 */         detection.setAttribute("classname", "plugins.nchenouard.particleTracking.sequenceGenerator.ProfileSpotTrack");
/* 176 */         detection.setAttribute("type", "1");
/* 177 */         track.addContent((Content)detection);
/*     */       } 
/* 179 */       trackGroup.addContent((Content)track);
/*     */     } 
/* 181 */     root.addContent((Content)trackGroup);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 187 */     Element linklist = new Element("linklist");
/* 188 */     Collection<List<Spot>> links = splitter.getLinks();
/* 189 */     for (List<Spot> link : links) {
/*     */       
/* 191 */       Spot spotA = link.get(0);
/* 192 */       Spot spotB = link.get(1);
/*     */       
/* 194 */       int from = ((Integer)endings.get(spotA)).intValue();
/* 195 */       int to = ((Integer)beginnings.get(spotB)).intValue();
/*     */       
/* 197 */       Element linkEl = new Element("link");
/* 198 */       linkEl.setAttribute("from", "" + from);
/* 199 */       linkEl.setAttribute("to", "" + to);
/*     */       
/* 201 */       linklist.addContent((Content)linkEl);
/*     */     } 
/* 203 */     root.addContent((Content)linklist);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 209 */     Document document = new Document(root);
/* 210 */     XMLOutputter outputter = new XMLOutputter(Format.getPrettyFormat());
/*     */     
/*     */     try {
/* 213 */       outputter.output(document, new FileOutputStream(this.file));
/*     */     }
/* 215 */     catch (FileNotFoundException e) {
/*     */       
/* 217 */       this.errorMessage = e.getMessage();
/* 218 */       return false;
/*     */     }
/* 220 */     catch (IOException e) {
/*     */       
/* 222 */       this.errorMessage = e.getMessage();
/* 223 */       return false;
/*     */     } 
/*     */     
/* 226 */     long end = System.currentTimeMillis();
/* 227 */     this.processingTime = end - start;
/* 228 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getErrorMessage() {
/* 234 */     return this.errorMessage;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void main(String[] args) throws JDOMException, IOException {
/* 243 */     File source = new File("/Users/tinevez/Projects/JYTinevez/CelegansLineage/Data/LSM700U/10-03-17-3hours_bis.xml");
/* 244 */     TmXmlReader reader = new TmXmlReader(source);
/*     */     
/* 246 */     Model model = reader.getModel();
/* 247 */     double[] calibration = readCalibration(source);
/*     */     
/* 249 */     File target = new File("/Users/tinevez/Desktop/IcyConverstion.xml");
/* 250 */     IcyTrackFormatWriter exporter = new IcyTrackFormatWriter(target, model, calibration);
/* 251 */     if (!exporter.checkInput() || !exporter.process()) {
/*     */       
/* 253 */       System.out.println(exporter.getErrorMessage());
/*     */     }
/*     */     else {
/*     */       
/* 257 */       System.out.println("Export done in " + exporter.getProcessingTime() + " ms.");
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static double[] readCalibration(File source) throws JDOMException, IOException {
/* 263 */     SAXBuilder sb = new SAXBuilder();
/* 264 */     Document document = sb.build(source);
/* 265 */     Element root = document.getRootElement();
/*     */     
/* 267 */     double[] calibration = new double[3];
/*     */     
/* 269 */     Element settings = root.getChild("Settings");
/* 270 */     Element imageData = settings.getChild("ImageData");
/*     */     
/* 272 */     calibration[0] = imageData.getAttribute("pixelwidth").getDoubleValue();
/* 273 */     calibration[1] = imageData.getAttribute("pixelheight").getDoubleValue();
/* 274 */     calibration[2] = imageData.getAttribute("voxeldepth").getDoubleValue();
/* 275 */     return calibration;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/io/IcyTrackFormatWriter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */