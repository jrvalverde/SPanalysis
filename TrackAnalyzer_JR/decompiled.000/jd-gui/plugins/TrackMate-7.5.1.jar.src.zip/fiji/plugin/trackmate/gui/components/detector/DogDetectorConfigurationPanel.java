/*    */ package fiji.plugin.trackmate.gui.components.detector;
/*    */ 
/*    */ import fiji.plugin.trackmate.Model;
/*    */ import fiji.plugin.trackmate.Settings;
/*    */ import fiji.plugin.trackmate.detection.DogDetectorFactory;
/*    */ import fiji.plugin.trackmate.detection.SpotDetectorFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DogDetectorConfigurationPanel
/*    */   extends LogDetectorConfigurationPanel
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   public DogDetectorConfigurationPanel(Settings settings, Model model, String infoText, String detectorName) {
/* 35 */     super(settings, model, infoText, detectorName);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected SpotDetectorFactory<?> getDetectorFactory() {
/* 42 */     return (SpotDetectorFactory<?>)new DogDetectorFactory();
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate-7.5.1.jar!/fiji/plugin/trackmate/gui/components/detector/DogDetectorConfigurationPanel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */