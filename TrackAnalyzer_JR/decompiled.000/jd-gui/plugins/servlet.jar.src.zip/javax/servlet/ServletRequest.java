package javax.servlet;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.Enumeration;
import java.util.Locale;
import java.util.Map;

public interface ServletRequest {
  Object getAttribute(String paramString);
  
  Enumeration getAttributeNames();
  
  String getCharacterEncoding();
  
  void setCharacterEncoding(String paramString) throws UnsupportedEncodingException;
  
  int getContentLength();
  
  String getContentType();
  
  ServletInputStream getInputStream() throws IOException;
  
  String getParameter(String paramString);
  
  Enumeration getParameterNames();
  
  String[] getParameterValues(String paramString);
  
  Map getParameterMap();
  
  String getProtocol();
  
  String getScheme();
  
  String getServerName();
  
  int getServerPort();
  
  BufferedReader getReader() throws IOException;
  
  String getRemoteAddr();
  
  String getRemoteHost();
  
  void setAttribute(String paramString, Object paramObject);
  
  void removeAttribute(String paramString);
  
  Locale getLocale();
  
  Enumeration getLocales();
  
  boolean isSecure();
  
  RequestDispatcher getRequestDispatcher(String paramString);
  
  String getRealPath(String paramString);
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/servlet.jar!/javax/servlet/ServletRequest.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */