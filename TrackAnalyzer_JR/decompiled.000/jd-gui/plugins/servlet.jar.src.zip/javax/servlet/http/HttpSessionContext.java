package javax.servlet.http;

import java.util.Enumeration;

public interface HttpSessionContext {
  HttpSession getSession(String paramString);
  
  Enumeration getIds();
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/servlet.jar!/javax/servlet/http/HttpSessionContext.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */