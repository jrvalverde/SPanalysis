package javax.servlet.http;

import java.util.EventListener;

public interface HttpSessionListener extends EventListener {
  void sessionCreated(HttpSessionEvent paramHttpSessionEvent);
  
  void sessionDestroyed(HttpSessionEvent paramHttpSessionEvent);
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/servlet.jar!/javax/servlet/http/HttpSessionListener.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */