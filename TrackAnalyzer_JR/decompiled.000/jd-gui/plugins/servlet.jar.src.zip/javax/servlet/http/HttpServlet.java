/*     */ package javax.servlet.http;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Serializable;
/*     */ import java.lang.reflect.Method;
/*     */ import java.text.MessageFormat;
/*     */ import java.util.Enumeration;
/*     */ import java.util.ResourceBundle;
/*     */ import javax.servlet.GenericServlet;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.ServletOutputStream;
/*     */ import javax.servlet.ServletRequest;
/*     */ import javax.servlet.ServletResponse;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class HttpServlet
/*     */   extends GenericServlet
/*     */   implements Serializable
/*     */ {
/* 130 */   private static final String METHOD_DELETE = "DELETE";
/* 131 */   private static final String METHOD_HEAD = "HEAD";
/* 132 */   private static final String METHOD_GET = "GET";
/* 133 */   private static final String METHOD_OPTIONS = "OPTIONS";
/* 134 */   private static final String METHOD_POST = "POST";
/* 135 */   private static final String METHOD_PUT = "PUT";
/* 136 */   private static final String METHOD_TRACE = "TRACE";
/*     */   
/* 138 */   private static final String HEADER_IFMODSINCE = "If-Modified-Since";
/* 139 */   private static final String HEADER_LASTMOD = "Last-Modified";
/*     */   
/* 141 */   private static final String LSTRING_FILE = "javax.servlet.http.LocalStrings";
/*     */   
/* 143 */   private static ResourceBundle lStrings = ResourceBundle.getBundle("javax.servlet.http.LocalStrings");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
/* 227 */     String protocol = req.getProtocol();
/* 228 */     String msg = lStrings.getString("http.method_get_not_supported");
/* 229 */     if (protocol.endsWith("1.1")) {
/* 230 */       resp.sendError(405, msg);
/*     */     } else {
/* 232 */       resp.sendError(400, msg);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected long getLastModified(HttpServletRequest req) {
/* 266 */     return -1L;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void doHead(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
/* 311 */     NoBodyResponse response = new NoBodyResponse(resp);
/*     */     
/* 313 */     doGet(req, response);
/* 314 */     response.setContentLength();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
/* 386 */     String protocol = req.getProtocol();
/* 387 */     String msg = lStrings.getString("http.method_post_not_supported");
/* 388 */     if (protocol.endsWith("1.1")) {
/* 389 */       resp.sendError(405, msg);
/*     */     } else {
/* 391 */       resp.sendError(400, msg);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void doPut(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
/* 446 */     String protocol = req.getProtocol();
/* 447 */     String msg = lStrings.getString("http.method_put_not_supported");
/* 448 */     if (protocol.endsWith("1.1")) {
/* 449 */       resp.sendError(405, msg);
/*     */     } else {
/* 451 */       resp.sendError(400, msg);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void doDelete(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
/* 501 */     String protocol = req.getProtocol();
/* 502 */     String msg = lStrings.getString("http.method_delete_not_supported");
/* 503 */     if (protocol.endsWith("1.1")) {
/* 504 */       resp.sendError(405, msg);
/*     */     } else {
/* 506 */       resp.sendError(400, msg);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Method[] getAllDeclaredMethods(Class c) {
/* 515 */     if (c.getName().equals("javax.servlet.http.HttpServlet")) {
/* 516 */       return null;
/*     */     }
/* 518 */     int j = 0;
/* 519 */     Method[] parentMethods = getAllDeclaredMethods(c.getSuperclass());
/* 520 */     Method[] thisMethods = c.getDeclaredMethods();
/*     */     
/* 522 */     if (parentMethods != null) {
/* 523 */       Method[] allMethods = new Method[parentMethods.length + thisMethods.length];
/*     */       
/* 525 */       for (int i = 0; i < parentMethods.length; i++) {
/* 526 */         allMethods[i] = parentMethods[i];
/* 527 */         j = i;
/*     */       } 
/*     */       
/* 530 */       for (int k = ++j; k < thisMethods.length + j; k++) {
/* 531 */         allMethods[k] = thisMethods[k - j];
/*     */       }
/* 533 */       return allMethods;
/*     */     } 
/* 535 */     return thisMethods;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void doOptions(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
/* 581 */     Method[] methods = getAllDeclaredMethods(getClass());
/*     */     
/* 583 */     boolean ALLOW_GET = false;
/* 584 */     boolean ALLOW_HEAD = false;
/* 585 */     boolean ALLOW_POST = false;
/* 586 */     boolean ALLOW_PUT = false;
/* 587 */     boolean ALLOW_DELETE = false;
/* 588 */     boolean ALLOW_TRACE = true;
/* 589 */     boolean ALLOW_OPTIONS = true;
/*     */     
/* 591 */     for (int i = 0; i < methods.length; i++) {
/* 592 */       Method m = methods[i];
/*     */       
/* 594 */       if (m.getName().equals("doGet")) {
/* 595 */         ALLOW_GET = true;
/* 596 */         ALLOW_HEAD = true;
/*     */       } 
/* 598 */       if (m.getName().equals("doPost"))
/* 599 */         ALLOW_POST = true; 
/* 600 */       if (m.getName().equals("doPut"))
/* 601 */         ALLOW_PUT = true; 
/* 602 */       if (m.getName().equals("doDelete")) {
/* 603 */         ALLOW_DELETE = true;
/*     */       }
/*     */     } 
/*     */     
/* 607 */     String allow = null;
/* 608 */     if (ALLOW_GET && 
/* 609 */       allow == null) allow = "GET"; 
/* 610 */     if (ALLOW_HEAD)
/* 611 */       if (allow == null) { allow = "HEAD"; }
/* 612 */       else { allow = allow + ", HEAD"; }
/* 613 */         if (ALLOW_POST)
/* 614 */       if (allow == null) { allow = "POST"; }
/* 615 */       else { allow = allow + ", POST"; }
/* 616 */         if (ALLOW_PUT)
/* 617 */       if (allow == null) { allow = "PUT"; }
/* 618 */       else { allow = allow + ", PUT"; }
/* 619 */         if (ALLOW_DELETE)
/* 620 */       if (allow == null) { allow = "DELETE"; }
/* 621 */       else { allow = allow + ", DELETE"; }
/* 622 */         if (ALLOW_TRACE)
/* 623 */       if (allow == null) { allow = "TRACE"; }
/* 624 */       else { allow = allow + ", TRACE"; }
/* 625 */         if (ALLOW_OPTIONS)
/* 626 */       if (allow == null) { allow = "OPTIONS"; }
/* 627 */       else { allow = allow + ", OPTIONS"; }
/*     */        
/* 629 */     resp.setHeader("Allow", allow);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void doTrace(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
/* 670 */     String CRLF = "\r\n";
/* 671 */     String responseString = "TRACE " + req.getRequestURI() + " " + req.getProtocol();
/*     */ 
/*     */     
/* 674 */     Enumeration reqHeaderEnum = req.getHeaderNames();
/*     */     
/* 676 */     while (reqHeaderEnum.hasMoreElements()) {
/* 677 */       String headerName = reqHeaderEnum.nextElement();
/* 678 */       responseString = responseString + CRLF + headerName + ": " + req.getHeader(headerName);
/*     */     } 
/*     */ 
/*     */     
/* 682 */     responseString = responseString + CRLF;
/*     */     
/* 684 */     int responseLength = responseString.length();
/*     */     
/* 686 */     resp.setContentType("message/http");
/* 687 */     resp.setContentLength(responseLength);
/* 688 */     ServletOutputStream out = resp.getOutputStream();
/* 689 */     out.print(responseString);
/* 690 */     out.close();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
/* 733 */     String method = req.getMethod();
/*     */     
/* 735 */     if (method.equals("GET")) {
/* 736 */       long lastModified = getLastModified(req);
/* 737 */       if (lastModified == -1L) {
/*     */ 
/*     */         
/* 740 */         doGet(req, resp);
/*     */       } else {
/* 742 */         long ifModifiedSince = req.getDateHeader("If-Modified-Since");
/* 743 */         if (ifModifiedSince < lastModified / 1000L * 1000L) {
/*     */ 
/*     */ 
/*     */           
/* 747 */           maybeSetLastModified(resp, lastModified);
/* 748 */           doGet(req, resp);
/*     */         } else {
/* 750 */           resp.setStatus(304);
/*     */         }
/*     */       
/*     */       } 
/* 754 */     } else if (method.equals("HEAD")) {
/* 755 */       long lastModified = getLastModified(req);
/* 756 */       maybeSetLastModified(resp, lastModified);
/* 757 */       doHead(req, resp);
/*     */     }
/* 759 */     else if (method.equals("POST")) {
/* 760 */       doPost(req, resp);
/*     */     }
/* 762 */     else if (method.equals("PUT")) {
/* 763 */       doPut(req, resp);
/*     */     }
/* 765 */     else if (method.equals("DELETE")) {
/* 766 */       doDelete(req, resp);
/*     */     }
/* 768 */     else if (method.equals("OPTIONS")) {
/* 769 */       doOptions(req, resp);
/*     */     }
/* 771 */     else if (method.equals("TRACE")) {
/* 772 */       doTrace(req, resp);
/*     */ 
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */ 
/*     */       
/* 780 */       String errMsg = lStrings.getString("http.method_not_implemented");
/* 781 */       Object[] errArgs = new Object[1];
/* 782 */       errArgs[0] = method;
/* 783 */       errMsg = MessageFormat.format(errMsg, errArgs);
/*     */       
/* 785 */       resp.sendError(501, errMsg);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void maybeSetLastModified(HttpServletResponse resp, long lastModified) {
/* 803 */     if (resp.containsHeader("Last-Modified"))
/*     */       return; 
/* 805 */     if (lastModified >= 0L) {
/* 806 */       resp.setDateHeader("Last-Modified", lastModified);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void service(ServletRequest req, ServletResponse res) throws ServletException, IOException {
/*     */     HttpServletRequest request;
/*     */     HttpServletResponse response;
/*     */     try {
/* 848 */       request = (HttpServletRequest)req;
/* 849 */       response = (HttpServletResponse)res;
/*     */     } catch (ClassCastException e) {
/* 851 */       throw new ServletException("non-HTTP request or response");
/*     */     } 
/* 853 */     service(request, response);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/servlet.jar!/javax/servlet/http/HttpServlet.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */