package javax.servlet.http;

import java.util.EventListener;

public interface HttpSessionBindingListener extends EventListener {
  void valueBound(HttpSessionBindingEvent paramHttpSessionBindingEvent);
  
  void valueUnbound(HttpSessionBindingEvent paramHttpSessionBindingEvent);
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/servlet.jar!/javax/servlet/http/HttpSessionBindingListener.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */