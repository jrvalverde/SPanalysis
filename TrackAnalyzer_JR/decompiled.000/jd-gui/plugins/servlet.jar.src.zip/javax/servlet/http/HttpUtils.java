/*     */ package javax.servlet.http;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.util.Hashtable;
/*     */ import java.util.ResourceBundle;
/*     */ import java.util.StringTokenizer;
/*     */ import javax.servlet.ServletInputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HttpUtils
/*     */ {
/*  81 */   private static final String LSTRING_FILE = "javax.servlet.http.LocalStrings";
/*     */   
/*  83 */   private static ResourceBundle lStrings = ResourceBundle.getBundle("javax.servlet.http.LocalStrings");
/*     */ 
/*     */   
/*  86 */   static Hashtable nullHashtable = new Hashtable();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Hashtable parseQueryString(String s) {
/* 135 */     String[] valArray = null;
/*     */     
/* 137 */     if (s == null) {
/* 138 */       throw new IllegalArgumentException();
/*     */     }
/* 140 */     Hashtable ht = new Hashtable();
/* 141 */     StringBuffer sb = new StringBuffer();
/* 142 */     StringTokenizer st = new StringTokenizer(s, "&");
/* 143 */     while (st.hasMoreTokens()) {
/* 144 */       String pair = st.nextToken();
/* 145 */       int pos = pair.indexOf('=');
/* 146 */       if (pos == -1)
/*     */       {
/*     */         
/* 149 */         throw new IllegalArgumentException();
/*     */       }
/* 151 */       String key = parseName(pair.substring(0, pos), sb);
/* 152 */       String val = parseName(pair.substring(pos + 1, pair.length()), sb);
/* 153 */       if (ht.containsKey(key)) {
/* 154 */         String[] oldVals = (String[])ht.get(key);
/* 155 */         valArray = new String[oldVals.length + 1];
/* 156 */         for (int i = 0; i < oldVals.length; i++)
/* 157 */           valArray[i] = oldVals[i]; 
/* 158 */         valArray[oldVals.length] = val;
/*     */       } else {
/* 160 */         valArray = new String[1];
/* 161 */         valArray[0] = val;
/*     */       } 
/* 163 */       ht.put(key, valArray);
/*     */     } 
/* 165 */     return ht;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Hashtable parsePostData(int len, ServletInputStream in) {
/* 218 */     if (len <= 0) {
/* 219 */       return new Hashtable();
/*     */     }
/* 221 */     if (in == null) {
/* 222 */       throw new IllegalArgumentException();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 228 */     byte[] postedBytes = new byte[len];
/*     */     try {
/* 230 */       int offset = 0;
/*     */       
/*     */       do {
/* 233 */         int inputLen = in.read(postedBytes, offset, len - offset);
/* 234 */         if (inputLen <= 0) {
/* 235 */           String msg = lStrings.getString("err.io.short_read");
/* 236 */           throw new IllegalArgumentException(msg);
/*     */         } 
/* 238 */         offset += inputLen;
/* 239 */       } while (len - offset > 0);
/*     */     } catch (IOException e) {
/*     */       
/* 242 */       throw new IllegalArgumentException(e.getMessage());
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 251 */       String postedBody = new String(postedBytes, 0, len, "8859_1");
/* 252 */       return parseQueryString(postedBody);
/*     */     }
/*     */     catch (UnsupportedEncodingException e) {
/*     */       
/* 256 */       throw new IllegalArgumentException(e.getMessage());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String parseName(String s, StringBuffer sb) {
/* 268 */     sb.setLength(0);
/* 269 */     for (int i = 0; i < s.length(); i++) {
/* 270 */       char c = s.charAt(i);
/* 271 */       switch (c) {
/*     */         case '+':
/* 273 */           sb.append(' ');
/*     */           break;
/*     */         case '%':
/*     */           try {
/* 277 */             sb.append((char)Integer.parseInt(s.substring(i + 1, i + 3), 16));
/*     */             
/* 279 */             i += 2;
/*     */           }
/*     */           catch (NumberFormatException e) {
/*     */             
/* 283 */             throw new IllegalArgumentException();
/*     */           } catch (StringIndexOutOfBoundsException e) {
/* 285 */             String rest = s.substring(i);
/* 286 */             sb.append(rest);
/* 287 */             if (rest.length() == 2) {
/* 288 */               i++;
/*     */             }
/*     */           } 
/*     */           break;
/*     */         default:
/* 293 */           sb.append(c);
/*     */           break;
/*     */       } 
/*     */     } 
/* 297 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static StringBuffer getRequestURL(HttpServletRequest req) {
/* 327 */     StringBuffer url = new StringBuffer();
/* 328 */     String scheme = req.getScheme();
/* 329 */     int port = req.getServerPort();
/* 330 */     String urlPath = req.getRequestURI();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 335 */     url.append(scheme);
/* 336 */     url.append("://");
/* 337 */     url.append(req.getServerName());
/* 338 */     if ((scheme.equals("http") && port != 80) || (scheme.equals("https") && port != 443)) {
/*     */       
/* 340 */       url.append(':');
/* 341 */       url.append(req.getServerPort());
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 347 */     url.append(urlPath);
/* 348 */     return url;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/servlet.jar!/javax/servlet/http/HttpUtils.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */