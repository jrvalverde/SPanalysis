package javax.servlet.http;

import java.util.EventListener;

public interface HttpSessionAttributeListener extends EventListener {
  void attributeAdded(HttpSessionBindingEvent paramHttpSessionBindingEvent);
  
  void attributeRemoved(HttpSessionBindingEvent paramHttpSessionBindingEvent);
  
  void attributeReplaced(HttpSessionBindingEvent paramHttpSessionBindingEvent);
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/servlet.jar!/javax/servlet/http/HttpSessionAttributeListener.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */