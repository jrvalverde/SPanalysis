/*     */ package javax.servlet.http;
/*     */ 
/*     */ import java.security.Principal;
/*     */ import java.util.Enumeration;
/*     */ import javax.servlet.ServletRequest;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface HttpServletRequest
/*     */   extends ServletRequest
/*     */ {
/*  88 */   public static final String BASIC_AUTH = "BASIC";
/*     */ 
/*     */ 
/*     */   
/*  92 */   public static final String FORM_AUTH = "FORM";
/*     */ 
/*     */ 
/*     */   
/*  96 */   public static final String CLIENT_CERT_AUTH = "CLIENT_CERT";
/*     */ 
/*     */ 
/*     */   
/* 100 */   public static final String DIGEST_AUTH = "DIGEST";
/*     */   
/*     */   String getAuthType();
/*     */   
/*     */   Cookie[] getCookies();
/*     */   
/*     */   long getDateHeader(String paramString);
/*     */   
/*     */   String getHeader(String paramString);
/*     */   
/*     */   Enumeration getHeaders(String paramString);
/*     */   
/*     */   Enumeration getHeaderNames();
/*     */   
/*     */   int getIntHeader(String paramString);
/*     */   
/*     */   String getMethod();
/*     */   
/*     */   String getPathInfo();
/*     */   
/*     */   String getPathTranslated();
/*     */   
/*     */   String getContextPath();
/*     */   
/*     */   String getQueryString();
/*     */   
/*     */   String getRemoteUser();
/*     */   
/*     */   boolean isUserInRole(String paramString);
/*     */   
/*     */   Principal getUserPrincipal();
/*     */   
/*     */   String getRequestedSessionId();
/*     */   
/*     */   String getRequestURI();
/*     */   
/*     */   StringBuffer getRequestURL();
/*     */   
/*     */   String getServletPath();
/*     */   
/*     */   HttpSession getSession(boolean paramBoolean);
/*     */   
/*     */   HttpSession getSession();
/*     */   
/*     */   boolean isRequestedSessionIdValid();
/*     */   
/*     */   boolean isRequestedSessionIdFromCookie();
/*     */   
/*     */   boolean isRequestedSessionIdFromURL();
/*     */   
/*     */   boolean isRequestedSessionIdFromUrl();
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/servlet.jar!/javax/servlet/http/HttpServletRequest.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */