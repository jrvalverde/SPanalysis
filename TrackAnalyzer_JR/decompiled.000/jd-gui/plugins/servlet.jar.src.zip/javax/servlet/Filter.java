package javax.servlet;

import java.io.IOException;

public interface Filter {
  void init(FilterConfig paramFilterConfig) throws ServletException;
  
  void doFilter(ServletRequest paramServletRequest, ServletResponse paramServletResponse, FilterChain paramFilterChain) throws IOException, ServletException;
  
  void destroy();
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/servlet.jar!/javax/servlet/Filter.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */