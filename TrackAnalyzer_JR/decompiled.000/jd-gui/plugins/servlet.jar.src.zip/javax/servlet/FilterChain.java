package javax.servlet;

import java.io.IOException;

public interface FilterChain {
  void doFilter(ServletRequest paramServletRequest, ServletResponse paramServletResponse) throws IOException, ServletException;
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/servlet.jar!/javax/servlet/FilterChain.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */