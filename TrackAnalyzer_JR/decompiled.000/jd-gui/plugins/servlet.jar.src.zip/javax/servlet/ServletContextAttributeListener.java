package javax.servlet;

import java.util.EventListener;

public interface ServletContextAttributeListener extends EventListener {
  void attributeAdded(ServletContextAttributeEvent paramServletContextAttributeEvent);
  
  void attributeRemoved(ServletContextAttributeEvent paramServletContextAttributeEvent);
  
  void attributeReplaced(ServletContextAttributeEvent paramServletContextAttributeEvent);
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/servlet.jar!/javax/servlet/ServletContextAttributeListener.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */