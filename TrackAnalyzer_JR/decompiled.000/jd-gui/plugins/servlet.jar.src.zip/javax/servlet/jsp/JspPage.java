package javax.servlet.jsp;

import javax.servlet.Servlet;

public interface JspPage extends Servlet {
  void jspInit();
  
  void jspDestroy();
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/servlet.jar!/javax/servlet/jsp/JspPage.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */