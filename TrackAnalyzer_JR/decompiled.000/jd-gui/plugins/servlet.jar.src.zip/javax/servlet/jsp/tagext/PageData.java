package javax.servlet.jsp.tagext;

import java.io.InputStream;

public abstract class PageData {
  public abstract InputStream getInputStream();
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/servlet.jar!/javax/servlet/jsp/tagext/PageData.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */