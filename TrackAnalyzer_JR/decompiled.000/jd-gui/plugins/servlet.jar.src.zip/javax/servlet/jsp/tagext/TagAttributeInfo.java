/*     */ package javax.servlet.jsp.tagext;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TagAttributeInfo
/*     */ {
/*  73 */   public static final String ID = "id";
/*     */ 
/*     */   
/*     */   private String name;
/*     */ 
/*     */   
/*     */   private String type;
/*     */ 
/*     */   
/*     */   private boolean reqTime;
/*     */ 
/*     */   
/*     */   private boolean required;
/*     */ 
/*     */ 
/*     */   
/*     */   public TagAttributeInfo(String name, boolean required, String type, boolean reqTime) {
/*  90 */     this.name = name;
/*  91 */     this.required = required;
/*  92 */     this.type = type;
/*  93 */     this.reqTime = reqTime;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/* 103 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getTypeName() {
/* 113 */     return this.type;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean canBeRequestTime() {
/* 123 */     return this.reqTime;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isRequired() {
/* 132 */     return this.required;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static TagAttributeInfo getIdAttribute(TagAttributeInfo[] a) {
/* 143 */     for (int i = 0; i < a.length; i++) {
/* 144 */       if (a[i].getName().equals("id")) {
/* 145 */         return a[i];
/*     */       }
/*     */     } 
/* 148 */     return null;
/*     */   }
/*     */   
/*     */   public String toString() {
/* 152 */     StringBuffer b = new StringBuffer();
/* 153 */     b.append("name = " + this.name + " ");
/* 154 */     b.append("type = " + this.type + " ");
/* 155 */     b.append("reqTime = " + this.reqTime + " ");
/* 156 */     b.append("required = " + this.required + " ");
/* 157 */     return b.toString();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/servlet.jar!/javax/servlet/jsp/tagext/TagAttributeInfo.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */