package javax.servlet.jsp;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public interface HttpJspPage extends JspPage {
  void _jspService(HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse) throws ServletException, IOException;
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/servlet.jar!/javax/servlet/jsp/HttpJspPage.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */