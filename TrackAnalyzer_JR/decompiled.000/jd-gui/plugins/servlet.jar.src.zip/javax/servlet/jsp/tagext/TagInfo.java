/*     */ package javax.servlet.jsp.tagext;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TagInfo
/*     */ {
/*  72 */   public static final String BODY_CONTENT_JSP = "JSP";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  78 */   public static final String BODY_CONTENT_TAG_DEPENDENT = "TAGDEPENDENT";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  85 */   public static final String BODY_CONTENT_EMPTY = "EMPTY";
/*     */ 
/*     */   
/*     */   private String tagName;
/*     */ 
/*     */   
/*     */   private String tagClassName;
/*     */ 
/*     */   
/*     */   private String bodyContent;
/*     */ 
/*     */   
/*     */   private String infoString;
/*     */   
/*     */   private TagLibraryInfo tagLibrary;
/*     */   
/*     */   private TagExtraInfo tagExtraInfo;
/*     */   
/*     */   private TagAttributeInfo[] attributeInfo;
/*     */   
/*     */   private String displayName;
/*     */   
/*     */   private String smallIcon;
/*     */   
/*     */   private String largeIcon;
/*     */   
/*     */   private TagVariableInfo[] tagVariableInfo;
/*     */ 
/*     */   
/*     */   public TagInfo(String tagName, String tagClassName, String bodycontent, String infoString, TagLibraryInfo taglib, TagExtraInfo tagExtraInfo, TagAttributeInfo[] attributeInfo) {
/* 115 */     this.tagName = tagName;
/* 116 */     this.tagClassName = tagClassName;
/* 117 */     this.bodyContent = bodycontent;
/* 118 */     this.infoString = infoString;
/* 119 */     this.tagLibrary = taglib;
/* 120 */     this.tagExtraInfo = tagExtraInfo;
/* 121 */     this.attributeInfo = attributeInfo;
/*     */     
/* 123 */     if (tagExtraInfo != null) {
/* 124 */       tagExtraInfo.setTagInfo(this);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TagInfo(String tagName, String tagClassName, String bodycontent, String infoString, TagLibraryInfo taglib, TagExtraInfo tagExtraInfo, TagAttributeInfo[] attributeInfo, String displayName, String smallIcon, String largeIcon, TagVariableInfo[] tvi) {
/* 162 */     this.tagName = tagName;
/* 163 */     this.tagClassName = tagClassName;
/* 164 */     this.bodyContent = bodycontent;
/* 165 */     this.infoString = infoString;
/* 166 */     this.tagLibrary = taglib;
/* 167 */     this.tagExtraInfo = tagExtraInfo;
/* 168 */     this.attributeInfo = attributeInfo;
/* 169 */     this.displayName = displayName;
/* 170 */     this.smallIcon = smallIcon;
/* 171 */     this.largeIcon = largeIcon;
/* 172 */     this.tagVariableInfo = tvi;
/*     */     
/* 174 */     if (tagExtraInfo != null) {
/* 175 */       tagExtraInfo.setTagInfo(this);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getTagName() {
/* 185 */     return this.tagName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TagAttributeInfo[] getAttributes() {
/* 198 */     return this.attributeInfo;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public VariableInfo[] getVariableInfo(TagData data) {
/* 213 */     TagExtraInfo tei = getTagExtraInfo();
/* 214 */     if (tei == null) {
/* 215 */       return null;
/*     */     }
/* 217 */     return tei.getVariableInfo(data);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isValid(TagData data) {
/* 230 */     TagExtraInfo tei = getTagExtraInfo();
/* 231 */     if (tei == null) {
/* 232 */       return true;
/*     */     }
/* 234 */     return tei.isValid(data);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTagExtraInfo(TagExtraInfo tei) {
/* 244 */     this.tagExtraInfo = tei;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TagExtraInfo getTagExtraInfo() {
/* 254 */     return this.tagExtraInfo;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getTagClassName() {
/* 265 */     return this.tagClassName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getBodyContent() {
/* 276 */     return this.bodyContent;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getInfoString() {
/* 287 */     return this.infoString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTagLibrary(TagLibraryInfo tl) {
/* 307 */     this.tagLibrary = tl;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TagLibraryInfo getTagLibrary() {
/* 317 */     return this.tagLibrary;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDisplayName() {
/* 331 */     return this.displayName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getSmallIcon() {
/* 341 */     return this.smallIcon;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getLargeIcon() {
/* 351 */     return this.largeIcon;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TagVariableInfo[] getTagVariableInfos() {
/* 361 */     return this.tagVariableInfo;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 370 */     StringBuffer b = new StringBuffer();
/* 371 */     b.append("name = " + this.tagName + " ");
/* 372 */     b.append("class = " + this.tagClassName + " ");
/* 373 */     b.append("body = " + this.bodyContent + " ");
/* 374 */     b.append("info = " + this.infoString + " ");
/* 375 */     b.append("attributes = {\n");
/* 376 */     for (int i = 0; i < this.attributeInfo.length; i++)
/* 377 */       b.append("\t" + this.attributeInfo[i].toString()); 
/* 378 */     b.append("\n}\n");
/* 379 */     return b.toString();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/servlet.jar!/javax/servlet/jsp/tagext/TagInfo.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */