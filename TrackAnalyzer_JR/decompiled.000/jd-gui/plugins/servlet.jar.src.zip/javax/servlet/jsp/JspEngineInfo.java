package javax.servlet.jsp;

public abstract class JspEngineInfo {
  public abstract String getSpecificationVersion();
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/servlet.jar!/javax/servlet/jsp/JspEngineInfo.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */