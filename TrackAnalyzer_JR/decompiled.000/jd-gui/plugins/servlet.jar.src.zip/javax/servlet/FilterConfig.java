package javax.servlet;

import java.util.Enumeration;

public interface FilterConfig {
  String getFilterName();
  
  ServletContext getServletContext();
  
  String getInitParameter(String paramString);
  
  Enumeration getInitParameterNames();
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/servlet.jar!/javax/servlet/FilterConfig.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */