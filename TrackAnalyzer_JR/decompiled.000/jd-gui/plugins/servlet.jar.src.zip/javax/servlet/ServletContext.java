package javax.servlet;

import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Enumeration;
import java.util.Set;

public interface ServletContext {
  ServletContext getContext(String paramString);
  
  int getMajorVersion();
  
  int getMinorVersion();
  
  String getMimeType(String paramString);
  
  Set getResourcePaths(String paramString);
  
  URL getResource(String paramString) throws MalformedURLException;
  
  InputStream getResourceAsStream(String paramString);
  
  RequestDispatcher getRequestDispatcher(String paramString);
  
  RequestDispatcher getNamedDispatcher(String paramString);
  
  Servlet getServlet(String paramString) throws ServletException;
  
  Enumeration getServlets();
  
  Enumeration getServletNames();
  
  void log(String paramString);
  
  void log(Exception paramException, String paramString);
  
  void log(String paramString, Throwable paramThrowable);
  
  String getRealPath(String paramString);
  
  String getServerInfo();
  
  String getInitParameter(String paramString);
  
  Enumeration getInitParameterNames();
  
  Object getAttribute(String paramString);
  
  Enumeration getAttributeNames();
  
  void setAttribute(String paramString, Object paramObject);
  
  void removeAttribute(String paramString);
  
  String getServletContextName();
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/servlet.jar!/javax/servlet/ServletContext.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */