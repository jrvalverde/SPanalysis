package javax.servlet;

import java.util.EventListener;

public interface ServletContextListener extends EventListener {
  void contextInitialized(ServletContextEvent paramServletContextEvent);
  
  void contextDestroyed(ServletContextEvent paramServletContextEvent);
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/servlet.jar!/javax/servlet/ServletContextListener.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */