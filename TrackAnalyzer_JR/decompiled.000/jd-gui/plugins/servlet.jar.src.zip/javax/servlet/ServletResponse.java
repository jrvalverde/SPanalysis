package javax.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Locale;

public interface ServletResponse {
  String getCharacterEncoding();
  
  ServletOutputStream getOutputStream() throws IOException;
  
  PrintWriter getWriter() throws IOException;
  
  void setContentLength(int paramInt);
  
  void setContentType(String paramString);
  
  void setBufferSize(int paramInt);
  
  int getBufferSize();
  
  void flushBuffer() throws IOException;
  
  void resetBuffer();
  
  boolean isCommitted();
  
  void reset();
  
  void setLocale(Locale paramLocale);
  
  Locale getLocale();
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/servlet.jar!/javax/servlet/ServletResponse.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */