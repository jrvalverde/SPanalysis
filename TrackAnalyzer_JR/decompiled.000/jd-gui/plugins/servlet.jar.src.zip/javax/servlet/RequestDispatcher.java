package javax.servlet;

import java.io.IOException;

public interface RequestDispatcher {
  void forward(ServletRequest paramServletRequest, ServletResponse paramServletResponse) throws ServletException, IOException;
  
  void include(ServletRequest paramServletRequest, ServletResponse paramServletResponse) throws ServletException, IOException;
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/servlet.jar!/javax/servlet/RequestDispatcher.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */