package com.orsoncharts.demo;

import com.orsoncharts.Chart3D;
import com.orsoncharts.Chart3DFactory;
import com.orsoncharts.TitleAnchor;
import com.orsoncharts.axis.NumberAxis3D;
import com.orsoncharts.axis.StandardCategoryAxis3D;
import com.orsoncharts.data.DataUtils;
import com.orsoncharts.data.DefaultKeyedValues;
import com.orsoncharts.data.JSONUtils;
import com.orsoncharts.data.KeyedValues;
import com.orsoncharts.data.KeyedValues3D;
import com.orsoncharts.data.PieDataset3D;
import com.orsoncharts.data.StandardPieDataset3D;
import com.orsoncharts.data.category.CategoryDataset3D;
import com.orsoncharts.data.category.StandardCategoryDataset3D;
import com.orsoncharts.data.xyz.XYZDataset;
import com.orsoncharts.legend.LegendAnchor;
import com.orsoncharts.marker.CategoryMarker;
import com.orsoncharts.marker.RangeMarker;
import com.orsoncharts.marker.ValueMarker;
import com.orsoncharts.plot.CategoryPlot3D;
import com.orsoncharts.plot.XYZPlot;
import com.orsoncharts.renderer.xyz.ScatterXYZRenderer;
import com.orsoncharts.util.Orientation;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.jfree.graphics2d.svg.SVGGraphics2D;

public class SVGDemo1 {
  static String generateSVGForChart(Chart3D paramChart3D, int paramInt1, int paramInt2, String paramString) {
    SVGGraphics2D sVGGraphics2D = new SVGGraphics2D(paramInt1, paramInt2);
    sVGGraphics2D.setDefsKeyPrefix(paramString);
    paramChart3D.setElementHinting(true);
    paramChart3D.draw((Graphics2D)sVGGraphics2D, new Rectangle(paramInt1, paramInt2));
    return sVGGraphics2D.getSVGElement(paramChart3D.getID());
  }
  
  static PieDataset3D createPieChartDataset() {
    StandardPieDataset3D standardPieDataset3D = new StandardPieDataset3D();
    standardPieDataset3D.add("Milk Products", 11625.0D);
    standardPieDataset3D.add("Meat", 5114.0D);
    standardPieDataset3D.add("Wood/Logs", 3060.0D);
    standardPieDataset3D.add("Crude Oil", 2023.0D);
    standardPieDataset3D.add("Machinery", 1865.0D);
    standardPieDataset3D.add("Fruit", 1587.0D);
    standardPieDataset3D.add("Fish", 1367.0D);
    standardPieDataset3D.add("Wine", 1177.0D);
    standardPieDataset3D.add("Other", 18870.0D);
    return (PieDataset3D)standardPieDataset3D;
  }
  
  static Chart3D createPieChart(String paramString) {
    Chart3D chart3D = Chart3DFactory.createPieChart("New Zealand Exports 2012", "http://www.stats.govt.nz/browse_for_stats/snapshots-of-nz/nz-in-profile-2013.aspx", createPieChartDataset());
    chart3D.setID(paramString);
    chart3D.setTitleAnchor(TitleAnchor.TOP_LEFT);
    chart3D.setLegendPosition(LegendAnchor.BOTTOM_CENTER, Orientation.HORIZONTAL);
    return chart3D;
  }
  
  private static CategoryDataset3D createBarChartDataset() {
    StandardCategoryDataset3D standardCategoryDataset3D = new StandardCategoryDataset3D();
    DefaultKeyedValues defaultKeyedValues1 = new DefaultKeyedValues();
    defaultKeyedValues1.put("Q2/11", Double.valueOf(8.181D));
    defaultKeyedValues1.put("Q3/11", Double.valueOf(8.792D));
    defaultKeyedValues1.put("Q4/11", Double.valueOf(9.039D));
    defaultKeyedValues1.put("Q1/12", Double.valueOf(10.916D));
    defaultKeyedValues1.put("Q2/12", Double.valueOf(8.181D));
    defaultKeyedValues1.put("Q3/12", Double.valueOf(9.094D));
    defaultKeyedValues1.put("Q4/12", Double.valueOf(8.958D));
    defaultKeyedValues1.put("Q1/13", Double.valueOf(10.947D));
    defaultKeyedValues1.put("Q2/13", Double.valueOf(8.372D));
    defaultKeyedValues1.put("Q3/13", Double.valueOf(9.275D));
    standardCategoryDataset3D.addSeriesAsRow("Oracle", (KeyedValues)defaultKeyedValues1);
    DefaultKeyedValues defaultKeyedValues2 = new DefaultKeyedValues();
    defaultKeyedValues2.put("Q2/11", Double.valueOf(9.03D));
    defaultKeyedValues2.put("Q3/11", Double.valueOf(9.72D));
    defaultKeyedValues2.put("Q4/11", Double.valueOf(10.58D));
    defaultKeyedValues2.put("Q1/12", Double.valueOf(10.65D));
    defaultKeyedValues2.put("Q2/12", Double.valueOf(12.214D));
    defaultKeyedValues2.put("Q3/12", Double.valueOf(14.101D));
    defaultKeyedValues2.put("Q4/12", Double.valueOf(14.419D));
    defaultKeyedValues2.put("Q1/13", Double.valueOf(13.969D));
    defaultKeyedValues2.put("Q2/13", Double.valueOf(14.105D));
    defaultKeyedValues2.put("Q3/13", Double.valueOf(14.893D));
    defaultKeyedValues2.put("Q4/13", Double.valueOf(16.858D));
    standardCategoryDataset3D.addSeriesAsRow("Google", (KeyedValues)defaultKeyedValues2);
    DefaultKeyedValues defaultKeyedValues3 = new DefaultKeyedValues();
    defaultKeyedValues3.put("Q2/11", Double.valueOf(17.37D));
    defaultKeyedValues3.put("Q3/11", Double.valueOf(17.37D));
    defaultKeyedValues3.put("Q4/11", Double.valueOf(20.89D));
    defaultKeyedValues3.put("Q1/12", Double.valueOf(17.41D));
    defaultKeyedValues3.put("Q2/12", Double.valueOf(18.06D));
    defaultKeyedValues3.put("Q3/12", Double.valueOf(16.008D));
    defaultKeyedValues3.put("Q4/12", Double.valueOf(21.456D));
    defaultKeyedValues3.put("Q1/13", Double.valueOf(20.489D));
    defaultKeyedValues3.put("Q2/13", Double.valueOf(19.896D));
    defaultKeyedValues3.put("Q3/13", Double.valueOf(18.529D));
    defaultKeyedValues3.put("Q4/13", Double.valueOf(24.519D));
    standardCategoryDataset3D.addSeriesAsRow("Microsoft", (KeyedValues)defaultKeyedValues3);
    DefaultKeyedValues defaultKeyedValues4 = new DefaultKeyedValues();
    defaultKeyedValues4.put("Q2/11", Double.valueOf(28.57D));
    defaultKeyedValues4.put("Q3/11", Double.valueOf(28.27D));
    defaultKeyedValues4.put("Q4/11", Double.valueOf(46.33D));
    defaultKeyedValues4.put("Q1/12", Double.valueOf(39.2D));
    defaultKeyedValues4.put("Q2/12", Double.valueOf(35.0D));
    defaultKeyedValues4.put("Q3/12", Double.valueOf(36.0D));
    defaultKeyedValues4.put("Q4/12", Double.valueOf(54.5D));
    defaultKeyedValues4.put("Q1/13", Double.valueOf(43.6D));
    defaultKeyedValues4.put("Q2/13", Double.valueOf(35.323D));
    defaultKeyedValues4.put("Q3/13", Double.valueOf(37.5D));
    defaultKeyedValues4.put("Q4/13", Double.valueOf(57.594D));
    standardCategoryDataset3D.addSeriesAsRow("Apple", (KeyedValues)defaultKeyedValues4);
    return (CategoryDataset3D)standardCategoryDataset3D;
  }
  
  static Chart3D createBarChart(String paramString) {
    CategoryDataset3D categoryDataset3D = createBarChartDataset();
    Chart3D chart3D = Chart3DFactory.createBarChart("Quarterly Revenues", "For some large IT companies", categoryDataset3D, null, "Quarter", "$billion Revenues");
    chart3D.setID(paramString);
    chart3D.setChartBoxColor(new Color(255, 255, 255, 127));
    chart3D.setLegendAnchor(LegendAnchor.BOTTOM_RIGHT);
    CategoryPlot3D categoryPlot3D = (CategoryPlot3D)chart3D.getPlot();
    categoryPlot3D.setGridlinePaintForValues(Color.BLACK);
    StandardCategoryAxis3D standardCategoryAxis3D1 = (StandardCategoryAxis3D)categoryPlot3D.getRowAxis();
    CategoryMarker categoryMarker1 = new CategoryMarker("Apple");
    standardCategoryAxis3D1.setMarker("Apple", categoryMarker1);
    StandardCategoryAxis3D standardCategoryAxis3D2 = (StandardCategoryAxis3D)categoryPlot3D.getColumnAxis();
    CategoryMarker categoryMarker2 = new CategoryMarker("Q4/12");
    standardCategoryAxis3D2.setMarker("Q4/12", categoryMarker2);
    chart3D.getViewPoint().setRho(1.3D * chart3D.getViewPoint().getRho());
    return chart3D;
  }
  
  private static XYZDataset createScatterDataset(Comparable<?> paramComparable1, Comparable<?> paramComparable2, Comparable<?> paramComparable3) {
    KeyedValues3D keyedValues3D;
    InputStreamReader inputStreamReader = new InputStreamReader(SVGDemo1.class.getResourceAsStream("iris.txt"));
    try {
      keyedValues3D = JSONUtils.readKeyedValues3D(inputStreamReader);
    } catch (IOException iOException) {
      throw new RuntimeException(iOException);
    } 
    return DataUtils.extractXYZDatasetFromColumns(keyedValues3D, paramComparable1, paramComparable2, paramComparable3);
  }
  
  static Chart3D createScatterChart(String paramString) {
    XYZDataset xYZDataset = createScatterDataset("sepal length", "sepal width", "petal length");
    Chart3D chart3D = Chart3DFactory.createScatterChart("Iris Dataset", null, xYZDataset, "Sepal Length", "Sepal Width", "Petal Length");
    chart3D.setID(paramString);
    chart3D.setLegendAnchor(LegendAnchor.BOTTOM_LEFT);
    chart3D.setLegendOrientation(Orientation.VERTICAL);
    XYZPlot xYZPlot = (XYZPlot)chart3D.getPlot();
    NumberAxis3D numberAxis3D = (NumberAxis3D)xYZPlot.getYAxis();
    RangeMarker rangeMarker = new RangeMarker(3.5D, 4.0D);
    numberAxis3D.setMarker("M1", (ValueMarker)rangeMarker);
    ScatterXYZRenderer scatterXYZRenderer = (ScatterXYZRenderer)xYZPlot.getRenderer();
    scatterXYZRenderer.setSize(0.15D);
    chart3D.getViewPoint().panLeftRight(0.2617993877991494D);
    chart3D.getViewPoint().roll(0.2617993877991494D);
    chart3D.getViewPoint().setRho(1.6D * chart3D.getViewPoint().getRho());
    return chart3D;
  }
  
  public static void main(String[] paramArrayOfString) throws Exception {
    BufferedWriter bufferedWriter = null;
    try {
      FileOutputStream fileOutputStream = new FileOutputStream("SVGDemo1.html");
      OutputStreamWriter outputStreamWriter = new OutputStreamWriter(fileOutputStream, "UTF-8");
      bufferedWriter = new BufferedWriter(outputStreamWriter);
      bufferedWriter.write("<!DOCTYPE html>\n");
      bufferedWriter.write("<html>\n");
      bufferedWriter.write("<head>\n");
      bufferedWriter.write("<title>SVG Demo 1</title>\n");
      bufferedWriter.write("<meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\" />\n");
      bufferedWriter.write("<script src=\"lib/opentip-native.js\"></script>");
      bufferedWriter.write("<link href=\"css/opentip.css\" rel=\"stylesheet\" type=\"text/css\" />");
      bufferedWriter.write("<script src=\"lib/orsoncharts.js\"></script>");
      bufferedWriter.write("</head>\n");
      bufferedWriter.write("<body>\n");
      bufferedWriter.write("<h1>SVG Chart Demo</h1>\n");
      bufferedWriter.write("<p>Click on an item in the chart or just hover and look at the tooltip (the ");
      bufferedWriter.write("reference is a string in JSON format that should contain enough information to ");
      bufferedWriter.write("identify the chart element):</p>\n");
      bufferedWriter.write("  <script type=\"application/javascript\">\n");
      bufferedWriter.write("    function pieChartData() {\n");
      bufferedWriter.write("      return " + JSONUtils.writeKeyedValues((KeyedValues)createPieChartDataset()) + "\n");
      bufferedWriter.write("    }\n");
      bufferedWriter.write("  </script>\n");
      bufferedWriter.write("  <script type=\"application/javascript\">\n");
      bufferedWriter.write("    function barChartData() {\n");
      bufferedWriter.write("      return " + JSONUtils.writeKeyedValues3D((KeyedValues3D)createBarChartDataset()) + "\n");
      bufferedWriter.write("    }\n");
      bufferedWriter.write("  </script>\n");
      bufferedWriter.write("  <script type=\"application/javascript\">\n");
      bufferedWriter.write("    function scatterChartData() {\n");
      XYZDataset xYZDataset = createScatterDataset("sepal length", "sepal width", "petal length");
      bufferedWriter.write("      return " + JSONUtils.writeXYZDataset(xYZDataset) + "\n");
      bufferedWriter.write("    }\n");
      bufferedWriter.write("  </script>\n");
      bufferedWriter.write("  <script type=\"application/javascript\">\n");
      bufferedWriter.write("    // wait until all the resources are loaded\n");
      bufferedWriter.write("    window.addEventListener(\"load\", initialise, false);\n");
      bufferedWriter.write("    function initialise() {\n");
      bufferedWriter.write("      orsoncharts.pieDataset = new orsoncharts.KeyedValuesDataset();\n");
      bufferedWriter.write("      orsoncharts.pieDataset.data = pieChartData();\n");
      bufferedWriter.write("      orsoncharts.pieLabelGenerator = new orsoncharts.KeyedValueLabels();\n");
      bufferedWriter.write("      orsoncharts.pieLabelGenerator.valueDP = 0;\n");
      bufferedWriter.write("      orsoncharts.pieLabelGenerator.format = \"{K} = NZ${V} million\";\n");
      bufferedWriter.write("      orsoncharts.barDataset = new orsoncharts.KeyedValues3DDataset();\n");
      bufferedWriter.write("      orsoncharts.barDataset.data = barChartData();\n");
      bufferedWriter.write("      orsoncharts.barLabelGenerator = new orsoncharts.KeyedValue3DLabels();\n");
      bufferedWriter.write("      orsoncharts.barLabelGenerator.format = \"{R}, {C} = US${V} billion\";\n");
      bufferedWriter.write("      orsoncharts.scatterDataset = new orsoncharts.XYZDataset();\n");
      bufferedWriter.write("      orsoncharts.scatterDataset.data.series = scatterChartData();\n");
      bufferedWriter.write("      orsoncharts.scatterLabelGenerator = new orsoncharts.XYZLabels();\n");
      bufferedWriter.write("      orsoncharts.scatterLabelGenerator.format = \"{S} = ({X}, {Y}, {Z})\";\n");
      bufferedWriter.write("      var pieSVG = document.getElementById(\"PieChart1\");\n");
      bufferedWriter.write("      pieSVG.onmouseover = handleMouseOver;\n");
      bufferedWriter.write("      pieSVG.onclick = handleClick;\n");
      bufferedWriter.write("      var barSVG = document.getElementById(\"BarChart1\");\n");
      bufferedWriter.write("      barSVG.onmouseover = handleMouseOver;\n");
      bufferedWriter.write("      barSVG.onclick = handleClick;\n");
      bufferedWriter.write("      var scatterSVG = document.getElementById(\"ScatterChart1\");\n");
      bufferedWriter.write("      scatterSVG.onmouseover = handleMouseOver;\n");
      bufferedWriter.write("      scatterSVG.onclick = handleClick;\n");
      bufferedWriter.write("    }\n");
      bufferedWriter.write("    function handleClick(evt) {\n");
      bufferedWriter.write("      var element = evt.target;\n");
      bufferedWriter.write("      var ref = orsoncharts.Utils.findChartRef(element);\n");
      bufferedWriter.write("      var chartId = orsoncharts.Utils.findChartId(element);\n");
      bufferedWriter.write("      alert('You clicked on the item ' + ref + ' for the chart [' + chartId + ']');\n");
      bufferedWriter.write("    }\n");
      bufferedWriter.write("    function handleMouseOver(evt) {\n");
      bufferedWriter.write("      var element = evt.target;\n");
      bufferedWriter.write("      var ref = orsoncharts.Utils.findChartRef(element);\n");
      bufferedWriter.write("      var content;\n");
      bufferedWriter.write("      var chartId = orsoncharts.Utils.findChartId(element);\n");
      bufferedWriter.write("      if (ref != null && ref != 'ORSON_CHART_TOP_LEVEL') {\n");
      bufferedWriter.write("        var refObj = JSON.parse(ref);\n");
      bufferedWriter.write("        if (Opentip.tips.length < 1) {\n");
      bufferedWriter.write("          myOpentip = new Opentip(element, \"content\");\n");
      bufferedWriter.write("        } else {\n");
      bufferedWriter.write("          myOpentip = Opentip.tips[0];\n");
      bufferedWriter.write("        }\n");
      bufferedWriter.write("        myOpentip.target = element;\n");
      bufferedWriter.write("        if (chartId == \"PieChart1\") {\n");
      bufferedWriter.write("          if (refObj.hasOwnProperty(\"key\")) {\n");
      bufferedWriter.write("             var itemIndex = orsoncharts.pieDataset.indexOf(refObj.key);\n");
      bufferedWriter.write("             content = orsoncharts.pieLabelGenerator.itemLabel(orsoncharts.pieDataset, itemIndex);\n");
      bufferedWriter.write("          } else { content = ref; }\n");
      bufferedWriter.write("        } else if (chartId == \"BarChart1\") {\n");
      bufferedWriter.write("          if (!refObj.hasOwnProperty(\"type\")) {\n");
      bufferedWriter.write("            var seriesIndex = orsoncharts.barDataset.seriesIndex(refObj.seriesKey);\n");
      bufferedWriter.write("            var rowIndex = orsoncharts.barDataset.rowIndex(refObj.rowKey);\n");
      bufferedWriter.write("            var columnIndex = orsoncharts.barDataset.columnIndex(refObj.columnKey);\n");
      bufferedWriter.write("            content = orsoncharts.barLabelGenerator.itemLabel(orsoncharts.barDataset, seriesIndex, rowIndex, columnIndex);\n");
      bufferedWriter.write("          } else {\n");
      bufferedWriter.write("          content = ref + \" for bar chart.\";\n");
      bufferedWriter.write("          }\n");
      bufferedWriter.write("        } else if (chartId == \"ScatterChart1\") {\n");
      bufferedWriter.write("          if (!refObj.hasOwnProperty(\"type\")) {\n");
      bufferedWriter.write("            content = orsoncharts.scatterLabelGenerator.itemLabel(orsoncharts.scatterDataset, refObj.seriesKey, refObj.itemIndex);\n");
      bufferedWriter.write("          } else {\n");
      bufferedWriter.write("            content = ref + \" for scatter plot.\";\n");
      bufferedWriter.write("          }\n");
      bufferedWriter.write("        }\n");
      bufferedWriter.write("        myOpentip.setContent(content);\n");
      bufferedWriter.write("        myOpentip.reposition();\n");
      bufferedWriter.write("        myOpentip.show();\n");
      bufferedWriter.write("      }\n");
      bufferedWriter.write("    }\n");
      bufferedWriter.write("</script>\n");
      bufferedWriter.write("<p>\n");
      Chart3D chart3D1 = createPieChart("PieChart1");
      bufferedWriter.write(generateSVGForChart(chart3D1, 600, 370, "defs1_") + "\n");
      bufferedWriter.write("</p>\n");
      bufferedWriter.write("<p>\n");
      Chart3D chart3D2 = createBarChart("BarChart1");
      bufferedWriter.write(generateSVGForChart(chart3D2, 600, 370, "defs2_") + "\n");
      bufferedWriter.write("</p>\n");
      bufferedWriter.write("<p>\n");
      Chart3D chart3D3 = createScatterChart("ScatterChart1");
      bufferedWriter.write(generateSVGForChart(chart3D3, 600, 370, "defs3_") + "\n");
      bufferedWriter.write("</p>\n");
      bufferedWriter.write("</body>\n");
      bufferedWriter.write("</html>\n");
      bufferedWriter.flush();
    } finally {
      try {
        if (bufferedWriter != null)
          bufferedWriter.close(); 
      } catch (IOException iOException) {
        Logger.getLogger(SVGDemo1.class.getName()).log(Level.SEVERE, (String)null, iOException);
      } 
    } 
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/com/orsoncharts/demo/SVGDemo1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */