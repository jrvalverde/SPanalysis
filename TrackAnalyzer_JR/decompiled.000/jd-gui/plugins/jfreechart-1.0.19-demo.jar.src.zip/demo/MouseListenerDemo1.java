package demo;

import java.awt.Container;
import java.awt.Dimension;
import java.awt.Window;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartMouseEvent;
import org.jfree.chart.ChartMouseListener;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.entity.ChartEntity;
import org.jfree.data.general.DefaultPieDataset;
import org.jfree.data.general.PieDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

public class MouseListenerDemo1 extends ApplicationFrame implements ChartMouseListener {
  public MouseListenerDemo1(String paramString) {
    super(paramString);
    DefaultPieDataset defaultPieDataset = new DefaultPieDataset();
    defaultPieDataset.setValue("Java", new Double(43.2D));
    defaultPieDataset.setValue("Visual Basic", new Double(0.0D));
    defaultPieDataset.setValue("C/C++", new Double(17.5D));
    JFreeChart jFreeChart = ChartFactory.createPieChart("MouseListenerDemo1", (PieDataset)defaultPieDataset, true, true, false);
    ChartPanel chartPanel = new ChartPanel(jFreeChart, false, false, false, false, false);
    chartPanel.addChartMouseListener(this);
    chartPanel.setPreferredSize(new Dimension(500, 270));
    setContentPane((Container)chartPanel);
  }
  
  public void chartMouseClicked(ChartMouseEvent paramChartMouseEvent) {
    ChartEntity chartEntity = paramChartMouseEvent.getEntity();
    if (chartEntity != null) {
      System.out.println("Mouse clicked: " + chartEntity.toString());
    } else {
      System.out.println("Mouse clicked: null entity.");
    } 
  }
  
  public void chartMouseMoved(ChartMouseEvent paramChartMouseEvent) {
    int i = paramChartMouseEvent.getTrigger().getX();
    int j = paramChartMouseEvent.getTrigger().getY();
    ChartEntity chartEntity = paramChartMouseEvent.getEntity();
    if (chartEntity != null) {
      System.out.println("Mouse moved: " + i + ", " + j + ": " + chartEntity.toString());
    } else {
      System.out.println("Mouse moved: " + i + ", " + j + ": null entity.");
    } 
  }
  
  public static void main(String[] paramArrayOfString) {
    MouseListenerDemo1 mouseListenerDemo1 = new MouseListenerDemo1("JFreeChart: MouseListenerDemo1.java");
    mouseListenerDemo1.pack();
    RefineryUtilities.centerFrameOnScreen((Window)mouseListenerDemo1);
    mouseListenerDemo1.setVisible(true);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/MouseListenerDemo1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */