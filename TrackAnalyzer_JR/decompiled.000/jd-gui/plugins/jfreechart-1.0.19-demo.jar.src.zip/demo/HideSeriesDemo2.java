package demo;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Window;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JCheckBox;
import javax.swing.JPanel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.renderer.category.CategoryItemRenderer;
import org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.statistics.DefaultStatisticalCategoryDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

public class HideSeriesDemo2 extends ApplicationFrame {
  public HideSeriesDemo2(String paramString) {
    super(paramString);
    setContentPane(new MyDemoPanel());
  }
  
  public static JPanel createDemoPanel() {
    return new MyDemoPanel();
  }
  
  public static void main(String[] paramArrayOfString) {
    HideSeriesDemo2 hideSeriesDemo2 = new HideSeriesDemo2("JFreeChart: HideSeriesDemo2.java");
    hideSeriesDemo2.pack();
    RefineryUtilities.centerFrameOnScreen((Window)hideSeriesDemo2);
    hideSeriesDemo2.setVisible(true);
  }
  
  static class MyDemoPanel extends DemoPanel implements ActionListener {
    private CategoryItemRenderer renderer;
    
    public MyDemoPanel() {
      super(new BorderLayout());
      CategoryDataset categoryDataset = createSampleDataset();
      JFreeChart jFreeChart = createChart(categoryDataset);
      addChart(jFreeChart);
      ChartPanel chartPanel = new ChartPanel(jFreeChart);
      JPanel jPanel = new JPanel();
      JCheckBox jCheckBox1 = new JCheckBox("Series 1");
      jCheckBox1.setActionCommand("S1");
      jCheckBox1.addActionListener(this);
      jCheckBox1.setSelected(true);
      JCheckBox jCheckBox2 = new JCheckBox("Series 2");
      jCheckBox2.setActionCommand("S2");
      jCheckBox2.addActionListener(this);
      jCheckBox2.setSelected(true);
      JCheckBox jCheckBox3 = new JCheckBox("Series 3");
      jCheckBox3.setActionCommand("S3");
      jCheckBox3.addActionListener(this);
      jCheckBox3.setSelected(true);
      jPanel.add(jCheckBox1);
      jPanel.add(jCheckBox2);
      jPanel.add(jCheckBox3);
      add((Component)chartPanel);
      add(jPanel, "South");
      chartPanel.setPreferredSize(new Dimension(500, 270));
    }
    
    private CategoryDataset createSampleDataset() {
      DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset = new DefaultStatisticalCategoryDataset();
      defaultStatisticalCategoryDataset.add(10.0D, 2.4D, "Row 1", "Column 1");
      defaultStatisticalCategoryDataset.add(15.0D, 4.4D, "Row 1", "Column 2");
      defaultStatisticalCategoryDataset.add(13.0D, 2.1D, "Row 1", "Column 3");
      defaultStatisticalCategoryDataset.add(7.0D, 1.3D, "Row 1", "Column 4");
      defaultStatisticalCategoryDataset.add(22.0D, 2.4D, "Row 2", "Column 1");
      defaultStatisticalCategoryDataset.add(18.0D, 4.4D, "Row 2", "Column 2");
      defaultStatisticalCategoryDataset.add(28.0D, 2.1D, "Row 2", "Column 3");
      defaultStatisticalCategoryDataset.add(7.0D, 1.3D, "Row 2", "Column 4");
      defaultStatisticalCategoryDataset.add(2.0D, 2.4D, "Row 3", "Column 1");
      defaultStatisticalCategoryDataset.add(8.0D, 4.4D, "Row 3", "Column 2");
      defaultStatisticalCategoryDataset.add(8.0D, 2.1D, "Row 3", "Column 3");
      defaultStatisticalCategoryDataset.add(7.0D, 1.3D, "Row 3", "Column 4");
      return (CategoryDataset)defaultStatisticalCategoryDataset;
    }
    
    private JFreeChart createChart(CategoryDataset param1CategoryDataset) {
      JFreeChart jFreeChart = ChartFactory.createAreaChart("Hide Series Demo 2", "Category", "Value", param1CategoryDataset, PlotOrientation.VERTICAL, true, true, false);
      CategoryPlot categoryPlot = (CategoryPlot)jFreeChart.getPlot();
      categoryPlot.setRenderer((CategoryItemRenderer)new StatisticalLineAndShapeRenderer());
      this.renderer = categoryPlot.getRenderer(0);
      return jFreeChart;
    }
    
    public void actionPerformed(ActionEvent param1ActionEvent) {
      byte b = -1;
      if (param1ActionEvent.getActionCommand().equals("S1")) {
        b = 0;
      } else if (param1ActionEvent.getActionCommand().equals("S2")) {
        b = 1;
      } else if (param1ActionEvent.getActionCommand().equals("S3")) {
        b = 2;
      } 
      if (b >= 0) {
        boolean bool = this.renderer.getItemVisible(b, 0);
        this.renderer.setSeriesVisible(b, Boolean.valueOf(!bool));
      } 
    }
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/HideSeriesDemo2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */