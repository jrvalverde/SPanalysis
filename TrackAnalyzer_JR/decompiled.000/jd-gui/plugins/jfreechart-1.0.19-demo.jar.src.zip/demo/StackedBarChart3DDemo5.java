package demo;

import java.awt.Component;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.Window;
import javax.swing.JPanel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

public class StackedBarChart3DDemo5 extends ApplicationFrame {
  private static int CHART_COUNT = 4;
  
  public StackedBarChart3DDemo5(String paramString) {
    super(paramString);
    setContentPane(createDemoPanel());
  }
  
  private static CategoryDataset createDataset(int paramInt) {
    DefaultCategoryDataset defaultCategoryDataset = new DefaultCategoryDataset();
    defaultCategoryDataset.addValue(1.0D, "Series 1", "Category 1");
    defaultCategoryDataset.addValue(2.0D, "Series 1", "Category 2");
    defaultCategoryDataset.addValue(1.5D, "Series 1", "Category 3");
    defaultCategoryDataset.addValue(1.5D, "Series 1", "Category 4");
    defaultCategoryDataset.addValue(-1.0D, "Series 2", "Category 1");
    defaultCategoryDataset.addValue(-1.9D, "Series 2", "Category 2");
    defaultCategoryDataset.addValue(-1.5D, "Series 2", "Category 3");
    defaultCategoryDataset.addValue(-1.5D, "Series 2", "Category 4");
    defaultCategoryDataset.addValue(1.0D, "Series 3", "Category 1");
    defaultCategoryDataset.addValue(1.9D, "Series 3", "Category 2");
    defaultCategoryDataset.addValue(1.5D, "Series 3", "Category 3");
    defaultCategoryDataset.addValue(1.5D, "Series 3", "Category 4");
    return (CategoryDataset)defaultCategoryDataset;
  }
  
  private static JFreeChart createChart(int paramInt, CategoryDataset paramCategoryDataset) {
    JFreeChart jFreeChart = ChartFactory.createStackedBarChart3D("Chart " + (paramInt + 1), "Category", "Value", paramCategoryDataset, PlotOrientation.VERTICAL, false, false, false);
    CategoryPlot categoryPlot = (CategoryPlot)jFreeChart.getPlot();
    categoryPlot.getDomainAxis().setMaximumCategoryLabelLines(2);
    ValueAxis valueAxis = categoryPlot.getRangeAxis();
    valueAxis.setStandardTickUnits(NumberAxis.createIntegerTickUnits());
    return jFreeChart;
  }
  
  public static JPanel createDemoPanel() {
    return new MyDemoPanel();
  }
  
  public static void main(String[] paramArrayOfString) {
    StackedBarChart3DDemo5 stackedBarChart3DDemo5 = new StackedBarChart3DDemo5("JFreeChart - Stacked Bar Chart 3D Demo 5");
    stackedBarChart3DDemo5.pack();
    RefineryUtilities.centerFrameOnScreen((Window)stackedBarChart3DDemo5);
    stackedBarChart3DDemo5.setVisible(true);
  }
  
  static class MyDemoPanel extends DemoPanel {
    private CategoryDataset[] datasets = new CategoryDataset[StackedBarChart3DDemo5.CHART_COUNT];
    
    private JFreeChart[] charts = new JFreeChart[StackedBarChart3DDemo5.CHART_COUNT];
    
    private ChartPanel[] panels = new ChartPanel[StackedBarChart3DDemo5.CHART_COUNT];
    
    public MyDemoPanel() {
      super(new GridLayout(2, 2));
      for (byte b = 0; b < StackedBarChart3DDemo5.CHART_COUNT; b++) {
        this.datasets[b] = StackedBarChart3DDemo5.createDataset(b);
        this.charts[b] = StackedBarChart3DDemo5.createChart(b, this.datasets[b]);
        addChart(this.charts[b]);
        this.panels[b] = new ChartPanel(this.charts[b]);
      } 
      CategoryPlot categoryPlot1 = (CategoryPlot)this.charts[1].getPlot();
      CategoryPlot categoryPlot2 = (CategoryPlot)this.charts[2].getPlot();
      CategoryPlot categoryPlot3 = (CategoryPlot)this.charts[3].getPlot();
      categoryPlot1.getRangeAxis().setInverted(true);
      categoryPlot3.getRangeAxis().setInverted(true);
      categoryPlot2.setOrientation(PlotOrientation.HORIZONTAL);
      categoryPlot3.setOrientation(PlotOrientation.HORIZONTAL);
      add((Component)this.panels[0]);
      add((Component)this.panels[1]);
      add((Component)this.panels[2]);
      add((Component)this.panels[3]);
      setPreferredSize(new Dimension(800, 600));
    }
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/StackedBarChart3DDemo5.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */