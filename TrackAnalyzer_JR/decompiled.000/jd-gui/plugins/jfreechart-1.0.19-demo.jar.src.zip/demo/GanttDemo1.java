package demo;

import java.awt.Dimension;
import java.awt.Window;
import java.util.Calendar;
import java.util.Date;
import javax.swing.JPanel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.renderer.category.GanttRenderer;
import org.jfree.data.category.IntervalCategoryDataset;
import org.jfree.data.gantt.Task;
import org.jfree.data.gantt.TaskSeries;
import org.jfree.data.gantt.TaskSeriesCollection;
import org.jfree.data.time.SimpleTimePeriod;
import org.jfree.data.time.TimePeriod;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

public class GanttDemo1 extends ApplicationFrame {
  public GanttDemo1(String paramString) {
    super(paramString);
    JPanel jPanel = createDemoPanel();
    jPanel.setPreferredSize(new Dimension(500, 270));
    setContentPane(jPanel);
  }
  
  public static IntervalCategoryDataset createDataset() {
    TaskSeries taskSeries1 = new TaskSeries("Scheduled");
    taskSeries1.add(new Task("Write Proposal", (TimePeriod)new SimpleTimePeriod(date(1, 3, 2001), date(5, 3, 2001))));
    taskSeries1.add(new Task("Obtain Approval", (TimePeriod)new SimpleTimePeriod(date(9, 3, 2001), date(9, 3, 2001))));
    taskSeries1.add(new Task("Requirements Analysis", (TimePeriod)new SimpleTimePeriod(date(10, 3, 2001), date(5, 4, 2001))));
    taskSeries1.add(new Task("Design Phase", (TimePeriod)new SimpleTimePeriod(date(6, 4, 2001), date(30, 4, 2001))));
    taskSeries1.add(new Task("Design Signoff", (TimePeriod)new SimpleTimePeriod(date(2, 5, 2001), date(2, 5, 2001))));
    taskSeries1.add(new Task("Alpha Implementation", (TimePeriod)new SimpleTimePeriod(date(3, 5, 2001), date(31, 6, 2001))));
    taskSeries1.add(new Task("Design Review", (TimePeriod)new SimpleTimePeriod(date(1, 7, 2001), date(8, 7, 2001))));
    taskSeries1.add(new Task("Revised Design Signoff", (TimePeriod)new SimpleTimePeriod(date(10, 7, 2001), date(10, 7, 2001))));
    taskSeries1.add(new Task("Beta Implementation", (TimePeriod)new SimpleTimePeriod(date(12, 7, 2001), date(12, 8, 2001))));
    taskSeries1.add(new Task("Testing", (TimePeriod)new SimpleTimePeriod(date(13, 8, 2001), date(31, 9, 2001))));
    taskSeries1.add(new Task("Final Implementation", (TimePeriod)new SimpleTimePeriod(date(1, 10, 2001), date(15, 10, 2001))));
    taskSeries1.add(new Task("Signoff", (TimePeriod)new SimpleTimePeriod(date(28, 10, 2001), date(30, 10, 2001))));
    TaskSeries taskSeries2 = new TaskSeries("Actual");
    taskSeries2.add(new Task("Write Proposal", (TimePeriod)new SimpleTimePeriod(date(1, 3, 2001), date(5, 3, 2001))));
    taskSeries2.add(new Task("Obtain Approval", (TimePeriod)new SimpleTimePeriod(date(9, 3, 2001), date(9, 3, 2001))));
    taskSeries2.add(new Task("Requirements Analysis", (TimePeriod)new SimpleTimePeriod(date(10, 3, 2001), date(15, 4, 2001))));
    taskSeries2.add(new Task("Design Phase", (TimePeriod)new SimpleTimePeriod(date(15, 4, 2001), date(17, 5, 2001))));
    taskSeries2.add(new Task("Design Signoff", (TimePeriod)new SimpleTimePeriod(date(30, 5, 2001), date(30, 5, 2001))));
    taskSeries2.add(new Task("Alpha Implementation", (TimePeriod)new SimpleTimePeriod(date(1, 6, 2001), date(12, 8, 2001))));
    taskSeries2.add(new Task("Design Review", (TimePeriod)new SimpleTimePeriod(date(12, 8, 2001), date(22, 8, 2001))));
    taskSeries2.add(new Task("Revised Design Signoff", (TimePeriod)new SimpleTimePeriod(date(25, 8, 2001), date(27, 8, 2001))));
    taskSeries2.add(new Task("Beta Implementation", (TimePeriod)new SimpleTimePeriod(date(27, 8, 2001), date(30, 9, 2001))));
    taskSeries2.add(new Task("Testing", (TimePeriod)new SimpleTimePeriod(date(31, 9, 2001), date(17, 10, 2001))));
    taskSeries2.add(new Task("Final Implementation", (TimePeriod)new SimpleTimePeriod(date(18, 10, 2001), date(5, 11, 2001))));
    taskSeries2.add(new Task("Signoff", (TimePeriod)new SimpleTimePeriod(date(10, 11, 2001), date(11, 11, 2001))));
    TaskSeriesCollection taskSeriesCollection = new TaskSeriesCollection();
    taskSeriesCollection.add(taskSeries1);
    taskSeriesCollection.add(taskSeries2);
    return (IntervalCategoryDataset)taskSeriesCollection;
  }
  
  private static Date date(int paramInt1, int paramInt2, int paramInt3) {
    Calendar calendar = Calendar.getInstance();
    calendar.set(paramInt3, paramInt2, paramInt1);
    return calendar.getTime();
  }
  
  private static JFreeChart createChart(IntervalCategoryDataset paramIntervalCategoryDataset) {
    JFreeChart jFreeChart = ChartFactory.createGanttChart("Gantt Chart Demo", "Task", "Date", paramIntervalCategoryDataset, true, true, false);
    CategoryPlot categoryPlot = (CategoryPlot)jFreeChart.getPlot();
    categoryPlot.setRangePannable(true);
    categoryPlot.getDomainAxis().setMaximumCategoryLabelWidthRatio(10.0F);
    categoryPlot.setRangeCrosshairVisible(true);
    GanttRenderer ganttRenderer = (GanttRenderer)categoryPlot.getRenderer();
    ganttRenderer.setDrawBarOutline(false);
    return jFreeChart;
  }
  
  public static JPanel createDemoPanel() {
    JFreeChart jFreeChart = createChart(createDataset());
    ChartPanel chartPanel = new ChartPanel(jFreeChart);
    chartPanel.setMouseWheelEnabled(true);
    return (JPanel)chartPanel;
  }
  
  public static void main(String[] paramArrayOfString) {
    GanttDemo1 ganttDemo1 = new GanttDemo1("JFreeChart: GanttDemo1.java");
    ganttDemo1.pack();
    RefineryUtilities.centerFrameOnScreen((Window)ganttDemo1);
    ganttDemo1.setVisible(true);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/GanttDemo1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */