package demo;

import java.awt.BasicStroke;
import java.awt.Dimension;
import java.awt.Polygon;
import java.awt.Shape;
import java.awt.Window;
import java.awt.geom.Rectangle2D;
import javax.swing.JPanel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.labels.CategoryItemLabelGenerator;
import org.jfree.chart.labels.StandardCategoryItemLabelGenerator;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.DefaultDrawingSupplier;
import org.jfree.chart.plot.DrawingSupplier;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.renderer.category.LineAndShapeRenderer;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

public class LineChartDemo5 extends ApplicationFrame {
  public LineChartDemo5(String paramString) {
    super(paramString);
    JPanel jPanel = createDemoPanel();
    jPanel.setPreferredSize(new Dimension(500, 270));
    setContentPane(jPanel);
  }
  
  private static CategoryDataset createDataset() {
    String str1 = "First";
    String str2 = "Second";
    String str3 = "Third";
    String str4 = "Type 1";
    String str5 = "Type 2";
    String str6 = "Type 3";
    String str7 = "Type 4";
    String str8 = "Type 5";
    String str9 = "Type 6";
    String str10 = "Type 7";
    String str11 = "Type 8";
    DefaultCategoryDataset defaultCategoryDataset = new DefaultCategoryDataset();
    defaultCategoryDataset.addValue(1.0D, str1, str4);
    defaultCategoryDataset.addValue(4.0D, str1, str5);
    defaultCategoryDataset.addValue(3.0D, str1, str6);
    defaultCategoryDataset.addValue(5.0D, str1, str7);
    defaultCategoryDataset.addValue(5.0D, str1, str8);
    defaultCategoryDataset.addValue(7.0D, str1, str9);
    defaultCategoryDataset.addValue(7.0D, str1, str10);
    defaultCategoryDataset.addValue(8.0D, str1, str11);
    defaultCategoryDataset.addValue(5.0D, str2, str4);
    defaultCategoryDataset.addValue(7.0D, str2, str5);
    defaultCategoryDataset.addValue(6.0D, str2, str6);
    defaultCategoryDataset.addValue(8.0D, str2, str7);
    defaultCategoryDataset.addValue(4.0D, str2, str8);
    defaultCategoryDataset.addValue(4.0D, str2, str9);
    defaultCategoryDataset.addValue(2.0D, str2, str10);
    defaultCategoryDataset.addValue(1.0D, str2, str11);
    defaultCategoryDataset.addValue(4.0D, str3, str4);
    defaultCategoryDataset.addValue(3.0D, str3, str5);
    defaultCategoryDataset.addValue(2.0D, str3, str6);
    defaultCategoryDataset.addValue(3.0D, str3, str7);
    defaultCategoryDataset.addValue(6.0D, str3, str8);
    defaultCategoryDataset.addValue(3.0D, str3, str9);
    defaultCategoryDataset.addValue(4.0D, str3, str10);
    defaultCategoryDataset.addValue(3.0D, str3, str11);
    return (CategoryDataset)defaultCategoryDataset;
  }
  
  private static JFreeChart createChart(CategoryDataset paramCategoryDataset) {
    JFreeChart jFreeChart = ChartFactory.createLineChart("Line Chart Demo 5", "Type", "Value", paramCategoryDataset, PlotOrientation.VERTICAL, true, true, false);
    Shape[] arrayOfShape = new Shape[3];
    int[] arrayOfInt1 = { -3, 3, -3 };
    int[] arrayOfInt2 = { -3, 0, 3 };
    arrayOfShape[0] = new Polygon(arrayOfInt1, arrayOfInt2, 3);
    arrayOfShape[1] = new Rectangle2D.Double(-2.0D, -3.0D, 3.0D, 6.0D);
    arrayOfInt1 = new int[] { -3, 3, 3 };
    arrayOfInt2 = new int[] { 0, -3, 3 };
    arrayOfShape[2] = new Polygon(arrayOfInt1, arrayOfInt2, 3);
    DefaultDrawingSupplier defaultDrawingSupplier = new DefaultDrawingSupplier(DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE, DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE, DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE, DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE, arrayOfShape);
    CategoryPlot categoryPlot = (CategoryPlot)jFreeChart.getPlot();
    categoryPlot.setOrientation(PlotOrientation.HORIZONTAL);
    categoryPlot.setDrawingSupplier((DrawingSupplier)defaultDrawingSupplier);
    categoryPlot.getRenderer().setSeriesStroke(0, new BasicStroke(2.0F, 1, 1, 1.0F, new float[] { 10.0F, 6.0F }, 0.0F));
    categoryPlot.getRenderer().setSeriesStroke(1, new BasicStroke(2.0F, 1, 1, 1.0F, new float[] { 6.0F, 6.0F }, 0.0F));
    categoryPlot.getRenderer().setSeriesStroke(2, new BasicStroke(2.0F, 1, 1, 1.0F, new float[] { 2.0F, 6.0F }, 0.0F));
    LineAndShapeRenderer lineAndShapeRenderer = (LineAndShapeRenderer)categoryPlot.getRenderer();
    lineAndShapeRenderer.setBaseShapesVisible(true);
    lineAndShapeRenderer.setBaseItemLabelsVisible(true);
    lineAndShapeRenderer.setBaseItemLabelGenerator((CategoryItemLabelGenerator)new StandardCategoryItemLabelGenerator());
    NumberAxis numberAxis = (NumberAxis)categoryPlot.getRangeAxis();
    numberAxis.setStandardTickUnits(NumberAxis.createIntegerTickUnits());
    numberAxis.setAutoRangeIncludesZero(false);
    numberAxis.setUpperMargin(0.12D);
    return jFreeChart;
  }
  
  public static JPanel createDemoPanel() {
    JFreeChart jFreeChart = createChart(createDataset());
    return (JPanel)new ChartPanel(jFreeChart);
  }
  
  public static void main(String[] paramArrayOfString) {
    LineChartDemo5 lineChartDemo5 = new LineChartDemo5("JFreeChart: LineChartDemo5.java");
    lineChartDemo5.pack();
    RefineryUtilities.centerFrameOnScreen((Window)lineChartDemo5);
    lineChartDemo5.setVisible(true);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/LineChartDemo5.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */