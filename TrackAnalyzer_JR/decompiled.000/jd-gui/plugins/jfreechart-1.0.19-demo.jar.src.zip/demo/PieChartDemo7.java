package demo;

import java.awt.Dimension;
import java.awt.Window;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.NumberFormat;
import javax.swing.JPanel;
import javax.swing.Timer;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.labels.PieSectionLabelGenerator;
import org.jfree.chart.labels.StandardPieSectionLabelGenerator;
import org.jfree.chart.plot.PiePlot;
import org.jfree.data.general.DefaultPieDataset;
import org.jfree.data.general.PieDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

public class PieChartDemo7 extends ApplicationFrame {
  public PieChartDemo7(String paramString) {
    super(paramString);
    setContentPane(createDemoPanel());
  }
  
  private static PieDataset createDataset(int paramInt) {
    DefaultPieDataset defaultPieDataset = new DefaultPieDataset();
    for (byte b = 0; b < paramInt; b++) {
      double d = 100.0D * Math.random();
      defaultPieDataset.setValue("Section " + b, d);
    } 
    return (PieDataset)defaultPieDataset;
  }
  
  public static JPanel createDemoPanel() {
    PieDataset pieDataset = createDataset(14);
    JFreeChart jFreeChart = ChartFactory.createPieChart("Pie Chart Demo 7", pieDataset, false, true, false);
    PiePlot piePlot = (PiePlot)jFreeChart.getPlot();
    piePlot.setCircular(true);
    piePlot.setLabelGenerator((PieSectionLabelGenerator)new StandardPieSectionLabelGenerator("{0} = {2}", NumberFormat.getNumberInstance(), NumberFormat.getPercentInstance()));
    piePlot.setNoDataMessage("No data available");
    ChartPanel chartPanel = new ChartPanel(jFreeChart);
    chartPanel.setPreferredSize(new Dimension(500, 270));
    Rotator rotator = new Rotator(piePlot);
    rotator.start();
    return (JPanel)chartPanel;
  }
  
  public static void main(String[] paramArrayOfString) {
    PieChartDemo7 pieChartDemo7 = new PieChartDemo7("JFreeChart: PieChartDemo7.java");
    pieChartDemo7.pack();
    RefineryUtilities.centerFrameOnScreen((Window)pieChartDemo7);
    pieChartDemo7.setVisible(true);
  }
  
  static class Rotator extends Timer implements ActionListener {
    private PiePlot plot;
    
    private int angle = 270;
    
    Rotator(PiePlot param1PiePlot) {
      super(50, null);
      this.plot = param1PiePlot;
      addActionListener(this);
    }
    
    public void actionPerformed(ActionEvent param1ActionEvent) {
      this.plot.setStartAngle(this.angle);
      this.angle++;
      if (this.angle == 360)
        this.angle = 0; 
    }
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/PieChartDemo7.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */