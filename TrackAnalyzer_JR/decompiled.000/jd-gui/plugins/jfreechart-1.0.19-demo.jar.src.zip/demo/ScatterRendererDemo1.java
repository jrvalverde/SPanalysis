package demo;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Window;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JPanel;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.Plot;
import org.jfree.chart.renderer.category.CategoryItemRenderer;
import org.jfree.chart.renderer.category.ScatterRenderer;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.statistics.DefaultMultiValueCategoryDataset;
import org.jfree.data.statistics.MultiValueCategoryDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RectangleInsets;
import org.jfree.ui.RefineryUtilities;

public class ScatterRendererDemo1 extends ApplicationFrame {
  public ScatterRendererDemo1(String paramString) {
    super(paramString);
    JPanel jPanel = createDemoPanel();
    jPanel.setPreferredSize(new Dimension(500, 270));
    setContentPane(jPanel);
  }
  
  private static List listOfValues(double[] paramArrayOfdouble) {
    ArrayList<Double> arrayList = new ArrayList();
    for (byte b = 0; b < paramArrayOfdouble.length; b++)
      arrayList.add(new Double(paramArrayOfdouble[b])); 
    return arrayList;
  }
  
  private static MultiValueCategoryDataset createDataset() {
    DefaultMultiValueCategoryDataset defaultMultiValueCategoryDataset = new DefaultMultiValueCategoryDataset();
    defaultMultiValueCategoryDataset.add(listOfValues(new double[] { 1.0D, 2.0D, 3.0D }, ), "Series 1", "C1");
    defaultMultiValueCategoryDataset.add(listOfValues(new double[] { 1.2D, 2.2D, 3.2D }, ), "Series 1", "C2");
    defaultMultiValueCategoryDataset.add(listOfValues(new double[] { 1.4D, 2.4D, 3.4D }, ), "Series 1", "C3");
    defaultMultiValueCategoryDataset.add(listOfValues(new double[] { 1.0D, 3.0D }, ), "Series 2", "C1");
    defaultMultiValueCategoryDataset.add(listOfValues(new double[] { 1.2D, 3.2D }, ), "Series 2", "C2");
    defaultMultiValueCategoryDataset.add(listOfValues(new double[] { 1.4D, 3.6D }, ), "Series 2", "C3");
    return (MultiValueCategoryDataset)defaultMultiValueCategoryDataset;
  }
  
  private static JFreeChart createChart(MultiValueCategoryDataset paramMultiValueCategoryDataset) {
    CategoryPlot categoryPlot = new CategoryPlot((CategoryDataset)paramMultiValueCategoryDataset, new CategoryAxis("Category"), (ValueAxis)new NumberAxis("Value"), (CategoryItemRenderer)new ScatterRenderer());
    categoryPlot.setBackgroundPaint(Color.lightGray);
    categoryPlot.setDomainGridlinePaint(Color.white);
    categoryPlot.setRangeGridlinePaint(Color.white);
    categoryPlot.setAxisOffset(new RectangleInsets(4.0D, 4.0D, 4.0D, 4.0D));
    JFreeChart jFreeChart = new JFreeChart("ScatterRendererDemo1", (Plot)categoryPlot);
    ChartUtilities.applyCurrentTheme(jFreeChart);
    return jFreeChart;
  }
  
  public static JPanel createDemoPanel() {
    JFreeChart jFreeChart = createChart(createDataset());
    return (JPanel)new ChartPanel(jFreeChart);
  }
  
  public static void main(String[] paramArrayOfString) {
    ScatterRendererDemo1 scatterRendererDemo1 = new ScatterRendererDemo1("JFreeChart: ScatterRendererDemo1.java");
    scatterRendererDemo1.pack();
    RefineryUtilities.centerFrameOnScreen((Window)scatterRendererDemo1);
    scatterRendererDemo1.setVisible(true);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/ScatterRendererDemo1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */