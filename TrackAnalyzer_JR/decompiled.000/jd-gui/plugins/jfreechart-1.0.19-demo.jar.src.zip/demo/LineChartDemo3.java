package demo;

import java.awt.Dimension;
import java.awt.Window;
import javax.swing.JPanel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
import org.jfree.data.xy.XYDataset;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

public class LineChartDemo3 extends ApplicationFrame {
  public LineChartDemo3(String paramString) {
    super(paramString);
    JPanel jPanel = createDemoPanel();
    jPanel.setPreferredSize(new Dimension(500, 270));
    setContentPane(jPanel);
  }
  
  public static JPanel createDemoPanel() {
    JFreeChart jFreeChart = createChart(createDataset());
    ChartPanel chartPanel = new ChartPanel(jFreeChart);
    chartPanel.setMouseWheelEnabled(true);
    return (JPanel)chartPanel;
  }
  
  private static XYDataset createDataset() {
    XYSeriesCollection xYSeriesCollection = new XYSeriesCollection();
    for (byte b = 0; b < 10; b++) {
      XYSeries xYSeries = new XYSeries("S" + b);
      for (byte b1 = 0; b1 < 10; b1++)
        xYSeries.add(b1, Math.random() * 100.0D); 
      xYSeriesCollection.addSeries(xYSeries);
    } 
    return (XYDataset)xYSeriesCollection;
  }
  
  private static JFreeChart createChart(XYDataset paramXYDataset) {
    JFreeChart jFreeChart = ChartFactory.createXYLineChart("Line Chart Demo 3", "X", "Y", paramXYDataset, PlotOrientation.VERTICAL, true, true, false);
    XYPlot xYPlot = (XYPlot)jFreeChart.getPlot();
    xYPlot.setDomainPannable(true);
    xYPlot.setRangePannable(true);
    xYPlot.setDomainZeroBaselineVisible(true);
    xYPlot.setRangeZeroBaselineVisible(true);
    XYLineAndShapeRenderer xYLineAndShapeRenderer = (XYLineAndShapeRenderer)xYPlot.getRenderer();
    xYLineAndShapeRenderer.setBaseShapesVisible(true);
    xYLineAndShapeRenderer.setBaseShapesFilled(true);
    xYLineAndShapeRenderer.setDrawOutlines(true);
    NumberAxis numberAxis = (NumberAxis)xYPlot.getRangeAxis();
    numberAxis.setStandardTickUnits(NumberAxis.createIntegerTickUnits());
    return jFreeChart;
  }
  
  public static void main(String[] paramArrayOfString) {
    LineChartDemo3 lineChartDemo3 = new LineChartDemo3("JFreeChart: LineChartDemo3.java");
    lineChartDemo3.pack();
    RefineryUtilities.centerFrameOnScreen((Window)lineChartDemo3);
    lineChartDemo3.setVisible(true);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/LineChartDemo3.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */