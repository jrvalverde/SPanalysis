package demo;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.GradientPaint;
import java.awt.GridLayout;
import java.awt.Window;
import javax.swing.JPanel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.renderer.category.BarPainter;
import org.jfree.chart.renderer.category.BarRenderer;
import org.jfree.chart.renderer.category.StandardBarPainter;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.GradientPaintTransformType;
import org.jfree.ui.GradientPaintTransformer;
import org.jfree.ui.RefineryUtilities;
import org.jfree.ui.StandardGradientPaintTransformer;

public class GradientPaintTransformerDemo1 extends ApplicationFrame {
  public GradientPaintTransformerDemo1(String paramString) {
    super(paramString);
    setContentPane(createDemoPanel());
  }
  
  private static JFreeChart createChart(String paramString, CategoryDataset paramCategoryDataset) {
    JFreeChart jFreeChart = ChartFactory.createBarChart(paramString, null, "Value", paramCategoryDataset, PlotOrientation.VERTICAL, true, true, false);
    CategoryPlot categoryPlot = (CategoryPlot)jFreeChart.getPlot();
    BarRenderer barRenderer = (BarRenderer)categoryPlot.getRenderer();
    barRenderer.setItemMargin(0.02D);
    return jFreeChart;
  }
  
  private static CategoryDataset createDataset() {
    DefaultCategoryDataset defaultCategoryDataset = new DefaultCategoryDataset();
    defaultCategoryDataset.addValue(7.0D, "Series 1", "Category 1");
    defaultCategoryDataset.addValue(5.0D, "Series 2", "Category 1");
    return (CategoryDataset)defaultCategoryDataset;
  }
  
  public static JPanel createDemoPanel() {
    DemoPanel demoPanel = new DemoPanel(new GridLayout(2, 2));
    demoPanel.setPreferredSize(new Dimension(800, 600));
    CategoryDataset categoryDataset = createDataset();
    JFreeChart jFreeChart1 = createChart("Type: VERTICAL", categoryDataset);
    CategoryPlot categoryPlot1 = (CategoryPlot)jFreeChart1.getPlot();
    BarRenderer barRenderer1 = (BarRenderer)categoryPlot1.getRenderer();
    barRenderer1.setBarPainter((BarPainter)new StandardBarPainter());
    barRenderer1.setDrawBarOutline(false);
    barRenderer1.setSeriesPaint(0, new GradientPaint(0.0F, 0.0F, Color.red, 0.0F, 0.0F, Color.yellow));
    barRenderer1.setSeriesPaint(1, new GradientPaint(0.0F, 0.0F, Color.blue, 0.0F, 0.0F, Color.green));
    barRenderer1.setGradientPaintTransformer((GradientPaintTransformer)new StandardGradientPaintTransformer(GradientPaintTransformType.VERTICAL));
    ChartPanel chartPanel1 = new ChartPanel(jFreeChart1);
    demoPanel.add((Component)chartPanel1);
    JFreeChart jFreeChart2 = createChart("Type: HORIZONTAL", categoryDataset);
    CategoryPlot categoryPlot2 = (CategoryPlot)jFreeChart2.getPlot();
    BarRenderer barRenderer2 = (BarRenderer)categoryPlot2.getRenderer();
    barRenderer2.setBarPainter((BarPainter)new StandardBarPainter());
    barRenderer2.setDrawBarOutline(false);
    barRenderer2.setSeriesPaint(0, new GradientPaint(0.0F, 0.0F, Color.red, 0.0F, 0.0F, Color.yellow));
    barRenderer2.setSeriesPaint(1, new GradientPaint(0.0F, 0.0F, Color.blue, 0.0F, 0.0F, Color.green));
    barRenderer2.setGradientPaintTransformer((GradientPaintTransformer)new StandardGradientPaintTransformer(GradientPaintTransformType.HORIZONTAL));
    ChartPanel chartPanel2 = new ChartPanel(jFreeChart2);
    demoPanel.add((Component)chartPanel2);
    JFreeChart jFreeChart3 = createChart("Type: CENTER_VERTICAL", categoryDataset);
    CategoryPlot categoryPlot3 = (CategoryPlot)jFreeChart3.getPlot();
    BarRenderer barRenderer3 = (BarRenderer)categoryPlot3.getRenderer();
    barRenderer3.setBarPainter((BarPainter)new StandardBarPainter());
    barRenderer3.setDrawBarOutline(false);
    barRenderer3.setSeriesPaint(0, new GradientPaint(0.0F, 0.0F, Color.red, 0.0F, 0.0F, Color.yellow));
    barRenderer3.setSeriesPaint(1, new GradientPaint(0.0F, 0.0F, Color.blue, 0.0F, 0.0F, Color.green));
    barRenderer3.setGradientPaintTransformer((GradientPaintTransformer)new StandardGradientPaintTransformer(GradientPaintTransformType.CENTER_VERTICAL));
    ChartPanel chartPanel3 = new ChartPanel(jFreeChart3);
    demoPanel.add((Component)chartPanel3);
    JFreeChart jFreeChart4 = createChart("Type: CENTER_HORIZONTAL", categoryDataset);
    CategoryPlot categoryPlot4 = (CategoryPlot)jFreeChart4.getPlot();
    BarRenderer barRenderer4 = (BarRenderer)categoryPlot4.getRenderer();
    barRenderer4.setBarPainter((BarPainter)new StandardBarPainter());
    barRenderer4.setDrawBarOutline(false);
    barRenderer4.setSeriesPaint(0, new GradientPaint(0.0F, 0.0F, Color.red, 0.0F, 0.0F, Color.yellow));
    barRenderer4.setSeriesPaint(1, new GradientPaint(0.0F, 0.0F, Color.blue, 0.0F, 0.0F, Color.green));
    barRenderer4.setGradientPaintTransformer((GradientPaintTransformer)new StandardGradientPaintTransformer(GradientPaintTransformType.CENTER_HORIZONTAL));
    ChartPanel chartPanel4 = new ChartPanel(jFreeChart4);
    demoPanel.add((Component)chartPanel4);
    demoPanel.addChart(jFreeChart1);
    demoPanel.addChart(jFreeChart2);
    demoPanel.addChart(jFreeChart3);
    demoPanel.addChart(jFreeChart4);
    return demoPanel;
  }
  
  public static void main(String[] paramArrayOfString) {
    GradientPaintTransformerDemo1 gradientPaintTransformerDemo1 = new GradientPaintTransformerDemo1("JFreeChart: GradientPaintTransformerDemo1.java");
    gradientPaintTransformerDemo1.pack();
    RefineryUtilities.centerFrameOnScreen((Window)gradientPaintTransformerDemo1);
    gradientPaintTransformerDemo1.setVisible(true);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/GradientPaintTransformerDemo1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */