package demo;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.GradientPaint;
import java.awt.GridLayout;
import java.awt.Window;
import javax.swing.JPanel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.renderer.category.BarRenderer;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RectangleInsets;
import org.jfree.ui.RefineryUtilities;

public class AxisOffsetsDemo1 extends ApplicationFrame {
  public AxisOffsetsDemo1(String paramString) {
    super(paramString);
    JPanel jPanel = createDemoPanel();
    jPanel.setPreferredSize(new Dimension(500, 270));
    setContentPane(jPanel);
  }
  
  private static CategoryDataset createDataset() {
    String str1 = "S1";
    String str2 = "S2";
    String str3 = "S3";
    String str4 = "C1";
    String str5 = "C2";
    String str6 = "C3";
    String str7 = "C4";
    String str8 = "C5";
    DefaultCategoryDataset defaultCategoryDataset = new DefaultCategoryDataset();
    defaultCategoryDataset.addValue(1.0D, str1, str4);
    defaultCategoryDataset.addValue(4.0D, str1, str5);
    defaultCategoryDataset.addValue(3.0D, str1, str6);
    defaultCategoryDataset.addValue(5.0D, str1, str7);
    defaultCategoryDataset.addValue(5.0D, str1, str8);
    defaultCategoryDataset.addValue(5.0D, str2, str4);
    defaultCategoryDataset.addValue(7.0D, str2, str5);
    defaultCategoryDataset.addValue(6.0D, str2, str6);
    defaultCategoryDataset.addValue(8.0D, str2, str7);
    defaultCategoryDataset.addValue(4.0D, str2, str8);
    defaultCategoryDataset.addValue(4.0D, str3, str4);
    defaultCategoryDataset.addValue(3.0D, str3, str5);
    defaultCategoryDataset.addValue(2.0D, str3, str6);
    defaultCategoryDataset.addValue(3.0D, str3, str7);
    defaultCategoryDataset.addValue(6.0D, str3, str8);
    return (CategoryDataset)defaultCategoryDataset;
  }
  
  private static JFreeChart createChart(String paramString, CategoryDataset paramCategoryDataset) {
    JFreeChart jFreeChart = ChartFactory.createBarChart(paramString, "Category", "Value", paramCategoryDataset);
    jFreeChart.removeLegend();
    CategoryPlot categoryPlot = (CategoryPlot)jFreeChart.getPlot();
    categoryPlot.setDomainGridlinesVisible(true);
    NumberAxis numberAxis = (NumberAxis)categoryPlot.getRangeAxis();
    numberAxis.setStandardTickUnits(NumberAxis.createIntegerTickUnits());
    BarRenderer barRenderer = (BarRenderer)categoryPlot.getRenderer();
    barRenderer.setDrawBarOutline(false);
    GradientPaint gradientPaint1 = new GradientPaint(0.0F, 0.0F, Color.BLUE, 0.0F, 0.0F, new Color(0, 0, 64));
    GradientPaint gradientPaint2 = new GradientPaint(0.0F, 0.0F, Color.GREEN, 0.0F, 0.0F, new Color(0, 64, 0));
    GradientPaint gradientPaint3 = new GradientPaint(0.0F, 0.0F, Color.RED, 0.0F, 0.0F, new Color(64, 0, 0));
    barRenderer.setSeriesPaint(0, gradientPaint1);
    barRenderer.setSeriesPaint(1, gradientPaint2);
    barRenderer.setSeriesPaint(2, gradientPaint3);
    return jFreeChart;
  }
  
  public static JPanel createDemoPanel() {
    JFreeChart jFreeChart1 = createChart("Axis Offsets: 0", createDataset());
    CategoryPlot categoryPlot1 = (CategoryPlot)jFreeChart1.getPlot();
    categoryPlot1.setAxisOffset(RectangleInsets.ZERO_INSETS);
    ChartPanel chartPanel1 = new ChartPanel(jFreeChart1);
    chartPanel1.setMinimumDrawWidth(0);
    chartPanel1.setMinimumDrawHeight(0);
    JFreeChart jFreeChart2 = createChart("Axis Offsets: 5", createDataset());
    ChartPanel chartPanel2 = new ChartPanel(jFreeChart2);
    chartPanel2.setMinimumDrawWidth(0);
    chartPanel2.setMinimumDrawHeight(0);
    CategoryPlot categoryPlot2 = (CategoryPlot)jFreeChart2.getPlot();
    categoryPlot2.setAxisOffset(new RectangleInsets(5.0D, 5.0D, 5.0D, 5.0D));
    DemoPanel demoPanel = new DemoPanel(new GridLayout(2, 1));
    demoPanel.add((Component)chartPanel1);
    demoPanel.add((Component)chartPanel2);
    demoPanel.addChart(jFreeChart1);
    demoPanel.addChart(jFreeChart2);
    return demoPanel;
  }
  
  public static void main(String[] paramArrayOfString) {
    AxisOffsetsDemo1 axisOffsetsDemo1 = new AxisOffsetsDemo1("JFreeChart: AxisOffsetsDemo1.java");
    axisOffsetsDemo1.pack();
    RefineryUtilities.centerFrameOnScreen((Window)axisOffsetsDemo1);
    axisOffsetsDemo1.setVisible(true);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/AxisOffsetsDemo1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */