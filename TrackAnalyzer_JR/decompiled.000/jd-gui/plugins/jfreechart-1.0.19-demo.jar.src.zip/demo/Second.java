package demo;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartFrame;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.StandardXYItemRenderer;
import org.jfree.chart.renderer.xy.XYItemRenderer;
import org.jfree.data.xy.XYDataset;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;

public class Second {
  public static void main(String[] paramArrayOfString) {
    XYSeries xYSeries1 = new XYSeries("Advisory Range");
    xYSeries1.add(new Integer(1200), new Integer(1));
    xYSeries1.add(new Integer(1500), new Integer(1));
    XYSeries xYSeries2 = new XYSeries("Normal Range");
    xYSeries2.add(new Integer(2000), new Integer(4));
    xYSeries2.add(new Integer(2300), new Integer(4));
    XYSeries xYSeries3 = new XYSeries("Recommended");
    xYSeries3.add(new Integer(2100), new Integer(2));
    XYSeries xYSeries4 = new XYSeries("Current");
    xYSeries4.add(new Integer(2400), new Integer(3));
    XYSeriesCollection xYSeriesCollection = new XYSeriesCollection();
    xYSeriesCollection.addSeries(xYSeries1);
    xYSeriesCollection.addSeries(xYSeries2);
    xYSeriesCollection.addSeries(xYSeries3);
    xYSeriesCollection.addSeries(xYSeries4);
    JFreeChart jFreeChart = ChartFactory.createXYLineChart("My Chart", "Calories", "Y", (XYDataset)xYSeriesCollection, PlotOrientation.VERTICAL, true, true, false);
    StandardXYItemRenderer standardXYItemRenderer = new StandardXYItemRenderer(3, null);
    XYPlot xYPlot = (XYPlot)jFreeChart.getPlot();
    xYPlot.setRenderer((XYItemRenderer)standardXYItemRenderer);
    ValueAxis valueAxis = xYPlot.getRangeAxis();
    valueAxis.setTickLabelsVisible(false);
    valueAxis.setRange(0.0D, 5.0D);
    ChartFrame chartFrame = new ChartFrame("Test", jFreeChart);
    chartFrame.pack();
    chartFrame.setVisible(true);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/Second.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */