package demo;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Window;
import javax.swing.JPanel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.DeviationRenderer;
import org.jfree.chart.renderer.xy.XYItemRenderer;
import org.jfree.data.time.RegularTimePeriod;
import org.jfree.data.time.Week;
import org.jfree.data.xy.XYDataset;
import org.jfree.data.xy.YIntervalSeries;
import org.jfree.data.xy.YIntervalSeriesCollection;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RectangleInsets;
import org.jfree.ui.RefineryUtilities;

public class DeviationRendererDemo2 extends ApplicationFrame {
  public DeviationRendererDemo2(String paramString) {
    super(paramString);
    JPanel jPanel = createDemoPanel();
    jPanel.setPreferredSize(new Dimension(500, 270));
    setContentPane(jPanel);
  }
  
  private static XYDataset createDataset() {
    YIntervalSeries yIntervalSeries1 = new YIntervalSeries("Series 1");
    YIntervalSeries yIntervalSeries2 = new YIntervalSeries("Series 2");
    Week week = new Week();
    double d1 = 100.0D;
    double d2 = 100.0D;
    for (byte b = 0; b <= 52; b++) {
      double d3 = 0.05D * b;
      yIntervalSeries1.add(week.getFirstMillisecond(), d1, d1 - d3, d1 + d3);
      d1 = d1 + Math.random() - 0.45D;
      double d4 = 0.07D * b;
      yIntervalSeries2.add(week.getFirstMillisecond(), d2, d2 - d4, d2 + d4);
      d2 = d2 + Math.random() - 0.55D;
      RegularTimePeriod regularTimePeriod = week.next();
    } 
    YIntervalSeriesCollection yIntervalSeriesCollection = new YIntervalSeriesCollection();
    yIntervalSeriesCollection.addSeries(yIntervalSeries1);
    yIntervalSeriesCollection.addSeries(yIntervalSeries2);
    return (XYDataset)yIntervalSeriesCollection;
  }
  
  private static JFreeChart createChart(XYDataset paramXYDataset) {
    JFreeChart jFreeChart = ChartFactory.createTimeSeriesChart("Projected Values - Test", "Date", "Index Projection", paramXYDataset, true, true, false);
    XYPlot xYPlot = (XYPlot)jFreeChart.getPlot();
    xYPlot.setDomainPannable(true);
    xYPlot.setRangePannable(false);
    xYPlot.setInsets(new RectangleInsets(5.0D, 5.0D, 5.0D, 20.0D));
    DeviationRenderer deviationRenderer = new DeviationRenderer(true, false);
    deviationRenderer.setSeriesStroke(0, new BasicStroke(3.0F, 1, 1));
    deviationRenderer.setSeriesStroke(0, new BasicStroke(3.0F, 1, 1));
    deviationRenderer.setSeriesStroke(1, new BasicStroke(3.0F, 1, 1));
    deviationRenderer.setSeriesFillPaint(0, new Color(255, 200, 200));
    deviationRenderer.setSeriesFillPaint(1, new Color(200, 200, 255));
    xYPlot.setRenderer((XYItemRenderer)deviationRenderer);
    NumberAxis numberAxis = (NumberAxis)xYPlot.getRangeAxis();
    numberAxis.setAutoRangeIncludesZero(false);
    numberAxis.setStandardTickUnits(NumberAxis.createIntegerTickUnits());
    return jFreeChart;
  }
  
  public static JPanel createDemoPanel() {
    JFreeChart jFreeChart = createChart(createDataset());
    return (JPanel)new ChartPanel(jFreeChart);
  }
  
  public static void main(String[] paramArrayOfString) {
    DeviationRendererDemo2 deviationRendererDemo2 = new DeviationRendererDemo2("JFreeChart: DeviationRendererDemo2.java");
    deviationRendererDemo2.pack();
    RefineryUtilities.centerFrameOnScreen((Window)deviationRendererDemo2);
    deviationRendererDemo2.setVisible(true);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/DeviationRendererDemo2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */