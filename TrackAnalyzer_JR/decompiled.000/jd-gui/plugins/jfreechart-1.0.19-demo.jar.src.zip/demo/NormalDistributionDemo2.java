package demo;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Window;
import javax.swing.JPanel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.annotations.XYAnnotation;
import org.jfree.chart.annotations.XYPointerAnnotation;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
import org.jfree.data.function.Function2D;
import org.jfree.data.function.NormalDistributionFunction2D;
import org.jfree.data.general.DatasetUtilities;
import org.jfree.data.xy.XYDataset;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;
import org.jfree.ui.TextAnchor;

public class NormalDistributionDemo2 extends ApplicationFrame {
  public NormalDistributionDemo2(String paramString) {
    super(paramString);
    JPanel jPanel = createDemoPanel();
    jPanel.setPreferredSize(new Dimension(500, 270));
    setContentPane(jPanel);
  }
  
  public static JPanel createDemoPanel() {
    JFreeChart jFreeChart = createChart(createDataset());
    ChartPanel chartPanel = new ChartPanel(jFreeChart);
    chartPanel.setMouseWheelEnabled(true);
    return (JPanel)chartPanel;
  }
  
  public static XYDataset createDataset() {
    XYSeriesCollection xYSeriesCollection = new XYSeriesCollection();
    NormalDistributionFunction2D normalDistributionFunction2D1 = new NormalDistributionFunction2D(0.0D, 1.0D);
    XYSeries xYSeries1 = DatasetUtilities.sampleFunction2DToSeries((Function2D)normalDistributionFunction2D1, -5.1D, 5.1D, 121, "N1");
    xYSeriesCollection.addSeries(xYSeries1);
    NormalDistributionFunction2D normalDistributionFunction2D2 = new NormalDistributionFunction2D(0.0D, Math.sqrt(0.2D));
    XYSeries xYSeries2 = DatasetUtilities.sampleFunction2DToSeries((Function2D)normalDistributionFunction2D2, -5.1D, 5.1D, 121, "N2");
    xYSeriesCollection.addSeries(xYSeries2);
    NormalDistributionFunction2D normalDistributionFunction2D3 = new NormalDistributionFunction2D(0.0D, Math.sqrt(5.0D));
    XYSeries xYSeries3 = DatasetUtilities.sampleFunction2DToSeries((Function2D)normalDistributionFunction2D3, -5.1D, 5.1D, 121, "N3");
    xYSeriesCollection.addSeries(xYSeries3);
    NormalDistributionFunction2D normalDistributionFunction2D4 = new NormalDistributionFunction2D(-2.0D, Math.sqrt(0.5D));
    XYSeries xYSeries4 = DatasetUtilities.sampleFunction2DToSeries((Function2D)normalDistributionFunction2D4, -5.1D, 5.1D, 121, "N4");
    xYSeriesCollection.addSeries(xYSeries4);
    return (XYDataset)xYSeriesCollection;
  }
  
  public static JFreeChart createChart(XYDataset paramXYDataset) {
    JFreeChart jFreeChart = ChartFactory.createXYLineChart("Normal Distribution Demo 2", "X", "Y", paramXYDataset, PlotOrientation.VERTICAL, true, true, false);
    XYPlot xYPlot = (XYPlot)jFreeChart.getPlot();
    xYPlot.setDomainZeroBaselineVisible(true);
    xYPlot.setRangeZeroBaselineVisible(true);
    xYPlot.setDomainPannable(true);
    xYPlot.setRangePannable(true);
    ValueAxis valueAxis = xYPlot.getDomainAxis();
    valueAxis.setLowerMargin(0.0D);
    valueAxis.setUpperMargin(0.0D);
    XYLineAndShapeRenderer xYLineAndShapeRenderer = (XYLineAndShapeRenderer)xYPlot.getRenderer();
    xYLineAndShapeRenderer.setDrawSeriesLineAsPath(true);
    xYLineAndShapeRenderer.setSeriesStroke(0, new BasicStroke(1.5F));
    xYLineAndShapeRenderer.setSeriesStroke(1, new BasicStroke(2.0F, 1, 1, 1.0F, new float[] { 6.0F, 4.0F }, 0.0F));
    xYLineAndShapeRenderer.setSeriesStroke(2, new BasicStroke(2.0F, 1, 1, 1.0F, new float[] { 6.0F, 4.0F, 3.0F, 3.0F }, 0.0F));
    xYLineAndShapeRenderer.setSeriesStroke(3, new BasicStroke(2.0F, 1, 1, 1.0F, new float[] { 4.0F, 4.0F }, 0.0F));
    XYPointerAnnotation xYPointerAnnotation1 = new XYPointerAnnotation("μ = -2.0, σ² = 0.5", -2.0D, 0.564D, 3.9269908169872414D);
    xYPointerAnnotation1.setLabelOffset(4.0D);
    xYPointerAnnotation1.setTextAnchor(TextAnchor.BOTTOM_RIGHT);
    xYPointerAnnotation1.setBackgroundPaint(Color.yellow);
    xYPlot.addAnnotation((XYAnnotation)xYPointerAnnotation1);
    XYPointerAnnotation xYPointerAnnotation2 = new XYPointerAnnotation("μ = 0.0, σ² = 0.2", 0.225D, 0.8D, 0.0D);
    xYPointerAnnotation2.setLabelOffset(4.0D);
    xYPointerAnnotation2.setTextAnchor(TextAnchor.CENTER_LEFT);
    xYPointerAnnotation2.setBackgroundPaint(new Color(0, 0, 255, 63));
    xYPlot.addAnnotation((XYAnnotation)xYPointerAnnotation2);
    XYPointerAnnotation xYPointerAnnotation3 = new XYPointerAnnotation("μ = 0.0, σ² = 1.0", 0.75D, 0.3D, 5.497787143782138D);
    xYPointerAnnotation3.setLabelOffset(4.0D);
    xYPointerAnnotation3.setTextAnchor(TextAnchor.HALF_ASCENT_LEFT);
    xYPointerAnnotation3.setBackgroundPaint(new Color(255, 0, 0, 63));
    xYPlot.addAnnotation((XYAnnotation)xYPointerAnnotation3);
    XYPointerAnnotation xYPointerAnnotation4 = new XYPointerAnnotation("μ = 0.0, σ² = 5.0", 3.0D, 0.075D, 4.71238898038469D);
    xYPointerAnnotation4.setLabelOffset(4.0D);
    xYPointerAnnotation4.setTextAnchor(TextAnchor.BOTTOM_CENTER);
    xYPointerAnnotation4.setBackgroundPaint(new Color(0, 255, 0, 63));
    xYPlot.addAnnotation((XYAnnotation)xYPointerAnnotation4);
    return jFreeChart;
  }
  
  public static void main(String[] paramArrayOfString) {
    NormalDistributionDemo2 normalDistributionDemo2 = new NormalDistributionDemo2("JFreeChart: NormalDistributionDemo2.java");
    normalDistributionDemo2.pack();
    RefineryUtilities.centerFrameOnScreen((Window)normalDistributionDemo2);
    normalDistributionDemo2.setVisible(true);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/NormalDistributionDemo2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */