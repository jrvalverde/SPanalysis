package demo;

import java.awt.Container;
import java.awt.Dimension;
import java.awt.Window;
import javax.swing.JPanel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.CategoryLabelPositions;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.labels.CategoryItemLabelGenerator;
import org.jfree.chart.labels.StandardCategoryItemLabelGenerator;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.renderer.category.CategoryItemRenderer;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

public class BarChartDemo8 extends ApplicationFrame {
  public BarChartDemo8(String paramString) {
    super(paramString);
    CategoryDataset categoryDataset = createDataset();
    JFreeChart jFreeChart = createChart(categoryDataset);
    ChartPanel chartPanel = new ChartPanel(jFreeChart);
    chartPanel.setPreferredSize(new Dimension(500, 270));
    setContentPane((Container)chartPanel);
  }
  
  private static CategoryDataset createDataset() {
    String str1 = "First";
    String str2 = "Second";
    String str3 = "Third";
    String str4 = "Category 1";
    String str5 = "Category 2";
    String str6 = "Category 3";
    String str7 = "Category 4";
    String str8 = "Category 5";
    DefaultCategoryDataset defaultCategoryDataset = new DefaultCategoryDataset();
    defaultCategoryDataset.addValue(1.0D, str1, str4);
    defaultCategoryDataset.addValue(4.0D, str1, str5);
    defaultCategoryDataset.addValue(3.0D, str1, str6);
    defaultCategoryDataset.addValue(5.0D, str1, str7);
    defaultCategoryDataset.addValue(5.0D, str1, str8);
    defaultCategoryDataset.addValue(5.0D, str2, str4);
    defaultCategoryDataset.addValue(7.0D, str2, str5);
    defaultCategoryDataset.addValue(6.0D, str2, str6);
    defaultCategoryDataset.addValue(8.0D, str2, str7);
    defaultCategoryDataset.addValue(4.0D, str2, str8);
    defaultCategoryDataset.addValue(4.0D, str3, str4);
    defaultCategoryDataset.addValue(3.0D, str3, str5);
    defaultCategoryDataset.addValue(2.0D, str3, str6);
    defaultCategoryDataset.addValue(3.0D, str3, str7);
    defaultCategoryDataset.addValue(6.0D, str3, str8);
    return (CategoryDataset)defaultCategoryDataset;
  }
  
  private static JFreeChart createChart(CategoryDataset paramCategoryDataset) {
    JFreeChart jFreeChart = ChartFactory.createBarChart("Bar Chart Demo 8", "Category", "Value", paramCategoryDataset);
    jFreeChart.removeLegend();
    CategoryPlot categoryPlot = (CategoryPlot)jFreeChart.getPlot();
    NumberAxis numberAxis = (NumberAxis)categoryPlot.getRangeAxis();
    numberAxis.setStandardTickUnits(NumberAxis.createIntegerTickUnits());
    numberAxis.setUpperMargin(0.15D);
    CategoryItemRenderer categoryItemRenderer = categoryPlot.getRenderer();
    categoryItemRenderer.setBaseItemLabelGenerator((CategoryItemLabelGenerator)new StandardCategoryItemLabelGenerator());
    categoryItemRenderer.setSeriesItemLabelsVisible(0, Boolean.TRUE);
    CategoryAxis categoryAxis = categoryPlot.getDomainAxis();
    categoryAxis.setCategoryLabelPositions(CategoryLabelPositions.UP_45);
    return jFreeChart;
  }
  
  public static JPanel createDemoPanel() {
    JFreeChart jFreeChart = createChart(createDataset());
    return (JPanel)new ChartPanel(jFreeChart);
  }
  
  public static void main(String[] paramArrayOfString) {
    BarChartDemo8 barChartDemo8 = new BarChartDemo8("JFreeChart: BarChartDemo8.java");
    barChartDemo8.pack();
    RefineryUtilities.centerFrameOnScreen((Window)barChartDemo8);
    barChartDemo8.setVisible(true);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/BarChartDemo8.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */