package demo;

import java.awt.Dimension;
import java.awt.Font;
import java.awt.Window;
import java.text.NumberFormat;
import javax.swing.JPanel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.labels.AbstractCategoryItemLabelGenerator;
import org.jfree.chart.labels.CategoryItemLabelGenerator;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.renderer.category.CategoryItemRenderer;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

public class ItemLabelDemo1 extends ApplicationFrame {
  public ItemLabelDemo1(String paramString) {
    super(paramString);
    JPanel jPanel = createDemoPanel();
    jPanel.setPreferredSize(new Dimension(500, 270));
    setContentPane(jPanel);
  }
  
  private static CategoryDataset createDataset() {
    DefaultCategoryDataset defaultCategoryDataset = new DefaultCategoryDataset();
    defaultCategoryDataset.addValue(11.0D, "S1", "C1");
    defaultCategoryDataset.addValue(44.3D, "S1", "C2");
    defaultCategoryDataset.addValue(93.0D, "S1", "C3");
    defaultCategoryDataset.addValue(35.6D, "S1", "C4");
    defaultCategoryDataset.addValue(75.1D, "S1", "C5");
    return (CategoryDataset)defaultCategoryDataset;
  }
  
  private static JFreeChart createChart(CategoryDataset paramCategoryDataset) {
    JFreeChart jFreeChart = ChartFactory.createBarChart("Item Label Demo 1", "Category", "Value", paramCategoryDataset, PlotOrientation.VERTICAL, false, true, false);
    CategoryPlot categoryPlot = (CategoryPlot)jFreeChart.getPlot();
    categoryPlot.setRangePannable(true);
    categoryPlot.setRangeZeroBaselineVisible(true);
    NumberAxis numberAxis = (NumberAxis)categoryPlot.getRangeAxis();
    numberAxis.setUpperMargin(0.15D);
    CategoryItemRenderer categoryItemRenderer = categoryPlot.getRenderer();
    categoryItemRenderer.setBaseItemLabelGenerator(new LabelGenerator(50.0D));
    categoryItemRenderer.setBaseItemLabelFont(new Font("Serif", 0, 20));
    categoryItemRenderer.setBaseItemLabelsVisible(true);
    return jFreeChart;
  }
  
  public static JPanel createDemoPanel() {
    JFreeChart jFreeChart = createChart(createDataset());
    ChartPanel chartPanel = new ChartPanel(jFreeChart);
    chartPanel.setMouseWheelEnabled(true);
    return (JPanel)chartPanel;
  }
  
  public static void main(String[] paramArrayOfString) {
    ItemLabelDemo1 itemLabelDemo1 = new ItemLabelDemo1("JFreeChart: ItemLabelDemo1.java");
    itemLabelDemo1.pack();
    RefineryUtilities.centerFrameOnScreen((Window)itemLabelDemo1);
    itemLabelDemo1.setVisible(true);
  }
  
  static class LabelGenerator extends AbstractCategoryItemLabelGenerator implements CategoryItemLabelGenerator {
    private double threshold;
    
    public LabelGenerator(double param1Double) {
      super("", NumberFormat.getInstance());
      this.threshold = param1Double;
    }
    
    public String generateLabel(CategoryDataset param1CategoryDataset, int param1Int1, int param1Int2) {
      String str = null;
      Number number = param1CategoryDataset.getValue(param1Int1, param1Int2);
      if (number != null) {
        double d = number.doubleValue();
        if (d > this.threshold)
          str = number.toString(); 
      } 
      return str;
    }
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/ItemLabelDemo1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */