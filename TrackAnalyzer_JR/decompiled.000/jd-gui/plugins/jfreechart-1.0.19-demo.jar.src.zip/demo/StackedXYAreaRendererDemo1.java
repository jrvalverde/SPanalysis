package demo;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Window;
import javax.swing.JPanel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.labels.StandardXYToolTipGenerator;
import org.jfree.chart.labels.XYToolTipGenerator;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.StackedXYAreaRenderer;
import org.jfree.chart.renderer.xy.XYItemRenderer;
import org.jfree.data.xy.DefaultTableXYDataset;
import org.jfree.data.xy.TableXYDataset;
import org.jfree.data.xy.XYSeries;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

public class StackedXYAreaRendererDemo1 extends ApplicationFrame {
  public StackedXYAreaRendererDemo1(String paramString) {
    super(paramString);
    JPanel jPanel = createDemoPanel();
    jPanel.setPreferredSize(new Dimension(500, 270));
    setContentPane(jPanel);
  }
  
  private static TableXYDataset createDataset() {
    DefaultTableXYDataset defaultTableXYDataset = new DefaultTableXYDataset();
    XYSeries xYSeries1 = new XYSeries("Series 1", true, false);
    xYSeries1.add(5.0D, 5.0D);
    xYSeries1.add(10.0D, 15.5D);
    xYSeries1.add(15.0D, 9.5D);
    xYSeries1.add(20.0D, 7.5D);
    defaultTableXYDataset.addSeries(xYSeries1);
    XYSeries xYSeries2 = new XYSeries("Series 2", true, false);
    xYSeries2.add(5.0D, 5.0D);
    xYSeries2.add(10.0D, 15.5D);
    xYSeries2.add(15.0D, 9.5D);
    xYSeries2.add(20.0D, 3.5D);
    defaultTableXYDataset.addSeries(xYSeries2);
    return (TableXYDataset)defaultTableXYDataset;
  }
  
  private static JFreeChart createChart(TableXYDataset paramTableXYDataset) {
    JFreeChart jFreeChart = ChartFactory.createStackedXYAreaChart("StackedXYAreaRendererDemo1", "X Value", "Y Value", paramTableXYDataset, PlotOrientation.VERTICAL, true, true, false);
    XYPlot xYPlot = (XYPlot)jFreeChart.getPlot();
    StackedXYAreaRenderer stackedXYAreaRenderer = new StackedXYAreaRenderer(5);
    stackedXYAreaRenderer.setBaseToolTipGenerator((XYToolTipGenerator)new StandardXYToolTipGenerator());
    xYPlot.setRenderer(0, (XYItemRenderer)stackedXYAreaRenderer);
    xYPlot.setDomainCrosshairVisible(true);
    xYPlot.setRangeCrosshairVisible(true);
    stackedXYAreaRenderer.setShapePaint(Color.yellow);
    ChartUtilities.applyCurrentTheme(jFreeChart);
    return jFreeChart;
  }
  
  public static JPanel createDemoPanel() {
    JFreeChart jFreeChart = createChart(createDataset());
    return (JPanel)new ChartPanel(jFreeChart);
  }
  
  public static void main(String[] paramArrayOfString) {
    StackedXYAreaRendererDemo1 stackedXYAreaRendererDemo1 = new StackedXYAreaRendererDemo1("StackedXYAreaRendererDemo1");
    stackedXYAreaRendererDemo1.pack();
    RefineryUtilities.centerFrameOnScreen((Window)stackedXYAreaRendererDemo1);
    stackedXYAreaRendererDemo1.setVisible(true);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/StackedXYAreaRendererDemo1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */