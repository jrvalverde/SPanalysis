package demo;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Window;
import javax.swing.JPanel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.data.xy.XYDataset;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

public class GridBandDemo1 extends ApplicationFrame {
  public GridBandDemo1(String paramString) {
    super(paramString);
    JPanel jPanel = createDemoPanel();
    jPanel.setPreferredSize(new Dimension(500, 270));
    setContentPane(jPanel);
  }
  
  private static JFreeChart createChart(XYDataset paramXYDataset) {
    JFreeChart jFreeChart = ChartFactory.createScatterPlot("Grid Band Demo 1", "X", "Y", paramXYDataset, PlotOrientation.VERTICAL, true, false, false);
    XYPlot xYPlot = (XYPlot)jFreeChart.getPlot();
    xYPlot.setNoDataMessage("NO DATA");
    xYPlot.setRangeZeroBaselineVisible(true);
    xYPlot.setDomainPannable(true);
    xYPlot.setRangePannable(true);
    xYPlot.setDomainTickBandPaint(new Color(0, 100, 0, 50));
    xYPlot.setRangeTickBandPaint(new Color(0, 100, 0, 50));
    return jFreeChart;
  }
  
  public static JPanel createDemoPanel() {
    XYSeries xYSeries = new XYSeries("Random Data");
    for (byte b = 0; b < 100; b++)
      xYSeries.add(Math.random() + 1.0D, Math.random() + 1.0D); 
    XYSeriesCollection xYSeriesCollection = new XYSeriesCollection();
    xYSeriesCollection.addSeries(xYSeries);
    JFreeChart jFreeChart = createChart((XYDataset)xYSeriesCollection);
    ChartPanel chartPanel = new ChartPanel(jFreeChart);
    chartPanel.setMouseWheelEnabled(true);
    return (JPanel)chartPanel;
  }
  
  public static void main(String[] paramArrayOfString) {
    GridBandDemo1 gridBandDemo1 = new GridBandDemo1("JFreeChart: GridBandDemo1.java");
    gridBandDemo1.pack();
    RefineryUtilities.centerFrameOnScreen((Window)gridBandDemo1);
    gridBandDemo1.setVisible(true);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/GridBandDemo1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */