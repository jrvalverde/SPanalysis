package demo;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GradientPaint;
import java.awt.Window;
import java.text.DecimalFormat;
import javax.swing.JPanel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.labels.CategoryToolTipGenerator;
import org.jfree.chart.labels.StandardCategoryToolTipGenerator;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.renderer.category.BarRenderer;
import org.jfree.chart.title.TextTitle;
import org.jfree.chart.title.Title;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RectangleEdge;
import org.jfree.ui.RefineryUtilities;

public class BarChartDemo11 extends ApplicationFrame {
  public BarChartDemo11(String paramString) {
    super(paramString);
    JPanel jPanel = createDemoPanel();
    jPanel.setPreferredSize(new Dimension(500, 270));
    setContentPane(jPanel);
  }
  
  private static CategoryDataset createDataset() {
    DefaultCategoryDataset defaultCategoryDataset = new DefaultCategoryDataset();
    defaultCategoryDataset.addValue(33.0D, "S1", "GNU General Public License (GPL) 2.0");
    defaultCategoryDataset.addValue(13.0D, "S1", "Apache License 2.0");
    defaultCategoryDataset.addValue(12.0D, "S1", "GNU General Public License (GPL) 3.0");
    defaultCategoryDataset.addValue(11.0D, "S1", "MIT License");
    defaultCategoryDataset.addValue(7.0D, "S1", "BSD License 2.0");
    defaultCategoryDataset.addValue(6.0D, "S1", "Artistic Licence (Perl)");
    defaultCategoryDataset.addValue(6.0D, "S1", "GNU Lesser General Public License (LGPL) 2.1");
    defaultCategoryDataset.addValue(3.0D, "S1", "GNU Lesser General Public License (LGPL) 3.0");
    defaultCategoryDataset.addValue(2.0D, "S1", "Eclipse Public License");
    defaultCategoryDataset.addValue(1.0D, "S1", "Code Project 1.02 License");
    return (CategoryDataset)defaultCategoryDataset;
  }
  
  private static JFreeChart createChart(CategoryDataset paramCategoryDataset) {
    JFreeChart jFreeChart = ChartFactory.createBarChart("Open Source Projects By License", "License", "Percent", paramCategoryDataset);
    jFreeChart.removeLegend();
    TextTitle textTitle = new TextTitle("Source: http://www.blackducksoftware.com/resources/data/top-20-licenses (as at 30 Aug 2013)", new Font("Dialog", 0, 9));
    textTitle.setPosition(RectangleEdge.BOTTOM);
    jFreeChart.addSubtitle((Title)textTitle);
    CategoryPlot categoryPlot = (CategoryPlot)jFreeChart.getPlot();
    categoryPlot.setOrientation(PlotOrientation.HORIZONTAL);
    categoryPlot.setDomainGridlinesVisible(true);
    categoryPlot.getDomainAxis().setMaximumCategoryLabelWidthRatio(0.8F);
    NumberAxis numberAxis = (NumberAxis)categoryPlot.getRangeAxis();
    numberAxis.setStandardTickUnits(NumberAxis.createIntegerTickUnits());
    BarRenderer barRenderer = (BarRenderer)categoryPlot.getRenderer();
    barRenderer.setDrawBarOutline(false);
    StandardCategoryToolTipGenerator standardCategoryToolTipGenerator = new StandardCategoryToolTipGenerator("{1}: {2} percent", new DecimalFormat("0"));
    barRenderer.setBaseToolTipGenerator((CategoryToolTipGenerator)standardCategoryToolTipGenerator);
    GradientPaint gradientPaint = new GradientPaint(0.0F, 0.0F, Color.BLUE, 0.0F, 0.0F, new Color(0, 0, 64));
    barRenderer.setSeriesPaint(0, gradientPaint);
    return jFreeChart;
  }
  
  public static JPanel createDemoPanel() {
    JFreeChart jFreeChart = createChart(createDataset());
    return (JPanel)new ChartPanel(jFreeChart);
  }
  
  public static void main(String[] paramArrayOfString) {
    BarChartDemo11 barChartDemo11 = new BarChartDemo11("JFreeChart: BarChartDemo11.java");
    barChartDemo11.pack();
    RefineryUtilities.centerFrameOnScreen((Window)barChartDemo11);
    barChartDemo11.setVisible(true);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/BarChartDemo11.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */