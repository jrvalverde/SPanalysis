package demo;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartFrame;
import org.jfree.chart.JFreeChart;
import org.jfree.data.general.DefaultPieDataset;
import org.jfree.data.general.PieDataset;

public class First {
  public static void main(String[] paramArrayOfString) {
    DefaultPieDataset defaultPieDataset = new DefaultPieDataset();
    defaultPieDataset.setValue("Category 1", 43.2D);
    defaultPieDataset.setValue("Category 2", 27.9D);
    defaultPieDataset.setValue("Category 3", 79.5D);
    JFreeChart jFreeChart = ChartFactory.createPieChart("Sample Pie Chart", (PieDataset)defaultPieDataset, true, true, false);
    ChartFrame chartFrame = new ChartFrame("JFreeChart: First.java", jFreeChart);
    chartFrame.pack();
    chartFrame.setVisible(true);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/First.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */