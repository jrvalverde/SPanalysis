package demo;

import java.awt.BasicStroke;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.GradientPaint;
import java.awt.Point;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.Plot;
import org.jfree.chart.plot.dial.ArcDialFrame;
import org.jfree.chart.plot.dial.DialBackground;
import org.jfree.chart.plot.dial.DialFrame;
import org.jfree.chart.plot.dial.DialLayer;
import org.jfree.chart.plot.dial.DialPlot;
import org.jfree.chart.plot.dial.DialPointer;
import org.jfree.chart.plot.dial.DialScale;
import org.jfree.chart.plot.dial.StandardDialScale;
import org.jfree.data.general.DefaultValueDataset;
import org.jfree.data.general.ValueDataset;
import org.jfree.ui.GradientPaintTransformType;
import org.jfree.ui.GradientPaintTransformer;
import org.jfree.ui.StandardGradientPaintTransformer;

public class DialDemo3 extends JFrame {
  public static JPanel createDemoPanel() {
    return new DemoPanel();
  }
  
  public DialDemo3(String paramString) {
    super(paramString);
    setDefaultCloseOperation(3);
    setContentPane(createDemoPanel());
  }
  
  public static void main(String[] paramArrayOfString) {
    DialDemo3 dialDemo3 = new DialDemo3("JFreeChart: DialDemo3.java");
    dialDemo3.pack();
    dialDemo3.setVisible(true);
  }
  
  static class DemoPanel extends JPanel implements ChangeListener {
    JSlider slider;
    
    DefaultValueDataset dataset = new DefaultValueDataset(50.0D);
    
    public DemoPanel() {
      super(new BorderLayout());
      DialPlot dialPlot = new DialPlot();
      dialPlot.setView(0.21D, 0.0D, 0.58D, 0.3D);
      dialPlot.setDataset((ValueDataset)this.dataset);
      ArcDialFrame arcDialFrame = new ArcDialFrame(60.0D, 60.0D);
      arcDialFrame.setInnerRadius(0.6D);
      arcDialFrame.setOuterRadius(0.9D);
      arcDialFrame.setForegroundPaint(Color.darkGray);
      arcDialFrame.setStroke(new BasicStroke(3.0F));
      dialPlot.setDialFrame((DialFrame)arcDialFrame);
      GradientPaint gradientPaint = new GradientPaint(new Point(), new Color(255, 255, 255), new Point(), new Color(240, 240, 240));
      DialBackground dialBackground = new DialBackground(gradientPaint);
      dialBackground.setGradientPaintTransformer((GradientPaintTransformer)new StandardGradientPaintTransformer(GradientPaintTransformType.VERTICAL));
      dialPlot.addLayer((DialLayer)dialBackground);
      StandardDialScale standardDialScale = new StandardDialScale(0.0D, 100.0D, 115.0D, -50.0D, 10.0D, 4);
      standardDialScale.setTickRadius(0.88D);
      standardDialScale.setTickLabelOffset(0.07D);
      standardDialScale.setMajorTickIncrement(25.0D);
      dialPlot.addScale(0, (DialScale)standardDialScale);
      DialPointer.Pin pin = new DialPointer.Pin();
      pin.setRadius(0.82D);
      dialPlot.addLayer((DialLayer)pin);
      JFreeChart jFreeChart = new JFreeChart((Plot)dialPlot);
      jFreeChart.setTitle("Dial Demo 3");
      ChartPanel chartPanel = new ChartPanel(jFreeChart);
      chartPanel.setPreferredSize(new Dimension(400, 250));
      this.slider = new JSlider(0, 100);
      this.slider.setMajorTickSpacing(10);
      this.slider.setPaintLabels(true);
      this.slider.addChangeListener(this);
      add((Component)chartPanel);
      add(this.slider, "South");
    }
    
    public void stateChanged(ChangeEvent param1ChangeEvent) {
      this.dataset.setValue(new Integer(this.slider.getValue()));
    }
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/DialDemo3.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */