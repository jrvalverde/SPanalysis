package demo;

import java.awt.Dimension;
import java.awt.Paint;
import java.awt.Window;
import java.text.NumberFormat;
import javax.swing.JPanel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.labels.CategoryItemLabelGenerator;
import org.jfree.chart.labels.ItemLabelAnchor;
import org.jfree.chart.labels.ItemLabelPosition;
import org.jfree.chart.labels.StandardCategoryItemLabelGenerator;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.DefaultDrawingSupplier;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.renderer.category.CategoryItemRenderer;
import org.jfree.chart.renderer.category.StackedBarRenderer;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;
import org.jfree.ui.TextAnchor;

public class ItemLabelDemo5 extends ApplicationFrame {
  public ItemLabelDemo5(String paramString) {
    super(paramString);
    JPanel jPanel = createDemoPanel();
    jPanel.setPreferredSize(new Dimension(500, 270));
    setContentPane(jPanel);
  }
  
  public static CategoryDataset createDataset() {
    DefaultCategoryDataset defaultCategoryDataset = new DefaultCategoryDataset();
    defaultCategoryDataset.addValue(52.83D, "Germany", "Western EU");
    defaultCategoryDataset.addValue(20.83D, "France", "Western EU");
    defaultCategoryDataset.addValue(10.83D, "Great Britain", "Western EU");
    defaultCategoryDataset.addValue(7.33D, "Netherlands", "Western EU");
    defaultCategoryDataset.addValue(4.66D, "Belgium", "Western EU");
    defaultCategoryDataset.addValue(57.14D, "Spain", "Southern EU");
    defaultCategoryDataset.addValue(14.28D, "Greece", "Southern EU");
    defaultCategoryDataset.addValue(14.28D, "Italy", "Southern EU");
    defaultCategoryDataset.addValue(14.28D, "Portugal", "Southern EU");
    defaultCategoryDataset.addValue(100.0D, "Czech Republic", "Eastern EU");
    defaultCategoryDataset.addValue(66.66D, "Denmark", "Scandinavia");
    defaultCategoryDataset.addValue(33.33D, "Finland", "Scandinavia");
    defaultCategoryDataset.addValue(0.0D, "", "Africa");
    defaultCategoryDataset.addValue(100.0D, "Israel", "Asia");
    return (CategoryDataset)defaultCategoryDataset;
  }
  
  private static JFreeChart createChart(CategoryDataset paramCategoryDataset) {
    JFreeChart jFreeChart = ChartFactory.createStackedBarChart("Item Label Demo 5", null, null, paramCategoryDataset, PlotOrientation.VERTICAL, false, true, false);
    CategoryPlot categoryPlot = (CategoryPlot)jFreeChart.getPlot();
    MyStackedBarRenderer myStackedBarRenderer = new MyStackedBarRenderer();
    categoryPlot.setRenderer((CategoryItemRenderer)myStackedBarRenderer);
    ItemLabelPosition itemLabelPosition = new ItemLabelPosition(ItemLabelAnchor.CENTER, TextAnchor.CENTER, TextAnchor.CENTER, 0.0D);
    myStackedBarRenderer.setPositiveItemLabelPositionFallback(itemLabelPosition);
    myStackedBarRenderer.setNegativeItemLabelPositionFallback(itemLabelPosition);
    StandardCategoryItemLabelGenerator standardCategoryItemLabelGenerator = new StandardCategoryItemLabelGenerator("{0}", NumberFormat.getInstance());
    myStackedBarRenderer.setBaseItemLabelGenerator((CategoryItemLabelGenerator)standardCategoryItemLabelGenerator);
    myStackedBarRenderer.setBaseItemLabelsVisible(true);
    NumberAxis numberAxis = (NumberAxis)categoryPlot.getRangeAxis();
    numberAxis.setUpperBound(100.0D);
    ChartUtilities.applyCurrentTheme(jFreeChart);
    return jFreeChart;
  }
  
  public static JPanel createDemoPanel() {
    JFreeChart jFreeChart = createChart(createDataset());
    return (JPanel)new ChartPanel(jFreeChart);
  }
  
  public static void main(String[] paramArrayOfString) {
    ItemLabelDemo5 itemLabelDemo5 = new ItemLabelDemo5("JFreeChart: ItemLabelDemo5.java");
    itemLabelDemo5.pack();
    RefineryUtilities.centerFrameOnScreen((Window)itemLabelDemo5);
    itemLabelDemo5.setVisible(true);
  }
  
  private static class MyStackedBarRenderer extends StackedBarRenderer {
    int oldColumn = -99;
    
    int count = 0;
    
    Paint[] list = DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
    
    private MyStackedBarRenderer() {}
    
    public Paint getItemPaint(int param1Int1, int param1Int2) {
      if (this.oldColumn != param1Int2) {
        this.count = 0;
        this.oldColumn = param1Int2;
      } else {
        this.count++;
      } 
      return this.list[this.count];
    }
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/ItemLabelDemo5.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */