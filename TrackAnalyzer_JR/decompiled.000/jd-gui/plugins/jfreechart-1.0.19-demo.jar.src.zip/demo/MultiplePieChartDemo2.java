package demo;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Window;
import java.text.NumberFormat;
import javax.swing.JPanel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.labels.PieSectionLabelGenerator;
import org.jfree.chart.labels.StandardPieSectionLabelGenerator;
import org.jfree.chart.plot.MultiplePiePlot;
import org.jfree.chart.plot.PiePlot;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.general.DatasetUtilities;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;
import org.jfree.util.TableOrder;

public class MultiplePieChartDemo2 extends ApplicationFrame {
  public MultiplePieChartDemo2(String paramString) {
    super(paramString);
    CategoryDataset categoryDataset = createDataset();
    JFreeChart jFreeChart = createChart(categoryDataset);
    ChartPanel chartPanel = new ChartPanel(jFreeChart, true, true, true, false, true);
    chartPanel.setPreferredSize(new Dimension(600, 380));
    setContentPane((Container)chartPanel);
  }
  
  private static CategoryDataset createDataset() {
    double[][] arrayOfDouble = { { 3.0D, 4.0D, 3.0D, 5.0D }, { 5.0D, 7.0D, 6.0D, 8.0D }, { 5.0D, 7.0D, 3.0D, 8.0D }, { 1.0D, 2.0D, 3.0D, 4.0D }, { 2.0D, 3.0D, 2.0D, 3.0D } };
    return DatasetUtilities.createCategoryDataset("Region ", "Sales/Q", arrayOfDouble);
  }
  
  private static JFreeChart createChart(CategoryDataset paramCategoryDataset) {
    JFreeChart jFreeChart1 = ChartFactory.createMultiplePieChart("Multiple Pie Chart", paramCategoryDataset, TableOrder.BY_COLUMN, true, true, false);
    MultiplePiePlot multiplePiePlot = (MultiplePiePlot)jFreeChart1.getPlot();
    multiplePiePlot.setBackgroundPaint(Color.white);
    multiplePiePlot.setOutlineStroke(new BasicStroke(1.0F));
    JFreeChart jFreeChart2 = multiplePiePlot.getPieChart();
    PiePlot piePlot = (PiePlot)jFreeChart2.getPlot();
    piePlot.setBackgroundPaint(null);
    piePlot.setOutlineStroke(null);
    piePlot.setLabelGenerator((PieSectionLabelGenerator)new StandardPieSectionLabelGenerator("{0} ({2})", NumberFormat.getNumberInstance(), NumberFormat.getPercentInstance()));
    piePlot.setMaximumLabelWidth(0.2D);
    return jFreeChart1;
  }
  
  public static JPanel createDemoPanel() {
    JFreeChart jFreeChart = createChart(createDataset());
    return (JPanel)new ChartPanel(jFreeChart);
  }
  
  public static void main(String[] paramArrayOfString) {
    MultiplePieChartDemo2 multiplePieChartDemo2 = new MultiplePieChartDemo2("JFreeChart: MultiplePieChartDemo2.java");
    multiplePieChartDemo2.pack();
    RefineryUtilities.centerFrameOnScreen((Window)multiplePieChartDemo2);
    multiplePieChartDemo2.setVisible(true);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/MultiplePieChartDemo2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */