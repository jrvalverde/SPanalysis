package demo;

import java.awt.Dimension;
import java.awt.Window;
import javax.swing.JPanel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.AxisLocation;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYItemRenderer;
import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
import org.jfree.data.time.Minute;
import org.jfree.data.time.RegularTimePeriod;
import org.jfree.data.time.TimeSeries;
import org.jfree.data.time.TimeSeriesCollection;
import org.jfree.data.xy.XYDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

public class MultipleAxisDemo3 extends ApplicationFrame {
  public MultipleAxisDemo3(String paramString) {
    super(paramString);
    JPanel jPanel = createDemoPanel();
    jPanel.setPreferredSize(new Dimension(600, 270));
    setContentPane(jPanel);
  }
  
  private static JFreeChart createChart() {
    XYDataset xYDataset1 = createDataset("Series 1", 100.0D, (RegularTimePeriod)new Minute(), 200);
    JFreeChart jFreeChart = ChartFactory.createTimeSeriesChart("Multiple Axis Demo 3", "Time of Day", "Primary Range Axis", xYDataset1, true, true, false);
    XYPlot xYPlot = (XYPlot)jFreeChart.getPlot();
    xYPlot.setOrientation(PlotOrientation.VERTICAL);
    NumberAxis numberAxis1 = new NumberAxis("Domain Axis 2");
    numberAxis1.setAutoRangeIncludesZero(false);
    xYPlot.setDomainAxis(1, (ValueAxis)numberAxis1);
    xYPlot.setDomainAxisLocation(1, AxisLocation.BOTTOM_OR_LEFT);
    NumberAxis numberAxis2 = new NumberAxis("Domain Axis 3");
    numberAxis1.setAutoRangeIncludesZero(false);
    xYPlot.setDomainAxis(2, (ValueAxis)numberAxis2);
    xYPlot.setDomainAxisLocation(2, AxisLocation.BOTTOM_OR_LEFT);
    NumberAxis numberAxis3 = new NumberAxis("Range Axis 2");
    xYPlot.setRangeAxis(1, (ValueAxis)numberAxis3);
    xYPlot.setRangeAxisLocation(1, AxisLocation.BOTTOM_OR_RIGHT);
    XYDataset xYDataset2 = createDataset("Series 2", 1000.0D, (RegularTimePeriod)new Minute(), 170);
    xYPlot.setDataset(1, xYDataset2);
    xYPlot.mapDatasetToDomainAxis(1, 1);
    xYPlot.mapDatasetToRangeAxis(1, 1);
    xYPlot.setRenderer(1, (XYItemRenderer)new XYLineAndShapeRenderer(true, false));
    ChartUtilities.applyCurrentTheme(jFreeChart);
    return jFreeChart;
  }
  
  private static XYDataset createDataset(String paramString, double paramDouble, RegularTimePeriod paramRegularTimePeriod, int paramInt) {
    TimeSeries timeSeries = new TimeSeries(paramString);
    RegularTimePeriod regularTimePeriod = paramRegularTimePeriod;
    double d = paramDouble;
    for (byte b = 0; b < paramInt; b++) {
      timeSeries.add(regularTimePeriod, d);
      regularTimePeriod = regularTimePeriod.next();
      d *= 1.0D + (Math.random() - 0.495D) / 10.0D;
    } 
    TimeSeriesCollection timeSeriesCollection = new TimeSeriesCollection();
    timeSeriesCollection.addSeries(timeSeries);
    return (XYDataset)timeSeriesCollection;
  }
  
  public static JPanel createDemoPanel() {
    JFreeChart jFreeChart = createChart();
    return (JPanel)new ChartPanel(jFreeChart);
  }
  
  public static void main(String[] paramArrayOfString) {
    MultipleAxisDemo3 multipleAxisDemo3 = new MultipleAxisDemo3("JFreeChart: MultipleAxisDemo3.java");
    multipleAxisDemo3.pack();
    RefineryUtilities.centerFrameOnScreen((Window)multipleAxisDemo3);
    multipleAxisDemo3.setVisible(true);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/MultipleAxisDemo3.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */