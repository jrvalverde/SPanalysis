package demo;

import org.jfree.data.general.Dataset;
import org.jfree.data.general.DatasetChangeEvent;
import org.jfree.data.xy.AbstractXYDataset;
import org.jfree.data.xy.XYDataset;

public class SampleXYDataset extends AbstractXYDataset implements XYDataset {
  private double translate = 0.0D;
  
  public double getTranslate() {
    return this.translate;
  }
  
  public void setTranslate(double paramDouble) {
    this.translate = paramDouble;
    notifyListeners(new DatasetChangeEvent(this, (Dataset)this));
  }
  
  public Number getX(int paramInt1, int paramInt2) {
    return new Double(-10.0D + this.translate + paramInt2 / 10.0D);
  }
  
  public Number getY(int paramInt1, int paramInt2) {
    return (paramInt1 == 0) ? new Double(Math.cos(-10.0D + this.translate + paramInt2 / 10.0D)) : new Double(2.0D * Math.sin(-10.0D + this.translate + paramInt2 / 10.0D));
  }
  
  public int getSeriesCount() {
    return 2;
  }
  
  public Comparable getSeriesKey(int paramInt) {
    return (paramInt == 0) ? "y = cosine(x)" : ((paramInt == 1) ? "y = 2*sine(x)" : "Error");
  }
  
  public int getItemCount(int paramInt) {
    return 200;
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/SampleXYDataset.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */