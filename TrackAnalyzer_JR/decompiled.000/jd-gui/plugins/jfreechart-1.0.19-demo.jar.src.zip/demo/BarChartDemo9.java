package demo;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GradientPaint;
import java.awt.Paint;
import java.awt.Window;
import javax.swing.JPanel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.renderer.category.BarPainter;
import org.jfree.chart.renderer.category.BarRenderer;
import org.jfree.chart.renderer.category.CategoryItemRenderer;
import org.jfree.chart.renderer.category.StandardBarPainter;
import org.jfree.chart.title.TextTitle;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.GradientPaintTransformType;
import org.jfree.ui.GradientPaintTransformer;
import org.jfree.ui.RectangleInsets;
import org.jfree.ui.RefineryUtilities;
import org.jfree.ui.StandardGradientPaintTransformer;

public class BarChartDemo9 extends ApplicationFrame {
  public BarChartDemo9(String paramString) {
    super(paramString);
    JPanel jPanel = createDemoPanel();
    jPanel.setPreferredSize(new Dimension(500, 270));
    setContentPane(jPanel);
  }
  
  private static CategoryDataset createDataset() {
    DefaultCategoryDataset defaultCategoryDataset = new DefaultCategoryDataset();
    defaultCategoryDataset.addValue(410.0D, "Network Traffic", "Monday");
    defaultCategoryDataset.addValue(680.0D, "Network Traffic", "Tuesday");
    defaultCategoryDataset.addValue(530.0D, "Network Traffic", "Wednesday");
    defaultCategoryDataset.addValue(570.0D, "Network Traffic", "Thursday");
    defaultCategoryDataset.addValue(330.0D, "Network Traffic", "Friday");
    return (CategoryDataset)defaultCategoryDataset;
  }
  
  private static JFreeChart createChart(CategoryDataset paramCategoryDataset) {
    JFreeChart jFreeChart = ChartFactory.createBarChart("Bar Chart Demo 9", null, "Value", paramCategoryDataset, PlotOrientation.VERTICAL, false, true, false);
    TextTitle textTitle = jFreeChart.getTitle();
    textTitle.setBorder(0.0D, 0.0D, 1.0D, 0.0D);
    textTitle.setBackgroundPaint(new GradientPaint(0.0F, 0.0F, Color.red, 350.0F, 0.0F, Color.white, true));
    textTitle.setExpandToFitSpace(true);
    jFreeChart.setBackgroundPaint(new GradientPaint(0.0F, 0.0F, Color.yellow, 350.0F, 0.0F, Color.white, true));
    CategoryPlot categoryPlot = (CategoryPlot)jFreeChart.getPlot();
    categoryPlot.setNoDataMessage("NO DATA!");
    categoryPlot.setBackgroundPaint(null);
    categoryPlot.setInsets(new RectangleInsets(10.0D, 5.0D, 5.0D, 5.0D));
    categoryPlot.setOutlinePaint(Color.black);
    categoryPlot.setRangeGridlinePaint(Color.gray);
    categoryPlot.setRangeGridlineStroke(new BasicStroke(1.0F));
    Paint[] arrayOfPaint = createPaint();
    CustomBarRenderer customBarRenderer = new CustomBarRenderer(arrayOfPaint);
    customBarRenderer.setBarPainter((BarPainter)new StandardBarPainter());
    customBarRenderer.setDrawBarOutline(true);
    customBarRenderer.setGradientPaintTransformer((GradientPaintTransformer)new StandardGradientPaintTransformer(GradientPaintTransformType.CENTER_HORIZONTAL));
    categoryPlot.setRenderer((CategoryItemRenderer)customBarRenderer);
    NumberAxis numberAxis = (NumberAxis)categoryPlot.getRangeAxis();
    numberAxis.setStandardTickUnits(NumberAxis.createIntegerTickUnits());
    numberAxis.setRange(0.0D, 800.0D);
    numberAxis.setTickMarkPaint(Color.black);
    return jFreeChart;
  }
  
  private static Paint[] createPaint() {
    Paint[] arrayOfPaint = new Paint[5];
    arrayOfPaint[0] = new GradientPaint(0.0F, 0.0F, Color.red, 0.0F, 0.0F, Color.white);
    arrayOfPaint[1] = new GradientPaint(0.0F, 0.0F, Color.green, 0.0F, 0.0F, Color.white);
    arrayOfPaint[2] = new GradientPaint(0.0F, 0.0F, Color.blue, 0.0F, 0.0F, Color.white);
    arrayOfPaint[3] = new GradientPaint(0.0F, 0.0F, Color.orange, 0.0F, 0.0F, Color.white);
    arrayOfPaint[4] = new GradientPaint(0.0F, 0.0F, Color.magenta, 0.0F, 0.0F, Color.white);
    return arrayOfPaint;
  }
  
  public static JPanel createDemoPanel() {
    JFreeChart jFreeChart = createChart(createDataset());
    return (JPanel)new ChartPanel(jFreeChart);
  }
  
  public static void main(String[] paramArrayOfString) {
    BarChartDemo9 barChartDemo9 = new BarChartDemo9("JFreeChart: BarChartDemo9.java");
    barChartDemo9.pack();
    RefineryUtilities.centerFrameOnScreen((Window)barChartDemo9);
    barChartDemo9.setVisible(true);
  }
  
  static class CustomBarRenderer extends BarRenderer {
    private Paint[] colors;
    
    public CustomBarRenderer(Paint[] param1ArrayOfPaint) {
      this.colors = param1ArrayOfPaint;
    }
    
    public Paint getItemPaint(int param1Int1, int param1Int2) {
      return this.colors[param1Int2 % this.colors.length];
    }
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/BarChartDemo9.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */