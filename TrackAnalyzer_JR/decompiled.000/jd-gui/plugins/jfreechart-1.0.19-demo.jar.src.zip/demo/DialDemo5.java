package demo;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.Plot;
import org.jfree.chart.plot.dial.DialBackground;
import org.jfree.chart.plot.dial.DialCap;
import org.jfree.chart.plot.dial.DialFrame;
import org.jfree.chart.plot.dial.DialLayer;
import org.jfree.chart.plot.dial.DialPlot;
import org.jfree.chart.plot.dial.DialPointer;
import org.jfree.chart.plot.dial.DialScale;
import org.jfree.chart.plot.dial.StandardDialFrame;
import org.jfree.chart.plot.dial.StandardDialScale;
import org.jfree.data.general.DefaultValueDataset;
import org.jfree.data.general.ValueDataset;
import org.jfree.ui.GradientPaintTransformType;
import org.jfree.ui.GradientPaintTransformer;
import org.jfree.ui.StandardGradientPaintTransformer;

public class DialDemo5 extends JFrame {
  public DialDemo5(String paramString) {
    super(paramString);
    setDefaultCloseOperation(3);
    setContentPane(createDemoPanel());
  }
  
  public static JPanel createDemoPanel() {
    return new DemoPanel();
  }
  
  public static void main(String[] paramArrayOfString) {
    DialDemo5 dialDemo5 = new DialDemo5("JFreeChart: DialDemo5.java");
    dialDemo5.pack();
    dialDemo5.setVisible(true);
  }
  
  static class DemoPanel extends JPanel implements ChangeListener {
    DefaultValueDataset hoursDataset = new DefaultValueDataset(6.0D);
    
    DefaultValueDataset dataset2 = new DefaultValueDataset(15.0D);
    
    JSlider slider1;
    
    JSlider slider2;
    
    public DemoPanel() {
      super(new BorderLayout());
      DialPlot dialPlot = new DialPlot();
      dialPlot.setView(0.0D, 0.0D, 1.0D, 1.0D);
      dialPlot.setDataset(0, (ValueDataset)this.hoursDataset);
      dialPlot.setDataset(1, (ValueDataset)this.dataset2);
      StandardDialFrame standardDialFrame = new StandardDialFrame();
      standardDialFrame.setBackgroundPaint(Color.lightGray);
      standardDialFrame.setForegroundPaint(Color.darkGray);
      dialPlot.setDialFrame((DialFrame)standardDialFrame);
      DialBackground dialBackground = new DialBackground(Color.white);
      dialBackground.setGradientPaintTransformer((GradientPaintTransformer)new StandardGradientPaintTransformer(GradientPaintTransformType.VERTICAL));
      dialPlot.setBackground((DialLayer)dialBackground);
      StandardDialScale standardDialScale1 = new StandardDialScale(0.0D, 12.0D, 90.0D, -360.0D, 10.0D, 4);
      standardDialScale1.setFirstTickLabelVisible(false);
      standardDialScale1.setMajorTickIncrement(1.0D);
      standardDialScale1.setTickRadius(0.88D);
      standardDialScale1.setTickLabelOffset(0.15D);
      standardDialScale1.setTickLabelFont(new Font("Dialog", 0, 14));
      dialPlot.addScale(0, (DialScale)standardDialScale1);
      StandardDialScale standardDialScale2 = new StandardDialScale(0.0D, 60.0D, 90.0D, -360.0D, 10.0D, 4);
      standardDialScale2.setVisible(false);
      standardDialScale2.setMajorTickIncrement(5.0D);
      standardDialScale2.setTickRadius(0.68D);
      standardDialScale2.setTickLabelOffset(0.15D);
      standardDialScale2.setTickLabelFont(new Font("Dialog", 0, 14));
      dialPlot.addScale(1, (DialScale)standardDialScale2);
      DialPointer.Pointer pointer1 = new DialPointer.Pointer(0);
      pointer1.setRadius(0.55D);
      dialPlot.addLayer((DialLayer)pointer1);
      dialPlot.mapDatasetToScale(1, 1);
      DialPointer.Pointer pointer2 = new DialPointer.Pointer(1);
      dialPlot.addLayer((DialLayer)pointer2);
      DialCap dialCap = new DialCap();
      dialCap.setRadius(0.1D);
      dialPlot.setCap((DialLayer)dialCap);
      JFreeChart jFreeChart = new JFreeChart((Plot)dialPlot);
      jFreeChart.setTitle("Dial Demo 5");
      ChartPanel chartPanel = new ChartPanel(jFreeChart);
      chartPanel.setPreferredSize(new Dimension(400, 400));
      JPanel jPanel = new JPanel(new GridLayout(2, 2));
      jPanel.add(new JLabel("Hours:"));
      jPanel.add(new JLabel("Minutes:"));
      this.slider1 = new JSlider(0, 12);
      this.slider1.setMajorTickSpacing(2);
      this.slider1.setPaintTicks(true);
      this.slider1.setPaintLabels(true);
      this.slider1.addChangeListener(this);
      jPanel.add(this.slider1);
      jPanel.add(this.slider1);
      this.slider2 = new JSlider(0, 60);
      this.slider2.setValue(15);
      this.slider2.setMajorTickSpacing(10);
      this.slider2.setPaintTicks(true);
      this.slider2.setPaintLabels(true);
      this.slider2.addChangeListener(this);
      jPanel.add(this.slider2);
      add((Component)chartPanel);
      add(jPanel, "South");
    }
    
    public void stateChanged(ChangeEvent param1ChangeEvent) {
      this.hoursDataset.setValue(new Integer(this.slider1.getValue()));
      this.dataset2.setValue(new Integer(this.slider2.getValue()));
    }
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/DialDemo5.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */