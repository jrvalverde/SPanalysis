package demo;

import java.awt.Dimension;
import java.awt.Window;
import javax.swing.JPanel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PiePlot3D;
import org.jfree.data.general.DefaultPieDataset;
import org.jfree.data.general.PieDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;
import org.jfree.util.Rotation;

public class PieChart3DDemo2 extends ApplicationFrame {
  public PieChart3DDemo2(String paramString) {
    super(paramString);
    JPanel jPanel = createDemoPanel();
    jPanel.setPreferredSize(new Dimension(500, 270));
    setContentPane(jPanel);
  }
  
  private static JFreeChart createChart(PieDataset paramPieDataset) {
    JFreeChart jFreeChart = ChartFactory.createPieChart3D("Pie Chart 3D Demo 2", paramPieDataset, true, false, false);
    PiePlot3D piePlot3D = (PiePlot3D)jFreeChart.getPlot();
    piePlot3D.setStartAngle(270.0D);
    piePlot3D.setDirection(Rotation.ANTICLOCKWISE);
    piePlot3D.setForegroundAlpha(0.6F);
    return jFreeChart;
  }
  
  private static PieDataset createDataset() {
    DefaultPieDataset defaultPieDataset = new DefaultPieDataset();
    defaultPieDataset.setValue("Java", new Double(43.2D));
    defaultPieDataset.setValue("Visual Basic", new Double(10.0D));
    defaultPieDataset.setValue("C/C++", new Double(17.5D));
    defaultPieDataset.setValue("PHP", new Double(32.5D));
    defaultPieDataset.setValue("Perl", new Double(12.5D));
    return (PieDataset)defaultPieDataset;
  }
  
  public static JPanel createDemoPanel() {
    JFreeChart jFreeChart = createChart(createDataset());
    Rotator rotator = new Rotator((PiePlot3D)jFreeChart.getPlot());
    rotator.start();
    return (JPanel)new ChartPanel(jFreeChart);
  }
  
  public static void main(String[] paramArrayOfString) {
    PieChart3DDemo2 pieChart3DDemo2 = new PieChart3DDemo2("JFreeChart: PieChart3DDemo2.java");
    pieChart3DDemo2.pack();
    RefineryUtilities.centerFrameOnScreen((Window)pieChart3DDemo2);
    pieChart3DDemo2.setVisible(true);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/PieChart3DDemo2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */