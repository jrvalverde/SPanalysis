package demo;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Window;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.MeterInterval;
import org.jfree.chart.plot.MeterPlot;
import org.jfree.chart.plot.Plot;
import org.jfree.data.Range;
import org.jfree.data.general.DefaultValueDataset;
import org.jfree.data.general.ValueDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

public class MeterChartDemo2 extends ApplicationFrame {
  private static DefaultValueDataset dataset;
  
  public MeterChartDemo2(String paramString) {
    super(paramString);
    JPanel jPanel = createDemoPanel();
    jPanel.setPreferredSize(new Dimension(500, 270));
    setContentPane(jPanel);
  }
  
  private static JFreeChart createChart(ValueDataset paramValueDataset) {
    MeterPlot meterPlot = new MeterPlot(paramValueDataset);
    meterPlot.addInterval(new MeterInterval("High", new Range(80.0D, 100.0D)));
    meterPlot.setDialOutlinePaint(Color.white);
    JFreeChart jFreeChart = new JFreeChart("Meter Chart 2", JFreeChart.DEFAULT_TITLE_FONT, (Plot)meterPlot, false);
    ChartUtilities.applyCurrentTheme(jFreeChart);
    return jFreeChart;
  }
  
  public static JPanel createDemoPanel() {
    dataset = new DefaultValueDataset(50.0D);
    JFreeChart jFreeChart = createChart((ValueDataset)dataset);
    JPanel jPanel = new JPanel(new BorderLayout());
    JSlider jSlider = new JSlider(-10, 110, 50);
    jSlider.setMajorTickSpacing(10);
    jSlider.setMinorTickSpacing(5);
    jSlider.setPaintLabels(true);
    jSlider.setPaintTicks(true);
    jSlider.addChangeListener(new ChangeListener() {
          public void stateChanged(ChangeEvent param1ChangeEvent) {
            JSlider jSlider = (JSlider)param1ChangeEvent.getSource();
            MeterChartDemo2.dataset.setValue(new Integer(jSlider.getValue()));
          }
        });
    jPanel.add((Component)new ChartPanel(jFreeChart));
    jPanel.add("South", jSlider);
    return jPanel;
  }
  
  public static void main(String[] paramArrayOfString) {
    MeterChartDemo2 meterChartDemo2 = new MeterChartDemo2("JFreeChart: MeterChartDemo2.java");
    meterChartDemo2.pack();
    RefineryUtilities.centerFrameOnScreen((Window)meterChartDemo2);
    meterChartDemo2.setVisible(true);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/MeterChartDemo2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */