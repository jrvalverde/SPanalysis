package demo;

import java.awt.Dimension;
import java.awt.Window;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import javax.swing.JPanel;
import org.jfree.chart.ChartMouseEvent;
import org.jfree.chart.ChartMouseListener;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.DateAxis;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.labels.StandardXYToolTipGenerator;
import org.jfree.chart.labels.XYToolTipGenerator;
import org.jfree.chart.plot.CombinedRangeXYPlot;
import org.jfree.chart.plot.DatasetRenderingOrder;
import org.jfree.chart.plot.Plot;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.StandardXYItemRenderer;
import org.jfree.chart.renderer.xy.XYAreaRenderer;
import org.jfree.chart.renderer.xy.XYBarRenderer;
import org.jfree.chart.renderer.xy.XYItemRenderer;
import org.jfree.data.time.Month;
import org.jfree.data.time.RegularTimePeriod;
import org.jfree.data.time.TimeSeries;
import org.jfree.data.time.TimeSeriesCollection;
import org.jfree.data.time.Year;
import org.jfree.data.xy.XYDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

public class CombinedTimeSeriesDemo1 extends ApplicationFrame {
  public CombinedTimeSeriesDemo1(String paramString) {
    super(paramString);
    setContentPane(createDemoPanel());
  }
  
  public static JPanel createDemoPanel() {
    TimeSeries timeSeries1 = new TimeSeries("Annual");
    timeSeries1.add((RegularTimePeriod)new Year(1998), 80.0D);
    timeSeries1.add((RegularTimePeriod)new Year(1999), 85.0D);
    timeSeries1.add((RegularTimePeriod)new Year(2000), 87.6D);
    TimeSeriesCollection timeSeriesCollection1 = new TimeSeriesCollection(timeSeries1);
    TimeSeries timeSeries2 = new TimeSeries("Monthly A");
    timeSeries2.add((RegularTimePeriod)new Month(7, 2000), 85.8D);
    timeSeries2.add((RegularTimePeriod)new Month(8, 2000), 85.8D);
    timeSeries2.add((RegularTimePeriod)new Month(9, 2000), 85.8D);
    timeSeries2.add((RegularTimePeriod)new Month(10, 2000), 86.5D);
    timeSeries2.add((RegularTimePeriod)new Month(11, 2000), 86.5D);
    timeSeries2.add((RegularTimePeriod)new Month(12, 2000), 86.5D);
    timeSeries2.add((RegularTimePeriod)new Month(1, 2001), 87.7D);
    timeSeries2.add((RegularTimePeriod)new Month(2, 2001), 87.7D);
    timeSeries2.add((RegularTimePeriod)new Month(3, 2001), 87.7D);
    timeSeries2.add((RegularTimePeriod)new Month(4, 2001), 88.5D);
    timeSeries2.add((RegularTimePeriod)new Month(5, 2001), 88.5D);
    timeSeries2.add((RegularTimePeriod)new Month(6, 2001), 88.5D);
    timeSeries2.add((RegularTimePeriod)new Month(7, 2001), 90.0D);
    timeSeries2.add((RegularTimePeriod)new Month(8, 2001), 90.0D);
    timeSeries2.add((RegularTimePeriod)new Month(9, 2001), 90.0D);
    timeSeries2.add((RegularTimePeriod)new Month(10, 2001), 90.0D);
    timeSeries2.add((RegularTimePeriod)new Month(11, 2001), 90.0D);
    timeSeries2.add((RegularTimePeriod)new Month(12, 2001), 90.0D);
    timeSeries2.add((RegularTimePeriod)new Month(1, 2002), 90.0D);
    timeSeries2.add((RegularTimePeriod)new Month(2, 2002), 90.0D);
    timeSeries2.add((RegularTimePeriod)new Month(3, 2002), 90.0D);
    timeSeries2.add((RegularTimePeriod)new Month(4, 2002), 90.0D);
    timeSeries2.add((RegularTimePeriod)new Month(5, 2002), 90.0D);
    timeSeries2.add((RegularTimePeriod)new Month(6, 2002), 90.0D);
    TimeSeries timeSeries3 = new TimeSeries("Monthly B");
    timeSeries3.add((RegularTimePeriod)new Month(7, 2000), 83.8D);
    timeSeries3.add((RegularTimePeriod)new Month(8, 2000), 83.8D);
    timeSeries3.add((RegularTimePeriod)new Month(9, 2000), 83.8D);
    timeSeries3.add((RegularTimePeriod)new Month(10, 2000), 84.5D);
    timeSeries3.add((RegularTimePeriod)new Month(11, 2000), 84.5D);
    timeSeries3.add((RegularTimePeriod)new Month(12, 2000), 84.5D);
    timeSeries3.add((RegularTimePeriod)new Month(1, 2001), 85.7D);
    timeSeries3.add((RegularTimePeriod)new Month(2, 2001), 85.7D);
    timeSeries3.add((RegularTimePeriod)new Month(3, 2001), 85.7D);
    timeSeries3.add((RegularTimePeriod)new Month(4, 2001), 86.5D);
    timeSeries3.add((RegularTimePeriod)new Month(5, 2001), 86.5D);
    timeSeries3.add((RegularTimePeriod)new Month(6, 2001), 86.5D);
    timeSeries3.add((RegularTimePeriod)new Month(7, 2001), 88.0D);
    timeSeries3.add((RegularTimePeriod)new Month(8, 2001), 88.0D);
    timeSeries3.add((RegularTimePeriod)new Month(9, 2001), 88.0D);
    timeSeries3.add((RegularTimePeriod)new Month(10, 2001), 88.0D);
    timeSeries3.add((RegularTimePeriod)new Month(11, 2001), 88.0D);
    timeSeries3.add((RegularTimePeriod)new Month(12, 2001), 88.0D);
    timeSeries3.add((RegularTimePeriod)new Month(1, 2002), 88.0D);
    timeSeries3.add((RegularTimePeriod)new Month(2, 2002), 88.0D);
    timeSeries3.add((RegularTimePeriod)new Month(3, 2002), 88.0D);
    timeSeries3.add((RegularTimePeriod)new Month(4, 2002), 88.0D);
    timeSeries3.add((RegularTimePeriod)new Month(5, 2002), 88.0D);
    timeSeries3.add((RegularTimePeriod)new Month(6, 2002), 88.0D);
    TimeSeriesCollection timeSeriesCollection2 = new TimeSeriesCollection();
    timeSeriesCollection2.addSeries(timeSeries2);
    timeSeriesCollection2.addSeries(timeSeries3);
    TimeSeries timeSeries4 = new TimeSeries("XXX");
    timeSeries4.add((RegularTimePeriod)new Month(7, 2000), 81.5D);
    timeSeries4.add((RegularTimePeriod)new Month(8, 2000), 86.0D);
    timeSeries4.add((RegularTimePeriod)new Month(9, 2000), 82.0D);
    timeSeries4.add((RegularTimePeriod)new Month(10, 2000), 89.5D);
    timeSeries4.add((RegularTimePeriod)new Month(11, 2000), 88.0D);
    timeSeries4.add((RegularTimePeriod)new Month(12, 2000), 88.0D);
    timeSeries4.add((RegularTimePeriod)new Month(1, 2001), 90.0D);
    timeSeries4.add((RegularTimePeriod)new Month(2, 2001), 89.5D);
    timeSeries4.add((RegularTimePeriod)new Month(3, 2001), 90.2D);
    timeSeries4.add((RegularTimePeriod)new Month(4, 2001), 90.6D);
    timeSeries4.add((RegularTimePeriod)new Month(5, 2001), 87.5D);
    timeSeries4.add((RegularTimePeriod)new Month(6, 2001), 91.0D);
    timeSeries4.add((RegularTimePeriod)new Month(7, 2001), 89.7D);
    timeSeries4.add((RegularTimePeriod)new Month(8, 2001), 87.0D);
    timeSeries4.add((RegularTimePeriod)new Month(9, 2001), 91.2D);
    timeSeries4.add((RegularTimePeriod)new Month(10, 2001), 84.0D);
    timeSeries4.add((RegularTimePeriod)new Month(11, 2001), 90.0D);
    timeSeries4.add((RegularTimePeriod)new Month(12, 2001), 92.0D);
    TimeSeriesCollection timeSeriesCollection3 = new TimeSeriesCollection(timeSeries4);
    XYBarRenderer xYBarRenderer = new XYBarRenderer(0.2D);
    xYBarRenderer.setBaseToolTipGenerator((XYToolTipGenerator)new StandardXYToolTipGenerator("{0} ({1}, {2})", new SimpleDateFormat("yyyy"), new DecimalFormat("0.00")));
    XYPlot xYPlot1 = new XYPlot((XYDataset)timeSeriesCollection1, (ValueAxis)new DateAxis("Date"), null, (XYItemRenderer)xYBarRenderer);
    XYAreaRenderer xYAreaRenderer = new XYAreaRenderer();
    XYPlot xYPlot2 = new XYPlot((XYDataset)timeSeriesCollection2, (ValueAxis)new DateAxis("Date"), null, (XYItemRenderer)xYAreaRenderer);
    StandardXYItemRenderer standardXYItemRenderer = new StandardXYItemRenderer(3);
    standardXYItemRenderer.setBaseShapesFilled(true);
    xYPlot2.setDataset(1, (XYDataset)timeSeriesCollection3);
    xYPlot2.setRenderer(1, (XYItemRenderer)standardXYItemRenderer);
    xYPlot2.setDatasetRenderingOrder(DatasetRenderingOrder.FORWARD);
    NumberAxis numberAxis = new NumberAxis("Value");
    numberAxis.setAutoRangeIncludesZero(false);
    CombinedRangeXYPlot combinedRangeXYPlot = new CombinedRangeXYPlot((ValueAxis)numberAxis);
    combinedRangeXYPlot.add(xYPlot1, 1);
    combinedRangeXYPlot.add(xYPlot2, 4);
    JFreeChart jFreeChart = new JFreeChart("Sample Combined Plot", JFreeChart.DEFAULT_TITLE_FONT, (Plot)combinedRangeXYPlot, true);
    ChartUtilities.applyCurrentTheme(jFreeChart);
    ChartPanel chartPanel = new ChartPanel(jFreeChart);
    chartPanel.setPreferredSize(new Dimension(500, 270));
    chartPanel.addChartMouseListener(new ChartMouseListener() {
          public void chartMouseClicked(ChartMouseEvent param1ChartMouseEvent) {
            System.out.println(param1ChartMouseEvent.getEntity());
          }
          
          public void chartMouseMoved(ChartMouseEvent param1ChartMouseEvent) {
            System.out.println(param1ChartMouseEvent.getEntity());
          }
        });
    return (JPanel)chartPanel;
  }
  
  public static void main(String[] paramArrayOfString) {
    CombinedTimeSeriesDemo1 combinedTimeSeriesDemo1 = new CombinedTimeSeriesDemo1("JFreeChart: CombinedTimeSeriesDemo1.java");
    combinedTimeSeriesDemo1.pack();
    RefineryUtilities.centerFrameOnScreen((Window)combinedTimeSeriesDemo1);
    combinedTimeSeriesDemo1.setVisible(true);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/CombinedTimeSeriesDemo1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */