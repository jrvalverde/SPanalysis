package demo;

import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.io.File;
import java.io.IOException;
import org.jfree.chart.JFreeChart;
import org.jfree.graphics2d.canvas.CanvasGraphics2D;
import org.jfree.graphics2d.canvas.CanvasUtils;
import org.jfree.ui.RectangleInsets;

public class CanvasExportTask implements Runnable {
  JFreeChart chart;
  
  int width;
  
  int height;
  
  File file;
  
  public CanvasExportTask(JFreeChart paramJFreeChart, int paramInt1, int paramInt2, File paramFile) {
    this.chart = paramJFreeChart;
    this.file = paramFile;
    this.width = paramInt1;
    this.height = paramInt2;
    paramJFreeChart.setBorderVisible(true);
    paramJFreeChart.setPadding(new RectangleInsets(2.0D, 2.0D, 2.0D, 2.0D));
  }
  
  public void run() {
    try {
      CanvasGraphics2D canvasGraphics2D = new CanvasGraphics2D("canvas1");
      this.chart.draw((Graphics2D)canvasGraphics2D, new Rectangle(this.width, this.height));
      CanvasUtils.writeToHTML(this.file, "", canvasGraphics2D.getCanvasID(), this.width, this.height, canvasGraphics2D.getScript() + "\n");
    } catch (IOException iOException) {
      throw new RuntimeException(iOException);
    } 
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/CanvasExportTask.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */