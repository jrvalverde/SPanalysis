package demo;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Window;
import java.text.SimpleDateFormat;
import javax.swing.JPanel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.DateAxis;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYItemRenderer;
import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
import org.jfree.data.time.Month;
import org.jfree.data.time.MovingAverage;
import org.jfree.data.time.RegularTimePeriod;
import org.jfree.data.time.TimeSeries;
import org.jfree.data.time.TimeSeriesCollection;
import org.jfree.data.xy.XYDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

public class MovingAverageDemo1 extends ApplicationFrame {
  public MovingAverageDemo1(String paramString) {
    super(paramString);
    JPanel jPanel = createDemoPanel();
    jPanel.setPreferredSize(new Dimension(500, 270));
    setContentPane(jPanel);
  }
  
  public static XYDataset createDataset() {
    TimeSeries timeSeries1 = new TimeSeries("L&G European Index Trust");
    timeSeries1.add((RegularTimePeriod)new Month(2, 2001), 181.8D);
    timeSeries1.add((RegularTimePeriod)new Month(3, 2001), 167.3D);
    timeSeries1.add((RegularTimePeriod)new Month(4, 2001), 153.8D);
    timeSeries1.add((RegularTimePeriod)new Month(5, 2001), 167.6D);
    timeSeries1.add((RegularTimePeriod)new Month(6, 2001), 158.8D);
    timeSeries1.add((RegularTimePeriod)new Month(7, 2001), 148.3D);
    timeSeries1.add((RegularTimePeriod)new Month(8, 2001), 153.9D);
    timeSeries1.add((RegularTimePeriod)new Month(9, 2001), 142.7D);
    timeSeries1.add((RegularTimePeriod)new Month(10, 2001), 123.2D);
    timeSeries1.add((RegularTimePeriod)new Month(11, 2001), 131.8D);
    timeSeries1.add((RegularTimePeriod)new Month(12, 2001), 139.6D);
    timeSeries1.add((RegularTimePeriod)new Month(1, 2002), 142.9D);
    timeSeries1.add((RegularTimePeriod)new Month(2, 2002), 138.7D);
    timeSeries1.add((RegularTimePeriod)new Month(3, 2002), 137.3D);
    timeSeries1.add((RegularTimePeriod)new Month(4, 2002), 143.9D);
    timeSeries1.add((RegularTimePeriod)new Month(5, 2002), 139.8D);
    timeSeries1.add((RegularTimePeriod)new Month(6, 2002), 137.0D);
    timeSeries1.add((RegularTimePeriod)new Month(7, 2002), 132.8D);
    TimeSeries timeSeries2 = MovingAverage.createMovingAverage(timeSeries1, "Six Month Moving Average", 6, 0);
    TimeSeriesCollection timeSeriesCollection = new TimeSeriesCollection();
    timeSeriesCollection.addSeries(timeSeries1);
    timeSeriesCollection.addSeries(timeSeries2);
    return (XYDataset)timeSeriesCollection;
  }
  
  public static JFreeChart createChart(XYDataset paramXYDataset) {
    String str = "Legal & General Unit Trust Prices";
    JFreeChart jFreeChart = ChartFactory.createTimeSeriesChart(str, "Date", "Price Per Unit", paramXYDataset, true, true, false);
    XYPlot xYPlot = (XYPlot)jFreeChart.getPlot();
    XYItemRenderer xYItemRenderer = xYPlot.getRenderer();
    if (xYItemRenderer instanceof XYLineAndShapeRenderer) {
      XYLineAndShapeRenderer xYLineAndShapeRenderer = (XYLineAndShapeRenderer)xYItemRenderer;
      xYLineAndShapeRenderer.setBaseShapesVisible(false);
      xYLineAndShapeRenderer.setSeriesShapesVisible(0, true);
      xYLineAndShapeRenderer.setUseFillPaint(true);
      xYLineAndShapeRenderer.setBaseFillPaint(Color.white);
    } 
    DateAxis dateAxis = (DateAxis)xYPlot.getDomainAxis();
    dateAxis.setDateFormatOverride(new SimpleDateFormat("MMM-yyyy"));
    return jFreeChart;
  }
  
  public static JPanel createDemoPanel() {
    JFreeChart jFreeChart = createChart(createDataset());
    ChartPanel chartPanel = new ChartPanel(jFreeChart);
    chartPanel.setMouseWheelEnabled(true);
    return (JPanel)chartPanel;
  }
  
  public static void main(String[] paramArrayOfString) {
    MovingAverageDemo1 movingAverageDemo1 = new MovingAverageDemo1("JFreeChart: MovingAverageDemo1.java");
    movingAverageDemo1.pack();
    RefineryUtilities.centerFrameOnScreen((Window)movingAverageDemo1);
    movingAverageDemo1.setVisible(true);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/MovingAverageDemo1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */