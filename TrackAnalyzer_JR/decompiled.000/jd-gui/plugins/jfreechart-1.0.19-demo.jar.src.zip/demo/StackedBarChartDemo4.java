package demo;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GradientPaint;
import java.awt.Window;
import javax.swing.JPanel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.LegendItem;
import org.jfree.chart.LegendItemCollection;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.SubCategoryAxis;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.Plot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.renderer.category.CategoryItemRenderer;
import org.jfree.chart.renderer.category.GroupedStackedBarRenderer;
import org.jfree.data.KeyToGroupMap;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.GradientPaintTransformType;
import org.jfree.ui.GradientPaintTransformer;
import org.jfree.ui.RefineryUtilities;
import org.jfree.ui.StandardGradientPaintTransformer;

public class StackedBarChartDemo4 extends ApplicationFrame {
  public StackedBarChartDemo4(String paramString) {
    super(paramString);
    JPanel jPanel = createDemoPanel();
    jPanel.setPreferredSize(new Dimension(590, 350));
    setContentPane(jPanel);
  }
  
  private static CategoryDataset createDataset() {
    DefaultCategoryDataset defaultCategoryDataset = new DefaultCategoryDataset();
    defaultCategoryDataset.addValue(20.3D, "Product 1 (US)", "Jan 04");
    defaultCategoryDataset.addValue(27.2D, "Product 1 (US)", "Feb 04");
    defaultCategoryDataset.addValue(19.7D, "Product 1 (US)", "Mar 04");
    defaultCategoryDataset.addValue(19.4D, "Product 1 (Europe)", "Jan 04");
    defaultCategoryDataset.addValue(10.9D, "Product 1 (Europe)", "Feb 04");
    defaultCategoryDataset.addValue(18.4D, "Product 1 (Europe)", "Mar 04");
    defaultCategoryDataset.addValue(16.5D, "Product 1 (Asia)", "Jan 04");
    defaultCategoryDataset.addValue(15.9D, "Product 1 (Asia)", "Feb 04");
    defaultCategoryDataset.addValue(16.1D, "Product 1 (Asia)", "Mar 04");
    defaultCategoryDataset.addValue(13.2D, "Product 1 (Middle East)", "Jan 04");
    defaultCategoryDataset.addValue(14.4D, "Product 1 (Middle East)", "Feb 04");
    defaultCategoryDataset.addValue(13.7D, "Product 1 (Middle East)", "Mar 04");
    defaultCategoryDataset.addValue(23.3D, "Product 2 (US)", "Jan 04");
    defaultCategoryDataset.addValue(16.2D, "Product 2 (US)", "Feb 04");
    defaultCategoryDataset.addValue(28.7D, "Product 2 (US)", "Mar 04");
    defaultCategoryDataset.addValue(12.7D, "Product 2 (Europe)", "Jan 04");
    defaultCategoryDataset.addValue(17.9D, "Product 2 (Europe)", "Feb 04");
    defaultCategoryDataset.addValue(12.6D, "Product 2 (Europe)", "Mar 04");
    defaultCategoryDataset.addValue(15.4D, "Product 2 (Asia)", "Jan 04");
    defaultCategoryDataset.addValue(21.0D, "Product 2 (Asia)", "Feb 04");
    defaultCategoryDataset.addValue(11.1D, "Product 2 (Asia)", "Mar 04");
    defaultCategoryDataset.addValue(23.8D, "Product 2 (Middle East)", "Jan 04");
    defaultCategoryDataset.addValue(23.4D, "Product 2 (Middle East)", "Feb 04");
    defaultCategoryDataset.addValue(19.3D, "Product 2 (Middle East)", "Mar 04");
    defaultCategoryDataset.addValue(11.9D, "Product 3 (US)", "Jan 04");
    defaultCategoryDataset.addValue(31.0D, "Product 3 (US)", "Feb 04");
    defaultCategoryDataset.addValue(22.7D, "Product 3 (US)", "Mar 04");
    defaultCategoryDataset.addValue(15.3D, "Product 3 (Europe)", "Jan 04");
    defaultCategoryDataset.addValue(14.4D, "Product 3 (Europe)", "Feb 04");
    defaultCategoryDataset.addValue(25.3D, "Product 3 (Europe)", "Mar 04");
    defaultCategoryDataset.addValue(23.9D, "Product 3 (Asia)", "Jan 04");
    defaultCategoryDataset.addValue(19.0D, "Product 3 (Asia)", "Feb 04");
    defaultCategoryDataset.addValue(10.1D, "Product 3 (Asia)", "Mar 04");
    defaultCategoryDataset.addValue(13.2D, "Product 3 (Middle East)", "Jan 04");
    defaultCategoryDataset.addValue(15.5D, "Product 3 (Middle East)", "Feb 04");
    defaultCategoryDataset.addValue(10.1D, "Product 3 (Middle East)", "Mar 04");
    return (CategoryDataset)defaultCategoryDataset;
  }
  
  private static JFreeChart createChart(CategoryDataset paramCategoryDataset) {
    JFreeChart jFreeChart = ChartFactory.createStackedBarChart("Stacked Bar Chart Demo 4", "Category", "Value", paramCategoryDataset, PlotOrientation.VERTICAL, true, true, false);
    GroupedStackedBarRenderer groupedStackedBarRenderer = new GroupedStackedBarRenderer();
    KeyToGroupMap keyToGroupMap = new KeyToGroupMap("G1");
    keyToGroupMap.mapKeyToGroup("Product 1 (US)", "G1");
    keyToGroupMap.mapKeyToGroup("Product 1 (Europe)", "G1");
    keyToGroupMap.mapKeyToGroup("Product 1 (Asia)", "G1");
    keyToGroupMap.mapKeyToGroup("Product 1 (Middle East)", "G1");
    keyToGroupMap.mapKeyToGroup("Product 2 (US)", "G2");
    keyToGroupMap.mapKeyToGroup("Product 2 (Europe)", "G2");
    keyToGroupMap.mapKeyToGroup("Product 2 (Asia)", "G2");
    keyToGroupMap.mapKeyToGroup("Product 2 (Middle East)", "G2");
    keyToGroupMap.mapKeyToGroup("Product 3 (US)", "G3");
    keyToGroupMap.mapKeyToGroup("Product 3 (Europe)", "G3");
    keyToGroupMap.mapKeyToGroup("Product 3 (Asia)", "G3");
    keyToGroupMap.mapKeyToGroup("Product 3 (Middle East)", "G3");
    groupedStackedBarRenderer.setSeriesToGroupMap(keyToGroupMap);
    groupedStackedBarRenderer.setItemMargin(0.1D);
    groupedStackedBarRenderer.setDrawBarOutline(false);
    SubCategoryAxis subCategoryAxis = new SubCategoryAxis("Product / Month");
    subCategoryAxis.setCategoryMargin(0.05D);
    subCategoryAxis.addSubCategory("Product 1");
    subCategoryAxis.addSubCategory("Product 2");
    subCategoryAxis.addSubCategory("Product 3");
    CategoryPlot categoryPlot = (CategoryPlot)jFreeChart.getPlot();
    categoryPlot.setDomainAxis((CategoryAxis)subCategoryAxis);
    categoryPlot.setRenderer((CategoryItemRenderer)groupedStackedBarRenderer);
    categoryPlot.setFixedLegendItems(createLegendItems());
    ChartUtilities.applyCurrentTheme(jFreeChart);
    subCategoryAxis.setSubLabelFont(new Font("Tahoma", 2, 10));
    GradientPaint gradientPaint1 = new GradientPaint(0.0F, 0.0F, new Color(34, 34, 255), 0.0F, 0.0F, new Color(136, 136, 255));
    groupedStackedBarRenderer.setSeriesPaint(0, gradientPaint1);
    groupedStackedBarRenderer.setSeriesPaint(4, gradientPaint1);
    groupedStackedBarRenderer.setSeriesPaint(8, gradientPaint1);
    GradientPaint gradientPaint2 = new GradientPaint(0.0F, 0.0F, new Color(34, 255, 34), 0.0F, 0.0F, new Color(136, 255, 136));
    groupedStackedBarRenderer.setSeriesPaint(1, gradientPaint2);
    groupedStackedBarRenderer.setSeriesPaint(5, gradientPaint2);
    groupedStackedBarRenderer.setSeriesPaint(9, gradientPaint2);
    GradientPaint gradientPaint3 = new GradientPaint(0.0F, 0.0F, new Color(255, 34, 34), 0.0F, 0.0F, new Color(255, 136, 136));
    groupedStackedBarRenderer.setSeriesPaint(2, gradientPaint3);
    groupedStackedBarRenderer.setSeriesPaint(6, gradientPaint3);
    groupedStackedBarRenderer.setSeriesPaint(10, gradientPaint3);
    GradientPaint gradientPaint4 = new GradientPaint(0.0F, 0.0F, new Color(255, 255, 34), 0.0F, 0.0F, new Color(255, 255, 136));
    groupedStackedBarRenderer.setSeriesPaint(3, gradientPaint4);
    groupedStackedBarRenderer.setSeriesPaint(7, gradientPaint4);
    groupedStackedBarRenderer.setSeriesPaint(11, gradientPaint4);
    groupedStackedBarRenderer.setGradientPaintTransformer((GradientPaintTransformer)new StandardGradientPaintTransformer(GradientPaintTransformType.HORIZONTAL));
    return jFreeChart;
  }
  
  private static LegendItemCollection createLegendItems() {
    LegendItemCollection legendItemCollection = new LegendItemCollection();
    LegendItem legendItem1 = new LegendItem("US", "-", null, null, Plot.DEFAULT_LEGEND_ITEM_BOX, new Color(34, 34, 255));
    LegendItem legendItem2 = new LegendItem("Europe", "-", null, null, Plot.DEFAULT_LEGEND_ITEM_BOX, new Color(34, 255, 34));
    LegendItem legendItem3 = new LegendItem("Asia", "-", null, null, Plot.DEFAULT_LEGEND_ITEM_BOX, new Color(255, 34, 34));
    LegendItem legendItem4 = new LegendItem("Middle East", "-", null, null, Plot.DEFAULT_LEGEND_ITEM_BOX, new Color(255, 255, 34));
    legendItemCollection.add(legendItem1);
    legendItemCollection.add(legendItem2);
    legendItemCollection.add(legendItem3);
    legendItemCollection.add(legendItem4);
    return legendItemCollection;
  }
  
  public static JPanel createDemoPanel() {
    JFreeChart jFreeChart = createChart(createDataset());
    return (JPanel)new ChartPanel(jFreeChart);
  }
  
  public static void main(String[] paramArrayOfString) {
    StackedBarChartDemo4 stackedBarChartDemo4 = new StackedBarChartDemo4("Stacked Bar Chart Demo 4");
    stackedBarChartDemo4.pack();
    RefineryUtilities.centerFrameOnScreen((Window)stackedBarChartDemo4);
    stackedBarChartDemo4.setVisible(true);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/StackedBarChartDemo4.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */