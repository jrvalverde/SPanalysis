package demo;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Window;
import javax.swing.JPanel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.labels.BubbleXYItemLabelGenerator;
import org.jfree.chart.labels.ItemLabelAnchor;
import org.jfree.chart.labels.ItemLabelPosition;
import org.jfree.chart.labels.StandardXYZToolTipGenerator;
import org.jfree.chart.labels.XYItemLabelGenerator;
import org.jfree.chart.labels.XYToolTipGenerator;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYBubbleRenderer;
import org.jfree.chart.renderer.xy.XYItemRenderer;
import org.jfree.data.xy.XYZDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;
import org.jfree.ui.TextAnchor;

public class BubbleChartDemo2 extends ApplicationFrame {
  public BubbleChartDemo2(String paramString) {
    super(paramString);
    JPanel jPanel = createDemoPanel();
    jPanel.setPreferredSize(new Dimension(500, 270));
    setContentPane(jPanel);
  }
  
  private static JFreeChart createChart(XYZDataset paramXYZDataset) {
    JFreeChart jFreeChart = ChartFactory.createBubbleChart("Bubble Chart Demo 2", "X", "Y", paramXYZDataset, PlotOrientation.VERTICAL, true, true, false);
    XYPlot xYPlot = (XYPlot)jFreeChart.getPlot();
    xYPlot.setRenderer((XYItemRenderer)new XYBubbleRenderer(0));
    xYPlot.setForegroundAlpha(0.65F);
    xYPlot.setDomainPannable(true);
    xYPlot.setRangePannable(true);
    XYItemRenderer xYItemRenderer = xYPlot.getRenderer();
    xYItemRenderer.setSeriesPaint(0, Color.blue);
    xYItemRenderer.setBaseItemLabelGenerator((XYItemLabelGenerator)new BubbleXYItemLabelGenerator());
    xYItemRenderer.setBaseToolTipGenerator((XYToolTipGenerator)new StandardXYZToolTipGenerator());
    xYItemRenderer.setBaseItemLabelsVisible(true);
    xYItemRenderer.setBasePositiveItemLabelPosition(new ItemLabelPosition(ItemLabelAnchor.CENTER, TextAnchor.CENTER));
    NumberAxis numberAxis1 = (NumberAxis)xYPlot.getDomainAxis();
    numberAxis1.setRange(0.0D, 10.0D);
    NumberAxis numberAxis2 = (NumberAxis)xYPlot.getRangeAxis();
    numberAxis2.setRange(0.0D, 10.0D);
    return jFreeChart;
  }
  
  public static JPanel createDemoPanel() {
    JFreeChart jFreeChart = createChart(new SampleXYZDataset2());
    ChartPanel chartPanel = new ChartPanel(jFreeChart);
    chartPanel.setMouseWheelEnabled(true);
    return (JPanel)chartPanel;
  }
  
  public static void main(String[] paramArrayOfString) {
    BubbleChartDemo2 bubbleChartDemo2 = new BubbleChartDemo2("JFreeChart: BubbleChartDemo2.java");
    bubbleChartDemo2.pack();
    RefineryUtilities.centerFrameOnScreen((Window)bubbleChartDemo2);
    bubbleChartDemo2.setVisible(true);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/BubbleChartDemo2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */