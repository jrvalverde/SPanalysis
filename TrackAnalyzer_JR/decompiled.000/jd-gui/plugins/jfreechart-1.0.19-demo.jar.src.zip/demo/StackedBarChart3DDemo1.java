package demo;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Window;
import javax.swing.JPanel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.labels.CategoryItemLabelGenerator;
import org.jfree.chart.labels.ItemLabelAnchor;
import org.jfree.chart.labels.ItemLabelPosition;
import org.jfree.chart.labels.StandardCategoryItemLabelGenerator;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.IntervalMarker;
import org.jfree.chart.plot.Marker;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.renderer.category.BarRenderer;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;
import org.jfree.ui.TextAnchor;

public class StackedBarChart3DDemo1 extends ApplicationFrame {
  public StackedBarChart3DDemo1(String paramString) {
    super(paramString);
    JPanel jPanel = createDemoPanel();
    jPanel.setPreferredSize(new Dimension(500, 270));
    setContentPane(jPanel);
  }
  
  public static CategoryDataset createDataset() {
    DefaultCategoryDataset defaultCategoryDataset = new DefaultCategoryDataset();
    defaultCategoryDataset.addValue(10.0D, "Series 1", "C1");
    defaultCategoryDataset.addValue(5.0D, "Series 1", "C2");
    defaultCategoryDataset.addValue(6.0D, "Series 1", "C3");
    defaultCategoryDataset.addValue(7.0D, "Series 1", "C4");
    defaultCategoryDataset.addValue(8.0D, "Series 1", "C5");
    defaultCategoryDataset.addValue(9.0D, "Series 1", "C6");
    defaultCategoryDataset.addValue(10.0D, "Series 1", "C7");
    defaultCategoryDataset.addValue(11.0D, "Series 1", "C8");
    defaultCategoryDataset.addValue(3.0D, "Series 1", "C9");
    defaultCategoryDataset.addValue(4.0D, "Series 2", "C1");
    defaultCategoryDataset.addValue(7.0D, "Series 2", "C2");
    defaultCategoryDataset.addValue(17.0D, "Series 2", "C3");
    defaultCategoryDataset.addValue(15.0D, "Series 2", "C4");
    defaultCategoryDataset.addValue(6.0D, "Series 2", "C5");
    defaultCategoryDataset.addValue(8.0D, "Series 2", "C6");
    defaultCategoryDataset.addValue(9.0D, "Series 2", "C7");
    defaultCategoryDataset.addValue(13.0D, "Series 2", "C8");
    defaultCategoryDataset.addValue(7.0D, "Series 2", "C9");
    defaultCategoryDataset.addValue(15.0D, "Series 3", "C1");
    defaultCategoryDataset.addValue(14.0D, "Series 3", "C2");
    defaultCategoryDataset.addValue(12.0D, "Series 3", "C3");
    defaultCategoryDataset.addValue(11.0D, "Series 3", "C4");
    defaultCategoryDataset.addValue(10.0D, "Series 3", "C5");
    defaultCategoryDataset.addValue(0.0D, "Series 3", "C6");
    defaultCategoryDataset.addValue(7.0D, "Series 3", "C7");
    defaultCategoryDataset.addValue(9.0D, "Series 3", "C8");
    defaultCategoryDataset.addValue(11.0D, "Series 3", "C9");
    defaultCategoryDataset.addValue(14.0D, "Series 4", "C1");
    defaultCategoryDataset.addValue(3.0D, "Series 4", "C2");
    defaultCategoryDataset.addValue(7.0D, "Series 4", "C3");
    defaultCategoryDataset.addValue(0.0D, "Series 4", "C4");
    defaultCategoryDataset.addValue(9.0D, "Series 4", "C5");
    defaultCategoryDataset.addValue(6.0D, "Series 4", "C6");
    defaultCategoryDataset.addValue(7.0D, "Series 4", "C7");
    defaultCategoryDataset.addValue(9.0D, "Series 4", "C8");
    defaultCategoryDataset.addValue(10.0D, "Series 4", "C9");
    return (CategoryDataset)defaultCategoryDataset;
  }
  
  private static JFreeChart createChart(CategoryDataset paramCategoryDataset) {
    JFreeChart jFreeChart = ChartFactory.createStackedBarChart3D("Stacked Bar Chart 3D Demo 1", "Category", "Value", paramCategoryDataset, PlotOrientation.VERTICAL, true, true, false);
    CategoryPlot categoryPlot = (CategoryPlot)jFreeChart.getPlot();
    IntervalMarker intervalMarker = new IntervalMarker(5.0D, 10.0D, Color.gray, new BasicStroke(0.5F), Color.blue, new BasicStroke(0.5F), 0.5F);
    categoryPlot.addRangeMarker((Marker)intervalMarker);
    BarRenderer barRenderer = (BarRenderer)categoryPlot.getRenderer();
    barRenderer.setDrawBarOutline(false);
    barRenderer.setBaseItemLabelGenerator((CategoryItemLabelGenerator)new StandardCategoryItemLabelGenerator());
    barRenderer.setBaseItemLabelsVisible(true);
    barRenderer.setBasePositiveItemLabelPosition(new ItemLabelPosition(ItemLabelAnchor.CENTER, TextAnchor.CENTER));
    barRenderer.setBaseNegativeItemLabelPosition(new ItemLabelPosition(ItemLabelAnchor.CENTER, TextAnchor.CENTER));
    return jFreeChart;
  }
  
  public static JPanel createDemoPanel() {
    JFreeChart jFreeChart = createChart(createDataset());
    return (JPanel)new ChartPanel(jFreeChart);
  }
  
  public static void main(String[] paramArrayOfString) {
    StackedBarChart3DDemo1 stackedBarChart3DDemo1 = new StackedBarChart3DDemo1("Stacked Bar Chart 3D Demo 1");
    stackedBarChart3DDemo1.pack();
    RefineryUtilities.centerFrameOnScreen((Window)stackedBarChart3DDemo1);
    stackedBarChart3DDemo1.setVisible(true);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/StackedBarChart3DDemo1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */