package demo;

import java.awt.Container;
import java.awt.Dimension;
import java.awt.Point;
import java.awt.Window;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartMouseEvent;
import org.jfree.chart.ChartMouseListener;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.ChartRenderingInfo;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.data.xy.XYDataset;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RectangleEdge;
import org.jfree.ui.RefineryUtilities;

public class MouseListenerDemo4 extends ApplicationFrame implements ChartMouseListener {
  private JFreeChart chart;
  
  private ChartPanel chartPanel;
  
  public MouseListenerDemo4(String paramString) {
    super(paramString);
    String str = "Mouse Listener Demo 4";
    XYDataset xYDataset = createDataset();
    this.chart = ChartFactory.createXYLineChart(str, "X", "Y", xYDataset, PlotOrientation.VERTICAL, true, true, false);
    XYPlot xYPlot = (XYPlot)this.chart.getPlot();
    xYPlot.setDomainPannable(true);
    xYPlot.setRangePannable(true);
    this.chartPanel = new ChartPanel(this.chart);
    this.chartPanel.setMouseWheelEnabled(true);
    this.chartPanel.setPreferredSize(new Dimension(500, 270));
    this.chartPanel.setMouseZoomable(true);
    this.chartPanel.addChartMouseListener(this);
    setContentPane((Container)this.chartPanel);
  }
  
  public XYDataset createDataset() {
    XYSeries xYSeries = new XYSeries("Series 1");
    xYSeries.add(12.5D, 11.0D);
    xYSeries.add(15.0D, 9.3D);
    xYSeries.add(20.0D, 21.0D);
    XYSeriesCollection xYSeriesCollection = new XYSeriesCollection();
    xYSeriesCollection.addSeries(xYSeries);
    return (XYDataset)xYSeriesCollection;
  }
  
  public void chartMouseClicked(ChartMouseEvent paramChartMouseEvent) {
    int i = paramChartMouseEvent.getTrigger().getX();
    int j = paramChartMouseEvent.getTrigger().getY();
    System.out.println("x = " + i + ", y = " + j);
    Point2D point2D = this.chartPanel.translateScreenToJava2D(new Point(i, j));
    XYPlot xYPlot = (XYPlot)this.chart.getPlot();
    ChartRenderingInfo chartRenderingInfo = this.chartPanel.getChartRenderingInfo();
    Rectangle2D rectangle2D = chartRenderingInfo.getPlotInfo().getDataArea();
    ValueAxis valueAxis1 = xYPlot.getDomainAxis();
    RectangleEdge rectangleEdge1 = xYPlot.getDomainAxisEdge();
    ValueAxis valueAxis2 = xYPlot.getRangeAxis();
    RectangleEdge rectangleEdge2 = xYPlot.getRangeAxisEdge();
    double d1 = valueAxis1.java2DToValue(point2D.getX(), rectangle2D, rectangleEdge1);
    double d2 = valueAxis2.java2DToValue(point2D.getY(), rectangle2D, rectangleEdge2);
    System.out.println("Chart: x = " + d1 + ", y = " + d2);
  }
  
  public void chartMouseMoved(ChartMouseEvent paramChartMouseEvent) {}
  
  public static void main(String[] paramArrayOfString) {
    MouseListenerDemo4 mouseListenerDemo4 = new MouseListenerDemo4("JFreeChart: MouseListenerDemo4.java");
    mouseListenerDemo4.pack();
    RefineryUtilities.centerFrameOnScreen((Window)mouseListenerDemo4);
    mouseListenerDemo4.setVisible(true);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/MouseListenerDemo4.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */