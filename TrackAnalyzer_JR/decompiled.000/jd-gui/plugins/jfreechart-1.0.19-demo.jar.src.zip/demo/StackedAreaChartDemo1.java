package demo;

import java.awt.Dimension;
import java.awt.Window;
import javax.swing.JPanel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.renderer.category.CategoryItemRenderer;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

public class StackedAreaChartDemo1 extends ApplicationFrame {
  public StackedAreaChartDemo1(String paramString) {
    super(paramString);
    JPanel jPanel = createDemoPanel();
    jPanel.setPreferredSize(new Dimension(500, 270));
    setContentPane(jPanel);
  }
  
  public static CategoryDataset createDataset() {
    DefaultCategoryDataset defaultCategoryDataset = new DefaultCategoryDataset();
    defaultCategoryDataset.addValue(1.0D, "S1", "C1");
    defaultCategoryDataset.addValue(2.0D, "S1", "C2");
    defaultCategoryDataset.addValue(3.0D, "S1", "C3");
    defaultCategoryDataset.addValue(4.0D, "S1", "C4");
    defaultCategoryDataset.addValue(5.0D, "S1", "C5");
    defaultCategoryDataset.addValue(6.0D, "S1", "C6");
    defaultCategoryDataset.addValue(7.0D, "S1", "C7");
    defaultCategoryDataset.addValue(8.0D, "S1", "C8");
    defaultCategoryDataset.addValue(6.0D, "S2", "C1");
    defaultCategoryDataset.addValue(3.0D, "S2", "C2");
    defaultCategoryDataset.addValue(4.0D, "S2", "C3");
    defaultCategoryDataset.addValue(3.0D, "S2", "C4");
    defaultCategoryDataset.addValue(9.0D, "S2", "C5");
    defaultCategoryDataset.addValue(7.0D, "S2", "C6");
    defaultCategoryDataset.addValue(2.0D, "S2", "C7");
    defaultCategoryDataset.addValue(3.0D, "S2", "C8");
    defaultCategoryDataset.addValue(1.0D, "S3", "C1");
    defaultCategoryDataset.addValue(7.0D, "S3", "C2");
    defaultCategoryDataset.addValue(6.0D, "S3", "C3");
    defaultCategoryDataset.addValue(7.0D, "S3", "C4");
    defaultCategoryDataset.addValue(4.0D, "S3", "C5");
    defaultCategoryDataset.addValue(5.0D, "S3", "C6");
    defaultCategoryDataset.addValue(3.0D, "S3", "C7");
    defaultCategoryDataset.addValue(1.0D, "S3", "C8");
    return (CategoryDataset)defaultCategoryDataset;
  }
  
  public static JFreeChart createChart(CategoryDataset paramCategoryDataset) {
    JFreeChart jFreeChart = ChartFactory.createStackedAreaChart("Stacked Area Chart", "Category", "Value", paramCategoryDataset, PlotOrientation.VERTICAL, true, true, false);
    CategoryPlot categoryPlot = (CategoryPlot)jFreeChart.getPlot();
    categoryPlot.setForegroundAlpha(0.85F);
    CategoryAxis categoryAxis = categoryPlot.getDomainAxis();
    categoryAxis.setLowerMargin(0.0D);
    categoryAxis.setUpperMargin(0.0D);
    categoryAxis.setCategoryMargin(0.0D);
    NumberAxis numberAxis = (NumberAxis)categoryPlot.getRangeAxis();
    numberAxis.setStandardTickUnits(NumberAxis.createIntegerTickUnits());
    CategoryItemRenderer categoryItemRenderer = categoryPlot.getRenderer();
    categoryItemRenderer.setBaseItemLabelsVisible(true);
    return jFreeChart;
  }
  
  public static JPanel createDemoPanel() {
    JFreeChart jFreeChart = createChart(createDataset());
    return (JPanel)new ChartPanel(jFreeChart);
  }
  
  public static void main(String[] paramArrayOfString) {
    StackedAreaChartDemo1 stackedAreaChartDemo1 = new StackedAreaChartDemo1("JFreeChart: StackedAreaChartDemo1.java");
    stackedAreaChartDemo1.pack();
    RefineryUtilities.centerFrameOnScreen((Window)stackedAreaChartDemo1);
    stackedAreaChartDemo1.setVisible(true);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/StackedAreaChartDemo1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */