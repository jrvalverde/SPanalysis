package demo;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Window;
import java.util.Date;
import javax.swing.BorderFactory;
import javax.swing.JPanel;
import javax.swing.JScrollBar;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.DateAxis;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.IntervalMarker;
import org.jfree.chart.plot.Marker;
import org.jfree.chart.renderer.category.GanttRenderer;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.IntervalCategoryDataset;
import org.jfree.data.gantt.GanttCategoryDataset;
import org.jfree.data.gantt.SlidingGanttCategoryDataset;
import org.jfree.data.gantt.Task;
import org.jfree.data.gantt.TaskSeries;
import org.jfree.data.gantt.TaskSeriesCollection;
import org.jfree.data.general.DatasetUtilities;
import org.jfree.data.time.Day;
import org.jfree.data.time.Hour;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.Layer;
import org.jfree.ui.RefineryUtilities;

public class SlidingGanttDatasetDemo1 extends ApplicationFrame {
  public SlidingGanttDatasetDemo1(String paramString) {
    super(paramString);
    setDefaultCloseOperation(3);
    setContentPane(createDemoPanel());
  }
  
  public static JPanel createDemoPanel() {
    return new DemoPanel();
  }
  
  public static void main(String[] paramArrayOfString) {
    SlidingGanttDatasetDemo1 slidingGanttDatasetDemo1 = new SlidingGanttDatasetDemo1("JFreeChart: SlidingGanttDatasetDemo1.java");
    slidingGanttDatasetDemo1.pack();
    RefineryUtilities.centerFrameOnScreen((Window)slidingGanttDatasetDemo1);
    slidingGanttDatasetDemo1.setVisible(true);
  }
  
  static class DemoPanel extends JPanel implements ChangeListener {
    JScrollBar scroller;
    
    SlidingGanttCategoryDataset dataset = new SlidingGanttCategoryDataset(createDataset(), 0, 15);
    
    public DemoPanel() {
      super(new BorderLayout());
      JFreeChart jFreeChart = createChart(this.dataset);
      ChartPanel chartPanel = new ChartPanel(jFreeChart);
      chartPanel.setPreferredSize(new Dimension(400, 400));
      this.scroller = new JScrollBar(1, 0, 15, 0, 50);
      add((Component)chartPanel);
      this.scroller.getModel().addChangeListener(this);
      JPanel jPanel = new JPanel(new BorderLayout());
      jPanel.add(this.scroller);
      jPanel.setBorder(BorderFactory.createEmptyBorder(66, 2, 2, 2));
      add(jPanel, "East");
    }
    
    public static GanttCategoryDataset createDataset() {
      TaskSeries taskSeries = new TaskSeries("Scheduled");
      Day day1 = new Day();
      Day day2 = new Day();
      for (byte b = 0; b < 50; b++) {
        int i = (int)(Math.random() * 10.0D) + 1;
        for (byte b1 = 0; b1 < i; b1++)
          day2 = (Day)day2.next(); 
        taskSeries.add(new Task("Task " + b, new Date(day1.getMiddleMillisecond()), new Date(day2.getMiddleMillisecond())));
        day1 = (Day)day2.next();
        day2 = (Day)day2.next();
      } 
      TaskSeriesCollection taskSeriesCollection = new TaskSeriesCollection();
      taskSeriesCollection.add(taskSeries);
      return (GanttCategoryDataset)taskSeriesCollection;
    }
    
    private static JFreeChart createChart(SlidingGanttCategoryDataset param1SlidingGanttCategoryDataset) {
      JFreeChart jFreeChart = ChartFactory.createGanttChart("Gantt Chart Demo", "Task", "Date", (IntervalCategoryDataset)param1SlidingGanttCategoryDataset, true, true, false);
      CategoryPlot categoryPlot = (CategoryPlot)jFreeChart.getPlot();
      Hour hour = new Hour(1, 14, 5, 2008);
      for (byte b = 0; b < 12; b++) {
        IntervalMarker intervalMarker = new IntervalMarker(hour.getFirstMillisecond(), hour.getLastMillisecond(), Color.lightGray);
        categoryPlot.addRangeMarker((Marker)intervalMarker, Layer.BACKGROUND);
        hour = (Hour)hour.next().next();
      } 
      categoryPlot.getDomainAxis().setMaximumCategoryLabelWidthRatio(10.0F);
      DateAxis dateAxis = (DateAxis)categoryPlot.getRangeAxis();
      dateAxis.setRange(DatasetUtilities.findRangeBounds((CategoryDataset)param1SlidingGanttCategoryDataset.getUnderlyingDataset(), true));
      GanttRenderer ganttRenderer = (GanttRenderer)categoryPlot.getRenderer();
      ganttRenderer.setDrawBarOutline(false);
      ganttRenderer.setShadowVisible(false);
      return jFreeChart;
    }
    
    public void stateChanged(ChangeEvent param1ChangeEvent) {
      this.dataset.setFirstCategoryIndex(this.scroller.getValue());
    }
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/SlidingGanttDatasetDemo1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */