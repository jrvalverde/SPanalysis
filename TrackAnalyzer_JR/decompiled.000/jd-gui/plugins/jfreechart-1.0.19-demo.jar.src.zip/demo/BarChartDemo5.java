package demo;

import java.awt.Dimension;
import java.awt.Font;
import java.awt.Window;
import java.text.DecimalFormat;
import javax.swing.JPanel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.AxisLocation;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.labels.CategoryItemLabelGenerator;
import org.jfree.chart.labels.CategoryToolTipGenerator;
import org.jfree.chart.labels.StandardCategoryItemLabelGenerator;
import org.jfree.chart.labels.StandardCategoryToolTipGenerator;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.renderer.category.BarRenderer;
import org.jfree.chart.title.TextTitle;
import org.jfree.chart.title.Title;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

public class BarChartDemo5 extends ApplicationFrame {
  public BarChartDemo5(String paramString) {
    super(paramString);
    JPanel jPanel = createDemoPanel();
    jPanel.setPreferredSize(new Dimension(500, 270));
    setContentPane(jPanel);
  }
  
  private static CategoryDataset createDataset() {
    DefaultCategoryDataset defaultCategoryDataset = new DefaultCategoryDataset();
    String str = "Prison Population Rates";
    defaultCategoryDataset.addValue(59.0D, str, "Norway");
    defaultCategoryDataset.addValue(69.0D, str, "Switzerland");
    defaultCategoryDataset.addValue(85.0D, str, "France");
    defaultCategoryDataset.addValue(93.0D, str, "Syria");
    defaultCategoryDataset.addValue(96.0D, str, "Germany");
    defaultCategoryDataset.addValue(111.0D, str, "China");
    defaultCategoryDataset.addValue(116.0D, str, "Australia");
    defaultCategoryDataset.addValue(121.0D, str, "Egypt");
    defaultCategoryDataset.addValue(129.0D, str, "England & Wales");
    defaultCategoryDataset.addValue(157.0D, str, "New Zealand");
    defaultCategoryDataset.addValue(205.0D, str, "Chile");
    defaultCategoryDataset.addValue(229.0D, str, "Iran");
    defaultCategoryDataset.addValue(359.0D, str, "Singapore");
    defaultCategoryDataset.addValue(404.0D, str, "South Africa");
    defaultCategoryDataset.addValue(406.0D, str, "Ukraine");
    defaultCategoryDataset.addValue(686.0D, str, "USA");
    return (CategoryDataset)defaultCategoryDataset;
  }
  
  private static JFreeChart createChart(CategoryDataset paramCategoryDataset) {
    JFreeChart jFreeChart = ChartFactory.createBarChart("Prison Population Rates - Selected Countries", "Country", "Prisoners Per 100,000 National Population", paramCategoryDataset, PlotOrientation.HORIZONTAL, false, true, false);
    jFreeChart.addSubtitle((Title)new TextTitle("Source: http://www.homeoffice.gov.uk/rds/pdfs2/r188.pdf", new Font("Dialog", 2, 10)));
    CategoryPlot categoryPlot = (CategoryPlot)jFreeChart.getPlot();
    categoryPlot.setRangeAxisLocation(AxisLocation.BOTTOM_OR_LEFT);
    categoryPlot.setRangePannable(true);
    BarRenderer barRenderer = (BarRenderer)categoryPlot.getRenderer();
    barRenderer.setItemLabelAnchorOffset(9.0D);
    barRenderer.setBaseItemLabelsVisible(true);
    barRenderer.setBaseItemLabelGenerator((CategoryItemLabelGenerator)new StandardCategoryItemLabelGenerator());
    barRenderer.setBaseToolTipGenerator((CategoryToolTipGenerator)new StandardCategoryToolTipGenerator("{0}, {1}) = {2} per 100,000", new DecimalFormat("0")));
    CategoryAxis categoryAxis = categoryPlot.getDomainAxis();
    categoryAxis.setCategoryMargin(0.25D);
    categoryAxis.setUpperMargin(0.02D);
    categoryAxis.setLowerMargin(0.02D);
    NumberAxis numberAxis = (NumberAxis)categoryPlot.getRangeAxis();
    numberAxis.setStandardTickUnits(NumberAxis.createIntegerTickUnits());
    numberAxis.setUpperMargin(0.1D);
    ChartUtilities.applyCurrentTheme(jFreeChart);
    return jFreeChart;
  }
  
  public static JPanel createDemoPanel() {
    JFreeChart jFreeChart = createChart(createDataset());
    ChartPanel chartPanel = new ChartPanel(jFreeChart);
    chartPanel.setMouseWheelEnabled(true);
    return (JPanel)chartPanel;
  }
  
  public static void main(String[] paramArrayOfString) {
    BarChartDemo5 barChartDemo5 = new BarChartDemo5("JFreeChart: BarChartDemo5.java");
    barChartDemo5.pack();
    RefineryUtilities.centerFrameOnScreen((Window)barChartDemo5);
    barChartDemo5.setVisible(true);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/BarChartDemo5.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */