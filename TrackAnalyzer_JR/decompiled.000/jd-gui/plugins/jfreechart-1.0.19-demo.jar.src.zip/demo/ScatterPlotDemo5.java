package demo;

import java.awt.Dimension;
import java.awt.Window;
import java.awt.font.TextAttribute;
import java.text.AttributedString;
import javax.swing.JPanel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYDotRenderer;
import org.jfree.chart.renderer.xy.XYItemRenderer;
import org.jfree.data.xy.XYDataset;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RectangleInsets;
import org.jfree.ui.RefineryUtilities;

public class ScatterPlotDemo5 extends ApplicationFrame {
  public ScatterPlotDemo5(String paramString) {
    super(paramString);
    JPanel jPanel = createDemoPanel();
    jPanel.setPreferredSize(new Dimension(500, 270));
    setContentPane(jPanel);
  }
  
  public static XYDataset createDataset() {
    XYSeriesCollection xYSeriesCollection = new XYSeriesCollection();
    XYSeries xYSeries1 = new XYSeries("S1");
    XYSeries xYSeries2 = new XYSeries("S2");
    for (byte b = 0; b < 100; b++) {
      xYSeries1.add(Math.random() * 50.0D, Math.random() * 100.0D);
      xYSeries2.add(Math.random() * 50.0D, Math.random() * 100.0D);
    } 
    xYSeriesCollection.addSeries(xYSeries1);
    xYSeriesCollection.addSeries(xYSeries2);
    return (XYDataset)xYSeriesCollection;
  }
  
  public static JPanel createDemoPanel() {
    JFreeChart jFreeChart = ChartFactory.createScatterPlot("Scatter Plot Demo 5", "X", "Y", createDataset());
    XYPlot xYPlot = (XYPlot)jFreeChart.getPlot();
    xYPlot.setBackgroundPaint(null);
    xYPlot.setAxisOffset(RectangleInsets.ZERO_INSETS);
    xYPlot.setOutlineVisible(false);
    XYDotRenderer xYDotRenderer = new XYDotRenderer();
    xYDotRenderer.setDotWidth(4);
    xYDotRenderer.setDotHeight(4);
    xYPlot.setRenderer((XYItemRenderer)xYDotRenderer);
    xYPlot.setDomainCrosshairVisible(true);
    xYPlot.setRangeCrosshairVisible(true);
    NumberAxis numberAxis1 = (NumberAxis)xYPlot.getDomainAxis();
    AttributedString attributedString1 = new AttributedString("H20");
    attributedString1.addAttribute(TextAttribute.SUPERSCRIPT, TextAttribute.SUPERSCRIPT_SUB, 1, 2);
    numberAxis1.setAttributedLabel(attributedString1);
    numberAxis1.setPositiveArrowVisible(true);
    numberAxis1.setAutoRangeIncludesZero(false);
    NumberAxis numberAxis2 = (NumberAxis)xYPlot.getRangeAxis();
    AttributedString attributedString2 = new AttributedString("kg x 106");
    attributedString2.addAttribute(TextAttribute.SUPERSCRIPT, TextAttribute.SUPERSCRIPT_SUPER, 7, 8);
    numberAxis2.setAttributedLabel(attributedString2);
    numberAxis2.setPositiveArrowVisible(true);
    ChartPanel chartPanel = new ChartPanel(jFreeChart);
    chartPanel.setMouseWheelEnabled(true);
    return (JPanel)chartPanel;
  }
  
  public static void main(String[] paramArrayOfString) {
    ScatterPlotDemo5 scatterPlotDemo5 = new ScatterPlotDemo5("JFreeChart: ScatterPlotDemo5.java");
    scatterPlotDemo5.pack();
    RefineryUtilities.centerFrameOnScreen((Window)scatterPlotDemo5);
    scatterPlotDemo5.setVisible(true);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/ScatterPlotDemo5.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */