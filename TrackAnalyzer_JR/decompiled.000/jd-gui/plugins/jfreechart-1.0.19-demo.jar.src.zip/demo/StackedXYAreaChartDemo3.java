package demo;

import java.awt.Dimension;
import java.awt.Window;
import javax.swing.JPanel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.DateAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.data.time.Day;
import org.jfree.data.time.TimePeriod;
import org.jfree.data.time.TimeTableXYDataset;
import org.jfree.data.xy.TableXYDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

public class StackedXYAreaChartDemo3 extends ApplicationFrame {
  public StackedXYAreaChartDemo3(String paramString) {
    super(paramString);
    JPanel jPanel = createDemoPanel();
    jPanel.setPreferredSize(new Dimension(500, 270));
    setContentPane(jPanel);
  }
  
  private static TableXYDataset createDataset() {
    TimeTableXYDataset timeTableXYDataset = new TimeTableXYDataset();
    timeTableXYDataset.add((TimePeriod)new Day(14, 2, 2007), 87.0D, "Series 1");
    timeTableXYDataset.add((TimePeriod)new Day(15, 2, 2007), 67.0D, "Series 1");
    timeTableXYDataset.add((TimePeriod)new Day(16, 2, 2007), 78.0D, "Series 1");
    timeTableXYDataset.add((TimePeriod)new Day(17, 2, 2007), 55.0D, "Series 1");
    timeTableXYDataset.add((TimePeriod)new Day(18, 2, 2007), 58.0D, "Series 1");
    timeTableXYDataset.add((TimePeriod)new Day(19, 2, 2007), 60.0D, "Series 1");
    timeTableXYDataset.add((TimePeriod)new Day(14, 2, 2007), 45.0D, "Series 2");
    timeTableXYDataset.add((TimePeriod)new Day(15, 2, 2007), 67.0D, "Series 2");
    timeTableXYDataset.add((TimePeriod)new Day(16, 2, 2007), 61.0D, "Series 2");
    timeTableXYDataset.add((TimePeriod)new Day(17, 2, 2007), 58.0D, "Series 2");
    timeTableXYDataset.add((TimePeriod)new Day(18, 2, 2007), 73.0D, "Series 2");
    timeTableXYDataset.add((TimePeriod)new Day(19, 2, 2007), 64.0D, "Series 2");
    timeTableXYDataset.add((TimePeriod)new Day(14, 2, 2007), 32.0D, "Series 3");
    timeTableXYDataset.add((TimePeriod)new Day(15, 2, 2007), 38.0D, "Series 3");
    timeTableXYDataset.add((TimePeriod)new Day(16, 2, 2007), 43.0D, "Series 3");
    timeTableXYDataset.add((TimePeriod)new Day(17, 2, 2007), 12.0D, "Series 3");
    timeTableXYDataset.add((TimePeriod)new Day(18, 2, 2007), 19.0D, "Series 3");
    timeTableXYDataset.add((TimePeriod)new Day(19, 2, 2007), 26.0D, "Series 3");
    return (TableXYDataset)timeTableXYDataset;
  }
  
  private static JFreeChart createChart(TableXYDataset paramTableXYDataset) {
    JFreeChart jFreeChart = ChartFactory.createStackedXYAreaChart("Stacked XY Area Chart Demo 3", "X Value", "Y Value", paramTableXYDataset, PlotOrientation.VERTICAL, true, true, false);
    XYPlot xYPlot = (XYPlot)jFreeChart.getPlot();
    DateAxis dateAxis = new DateAxis("Date");
    xYPlot.setDomainAxis((ValueAxis)dateAxis);
    dateAxis.setLowerMargin(0.0D);
    dateAxis.setUpperMargin(0.0D);
    ChartUtilities.applyCurrentTheme(jFreeChart);
    return jFreeChart;
  }
  
  public static JPanel createDemoPanel() {
    JFreeChart jFreeChart = createChart(createDataset());
    return (JPanel)new ChartPanel(jFreeChart);
  }
  
  public static void main(String[] paramArrayOfString) {
    StackedXYAreaChartDemo3 stackedXYAreaChartDemo3 = new StackedXYAreaChartDemo3("Stacked XY Area Chart Demo 3");
    stackedXYAreaChartDemo3.pack();
    RefineryUtilities.centerFrameOnScreen((Window)stackedXYAreaChartDemo3);
    stackedXYAreaChartDemo3.setVisible(true);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/StackedXYAreaChartDemo3.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */