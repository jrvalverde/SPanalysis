package demo;

import java.awt.image.BufferedImage;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.MeterPlot;
import org.jfree.chart.plot.Plot;
import org.jfree.data.general.DefaultValueDataset;
import org.jfree.data.general.ValueDataset;

public class MeterChartDemo4 {
  public static void main(String[] paramArrayOfString) {
    DefaultValueDataset defaultValueDataset = new DefaultValueDataset(75.0D);
    MeterPlot meterPlot = new MeterPlot((ValueDataset)defaultValueDataset);
    JFreeChart jFreeChart = new JFreeChart("Scaled Image Test", (Plot)meterPlot);
    ChartUtilities.applyCurrentTheme(jFreeChart);
    try {
      File file = new File("meterchart100.png");
      BufferedOutputStream bufferedOutputStream = new BufferedOutputStream(new FileOutputStream(file));
      BufferedImage bufferedImage = jFreeChart.createBufferedImage(200, 200, 400.0D, 400.0D, null);
      ChartUtilities.writeBufferedImageAsPNG(bufferedOutputStream, bufferedImage);
    } catch (IOException iOException) {
      System.out.println(iOException.toString());
    } 
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/MeterChartDemo4.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */