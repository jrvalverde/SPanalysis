package demo;

import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Window;
import javax.swing.JPanel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.labels.PieSectionLabelGenerator;
import org.jfree.chart.labels.StandardPieSectionLabelGenerator;
import org.jfree.chart.plot.PiePlot;
import org.jfree.chart.title.TextTitle;
import org.jfree.chart.title.Title;
import org.jfree.data.general.DefaultPieDataset;
import org.jfree.data.general.PieDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

public class PieChartDemo6 extends ApplicationFrame {
  public PieChartDemo6(String paramString) {
    super(paramString);
    JPanel jPanel = createDemoPanel();
    jPanel.setPreferredSize(new Dimension(800, 600));
    setContentPane(jPanel);
  }
  
  private static PieDataset createDataset() {
    DefaultPieDataset defaultPieDataset = new DefaultPieDataset();
    defaultPieDataset.setValue("S1", 7.0D);
    defaultPieDataset.setValue("S2", null);
    defaultPieDataset.setValue("S3", 0.0D);
    defaultPieDataset.setValue("S4", 3.0D);
    defaultPieDataset.setValue("S5", -1.0D);
    return (PieDataset)defaultPieDataset;
  }
  
  private static JFreeChart createChart(String paramString, PieDataset paramPieDataset) {
    JFreeChart jFreeChart = ChartFactory.createPieChart(paramString, paramPieDataset, true, true, false);
    PiePlot piePlot = (PiePlot)jFreeChart.getPlot();
    piePlot.setLabelGenerator((PieSectionLabelGenerator)new StandardPieSectionLabelGenerator("{0} = {1}"));
    return jFreeChart;
  }
  
  public static JPanel createDemoPanel() {
    DemoPanel demoPanel = new DemoPanel(new GridLayout(2, 2));
    JFreeChart jFreeChart1 = createChart("Pie Chart 1", createDataset());
    Font font = new Font("Dialog", 0, 12);
    jFreeChart1.addSubtitle((Title)new TextTitle("Ignore nulls: false; Ignore zeros: false;", font));
    JFreeChart jFreeChart2 = createChart("Pie Chart 2", createDataset());
    jFreeChart2.addSubtitle((Title)new TextTitle("Ignore nulls: true; Ignore zeros: false;", font));
    PiePlot piePlot1 = (PiePlot)jFreeChart2.getPlot();
    piePlot1.setIgnoreNullValues(true);
    piePlot1.setIgnoreZeroValues(false);
    JFreeChart jFreeChart3 = createChart("Pie Chart 3", createDataset());
    jFreeChart3.addSubtitle((Title)new TextTitle("Ignore nulls: false; Ignore zeros: true;", font));
    PiePlot piePlot2 = (PiePlot)jFreeChart3.getPlot();
    piePlot2.setIgnoreNullValues(false);
    piePlot2.setIgnoreZeroValues(true);
    JFreeChart jFreeChart4 = createChart("Pie Chart 4", createDataset());
    jFreeChart4.addSubtitle((Title)new TextTitle("Ignore nulls: true; Ignore zeros: true;", font));
    PiePlot piePlot3 = (PiePlot)jFreeChart4.getPlot();
    piePlot3.setIgnoreNullValues(true);
    piePlot3.setIgnoreZeroValues(true);
    demoPanel.add((Component)new ChartPanel(jFreeChart1));
    demoPanel.add((Component)new ChartPanel(jFreeChart2));
    demoPanel.add((Component)new ChartPanel(jFreeChart3));
    demoPanel.add((Component)new ChartPanel(jFreeChart4));
    demoPanel.addChart(jFreeChart1);
    demoPanel.addChart(jFreeChart2);
    demoPanel.addChart(jFreeChart3);
    demoPanel.addChart(jFreeChart4);
    return demoPanel;
  }
  
  public static void main(String[] paramArrayOfString) {
    PieChartDemo6 pieChartDemo6 = new PieChartDemo6("JFreeChart: PieChartDemo6.java");
    pieChartDemo6.pack();
    RefineryUtilities.centerFrameOnScreen((Window)pieChartDemo6);
    pieChartDemo6.setVisible(true);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/PieChartDemo6.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */