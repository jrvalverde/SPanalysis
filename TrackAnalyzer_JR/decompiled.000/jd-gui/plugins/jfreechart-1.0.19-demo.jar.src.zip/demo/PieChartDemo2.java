package demo;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Window;
import javax.swing.JPanel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.labels.PieSectionLabelGenerator;
import org.jfree.chart.labels.StandardPieSectionLabelGenerator;
import org.jfree.chart.plot.PiePlot;
import org.jfree.data.general.DefaultPieDataset;
import org.jfree.data.general.PieDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

public class PieChartDemo2 extends ApplicationFrame {
  public PieChartDemo2(String paramString) {
    super(paramString);
    JPanel jPanel = createDemoPanel();
    jPanel.setPreferredSize(new Dimension(500, 270));
    setContentPane(jPanel);
  }
  
  private static PieDataset createDataset() {
    DefaultPieDataset defaultPieDataset = new DefaultPieDataset();
    defaultPieDataset.setValue("One", 43.2D);
    defaultPieDataset.setValue("Two", 10.0D);
    defaultPieDataset.setValue("Three", 27.5D);
    defaultPieDataset.setValue("Four", 17.5D);
    defaultPieDataset.setValue("Five", 11.0D);
    defaultPieDataset.setValue("Six", 19.4D);
    return (PieDataset)defaultPieDataset;
  }
  
  private static JFreeChart createChart(PieDataset paramPieDataset) {
    JFreeChart jFreeChart = ChartFactory.createPieChart("Pie Chart Demo 2", paramPieDataset, true, true, false);
    PiePlot piePlot = (PiePlot)jFreeChart.getPlot();
    piePlot.setSectionPaint("One", new Color(160, 160, 255));
    piePlot.setSectionPaint("Two", new Color(128, 128, 223));
    piePlot.setSectionPaint("Three", new Color(96, 96, 191));
    piePlot.setSectionPaint("Four", new Color(64, 64, 159));
    piePlot.setSectionPaint("Five", new Color(32, 32, 127));
    piePlot.setSectionPaint("Six", new Color(0, 0, 111));
    piePlot.setNoDataMessage("No data available");
    piePlot.setExplodePercent("Two", 0.2D);
    piePlot.setLabelGenerator((PieSectionLabelGenerator)new StandardPieSectionLabelGenerator("{0} ({2} percent)"));
    piePlot.setLabelBackgroundPaint(new Color(220, 220, 220));
    piePlot.setLegendLabelToolTipGenerator((PieSectionLabelGenerator)new StandardPieSectionLabelGenerator("Tooltip for legend item {0}"));
    piePlot.setSimpleLabels(true);
    piePlot.setInteriorGap(0.0D);
    return jFreeChart;
  }
  
  public static JPanel createDemoPanel() {
    JFreeChart jFreeChart = createChart(createDataset());
    ChartPanel chartPanel = new ChartPanel(jFreeChart);
    chartPanel.setMouseWheelEnabled(true);
    return (JPanel)chartPanel;
  }
  
  public static void main(String[] paramArrayOfString) {
    PieChartDemo2 pieChartDemo2 = new PieChartDemo2("JFreeChart: PieChartDemo2.java");
    pieChartDemo2.pack();
    RefineryUtilities.centerFrameOnScreen((Window)pieChartDemo2);
    pieChartDemo2.setVisible(true);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/PieChartDemo2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */