package demo;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.Window;
import java.text.NumberFormat;
import javax.swing.BorderFactory;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.CompassFormat;
import org.jfree.chart.axis.ModuloAxis;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.axis.NumberTickUnit;
import org.jfree.chart.axis.TickUnit;
import org.jfree.chart.axis.TickUnitSource;
import org.jfree.chart.axis.TickUnits;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYAreaRenderer;
import org.jfree.chart.renderer.xy.XYItemRenderer;
import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
import org.jfree.data.Range;
import org.jfree.data.time.Minute;
import org.jfree.data.time.RegularTimePeriod;
import org.jfree.data.time.TimeSeries;
import org.jfree.data.time.TimeSeriesCollection;
import org.jfree.data.xy.XYDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

public class CompassFormatDemo2 extends ApplicationFrame {
  public CompassFormatDemo2(String paramString) {
    super(paramString);
    setContentPane(new MyDemoPanel());
  }
  
  public static JPanel createDemoPanel() {
    return new MyDemoPanel();
  }
  
  public static void main(String[] paramArrayOfString) {
    CompassFormatDemo2 compassFormatDemo2 = new CompassFormatDemo2("JFreeChart: CompassFormatDemo2.java");
    compassFormatDemo2.pack();
    RefineryUtilities.centerFrameOnScreen((Window)compassFormatDemo2);
    compassFormatDemo2.setVisible(true);
  }
  
  private static class MyDemoPanel extends DemoPanel implements ChangeListener {
    private JSlider directionSlider;
    
    private JSlider fieldSlider;
    
    private ModuloAxis rangeAxis;
    
    private double direction = 0.0D;
    
    private double degrees = 45.0D;
    
    public MyDemoPanel() {
      super(new BorderLayout());
      JPanel jPanel = new JPanel(new GridLayout(1, 2));
      this.fieldSlider = new JSlider(1, 10, 180, 45);
      this.fieldSlider.setPaintLabels(true);
      this.fieldSlider.setPaintTicks(true);
      this.fieldSlider.setMajorTickSpacing(10);
      this.fieldSlider.setMinorTickSpacing(5);
      this.fieldSlider.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
      this.fieldSlider.addChangeListener(this);
      this.directionSlider = new JSlider(1, 0, 360, 0);
      this.directionSlider.setMajorTickSpacing(30);
      this.directionSlider.setMinorTickSpacing(5);
      this.directionSlider.setPaintLabels(true);
      this.directionSlider.setPaintTicks(true);
      this.directionSlider.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
      this.directionSlider.setPaintTrack(true);
      this.directionSlider.addChangeListener(this);
      jPanel.add(this.fieldSlider);
      jPanel.add(this.directionSlider);
      JFreeChart jFreeChart = createChart();
      addChart(jFreeChart);
      ChartPanel chartPanel = new ChartPanel(jFreeChart);
      chartPanel.setPreferredSize(new Dimension(500, 270));
      add(jPanel, "West");
      add((Component)chartPanel);
    }
    
    private XYDataset createDirectionDataset(int param1Int) {
      TimeSeriesCollection timeSeriesCollection = new TimeSeriesCollection();
      TimeSeries timeSeries = new TimeSeries("Wind Direction");
      Minute minute = new Minute();
      double d = 0.0D;
      for (byte b = 0; b < param1Int; b++) {
        timeSeries.add((RegularTimePeriod)minute, d);
        RegularTimePeriod regularTimePeriod = minute.next();
        d += (Math.random() - 0.5D) * 15.0D;
        if (d < 0.0D) {
          d += 360.0D;
        } else if (d > 360.0D) {
          d -= 360.0D;
        } 
      } 
      timeSeriesCollection.addSeries(timeSeries);
      return (XYDataset)timeSeriesCollection;
    }
    
    private XYDataset createForceDataset(int param1Int) {
      TimeSeriesCollection timeSeriesCollection = new TimeSeriesCollection();
      TimeSeries timeSeries = new TimeSeries("Wind Force");
      Minute minute = new Minute();
      double d = 3.0D;
      for (byte b = 0; b < param1Int; b++) {
        timeSeries.add((RegularTimePeriod)minute, d);
        RegularTimePeriod regularTimePeriod = minute.next();
        d = Math.max(0.5D, d + (Math.random() - 0.5D) * 0.5D);
      } 
      timeSeriesCollection.addSeries(timeSeries);
      return (XYDataset)timeSeriesCollection;
    }
    
    private JFreeChart createChart() {
      XYDataset xYDataset = createDirectionDataset(100);
      JFreeChart jFreeChart = ChartFactory.createTimeSeriesChart("Time", "Date", "Direction", xYDataset, true, true, false);
      XYPlot xYPlot = (XYPlot)jFreeChart.getPlot();
      xYPlot.getDomainAxis().setLowerMargin(0.0D);
      xYPlot.getDomainAxis().setUpperMargin(0.0D);
      this.rangeAxis = new ModuloAxis("Direction", new Range(0.0D, 360.0D));
      TickUnits tickUnits = new TickUnits();
      tickUnits.add((TickUnit)new NumberTickUnit(180.0D, (NumberFormat)new CompassFormat()));
      tickUnits.add((TickUnit)new NumberTickUnit(90.0D, (NumberFormat)new CompassFormat()));
      tickUnits.add((TickUnit)new NumberTickUnit(45.0D, (NumberFormat)new CompassFormat()));
      tickUnits.add((TickUnit)new NumberTickUnit(22.5D, (NumberFormat)new CompassFormat()));
      this.rangeAxis.setStandardTickUnits((TickUnitSource)tickUnits);
      XYLineAndShapeRenderer xYLineAndShapeRenderer = new XYLineAndShapeRenderer();
      xYLineAndShapeRenderer.setBaseLinesVisible(false);
      xYLineAndShapeRenderer.setBaseShapesVisible(true);
      xYPlot.setRenderer((XYItemRenderer)xYLineAndShapeRenderer);
      xYPlot.setRangeAxis((ValueAxis)this.rangeAxis);
      this.rangeAxis.setDisplayRange(-45.0D, 45.0D);
      XYAreaRenderer xYAreaRenderer = new XYAreaRenderer();
      NumberAxis numberAxis = new NumberAxis("Force");
      numberAxis.setRange(0.0D, 12.0D);
      xYAreaRenderer.setSeriesPaint(0, new Color(0, 0, 255, 128));
      xYPlot.setDataset(1, createForceDataset(100));
      xYPlot.setRenderer(1, (XYItemRenderer)xYAreaRenderer);
      xYPlot.setRangeAxis(1, (ValueAxis)numberAxis);
      xYPlot.mapDatasetToRangeAxis(1, 1);
      ChartUtilities.applyCurrentTheme(jFreeChart);
      return jFreeChart;
    }
    
    public void stateChanged(ChangeEvent param1ChangeEvent) {
      if (param1ChangeEvent.getSource() == this.directionSlider) {
        this.direction = this.directionSlider.getValue();
        this.rangeAxis.setDisplayRange(this.direction - this.degrees, this.direction + this.degrees);
      } else if (param1ChangeEvent.getSource() == this.fieldSlider) {
        this.degrees = this.fieldSlider.getValue();
        this.rangeAxis.setDisplayRange(this.direction - this.degrees, this.direction + this.degrees);
      } 
    }
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/CompassFormatDemo2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */