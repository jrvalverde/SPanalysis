package demo;

import java.awt.Color;
import java.awt.Window;
import javax.swing.JPanel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.LegendItemSource;
import org.jfree.chart.annotations.XYAnnotation;
import org.jfree.chart.annotations.XYPointerAnnotation;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.block.Arrangement;
import org.jfree.chart.block.Block;
import org.jfree.chart.block.BlockBorder;
import org.jfree.chart.block.BlockContainer;
import org.jfree.chart.block.BlockFrame;
import org.jfree.chart.block.BorderArrangement;
import org.jfree.chart.block.EmptyBlock;
import org.jfree.chart.labels.StandardXYToolTipGenerator;
import org.jfree.chart.labels.XYToolTipGenerator;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYItemRenderer;
import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
import org.jfree.chart.title.CompositeTitle;
import org.jfree.chart.title.LegendTitle;
import org.jfree.chart.title.Title;
import org.jfree.data.xy.XYDataset;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RectangleEdge;
import org.jfree.ui.RefineryUtilities;
import org.jfree.ui.TextAnchor;

public class AnnotationDemo2 extends ApplicationFrame {
  public AnnotationDemo2(String paramString) {
    super(paramString);
    setContentPane(createDemoPanel());
  }
  
  private static XYDataset createDataset1() {
    XYSeries xYSeries = new XYSeries("Random Data 1");
    xYSeries.add(1.0D, 181.8D);
    xYSeries.add(2.0D, 167.3D);
    xYSeries.add(3.0D, 153.8D);
    xYSeries.add(4.0D, 167.6D);
    xYSeries.add(5.0D, 158.8D);
    xYSeries.add(6.0D, 148.3D);
    xYSeries.add(7.0D, 153.9D);
    xYSeries.add(8.0D, 142.7D);
    xYSeries.add(9.0D, 123.2D);
    xYSeries.add(10.0D, 131.8D);
    xYSeries.add(11.0D, 139.6D);
    xYSeries.add(12.0D, 142.9D);
    xYSeries.add(13.0D, 138.7D);
    xYSeries.add(14.0D, 137.3D);
    xYSeries.add(15.0D, 143.9D);
    xYSeries.add(16.0D, 139.8D);
    xYSeries.add(17.0D, 137.0D);
    xYSeries.add(18.0D, 132.8D);
    XYSeriesCollection xYSeriesCollection = new XYSeriesCollection();
    xYSeriesCollection.addSeries(xYSeries);
    return (XYDataset)xYSeriesCollection;
  }
  
  private static XYDataset createDataset2() {
    XYSeries xYSeries = new XYSeries("Random Data 2");
    xYSeries.add(1.0D, 429.6D);
    xYSeries.add(2.0D, 323.2D);
    xYSeries.add(3.0D, 417.2D);
    xYSeries.add(4.0D, 624.1D);
    xYSeries.add(5.0D, 422.6D);
    xYSeries.add(6.0D, 619.2D);
    xYSeries.add(7.0D, 416.5D);
    xYSeries.add(8.0D, 512.7D);
    xYSeries.add(9.0D, 501.5D);
    xYSeries.add(10.0D, 306.1D);
    xYSeries.add(11.0D, 410.3D);
    xYSeries.add(12.0D, 511.7D);
    xYSeries.add(13.0D, 611.0D);
    xYSeries.add(14.0D, 709.6D);
    xYSeries.add(15.0D, 613.2D);
    xYSeries.add(16.0D, 711.6D);
    xYSeries.add(17.0D, 708.8D);
    xYSeries.add(18.0D, 501.6D);
    XYSeriesCollection xYSeriesCollection = new XYSeriesCollection();
    xYSeriesCollection.addSeries(xYSeries);
    return (XYDataset)xYSeriesCollection;
  }
  
  private static JFreeChart createChart() {
    XYDataset xYDataset = createDataset1();
    JFreeChart jFreeChart = ChartFactory.createXYLineChart("Annotation Demo 2", "Date", "Price Per Unit", xYDataset);
    jFreeChart.removeLegend();
    XYPlot xYPlot = (XYPlot)jFreeChart.getPlot();
    xYPlot.setDomainPannable(true);
    xYPlot.setRangePannable(true);
    NumberAxis numberAxis1 = (NumberAxis)xYPlot.getRangeAxis();
    numberAxis1.setAutoRangeIncludesZero(false);
    NumberAxis numberAxis2 = new NumberAxis("Secondary");
    numberAxis2.setAutoRangeIncludesZero(false);
    xYPlot.setRangeAxis(1, (ValueAxis)numberAxis2);
    xYPlot.setDataset(1, createDataset2());
    xYPlot.mapDatasetToRangeAxis(1, 1);
    XYLineAndShapeRenderer xYLineAndShapeRenderer1 = (XYLineAndShapeRenderer)xYPlot.getRenderer();
    xYLineAndShapeRenderer1.setBaseToolTipGenerator((XYToolTipGenerator)StandardXYToolTipGenerator.getTimeSeriesInstance());
    xYLineAndShapeRenderer1.setBaseShapesVisible(true);
    xYLineAndShapeRenderer1.setBaseShapesFilled(true);
    XYPointerAnnotation xYPointerAnnotation1 = new XYPointerAnnotation("Annotation 1 (2.0, 167.3)", 2.0D, 167.3D, -0.7853981633974483D);
    xYPointerAnnotation1.setTextAnchor(TextAnchor.BOTTOM_LEFT);
    xYPointerAnnotation1.setPaint(Color.red);
    xYPointerAnnotation1.setArrowPaint(Color.red);
    xYLineAndShapeRenderer1.addAnnotation((XYAnnotation)xYPointerAnnotation1);
    XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new XYLineAndShapeRenderer(true, true);
    xYLineAndShapeRenderer2.setSeriesPaint(0, Color.black);
    xYLineAndShapeRenderer1.setBaseToolTipGenerator((XYToolTipGenerator)StandardXYToolTipGenerator.getTimeSeriesInstance());
    XYPointerAnnotation xYPointerAnnotation2 = new XYPointerAnnotation("Annotation 2 (15.0, 613.2)", 15.0D, 613.2D, 1.5707963267948966D);
    xYPointerAnnotation2.setTextAnchor(TextAnchor.TOP_CENTER);
    xYLineAndShapeRenderer2.addAnnotation((XYAnnotation)xYPointerAnnotation2);
    xYPlot.setRenderer(1, (XYItemRenderer)xYLineAndShapeRenderer2);
    LegendTitle legendTitle1 = new LegendTitle((LegendItemSource)xYLineAndShapeRenderer1);
    LegendTitle legendTitle2 = new LegendTitle((LegendItemSource)xYLineAndShapeRenderer2);
    BlockContainer blockContainer = new BlockContainer((Arrangement)new BorderArrangement());
    blockContainer.add((Block)legendTitle1, RectangleEdge.LEFT);
    blockContainer.add((Block)legendTitle2, RectangleEdge.RIGHT);
    blockContainer.add((Block)new EmptyBlock(2000.0D, 0.0D));
    CompositeTitle compositeTitle = new CompositeTitle(blockContainer);
    compositeTitle.setFrame((BlockFrame)new BlockBorder(Color.red));
    compositeTitle.setBackgroundPaint(Color.LIGHT_GRAY);
    compositeTitle.setPosition(RectangleEdge.BOTTOM);
    jFreeChart.addSubtitle((Title)compositeTitle);
    ChartUtilities.applyCurrentTheme(jFreeChart);
    return jFreeChart;
  }
  
  public static JPanel createDemoPanel() {
    JFreeChart jFreeChart = createChart();
    ChartPanel chartPanel = new ChartPanel(jFreeChart);
    chartPanel.setMouseWheelEnabled(true);
    return (JPanel)chartPanel;
  }
  
  public static void main(String[] paramArrayOfString) {
    AnnotationDemo2 annotationDemo2 = new AnnotationDemo2("JFreeChart: AnnotationDemo2.java");
    annotationDemo2.pack();
    RefineryUtilities.centerFrameOnScreen((Window)annotationDemo2);
    annotationDemo2.setVisible(true);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/AnnotationDemo2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */