package demo;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Window;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.BorderFactory;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.CompoundBorder;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableModel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.event.ChartChangeEvent;
import org.jfree.chart.event.ChartChangeListener;
import org.jfree.chart.event.ChartProgressEvent;
import org.jfree.chart.event.ChartProgressListener;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYItemRenderer;
import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
import org.jfree.data.time.Minute;
import org.jfree.data.time.RegularTimePeriod;
import org.jfree.data.time.TimeSeries;
import org.jfree.data.time.TimeSeriesCollection;
import org.jfree.data.time.TimeSeriesDataItem;
import org.jfree.data.xy.XYDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.DateCellRenderer;
import org.jfree.ui.NumberCellRenderer;
import org.jfree.ui.RefineryUtilities;

public class CrosshairDemo2 extends ApplicationFrame {
  public CrosshairDemo2(String paramString) {
    super(paramString);
    setContentPane(new MyDemoPanel());
  }
  
  public static JPanel createDemoPanel() {
    return new MyDemoPanel();
  }
  
  public static void main(String[] paramArrayOfString) {
    CrosshairDemo2 crosshairDemo2 = new CrosshairDemo2("JFreeChart: CrosshairDemo2.java");
    crosshairDemo2.pack();
    RefineryUtilities.centerFrameOnScreen((Window)crosshairDemo2);
    crosshairDemo2.setVisible(true);
  }
  
  static class DemoTableModel extends AbstractTableModel implements TableModel {
    private Object[][] data;
    
    public DemoTableModel(int param1Int) {
      this.data = new Object[param1Int][7];
    }
    
    public int getColumnCount() {
      return 7;
    }
    
    public int getRowCount() {
      return this.data.length;
    }
    
    public Object getValueAt(int param1Int1, int param1Int2) {
      return this.data[param1Int1][param1Int2];
    }
    
    public void setValueAt(Object param1Object, int param1Int1, int param1Int2) {
      this.data[param1Int1][param1Int2] = param1Object;
      fireTableDataChanged();
    }
    
    public String getColumnName(int param1Int) {
      switch (param1Int) {
        case 0:
          return "Series Name:";
        case 1:
          return "X:";
        case 2:
          return "Y:";
        case 3:
          return "X (prev)";
        case 4:
          return "Y (prev):";
        case 5:
          return "X (next):";
        case 6:
          return "Y (next):";
      } 
      return null;
    }
  }
  
  private static class MyDemoPanel extends DemoPanel implements ChartChangeListener, ChartProgressListener {
    private static final int SERIES_COUNT = 4;
    
    private TimeSeriesCollection[] datasets = new TimeSeriesCollection[4];
    
    private TimeSeries[] series = new TimeSeries[4];
    
    private ChartPanel chartPanel;
    
    private CrosshairDemo2.DemoTableModel model;
    
    public MyDemoPanel() {
      super(new BorderLayout());
      JPanel jPanel1 = new JPanel(new BorderLayout());
      JFreeChart jFreeChart = createChart();
      addChart(jFreeChart);
      this.chartPanel = new ChartPanel(jFreeChart);
      this.chartPanel.setPreferredSize(new Dimension(600, 270));
      this.chartPanel.setDomainZoomable(true);
      this.chartPanel.setRangeZoomable(true);
      CompoundBorder compoundBorder = BorderFactory.createCompoundBorder(BorderFactory.createEmptyBorder(4, 4, 4, 4), BorderFactory.createEtchedBorder());
      this.chartPanel.setBorder(compoundBorder);
      jPanel1.add((Component)this.chartPanel);
      JPanel jPanel2 = new JPanel(new BorderLayout());
      jPanel2.setPreferredSize(new Dimension(400, 120));
      jPanel2.setBorder(BorderFactory.createEmptyBorder(0, 4, 4, 4));
      this.model = new CrosshairDemo2.DemoTableModel(4);
      for (byte b = 0; b < 4; b++) {
        XYPlot xYPlot = (XYPlot)jFreeChart.getPlot();
        this.model.setValueAt(xYPlot.getDataset(b).getSeriesKey(0), b, 0);
        this.model.setValueAt(new Double("0.00"), b, 1);
        this.model.setValueAt(new Double("0.00"), b, 2);
        this.model.setValueAt(new Double("0.00"), b, 3);
        this.model.setValueAt(new Double("0.00"), b, 4);
        this.model.setValueAt(new Double("0.00"), b, 5);
        this.model.setValueAt(new Double("0.00"), b, 6);
      } 
      JTable jTable = new JTable(this.model);
      DateCellRenderer dateCellRenderer = new DateCellRenderer(new SimpleDateFormat("HH:mm:ss"));
      NumberCellRenderer numberCellRenderer = new NumberCellRenderer();
      jTable.getColumnModel().getColumn(1).setCellRenderer((TableCellRenderer)dateCellRenderer);
      jTable.getColumnModel().getColumn(2).setCellRenderer((TableCellRenderer)numberCellRenderer);
      jTable.getColumnModel().getColumn(3).setCellRenderer((TableCellRenderer)dateCellRenderer);
      jTable.getColumnModel().getColumn(4).setCellRenderer((TableCellRenderer)numberCellRenderer);
      jTable.getColumnModel().getColumn(5).setCellRenderer((TableCellRenderer)dateCellRenderer);
      jTable.getColumnModel().getColumn(6).setCellRenderer((TableCellRenderer)numberCellRenderer);
      jPanel2.add(new JScrollPane(jTable));
      jPanel1.add(jPanel2, "South");
      add(jPanel1);
    }
    
    private XYDataset createDataset(int param1Int1, String param1String, double param1Double, RegularTimePeriod param1RegularTimePeriod, int param1Int2) {
      this.series[param1Int1] = new TimeSeries(param1String);
      RegularTimePeriod regularTimePeriod = param1RegularTimePeriod;
      double d = param1Double;
      for (byte b = 0; b < param1Int2; b++) {
        this.series[param1Int1].add(regularTimePeriod, d);
        regularTimePeriod = regularTimePeriod.next();
        d *= 1.0D + (Math.random() - 0.495D) / 10.0D;
      } 
      this.datasets[param1Int1] = new TimeSeriesCollection();
      this.datasets[param1Int1].addSeries(this.series[param1Int1]);
      return (XYDataset)this.datasets[param1Int1];
    }
    
    public void chartChanged(ChartChangeEvent param1ChartChangeEvent) {
      if (this.chartPanel == null)
        return; 
      JFreeChart jFreeChart = this.chartPanel.getChart();
      if (jFreeChart != null) {
        XYPlot xYPlot = (XYPlot)jFreeChart.getPlot();
        XYDataset xYDataset = xYPlot.getDataset();
        Comparable comparable = xYDataset.getSeriesKey(0);
        double d = xYPlot.getDomainCrosshairValue();
        this.model.setValueAt(comparable, 0, 0);
        long l = (long)d;
        for (byte b = 0; b < 4; b++) {
          double d3;
          this.model.setValueAt(new Long(l), b, 1);
          int[] arrayOfInt = this.datasets[b].getSurroundingItems(0, l);
          long l1 = 0L;
          long l2 = 0L;
          double d1 = 0.0D;
          double d2 = 0.0D;
          if (arrayOfInt[0] >= 0) {
            TimeSeriesDataItem timeSeriesDataItem = this.series[b].getDataItem(arrayOfInt[0]);
            l1 = timeSeriesDataItem.getPeriod().getMiddleMillisecond();
            Number number = timeSeriesDataItem.getValue();
            if (number != null) {
              d1 = number.doubleValue();
              this.model.setValueAt(new Double(d1), b, 4);
            } else {
              this.model.setValueAt(null, b, 4);
            } 
            this.model.setValueAt(new Long(l1), b, 3);
          } else {
            this.model.setValueAt(new Double(0.0D), b, 4);
            this.model.setValueAt(new Double(xYPlot.getDomainAxis().getRange().getLowerBound()), b, 3);
          } 
          if (arrayOfInt[1] >= 0) {
            TimeSeriesDataItem timeSeriesDataItem = this.series[b].getDataItem(arrayOfInt[1]);
            l2 = timeSeriesDataItem.getPeriod().getMiddleMillisecond();
            Number number = timeSeriesDataItem.getValue();
            if (number != null) {
              d2 = number.doubleValue();
              this.model.setValueAt(new Double(d2), b, 6);
            } else {
              this.model.setValueAt(null, b, 6);
            } 
            this.model.setValueAt(new Long(l2), b, 5);
          } else {
            this.model.setValueAt(new Double(0.0D), b, 6);
            this.model.setValueAt(new Double(xYPlot.getDomainAxis().getRange().getUpperBound()), b, 5);
          } 
          if (l2 - l1 > 0L) {
            d3 = d1 + (l - l1) / (l2 - l1) * (d2 - d1);
          } else {
            d3 = d1;
          } 
          this.model.setValueAt(new Double(d3), b, 2);
        } 
      } 
    }
    
    private JFreeChart createChart() {
      JFreeChart jFreeChart = ChartFactory.createTimeSeriesChart("Crosshair Demo 2", "Time of Day", "Value", null, true, true, false);
      XYPlot xYPlot = (XYPlot)jFreeChart.getPlot();
      XYDataset[] arrayOfXYDataset = new XYDataset[4];
      for (byte b = 0; b < 4; b++) {
        arrayOfXYDataset[b] = createDataset(b, "Series " + b, 100.0D + b * 200.0D, (RegularTimePeriod)new Minute(), 200);
        if (b == 0) {
          xYPlot.setDataset(arrayOfXYDataset[b]);
        } else {
          xYPlot.setDataset(b, arrayOfXYDataset[b]);
          xYPlot.setRangeAxis(b, (ValueAxis)new NumberAxis("Axis " + (b + 1)));
          xYPlot.mapDatasetToRangeAxis(b, b);
          xYPlot.setRenderer(b, (XYItemRenderer)new XYLineAndShapeRenderer(true, false));
        } 
      } 
      jFreeChart.addChangeListener(this);
      jFreeChart.addProgressListener(this);
      xYPlot.setOrientation(PlotOrientation.VERTICAL);
      xYPlot.setDomainCrosshairVisible(true);
      xYPlot.setDomainCrosshairLockedOnData(false);
      xYPlot.setRangeCrosshairVisible(false);
      ChartUtilities.applyCurrentTheme(jFreeChart);
      return jFreeChart;
    }
    
    public void chartProgress(ChartProgressEvent param1ChartProgressEvent) {
      if (param1ChartProgressEvent.getType() != 2)
        return; 
      if (this.chartPanel == null)
        return; 
      JFreeChart jFreeChart = this.chartPanel.getChart();
      if (jFreeChart != null) {
        XYPlot xYPlot = (XYPlot)jFreeChart.getPlot();
        XYDataset xYDataset = xYPlot.getDataset();
        Comparable comparable = xYDataset.getSeriesKey(0);
        double d = xYPlot.getDomainCrosshairValue();
        this.model.setValueAt(comparable, 0, 0);
        long l = (long)d;
        this.model.setValueAt(new Long(l), 0, 1);
        for (byte b = 0; b < 4; b++) {
          int i = this.series[b].getIndex((RegularTimePeriod)new Minute(new Date(l)));
          if (i >= 0) {
            TimeSeriesDataItem timeSeriesDataItem1 = this.series[b].getDataItem(Math.min(199, Math.max(0, i)));
            TimeSeriesDataItem timeSeriesDataItem2 = this.series[b].getDataItem(Math.max(0, i - 1));
            TimeSeriesDataItem timeSeriesDataItem3 = this.series[b].getDataItem(Math.min(199, i + 1));
            long l1 = timeSeriesDataItem1.getPeriod().getMiddleMillisecond();
            double d1 = timeSeriesDataItem1.getValue().doubleValue();
            long l2 = timeSeriesDataItem2.getPeriod().getMiddleMillisecond();
            double d2 = timeSeriesDataItem2.getValue().doubleValue();
            long l3 = timeSeriesDataItem3.getPeriod().getMiddleMillisecond();
            double d3 = timeSeriesDataItem3.getValue().doubleValue();
            this.model.setValueAt(new Long(l1), b, 1);
            this.model.setValueAt(new Double(d1), b, 2);
            this.model.setValueAt(new Long(l2), b, 3);
            this.model.setValueAt(new Double(d2), b, 4);
            this.model.setValueAt(new Long(l3), b, 5);
            this.model.setValueAt(new Double(d3), b, 6);
          } 
        } 
      } 
    }
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/CrosshairDemo2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */