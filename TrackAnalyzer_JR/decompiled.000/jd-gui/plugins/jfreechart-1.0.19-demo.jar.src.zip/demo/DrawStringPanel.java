package demo;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Insets;
import java.awt.geom.Line2D;
import java.awt.geom.Rectangle2D;
import javax.swing.JPanel;
import org.jfree.text.TextUtilities;
import org.jfree.ui.TextAnchor;

public class DrawStringPanel extends JPanel {
  private static final Dimension PREFERRED_SIZE = new Dimension(500, 300);
  
  private boolean rotate;
  
  private String text = "Hello World";
  
  private TextAnchor anchor = TextAnchor.TOP_LEFT;
  
  private TextAnchor rotationAnchor = TextAnchor.TOP_LEFT;
  
  private Font font = new Font("Serif", 0, 12);
  
  private double angle;
  
  public DrawStringPanel(String paramString, boolean paramBoolean) {
    this.text = paramString;
    this.rotate = paramBoolean;
  }
  
  public Dimension getPreferredSize() {
    return PREFERRED_SIZE;
  }
  
  public void setAnchor(TextAnchor paramTextAnchor) {
    this.anchor = paramTextAnchor;
  }
  
  public void setRotationAnchor(TextAnchor paramTextAnchor) {
    this.rotationAnchor = paramTextAnchor;
  }
  
  public void setAngle(double paramDouble) {
    this.angle = paramDouble;
  }
  
  public Font getFont() {
    return this.font;
  }
  
  public void setFont(Font paramFont) {
    this.font = paramFont;
  }
  
  public void paintComponent(Graphics paramGraphics) {
    super.paintComponent(paramGraphics);
    Graphics2D graphics2D = (Graphics2D)paramGraphics;
    Dimension dimension = getSize();
    Insets insets = getInsets();
    Rectangle2D.Double double_ = new Rectangle2D.Double(insets.left, insets.top, dimension.getWidth() - insets.left - insets.right, dimension.getHeight() - insets.top - insets.bottom);
    double d1 = double_.getCenterX();
    double d2 = double_.getCenterY();
    Line2D.Double double_1 = new Line2D.Double(d1 - 2.0D, d2 + 2.0D, d1 + 2.0D, d2 - 2.0D);
    Line2D.Double double_2 = new Line2D.Double(d1 - 2.0D, d2 - 2.0D, d1 + 2.0D, d2 + 2.0D);
    graphics2D.setPaint(Color.red);
    graphics2D.draw(double_1);
    graphics2D.draw(double_2);
    graphics2D.setFont(this.font);
    graphics2D.setPaint(Color.black);
    if (this.rotate) {
      TextUtilities.drawRotatedString(this.text, graphics2D, (float)d1, (float)d2, this.anchor, this.angle, this.rotationAnchor);
    } else {
      TextUtilities.drawAlignedString(this.text, graphics2D, (float)d1, (float)d2, this.anchor);
    } 
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/DrawStringPanel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */