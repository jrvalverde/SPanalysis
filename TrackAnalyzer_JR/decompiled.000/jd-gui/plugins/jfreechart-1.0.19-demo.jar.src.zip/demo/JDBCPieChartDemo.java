package demo;

import java.awt.Color;
import java.awt.Container;
import java.awt.Window;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PiePlot;
import org.jfree.data.general.PieDataset;
import org.jfree.data.jdbc.JDBCPieDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

public class JDBCPieChartDemo extends ApplicationFrame {
  public JDBCPieChartDemo(String paramString) {
    super(paramString);
    PieDataset pieDataset = readData();
    JFreeChart jFreeChart = ChartFactory.createPieChart("JDBC Pie Chart Demo", pieDataset, true, true, false);
    jFreeChart.setBackgroundPaint(Color.yellow);
    PiePlot piePlot = (PiePlot)jFreeChart.getPlot();
    piePlot.setNoDataMessage("No data available");
    ChartPanel chartPanel = new ChartPanel(jFreeChart);
    setContentPane((Container)chartPanel);
  }
  
  private PieDataset readData() {
    JDBCPieDataset jDBCPieDataset = null;
    String str = "jdbc:postgresql://nomad/jfreechartdb";
    try {
      Class.forName("org.postgresql.Driver");
    } catch (ClassNotFoundException classNotFoundException) {
      System.err.print("ClassNotFoundException: ");
      System.err.println(classNotFoundException.getMessage());
    } 
    try {
      Connection connection = DriverManager.getConnection(str, "jfreechart", "password");
      jDBCPieDataset = new JDBCPieDataset(connection);
      String str1 = "SELECT * FROM PIEDATA1;";
      jDBCPieDataset.executeQuery(str1);
      connection.close();
    } catch (SQLException sQLException) {
      System.err.print("SQLException: ");
      System.err.println(sQLException.getMessage());
    } catch (Exception exception) {
      System.err.print("Exception: ");
      System.err.println(exception.getMessage());
    } 
    return (PieDataset)jDBCPieDataset;
  }
  
  public static void main(String[] paramArrayOfString) {
    JDBCPieChartDemo jDBCPieChartDemo = new JDBCPieChartDemo("JDBC Pie Chart Demo");
    jDBCPieChartDemo.pack();
    RefineryUtilities.centerFrameOnScreen((Window)jDBCPieChartDemo);
    jDBCPieChartDemo.setVisible(true);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/JDBCPieChartDemo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */