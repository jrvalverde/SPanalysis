package demo;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.Timer;
import org.jfree.data.category.DefaultCategoryDataset;

class Animator extends Timer implements ActionListener {
  private DefaultCategoryDataset dataset;
  
  Animator(DefaultCategoryDataset paramDefaultCategoryDataset) {
    super(20, null);
    this.dataset = paramDefaultCategoryDataset;
    addActionListener(this);
  }
  
  public void actionPerformed(ActionEvent paramActionEvent) {
    int i = (int)(Math.random() * this.dataset.getRowCount());
    Comparable comparable1 = this.dataset.getRowKey(i);
    int j = (int)(Math.random() * this.dataset.getColumnCount());
    Comparable comparable2 = this.dataset.getColumnKey(j);
    boolean bool = (Math.random() - 0.5D < 0.0D) ? true : true;
    this.dataset.setValue(Math.max(0.0D, this.dataset.getValue(i, j).doubleValue() + bool), comparable1, comparable2);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/Animator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */