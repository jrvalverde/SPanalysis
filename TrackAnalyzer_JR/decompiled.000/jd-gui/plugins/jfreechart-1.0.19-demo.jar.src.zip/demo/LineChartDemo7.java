package demo;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Window;
import javax.swing.JPanel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.renderer.category.LineAndShapeRenderer;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;
import org.jfree.util.ShapeUtilities;

public class LineChartDemo7 extends ApplicationFrame {
  public LineChartDemo7(String paramString) {
    super(paramString);
    JPanel jPanel = createDemoPanel();
    jPanel.setPreferredSize(new Dimension(500, 270));
    setContentPane(jPanel);
  }
  
  private static CategoryDataset createDataset() {
    DefaultCategoryDataset defaultCategoryDataset = new DefaultCategoryDataset();
    defaultCategoryDataset.addValue(21.0D, "Series 1", "Category 1");
    defaultCategoryDataset.addValue(50.0D, "Series 1", "Category 2");
    defaultCategoryDataset.addValue(152.0D, "Series 1", "Category 3");
    defaultCategoryDataset.addValue(184.0D, "Series 1", "Category 4");
    defaultCategoryDataset.addValue(299.0D, "Series 1", "Category 5");
    defaultCategoryDataset.addValue(275.0D, "Series 2", "Category 1");
    defaultCategoryDataset.addValue(121.0D, "Series 2", "Category 2");
    defaultCategoryDataset.addValue(98.0D, "Series 2", "Category 3");
    defaultCategoryDataset.addValue(103.0D, "Series 2", "Category 4");
    defaultCategoryDataset.addValue(210.0D, "Series 2", "Category 5");
    defaultCategoryDataset.addValue(198.0D, "Series 3", "Category 1");
    defaultCategoryDataset.addValue(165.0D, "Series 3", "Category 2");
    defaultCategoryDataset.addValue(55.0D, "Series 3", "Category 3");
    defaultCategoryDataset.addValue(34.0D, "Series 3", "Category 4");
    defaultCategoryDataset.addValue(77.0D, "Series 3", "Category 5");
    return (CategoryDataset)defaultCategoryDataset;
  }
  
  private static JFreeChart createChart(CategoryDataset paramCategoryDataset) {
    JFreeChart jFreeChart = ChartFactory.createLineChart("Line Chart Demo 7", "Category", "Count", paramCategoryDataset, PlotOrientation.VERTICAL, true, true, false);
    CategoryPlot categoryPlot = (CategoryPlot)jFreeChart.getPlot();
    NumberAxis numberAxis = (NumberAxis)categoryPlot.getRangeAxis();
    numberAxis.setStandardTickUnits(NumberAxis.createIntegerTickUnits());
    LineAndShapeRenderer lineAndShapeRenderer = (LineAndShapeRenderer)categoryPlot.getRenderer();
    lineAndShapeRenderer.setSeriesShapesVisible(0, true);
    lineAndShapeRenderer.setSeriesShapesVisible(1, false);
    lineAndShapeRenderer.setSeriesShapesVisible(2, true);
    lineAndShapeRenderer.setSeriesLinesVisible(2, false);
    lineAndShapeRenderer.setSeriesShape(2, ShapeUtilities.createDiamond(4.0F));
    lineAndShapeRenderer.setDrawOutlines(true);
    lineAndShapeRenderer.setUseFillPaint(true);
    lineAndShapeRenderer.setBaseFillPaint(Color.white);
    return jFreeChart;
  }
  
  public static JPanel createDemoPanel() {
    JFreeChart jFreeChart = createChart(createDataset());
    return (JPanel)new ChartPanel(jFreeChart);
  }
  
  public static void main(String[] paramArrayOfString) {
    LineChartDemo7 lineChartDemo7 = new LineChartDemo7("JFreeChart: LineChartDemo7.java");
    lineChartDemo7.pack();
    RefineryUtilities.centerFrameOnScreen((Window)lineChartDemo7);
    lineChartDemo7.setVisible(true);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/LineChartDemo7.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */