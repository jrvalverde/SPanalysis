package demo;

import java.io.File;
import java.io.IOException;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.data.xy.XYDataset;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;
import org.jfree.ui.RectangleInsets;

public class SparklineDemo1 {
  public static void main(String[] paramArrayOfString) {
    XYSeries xYSeries = new XYSeries("Series 1");
    xYSeries.add(1.0D, 1.0D);
    xYSeries.add(2.0D, 3.0D);
    xYSeries.add(3.0D, 2.0D);
    xYSeries.add(4.0D, 4.0D);
    XYSeriesCollection xYSeriesCollection = new XYSeriesCollection();
    xYSeriesCollection.addSeries(xYSeries);
    JFreeChart jFreeChart = ChartFactory.createXYLineChart(null, "X", "Y", (XYDataset)xYSeriesCollection, PlotOrientation.VERTICAL, false, false, false);
    XYPlot xYPlot = (XYPlot)jFreeChart.getPlot();
    xYPlot.setInsets(RectangleInsets.ZERO_INSETS);
    xYPlot.setDomainGridlinesVisible(false);
    xYPlot.setRangeGridlinesVisible(false);
    xYPlot.setOutlinePaint(null);
    xYPlot.getDomainAxis().setVisible(false);
    xYPlot.getRangeAxis().setVisible(false);
    try {
      ChartUtilities.saveChartAsPNG(new File("Sparky.png"), jFreeChart, 100, 20);
    } catch (IOException iOException) {
      iOException.printStackTrace();
    } 
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/SparklineDemo1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */