package demo;

import java.awt.Dimension;
import java.awt.Window;
import javax.swing.JPanel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.data.function.Function2D;
import org.jfree.data.general.DatasetUtilities;
import org.jfree.data.xy.XYDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

public class Function2DDemo1 extends ApplicationFrame {
  public Function2DDemo1(String paramString) {
    super(paramString);
    JPanel jPanel = createDemoPanel();
    jPanel.setPreferredSize(new Dimension(500, 270));
    setContentPane(jPanel);
  }
  
  private static JFreeChart createChart(XYDataset paramXYDataset) {
    JFreeChart jFreeChart = ChartFactory.createXYLineChart("Function2DDemo1 ", "X", "Y", paramXYDataset, PlotOrientation.VERTICAL, true, true, false);
    XYPlot xYPlot = (XYPlot)jFreeChart.getPlot();
    xYPlot.setDomainPannable(true);
    xYPlot.setRangePannable(true);
    ValueAxis valueAxis1 = xYPlot.getDomainAxis();
    valueAxis1.setLowerMargin(0.0D);
    valueAxis1.setUpperMargin(0.0D);
    valueAxis1.setRange(-2.0D, 2.0D);
    ValueAxis valueAxis2 = xYPlot.getRangeAxis();
    valueAxis2.setRange(0.0D, 5.0D);
    return jFreeChart;
  }
  
  public static XYDataset createDataset() {
    return DatasetUtilities.sampleFunction2D(new X2(), -40.0D, 40.0D, 400, "f(x)");
  }
  
  public static JPanel createDemoPanel() {
    JFreeChart jFreeChart = createChart(createDataset());
    ChartPanel chartPanel = new ChartPanel(jFreeChart);
    chartPanel.setMouseWheelEnabled(true);
    return (JPanel)chartPanel;
  }
  
  public static void main(String[] paramArrayOfString) {
    Function2DDemo1 function2DDemo1 = new Function2DDemo1("JFreeChart: Function2DDemo1.java");
    function2DDemo1.pack();
    RefineryUtilities.centerFrameOnScreen((Window)function2DDemo1);
    function2DDemo1.setVisible(true);
  }
  
  static class X2 implements Function2D {
    public double getValue(double param1Double) {
      return param1Double * param1Double + 2.0D;
    }
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/Function2DDemo1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */