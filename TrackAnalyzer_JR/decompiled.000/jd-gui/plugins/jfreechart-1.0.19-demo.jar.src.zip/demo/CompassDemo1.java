package demo;

import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Window;
import javax.swing.JPanel;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.CompassPlot;
import org.jfree.chart.plot.Plot;
import org.jfree.data.general.DefaultValueDataset;
import org.jfree.data.general.ValueDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

public class CompassDemo1 extends ApplicationFrame {
  public CompassDemo1(String paramString) {
    super(paramString);
    ChartPanel chartPanel = (ChartPanel)createDemoPanel();
    chartPanel.setPreferredSize(new Dimension(500, 270));
    chartPanel.setEnforceFileExtensions(false);
    setContentPane((Container)chartPanel);
  }
  
  private static JFreeChart createChart(ValueDataset paramValueDataset) {
    CompassPlot compassPlot = new CompassPlot(paramValueDataset);
    compassPlot.setSeriesNeedle(7);
    compassPlot.setSeriesPaint(0, Color.black);
    compassPlot.setSeriesOutlinePaint(0, Color.black);
    compassPlot.setRosePaint(Color.red);
    compassPlot.setRoseHighlightPaint(Color.gray);
    compassPlot.setRoseCenterPaint(Color.white);
    compassPlot.setDrawBorder(false);
    JFreeChart jFreeChart = new JFreeChart((Plot)compassPlot);
    ChartUtilities.applyCurrentTheme(jFreeChart);
    return jFreeChart;
  }
  
  public static JPanel createDemoPanel() {
    JFreeChart jFreeChart = createChart((ValueDataset)new DefaultValueDataset(new Double(45.0D)));
    return (JPanel)new ChartPanel(jFreeChart);
  }
  
  public static void main(String[] paramArrayOfString) {
    CompassDemo1 compassDemo1 = new CompassDemo1("JFreeChart: CompassDemo1.java");
    compassDemo1.pack();
    RefineryUtilities.centerFrameOnScreen((Window)compassDemo1);
    compassDemo1.setVisible(true);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/CompassDemo1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */