package demo;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GradientPaint;
import java.awt.Point;
import java.awt.RadialGradientPaint;
import java.awt.Window;
import java.awt.geom.Point2D;
import javax.swing.JPanel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.ChartTheme;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.StandardChartTheme;
import org.jfree.chart.plot.PiePlot;
import org.jfree.chart.title.TextTitle;
import org.jfree.chart.title.Title;
import org.jfree.data.general.DefaultPieDataset;
import org.jfree.data.general.PieDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.HorizontalAlignment;
import org.jfree.ui.RectangleEdge;
import org.jfree.ui.RectangleInsets;
import org.jfree.ui.RefineryUtilities;

public class PieChartDemo1 extends ApplicationFrame {
  private static final long serialVersionUID = 1L;
  
  public PieChartDemo1(String paramString) {
    super(paramString);
    ChartFactory.setChartTheme((ChartTheme)new StandardChartTheme("JFree/Shadow", true));
    setContentPane(createDemoPanel());
  }
  
  private static PieDataset createDataset() {
    DefaultPieDataset defaultPieDataset = new DefaultPieDataset();
    defaultPieDataset.setValue("Samsung", new Double(27.8D));
    defaultPieDataset.setValue("Others", new Double(55.3D));
    defaultPieDataset.setValue("Nokia", new Double(16.8D));
    defaultPieDataset.setValue("Apple", new Double(17.1D));
    return (PieDataset)defaultPieDataset;
  }
  
  private static JFreeChart createChart(PieDataset paramPieDataset) {
    JFreeChart jFreeChart = ChartFactory.createPieChart("Smart Phones Manufactured / Q3 2011", paramPieDataset, false, true, false);
    jFreeChart.setBackgroundPaint(new GradientPaint(new Point(0, 0), new Color(20, 20, 20), new Point(400, 200), Color.DARK_GRAY));
    TextTitle textTitle1 = jFreeChart.getTitle();
    textTitle1.setHorizontalAlignment(HorizontalAlignment.LEFT);
    textTitle1.setPaint(new Color(240, 240, 240));
    textTitle1.setFont(new Font("Arial", 1, 26));
    PiePlot piePlot = (PiePlot)jFreeChart.getPlot();
    piePlot.setBackgroundPaint(null);
    piePlot.setInteriorGap(0.04D);
    piePlot.setOutlineVisible(false);
    piePlot.setSectionPaint("Others", createGradientPaint(new Color(200, 200, 255), Color.BLUE));
    piePlot.setSectionPaint("Samsung", createGradientPaint(new Color(255, 200, 200), Color.RED));
    piePlot.setSectionPaint("Apple", createGradientPaint(new Color(200, 255, 200), Color.GREEN));
    piePlot.setSectionPaint("Nokia", createGradientPaint(new Color(200, 255, 200), Color.YELLOW));
    piePlot.setBaseSectionOutlinePaint(Color.WHITE);
    piePlot.setSectionOutlinesVisible(true);
    piePlot.setBaseSectionOutlineStroke(new BasicStroke(2.0F));
    piePlot.setLabelFont(new Font("Courier New", 1, 20));
    piePlot.setLabelLinkPaint(Color.WHITE);
    piePlot.setLabelLinkStroke(new BasicStroke(2.0F));
    piePlot.setLabelOutlineStroke(null);
    piePlot.setLabelPaint(Color.WHITE);
    piePlot.setLabelBackgroundPaint(null);
    TextTitle textTitle2 = new TextTitle("Source: http://www.bbc.co.uk/news/business-15489523", new Font("Courier New", 0, 12));
    textTitle2.setPaint(Color.WHITE);
    textTitle2.setPosition(RectangleEdge.BOTTOM);
    textTitle2.setHorizontalAlignment(HorizontalAlignment.RIGHT);
    jFreeChart.addSubtitle((Title)textTitle2);
    return jFreeChart;
  }
  
  private static RadialGradientPaint createGradientPaint(Color paramColor1, Color paramColor2) {
    Point2D.Float float_ = new Point2D.Float(0.0F, 0.0F);
    float f = 200.0F;
    float[] arrayOfFloat = { 0.0F, 1.0F };
    return new RadialGradientPaint(float_, f, arrayOfFloat, new Color[] { paramColor1, paramColor2 });
  }
  
  public static JPanel createDemoPanel() {
    JFreeChart jFreeChart = createChart(createDataset());
    jFreeChart.setPadding(new RectangleInsets(4.0D, 8.0D, 2.0D, 2.0D));
    ChartPanel chartPanel = new ChartPanel(jFreeChart);
    chartPanel.setMouseWheelEnabled(true);
    chartPanel.setPreferredSize(new Dimension(600, 300));
    return (JPanel)chartPanel;
  }
  
  public static void main(String[] paramArrayOfString) {
    PieChartDemo1 pieChartDemo1 = new PieChartDemo1("JFreeChart: Pie Chart Demo 1");
    pieChartDemo1.pack();
    RefineryUtilities.centerFrameOnScreen((Window)pieChartDemo1);
    pieChartDemo1.setVisible(true);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/PieChartDemo1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */