package demo;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Window;
import java.text.SimpleDateFormat;
import javax.swing.JPanel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.PeriodAxis;
import org.jfree.chart.axis.PeriodAxisLabelInfo;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.IntervalMarker;
import org.jfree.chart.plot.Marker;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.ValueMarker;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYItemRenderer;
import org.jfree.data.time.Day;
import org.jfree.data.time.Hour;
import org.jfree.data.time.RegularTimePeriod;
import org.jfree.data.time.TimeSeries;
import org.jfree.data.time.TimeSeriesCollection;
import org.jfree.data.xy.XYDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.Layer;
import org.jfree.ui.LengthAdjustmentType;
import org.jfree.ui.RectangleAnchor;
import org.jfree.ui.RefineryUtilities;
import org.jfree.ui.TextAnchor;

public class MarkerDemo2 extends ApplicationFrame {
  public MarkerDemo2(String paramString) {
    super(paramString);
    XYDataset xYDataset = createDataset();
    JFreeChart jFreeChart = createChart(xYDataset);
    ChartPanel chartPanel = new ChartPanel(jFreeChart);
    chartPanel.setPreferredSize(new Dimension(500, 270));
    chartPanel.setDomainZoomable(true);
    chartPanel.setRangeZoomable(true);
    setContentPane((Container)chartPanel);
  }
  
  private static JFreeChart createChart(XYDataset paramXYDataset) {
    JFreeChart jFreeChart = ChartFactory.createXYLineChart("Marker Demo 2", "X", "Temperature", paramXYDataset, PlotOrientation.VERTICAL, false, true, false);
    XYPlot xYPlot = (XYPlot)jFreeChart.getPlot();
    PeriodAxis periodAxis = new PeriodAxis(null, (RegularTimePeriod)new Hour(0, 30, 6, 2005), (RegularTimePeriod)new Hour(23, 30, 6, 2005));
    PeriodAxisLabelInfo[] arrayOfPeriodAxisLabelInfo = new PeriodAxisLabelInfo[2];
    arrayOfPeriodAxisLabelInfo[0] = new PeriodAxisLabelInfo(Hour.class, new SimpleDateFormat("HH"));
    arrayOfPeriodAxisLabelInfo[1] = new PeriodAxisLabelInfo(Day.class, new SimpleDateFormat("dd-MMM"));
    periodAxis.setLabelInfo(arrayOfPeriodAxisLabelInfo);
    xYPlot.setDomainAxis((ValueAxis)periodAxis);
    ChartUtilities.applyCurrentTheme(jFreeChart);
    xYPlot.setDomainGridlinePaint(Color.lightGray);
    xYPlot.setDomainGridlineStroke(new BasicStroke(1.0F));
    xYPlot.setRangeGridlinePaint(Color.lightGray);
    xYPlot.setRangeGridlineStroke(new BasicStroke(1.0F));
    xYPlot.setRangeTickBandPaint(new Color(240, 240, 240));
    ValueAxis valueAxis = xYPlot.getRangeAxis();
    valueAxis.setRange(0.0D, 100.0D);
    XYItemRenderer xYItemRenderer = xYPlot.getRenderer();
    xYItemRenderer.setSeriesPaint(0, Color.green);
    xYItemRenderer.setSeriesStroke(0, new BasicStroke(2.0F));
    ValueMarker valueMarker1 = new ValueMarker(80.0D);
    valueMarker1.setLabelOffsetType(LengthAdjustmentType.EXPAND);
    valueMarker1.setPaint(Color.red);
    valueMarker1.setStroke(new BasicStroke(2.0F));
    valueMarker1.setLabel("Temperature Threshold");
    valueMarker1.setLabelFont(new Font("SansSerif", 0, 11));
    valueMarker1.setLabelPaint(Color.red);
    valueMarker1.setLabelAnchor(RectangleAnchor.TOP_LEFT);
    valueMarker1.setLabelTextAnchor(TextAnchor.BOTTOM_LEFT);
    xYPlot.addRangeMarker((Marker)valueMarker1);
    Hour hour1 = new Hour(18, 30, 6, 2005);
    Hour hour2 = new Hour(20, 30, 6, 2005);
    double d1 = hour1.getFirstMillisecond();
    double d2 = hour2.getFirstMillisecond();
    IntervalMarker intervalMarker = new IntervalMarker(d1, d2);
    intervalMarker.setLabelOffsetType(LengthAdjustmentType.EXPAND);
    intervalMarker.setPaint(new Color(150, 150, 255));
    intervalMarker.setLabel("Automatic Cooling");
    intervalMarker.setLabelFont(new Font("SansSerif", 0, 11));
    intervalMarker.setLabelPaint(Color.blue);
    intervalMarker.setLabelAnchor(RectangleAnchor.TOP_LEFT);
    intervalMarker.setLabelTextAnchor(TextAnchor.TOP_RIGHT);
    xYPlot.addDomainMarker((Marker)intervalMarker, Layer.BACKGROUND);
    ValueMarker valueMarker2 = new ValueMarker(d1, Color.blue, new BasicStroke(2.0F));
    ValueMarker valueMarker3 = new ValueMarker(d2, Color.blue, new BasicStroke(2.0F));
    xYPlot.addDomainMarker((Marker)valueMarker2, Layer.BACKGROUND);
    xYPlot.addDomainMarker((Marker)valueMarker3, Layer.BACKGROUND);
    return jFreeChart;
  }
  
  private static XYDataset createDataset() {
    TimeSeriesCollection timeSeriesCollection = new TimeSeriesCollection();
    TimeSeries timeSeries = new TimeSeries("Temperature");
    timeSeries.add((RegularTimePeriod)new Hour(0, 30, 6, 2005), 45.3D);
    timeSeries.add((RegularTimePeriod)new Hour(1, 30, 6, 2005), 48.9D);
    timeSeries.add((RegularTimePeriod)new Hour(2, 30, 6, 2005), 52.1D);
    timeSeries.add((RegularTimePeriod)new Hour(3, 30, 6, 2005), 44.8D);
    timeSeries.add((RegularTimePeriod)new Hour(4, 30, 6, 2005), 49.9D);
    timeSeries.add((RegularTimePeriod)new Hour(5, 30, 6, 2005), 55.5D);
    timeSeries.add((RegularTimePeriod)new Hour(6, 30, 6, 2005), 58.2D);
    timeSeries.add((RegularTimePeriod)new Hour(7, 30, 6, 2005), 58.1D);
    timeSeries.add((RegularTimePeriod)new Hour(8, 30, 6, 2005), 63.7D);
    timeSeries.add((RegularTimePeriod)new Hour(9, 30, 6, 2005), 66.3D);
    timeSeries.add((RegularTimePeriod)new Hour(10, 30, 6, 2005), 69.8D);
    timeSeries.add((RegularTimePeriod)new Hour(11, 30, 6, 2005), 70.1D);
    timeSeries.add((RegularTimePeriod)new Hour(12, 30, 6, 2005), 72.4D);
    timeSeries.add((RegularTimePeriod)new Hour(13, 30, 6, 2005), 69.7D);
    timeSeries.add((RegularTimePeriod)new Hour(14, 30, 6, 2005), 68.6D);
    timeSeries.add((RegularTimePeriod)new Hour(15, 30, 6, 2005), 70.9D);
    timeSeries.add((RegularTimePeriod)new Hour(16, 30, 6, 2005), 73.4D);
    timeSeries.add((RegularTimePeriod)new Hour(17, 30, 6, 2005), 77.5D);
    timeSeries.add((RegularTimePeriod)new Hour(18, 30, 6, 2005), 82.9D);
    timeSeries.add((RegularTimePeriod)new Hour(19, 30, 6, 2005), 62.1D);
    timeSeries.add((RegularTimePeriod)new Hour(20, 30, 6, 2005), 37.3D);
    timeSeries.add((RegularTimePeriod)new Hour(21, 30, 6, 2005), 40.7D);
    timeSeries.add((RegularTimePeriod)new Hour(22, 30, 6, 2005), 44.2D);
    timeSeries.add((RegularTimePeriod)new Hour(23, 30, 6, 2005), 49.8D);
    timeSeriesCollection.addSeries(timeSeries);
    return (XYDataset)timeSeriesCollection;
  }
  
  public static JPanel createDemoPanel() {
    JFreeChart jFreeChart = createChart(createDataset());
    return (JPanel)new ChartPanel(jFreeChart);
  }
  
  public static void main(String[] paramArrayOfString) {
    MarkerDemo2 markerDemo2 = new MarkerDemo2("JFreeChart: MarkerDemo2.java");
    markerDemo2.pack();
    RefineryUtilities.centerFrameOnScreen((Window)markerDemo2);
    markerDemo2.setVisible(true);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/MarkerDemo2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */