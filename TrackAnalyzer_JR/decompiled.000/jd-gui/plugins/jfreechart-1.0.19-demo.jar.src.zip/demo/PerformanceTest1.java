package demo;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Window;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import javax.swing.JPanel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.StandardXYItemRenderer;
import org.jfree.chart.renderer.xy.XYItemRenderer;
import org.jfree.data.time.FixedMillisecond;
import org.jfree.data.time.Millisecond;
import org.jfree.data.time.RegularTimePeriod;
import org.jfree.data.time.TimeSeries;
import org.jfree.data.time.TimeSeriesCollection;
import org.jfree.data.xy.XYDataset;
import org.jfree.data.xy.XYSeries;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RectangleInsets;
import org.jfree.ui.RefineryUtilities;

public class PerformanceTest1 extends ApplicationFrame {
  private TimeSeries timings = new TimeSeries("Timings");
  
  public PerformanceTest1(String paramString) {
    super(paramString);
    TimeSeriesCollection timeSeriesCollection = new TimeSeriesCollection(this.timings);
    JFreeChart jFreeChart = createChart((XYDataset)timeSeriesCollection);
    ChartPanel chartPanel = new ChartPanel(jFreeChart);
    chartPanel.setPreferredSize(new Dimension(500, 270));
    chartPanel.setMouseZoomable(true);
    setContentPane((Container)chartPanel);
  }
  
  private static JFreeChart createChart(XYDataset paramXYDataset) {
    JFreeChart jFreeChart = ChartFactory.createTimeSeriesChart("Performance Test 1", "Time", "Milliseconds", paramXYDataset, true, true, false);
    jFreeChart.setBackgroundPaint(Color.white);
    XYPlot xYPlot = (XYPlot)jFreeChart.getPlot();
    xYPlot.setBackgroundPaint(Color.lightGray);
    xYPlot.setDomainGridlinePaint(Color.white);
    xYPlot.setRangeGridlinePaint(Color.white);
    xYPlot.setAxisOffset(new RectangleInsets(5.0D, 5.0D, 5.0D, 5.0D));
    xYPlot.setDomainCrosshairVisible(true);
    xYPlot.setRangeCrosshairVisible(true);
    XYItemRenderer xYItemRenderer = xYPlot.getRenderer();
    if (xYItemRenderer instanceof StandardXYItemRenderer) {
      StandardXYItemRenderer standardXYItemRenderer = (StandardXYItemRenderer)xYItemRenderer;
      standardXYItemRenderer.setSeriesStroke(0, new BasicStroke(1.1F));
    } 
    return jFreeChart;
  }
  
  public static JPanel createDemoPanel() {
    JFreeChart jFreeChart = createChart((XYDataset)null);
    return (JPanel)new ChartPanel(jFreeChart);
  }
  
  public void addObservation(long paramLong) {
    this.timings.addOrUpdate((RegularTimePeriod)new Millisecond(), paramLong);
  }
  
  public static void main2(String[] paramArrayOfString) {
    PerformanceTest1 performanceTest1 = new PerformanceTest1("Performance Test 1");
    performanceTest1.pack();
    RefineryUtilities.centerFrameOnScreen((Window)performanceTest1);
    performanceTest1.setVisible(true);
    TimeSeries timeSeries = new TimeSeries("Test");
    timeSeries.setMaximumItemAge(200L);
    while (true) {
      Millisecond millisecond = new Millisecond();
      long l1 = System.currentTimeMillis();
      for (byte b = 0; b < 'È'; b++) {
        millisecond = (Millisecond)millisecond.next();
        timeSeries.addOrUpdate((RegularTimePeriod)millisecond, 1.0D);
      } 
      long l2 = System.currentTimeMillis();
      performanceTest1.addObservation(l2 - l1);
    } 
  }
  
  public static void main4(String[] paramArrayOfString) {
    TimeSeries timeSeries = new TimeSeries("Test");
    timeSeries.setMaximumItemCount(4000);
    FixedMillisecond fixedMillisecond = new FixedMillisecond();
    for (byte b = 0; b < '鱀'; b++) {
      long l1 = System.currentTimeMillis();
      for (byte b1 = 0; b1 < 'Ɛ'; b1++) {
        fixedMillisecond = (FixedMillisecond)fixedMillisecond.next();
        timeSeries.add((RegularTimePeriod)fixedMillisecond, Math.random());
      } 
      long l2 = System.currentTimeMillis();
      System.out.println(b + " --> " + (l2 - l1) + " (" + Runtime.getRuntime().freeMemory() + " / " + Runtime.getRuntime().totalMemory() + ")");
    } 
  }
  
  public static void main5(String[] paramArrayOfString) {
    XYSeries xYSeries = new XYSeries("Test");
    xYSeries.setMaximumItemCount(4000);
    byte b1 = 0;
    for (byte b2 = 0; b2 < '鱀'; b2++) {
      long l1 = System.currentTimeMillis();
      for (byte b = 0; b < 'ྠ'; b++)
        xYSeries.add(b1++, Math.random()); 
      long l2 = System.currentTimeMillis();
      System.out.println(b2 + " --> " + (l2 - l1) + " (" + Runtime.getRuntime().freeMemory() + " / " + Runtime.getRuntime().totalMemory() + ")");
    } 
  }
  
  public static void main(String[] paramArrayOfString) {
    ArrayList<Double> arrayList = new ArrayList();
    int i;
    for (i = 0; i < 4000; i++)
      arrayList.add(new Double(Math.random())); 
    i = 0;
    for (byte b = 0; b < '丠'; b++) {
      long l1 = System.currentTimeMillis();
      for (byte b1 = 0; b1 < 1000000; b1++)
        i += b1; 
      long l2 = System.currentTimeMillis();
      System.out.println(b + " --> " + (l2 - l1) + " (" + Runtime.getRuntime().freeMemory() + " / " + Runtime.getRuntime().totalMemory() + ")");
    } 
  }
  
  public static void main3(String[] paramArrayOfString) {
    ArrayList<Millisecond> arrayList = new ArrayList();
    Millisecond millisecond = new Millisecond();
    byte b;
    for (b = 0; b < 'È'; b++) {
      millisecond = (Millisecond)millisecond.next();
      arrayList.add(millisecond);
    } 
    for (b = 0; b < 'ߐ'; b++) {
      long l1 = System.currentTimeMillis();
      Collections.binarySearch((List)arrayList, new Millisecond());
      long l2 = System.currentTimeMillis();
      System.out.println(b + " --> " + (l2 - l1) + " (" + Runtime.getRuntime().freeMemory() + " / " + Runtime.getRuntime().totalMemory() + ")");
    } 
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/PerformanceTest1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */