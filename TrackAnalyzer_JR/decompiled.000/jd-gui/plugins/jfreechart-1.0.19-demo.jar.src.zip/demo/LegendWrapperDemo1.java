package demo;

import java.awt.Font;
import java.awt.Window;
import javax.swing.JPanel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.LegendItemSource;
import org.jfree.chart.block.Arrangement;
import org.jfree.chart.block.Block;
import org.jfree.chart.block.BlockBorder;
import org.jfree.chart.block.BlockContainer;
import org.jfree.chart.block.BlockFrame;
import org.jfree.chart.block.BorderArrangement;
import org.jfree.chart.block.LabelBlock;
import org.jfree.chart.plot.PiePlot;
import org.jfree.chart.title.LegendTitle;
import org.jfree.chart.title.Title;
import org.jfree.data.general.DefaultPieDataset;
import org.jfree.data.general.PieDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.HorizontalAlignment;
import org.jfree.ui.RectangleEdge;
import org.jfree.ui.RefineryUtilities;

public class LegendWrapperDemo1 extends ApplicationFrame {
  public LegendWrapperDemo1(String paramString) {
    super(paramString);
    setContentPane(createDemoPanel());
  }
  
  private static PieDataset createDataset() {
    DefaultPieDataset defaultPieDataset = new DefaultPieDataset();
    defaultPieDataset.setValue("One", new Double(43.2D));
    defaultPieDataset.setValue("Two", new Double(10.0D));
    defaultPieDataset.setValue("Three", new Double(27.5D));
    defaultPieDataset.setValue("Four", new Double(17.5D));
    defaultPieDataset.setValue("Five", new Double(11.0D));
    defaultPieDataset.setValue("Six", new Double(19.4D));
    return (PieDataset)defaultPieDataset;
  }
  
  private static JFreeChart createChart(PieDataset paramPieDataset) {
    JFreeChart jFreeChart = ChartFactory.createPieChart("Legend Wrapper Demo 1", paramPieDataset, false, true, false);
    PiePlot piePlot = (PiePlot)jFreeChart.getPlot();
    piePlot.setLabelFont(new Font("SansSerif", 0, 12));
    piePlot.setNoDataMessage("No data available");
    piePlot.setCircular(true);
    piePlot.setLabelGap(0.02D);
    LegendTitle legendTitle = new LegendTitle((LegendItemSource)jFreeChart.getPlot());
    BlockContainer blockContainer1 = new BlockContainer((Arrangement)new BorderArrangement());
    blockContainer1.setFrame((BlockFrame)new BlockBorder(1.0D, 1.0D, 1.0D, 1.0D));
    LabelBlock labelBlock1 = new LabelBlock("Legend Items:", new Font("SansSerif", 1, 12));
    labelBlock1.setPadding(5.0D, 5.0D, 5.0D, 5.0D);
    blockContainer1.add((Block)labelBlock1, RectangleEdge.TOP);
    LabelBlock labelBlock2 = new LabelBlock("Source: http://www.jfree.org");
    labelBlock2.setPadding(8.0D, 20.0D, 2.0D, 5.0D);
    blockContainer1.add((Block)labelBlock2, RectangleEdge.BOTTOM);
    BlockContainer blockContainer2 = legendTitle.getItemContainer();
    blockContainer2.setPadding(2.0D, 10.0D, 5.0D, 2.0D);
    blockContainer1.add((Block)blockContainer2);
    legendTitle.setWrapper(blockContainer1);
    legendTitle.setPosition(RectangleEdge.RIGHT);
    legendTitle.setHorizontalAlignment(HorizontalAlignment.LEFT);
    jFreeChart.addSubtitle((Title)legendTitle);
    ChartUtilities.applyCurrentTheme(jFreeChart);
    return jFreeChart;
  }
  
  public static JPanel createDemoPanel() {
    JFreeChart jFreeChart = createChart(createDataset());
    return (JPanel)new ChartPanel(jFreeChart);
  }
  
  public static void main(String[] paramArrayOfString) {
    LegendWrapperDemo1 legendWrapperDemo1 = new LegendWrapperDemo1("JFreeChart: LegendWrapperDemo1.java");
    legendWrapperDemo1.pack();
    RefineryUtilities.centerFrameOnScreen((Window)legendWrapperDemo1);
    legendWrapperDemo1.setVisible(true);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/LegendWrapperDemo1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */