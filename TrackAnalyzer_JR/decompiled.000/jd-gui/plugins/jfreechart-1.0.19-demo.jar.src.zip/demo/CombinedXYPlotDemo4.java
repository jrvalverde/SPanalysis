package demo;

import java.awt.Container;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Window;
import javax.swing.JPanel;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.annotations.XYAnnotation;
import org.jfree.chart.annotations.XYTextAnnotation;
import org.jfree.chart.axis.AxisLocation;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.CombinedDomainXYPlot;
import org.jfree.chart.plot.Plot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.StandardXYItemRenderer;
import org.jfree.chart.renderer.xy.XYItemRenderer;
import org.jfree.data.xy.XYDataset;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

public class CombinedXYPlotDemo4 extends ApplicationFrame {
  public CombinedXYPlotDemo4(String paramString) {
    super(paramString);
    ChartPanel chartPanel = (ChartPanel)createDemoPanel();
    chartPanel.setPreferredSize(new Dimension(500, 270));
    setContentPane((Container)chartPanel);
  }
  
  private static JFreeChart createCombinedChart() {
    XYDataset xYDataset1 = createDataset1();
    StandardXYItemRenderer standardXYItemRenderer1 = new StandardXYItemRenderer();
    NumberAxis numberAxis1 = new NumberAxis("Range 1");
    XYPlot xYPlot1 = new XYPlot(xYDataset1, null, (ValueAxis)numberAxis1, (XYItemRenderer)standardXYItemRenderer1);
    xYPlot1.setRangeAxisLocation(AxisLocation.BOTTOM_OR_LEFT);
    xYPlot1.setDataset(1, createDataset2());
    NumberAxis numberAxis2 = new NumberAxis("Range Axis 2");
    numberAxis2.setAutoRangeIncludesZero(false);
    xYPlot1.setRangeAxis(1, (ValueAxis)numberAxis2);
    xYPlot1.setRangeAxisLocation(1, AxisLocation.BOTTOM_OR_RIGHT);
    xYPlot1.setRenderer(1, (XYItemRenderer)new StandardXYItemRenderer());
    xYPlot1.mapDatasetToRangeAxis(1, 1);
    xYPlot1.setRangePannable(true);
    XYTextAnnotation xYTextAnnotation = new XYTextAnnotation("Hello!", 50.0D, 10000.0D);
    xYTextAnnotation.setFont(new Font("SansSerif", 0, 9));
    xYTextAnnotation.setRotationAngle(0.7853981633974483D);
    xYPlot1.addAnnotation((XYAnnotation)xYTextAnnotation);
    XYDataset xYDataset2 = createDataset2();
    StandardXYItemRenderer standardXYItemRenderer2 = new StandardXYItemRenderer();
    NumberAxis numberAxis3 = new NumberAxis("Range 2");
    numberAxis3.setAutoRangeIncludesZero(false);
    XYPlot xYPlot2 = new XYPlot(xYDataset2, null, (ValueAxis)numberAxis3, (XYItemRenderer)standardXYItemRenderer2);
    xYPlot2.setRangeAxisLocation(AxisLocation.TOP_OR_LEFT);
    CombinedDomainXYPlot combinedDomainXYPlot = new CombinedDomainXYPlot((ValueAxis)new NumberAxis("Domain"));
    combinedDomainXYPlot.setGap(10.0D);
    combinedDomainXYPlot.setDomainPannable(true);
    combinedDomainXYPlot.add(xYPlot1, 1);
    combinedDomainXYPlot.add(xYPlot2, 1);
    combinedDomainXYPlot.setOrientation(PlotOrientation.VERTICAL);
    JFreeChart jFreeChart = new JFreeChart("CombinedDomainXYPlot Demo", JFreeChart.DEFAULT_TITLE_FONT, (Plot)combinedDomainXYPlot, true);
    ChartUtilities.applyCurrentTheme(jFreeChart);
    return jFreeChart;
  }
  
  private static XYDataset createDataset1() {
    XYSeries xYSeries1 = new XYSeries("Series 1a");
    xYSeries1.add(10.0D, 12353.3D);
    xYSeries1.add(20.0D, 13734.4D);
    xYSeries1.add(30.0D, 14525.3D);
    xYSeries1.add(40.0D, 13984.3D);
    xYSeries1.add(50.0D, 12999.4D);
    xYSeries1.add(60.0D, 14274.3D);
    xYSeries1.add(70.0D, 15943.5D);
    xYSeries1.add(80.0D, 14845.3D);
    xYSeries1.add(90.0D, 14645.4D);
    xYSeries1.add(100.0D, 16234.6D);
    xYSeries1.add(110.0D, 17232.3D);
    xYSeries1.add(120.0D, 14232.2D);
    xYSeries1.add(130.0D, 13102.2D);
    xYSeries1.add(140.0D, 14230.2D);
    xYSeries1.add(150.0D, 11235.2D);
    XYSeries xYSeries2 = new XYSeries("Series 1b");
    xYSeries2.add(10.0D, 15000.3D);
    xYSeries2.add(20.0D, 11000.4D);
    xYSeries2.add(30.0D, 17000.3D);
    xYSeries2.add(40.0D, 15000.3D);
    xYSeries2.add(50.0D, 14000.4D);
    xYSeries2.add(60.0D, 12000.3D);
    xYSeries2.add(70.0D, 11000.5D);
    xYSeries2.add(80.0D, 12000.3D);
    xYSeries2.add(90.0D, 13000.4D);
    xYSeries2.add(100.0D, 12000.6D);
    xYSeries2.add(110.0D, 13000.3D);
    xYSeries2.add(120.0D, 17000.2D);
    xYSeries2.add(130.0D, 18000.2D);
    xYSeries2.add(140.0D, 16000.2D);
    xYSeries2.add(150.0D, 17000.2D);
    XYSeriesCollection xYSeriesCollection = new XYSeriesCollection();
    xYSeriesCollection.addSeries(xYSeries1);
    xYSeriesCollection.addSeries(xYSeries2);
    return (XYDataset)xYSeriesCollection;
  }
  
  private static XYDataset createDataset2() {
    XYSeries xYSeries = new XYSeries("Series 2");
    xYSeries.add(10.0D, 6853.2D);
    xYSeries.add(20.0D, 9642.3D);
    xYSeries.add(30.0D, 8253.5D);
    xYSeries.add(40.0D, 5352.3D);
    xYSeries.add(50.0D, 3532.0D);
    xYSeries.add(60.0D, 2635.3D);
    xYSeries.add(70.0D, 3998.2D);
    xYSeries.add(80.0D, 1943.2D);
    xYSeries.add(90.0D, 6943.9D);
    xYSeries.add(100.0D, 7843.2D);
    xYSeries.add(105.0D, 6495.3D);
    xYSeries.add(110.0D, 7943.6D);
    xYSeries.add(115.0D, 8500.7D);
    xYSeries.add(120.0D, 9595.9D);
    return (XYDataset)new XYSeriesCollection(xYSeries);
  }
  
  public static JPanel createDemoPanel() {
    JFreeChart jFreeChart = createCombinedChart();
    ChartPanel chartPanel = new ChartPanel(jFreeChart);
    chartPanel.setMouseWheelEnabled(true);
    return (JPanel)new ChartPanel(jFreeChart);
  }
  
  public static void main(String[] paramArrayOfString) {
    CombinedXYPlotDemo4 combinedXYPlotDemo4 = new CombinedXYPlotDemo4("JFreeChart: CombinedDomainXYPlotDemo4.java");
    combinedXYPlotDemo4.pack();
    RefineryUtilities.centerFrameOnScreen((Window)combinedXYPlotDemo4);
    combinedXYPlotDemo4.setVisible(true);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/CombinedXYPlotDemo4.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */