package demo;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Window;
import javax.swing.JPanel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.DateAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYDifferenceRenderer;
import org.jfree.chart.renderer.xy.XYItemRenderer;
import org.jfree.data.time.Day;
import org.jfree.data.time.RegularTimePeriod;
import org.jfree.data.time.TimeSeries;
import org.jfree.data.time.TimeSeriesCollection;
import org.jfree.data.xy.XYDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

public class DifferenceChartDemo1 extends ApplicationFrame {
  public DifferenceChartDemo1(String paramString) {
    super(paramString);
    JPanel jPanel = createDemoPanel();
    jPanel.setPreferredSize(new Dimension(500, 270));
    setContentPane(jPanel);
  }
  
  private static XYDataset createDataset() {
    TimeSeries timeSeries1 = new TimeSeries("Random 1");
    TimeSeries timeSeries2 = new TimeSeries("Random 2");
    double d1 = 0.0D;
    double d2 = 0.0D;
    Day day = new Day();
    for (byte b = 0; b < 'È'; b++) {
      d1 = d1 + Math.random() - 0.5D;
      d2 = d2 + Math.random() - 0.5D;
      timeSeries1.add((RegularTimePeriod)day, d1);
      timeSeries2.add((RegularTimePeriod)day, d2);
      day = (Day)day.next();
    } 
    TimeSeriesCollection timeSeriesCollection = new TimeSeriesCollection();
    timeSeriesCollection.addSeries(timeSeries1);
    timeSeriesCollection.addSeries(timeSeries2);
    return (XYDataset)timeSeriesCollection;
  }
  
  private static JFreeChart createChart(XYDataset paramXYDataset) {
    JFreeChart jFreeChart = ChartFactory.createTimeSeriesChart("Difference Chart Demo 1", "Time", "Value", paramXYDataset, true, true, false);
    XYPlot xYPlot = (XYPlot)jFreeChart.getPlot();
    xYPlot.setDomainPannable(true);
    XYDifferenceRenderer xYDifferenceRenderer = new XYDifferenceRenderer(Color.green, Color.red, false);
    xYDifferenceRenderer.setRoundXCoordinates(true);
    xYPlot.setDomainCrosshairLockedOnData(true);
    xYPlot.setRangeCrosshairLockedOnData(true);
    xYPlot.setDomainCrosshairVisible(true);
    xYPlot.setRangeCrosshairVisible(true);
    xYPlot.setRenderer((XYItemRenderer)xYDifferenceRenderer);
    DateAxis dateAxis = new DateAxis("Time");
    dateAxis.setLowerMargin(0.0D);
    dateAxis.setUpperMargin(0.0D);
    xYPlot.setDomainAxis((ValueAxis)dateAxis);
    xYPlot.setForegroundAlpha(0.5F);
    ChartUtilities.applyCurrentTheme(jFreeChart);
    return jFreeChart;
  }
  
  public static JPanel createDemoPanel() {
    JFreeChart jFreeChart = createChart(createDataset());
    ChartPanel chartPanel = new ChartPanel(jFreeChart);
    chartPanel.setMouseWheelEnabled(true);
    return (JPanel)chartPanel;
  }
  
  public static void main(String[] paramArrayOfString) {
    DifferenceChartDemo1 differenceChartDemo1 = new DifferenceChartDemo1("JFreeChart: DifferenceChartDemo1.java");
    differenceChartDemo1.pack();
    RefineryUtilities.centerFrameOnScreen((Window)differenceChartDemo1);
    differenceChartDemo1.setVisible(true);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/DifferenceChartDemo1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */