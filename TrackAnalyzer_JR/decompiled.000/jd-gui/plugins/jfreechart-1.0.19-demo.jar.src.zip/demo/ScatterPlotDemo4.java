package demo;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Window;
import javax.swing.JPanel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYDotRenderer;
import org.jfree.chart.renderer.xy.XYItemRenderer;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

public class ScatterPlotDemo4 extends ApplicationFrame {
  public ScatterPlotDemo4(String paramString) {
    super(paramString);
    JPanel jPanel = createDemoPanel();
    jPanel.setPreferredSize(new Dimension(500, 270));
    setContentPane(jPanel);
  }
  
  public static JPanel createDemoPanel() {
    SampleXYDataset2 sampleXYDataset2 = new SampleXYDataset2();
    JFreeChart jFreeChart = ChartFactory.createScatterPlot("Scatter Plot Demo 4", "X", "Y", sampleXYDataset2, PlotOrientation.VERTICAL, true, true, false);
    XYPlot xYPlot = (XYPlot)jFreeChart.getPlot();
    xYPlot.setRangeTickBandPaint(new Color(200, 200, 100, 100));
    XYDotRenderer xYDotRenderer = new XYDotRenderer();
    xYDotRenderer.setDotWidth(4);
    xYDotRenderer.setDotHeight(4);
    xYPlot.setRenderer((XYItemRenderer)xYDotRenderer);
    xYPlot.setDomainCrosshairVisible(true);
    xYPlot.setRangeCrosshairVisible(true);
    NumberAxis numberAxis = (NumberAxis)xYPlot.getDomainAxis();
    numberAxis.setAutoRangeIncludesZero(false);
    xYPlot.getRangeAxis().setInverted(true);
    ChartPanel chartPanel = new ChartPanel(jFreeChart);
    chartPanel.setMouseWheelEnabled(true);
    return (JPanel)chartPanel;
  }
  
  public static void main(String[] paramArrayOfString) {
    ScatterPlotDemo4 scatterPlotDemo4 = new ScatterPlotDemo4("JFreeChart: ScatterPlotDemo4.java");
    scatterPlotDemo4.pack();
    RefineryUtilities.centerFrameOnScreen((Window)scatterPlotDemo4);
    scatterPlotDemo4.setVisible(true);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/ScatterPlotDemo4.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */