package demo;

import java.awt.Dimension;
import java.awt.Window;
import javax.swing.JPanel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYDotRenderer;
import org.jfree.chart.renderer.xy.XYItemRenderer;
import org.jfree.data.xy.XYDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

public class ScatterPlotDemo2 extends ApplicationFrame {
  public ScatterPlotDemo2(String paramString) {
    super(paramString);
    JPanel jPanel = createDemoPanel();
    jPanel.setPreferredSize(new Dimension(500, 270));
    setContentPane(jPanel);
  }
  
  private static JFreeChart createChart(XYDataset paramXYDataset) {
    JFreeChart jFreeChart = ChartFactory.createScatterPlot("Scatter Plot Demo 2", "X", "Y", paramXYDataset, PlotOrientation.VERTICAL, true, true, false);
    XYPlot xYPlot = (XYPlot)jFreeChart.getPlot();
    xYPlot.setDomainCrosshairVisible(true);
    xYPlot.setDomainCrosshairLockedOnData(true);
    xYPlot.setRangeCrosshairVisible(true);
    xYPlot.setRangeCrosshairLockedOnData(true);
    xYPlot.setDomainZeroBaselineVisible(true);
    xYPlot.setRangeZeroBaselineVisible(true);
    XYDotRenderer xYDotRenderer = new XYDotRenderer();
    xYDotRenderer.setDotWidth(2);
    xYDotRenderer.setDotHeight(2);
    xYPlot.setRenderer((XYItemRenderer)xYDotRenderer);
    NumberAxis numberAxis = (NumberAxis)xYPlot.getDomainAxis();
    numberAxis.setAutoRangeIncludesZero(false);
    return jFreeChart;
  }
  
  public static JPanel createDemoPanel() {
    JFreeChart jFreeChart = createChart(new SampleXYDataset2());
    ChartPanel chartPanel = new ChartPanel(jFreeChart);
    chartPanel.setMouseWheelEnabled(true);
    return (JPanel)chartPanel;
  }
  
  public static void main(String[] paramArrayOfString) {
    ScatterPlotDemo2 scatterPlotDemo2 = new ScatterPlotDemo2("JFreeChart: ScatterPlotDemo2.java");
    scatterPlotDemo2.pack();
    RefineryUtilities.centerFrameOnScreen((Window)scatterPlotDemo2);
    scatterPlotDemo2.setVisible(true);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/ScatterPlotDemo2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */