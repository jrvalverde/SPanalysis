package demo;

import java.awt.Dimension;
import java.awt.Window;
import javax.swing.JPanel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.CategoryLabelPositions;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.renderer.AreaRendererEndType;
import org.jfree.chart.renderer.category.AreaRenderer;
import org.jfree.chart.title.TextTitle;
import org.jfree.chart.title.Title;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RectangleEdge;
import org.jfree.ui.RectangleInsets;
import org.jfree.ui.RefineryUtilities;
import org.jfree.ui.VerticalAlignment;
import org.jfree.util.UnitType;

public class AreaChartDemo1 extends ApplicationFrame {
  public AreaChartDemo1(String paramString) {
    super(paramString);
    JPanel jPanel = createDemoPanel();
    jPanel.setPreferredSize(new Dimension(500, 270));
    setContentPane(jPanel);
  }
  
  private static CategoryDataset createDataset() {
    DefaultCategoryDataset defaultCategoryDataset = new DefaultCategoryDataset();
    defaultCategoryDataset.addValue(1.0D, "Series 1", "Type 1");
    defaultCategoryDataset.addValue(4.0D, "Series 1", "Type 2");
    defaultCategoryDataset.addValue(3.0D, "Series 1", "Type 3");
    defaultCategoryDataset.addValue(5.0D, "Series 1", "Type 4");
    defaultCategoryDataset.addValue(5.0D, "Series 1", "Type 5");
    defaultCategoryDataset.addValue(7.0D, "Series 1", "Type 6");
    defaultCategoryDataset.addValue(7.0D, "Series 1", "Type 7");
    defaultCategoryDataset.addValue(8.0D, "Series 1", "Type 8");
    defaultCategoryDataset.addValue(5.0D, "Series 2", "Type 1");
    defaultCategoryDataset.addValue(7.0D, "Series 2", "Type 2");
    defaultCategoryDataset.addValue(6.0D, "Series 2", "Type 3");
    defaultCategoryDataset.addValue(8.0D, "Series 2", "Type 4");
    defaultCategoryDataset.addValue(4.0D, "Series 2", "Type 5");
    defaultCategoryDataset.addValue(4.0D, "Series 2", "Type 6");
    defaultCategoryDataset.addValue(2.0D, "Series 2", "Type 7");
    defaultCategoryDataset.addValue(1.0D, "Series 2", "Type 8");
    defaultCategoryDataset.addValue(4.0D, "Series 3", "Type 1");
    defaultCategoryDataset.addValue(3.0D, "Series 3", "Type 2");
    defaultCategoryDataset.addValue(2.0D, "Series 3", "Type 3");
    defaultCategoryDataset.addValue(3.0D, "Series 3", "Type 4");
    defaultCategoryDataset.addValue(6.0D, "Series 3", "Type 5");
    defaultCategoryDataset.addValue(3.0D, "Series 3", "Type 6");
    defaultCategoryDataset.addValue(4.0D, "Series 3", "Type 7");
    defaultCategoryDataset.addValue(3.0D, "Series 3", "Type 8");
    return (CategoryDataset)defaultCategoryDataset;
  }
  
  private static JFreeChart createChart(CategoryDataset paramCategoryDataset) {
    JFreeChart jFreeChart = ChartFactory.createAreaChart("Area Chart", "Category", "Value", paramCategoryDataset);
    TextTitle textTitle = new TextTitle("An area chart demonstration.  We use this subtitle as an example of what happens when you get a really long title or subtitle.");
    textTitle.setPosition(RectangleEdge.TOP);
    textTitle.setPadding(new RectangleInsets(UnitType.RELATIVE, 0.05D, 0.05D, 0.05D, 0.05D));
    textTitle.setVerticalAlignment(VerticalAlignment.BOTTOM);
    jFreeChart.addSubtitle((Title)textTitle);
    CategoryPlot categoryPlot = (CategoryPlot)jFreeChart.getPlot();
    categoryPlot.setForegroundAlpha(0.5F);
    categoryPlot.setDomainGridlinesVisible(true);
    AreaRenderer areaRenderer = (AreaRenderer)categoryPlot.getRenderer();
    areaRenderer.setEndType(AreaRendererEndType.LEVEL);
    CategoryAxis categoryAxis = categoryPlot.getDomainAxis();
    categoryAxis.setCategoryLabelPositions(CategoryLabelPositions.UP_45);
    categoryAxis.setLowerMargin(0.0D);
    categoryAxis.setUpperMargin(0.0D);
    categoryAxis.addCategoryLabelToolTip("Type 1", "The first type.");
    categoryAxis.addCategoryLabelToolTip("Type 2", "The second type.");
    categoryAxis.addCategoryLabelToolTip("Type 3", "The third type.");
    NumberAxis numberAxis = (NumberAxis)categoryPlot.getRangeAxis();
    numberAxis.setStandardTickUnits(NumberAxis.createIntegerTickUnits());
    numberAxis.setLabelAngle(0.0D);
    ChartUtilities.applyCurrentTheme(jFreeChart);
    return jFreeChart;
  }
  
  public static JPanel createDemoPanel() {
    JFreeChart jFreeChart = createChart(createDataset());
    return (JPanel)new ChartPanel(jFreeChart);
  }
  
  public static void main(String[] paramArrayOfString) {
    AreaChartDemo1 areaChartDemo1 = new AreaChartDemo1("JFreeChart: AreaChartDemo1.java");
    areaChartDemo1.pack();
    RefineryUtilities.centerFrameOnScreen((Window)areaChartDemo1);
    areaChartDemo1.setVisible(true);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/AreaChartDemo1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */