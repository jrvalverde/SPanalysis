package demo;

import java.awt.Dimension;
import java.awt.Window;
import java.text.NumberFormat;
import javax.swing.JPanel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.labels.CategoryItemLabelGenerator;
import org.jfree.chart.labels.CategoryToolTipGenerator;
import org.jfree.chart.labels.StandardCategoryItemLabelGenerator;
import org.jfree.chart.labels.StandardCategoryToolTipGenerator;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.renderer.category.CategoryItemRenderer;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

public class StackedBarChartDemo3 extends ApplicationFrame {
  public StackedBarChartDemo3(String paramString) {
    super(paramString);
    JPanel jPanel = createDemoPanel();
    jPanel.setPreferredSize(new Dimension(500, 270));
    setContentPane(jPanel);
  }
  
  private static CategoryDataset createDataset() {
    DefaultCategoryDataset defaultCategoryDataset = new DefaultCategoryDataset();
    defaultCategoryDataset.addValue(10.0D, "Series 1", "Jan");
    defaultCategoryDataset.addValue(12.0D, "Series 1", "Feb");
    defaultCategoryDataset.addValue(13.0D, "Series 1", "Mar");
    defaultCategoryDataset.addValue(4.0D, "Series 2", "Jan");
    defaultCategoryDataset.addValue(3.0D, "Series 2", "Feb");
    defaultCategoryDataset.addValue(2.0D, "Series 2", "Mar");
    defaultCategoryDataset.addValue(2.0D, "Series 3", "Jan");
    defaultCategoryDataset.addValue(3.0D, "Series 3", "Feb");
    defaultCategoryDataset.addValue(2.0D, "Series 3", "Mar");
    defaultCategoryDataset.addValue(2.0D, "Series 4", "Jan");
    defaultCategoryDataset.addValue(3.0D, "Series 4", "Feb");
    defaultCategoryDataset.addValue(4.0D, "Series 4", "Mar");
    return (CategoryDataset)defaultCategoryDataset;
  }
  
  private static JFreeChart createChart(CategoryDataset paramCategoryDataset) {
    JFreeChart jFreeChart = ChartFactory.createStackedBarChart("Stacked Bar Chart Demo 3", "Category", "Value", paramCategoryDataset, PlotOrientation.VERTICAL, true, false, false);
    CategoryPlot categoryPlot = (CategoryPlot)jFreeChart.getPlot();
    ExtendedStackedBarRenderer extendedStackedBarRenderer = new ExtendedStackedBarRenderer();
    extendedStackedBarRenderer.setBaseItemLabelsVisible(true);
    extendedStackedBarRenderer.setBaseItemLabelGenerator((CategoryItemLabelGenerator)new StandardCategoryItemLabelGenerator());
    extendedStackedBarRenderer.setBaseToolTipGenerator((CategoryToolTipGenerator)new StandardCategoryToolTipGenerator());
    categoryPlot.setRenderer((CategoryItemRenderer)extendedStackedBarRenderer);
    NumberAxis numberAxis = (NumberAxis)categoryPlot.getRangeAxis();
    numberAxis.setStandardTickUnits(NumberAxis.createIntegerTickUnits());
    numberAxis.setLowerMargin(0.15D);
    numberAxis.setUpperMargin(0.15D);
    numberAxis.setNumberFormatOverride(NumberFormat.getPercentInstance());
    ChartUtilities.applyCurrentTheme(jFreeChart);
    return jFreeChart;
  }
  
  public static JPanel createDemoPanel() {
    JFreeChart jFreeChart = createChart(createDataset());
    return (JPanel)new ChartPanel(jFreeChart);
  }
  
  public static void main(String[] paramArrayOfString) {
    StackedBarChartDemo3 stackedBarChartDemo3 = new StackedBarChartDemo3("Stacked Bar Chart Demo 3");
    stackedBarChartDemo3.pack();
    RefineryUtilities.centerFrameOnScreen((Window)stackedBarChartDemo3);
    stackedBarChartDemo3.setVisible(true);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/StackedBarChartDemo3.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */