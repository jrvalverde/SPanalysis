package demo;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Window;
import javax.swing.JPanel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.DateAxis;
import org.jfree.chart.axis.DateTickMarkPosition;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.CandlestickRenderer;
import org.jfree.chart.renderer.xy.HighLowRenderer;
import org.jfree.chart.renderer.xy.XYItemRenderer;
import org.jfree.data.time.Day;
import org.jfree.data.time.RegularTimePeriod;
import org.jfree.data.time.ohlc.OHLCSeries;
import org.jfree.data.time.ohlc.OHLCSeriesCollection;
import org.jfree.data.xy.OHLCDataset;
import org.jfree.data.xy.XYDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

public class HighLowChartDemo3 extends ApplicationFrame {
  public HighLowChartDemo3(String paramString) {
    super(paramString);
    JPanel jPanel = createDemoPanel();
    jPanel.setPreferredSize(new Dimension(500, 270));
    setContentPane(jPanel);
  }
  
  public static OHLCDataset createDataset1() {
    OHLCSeries oHLCSeries = new OHLCSeries("Series 1");
    oHLCSeries.add((RegularTimePeriod)new Day(24, 9, 2007), 50.5D, 53.2D, 49.8D, 50.1D);
    oHLCSeries.add((RegularTimePeriod)new Day(25, 9, 2007), 50.2D, 51.2D, 47.8D, 48.1D);
    oHLCSeries.add((RegularTimePeriod)new Day(26, 9, 2007), 48.0D, 49.2D, 45.3D, 47.4D);
    oHLCSeries.add((RegularTimePeriod)new Day(27, 9, 2007), 47.5D, 48.3D, 46.8D, 46.8D);
    oHLCSeries.add((RegularTimePeriod)new Day(28, 9, 2007), 46.6D, 47.0D, 45.1D, 46.0D);
    oHLCSeries.add((RegularTimePeriod)new Day(1, 10, 2007), 46.6D, 47.0D, 45.1D, 46.0D);
    oHLCSeries.add((RegularTimePeriod)new Day(2, 10, 2007), 47.5D, 48.3D, 46.8D, 46.8D);
    oHLCSeries.add((RegularTimePeriod)new Day(3, 10, 2007), 48.0D, 49.2D, 45.3D, 47.4D);
    oHLCSeries.add((RegularTimePeriod)new Day(4, 10, 2007), 50.2D, 51.2D, 47.8D, 48.1D);
    oHLCSeries.add((RegularTimePeriod)new Day(5, 10, 2007), 50.5D, 53.2D, 49.8D, 50.1D);
    OHLCSeriesCollection oHLCSeriesCollection = new OHLCSeriesCollection();
    oHLCSeriesCollection.addSeries(oHLCSeries);
    return (OHLCDataset)oHLCSeriesCollection;
  }
  
  public static OHLCDataset createDataset2() {
    OHLCSeries oHLCSeries = new OHLCSeries("Series 2");
    oHLCSeries.add((RegularTimePeriod)new Day(24, 9, 2007), 5.5D, 6.2D, 4.8D, 5.9D);
    oHLCSeries.add((RegularTimePeriod)new Day(25, 9, 2007), 6.0D, 6.9D, 6.0D, 6.7D);
    oHLCSeries.add((RegularTimePeriod)new Day(26, 9, 2007), 6.8D, 7.5D, 6.4D, 7.1D);
    oHLCSeries.add((RegularTimePeriod)new Day(27, 9, 2007), 7.2D, 8.2D, 7.0D, 7.9D);
    oHLCSeries.add((RegularTimePeriod)new Day(28, 9, 2007), 7.8D, 8.5D, 7.7D, 8.2D);
    oHLCSeries.add((RegularTimePeriod)new Day(1, 10, 2007), 8.2D, 8.5D, 7.7D, 7.8D);
    oHLCSeries.add((RegularTimePeriod)new Day(2, 10, 2007), 7.9D, 8.2D, 7.0D, 7.2D);
    oHLCSeries.add((RegularTimePeriod)new Day(3, 10, 2007), 7.1D, 7.5D, 6.4D, 6.8D);
    oHLCSeries.add((RegularTimePeriod)new Day(4, 10, 2007), 6.0D, 6.9D, 6.0D, 6.7D);
    oHLCSeries.add((RegularTimePeriod)new Day(5, 10, 2007), 5.5D, 6.2D, 4.8D, 5.9D);
    OHLCSeriesCollection oHLCSeriesCollection = new OHLCSeriesCollection();
    oHLCSeriesCollection.addSeries(oHLCSeries);
    return (OHLCDataset)oHLCSeriesCollection;
  }
  
  private static JFreeChart createChart(OHLCDataset paramOHLCDataset) {
    JFreeChart jFreeChart = ChartFactory.createHighLowChart("OHLC Demo 3", "Time", "Price", paramOHLCDataset, true);
    XYPlot xYPlot = (XYPlot)jFreeChart.getPlot();
    HighLowRenderer highLowRenderer = (HighLowRenderer)xYPlot.getRenderer();
    highLowRenderer.setBaseStroke(new BasicStroke(2.0F));
    highLowRenderer.setSeriesPaint(0, Color.blue);
    DateAxis dateAxis = (DateAxis)xYPlot.getDomainAxis();
    dateAxis.setTickMarkPosition(DateTickMarkPosition.MIDDLE);
    NumberAxis numberAxis1 = (NumberAxis)xYPlot.getRangeAxis();
    numberAxis1.setAutoRangeIncludesZero(false);
    NumberAxis numberAxis2 = new NumberAxis("Price 2");
    numberAxis2.setAutoRangeIncludesZero(false);
    xYPlot.setRangeAxis(1, (ValueAxis)numberAxis2);
    xYPlot.setDataset(1, (XYDataset)createDataset2());
    xYPlot.setRenderer(1, (XYItemRenderer)new CandlestickRenderer(10.0D));
    xYPlot.mapDatasetToRangeAxis(1, 1);
    ChartUtilities.applyCurrentTheme(jFreeChart);
    return jFreeChart;
  }
  
  public static JPanel createDemoPanel() {
    JFreeChart jFreeChart = createChart(createDataset1());
    return (JPanel)new ChartPanel(jFreeChart);
  }
  
  public static void main(String[] paramArrayOfString) {
    HighLowChartDemo3 highLowChartDemo3 = new HighLowChartDemo3("JFreeChart: HighLowChartDemo3.java");
    highLowChartDemo3.pack();
    RefineryUtilities.centerFrameOnScreen((Window)highLowChartDemo3);
    highLowChartDemo3.setVisible(true);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/HighLowChartDemo3.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */