package demo;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Paint;
import java.awt.Window;
import java.text.NumberFormat;
import javax.swing.JPanel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.annotations.CategoryAnnotation;
import org.jfree.chart.annotations.CategoryTextAnnotation;
import org.jfree.chart.axis.CategoryAnchor;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.labels.CategoryItemLabelGenerator;
import org.jfree.chart.labels.ItemLabelAnchor;
import org.jfree.chart.labels.ItemLabelPosition;
import org.jfree.chart.labels.StandardCategoryItemLabelGenerator;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.Marker;
import org.jfree.chart.plot.ValueMarker;
import org.jfree.chart.renderer.category.BarRenderer3D;
import org.jfree.chart.renderer.category.CategoryItemRenderer;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.Layer;
import org.jfree.ui.RefineryUtilities;
import org.jfree.ui.TextAnchor;

public class BarChart3DDemo4 extends ApplicationFrame {
  public BarChart3DDemo4(String paramString) {
    super(paramString);
    CategoryDataset categoryDataset = createDataset();
    JFreeChart jFreeChart = createChart(categoryDataset);
    ChartPanel chartPanel = new ChartPanel(jFreeChart);
    chartPanel.setPreferredSize(new Dimension(500, 270));
    setContentPane((Container)chartPanel);
  }
  
  private static CategoryDataset createDataset() {
    DefaultCategoryDataset defaultCategoryDataset = new DefaultCategoryDataset();
    defaultCategoryDataset.addValue(0.77D, "Series 1", "Robert");
    defaultCategoryDataset.addValue(0.93D, "Series 1", "Mary");
    defaultCategoryDataset.addValue(0.59D, "Series 1", "John");
    defaultCategoryDataset.addValue(0.75D, "Series 1", "Ellen");
    defaultCategoryDataset.addValue(0.63D, "Series 1", "Jack");
    defaultCategoryDataset.addValue(0.95D, "Series 1", "David");
    defaultCategoryDataset.addValue(0.71D, "Series 1", "Mark");
    defaultCategoryDataset.addValue(0.65D, "Series 1", "Andy");
    return (CategoryDataset)defaultCategoryDataset;
  }
  
  private static JFreeChart createChart(CategoryDataset paramCategoryDataset) {
    JFreeChart jFreeChart = ChartFactory.createBarChart3D("Student Grades", "Students", "Grade", paramCategoryDataset);
    jFreeChart.removeLegend();
    CategoryPlot categoryPlot = (CategoryPlot)jFreeChart.getPlot();
    CustomBarRenderer3D customBarRenderer3D = new CustomBarRenderer3D();
    customBarRenderer3D.setBaseItemLabelGenerator((CategoryItemLabelGenerator)new StandardCategoryItemLabelGenerator());
    customBarRenderer3D.setBaseItemLabelsVisible(true);
    customBarRenderer3D.setItemLabelAnchorOffset(10.0D);
    customBarRenderer3D.setBasePositiveItemLabelPosition(new ItemLabelPosition(ItemLabelAnchor.OUTSIDE12, TextAnchor.BASELINE_LEFT));
    categoryPlot.setRenderer((CategoryItemRenderer)customBarRenderer3D);
    ValueMarker valueMarker = new ValueMarker(0.7D, new Color(200, 200, 255), new BasicStroke(1.0F), new Color(200, 200, 255), new BasicStroke(1.0F), 1.0F);
    categoryPlot.addRangeMarker((Marker)valueMarker, Layer.BACKGROUND);
    customBarRenderer3D.setBaseItemLabelsVisible(true);
    customBarRenderer3D.setMaximumBarWidth(0.05D);
    CategoryTextAnnotation categoryTextAnnotation = new CategoryTextAnnotation("Minimum grade to pass", "Robert", 0.71D);
    categoryTextAnnotation.setCategoryAnchor(CategoryAnchor.START);
    categoryTextAnnotation.setFont(new Font("SansSerif", 0, 12));
    categoryTextAnnotation.setTextAnchor(TextAnchor.BOTTOM_LEFT);
    categoryPlot.addAnnotation((CategoryAnnotation)categoryTextAnnotation);
    NumberAxis numberAxis = (NumberAxis)categoryPlot.getRangeAxis();
    numberAxis.setNumberFormatOverride(NumberFormat.getPercentInstance());
    numberAxis.setUpperMargin(0.1D);
    ChartUtilities.applyCurrentTheme(jFreeChart);
    return jFreeChart;
  }
  
  public static JPanel createDemoPanel() {
    JFreeChart jFreeChart = createChart(createDataset());
    return (JPanel)new ChartPanel(jFreeChart);
  }
  
  public static void main(String[] paramArrayOfString) {
    BarChart3DDemo4 barChart3DDemo4 = new BarChart3DDemo4("JFreeChart: BarChart3DDemo4.java");
    barChart3DDemo4.pack();
    RefineryUtilities.centerFrameOnScreen((Window)barChart3DDemo4);
    barChart3DDemo4.setVisible(true);
  }
  
  static class CustomBarRenderer3D extends BarRenderer3D {
    public Paint getItemPaint(int param1Int1, int param1Int2) {
      CategoryDataset categoryDataset = getPlot().getDataset();
      double d = categoryDataset.getValue(param1Int1, param1Int2).doubleValue();
      return (d >= 0.7D) ? Color.green : Color.red;
    }
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/BarChart3DDemo4.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */