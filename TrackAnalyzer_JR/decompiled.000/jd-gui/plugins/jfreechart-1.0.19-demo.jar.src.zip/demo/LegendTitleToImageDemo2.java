package demo;

import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.block.RectangleConstraint;
import org.jfree.chart.title.LegendTitle;
import org.jfree.data.Range;
import org.jfree.data.general.DefaultPieDataset;
import org.jfree.data.general.PieDataset;
import org.jfree.ui.Size2D;

public class LegendTitleToImageDemo2 {
  public static void main(String[] paramArrayOfString) throws IOException {
    DefaultPieDataset defaultPieDataset = new DefaultPieDataset();
    defaultPieDataset.setValue("England", 1.0D);
    defaultPieDataset.setValue("France", 2.0D);
    defaultPieDataset.setValue("Germany", 3.0D);
    defaultPieDataset.setValue("Italy", 4.0D);
    defaultPieDataset.setValue("Scotland", 5.0D);
    defaultPieDataset.setValue("Belgium", 6.0D);
    defaultPieDataset.setValue("Poland", 7.0D);
    defaultPieDataset.setValue("Spain", 8.0D);
    defaultPieDataset.setValue("Portugal", 9.0D);
    defaultPieDataset.setValue("Switzerland", 10.0D);
    defaultPieDataset.setValue("Austria", 11.0D);
    defaultPieDataset.setValue("Luxembourg", 12.0D);
    JFreeChart jFreeChart = ChartFactory.createPieChart("Test", (PieDataset)defaultPieDataset, true, false, false);
    LegendTitle legendTitle = jFreeChart.getLegend();
    legendTitle.setMargin(0.0D, 0.0D, 1.0D, 1.0D);
    BufferedImage bufferedImage1 = new BufferedImage(1, 1, 2);
    Graphics2D graphics2D1 = bufferedImage1.createGraphics();
    Size2D size2D = legendTitle.arrange(graphics2D1, new RectangleConstraint(250.0D, new Range(0.0D, 10000.0D)));
    graphics2D1.dispose();
    int i = (int)Math.rint(size2D.width);
    int j = (int)Math.rint(size2D.height);
    BufferedImage bufferedImage2 = new BufferedImage(i, j, 2);
    Graphics2D graphics2D2 = bufferedImage2.createGraphics();
    legendTitle.draw(graphics2D2, new Rectangle2D.Double(0.0D, 0.0D, i, j));
    graphics2D2.dispose();
    BufferedOutputStream bufferedOutputStream = new BufferedOutputStream(new FileOutputStream(new File("LegendTitleToImageDemo2.png")));
    ChartUtilities.writeBufferedImageAsPNG(bufferedOutputStream, bufferedImage2);
    bufferedOutputStream.close();
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/LegendTitleToImageDemo2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */