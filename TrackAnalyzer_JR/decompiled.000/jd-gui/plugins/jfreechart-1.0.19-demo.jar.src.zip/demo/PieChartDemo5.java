package demo;

import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Window;
import javax.swing.JPanel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PiePlot;
import org.jfree.chart.plot.PiePlot3D;
import org.jfree.chart.title.TextTitle;
import org.jfree.chart.title.Title;
import org.jfree.data.general.DefaultPieDataset;
import org.jfree.data.general.PieDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

public class PieChartDemo5 extends ApplicationFrame {
  public PieChartDemo5(String paramString) {
    super(paramString);
    setContentPane(createDemoPanel());
  }
  
  public static JPanel createDemoPanel() {
    DemoPanel demoPanel = new DemoPanel(new GridLayout(2, 2));
    DefaultPieDataset defaultPieDataset = new DefaultPieDataset();
    defaultPieDataset.setValue("Section 1", 23.3D);
    defaultPieDataset.setValue("Section 2", 56.5D);
    defaultPieDataset.setValue("Section 3", 43.3D);
    defaultPieDataset.setValue("Section 4", 11.1D);
    JFreeChart jFreeChart1 = ChartFactory.createPieChart("Chart 1", (PieDataset)defaultPieDataset, false, false, false);
    jFreeChart1.addSubtitle((Title)new TextTitle("setCircular(true);", new Font("Dialog", 0, 12)));
    PiePlot piePlot1 = (PiePlot)jFreeChart1.getPlot();
    piePlot1.setCircular(true);
    piePlot1.setInteriorGap(0.04D);
    piePlot1.setMaximumLabelWidth(0.2D);
    JFreeChart jFreeChart2 = ChartFactory.createPieChart("Chart 2", (PieDataset)defaultPieDataset, false, false, false);
    jFreeChart2.addSubtitle((Title)new TextTitle("setCircular(false);", new Font("Dialog", 0, 12)));
    PiePlot piePlot2 = (PiePlot)jFreeChart2.getPlot();
    piePlot2.setCircular(false);
    piePlot2.setInteriorGap(0.04D);
    piePlot2.setMaximumLabelWidth(0.2D);
    JFreeChart jFreeChart3 = ChartFactory.createPieChart3D("Chart 3", (PieDataset)defaultPieDataset, false, false, false);
    jFreeChart3.addSubtitle((Title)new TextTitle("setCircular(true);", new Font("Dialog", 0, 12)));
    PiePlot3D piePlot3D1 = (PiePlot3D)jFreeChart3.getPlot();
    piePlot3D1.setForegroundAlpha(0.6F);
    piePlot3D1.setCircular(true);
    piePlot3D1.setInteriorGap(0.04D);
    piePlot3D1.setMaximumLabelWidth(0.2D);
    JFreeChart jFreeChart4 = ChartFactory.createPieChart3D("Chart 4", (PieDataset)defaultPieDataset, false, false, false);
    jFreeChart4.addSubtitle((Title)new TextTitle("setCircular(false);", new Font("Dialog", 0, 12)));
    PiePlot3D piePlot3D2 = (PiePlot3D)jFreeChart4.getPlot();
    piePlot3D2.setForegroundAlpha(0.6F);
    piePlot3D2.setCircular(false);
    piePlot3D2.setInteriorGap(0.04D);
    piePlot3D2.setMaximumLabelWidth(0.2D);
    demoPanel.add((Component)new ChartPanel(jFreeChart1));
    demoPanel.add((Component)new ChartPanel(jFreeChart2));
    demoPanel.add((Component)new ChartPanel(jFreeChart3));
    demoPanel.add((Component)new ChartPanel(jFreeChart4));
    demoPanel.addChart(jFreeChart1);
    demoPanel.addChart(jFreeChart2);
    demoPanel.addChart(jFreeChart3);
    demoPanel.addChart(jFreeChart4);
    demoPanel.setPreferredSize(new Dimension(800, 600));
    return demoPanel;
  }
  
  public static void main(String[] paramArrayOfString) {
    PieChartDemo5 pieChartDemo5 = new PieChartDemo5("JFreeChart: PieChartDemo5.java");
    pieChartDemo5.pack();
    RefineryUtilities.centerFrameOnScreen((Window)pieChartDemo5);
    pieChartDemo5.setVisible(true);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/PieChartDemo5.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */