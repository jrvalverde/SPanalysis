package demo;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Window;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JPanel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.DefaultXYItemRenderer;
import org.jfree.chart.renderer.xy.XYItemRenderer;
import org.jfree.data.time.Millisecond;
import org.jfree.data.time.RegularTimePeriod;
import org.jfree.data.time.TimeSeries;
import org.jfree.data.time.TimeSeriesCollection;
import org.jfree.data.xy.XYDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

public class DynamicDataDemo2 extends ApplicationFrame {
  public DynamicDataDemo2(String paramString) {
    super(paramString);
    setContentPane(createDemoPanel());
  }
  
  public static JPanel createDemoPanel() {
    return new MyDemoPanel();
  }
  
  public static void main(String[] paramArrayOfString) {
    DynamicDataDemo2 dynamicDataDemo2 = new DynamicDataDemo2("JFreeChart: DynamicDataDemo2.java");
    dynamicDataDemo2.pack();
    RefineryUtilities.centerFrameOnScreen((Window)dynamicDataDemo2);
    dynamicDataDemo2.setVisible(true);
  }
  
  static class MyDemoPanel extends DemoPanel implements ActionListener {
    private TimeSeries series1 = new TimeSeries("Random 1");
    
    private TimeSeries series2 = new TimeSeries("Random 2");
    
    private double lastValue1 = 100.0D;
    
    private double lastValue2 = 500.0D;
    
    public MyDemoPanel() {
      super(new BorderLayout());
      TimeSeriesCollection timeSeriesCollection1 = new TimeSeriesCollection(this.series1);
      TimeSeriesCollection timeSeriesCollection2 = new TimeSeriesCollection(this.series2);
      JFreeChart jFreeChart = ChartFactory.createTimeSeriesChart("Dynamic Data Demo 2", "Time", "Value", (XYDataset)timeSeriesCollection1);
      addChart(jFreeChart);
      XYPlot xYPlot = (XYPlot)jFreeChart.getPlot();
      ValueAxis valueAxis = xYPlot.getDomainAxis();
      valueAxis.setAutoRange(true);
      valueAxis.setFixedAutoRange(10000.0D);
      xYPlot.setDataset(1, (XYDataset)timeSeriesCollection2);
      NumberAxis numberAxis = new NumberAxis("Range Axis 2");
      numberAxis.setAutoRangeIncludesZero(false);
      xYPlot.setRenderer(1, (XYItemRenderer)new DefaultXYItemRenderer());
      xYPlot.setRangeAxis(1, (ValueAxis)numberAxis);
      xYPlot.mapDatasetToRangeAxis(1, 1);
      ChartUtilities.applyCurrentTheme(jFreeChart);
      ChartPanel chartPanel = new ChartPanel(jFreeChart);
      add((Component)chartPanel);
      JButton jButton1 = new JButton("Add To Series 1");
      jButton1.setActionCommand("ADD_DATA_1");
      jButton1.addActionListener(this);
      JButton jButton2 = new JButton("Add To Series 2");
      jButton2.setActionCommand("ADD_DATA_2");
      jButton2.addActionListener(this);
      JButton jButton3 = new JButton("Add To Both");
      jButton3.setActionCommand("ADD_BOTH");
      jButton3.addActionListener(this);
      JPanel jPanel = new JPanel(new FlowLayout());
      jPanel.setBackground(Color.white);
      jPanel.add(jButton1);
      jPanel.add(jButton2);
      jPanel.add(jButton3);
      add(jPanel, "South");
      chartPanel.setPreferredSize(new Dimension(500, 270));
    }
    
    public void actionPerformed(ActionEvent param1ActionEvent) {
      boolean bool1 = false;
      boolean bool2 = false;
      if (param1ActionEvent.getActionCommand().equals("ADD_DATA_1")) {
        bool1 = true;
      } else if (param1ActionEvent.getActionCommand().equals("ADD_DATA_2")) {
        bool2 = true;
      } else if (param1ActionEvent.getActionCommand().equals("ADD_BOTH")) {
        bool1 = true;
        bool2 = true;
      } 
      if (bool1) {
        double d = 0.9D + 0.2D * Math.random();
        this.lastValue1 *= d;
        Millisecond millisecond = new Millisecond();
        System.out.println("Now = " + millisecond.toString());
        this.series1.add((RegularTimePeriod)new Millisecond(), this.lastValue1);
      } 
      if (bool2) {
        double d = 0.9D + 0.2D * Math.random();
        this.lastValue2 *= d;
        Millisecond millisecond = new Millisecond();
        System.out.println("Now = " + millisecond.toString());
        this.series2.add((RegularTimePeriod)new Millisecond(), this.lastValue2);
      } 
    }
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/DynamicDataDemo2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */