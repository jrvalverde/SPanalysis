package demo;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GradientPaint;
import java.awt.Paint;
import java.awt.Window;
import javax.swing.JPanel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.labels.CategoryToolTipGenerator;
import org.jfree.chart.labels.StandardCategoryToolTipGenerator;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.renderer.category.CategoryItemRenderer;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.GradientPaintTransformType;
import org.jfree.ui.GradientPaintTransformer;
import org.jfree.ui.RefineryUtilities;
import org.jfree.ui.StandardGradientPaintTransformer;

public class CylinderChartDemo1 extends ApplicationFrame {
  public CylinderChartDemo1(String paramString) {
    super(paramString);
    JPanel jPanel = createDemoPanel();
    jPanel.setPreferredSize(new Dimension(500, 270));
    setContentPane(jPanel);
  }
  
  private static CategoryDataset createDataset() {
    DefaultCategoryDataset defaultCategoryDataset = new DefaultCategoryDataset();
    defaultCategoryDataset.addValue(4.0D, "S1", "Monday");
    defaultCategoryDataset.addValue(5.0D, "S1", "Tuesday");
    defaultCategoryDataset.addValue(-7.0D, "S1", "Wednesday");
    defaultCategoryDataset.addValue(6.0D, "S1", "Thursday");
    defaultCategoryDataset.addValue(4.0D, "S1", "Friday");
    return (CategoryDataset)defaultCategoryDataset;
  }
  
  private static JFreeChart createChart(CategoryDataset paramCategoryDataset) {
    JFreeChart jFreeChart = ChartFactory.createBarChart3D("Cylinder Chart Demo 1", "Category", "Value", paramCategoryDataset, PlotOrientation.VERTICAL, false, true, false);
    CategoryPlot categoryPlot = (CategoryPlot)jFreeChart.getPlot();
    categoryPlot.setRangePannable(true);
    Paint[] arrayOfPaint = createPaint();
    CustomCylinderRenderer customCylinderRenderer = new CustomCylinderRenderer(arrayOfPaint);
    customCylinderRenderer.setGradientPaintTransformer((GradientPaintTransformer)new StandardGradientPaintTransformer(GradientPaintTransformType.CENTER_HORIZONTAL));
    customCylinderRenderer.setBaseOutlinePaint(Color.gray);
    customCylinderRenderer.setBaseOutlineStroke(new BasicStroke(0.3F));
    customCylinderRenderer.setBaseToolTipGenerator((CategoryToolTipGenerator)new StandardCategoryToolTipGenerator());
    categoryPlot.setRenderer((CategoryItemRenderer)customCylinderRenderer);
    ChartUtilities.applyCurrentTheme(jFreeChart);
    return jFreeChart;
  }
  
  private static Paint[] createPaint() {
    Paint[] arrayOfPaint = new Paint[5];
    arrayOfPaint[0] = new GradientPaint(0.0F, 0.0F, Color.red, 0.0F, 0.0F, Color.white);
    arrayOfPaint[1] = new GradientPaint(0.0F, 0.0F, Color.green, 0.0F, 0.0F, Color.white);
    arrayOfPaint[2] = new GradientPaint(0.0F, 0.0F, Color.blue, 0.0F, 0.0F, Color.white);
    arrayOfPaint[3] = new GradientPaint(0.0F, 0.0F, Color.orange, 0.0F, 0.0F, Color.white);
    arrayOfPaint[4] = new GradientPaint(0.0F, 0.0F, Color.magenta, 0.0F, 0.0F, Color.white);
    return arrayOfPaint;
  }
  
  public static JPanel createDemoPanel() {
    JFreeChart jFreeChart = createChart(createDataset());
    ChartPanel chartPanel = new ChartPanel(jFreeChart);
    chartPanel.setMouseWheelEnabled(true);
    return (JPanel)chartPanel;
  }
  
  public static void main(String[] paramArrayOfString) {
    CylinderChartDemo1 cylinderChartDemo1 = new CylinderChartDemo1("JFreeChart: CylinderChartDemo1.java");
    cylinderChartDemo1.pack();
    RefineryUtilities.centerFrameOnScreen((Window)cylinderChartDemo1);
    cylinderChartDemo1.setVisible(true);
  }
  
  static class CustomCylinderRenderer extends CylinderRenderer {
    private Paint[] colors;
    
    public CustomCylinderRenderer(Paint[] param1ArrayOfPaint) {
      this.colors = param1ArrayOfPaint;
    }
    
    public Paint getItemPaint(int param1Int1, int param1Int2) {
      return this.colors[param1Int2 % this.colors.length];
    }
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/CylinderChartDemo1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */