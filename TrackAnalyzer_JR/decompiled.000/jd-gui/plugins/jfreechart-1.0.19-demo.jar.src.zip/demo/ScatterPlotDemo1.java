package demo;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Window;
import javax.swing.JPanel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
import org.jfree.data.xy.XYDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

public class ScatterPlotDemo1 extends ApplicationFrame {
  public ScatterPlotDemo1(String paramString) {
    super(paramString);
    JPanel jPanel = createDemoPanel();
    jPanel.setPreferredSize(new Dimension(500, 270));
    setContentPane(jPanel);
  }
  
  private static JFreeChart createChart(XYDataset paramXYDataset) {
    JFreeChart jFreeChart = ChartFactory.createScatterPlot("Scatter Plot Demo 1", "X", "Y", paramXYDataset, PlotOrientation.VERTICAL, true, true, false);
    XYPlot xYPlot = (XYPlot)jFreeChart.getPlot();
    xYPlot.setNoDataMessage("NO DATA");
    xYPlot.setDomainPannable(true);
    xYPlot.setRangePannable(true);
    xYPlot.setDomainZeroBaselineVisible(true);
    xYPlot.setRangeZeroBaselineVisible(true);
    xYPlot.setDomainGridlineStroke(new BasicStroke(0.0F));
    xYPlot.setDomainMinorGridlineStroke(new BasicStroke(0.0F));
    xYPlot.setDomainGridlinePaint(Color.blue);
    xYPlot.setRangeGridlineStroke(new BasicStroke(0.0F));
    xYPlot.setRangeMinorGridlineStroke(new BasicStroke(0.0F));
    xYPlot.setRangeGridlinePaint(Color.blue);
    xYPlot.setDomainMinorGridlinesVisible(true);
    xYPlot.setRangeMinorGridlinesVisible(true);
    XYLineAndShapeRenderer xYLineAndShapeRenderer = (XYLineAndShapeRenderer)xYPlot.getRenderer();
    xYLineAndShapeRenderer.setSeriesOutlinePaint(0, Color.black);
    xYLineAndShapeRenderer.setUseOutlinePaint(true);
    NumberAxis numberAxis1 = (NumberAxis)xYPlot.getDomainAxis();
    numberAxis1.setAutoRangeIncludesZero(false);
    numberAxis1.setTickMarkInsideLength(2.0F);
    numberAxis1.setTickMarkOutsideLength(2.0F);
    numberAxis1.setMinorTickCount(2);
    numberAxis1.setMinorTickMarksVisible(true);
    NumberAxis numberAxis2 = (NumberAxis)xYPlot.getRangeAxis();
    numberAxis2.setTickMarkInsideLength(2.0F);
    numberAxis2.setTickMarkOutsideLength(2.0F);
    numberAxis2.setMinorTickCount(2);
    numberAxis2.setMinorTickMarksVisible(true);
    return jFreeChart;
  }
  
  public static JPanel createDemoPanel() {
    JFreeChart jFreeChart = createChart(new SampleXYDataset2());
    ChartPanel chartPanel = new ChartPanel(jFreeChart);
    chartPanel.setMouseWheelEnabled(true);
    return (JPanel)chartPanel;
  }
  
  public static void main(String[] paramArrayOfString) {
    ScatterPlotDemo1 scatterPlotDemo1 = new ScatterPlotDemo1("JFreeChart: ScatterPlotDemo1.java");
    scatterPlotDemo1.pack();
    RefineryUtilities.centerFrameOnScreen((Window)scatterPlotDemo1);
    scatterPlotDemo1.setVisible(true);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/ScatterPlotDemo1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */