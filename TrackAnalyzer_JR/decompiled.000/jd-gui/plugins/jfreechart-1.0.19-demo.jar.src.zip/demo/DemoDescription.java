package demo;

public class DemoDescription {
  private String className;
  
  private String description;
  
  public DemoDescription(String paramString1, String paramString2) {
    this.className = paramString1;
    this.description = paramString2;
  }
  
  public String getClassName() {
    return this.className;
  }
  
  public String getDescription() {
    return this.description;
  }
  
  public String toString() {
    return this.description;
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/DemoDescription.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */