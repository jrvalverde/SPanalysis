package demo;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Window;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ButtonGroup;
import javax.swing.JCheckBox;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JSlider;
import javax.swing.border.TitledBorder;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.CategoryLabelPositions;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

public class CategoryLabelPositionsDemo1 extends ApplicationFrame {
  static JFreeChart chart;
  
  static JCheckBox invertCheckBox;
  
  static JRadioButton horizontalRadioButton;
  
  static JRadioButton verticalRadioButton;
  
  static JSlider slider;
  
  public CategoryLabelPositionsDemo1(String paramString) {
    super(paramString);
    JPanel jPanel = createDemoPanel();
    jPanel.setPreferredSize(new Dimension(500, 350));
    setContentPane(jPanel);
  }
  
  private static JFreeChart createChart(CategoryDataset paramCategoryDataset) {
    JFreeChart jFreeChart = ChartFactory.createBarChart("CategoryLabelPositionsDemo1", "Category", "Value", paramCategoryDataset, PlotOrientation.VERTICAL, false, false, false);
    CategoryPlot categoryPlot = (CategoryPlot)jFreeChart.getPlot();
    CategoryAxis categoryAxis = categoryPlot.getDomainAxis();
    categoryAxis.setMaximumCategoryLabelLines(2147483647);
    categoryAxis.setCategoryLabelPositions(CategoryLabelPositions.createUpRotationLabelPositions(0.7853981633974483D));
    return jFreeChart;
  }
  
  public static CategoryDataset createDataset() {
    DefaultCategoryDataset defaultCategoryDataset = new DefaultCategoryDataset();
    defaultCategoryDataset.addValue(1.0D, "R1", "Category 1 (Long)");
    defaultCategoryDataset.addValue(5.0D, "R1", "Category 2 (Long)");
    defaultCategoryDataset.addValue(3.0D, "R1", "Category 3 (Long)");
    defaultCategoryDataset.addValue(2.0D, "R1", "Category 4 (Long)");
    defaultCategoryDataset.addValue(9.0D, "R1", "Category 5 (Long)");
    defaultCategoryDataset.addValue(7.0D, "R1", "Category 6 (Long)");
    defaultCategoryDataset.addValue(6.0D, "R1", "Category 7 (Long)");
    defaultCategoryDataset.addValue(8.0D, "R1", "Category 8 (Long)");
    return (CategoryDataset)defaultCategoryDataset;
  }
  
  public static JPanel createDemoPanel() {
    CategoryDataset categoryDataset = createDataset();
    chart = createChart(categoryDataset);
    DemoPanel demoPanel = new DemoPanel(new BorderLayout());
    JPanel jPanel1 = new JPanel(new BorderLayout());
    JPanel jPanel2 = new JPanel();
    invertCheckBox = new JCheckBox("Invert Range Axis?");
    invertCheckBox.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent param1ActionEvent) {
            CategoryPlot categoryPlot = (CategoryPlot)CategoryLabelPositionsDemo1.chart.getPlot();
            categoryPlot.getRangeAxis().setInverted(CategoryLabelPositionsDemo1.invertCheckBox.isSelected());
          }
        });
    jPanel2.add(invertCheckBox);
    ButtonGroup buttonGroup = new ButtonGroup();
    horizontalRadioButton = new JRadioButton("Horizontal", false);
    horizontalRadioButton.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent param1ActionEvent) {
            if (CategoryLabelPositionsDemo1.horizontalRadioButton.isSelected()) {
              CategoryPlot categoryPlot = (CategoryPlot)CategoryLabelPositionsDemo1.chart.getPlot();
              categoryPlot.setOrientation(PlotOrientation.HORIZONTAL);
            } 
          }
        });
    buttonGroup.add(horizontalRadioButton);
    verticalRadioButton = new JRadioButton("Vertical", true);
    verticalRadioButton.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent param1ActionEvent) {
            if (CategoryLabelPositionsDemo1.verticalRadioButton.isSelected()) {
              CategoryPlot categoryPlot = (CategoryPlot)CategoryLabelPositionsDemo1.chart.getPlot();
              categoryPlot.setOrientation(PlotOrientation.VERTICAL);
            } 
          }
        });
    buttonGroup.add(verticalRadioButton);
    jPanel2.add(horizontalRadioButton);
    jPanel2.add(verticalRadioButton);
    jPanel2.setBorder(new TitledBorder("Plot Settings: "));
    JPanel jPanel3 = new JPanel(new BorderLayout());
    slider = new JSlider(0, 90, 45);
    slider.setMajorTickSpacing(10);
    slider.setMinorTickSpacing(5);
    slider.setPaintLabels(true);
    slider.setPaintTicks(true);
    slider.addChangeListener(new ChangeListener() {
          public void stateChanged(ChangeEvent param1ChangeEvent) {
            CategoryPlot categoryPlot = (CategoryPlot)CategoryLabelPositionsDemo1.chart.getPlot();
            CategoryAxis categoryAxis = categoryPlot.getDomainAxis();
            categoryAxis.setCategoryLabelPositions(CategoryLabelPositions.createUpRotationLabelPositions(CategoryLabelPositionsDemo1.slider.getValue() * Math.PI / 180.0D));
          }
        });
    jPanel3.add(slider);
    jPanel3.setBorder(new TitledBorder("Axis Label Rotation Angle:"));
    jPanel1.add("North", jPanel2);
    jPanel1.add(jPanel3);
    demoPanel.add((Component)new ChartPanel(chart));
    demoPanel.addChart(chart);
    demoPanel.add("South", jPanel1);
    return demoPanel;
  }
  
  public static void main(String[] paramArrayOfString) {
    CategoryLabelPositionsDemo1 categoryLabelPositionsDemo1 = new CategoryLabelPositionsDemo1("JFreeChart: CategoryLabelPositionsDemo1.java");
    categoryLabelPositionsDemo1.pack();
    RefineryUtilities.centerFrameOnScreen((Window)categoryLabelPositionsDemo1);
    categoryLabelPositionsDemo1.setVisible(true);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/CategoryLabelPositionsDemo1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */