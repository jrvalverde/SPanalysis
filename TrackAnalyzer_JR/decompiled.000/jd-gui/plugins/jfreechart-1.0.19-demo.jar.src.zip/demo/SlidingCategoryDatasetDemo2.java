package demo;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.GradientPaint;
import java.awt.Window;
import javax.swing.BorderFactory;
import javax.swing.JPanel;
import javax.swing.JScrollBar;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.renderer.category.BarRenderer;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.category.SlidingCategoryDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

public class SlidingCategoryDatasetDemo2 extends ApplicationFrame {
  public SlidingCategoryDatasetDemo2(String paramString) {
    super(paramString);
    setDefaultCloseOperation(3);
    setContentPane(createDemoPanel());
  }
  
  public static JPanel createDemoPanel() {
    return new MyDemoPanel();
  }
  
  public static void main(String[] paramArrayOfString) {
    SlidingCategoryDatasetDemo2 slidingCategoryDatasetDemo2 = new SlidingCategoryDatasetDemo2("JFreeChart: SlidingCategoryDatasetDemo2.java");
    slidingCategoryDatasetDemo2.pack();
    RefineryUtilities.centerFrameOnScreen((Window)slidingCategoryDatasetDemo2);
    slidingCategoryDatasetDemo2.setVisible(true);
  }
  
  static class MyDemoPanel extends DemoPanel implements ChangeListener {
    JScrollBar scroller;
    
    SlidingCategoryDataset dataset = new SlidingCategoryDataset(createDataset(), 0, 10);
    
    public MyDemoPanel() {
      super(new BorderLayout());
      JFreeChart jFreeChart = createChart((CategoryDataset)this.dataset);
      addChart(jFreeChart);
      ChartPanel chartPanel = new ChartPanel(jFreeChart);
      chartPanel.setPreferredSize(new Dimension(400, 400));
      this.scroller = new JScrollBar(0, 0, 10, 0, 50);
      add((Component)chartPanel);
      this.scroller.getModel().addChangeListener(this);
      JPanel jPanel = new JPanel(new BorderLayout());
      jPanel.add(this.scroller);
      jPanel.setBorder(BorderFactory.createEmptyBorder(2, 2, 2, 2));
      jPanel.setBackground(Color.white);
      add(jPanel, "South");
    }
    
    private static CategoryDataset createDataset() {
      DefaultCategoryDataset defaultCategoryDataset = new DefaultCategoryDataset();
      for (byte b = 0; b < 50; b++)
        defaultCategoryDataset.addValue(Math.random() * 100.0D, "S1", "S" + b); 
      return (CategoryDataset)defaultCategoryDataset;
    }
    
    private static JFreeChart createChart(CategoryDataset param1CategoryDataset) {
      JFreeChart jFreeChart = ChartFactory.createBarChart("SlidingCategoryDatasetDemo2", "Series", "Value", param1CategoryDataset, PlotOrientation.VERTICAL, false, true, false);
      CategoryPlot categoryPlot = (CategoryPlot)jFreeChart.getPlot();
      CategoryAxis categoryAxis = categoryPlot.getDomainAxis();
      categoryAxis.setMaximumCategoryLabelWidthRatio(0.8F);
      categoryAxis.setLowerMargin(0.02D);
      categoryAxis.setUpperMargin(0.02D);
      NumberAxis numberAxis = (NumberAxis)categoryPlot.getRangeAxis();
      numberAxis.setStandardTickUnits(NumberAxis.createIntegerTickUnits());
      numberAxis.setRange(0.0D, 100.0D);
      BarRenderer barRenderer = (BarRenderer)categoryPlot.getRenderer();
      barRenderer.setDrawBarOutline(false);
      GradientPaint gradientPaint = new GradientPaint(0.0F, 0.0F, Color.blue, 0.0F, 0.0F, new Color(0, 0, 64));
      barRenderer.setSeriesPaint(0, gradientPaint);
      return jFreeChart;
    }
    
    public void stateChanged(ChangeEvent param1ChangeEvent) {
      this.dataset.setFirstCategoryIndex(this.scroller.getValue());
    }
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/SlidingCategoryDatasetDemo2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */