package demo;

import java.awt.Container;
import java.awt.Dimension;
import java.awt.Window;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartMouseEvent;
import org.jfree.chart.ChartMouseListener;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.entity.ChartEntity;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

public class MouseListenerDemo2 extends ApplicationFrame implements ChartMouseListener {
  public MouseListenerDemo2(String paramString) {
    super(paramString);
    DefaultCategoryDataset defaultCategoryDataset = new DefaultCategoryDataset();
    defaultCategoryDataset.addValue(1.0D, "S1", "C1");
    defaultCategoryDataset.addValue(4.0D, "S1", "C2");
    defaultCategoryDataset.addValue(3.0D, "S1", "C3");
    defaultCategoryDataset.addValue(5.0D, "S1", "C4");
    defaultCategoryDataset.addValue(5.0D, "S1", "C5");
    defaultCategoryDataset.addValue(6.0D, "S1", "C6");
    defaultCategoryDataset.addValue(7.0D, "S1", "C7");
    defaultCategoryDataset.addValue(8.0D, "S1", "C8");
    defaultCategoryDataset.addValue(5.0D, "S2", "C1");
    defaultCategoryDataset.addValue(7.0D, "S2", "C2");
    defaultCategoryDataset.addValue(6.0D, "S2", "C3");
    defaultCategoryDataset.addValue(8.0D, "S2", "C4");
    defaultCategoryDataset.addValue(4.0D, "S2", "C5");
    defaultCategoryDataset.addValue(4.0D, "S2", "C6");
    defaultCategoryDataset.addValue(3.0D, "S2", "C7");
    defaultCategoryDataset.addValue(1.0D, "S2", "C8");
    defaultCategoryDataset.addValue(4.0D, "S3", "C1");
    defaultCategoryDataset.addValue(3.0D, "S3", "C2");
    defaultCategoryDataset.addValue(2.0D, "S3", "C3");
    defaultCategoryDataset.addValue(3.0D, "S3", "C4");
    defaultCategoryDataset.addValue(6.0D, "S3", "C5");
    defaultCategoryDataset.addValue(3.0D, "S3", "C6");
    defaultCategoryDataset.addValue(4.0D, "S3", "C7");
    defaultCategoryDataset.addValue(3.0D, "S3", "C8");
    JFreeChart jFreeChart = ChartFactory.createBarChart("MouseListenerDemo2", "Category", "Value", (CategoryDataset)defaultCategoryDataset, PlotOrientation.VERTICAL, true, true, false);
    ChartPanel chartPanel = new ChartPanel(jFreeChart);
    chartPanel.addChartMouseListener(this);
    chartPanel.setPreferredSize(new Dimension(500, 270));
    setContentPane((Container)chartPanel);
  }
  
  public void chartMouseClicked(ChartMouseEvent paramChartMouseEvent) {
    ChartEntity chartEntity = paramChartMouseEvent.getEntity();
    if (chartEntity != null) {
      System.out.println("Mouse clicked: " + chartEntity.toString());
    } else {
      System.out.println("Mouse clicked: null entity.");
    } 
  }
  
  public void chartMouseMoved(ChartMouseEvent paramChartMouseEvent) {
    int i = paramChartMouseEvent.getTrigger().getX();
    int j = paramChartMouseEvent.getTrigger().getY();
    ChartEntity chartEntity = paramChartMouseEvent.getEntity();
    if (chartEntity != null) {
      System.out.println("Mouse moved: " + i + ", " + j + ": " + chartEntity.toString());
    } else {
      System.out.println("Mouse moved: " + i + ", " + j + ": null entity.");
    } 
  }
  
  public static void main(String[] paramArrayOfString) {
    MouseListenerDemo2 mouseListenerDemo2 = new MouseListenerDemo2("JFreeChart: MouseListenerDemo2.java");
    mouseListenerDemo2.pack();
    RefineryUtilities.centerFrameOnScreen((Window)mouseListenerDemo2);
    mouseListenerDemo2.setVisible(true);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/MouseListenerDemo2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */