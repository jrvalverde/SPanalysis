package demo;

import java.awt.Component;
import java.awt.Dimension;
import java.awt.Window;
import javax.swing.JDesktopPane;
import javax.swing.JInternalFrame;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.time.Minute;
import org.jfree.data.time.RegularTimePeriod;
import org.jfree.data.time.TimeSeries;
import org.jfree.data.time.TimeSeriesCollection;
import org.jfree.data.xy.XYDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

public class InternalFrameDemo extends ApplicationFrame {
  public InternalFrameDemo(String paramString) {
    super(paramString);
    JDesktopPane jDesktopPane = new JDesktopPane();
    jDesktopPane.setPreferredSize(new Dimension(600, 400));
    JInternalFrame jInternalFrame1 = createFrame1();
    jDesktopPane.add(jInternalFrame1);
    jInternalFrame1.pack();
    jInternalFrame1.setVisible(true);
    JInternalFrame jInternalFrame2 = createFrame2();
    jDesktopPane.add(jInternalFrame2);
    jInternalFrame2.pack();
    jInternalFrame2.setLocation(100, 200);
    jInternalFrame2.setVisible(true);
    getContentPane().add(jDesktopPane);
  }
  
  private JInternalFrame createFrame1() {
    DefaultCategoryDataset defaultCategoryDataset = new DefaultCategoryDataset();
    defaultCategoryDataset.addValue(34.0D, "Series 1", "Category 1");
    defaultCategoryDataset.addValue(23.0D, "Series 1", "Category 2");
    defaultCategoryDataset.addValue(54.0D, "Series 1", "Category 3");
    JFreeChart jFreeChart = ChartFactory.createBarChart("Bar Chart", "Category", "Series", (CategoryDataset)defaultCategoryDataset, PlotOrientation.VERTICAL, true, true, false);
    ChartPanel chartPanel = new ChartPanel(jFreeChart);
    chartPanel.setPreferredSize(new Dimension(200, 100));
    JInternalFrame jInternalFrame = new JInternalFrame("Frame 1", true);
    jInternalFrame.getContentPane().add((Component)chartPanel);
    return jInternalFrame;
  }
  
  private JInternalFrame createFrame2() {
    XYDataset xYDataset = createDataset("Series 1", 100.0D, (RegularTimePeriod)new Minute(), 200);
    JFreeChart jFreeChart = ChartFactory.createTimeSeriesChart("Time Series Chart", "Time of Day", "Value", xYDataset, true, true, false);
    ChartPanel chartPanel = new ChartPanel(jFreeChart);
    chartPanel.setPreferredSize(new Dimension(200, 100));
    JInternalFrame jInternalFrame = new JInternalFrame("Frame 2", true);
    jInternalFrame.getContentPane().add((Component)chartPanel);
    return jInternalFrame;
  }
  
  private XYDataset createDataset(String paramString, double paramDouble, RegularTimePeriod paramRegularTimePeriod, int paramInt) {
    TimeSeries timeSeries = new TimeSeries(paramString);
    RegularTimePeriod regularTimePeriod = paramRegularTimePeriod;
    double d = paramDouble;
    for (byte b = 0; b < paramInt; b++) {
      timeSeries.add(regularTimePeriod, d);
      regularTimePeriod = regularTimePeriod.next();
      d *= 1.0D + (Math.random() - 0.495D) / 10.0D;
    } 
    TimeSeriesCollection timeSeriesCollection = new TimeSeriesCollection();
    timeSeriesCollection.addSeries(timeSeries);
    return (XYDataset)timeSeriesCollection;
  }
  
  public static void main(String[] paramArrayOfString) {
    InternalFrameDemo internalFrameDemo = new InternalFrameDemo("Internal Frame Demo");
    internalFrameDemo.pack();
    RefineryUtilities.centerFrameOnScreen((Window)internalFrameDemo);
    internalFrameDemo.setVisible(true);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/InternalFrameDemo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */