package demo;

import java.awt.Dimension;
import java.awt.Window;
import javax.swing.JPanel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.SubCategoryAxis;
import org.jfree.chart.labels.CategoryItemLabelGenerator;
import org.jfree.chart.labels.ItemLabelAnchor;
import org.jfree.chart.labels.ItemLabelPosition;
import org.jfree.chart.labels.StandardCategoryItemLabelGenerator;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.renderer.category.CategoryItemRenderer;
import org.jfree.chart.renderer.category.GroupedStackedBarRenderer;
import org.jfree.data.KeyToGroupMap;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;
import org.jfree.ui.TextAnchor;

public class StackedBarChartDemo5 extends ApplicationFrame {
  public StackedBarChartDemo5(String paramString) {
    super(paramString);
    JPanel jPanel = createDemoPanel();
    jPanel.setPreferredSize(new Dimension(500, 270));
    setContentPane(jPanel);
  }
  
  private static CategoryDataset createDataset() {
    DefaultCategoryDataset defaultCategoryDataset = new DefaultCategoryDataset();
    defaultCategoryDataset.addValue(3396.0D, "S1", "C1");
    defaultCategoryDataset.addValue(1580.0D, "S2", "C1");
    defaultCategoryDataset.addValue(76.0D, "S3", "C1");
    defaultCategoryDataset.addValue(10100.0D, "S4", "C1");
    defaultCategoryDataset.addValue(3429.0D, "S1", "C2");
    defaultCategoryDataset.addValue(1562.0D, "S2", "C2");
    defaultCategoryDataset.addValue(61.0D, "S3", "C2");
    defaultCategoryDataset.addValue(-10100.0D, "S4", "C2");
    return (CategoryDataset)defaultCategoryDataset;
  }
  
  private static JFreeChart createChart(CategoryDataset paramCategoryDataset) {
    JFreeChart jFreeChart = ChartFactory.createStackedBarChart("Stacked Bar Chart Demo 5", "Category", "Value", paramCategoryDataset, PlotOrientation.VERTICAL, true, true, false);
    GroupedStackedBarRenderer groupedStackedBarRenderer = new GroupedStackedBarRenderer();
    KeyToGroupMap keyToGroupMap = new KeyToGroupMap("G1");
    keyToGroupMap.mapKeyToGroup("S1", "G1");
    keyToGroupMap.mapKeyToGroup("S2", "G1");
    keyToGroupMap.mapKeyToGroup("S3", "G2");
    keyToGroupMap.mapKeyToGroup("S4", "G3");
    groupedStackedBarRenderer.setSeriesToGroupMap(keyToGroupMap);
    groupedStackedBarRenderer.setBaseItemLabelGenerator((CategoryItemLabelGenerator)new StandardCategoryItemLabelGenerator());
    groupedStackedBarRenderer.setBaseItemLabelsVisible(true);
    groupedStackedBarRenderer.setPositiveItemLabelPositionFallback(new ItemLabelPosition(ItemLabelAnchor.OUTSIDE12, TextAnchor.BOTTOM_CENTER));
    groupedStackedBarRenderer.setItemMargin(0.1D);
    SubCategoryAxis subCategoryAxis = new SubCategoryAxis("Category / Group");
    subCategoryAxis.setCategoryMargin(0.05D);
    subCategoryAxis.addSubCategory("G1");
    subCategoryAxis.addSubCategory("G2");
    subCategoryAxis.addSubCategory("G3");
    CategoryPlot categoryPlot = (CategoryPlot)jFreeChart.getPlot();
    categoryPlot.setDomainAxis((CategoryAxis)subCategoryAxis);
    categoryPlot.setRenderer((CategoryItemRenderer)groupedStackedBarRenderer);
    ChartUtilities.applyCurrentTheme(jFreeChart);
    return jFreeChart;
  }
  
  public static JPanel createDemoPanel() {
    JFreeChart jFreeChart = createChart(createDataset());
    return (JPanel)new ChartPanel(jFreeChart);
  }
  
  public static void main(String[] paramArrayOfString) {
    StackedBarChartDemo5 stackedBarChartDemo5 = new StackedBarChartDemo5("Stacked Bar Chart Demo 5");
    stackedBarChartDemo5.pack();
    RefineryUtilities.centerFrameOnScreen((Window)stackedBarChartDemo5);
    stackedBarChartDemo5.setVisible(true);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/StackedBarChartDemo5.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */