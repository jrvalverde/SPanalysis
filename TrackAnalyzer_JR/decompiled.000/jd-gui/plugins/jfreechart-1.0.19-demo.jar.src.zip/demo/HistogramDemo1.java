package demo;

import java.awt.Dimension;
import java.awt.Window;
import java.io.IOException;
import java.util.Random;
import javax.swing.JPanel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.StandardXYBarPainter;
import org.jfree.chart.renderer.xy.XYBarPainter;
import org.jfree.chart.renderer.xy.XYBarRenderer;
import org.jfree.data.statistics.HistogramDataset;
import org.jfree.data.xy.IntervalXYDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

public class HistogramDemo1 extends ApplicationFrame {
  public HistogramDemo1(String paramString) {
    super(paramString);
    JPanel jPanel = createDemoPanel();
    jPanel.setPreferredSize(new Dimension(500, 270));
    setContentPane(jPanel);
  }
  
  private static IntervalXYDataset createDataset() {
    HistogramDataset histogramDataset = new HistogramDataset();
    double[] arrayOfDouble = new double[1000];
    Random random = new Random(12345678L);
    byte b;
    for (b = 0; b < 'Ϩ'; b++)
      arrayOfDouble[b] = random.nextGaussian() + 5.0D; 
    histogramDataset.addSeries("H1", arrayOfDouble, 100, 2.0D, 8.0D);
    arrayOfDouble = new double[1000];
    for (b = 0; b < 'Ϩ'; b++)
      arrayOfDouble[b] = random.nextGaussian() + 7.0D; 
    histogramDataset.addSeries("H2", arrayOfDouble, 100, 4.0D, 10.0D);
    return (IntervalXYDataset)histogramDataset;
  }
  
  private static JFreeChart createChart(IntervalXYDataset paramIntervalXYDataset) {
    JFreeChart jFreeChart = ChartFactory.createHistogram("Histogram Demo 1", null, null, paramIntervalXYDataset, PlotOrientation.VERTICAL, true, true, false);
    XYPlot xYPlot = (XYPlot)jFreeChart.getPlot();
    xYPlot.setDomainPannable(true);
    xYPlot.setRangePannable(true);
    xYPlot.setForegroundAlpha(0.85F);
    NumberAxis numberAxis = (NumberAxis)xYPlot.getRangeAxis();
    numberAxis.setStandardTickUnits(NumberAxis.createIntegerTickUnits());
    XYBarRenderer xYBarRenderer = (XYBarRenderer)xYPlot.getRenderer();
    xYBarRenderer.setDrawBarOutline(false);
    xYBarRenderer.setBarPainter((XYBarPainter)new StandardXYBarPainter());
    xYBarRenderer.setShadowVisible(false);
    return jFreeChart;
  }
  
  public static JPanel createDemoPanel() {
    JFreeChart jFreeChart = createChart(createDataset());
    ChartPanel chartPanel = new ChartPanel(jFreeChart);
    chartPanel.setMouseWheelEnabled(true);
    return (JPanel)chartPanel;
  }
  
  public static void main(String[] paramArrayOfString) throws IOException {
    HistogramDemo1 histogramDemo1 = new HistogramDemo1("JFreeChart: HistogramDemo1.java");
    histogramDemo1.pack();
    RefineryUtilities.centerFrameOnScreen((Window)histogramDemo1);
    histogramDemo1.setVisible(true);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/HistogramDemo1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */