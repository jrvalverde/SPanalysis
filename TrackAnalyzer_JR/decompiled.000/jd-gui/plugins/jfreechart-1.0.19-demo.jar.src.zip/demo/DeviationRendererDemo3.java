package demo;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Window;
import javax.swing.JPanel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.DateAxis;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.DeviationRenderer;
import org.jfree.chart.renderer.xy.XYItemRenderer;
import org.jfree.data.time.Quarter;
import org.jfree.data.time.RegularTimePeriod;
import org.jfree.data.xy.XYDataset;
import org.jfree.data.xy.YIntervalSeries;
import org.jfree.data.xy.YIntervalSeriesCollection;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

public class DeviationRendererDemo3 extends ApplicationFrame {
  public DeviationRendererDemo3(String paramString) {
    super(paramString);
    JPanel jPanel = createDemoPanel();
    jPanel.setPreferredSize(new Dimension(500, 270));
    setContentPane(jPanel);
  }
  
  private static XYDataset createDataset() {
    YIntervalSeries yIntervalSeries1 = new YIntervalSeries("Band A");
    YIntervalSeries yIntervalSeries2 = new YIntervalSeries("Band B");
    YIntervalSeries yIntervalSeries3 = new YIntervalSeries("Band C");
    Quarter quarter = new Quarter(1, 2005);
    double d = 0.0D;
    for (byte b = 0; b <= 12; b++) {
      d += (Math.random() - 0.5D) * 15.0D;
      yIntervalSeries1.add(quarter.getMiddleMillisecond(), d, d + 10.0D, Math.max(50.0D, d + 30.0D));
      yIntervalSeries2.add(quarter.getMiddleMillisecond(), d, d - 10.0D, d + 10.0D);
      yIntervalSeries3.add(quarter.getMiddleMillisecond(), d, Math.min(-50.0D, d - 30.0D), d - 10.0D);
      RegularTimePeriod regularTimePeriod = quarter.next();
    } 
    YIntervalSeriesCollection yIntervalSeriesCollection = new YIntervalSeriesCollection();
    yIntervalSeriesCollection.addSeries(yIntervalSeries1);
    yIntervalSeriesCollection.addSeries(yIntervalSeries2);
    yIntervalSeriesCollection.addSeries(yIntervalSeries3);
    return (XYDataset)yIntervalSeriesCollection;
  }
  
  private static JFreeChart createChart(XYDataset paramXYDataset) {
    JFreeChart jFreeChart = ChartFactory.createXYLineChart("DeviationRenderer - Demo 3", "X", "Y", paramXYDataset, PlotOrientation.VERTICAL, false, true, false);
    XYPlot xYPlot = (XYPlot)jFreeChart.getPlot();
    DeviationRenderer deviationRenderer = new DeviationRenderer(false, false);
    deviationRenderer.setSeriesStroke(0, new BasicStroke(3.0F, 1, 1));
    deviationRenderer.setSeriesStroke(0, new BasicStroke(3.0F, 1, 1));
    deviationRenderer.setSeriesStroke(1, new BasicStroke(3.0F, 1, 1));
    deviationRenderer.setSeriesFillPaint(0, Color.red);
    deviationRenderer.setSeriesFillPaint(1, Color.orange);
    deviationRenderer.setSeriesFillPaint(2, Color.green);
    xYPlot.setRenderer((XYItemRenderer)deviationRenderer);
    DateAxis dateAxis = new DateAxis("Date");
    dateAxis.setLowerMargin(0.0D);
    dateAxis.setUpperMargin(0.0D);
    xYPlot.setDomainAxis((ValueAxis)dateAxis);
    NumberAxis numberAxis = (NumberAxis)xYPlot.getRangeAxis();
    numberAxis.setRange(-40.0D, 40.0D);
    numberAxis.setStandardTickUnits(NumberAxis.createIntegerTickUnits());
    ChartUtilities.applyCurrentTheme(jFreeChart);
    return jFreeChart;
  }
  
  public static JPanel createDemoPanel() {
    JFreeChart jFreeChart = createChart(createDataset());
    return (JPanel)new ChartPanel(jFreeChart);
  }
  
  public static void main(String[] paramArrayOfString) {
    DeviationRendererDemo3 deviationRendererDemo3 = new DeviationRendererDemo3("JFreeChart : DeviationRendererDemo3.java");
    deviationRendererDemo3.pack();
    RefineryUtilities.centerFrameOnScreen((Window)deviationRendererDemo3);
    deviationRendererDemo3.setVisible(true);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/DeviationRendererDemo3.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */