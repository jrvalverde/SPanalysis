package demo;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Window;
import java.awt.font.TextAttribute;
import java.text.AttributedString;
import javax.swing.JPanel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.CategoryLabelPositions;
import org.jfree.chart.labels.CategoryItemLabelGenerator;
import org.jfree.chart.labels.StandardCategoryItemLabelGenerator;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.renderer.category.BarPainter;
import org.jfree.chart.renderer.category.StackedBarRenderer;
import org.jfree.chart.renderer.category.StandardBarPainter;
import org.jfree.chart.title.TextTitle;
import org.jfree.chart.title.Title;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

public class StackedBarChartDemo1 extends ApplicationFrame {
  public StackedBarChartDemo1(String paramString) {
    super(paramString);
    JPanel jPanel = createDemoPanel();
    jPanel.setPreferredSize(new Dimension(500, 270));
    setContentPane(jPanel);
  }
  
  private static CategoryDataset createDataset() {
    DefaultCategoryDataset defaultCategoryDataset = new DefaultCategoryDataset();
    defaultCategoryDataset.addValue(197.0D, "Agricultural", "Brazil");
    defaultCategoryDataset.addValue(64.0D, "Domestic", "Brazil");
    defaultCategoryDataset.addValue(57.0D, "Industrial", "Brazil");
    defaultCategoryDataset.addValue(339.0D, "Agricultural", "Indonesia");
    defaultCategoryDataset.addValue(30.0D, "Domestic", "Indonesia");
    defaultCategoryDataset.addValue(4.0D, "Industrial", "Indonesia");
    defaultCategoryDataset.addValue(279.0D, "Agricultural", "China");
    defaultCategoryDataset.addValue(27.0D, "Domestic", "China");
    defaultCategoryDataset.addValue(107.0D, "Industrial", "China");
    defaultCategoryDataset.addValue(92.0D, "Agricultural", "Germany");
    defaultCategoryDataset.addValue(55.0D, "Domestic", "Germany");
    defaultCategoryDataset.addValue(313.0D, "Industrial", "Germany");
    defaultCategoryDataset.addValue(96.0D, "Agricultural", "Russia");
    defaultCategoryDataset.addValue(102.0D, "Domestic", "Russia");
    defaultCategoryDataset.addValue(337.0D, "Industrial", "Russia");
    defaultCategoryDataset.addValue(403.0D, "Agricultural", "Turkey");
    defaultCategoryDataset.addValue(82.0D, "Domestic", "Turkey");
    defaultCategoryDataset.addValue(60.0D, "Industrial", "Turkey");
    defaultCategoryDataset.addValue(536.0D, "Agricultural", "Bangladesh");
    defaultCategoryDataset.addValue(17.0D, "Domestic", "Bangladesh");
    defaultCategoryDataset.addValue(6.0D, "Industrial", "Bangladesh");
    defaultCategoryDataset.addValue(508.0D, "Agricultural", "India");
    defaultCategoryDataset.addValue(47.0D, "Domestic", "India");
    defaultCategoryDataset.addValue(30.0D, "Industrial", "India");
    defaultCategoryDataset.addValue(428.0D, "Agricultural", "Japan");
    defaultCategoryDataset.addValue(138.0D, "Domestic", "Japan");
    defaultCategoryDataset.addValue(124.0D, "Industrial", "Japan");
    defaultCategoryDataset.addValue(325.0D, "Agricultural", "Italy");
    defaultCategoryDataset.addValue(130.0D, "Domestic", "Italy");
    defaultCategoryDataset.addValue(268.0D, "Industrial", "Italy");
    defaultCategoryDataset.addValue(569.0D, "Agricultural", "Mexico");
    defaultCategoryDataset.addValue(126.0D, "Domestic", "Mexico");
    defaultCategoryDataset.addValue(37.0D, "Industrial", "Mexico");
    defaultCategoryDataset.addValue(576.0D, "Agricultural", "Vietnam");
    defaultCategoryDataset.addValue(68.0D, "Domestic", "Vietnam");
    defaultCategoryDataset.addValue(203.0D, "Industrial", "Vietnam");
    defaultCategoryDataset.addValue(794.0D, "Agricultural", "Egypt");
    defaultCategoryDataset.addValue(74.0D, "Domestic", "Egypt");
    defaultCategoryDataset.addValue(55.0D, "Industrial", "Egypt");
    defaultCategoryDataset.addValue(954.0D, "Agricultural", "Iran");
    defaultCategoryDataset.addValue(21.0D, "Domestic", "Iran");
    defaultCategoryDataset.addValue(73.0D, "Industrial", "Iran");
    defaultCategoryDataset.addValue(1029.0D, "Agricultural", "Pakistan");
    defaultCategoryDataset.addValue(21.0D, "Domestic", "Pakistan");
    defaultCategoryDataset.addValue(21.0D, "Industrial", "Pakistan");
    defaultCategoryDataset.addValue(1236.0D, "Agricultural", "Thailand");
    defaultCategoryDataset.addValue(26.0D, "Domestic", "Thailand");
    defaultCategoryDataset.addValue(26.0D, "Industrial", "Thailand");
    defaultCategoryDataset.addValue(165.0D, "Agricultural", "Canada");
    defaultCategoryDataset.addValue(274.0D, "Domestic", "Canada");
    defaultCategoryDataset.addValue(947.0D, "Industrial", "Canada");
    defaultCategoryDataset.addValue(1363.0D, "Agricultural", "Iraq");
    defaultCategoryDataset.addValue(44.0D, "Domestic", "Iraq");
    defaultCategoryDataset.addValue(74.0D, "Industrial", "Iraq");
    defaultCategoryDataset.addValue(656.0D, "Agricultural", "US");
    defaultCategoryDataset.addValue(208.0D, "Domestic", "US");
    defaultCategoryDataset.addValue(736.0D, "Industrial", "US");
    defaultCategoryDataset.addValue(2040.0D, "Agricultural", "Uzbekistan");
    defaultCategoryDataset.addValue(110.0D, "Domestic", "Uzbekistan");
    defaultCategoryDataset.addValue(44.0D, "Industrial", "Uzbekistan");
    return (CategoryDataset)defaultCategoryDataset;
  }
  
  private static JFreeChart createChart(CategoryDataset paramCategoryDataset) {
    JFreeChart jFreeChart = ChartFactory.createStackedBarChart("Freshwater Usage By Country", "Country", "Value", paramCategoryDataset);
    jFreeChart.addSubtitle((Title)new TextTitle("Source: http://en.wikipedia.org/wiki/Peak_water#Water_supply"));
    CategoryPlot categoryPlot = (CategoryPlot)jFreeChart.getPlot();
    CategoryAxis categoryAxis = categoryPlot.getDomainAxis();
    categoryAxis.setLowerMargin(0.01D);
    categoryAxis.setUpperMargin(0.01D);
    categoryAxis.setCategoryLabelPositions(CategoryLabelPositions.UP_90);
    AttributedString attributedString = new AttributedString("m3/person/year");
    attributedString.addAttribute(TextAttribute.WEIGHT, TextAttribute.WEIGHT_ULTRABOLD);
    attributedString.addAttribute(TextAttribute.SIZE, Integer.valueOf(14));
    attributedString.addAttribute(TextAttribute.SUPERSCRIPT, TextAttribute.SUPERSCRIPT_SUPER, 1, 2);
    categoryPlot.getRangeAxis().setAttributedLabel(attributedString);
    StackedBarRenderer stackedBarRenderer = (StackedBarRenderer)categoryPlot.getRenderer();
    stackedBarRenderer.setDrawBarOutline(false);
    stackedBarRenderer.setBarPainter((BarPainter)new StandardBarPainter());
    stackedBarRenderer.setBaseItemLabelsVisible(true);
    stackedBarRenderer.setBaseItemLabelGenerator((CategoryItemLabelGenerator)new StandardCategoryItemLabelGenerator());
    stackedBarRenderer.setBaseItemLabelPaint(Color.WHITE);
    stackedBarRenderer.setSeriesPaint(0, new Color(0, 55, 122));
    stackedBarRenderer.setSeriesPaint(1, new Color(24, 123, 58));
    stackedBarRenderer.setSeriesPaint(2, Color.RED);
    return jFreeChart;
  }
  
  public static JPanel createDemoPanel() {
    JFreeChart jFreeChart = createChart(createDataset());
    return (JPanel)new ChartPanel(jFreeChart);
  }
  
  public static void main(String[] paramArrayOfString) {
    StackedBarChartDemo1 stackedBarChartDemo1 = new StackedBarChartDemo1("JFreeChart: StackedBarChartDemo1");
    stackedBarChartDemo1.pack();
    RefineryUtilities.centerFrameOnScreen((Window)stackedBarChartDemo1);
    stackedBarChartDemo1.setVisible(true);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/StackedBarChartDemo1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */