package demo;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Window;
import java.awt.image.BufferedImage;
import javax.swing.BorderFactory;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.annotations.XYAnnotation;
import org.jfree.chart.annotations.XYDataImageAnnotation;
import org.jfree.chart.axis.AxisLocation;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.event.ChartChangeEvent;
import org.jfree.chart.event.ChartChangeListener;
import org.jfree.chart.panel.CrosshairOverlay;
import org.jfree.chart.panel.Overlay;
import org.jfree.chart.plot.Crosshair;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.GrayPaintScale;
import org.jfree.chart.renderer.PaintScale;
import org.jfree.data.Range;
import org.jfree.data.general.DefaultHeatMapDataset;
import org.jfree.data.general.HeatMapDataset;
import org.jfree.data.general.HeatMapUtilities;
import org.jfree.data.xy.XYDataset;
import org.jfree.data.xy.XYSeriesCollection;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.Layer;
import org.jfree.ui.RectangleAnchor;
import org.jfree.ui.RefineryUtilities;

public class CrossSectionDemo1 extends ApplicationFrame {
  public CrossSectionDemo1(String paramString) {
    super(paramString);
    JPanel jPanel = createDemoPanel();
    setContentPane(jPanel);
  }
  
  private static HeatMapDataset createMapDataset() {
    DefaultHeatMapDataset defaultHeatMapDataset = new DefaultHeatMapDataset(501, 501, -250.0D, 250.0D, -250.0D, 250.0D);
    for (byte b = 0; b < 'ǵ'; b++) {
      for (byte b1 = 0; b1 < 'ǵ'; b1++)
        defaultHeatMapDataset.setZValue(b, b1, Math.sin(Math.sqrt((b * b1)) / 10.0D)); 
    } 
    return (HeatMapDataset)defaultHeatMapDataset;
  }
  
  public static JPanel createDemoPanel() {
    return new MyDemoPanel();
  }
  
  public static void main(String[] paramArrayOfString) {
    CrossSectionDemo1 crossSectionDemo1 = new CrossSectionDemo1("JFreeChart: CrossSectionDemo1");
    crossSectionDemo1.pack();
    RefineryUtilities.centerFrameOnScreen((Window)crossSectionDemo1);
    crossSectionDemo1.setVisible(true);
  }
  
  static class MyDemoPanel extends DemoPanel implements ChangeListener, ChartChangeListener {
    private HeatMapDataset dataset;
    
    private JFreeChart mainChart;
    
    private JFreeChart subchart1;
    
    private JFreeChart subchart2;
    
    private JSlider slider1;
    
    private JSlider slider2;
    
    private Crosshair crosshair1;
    
    private Crosshair crosshair2;
    
    private Range lastXRange;
    
    private Range lastYRange;
    
    public MyDemoPanel() {
      super(new BorderLayout());
      ChartPanel chartPanel1 = (ChartPanel)createMainPanel();
      chartPanel1.setPreferredSize(new Dimension(500, 270));
      CrosshairOverlay crosshairOverlay = new CrosshairOverlay();
      this.crosshair1 = new Crosshair(0.0D);
      this.crosshair1.setPaint(Color.red);
      this.crosshair2 = new Crosshair(0.0D);
      this.crosshair2.setPaint(Color.blue);
      crosshairOverlay.addDomainCrosshair(this.crosshair1);
      crosshairOverlay.addRangeCrosshair(this.crosshair2);
      chartPanel1.addOverlay((Overlay)crosshairOverlay);
      this.crosshair1.setLabelVisible(true);
      this.crosshair1.setLabelAnchor(RectangleAnchor.BOTTOM_RIGHT);
      this.crosshair1.setLabelBackgroundPaint(new Color(255, 255, 0, 100));
      this.crosshair2.setLabelVisible(true);
      this.crosshair2.setLabelBackgroundPaint(new Color(255, 255, 0, 100));
      add((Component)chartPanel1);
      JPanel jPanel1 = new JPanel(new BorderLayout());
      XYSeriesCollection xYSeriesCollection1 = new XYSeriesCollection();
      this.subchart1 = ChartFactory.createXYLineChart("Cross-section A", "Y", "Z", (XYDataset)xYSeriesCollection1, PlotOrientation.HORIZONTAL, false, false, false);
      XYPlot xYPlot1 = (XYPlot)this.subchart1.getPlot();
      xYPlot1.getDomainAxis().setLowerMargin(0.0D);
      xYPlot1.getDomainAxis().setUpperMargin(0.0D);
      xYPlot1.setDomainAxisLocation(AxisLocation.BOTTOM_OR_RIGHT);
      ChartPanel chartPanel2 = new ChartPanel(this.subchart1);
      chartPanel2.setMinimumDrawWidth(0);
      chartPanel2.setMinimumDrawHeight(0);
      chartPanel2.setPreferredSize(new Dimension(200, 150));
      this.slider1 = new JSlider(-250, 250, 0);
      this.slider1.addChangeListener(this);
      this.slider1.setOrientation(1);
      jPanel1.add((Component)chartPanel2);
      jPanel1.add(this.slider1, "West");
      JPanel jPanel2 = new JPanel(new BorderLayout());
      XYSeriesCollection xYSeriesCollection2 = new XYSeriesCollection();
      this.subchart2 = ChartFactory.createXYLineChart("Cross-section B", "X", "Z", (XYDataset)xYSeriesCollection2, PlotOrientation.VERTICAL, false, false, false);
      XYPlot xYPlot2 = (XYPlot)this.subchart2.getPlot();
      xYPlot2.getDomainAxis().setLowerMargin(0.0D);
      xYPlot2.getDomainAxis().setUpperMargin(0.0D);
      xYPlot2.getRenderer().setSeriesPaint(0, Color.blue);
      ChartPanel chartPanel3 = new ChartPanel(this.subchart2);
      chartPanel3.setMinimumDrawWidth(0);
      chartPanel3.setMinimumDrawHeight(0);
      chartPanel3.setPreferredSize(new Dimension(200, 150));
      JPanel jPanel3 = new JPanel();
      jPanel3.setPreferredSize(new Dimension(200, 10));
      jPanel2.add(jPanel3, "East");
      this.slider2 = new JSlider(-250, 250, 0);
      this.slider2.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 200));
      this.slider2.addChangeListener(this);
      jPanel2.add((Component)chartPanel3);
      jPanel2.add(this.slider2, "North");
      add(jPanel1, "East");
      add(jPanel2, "South");
      this.mainChart.setNotify(true);
    }
    
    public JPanel createMainPanel() {
      this.mainChart = createChart((XYDataset)new XYSeriesCollection());
      this.mainChart.addChangeListener(this);
      ChartPanel chartPanel = new ChartPanel(this.mainChart);
      chartPanel.setFillZoomRectangle(true);
      chartPanel.setMouseWheelEnabled(true);
      return (JPanel)chartPanel;
    }
    
    public void stateChanged(ChangeEvent param1ChangeEvent) {
      if (param1ChangeEvent.getSource() == this.slider1) {
        this.crosshair2.setValue(this.slider1.getValue());
        int i = this.slider1.getValue() - this.slider1.getMinimum();
        XYDataset xYDataset = HeatMapUtilities.extractColumnFromHeatMapDataset(this.dataset, i, "Y1");
        this.subchart2.getXYPlot().setDataset(xYDataset);
      } else if (param1ChangeEvent.getSource() == this.slider2) {
        this.crosshair1.setValue(this.slider2.getValue());
        int i = this.slider2.getValue() - this.slider2.getMinimum();
        XYDataset xYDataset = HeatMapUtilities.extractRowFromHeatMapDataset(this.dataset, i, "Y2");
        this.subchart1.getXYPlot().setDataset(xYDataset);
      } 
    }
    
    public void chartChanged(ChartChangeEvent param1ChartChangeEvent) {
      XYPlot xYPlot = (XYPlot)this.mainChart.getPlot();
      if (!xYPlot.getDomainAxis().getRange().equals(this.lastXRange)) {
        this.lastXRange = xYPlot.getDomainAxis().getRange();
        XYPlot xYPlot1 = (XYPlot)this.subchart2.getPlot();
        xYPlot1.getDomainAxis().setRange(this.lastXRange);
      } 
      if (!xYPlot.getRangeAxis().getRange().equals(this.lastYRange)) {
        this.lastYRange = xYPlot.getRangeAxis().getRange();
        XYPlot xYPlot1 = (XYPlot)this.subchart1.getPlot();
        xYPlot1.getDomainAxis().setRange(this.lastYRange);
      } 
    }
    
    private JFreeChart createChart(XYDataset param1XYDataset) {
      JFreeChart jFreeChart = ChartFactory.createScatterPlot("CrossSectionDemo1", "X", "Y", param1XYDataset, PlotOrientation.VERTICAL, true, false, false);
      this.dataset = CrossSectionDemo1.createMapDataset();
      GrayPaintScale grayPaintScale = new GrayPaintScale(-1.0D, 1.0D, 128);
      BufferedImage bufferedImage = HeatMapUtilities.createHeatMapImage(this.dataset, (PaintScale)grayPaintScale);
      XYDataImageAnnotation xYDataImageAnnotation = new XYDataImageAnnotation(bufferedImage, -250.5D, -250.5D, 501.0D, 501.0D, true);
      XYPlot xYPlot = (XYPlot)jFreeChart.getPlot();
      xYPlot.setDomainPannable(true);
      xYPlot.setRangePannable(true);
      xYPlot.getRenderer().addAnnotation((XYAnnotation)xYDataImageAnnotation, Layer.BACKGROUND);
      NumberAxis numberAxis1 = (NumberAxis)xYPlot.getDomainAxis();
      numberAxis1.setStandardTickUnits(NumberAxis.createIntegerTickUnits());
      numberAxis1.setLowerMargin(0.0D);
      numberAxis1.setUpperMargin(0.0D);
      NumberAxis numberAxis2 = (NumberAxis)xYPlot.getRangeAxis();
      numberAxis2.setStandardTickUnits(NumberAxis.createIntegerTickUnits());
      numberAxis2.setLowerMargin(0.0D);
      numberAxis2.setUpperMargin(0.0D);
      return jFreeChart;
    }
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/CrossSectionDemo1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */