package demo;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Window;
import javax.swing.JPanel;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.DialShape;
import org.jfree.chart.plot.MeterInterval;
import org.jfree.chart.plot.MeterPlot;
import org.jfree.chart.plot.Plot;
import org.jfree.data.Range;
import org.jfree.data.general.DefaultValueDataset;
import org.jfree.data.general.ValueDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

public class MeterChartDemo3 extends ApplicationFrame {
  public MeterChartDemo3(String paramString) {
    super(paramString);
    JPanel jPanel = createDemoPanel();
    jPanel.setPreferredSize(new Dimension(500, 270));
    setContentPane(jPanel);
  }
  
  private static JFreeChart createChart(String paramString, ValueDataset paramValueDataset, DialShape paramDialShape) {
    MeterPlot meterPlot = new MeterPlot(paramValueDataset);
    meterPlot.setDialShape(paramDialShape);
    meterPlot.setRange(new Range(0.0D, 60.0D));
    meterPlot.addInterval(new MeterInterval("Normal", new Range(0.0D, 35.0D), Color.lightGray, new BasicStroke(2.0F), new Color(0, 255, 0, 64)));
    meterPlot.addInterval(new MeterInterval("Warning", new Range(35.0D, 50.0D), Color.lightGray, new BasicStroke(2.0F), new Color(255, 255, 0, 64)));
    meterPlot.addInterval(new MeterInterval("Critical", new Range(50.0D, 60.0D), Color.lightGray, new BasicStroke(2.0F), new Color(255, 0, 0, 128)));
    meterPlot.setNeedlePaint(Color.darkGray);
    meterPlot.setDialBackgroundPaint(Color.white);
    meterPlot.setDialOutlinePaint(Color.gray);
    meterPlot.setMeterAngle(260);
    meterPlot.setTickLabelsVisible(true);
    meterPlot.setTickLabelFont(new Font("Dialog", 1, 10));
    meterPlot.setTickLabelPaint(Color.darkGray);
    meterPlot.setTickSize(5.0D);
    meterPlot.setTickPaint(Color.lightGray);
    meterPlot.setValuePaint(Color.black);
    meterPlot.setValueFont(new Font("Dialog", 1, 14));
    JFreeChart jFreeChart = new JFreeChart(paramString, JFreeChart.DEFAULT_TITLE_FONT, (Plot)meterPlot, true);
    ChartUtilities.applyCurrentTheme(jFreeChart);
    return jFreeChart;
  }
  
  public static JPanel createDemoPanel() {
    JPanel jPanel = new JPanel(new GridLayout(1, 3));
    DefaultValueDataset defaultValueDataset = new DefaultValueDataset(23.0D);
    ChartPanel chartPanel1 = new ChartPanel(createChart("DialShape.PIE", (ValueDataset)defaultValueDataset, DialShape.PIE));
    ChartPanel chartPanel2 = new ChartPanel(createChart("DialShape.CHORD", (ValueDataset)defaultValueDataset, DialShape.CHORD));
    ChartPanel chartPanel3 = new ChartPanel(createChart("DialShape.CIRCLE", (ValueDataset)defaultValueDataset, DialShape.CIRCLE));
    jPanel.add((Component)chartPanel1);
    jPanel.add((Component)chartPanel2);
    jPanel.add((Component)chartPanel3);
    return jPanel;
  }
  
  public static void main(String[] paramArrayOfString) {
    MeterChartDemo3 meterChartDemo3 = new MeterChartDemo3("JFreeChart: MeterChartDemo3.java");
    meterChartDemo3.pack();
    RefineryUtilities.centerFrameOnScreen((Window)meterChartDemo3);
    meterChartDemo3.setVisible(true);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/MeterChartDemo3.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */