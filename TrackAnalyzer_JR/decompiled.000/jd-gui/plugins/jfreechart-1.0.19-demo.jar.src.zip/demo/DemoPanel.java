package demo;

import java.awt.LayoutManager;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JPanel;
import org.jfree.chart.JFreeChart;

public class DemoPanel extends JPanel {
  List charts = new ArrayList();
  
  public DemoPanel(LayoutManager paramLayoutManager) {
    super(paramLayoutManager);
  }
  
  public void addChart(JFreeChart paramJFreeChart) {
    this.charts.add(paramJFreeChart);
  }
  
  public JFreeChart[] getCharts() {
    int i = this.charts.size();
    JFreeChart[] arrayOfJFreeChart = new JFreeChart[i];
    for (byte b = 0; b < i; b++)
      arrayOfJFreeChart[b] = this.charts.get(b); 
    return arrayOfJFreeChart;
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/DemoPanel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */