package demo;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Window;
import java.text.SimpleDateFormat;
import javax.swing.JPanel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.AxisLocation;
import org.jfree.chart.axis.DateAxis;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYItemRenderer;
import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
import org.jfree.data.time.Day;
import org.jfree.data.time.RegularTimePeriod;
import org.jfree.data.time.TimeSeries;
import org.jfree.data.time.TimeSeriesCollection;
import org.jfree.data.xy.XYDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

public class MultipleAxisDemo4 extends ApplicationFrame {
  public MultipleAxisDemo4(String paramString) {
    super(paramString);
    JPanel jPanel = createDemoPanel();
    jPanel.setPreferredSize(new Dimension(600, 270));
    setContentPane(jPanel);
  }
  
  private static JFreeChart createChart() {
    XYDataset xYDataset1 = createDataset("March 2007", 100.0D, (RegularTimePeriod)new Day(1, 3, 2007), 31);
    JFreeChart jFreeChart = ChartFactory.createTimeSeriesChart("Multiple Axis Demo 4", "Date", "Value", xYDataset1, true, true, false);
    XYPlot xYPlot = (XYPlot)jFreeChart.getPlot();
    xYPlot.setOrientation(PlotOrientation.VERTICAL);
    DateAxis dateAxis1 = (DateAxis)xYPlot.getDomainAxis();
    dateAxis1.setDateFormatOverride(new SimpleDateFormat("d-MMM-yyyy"));
    XYItemRenderer xYItemRenderer = xYPlot.getRenderer();
    xYItemRenderer.setSeriesPaint(0, Color.red);
    NumberAxis numberAxis1 = (NumberAxis)xYPlot.getRangeAxis();
    numberAxis1.setTickLabelPaint(Color.red);
    DateAxis dateAxis2 = new DateAxis("Date");
    dateAxis2.setDateFormatOverride(new SimpleDateFormat("d-MMM-yyyy"));
    xYPlot.setDomainAxis(1, (ValueAxis)dateAxis2);
    xYPlot.setDomainAxisLocation(1, AxisLocation.TOP_OR_LEFT);
    NumberAxis numberAxis2 = new NumberAxis("Value");
    numberAxis2.setAutoRangeIncludesZero(false);
    numberAxis2.setTickLabelPaint(Color.blue);
    xYPlot.setRangeAxis(1, (ValueAxis)numberAxis2);
    xYPlot.setRangeAxisLocation(1, AxisLocation.BOTTOM_OR_RIGHT);
    XYDataset xYDataset2 = createDataset("July 2007", 1000.0D, (RegularTimePeriod)new Day(1, 7, 2007), 31);
    xYPlot.setDataset(1, xYDataset2);
    xYPlot.mapDatasetToDomainAxis(1, 1);
    xYPlot.mapDatasetToRangeAxis(1, 1);
    XYLineAndShapeRenderer xYLineAndShapeRenderer = new XYLineAndShapeRenderer(true, false);
    xYLineAndShapeRenderer.setSeriesPaint(0, Color.blue);
    xYPlot.setRenderer(1, (XYItemRenderer)xYLineAndShapeRenderer);
    ChartUtilities.applyCurrentTheme(jFreeChart);
    return jFreeChart;
  }
  
  private static XYDataset createDataset(String paramString, double paramDouble, RegularTimePeriod paramRegularTimePeriod, int paramInt) {
    TimeSeries timeSeries = new TimeSeries(paramString);
    RegularTimePeriod regularTimePeriod = paramRegularTimePeriod;
    double d = paramDouble;
    for (byte b = 0; b < paramInt; b++) {
      timeSeries.add(regularTimePeriod, d);
      regularTimePeriod = regularTimePeriod.next();
      d *= 1.0D + (Math.random() - 0.495D) / 10.0D;
    } 
    TimeSeriesCollection timeSeriesCollection = new TimeSeriesCollection();
    timeSeriesCollection.addSeries(timeSeries);
    return (XYDataset)timeSeriesCollection;
  }
  
  public static JPanel createDemoPanel() {
    JFreeChart jFreeChart = createChart();
    return (JPanel)new ChartPanel(jFreeChart);
  }
  
  public static void main(String[] paramArrayOfString) {
    MultipleAxisDemo4 multipleAxisDemo4 = new MultipleAxisDemo4("JFreeChart: MultipleAxisDemo4.java");
    multipleAxisDemo4.pack();
    RefineryUtilities.centerFrameOnScreen((Window)multipleAxisDemo4);
    multipleAxisDemo4.setVisible(true);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/MultipleAxisDemo4.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */