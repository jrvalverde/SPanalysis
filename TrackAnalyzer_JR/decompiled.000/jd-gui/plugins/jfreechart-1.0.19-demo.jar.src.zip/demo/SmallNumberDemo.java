package demo;

import java.awt.Container;
import java.awt.Dimension;
import java.awt.Window;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.axis.StandardTickUnitSource;
import org.jfree.chart.axis.TickUnitSource;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.data.xy.XYDataset;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

public class SmallNumberDemo extends ApplicationFrame {
  public SmallNumberDemo(String paramString) {
    super(paramString);
    XYSeries xYSeries = new XYSeries("Small Numbers");
    xYSeries.add(1.0E-5D, 1.0E-16D);
    xYSeries.add(5.0E-5D, 2.0E-12D);
    XYSeriesCollection xYSeriesCollection = new XYSeriesCollection(xYSeries);
    JFreeChart jFreeChart = ChartFactory.createXYLineChart("Small Number Demo", "X", "Y", (XYDataset)xYSeriesCollection, PlotOrientation.VERTICAL, true, true, false);
    XYPlot xYPlot = (XYPlot)jFreeChart.getPlot();
    NumberAxis numberAxis1 = (NumberAxis)xYPlot.getDomainAxis();
    numberAxis1.setStandardTickUnits((TickUnitSource)new StandardTickUnitSource());
    NumberAxis numberAxis2 = (NumberAxis)xYPlot.getRangeAxis();
    numberAxis2.setStandardTickUnits((TickUnitSource)new StandardTickUnitSource());
    numberAxis2.setAutoRangeMinimumSize(Double.MIN_VALUE);
    ChartPanel chartPanel = new ChartPanel(jFreeChart);
    chartPanel.setPreferredSize(new Dimension(500, 270));
    setContentPane((Container)chartPanel);
  }
  
  public static void main(String[] paramArrayOfString) {
    System.out.println("Min Double: 4.9E-324");
    SmallNumberDemo smallNumberDemo = new SmallNumberDemo("Small Number Demo");
    smallNumberDemo.pack();
    RefineryUtilities.centerFrameOnScreen((Window)smallNumberDemo);
    smallNumberDemo.setVisible(true);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/SmallNumberDemo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */