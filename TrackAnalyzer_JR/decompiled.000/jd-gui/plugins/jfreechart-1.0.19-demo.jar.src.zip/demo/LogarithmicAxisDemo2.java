package demo;

import java.awt.Dimension;
import java.awt.Window;
import javax.swing.JPanel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.LogarithmicAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.data.xy.XYDataset;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

public class LogarithmicAxisDemo2 extends ApplicationFrame {
  public LogarithmicAxisDemo2(String paramString) {
    super(paramString);
    JPanel jPanel = createDemoPanel();
    jPanel.setPreferredSize(new Dimension(500, 270));
    setContentPane(jPanel);
  }
  
  private static JFreeChart createChart(XYDataset paramXYDataset) {
    JFreeChart jFreeChart = ChartFactory.createScatterPlot("Logarithmic Axis Demo 2", "X", "Y", paramXYDataset, PlotOrientation.VERTICAL, true, true, false);
    XYPlot xYPlot = (XYPlot)jFreeChart.getPlot();
    LogarithmicAxis logarithmicAxis1 = new LogarithmicAxis("X");
    logarithmicAxis1.setExpTickLabelsFlag(true);
    logarithmicAxis1.setStrictValuesFlag(false);
    LogarithmicAxis logarithmicAxis2 = new LogarithmicAxis("Y");
    logarithmicAxis2.setAllowNegativesFlag(true);
    logarithmicAxis2.setLog10TickLabelsFlag(true);
    xYPlot.setDomainAxis((ValueAxis)logarithmicAxis1);
    xYPlot.setRangeAxis((ValueAxis)logarithmicAxis2);
    ChartUtilities.applyCurrentTheme(jFreeChart);
    return jFreeChart;
  }
  
  private static XYDataset createDataset() {
    XYSeries xYSeries = new XYSeries("Series 1");
    xYSeries.add(-500.0D, -500.0D);
    xYSeries.add(-50.0D, -50.0D);
    xYSeries.add(-5.0D, -5.0D);
    xYSeries.add(0.0D, 0.0D);
    xYSeries.add(5.0D, 5.0D);
    xYSeries.add(50.0D, 50.0D);
    xYSeries.add(500.0D, 500.0D);
    return (XYDataset)new XYSeriesCollection(xYSeries);
  }
  
  public static JPanel createDemoPanel() {
    JFreeChart jFreeChart = createChart(createDataset());
    return (JPanel)new ChartPanel(jFreeChart);
  }
  
  public static void main(String[] paramArrayOfString) {
    LogarithmicAxisDemo2 logarithmicAxisDemo2 = new LogarithmicAxisDemo2("JFreeChart: LogarithmicAxisDemo2.java");
    logarithmicAxisDemo2.pack();
    RefineryUtilities.centerFrameOnScreen((Window)logarithmicAxisDemo2);
    logarithmicAxisDemo2.setVisible(true);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/LogarithmicAxisDemo2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */