package demo;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Window;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JPanel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.XYPlot;
import org.jfree.data.time.Millisecond;
import org.jfree.data.time.RegularTimePeriod;
import org.jfree.data.time.TimeSeries;
import org.jfree.data.time.TimeSeriesCollection;
import org.jfree.data.xy.XYDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

public class DynamicDataDemo1 extends ApplicationFrame {
  public DynamicDataDemo1(String paramString) {
    super(paramString);
    MyDemoPanel myDemoPanel = new MyDemoPanel();
    setContentPane(myDemoPanel);
  }
  
  public static JPanel createDemoPanel() {
    return new MyDemoPanel();
  }
  
  public static void main(String[] paramArrayOfString) {
    DynamicDataDemo1 dynamicDataDemo1 = new DynamicDataDemo1("JFreeChart: DynamicDataDemo1.java");
    dynamicDataDemo1.pack();
    RefineryUtilities.centerFrameOnScreen((Window)dynamicDataDemo1);
    dynamicDataDemo1.setVisible(true);
  }
  
  static class MyDemoPanel extends DemoPanel implements ActionListener {
    private TimeSeries series = new TimeSeries("Random Data");
    
    private double lastValue = 100.0D;
    
    public MyDemoPanel() {
      super(new BorderLayout());
      TimeSeriesCollection timeSeriesCollection = new TimeSeriesCollection(this.series);
      ChartPanel chartPanel = new ChartPanel(createChart((XYDataset)timeSeriesCollection));
      chartPanel.setPreferredSize(new Dimension(500, 270));
      addChart(chartPanel.getChart());
      JPanel jPanel = new JPanel();
      jPanel.setBorder(BorderFactory.createEmptyBorder(4, 4, 4, 4));
      JButton jButton = new JButton("Add New Data Item");
      jButton.setActionCommand("ADD_DATA");
      jButton.addActionListener(this);
      jPanel.add(jButton);
      add((Component)chartPanel);
      add(jPanel, "South");
    }
    
    private JFreeChart createChart(XYDataset param1XYDataset) {
      JFreeChart jFreeChart = ChartFactory.createTimeSeriesChart("Dynamic Data Demo", "Time", "Value", param1XYDataset);
      XYPlot xYPlot = (XYPlot)jFreeChart.getPlot();
      ValueAxis valueAxis = xYPlot.getDomainAxis();
      valueAxis.setAutoRange(true);
      valueAxis.setFixedAutoRange(60000.0D);
      valueAxis = xYPlot.getRangeAxis();
      valueAxis.setRange(0.0D, 200.0D);
      return jFreeChart;
    }
    
    public void actionPerformed(ActionEvent param1ActionEvent) {
      if (param1ActionEvent.getActionCommand().equals("ADD_DATA")) {
        double d = 0.9D + 0.2D * Math.random();
        this.lastValue *= d;
        Millisecond millisecond = new Millisecond();
        System.out.println("Now = " + millisecond.toString());
        this.series.add((RegularTimePeriod)new Millisecond(), this.lastValue);
      } 
    }
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/DynamicDataDemo1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */