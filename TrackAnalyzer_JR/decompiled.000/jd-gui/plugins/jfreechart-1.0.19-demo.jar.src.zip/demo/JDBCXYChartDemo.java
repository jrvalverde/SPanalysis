package demo;

import java.awt.Color;
import java.awt.Container;
import java.awt.Window;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.data.jdbc.JDBCXYDataset;
import org.jfree.data.xy.XYDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

public class JDBCXYChartDemo extends ApplicationFrame {
  public JDBCXYChartDemo(String paramString) {
    super(paramString);
    XYDataset xYDataset = readData();
    JFreeChart jFreeChart = ChartFactory.createTimeSeriesChart("JDBC XY Chart Demo", "Date", "Value", xYDataset, true, true, false);
    jFreeChart.setBackgroundPaint(Color.yellow);
    ChartPanel chartPanel = new ChartPanel(jFreeChart);
    setContentPane((Container)chartPanel);
  }
  
  private XYDataset readData() {
    JDBCXYDataset jDBCXYDataset = null;
    String str = "jdbc:postgresql://nomad/jfreechartdb";
    try {
      Class.forName("org.postgresql.Driver");
    } catch (ClassNotFoundException classNotFoundException) {
      System.err.print("ClassNotFoundException: ");
      System.err.println(classNotFoundException.getMessage());
    } 
    try {
      Connection connection = DriverManager.getConnection(str, "jfreechart", "password");
      jDBCXYDataset = new JDBCXYDataset(connection);
      String str1 = "SELECT * FROM XYDATA1;";
      jDBCXYDataset.executeQuery(str1);
      connection.close();
    } catch (SQLException sQLException) {
      System.err.print("SQLException: ");
      System.err.println(sQLException.getMessage());
    } catch (Exception exception) {
      System.err.print("Exception: ");
      System.err.println(exception.getMessage());
    } 
    return (XYDataset)jDBCXYDataset;
  }
  
  public static void main(String[] paramArrayOfString) {
    JDBCXYChartDemo jDBCXYChartDemo = new JDBCXYChartDemo("JDBC XY Chart Demo");
    jDBCXYChartDemo.pack();
    RefineryUtilities.centerFrameOnScreen((Window)jDBCXYChartDemo);
    jDBCXYChartDemo.setVisible(true);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/JDBCXYChartDemo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */