package demo;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.GradientPaint;
import java.awt.Paint;
import java.awt.Window;
import javax.swing.JPanel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartMouseEvent;
import org.jfree.chart.ChartMouseListener;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.entity.CategoryItemEntity;
import org.jfree.chart.entity.ChartEntity;
import org.jfree.chart.event.RendererChangeEvent;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.renderer.category.BarRenderer;
import org.jfree.chart.renderer.category.CategoryItemRenderer;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

public class MouseOverDemo1 extends ApplicationFrame {
  public MouseOverDemo1(String paramString) {
    super(paramString);
    JPanel jPanel = createDemoPanel();
    jPanel.setPreferredSize(new Dimension(500, 270));
    setContentPane(jPanel);
  }
  
  private static CategoryDataset createDataset() {
    String str1 = "First";
    String str2 = "Second";
    String str3 = "Third";
    String str4 = "Category 1";
    String str5 = "Category 2";
    String str6 = "Category 3";
    String str7 = "Category 4";
    String str8 = "Category 5";
    DefaultCategoryDataset defaultCategoryDataset = new DefaultCategoryDataset();
    defaultCategoryDataset.addValue(1.0D, str1, str4);
    defaultCategoryDataset.addValue(4.0D, str1, str5);
    defaultCategoryDataset.addValue(3.0D, str1, str6);
    defaultCategoryDataset.addValue(5.0D, str1, str7);
    defaultCategoryDataset.addValue(5.0D, str1, str8);
    defaultCategoryDataset.addValue(5.0D, str2, str4);
    defaultCategoryDataset.addValue(7.0D, str2, str5);
    defaultCategoryDataset.addValue(6.0D, str2, str6);
    defaultCategoryDataset.addValue(8.0D, str2, str7);
    defaultCategoryDataset.addValue(4.0D, str2, str8);
    defaultCategoryDataset.addValue(4.0D, str3, str4);
    defaultCategoryDataset.addValue(3.0D, str3, str5);
    defaultCategoryDataset.addValue(2.0D, str3, str6);
    defaultCategoryDataset.addValue(3.0D, str3, str7);
    defaultCategoryDataset.addValue(6.0D, str3, str8);
    return (CategoryDataset)defaultCategoryDataset;
  }
  
  private static JFreeChart createChart(CategoryDataset paramCategoryDataset) {
    JFreeChart jFreeChart = ChartFactory.createBarChart("Mouseover Demo 1", "Category", "Value", paramCategoryDataset, PlotOrientation.VERTICAL, true, true, false);
    CategoryPlot categoryPlot = (CategoryPlot)jFreeChart.getPlot();
    categoryPlot.setDomainGridlinesVisible(true);
    NumberAxis numberAxis = (NumberAxis)categoryPlot.getRangeAxis();
    numberAxis.setStandardTickUnits(NumberAxis.createIntegerTickUnits());
    MyBarRenderer myBarRenderer = new MyBarRenderer();
    myBarRenderer.setDrawBarOutline(true);
    categoryPlot.setRenderer((CategoryItemRenderer)myBarRenderer);
    ChartUtilities.applyCurrentTheme(jFreeChart);
    GradientPaint gradientPaint1 = new GradientPaint(0.0F, 0.0F, Color.blue, 0.0F, 0.0F, new Color(0, 0, 64));
    GradientPaint gradientPaint2 = new GradientPaint(0.0F, 0.0F, Color.green, 0.0F, 0.0F, new Color(0, 64, 0));
    GradientPaint gradientPaint3 = new GradientPaint(0.0F, 0.0F, Color.red, 0.0F, 0.0F, new Color(64, 0, 0));
    myBarRenderer.setSeriesPaint(0, gradientPaint1);
    myBarRenderer.setSeriesPaint(1, gradientPaint2);
    myBarRenderer.setSeriesPaint(2, gradientPaint3);
    return jFreeChart;
  }
  
  public static JPanel createDemoPanel() {
    JFreeChart jFreeChart = createChart(createDataset());
    CategoryPlot categoryPlot = (CategoryPlot)jFreeChart.getPlot();
    MyBarRenderer myBarRenderer = (MyBarRenderer)categoryPlot.getRenderer();
    MyDemoPanel myDemoPanel = new MyDemoPanel(myBarRenderer);
    ChartPanel chartPanel = new ChartPanel(jFreeChart);
    myDemoPanel.addChart(jFreeChart);
    chartPanel.addChartMouseListener(myDemoPanel);
    myDemoPanel.add((Component)chartPanel);
    return myDemoPanel;
  }
  
  public static void main(String[] paramArrayOfString) {
    MouseOverDemo1 mouseOverDemo1 = new MouseOverDemo1("JFreeChart: MouseoverDemo1.java");
    mouseOverDemo1.pack();
    RefineryUtilities.centerFrameOnScreen((Window)mouseOverDemo1);
    mouseOverDemo1.setVisible(true);
  }
  
  static class MyDemoPanel extends DemoPanel implements ChartMouseListener {
    private MouseOverDemo1.MyBarRenderer renderer;
    
    public MyDemoPanel(MouseOverDemo1.MyBarRenderer param1MyBarRenderer) {
      super(new BorderLayout());
      this.renderer = param1MyBarRenderer;
    }
    
    public void chartMouseMoved(ChartMouseEvent param1ChartMouseEvent) {
      ChartEntity chartEntity = param1ChartMouseEvent.getEntity();
      if (!(chartEntity instanceof CategoryItemEntity)) {
        this.renderer.setHighlightedItem(-1, -1);
        return;
      } 
      CategoryItemEntity categoryItemEntity = (CategoryItemEntity)chartEntity;
      CategoryDataset categoryDataset = categoryItemEntity.getDataset();
      this.renderer.setHighlightedItem(categoryDataset.getRowIndex(categoryItemEntity.getRowKey()), categoryDataset.getColumnIndex(categoryItemEntity.getColumnKey()));
    }
    
    public void chartMouseClicked(ChartMouseEvent param1ChartMouseEvent) {}
  }
  
  static class MyBarRenderer extends BarRenderer {
    private int highlightRow = -1;
    
    private int highlightColumn = -1;
    
    public void setHighlightedItem(int param1Int1, int param1Int2) {
      if (this.highlightRow == param1Int1 && this.highlightColumn == param1Int2)
        return; 
      this.highlightRow = param1Int1;
      this.highlightColumn = param1Int2;
      notifyListeners(new RendererChangeEvent(this));
    }
    
    public Paint getItemOutlinePaint(int param1Int1, int param1Int2) {
      return (param1Int1 == this.highlightRow && param1Int2 == this.highlightColumn) ? Color.yellow : super.getItemOutlinePaint(param1Int1, param1Int2);
    }
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/MouseOverDemo1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */