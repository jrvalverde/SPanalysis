package demo;

import com.orsonpdf.PDFDocument;
import com.orsonpdf.PDFGraphics2D;
import com.orsonpdf.Page;
import java.awt.Graphics2D;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.Transferable;
import java.awt.datatransfer.UnsupportedFlavorException;
import java.awt.geom.Rectangle2D;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import org.jfree.chart.JFreeChart;

public class PDFChartTransferable implements Transferable {
  final DataFlavor pdfFlavor = new DataFlavor("application/pdf", "PDF");
  
  private JFreeChart chart;
  
  private int width;
  
  private int height;
  
  public PDFChartTransferable(JFreeChart paramJFreeChart, int paramInt1, int paramInt2) {
    this(paramJFreeChart, paramInt1, paramInt2, true);
  }
  
  public PDFChartTransferable(JFreeChart paramJFreeChart, int paramInt1, int paramInt2, boolean paramBoolean) {
    try {
      this.chart = (JFreeChart)paramJFreeChart.clone();
    } catch (CloneNotSupportedException cloneNotSupportedException) {
      this.chart = paramJFreeChart;
    } 
    this.width = paramInt1;
    this.height = paramInt2;
  }
  
  public DataFlavor[] getTransferDataFlavors() {
    return new DataFlavor[] { this.pdfFlavor };
  }
  
  public boolean isDataFlavorSupported(DataFlavor paramDataFlavor) {
    return this.pdfFlavor.equals(paramDataFlavor);
  }
  
  public Object getTransferData(DataFlavor paramDataFlavor) throws UnsupportedFlavorException, IOException {
    if (this.pdfFlavor.equals(paramDataFlavor)) {
      PDFDocument pDFDocument = new PDFDocument();
      Rectangle2D.Double double_ = new Rectangle2D.Double(0.0D, 0.0D, this.width, this.height);
      Page page = pDFDocument.createPage(double_);
      PDFGraphics2D pDFGraphics2D = page.getGraphics2D();
      this.chart.draw((Graphics2D)pDFGraphics2D, double_);
      return new ByteArrayInputStream(pDFDocument.getPDFBytes());
    } 
    throw new UnsupportedFlavorException(paramDataFlavor);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/PDFChartTransferable.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */