package demo;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Window;
import javax.swing.JPanel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.plot.PolarPlot;
import org.jfree.data.xy.XYDataset;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

public class PolarChartDemo1 extends ApplicationFrame {
  public PolarChartDemo1(String paramString) {
    super(paramString);
    JPanel jPanel = createDemoPanel();
    jPanel.setPreferredSize(new Dimension(500, 270));
    setContentPane(jPanel);
  }
  
  private static XYDataset createDataset() {
    XYSeriesCollection xYSeriesCollection = new XYSeriesCollection();
    XYSeries xYSeries1 = new XYSeries("Series 1");
    xYSeries1.add(0.0D, 2.0D);
    xYSeries1.add(90.0D, 13.0D);
    xYSeries1.add(180.0D, 9.0D);
    xYSeries1.add(270.0D, 8.0D);
    xYSeriesCollection.addSeries(xYSeries1);
    XYSeries xYSeries2 = new XYSeries("Series 2");
    xYSeries2.add(90.0D, -11.2D);
    xYSeries2.add(180.0D, 21.4D);
    xYSeries2.add(250.0D, 17.3D);
    xYSeries2.add(355.0D, 10.9D);
    xYSeriesCollection.addSeries(xYSeries2);
    return (XYDataset)xYSeriesCollection;
  }
  
  private static JFreeChart createChart(XYDataset paramXYDataset) {
    JFreeChart jFreeChart = ChartFactory.createPolarChart("Polar Chart Demo 1", paramXYDataset, true, false, false);
    PolarPlot polarPlot = (PolarPlot)jFreeChart.getPlot();
    polarPlot.addCornerTextItem("Corner Item 1");
    polarPlot.addCornerTextItem("Corner Item 2");
    polarPlot.setAngleGridlinePaint(Color.white);
    polarPlot.setRadiusGridlinePaint(Color.white);
    NumberAxis numberAxis = (NumberAxis)polarPlot.getAxis();
    numberAxis.setStandardTickUnits(NumberAxis.createIntegerTickUnits());
    ChartUtilities.applyCurrentTheme(jFreeChart);
    return jFreeChart;
  }
  
  public static JPanel createDemoPanel() {
    JFreeChart jFreeChart = createChart(createDataset());
    ChartPanel chartPanel = new ChartPanel(jFreeChart);
    chartPanel.setMouseZoomable(false);
    return (JPanel)chartPanel;
  }
  
  public static void main(String[] paramArrayOfString) {
    PolarChartDemo1 polarChartDemo1 = new PolarChartDemo1("JFreeChart: PolarChartDemo1.java");
    polarChartDemo1.pack();
    RefineryUtilities.centerFrameOnScreen((Window)polarChartDemo1);
    polarChartDemo1.setVisible(true);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/PolarChartDemo1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */