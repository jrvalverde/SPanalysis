package demo;

import java.awt.Dimension;
import java.awt.Window;
import javax.swing.JPanel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.LegendItemSource;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.CategoryLabelPositions;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.block.Arrangement;
import org.jfree.chart.block.Block;
import org.jfree.chart.block.BlockBorder;
import org.jfree.chart.block.BlockContainer;
import org.jfree.chart.block.BlockFrame;
import org.jfree.chart.block.BorderArrangement;
import org.jfree.chart.block.EmptyBlock;
import org.jfree.chart.labels.CategoryToolTipGenerator;
import org.jfree.chart.labels.StandardCategoryToolTipGenerator;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.DatasetRenderingOrder;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.renderer.category.CategoryItemRenderer;
import org.jfree.chart.renderer.category.LineAndShapeRenderer;
import org.jfree.chart.title.CompositeTitle;
import org.jfree.chart.title.LegendTitle;
import org.jfree.chart.title.Title;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RectangleEdge;
import org.jfree.ui.RectangleInsets;
import org.jfree.ui.RefineryUtilities;

public class DualAxisDemo1 extends ApplicationFrame {
  public DualAxisDemo1(String paramString) {
    super(paramString);
    JPanel jPanel = createDemoPanel();
    jPanel.setPreferredSize(new Dimension(500, 270));
    setContentPane(jPanel);
  }
  
  private static CategoryDataset createDataset1() {
    String str1 = "S1";
    String str2 = "S2";
    String str3 = "S3";
    String str4 = "Category 1";
    String str5 = "Category 2";
    String str6 = "Category 3";
    String str7 = "Category 4";
    String str8 = "Category 5";
    String str9 = "Category 6";
    String str10 = "Category 7";
    String str11 = "Category 8";
    DefaultCategoryDataset defaultCategoryDataset = new DefaultCategoryDataset();
    defaultCategoryDataset.addValue(1.0D, str1, str4);
    defaultCategoryDataset.addValue(4.0D, str1, str5);
    defaultCategoryDataset.addValue(3.0D, str1, str6);
    defaultCategoryDataset.addValue(5.0D, str1, str7);
    defaultCategoryDataset.addValue(5.0D, str1, str8);
    defaultCategoryDataset.addValue(7.0D, str1, str9);
    defaultCategoryDataset.addValue(7.0D, str1, str10);
    defaultCategoryDataset.addValue(8.0D, str1, str11);
    defaultCategoryDataset.addValue(5.0D, str2, str4);
    defaultCategoryDataset.addValue(7.0D, str2, str5);
    defaultCategoryDataset.addValue(6.0D, str2, str6);
    defaultCategoryDataset.addValue(8.0D, str2, str7);
    defaultCategoryDataset.addValue(4.0D, str2, str8);
    defaultCategoryDataset.addValue(4.0D, str2, str9);
    defaultCategoryDataset.addValue(2.0D, str2, str10);
    defaultCategoryDataset.addValue(1.0D, str2, str11);
    defaultCategoryDataset.addValue(4.0D, str3, str4);
    defaultCategoryDataset.addValue(3.0D, str3, str5);
    defaultCategoryDataset.addValue(2.0D, str3, str6);
    defaultCategoryDataset.addValue(3.0D, str3, str7);
    defaultCategoryDataset.addValue(6.0D, str3, str8);
    defaultCategoryDataset.addValue(3.0D, str3, str9);
    defaultCategoryDataset.addValue(4.0D, str3, str10);
    defaultCategoryDataset.addValue(3.0D, str3, str11);
    return (CategoryDataset)defaultCategoryDataset;
  }
  
  private static CategoryDataset createDataset2() {
    String str1 = "S4";
    String str2 = "Category 1";
    String str3 = "Category 2";
    String str4 = "Category 3";
    String str5 = "Category 4";
    String str6 = "Category 5";
    String str7 = "Category 6";
    String str8 = "Category 7";
    String str9 = "Category 8";
    DefaultCategoryDataset defaultCategoryDataset = new DefaultCategoryDataset();
    defaultCategoryDataset.addValue(15.0D, str1, str2);
    defaultCategoryDataset.addValue(24.0D, str1, str3);
    defaultCategoryDataset.addValue(31.0D, str1, str4);
    defaultCategoryDataset.addValue(25.0D, str1, str5);
    defaultCategoryDataset.addValue(56.0D, str1, str6);
    defaultCategoryDataset.addValue(37.0D, str1, str7);
    defaultCategoryDataset.addValue(77.0D, str1, str8);
    defaultCategoryDataset.addValue(18.0D, str1, str9);
    return (CategoryDataset)defaultCategoryDataset;
  }
  
  private static JFreeChart createChart() {
    JFreeChart jFreeChart = ChartFactory.createBarChart("DualAxisDemo1", "Category", "Value", createDataset1(), PlotOrientation.VERTICAL, false, true, false);
    CategoryPlot categoryPlot = (CategoryPlot)jFreeChart.getPlot();
    CategoryDataset categoryDataset = createDataset2();
    categoryPlot.setDataset(1, categoryDataset);
    categoryPlot.mapDatasetToRangeAxis(1, 1);
    CategoryAxis categoryAxis = categoryPlot.getDomainAxis();
    categoryAxis.setCategoryLabelPositions(CategoryLabelPositions.DOWN_45);
    NumberAxis numberAxis = new NumberAxis("Secondary");
    categoryPlot.setRangeAxis(1, (ValueAxis)numberAxis);
    LineAndShapeRenderer lineAndShapeRenderer = new LineAndShapeRenderer();
    lineAndShapeRenderer.setBaseToolTipGenerator((CategoryToolTipGenerator)new StandardCategoryToolTipGenerator());
    categoryPlot.setRenderer(1, (CategoryItemRenderer)lineAndShapeRenderer);
    categoryPlot.setDatasetRenderingOrder(DatasetRenderingOrder.FORWARD);
    LegendTitle legendTitle1 = new LegendTitle((LegendItemSource)categoryPlot.getRenderer(0));
    legendTitle1.setMargin(new RectangleInsets(2.0D, 2.0D, 2.0D, 2.0D));
    legendTitle1.setFrame((BlockFrame)new BlockBorder());
    LegendTitle legendTitle2 = new LegendTitle((LegendItemSource)categoryPlot.getRenderer(1));
    legendTitle2.setMargin(new RectangleInsets(2.0D, 2.0D, 2.0D, 2.0D));
    legendTitle2.setFrame((BlockFrame)new BlockBorder());
    BlockContainer blockContainer = new BlockContainer((Arrangement)new BorderArrangement());
    blockContainer.add((Block)legendTitle1, RectangleEdge.LEFT);
    blockContainer.add((Block)legendTitle2, RectangleEdge.RIGHT);
    blockContainer.add((Block)new EmptyBlock(2000.0D, 0.0D));
    CompositeTitle compositeTitle = new CompositeTitle(blockContainer);
    compositeTitle.setPosition(RectangleEdge.BOTTOM);
    jFreeChart.addSubtitle((Title)compositeTitle);
    ChartUtilities.applyCurrentTheme(jFreeChart);
    return jFreeChart;
  }
  
  public static JPanel createDemoPanel() {
    JFreeChart jFreeChart = createChart();
    return (JPanel)new ChartPanel(jFreeChart);
  }
  
  public static void main(String[] paramArrayOfString) {
    DualAxisDemo1 dualAxisDemo1 = new DualAxisDemo1("JFreeChart: DualAxisDemo1.java");
    dualAxisDemo1.pack();
    RefineryUtilities.centerFrameOnScreen((Window)dualAxisDemo1);
    dualAxisDemo1.setVisible(true);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/DualAxisDemo1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */