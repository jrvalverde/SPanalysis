package demo;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Window;
import javax.swing.JPanel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.AxisLocation;
import org.jfree.chart.axis.NumberAxis3D;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.DatasetRenderingOrder;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.renderer.category.CategoryItemRenderer;
import org.jfree.chart.renderer.category.LineRenderer3D;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

public class DualAxisDemo4 extends ApplicationFrame {
  public DualAxisDemo4(String paramString) {
    super(paramString);
    JPanel jPanel = createDemoPanel();
    jPanel.setPreferredSize(new Dimension(500, 270));
    setContentPane(jPanel);
  }
  
  private static JFreeChart createChart() {
    CategoryDataset categoryDataset1 = createDataset1();
    JFreeChart jFreeChart = ChartFactory.createBarChart3D("Dual Axis Chart", "Category", "Value", categoryDataset1, PlotOrientation.VERTICAL, true, true, false);
    CategoryPlot categoryPlot = (CategoryPlot)jFreeChart.getPlot();
    categoryPlot.setDomainAxisLocation(AxisLocation.BOTTOM_OR_LEFT);
    categoryPlot.setRangeAxisLocation(AxisLocation.TOP_OR_LEFT);
    CategoryItemRenderer categoryItemRenderer = categoryPlot.getRenderer();
    categoryItemRenderer.setSeriesPaint(0, Color.red);
    categoryItemRenderer.setSeriesPaint(1, Color.yellow);
    categoryItemRenderer.setSeriesPaint(2, Color.green);
    CategoryDataset categoryDataset2 = createDataset2();
    NumberAxis3D numberAxis3D = new NumberAxis3D("Secondary");
    categoryPlot.setRangeAxis(1, (ValueAxis)numberAxis3D);
    categoryPlot.setDataset(1, categoryDataset2);
    categoryPlot.mapDatasetToRangeAxis(1, 1);
    LineRenderer3D lineRenderer3D = new LineRenderer3D();
    lineRenderer3D.setSeriesPaint(0, Color.blue);
    categoryPlot.setRenderer(1, (CategoryItemRenderer)lineRenderer3D);
    categoryPlot.setDatasetRenderingOrder(DatasetRenderingOrder.FORWARD);
    ChartUtilities.applyCurrentTheme(jFreeChart);
    return jFreeChart;
  }
  
  private static CategoryDataset createDataset1() {
    String str1 = "First";
    String str2 = "Second";
    String str3 = "Third";
    String str4 = "Category 1";
    String str5 = "Category 2";
    String str6 = "Category 3";
    String str7 = "Category 4";
    String str8 = "Category 5";
    DefaultCategoryDataset defaultCategoryDataset = new DefaultCategoryDataset();
    defaultCategoryDataset.addValue(1.0D, str1, str4);
    defaultCategoryDataset.addValue(4.0D, str1, str5);
    defaultCategoryDataset.addValue(3.0D, str1, str6);
    defaultCategoryDataset.addValue(5.0D, str1, str7);
    defaultCategoryDataset.addValue(5.0D, str1, str8);
    defaultCategoryDataset.addValue(5.0D, str2, str4);
    defaultCategoryDataset.addValue(7.0D, str2, str5);
    defaultCategoryDataset.addValue(6.0D, str2, str6);
    defaultCategoryDataset.addValue(8.0D, str2, str7);
    defaultCategoryDataset.addValue(4.0D, str2, str8);
    defaultCategoryDataset.addValue(4.0D, str3, str4);
    defaultCategoryDataset.addValue(3.0D, str3, str5);
    defaultCategoryDataset.addValue(2.0D, str3, str6);
    defaultCategoryDataset.addValue(3.0D, str3, str7);
    defaultCategoryDataset.addValue(6.0D, str3, str8);
    return (CategoryDataset)defaultCategoryDataset;
  }
  
  private static CategoryDataset createDataset2() {
    String str1 = "Fourth";
    String str2 = "Category 1";
    String str3 = "Category 2";
    String str4 = "Category 3";
    String str5 = "Category 4";
    String str6 = "Category 5";
    DefaultCategoryDataset defaultCategoryDataset = new DefaultCategoryDataset();
    defaultCategoryDataset.addValue(15.0D, str1, str2);
    defaultCategoryDataset.addValue(24.0D, str1, str3);
    defaultCategoryDataset.addValue(31.0D, str1, str4);
    defaultCategoryDataset.addValue(25.0D, str1, str5);
    defaultCategoryDataset.addValue(56.0D, str1, str6);
    return (CategoryDataset)defaultCategoryDataset;
  }
  
  public static JPanel createDemoPanel() {
    JFreeChart jFreeChart = createChart();
    return (JPanel)new ChartPanel(jFreeChart);
  }
  
  public static void main(String[] paramArrayOfString) {
    DualAxisDemo4 dualAxisDemo4 = new DualAxisDemo4("JFreeChart: DualAxisDemo4.java");
    dualAxisDemo4.pack();
    RefineryUtilities.centerFrameOnScreen((Window)dualAxisDemo4);
    dualAxisDemo4.setVisible(true);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/DualAxisDemo4.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */