package demo;

import java.awt.Dimension;
import java.awt.Window;
import javax.swing.JPanel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.DateAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.renderer.category.StackedBarRenderer;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

public class StackedBarChartDemo6 extends ApplicationFrame {
  public StackedBarChartDemo6(String paramString) {
    super(paramString);
    JPanel jPanel = createDemoPanel();
    jPanel.setPreferredSize(new Dimension(500, 270));
    setContentPane(jPanel);
  }
  
  private static CategoryDataset createDataset() {
    DefaultCategoryDataset defaultCategoryDataset = new DefaultCategoryDataset();
    long l = 86400000L;
    defaultCategoryDataset.addValue((3L * l), "Series 1", "Category 1");
    defaultCategoryDataset.addValue((1L * l), "Series 2", "Category 1");
    defaultCategoryDataset.addValue((2L * l), "Series 3", "Category 1");
    defaultCategoryDataset.addValue((4L * l), "Series 1", "Category 2");
    defaultCategoryDataset.addValue((5L * l), "Series 2", "Category 2");
    defaultCategoryDataset.addValue((1L * l), "Series 3", "Category 2");
    return (CategoryDataset)defaultCategoryDataset;
  }
  
  private static JFreeChart createChart(CategoryDataset paramCategoryDataset) {
    JFreeChart jFreeChart = ChartFactory.createStackedBarChart("Stacked Bar Chart Demo 6", "Category", "Value", paramCategoryDataset, PlotOrientation.HORIZONTAL, true, true, false);
    CategoryPlot categoryPlot = (CategoryPlot)jFreeChart.getPlot();
    StackedBarRenderer stackedBarRenderer = (StackedBarRenderer)categoryPlot.getRenderer();
    stackedBarRenderer.setDrawBarOutline(false);
    long l = System.currentTimeMillis();
    stackedBarRenderer.setBase(l);
    DateAxis dateAxis = new DateAxis("Date");
    dateAxis.setLowerMargin(0.0D);
    categoryPlot.setRangeAxis((ValueAxis)dateAxis);
    ChartUtilities.applyCurrentTheme(jFreeChart);
    return jFreeChart;
  }
  
  public static JPanel createDemoPanel() {
    JFreeChart jFreeChart = createChart(createDataset());
    return (JPanel)new ChartPanel(jFreeChart);
  }
  
  public static void main(String[] paramArrayOfString) {
    StackedBarChartDemo6 stackedBarChartDemo6 = new StackedBarChartDemo6("Stacked Bar Chart Demo 6");
    stackedBarChartDemo6.pack();
    RefineryUtilities.centerFrameOnScreen((Window)stackedBarChartDemo6);
    stackedBarChartDemo6.setVisible(true);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/StackedBarChartDemo6.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */