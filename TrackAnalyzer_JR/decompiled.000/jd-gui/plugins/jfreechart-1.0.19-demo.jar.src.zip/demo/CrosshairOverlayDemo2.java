package demo;

import java.awt.BasicStroke;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.geom.Rectangle2D;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartMouseEvent;
import org.jfree.chart.ChartMouseListener;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.panel.CrosshairOverlay;
import org.jfree.chart.panel.Overlay;
import org.jfree.chart.plot.Crosshair;
import org.jfree.chart.plot.XYPlot;
import org.jfree.data.general.DatasetUtilities;
import org.jfree.data.xy.XYDataset;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;
import org.jfree.ui.RectangleAnchor;
import org.jfree.ui.RectangleEdge;

public class CrosshairOverlayDemo2 extends JFrame {
  public CrosshairOverlayDemo2(String paramString) {
    super(paramString);
    setContentPane(createDemoPanel());
  }
  
  public static JPanel createDemoPanel() {
    return new MyDemoPanel();
  }
  
  public static void main(String[] paramArrayOfString) {
    SwingUtilities.invokeLater(new Runnable() {
          public void run() {
            CrosshairOverlayDemo2 crosshairOverlayDemo2 = new CrosshairOverlayDemo2("JFreeChart: CrosshairOverlayDemo2.java");
            crosshairOverlayDemo2.pack();
            crosshairOverlayDemo2.setVisible(true);
          }
        });
  }
  
  static class MyDemoPanel extends JPanel implements ChartMouseListener {
    private static final int SERIES_COUNT = 4;
    
    private ChartPanel chartPanel;
    
    private Crosshair xCrosshair;
    
    private Crosshair[] yCrosshairs;
    
    public MyDemoPanel() {
      super(new BorderLayout());
      JFreeChart jFreeChart = createChart(createDataset());
      this.chartPanel = new ChartPanel(jFreeChart);
      this.chartPanel.addChartMouseListener(this);
      CrosshairOverlay crosshairOverlay = new CrosshairOverlay();
      this.xCrosshair = new Crosshair(Double.NaN, Color.GRAY, new BasicStroke(0.0F));
      this.xCrosshair.setLabelVisible(true);
      crosshairOverlay.addDomainCrosshair(this.xCrosshair);
      this.yCrosshairs = new Crosshair[4];
      for (byte b = 0; b < 4; b++) {
        this.yCrosshairs[b] = new Crosshair(Double.NaN, Color.GRAY, new BasicStroke(0.0F));
        this.yCrosshairs[b].setLabelVisible(true);
        if (b % 2 != 0)
          this.yCrosshairs[b].setLabelAnchor(RectangleAnchor.TOP_RIGHT); 
        crosshairOverlay.addRangeCrosshair(this.yCrosshairs[b]);
      } 
      this.chartPanel.addOverlay((Overlay)crosshairOverlay);
      add((Component)this.chartPanel);
    }
    
    private JFreeChart createChart(XYDataset param1XYDataset) {
      return ChartFactory.createXYLineChart("CrosshairOverlayDemo2", "X", "Y", param1XYDataset);
    }
    
    private XYDataset createDataset() {
      XYSeriesCollection xYSeriesCollection = new XYSeriesCollection();
      for (byte b = 0; b < 4; b++) {
        XYSeries xYSeries = new XYSeries("S" + b);
        for (byte b1 = 0; b1 < 10; b1++)
          xYSeries.add(b1, b1 + Math.random() * 4.0D); 
        xYSeriesCollection.addSeries(xYSeries);
      } 
      return (XYDataset)xYSeriesCollection;
    }
    
    public void chartMouseClicked(ChartMouseEvent param1ChartMouseEvent) {}
    
    public void chartMouseMoved(ChartMouseEvent param1ChartMouseEvent) {
      Rectangle2D rectangle2D = this.chartPanel.getScreenDataArea();
      JFreeChart jFreeChart = param1ChartMouseEvent.getChart();
      XYPlot xYPlot = (XYPlot)jFreeChart.getPlot();
      ValueAxis valueAxis = xYPlot.getDomainAxis();
      double d = valueAxis.java2DToValue(param1ChartMouseEvent.getTrigger().getX(), rectangle2D, RectangleEdge.BOTTOM);
      this.xCrosshair.setValue(d);
      for (byte b = 0; b < 4; b++) {
        double d1 = DatasetUtilities.findYValue(xYPlot.getDataset(), b, d);
        this.yCrosshairs[b].setValue(d1);
      } 
    }
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/CrosshairOverlayDemo2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */