package demo;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Window;
import java.awt.geom.Ellipse2D;
import java.net.URL;
import javax.swing.ImageIcon;
import javax.swing.JPanel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.renderer.category.LineAndShapeRenderer;
import org.jfree.chart.title.TextTitle;
import org.jfree.chart.title.Title;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.HorizontalAlignment;
import org.jfree.ui.RectangleEdge;
import org.jfree.ui.RefineryUtilities;

public class LineChartDemo1 extends ApplicationFrame {
  public LineChartDemo1(String paramString) {
    super(paramString);
    JPanel jPanel = createDemoPanel();
    jPanel.setPreferredSize(new Dimension(500, 270));
    setContentPane(jPanel);
  }
  
  private static CategoryDataset createDataset() {
    DefaultCategoryDataset defaultCategoryDataset = new DefaultCategoryDataset();
    defaultCategoryDataset.addValue(212.0D, "Classes", "JDK 1.0");
    defaultCategoryDataset.addValue(504.0D, "Classes", "JDK 1.1");
    defaultCategoryDataset.addValue(1520.0D, "Classes", "JDK 1.2");
    defaultCategoryDataset.addValue(1842.0D, "Classes", "JDK 1.3");
    defaultCategoryDataset.addValue(2991.0D, "Classes", "JDK 1.4");
    defaultCategoryDataset.addValue(3500.0D, "Classes", "JDK 1.5");
    return (CategoryDataset)defaultCategoryDataset;
  }
  
  private static JFreeChart createChart(CategoryDataset paramCategoryDataset) {
    JFreeChart jFreeChart = ChartFactory.createLineChart("Java Standard Class Library", null, "Class Count", paramCategoryDataset, PlotOrientation.VERTICAL, false, true, false);
    jFreeChart.addSubtitle((Title)new TextTitle("Number of Classes By Release"));
    TextTitle textTitle = new TextTitle("Source: Java In A Nutshell (5th Edition) by David Flanagan (O'Reilly)");
    textTitle.setFont(new Font("SansSerif", 0, 10));
    textTitle.setPosition(RectangleEdge.BOTTOM);
    textTitle.setHorizontalAlignment(HorizontalAlignment.RIGHT);
    jFreeChart.addSubtitle((Title)textTitle);
    CategoryPlot categoryPlot = (CategoryPlot)jFreeChart.getPlot();
    categoryPlot.setRangePannable(true);
    categoryPlot.setRangeGridlinesVisible(false);
    URL uRL = LineChartDemo1.class.getClassLoader().getResource("OnBridge11small.png");
    if (uRL != null) {
      ImageIcon imageIcon = new ImageIcon(uRL);
      jFreeChart.setBackgroundImage(imageIcon.getImage());
      categoryPlot.setBackgroundPaint(null);
    } 
    NumberAxis numberAxis = (NumberAxis)categoryPlot.getRangeAxis();
    numberAxis.setStandardTickUnits(NumberAxis.createIntegerTickUnits());
    ChartUtilities.applyCurrentTheme(jFreeChart);
    LineAndShapeRenderer lineAndShapeRenderer = (LineAndShapeRenderer)categoryPlot.getRenderer();
    lineAndShapeRenderer.setBaseShapesVisible(true);
    lineAndShapeRenderer.setDrawOutlines(true);
    lineAndShapeRenderer.setUseFillPaint(true);
    lineAndShapeRenderer.setBaseFillPaint(Color.white);
    lineAndShapeRenderer.setSeriesStroke(0, new BasicStroke(3.0F));
    lineAndShapeRenderer.setSeriesOutlineStroke(0, new BasicStroke(2.0F));
    lineAndShapeRenderer.setSeriesShape(0, new Ellipse2D.Double(-5.0D, -5.0D, 10.0D, 10.0D));
    return jFreeChart;
  }
  
  public static JPanel createDemoPanel() {
    JFreeChart jFreeChart = createChart(createDataset());
    ChartPanel chartPanel = new ChartPanel(jFreeChart);
    chartPanel.setMouseWheelEnabled(true);
    return (JPanel)chartPanel;
  }
  
  public static void main(String[] paramArrayOfString) {
    LineChartDemo1 lineChartDemo1 = new LineChartDemo1("JFreeChart: LineChartDemo1.java");
    lineChartDemo1.pack();
    RefineryUtilities.centerFrameOnScreen((Window)lineChartDemo1);
    lineChartDemo1.setVisible(true);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/LineChartDemo1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */