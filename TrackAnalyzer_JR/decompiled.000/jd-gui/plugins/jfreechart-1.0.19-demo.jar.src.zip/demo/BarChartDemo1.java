package demo;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.GradientPaint;
import java.awt.Window;
import javax.swing.JPanel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.CategoryLabelPositions;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.labels.CategorySeriesLabelGenerator;
import org.jfree.chart.labels.StandardCategorySeriesLabelGenerator;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.renderer.category.BarRenderer;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

public class BarChartDemo1 extends ApplicationFrame {
  public BarChartDemo1(String paramString) {
    super(paramString);
    JPanel jPanel = createDemoPanel();
    jPanel.setPreferredSize(new Dimension(500, 270));
    setContentPane(jPanel);
  }
  
  private static CategoryDataset createDataset() {
    String str1 = "First";
    String str2 = "Second";
    String str3 = "Third";
    String str4 = "Category 1";
    String str5 = "Category 2";
    String str6 = "Category 3";
    String str7 = "Category 4";
    String str8 = "Category 5";
    DefaultCategoryDataset defaultCategoryDataset = new DefaultCategoryDataset();
    defaultCategoryDataset.addValue(1.0D, str1, str4);
    defaultCategoryDataset.addValue(4.0D, str1, str5);
    defaultCategoryDataset.addValue(3.0D, str1, str6);
    defaultCategoryDataset.addValue(5.0D, str1, str7);
    defaultCategoryDataset.addValue(5.0D, str1, str8);
    defaultCategoryDataset.addValue(5.0D, str2, str4);
    defaultCategoryDataset.addValue(7.0D, str2, str5);
    defaultCategoryDataset.addValue(6.0D, str2, str6);
    defaultCategoryDataset.addValue(8.0D, str2, str7);
    defaultCategoryDataset.addValue(4.0D, str2, str8);
    defaultCategoryDataset.addValue(4.0D, str3, str4);
    defaultCategoryDataset.addValue(3.0D, str3, str5);
    defaultCategoryDataset.addValue(2.0D, str3, str6);
    defaultCategoryDataset.addValue(3.0D, str3, str7);
    defaultCategoryDataset.addValue(6.0D, str3, str8);
    return (CategoryDataset)defaultCategoryDataset;
  }
  
  private static JFreeChart createChart(CategoryDataset paramCategoryDataset) {
    JFreeChart jFreeChart = ChartFactory.createBarChart("Bar Chart Demo 1", "Category", "Value", paramCategoryDataset);
    CategoryPlot categoryPlot = (CategoryPlot)jFreeChart.getPlot();
    categoryPlot.setDomainGridlinesVisible(true);
    categoryPlot.setRangeCrosshairVisible(true);
    categoryPlot.setRangeCrosshairPaint(Color.blue);
    NumberAxis numberAxis = (NumberAxis)categoryPlot.getRangeAxis();
    numberAxis.setStandardTickUnits(NumberAxis.createIntegerTickUnits());
    BarRenderer barRenderer = (BarRenderer)categoryPlot.getRenderer();
    barRenderer.setDrawBarOutline(false);
    GradientPaint gradientPaint1 = new GradientPaint(0.0F, 0.0F, Color.blue, 0.0F, 0.0F, new Color(0, 0, 64));
    GradientPaint gradientPaint2 = new GradientPaint(0.0F, 0.0F, Color.green, 0.0F, 0.0F, new Color(0, 64, 0));
    GradientPaint gradientPaint3 = new GradientPaint(0.0F, 0.0F, Color.red, 0.0F, 0.0F, new Color(64, 0, 0));
    barRenderer.setSeriesPaint(0, gradientPaint1);
    barRenderer.setSeriesPaint(1, gradientPaint2);
    barRenderer.setSeriesPaint(2, gradientPaint3);
    barRenderer.setLegendItemToolTipGenerator((CategorySeriesLabelGenerator)new StandardCategorySeriesLabelGenerator("Tooltip: {0}"));
    CategoryAxis categoryAxis = categoryPlot.getDomainAxis();
    categoryAxis.setCategoryLabelPositions(CategoryLabelPositions.createUpRotationLabelPositions(0.5235987755982988D));
    return jFreeChart;
  }
  
  public static JPanel createDemoPanel() {
    JFreeChart jFreeChart = createChart(createDataset());
    return (JPanel)new ChartPanel(jFreeChart);
  }
  
  public static void main(String[] paramArrayOfString) {
    BarChartDemo1 barChartDemo1 = new BarChartDemo1("JFreeChart: BarChartDemo1.java");
    barChartDemo1.pack();
    RefineryUtilities.centerFrameOnScreen((Window)barChartDemo1);
    barChartDemo1.setVisible(true);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/BarChartDemo1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */