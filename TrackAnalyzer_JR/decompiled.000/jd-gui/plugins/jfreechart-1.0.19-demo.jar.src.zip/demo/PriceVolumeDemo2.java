package demo;

import java.awt.Container;
import java.awt.Dimension;
import java.awt.Window;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import javax.swing.JPanel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.DateAxis;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.labels.StandardXYToolTipGenerator;
import org.jfree.chart.labels.XYToolTipGenerator;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.StandardXYBarPainter;
import org.jfree.chart.renderer.xy.XYBarPainter;
import org.jfree.chart.renderer.xy.XYBarRenderer;
import org.jfree.chart.renderer.xy.XYItemRenderer;
import org.jfree.data.time.Day;
import org.jfree.data.time.RegularTimePeriod;
import org.jfree.data.time.TimeSeries;
import org.jfree.data.time.TimeSeriesCollection;
import org.jfree.data.time.ohlc.OHLCSeries;
import org.jfree.data.time.ohlc.OHLCSeriesCollection;
import org.jfree.data.xy.IntervalXYDataset;
import org.jfree.data.xy.OHLCDataset;
import org.jfree.data.xy.XYDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

public class PriceVolumeDemo2 extends ApplicationFrame {
  public PriceVolumeDemo2(String paramString) {
    super(paramString);
    JFreeChart jFreeChart = createChart();
    ChartPanel chartPanel = new ChartPanel(jFreeChart, true, true, true, false, true);
    chartPanel.setPreferredSize(new Dimension(500, 270));
    setContentPane((Container)chartPanel);
  }
  
  private static JFreeChart createChart() {
    OHLCDataset oHLCDataset = createPriceDataset();
    String str = "Sun Microsystems (SUNW)";
    JFreeChart jFreeChart = ChartFactory.createHighLowChart(str, "Date", "Price", oHLCDataset, true);
    XYPlot xYPlot = (XYPlot)jFreeChart.getPlot();
    DateAxis dateAxis = (DateAxis)xYPlot.getDomainAxis();
    dateAxis.setLowerMargin(0.01D);
    dateAxis.setUpperMargin(0.01D);
    NumberAxis numberAxis1 = (NumberAxis)xYPlot.getRangeAxis();
    numberAxis1.setLowerMargin(0.6D);
    numberAxis1.setAutoRangeIncludesZero(false);
    XYItemRenderer xYItemRenderer = xYPlot.getRenderer();
    xYItemRenderer.setBaseToolTipGenerator((XYToolTipGenerator)new StandardXYToolTipGenerator("{0}: ({1}, {2})", new SimpleDateFormat("d-MMM-yyyy"), new DecimalFormat("0.00")));
    NumberAxis numberAxis2 = new NumberAxis("Volume");
    numberAxis2.setUpperMargin(1.0D);
    xYPlot.setRangeAxis(1, (ValueAxis)numberAxis2);
    xYPlot.setDataset(1, (XYDataset)createVolumeDataset());
    xYPlot.setRangeAxis(1, (ValueAxis)numberAxis2);
    xYPlot.mapDatasetToRangeAxis(1, 1);
    XYBarRenderer xYBarRenderer = new XYBarRenderer();
    xYBarRenderer.setDrawBarOutline(false);
    xYBarRenderer.setBaseToolTipGenerator((XYToolTipGenerator)new StandardXYToolTipGenerator("{0}: ({1}, {2})", new SimpleDateFormat("d-MMM-yyyy"), new DecimalFormat("0,000.00")));
    xYPlot.setRenderer(1, (XYItemRenderer)xYBarRenderer);
    ChartUtilities.applyCurrentTheme(jFreeChart);
    xYBarRenderer.setShadowVisible(false);
    xYBarRenderer.setBarPainter((XYBarPainter)new StandardXYBarPainter());
    return jFreeChart;
  }
  
  private static OHLCDataset createPriceDataset() {
    OHLCSeries oHLCSeries = new OHLCSeries("SUNW");
    oHLCSeries.add((RegularTimePeriod)new Day(12, 4, 2007), 5.9D, 5.96D, 5.87D, 5.9D);
    oHLCSeries.add((RegularTimePeriod)new Day(13, 4, 2007), 5.89D, 5.9D, 5.78D, 5.8D);
    oHLCSeries.add((RegularTimePeriod)new Day(16, 4, 2007), 5.81D, 5.87D, 5.79D, 5.86D);
    oHLCSeries.add((RegularTimePeriod)new Day(17, 4, 2007), 5.87D, 5.95D, 5.82D, 5.95D);
    oHLCSeries.add((RegularTimePeriod)new Day(18, 4, 2007), 5.89D, 5.95D, 5.87D, 5.94D);
    oHLCSeries.add((RegularTimePeriod)new Day(19, 4, 2007), 5.87D, 5.96D, 5.86D, 5.89D);
    oHLCSeries.add((RegularTimePeriod)new Day(20, 4, 2007), 5.94D, 5.95D, 5.87D, 5.93D);
    oHLCSeries.add((RegularTimePeriod)new Day(23, 4, 2007), 5.93D, 5.95D, 5.89D, 5.92D);
    oHLCSeries.add((RegularTimePeriod)new Day(24, 4, 2007), 5.93D, 5.97D, 5.88D, 5.94D);
    oHLCSeries.add((RegularTimePeriod)new Day(25, 4, 2007), 5.58D, 5.58D, 5.17D, 5.27D);
    oHLCSeries.add((RegularTimePeriod)new Day(26, 4, 2007), 5.25D, 5.3D, 5.2D, 5.25D);
    oHLCSeries.add((RegularTimePeriod)new Day(27, 4, 2007), 5.23D, 5.28D, 5.19D, 5.26D);
    oHLCSeries.add((RegularTimePeriod)new Day(30, 4, 2007), 5.25D, 5.26D, 5.2D, 5.22D);
    oHLCSeries.add((RegularTimePeriod)new Day(1, 5, 2007), 5.23D, 5.24D, 4.99D, 5.09D);
    oHLCSeries.add((RegularTimePeriod)new Day(2, 5, 2007), 5.09D, 5.17D, 5.08D, 5.15D);
    oHLCSeries.add((RegularTimePeriod)new Day(3, 5, 2007), 5.14D, 5.2D, 5.11D, 5.18D);
    oHLCSeries.add((RegularTimePeriod)new Day(4, 5, 2007), 5.21D, 5.3D, 5.2D, 5.24D);
    oHLCSeries.add((RegularTimePeriod)new Day(7, 5, 2007), 5.22D, 5.28D, 5.21D, 5.22D);
    oHLCSeries.add((RegularTimePeriod)new Day(8, 5, 2007), 5.24D, 5.27D, 5.21D, 5.22D);
    oHLCSeries.add((RegularTimePeriod)new Day(9, 5, 2007), 5.21D, 5.22D, 5.15D, 5.2D);
    oHLCSeries.add((RegularTimePeriod)new Day(10, 5, 2007), 5.16D, 5.19D, 5.13D, 5.13D);
    oHLCSeries.add((RegularTimePeriod)new Day(11, 5, 2007), 5.14D, 5.18D, 5.12D, 5.15D);
    oHLCSeries.add((RegularTimePeriod)new Day(14, 5, 2007), 5.16D, 5.29D, 5.16D, 5.22D);
    oHLCSeries.add((RegularTimePeriod)new Day(15, 5, 2007), 5.22D, 5.23D, 5.13D, 5.14D);
    oHLCSeries.add((RegularTimePeriod)new Day(16, 5, 2007), 5.14D, 5.16D, 5.07D, 5.12D);
    oHLCSeries.add((RegularTimePeriod)new Day(17, 5, 2007), 5.35D, 5.43D, 5.3D, 5.3D);
    oHLCSeries.add((RegularTimePeriod)new Day(18, 5, 2007), 5.35D, 5.35D, 5.26D, 5.29D);
    oHLCSeries.add((RegularTimePeriod)new Day(21, 5, 2007), 5.29D, 5.39D, 5.24D, 5.39D);
    oHLCSeries.add((RegularTimePeriod)new Day(22, 5, 2007), 5.39D, 5.42D, 5.34D, 5.38D);
    oHLCSeries.add((RegularTimePeriod)new Day(23, 5, 2007), 5.37D, 5.43D, 5.36D, 5.38D);
    oHLCSeries.add((RegularTimePeriod)new Day(24, 5, 2007), 5.36D, 5.37D, 5.15D, 5.15D);
    oHLCSeries.add((RegularTimePeriod)new Day(25, 5, 2007), 5.18D, 5.21D, 5.15D, 5.16D);
    oHLCSeries.add((RegularTimePeriod)new Day(29, 5, 2007), 5.16D, 5.17D, 5.0D, 5.06D);
    oHLCSeries.add((RegularTimePeriod)new Day(30, 5, 2007), 5.01D, 5.15D, 4.96D, 5.12D);
    oHLCSeries.add((RegularTimePeriod)new Day(31, 5, 2007), 5.16D, 5.19D, 5.07D, 5.1D);
    oHLCSeries.add((RegularTimePeriod)new Day(1, 6, 2007), 5.12D, 5.2D, 5.12D, 5.18D);
    oHLCSeries.add((RegularTimePeriod)new Day(4, 6, 2007), 5.15D, 5.24D, 5.07D, 5.11D);
    oHLCSeries.add((RegularTimePeriod)new Day(5, 6, 2007), 5.08D, 5.08D, 4.97D, 5.07D);
    oHLCSeries.add((RegularTimePeriod)new Day(6, 6, 2007), 5.03D, 5.05D, 4.99D, 5.02D);
    oHLCSeries.add((RegularTimePeriod)new Day(7, 6, 2007), 5.0D, 5.05D, 4.97D, 4.97D);
    oHLCSeries.add((RegularTimePeriod)new Day(8, 6, 2007), 4.98D, 5.04D, 4.95D, 5.04D);
    oHLCSeries.add((RegularTimePeriod)new Day(11, 6, 2007), 5.05D, 5.06D, 4.95D, 4.96D);
    oHLCSeries.add((RegularTimePeriod)new Day(12, 6, 2007), 4.95D, 5.01D, 4.92D, 4.92D);
    oHLCSeries.add((RegularTimePeriod)new Day(13, 6, 2007), 4.95D, 4.99D, 4.83D, 4.99D);
    oHLCSeries.add((RegularTimePeriod)new Day(14, 6, 2007), 5.05D, 5.1D, 5.02D, 5.08D);
    oHLCSeries.add((RegularTimePeriod)new Day(15, 6, 2007), 5.13D, 5.13D, 5.03D, 5.05D);
    oHLCSeries.add((RegularTimePeriod)new Day(18, 6, 2007), 5.06D, 5.07D, 5.01D, 5.05D);
    oHLCSeries.add((RegularTimePeriod)new Day(19, 6, 2007), 5.03D, 5.16D, 5.03D, 5.1D);
    oHLCSeries.add((RegularTimePeriod)new Day(20, 6, 2007), 5.14D, 5.15D, 5.05D, 5.05D);
    oHLCSeries.add((RegularTimePeriod)new Day(21, 6, 2007), 5.07D, 5.18D, 5.06D, 5.13D);
    oHLCSeries.add((RegularTimePeriod)new Day(22, 6, 2007), 5.11D, 5.14D, 5.08D, 5.08D);
    oHLCSeries.add((RegularTimePeriod)new Day(25, 6, 2007), 5.08D, 5.1D, 4.99D, 5.02D);
    oHLCSeries.add((RegularTimePeriod)new Day(26, 6, 2007), 5.04D, 5.1D, 4.99D, 5.01D);
    oHLCSeries.add((RegularTimePeriod)new Day(27, 6, 2007), 5.0D, 5.09D, 4.99D, 5.07D);
    oHLCSeries.add((RegularTimePeriod)new Day(28, 6, 2007), 5.08D, 5.19D, 5.07D, 5.16D);
    oHLCSeries.add((RegularTimePeriod)new Day(29, 6, 2007), 5.19D, 5.33D, 5.16D, 5.26D);
    oHLCSeries.add((RegularTimePeriod)new Day(2, 7, 2007), 5.13D, 5.33D, 5.12D, 5.19D);
    oHLCSeries.add((RegularTimePeriod)new Day(3, 7, 2007), 5.2D, 5.24D, 5.17D, 5.22D);
    oHLCSeries.add((RegularTimePeriod)new Day(5, 7, 2007), 5.28D, 5.35D, 5.24D, 5.33D);
    oHLCSeries.add((RegularTimePeriod)new Day(6, 7, 2007), 5.36D, 5.49D, 5.34D, 5.38D);
    oHLCSeries.add((RegularTimePeriod)new Day(9, 7, 2007), 5.4D, 5.44D, 5.31D, 5.33D);
    oHLCSeries.add((RegularTimePeriod)new Day(10, 7, 2007), 5.29D, 5.41D, 5.28D, 5.32D);
    oHLCSeries.add((RegularTimePeriod)new Day(11, 7, 2007), 5.29D, 5.38D, 5.29D, 5.38D);
    oHLCSeries.add((RegularTimePeriod)new Day(12, 7, 2007), 5.38D, 5.43D, 5.33D, 5.43D);
    oHLCSeries.add((RegularTimePeriod)new Day(13, 7, 2007), 5.42D, 5.43D, 5.34D, 5.37D);
    oHLCSeries.add((RegularTimePeriod)new Day(16, 7, 2007), 5.33D, 5.38D, 5.3D, 5.34D);
    OHLCSeriesCollection oHLCSeriesCollection = new OHLCSeriesCollection();
    oHLCSeriesCollection.addSeries(oHLCSeries);
    return (OHLCDataset)oHLCSeriesCollection;
  }
  
  private static IntervalXYDataset createVolumeDataset() {
    TimeSeries timeSeries = new TimeSeries("Volume");
    timeSeries.add((RegularTimePeriod)new Day(12, 4, 2007), 4.96468E7D);
    timeSeries.add((RegularTimePeriod)new Day(13, 4, 2007), 6.73193E7D);
    timeSeries.add((RegularTimePeriod)new Day(16, 4, 2007), 5.68402E7D);
    timeSeries.add((RegularTimePeriod)new Day(17, 4, 2007), 4.07523E7D);
    timeSeries.add((RegularTimePeriod)new Day(18, 4, 2007), 4.25338E7D);
    timeSeries.add((RegularTimePeriod)new Day(19, 4, 2007), 3.42321E7D);
    timeSeries.add((RegularTimePeriod)new Day(20, 4, 2007), 3.24376E7D);
    timeSeries.add((RegularTimePeriod)new Day(23, 4, 2007), 2.87559E7D);
    timeSeries.add((RegularTimePeriod)new Day(24, 4, 2007), 7.45033E7D);
    timeSeries.add((RegularTimePeriod)new Day(25, 4, 2007), 3.22214E8D);
    timeSeries.add((RegularTimePeriod)new Day(26, 4, 2007), 9.61417E7D);
    timeSeries.add((RegularTimePeriod)new Day(27, 4, 2007), 6.23262E7D);
    timeSeries.add((RegularTimePeriod)new Day(30, 4, 2007), 5.23344E7D);
    timeSeries.add((RegularTimePeriod)new Day(1, 5, 2007), 1.330961E8D);
    timeSeries.add((RegularTimePeriod)new Day(2, 5, 2007), 9.38745E7D);
    timeSeries.add((RegularTimePeriod)new Day(3, 5, 2007), 1.010114E8D);
    timeSeries.add((RegularTimePeriod)new Day(4, 5, 2007), 5.66297E7D);
    timeSeries.add((RegularTimePeriod)new Day(7, 5, 2007), 4.33022E7D);
    timeSeries.add((RegularTimePeriod)new Day(8, 5, 2007), 5.14565E7D);
    timeSeries.add((RegularTimePeriod)new Day(9, 5, 2007), 4.82309E7D);
    timeSeries.add((RegularTimePeriod)new Day(10, 5, 2007), 6.5536E7D);
    timeSeries.add((RegularTimePeriod)new Day(11, 5, 2007), 4.64697E7D);
    timeSeries.add((RegularTimePeriod)new Day(14, 5, 2007), 1.1858E8D);
    timeSeries.add((RegularTimePeriod)new Day(15, 5, 2007), 5.07741E7D);
    timeSeries.add((RegularTimePeriod)new Day(16, 5, 2007), 4.45902E7D);
    timeSeries.add((RegularTimePeriod)new Day(17, 5, 2007), 1.254825E8D);
    timeSeries.add((RegularTimePeriod)new Day(18, 5, 2007), 4.99875E7D);
    timeSeries.add((RegularTimePeriod)new Day(21, 5, 2007), 4.83874E7D);
    timeSeries.add((RegularTimePeriod)new Day(22, 5, 2007), 6.79926E7D);
    timeSeries.add((RegularTimePeriod)new Day(23, 5, 2007), 4.56292E7D);
    timeSeries.add((RegularTimePeriod)new Day(24, 5, 2007), 1.232886E8D);
    timeSeries.add((RegularTimePeriod)new Day(25, 5, 2007), 4.73453E7D);
    timeSeries.add((RegularTimePeriod)new Day(29, 5, 2007), 9.0454E7D);
    timeSeries.add((RegularTimePeriod)new Day(30, 5, 2007), 7.30492E7D);
    timeSeries.add((RegularTimePeriod)new Day(31, 5, 2007), 6.03954E7D);
    timeSeries.add((RegularTimePeriod)new Day(1, 6, 2007), 4.87923E7D);
    timeSeries.add((RegularTimePeriod)new Day(4, 6, 2007), 1.099728E8D);
    timeSeries.add((RegularTimePeriod)new Day(5, 6, 2007), 1.982012E8D);
    timeSeries.add((RegularTimePeriod)new Day(6, 6, 2007), 1.214157E8D);
    timeSeries.add((RegularTimePeriod)new Day(7, 6, 2007), 5.66374E7D);
    timeSeries.add((RegularTimePeriod)new Day(8, 6, 2007), 6.41166E7D);
    timeSeries.add((RegularTimePeriod)new Day(11, 6, 2007), 6.02748E7D);
    timeSeries.add((RegularTimePeriod)new Day(12, 6, 2007), 9.34513E7D);
    timeSeries.add((RegularTimePeriod)new Day(13, 6, 2007), 1.03309E8D);
    timeSeries.add((RegularTimePeriod)new Day(14, 6, 2007), 1.031354E8D);
    timeSeries.add((RegularTimePeriod)new Day(15, 6, 2007), 1.044159E8D);
    timeSeries.add((RegularTimePeriod)new Day(18, 6, 2007), 5.15069E7D);
    timeSeries.add((RegularTimePeriod)new Day(19, 6, 2007), 7.45921E7D);
    timeSeries.add((RegularTimePeriod)new Day(20, 6, 2007), 6.90276E7D);
    timeSeries.add((RegularTimePeriod)new Day(21, 6, 2007), 9.72125E7D);
    timeSeries.add((RegularTimePeriod)new Day(22, 6, 2007), 5.1612E7D);
    timeSeries.add((RegularTimePeriod)new Day(25, 6, 2007), 6.38454E7D);
    timeSeries.add((RegularTimePeriod)new Day(26, 6, 2007), 8.48184E7D);
    timeSeries.add((RegularTimePeriod)new Day(27, 6, 2007), 7.35129E7D);
    timeSeries.add((RegularTimePeriod)new Day(28, 6, 2007), 7.52751E7D);
    timeSeries.add((RegularTimePeriod)new Day(29, 6, 2007), 1.042039E8D);
    timeSeries.add((RegularTimePeriod)new Day(2, 7, 2007), 6.65404E7D);
    timeSeries.add((RegularTimePeriod)new Day(3, 7, 2007), 2.85208E7D);
    timeSeries.add((RegularTimePeriod)new Day(5, 7, 2007), 4.71763E7D);
    timeSeries.add((RegularTimePeriod)new Day(6, 7, 2007), 7.00848E7D);
    timeSeries.add((RegularTimePeriod)new Day(9, 7, 2007), 9.16308E7D);
    timeSeries.add((RegularTimePeriod)new Day(10, 7, 2007), 1.140717E8D);
    timeSeries.add((RegularTimePeriod)new Day(11, 7, 2007), 3.42179E7D);
    timeSeries.add((RegularTimePeriod)new Day(12, 7, 2007), 3.0298E7D);
    timeSeries.add((RegularTimePeriod)new Day(13, 7, 2007), 4.04235E7D);
    timeSeries.add((RegularTimePeriod)new Day(16, 7, 2007), 3.9238E7D);
    return (IntervalXYDataset)new TimeSeriesCollection(timeSeries);
  }
  
  public static JPanel createDemoPanel() {
    JFreeChart jFreeChart = createChart();
    return (JPanel)new ChartPanel(jFreeChart);
  }
  
  public static void main(String[] paramArrayOfString) {
    PriceVolumeDemo2 priceVolumeDemo2 = new PriceVolumeDemo2("JFreeChart: PriceVolumeDemo2.java");
    priceVolumeDemo2.pack();
    RefineryUtilities.centerFrameOnScreen((Window)priceVolumeDemo2);
    priceVolumeDemo2.setVisible(true);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/PriceVolumeDemo2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */