package demo;

import java.awt.Dimension;
import java.awt.Point;
import java.awt.Window;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import javax.swing.JPanel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartMouseEvent;
import org.jfree.chart.ChartMouseListener;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.ChartRenderingInfo;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.data.xy.XYDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

public class ScatterPlotDemo3 extends ApplicationFrame {
  public ScatterPlotDemo3(String paramString) {
    super(paramString);
    JPanel jPanel = createDemoPanel();
    jPanel.setPreferredSize(new Dimension(500, 270));
    setContentPane(jPanel);
  }
  
  private static JFreeChart createChart(XYDataset paramXYDataset) {
    JFreeChart jFreeChart = ChartFactory.createScatterPlot("Scatter Plot Demo 3", "X", "Y", paramXYDataset, PlotOrientation.VERTICAL, true, true, false);
    XYPlot xYPlot = (XYPlot)jFreeChart.getPlot();
    xYPlot.setDomainCrosshairVisible(true);
    xYPlot.setDomainCrosshairLockedOnData(true);
    xYPlot.setRangeCrosshairVisible(true);
    xYPlot.setRangeCrosshairLockedOnData(true);
    xYPlot.setDomainZeroBaselineVisible(true);
    xYPlot.setRangeZeroBaselineVisible(true);
    xYPlot.setDomainPannable(true);
    xYPlot.setRangePannable(true);
    NumberAxis numberAxis = (NumberAxis)xYPlot.getDomainAxis();
    numberAxis.setAutoRangeIncludesZero(false);
    return jFreeChart;
  }
  
  public static JPanel createDemoPanel() {
    JFreeChart jFreeChart = createChart(new SampleXYDataset2());
    ChartPanel chartPanel = new ChartPanel(jFreeChart);
    chartPanel.setMouseWheelEnabled(true);
    chartPanel.addChartMouseListener(new MyChartMouseListener(chartPanel));
    return (JPanel)chartPanel;
  }
  
  public static void main(String[] paramArrayOfString) {
    ScatterPlotDemo3 scatterPlotDemo3 = new ScatterPlotDemo3("JFreeChart: ScatterPlotDemo3.java");
    scatterPlotDemo3.pack();
    RefineryUtilities.centerFrameOnScreen((Window)scatterPlotDemo3);
    scatterPlotDemo3.setVisible(true);
  }
  
  static class MyChartMouseListener implements ChartMouseListener {
    ChartPanel panel;
    
    public MyChartMouseListener(ChartPanel param1ChartPanel) {
      this.panel = param1ChartPanel;
    }
    
    public void chartMouseClicked(ChartMouseEvent param1ChartMouseEvent) {
      int i = param1ChartMouseEvent.getTrigger().getX();
      int j = param1ChartMouseEvent.getTrigger().getY();
      Point2D point2D = this.panel.translateScreenToJava2D(new Point(i, j));
      XYPlot xYPlot = (XYPlot)this.panel.getChart().getPlot();
      ChartRenderingInfo chartRenderingInfo = this.panel.getChartRenderingInfo();
      Rectangle2D rectangle2D = chartRenderingInfo.getPlotInfo().getDataArea();
      double d1 = xYPlot.getDomainAxis().java2DToValue(point2D.getX(), rectangle2D, xYPlot.getDomainAxisEdge());
      double d2 = xYPlot.getRangeAxis().java2DToValue(point2D.getY(), rectangle2D, xYPlot.getRangeAxisEdge());
      ValueAxis valueAxis1 = xYPlot.getDomainAxis();
      ValueAxis valueAxis2 = xYPlot.getRangeAxis();
      double d3 = valueAxis1.valueToJava2D(d1, rectangle2D, xYPlot.getDomainAxisEdge());
      double d4 = valueAxis2.valueToJava2D(d2, rectangle2D, xYPlot.getRangeAxisEdge());
      Point point = this.panel.translateJava2DToScreen(new Point2D.Double(d3, d4));
      System.out.println("Mouse coordinates are (" + i + ", " + j + "), in data space = (" + d1 + ", " + d2 + ").");
      System.out.println("--> (" + point.getX() + ", " + point.getY() + ")");
    }
    
    public void chartMouseMoved(ChartMouseEvent param1ChartMouseEvent) {}
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/ScatterPlotDemo3.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */