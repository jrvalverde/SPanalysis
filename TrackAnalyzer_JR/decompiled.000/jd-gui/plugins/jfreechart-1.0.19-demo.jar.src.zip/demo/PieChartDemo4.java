package demo;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Window;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Collections;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JPanel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PieLabelLinkStyle;
import org.jfree.chart.plot.PiePlot;
import org.jfree.data.general.DefaultPieDataset;
import org.jfree.data.general.PieDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;
import org.jfree.util.SortOrder;

public class PieChartDemo4 extends ApplicationFrame {
  public PieChartDemo4(String paramString) {
    super(paramString);
    JPanel jPanel = createDemoPanel();
    jPanel.setPreferredSize(new Dimension(500, 270));
    setContentPane(jPanel);
  }
  
  private static DefaultPieDataset createDataset() {
    DefaultPieDataset defaultPieDataset = new DefaultPieDataset();
    defaultPieDataset.setValue("Section A", new Double(43.2D));
    defaultPieDataset.setValue("Section B", new Double(10.0D));
    defaultPieDataset.setValue("Section C", new Double(27.5D));
    defaultPieDataset.setValue("Section D", new Double(17.5D));
    defaultPieDataset.setValue("Section E", new Double(11.0D));
    defaultPieDataset.setValue("Section F", new Double(19.4D));
    return defaultPieDataset;
  }
  
  private static JFreeChart createChart(PieDataset paramPieDataset) {
    JFreeChart jFreeChart = ChartFactory.createPieChart("Pie Chart Demo 4", paramPieDataset, true, true, false);
    PiePlot piePlot = (PiePlot)jFreeChart.getPlot();
    piePlot.setNoDataMessage("No data available");
    piePlot.setCircular(false);
    piePlot.setLabelGap(0.02D);
    piePlot.setExplodePercent("Section D", 0.5D);
    piePlot.setLabelLinkStyle(PieLabelLinkStyle.CUBIC_CURVE);
    return jFreeChart;
  }
  
  public static JPanel createDemoPanel() {
    return new MyDemoPanel(createDataset());
  }
  
  public static void main(String[] paramArrayOfString) {
    PieChartDemo4 pieChartDemo4 = new PieChartDemo4("JFreeChart: PieChartDemo4.java");
    pieChartDemo4.pack();
    RefineryUtilities.centerFrameOnScreen((Window)pieChartDemo4);
    pieChartDemo4.setVisible(true);
  }
  
  private static class MyDemoPanel extends DemoPanel implements ActionListener {
    JFreeChart chart;
    
    DefaultPieDataset dataset;
    
    boolean ascendingByKey = false;
    
    boolean ascendingByValue = false;
    
    public MyDemoPanel(DefaultPieDataset param1DefaultPieDataset) {
      super(new BorderLayout());
      this.dataset = param1DefaultPieDataset;
      this.chart = PieChartDemo4.createChart((PieDataset)param1DefaultPieDataset);
      addChart(this.chart);
      ChartPanel chartPanel = new ChartPanel(this.chart);
      chartPanel.setMouseWheelEnabled(true);
      add((Component)chartPanel);
      JPanel jPanel = new JPanel(new FlowLayout());
      JButton jButton1 = new JButton("By Key");
      jButton1.setActionCommand("BY_KEY");
      jButton1.addActionListener(this);
      JButton jButton2 = new JButton("By Value");
      jButton2.setActionCommand("BY_VALUE");
      jButton2.addActionListener(this);
      JButton jButton3 = new JButton("Random");
      jButton3.setActionCommand("RANDOM");
      jButton3.addActionListener(this);
      JCheckBox jCheckBox = new JCheckBox("Simple Labels");
      jCheckBox.setActionCommand("LABELS");
      jCheckBox.addActionListener(this);
      jPanel.add(jButton1);
      jPanel.add(jButton2);
      jPanel.add(jButton3);
      jPanel.add(jCheckBox);
      add(jPanel, "South");
    }
    
    public void actionPerformed(ActionEvent param1ActionEvent) {
      String str = param1ActionEvent.getActionCommand();
      if ("BY_KEY".equals(str)) {
        if (!this.ascendingByKey) {
          this.dataset.sortByKeys(SortOrder.ASCENDING);
          this.ascendingByKey = true;
        } else {
          this.dataset.sortByKeys(SortOrder.DESCENDING);
          this.ascendingByKey = false;
        } 
      } else if ("BY_VALUE".equals(str)) {
        if (!this.ascendingByValue) {
          this.dataset.sortByValues(SortOrder.ASCENDING);
          this.ascendingByValue = true;
        } else {
          this.dataset.sortByValues(SortOrder.DESCENDING);
          this.ascendingByValue = false;
        } 
      } else if ("RANDOM".equals(str)) {
        ArrayList<?> arrayList = new ArrayList(this.dataset.getKeys());
        Collections.shuffle(arrayList);
        DefaultPieDataset defaultPieDataset = new DefaultPieDataset();
        for (Comparable comparable : arrayList)
          defaultPieDataset.setValue(comparable, this.dataset.getValue(comparable)); 
        PiePlot piePlot = (PiePlot)this.chart.getPlot();
        piePlot.setDataset((PieDataset)defaultPieDataset);
        this.dataset = defaultPieDataset;
      } else if ("LABELS".equals(str)) {
        PiePlot piePlot = (PiePlot)this.chart.getPlot();
        boolean bool = piePlot.getSimpleLabels();
        if (bool) {
          piePlot.setInteriorGap(0.05D);
          piePlot.setSimpleLabels(false);
        } else {
          piePlot.setInteriorGap(0.01D);
          piePlot.setSimpleLabels(true);
        } 
      } 
    }
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/PieChartDemo4.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */