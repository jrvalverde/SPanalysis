package demo;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Window;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JPanel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.StandardXYItemRenderer;
import org.jfree.chart.renderer.xy.XYItemRenderer;
import org.jfree.data.time.Day;
import org.jfree.data.time.RegularTimePeriod;
import org.jfree.data.time.TimeSeries;
import org.jfree.data.time.TimeSeriesCollection;
import org.jfree.data.xy.XYDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

public class MultipleDatasetDemo1 extends ApplicationFrame {
  public MultipleDatasetDemo1(String paramString) {
    super(paramString);
    setContentPane(createDemoPanel());
  }
  
  public static JPanel createDemoPanel() {
    return new MyDemoPanel();
  }
  
  public static void main(String[] paramArrayOfString) {
    MultipleDatasetDemo1 multipleDatasetDemo1 = new MultipleDatasetDemo1("JFreeChart: MultipleDatasetDemo1.java");
    multipleDatasetDemo1.pack();
    RefineryUtilities.centerFrameOnScreen((Window)multipleDatasetDemo1);
    multipleDatasetDemo1.setVisible(true);
  }
  
  static class MyDemoPanel extends DemoPanel implements ActionListener {
    private XYPlot plot;
    
    private int datasetIndex = 0;
    
    public MyDemoPanel() {
      super(new BorderLayout());
      TimeSeriesCollection timeSeriesCollection = createRandomDataset("Series 1");
      JFreeChart jFreeChart = ChartFactory.createTimeSeriesChart("Multiple Dataset Demo 1", "Time", "Value", (XYDataset)timeSeriesCollection, true, true, false);
      jFreeChart.setBackgroundPaint(null);
      addChart(jFreeChart);
      this.plot = (XYPlot)jFreeChart.getPlot();
      ValueAxis valueAxis = this.plot.getDomainAxis();
      valueAxis.setAutoRange(true);
      NumberAxis numberAxis = new NumberAxis("Range Axis 2");
      numberAxis.setAutoRangeIncludesZero(false);
      ChartUtilities.applyCurrentTheme(jFreeChart);
      JPanel jPanel1 = new JPanel(new BorderLayout());
      ChartPanel chartPanel = new ChartPanel(jFreeChart);
      jPanel1.add((Component)chartPanel);
      JButton jButton1 = new JButton("Add Dataset");
      jButton1.setActionCommand("ADD_DATASET");
      jButton1.addActionListener(this);
      JButton jButton2 = new JButton("Remove Dataset");
      jButton2.setActionCommand("REMOVE_DATASET");
      jButton2.addActionListener(this);
      JPanel jPanel2 = new JPanel(new FlowLayout());
      jPanel2.add(jButton1);
      jPanel2.add(jButton2);
      jPanel1.add(jPanel2, "South");
      chartPanel.setPreferredSize(new Dimension(500, 270));
      add(jPanel1);
    }
    
    private TimeSeriesCollection createRandomDataset(String param1String) {
      TimeSeries timeSeries = new TimeSeries(param1String);
      double d = 100.0D;
      Day day = new Day();
      for (byte b = 0; b < 50; b++) {
        timeSeries.add((RegularTimePeriod)day, d);
        RegularTimePeriod regularTimePeriod = day.next();
        d *= 1.0D + Math.random() / 100.0D;
      } 
      return new TimeSeriesCollection(timeSeries);
    }
    
    public void actionPerformed(ActionEvent param1ActionEvent) {
      if (param1ActionEvent.getActionCommand().equals("ADD_DATASET")) {
        if (this.datasetIndex < 20) {
          this.datasetIndex++;
          this.plot.setDataset(this.datasetIndex, (XYDataset)createRandomDataset("S" + this.datasetIndex));
          this.plot.setRenderer(this.datasetIndex, (XYItemRenderer)new StandardXYItemRenderer());
        } 
      } else if (param1ActionEvent.getActionCommand().equals("REMOVE_DATASET") && this.datasetIndex >= 1) {
        this.plot.setDataset(this.datasetIndex, null);
        this.plot.setRenderer(this.datasetIndex, null);
        this.datasetIndex--;
      } 
    }
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/MultipleDatasetDemo1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */