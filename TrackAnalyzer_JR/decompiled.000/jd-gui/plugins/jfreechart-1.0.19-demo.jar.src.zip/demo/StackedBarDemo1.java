package demo;

import java.awt.Container;
import java.awt.Dimension;
import java.awt.Window;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

public class StackedBarDemo1 extends ApplicationFrame {
  public StackedBarDemo1(String paramString) {
    super(paramString);
    DefaultCategoryDataset defaultCategoryDataset = new DefaultCategoryDataset();
    defaultCategoryDataset.addValue(1.0D, "Row 1", "Column 1");
    defaultCategoryDataset.addValue(5.0D, "Row 1", "Column 2");
    defaultCategoryDataset.addValue(3.0D, "Row 1", "Column 3");
    defaultCategoryDataset.addValue(2.0D, "Row 2", "Column 1");
    defaultCategoryDataset.addValue(3.0D, "Row 2", "Column 2");
    defaultCategoryDataset.addValue(2.0D, "Row 2", "Column 3");
    JFreeChart jFreeChart = ChartFactory.createStackedBarChart("StackedBarDemo1", "Category", "Value", (CategoryDataset)defaultCategoryDataset, PlotOrientation.VERTICAL, true, true, false);
    ChartPanel chartPanel = new ChartPanel(jFreeChart);
    chartPanel.setPreferredSize(new Dimension(500, 270));
    setContentPane((Container)chartPanel);
  }
  
  public static void main(String[] paramArrayOfString) {
    StackedBarDemo1 stackedBarDemo1 = new StackedBarDemo1("StackedBarDemo1");
    stackedBarDemo1.pack();
    RefineryUtilities.centerFrameOnScreen((Window)stackedBarDemo1);
    stackedBarDemo1.setVisible(true);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/StackedBarDemo1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */