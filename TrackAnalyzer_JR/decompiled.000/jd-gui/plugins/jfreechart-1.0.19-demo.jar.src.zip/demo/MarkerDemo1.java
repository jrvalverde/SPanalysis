package demo;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Window;
import javax.swing.JPanel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.annotations.XYAnnotation;
import org.jfree.chart.annotations.XYDrawableAnnotation;
import org.jfree.chart.annotations.XYPointerAnnotation;
import org.jfree.chart.axis.DateAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.labels.StandardXYToolTipGenerator;
import org.jfree.chart.labels.XYToolTipGenerator;
import org.jfree.chart.plot.Marker;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.ValueMarker;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.title.LegendTitle;
import org.jfree.data.time.Day;
import org.jfree.data.time.Hour;
import org.jfree.data.time.Minute;
import org.jfree.data.time.RegularTimePeriod;
import org.jfree.data.time.TimeSeries;
import org.jfree.data.time.TimeSeriesCollection;
import org.jfree.data.xy.XYDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.LengthAdjustmentType;
import org.jfree.ui.RectangleAnchor;
import org.jfree.ui.RectangleEdge;
import org.jfree.ui.RefineryUtilities;
import org.jfree.ui.TextAnchor;

public class MarkerDemo1 extends ApplicationFrame {
  public MarkerDemo1(String paramString) {
    super(paramString);
    ChartPanel chartPanel = (ChartPanel)createDemoPanel();
    chartPanel.setPreferredSize(new Dimension(500, 270));
    chartPanel.setDomainZoomable(true);
    chartPanel.setRangeZoomable(true);
    setContentPane((Container)chartPanel);
  }
  
  private static JFreeChart createChart(XYDataset paramXYDataset) {
    JFreeChart jFreeChart = ChartFactory.createScatterPlot("Marker Demo 1", "X", "Y", paramXYDataset, PlotOrientation.VERTICAL, true, true, false);
    LegendTitle legendTitle = (LegendTitle)jFreeChart.getSubtitle(0);
    legendTitle.setPosition(RectangleEdge.RIGHT);
    XYPlot xYPlot = (XYPlot)jFreeChart.getPlot();
    xYPlot.setDomainPannable(true);
    xYPlot.setRangePannable(true);
    xYPlot.getRenderer().setBaseToolTipGenerator((XYToolTipGenerator)StandardXYToolTipGenerator.getTimeSeriesInstance());
    DateAxis dateAxis = new DateAxis("Time");
    dateAxis.setUpperMargin(0.5D);
    xYPlot.setDomainAxis((ValueAxis)dateAxis);
    ValueAxis valueAxis = xYPlot.getRangeAxis();
    valueAxis.setUpperMargin(0.3D);
    valueAxis.setLowerMargin(0.5D);
    ValueMarker valueMarker1 = new ValueMarker(200.0D);
    valueMarker1.setLabelOffsetType(LengthAdjustmentType.EXPAND);
    valueMarker1.setPaint(Color.green);
    valueMarker1.setLabel("Bid Start Price");
    valueMarker1.setLabelAnchor(RectangleAnchor.BOTTOM_RIGHT);
    valueMarker1.setLabelTextAnchor(TextAnchor.TOP_RIGHT);
    xYPlot.addRangeMarker((Marker)valueMarker1);
    ValueMarker valueMarker2 = new ValueMarker(175.0D);
    valueMarker2.setLabelOffsetType(LengthAdjustmentType.EXPAND);
    valueMarker2.setPaint(Color.red);
    valueMarker2.setLabel("Target Price");
    valueMarker2.setLabelAnchor(RectangleAnchor.TOP_RIGHT);
    valueMarker2.setLabelTextAnchor(TextAnchor.BOTTOM_RIGHT);
    xYPlot.addRangeMarker((Marker)valueMarker2);
    Hour hour1 = new Hour(2, new Day(22, 5, 2003));
    double d = hour1.getFirstMillisecond();
    ValueMarker valueMarker3 = new ValueMarker(d);
    valueMarker3.setPaint(Color.orange);
    valueMarker3.setLabel("Original Close (02:00)");
    valueMarker3.setLabelAnchor(RectangleAnchor.TOP_LEFT);
    valueMarker3.setLabelTextAnchor(TextAnchor.TOP_RIGHT);
    xYPlot.addDomainMarker((Marker)valueMarker3);
    Minute minute1 = new Minute(15, hour1);
    d = minute1.getFirstMillisecond();
    ValueMarker valueMarker4 = new ValueMarker(d);
    valueMarker4.setPaint(Color.red);
    valueMarker4.setLabel("Close Date (02:15)");
    valueMarker4.setLabelAnchor(RectangleAnchor.TOP_RIGHT);
    valueMarker4.setLabelTextAnchor(TextAnchor.TOP_LEFT);
    xYPlot.addDomainMarker((Marker)valueMarker4);
    Hour hour2 = new Hour(2, new Day(22, 5, 2003));
    Minute minute2 = new Minute(10, hour2);
    d = minute2.getFirstMillisecond();
    CircleDrawer circleDrawer = new CircleDrawer(Color.red, new BasicStroke(1.0F), null);
    XYDrawableAnnotation xYDrawableAnnotation = new XYDrawableAnnotation(d, 163.0D, 11.0D, 11.0D, circleDrawer);
    xYPlot.addAnnotation((XYAnnotation)xYDrawableAnnotation);
    XYPointerAnnotation xYPointerAnnotation = new XYPointerAnnotation("Best Bid", d, 163.0D, 2.356194490192345D);
    xYPointerAnnotation.setBaseRadius(35.0D);
    xYPointerAnnotation.setTipRadius(10.0D);
    xYPointerAnnotation.setFont(new Font("SansSerif", 0, 9));
    xYPointerAnnotation.setPaint(Color.blue);
    xYPointerAnnotation.setTextAnchor(TextAnchor.HALF_ASCENT_RIGHT);
    xYPlot.addAnnotation((XYAnnotation)xYPointerAnnotation);
    ChartUtilities.applyCurrentTheme(jFreeChart);
    return jFreeChart;
  }
  
  private static XYDataset createDataset() {
    TimeSeriesCollection timeSeriesCollection = new TimeSeriesCollection();
    timeSeriesCollection.addSeries(createSupplier1Bids());
    timeSeriesCollection.addSeries(createSupplier2Bids());
    return (XYDataset)timeSeriesCollection;
  }
  
  private static TimeSeries createSupplier1Bids() {
    Hour hour = new Hour(1, new Day(22, 5, 2003));
    TimeSeries timeSeries = new TimeSeries("Supplier 1");
    timeSeries.add((RegularTimePeriod)new Minute(13, hour), 200.0D);
    timeSeries.add((RegularTimePeriod)new Minute(14, hour), 195.0D);
    timeSeries.add((RegularTimePeriod)new Minute(45, hour), 190.0D);
    timeSeries.add((RegularTimePeriod)new Minute(46, hour), 188.0D);
    timeSeries.add((RegularTimePeriod)new Minute(47, hour), 185.0D);
    timeSeries.add((RegularTimePeriod)new Minute(52, hour), 180.0D);
    return timeSeries;
  }
  
  private static TimeSeries createSupplier2Bids() {
    Hour hour1 = new Hour(1, new Day(22, 5, 2003));
    Hour hour2 = (Hour)hour1.next();
    TimeSeries timeSeries = new TimeSeries("Supplier 2");
    timeSeries.add((RegularTimePeriod)new Minute(25, hour1), 185.0D);
    timeSeries.add((RegularTimePeriod)new Minute(0, hour2), 175.0D);
    timeSeries.add((RegularTimePeriod)new Minute(5, hour2), 170.0D);
    timeSeries.add((RegularTimePeriod)new Minute(6, hour2), 168.0D);
    timeSeries.add((RegularTimePeriod)new Minute(9, hour2), 165.0D);
    timeSeries.add((RegularTimePeriod)new Minute(10, hour2), 163.0D);
    return timeSeries;
  }
  
  public static JPanel createDemoPanel() {
    JFreeChart jFreeChart = createChart(createDataset());
    ChartPanel chartPanel = new ChartPanel(jFreeChart);
    chartPanel.setMouseWheelEnabled(true);
    return (JPanel)chartPanel;
  }
  
  public static void main(String[] paramArrayOfString) {
    MarkerDemo1 markerDemo1 = new MarkerDemo1("JFreeChart: MarkerDemo1.java");
    markerDemo1.pack();
    RefineryUtilities.centerFrameOnScreen((Window)markerDemo1);
    markerDemo1.setVisible(true);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/MarkerDemo1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */