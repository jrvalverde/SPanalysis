package demo;

import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.title.LegendTitle;
import org.jfree.data.general.DefaultPieDataset;
import org.jfree.data.general.PieDataset;
import org.jfree.ui.Size2D;

public class LegendTitleToImageDemo1 {
  public static void main(String[] paramArrayOfString) throws IOException {
    DefaultPieDataset defaultPieDataset = new DefaultPieDataset();
    defaultPieDataset.setValue("A", 1.0D);
    defaultPieDataset.setValue("B", 2.0D);
    defaultPieDataset.setValue("C", 3.0D);
    JFreeChart jFreeChart = ChartFactory.createPieChart("Test", (PieDataset)defaultPieDataset, true, false, false);
    LegendTitle legendTitle = jFreeChart.getLegend();
    legendTitle.setMargin(0.0D, 0.0D, 1.0D, 1.0D);
    BufferedImage bufferedImage1 = new BufferedImage(1, 1, 2);
    Graphics2D graphics2D1 = bufferedImage1.createGraphics();
    Size2D size2D = legendTitle.arrange(graphics2D1);
    graphics2D1.dispose();
    int i = (int)Math.rint(size2D.width);
    int j = (int)Math.rint(size2D.height);
    BufferedImage bufferedImage2 = new BufferedImage(i, j, 2);
    Graphics2D graphics2D2 = bufferedImage2.createGraphics();
    legendTitle.draw(graphics2D2, new Rectangle2D.Double(0.0D, 0.0D, i, j));
    graphics2D2.dispose();
    BufferedOutputStream bufferedOutputStream = new BufferedOutputStream(new FileOutputStream(new File("LegendTitleToImageDemo1.png")));
    ChartUtilities.writeBufferedImageAsPNG(bufferedOutputStream, bufferedImage2);
    bufferedOutputStream.close();
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/LegendTitleToImageDemo1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */