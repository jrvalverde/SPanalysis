package demo;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.Window;
import java.awt.geom.Rectangle2D;
import javax.swing.JPanel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.annotations.XYAnnotation;
import org.jfree.chart.annotations.XYDataImageAnnotation;
import org.jfree.chart.annotations.XYLineAnnotation;
import org.jfree.chart.annotations.XYShapeAnnotation;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
import org.jfree.data.xy.XYDataset;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

public class PlotOrientationDemo1 extends ApplicationFrame {
  private static int CHART_COUNT = 8;
  
  public PlotOrientationDemo1(String paramString) {
    super(paramString);
    setContentPane(createDemoPanel());
  }
  
  private static XYDataset createDataset(int paramInt) {
    XYSeries xYSeries = new XYSeries("Series " + (paramInt + 1));
    xYSeries.add(-10.0D, -5.0D);
    xYSeries.add(10.0D, 5.0D);
    XYSeriesCollection xYSeriesCollection = new XYSeriesCollection();
    xYSeriesCollection.addSeries(xYSeries);
    return (XYDataset)xYSeriesCollection;
  }
  
  private static JFreeChart createChart(int paramInt, XYDataset paramXYDataset) {
    JFreeChart jFreeChart = ChartFactory.createXYLineChart("Chart " + (paramInt + 1), "X", "Y", paramXYDataset, PlotOrientation.VERTICAL, false, false, false);
    XYPlot xYPlot = (XYPlot)jFreeChart.getPlot();
    XYLineAndShapeRenderer xYLineAndShapeRenderer = (XYLineAndShapeRenderer)xYPlot.getRenderer();
    xYLineAndShapeRenderer.setBaseShapesVisible(true);
    xYLineAndShapeRenderer.setBaseShapesFilled(true);
    ValueAxis valueAxis1 = xYPlot.getDomainAxis();
    valueAxis1.setStandardTickUnits(NumberAxis.createIntegerTickUnits());
    ValueAxis valueAxis2 = xYPlot.getRangeAxis();
    valueAxis2.setStandardTickUnits(NumberAxis.createIntegerTickUnits());
    ChartUtilities.applyCurrentTheme(jFreeChart);
    return jFreeChart;
  }
  
  public static JPanel createDemoPanel() {
    return new MyDemoPanel();
  }
  
  public static void main(String[] paramArrayOfString) {
    PlotOrientationDemo1 plotOrientationDemo1 = new PlotOrientationDemo1("JFreeChart: PlotOrientationDemo1.java");
    plotOrientationDemo1.pack();
    RefineryUtilities.centerFrameOnScreen((Window)plotOrientationDemo1);
    plotOrientationDemo1.setVisible(true);
  }
  
  static class MyDemoPanel extends DemoPanel {
    private XYDataset[] datasets = new XYDataset[PlotOrientationDemo1.CHART_COUNT];
    
    private JFreeChart[] charts = new JFreeChart[PlotOrientationDemo1.CHART_COUNT];
    
    private ChartPanel[] panels = new ChartPanel[PlotOrientationDemo1.CHART_COUNT];
    
    public MyDemoPanel() {
      super(new GridLayout(2, 4));
      for (byte b = 0; b < PlotOrientationDemo1.CHART_COUNT; b++) {
        this.datasets[b] = PlotOrientationDemo1.createDataset(b);
        this.charts[b] = PlotOrientationDemo1.createChart(b, this.datasets[b]);
        XYPlot xYPlot = (XYPlot)this.charts[b].getPlot();
        xYPlot.setDomainPannable(true);
        xYPlot.setRangePannable(true);
        XYShapeAnnotation xYShapeAnnotation = new XYShapeAnnotation(new Rectangle2D.Double(-2.0D, -3.0D, 1.0D, 4.0D), new BasicStroke(1.0F), Color.blue, Color.yellow);
        XYLineAnnotation xYLineAnnotation = new XYLineAnnotation(0.0D, -5.0D, 10.0D, -5.0D);
        XYDataImageAnnotation xYDataImageAnnotation = new XYDataImageAnnotation(JFreeChart.INFO.getLogo(), 5.0D, 2.0D, 6.0D, 4.0D, true);
        xYPlot.addAnnotation((XYAnnotation)xYShapeAnnotation);
        xYPlot.addAnnotation((XYAnnotation)xYLineAnnotation);
        xYPlot.addAnnotation((XYAnnotation)xYDataImageAnnotation);
        xYPlot.setQuadrantPaint(0, new Color(230, 230, 255));
        xYPlot.setQuadrantPaint(1, new Color(230, 255, 230));
        xYPlot.setQuadrantPaint(2, new Color(255, 230, 230));
        xYPlot.setQuadrantPaint(3, new Color(255, 230, 255));
        addChart(this.charts[b]);
        this.panels[b] = new ChartPanel(this.charts[b]);
        this.panels[b].setMouseWheelEnabled(true);
      } 
      XYPlot xYPlot1 = (XYPlot)this.charts[1].getPlot();
      XYPlot xYPlot2 = (XYPlot)this.charts[2].getPlot();
      XYPlot xYPlot3 = (XYPlot)this.charts[3].getPlot();
      XYPlot xYPlot4 = (XYPlot)this.charts[4].getPlot();
      XYPlot xYPlot5 = (XYPlot)this.charts[5].getPlot();
      XYPlot xYPlot6 = (XYPlot)this.charts[6].getPlot();
      XYPlot xYPlot7 = (XYPlot)this.charts[7].getPlot();
      xYPlot1.getDomainAxis().setInverted(true);
      xYPlot2.getRangeAxis().setInverted(true);
      xYPlot3.getDomainAxis().setInverted(true);
      xYPlot3.getRangeAxis().setInverted(true);
      xYPlot5.getDomainAxis().setInverted(true);
      xYPlot6.getRangeAxis().setInverted(true);
      xYPlot4.getDomainAxis().setInverted(true);
      xYPlot4.getRangeAxis().setInverted(true);
      xYPlot4.setOrientation(PlotOrientation.HORIZONTAL);
      xYPlot5.setOrientation(PlotOrientation.HORIZONTAL);
      xYPlot6.setOrientation(PlotOrientation.HORIZONTAL);
      xYPlot7.setOrientation(PlotOrientation.HORIZONTAL);
      add((Component)this.panels[0]);
      add((Component)this.panels[1]);
      add((Component)this.panels[4]);
      add((Component)this.panels[5]);
      add((Component)this.panels[2]);
      add((Component)this.panels[3]);
      add((Component)this.panels[6]);
      add((Component)this.panels[7]);
      setPreferredSize(new Dimension(800, 600));
    }
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/PlotOrientationDemo1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */