package demo;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Window;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JPanel;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.DateAxis;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.CombinedDomainXYPlot;
import org.jfree.chart.plot.Plot;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.StandardXYItemRenderer;
import org.jfree.chart.renderer.xy.XYItemRenderer;
import org.jfree.chart.title.LegendTitle;
import org.jfree.data.time.Millisecond;
import org.jfree.data.time.RegularTimePeriod;
import org.jfree.data.time.TimeSeries;
import org.jfree.data.time.TimeSeriesCollection;
import org.jfree.data.xy.XYDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RectangleEdge;
import org.jfree.ui.RectangleInsets;
import org.jfree.ui.RefineryUtilities;
import org.jfree.util.UnitType;

public class DynamicDataDemo3 extends ApplicationFrame {
  public DynamicDataDemo3(String paramString) {
    super(paramString);
    setContentPane(createDemoPanel());
  }
  
  public static JPanel createDemoPanel() {
    return new MyDemoPanel();
  }
  
  public static void main(String[] paramArrayOfString) {
    DynamicDataDemo3 dynamicDataDemo3 = new DynamicDataDemo3("JFreeChart: DynamicDataDemo3.java");
    dynamicDataDemo3.pack();
    RefineryUtilities.centerFrameOnScreen((Window)dynamicDataDemo3);
    dynamicDataDemo3.setVisible(true);
  }
  
  static class MyDemoPanel extends DemoPanel implements ActionListener {
    public static final int SUBPLOT_COUNT = 3;
    
    private TimeSeriesCollection[] datasets;
    
    private double[] lastValue = new double[3];
    
    public MyDemoPanel() {
      super(new BorderLayout());
      CombinedDomainXYPlot combinedDomainXYPlot = new CombinedDomainXYPlot((ValueAxis)new DateAxis("Time"));
      this.datasets = new TimeSeriesCollection[3];
      for (byte b1 = 0; b1 < 3; b1++) {
        this.lastValue[b1] = 100.0D;
        TimeSeries timeSeries = new TimeSeries("Random " + b1);
        this.datasets[b1] = new TimeSeriesCollection(timeSeries);
        NumberAxis numberAxis = new NumberAxis("Y" + b1);
        numberAxis.setAutoRangeIncludesZero(false);
        XYPlot xYPlot = new XYPlot((XYDataset)this.datasets[b1], null, (ValueAxis)numberAxis, (XYItemRenderer)new StandardXYItemRenderer());
        xYPlot.setBackgroundPaint(Color.lightGray);
        xYPlot.setDomainGridlinePaint(Color.white);
        xYPlot.setRangeGridlinePaint(Color.white);
        combinedDomainXYPlot.add(xYPlot);
      } 
      JFreeChart jFreeChart = new JFreeChart("Dynamic Data Demo 3", (Plot)combinedDomainXYPlot);
      addChart(jFreeChart);
      LegendTitle legendTitle = (LegendTitle)jFreeChart.getSubtitle(0);
      legendTitle.setPosition(RectangleEdge.RIGHT);
      legendTitle.setMargin(new RectangleInsets(UnitType.ABSOLUTE, 0.0D, 4.0D, 0.0D, 4.0D));
      jFreeChart.setBorderPaint(Color.black);
      jFreeChart.setBorderVisible(true);
      ValueAxis valueAxis = combinedDomainXYPlot.getDomainAxis();
      valueAxis.setAutoRange(true);
      valueAxis.setFixedAutoRange(20000.0D);
      ChartUtilities.applyCurrentTheme(jFreeChart);
      ChartPanel chartPanel = new ChartPanel(jFreeChart);
      add((Component)chartPanel);
      JPanel jPanel = new JPanel(new FlowLayout());
      for (byte b2 = 0; b2 < 3; b2++) {
        JButton jButton1 = new JButton("Series " + b2);
        jButton1.setActionCommand("ADD_DATA_" + b2);
        jButton1.addActionListener(this);
        jPanel.add(jButton1);
      } 
      JButton jButton = new JButton("ALL");
      jButton.setActionCommand("ADD_ALL");
      jButton.addActionListener(this);
      jPanel.add(jButton);
      add(jPanel, "South");
      chartPanel.setPreferredSize(new Dimension(500, 470));
      chartPanel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
    }
    
    public void actionPerformed(ActionEvent param1ActionEvent) {
      for (byte b = 0; b < 3; b++) {
        if (param1ActionEvent.getActionCommand().endsWith(String.valueOf(b))) {
          Millisecond millisecond = new Millisecond();
          System.out.println("Now = " + millisecond.toString());
          this.lastValue[b] = this.lastValue[b] * (0.9D + 0.2D * Math.random());
          this.datasets[b].getSeries(0).add((RegularTimePeriod)new Millisecond(), this.lastValue[b]);
        } 
      } 
      if (param1ActionEvent.getActionCommand().equals("ADD_ALL")) {
        Millisecond millisecond = new Millisecond();
        System.out.println("Now = " + millisecond.toString());
        for (byte b1 = 0; b1 < 3; b1++) {
          this.lastValue[b1] = this.lastValue[b1] * (0.9D + 0.2D * Math.random());
          this.datasets[b1].getSeries(0).add((RegularTimePeriod)new Millisecond(), this.lastValue[b1]);
        } 
      } 
    }
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/DynamicDataDemo3.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */