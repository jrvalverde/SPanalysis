package demo;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Window;
import javax.swing.JPanel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RectangleInsets;
import org.jfree.ui.RefineryUtilities;

public class BarChartDemo6 extends ApplicationFrame {
  public BarChartDemo6(String paramString) {
    super(paramString);
    JPanel jPanel = createDemoPanel();
    jPanel.setPreferredSize(new Dimension(500, 270));
    setContentPane(jPanel);
  }
  
  private static CategoryDataset createDataset() {
    DefaultCategoryDataset defaultCategoryDataset = new DefaultCategoryDataset();
    defaultCategoryDataset.addValue(83.0D, "First", "Factor 1");
    return (CategoryDataset)defaultCategoryDataset;
  }
  
  private static JFreeChart createChart(CategoryDataset paramCategoryDataset) {
    JFreeChart jFreeChart = ChartFactory.createBarChart(null, "Category", "Score (%)", paramCategoryDataset);
    jFreeChart.removeLegend();
    jFreeChart.setBackgroundPaint(Color.YELLOW);
    CategoryPlot categoryPlot = (CategoryPlot)jFreeChart.getPlot();
    categoryPlot.setOrientation(PlotOrientation.HORIZONTAL);
    categoryPlot.setInsets(new RectangleInsets(0.0D, 0.0D, 0.0D, 0.0D));
    categoryPlot.setAxisOffset(RectangleInsets.ZERO_INSETS);
    categoryPlot.setRangeGridlinesVisible(false);
    CategoryAxis categoryAxis = categoryPlot.getDomainAxis();
    categoryAxis.setLowerMargin(0.2D);
    categoryAxis.setUpperMargin(0.2D);
    categoryAxis.setVisible(false);
    NumberAxis numberAxis = (NumberAxis)categoryPlot.getRangeAxis();
    numberAxis.setRange(0.0D, 100.0D);
    numberAxis.setVisible(false);
    return jFreeChart;
  }
  
  public static JPanel createDemoPanel() {
    JFreeChart jFreeChart = createChart(createDataset());
    return (JPanel)new ChartPanel(jFreeChart);
  }
  
  public static void main(String[] paramArrayOfString) {
    BarChartDemo6 barChartDemo6 = new BarChartDemo6("JFreeChart: BarChartDemo6.java");
    barChartDemo6.pack();
    RefineryUtilities.centerFrameOnScreen((Window)barChartDemo6);
    barChartDemo6.setVisible(true);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/BarChartDemo6.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */