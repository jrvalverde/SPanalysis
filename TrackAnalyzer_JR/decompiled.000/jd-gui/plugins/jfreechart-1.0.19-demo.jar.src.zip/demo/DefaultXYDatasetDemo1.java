package demo;

import java.awt.Dimension;
import java.awt.Window;
import javax.swing.JPanel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.xy.DefaultXYDataset;
import org.jfree.data.xy.XYDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

public class DefaultXYDatasetDemo1 extends ApplicationFrame {
  public DefaultXYDatasetDemo1(String paramString) {
    super(paramString);
    JPanel jPanel = createDemoPanel();
    jPanel.setPreferredSize(new Dimension(500, 270));
    setContentPane(jPanel);
  }
  
  private static JFreeChart createChart(XYDataset paramXYDataset) {
    return ChartFactory.createScatterPlot("DefaultXYDatasetDemo1", "X", "Y", paramXYDataset, PlotOrientation.VERTICAL, true, false, false);
  }
  
  private static XYDataset createDataset() {
    DefaultXYDataset defaultXYDataset = new DefaultXYDataset();
    double[] arrayOfDouble1 = { 1.0D, 2.0D, 3.0D, 4.0D, 5.0D, 6.0D, 7.0D, 8.0D };
    double[] arrayOfDouble2 = { 8.0D, 7.0D, 6.0D, 5.0D, 4.0D, 3.0D, 2.0D, 1.0D };
    double[][] arrayOfDouble3 = { arrayOfDouble1, arrayOfDouble2 };
    defaultXYDataset.addSeries("Series 1", arrayOfDouble3);
    double[] arrayOfDouble4 = { 1.0D, 2.0D, 3.0D, 4.0D, 5.0D, 6.0D, 7.0D, 8.0D };
    double[] arrayOfDouble5 = { 1.0D, 2.0D, 3.0D, 4.0D, 5.0D, 6.0D, 7.0D, 8.0D };
    double[][] arrayOfDouble6 = { arrayOfDouble4, arrayOfDouble5 };
    defaultXYDataset.addSeries("Series 2", arrayOfDouble6);
    return (XYDataset)defaultXYDataset;
  }
  
  public static JPanel createDemoPanel() {
    return (JPanel)new ChartPanel(createChart(createDataset()));
  }
  
  public static void main(String[] paramArrayOfString) {
    DefaultXYDatasetDemo1 defaultXYDatasetDemo1 = new DefaultXYDatasetDemo1("JFreeChart: DefautlXYDatasetDemo1.java");
    defaultXYDatasetDemo1.pack();
    RefineryUtilities.centerFrameOnScreen((Window)defaultXYDatasetDemo1);
    defaultXYDatasetDemo1.setVisible(true);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/DefaultXYDatasetDemo1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */