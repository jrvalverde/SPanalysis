package demo;

import java.awt.Dimension;
import java.awt.Window;
import javax.swing.JPanel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.general.DefaultKeyedValues2DDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

public class PopulationChartDemo1 extends ApplicationFrame {
  public PopulationChartDemo1(String paramString) {
    super(paramString);
    JPanel jPanel = createDemoPanel();
    jPanel.setPreferredSize(new Dimension(500, 270));
    setContentPane(jPanel);
  }
  
  public static JFreeChart createChart(CategoryDataset paramCategoryDataset) {
    return ChartFactory.createStackedBarChart("Population Chart Demo 1", "Age Group", "Population (millions)", paramCategoryDataset, PlotOrientation.HORIZONTAL, true, true, false);
  }
  
  public static CategoryDataset createDataset() {
    DefaultKeyedValues2DDataset defaultKeyedValues2DDataset = new DefaultKeyedValues2DDataset();
    defaultKeyedValues2DDataset.addValue(-6.0D, "Male", "70+");
    defaultKeyedValues2DDataset.addValue(-8.0D, "Male", "60-69");
    defaultKeyedValues2DDataset.addValue(-11.0D, "Male", "50-59");
    defaultKeyedValues2DDataset.addValue(-13.0D, "Male", "40-49");
    defaultKeyedValues2DDataset.addValue(-14.0D, "Male", "30-39");
    defaultKeyedValues2DDataset.addValue(-15.0D, "Male", "20-29");
    defaultKeyedValues2DDataset.addValue(-19.0D, "Male", "10-19");
    defaultKeyedValues2DDataset.addValue(-21.0D, "Male", "0-9");
    defaultKeyedValues2DDataset.addValue(10.0D, "Female", "70+");
    defaultKeyedValues2DDataset.addValue(12.0D, "Female", "60-69");
    defaultKeyedValues2DDataset.addValue(13.0D, "Female", "50-59");
    defaultKeyedValues2DDataset.addValue(14.0D, "Female", "40-49");
    defaultKeyedValues2DDataset.addValue(15.0D, "Female", "30-39");
    defaultKeyedValues2DDataset.addValue(17.0D, "Female", "20-29");
    defaultKeyedValues2DDataset.addValue(19.0D, "Female", "10-19");
    defaultKeyedValues2DDataset.addValue(20.0D, "Female", "0-9");
    return (CategoryDataset)defaultKeyedValues2DDataset;
  }
  
  public static JPanel createDemoPanel() {
    JFreeChart jFreeChart = createChart(createDataset());
    return (JPanel)new ChartPanel(jFreeChart);
  }
  
  public static void main(String[] paramArrayOfString) {
    PopulationChartDemo1 populationChartDemo1 = new PopulationChartDemo1("JFreeChart: PopulationChartDemo1.java");
    populationChartDemo1.pack();
    RefineryUtilities.centerFrameOnScreen((Window)populationChartDemo1);
    populationChartDemo1.setVisible(true);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/PopulationChartDemo1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */