package demo;

import java.awt.Container;
import java.awt.Dimension;
import java.awt.Window;
import javax.swing.JPanel;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.CategoryLabelPositions;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.labels.CategoryToolTipGenerator;
import org.jfree.chart.labels.StandardCategoryToolTipGenerator;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.Plot;
import org.jfree.chart.renderer.category.CategoryItemRenderer;
import org.jfree.chart.renderer.category.CategoryStepRenderer;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.general.DatasetUtilities;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RectangleInsets;
import org.jfree.ui.RefineryUtilities;

public class CategoryStepChartDemo1 extends ApplicationFrame {
  public CategoryStepChartDemo1(String paramString) {
    super(paramString);
    ChartPanel chartPanel = (ChartPanel)createDemoPanel();
    chartPanel.setPreferredSize(new Dimension(500, 270));
    chartPanel.setEnforceFileExtensions(false);
    setContentPane((Container)chartPanel);
  }
  
  private static CategoryDataset createDataset() {
    double[][] arrayOfDouble = { { 1.0D, 4.0D, 3.0D, 5.0D, 5.0D, 7.0D, 7.0D, 8.0D }, { 5.0D, 7.0D, 6.0D, 8.0D, 4.0D, 4.0D, 2.0D, 1.0D }, { 4.0D, 3.0D, 2.0D, 3.0D, 6.0D, 3.0D, 4.0D, 3.0D } };
    return DatasetUtilities.createCategoryDataset("Series ", "Type ", arrayOfDouble);
  }
  
  private static JFreeChart createChart(CategoryDataset paramCategoryDataset) {
    CategoryStepRenderer categoryStepRenderer = new CategoryStepRenderer(true);
    categoryStepRenderer.setBaseToolTipGenerator((CategoryToolTipGenerator)new StandardCategoryToolTipGenerator());
    CategoryAxis categoryAxis = new CategoryAxis("Category");
    NumberAxis numberAxis = new NumberAxis("Value");
    CategoryPlot categoryPlot = new CategoryPlot(paramCategoryDataset, categoryAxis, (ValueAxis)numberAxis, (CategoryItemRenderer)categoryStepRenderer);
    categoryPlot.setRangePannable(true);
    JFreeChart jFreeChart = new JFreeChart("Category Step Chart", (Plot)categoryPlot);
    categoryPlot.setAxisOffset(new RectangleInsets(5.0D, 5.0D, 5.0D, 5.0D));
    categoryPlot.setDomainGridlinesVisible(true);
    categoryPlot.setRangeGridlinesVisible(true);
    categoryAxis.setCategoryLabelPositions(CategoryLabelPositions.UP_45);
    categoryAxis.setLowerMargin(0.0D);
    categoryAxis.setUpperMargin(0.0D);
    categoryAxis.addCategoryLabelToolTip("Type 1", "The first type.");
    categoryAxis.addCategoryLabelToolTip("Type 2", "The second type.");
    categoryAxis.addCategoryLabelToolTip("Type 3", "The third type.");
    numberAxis.setStandardTickUnits(NumberAxis.createIntegerTickUnits());
    numberAxis.setLabelAngle(0.0D);
    ChartUtilities.applyCurrentTheme(jFreeChart);
    return jFreeChart;
  }
  
  public static JPanel createDemoPanel() {
    JFreeChart jFreeChart = createChart(createDataset());
    ChartPanel chartPanel = new ChartPanel(jFreeChart);
    chartPanel.setMouseWheelEnabled(true);
    return (JPanel)chartPanel;
  }
  
  public static void main(String[] paramArrayOfString) {
    CategoryStepChartDemo1 categoryStepChartDemo1 = new CategoryStepChartDemo1("JFreeChart : CategoryStepChartDemo1.java");
    categoryStepChartDemo1.pack();
    RefineryUtilities.centerFrameOnScreen((Window)categoryStepChartDemo1);
    categoryStepChartDemo1.setVisible(true);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/CategoryStepChartDemo1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */