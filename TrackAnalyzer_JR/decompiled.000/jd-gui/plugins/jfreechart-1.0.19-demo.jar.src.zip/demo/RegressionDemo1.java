package demo;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Window;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.Plot;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYItemRenderer;
import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
import org.jfree.data.function.Function2D;
import org.jfree.data.function.LineFunction2D;
import org.jfree.data.function.PowerFunction2D;
import org.jfree.data.general.DatasetUtilities;
import org.jfree.data.statistics.Regression;
import org.jfree.data.xy.XYDataset;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

public class RegressionDemo1 extends ApplicationFrame {
  public RegressionDemo1(String paramString) {
    super(paramString);
    JPanel jPanel = createDemoPanel();
    getContentPane().add(jPanel);
  }
  
  public static JPanel createDemoPanel() {
    return new MyDemoPanel();
  }
  
  public static void main(String[] paramArrayOfString) {
    RegressionDemo1 regressionDemo1 = new RegressionDemo1("JFreeChart: Regression Demo 1");
    regressionDemo1.pack();
    RefineryUtilities.centerFrameOnScreen((Window)regressionDemo1);
    regressionDemo1.setVisible(true);
  }
  
  static class MyDemoPanel extends DemoPanel {
    private XYDataset data1 = createSampleData1();
    
    public MyDemoPanel() {
      super(new BorderLayout());
      add(createContent());
    }
    
    private XYDataset createSampleData1() {
      XYSeries xYSeries = new XYSeries("Series 1");
      xYSeries.add(2.0D, 56.27D);
      xYSeries.add(3.0D, 41.32D);
      xYSeries.add(4.0D, 31.45D);
      xYSeries.add(5.0D, 30.05D);
      xYSeries.add(6.0D, 24.69D);
      xYSeries.add(7.0D, 19.78D);
      xYSeries.add(8.0D, 20.94D);
      xYSeries.add(9.0D, 16.73D);
      xYSeries.add(10.0D, 14.21D);
      xYSeries.add(11.0D, 12.44D);
      return (XYDataset)new XYSeriesCollection(xYSeries);
    }
    
    private JTabbedPane createContent() {
      JTabbedPane jTabbedPane = new JTabbedPane();
      jTabbedPane.add("Linear", (Component)createChartPanel1());
      jTabbedPane.add("Power", (Component)createChartPanel2());
      return jTabbedPane;
    }
    
    private ChartPanel createChartPanel1() {
      NumberAxis numberAxis1 = new NumberAxis("X");
      numberAxis1.setAutoRangeIncludesZero(false);
      NumberAxis numberAxis2 = new NumberAxis("Y");
      numberAxis2.setAutoRangeIncludesZero(false);
      XYLineAndShapeRenderer xYLineAndShapeRenderer1 = new XYLineAndShapeRenderer(false, true);
      XYPlot xYPlot = new XYPlot(this.data1, (ValueAxis)numberAxis1, (ValueAxis)numberAxis2, (XYItemRenderer)xYLineAndShapeRenderer1);
      double[] arrayOfDouble = Regression.getOLSRegression(this.data1, 0);
      LineFunction2D lineFunction2D = new LineFunction2D(arrayOfDouble[0], arrayOfDouble[1]);
      XYDataset xYDataset = DatasetUtilities.sampleFunction2D((Function2D)lineFunction2D, 2.0D, 11.0D, 100, "Fitted Regression Line");
      xYPlot.setDataset(1, xYDataset);
      XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new XYLineAndShapeRenderer(true, false);
      xYLineAndShapeRenderer2.setSeriesPaint(0, Color.blue);
      xYPlot.setRenderer(1, (XYItemRenderer)xYLineAndShapeRenderer2);
      JFreeChart jFreeChart = new JFreeChart("Linear Regression", JFreeChart.DEFAULT_TITLE_FONT, (Plot)xYPlot, true);
      ChartUtilities.applyCurrentTheme(jFreeChart);
      addChart(jFreeChart);
      return new ChartPanel(jFreeChart);
    }
    
    private ChartPanel createChartPanel2() {
      NumberAxis numberAxis1 = new NumberAxis("X");
      numberAxis1.setAutoRangeIncludesZero(false);
      NumberAxis numberAxis2 = new NumberAxis("Y");
      numberAxis2.setAutoRangeIncludesZero(false);
      XYLineAndShapeRenderer xYLineAndShapeRenderer1 = new XYLineAndShapeRenderer(false, true);
      XYPlot xYPlot = new XYPlot(this.data1, (ValueAxis)numberAxis1, (ValueAxis)numberAxis2, (XYItemRenderer)xYLineAndShapeRenderer1);
      double[] arrayOfDouble = Regression.getPowerRegression(this.data1, 0);
      PowerFunction2D powerFunction2D = new PowerFunction2D(arrayOfDouble[0], arrayOfDouble[1]);
      XYDataset xYDataset = DatasetUtilities.sampleFunction2D((Function2D)powerFunction2D, 2.0D, 11.0D, 100, "Fitted Regression Line");
      XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new XYLineAndShapeRenderer(true, false);
      xYLineAndShapeRenderer2.setSeriesPaint(0, Color.blue);
      xYPlot.setDataset(1, xYDataset);
      xYPlot.setRenderer(1, (XYItemRenderer)xYLineAndShapeRenderer2);
      JFreeChart jFreeChart = new JFreeChart("Power Regression", JFreeChart.DEFAULT_TITLE_FONT, (Plot)xYPlot, true);
      ChartUtilities.applyCurrentTheme(jFreeChart);
      addChart(jFreeChart);
      return new ChartPanel(jFreeChart);
    }
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/RegressionDemo1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */