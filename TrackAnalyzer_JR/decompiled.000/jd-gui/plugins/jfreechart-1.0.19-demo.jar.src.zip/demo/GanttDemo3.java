package demo;

import java.awt.Dimension;
import java.awt.Window;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import javax.swing.JPanel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.DateAxis;
import org.jfree.chart.labels.CategoryItemLabelGenerator;
import org.jfree.chart.labels.ItemLabelAnchor;
import org.jfree.chart.labels.ItemLabelPosition;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.renderer.category.GanttRenderer;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.IntervalCategoryDataset;
import org.jfree.data.gantt.Task;
import org.jfree.data.gantt.TaskSeries;
import org.jfree.data.gantt.TaskSeriesCollection;
import org.jfree.data.time.SimpleTimePeriod;
import org.jfree.data.time.TimePeriod;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;
import org.jfree.ui.TextAnchor;

public class GanttDemo3 extends ApplicationFrame {
  public GanttDemo3(String paramString) {
    super(paramString);
    JPanel jPanel = createDemoPanel();
    jPanel.setPreferredSize(new Dimension(500, 370));
    setContentPane(jPanel);
  }
  
  public static IntervalCategoryDataset createDataset() {
    TaskSeries taskSeries1 = new TaskSeries("Scheduled");
    taskSeries1.add(new Task("Write Proposal", (TimePeriod)new SimpleTimePeriod(date(1, 3, 2001), date(5, 3, 2001))));
    taskSeries1.add(new Task("Obtain Approval", (TimePeriod)new SimpleTimePeriod(date(9, 3, 2001), date(9, 3, 2001))));
    taskSeries1.add(new Task("Requirements Analysis", (TimePeriod)new SimpleTimePeriod(date(10, 3, 2001), date(5, 4, 2001))));
    taskSeries1.add(new Task("Design Phase", (TimePeriod)new SimpleTimePeriod(date(6, 4, 2001), date(30, 4, 2001))));
    taskSeries1.add(new Task("Design Signoff", (TimePeriod)new SimpleTimePeriod(date(2, 5, 2001), date(2, 5, 2001))));
    taskSeries1.add(new Task("Alpha Implementation", (TimePeriod)new SimpleTimePeriod(date(3, 5, 2001), date(31, 6, 2001))));
    taskSeries1.add(new Task("Design Review", (TimePeriod)new SimpleTimePeriod(date(1, 7, 2001), date(8, 7, 2001))));
    taskSeries1.add(new Task("Revised Design Signoff", (TimePeriod)new SimpleTimePeriod(date(10, 7, 2001), date(10, 7, 2001))));
    taskSeries1.add(new Task("Beta Implementation", (TimePeriod)new SimpleTimePeriod(date(12, 7, 2001), date(12, 8, 2001))));
    taskSeries1.add(new Task("Testing", (TimePeriod)new SimpleTimePeriod(date(13, 8, 2001), date(31, 9, 2001))));
    taskSeries1.add(new Task("Final Implementation", (TimePeriod)new SimpleTimePeriod(date(1, 10, 2001), date(15, 10, 2001))));
    taskSeries1.add(new Task("Signoff", (TimePeriod)new SimpleTimePeriod(date(28, 10, 2001), date(30, 10, 2001))));
    TaskSeries taskSeries2 = new TaskSeries("Actual");
    taskSeries2.add(new Task("Write Proposal", (TimePeriod)new SimpleTimePeriod(date(1, 3, 2001), date(5, 3, 2001))));
    taskSeries2.add(new Task("Obtain Approval", (TimePeriod)new SimpleTimePeriod(date(9, 3, 2001), date(9, 3, 2001))));
    taskSeries2.add(new Task("Requirements Analysis", (TimePeriod)new SimpleTimePeriod(date(10, 3, 2001), date(15, 4, 2001))));
    taskSeries2.add(new Task("Design Phase", (TimePeriod)new SimpleTimePeriod(date(15, 4, 2001), date(17, 5, 2001))));
    taskSeries2.add(new Task("Design Signoff", (TimePeriod)new SimpleTimePeriod(date(30, 5, 2001), date(30, 5, 2001))));
    taskSeries2.add(new Task("Alpha Implementation", (TimePeriod)new SimpleTimePeriod(date(1, 6, 2001), date(12, 8, 2001))));
    taskSeries2.add(new Task("Design Review", (TimePeriod)new SimpleTimePeriod(date(12, 8, 2001), date(22, 8, 2001))));
    taskSeries2.add(new Task("Revised Design Signoff", (TimePeriod)new SimpleTimePeriod(date(25, 8, 2001), date(27, 8, 2001))));
    taskSeries2.add(new Task("Beta Implementation", (TimePeriod)new SimpleTimePeriod(date(27, 8, 2001), date(30, 9, 2001))));
    taskSeries2.add(new Task("Testing", (TimePeriod)new SimpleTimePeriod(date(31, 9, 2001), date(17, 10, 2001))));
    taskSeries2.add(new Task("Final Implementation", (TimePeriod)new SimpleTimePeriod(date(18, 10, 2001), date(5, 11, 2001))));
    taskSeries2.add(new Task("Signoff", (TimePeriod)new SimpleTimePeriod(date(10, 11, 2001), date(11, 11, 2001))));
    TaskSeriesCollection taskSeriesCollection = new TaskSeriesCollection();
    taskSeriesCollection.add(taskSeries1);
    taskSeriesCollection.add(taskSeries2);
    return (IntervalCategoryDataset)taskSeriesCollection;
  }
  
  private static Date date(int paramInt1, int paramInt2, int paramInt3) {
    Calendar calendar = Calendar.getInstance();
    calendar.set(paramInt3, paramInt2, paramInt1);
    return calendar.getTime();
  }
  
  private static JFreeChart createChart(IntervalCategoryDataset paramIntervalCategoryDataset) {
    JFreeChart jFreeChart = ChartFactory.createGanttChart("Gantt Chart Demo", "Task", "Date", paramIntervalCategoryDataset);
    CategoryPlot categoryPlot = (CategoryPlot)jFreeChart.getPlot();
    categoryPlot.setRangePannable(true);
    categoryPlot.getDomainAxis().setMaximumCategoryLabelWidthRatio(10.0F);
    DateAxis dateAxis = (DateAxis)categoryPlot.getRangeAxis();
    dateAxis.setUpperMargin(0.2D);
    GanttRenderer ganttRenderer = (GanttRenderer)categoryPlot.getRenderer();
    ganttRenderer.setDrawBarOutline(false);
    ganttRenderer.setBaseItemLabelGenerator(new MyLabelGenerator(new SimpleDateFormat("d-MMM")));
    ganttRenderer.setBaseItemLabelsVisible(true);
    ganttRenderer.setBasePositiveItemLabelPosition(new ItemLabelPosition(ItemLabelAnchor.OUTSIDE3, TextAnchor.CENTER_LEFT));
    return jFreeChart;
  }
  
  public static JPanel createDemoPanel() {
    JFreeChart jFreeChart = createChart(createDataset());
    ChartPanel chartPanel = new ChartPanel(jFreeChart);
    chartPanel.setMouseWheelEnabled(true);
    return (JPanel)chartPanel;
  }
  
  public static void main(String[] paramArrayOfString) {
    GanttDemo3 ganttDemo3 = new GanttDemo3("JFreeChart: GanttDemo3.java");
    ganttDemo3.pack();
    RefineryUtilities.centerFrameOnScreen((Window)ganttDemo3);
    ganttDemo3.setVisible(true);
  }
  
  static class MyLabelGenerator implements CategoryItemLabelGenerator {
    DateFormat df;
    
    public MyLabelGenerator(DateFormat param1DateFormat) {
      this.df = param1DateFormat;
    }
    
    public String generateLabel(CategoryDataset param1CategoryDataset, int param1Int1, int param1Int2) {
      Number number;
      if (param1CategoryDataset instanceof IntervalCategoryDataset) {
        IntervalCategoryDataset intervalCategoryDataset = (IntervalCategoryDataset)param1CategoryDataset;
        number = intervalCategoryDataset.getEndValue(param1Int1, param1Int2);
      } else {
        number = param1CategoryDataset.getValue(param1Int1, param1Int2);
      } 
      if (number == null)
        return "null"; 
      long l = number.longValue();
      Date date = new Date(l);
      return this.df.format(date);
    }
    
    public String generateColumnLabel(CategoryDataset param1CategoryDataset, int param1Int) {
      return param1CategoryDataset.getColumnKey(param1Int).toString();
    }
    
    public String generateRowLabel(CategoryDataset param1CategoryDataset, int param1Int) {
      return param1CategoryDataset.getRowKey(param1Int).toString();
    }
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/GanttDemo3.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */