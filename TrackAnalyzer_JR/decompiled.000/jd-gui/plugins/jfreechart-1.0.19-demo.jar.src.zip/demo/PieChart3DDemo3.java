package demo;

import java.awt.Container;
import java.awt.Dimension;
import java.awt.Window;
import java.text.AttributedString;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.labels.PieSectionLabelGenerator;
import org.jfree.chart.plot.PiePlot3D;
import org.jfree.data.general.DefaultPieDataset;
import org.jfree.data.general.PieDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;
import org.jfree.util.Rotation;

public class PieChart3DDemo3 extends ApplicationFrame {
  public PieChart3DDemo3(String paramString) {
    super(paramString);
    PieDataset pieDataset = createDataset();
    JFreeChart jFreeChart = createChart(pieDataset);
    ChartPanel chartPanel = new ChartPanel(jFreeChart);
    chartPanel.setPreferredSize(new Dimension(500, 270));
    setContentPane((Container)chartPanel);
  }
  
  private static PieDataset createDataset() {
    DefaultPieDataset defaultPieDataset = new DefaultPieDataset();
    defaultPieDataset.setValue("Java", new Double(43.2D));
    defaultPieDataset.setValue("Visual Basic", new Double(10.0D));
    defaultPieDataset.setValue("C/C++", new Double(17.5D));
    defaultPieDataset.setValue("PHP", new Double(32.5D));
    defaultPieDataset.setValue("Perl", new Double(1.0D));
    return (PieDataset)defaultPieDataset;
  }
  
  private static JFreeChart createChart(PieDataset paramPieDataset) {
    JFreeChart jFreeChart = ChartFactory.createPieChart3D("Pie Chart 3D Demo 3", paramPieDataset, true, true, false);
    PiePlot3D piePlot3D = (PiePlot3D)jFreeChart.getPlot();
    piePlot3D.setStartAngle(290.0D);
    piePlot3D.setDirection(Rotation.CLOCKWISE);
    piePlot3D.setForegroundAlpha(0.5F);
    piePlot3D.setNoDataMessage("No data to display");
    piePlot3D.setLabelGenerator(new CustomLabelGenerator());
    return jFreeChart;
  }
  
  public static ChartPanel createDemoPanel() {
    JFreeChart jFreeChart = createChart(createDataset());
    ChartPanel chartPanel = new ChartPanel(jFreeChart);
    chartPanel.setMouseWheelEnabled(true);
    return chartPanel;
  }
  
  public static void main(String[] paramArrayOfString) {
    PieChart3DDemo3 pieChart3DDemo3 = new PieChart3DDemo3("JFreeChart: PieChart3DDemo3.java");
    pieChart3DDemo3.pack();
    RefineryUtilities.centerFrameOnScreen((Window)pieChart3DDemo3);
    pieChart3DDemo3.setVisible(true);
  }
  
  static class CustomLabelGenerator implements PieSectionLabelGenerator {
    public String generateSectionLabel(PieDataset param1PieDataset, Comparable param1Comparable) {
      String str = null;
      if (param1PieDataset != null && !param1Comparable.equals("PHP"))
        str = param1Comparable.toString(); 
      return str;
    }
    
    public AttributedString generateAttributedSectionLabel(PieDataset param1PieDataset, Comparable param1Comparable) {
      return null;
    }
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/PieChart3DDemo3.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */