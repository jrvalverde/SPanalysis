package demo;

import java.awt.GradientPaint;
import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.geom.Arc2D;
import java.awt.geom.Ellipse2D;
import java.awt.geom.GeneralPath;
import java.awt.geom.Rectangle2D;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.entity.CategoryItemEntity;
import org.jfree.chart.entity.ChartEntity;
import org.jfree.chart.entity.EntityCollection;
import org.jfree.chart.labels.CategoryItemLabelGenerator;
import org.jfree.chart.labels.CategoryToolTipGenerator;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.renderer.category.BarRenderer3D;
import org.jfree.chart.renderer.category.CategoryItemRendererState;
import org.jfree.data.category.CategoryDataset;
import org.jfree.ui.RectangleEdge;

public class CylinderRenderer extends BarRenderer3D {
  public CylinderRenderer() {}
  
  public CylinderRenderer(double paramDouble1, double paramDouble2) {
    super(paramDouble1, paramDouble2);
  }
  
  public void drawItem(Graphics2D paramGraphics2D, CategoryItemRendererState paramCategoryItemRendererState, Rectangle2D paramRectangle2D, CategoryPlot paramCategoryPlot, CategoryAxis paramCategoryAxis, ValueAxis paramValueAxis, CategoryDataset paramCategoryDataset, int paramInt1, int paramInt2, int paramInt3) {
    Number number = paramCategoryDataset.getValue(paramInt1, paramInt2);
    if (number == null)
      return; 
    double d1 = number.doubleValue();
    Rectangle2D.Double double_ = new Rectangle2D.Double(paramRectangle2D.getX(), paramRectangle2D.getY() + getYOffset(), paramRectangle2D.getWidth() - getXOffset(), paramRectangle2D.getHeight() - getYOffset());
    PlotOrientation plotOrientation = paramCategoryPlot.getOrientation();
    double d2 = calculateBarW0(paramCategoryPlot, plotOrientation, double_, paramCategoryAxis, paramCategoryItemRendererState, paramInt1, paramInt2);
    double[] arrayOfDouble = calculateBarL0L1(d1);
    if (arrayOfDouble == null)
      return; 
    RectangleEdge rectangleEdge = paramCategoryPlot.getRangeAxisEdge();
    float f1 = (float)paramValueAxis.valueToJava2D(arrayOfDouble[0], double_, rectangleEdge);
    float f2 = (float)paramValueAxis.valueToJava2D(arrayOfDouble[1], double_, rectangleEdge);
    float f3 = Math.min(f1, f2);
    float f4 = Math.abs(f2 - f1);
    GeneralPath generalPath = new GeneralPath();
    Ellipse2D.Double double_1 = null;
    if (plotOrientation == PlotOrientation.HORIZONTAL) {
      generalPath.moveTo((float)(f3 + getXOffset() / 2.0D), (float)d2);
      generalPath.lineTo((float)((f3 + f4) + getXOffset() / 2.0D), (float)d2);
      Arc2D.Double double_2 = new Arc2D.Double((f3 + f4), d2, getXOffset(), paramCategoryItemRendererState.getBarWidth(), 90.0D, 180.0D, 0);
      generalPath.append(double_2, true);
      generalPath.lineTo((float)(f3 + getXOffset() / 2.0D), (float)(d2 + paramCategoryItemRendererState.getBarWidth()));
      double_2 = new Arc2D.Double(f3, d2, getXOffset(), paramCategoryItemRendererState.getBarWidth(), 270.0D, -180.0D, 0);
      generalPath.append(double_2, true);
      generalPath.closePath();
      double_1 = new Ellipse2D.Double((f3 + f4), d2, getXOffset(), paramCategoryItemRendererState.getBarWidth());
    } else {
      generalPath.moveTo((float)d2, (float)(f3 - getYOffset() / 2.0D));
      generalPath.lineTo((float)d2, (float)((f3 + f4) - getYOffset() / 2.0D));
      Arc2D.Double double_2 = new Arc2D.Double(d2, (f3 + f4) - getYOffset(), paramCategoryItemRendererState.getBarWidth(), getYOffset(), 180.0D, 180.0D, 0);
      generalPath.append(double_2, true);
      generalPath.lineTo((float)(d2 + paramCategoryItemRendererState.getBarWidth()), (float)(f3 - getYOffset() / 2.0D));
      double_2 = new Arc2D.Double(d2, f3 - getYOffset(), paramCategoryItemRendererState.getBarWidth(), getYOffset(), 0.0D, -180.0D, 0);
      generalPath.append(double_2, true);
      generalPath.closePath();
      double_1 = new Ellipse2D.Double(d2, f3 - getYOffset(), paramCategoryItemRendererState.getBarWidth(), getYOffset());
    } 
    Paint paint = getItemPaint(paramInt1, paramInt2);
    if (getGradientPaintTransformer() != null && paint instanceof GradientPaint) {
      GradientPaint gradientPaint = (GradientPaint)paint;
      paint = getGradientPaintTransformer().transform(gradientPaint, generalPath);
    } 
    paramGraphics2D.setPaint(paint);
    paramGraphics2D.fill(generalPath);
    if (paint instanceof GradientPaint)
      paramGraphics2D.setPaint(((GradientPaint)paint).getColor2()); 
    if (double_1 != null)
      paramGraphics2D.fill(double_1); 
    if (isDrawBarOutline() && paramCategoryItemRendererState.getBarWidth() > 3.0D) {
      paramGraphics2D.setStroke(getItemOutlineStroke(paramInt1, paramInt2));
      paramGraphics2D.setPaint(getItemOutlinePaint(paramInt1, paramInt2));
      paramGraphics2D.draw(generalPath);
      if (double_1 != null)
        paramGraphics2D.draw(double_1); 
    } 
    CategoryItemLabelGenerator categoryItemLabelGenerator = getItemLabelGenerator(paramInt1, paramInt2);
    if (categoryItemLabelGenerator != null && isItemLabelVisible(paramInt1, paramInt2))
      drawItemLabel(paramGraphics2D, paramCategoryDataset, paramInt1, paramInt2, paramCategoryPlot, categoryItemLabelGenerator, generalPath.getBounds2D(), (d1 < 0.0D)); 
    if (paramCategoryItemRendererState.getInfo() != null) {
      EntityCollection entityCollection = paramCategoryItemRendererState.getEntityCollection();
      if (entityCollection != null) {
        String str1 = null;
        CategoryToolTipGenerator categoryToolTipGenerator = getToolTipGenerator(paramInt1, paramInt2);
        if (categoryToolTipGenerator != null)
          str1 = categoryToolTipGenerator.generateToolTip(paramCategoryDataset, paramInt1, paramInt2); 
        String str2 = null;
        if (getItemURLGenerator(paramInt1, paramInt2) != null)
          str2 = getItemURLGenerator(paramInt1, paramInt2).generateURL(paramCategoryDataset, paramInt1, paramInt2); 
        CategoryItemEntity categoryItemEntity = new CategoryItemEntity(generalPath.getBounds2D(), str1, str2, paramCategoryDataset, paramCategoryDataset.getRowKey(paramInt1), paramCategoryDataset.getColumnKey(paramInt2));
        entityCollection.add((ChartEntity)categoryItemEntity);
      } 
    } 
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/CylinderRenderer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */