package demo;

import java.awt.Container;
import java.awt.Dimension;
import java.awt.Window;
import javax.swing.JPanel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.labels.PieSectionLabelGenerator;
import org.jfree.chart.labels.StandardPieSectionLabelGenerator;
import org.jfree.chart.plot.MultiplePiePlot;
import org.jfree.chart.plot.PiePlot;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;
import org.jfree.util.TableOrder;

public class MultiplePieChartDemo4 extends ApplicationFrame {
  public MultiplePieChartDemo4(String paramString) {
    super(paramString);
    CategoryDataset categoryDataset = createDataset();
    JFreeChart jFreeChart = createChart(categoryDataset);
    ChartPanel chartPanel = new ChartPanel(jFreeChart, true, true, true, false, true);
    chartPanel.setPreferredSize(new Dimension(600, 380));
    setContentPane((Container)chartPanel);
  }
  
  private static CategoryDataset createDataset() {
    DefaultCategoryDataset defaultCategoryDataset = new DefaultCategoryDataset();
    defaultCategoryDataset.addValue(5.6D, "Row 0", "Column 0");
    defaultCategoryDataset.addValue(3.2D, "Row 0", "Column 1");
    defaultCategoryDataset.addValue(1.8D, "Row 0", "Column 2");
    defaultCategoryDataset.addValue(0.2D, "Row 0", "Column 3");
    defaultCategoryDataset.addValue(4.1D, "Row 0", "Column 4");
    defaultCategoryDataset.addValue(9.8D, "Row 1", "Column 0");
    defaultCategoryDataset.addValue(6.3D, "Row 1", "Column 1");
    defaultCategoryDataset.addValue(0.1D, "Row 1", "Column 2");
    defaultCategoryDataset.addValue(1.9D, "Row 1", "Column 3");
    defaultCategoryDataset.addValue(9.6D, "Row 1", "Column 4");
    defaultCategoryDataset.addValue(7.0D, "Row 2", "Column 0");
    defaultCategoryDataset.addValue(5.2D, "Row 2", "Column 1");
    defaultCategoryDataset.addValue(2.8D, "Row 2", "Column 2");
    defaultCategoryDataset.addValue(8.8D, "Row 2", "Column 3");
    defaultCategoryDataset.addValue(7.2D, "Row 2", "Column 4");
    defaultCategoryDataset.addValue(9.5D, "Row 3", "Column 0");
    defaultCategoryDataset.addValue(1.2D, "Row 3", "Column 1");
    defaultCategoryDataset.addValue(4.5D, "Row 3", "Column 2");
    defaultCategoryDataset.addValue(4.4D, "Row 3", "Column 3");
    defaultCategoryDataset.addValue(0.2D, "Row 3", "Column 4");
    defaultCategoryDataset.addValue(3.5D, "Row 4", "Column 0");
    defaultCategoryDataset.addValue(6.7D, "Row 4", "Column 1");
    defaultCategoryDataset.addValue(9.0D, "Row 4", "Column 2");
    defaultCategoryDataset.addValue(1.0D, "Row 4", "Column 3");
    defaultCategoryDataset.addValue(5.2D, "Row 4", "Column 4");
    defaultCategoryDataset.addValue(5.1D, "Row 5", "Column 0");
    defaultCategoryDataset.addValue(6.7D, "Row 5", "Column 1");
    defaultCategoryDataset.addValue(0.9D, "Row 5", "Column 2");
    defaultCategoryDataset.addValue(3.3D, "Row 5", "Column 3");
    defaultCategoryDataset.addValue(3.9D, "Row 5", "Column 4");
    defaultCategoryDataset.addValue(5.6D, "Row 6", "Column 0");
    defaultCategoryDataset.addValue(5.6D, "Row 6", "Column 1");
    defaultCategoryDataset.addValue(5.6D, "Row 6", "Column 2");
    defaultCategoryDataset.addValue(5.6D, "Row 6", "Column 3");
    defaultCategoryDataset.addValue(5.6D, "Row 6", "Column 4");
    defaultCategoryDataset.addValue(7.5D, "Row 7", "Column 0");
    defaultCategoryDataset.addValue(9.0D, "Row 7", "Column 1");
    defaultCategoryDataset.addValue(3.4D, "Row 7", "Column 2");
    defaultCategoryDataset.addValue(4.1D, "Row 7", "Column 3");
    defaultCategoryDataset.addValue(0.5D, "Row 7", "Column 4");
    return (CategoryDataset)defaultCategoryDataset;
  }
  
  private static JFreeChart createChart(CategoryDataset paramCategoryDataset) {
    JFreeChart jFreeChart1 = ChartFactory.createMultiplePieChart3D("Multiple Pie Chart Demo 4", paramCategoryDataset, TableOrder.BY_COLUMN, false, true, false);
    MultiplePiePlot multiplePiePlot = (MultiplePiePlot)jFreeChart1.getPlot();
    multiplePiePlot.setLimit(0.1D);
    JFreeChart jFreeChart2 = multiplePiePlot.getPieChart();
    PiePlot piePlot = (PiePlot)jFreeChart2.getPlot();
    piePlot.setIgnoreNullValues(true);
    piePlot.setLabelGenerator((PieSectionLabelGenerator)new StandardPieSectionLabelGenerator("{0}"));
    piePlot.setMaximumLabelWidth(0.2D);
    return jFreeChart1;
  }
  
  public static JPanel createDemoPanel() {
    JFreeChart jFreeChart = createChart(createDataset());
    return (JPanel)new ChartPanel(jFreeChart);
  }
  
  public static void main(String[] paramArrayOfString) {
    MultiplePieChartDemo4 multiplePieChartDemo4 = new MultiplePieChartDemo4("JFreeChart: MultiplePieChartDemo4.java");
    multiplePieChartDemo4.pack();
    RefineryUtilities.centerFrameOnScreen((Window)multiplePieChartDemo4);
    multiplePieChartDemo4.setVisible(true);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/MultiplePieChartDemo4.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */