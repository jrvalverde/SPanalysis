package demo;

import java.awt.BasicStroke;
import java.awt.Dimension;
import java.awt.Window;
import javax.swing.JPanel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.LogAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.data.xy.XYDataset;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

public class LogAxisDemo1 extends ApplicationFrame {
  public LogAxisDemo1(String paramString) {
    super(paramString);
    JPanel jPanel = createDemoPanel();
    jPanel.setPreferredSize(new Dimension(500, 270));
    setContentPane(jPanel);
  }
  
  private static JFreeChart createChart(XYDataset paramXYDataset) {
    JFreeChart jFreeChart = ChartFactory.createScatterPlot("Log Axis Demo 1", "X", "Y", paramXYDataset, PlotOrientation.VERTICAL, true, true, false);
    XYPlot xYPlot = (XYPlot)jFreeChart.getPlot();
    xYPlot.setDomainPannable(true);
    xYPlot.setRangePannable(true);
    xYPlot.setDomainGridlineStroke(new BasicStroke(1.0F));
    xYPlot.setRangeGridlineStroke(new BasicStroke(1.0F));
    xYPlot.setDomainMinorGridlinesVisible(true);
    xYPlot.setRangeMinorGridlinesVisible(true);
    xYPlot.setDomainMinorGridlineStroke(new BasicStroke(0.1F));
    xYPlot.setRangeMinorGridlineStroke(new BasicStroke(0.1F));
    LogAxis logAxis1 = new LogAxis("X");
    LogAxis logAxis2 = new LogAxis("Y");
    xYPlot.setDomainAxis((ValueAxis)logAxis1);
    xYPlot.setRangeAxis((ValueAxis)logAxis2);
    ChartUtilities.applyCurrentTheme(jFreeChart);
    return jFreeChart;
  }
  
  private static XYDataset createDataset() {
    XYSeries xYSeries = new XYSeries("Random Data");
    xYSeries.add(1.0D, 500.2D);
    xYSeries.add(5.0D, 694.1D);
    xYSeries.add(4.0D, 100.0D);
    xYSeries.add(12.5D, 734.4D);
    xYSeries.add(17.3D, 453.2D);
    xYSeries.add(21.2D, 500.2D);
    xYSeries.add(21.9D, 9005.5D);
    xYSeries.add(25.6D, 734.4D);
    xYSeries.add(6663000.0D, 6453.2D);
    return (XYDataset)new XYSeriesCollection(xYSeries);
  }
  
  public static JPanel createDemoPanel() {
    JFreeChart jFreeChart = createChart(createDataset());
    ChartPanel chartPanel = new ChartPanel(jFreeChart);
    chartPanel.setMouseWheelEnabled(true);
    return (JPanel)chartPanel;
  }
  
  public static void main(String[] paramArrayOfString) {
    LogAxisDemo1 logAxisDemo1 = new LogAxisDemo1("JFreeChart: LogAxisDemo1.java");
    logAxisDemo1.pack();
    RefineryUtilities.centerFrameOnScreen((Window)logAxisDemo1);
    logAxisDemo1.setVisible(true);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/LogAxisDemo1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */