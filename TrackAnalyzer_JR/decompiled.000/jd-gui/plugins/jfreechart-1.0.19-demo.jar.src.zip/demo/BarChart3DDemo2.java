package demo;

import java.awt.Dimension;
import java.awt.Window;
import javax.swing.JPanel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.CategoryLabelPosition;
import org.jfree.chart.axis.CategoryLabelPositions;
import org.jfree.chart.axis.CategoryLabelWidthType;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.text.TextBlockAnchor;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RectangleAnchor;
import org.jfree.ui.RefineryUtilities;
import org.jfree.ui.TextAnchor;
import org.jfree.util.SortOrder;

public class BarChart3DDemo2 extends ApplicationFrame {
  public BarChart3DDemo2(String paramString) {
    super(paramString);
    JPanel jPanel = createDemoPanel();
    jPanel.setPreferredSize(new Dimension(500, 270));
    setContentPane(jPanel);
  }
  
  private static CategoryDataset createDataset() {
    DefaultCategoryDataset defaultCategoryDataset = new DefaultCategoryDataset();
    defaultCategoryDataset.addValue(23.0D, "Series 1", "London");
    defaultCategoryDataset.addValue(14.0D, "Series 1", "New York");
    defaultCategoryDataset.addValue(14.0D, "Series 1", "Istanbul");
    defaultCategoryDataset.addValue(14.0D, "Series 1", "Cairo");
    defaultCategoryDataset.addValue(13.0D, "Series 2", "London");
    defaultCategoryDataset.addValue(19.0D, "Series 2", "New York");
    defaultCategoryDataset.addValue(19.0D, "Series 2", "Istanbul");
    defaultCategoryDataset.addValue(19.0D, "Series 2", "Cairo");
    defaultCategoryDataset.addValue(7.0D, "Series 3", "London");
    defaultCategoryDataset.addValue(9.0D, "Series 3", "New York");
    defaultCategoryDataset.addValue(9.0D, "Series 3", "Istanbul");
    defaultCategoryDataset.addValue(9.0D, "Series 3", "Cairo");
    return (CategoryDataset)defaultCategoryDataset;
  }
  
  private static JFreeChart createChart(CategoryDataset paramCategoryDataset) {
    JFreeChart jFreeChart = ChartFactory.createBarChart3D("3D Bar Chart Demo 2", "Category", "Value", paramCategoryDataset);
    CategoryPlot categoryPlot = (CategoryPlot)jFreeChart.getPlot();
    categoryPlot.setOrientation(PlotOrientation.HORIZONTAL);
    categoryPlot.setRowRenderingOrder(SortOrder.DESCENDING);
    categoryPlot.setColumnRenderingOrder(SortOrder.DESCENDING);
    categoryPlot.setForegroundAlpha(1.0F);
    categoryPlot.setRangePannable(true);
    CategoryAxis categoryAxis = categoryPlot.getDomainAxis();
    CategoryLabelPositions categoryLabelPositions = categoryAxis.getCategoryLabelPositions();
    CategoryLabelPosition categoryLabelPosition = new CategoryLabelPosition(RectangleAnchor.LEFT, TextBlockAnchor.CENTER_LEFT, TextAnchor.CENTER_LEFT, 0.0D, CategoryLabelWidthType.RANGE, 0.3F);
    categoryAxis.setCategoryLabelPositions(CategoryLabelPositions.replaceLeftPosition(categoryLabelPositions, categoryLabelPosition));
    return jFreeChart;
  }
  
  public static JPanel createDemoPanel() {
    JFreeChart jFreeChart = createChart(createDataset());
    ChartPanel chartPanel = new ChartPanel(jFreeChart);
    chartPanel.setMouseWheelEnabled(true);
    return (JPanel)chartPanel;
  }
  
  public static void main(String[] paramArrayOfString) {
    BarChart3DDemo2 barChart3DDemo2 = new BarChart3DDemo2("JFreeChart: BarChart3DDemo2.java");
    barChart3DDemo2.pack();
    RefineryUtilities.centerFrameOnScreen((Window)barChart3DDemo2);
    barChart3DDemo2.setVisible(true);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/BarChart3DDemo2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */