package demo;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Window;
import java.text.SimpleDateFormat;
import java.util.TimeZone;
import javax.swing.JPanel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.PeriodAxis;
import org.jfree.chart.axis.PeriodAxisLabelInfo;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYItemRenderer;
import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
import org.jfree.data.time.Day;
import org.jfree.data.time.Month;
import org.jfree.data.time.RegularTimePeriod;
import org.jfree.data.time.TimePeriodAnchor;
import org.jfree.data.time.TimeSeries;
import org.jfree.data.time.TimeSeriesCollection;
import org.jfree.data.time.Year;
import org.jfree.data.xy.XYDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RectangleInsets;
import org.jfree.ui.RefineryUtilities;

public class PeriodAxisDemo2 extends ApplicationFrame {
  public PeriodAxisDemo2(String paramString) {
    super(paramString);
    XYDataset xYDataset = createDataset();
    JFreeChart jFreeChart = createChart(xYDataset);
    ChartPanel chartPanel = new ChartPanel(jFreeChart);
    chartPanel.setPreferredSize(new Dimension(500, 270));
    chartPanel.setMouseZoomable(true, true);
    setContentPane((Container)chartPanel);
  }
  
  private static JFreeChart createChart(XYDataset paramXYDataset) {
    JFreeChart jFreeChart = ChartFactory.createTimeSeriesChart("Legal & General Unit Trust Prices", "Date", "Price Per Unit", paramXYDataset, true, true, false);
    XYPlot xYPlot = (XYPlot)jFreeChart.getPlot();
    xYPlot.setDomainCrosshairVisible(true);
    xYPlot.setRangeCrosshairVisible(true);
    XYItemRenderer xYItemRenderer = xYPlot.getRenderer();
    if (xYItemRenderer instanceof XYLineAndShapeRenderer) {
      XYLineAndShapeRenderer xYLineAndShapeRenderer = (XYLineAndShapeRenderer)xYItemRenderer;
      xYLineAndShapeRenderer.setBaseShapesVisible(true);
      xYLineAndShapeRenderer.setBaseShapesFilled(true);
      xYLineAndShapeRenderer.setBaseItemLabelsVisible(true);
    } 
    PeriodAxis periodAxis = new PeriodAxis("Date");
    periodAxis.setTimeZone(TimeZone.getTimeZone("Pacific/Auckland"));
    periodAxis.setAutoRangeTimePeriodClass(Day.class);
    PeriodAxisLabelInfo[] arrayOfPeriodAxisLabelInfo = new PeriodAxisLabelInfo[3];
    arrayOfPeriodAxisLabelInfo[0] = new PeriodAxisLabelInfo(Day.class, new SimpleDateFormat("d"));
    arrayOfPeriodAxisLabelInfo[1] = new PeriodAxisLabelInfo(Month.class, new SimpleDateFormat("MMM"), new RectangleInsets(2.0D, 2.0D, 2.0D, 2.0D), new Font("SansSerif", 1, 10), Color.blue, false, new BasicStroke(0.0F), Color.lightGray);
    arrayOfPeriodAxisLabelInfo[2] = new PeriodAxisLabelInfo(Year.class, new SimpleDateFormat("yyyy"));
    periodAxis.setLabelInfo(arrayOfPeriodAxisLabelInfo);
    xYPlot.setDomainAxis((ValueAxis)periodAxis);
    ChartUtilities.applyCurrentTheme(jFreeChart);
    return jFreeChart;
  }
  
  private static XYDataset createDataset() {
    TimeSeries timeSeries = new TimeSeries("L&G European Index Trust");
    timeSeries.add((RegularTimePeriod)new Day(24, 1, 2004), 181.8D);
    timeSeries.add((RegularTimePeriod)new Day(25, 1, 2004), 167.3D);
    timeSeries.add((RegularTimePeriod)new Day(26, 1, 2004), 153.8D);
    timeSeries.add((RegularTimePeriod)new Day(27, 1, 2004), 167.6D);
    timeSeries.add((RegularTimePeriod)new Day(28, 1, 2004), 158.8D);
    timeSeries.add((RegularTimePeriod)new Day(29, 1, 2004), 148.3D);
    timeSeries.add((RegularTimePeriod)new Day(30, 1, 2004), 153.9D);
    timeSeries.add((RegularTimePeriod)new Day(31, 1, 2004), 142.7D);
    timeSeries.add((RegularTimePeriod)new Day(1, 2, 2004), 123.2D);
    timeSeries.add((RegularTimePeriod)new Day(2, 2, 2004), 131.8D);
    timeSeries.add((RegularTimePeriod)new Day(3, 2, 2004), 139.6D);
    timeSeries.add((RegularTimePeriod)new Day(4, 2, 2004), 142.9D);
    timeSeries.add((RegularTimePeriod)new Day(5, 2, 2004), 138.7D);
    timeSeries.add((RegularTimePeriod)new Day(6, 2, 2004), 137.3D);
    timeSeries.add((RegularTimePeriod)new Day(7, 2, 2004), 143.9D);
    timeSeries.add((RegularTimePeriod)new Day(8, 2, 2004), 139.8D);
    timeSeries.add((RegularTimePeriod)new Day(9, 2, 2004), 137.0D);
    timeSeries.add((RegularTimePeriod)new Day(10, 2, 2004), 132.8D);
    TimeZone timeZone = TimeZone.getTimeZone("Pacific/Auckland");
    TimeSeriesCollection timeSeriesCollection = new TimeSeriesCollection(timeZone);
    timeSeriesCollection.addSeries(timeSeries);
    timeSeriesCollection.setXPosition(TimePeriodAnchor.MIDDLE);
    return (XYDataset)timeSeriesCollection;
  }
  
  public static JPanel createDemoPanel() {
    JFreeChart jFreeChart = createChart(createDataset());
    return (JPanel)new ChartPanel(jFreeChart);
  }
  
  public static void main(String[] paramArrayOfString) {
    PeriodAxisDemo2 periodAxisDemo2 = new PeriodAxisDemo2("JFreeChart: PeriodAxisDemo2.java");
    periodAxisDemo2.pack();
    RefineryUtilities.centerFrameOnScreen((Window)periodAxisDemo2);
    periodAxisDemo2.setVisible(true);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/PeriodAxisDemo2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */