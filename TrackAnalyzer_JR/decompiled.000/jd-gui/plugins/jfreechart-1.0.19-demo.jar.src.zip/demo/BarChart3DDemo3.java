package demo;

import java.awt.Dimension;
import java.awt.Window;
import javax.swing.JPanel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.CategoryLabelPositions;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.renderer.category.BarRenderer;
import org.jfree.chart.renderer.category.CategoryItemRenderer;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

public class BarChart3DDemo3 extends ApplicationFrame {
  public BarChart3DDemo3(String paramString) {
    super(paramString);
    JPanel jPanel = createDemoPanel();
    jPanel.setPreferredSize(new Dimension(500, 270));
    setContentPane(jPanel);
  }
  
  private static CategoryDataset createDataset() {
    DefaultCategoryDataset defaultCategoryDataset = new DefaultCategoryDataset();
    defaultCategoryDataset.addValue(25.0D, "Series 1", "Category 1");
    defaultCategoryDataset.addValue(34.0D, "Series 1", "Category 2");
    defaultCategoryDataset.addValue(19.0D, "Series 2", "Category 1");
    defaultCategoryDataset.addValue(29.0D, "Series 2", "Category 2");
    defaultCategoryDataset.addValue(41.0D, "Series 3", "Category 1");
    defaultCategoryDataset.addValue(33.0D, "Series 3", "Category 2");
    return (CategoryDataset)defaultCategoryDataset;
  }
  
  private static JFreeChart createChart(CategoryDataset paramCategoryDataset) {
    JFreeChart jFreeChart = ChartFactory.createBarChart3D("3D Bar Chart Demo", "Category", "Value", paramCategoryDataset);
    CategoryPlot categoryPlot = (CategoryPlot)jFreeChart.getPlot();
    CategoryAxis categoryAxis = categoryPlot.getDomainAxis();
    categoryAxis.setCategoryLabelPositions(CategoryLabelPositions.createUpRotationLabelPositions(0.39269908169872414D));
    CategoryItemRenderer categoryItemRenderer = categoryPlot.getRenderer();
    categoryItemRenderer.setBaseItemLabelsVisible(true);
    BarRenderer barRenderer = (BarRenderer)categoryItemRenderer;
    barRenderer.setItemMargin(0.2D);
    return jFreeChart;
  }
  
  public static JPanel createDemoPanel() {
    JFreeChart jFreeChart = createChart(createDataset());
    return (JPanel)new ChartPanel(jFreeChart);
  }
  
  public static void main(String[] paramArrayOfString) {
    BarChart3DDemo3 barChart3DDemo3 = new BarChart3DDemo3("JFreeChart: BarChart3DDemo3.java");
    barChart3DDemo3.pack();
    RefineryUtilities.centerFrameOnScreen((Window)barChart3DDemo3);
    barChart3DDemo3.setVisible(true);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/BarChart3DDemo3.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */