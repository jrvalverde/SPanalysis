package demo;

import java.awt.Dimension;
import java.awt.Window;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JPanel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.data.statistics.BoxAndWhiskerCategoryDataset;
import org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

public class BoxAndWhiskerChartDemo1 extends ApplicationFrame {
  public BoxAndWhiskerChartDemo1(String paramString) {
    super(paramString);
    JPanel jPanel = createDemoPanel();
    jPanel.setPreferredSize(new Dimension(500, 270));
    setContentPane(jPanel);
  }
  
  private static BoxAndWhiskerCategoryDataset createDataset() {
    byte b1 = 3;
    byte b2 = 5;
    byte b3 = 20;
    DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset = new DefaultBoxAndWhiskerCategoryDataset();
    for (byte b4 = 0; b4 < b1; b4++) {
      for (byte b = 0; b < b2; b++) {
        List list = createValueList(0.0D, 20.0D, b3);
        defaultBoxAndWhiskerCategoryDataset.add(list, "Series " + b4, "Category " + b);
      } 
    } 
    return (BoxAndWhiskerCategoryDataset)defaultBoxAndWhiskerCategoryDataset;
  }
  
  private static List createValueList(double paramDouble1, double paramDouble2, int paramInt) {
    ArrayList<Double> arrayList = new ArrayList();
    for (byte b = 0; b < paramInt; b++) {
      double d = paramDouble1 + Math.random() * (paramDouble2 - paramDouble1);
      arrayList.add(new Double(d));
    } 
    return arrayList;
  }
  
  private static JFreeChart createChart(BoxAndWhiskerCategoryDataset paramBoxAndWhiskerCategoryDataset) {
    JFreeChart jFreeChart = ChartFactory.createBoxAndWhiskerChart("Box and Whisker Chart Demo 1", "Category", "Value", paramBoxAndWhiskerCategoryDataset, true);
    CategoryPlot categoryPlot = (CategoryPlot)jFreeChart.getPlot();
    categoryPlot.setDomainGridlinesVisible(true);
    categoryPlot.setRangePannable(true);
    NumberAxis numberAxis = (NumberAxis)categoryPlot.getRangeAxis();
    numberAxis.setStandardTickUnits(NumberAxis.createIntegerTickUnits());
    return jFreeChart;
  }
  
  public static JPanel createDemoPanel() {
    JFreeChart jFreeChart = createChart(createDataset());
    ChartPanel chartPanel = new ChartPanel(jFreeChart);
    chartPanel.setMouseWheelEnabled(true);
    return (JPanel)chartPanel;
  }
  
  public static void main(String[] paramArrayOfString) {
    BoxAndWhiskerChartDemo1 boxAndWhiskerChartDemo1 = new BoxAndWhiskerChartDemo1("JFreeChart: BoxAndWhiskerChartDemo1.java");
    boxAndWhiskerChartDemo1.pack();
    RefineryUtilities.centerFrameOnScreen((Window)boxAndWhiskerChartDemo1);
    boxAndWhiskerChartDemo1.setVisible(true);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/BoxAndWhiskerChartDemo1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */