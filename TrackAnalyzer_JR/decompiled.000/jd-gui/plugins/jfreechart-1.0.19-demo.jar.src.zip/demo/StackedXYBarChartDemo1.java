package demo;

import java.awt.Dimension;
import java.awt.Window;
import javax.swing.JPanel;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.Plot;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.StackedXYBarRenderer;
import org.jfree.chart.renderer.xy.XYItemRenderer;
import org.jfree.data.xy.DefaultTableXYDataset;
import org.jfree.data.xy.TableXYDataset;
import org.jfree.data.xy.XYDataset;
import org.jfree.data.xy.XYSeries;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

public class StackedXYBarChartDemo1 extends ApplicationFrame {
  public StackedXYBarChartDemo1(String paramString) {
    super(paramString);
    JPanel jPanel = createDemoPanel();
    jPanel.setPreferredSize(new Dimension(500, 270));
    setContentPane(jPanel);
  }
  
  private static TableXYDataset createDataset() {
    DefaultTableXYDataset defaultTableXYDataset = new DefaultTableXYDataset();
    XYSeries xYSeries1 = new XYSeries("Series 1", true, false);
    xYSeries1.add(1.0D, 5.0D);
    xYSeries1.add(2.0D, 15.5D);
    xYSeries1.add(3.0D, 9.5D);
    xYSeries1.add(4.0D, 7.5D);
    defaultTableXYDataset.addSeries(xYSeries1);
    XYSeries xYSeries2 = new XYSeries("Series 2", true, false);
    xYSeries2.add(1.0D, 5.0D);
    xYSeries2.add(2.0D, 15.5D);
    xYSeries2.add(3.0D, 9.5D);
    xYSeries2.add(4.0D, 3.5D);
    defaultTableXYDataset.addSeries(xYSeries2);
    return (TableXYDataset)defaultTableXYDataset;
  }
  
  private static JFreeChart createChart(TableXYDataset paramTableXYDataset) {
    NumberAxis numberAxis1 = new NumberAxis("X");
    numberAxis1.setStandardTickUnits(NumberAxis.createIntegerTickUnits());
    NumberAxis numberAxis2 = new NumberAxis("Y");
    StackedXYBarRenderer stackedXYBarRenderer = new StackedXYBarRenderer(0.1D);
    stackedXYBarRenderer.setDrawBarOutline(false);
    XYPlot xYPlot = new XYPlot((XYDataset)paramTableXYDataset, (ValueAxis)numberAxis1, (ValueAxis)numberAxis2, (XYItemRenderer)stackedXYBarRenderer);
    JFreeChart jFreeChart = new JFreeChart("Stacked XY Bar Chart Demo 1", (Plot)xYPlot);
    ChartUtilities.applyCurrentTheme(jFreeChart);
    return jFreeChart;
  }
  
  public static JPanel createDemoPanel() {
    JFreeChart jFreeChart = createChart(createDataset());
    return (JPanel)new ChartPanel(jFreeChart);
  }
  
  public static void main(String[] paramArrayOfString) {
    StackedXYBarChartDemo1 stackedXYBarChartDemo1 = new StackedXYBarChartDemo1("Stacked XY Bar Chart Demo 1");
    stackedXYBarChartDemo1.pack();
    RefineryUtilities.centerFrameOnScreen((Window)stackedXYBarChartDemo1);
    stackedXYBarChartDemo1.setVisible(true);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/StackedXYBarChartDemo1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */