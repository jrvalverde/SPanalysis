package demo;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.GradientPaint;
import java.awt.GridLayout;
import java.awt.Window;
import javax.swing.JPanel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.ClusteredXYBarRenderer;
import org.jfree.chart.renderer.xy.XYBarRenderer;
import org.jfree.chart.renderer.xy.XYItemRenderer;
import org.jfree.data.time.Day;
import org.jfree.data.time.RegularTimePeriod;
import org.jfree.data.time.TimeSeries;
import org.jfree.data.time.TimeSeriesCollection;
import org.jfree.data.xy.IntervalXYDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.GradientPaintTransformType;
import org.jfree.ui.GradientPaintTransformer;
import org.jfree.ui.RefineryUtilities;
import org.jfree.ui.StandardGradientPaintTransformer;

public class ClusteredXYBarRendererDemo1 extends ApplicationFrame {
  public ClusteredXYBarRendererDemo1(String paramString) {
    super(paramString);
    setContentPane(createDemoPanel());
  }
  
  private static JFreeChart createChart(String paramString, IntervalXYDataset paramIntervalXYDataset) {
    JFreeChart jFreeChart = ChartFactory.createXYBarChart(paramString, null, true, "Y", paramIntervalXYDataset, PlotOrientation.VERTICAL, true, true, false);
    XYPlot xYPlot = (XYPlot)jFreeChart.getPlot();
    ClusteredXYBarRenderer clusteredXYBarRenderer = new ClusteredXYBarRenderer(0.2D, false);
    xYPlot.setRenderer((XYItemRenderer)clusteredXYBarRenderer);
    return jFreeChart;
  }
  
  private static IntervalXYDataset createDataset() {
    TimeSeries timeSeries1 = new TimeSeries("Series 1");
    timeSeries1.add((RegularTimePeriod)new Day(1, 1, 2003), 54.3D);
    timeSeries1.add((RegularTimePeriod)new Day(2, 1, 2003), 20.3D);
    timeSeries1.add((RegularTimePeriod)new Day(3, 1, 2003), 43.4D);
    timeSeries1.add((RegularTimePeriod)new Day(4, 1, 2003), -12.0D);
    TimeSeries timeSeries2 = new TimeSeries("Series 2");
    timeSeries2.add((RegularTimePeriod)new Day(1, 1, 2003), 8.0D);
    timeSeries2.add((RegularTimePeriod)new Day(2, 1, 2003), 16.0D);
    timeSeries2.add((RegularTimePeriod)new Day(3, 1, 2003), 21.0D);
    timeSeries2.add((RegularTimePeriod)new Day(4, 1, 2003), 5.0D);
    TimeSeriesCollection timeSeriesCollection = new TimeSeriesCollection();
    timeSeriesCollection.addSeries(timeSeries1);
    timeSeriesCollection.addSeries(timeSeries2);
    return (IntervalXYDataset)timeSeriesCollection;
  }
  
  public static JPanel createDemoPanel() {
    DemoPanel demoPanel = new DemoPanel(new GridLayout(2, 2));
    demoPanel.setPreferredSize(new Dimension(800, 600));
    IntervalXYDataset intervalXYDataset = createDataset();
    JFreeChart jFreeChart1 = createChart("Vertical", intervalXYDataset);
    XYPlot xYPlot1 = (XYPlot)jFreeChart1.getPlot();
    XYBarRenderer xYBarRenderer1 = (XYBarRenderer)xYPlot1.getRenderer();
    xYBarRenderer1.setDrawBarOutline(false);
    xYBarRenderer1.setSeriesPaint(0, new GradientPaint(0.0F, 0.0F, Color.red, 0.0F, 0.0F, Color.yellow));
    xYBarRenderer1.setSeriesPaint(1, new GradientPaint(0.0F, 0.0F, Color.blue, 0.0F, 0.0F, Color.green));
    xYBarRenderer1.setGradientPaintTransformer((GradientPaintTransformer)new StandardGradientPaintTransformer(GradientPaintTransformType.VERTICAL));
    ChartPanel chartPanel1 = new ChartPanel(jFreeChart1);
    demoPanel.add((Component)chartPanel1);
    JFreeChart jFreeChart2 = createChart("Vertical / Inverted Axis", intervalXYDataset);
    XYPlot xYPlot2 = (XYPlot)jFreeChart2.getPlot();
    XYBarRenderer xYBarRenderer2 = (XYBarRenderer)xYPlot2.getRenderer();
    xYBarRenderer2.setDrawBarOutline(false);
    xYBarRenderer2.setSeriesPaint(0, new GradientPaint(0.0F, 0.0F, Color.red, 0.0F, 0.0F, Color.yellow));
    xYBarRenderer2.setSeriesPaint(1, new GradientPaint(0.0F, 0.0F, Color.blue, 0.0F, 0.0F, Color.green));
    xYBarRenderer2.setGradientPaintTransformer((GradientPaintTransformer)new StandardGradientPaintTransformer(GradientPaintTransformType.HORIZONTAL));
    xYPlot2.getDomainAxis().setInverted(true);
    ChartPanel chartPanel2 = new ChartPanel(jFreeChart2);
    demoPanel.add((Component)chartPanel2);
    JFreeChart jFreeChart3 = createChart("Horizontal", intervalXYDataset);
    XYPlot xYPlot3 = (XYPlot)jFreeChart3.getPlot();
    xYPlot3.setOrientation(PlotOrientation.HORIZONTAL);
    XYBarRenderer xYBarRenderer3 = (XYBarRenderer)xYPlot3.getRenderer();
    xYBarRenderer3.setDrawBarOutline(false);
    xYBarRenderer3.setSeriesPaint(0, new GradientPaint(0.0F, 0.0F, Color.red, 0.0F, 0.0F, Color.yellow));
    xYBarRenderer3.setSeriesPaint(1, new GradientPaint(0.0F, 0.0F, Color.blue, 0.0F, 0.0F, Color.green));
    xYBarRenderer3.setGradientPaintTransformer((GradientPaintTransformer)new StandardGradientPaintTransformer(GradientPaintTransformType.CENTER_VERTICAL));
    ChartPanel chartPanel3 = new ChartPanel(jFreeChart3);
    demoPanel.add((Component)chartPanel3);
    JFreeChart jFreeChart4 = createChart("Horizontal / Inverted Axis", intervalXYDataset);
    XYPlot xYPlot4 = (XYPlot)jFreeChart4.getPlot();
    xYPlot4.setOrientation(PlotOrientation.HORIZONTAL);
    XYBarRenderer xYBarRenderer4 = (XYBarRenderer)xYPlot4.getRenderer();
    xYBarRenderer4.setDrawBarOutline(false);
    xYBarRenderer4.setSeriesPaint(0, new GradientPaint(0.0F, 0.0F, Color.red, 0.0F, 0.0F, Color.yellow));
    xYBarRenderer4.setSeriesPaint(1, new GradientPaint(0.0F, 0.0F, Color.blue, 0.0F, 0.0F, Color.green));
    xYBarRenderer4.setGradientPaintTransformer((GradientPaintTransformer)new StandardGradientPaintTransformer(GradientPaintTransformType.CENTER_HORIZONTAL));
    xYPlot4.getDomainAxis().setInverted(true);
    ChartPanel chartPanel4 = new ChartPanel(jFreeChart4);
    demoPanel.add((Component)chartPanel4);
    demoPanel.addChart(jFreeChart1);
    demoPanel.addChart(jFreeChart2);
    demoPanel.addChart(jFreeChart3);
    demoPanel.addChart(jFreeChart4);
    return demoPanel;
  }
  
  public static void main(String[] paramArrayOfString) {
    ClusteredXYBarRendererDemo1 clusteredXYBarRendererDemo1 = new ClusteredXYBarRendererDemo1("JFreeChart: ClusteredXYBarRendererDemo1.java");
    clusteredXYBarRendererDemo1.pack();
    RefineryUtilities.centerFrameOnScreen((Window)clusteredXYBarRendererDemo1);
    clusteredXYBarRendererDemo1.setVisible(true);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/ClusteredXYBarRendererDemo1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */