package demo;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Window;
import javax.swing.JPanel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.annotations.CategoryAnnotation;
import org.jfree.chart.annotations.CategoryPointerAnnotation;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.renderer.category.LineAndShapeRenderer;
import org.jfree.chart.title.TextTitle;
import org.jfree.chart.title.Title;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.HorizontalAlignment;
import org.jfree.ui.RectangleEdge;
import org.jfree.ui.RefineryUtilities;
import org.jfree.ui.TextAnchor;

public class CategoryPointerAnnotationDemo1 extends ApplicationFrame {
  public CategoryPointerAnnotationDemo1(String paramString) {
    super(paramString);
    JPanel jPanel = createDemoPanel();
    jPanel.setPreferredSize(new Dimension(500, 270));
    setContentPane(jPanel);
  }
  
  private static CategoryDataset createDataset() {
    DefaultCategoryDataset defaultCategoryDataset = new DefaultCategoryDataset();
    defaultCategoryDataset.addValue(212.0D, "Classes", "JDK 1.0");
    defaultCategoryDataset.addValue(504.0D, "Classes", "JDK 1.1");
    defaultCategoryDataset.addValue(1520.0D, "Classes", "JDK 1.2");
    defaultCategoryDataset.addValue(1842.0D, "Classes", "JDK 1.3");
    defaultCategoryDataset.addValue(2991.0D, "Classes", "JDK 1.4");
    return (CategoryDataset)defaultCategoryDataset;
  }
  
  private static JFreeChart createChart(CategoryDataset paramCategoryDataset) {
    JFreeChart jFreeChart = ChartFactory.createLineChart("Java Standard Class Library", "Release", "Class Count", paramCategoryDataset, PlotOrientation.VERTICAL, false, true, false);
    jFreeChart.addSubtitle((Title)new TextTitle("Number of Classes By Release"));
    TextTitle textTitle = new TextTitle("Source: Java In A Nutshell (4th Edition) by David Flanagan (O'Reilly)");
    textTitle.setFont(new Font("SansSerif", 0, 10));
    textTitle.setPosition(RectangleEdge.BOTTOM);
    textTitle.setHorizontalAlignment(HorizontalAlignment.RIGHT);
    jFreeChart.addSubtitle((Title)textTitle);
    CategoryPlot categoryPlot = (CategoryPlot)jFreeChart.getPlot();
    NumberAxis numberAxis = (NumberAxis)categoryPlot.getRangeAxis();
    numberAxis.setStandardTickUnits(NumberAxis.createIntegerTickUnits());
    LineAndShapeRenderer lineAndShapeRenderer = (LineAndShapeRenderer)categoryPlot.getRenderer();
    lineAndShapeRenderer.setBaseShapesVisible(true);
    lineAndShapeRenderer.setDrawOutlines(true);
    lineAndShapeRenderer.setUseFillPaint(true);
    lineAndShapeRenderer.setBaseFillPaint(Color.white);
    CategoryPointerAnnotation categoryPointerAnnotation = new CategoryPointerAnnotation("Released 4-Dec-1998", "JDK 1.2", 1530.0D, -2.356194490192345D);
    categoryPointerAnnotation.setTextAnchor(TextAnchor.BOTTOM_RIGHT);
    categoryPlot.addAnnotation((CategoryAnnotation)categoryPointerAnnotation);
    ChartUtilities.applyCurrentTheme(jFreeChart);
    return jFreeChart;
  }
  
  public static JPanel createDemoPanel() {
    JFreeChart jFreeChart = createChart(createDataset());
    return (JPanel)new ChartPanel(jFreeChart);
  }
  
  public static void main(String[] paramArrayOfString) {
    CategoryPointerAnnotationDemo1 categoryPointerAnnotationDemo1 = new CategoryPointerAnnotationDemo1("JFreeChart: CategoryPointerAnnotationDemo1.java");
    categoryPointerAnnotationDemo1.pack();
    RefineryUtilities.centerFrameOnScreen((Window)categoryPointerAnnotationDemo1);
    categoryPointerAnnotationDemo1.setVisible(true);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/CategoryPointerAnnotationDemo1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */