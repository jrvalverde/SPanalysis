package demo;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Paint;
import java.awt.Window;
import java.util.Arrays;
import java.util.List;
import javax.swing.JPanel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.labels.CategoryItemLabelGenerator;
import org.jfree.chart.labels.ItemLabelAnchor;
import org.jfree.chart.labels.ItemLabelPosition;
import org.jfree.chart.labels.StandardCategoryItemLabelGenerator;
import org.jfree.chart.plot.CategoryMarker;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.renderer.category.BarRenderer;
import org.jfree.chart.renderer.category.CategoryItemRenderer;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.general.DatasetUtilities;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.Layer;
import org.jfree.ui.LengthAdjustmentType;
import org.jfree.ui.RectangleAnchor;
import org.jfree.ui.RefineryUtilities;
import org.jfree.ui.TextAnchor;

public class BarChartDemo3 extends ApplicationFrame {
  public BarChartDemo3(String paramString) {
    super(paramString);
    JPanel jPanel = createDemoPanel();
    jPanel.setPreferredSize(new Dimension(500, 270));
    setContentPane(jPanel);
  }
  
  private static CategoryDataset createDataset() {
    double[][] arrayOfDouble = { { 4.0D, 3.0D, -2.0D, 3.0D, 6.0D } };
    return DatasetUtilities.createCategoryDataset("Series ", "Category ", arrayOfDouble);
  }
  
  private static JFreeChart createChart(CategoryDataset paramCategoryDataset) {
    JFreeChart jFreeChart = ChartFactory.createBarChart("Bar Chart Demo 3", "Category", "Value", paramCategoryDataset);
    jFreeChart.removeLegend();
    CategoryPlot categoryPlot = (CategoryPlot)jFreeChart.getPlot();
    categoryPlot.setNoDataMessage("NO DATA!");
    categoryPlot.setRangePannable(true);
    Paint[] arrayOfPaint = { new Color(196, 215, 216), new Color(78, 137, 139), new Color(138, 177, 178), new Color(19, 97, 100) };
    CustomRenderer customRenderer = new CustomRenderer(arrayOfPaint);
    customRenderer.setBaseItemLabelGenerator((CategoryItemLabelGenerator)new StandardCategoryItemLabelGenerator());
    customRenderer.setBaseItemLabelsVisible(true);
    ItemLabelPosition itemLabelPosition = new ItemLabelPosition(ItemLabelAnchor.CENTER, TextAnchor.CENTER, TextAnchor.CENTER, 0.0D);
    customRenderer.setBasePositiveItemLabelPosition(itemLabelPosition);
    categoryPlot.setRenderer((CategoryItemRenderer)customRenderer);
    CategoryMarker categoryMarker = new CategoryMarker("Category 3");
    categoryMarker.setLabel("Special");
    categoryMarker.setPaint(new Color(221, 255, 221, 128));
    categoryMarker.setAlpha(0.5F);
    categoryMarker.setLabelAnchor(RectangleAnchor.TOP_LEFT);
    categoryMarker.setLabelTextAnchor(TextAnchor.TOP_LEFT);
    categoryMarker.setLabelOffsetType(LengthAdjustmentType.CONTRACT);
    categoryPlot.addDomainMarker(categoryMarker, Layer.BACKGROUND);
    NumberAxis numberAxis1 = (NumberAxis)categoryPlot.getRangeAxis();
    numberAxis1.setStandardTickUnits(NumberAxis.createIntegerTickUnits());
    numberAxis1.setLowerMargin(0.15D);
    numberAxis1.setUpperMargin(0.15D);
    NumberAxis numberAxis2 = new NumberAxis(null);
    numberAxis2.setStandardTickUnits(NumberAxis.createIntegerTickUnits());
    numberAxis2.setLowerMargin(0.15D);
    numberAxis2.setUpperMargin(0.15D);
    categoryPlot.setRangeAxis(1, (ValueAxis)numberAxis2);
    CategoryAxis categoryAxis = new CategoryAxis(null);
    categoryPlot.setDomainAxis(1, categoryAxis);
    List<Integer> list = Arrays.asList(new Integer[] { new Integer(0), new Integer(1) });
    categoryPlot.mapDatasetToDomainAxes(0, list);
    categoryPlot.mapDatasetToRangeAxes(0, list);
    ChartUtilities.applyCurrentTheme(jFreeChart);
    return jFreeChart;
  }
  
  public static JPanel createDemoPanel() {
    JFreeChart jFreeChart = createChart(createDataset());
    return (JPanel)new ChartPanel(jFreeChart);
  }
  
  public static void main(String[] paramArrayOfString) {
    BarChartDemo3 barChartDemo3 = new BarChartDemo3("JFreeChart: BarChartDemo3.java");
    barChartDemo3.pack();
    RefineryUtilities.centerFrameOnScreen((Window)barChartDemo3);
    barChartDemo3.setVisible(true);
  }
  
  static class CustomRenderer extends BarRenderer {
    private Paint[] colors;
    
    public CustomRenderer(Paint[] param1ArrayOfPaint) {
      this.colors = param1ArrayOfPaint;
    }
    
    public Paint getItemPaint(int param1Int1, int param1Int2) {
      return this.colors[param1Int2 % this.colors.length];
    }
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/BarChartDemo3.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */