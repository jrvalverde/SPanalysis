package demo;

import java.awt.Container;
import java.awt.Dimension;
import java.awt.Window;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PiePlot3D;
import org.jfree.data.general.DefaultPieDataset;
import org.jfree.data.general.PieDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;
import org.jfree.util.Rotation;

public class PieChart3DDemo1 extends ApplicationFrame {
  public PieChart3DDemo1(String paramString) {
    super(paramString);
    ChartPanel chartPanel = createDemoPanel();
    chartPanel.setPreferredSize(new Dimension(500, 270));
    setContentPane((Container)chartPanel);
  }
  
  private static PieDataset createDataset() {
    DefaultPieDataset defaultPieDataset = new DefaultPieDataset();
    defaultPieDataset.setValue("Java", new Double(43.2D));
    defaultPieDataset.setValue("Visual Basic", new Double(10.0D));
    defaultPieDataset.setValue("C/C++", new Double(17.5D));
    defaultPieDataset.setValue("PHP", new Double(32.5D));
    defaultPieDataset.setValue("Perl", null);
    return (PieDataset)defaultPieDataset;
  }
  
  private static JFreeChart createChart(PieDataset paramPieDataset) {
    JFreeChart jFreeChart = ChartFactory.createPieChart3D("Pie Chart 3D Demo 1", paramPieDataset, true, true, false);
    PiePlot3D piePlot3D = (PiePlot3D)jFreeChart.getPlot();
    piePlot3D.setDarkerSides(true);
    piePlot3D.setStartAngle(290.0D);
    piePlot3D.setDirection(Rotation.CLOCKWISE);
    piePlot3D.setForegroundAlpha(0.5F);
    piePlot3D.setNoDataMessage("No data to display");
    return jFreeChart;
  }
  
  public static ChartPanel createDemoPanel() {
    JFreeChart jFreeChart = createChart(createDataset());
    ChartPanel chartPanel = new ChartPanel(jFreeChart);
    chartPanel.setMouseWheelEnabled(true);
    return chartPanel;
  }
  
  public static void main(String[] paramArrayOfString) {
    PieChart3DDemo1 pieChart3DDemo1 = new PieChart3DDemo1("JFreeChart: PieChart3DDemo1.java");
    pieChart3DDemo1.pack();
    RefineryUtilities.centerFrameOnScreen((Window)pieChart3DDemo1);
    pieChart3DDemo1.setVisible(true);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/PieChart3DDemo1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */