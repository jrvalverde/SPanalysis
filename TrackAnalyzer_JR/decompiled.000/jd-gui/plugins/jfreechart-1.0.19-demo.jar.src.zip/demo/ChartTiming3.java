package demo;

import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import javax.swing.Timer;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYDotRenderer;
import org.jfree.chart.renderer.xy.XYItemRenderer;
import org.jfree.data.xy.XYDataset;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;

public class ChartTiming3 implements ActionListener {
  private boolean finished;
  
  public void run() {
    this.finished = false;
    XYSeries xYSeries = new XYSeries("Random Data");
    for (byte b1 = 0; b1 < '֠'; b1++) {
      double d1 = Math.random();
      double d2 = Math.random();
      xYSeries.add(d1, d2);
    } 
    XYSeriesCollection xYSeriesCollection = new XYSeriesCollection(xYSeries);
    boolean bool = true;
    JFreeChart jFreeChart = ChartFactory.createScatterPlot("Scatter plot timing", "X", "Y", (XYDataset)xYSeriesCollection, PlotOrientation.VERTICAL, bool, false, false);
    XYPlot xYPlot = (XYPlot)jFreeChart.getPlot();
    xYPlot.setRenderer((XYItemRenderer)new XYDotRenderer());
    BufferedImage bufferedImage = new BufferedImage(400, 300, 1);
    Graphics2D graphics2D = bufferedImage.createGraphics();
    Rectangle2D.Double double_ = new Rectangle2D.Double(0.0D, 0.0D, 400.0D, 300.0D);
    Timer timer = new Timer(10000, this);
    timer.setRepeats(false);
    byte b2 = 0;
    timer.start();
    while (!this.finished) {
      jFreeChart.draw(graphics2D, double_, null, null);
      System.out.println("Charts drawn..." + b2);
      if (!this.finished)
        b2++; 
    } 
    System.out.println("DONE");
  }
  
  public void actionPerformed(ActionEvent paramActionEvent) {
    this.finished = true;
  }
  
  public static void main(String[] paramArrayOfString) {
    ChartTiming3 chartTiming3 = new ChartTiming3();
    chartTiming3.run();
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/ChartTiming3.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */