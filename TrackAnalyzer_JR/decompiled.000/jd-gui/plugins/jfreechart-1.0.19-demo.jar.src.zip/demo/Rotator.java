package demo;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.Timer;
import org.jfree.chart.plot.PiePlot3D;

class Rotator extends Timer implements ActionListener {
  private PiePlot3D plot;
  
  private int angle = 270;
  
  Rotator(PiePlot3D paramPiePlot3D) {
    super(100, null);
    this.plot = paramPiePlot3D;
    addActionListener(this);
  }
  
  public void actionPerformed(ActionEvent paramActionEvent) {
    this.plot.setStartAngle(this.angle);
    this.angle++;
    if (this.angle == 360)
      this.angle = 0; 
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/Rotator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */