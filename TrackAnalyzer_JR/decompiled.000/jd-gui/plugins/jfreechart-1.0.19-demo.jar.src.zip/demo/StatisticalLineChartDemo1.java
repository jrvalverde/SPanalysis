package demo;

import java.awt.Dimension;
import java.awt.Window;
import javax.swing.JPanel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.renderer.category.CategoryItemRenderer;
import org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.statistics.DefaultStatisticalCategoryDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

public class StatisticalLineChartDemo1 extends ApplicationFrame {
  public StatisticalLineChartDemo1(String paramString) {
    super(paramString);
    JPanel jPanel = createDemoPanel();
    jPanel.setPreferredSize(new Dimension(500, 270));
    setContentPane(jPanel);
  }
  
  private static CategoryDataset createDataset() {
    DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset = new DefaultStatisticalCategoryDataset();
    defaultStatisticalCategoryDataset.add(10.0D, 2.4D, "Row 1", "Column 1");
    defaultStatisticalCategoryDataset.add(15.0D, 4.4D, "Row 1", "Column 2");
    defaultStatisticalCategoryDataset.add(13.0D, 2.1D, "Row 1", "Column 3");
    defaultStatisticalCategoryDataset.add(7.0D, 1.3D, "Row 1", "Column 4");
    defaultStatisticalCategoryDataset.add(22.0D, 2.4D, "Row 2", "Column 1");
    defaultStatisticalCategoryDataset.add(18.0D, 4.4D, "Row 2", "Column 2");
    defaultStatisticalCategoryDataset.add(28.0D, 2.1D, "Row 2", "Column 3");
    defaultStatisticalCategoryDataset.add(17.0D, 1.3D, "Row 2", "Column 4");
    return (CategoryDataset)defaultStatisticalCategoryDataset;
  }
  
  private static JFreeChart createChart(CategoryDataset paramCategoryDataset) {
    JFreeChart jFreeChart = ChartFactory.createLineChart("Statistical Line Chart Demo 1", "Type", "Value", paramCategoryDataset, PlotOrientation.VERTICAL, true, true, false);
    CategoryPlot categoryPlot = (CategoryPlot)jFreeChart.getPlot();
    categoryPlot.setRangePannable(true);
    CategoryAxis categoryAxis = categoryPlot.getDomainAxis();
    categoryAxis.setUpperMargin(0.0D);
    categoryAxis.setLowerMargin(0.0D);
    NumberAxis numberAxis = (NumberAxis)categoryPlot.getRangeAxis();
    numberAxis.setStandardTickUnits(NumberAxis.createIntegerTickUnits());
    numberAxis.setAutoRangeIncludesZero(true);
    StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer = new StatisticalLineAndShapeRenderer(true, false);
    statisticalLineAndShapeRenderer.setUseSeriesOffset(true);
    categoryPlot.setRenderer((CategoryItemRenderer)statisticalLineAndShapeRenderer);
    return jFreeChart;
  }
  
  public static JPanel createDemoPanel() {
    JFreeChart jFreeChart = createChart(createDataset());
    ChartPanel chartPanel = new ChartPanel(jFreeChart);
    chartPanel.setMouseWheelEnabled(true);
    return (JPanel)chartPanel;
  }
  
  public static void main(String[] paramArrayOfString) {
    StatisticalLineChartDemo1 statisticalLineChartDemo1 = new StatisticalLineChartDemo1("JFreeChart: StatisticalLineChartDemo1.java");
    statisticalLineChartDemo1.pack();
    RefineryUtilities.centerFrameOnScreen((Window)statisticalLineChartDemo1);
    statisticalLineChartDemo1.setVisible(true);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/StatisticalLineChartDemo1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */