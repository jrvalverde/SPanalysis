package demo;

import java.awt.Dimension;
import java.awt.Font;
import java.awt.Window;
import javax.swing.JPanel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.RingPlot;
import org.jfree.data.general.DefaultPieDataset;
import org.jfree.data.general.PieDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

public class RingChartDemo1 extends ApplicationFrame {
  public RingChartDemo1(String paramString) {
    super(paramString);
    JPanel jPanel = createDemoPanel();
    jPanel.setPreferredSize(new Dimension(500, 270));
    setContentPane(jPanel);
  }
  
  private static PieDataset createDataset() {
    DefaultPieDataset defaultPieDataset = new DefaultPieDataset();
    defaultPieDataset.setValue("One", new Double(43.2D));
    defaultPieDataset.setValue("Two", new Double(10.0D));
    defaultPieDataset.setValue("Three", new Double(27.5D));
    defaultPieDataset.setValue("Four", new Double(17.5D));
    defaultPieDataset.setValue("Five", new Double(11.0D));
    defaultPieDataset.setValue("Six", new Double(19.4D));
    return (PieDataset)defaultPieDataset;
  }
  
  private static JFreeChart createChart(PieDataset paramPieDataset) {
    JFreeChart jFreeChart = ChartFactory.createRingChart("Ring Chart Demo 1", paramPieDataset, false, true, false);
    RingPlot ringPlot = (RingPlot)jFreeChart.getPlot();
    ringPlot.setLabelFont(new Font("SansSerif", 0, 12));
    ringPlot.setNoDataMessage("No data available");
    ringPlot.setSectionDepth(0.35D);
    ringPlot.setCircular(false);
    ringPlot.setLabelGap(0.02D);
    return jFreeChart;
  }
  
  public static JPanel createDemoPanel() {
    JFreeChart jFreeChart = createChart(createDataset());
    ChartPanel chartPanel = new ChartPanel(jFreeChart);
    chartPanel.setMouseWheelEnabled(true);
    return (JPanel)chartPanel;
  }
  
  public static void main(String[] paramArrayOfString) {
    RingChartDemo1 ringChartDemo1 = new RingChartDemo1("JFreeChart: RingChartDemo1.java");
    ringChartDemo1.pack();
    RefineryUtilities.centerFrameOnScreen((Window)ringChartDemo1);
    ringChartDemo1.setVisible(true);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/RingChartDemo1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */