package demo;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Window;
import javax.swing.JPanel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.DeviationRenderer;
import org.jfree.chart.renderer.xy.XYItemRenderer;
import org.jfree.data.xy.XYDataset;
import org.jfree.data.xy.YIntervalSeries;
import org.jfree.data.xy.YIntervalSeriesCollection;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

public class DeviationRendererDemo1 extends ApplicationFrame {
  public DeviationRendererDemo1(String paramString) {
    super(paramString);
    JPanel jPanel = createDemoPanel();
    jPanel.setPreferredSize(new Dimension(500, 270));
    setContentPane(jPanel);
  }
  
  private static XYDataset createDataset() {
    YIntervalSeries yIntervalSeries1 = new YIntervalSeries("Series 1");
    YIntervalSeries yIntervalSeries2 = new YIntervalSeries("Series 2");
    double d1 = 100.0D;
    double d2 = 100.0D;
    for (byte b = 0; b <= 100; b++) {
      d1 = d1 + Math.random() - 0.48D;
      double d3 = 0.05D * b;
      yIntervalSeries1.add(b, d1, d1 - d3, d1 + d3);
      d2 = d2 + Math.random() - 0.5D;
      double d4 = 0.07D * b;
      yIntervalSeries2.add(b, d2, d2 - d4, d2 + d4);
    } 
    YIntervalSeriesCollection yIntervalSeriesCollection = new YIntervalSeriesCollection();
    yIntervalSeriesCollection.addSeries(yIntervalSeries1);
    yIntervalSeriesCollection.addSeries(yIntervalSeries2);
    return (XYDataset)yIntervalSeriesCollection;
  }
  
  private static JFreeChart createChart(XYDataset paramXYDataset) {
    JFreeChart jFreeChart = ChartFactory.createXYLineChart("DeviationRenderer - Demo 1", "X", "Y", paramXYDataset);
    XYPlot xYPlot = (XYPlot)jFreeChart.getPlot();
    xYPlot.setDomainPannable(true);
    DeviationRenderer deviationRenderer = new DeviationRenderer(true, false);
    deviationRenderer.setSeriesStroke(0, new BasicStroke(3.0F, 1, 1));
    deviationRenderer.setSeriesStroke(0, new BasicStroke(3.0F, 1, 1));
    deviationRenderer.setSeriesStroke(1, new BasicStroke(3.0F, 1, 1));
    deviationRenderer.setSeriesFillPaint(0, new Color(255, 200, 200));
    deviationRenderer.setSeriesFillPaint(1, new Color(200, 200, 255));
    xYPlot.setRenderer((XYItemRenderer)deviationRenderer);
    NumberAxis numberAxis = (NumberAxis)xYPlot.getRangeAxis();
    numberAxis.setAutoRangeIncludesZero(false);
    numberAxis.setStandardTickUnits(NumberAxis.createIntegerTickUnits());
    return jFreeChart;
  }
  
  public static JPanel createDemoPanel() {
    JFreeChart jFreeChart = createChart(createDataset());
    ChartPanel chartPanel = new ChartPanel(jFreeChart);
    chartPanel.setMouseWheelEnabled(true);
    return (JPanel)chartPanel;
  }
  
  public static void main(String[] paramArrayOfString) {
    DeviationRendererDemo1 deviationRendererDemo1 = new DeviationRendererDemo1("JFreeChart : DeviationRendererDemo1.java");
    deviationRendererDemo1.pack();
    RefineryUtilities.centerFrameOnScreen((Window)deviationRendererDemo1);
    deviationRendererDemo1.setVisible(true);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/DeviationRendererDemo1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */