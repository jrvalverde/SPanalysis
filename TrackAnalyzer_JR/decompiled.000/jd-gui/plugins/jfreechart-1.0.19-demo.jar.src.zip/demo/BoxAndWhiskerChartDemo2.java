package demo;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Window;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JPanel;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.DateAxis;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.Plot;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYBoxAndWhiskerRenderer;
import org.jfree.chart.renderer.xy.XYItemRenderer;
import org.jfree.data.statistics.BoxAndWhiskerCalculator;
import org.jfree.data.statistics.BoxAndWhiskerXYDataset;
import org.jfree.data.statistics.DefaultBoxAndWhiskerXYDataset;
import org.jfree.data.time.Day;
import org.jfree.data.time.RegularTimePeriod;
import org.jfree.data.xy.XYDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

public class BoxAndWhiskerChartDemo2 extends ApplicationFrame {
  public BoxAndWhiskerChartDemo2(String paramString) {
    super(paramString);
    JPanel jPanel = createDemoPanel();
    jPanel.setPreferredSize(new Dimension(500, 270));
    setContentPane(jPanel);
  }
  
  private static BoxAndWhiskerXYDataset createDataset() {
    DefaultBoxAndWhiskerXYDataset defaultBoxAndWhiskerXYDataset = new DefaultBoxAndWhiskerXYDataset("Series Name");
    Day day = new Day();
    for (byte b = 0; b < 10; b++) {
      List list = createValueList(0.0D, 20.0D, 20);
      defaultBoxAndWhiskerXYDataset.add(day.getStart(), BoxAndWhiskerCalculator.calculateBoxAndWhiskerStatistics(list));
      RegularTimePeriod regularTimePeriod = day.next();
    } 
    return (BoxAndWhiskerXYDataset)defaultBoxAndWhiskerXYDataset;
  }
  
  private static List createValueList(double paramDouble1, double paramDouble2, int paramInt) {
    ArrayList<Double> arrayList = new ArrayList();
    for (byte b = 0; b < paramInt; b++) {
      double d = paramDouble1 + Math.random() * (paramDouble2 - paramDouble1);
      arrayList.add(new Double(d));
    } 
    return arrayList;
  }
  
  private static JFreeChart createChart(BoxAndWhiskerXYDataset paramBoxAndWhiskerXYDataset) {
    DateAxis dateAxis = new DateAxis("Day");
    NumberAxis numberAxis = new NumberAxis("Value");
    XYBoxAndWhiskerRenderer xYBoxAndWhiskerRenderer = new XYBoxAndWhiskerRenderer();
    XYPlot xYPlot = new XYPlot((XYDataset)paramBoxAndWhiskerXYDataset, (ValueAxis)dateAxis, (ValueAxis)numberAxis, (XYItemRenderer)xYBoxAndWhiskerRenderer);
    JFreeChart jFreeChart = new JFreeChart("Box-and-Whisker Chart Demo 2", (Plot)xYPlot);
    jFreeChart.setBackgroundPaint(Color.white);
    xYPlot.setBackgroundPaint(Color.lightGray);
    xYPlot.setDomainGridlinePaint(Color.white);
    xYPlot.setDomainGridlinesVisible(true);
    xYPlot.setRangeGridlinePaint(Color.white);
    xYPlot.setDomainPannable(true);
    xYPlot.setRangePannable(true);
    numberAxis.setStandardTickUnits(NumberAxis.createIntegerTickUnits());
    ChartUtilities.applyCurrentTheme(jFreeChart);
    return jFreeChart;
  }
  
  public static JPanel createDemoPanel() {
    JFreeChart jFreeChart = createChart(createDataset());
    ChartPanel chartPanel = new ChartPanel(jFreeChart);
    chartPanel.setMouseWheelEnabled(true);
    return (JPanel)chartPanel;
  }
  
  public static void main(String[] paramArrayOfString) {
    BoxAndWhiskerChartDemo2 boxAndWhiskerChartDemo2 = new BoxAndWhiskerChartDemo2("JFreeChart: BoxAndWhiskerChartDemo2.java");
    boxAndWhiskerChartDemo2.pack();
    RefineryUtilities.centerFrameOnScreen((Window)boxAndWhiskerChartDemo2);
    boxAndWhiskerChartDemo2.setVisible(true);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/BoxAndWhiskerChartDemo2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */