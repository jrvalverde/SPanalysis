package demo;

import java.awt.Dimension;
import java.awt.Window;
import javax.swing.JPanel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.renderer.category.CategoryItemRenderer;
import org.jfree.chart.renderer.category.MinMaxCategoryRenderer;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

public class MinMaxCategoryPlotDemo1 extends ApplicationFrame {
  public MinMaxCategoryPlotDemo1(String paramString) {
    super(paramString);
    JPanel jPanel = createDemoPanel();
    jPanel.setPreferredSize(new Dimension(500, 270));
    setContentPane(jPanel);
  }
  
  public static CategoryDataset createDataset() {
    DefaultCategoryDataset defaultCategoryDataset = new DefaultCategoryDataset();
    defaultCategoryDataset.addValue(1.0D, "First", "C1");
    defaultCategoryDataset.addValue(4.0D, "First", "C2");
    defaultCategoryDataset.addValue(3.0D, "First", "C3");
    defaultCategoryDataset.addValue(5.0D, "First", "C4");
    defaultCategoryDataset.addValue(5.0D, "First", "C5");
    defaultCategoryDataset.addValue(7.0D, "First", "C6");
    defaultCategoryDataset.addValue(7.0D, "First", "C7");
    defaultCategoryDataset.addValue(8.0D, "First", "C8");
    defaultCategoryDataset.addValue(5.0D, "Second", "C1");
    defaultCategoryDataset.addValue(7.0D, "Second", "C2");
    defaultCategoryDataset.addValue(6.0D, "Second", "C3");
    defaultCategoryDataset.addValue(8.0D, "Second", "C4");
    defaultCategoryDataset.addValue(4.0D, "Second", "C5");
    defaultCategoryDataset.addValue(4.0D, "Second", "C6");
    defaultCategoryDataset.addValue(2.0D, "Second", "C7");
    defaultCategoryDataset.addValue(1.0D, "Second", "C8");
    defaultCategoryDataset.addValue(4.0D, "Third", "C1");
    defaultCategoryDataset.addValue(3.0D, "Third", "C2");
    defaultCategoryDataset.addValue(2.0D, "Third", "C3");
    defaultCategoryDataset.addValue(3.0D, "Third", "C4");
    defaultCategoryDataset.addValue(6.0D, "Third", "C5");
    defaultCategoryDataset.addValue(3.0D, "Third", "C6");
    defaultCategoryDataset.addValue(4.0D, "Third", "C7");
    defaultCategoryDataset.addValue(3.0D, "Third", "C8");
    return (CategoryDataset)defaultCategoryDataset;
  }
  
  public static JFreeChart createChart(CategoryDataset paramCategoryDataset) {
    JFreeChart jFreeChart = ChartFactory.createBarChart("Min/Max Category Plot", "Category", "Value", paramCategoryDataset, PlotOrientation.VERTICAL, true, true, false);
    CategoryPlot categoryPlot = (CategoryPlot)jFreeChart.getPlot();
    categoryPlot.setRangePannable(true);
    MinMaxCategoryRenderer minMaxCategoryRenderer = new MinMaxCategoryRenderer();
    minMaxCategoryRenderer.setDrawLines(false);
    categoryPlot.setRenderer((CategoryItemRenderer)minMaxCategoryRenderer);
    ChartUtilities.applyCurrentTheme(jFreeChart);
    return jFreeChart;
  }
  
  public static JPanel createDemoPanel() {
    JFreeChart jFreeChart = createChart(createDataset());
    ChartPanel chartPanel = new ChartPanel(jFreeChart);
    chartPanel.setMouseWheelEnabled(true);
    return (JPanel)chartPanel;
  }
  
  public static void main(String[] paramArrayOfString) {
    MinMaxCategoryPlotDemo1 minMaxCategoryPlotDemo1 = new MinMaxCategoryPlotDemo1("JFreeChart: MinMaxCategoryPlotDemo1.java");
    minMaxCategoryPlotDemo1.pack();
    RefineryUtilities.centerFrameOnScreen((Window)minMaxCategoryPlotDemo1);
    minMaxCategoryPlotDemo1.setVisible(true);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/MinMaxCategoryPlotDemo1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */