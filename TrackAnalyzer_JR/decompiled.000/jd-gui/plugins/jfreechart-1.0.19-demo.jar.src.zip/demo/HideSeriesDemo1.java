package demo;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Window;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JCheckBox;
import javax.swing.JPanel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYItemRenderer;
import org.jfree.data.xy.XYDataset;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

public class HideSeriesDemo1 extends ApplicationFrame {
  public HideSeriesDemo1(String paramString) {
    super(paramString);
    setContentPane(new MyDemoPanel());
  }
  
  public static JPanel createDemoPanel() {
    return new MyDemoPanel();
  }
  
  public static void main(String[] paramArrayOfString) {
    HideSeriesDemo1 hideSeriesDemo1 = new HideSeriesDemo1("JFreeChart: HideSeriesDemo1.java");
    hideSeriesDemo1.pack();
    RefineryUtilities.centerFrameOnScreen((Window)hideSeriesDemo1);
    hideSeriesDemo1.setVisible(true);
  }
  
  static class MyDemoPanel extends DemoPanel implements ActionListener {
    private XYItemRenderer renderer;
    
    public MyDemoPanel() {
      super(new BorderLayout());
      XYDataset xYDataset = createSampleDataset();
      JFreeChart jFreeChart = createChart(xYDataset);
      addChart(jFreeChart);
      ChartPanel chartPanel = new ChartPanel(jFreeChart, true);
      JPanel jPanel = new JPanel();
      JCheckBox jCheckBox1 = new JCheckBox("Series 1");
      jCheckBox1.setActionCommand("S1");
      jCheckBox1.addActionListener(this);
      jCheckBox1.setSelected(true);
      JCheckBox jCheckBox2 = new JCheckBox("Series 2");
      jCheckBox2.setActionCommand("S2");
      jCheckBox2.addActionListener(this);
      jCheckBox2.setSelected(true);
      JCheckBox jCheckBox3 = new JCheckBox("Series 3");
      jCheckBox3.setActionCommand("S3");
      jCheckBox3.addActionListener(this);
      jCheckBox3.setSelected(true);
      jPanel.add(jCheckBox1);
      jPanel.add(jCheckBox2);
      jPanel.add(jCheckBox3);
      add((Component)chartPanel);
      add(jPanel, "South");
      chartPanel.setPreferredSize(new Dimension(500, 270));
    }
    
    private XYDataset createSampleDataset() {
      XYSeries xYSeries1 = new XYSeries("Series 1");
      xYSeries1.add(1.0D, 3.3D);
      xYSeries1.add(2.0D, 4.4D);
      xYSeries1.add(3.0D, 1.7D);
      XYSeries xYSeries2 = new XYSeries("Series 2");
      xYSeries2.add(1.0D, 7.3D);
      xYSeries2.add(2.0D, 6.8D);
      xYSeries2.add(3.0D, 9.6D);
      xYSeries2.add(4.0D, 5.6D);
      XYSeries xYSeries3 = new XYSeries("Series 3");
      xYSeries3.add(1.0D, 17.3D);
      xYSeries3.add(2.0D, 16.8D);
      xYSeries3.add(3.0D, 19.6D);
      xYSeries3.add(4.0D, 15.6D);
      XYSeriesCollection xYSeriesCollection = new XYSeriesCollection();
      xYSeriesCollection.addSeries(xYSeries1);
      xYSeriesCollection.addSeries(xYSeries2);
      xYSeriesCollection.addSeries(xYSeries3);
      return (XYDataset)xYSeriesCollection;
    }
    
    private JFreeChart createChart(XYDataset param1XYDataset) {
      JFreeChart jFreeChart = ChartFactory.createXYLineChart("Hide Series Demo 1", "X", "Y", param1XYDataset, PlotOrientation.VERTICAL, true, true, false);
      XYPlot xYPlot = (XYPlot)jFreeChart.getPlot();
      this.renderer = xYPlot.getRenderer();
      return jFreeChart;
    }
    
    public void actionPerformed(ActionEvent param1ActionEvent) {
      byte b = -1;
      if (param1ActionEvent.getActionCommand().equals("S1")) {
        b = 0;
      } else if (param1ActionEvent.getActionCommand().equals("S2")) {
        b = 1;
      } else if (param1ActionEvent.getActionCommand().equals("S3")) {
        b = 2;
      } 
      if (b >= 0) {
        boolean bool = this.renderer.getItemVisible(b, 0);
        this.renderer.setSeriesVisible(b, Boolean.valueOf(!bool));
      } 
    }
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/HideSeriesDemo1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */