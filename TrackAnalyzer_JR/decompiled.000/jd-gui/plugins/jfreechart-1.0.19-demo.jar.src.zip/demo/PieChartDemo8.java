package demo;

import java.awt.Dimension;
import java.awt.Window;
import java.awt.font.TextAttribute;
import java.text.AttributedString;
import javax.swing.JPanel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.labels.PieSectionLabelGenerator;
import org.jfree.chart.plot.PiePlot;
import org.jfree.data.general.DefaultPieDataset;
import org.jfree.data.general.PieDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

public class PieChartDemo8 extends ApplicationFrame {
  public PieChartDemo8(String paramString) {
    super(paramString);
    JPanel jPanel = createDemoPanel();
    jPanel.setPreferredSize(new Dimension(500, 270));
    setContentPane(jPanel);
  }
  
  private static PieDataset createDataset() {
    DefaultPieDataset defaultPieDataset = new DefaultPieDataset();
    defaultPieDataset.setValue("One", new Double(43.2D));
    defaultPieDataset.setValue("Two", new Double(10.0D));
    defaultPieDataset.setValue("Three", new Double(27.5D));
    defaultPieDataset.setValue("Four", new Double(17.5D));
    defaultPieDataset.setValue("Five", new Double(11.0D));
    defaultPieDataset.setValue("Six", new Double(19.4D));
    return (PieDataset)defaultPieDataset;
  }
  
  private static JFreeChart createChart(PieDataset paramPieDataset) {
    JFreeChart jFreeChart = ChartFactory.createPieChart("Pie Chart Demo 8", paramPieDataset, false, true, false);
    PiePlot piePlot = (PiePlot)jFreeChart.getPlot();
    piePlot.setLabelGenerator(new CustomLabelGenerator());
    return jFreeChart;
  }
  
  public static JPanel createDemoPanel() {
    JFreeChart jFreeChart = createChart(createDataset());
    return (JPanel)new ChartPanel(jFreeChart);
  }
  
  public static void main(String[] paramArrayOfString) {
    PieChartDemo8 pieChartDemo8 = new PieChartDemo8("JFreeChart: PieChartDemo8.java");
    pieChartDemo8.pack();
    RefineryUtilities.centerFrameOnScreen((Window)pieChartDemo8);
    pieChartDemo8.setVisible(true);
  }
  
  static class CustomLabelGenerator implements PieSectionLabelGenerator {
    public String generateSectionLabel(PieDataset param1PieDataset, Comparable param1Comparable) {
      String str = null;
      if (param1PieDataset != null && !param1Comparable.equals("Two"))
        str = param1Comparable.toString(); 
      return str;
    }
    
    public AttributedString generateAttributedSectionLabel(PieDataset param1PieDataset, Comparable param1Comparable) {
      AttributedString attributedString = null;
      String str1 = param1Comparable.toString();
      String str2 = str1 + " : " + String.valueOf(param1PieDataset.getValue(param1Comparable));
      attributedString = new AttributedString(str2);
      attributedString.addAttribute(TextAttribute.WEIGHT, TextAttribute.WEIGHT_BOLD, 0, str1.length() - 1);
      return attributedString;
    }
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/PieChartDemo8.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */