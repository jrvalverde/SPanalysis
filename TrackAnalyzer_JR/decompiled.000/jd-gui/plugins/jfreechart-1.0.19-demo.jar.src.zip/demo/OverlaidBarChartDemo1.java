package demo;

import java.awt.Dimension;
import java.awt.Window;
import javax.swing.JPanel;
import org.jfree.chart.ChartMouseEvent;
import org.jfree.chart.ChartMouseListener;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.CategoryLabelPositions;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.labels.CategoryItemLabelGenerator;
import org.jfree.chart.labels.StandardCategoryItemLabelGenerator;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.DatasetRenderingOrder;
import org.jfree.chart.plot.Plot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.renderer.category.BarRenderer;
import org.jfree.chart.renderer.category.CategoryItemRenderer;
import org.jfree.chart.renderer.category.LineAndShapeRenderer;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

public class OverlaidBarChartDemo1 extends ApplicationFrame {
  public OverlaidBarChartDemo1(String paramString) {
    super(paramString);
    JPanel jPanel = createDemoPanel();
    jPanel.setPreferredSize(new Dimension(500, 270));
    setContentPane(jPanel);
  }
  
  public static JFreeChart createChart() {
    DefaultCategoryDataset defaultCategoryDataset1 = new DefaultCategoryDataset();
    defaultCategoryDataset1.addValue(1.0D, "S1", "Category 1");
    defaultCategoryDataset1.addValue(4.0D, "S1", "Category 2");
    defaultCategoryDataset1.addValue(3.0D, "S1", "Category 3");
    defaultCategoryDataset1.addValue(5.0D, "S1", "Category 4");
    defaultCategoryDataset1.addValue(5.0D, "S1", "Category 5");
    defaultCategoryDataset1.addValue(7.0D, "S1", "Category 6");
    defaultCategoryDataset1.addValue(7.0D, "S1", "Category 7");
    defaultCategoryDataset1.addValue(8.0D, "S1", "Category 8");
    defaultCategoryDataset1.addValue(5.0D, "S2", "Category 1");
    defaultCategoryDataset1.addValue(7.0D, "S2", "Category 2");
    defaultCategoryDataset1.addValue(6.0D, "S2", "Category 3");
    defaultCategoryDataset1.addValue(8.0D, "S2", "Category 4");
    defaultCategoryDataset1.addValue(4.0D, "S2", "Category 5");
    defaultCategoryDataset1.addValue(4.0D, "S2", "Category 6");
    defaultCategoryDataset1.addValue(2.0D, "S2", "Category 7");
    defaultCategoryDataset1.addValue(1.0D, "S2", "Category 8");
    StandardCategoryItemLabelGenerator standardCategoryItemLabelGenerator = new StandardCategoryItemLabelGenerator();
    BarRenderer barRenderer = new BarRenderer();
    barRenderer.setBaseItemLabelGenerator((CategoryItemLabelGenerator)standardCategoryItemLabelGenerator);
    barRenderer.setBaseItemLabelsVisible(true);
    CategoryPlot categoryPlot = new CategoryPlot();
    categoryPlot.setDataset((CategoryDataset)defaultCategoryDataset1);
    categoryPlot.setRenderer((CategoryItemRenderer)barRenderer);
    categoryPlot.setDomainAxis(new CategoryAxis("Category"));
    categoryPlot.setRangeAxis((ValueAxis)new NumberAxis("Value"));
    categoryPlot.setOrientation(PlotOrientation.VERTICAL);
    categoryPlot.setRangeGridlinesVisible(true);
    categoryPlot.setDomainGridlinesVisible(true);
    DefaultCategoryDataset defaultCategoryDataset2 = new DefaultCategoryDataset();
    defaultCategoryDataset2.addValue(9.0D, "T1", "Category 1");
    defaultCategoryDataset2.addValue(7.0D, "T1", "Category 2");
    defaultCategoryDataset2.addValue(2.0D, "T1", "Category 3");
    defaultCategoryDataset2.addValue(6.0D, "T1", "Category 4");
    defaultCategoryDataset2.addValue(6.0D, "T1", "Category 5");
    defaultCategoryDataset2.addValue(9.0D, "T1", "Category 6");
    defaultCategoryDataset2.addValue(5.0D, "T1", "Category 7");
    defaultCategoryDataset2.addValue(4.0D, "T1", "Category 8");
    LineAndShapeRenderer lineAndShapeRenderer1 = new LineAndShapeRenderer();
    categoryPlot.setDataset(1, (CategoryDataset)defaultCategoryDataset2);
    categoryPlot.setRenderer(1, (CategoryItemRenderer)lineAndShapeRenderer1);
    NumberAxis numberAxis = new NumberAxis("Axis 2");
    categoryPlot.setRangeAxis(1, (ValueAxis)numberAxis);
    DefaultCategoryDataset defaultCategoryDataset3 = new DefaultCategoryDataset();
    defaultCategoryDataset3.addValue(94.0D, "R1", "Category 1");
    defaultCategoryDataset3.addValue(75.0D, "R1", "Category 2");
    defaultCategoryDataset3.addValue(22.0D, "R1", "Category 3");
    defaultCategoryDataset3.addValue(74.0D, "R1", "Category 4");
    defaultCategoryDataset3.addValue(83.0D, "R1", "Category 5");
    defaultCategoryDataset3.addValue(9.0D, "R1", "Category 6");
    defaultCategoryDataset3.addValue(23.0D, "R1", "Category 7");
    defaultCategoryDataset3.addValue(98.0D, "R1", "Category 8");
    categoryPlot.setDataset(2, (CategoryDataset)defaultCategoryDataset3);
    LineAndShapeRenderer lineAndShapeRenderer2 = new LineAndShapeRenderer();
    categoryPlot.setRenderer(2, (CategoryItemRenderer)lineAndShapeRenderer2);
    categoryPlot.mapDatasetToRangeAxis(2, 1);
    categoryPlot.setDatasetRenderingOrder(DatasetRenderingOrder.FORWARD);
    categoryPlot.getDomainAxis().setCategoryLabelPositions(CategoryLabelPositions.UP_45);
    JFreeChart jFreeChart = new JFreeChart((Plot)categoryPlot);
    jFreeChart.setTitle("Overlaid Bar Chart");
    ChartUtilities.applyCurrentTheme(jFreeChart);
    return jFreeChart;
  }
  
  public static JPanel createDemoPanel() {
    JFreeChart jFreeChart = createChart();
    ChartPanel chartPanel = new ChartPanel(jFreeChart);
    chartPanel.addChartMouseListener(new ChartMouseListener() {
          public void chartMouseClicked(ChartMouseEvent param1ChartMouseEvent) {
            System.out.println(param1ChartMouseEvent.getEntity());
          }
          
          public void chartMouseMoved(ChartMouseEvent param1ChartMouseEvent) {}
        });
    return (JPanel)chartPanel;
  }
  
  public static void main(String[] paramArrayOfString) {
    OverlaidBarChartDemo1 overlaidBarChartDemo1 = new OverlaidBarChartDemo1("JFreeChart: OverlaidBarChartDemo1.java");
    overlaidBarChartDemo1.pack();
    RefineryUtilities.centerFrameOnScreen((Window)overlaidBarChartDemo1);
    overlaidBarChartDemo1.setVisible(true);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/OverlaidBarChartDemo1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */