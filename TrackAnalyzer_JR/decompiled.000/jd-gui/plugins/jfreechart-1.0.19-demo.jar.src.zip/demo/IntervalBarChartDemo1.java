package demo;

import java.awt.Dimension;
import java.awt.Window;
import java.text.DecimalFormat;
import javax.swing.JPanel;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.Plot;
import org.jfree.chart.renderer.category.CategoryItemRenderer;
import org.jfree.chart.renderer.category.IntervalBarRenderer;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultIntervalCategoryDataset;
import org.jfree.data.category.IntervalCategoryDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

public class IntervalBarChartDemo1 extends ApplicationFrame {
  private static final long serialVersionUID = 1L;
  
  public IntervalBarChartDemo1(String paramString) {
    super(paramString);
    JPanel jPanel = createDemoPanel();
    jPanel.setPreferredSize(new Dimension(500, 270));
    setContentPane(jPanel);
  }
  
  private static IntervalCategoryDataset createDataset() {
    double[] arrayOfDouble1 = { 0.1D, 0.2D, 0.3D };
    double[] arrayOfDouble2 = { 0.3D, 0.4D, 0.5D };
    double[] arrayOfDouble3 = { 0.5D, 0.6D, 0.7D };
    double[] arrayOfDouble4 = { 0.7D, 0.8D, 0.9D };
    double[][] arrayOfDouble5 = { arrayOfDouble1, arrayOfDouble2 };
    double[][] arrayOfDouble6 = { arrayOfDouble3, arrayOfDouble4 };
    return (IntervalCategoryDataset)new DefaultIntervalCategoryDataset(arrayOfDouble5, arrayOfDouble6);
  }
  
  private static JFreeChart createChart(IntervalCategoryDataset paramIntervalCategoryDataset) {
    CategoryAxis categoryAxis = new CategoryAxis("Category");
    NumberAxis numberAxis = new NumberAxis("Percentage");
    numberAxis.setNumberFormatOverride(new DecimalFormat("0.00%"));
    IntervalBarRenderer intervalBarRenderer = new IntervalBarRenderer();
    CategoryPlot categoryPlot = new CategoryPlot((CategoryDataset)paramIntervalCategoryDataset, categoryAxis, (ValueAxis)numberAxis, (CategoryItemRenderer)intervalBarRenderer);
    JFreeChart jFreeChart = new JFreeChart("IntervalBarChartDemo1", (Plot)categoryPlot);
    categoryPlot.setDomainGridlinesVisible(true);
    categoryPlot.setRangePannable(true);
    ChartUtilities.applyCurrentTheme(jFreeChart);
    return jFreeChart;
  }
  
  public static JPanel createDemoPanel() {
    JFreeChart jFreeChart = createChart(createDataset());
    return (JPanel)new ChartPanel(jFreeChart);
  }
  
  public static void main(String[] paramArrayOfString) {
    IntervalBarChartDemo1 intervalBarChartDemo1 = new IntervalBarChartDemo1("JFreeChart: IntervalBarChartDemo1.java");
    intervalBarChartDemo1.pack();
    RefineryUtilities.centerFrameOnScreen((Window)intervalBarChartDemo1);
    intervalBarChartDemo1.setVisible(true);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/IntervalBarChartDemo1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */