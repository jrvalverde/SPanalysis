package demo;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GradientPaint;
import java.awt.Window;
import java.awt.geom.Rectangle2D;
import javax.swing.JPanel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.LegendItem;
import org.jfree.chart.LegendItemCollection;
import org.jfree.chart.LegendItemSource;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.renderer.category.BarRenderer;
import org.jfree.chart.title.LegendTitle;
import org.jfree.chart.title.TextTitle;
import org.jfree.chart.title.Title;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.HorizontalAlignment;
import org.jfree.ui.RectangleEdge;
import org.jfree.ui.RectangleInsets;
import org.jfree.ui.RefineryUtilities;

public class StackedBarChartDemo2 extends ApplicationFrame {
  public StackedBarChartDemo2(String paramString) {
    super(paramString);
    JPanel jPanel = createDemoPanel();
    jPanel.setPreferredSize(new Dimension(500, 270));
    setContentPane(jPanel);
  }
  
  private static CategoryDataset createDataset() {
    DefaultCategoryDataset defaultCategoryDataset = new DefaultCategoryDataset();
    defaultCategoryDataset.addValue(81.0D, "Against all torture", "Italy");
    defaultCategoryDataset.addValue(72.0D, "Against all torture", "Great Britain");
    defaultCategoryDataset.addValue(58.0D, "Against all torture", "USA");
    defaultCategoryDataset.addValue(48.0D, "Against all torture", "Israel");
    defaultCategoryDataset.addValue(43.0D, "Against all torture", "Russia");
    defaultCategoryDataset.addValue(23.0D, "Against all torture", "India");
    defaultCategoryDataset.addValue(59.0D, "Against all torture", "Average (*)");
    defaultCategoryDataset.addValue(5.0D, "-", "Italy");
    defaultCategoryDataset.addValue(4.0D, "-", "Great Britain");
    defaultCategoryDataset.addValue(6.0D, "-", "USA");
    defaultCategoryDataset.addValue(9.0D, "-", "Israel");
    defaultCategoryDataset.addValue(20.0D, "-", "Russia");
    defaultCategoryDataset.addValue(45.0D, "-", "India");
    defaultCategoryDataset.addValue(12.0D, "-", "Average (*)");
    defaultCategoryDataset.addValue(14.0D, "Some degree permissible", "Italy");
    defaultCategoryDataset.addValue(24.0D, "Some degree permissible", "Great Britain");
    defaultCategoryDataset.addValue(36.0D, "Some degree permissible", "USA");
    defaultCategoryDataset.addValue(43.0D, "Some degree permissible", "Israel");
    defaultCategoryDataset.addValue(37.0D, "Some degree permissible", "Russia");
    defaultCategoryDataset.addValue(32.0D, "Some degree permissible", "India");
    defaultCategoryDataset.addValue(29.0D, "Some degree permissible", "Average (*)");
    return (CategoryDataset)defaultCategoryDataset;
  }
  
  private static JFreeChart createChart(CategoryDataset paramCategoryDataset) {
    JFreeChart jFreeChart = ChartFactory.createStackedBarChart("Public Opinion : Torture of Prisoners", "Country", "%", paramCategoryDataset, PlotOrientation.HORIZONTAL, false, true, false);
    jFreeChart.getTitle().setMargin(2.0D, 0.0D, 0.0D, 0.0D);
    TextTitle textTitle1 = new TextTitle("Source: http://news.bbc.co.uk/1/hi/world/6063386.stm", new Font("Dialog", 0, 11));
    textTitle1.setPosition(RectangleEdge.BOTTOM);
    textTitle1.setHorizontalAlignment(HorizontalAlignment.RIGHT);
    textTitle1.setMargin(0.0D, 0.0D, 4.0D, 4.0D);
    jFreeChart.addSubtitle((Title)textTitle1);
    TextTitle textTitle2 = new TextTitle("(*) Across 27,000 respondents in 25 countries", new Font("Dialog", 0, 11));
    textTitle2.setPosition(RectangleEdge.BOTTOM);
    textTitle2.setHorizontalAlignment(HorizontalAlignment.RIGHT);
    textTitle2.setMargin(4.0D, 0.0D, 2.0D, 4.0D);
    jFreeChart.addSubtitle((Title)textTitle2);
    CategoryPlot categoryPlot = (CategoryPlot)jFreeChart.getPlot();
    LegendItemCollection legendItemCollection = new LegendItemCollection();
    legendItemCollection.add(new LegendItem("Against all torture", null, null, null, new Rectangle2D.Double(-6.0D, -3.0D, 12.0D, 6.0D), Color.green));
    legendItemCollection.add(new LegendItem("Some degree permissible", null, null, null, new Rectangle2D.Double(-6.0D, -3.0D, 12.0D, 6.0D), Color.red));
    categoryPlot.setFixedLegendItems(legendItemCollection);
    categoryPlot.setInsets(new RectangleInsets(5.0D, 5.0D, 5.0D, 20.0D));
    LegendTitle legendTitle = new LegendTitle((LegendItemSource)categoryPlot);
    legendTitle.setPosition(RectangleEdge.BOTTOM);
    jFreeChart.addSubtitle((Title)legendTitle);
    categoryPlot.setDomainGridlinesVisible(true);
    NumberAxis numberAxis = (NumberAxis)categoryPlot.getRangeAxis();
    numberAxis.setStandardTickUnits(NumberAxis.createIntegerTickUnits());
    numberAxis.setUpperMargin(0.0D);
    BarRenderer barRenderer = (BarRenderer)categoryPlot.getRenderer();
    barRenderer.setDrawBarOutline(false);
    ChartUtilities.applyCurrentTheme(jFreeChart);
    GradientPaint gradientPaint1 = new GradientPaint(0.0F, 0.0F, Color.green, 0.0F, 0.0F, new Color(0, 64, 0));
    Color color = new Color(0, 0, 0, 0);
    GradientPaint gradientPaint2 = new GradientPaint(0.0F, 0.0F, Color.red, 0.0F, 0.0F, new Color(64, 0, 0));
    barRenderer.setSeriesPaint(0, gradientPaint1);
    barRenderer.setSeriesPaint(1, color);
    barRenderer.setSeriesPaint(2, gradientPaint2);
    return jFreeChart;
  }
  
  public static JPanel createDemoPanel() {
    JFreeChart jFreeChart = createChart(createDataset());
    return (JPanel)new ChartPanel(jFreeChart);
  }
  
  public static void main(String[] paramArrayOfString) {
    StackedBarChartDemo2 stackedBarChartDemo2 = new StackedBarChartDemo2("JFreeChart: StackedBarChartDemo2.java");
    stackedBarChartDemo2.pack();
    RefineryUtilities.centerFrameOnScreen((Window)stackedBarChartDemo2);
    stackedBarChartDemo2.setVisible(true);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/StackedBarChartDemo2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */