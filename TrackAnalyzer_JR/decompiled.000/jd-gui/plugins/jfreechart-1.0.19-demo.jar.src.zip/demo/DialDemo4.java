package demo;

import java.awt.BasicStroke;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GradientPaint;
import java.awt.Point;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.Plot;
import org.jfree.chart.plot.dial.ArcDialFrame;
import org.jfree.chart.plot.dial.DialBackground;
import org.jfree.chart.plot.dial.DialFrame;
import org.jfree.chart.plot.dial.DialLayer;
import org.jfree.chart.plot.dial.DialPlot;
import org.jfree.chart.plot.dial.DialPointer;
import org.jfree.chart.plot.dial.DialScale;
import org.jfree.chart.plot.dial.StandardDialScale;
import org.jfree.data.general.DefaultValueDataset;
import org.jfree.data.general.ValueDataset;
import org.jfree.ui.GradientPaintTransformType;
import org.jfree.ui.GradientPaintTransformer;
import org.jfree.ui.StandardGradientPaintTransformer;

public class DialDemo4 extends JFrame {
  public static JPanel createDemoPanel() {
    return new DemoPanel();
  }
  
  public DialDemo4(String paramString) {
    super(paramString);
    setDefaultCloseOperation(3);
    setContentPane(createDemoPanel());
  }
  
  public static void main(String[] paramArrayOfString) {
    DialDemo4 dialDemo4 = new DialDemo4("JFreeChart: DialDemo4.java");
    dialDemo4.pack();
    dialDemo4.setVisible(true);
  }
  
  static class DemoPanel extends JPanel implements ChangeListener {
    JSlider slider;
    
    DefaultValueDataset dataset = new DefaultValueDataset(50.0D);
    
    public DemoPanel() {
      super(new BorderLayout());
      DialPlot dialPlot = new DialPlot();
      dialPlot.setView(0.78D, 0.37D, 0.22D, 0.26D);
      dialPlot.setDataset((ValueDataset)this.dataset);
      ArcDialFrame arcDialFrame = new ArcDialFrame(-10.0D, 20.0D);
      arcDialFrame.setInnerRadius(0.7D);
      arcDialFrame.setOuterRadius(0.9D);
      arcDialFrame.setForegroundPaint(Color.darkGray);
      arcDialFrame.setStroke(new BasicStroke(3.0F));
      dialPlot.setDialFrame((DialFrame)arcDialFrame);
      GradientPaint gradientPaint = new GradientPaint(new Point(), new Color(255, 255, 255), new Point(), new Color(240, 240, 240));
      DialBackground dialBackground = new DialBackground(gradientPaint);
      dialBackground.setGradientPaintTransformer((GradientPaintTransformer)new StandardGradientPaintTransformer(GradientPaintTransformType.VERTICAL));
      dialPlot.addLayer((DialLayer)dialBackground);
      StandardDialScale standardDialScale = new StandardDialScale(0.0D, 100.0D, -8.0D, 16.0D, 10.0D, 4);
      standardDialScale.setTickRadius(0.82D);
      standardDialScale.setTickLabelOffset(-0.04D);
      standardDialScale.setMajorTickIncrement(25.0D);
      standardDialScale.setTickLabelFont(new Font("Dialog", 0, 14));
      dialPlot.addScale(0, (DialScale)standardDialScale);
      DialPointer.Pin pin = new DialPointer.Pin();
      pin.setRadius(0.84D);
      dialPlot.addLayer((DialLayer)pin);
      JFreeChart jFreeChart = new JFreeChart((Plot)dialPlot);
      jFreeChart.setTitle("Dial Demo 4");
      ChartPanel chartPanel = new ChartPanel(jFreeChart);
      chartPanel.setPreferredSize(new Dimension(400, 250));
      this.slider = new JSlider(0, 100);
      this.slider.setMajorTickSpacing(10);
      this.slider.setPaintLabels(true);
      this.slider.addChangeListener(this);
      add((Component)chartPanel);
      add(this.slider, "South");
    }
    
    public void stateChanged(ChangeEvent param1ChangeEvent) {
      this.dataset.setValue(new Integer(this.slider.getValue()));
    }
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/DialDemo4.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */