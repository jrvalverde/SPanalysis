package demo;

import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import javax.swing.Timer;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.JFreeChart;
import org.jfree.data.general.DefaultPieDataset;
import org.jfree.data.general.PieDataset;

public class ChartTiming1 implements ActionListener {
  private boolean finished;
  
  public void run() {
    this.finished = false;
    DefaultPieDataset defaultPieDataset = new DefaultPieDataset();
    defaultPieDataset.setValue("One", new Double(10.3D));
    defaultPieDataset.setValue("Two", new Double(8.5D));
    defaultPieDataset.setValue("Three", new Double(3.9D));
    defaultPieDataset.setValue("Four", new Double(3.9D));
    defaultPieDataset.setValue("Five", new Double(3.9D));
    defaultPieDataset.setValue("Six", new Double(3.9D));
    boolean bool = true;
    JFreeChart jFreeChart = ChartFactory.createPieChart("Testing", (PieDataset)defaultPieDataset, bool, true, false);
    BufferedImage bufferedImage = new BufferedImage(400, 300, 1);
    Graphics2D graphics2D = bufferedImage.createGraphics();
    Rectangle2D.Double double_ = new Rectangle2D.Double(0.0D, 0.0D, 400.0D, 300.0D);
    Timer timer = new Timer(10000, this);
    timer.setRepeats(false);
    byte b = 0;
    timer.start();
    while (!this.finished) {
      jFreeChart.draw(graphics2D, double_, null, null);
      System.out.println("Charts drawn..." + b);
      if (!this.finished)
        b++; 
    } 
    System.out.println("DONE");
  }
  
  public void actionPerformed(ActionEvent paramActionEvent) {
    this.finished = true;
  }
  
  public static void main(String[] paramArrayOfString) {
    ChartTiming1 chartTiming1 = new ChartTiming1();
    chartTiming1.run();
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/ChartTiming1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */