package demo;

import java.awt.Container;
import java.awt.Dimension;
import java.awt.Window;
import java.text.DecimalFormat;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.renderer.category.StackedBarRenderer;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

public class StackedBarDemo3 extends ApplicationFrame {
  public StackedBarDemo3(String paramString) {
    super(paramString);
    DefaultCategoryDataset defaultCategoryDataset = new DefaultCategoryDataset();
    defaultCategoryDataset.addValue(1.0D, "Row 1", "Column 1");
    defaultCategoryDataset.addValue(5.0D, "Row 1", "Column 2");
    defaultCategoryDataset.addValue(3.0D, "Row 1", "Column 3");
    defaultCategoryDataset.addValue(2.0D, "Row 2", "Column 1");
    defaultCategoryDataset.addValue(3.0D, "Row 2", "Column 2");
    defaultCategoryDataset.addValue(2.0D, "Row 2", "Column 3");
    JFreeChart jFreeChart = ChartFactory.createStackedBarChart("StackedBarDemo3", "Category", "Value", (CategoryDataset)defaultCategoryDataset, PlotOrientation.VERTICAL, true, true, false);
    CategoryPlot categoryPlot = (CategoryPlot)jFreeChart.getPlot();
    StackedBarRenderer stackedBarRenderer = (StackedBarRenderer)categoryPlot.getRenderer();
    stackedBarRenderer.setRenderAsPercentages(true);
    NumberAxis numberAxis = (NumberAxis)categoryPlot.getRangeAxis();
    numberAxis.setLabel("Percentage");
    numberAxis.setNumberFormatOverride(new DecimalFormat("0.0%"));
    ChartPanel chartPanel = new ChartPanel(jFreeChart);
    chartPanel.setPreferredSize(new Dimension(500, 270));
    setContentPane((Container)chartPanel);
  }
  
  public static void main(String[] paramArrayOfString) {
    StackedBarDemo3 stackedBarDemo3 = new StackedBarDemo3("StackedBarDemo3");
    stackedBarDemo3.pack();
    RefineryUtilities.centerFrameOnScreen((Window)stackedBarDemo3);
    stackedBarDemo3.setVisible(true);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/StackedBarDemo3.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */