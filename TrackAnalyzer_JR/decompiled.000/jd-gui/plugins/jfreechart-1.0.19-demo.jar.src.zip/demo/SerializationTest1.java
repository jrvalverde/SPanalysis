package demo;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Window;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import javax.swing.JButton;
import javax.swing.JPanel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.XYPlot;
import org.jfree.data.time.Millisecond;
import org.jfree.data.time.RegularTimePeriod;
import org.jfree.data.time.TimeSeries;
import org.jfree.data.time.TimeSeriesCollection;
import org.jfree.data.xy.XYDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

public class SerializationTest1 extends ApplicationFrame implements ActionListener {
  private TimeSeries series = new TimeSeries("Random Data");
  
  private double lastValue = 100.0D;
  
  public SerializationTest1(String paramString) {
    super(paramString);
    TimeSeriesCollection timeSeriesCollection1 = new TimeSeriesCollection(this.series);
    JFreeChart jFreeChart1 = createChart((XYDataset)timeSeriesCollection1);
    JFreeChart jFreeChart2 = null;
    try {
      ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
      ObjectOutputStream objectOutputStream = new ObjectOutputStream(byteArrayOutputStream);
      objectOutputStream.writeObject(jFreeChart1);
      objectOutputStream.close();
      jFreeChart1 = null;
      timeSeriesCollection1 = null;
      this.series = null;
      System.gc();
      ObjectInputStream objectInputStream = new ObjectInputStream(new ByteArrayInputStream(byteArrayOutputStream.toByteArray()));
      jFreeChart2 = (JFreeChart)objectInputStream.readObject();
      objectInputStream.close();
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
    XYPlot xYPlot = (XYPlot)jFreeChart2.getPlot();
    TimeSeriesCollection timeSeriesCollection2 = (TimeSeriesCollection)xYPlot.getDataset();
    this.series = timeSeriesCollection2.getSeries(0);
    ChartPanel chartPanel = new ChartPanel(jFreeChart2);
    JButton jButton = new JButton("Add New Data Item");
    jButton.setActionCommand("ADD_DATA");
    jButton.addActionListener(this);
    JPanel jPanel = new JPanel(new BorderLayout());
    jPanel.add((Component)chartPanel);
    jPanel.add(jButton, "South");
    chartPanel.setPreferredSize(new Dimension(500, 270));
    setContentPane(jPanel);
  }
  
  private JFreeChart createChart(XYDataset paramXYDataset) {
    JFreeChart jFreeChart = ChartFactory.createTimeSeriesChart("Serialization Test 1", "Time", "Value", paramXYDataset, true, true, false);
    XYPlot xYPlot = (XYPlot)jFreeChart.getPlot();
    ValueAxis valueAxis = xYPlot.getDomainAxis();
    valueAxis.setAutoRange(true);
    valueAxis.setFixedAutoRange(60000.0D);
    return jFreeChart;
  }
  
  public void actionPerformed(ActionEvent paramActionEvent) {
    if (paramActionEvent.getActionCommand().equals("ADD_DATA")) {
      double d = 0.9D + 0.2D * Math.random();
      this.lastValue *= d;
      Millisecond millisecond = new Millisecond();
      System.out.println("Now = " + millisecond.toString());
      this.series.add((RegularTimePeriod)new Millisecond(), this.lastValue);
    } 
  }
  
  public static void main(String[] paramArrayOfString) {
    SerializationTest1 serializationTest1 = new SerializationTest1("Serialization Test 1");
    serializationTest1.pack();
    RefineryUtilities.centerFrameOnScreen((Window)serializationTest1);
    serializationTest1.setVisible(true);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/SerializationTest1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */