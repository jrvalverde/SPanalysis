package demo;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Window;
import java.text.SimpleDateFormat;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.DateAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYItemRenderer;
import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
import org.jfree.data.Range;
import org.jfree.data.time.Month;
import org.jfree.data.time.RegularTimePeriod;
import org.jfree.data.time.TimeSeries;
import org.jfree.data.time.TimeSeriesCollection;
import org.jfree.data.xy.XYDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

public class CrosshairDemo3 extends ApplicationFrame {
  public CrosshairDemo3(String paramString) {
    super(paramString);
    setContentPane(createDemoPanel());
  }
  
  public static JPanel createDemoPanel() {
    return new MyDemoPanel();
  }
  
  public static void main(String[] paramArrayOfString) {
    CrosshairDemo3 crosshairDemo3 = new CrosshairDemo3("JFreeChart: CrosshairDemo3.java");
    crosshairDemo3.pack();
    RefineryUtilities.centerFrameOnScreen((Window)crosshairDemo3);
    crosshairDemo3.setVisible(true);
  }
  
  static class MyDemoPanel extends DemoPanel implements ChangeListener {
    private JFreeChart chart;
    
    private JSlider slider;
    
    public MyDemoPanel() {
      super(new BorderLayout());
      XYDataset xYDataset = createDataset();
      this.chart = createChart(xYDataset);
      addChart(this.chart);
      ChartPanel chartPanel = new ChartPanel(this.chart);
      chartPanel.setPreferredSize(new Dimension(500, 270));
      chartPanel.setMouseZoomable(true);
      JPanel jPanel = new JPanel(new BorderLayout());
      this.slider = new JSlider(0, 100, 50);
      this.slider.addChangeListener(this);
      jPanel.add(this.slider);
      add((Component)chartPanel);
      add(jPanel, "South");
    }
    
    private JFreeChart createChart(XYDataset param1XYDataset) {
      JFreeChart jFreeChart = ChartFactory.createTimeSeriesChart("Legal & General Unit Trust Prices", "Date", "Price Per Unit", param1XYDataset, true, true, false);
      XYPlot xYPlot = (XYPlot)jFreeChart.getPlot();
      xYPlot.setDomainCrosshairVisible(true);
      xYPlot.setDomainCrosshairLockedOnData(false);
      xYPlot.setRangeCrosshairVisible(false);
      XYItemRenderer xYItemRenderer = xYPlot.getRenderer();
      if (xYItemRenderer instanceof XYLineAndShapeRenderer) {
        XYLineAndShapeRenderer xYLineAndShapeRenderer = (XYLineAndShapeRenderer)xYItemRenderer;
        xYLineAndShapeRenderer.setBaseShapesVisible(true);
        xYLineAndShapeRenderer.setBaseShapesFilled(true);
      } 
      DateAxis dateAxis = (DateAxis)xYPlot.getDomainAxis();
      dateAxis.setDateFormatOverride(new SimpleDateFormat("MMM-yyyy"));
      return jFreeChart;
    }
    
    private XYDataset createDataset() {
      TimeSeries timeSeries1 = new TimeSeries("L&G European Index Trust");
      timeSeries1.add((RegularTimePeriod)new Month(2, 2001), 181.8D);
      timeSeries1.add((RegularTimePeriod)new Month(3, 2001), 167.3D);
      timeSeries1.add((RegularTimePeriod)new Month(4, 2001), 153.8D);
      timeSeries1.add((RegularTimePeriod)new Month(5, 2001), 167.6D);
      timeSeries1.add((RegularTimePeriod)new Month(6, 2001), 158.8D);
      timeSeries1.add((RegularTimePeriod)new Month(7, 2001), 148.3D);
      timeSeries1.add((RegularTimePeriod)new Month(8, 2001), 153.9D);
      timeSeries1.add((RegularTimePeriod)new Month(9, 2001), 142.7D);
      timeSeries1.add((RegularTimePeriod)new Month(10, 2001), 123.2D);
      timeSeries1.add((RegularTimePeriod)new Month(11, 2001), 131.8D);
      timeSeries1.add((RegularTimePeriod)new Month(12, 2001), 139.6D);
      timeSeries1.add((RegularTimePeriod)new Month(1, 2002), 142.9D);
      timeSeries1.add((RegularTimePeriod)new Month(2, 2002), 138.7D);
      timeSeries1.add((RegularTimePeriod)new Month(3, 2002), 137.3D);
      timeSeries1.add((RegularTimePeriod)new Month(4, 2002), 143.9D);
      timeSeries1.add((RegularTimePeriod)new Month(5, 2002), 139.8D);
      timeSeries1.add((RegularTimePeriod)new Month(6, 2002), 137.0D);
      timeSeries1.add((RegularTimePeriod)new Month(7, 2002), 132.8D);
      TimeSeries timeSeries2 = new TimeSeries("L&G UK Index Trust");
      timeSeries2.add((RegularTimePeriod)new Month(2, 2001), 129.6D);
      timeSeries2.add((RegularTimePeriod)new Month(3, 2001), 123.2D);
      timeSeries2.add((RegularTimePeriod)new Month(4, 2001), 117.2D);
      timeSeries2.add((RegularTimePeriod)new Month(5, 2001), 124.1D);
      timeSeries2.add((RegularTimePeriod)new Month(6, 2001), 122.6D);
      timeSeries2.add((RegularTimePeriod)new Month(7, 2001), 119.2D);
      timeSeries2.add((RegularTimePeriod)new Month(8, 2001), 116.5D);
      timeSeries2.add((RegularTimePeriod)new Month(9, 2001), 112.7D);
      timeSeries2.add((RegularTimePeriod)new Month(10, 2001), 101.5D);
      timeSeries2.add((RegularTimePeriod)new Month(11, 2001), 106.1D);
      timeSeries2.add((RegularTimePeriod)new Month(12, 2001), 110.3D);
      timeSeries2.add((RegularTimePeriod)new Month(1, 2002), 111.7D);
      timeSeries2.add((RegularTimePeriod)new Month(2, 2002), 111.0D);
      timeSeries2.add((RegularTimePeriod)new Month(3, 2002), 109.6D);
      timeSeries2.add((RegularTimePeriod)new Month(4, 2002), 113.2D);
      timeSeries2.add((RegularTimePeriod)new Month(5, 2002), 111.6D);
      timeSeries2.add((RegularTimePeriod)new Month(6, 2002), 108.8D);
      timeSeries2.add((RegularTimePeriod)new Month(7, 2002), 101.6D);
      TimeSeriesCollection timeSeriesCollection = new TimeSeriesCollection();
      timeSeriesCollection.addSeries(timeSeries1);
      timeSeriesCollection.addSeries(timeSeries2);
      return (XYDataset)timeSeriesCollection;
    }
    
    public void stateChanged(ChangeEvent param1ChangeEvent) {
      int i = this.slider.getValue();
      XYPlot xYPlot = (XYPlot)this.chart.getPlot();
      ValueAxis valueAxis = xYPlot.getDomainAxis();
      Range range = valueAxis.getRange();
      double d = valueAxis.getLowerBound() + i / 100.0D * range.getLength();
      xYPlot.setDomainCrosshairValue(d);
    }
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/CrosshairDemo3.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */