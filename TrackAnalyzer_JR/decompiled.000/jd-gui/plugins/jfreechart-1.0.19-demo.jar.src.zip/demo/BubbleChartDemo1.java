package demo;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Window;
import javax.swing.JPanel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYItemRenderer;
import org.jfree.data.xy.DefaultXYZDataset;
import org.jfree.data.xy.XYZDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

public class BubbleChartDemo1 extends ApplicationFrame {
  public BubbleChartDemo1(String paramString) {
    super(paramString);
    JPanel jPanel = createDemoPanel();
    jPanel.setPreferredSize(new Dimension(500, 270));
    setContentPane(jPanel);
  }
  
  private static JFreeChart createChart(XYZDataset paramXYZDataset) {
    JFreeChart jFreeChart = ChartFactory.createBubbleChart("Bubble Chart Demo 1", "X", "Y", paramXYZDataset, PlotOrientation.HORIZONTAL, true, true, false);
    XYPlot xYPlot = (XYPlot)jFreeChart.getPlot();
    xYPlot.setForegroundAlpha(0.65F);
    xYPlot.setDomainPannable(true);
    xYPlot.setRangePannable(true);
    XYItemRenderer xYItemRenderer = xYPlot.getRenderer();
    xYItemRenderer.setSeriesPaint(0, Color.blue);
    NumberAxis numberAxis1 = (NumberAxis)xYPlot.getDomainAxis();
    numberAxis1.setLowerMargin(0.15D);
    numberAxis1.setUpperMargin(0.15D);
    NumberAxis numberAxis2 = (NumberAxis)xYPlot.getRangeAxis();
    numberAxis2.setLowerMargin(0.15D);
    numberAxis2.setUpperMargin(0.15D);
    return jFreeChart;
  }
  
  public static XYZDataset createDataset() {
    DefaultXYZDataset defaultXYZDataset = new DefaultXYZDataset();
    double[] arrayOfDouble1 = { 2.1D, 2.3D, 2.3D, 2.2D, 2.2D, 1.8D, 1.8D, 1.9D, 2.3D, 3.8D };
    double[] arrayOfDouble2 = { 14.1D, 11.1D, 10.0D, 8.8D, 8.7D, 8.4D, 5.4D, 4.1D, 4.1D, 25.0D };
    double[] arrayOfDouble3 = { 2.4D, 2.7D, 2.7D, 2.2D, 2.2D, 2.2D, 2.1D, 2.2D, 1.6D, 4.0D };
    double[][] arrayOfDouble = { arrayOfDouble1, arrayOfDouble2, arrayOfDouble3 };
    defaultXYZDataset.addSeries("Series 1", arrayOfDouble);
    return (XYZDataset)defaultXYZDataset;
  }
  
  public static JPanel createDemoPanel() {
    JFreeChart jFreeChart = createChart(createDataset());
    ChartPanel chartPanel = new ChartPanel(jFreeChart);
    chartPanel.setMouseWheelEnabled(true);
    chartPanel.setDomainZoomable(true);
    chartPanel.setRangeZoomable(true);
    return (JPanel)chartPanel;
  }
  
  public static void main(String[] paramArrayOfString) {
    BubbleChartDemo1 bubbleChartDemo1 = new BubbleChartDemo1("JFreeChart: BubbleChartDemo1.java");
    bubbleChartDemo1.pack();
    RefineryUtilities.centerFrameOnScreen((Window)bubbleChartDemo1);
    bubbleChartDemo1.setVisible(true);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/BubbleChartDemo1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */