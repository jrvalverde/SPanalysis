package demo;

import java.awt.Dimension;
import java.awt.Window;
import javax.swing.JPanel;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.LegendItem;
import org.jfree.chart.LegendItemCollection;
import org.jfree.chart.axis.AxisLocation;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.Plot;
import org.jfree.chart.renderer.category.BarRenderer;
import org.jfree.chart.renderer.category.CategoryItemRenderer;
import org.jfree.chart.renderer.category.GroupedStackedBarRenderer;
import org.jfree.data.KeyToGroupMap;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

public class DualAxisDemo6 extends ApplicationFrame {
  public DualAxisDemo6(String paramString) {
    super(paramString);
    JPanel jPanel = createDemoPanel();
    jPanel.setPreferredSize(new Dimension(500, 270));
    setContentPane(jPanel);
  }
  
  private static CategoryDataset createDataset1() {
    String str1 = "Series 1A";
    String str2 = "Series 1B";
    String str3 = "Category 1";
    String str4 = "Category 2";
    String str5 = "Category 3";
    String str6 = "Category 4";
    DefaultCategoryDataset defaultCategoryDataset = new DefaultCategoryDataset();
    defaultCategoryDataset.addValue(1.0D, str1, str3);
    defaultCategoryDataset.addValue(4.0D, str1, str4);
    defaultCategoryDataset.addValue(3.0D, str1, str5);
    defaultCategoryDataset.addValue(5.0D, str1, str6);
    defaultCategoryDataset.addValue(3.0D, str2, str3);
    defaultCategoryDataset.addValue(6.0D, str2, str4);
    defaultCategoryDataset.addValue(1.0D, str2, str5);
    defaultCategoryDataset.addValue(5.0D, str2, str6);
    return (CategoryDataset)defaultCategoryDataset;
  }
  
  private static CategoryDataset createDataset2() {
    String str1 = "Dummy 2";
    String str2 = "Series 2";
    String str3 = "Category 1";
    String str4 = "Category 2";
    String str5 = "Category 3";
    String str6 = "Category 4";
    DefaultCategoryDataset defaultCategoryDataset = new DefaultCategoryDataset();
    defaultCategoryDataset.addValue(null, str1, str3);
    defaultCategoryDataset.addValue(null, str1, str4);
    defaultCategoryDataset.addValue(null, str1, str5);
    defaultCategoryDataset.addValue(null, str1, str6);
    defaultCategoryDataset.addValue(75.0D, str2, str3);
    defaultCategoryDataset.addValue(87.0D, str2, str4);
    defaultCategoryDataset.addValue(96.0D, str2, str5);
    defaultCategoryDataset.addValue(68.0D, str2, str6);
    return (CategoryDataset)defaultCategoryDataset;
  }
  
  private static JFreeChart createChart(CategoryDataset paramCategoryDataset1, CategoryDataset paramCategoryDataset2) {
    CategoryAxis categoryAxis = new CategoryAxis("Category");
    NumberAxis numberAxis1 = new NumberAxis("Value");
    GroupedStackedBarRenderer groupedStackedBarRenderer = new GroupedStackedBarRenderer();
    KeyToGroupMap keyToGroupMap = new KeyToGroupMap("G1");
    keyToGroupMap.mapKeyToGroup("Series 1A", "G1");
    keyToGroupMap.mapKeyToGroup("Series 1B", "G1");
    keyToGroupMap.mapKeyToGroup("NOTHING", "G2");
    groupedStackedBarRenderer.setSeriesToGroupMap(keyToGroupMap);
    CategoryPlot categoryPlot = new CategoryPlot(paramCategoryDataset1, categoryAxis, (ValueAxis)numberAxis1, (CategoryItemRenderer)groupedStackedBarRenderer) {
        public LegendItemCollection getLegendItems() {
          LegendItemCollection legendItemCollection = new LegendItemCollection();
          legendItemCollection.addAll(getRenderer().getLegendItems());
          CategoryDataset categoryDataset = getDataset(1);
          if (categoryDataset != null) {
            CategoryItemRenderer categoryItemRenderer = getRenderer(1);
            if (categoryItemRenderer != null) {
              LegendItem legendItem = categoryItemRenderer.getLegendItem(1, 1);
              legendItemCollection.add(legendItem);
            } 
          } 
          return legendItemCollection;
        }
      };
    JFreeChart jFreeChart = new JFreeChart("Dual Axis Bar Chart", (Plot)categoryPlot);
    categoryPlot.setDomainAxisLocation(AxisLocation.BOTTOM_OR_RIGHT);
    categoryPlot.setDataset(1, paramCategoryDataset2);
    categoryPlot.mapDatasetToRangeAxis(1, 1);
    NumberAxis numberAxis2 = new NumberAxis("Secondary");
    categoryPlot.setRangeAxis(1, (ValueAxis)numberAxis2);
    categoryPlot.setRangeAxisLocation(1, AxisLocation.BOTTOM_OR_RIGHT);
    BarRenderer barRenderer = new BarRenderer();
    categoryPlot.setRenderer(1, (CategoryItemRenderer)barRenderer);
    ChartUtilities.applyCurrentTheme(jFreeChart);
    return jFreeChart;
  }
  
  public static JPanel createDemoPanel() {
    JFreeChart jFreeChart = createChart(createDataset1(), createDataset2());
    return (JPanel)new ChartPanel(jFreeChart);
  }
  
  public static void main(String[] paramArrayOfString) {
    DualAxisDemo6 dualAxisDemo6 = new DualAxisDemo6("JFreeChart: DualAxisDemo6.java");
    dualAxisDemo6.pack();
    RefineryUtilities.centerFrameOnScreen((Window)dualAxisDemo6);
    dualAxisDemo6.setVisible(true);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/DualAxisDemo6.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */