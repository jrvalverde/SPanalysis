package demo.orsoncharts.swing;

import com.orsoncharts.Chart3D;
import com.orsoncharts.Chart3DPanel;
import com.orsoncharts.graphics3d.swing.DisplayPanel3D;
import com.orsoncharts.graphics3d.swing.Panel3D;
import demo.orsoncharts.SurfaceRenderer2;
import java.awt.BorderLayout;
import java.awt.Component;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class SurfaceRendererDemo2 extends JFrame {
  public SurfaceRendererDemo2(String paramString) {
    super(paramString);
    addWindowListener(new ExitOnClose());
    getContentPane().add(createDemoPanel());
  }
  
  public static JPanel createDemoPanel() {
    DemoPanel demoPanel = new DemoPanel(new BorderLayout());
    demoPanel.setPreferredSize(OrsonChartsDemo.DEFAULT_CONTENT_SIZE);
    Chart3D chart3D = SurfaceRenderer2.createChart();
    Chart3DPanel chart3DPanel = new Chart3DPanel(chart3D);
    chart3DPanel.zoomToFit(OrsonChartsDemo.DEFAULT_CONTENT_SIZE);
    demoPanel.setChartPanel(chart3DPanel);
    demoPanel.add((Component)new DisplayPanel3D((Panel3D)chart3DPanel));
    return demoPanel;
  }
  
  public static void main(String[] paramArrayOfString) {
    SurfaceRendererDemo2 surfaceRendererDemo2 = new SurfaceRendererDemo2("OrsonCharts: SurfaceRendererDemo2.java");
    surfaceRendererDemo2.pack();
    surfaceRendererDemo2.setVisible(true);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/orsoncharts/swing/SurfaceRendererDemo2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */