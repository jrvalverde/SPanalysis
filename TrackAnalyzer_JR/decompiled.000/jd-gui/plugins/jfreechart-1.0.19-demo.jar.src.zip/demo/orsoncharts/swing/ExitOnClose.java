package demo.orsoncharts.swing;

import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class ExitOnClose extends WindowAdapter {
  public void windowClosing(WindowEvent paramWindowEvent) {
    System.exit(0);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/orsoncharts/swing/ExitOnClose.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */