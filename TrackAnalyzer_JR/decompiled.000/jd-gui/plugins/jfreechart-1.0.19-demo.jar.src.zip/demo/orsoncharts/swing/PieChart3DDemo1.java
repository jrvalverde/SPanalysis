package demo.orsoncharts.swing;

import com.orsoncharts.Chart3D;
import com.orsoncharts.Chart3DPanel;
import com.orsoncharts.data.PieDataset3D;
import com.orsoncharts.graphics3d.RenderedElement;
import com.orsoncharts.graphics3d.swing.DisplayPanel3D;
import com.orsoncharts.graphics3d.swing.Panel3D;
import com.orsoncharts.interaction.Chart3DMouseEvent;
import com.orsoncharts.interaction.Chart3DMouseListener;
import demo.orsoncharts.PieChart3D1;
import java.awt.BorderLayout;
import java.awt.Component;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

public class PieChart3DDemo1 extends JFrame {
  public PieChart3DDemo1(String paramString) {
    super(paramString);
    addWindowListener(new ExitOnClose());
    getContentPane().add(createDemoPanel());
  }
  
  public static JPanel createDemoPanel() {
    final DemoPanel content = new DemoPanel(new BorderLayout());
    demoPanel.setPreferredSize(OrsonChartsDemo.DEFAULT_CONTENT_SIZE);
    PieDataset3D pieDataset3D = PieChart3D1.createDataset();
    Chart3D chart3D = PieChart3D1.createChart(pieDataset3D);
    Chart3DPanel chart3DPanel = new Chart3DPanel(chart3D);
    chart3DPanel.setMargin(0.05D);
    chart3DPanel.addChartMouseListener(new Chart3DMouseListener() {
          public void chartMouseClicked(Chart3DMouseEvent param1Chart3DMouseEvent) {
            RenderedElement renderedElement = param1Chart3DMouseEvent.getElement();
            if (renderedElement != null)
              JOptionPane.showMessageDialog(content, Chart3D.renderedElementToString(param1Chart3DMouseEvent.getElement())); 
          }
          
          public void chartMouseMoved(Chart3DMouseEvent param1Chart3DMouseEvent) {}
        });
    demoPanel.setChartPanel(chart3DPanel);
    demoPanel.add((Component)new DisplayPanel3D((Panel3D)chart3DPanel));
    chart3DPanel.zoomToFit(OrsonChartsDemo.DEFAULT_CONTENT_SIZE);
    return demoPanel;
  }
  
  public static void main(String[] paramArrayOfString) {
    PieChart3DDemo1 pieChart3DDemo1 = new PieChart3DDemo1("OrsonCharts: PieChart3DDemo1.java");
    pieChart3DDemo1.pack();
    pieChart3DDemo1.setVisible(true);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/orsoncharts/swing/PieChart3DDemo1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */