package demo.orsoncharts.swing;

import com.orsoncharts.Chart3D;
import com.orsoncharts.Chart3DFactory;
import com.orsoncharts.Chart3DPanel;
import com.orsoncharts.axis.ValueAxis3D;
import com.orsoncharts.data.DefaultKeyedValues;
import com.orsoncharts.data.KeyedValues;
import com.orsoncharts.data.category.CategoryDataset3D;
import com.orsoncharts.data.category.StandardCategoryDataset3D;
import com.orsoncharts.graphics3d.Offset3D;
import com.orsoncharts.graphics3d.ViewPoint3D;
import com.orsoncharts.graphics3d.swing.DisplayPanel3D;
import com.orsoncharts.graphics3d.swing.Panel3D;
import com.orsoncharts.label.CategoryItemLabelGenerator;
import com.orsoncharts.label.ItemLabelPositioning;
import com.orsoncharts.label.StandardCategoryItemLabelGenerator;
import com.orsoncharts.plot.CategoryPlot3D;
import com.orsoncharts.renderer.category.LineRenderer3D;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.FlowLayout;
import java.awt.LayoutManager;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

public class AxisRangeDemo3 extends JFrame {
  public AxisRangeDemo3(String paramString) {
    super(paramString);
    addWindowListener(new ExitOnClose());
    getContentPane().add(createDemoPanel());
  }
  
  public static JPanel createDemoPanel() {
    CustomDemoPanel customDemoPanel = new CustomDemoPanel(new BorderLayout());
    customDemoPanel.setPreferredSize(OrsonChartsDemo.DEFAULT_CONTENT_SIZE);
    CategoryDataset3D categoryDataset3D = createDataset();
    Chart3D chart3D = Chart3DFactory.createLineChart("AxisRangeDemo3", "A test for axis range changes on a line chart", categoryDataset3D, "Row", "Category", "Value");
    chart3D.setChartBoxColor(new Color(255, 255, 255, 128));
    chart3D.setViewPoint(ViewPoint3D.createAboveLeftViewPoint(40.0D));
    CategoryPlot3D categoryPlot3D = (CategoryPlot3D)chart3D.getPlot();
    categoryPlot3D.getValueAxis().setRange(-500.0D, 500.0D);
    categoryPlot3D.getRowAxis().setVisible(false);
    LineRenderer3D lineRenderer3D = (LineRenderer3D)categoryPlot3D.getRenderer();
    lineRenderer3D.setItemLabelPositioning(ItemLabelPositioning.FRONT_AND_BACK);
    lineRenderer3D.setItemLabelOffsets(new Offset3D(0.0D, 0.0D, 1.2D));
    lineRenderer3D.setItemLabelGenerator((CategoryItemLabelGenerator)new StandardCategoryItemLabelGenerator("%4$.2f"));
    Chart3DPanel chart3DPanel = new Chart3DPanel(chart3D);
    customDemoPanel.setChartPanel(chart3DPanel);
    customDemoPanel.add((Component)new DisplayPanel3D((Panel3D)chart3DPanel));
    chart3DPanel.zoomToFit(OrsonChartsDemo.DEFAULT_CONTENT_SIZE);
    return customDemoPanel;
  }
  
  private static CategoryDataset3D createDataset() {
    StandardCategoryDataset3D standardCategoryDataset3D = new StandardCategoryDataset3D();
    DefaultKeyedValues defaultKeyedValues1 = new DefaultKeyedValues();
    defaultKeyedValues1.put("A", Integer.valueOf(-500));
    defaultKeyedValues1.put("B", Integer.valueOf(-200));
    defaultKeyedValues1.put("C", Integer.valueOf(-400));
    defaultKeyedValues1.put("D", Integer.valueOf(-150));
    standardCategoryDataset3D.addSeriesAsRow("All Negative", (KeyedValues)defaultKeyedValues1);
    DefaultKeyedValues defaultKeyedValues2 = new DefaultKeyedValues();
    defaultKeyedValues2.put("A", Integer.valueOf(-500));
    defaultKeyedValues2.put("B", Integer.valueOf(500));
    defaultKeyedValues2.put("C", Integer.valueOf(0));
    defaultKeyedValues2.put("D", Integer.valueOf(-150));
    standardCategoryDataset3D.addSeriesAsRow("Alternating 1", (KeyedValues)defaultKeyedValues2);
    DefaultKeyedValues defaultKeyedValues3 = new DefaultKeyedValues();
    defaultKeyedValues3.put("A", Integer.valueOf(500));
    defaultKeyedValues3.put("B", Integer.valueOf(-500));
    defaultKeyedValues3.put("C", Integer.valueOf(0));
    defaultKeyedValues3.put("D", Integer.valueOf(150));
    standardCategoryDataset3D.addSeriesAsRow("Alternating 2", (KeyedValues)defaultKeyedValues3);
    DefaultKeyedValues defaultKeyedValues4 = new DefaultKeyedValues();
    defaultKeyedValues4.put("A", Integer.valueOf(500));
    defaultKeyedValues4.put("B", Integer.valueOf(200));
    defaultKeyedValues4.put("C", Integer.valueOf(400));
    defaultKeyedValues4.put("D", Integer.valueOf(150));
    standardCategoryDataset3D.addSeriesAsRow("All Positive", (KeyedValues)defaultKeyedValues4);
    return (CategoryDataset3D)standardCategoryDataset3D;
  }
  
  public static void main(String[] paramArrayOfString) {
    AxisRangeDemo3 axisRangeDemo3 = new AxisRangeDemo3("OrsonCharts: AxisRangeDemo3.java");
    axisRangeDemo3.pack();
    axisRangeDemo3.setVisible(true);
  }
  
  static class CustomDemoPanel extends DemoPanel implements ChangeListener {
    private JSlider slider1 = new JSlider(-1000, 0);
    
    private JSlider slider2;
    
    public CustomDemoPanel(LayoutManager param1LayoutManager) {
      super(param1LayoutManager);
      this.slider1.setValue(-500);
      this.slider2 = new JSlider(0, 1000);
      this.slider2.setValue(500);
      this.slider1.addChangeListener(this);
      this.slider2.addChangeListener(this);
      JPanel jPanel = new JPanel(new FlowLayout());
      jPanel.add(new JLabel("Lower bound: "));
      jPanel.add(this.slider1);
      jPanel.add(new JLabel("Upper bound: "));
      jPanel.add(this.slider2);
      add(jPanel, "South");
    }
    
    public void stateChanged(ChangeEvent param1ChangeEvent) {
      Chart3D chart3D = (Chart3D)getChartPanel().getDrawable();
      CategoryPlot3D categoryPlot3D = (CategoryPlot3D)chart3D.getPlot();
      ValueAxis3D valueAxis3D = categoryPlot3D.getValueAxis();
      int i = this.slider1.getValue();
      int j = this.slider2.getValue();
      if (i != j)
        valueAxis3D.setRange(i, j); 
    }
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/orsoncharts/swing/AxisRangeDemo3.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */