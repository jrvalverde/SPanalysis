package demo.orsoncharts.swing;

import com.orsoncharts.Chart3D;
import com.orsoncharts.Chart3DPanel;
import com.orsoncharts.data.xyz.XYZDataset;
import com.orsoncharts.graphics3d.swing.DisplayPanel3D;
import com.orsoncharts.graphics3d.swing.Panel3D;
import demo.orsoncharts.ScatterPlot3D3;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.GridLayout;
import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class ScatterPlot3DDemo3 extends JFrame {
  public ScatterPlot3DDemo3(String paramString) {
    super(paramString);
    addWindowListener(new ExitOnClose());
    getContentPane().add(createDemoPanel());
  }
  
  public static JPanel createDemoPanel() {
    DemoPanel demoPanel = new DemoPanel(new GridLayout(2, 2));
    XYZDataset[] arrayOfXYZDataset = ScatterPlot3D3.createDatasets();
    Chart3D chart3D1 = ScatterPlot3D3.createChart("Iris Dataset : Combination 1", arrayOfXYZDataset[0], "Sepal Length", "Sepal Width", "Petal Length");
    Chart3DPanel chart3DPanel1 = new Chart3DPanel(chart3D1);
    chart3DPanel1.setPreferredSize(new Dimension(10, 10));
    chart3DPanel1.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(new Color(255, 255, 255, 0)), BorderFactory.createLineBorder(Color.DARK_GRAY)));
    chart3DPanel1.setMargin(0.35D);
    Chart3D chart3D2 = ScatterPlot3D3.createChart("Iris Dataset : Combination 2", arrayOfXYZDataset[1], "Sepal Length", "Sepal Width", "Petal Width");
    Chart3DPanel chart3DPanel2 = new Chart3DPanel(chart3D2);
    chart3DPanel2.setPreferredSize(new Dimension(10, 10));
    chart3DPanel2.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(new Color(255, 255, 255, 0)), BorderFactory.createLineBorder(Color.DARK_GRAY)));
    chart3DPanel2.setMargin(0.35D);
    Chart3D chart3D3 = ScatterPlot3D3.createChart("Iris Dataset : Combination 3", arrayOfXYZDataset[2], "Sepal Length", "Petal Width", "Petal Length");
    Chart3DPanel chart3DPanel3 = new Chart3DPanel(chart3D3);
    chart3DPanel3.setPreferredSize(new Dimension(10, 10));
    chart3DPanel3.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(new Color(255, 255, 255, 0)), BorderFactory.createLineBorder(Color.DARK_GRAY)));
    chart3DPanel3.setMargin(0.35D);
    Chart3D chart3D4 = ScatterPlot3D3.createChart("Iris Dataset : Combination 4", arrayOfXYZDataset[3], "Sepal Width", "Petal Width", "Petal Length");
    Chart3DPanel chart3DPanel4 = new Chart3DPanel(chart3D4);
    chart3DPanel4.setPreferredSize(new Dimension(10, 10));
    chart3DPanel4.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(new Color(255, 255, 255, 0)), BorderFactory.createLineBorder(Color.DARK_GRAY)));
    chart3DPanel4.setMargin(0.35D);
    demoPanel.add((Component)new DisplayPanel3D((Panel3D)chart3DPanel1, false, true));
    demoPanel.addChartPanel(chart3DPanel1);
    demoPanel.add((Component)new DisplayPanel3D((Panel3D)chart3DPanel2, false, true));
    demoPanel.addChartPanel(chart3DPanel2);
    demoPanel.add((Component)new DisplayPanel3D((Panel3D)chart3DPanel3, false, true));
    demoPanel.addChartPanel(chart3DPanel3);
    demoPanel.add((Component)new DisplayPanel3D((Panel3D)chart3DPanel4, false, true));
    demoPanel.addChartPanel(chart3DPanel4);
    demoPanel.setPreferredSize(new Dimension(400, 400));
    return demoPanel;
  }
  
  public static void main(String[] paramArrayOfString) {
    ScatterPlot3DDemo3 scatterPlot3DDemo3 = new ScatterPlot3DDemo3("OrsonCharts : ScatterPlot3DDemo3.java");
    scatterPlot3DDemo3.pack();
    scatterPlot3DDemo3.setVisible(true);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/orsoncharts/swing/ScatterPlot3DDemo3.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */