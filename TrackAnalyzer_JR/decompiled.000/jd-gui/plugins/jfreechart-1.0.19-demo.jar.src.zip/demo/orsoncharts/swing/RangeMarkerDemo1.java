package demo.orsoncharts.swing;

import com.orsoncharts.Chart3D;
import com.orsoncharts.Chart3DPanel;
import com.orsoncharts.data.xyz.XYZDataset;
import com.orsoncharts.data.xyz.XYZItemKey;
import com.orsoncharts.graphics3d.RenderedElement;
import com.orsoncharts.graphics3d.swing.DisplayPanel3D;
import com.orsoncharts.graphics3d.swing.Panel3D;
import com.orsoncharts.interaction.Chart3DMouseEvent;
import com.orsoncharts.interaction.Chart3DMouseListener;
import com.orsoncharts.interaction.StandardXYZDataItemSelection;
import com.orsoncharts.label.StandardXYZItemLabelGenerator;
import com.orsoncharts.marker.RangeMarker;
import com.orsoncharts.plot.XYZPlot;
import com.orsoncharts.renderer.xyz.ScatterXYZRenderer;
import com.orsoncharts.renderer.xyz.StandardXYZColorSource;
import com.orsoncharts.renderer.xyz.XYZColorSource;
import demo.orsoncharts.HighlightXYZColorSource;
import demo.orsoncharts.RangeMarker1;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.FlowLayout;
import java.awt.LayoutManager;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class RangeMarkerDemo1 extends JFrame {
  public RangeMarkerDemo1(String paramString) {
    super(paramString);
    addWindowListener(new ExitOnClose());
    getContentPane().add(createDemoPanel());
  }
  
  public static JPanel createDemoPanel() {
    CustomDemoPanel customDemoPanel = new CustomDemoPanel(new BorderLayout());
    customDemoPanel.setPreferredSize(OrsonChartsDemo.DEFAULT_CONTENT_SIZE);
    XYZDataset xYZDataset = RangeMarker1.createDataset();
    Chart3D chart3D = RangeMarker1.createChart(xYZDataset);
    Chart3DPanel chart3DPanel = new Chart3DPanel(chart3D);
    customDemoPanel.setChartPanel(chart3DPanel);
    chart3DPanel.addChartMouseListener(customDemoPanel);
    chart3DPanel.zoomToFit(OrsonChartsDemo.DEFAULT_CONTENT_SIZE);
    customDemoPanel.add((Component)new DisplayPanel3D((Panel3D)chart3DPanel));
    return customDemoPanel;
  }
  
  public static void main(String[] paramArrayOfString) {
    RangeMarkerDemo1 rangeMarkerDemo1 = new RangeMarkerDemo1("OrsonCharts : RangeMarkerDemo1.java");
    rangeMarkerDemo1.pack();
    rangeMarkerDemo1.setVisible(true);
  }
  
  static class CustomDemoPanel extends DemoPanel implements ActionListener, Chart3DMouseListener {
    private JCheckBox checkBox = new JCheckBox("Highlight items within range intersection");
    
    public CustomDemoPanel(LayoutManager param1LayoutManager) {
      super(param1LayoutManager);
      this.checkBox.setSelected(true);
      this.checkBox.addActionListener(this);
      JPanel jPanel = new JPanel(new FlowLayout());
      jPanel.add(this.checkBox);
      add(jPanel, "South");
    }
    
    public void actionPerformed(ActionEvent param1ActionEvent) {
      Chart3D chart3D = (Chart3D)getChartPanel().getDrawable();
      XYZPlot xYZPlot = (XYZPlot)chart3D.getPlot();
      RangeMarker rangeMarker1 = (RangeMarker)xYZPlot.getXAxis().getMarker("X1");
      RangeMarker rangeMarker2 = (RangeMarker)xYZPlot.getYAxis().getMarker("Y1");
      RangeMarker rangeMarker3 = (RangeMarker)xYZPlot.getZAxis().getMarker("Z1");
      if (this.checkBox.isSelected()) {
        HighlightXYZColorSource highlightXYZColorSource = new HighlightXYZColorSource(xYZPlot.getDataset(), Color.RED, rangeMarker1.getRange(), rangeMarker2.getRange(), rangeMarker3.getRange(), chart3D.getStyle().getStandardColors());
        xYZPlot.getRenderer().setColorSource((XYZColorSource)highlightXYZColorSource);
      } else {
        StandardXYZColorSource standardXYZColorSource = new StandardXYZColorSource(chart3D.getStyle().getStandardColors());
        xYZPlot.getRenderer().setColorSource((XYZColorSource)standardXYZColorSource);
      } 
    }
    
    public void chartMouseClicked(Chart3DMouseEvent param1Chart3DMouseEvent) {
      RenderedElement renderedElement = param1Chart3DMouseEvent.getElement();
      XYZItemKey xYZItemKey = (XYZItemKey)renderedElement.getProperty("key");
      if (xYZItemKey == null) {
        getItemSelection().clear();
        getChartPanel().getChart().setNotify(true);
        return;
      } 
      if (param1Chart3DMouseEvent.getTrigger().isShiftDown()) {
        getItemSelection().add(xYZItemKey);
      } else {
        getItemSelection().clear();
        getItemSelection().add(xYZItemKey);
      } 
      getChartPanel().getChart().setNotify(true);
    }
    
    private StandardXYZDataItemSelection getItemSelection() {
      Chart3D chart3D = getChartPanel().getChart();
      XYZPlot xYZPlot = (XYZPlot)chart3D.getPlot();
      ScatterXYZRenderer scatterXYZRenderer = (ScatterXYZRenderer)xYZPlot.getRenderer();
      StandardXYZItemLabelGenerator standardXYZItemLabelGenerator = (StandardXYZItemLabelGenerator)scatterXYZRenderer.getItemLabelGenerator();
      return (StandardXYZDataItemSelection)standardXYZItemLabelGenerator.getItemSelection();
    }
    
    public void chartMouseMoved(Chart3DMouseEvent param1Chart3DMouseEvent) {}
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/orsoncharts/swing/RangeMarkerDemo1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */