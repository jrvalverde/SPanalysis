package demo.orsoncharts.swing;

import com.orsoncharts.Chart3D;
import com.orsoncharts.Chart3DPanel;
import demo.orsoncharts.DemoDescription;
import java.awt.Color;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.URL;
import javax.swing.BorderFactory;
import javax.swing.JPanel;

public class DemoDisplayer implements Runnable {
  private OrsonChartsDemoComponent demoComp;
  
  private DemoDescription demoDescription;
  
  public DemoDisplayer(OrsonChartsDemoComponent paramOrsonChartsDemoComponent, DemoDescription paramDemoDescription) {
    this.demoComp = paramOrsonChartsDemoComponent;
    this.demoDescription = paramDemoDescription;
  }
  
  public void run() {
    try {
      Class<?> clazz = Class.forName(this.demoDescription.getClassName());
      Method method = clazz.getDeclaredMethod("createDemoPanel", (Class[])null);
      JPanel jPanel = (JPanel)method.invoke(null, (Object[])null);
      jPanel.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createEmptyBorder(4, 4, 4, 4), BorderFactory.createLineBorder(Color.BLACK)));
      this.demoComp.getChartContainer().removeAll();
      this.demoComp.getChartContainer().add(jPanel);
      this.demoComp.getChartContainer().validate();
      if (jPanel instanceof DemoPanel) {
        DemoPanel demoPanel = (DemoPanel)jPanel;
        for (Chart3DPanel chart3DPanel : demoPanel.getChartPanels()) {
          if (this.demoComp.getChartStyle() != null) {
            Chart3D chart3D = (Chart3D)chart3DPanel.getDrawable();
            chart3D.setStyle(this.demoComp.getChartStyle());
          } 
          chart3DPanel.zoomToFit();
        } 
      } 
      String str = this.demoDescription.getDescriptionFileName();
      URL uRL = OrsonChartsDemo.class.getResource(str);
      if (uRL != null)
        try {
          this.demoComp.getChartDescriptionPane().setPage(uRL);
        } catch (IOException iOException) {
          System.err.println("Attempted to read a bad URL: " + uRL);
        }  
    } catch (ClassNotFoundException classNotFoundException) {
      classNotFoundException.printStackTrace();
    } catch (NoSuchMethodException noSuchMethodException) {
      noSuchMethodException.printStackTrace();
    } catch (InvocationTargetException invocationTargetException) {
      invocationTargetException.printStackTrace();
    } catch (IllegalAccessException illegalAccessException) {
      illegalAccessException.printStackTrace();
    } 
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/orsoncharts/swing/DemoDisplayer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */