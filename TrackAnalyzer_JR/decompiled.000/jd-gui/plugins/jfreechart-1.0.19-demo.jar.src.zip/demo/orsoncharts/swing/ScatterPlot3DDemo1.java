package demo.orsoncharts.swing;

import com.orsoncharts.Chart3D;
import com.orsoncharts.Chart3DPanel;
import com.orsoncharts.data.xyz.XYZDataset;
import com.orsoncharts.graphics3d.swing.DisplayPanel3D;
import com.orsoncharts.graphics3d.swing.Panel3D;
import demo.orsoncharts.ScatterPlot3D1;
import java.awt.BorderLayout;
import java.awt.Component;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class ScatterPlot3DDemo1 extends JFrame {
  public ScatterPlot3DDemo1(String paramString) {
    super(paramString);
    addWindowListener(new ExitOnClose());
    getContentPane().add(createDemoPanel());
  }
  
  public static JPanel createDemoPanel() {
    DemoPanel demoPanel = new DemoPanel(new BorderLayout());
    demoPanel.setPreferredSize(OrsonChartsDemo.DEFAULT_CONTENT_SIZE);
    XYZDataset xYZDataset = ScatterPlot3D1.createDataset();
    Chart3D chart3D = ScatterPlot3D1.createChart(xYZDataset);
    Chart3DPanel chart3DPanel = new Chart3DPanel(chart3D);
    demoPanel.setChartPanel(chart3DPanel);
    chart3DPanel.zoomToFit(OrsonChartsDemo.DEFAULT_CONTENT_SIZE);
    demoPanel.add((Component)new DisplayPanel3D((Panel3D)chart3DPanel));
    return demoPanel;
  }
  
  public static void main(String[] paramArrayOfString) {
    ScatterPlot3DDemo1 scatterPlot3DDemo1 = new ScatterPlot3DDemo1("OrsonCharts : ScatterPlot3DDemo1.java");
    scatterPlot3DDemo1.pack();
    scatterPlot3DDemo1.setVisible(true);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/orsoncharts/swing/ScatterPlot3DDemo1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */