package demo.orsoncharts.swing;

import com.orsoncharts.Chart3DPanel;
import java.awt.LayoutManager;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JPanel;

public class DemoPanel extends JPanel {
  private List<Chart3DPanel> chartPanels = new ArrayList<Chart3DPanel>();
  
  public DemoPanel(LayoutManager paramLayoutManager) {
    super(paramLayoutManager);
  }
  
  public Chart3DPanel getChartPanel() {
    return this.chartPanels.isEmpty() ? null : this.chartPanels.get(0);
  }
  
  public List<Chart3DPanel> getChartPanels() {
    return this.chartPanels;
  }
  
  public void setChartPanel(Chart3DPanel paramChart3DPanel) {
    this.chartPanels.clear();
    this.chartPanels.add(paramChart3DPanel);
  }
  
  public void addChartPanel(Chart3DPanel paramChart3DPanel) {
    this.chartPanels.add(paramChart3DPanel);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/orsoncharts/swing/DemoPanel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */