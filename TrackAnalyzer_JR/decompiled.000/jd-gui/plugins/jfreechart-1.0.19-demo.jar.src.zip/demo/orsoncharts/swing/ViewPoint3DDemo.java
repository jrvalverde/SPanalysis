package demo.orsoncharts.swing;

import com.orsoncharts.graphics3d.DefaultDrawable3D;
import com.orsoncharts.graphics3d.Drawable3D;
import com.orsoncharts.graphics3d.Object3D;
import com.orsoncharts.graphics3d.Point3D;
import com.orsoncharts.graphics3d.Rotate3D;
import com.orsoncharts.graphics3d.ViewPoint3D;
import com.orsoncharts.graphics3d.World;
import com.orsoncharts.graphics3d.swing.DisplayPanel3D;
import com.orsoncharts.graphics3d.swing.Panel3D;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class ViewPoint3DDemo extends JFrame {
  List<Point3D> xlist;
  
  List<Point3D> ylist;
  
  List<Point3D> zlist;
  
  Panel3D panel3D;
  
  public ViewPoint3DDemo(String paramString) {
    super(paramString);
    addWindowListener(new ExitOnClose());
    getContentPane().add(createDemoPanel());
  }
  
  public final JPanel createDemoPanel() {
    JPanel jPanel = new JPanel(new BorderLayout());
    jPanel.setPreferredSize(OrsonChartsDemo.DEFAULT_CONTENT_SIZE);
    World world = new World();
    world.add(Object3D.createCube(1.0D, 0.0D, 0.0D, 0.0D, Color.BLUE));
    ViewPoint3D viewPoint3D = new ViewPoint3D(new Point3D(10.0D, 10.0D, 10.0D), 0.0D);
    this.xlist = addRing(true, world, new Point3D(0.0D, 5.0D, 0.0D), Point3D.UNIT_X, Color.GREEN);
    this.ylist = addRing(true, world, new Point3D(0.0D, 0.0D, 5.0D), Point3D.UNIT_Y, Color.ORANGE);
    this.zlist = addRing(true, world, new Point3D(0.0D, 5.0D, 0.0D), Point3D.UNIT_Z, Color.RED);
    DefaultDrawable3D defaultDrawable3D = new DefaultDrawable3D(world);
    this.panel3D = new Panel3D((Drawable3D)defaultDrawable3D);
    this.panel3D.setViewPoint(viewPoint3D);
    jPanel.add((Component)new DisplayPanel3D(this.panel3D));
    return jPanel;
  }
  
  private List<Point3D> addRing(boolean paramBoolean, World paramWorld, Point3D paramPoint3D1, Point3D paramPoint3D2, Color paramColor) {
    boolean bool = true;
    ArrayList<Point3D> arrayList = new ArrayList();
    Rotate3D rotate3D = new Rotate3D(Point3D.ORIGIN, paramPoint3D2, 0.0D);
    for (byte b = 0; b < 60; b++) {
      rotate3D.setAngle(0.10471975511965977D * b);
      Point3D point3D = rotate3D.applyRotation(paramPoint3D1);
      arrayList.add(point3D);
      if (paramBoolean)
        if (bool) {
          paramWorld.add(Object3D.createCube(0.2D, point3D.x, point3D.y, point3D.z, Color.RED));
          bool = false;
        } else {
          paramWorld.add(Object3D.createCube(0.2D, point3D.x, point3D.y, point3D.z, paramColor));
        }  
    } 
    return arrayList;
  }
  
  public static void main(String[] paramArrayOfString) {
    ViewPoint3DDemo viewPoint3DDemo = new ViewPoint3DDemo("OrsonCharts: ViewPointDemo.java");
    viewPoint3DDemo.pack();
    viewPoint3DDemo.setVisible(true);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/orsoncharts/swing/ViewPoint3DDemo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */