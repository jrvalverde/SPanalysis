package demo.orsoncharts.swing;

import com.orsoncharts.Chart3D;
import com.orsoncharts.Chart3DPanel;
import com.orsoncharts.data.category.CategoryDataset3D;
import com.orsoncharts.graphics3d.swing.DisplayPanel3D;
import com.orsoncharts.graphics3d.swing.Panel3D;
import demo.orsoncharts.AreaChart3D2;
import java.awt.BorderLayout;
import java.awt.Component;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class AreaChart3DDemo2 extends JFrame {
  public AreaChart3DDemo2(String paramString) {
    super(paramString);
    addWindowListener(new ExitOnClose());
    getContentPane().add(createDemoPanel());
  }
  
  public static JPanel createDemoPanel() {
    DemoPanel demoPanel = new DemoPanel(new BorderLayout());
    demoPanel.setPreferredSize(OrsonChartsDemo.DEFAULT_CONTENT_SIZE);
    CategoryDataset3D categoryDataset3D = AreaChart3D2.createDataset();
    Chart3D chart3D = AreaChart3D2.createChart(categoryDataset3D);
    Chart3DPanel chart3DPanel = new Chart3DPanel(chart3D);
    demoPanel.setChartPanel(chart3DPanel);
    demoPanel.add((Component)new DisplayPanel3D((Panel3D)chart3DPanel));
    chart3DPanel.zoomToFit(OrsonChartsDemo.DEFAULT_CONTENT_SIZE);
    return demoPanel;
  }
  
  public static void main(String[] paramArrayOfString) {
    AreaChart3DDemo2 areaChart3DDemo2 = new AreaChart3DDemo2("OrsonCharts: AreaChart3DDemo2.java");
    areaChart3DDemo2.pack();
    areaChart3DDemo2.setVisible(true);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/orsoncharts/swing/AreaChart3DDemo2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */