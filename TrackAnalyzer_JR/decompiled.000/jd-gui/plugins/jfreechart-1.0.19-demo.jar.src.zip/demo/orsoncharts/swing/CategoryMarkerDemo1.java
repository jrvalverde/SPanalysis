package demo.orsoncharts.swing;

import com.orsoncharts.Chart3D;
import com.orsoncharts.Chart3DFactory;
import com.orsoncharts.Chart3DPanel;
import com.orsoncharts.ChartElementVisitor;
import com.orsoncharts.axis.StandardCategoryAxis3D;
import com.orsoncharts.data.DefaultKeyedValues;
import com.orsoncharts.data.KeyedValues;
import com.orsoncharts.data.KeyedValues3D;
import com.orsoncharts.data.KeyedValues3DItemKey;
import com.orsoncharts.data.KeyedValues3DItemKeys;
import com.orsoncharts.data.category.CategoryDataset3D;
import com.orsoncharts.data.category.StandardCategoryDataset3D;
import com.orsoncharts.graphics3d.RenderedElement;
import com.orsoncharts.graphics3d.swing.DisplayPanel3D;
import com.orsoncharts.graphics3d.swing.Panel3D;
import com.orsoncharts.interaction.Chart3DMouseEvent;
import com.orsoncharts.interaction.Chart3DMouseListener;
import com.orsoncharts.interaction.InteractiveElementType;
import com.orsoncharts.interaction.KeyedValues3DItemSelection;
import com.orsoncharts.interaction.StandardKeyedValues3DItemSelection;
import com.orsoncharts.label.CategoryItemLabelGenerator;
import com.orsoncharts.label.StandardCategoryItemLabelGenerator;
import com.orsoncharts.legend.LegendAnchor;
import com.orsoncharts.marker.CategoryMarker;
import com.orsoncharts.plot.CategoryPlot3D;
import com.orsoncharts.renderer.category.BarRenderer3D;
import com.orsoncharts.renderer.category.CategoryColorSource;
import com.orsoncharts.style.ChartStyler;
import demo.orsoncharts.HighlightCategoryColorSource;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.FlowLayout;
import java.awt.LayoutManager;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class CategoryMarkerDemo1 extends JFrame {
  public CategoryMarkerDemo1(String paramString) {
    super(paramString);
    addWindowListener(new ExitOnClose());
    getContentPane().add(createDemoPanel());
  }
  
  public static JPanel createDemoPanel() {
    CustomDemoPanel customDemoPanel = new CustomDemoPanel(new BorderLayout());
    customDemoPanel.setPreferredSize(OrsonChartsDemo.DEFAULT_CONTENT_SIZE);
    Chart3D chart3D = createChart(createDataset());
    Chart3DPanel chart3DPanel = new Chart3DPanel(chart3D);
    chart3DPanel.setMargin(0.3D);
    chart3DPanel.getViewPoint().panLeftRight(-0.3D);
    chart3DPanel.getViewPoint().moveUpDown(-0.12D);
    chart3DPanel.getViewPoint().roll(-0.05235987755982988D);
    customDemoPanel.setChartPanel(chart3DPanel);
    chart3DPanel.zoomToFit(OrsonChartsDemo.DEFAULT_CONTENT_SIZE);
    chart3DPanel.addChartMouseListener(customDemoPanel);
    customDemoPanel.add((Component)new DisplayPanel3D((Panel3D)chart3DPanel));
    return customDemoPanel;
  }
  
  public static Chart3D createChart(CategoryDataset3D paramCategoryDataset3D) {
    Chart3D chart3D = Chart3DFactory.createBarChart("Quarterly Revenues", "For some large IT companies", paramCategoryDataset3D, null, "Quarter", "$billion Revenues");
    chart3D.setChartBoxColor(new Color(255, 255, 255, 127));
    chart3D.setLegendAnchor(LegendAnchor.BOTTOM_RIGHT);
    CategoryPlot3D categoryPlot3D = (CategoryPlot3D)chart3D.getPlot();
    categoryPlot3D.setGridlinePaintForValues(Color.BLACK);
    StandardCategoryAxis3D standardCategoryAxis3D1 = (StandardCategoryAxis3D)categoryPlot3D.getRowAxis();
    standardCategoryAxis3D1.setMarker("RM1", new CategoryMarker("Apple"));
    StandardCategoryAxis3D standardCategoryAxis3D2 = (StandardCategoryAxis3D)categoryPlot3D.getColumnAxis();
    standardCategoryAxis3D2.setMarker("CM1", new CategoryMarker("Q4/12"));
    BarRenderer3D barRenderer3D = (BarRenderer3D)categoryPlot3D.getRenderer();
    StandardCategoryItemLabelGenerator standardCategoryItemLabelGenerator = new StandardCategoryItemLabelGenerator("%4$.2f");
    StandardKeyedValues3DItemSelection standardKeyedValues3DItemSelection = new StandardKeyedValues3DItemSelection();
    standardCategoryItemLabelGenerator.setItemSelection(standardKeyedValues3DItemSelection);
    barRenderer3D.setItemLabelGenerator((CategoryItemLabelGenerator)standardCategoryItemLabelGenerator);
    HighlightCategoryColorSource highlightCategoryColorSource = new HighlightCategoryColorSource();
    highlightCategoryColorSource.setHighlightRowIndex(3);
    highlightCategoryColorSource.setHighlightColumnIndex(6);
    barRenderer3D.setColorSource((CategoryColorSource)highlightCategoryColorSource);
    return chart3D;
  }
  
  public static CategoryDataset3D createDataset() {
    StandardCategoryDataset3D standardCategoryDataset3D = new StandardCategoryDataset3D();
    DefaultKeyedValues defaultKeyedValues1 = new DefaultKeyedValues();
    defaultKeyedValues1.put("Q2/11", Double.valueOf(8.181D));
    defaultKeyedValues1.put("Q3/11", Double.valueOf(8.792D));
    defaultKeyedValues1.put("Q4/11", Double.valueOf(9.039D));
    defaultKeyedValues1.put("Q1/12", Double.valueOf(10.916D));
    defaultKeyedValues1.put("Q2/12", Double.valueOf(8.181D));
    defaultKeyedValues1.put("Q3/12", Double.valueOf(9.094D));
    defaultKeyedValues1.put("Q4/12", Double.valueOf(8.958D));
    defaultKeyedValues1.put("Q1/13", Double.valueOf(10.947D));
    defaultKeyedValues1.put("Q2/13", Double.valueOf(8.372D));
    defaultKeyedValues1.put("Q3/13", Double.valueOf(9.275D));
    standardCategoryDataset3D.addSeriesAsRow("Oracle", (KeyedValues)defaultKeyedValues1);
    DefaultKeyedValues defaultKeyedValues2 = new DefaultKeyedValues();
    defaultKeyedValues2.put("Q2/11", Double.valueOf(9.03D));
    defaultKeyedValues2.put("Q3/11", Double.valueOf(9.72D));
    defaultKeyedValues2.put("Q4/11", Double.valueOf(10.58D));
    defaultKeyedValues2.put("Q1/12", Double.valueOf(10.65D));
    defaultKeyedValues2.put("Q2/12", Double.valueOf(12.214D));
    defaultKeyedValues2.put("Q3/12", Double.valueOf(14.101D));
    defaultKeyedValues2.put("Q4/12", Double.valueOf(14.419D));
    defaultKeyedValues2.put("Q1/13", Double.valueOf(13.969D));
    defaultKeyedValues2.put("Q2/13", Double.valueOf(14.105D));
    defaultKeyedValues2.put("Q3/13", Double.valueOf(14.893D));
    defaultKeyedValues2.put("Q4/13", Double.valueOf(16.858D));
    standardCategoryDataset3D.addSeriesAsRow("Google", (KeyedValues)defaultKeyedValues2);
    DefaultKeyedValues defaultKeyedValues3 = new DefaultKeyedValues();
    defaultKeyedValues3.put("Q2/11", Double.valueOf(17.37D));
    defaultKeyedValues3.put("Q3/11", Double.valueOf(17.37D));
    defaultKeyedValues3.put("Q4/11", Double.valueOf(20.89D));
    defaultKeyedValues3.put("Q1/12", Double.valueOf(17.41D));
    defaultKeyedValues3.put("Q2/12", Double.valueOf(18.06D));
    defaultKeyedValues3.put("Q3/12", Double.valueOf(16.008D));
    defaultKeyedValues3.put("Q4/12", Double.valueOf(21.456D));
    defaultKeyedValues3.put("Q1/13", Double.valueOf(20.489D));
    defaultKeyedValues3.put("Q2/13", Double.valueOf(19.896D));
    defaultKeyedValues3.put("Q3/13", Double.valueOf(18.529D));
    defaultKeyedValues3.put("Q4/13", Double.valueOf(24.519D));
    standardCategoryDataset3D.addSeriesAsRow("Microsoft", (KeyedValues)defaultKeyedValues3);
    DefaultKeyedValues defaultKeyedValues4 = new DefaultKeyedValues();
    defaultKeyedValues4.put("Q2/11", Double.valueOf(28.57D));
    defaultKeyedValues4.put("Q3/11", Double.valueOf(28.27D));
    defaultKeyedValues4.put("Q4/11", Double.valueOf(46.33D));
    defaultKeyedValues4.put("Q1/12", Double.valueOf(39.2D));
    defaultKeyedValues4.put("Q2/12", Double.valueOf(35.0D));
    defaultKeyedValues4.put("Q3/12", Double.valueOf(36.0D));
    defaultKeyedValues4.put("Q4/12", Double.valueOf(54.5D));
    defaultKeyedValues4.put("Q1/13", Double.valueOf(43.6D));
    defaultKeyedValues4.put("Q2/13", Double.valueOf(35.323D));
    defaultKeyedValues4.put("Q3/13", Double.valueOf(37.5D));
    defaultKeyedValues4.put("Q4/13", Double.valueOf(57.594D));
    standardCategoryDataset3D.addSeriesAsRow("Apple", (KeyedValues)defaultKeyedValues4);
    return (CategoryDataset3D)standardCategoryDataset3D;
  }
  
  public static void main(String[] paramArrayOfString) {
    CategoryMarkerDemo1 categoryMarkerDemo1 = new CategoryMarkerDemo1("OrsonCharts: CategoryMarkerDemo1.java");
    categoryMarkerDemo1.pack();
    categoryMarkerDemo1.setVisible(true);
  }
  
  static class CustomDemoPanel extends DemoPanel implements ActionListener, Chart3DMouseListener {
    private String selectedRowKey;
    
    private String selectedColumnKey;
    
    private JCheckBox itemLabelCheckBox;
    
    public CustomDemoPanel(LayoutManager param1LayoutManager) {
      super(param1LayoutManager);
      JPanel jPanel = new JPanel(new FlowLayout());
      this.itemLabelCheckBox = new JCheckBox("Show item labels?");
      this.itemLabelCheckBox.addActionListener(this);
      jPanel.add(this.itemLabelCheckBox);
      this.selectedRowKey = "Apple";
      this.selectedColumnKey = "Q4/12";
      add(jPanel, "South");
    }
    
    private void updateColorSource(String param1String1, String param1String2) {
      HighlightCategoryColorSource highlightCategoryColorSource = (HighlightCategoryColorSource)getRenderer().getColorSource();
      int i = getPlot().getDataset().getRowIndex(param1String1);
      int j = getPlot().getDataset().getColumnIndex(param1String2);
      highlightCategoryColorSource.setHighlightRowIndex(i);
      highlightCategoryColorSource.setHighlightColumnIndex(j);
    }
    
    private void updateItemSelection(String param1String1, String param1String2) {
      StandardKeyedValues3DItemSelection standardKeyedValues3DItemSelection = (StandardKeyedValues3DItemSelection)getItemSelection();
      standardKeyedValues3DItemSelection.clear();
      if (this.itemLabelCheckBox.isSelected()) {
        standardKeyedValues3DItemSelection.addAll(KeyedValues3DItemKeys.itemKeysForColumn((KeyedValues3D)getPlot().getDataset(), param1String2));
        standardKeyedValues3DItemSelection.addAll(KeyedValues3DItemKeys.itemKeysForRow((KeyedValues3D)getPlot().getDataset(), param1String1));
      } 
    }
    
    private CategoryPlot3D getPlot() {
      Chart3D chart3D = getChartPanel().getChart();
      return (CategoryPlot3D)chart3D.getPlot();
    }
    
    private BarRenderer3D getRenderer() {
      return (BarRenderer3D)getPlot().getRenderer();
    }
    
    private KeyedValues3DItemSelection getItemSelection() {
      StandardCategoryItemLabelGenerator standardCategoryItemLabelGenerator = (StandardCategoryItemLabelGenerator)getRenderer().getItemLabelGenerator();
      return standardCategoryItemLabelGenerator.getItemSelection();
    }
    
    private void handleSelectItem(Comparable param1Comparable1, Comparable param1Comparable2) {
      Chart3D chart3D = getChartPanel().getChart();
      chart3D.setNotify(false);
      CategoryPlot3D categoryPlot3D = getPlot();
      StandardCategoryAxis3D standardCategoryAxis3D1 = (StandardCategoryAxis3D)categoryPlot3D.getRowAxis();
      CategoryMarker categoryMarker1 = standardCategoryAxis3D1.getMarker("RM1");
      if (categoryMarker1 == null) {
        categoryMarker1 = new CategoryMarker("");
        categoryMarker1.receive((ChartElementVisitor)new ChartStyler(chart3D.getStyle()));
      } 
      StandardCategoryAxis3D standardCategoryAxis3D2 = (StandardCategoryAxis3D)categoryPlot3D.getColumnAxis();
      CategoryMarker categoryMarker2 = standardCategoryAxis3D2.getMarker("CM1");
      if (categoryMarker2 == null) {
        categoryMarker2 = new CategoryMarker("");
        categoryMarker2.receive((ChartElementVisitor)new ChartStyler(chart3D.getStyle()));
      } 
      this.selectedRowKey = param1Comparable1.toString();
      this.selectedColumnKey = param1Comparable2.toString();
      categoryMarker1.setCategory(this.selectedRowKey);
      categoryMarker2.setCategory(this.selectedColumnKey);
      updateColorSource(this.selectedRowKey, this.selectedColumnKey);
      updateItemSelection(this.selectedRowKey, this.selectedColumnKey);
      chart3D.setNotify(true);
    }
    
    private void handleSelectRow(Comparable param1Comparable) {
      handleSelectItem(param1Comparable, this.selectedColumnKey);
    }
    
    private void handleSelectColumn(Comparable param1Comparable) {
      handleSelectItem(this.selectedRowKey, param1Comparable);
    }
    
    public void chartMouseClicked(Chart3DMouseEvent param1Chart3DMouseEvent) {
      RenderedElement renderedElement = param1Chart3DMouseEvent.getElement();
      if (renderedElement == null)
        return; 
      KeyedValues3DItemKey keyedValues3DItemKey = (KeyedValues3DItemKey)renderedElement.getProperty("key");
      if (keyedValues3DItemKey != null) {
        handleSelectItem(keyedValues3DItemKey.getRowKey(), keyedValues3DItemKey.getColumnKey());
      } else if (InteractiveElementType.CATEGORY_AXIS_TICK_LABEL.equals(renderedElement.getType())) {
        String str1 = (String)renderedElement.getProperty("label");
        String str2 = (String)renderedElement.getProperty("axis");
        if (str2.equals("row")) {
          handleSelectRow(str1);
        } else {
          handleSelectColumn(str1);
        } 
      } else if (InteractiveElementType.LEGEND_ITEM.equals(renderedElement.getType())) {
        Comparable comparable = (Comparable)renderedElement.getProperty("series_key");
        handleSelectRow(comparable);
      } 
    }
    
    public void chartMouseMoved(Chart3DMouseEvent param1Chart3DMouseEvent) {}
    
    public void actionPerformed(ActionEvent param1ActionEvent) {
      updateItemSelection(this.selectedRowKey, this.selectedColumnKey);
      getChartPanel().getChart().setNotify(true);
    }
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/orsoncharts/swing/CategoryMarkerDemo1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */