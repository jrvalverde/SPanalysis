package demo.orsoncharts.swing;

import com.orsoncharts.Chart3D;
import com.orsoncharts.Chart3DPanel;
import com.orsoncharts.graphics3d.swing.DisplayPanel3D;
import com.orsoncharts.graphics3d.swing.Panel3D;
import demo.orsoncharts.SurfaceRenderer1;
import java.awt.BorderLayout;
import java.awt.Component;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class SurfaceRendererDemo1 extends JFrame {
  public SurfaceRendererDemo1(String paramString) {
    super(paramString);
    addWindowListener(new ExitOnClose());
    getContentPane().add(createDemoPanel());
  }
  
  public static JPanel createDemoPanel() {
    DemoPanel demoPanel = new DemoPanel(new BorderLayout());
    demoPanel.setPreferredSize(OrsonChartsDemo.DEFAULT_CONTENT_SIZE);
    Chart3D chart3D = SurfaceRenderer1.createChart();
    Chart3DPanel chart3DPanel = new Chart3DPanel(chart3D);
    chart3DPanel.zoomToFit(OrsonChartsDemo.DEFAULT_CONTENT_SIZE);
    demoPanel.setChartPanel(chart3DPanel);
    demoPanel.add((Component)new DisplayPanel3D((Panel3D)chart3DPanel));
    return demoPanel;
  }
  
  public static void main(String[] paramArrayOfString) {
    SurfaceRendererDemo1 surfaceRendererDemo1 = new SurfaceRendererDemo1("OrsonCharts: SurfaceRendererDemo1.java");
    surfaceRendererDemo1.pack();
    surfaceRendererDemo1.setVisible(true);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/orsoncharts/swing/SurfaceRendererDemo1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */