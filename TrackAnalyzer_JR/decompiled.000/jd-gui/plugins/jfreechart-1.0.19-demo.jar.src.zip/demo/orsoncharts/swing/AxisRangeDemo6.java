package demo.orsoncharts.swing;

import com.orsoncharts.Chart3D;
import com.orsoncharts.Chart3DFactory;
import com.orsoncharts.Chart3DPanel;
import com.orsoncharts.axis.ValueAxis3D;
import com.orsoncharts.data.function.Function3D;
import com.orsoncharts.graphics3d.Dimension3D;
import com.orsoncharts.graphics3d.ViewPoint3D;
import com.orsoncharts.graphics3d.swing.DisplayPanel3D;
import com.orsoncharts.graphics3d.swing.Panel3D;
import com.orsoncharts.plot.XYZPlot;
import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.LayoutManager;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

public class AxisRangeDemo6 extends JFrame {
  public AxisRangeDemo6(String paramString) {
    super(paramString);
    addWindowListener(new ExitOnClose());
    getContentPane().add(createDemoPanel());
  }
  
  public static JPanel createDemoPanel() {
    CustomDemoPanel customDemoPanel = new CustomDemoPanel(new BorderLayout());
    customDemoPanel.setPreferredSize(OrsonChartsDemo.DEFAULT_CONTENT_SIZE);
    Function3D function3D = new Function3D() {
        public double getValue(double param1Double1, double param1Double2) {
          return Math.cos(param1Double1) * Math.sin(param1Double2);
        }
      };
    Chart3D chart3D = Chart3DFactory.createSurfaceChart("AxisRangeDemo6", "Chart created with Orson Charts", function3D, "X", "Y", "Z");
    XYZPlot xYZPlot = (XYZPlot)chart3D.getPlot();
    xYZPlot.setDimensions(new Dimension3D(10.0D, 4.0D, 10.0D));
    xYZPlot.getXAxis().setRange(-5.0D, 5.0D);
    xYZPlot.getZAxis().setRange(-5.0D, 5.0D);
    chart3D.setViewPoint(ViewPoint3D.createAboveLeftViewPoint(40.0D));
    Chart3DPanel chart3DPanel = new Chart3DPanel(chart3D);
    customDemoPanel.setChartPanel(chart3DPanel);
    chart3DPanel.zoomToFit(OrsonChartsDemo.DEFAULT_CONTENT_SIZE);
    customDemoPanel.add((Component)new DisplayPanel3D((Panel3D)chart3DPanel));
    return customDemoPanel;
  }
  
  public static void main(String[] paramArrayOfString) {
    AxisRangeDemo6 axisRangeDemo6 = new AxisRangeDemo6("OrsonCharts : AxisRangeDemo6.java");
    axisRangeDemo6.pack();
    axisRangeDemo6.setVisible(true);
  }
  
  static class CustomDemoPanel extends DemoPanel implements ChangeListener {
    private JSlider xslider1 = new JSlider(0, 50);
    
    private JSlider xslider2;
    
    private JSlider yslider1;
    
    private JSlider yslider2;
    
    private JSlider zslider1;
    
    private JSlider zslider2;
    
    public CustomDemoPanel(LayoutManager param1LayoutManager) {
      super(param1LayoutManager);
      this.xslider1.setValue(0);
      this.xslider2 = new JSlider(50, 100);
      this.xslider2.setValue(100);
      this.xslider1.addChangeListener(this);
      this.xslider2.addChangeListener(this);
      this.yslider1 = new JSlider(0, 50);
      this.yslider1.setValue(0);
      this.yslider2 = new JSlider(50, 100);
      this.yslider2.setValue(100);
      this.yslider1.addChangeListener(this);
      this.yslider2.addChangeListener(this);
      this.zslider1 = new JSlider(0, 50);
      this.zslider1.setValue(0);
      this.zslider2 = new JSlider(50, 100);
      this.zslider2.setValue(100);
      this.zslider1.addChangeListener(this);
      this.zslider2.addChangeListener(this);
      JPanel jPanel1 = new JPanel(new GridLayout(3, 1));
      JPanel jPanel2 = new JPanel(new FlowLayout());
      jPanel2.add(new JLabel("X axis: "));
      jPanel2.add(new JLabel("Lower bound: "));
      jPanel2.add(this.xslider1);
      jPanel2.add(new JLabel("Upper bound: "));
      jPanel2.add(this.xslider2);
      jPanel1.add(jPanel2);
      JPanel jPanel3 = new JPanel(new FlowLayout());
      jPanel3.add(new JLabel("Y axis: "));
      jPanel3.add(new JLabel("Lower bound: "));
      jPanel3.add(this.yslider1);
      jPanel3.add(new JLabel("Upper bound: "));
      jPanel3.add(this.yslider2);
      jPanel1.add(jPanel3);
      JPanel jPanel4 = new JPanel(new FlowLayout());
      jPanel4.add(new JLabel("Z axis: "));
      jPanel4.add(new JLabel("Lower bound: "));
      jPanel4.add(this.zslider1);
      jPanel4.add(new JLabel("Upper bound: "));
      jPanel4.add(this.zslider2);
      jPanel1.add(jPanel4);
      add(jPanel1, "South");
    }
    
    public void stateChanged(ChangeEvent param1ChangeEvent) {
      Chart3D chart3D = (Chart3D)getChartPanel().getDrawable();
      XYZPlot xYZPlot = (XYZPlot)chart3D.getPlot();
      ValueAxis3D valueAxis3D1 = xYZPlot.getXAxis();
      double d1 = this.xslider1.getValue() / 10.0D - 5.0D;
      double d2 = this.xslider2.getValue() / 10.0D - 5.0D;
      if (d1 != d2)
        valueAxis3D1.setRange(d1, d2); 
      ValueAxis3D valueAxis3D2 = xYZPlot.getYAxis();
      double d3 = this.yslider1.getValue() / 40.0D - 1.0D;
      double d4 = this.yslider2.getValue() / 40.0D - 1.0D;
      if (d3 != d4)
        valueAxis3D2.setRange(d3, d4); 
      ValueAxis3D valueAxis3D3 = xYZPlot.getZAxis();
      double d5 = this.zslider1.getValue() / 10.0D - 5.0D;
      double d6 = this.zslider2.getValue() / 10.0D - 5.0D;
      if (d5 != d6)
        valueAxis3D3.setRange(d5, d6); 
    }
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/orsoncharts/swing/AxisRangeDemo6.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */