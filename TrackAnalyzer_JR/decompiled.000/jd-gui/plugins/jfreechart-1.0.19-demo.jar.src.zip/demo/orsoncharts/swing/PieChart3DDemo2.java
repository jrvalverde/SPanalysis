package demo.orsoncharts.swing;

import com.orsoncharts.Chart3D;
import com.orsoncharts.Chart3DPanel;
import com.orsoncharts.data.PieDataset3D;
import com.orsoncharts.graphics3d.swing.DisplayPanel3D;
import com.orsoncharts.graphics3d.swing.Panel3D;
import com.orsoncharts.plot.PiePlot3D;
import demo.orsoncharts.PieChart3D2;
import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class PieChart3DDemo2 extends JFrame {
  public static JPanel createDemoPanel() {
    DemoPanel demoPanel = new DemoPanel(new BorderLayout());
    demoPanel.setPreferredSize(OrsonChartsDemo.DEFAULT_CONTENT_SIZE);
    PieDataset3D pieDataset3D = PieChart3D2.createDataset();
    final Chart3D chart = PieChart3D2.createChart(pieDataset3D);
    Chart3DPanel chart3DPanel = new Chart3DPanel(chart3D);
    chart3DPanel.setMargin(0.15D);
    demoPanel.setChartPanel(chart3DPanel);
    chart3DPanel.zoomToFit(OrsonChartsDemo.DEFAULT_CONTENT_SIZE);
    demoPanel.add((Component)new DisplayPanel3D((Panel3D)chart3DPanel));
    JButton jButton = new JButton("Change the Data");
    jButton.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent param1ActionEvent) {
            PieDataset3D pieDataset3D = PieChart3D2.createDataset();
            PiePlot3D piePlot3D = (PiePlot3D)chart.getPlot();
            piePlot3D.setDataset(pieDataset3D);
          }
        });
    demoPanel.add(jButton, "South");
    return demoPanel;
  }
  
  public PieChart3DDemo2(String paramString) {
    super(paramString);
    addWindowListener(new ExitOnClose());
    getContentPane().add(createDemoPanel());
  }
  
  public static void main(String[] paramArrayOfString) {
    PieChart3DDemo2 pieChart3DDemo2 = new PieChart3DDemo2("OrsonCharts: PieChart3DDemo2.java");
    pieChart3DDemo2.pack();
    pieChart3DDemo2.setVisible(true);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/orsoncharts/swing/PieChart3DDemo2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */