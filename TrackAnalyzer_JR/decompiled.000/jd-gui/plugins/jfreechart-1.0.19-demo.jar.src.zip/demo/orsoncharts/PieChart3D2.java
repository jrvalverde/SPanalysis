package demo.orsoncharts;

import com.orsoncharts.Chart3D;
import com.orsoncharts.Chart3DFactory;
import com.orsoncharts.Colors;
import com.orsoncharts.TitleAnchor;
import com.orsoncharts.data.PieDataset3D;
import com.orsoncharts.data.StandardPieDataset3D;
import com.orsoncharts.label.PieLabelGenerator;
import com.orsoncharts.label.StandardPieLabelGenerator;
import com.orsoncharts.plot.PiePlot3D;

public class PieChart3D2 {
  public static PieDataset3D createDataset() {
    StandardPieDataset3D standardPieDataset3D = new StandardPieDataset3D();
    standardPieDataset3D.add("United States", Math.random() * 30.0D);
    standardPieDataset3D.add("France", Math.random() * 20.0D);
    standardPieDataset3D.add("New Zealand", Math.random() * 12.0D);
    standardPieDataset3D.add("United Kingdom", Math.random() * 43.0D);
    standardPieDataset3D.add("Australia", Math.random() * 43.0D);
    standardPieDataset3D.add("Canada", Math.random() * 43.0D);
    return (PieDataset3D)standardPieDataset3D;
  }
  
  public static Chart3D createChart(PieDataset3D paramPieDataset3D) {
    Chart3D chart3D = Chart3DFactory.createPieChart("Orson Charts 3D", "For more info see: http://www.object-refinery.com/orsoncharts/", createDataset());
    chart3D.setTitleAnchor(TitleAnchor.TOP_LEFT);
    PiePlot3D piePlot3D = (PiePlot3D)chart3D.getPlot();
    piePlot3D.setLegendLabelGenerator((PieLabelGenerator)new StandardPieLabelGenerator("%s (%3$,.0f%%)"));
    piePlot3D.setSectionLabelGenerator((PieLabelGenerator)new StandardPieLabelGenerator("%s (%3$,.0f%%)"));
    piePlot3D.setSectionColors(Colors.createFancyLightColors());
    return chart3D;
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/orsoncharts/PieChart3D2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */