package demo.orsoncharts;

import com.orsoncharts.Chart3D;
import com.orsoncharts.Chart3DFactory;
import com.orsoncharts.Colors;
import com.orsoncharts.axis.NumberAxis3D;
import com.orsoncharts.axis.NumberTickSelector;
import com.orsoncharts.axis.TickSelector;
import com.orsoncharts.data.DefaultKeyedValues;
import com.orsoncharts.data.KeyedValues;
import com.orsoncharts.data.category.CategoryDataset3D;
import com.orsoncharts.data.category.StandardCategoryDataset3D;
import com.orsoncharts.graphics3d.Dimension3D;
import com.orsoncharts.graphics3d.ViewPoint3D;
import com.orsoncharts.plot.CategoryPlot3D;

public class LineChart3D1 {
  public static Chart3D createChart(CategoryDataset3D paramCategoryDataset3D) {
    Chart3D chart3D = Chart3DFactory.createLineChart("Web Browser Market Share", "Source: http://gs.statcounter.com", paramCategoryDataset3D, null, null, "Market Share (%)");
    CategoryPlot3D categoryPlot3D = (CategoryPlot3D)chart3D.getPlot();
    categoryPlot3D.setDimensions(new Dimension3D(18.0D, 8.0D, 4.0D));
    categoryPlot3D.getRowAxis().setVisible(false);
    NumberAxis3D numberAxis3D = (NumberAxis3D)categoryPlot3D.getValueAxis();
    numberAxis3D.setTickSelector((TickSelector)new NumberTickSelector(true));
    categoryPlot3D.getRenderer().setColors(Colors.createFancyDarkColors());
    chart3D.setViewPoint(ViewPoint3D.createAboveViewPoint(30.0D));
    return chart3D;
  }
  
  public static CategoryDataset3D createDataset() {
    StandardCategoryDataset3D standardCategoryDataset3D = new StandardCategoryDataset3D();
    standardCategoryDataset3D.addSeriesAsRow("Safari", createSafariData());
    standardCategoryDataset3D.addSeriesAsRow("Firefox", createFirefoxData());
    standardCategoryDataset3D.addSeriesAsRow("Internet Explorer", createInternetExplorerData());
    standardCategoryDataset3D.addSeriesAsRow("Chrome", createChromeData());
    return (CategoryDataset3D)standardCategoryDataset3D;
  }
  
  private static KeyedValues<Double> createChromeData() {
    DefaultKeyedValues defaultKeyedValues = new DefaultKeyedValues();
    defaultKeyedValues.put("Jan-12", Double.valueOf(0.284D));
    defaultKeyedValues.put("Feb-12", Double.valueOf(0.2984D));
    defaultKeyedValues.put("Mar-12", Double.valueOf(0.3087D));
    defaultKeyedValues.put("Apr-12", Double.valueOf(0.3123D));
    defaultKeyedValues.put("May-12", Double.valueOf(0.3243D));
    defaultKeyedValues.put("Jun-12", Double.valueOf(0.3276D));
    defaultKeyedValues.put("Jul-12", Double.valueOf(0.3381D));
    defaultKeyedValues.put("Aug-12", Double.valueOf(0.3359D));
    defaultKeyedValues.put("Sep-12", Double.valueOf(0.3421D));
    defaultKeyedValues.put("Oct-12", Double.valueOf(0.3477D));
    defaultKeyedValues.put("Nov-12", Double.valueOf(0.3572D));
    defaultKeyedValues.put("Dec-12", Double.valueOf(0.3642D));
    defaultKeyedValues.put("Jan-13", Double.valueOf(0.3652D));
    defaultKeyedValues.put("Feb-13", Double.valueOf(0.3709D));
    defaultKeyedValues.put("Mar-13", Double.valueOf(0.3807D));
    defaultKeyedValues.put("Apr-13", Double.valueOf(0.3915D));
    defaultKeyedValues.put("May-13", Double.valueOf(0.4138D));
    defaultKeyedValues.put("Jun-13", Double.valueOf(0.4268D));
    return (KeyedValues<Double>)defaultKeyedValues;
  }
  
  private static KeyedValues<Double> createFirefoxData() {
    DefaultKeyedValues defaultKeyedValues = new DefaultKeyedValues();
    defaultKeyedValues.put("Jan-12", Double.valueOf(0.2478D));
    defaultKeyedValues.put("Feb-12", Double.valueOf(0.2488D));
    defaultKeyedValues.put("Mar-12", Double.valueOf(0.2498D));
    defaultKeyedValues.put("Apr-12", Double.valueOf(0.2487D));
    defaultKeyedValues.put("May-12", Double.valueOf(0.2555D));
    defaultKeyedValues.put("Jun-12", Double.valueOf(0.2456D));
    defaultKeyedValues.put("Jul-12", Double.valueOf(0.2373D));
    defaultKeyedValues.put("Aug-12", Double.valueOf(0.2285D));
    defaultKeyedValues.put("Sep-12", Double.valueOf(0.224D));
    defaultKeyedValues.put("Oct-12", Double.valueOf(0.2232D));
    defaultKeyedValues.put("Nov-12", Double.valueOf(0.2237D));
    defaultKeyedValues.put("Dec-12", Double.valueOf(0.2189D));
    defaultKeyedValues.put("Jan-13", Double.valueOf(0.2142D));
    defaultKeyedValues.put("Feb-13", Double.valueOf(0.2134D));
    defaultKeyedValues.put("Mar-13", Double.valueOf(0.2087D));
    defaultKeyedValues.put("Apr-13", Double.valueOf(0.2006D));
    defaultKeyedValues.put("May-13", Double.valueOf(0.1976D));
    defaultKeyedValues.put("Jun-13", Double.valueOf(0.2001D));
    return (KeyedValues<Double>)defaultKeyedValues;
  }
  
  private static KeyedValues<Double> createInternetExplorerData() {
    DefaultKeyedValues defaultKeyedValues = new DefaultKeyedValues();
    defaultKeyedValues.put("Jan-12", Double.valueOf(0.3745D));
    defaultKeyedValues.put("Feb-12", Double.valueOf(0.3575D));
    defaultKeyedValues.put("Mar-12", Double.valueOf(0.3481D));
    defaultKeyedValues.put("Apr-12", Double.valueOf(0.3407D));
    defaultKeyedValues.put("May-12", Double.valueOf(0.3212D));
    defaultKeyedValues.put("Jun-12", Double.valueOf(0.3231D));
    defaultKeyedValues.put("Jul-12", Double.valueOf(0.3204D));
    defaultKeyedValues.put("Aug-12", Double.valueOf(0.3285D));
    defaultKeyedValues.put("Sep-12", Double.valueOf(0.327D));
    defaultKeyedValues.put("Oct-12", Double.valueOf(0.3208D));
    defaultKeyedValues.put("Nov-12", Double.valueOf(0.3123D));
    defaultKeyedValues.put("Dec-12", Double.valueOf(0.3078D));
    defaultKeyedValues.put("Jan-13", Double.valueOf(0.3069D));
    defaultKeyedValues.put("Feb-13", Double.valueOf(0.2982D));
    defaultKeyedValues.put("Mar-13", Double.valueOf(0.293D));
    defaultKeyedValues.put("Jun-13", Double.valueOf(0.2544D));
    defaultKeyedValues.put("May-13", Double.valueOf(0.2772D));
    defaultKeyedValues.put("Apr-13", Double.valueOf(0.2971D));
    return (KeyedValues<Double>)defaultKeyedValues;
  }
  
  private static KeyedValues<Double> createSafariData() {
    DefaultKeyedValues defaultKeyedValues = new DefaultKeyedValues();
    defaultKeyedValues.put("Jan-12", Double.valueOf(0.0662D));
    defaultKeyedValues.put("Feb-12", Double.valueOf(0.0677D));
    defaultKeyedValues.put("Mar-12", Double.valueOf(0.0672D));
    defaultKeyedValues.put("Apr-12", Double.valueOf(0.0713D));
    defaultKeyedValues.put("May-12", Double.valueOf(0.0709D));
    defaultKeyedValues.put("Jun-12", Double.valueOf(0.07D));
    defaultKeyedValues.put("Jul-12", Double.valueOf(0.0712D));
    defaultKeyedValues.put("Aug-12", Double.valueOf(0.0739D));
    defaultKeyedValues.put("Sep-12", Double.valueOf(0.077D));
    defaultKeyedValues.put("Oct-12", Double.valueOf(0.0781D));
    defaultKeyedValues.put("Nov-12", Double.valueOf(0.0783D));
    defaultKeyedValues.put("Dec-12", Double.valueOf(0.0792D));
    defaultKeyedValues.put("Jan-13", Double.valueOf(0.083D));
    defaultKeyedValues.put("Feb-13", Double.valueOf(0.086D));
    defaultKeyedValues.put("Mar-13", Double.valueOf(0.085D));
    defaultKeyedValues.put("Apr-13", Double.valueOf(0.08D));
    defaultKeyedValues.put("May-13", Double.valueOf(0.0796D));
    defaultKeyedValues.put("Jun-13", Double.valueOf(0.0839D));
    return (KeyedValues<Double>)defaultKeyedValues;
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/orsoncharts/LineChart3D1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */