package demo.orsoncharts;

public class DemoDescription {
  private String className;
  
  private String fileName;
  
  private String descriptionFileName;
  
  public DemoDescription(String paramString1, String paramString2, String paramString3) {
    this.className = paramString1;
    this.fileName = paramString2;
    this.descriptionFileName = paramString3;
  }
  
  public String getClassName() {
    return this.className;
  }
  
  public String getFileName() {
    return this.fileName;
  }
  
  public String getDescriptionFileName() {
    return this.descriptionFileName;
  }
  
  public String toString() {
    return this.fileName;
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/orsoncharts/DemoDescription.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */