package demo.orsoncharts;

import com.orsoncharts.Chart3D;
import com.orsoncharts.Chart3DFactory;
import com.orsoncharts.Colors;
import com.orsoncharts.data.xyz.XYZDataset;
import com.orsoncharts.data.xyz.XYZSeries;
import com.orsoncharts.data.xyz.XYZSeriesCollection;
import com.orsoncharts.graphics3d.Dimension3D;
import com.orsoncharts.graphics3d.ViewPoint3D;
import com.orsoncharts.label.StandardXYZLabelGenerator;
import com.orsoncharts.label.XYZLabelGenerator;
import com.orsoncharts.plot.XYZPlot;
import com.orsoncharts.renderer.xyz.ScatterXYZRenderer;

public class ScatterPlot3D1 {
  public static Chart3D createChart(XYZDataset paramXYZDataset) {
    Chart3D chart3D = Chart3DFactory.createScatterChart("ScatterPlot3DDemo1", "Chart created with Orson Charts", paramXYZDataset, "X", "Y", "Z");
    XYZPlot xYZPlot = (XYZPlot)chart3D.getPlot();
    xYZPlot.setDimensions(new Dimension3D(10.0D, 4.0D, 4.0D));
    xYZPlot.setLegendLabelGenerator((XYZLabelGenerator)new StandardXYZLabelGenerator("%s (%2$,d)"));
    ScatterXYZRenderer scatterXYZRenderer = (ScatterXYZRenderer)xYZPlot.getRenderer();
    scatterXYZRenderer.setSize(0.15D);
    scatterXYZRenderer.setColors(Colors.createIntenseColors());
    chart3D.setViewPoint(ViewPoint3D.createAboveLeftViewPoint(40.0D));
    return chart3D;
  }
  
  public static XYZDataset createDataset() {
    XYZSeries xYZSeries1 = createRandomSeries("S1", 10);
    XYZSeries xYZSeries2 = createRandomSeries("S2", 50);
    XYZSeries xYZSeries3 = createRandomSeries("S3", 150);
    XYZSeriesCollection xYZSeriesCollection = new XYZSeriesCollection();
    xYZSeriesCollection.add(xYZSeries1);
    xYZSeriesCollection.add(xYZSeries2);
    xYZSeriesCollection.add(xYZSeries3);
    return (XYZDataset)xYZSeriesCollection;
  }
  
  private static XYZSeries createRandomSeries(String paramString, int paramInt) {
    XYZSeries xYZSeries = new XYZSeries(paramString);
    for (byte b = 0; b < paramInt; b++)
      xYZSeries.add(Math.random() * 100.0D, Math.random() / 100.0D, Math.random() * 100.0D); 
    return xYZSeries;
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/orsoncharts/ScatterPlot3D1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */