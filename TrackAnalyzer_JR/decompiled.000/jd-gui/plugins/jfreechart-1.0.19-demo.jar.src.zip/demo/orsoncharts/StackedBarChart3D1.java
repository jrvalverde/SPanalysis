package demo.orsoncharts;

import com.orsoncharts.Chart3D;
import com.orsoncharts.Chart3DFactory;
import com.orsoncharts.data.DefaultKeyedValues;
import com.orsoncharts.data.KeyedValues;
import com.orsoncharts.data.category.CategoryDataset3D;
import com.orsoncharts.data.category.StandardCategoryDataset3D;

public class StackedBarChart3D1 {
  public static Chart3D createChart(CategoryDataset3D paramCategoryDataset3D) {
    return Chart3DFactory.createStackedBarChart("Stacked Bar Chart", "Put the data source here", paramCategoryDataset3D, null, null, "Value");
  }
  
  public static CategoryDataset3D createDataset() {
    StandardCategoryDataset3D standardCategoryDataset3D = new StandardCategoryDataset3D();
    DefaultKeyedValues defaultKeyedValues1 = new DefaultKeyedValues();
    defaultKeyedValues1.put("A", Double.valueOf(4.0D));
    defaultKeyedValues1.put("B", Double.valueOf(2.0D));
    defaultKeyedValues1.put("C", Double.valueOf(3.0D));
    defaultKeyedValues1.put("D", Double.valueOf(5.0D));
    defaultKeyedValues1.put("E", Double.valueOf(2.0D));
    defaultKeyedValues1.put("F", Double.valueOf(1.0D));
    DefaultKeyedValues defaultKeyedValues2 = new DefaultKeyedValues();
    defaultKeyedValues2.put("A", Double.valueOf(1.0D));
    defaultKeyedValues2.put("B", Double.valueOf(2.0D));
    defaultKeyedValues2.put("C", Double.valueOf(3.0D));
    defaultKeyedValues2.put("D", Double.valueOf(2.0D));
    defaultKeyedValues2.put("E", Double.valueOf(3.0D));
    defaultKeyedValues2.put("F", Double.valueOf(1.0D));
    DefaultKeyedValues defaultKeyedValues3 = new DefaultKeyedValues();
    defaultKeyedValues3.put("A", Double.valueOf(6.0D));
    defaultKeyedValues3.put("B", Double.valueOf(6.0D));
    defaultKeyedValues3.put("C", Double.valueOf(6.0D));
    defaultKeyedValues3.put("D", Double.valueOf(4.0D));
    defaultKeyedValues3.put("E", Double.valueOf(4.0D));
    defaultKeyedValues3.put("F", Double.valueOf(4.0D));
    DefaultKeyedValues defaultKeyedValues4 = new DefaultKeyedValues();
    defaultKeyedValues4.put("A", Double.valueOf(9.0D));
    defaultKeyedValues4.put("B", Double.valueOf(8.0D));
    defaultKeyedValues4.put("C", Double.valueOf(7.0D));
    defaultKeyedValues4.put("D", Double.valueOf(6.0D));
    defaultKeyedValues4.put("D", Double.valueOf(3.0D));
    defaultKeyedValues4.put("E", Double.valueOf(4.0D));
    defaultKeyedValues4.put("F", Double.valueOf(6.0D));
    DefaultKeyedValues defaultKeyedValues5 = new DefaultKeyedValues();
    defaultKeyedValues5.put("A", Double.valueOf(9.0D));
    defaultKeyedValues5.put("B", Double.valueOf(8.0D));
    defaultKeyedValues5.put("C", Double.valueOf(7.0D));
    defaultKeyedValues5.put("D", Double.valueOf(6.0D));
    defaultKeyedValues5.put("E", Double.valueOf(7.0D));
    defaultKeyedValues5.put("F", Double.valueOf(9.0D));
    standardCategoryDataset3D.addSeriesAsRow("Series 1", "Row 1", (KeyedValues)defaultKeyedValues1);
    standardCategoryDataset3D.addSeriesAsRow("Series 2", "Row 2", (KeyedValues)defaultKeyedValues2);
    standardCategoryDataset3D.addSeriesAsRow("Series 3", "Row 2", (KeyedValues)defaultKeyedValues3);
    standardCategoryDataset3D.addSeriesAsRow("Series 4", "Row 3", (KeyedValues)defaultKeyedValues4);
    standardCategoryDataset3D.addSeriesAsRow("Series 5", "Row 3", (KeyedValues)defaultKeyedValues5);
    return (CategoryDataset3D)standardCategoryDataset3D;
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/orsoncharts/StackedBarChart3D1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */