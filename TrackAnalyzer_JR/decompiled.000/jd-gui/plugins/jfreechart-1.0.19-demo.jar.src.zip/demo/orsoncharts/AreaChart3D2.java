package demo.orsoncharts;

import com.orsoncharts.Chart3D;
import com.orsoncharts.Chart3DFactory;
import com.orsoncharts.Colors;
import com.orsoncharts.data.DefaultKeyedValues;
import com.orsoncharts.data.KeyedValues;
import com.orsoncharts.data.category.CategoryDataset3D;
import com.orsoncharts.data.category.StandardCategoryDataset3D;
import com.orsoncharts.graphics3d.ViewPoint3D;
import com.orsoncharts.plot.CategoryPlot3D;
import com.orsoncharts.renderer.category.AreaRenderer3D;
import java.awt.Color;

public class AreaChart3D2 {
  public static Chart3D createChart(CategoryDataset3D paramCategoryDataset3D) {
    Chart3D chart3D = Chart3DFactory.createAreaChart("AreaChart3DDemo2", "Chart created with Orson Charts", paramCategoryDataset3D, "Row", "Category", "Value");
    chart3D.setChartBoxColor(new Color(255, 255, 255, 128));
    chart3D.setViewPoint(ViewPoint3D.createAboveLeftViewPoint(40.0D));
    CategoryPlot3D categoryPlot3D = (CategoryPlot3D)chart3D.getPlot();
    categoryPlot3D.getRowAxis().setVisible(false);
    AreaRenderer3D areaRenderer3D = (AreaRenderer3D)categoryPlot3D.getRenderer();
    areaRenderer3D.setBaseColor(Color.GRAY);
    areaRenderer3D.setColors(Colors.getSAPMultiColor());
    return chart3D;
  }
  
  public static CategoryDataset3D createDataset() {
    StandardCategoryDataset3D standardCategoryDataset3D = new StandardCategoryDataset3D();
    DefaultKeyedValues defaultKeyedValues1 = new DefaultKeyedValues();
    defaultKeyedValues1.put("A", Integer.valueOf(-1));
    defaultKeyedValues1.put("B", Integer.valueOf(-4));
    defaultKeyedValues1.put("C", Integer.valueOf(-9));
    defaultKeyedValues1.put("D", Integer.valueOf(-5));
    defaultKeyedValues1.put("E", Integer.valueOf(-5));
    defaultKeyedValues1.put("F", Integer.valueOf(-2));
    defaultKeyedValues1.put("G", Integer.valueOf(-4));
    defaultKeyedValues1.put("H", Integer.valueOf(-7));
    defaultKeyedValues1.put("I", Integer.valueOf(-3));
    defaultKeyedValues1.put("J", Integer.valueOf(-1));
    standardCategoryDataset3D.addSeriesAsRow("Series 1", (KeyedValues)defaultKeyedValues1);
    DefaultKeyedValues defaultKeyedValues2 = new DefaultKeyedValues();
    defaultKeyedValues2.put("A", Integer.valueOf(1));
    defaultKeyedValues2.put("B", Integer.valueOf(12));
    defaultKeyedValues2.put("C", Integer.valueOf(14));
    defaultKeyedValues2.put("D", Integer.valueOf(7));
    defaultKeyedValues2.put("E", Integer.valueOf(2));
    defaultKeyedValues2.put("F", Integer.valueOf(-9));
    defaultKeyedValues2.put("G", Integer.valueOf(-14));
    defaultKeyedValues2.put("H", Integer.valueOf(0));
    defaultKeyedValues2.put("I", Integer.valueOf(12));
    defaultKeyedValues2.put("J", Integer.valueOf(4));
    standardCategoryDataset3D.addSeriesAsRow("Series 2", (KeyedValues)defaultKeyedValues2);
    DefaultKeyedValues defaultKeyedValues3 = new DefaultKeyedValues();
    defaultKeyedValues3.put("A", Integer.valueOf(5));
    defaultKeyedValues3.put("B", Integer.valueOf(13));
    defaultKeyedValues3.put("C", Integer.valueOf(19));
    defaultKeyedValues3.put("D", Integer.valueOf(11));
    defaultKeyedValues3.put("E", Integer.valueOf(10));
    defaultKeyedValues3.put("F", Integer.valueOf(5));
    defaultKeyedValues3.put("G", Integer.valueOf(-7));
    defaultKeyedValues3.put("H", Integer.valueOf(-3));
    defaultKeyedValues3.put("I", Integer.valueOf(-15));
    defaultKeyedValues3.put("J", Integer.valueOf(-20));
    standardCategoryDataset3D.addSeriesAsRow("Series 3", (KeyedValues)defaultKeyedValues3);
    DefaultKeyedValues defaultKeyedValues4 = new DefaultKeyedValues();
    defaultKeyedValues4.put("A", Integer.valueOf(5));
    defaultKeyedValues4.put("B", Integer.valueOf(18));
    defaultKeyedValues4.put("C", Integer.valueOf(20));
    defaultKeyedValues4.put("D", Integer.valueOf(17));
    defaultKeyedValues4.put("E", Integer.valueOf(11));
    defaultKeyedValues4.put("F", Integer.valueOf(19));
    defaultKeyedValues4.put("G", Integer.valueOf(25));
    defaultKeyedValues4.put("H", Integer.valueOf(12));
    defaultKeyedValues4.put("I", Integer.valueOf(4));
    defaultKeyedValues4.put("J", Integer.valueOf(2));
    standardCategoryDataset3D.addSeriesAsRow("Series 4", (KeyedValues)defaultKeyedValues4);
    return (CategoryDataset3D)standardCategoryDataset3D;
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/orsoncharts/AreaChart3D2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */