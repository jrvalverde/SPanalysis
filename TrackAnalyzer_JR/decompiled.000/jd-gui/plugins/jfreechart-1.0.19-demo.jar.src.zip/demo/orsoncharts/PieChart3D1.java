package demo.orsoncharts;

import com.orsoncharts.Chart3D;
import com.orsoncharts.Chart3DFactory;
import com.orsoncharts.TitleAnchor;
import com.orsoncharts.data.PieDataset3D;
import com.orsoncharts.data.StandardPieDataset3D;
import com.orsoncharts.legend.LegendAnchor;
import com.orsoncharts.util.Orientation;

public class PieChart3D1 {
  public static Chart3D createChart(PieDataset3D paramPieDataset3D) {
    Chart3D chart3D = Chart3DFactory.createPieChart("New Zealand Exports 2012", "http://www.stats.govt.nz/browse_for_stats/snapshots-of-nz/nz-in-profile-2013.aspx", createDataset());
    chart3D.setTitleAnchor(TitleAnchor.TOP_LEFT);
    chart3D.setLegendPosition(LegendAnchor.BOTTOM_CENTER, Orientation.HORIZONTAL);
    return chart3D;
  }
  
  public static PieDataset3D createDataset() {
    StandardPieDataset3D standardPieDataset3D = new StandardPieDataset3D();
    standardPieDataset3D.add("Milk Products", 11625.0D);
    standardPieDataset3D.add("Meat", 5114.0D);
    standardPieDataset3D.add("Wood/Logs", 3060.0D);
    standardPieDataset3D.add("Crude Oil", 2023.0D);
    standardPieDataset3D.add("Machinery", 1865.0D);
    standardPieDataset3D.add("Fruit", 1587.0D);
    standardPieDataset3D.add("Fish", 1367.0D);
    standardPieDataset3D.add("Wine", 1177.0D);
    standardPieDataset3D.add("Other", 18870.0D);
    return (PieDataset3D)standardPieDataset3D;
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/orsoncharts/PieChart3D1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */