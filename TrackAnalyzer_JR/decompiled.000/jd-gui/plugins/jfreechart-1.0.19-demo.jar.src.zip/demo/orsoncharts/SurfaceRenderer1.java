package demo.orsoncharts;

import com.orsoncharts.Chart3D;
import com.orsoncharts.Chart3DFactory;
import com.orsoncharts.Range;
import com.orsoncharts.axis.ValueAxis3D;
import com.orsoncharts.data.function.Function3D;
import com.orsoncharts.graphics3d.Dimension3D;
import com.orsoncharts.plot.XYZPlot;
import com.orsoncharts.renderer.ColorScale;
import com.orsoncharts.renderer.GradientColorScale;
import com.orsoncharts.renderer.xyz.SurfaceRenderer;
import java.awt.Color;

public class SurfaceRenderer1 {
  public static Chart3D createChart() {
    Function3D function3D = new Function3D() {
        public double getValue(double param1Double1, double param1Double2) {
          return Math.cos(param1Double1) * Math.sin(param1Double2);
        }
      };
    Chart3D chart3D = Chart3DFactory.createSurfaceChart("SurfaceRendererDemo1", "y = cos(x) * sin(z)", function3D, "X", "Y", "Z");
    XYZPlot xYZPlot = (XYZPlot)chart3D.getPlot();
    xYZPlot.setDimensions(new Dimension3D(10.0D, 5.0D, 10.0D));
    ValueAxis3D valueAxis3D1 = xYZPlot.getXAxis();
    valueAxis3D1.setRange(-3.141592653589793D, Math.PI);
    ValueAxis3D valueAxis3D2 = xYZPlot.getZAxis();
    valueAxis3D2.setRange(-3.141592653589793D, Math.PI);
    SurfaceRenderer surfaceRenderer = (SurfaceRenderer)xYZPlot.getRenderer();
    surfaceRenderer.setColorScale((ColorScale)new GradientColorScale(new Range(-1.0D, 1.0D), Color.RED, Color.YELLOW));
    return chart3D;
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/orsoncharts/SurfaceRenderer1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */