package demo.orsoncharts;

import com.orsoncharts.Chart3D;
import com.orsoncharts.Chart3DFactory;
import com.orsoncharts.Colors;
import com.orsoncharts.axis.NumberAxis3D;
import com.orsoncharts.axis.StandardCategoryAxis3D;
import com.orsoncharts.data.DefaultKeyedValues;
import com.orsoncharts.data.KeyedValues;
import com.orsoncharts.data.category.CategoryDataset3D;
import com.orsoncharts.data.category.StandardCategoryDataset3D;
import com.orsoncharts.label.CategoryItemLabelGenerator;
import com.orsoncharts.label.StandardCategoryItemLabelGenerator;
import com.orsoncharts.legend.LegendAnchor;
import com.orsoncharts.plot.CategoryPlot3D;
import com.orsoncharts.util.Orientation;
import com.orsonpdf.PDFHints;
import java.awt.BasicStroke;
import java.awt.Color;

public class BarChart3D2 {
  public static Chart3D createChart(CategoryDataset3D paramCategoryDataset3D) {
    Chart3D chart3D = Chart3DFactory.createBarChart("Average Maximum Temperature", "http://www.worldclimateguide.co.uk/climateguides/", paramCategoryDataset3D, null, null, "Temp °C");
    chart3D.getRenderingHints().put(PDFHints.KEY_DRAW_STRING_TYPE, PDFHints.VALUE_DRAW_STRING_TYPE_VECTOR);
    chart3D.setLegendPosition(LegendAnchor.BOTTOM_RIGHT, Orientation.VERTICAL);
    chart3D.getViewPoint().panLeftRight(-0.05235987755982988D);
    CategoryPlot3D categoryPlot3D = (CategoryPlot3D)chart3D.getPlot();
    StandardCategoryAxis3D standardCategoryAxis3D1 = (StandardCategoryAxis3D)categoryPlot3D.getColumnAxis();
    NumberAxis3D numberAxis3D = (NumberAxis3D)categoryPlot3D.getValueAxis();
    StandardCategoryAxis3D standardCategoryAxis3D2 = (StandardCategoryAxis3D)categoryPlot3D.getRowAxis();
    categoryPlot3D.setGridlineStrokeForValues(new BasicStroke(0.0F));
    standardCategoryAxis3D1.setLineColor(new Color(0, 0, 0, 0));
    numberAxis3D.setLineColor(new Color(0, 0, 0, 0));
    standardCategoryAxis3D2.setLineColor(new Color(0, 0, 0, 0));
    categoryPlot3D.getRenderer().setColors(Colors.createPastelColors());
    categoryPlot3D.setToolTipGenerator((CategoryItemLabelGenerator)new StandardCategoryItemLabelGenerator("%2$s (%3$s) = %4$s degrees"));
    return chart3D;
  }
  
  public static CategoryDataset3D createDataset() {
    StandardCategoryDataset3D standardCategoryDataset3D = new StandardCategoryDataset3D();
    DefaultKeyedValues defaultKeyedValues1 = new DefaultKeyedValues();
    defaultKeyedValues1.put("Jan", Integer.valueOf(7));
    defaultKeyedValues1.put("Feb", Integer.valueOf(7));
    defaultKeyedValues1.put("Mar", Integer.valueOf(10));
    defaultKeyedValues1.put("Apr", Integer.valueOf(13));
    defaultKeyedValues1.put("May", Integer.valueOf(17));
    defaultKeyedValues1.put("Jun", Integer.valueOf(20));
    defaultKeyedValues1.put("Jul", Integer.valueOf(22));
    defaultKeyedValues1.put("Aug", Integer.valueOf(21));
    defaultKeyedValues1.put("Sep", Integer.valueOf(19));
    defaultKeyedValues1.put("Oct", Integer.valueOf(15));
    defaultKeyedValues1.put("Nov", Integer.valueOf(10));
    defaultKeyedValues1.put("Dec", Integer.valueOf(8));
    standardCategoryDataset3D.addSeriesAsRow("London", (KeyedValues)defaultKeyedValues1);
    DefaultKeyedValues defaultKeyedValues2 = new DefaultKeyedValues();
    defaultKeyedValues2.put("Jan", Integer.valueOf(3));
    defaultKeyedValues2.put("Feb", Integer.valueOf(5));
    defaultKeyedValues2.put("Mar", Integer.valueOf(9));
    defaultKeyedValues2.put("Apr", Integer.valueOf(14));
    defaultKeyedValues2.put("May", Integer.valueOf(18));
    defaultKeyedValues2.put("Jun", Integer.valueOf(22));
    defaultKeyedValues2.put("Jul", Integer.valueOf(25));
    defaultKeyedValues2.put("Aug", Integer.valueOf(24));
    defaultKeyedValues2.put("Sep", Integer.valueOf(20));
    defaultKeyedValues2.put("Oct", Integer.valueOf(14));
    defaultKeyedValues2.put("Nov", Integer.valueOf(8));
    defaultKeyedValues2.put("Dec", Integer.valueOf(4));
    standardCategoryDataset3D.addSeriesAsRow("Geneva", (KeyedValues)defaultKeyedValues2);
    DefaultKeyedValues defaultKeyedValues3 = new DefaultKeyedValues();
    defaultKeyedValues3.put("Jan", Integer.valueOf(9));
    defaultKeyedValues3.put("Feb", Integer.valueOf(11));
    defaultKeyedValues3.put("Mar", Integer.valueOf(13));
    defaultKeyedValues3.put("Apr", Integer.valueOf(16));
    defaultKeyedValues3.put("May", Integer.valueOf(20));
    defaultKeyedValues3.put("Jun", Integer.valueOf(23));
    defaultKeyedValues3.put("Jul", Integer.valueOf(26));
    defaultKeyedValues3.put("Aug", Integer.valueOf(26));
    defaultKeyedValues3.put("Sep", Integer.valueOf(24));
    defaultKeyedValues3.put("Oct", Integer.valueOf(19));
    defaultKeyedValues3.put("Nov", Integer.valueOf(13));
    defaultKeyedValues3.put("Dec", Integer.valueOf(9));
    standardCategoryDataset3D.addSeriesAsRow("Bergerac", (KeyedValues)defaultKeyedValues3);
    DefaultKeyedValues defaultKeyedValues4 = new DefaultKeyedValues();
    defaultKeyedValues4.put("Jan", Integer.valueOf(22));
    defaultKeyedValues4.put("Feb", Integer.valueOf(22));
    defaultKeyedValues4.put("Mar", Integer.valueOf(20));
    defaultKeyedValues4.put("Apr", Integer.valueOf(17));
    defaultKeyedValues4.put("May", Integer.valueOf(14));
    defaultKeyedValues4.put("Jun", Integer.valueOf(11));
    defaultKeyedValues4.put("Jul", Integer.valueOf(11));
    defaultKeyedValues4.put("Aug", Integer.valueOf(12));
    defaultKeyedValues4.put("Sep", Integer.valueOf(14));
    defaultKeyedValues4.put("Oct", Integer.valueOf(17));
    defaultKeyedValues4.put("Nov", Integer.valueOf(19));
    defaultKeyedValues4.put("Dec", Integer.valueOf(21));
    standardCategoryDataset3D.addSeriesAsRow("Christchurch", (KeyedValues)defaultKeyedValues4);
    DefaultKeyedValues defaultKeyedValues5 = new DefaultKeyedValues();
    defaultKeyedValues5.put("Jan", Integer.valueOf(20));
    defaultKeyedValues5.put("Feb", Integer.valueOf(20));
    defaultKeyedValues5.put("Mar", Integer.valueOf(19));
    defaultKeyedValues5.put("Apr", Integer.valueOf(17));
    defaultKeyedValues5.put("May", Integer.valueOf(14));
    defaultKeyedValues5.put("Jun", Integer.valueOf(12));
    defaultKeyedValues5.put("Jul", Integer.valueOf(11));
    defaultKeyedValues5.put("Aug", Integer.valueOf(12));
    defaultKeyedValues5.put("Sep", Integer.valueOf(13));
    defaultKeyedValues5.put("Oct", Integer.valueOf(15));
    defaultKeyedValues5.put("Nov", Integer.valueOf(17));
    defaultKeyedValues5.put("Dec", Integer.valueOf(19));
    standardCategoryDataset3D.addSeriesAsRow("Wellington", (KeyedValues)defaultKeyedValues5);
    return (CategoryDataset3D)standardCategoryDataset3D;
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/orsoncharts/BarChart3D2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */