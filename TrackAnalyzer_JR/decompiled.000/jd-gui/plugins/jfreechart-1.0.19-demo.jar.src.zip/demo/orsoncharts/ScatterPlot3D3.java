package demo.orsoncharts;

import com.orsoncharts.Chart3D;
import com.orsoncharts.Chart3DFactory;
import com.orsoncharts.Colors;
import com.orsoncharts.data.DataUtils;
import com.orsoncharts.data.JSONUtils;
import com.orsoncharts.data.KeyedValues3D;
import com.orsoncharts.data.xyz.XYZDataset;
import com.orsoncharts.graphics3d.ViewPoint3D;
import com.orsoncharts.legend.LegendAnchor;
import com.orsoncharts.plot.XYZPlot;
import com.orsoncharts.renderer.xyz.ScatterXYZRenderer;
import com.orsoncharts.style.StandardChartStyle;
import com.orsoncharts.table.TableElement;
import com.orsoncharts.table.TextElement;
import com.orsoncharts.util.Orientation;
import java.io.IOException;
import java.io.InputStreamReader;

public class ScatterPlot3D3 {
  public static XYZDataset[] createDatasets() {
    XYZDataset[] arrayOfXYZDataset = new XYZDataset[4];
    arrayOfXYZDataset[0] = createDataset("sepal length", "sepal width", "petal length");
    arrayOfXYZDataset[1] = createDataset("sepal length", "sepal width", "petal width");
    arrayOfXYZDataset[2] = createDataset("sepal length", "petal width", "petal length");
    arrayOfXYZDataset[3] = createDataset("sepal width", "petal width", "petal length");
    return arrayOfXYZDataset;
  }
  
  public static Chart3D createChart(String paramString1, XYZDataset paramXYZDataset, String paramString2, String paramString3, String paramString4) {
    Chart3D chart3D = Chart3DFactory.createScatterChart(null, null, paramXYZDataset, paramString2, paramString3, paramString4);
    TextElement textElement = new TextElement(paramString1);
    textElement.setFont(StandardChartStyle.createDefaultFont(0, 16));
    chart3D.setTitle((TableElement)textElement);
    chart3D.setLegendAnchor(LegendAnchor.BOTTOM_LEFT);
    chart3D.setLegendOrientation(Orientation.VERTICAL);
    XYZPlot xYZPlot = (XYZPlot)chart3D.getPlot();
    ScatterXYZRenderer scatterXYZRenderer = (ScatterXYZRenderer)xYZPlot.getRenderer();
    scatterXYZRenderer.setSize(0.15D);
    scatterXYZRenderer.setColors(Colors.createIntenseColors());
    chart3D.setViewPoint(ViewPoint3D.createAboveLeftViewPoint(40.0D));
    return chart3D;
  }
  
  private static XYZDataset createDataset(Comparable<?> paramComparable1, Comparable<?> paramComparable2, Comparable<?> paramComparable3) {
    KeyedValues3D keyedValues3D;
    InputStreamReader inputStreamReader = new InputStreamReader(ScatterPlot3D3.class.getResourceAsStream("iris.txt"));
    try {
      keyedValues3D = JSONUtils.readKeyedValues3D(inputStreamReader);
    } catch (IOException iOException) {
      throw new RuntimeException(iOException);
    } 
    return DataUtils.extractXYZDatasetFromColumns(keyedValues3D, paramComparable1, paramComparable2, paramComparable3);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/orsoncharts/ScatterPlot3D3.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */