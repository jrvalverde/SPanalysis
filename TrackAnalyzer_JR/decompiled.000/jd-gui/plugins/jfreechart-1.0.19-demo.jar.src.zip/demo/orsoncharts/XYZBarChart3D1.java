package demo.orsoncharts;

import com.orsoncharts.Chart3D;
import com.orsoncharts.Chart3DFactory;
import com.orsoncharts.data.xyz.XYZDataset;
import com.orsoncharts.data.xyz.XYZSeries;
import com.orsoncharts.data.xyz.XYZSeriesCollection;
import com.orsoncharts.graphics3d.ViewPoint3D;

public class XYZBarChart3D1 {
  public static Chart3D createChart(XYZDataset paramXYZDataset) {
    Chart3D chart3D = Chart3DFactory.createXYZBarChart("XYZBarChart3DDemo1", "Chart created with Orson Charts", paramXYZDataset, "X", "Value", "Z");
    chart3D.setViewPoint(ViewPoint3D.createAboveRightViewPoint(40.0D));
    return chart3D;
  }
  
  public static XYZDataset createDataset() {
    XYZSeries xYZSeries1 = new XYZSeries("Series 1");
    xYZSeries1.add(1.0D, 5.0D, 1.0D);
    XYZSeries xYZSeries2 = new XYZSeries("Series 2");
    xYZSeries2.add(2.0D, 8.0D, 2.0D);
    XYZSeries xYZSeries3 = new XYZSeries("Series 3");
    xYZSeries3.add(1.0D, 10.0D, 2.0D);
    XYZSeriesCollection xYZSeriesCollection = new XYZSeriesCollection();
    xYZSeriesCollection.add(xYZSeries1);
    xYZSeriesCollection.add(xYZSeries2);
    xYZSeriesCollection.add(xYZSeries3);
    return (XYZDataset)xYZSeriesCollection;
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/orsoncharts/XYZBarChart3D1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */