package demo.orsoncharts;

import com.orsoncharts.Chart3D;
import com.orsoncharts.Chart3DFactory;
import com.orsoncharts.data.DefaultKeyedValues;
import com.orsoncharts.data.KeyedValues;
import com.orsoncharts.data.category.CategoryDataset3D;
import com.orsoncharts.data.category.StandardCategoryDataset3D;
import com.orsoncharts.legend.LegendAnchor;
import java.awt.Color;

public class LineChart3D2 {
  public static Chart3D createChart(CategoryDataset3D paramCategoryDataset3D) {
    Chart3D chart3D = Chart3DFactory.createLineChart("Quarterly Profits", "Large Banks in USA", paramCategoryDataset3D, null, "Quarter", "$ millions");
    chart3D.setChartBoxColor(new Color(255, 255, 255, 128));
    chart3D.setLegendAnchor(LegendAnchor.TOP_RIGHT);
    return chart3D;
  }
  
  public static CategoryDataset3D createDataset() {
    StandardCategoryDataset3D standardCategoryDataset3D = new StandardCategoryDataset3D();
    DefaultKeyedValues defaultKeyedValues1 = new DefaultKeyedValues();
    defaultKeyedValues1.put("Q3/11", Integer.valueOf(5889));
    defaultKeyedValues1.put("Q4/11", Integer.valueOf(1584));
    defaultKeyedValues1.put("Q1/12", Integer.valueOf(328));
    defaultKeyedValues1.put("Q2/12", Integer.valueOf(2098));
    defaultKeyedValues1.put("Q3/12", Integer.valueOf(-33));
    defaultKeyedValues1.put("Q4/12", Integer.valueOf(367));
    defaultKeyedValues1.put("Q1/13", Integer.valueOf(1110));
    defaultKeyedValues1.put("Q2/13", Integer.valueOf(3571));
    defaultKeyedValues1.put("Q3/13", Integer.valueOf(2218));
    standardCategoryDataset3D.addSeriesAsRow("Bank of America", (KeyedValues)defaultKeyedValues1);
    DefaultKeyedValues defaultKeyedValues2 = new DefaultKeyedValues();
    defaultKeyedValues2.put("Q3/11", Integer.valueOf(3771));
    defaultKeyedValues2.put("Q4/11", Integer.valueOf(956));
    defaultKeyedValues2.put("Q1/12", Integer.valueOf(2931));
    defaultKeyedValues2.put("Q2/12", Integer.valueOf(2946));
    defaultKeyedValues2.put("Q3/12", Integer.valueOf(468));
    defaultKeyedValues2.put("Q4/12", Integer.valueOf(1196));
    defaultKeyedValues2.put("Q1/13", Integer.valueOf(3808));
    defaultKeyedValues2.put("Q2/13", Integer.valueOf(4182));
    defaultKeyedValues2.put("Q3/13", Integer.valueOf(3227));
    standardCategoryDataset3D.addSeriesAsRow("Citigroup", (KeyedValues)defaultKeyedValues2);
    DefaultKeyedValues defaultKeyedValues3 = new DefaultKeyedValues();
    defaultKeyedValues3.put("Q3/11", Integer.valueOf(4055));
    defaultKeyedValues3.put("Q4/11", Integer.valueOf(4107));
    defaultKeyedValues3.put("Q1/12", Integer.valueOf(4248));
    defaultKeyedValues3.put("Q2/12", Integer.valueOf(4622));
    defaultKeyedValues3.put("Q3/12", Integer.valueOf(4937));
    defaultKeyedValues3.put("Q4/12", Integer.valueOf(4857));
    defaultKeyedValues3.put("Q1/13", Integer.valueOf(4931));
    defaultKeyedValues3.put("Q2/13", Integer.valueOf(5272));
    defaultKeyedValues3.put("Q3/13", Integer.valueOf(5317));
    standardCategoryDataset3D.addSeriesAsRow("Wells Fargo", (KeyedValues)defaultKeyedValues3);
    DefaultKeyedValues defaultKeyedValues4 = new DefaultKeyedValues();
    defaultKeyedValues4.put("Q3/11", Integer.valueOf(4262));
    defaultKeyedValues4.put("Q4/11", Integer.valueOf(3728));
    defaultKeyedValues4.put("Q1/12", Integer.valueOf(4924));
    defaultKeyedValues4.put("Q2/12", Integer.valueOf(4960));
    defaultKeyedValues4.put("Q3/12", Integer.valueOf(5708));
    defaultKeyedValues4.put("Q4/12", Integer.valueOf(5692));
    defaultKeyedValues4.put("Q1/13", Integer.valueOf(6529));
    defaultKeyedValues4.put("Q2/13", Integer.valueOf(6496));
    defaultKeyedValues4.put("Q3/13", Integer.valueOf(-380));
    standardCategoryDataset3D.addSeriesAsRow("J.P.Morgan", (KeyedValues)defaultKeyedValues4);
    return (CategoryDataset3D)standardCategoryDataset3D;
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/orsoncharts/LineChart3D2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */