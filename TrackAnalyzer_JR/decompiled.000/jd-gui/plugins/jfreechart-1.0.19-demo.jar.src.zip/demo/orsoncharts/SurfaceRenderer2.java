package demo.orsoncharts;

import com.orsoncharts.Chart3D;
import com.orsoncharts.Chart3DFactory;
import com.orsoncharts.Range;
import com.orsoncharts.axis.ValueAxis3D;
import com.orsoncharts.data.function.Function3D;
import com.orsoncharts.graphics3d.Dimension3D;
import com.orsoncharts.legend.LegendAnchor;
import com.orsoncharts.plot.XYZPlot;
import com.orsoncharts.renderer.ColorScale;
import com.orsoncharts.renderer.RainbowScale;
import com.orsoncharts.renderer.xyz.SurfaceRenderer;
import com.orsoncharts.util.Orientation;

public class SurfaceRenderer2 {
  public static Chart3D createChart() {
    Function3D function3D = new Function3D() {
        public double getValue(double param1Double1, double param1Double2) {
          return Math.sin(param1Double1 * param1Double1 + param1Double2 * param1Double2);
        }
      };
    Chart3D chart3D = Chart3DFactory.createSurfaceChart("SurfaceRendererDemo2", "y = sin(x^2 + z^2)", function3D, "X", "Y", "Z");
    XYZPlot xYZPlot = (XYZPlot)chart3D.getPlot();
    xYZPlot.setDimensions(new Dimension3D(10.0D, 5.0D, 10.0D));
    ValueAxis3D valueAxis3D1 = xYZPlot.getXAxis();
    valueAxis3D1.setRange(-2.0D, 2.0D);
    ValueAxis3D valueAxis3D2 = xYZPlot.getZAxis();
    valueAxis3D2.setRange(-2.0D, 2.0D);
    SurfaceRenderer surfaceRenderer = (SurfaceRenderer)xYZPlot.getRenderer();
    surfaceRenderer.setColorScale((ColorScale)new RainbowScale(new Range(-1.0D, 1.0D)));
    surfaceRenderer.setDrawFaceOutlines(false);
    chart3D.setLegendPosition(LegendAnchor.BOTTOM_RIGHT, Orientation.VERTICAL);
    return chart3D;
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/orsoncharts/SurfaceRenderer2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */