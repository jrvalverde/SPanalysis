package demo.orsoncharts;

import com.orsoncharts.Chart3D;
import com.orsoncharts.Chart3DFactory;
import com.orsoncharts.ChartElementVisitor;
import com.orsoncharts.axis.LabelOrientation;
import com.orsoncharts.axis.LogAxis3D;
import com.orsoncharts.axis.ValueAxis3D;
import com.orsoncharts.data.xyz.XYZDataset;
import com.orsoncharts.data.xyz.XYZSeries;
import com.orsoncharts.data.xyz.XYZSeriesCollection;
import com.orsoncharts.graphics3d.Dimension3D;
import com.orsoncharts.graphics3d.ViewPoint3D;
import com.orsoncharts.plot.XYZPlot;
import com.orsoncharts.renderer.xyz.ScatterXYZRenderer;
import com.orsoncharts.style.ChartStyler;
import java.awt.Color;

public class ScatterPlot3D2 {
  public static Chart3D createChart(XYZDataset paramXYZDataset) {
    Chart3D chart3D = Chart3DFactory.createScatterChart("ScatterPlot3DDemo2", null, paramXYZDataset, "X", "Y", "Z");
    XYZPlot xYZPlot = (XYZPlot)chart3D.getPlot();
    ScatterXYZRenderer scatterXYZRenderer = (ScatterXYZRenderer)xYZPlot.getRenderer();
    xYZPlot.setDimensions(new Dimension3D(10.0D, 6.0D, 10.0D));
    scatterXYZRenderer.setSize(0.1D);
    scatterXYZRenderer.setColors(new Color[] { new Color(255, 128, 128), new Color(128, 255, 128) });
    LogAxis3D logAxis3D = new LogAxis3D("Y (log scale)");
    logAxis3D.setTickLabelOrientation(LabelOrientation.PERPENDICULAR);
    logAxis3D.receive((ChartElementVisitor)new ChartStyler(chart3D.getStyle()));
    xYZPlot.setYAxis((ValueAxis3D)logAxis3D);
    chart3D.setViewPoint(ViewPoint3D.createAboveLeftViewPoint(40.0D));
    return chart3D;
  }
  
  public static XYZDataset createDataset() {
    XYZSeries xYZSeries1 = new XYZSeries("S1");
    for (byte b1 = 0; b1 < 'Ϩ'; b1++)
      xYZSeries1.add(Math.random() * 100.0D, Math.pow(10.0D, Math.random() * 5.0D), Math.random() * 100.0D); 
    XYZSeries xYZSeries2 = new XYZSeries("S2");
    for (byte b2 = 0; b2 < 'Ϩ'; b2++)
      xYZSeries2.add(Math.random() * 100.0D, Math.random() * 100000.0D, Math.random() * 100.0D); 
    XYZSeriesCollection xYZSeriesCollection = new XYZSeriesCollection();
    xYZSeriesCollection.add(xYZSeries1);
    xYZSeriesCollection.add(xYZSeries2);
    return (XYZDataset)xYZSeriesCollection;
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/orsoncharts/ScatterPlot3D2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */