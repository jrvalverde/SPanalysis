package demo.orsoncharts;

import com.orsoncharts.Chart3D;
import com.orsoncharts.Chart3DFactory;
import com.orsoncharts.data.DefaultKeyedValues;
import com.orsoncharts.data.KeyedValues;
import com.orsoncharts.data.category.CategoryDataset3D;
import com.orsoncharts.data.category.StandardCategoryDataset3D;
import com.orsoncharts.plot.CategoryPlot3D;
import com.orsoncharts.renderer.category.AreaRenderer3D;
import java.awt.Color;

public class AreaChart3D1 {
  public static Chart3D createChart(CategoryDataset3D paramCategoryDataset3D) {
    Chart3D chart3D = Chart3DFactory.createAreaChart("Reported Revenues By Quarter", "Large companies in the IT industry", paramCategoryDataset3D, "Company", "Quarter", "Value");
    chart3D.setChartBoxColor(new Color(255, 255, 255, 128));
    CategoryPlot3D categoryPlot3D = (CategoryPlot3D)chart3D.getPlot();
    categoryPlot3D.getRowAxis().setVisible(false);
    AreaRenderer3D areaRenderer3D = (AreaRenderer3D)categoryPlot3D.getRenderer();
    areaRenderer3D.setBaseColor(Color.GRAY);
    return chart3D;
  }
  
  public static CategoryDataset3D createDataset() {
    StandardCategoryDataset3D standardCategoryDataset3D = new StandardCategoryDataset3D();
    DefaultKeyedValues defaultKeyedValues1 = new DefaultKeyedValues();
    defaultKeyedValues1.put("Q2/11", Double.valueOf(8.181D));
    defaultKeyedValues1.put("Q3/11", Double.valueOf(8.792D));
    defaultKeyedValues1.put("Q4/11", Double.valueOf(9.039D));
    defaultKeyedValues1.put("Q1/12", Double.valueOf(10.916D));
    defaultKeyedValues1.put("Q2/12", Double.valueOf(8.181D));
    defaultKeyedValues1.put("Q3/12", Double.valueOf(9.094D));
    defaultKeyedValues1.put("Q4/12", Double.valueOf(8.958D));
    defaultKeyedValues1.put("Q1/13", Double.valueOf(10.947D));
    defaultKeyedValues1.put("Q2/13", Double.valueOf(8.372D));
    defaultKeyedValues1.put("Q3/13", Double.valueOf(9.275D));
    standardCategoryDataset3D.addSeriesAsRow("Oracle", (KeyedValues)defaultKeyedValues1);
    DefaultKeyedValues defaultKeyedValues2 = new DefaultKeyedValues();
    defaultKeyedValues2.put("Q2/11", Double.valueOf(9.03D));
    defaultKeyedValues2.put("Q3/11", Double.valueOf(9.72D));
    defaultKeyedValues2.put("Q4/11", Double.valueOf(10.58D));
    defaultKeyedValues2.put("Q1/12", Double.valueOf(10.65D));
    defaultKeyedValues2.put("Q2/12", Double.valueOf(12.214D));
    defaultKeyedValues2.put("Q3/12", Double.valueOf(14.101D));
    defaultKeyedValues2.put("Q4/12", Double.valueOf(14.419D));
    defaultKeyedValues2.put("Q1/13", Double.valueOf(13.969D));
    defaultKeyedValues2.put("Q2/13", Double.valueOf(14.105D));
    defaultKeyedValues2.put("Q3/13", Double.valueOf(14.893D));
    defaultKeyedValues2.put("Q4/13", Double.valueOf(16.858D));
    standardCategoryDataset3D.addSeriesAsRow("Google", (KeyedValues)defaultKeyedValues2);
    DefaultKeyedValues defaultKeyedValues3 = new DefaultKeyedValues();
    defaultKeyedValues3.put("Q2/11", Double.valueOf(17.37D));
    defaultKeyedValues3.put("Q3/11", Double.valueOf(17.37D));
    defaultKeyedValues3.put("Q4/11", Double.valueOf(20.89D));
    defaultKeyedValues3.put("Q1/12", Double.valueOf(17.41D));
    defaultKeyedValues3.put("Q2/12", Double.valueOf(18.06D));
    defaultKeyedValues3.put("Q3/12", Double.valueOf(16.008D));
    defaultKeyedValues3.put("Q4/12", Double.valueOf(21.456D));
    defaultKeyedValues3.put("Q1/13", Double.valueOf(20.489D));
    defaultKeyedValues3.put("Q2/13", Double.valueOf(19.896D));
    defaultKeyedValues3.put("Q3/13", Double.valueOf(18.529D));
    defaultKeyedValues3.put("Q4/13", Double.valueOf(24.519D));
    standardCategoryDataset3D.addSeriesAsRow("Microsoft", (KeyedValues)defaultKeyedValues3);
    DefaultKeyedValues defaultKeyedValues4 = new DefaultKeyedValues();
    defaultKeyedValues4.put("Q2/11", Double.valueOf(28.57D));
    defaultKeyedValues4.put("Q3/11", Double.valueOf(28.27D));
    defaultKeyedValues4.put("Q4/11", Double.valueOf(46.33D));
    defaultKeyedValues4.put("Q1/12", Double.valueOf(39.2D));
    defaultKeyedValues4.put("Q2/12", Double.valueOf(35.0D));
    defaultKeyedValues4.put("Q3/12", Double.valueOf(36.0D));
    defaultKeyedValues4.put("Q4/12", Double.valueOf(54.5D));
    defaultKeyedValues4.put("Q1/13", Double.valueOf(43.6D));
    defaultKeyedValues4.put("Q2/13", Double.valueOf(35.323D));
    defaultKeyedValues4.put("Q3/13", Double.valueOf(37.5D));
    defaultKeyedValues4.put("Q4/13", Double.valueOf(57.594D));
    standardCategoryDataset3D.addSeriesAsRow("Apple", (KeyedValues)defaultKeyedValues4);
    return (CategoryDataset3D)standardCategoryDataset3D;
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/orsoncharts/AreaChart3D1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */