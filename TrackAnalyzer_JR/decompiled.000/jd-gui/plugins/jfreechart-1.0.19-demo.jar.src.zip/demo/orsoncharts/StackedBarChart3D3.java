package demo.orsoncharts;

import com.orsoncharts.Chart3D;
import com.orsoncharts.Chart3DFactory;
import com.orsoncharts.Colors;
import com.orsoncharts.axis.LabelOrientation;
import com.orsoncharts.axis.StandardCategoryAxis3D;
import com.orsoncharts.data.category.CategoryDataset3D;
import com.orsoncharts.data.category.StandardCategoryDataset3D;
import com.orsoncharts.label.CategoryItemLabelGenerator;
import com.orsoncharts.label.CategoryLabelGenerator;
import com.orsoncharts.label.StandardCategoryItemLabelGenerator;
import com.orsoncharts.label.StandardCategoryLabelGenerator;
import com.orsoncharts.plot.CategoryPlot3D;
import com.orsoncharts.renderer.category.StackedBarRenderer3D;
import com.orsoncharts.table.RectanglePainter;
import com.orsoncharts.table.StandardRectanglePainter;
import com.orsoncharts.util.Fit2D;
import java.awt.Color;
import java.net.URL;
import javax.swing.ImageIcon;

public class StackedBarChart3D3 {
  public static Chart3D createChart(CategoryDataset3D paramCategoryDataset3D) {
    Chart3D chart3D = Chart3DFactory.createStackedBarChart("The Sinking of the Titanic", "Survival data for 2,201 passengers", paramCategoryDataset3D, null, "Class", "Passengers");
    URL uRL = StackedBarChart3D3.class.getResource("iStock_000003105870Small.jpg");
    ImageIcon imageIcon = new ImageIcon(uRL);
    StandardRectanglePainter standardRectanglePainter = new StandardRectanglePainter(Color.WHITE, imageIcon.getImage(), Fit2D.SCALE_TO_FIT_TARGET);
    chart3D.setBackground((RectanglePainter)standardRectanglePainter);
    chart3D.setChartBoxColor(new Color(255, 255, 255, 155));
    CategoryPlot3D categoryPlot3D = (CategoryPlot3D)chart3D.getPlot();
    categoryPlot3D.setLegendLabelGenerator((CategoryLabelGenerator)new StandardCategoryLabelGenerator("%s (%3$,.0f)"));
    categoryPlot3D.setToolTipGenerator((CategoryItemLabelGenerator)new StandardCategoryItemLabelGenerator("%s, %s, %s = %4$.0f"));
    StandardCategoryAxis3D standardCategoryAxis3D1 = (StandardCategoryAxis3D)categoryPlot3D.getRowAxis();
    standardCategoryAxis3D1.setTickLabelGenerator((CategoryLabelGenerator)new StandardCategoryLabelGenerator("%s (%3$,.0f)"));
    StandardCategoryAxis3D standardCategoryAxis3D2 = (StandardCategoryAxis3D)categoryPlot3D.getColumnAxis();
    standardCategoryAxis3D2.setTickLabelGenerator((CategoryLabelGenerator)new StandardCategoryLabelGenerator("%s (%3$,.0f)"));
    standardCategoryAxis3D2.setTickLabelOrientation(LabelOrientation.PARALLEL);
    standardCategoryAxis3D2.setMaxTickLabelLevels(2);
    StackedBarRenderer3D stackedBarRenderer3D = (StackedBarRenderer3D)categoryPlot3D.getRenderer();
    stackedBarRenderer3D.setColors(Colors.createIceCubeColors());
    return chart3D;
  }
  
  public static CategoryDataset3D createDataset() {
    StandardCategoryDataset3D standardCategoryDataset3D = new StandardCategoryDataset3D();
    standardCategoryDataset3D.addValue(Integer.valueOf(146), "Survivors", "Women/Children", "1st");
    standardCategoryDataset3D.addValue(Integer.valueOf(104), "Survivors", "Women/Children", "2nd");
    standardCategoryDataset3D.addValue(Integer.valueOf(103), "Survivors", "Women/Children", "3rd");
    standardCategoryDataset3D.addValue(Integer.valueOf(20), "Survivors", "Women/Children", "Crew");
    standardCategoryDataset3D.addValue(Integer.valueOf(57), "Survivors", "Men", "1st");
    standardCategoryDataset3D.addValue(Integer.valueOf(14), "Survivors", "Men", "2nd");
    standardCategoryDataset3D.addValue(Integer.valueOf(75), "Survivors", "Men", "3rd");
    standardCategoryDataset3D.addValue(Integer.valueOf(192), "Survivors", "Men", "Crew");
    standardCategoryDataset3D.addValue(Integer.valueOf(4), "Victims", "Women/Children", "1st");
    standardCategoryDataset3D.addValue(Integer.valueOf(13), "Victims", "Women/Children", "2nd");
    standardCategoryDataset3D.addValue(Integer.valueOf(141), "Victims", "Women/Children", "3rd");
    standardCategoryDataset3D.addValue(Integer.valueOf(3), "Victims", "Women/Children", "Crew");
    standardCategoryDataset3D.addValue(Integer.valueOf(118), "Victims", "Men", "1st");
    standardCategoryDataset3D.addValue(Integer.valueOf(154), "Victims", "Men", "2nd");
    standardCategoryDataset3D.addValue(Integer.valueOf(387), "Victims", "Men", "3rd");
    standardCategoryDataset3D.addValue(Integer.valueOf(670), "Victims", "Men", "Crew");
    return (CategoryDataset3D)standardCategoryDataset3D;
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/orsoncharts/StackedBarChart3D3.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */