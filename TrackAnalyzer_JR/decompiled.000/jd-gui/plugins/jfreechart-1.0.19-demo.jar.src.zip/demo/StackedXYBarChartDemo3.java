package demo;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.GradientPaint;
import java.awt.Window;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import javax.swing.JPanel;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.DateAxis;
import org.jfree.chart.axis.DateTickMarkPosition;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.labels.StandardXYToolTipGenerator;
import org.jfree.chart.labels.XYToolTipGenerator;
import org.jfree.chart.plot.Plot;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.StackedXYBarRenderer;
import org.jfree.chart.renderer.xy.XYItemRenderer;
import org.jfree.chart.title.TextTitle;
import org.jfree.chart.title.Title;
import org.jfree.data.time.TimePeriod;
import org.jfree.data.time.TimeTableXYDataset;
import org.jfree.data.time.Year;
import org.jfree.data.xy.TableXYDataset;
import org.jfree.data.xy.XYDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.GradientPaintTransformType;
import org.jfree.ui.GradientPaintTransformer;
import org.jfree.ui.RefineryUtilities;
import org.jfree.ui.StandardGradientPaintTransformer;

public class StackedXYBarChartDemo3 extends ApplicationFrame {
  public StackedXYBarChartDemo3(String paramString) {
    super(paramString);
    JPanel jPanel = createDemoPanel();
    jPanel.setPreferredSize(new Dimension(500, 270));
    setContentPane(jPanel);
  }
  
  private static TableXYDataset createDataset() {
    TimeTableXYDataset timeTableXYDataset = new TimeTableXYDataset();
    timeTableXYDataset.add((TimePeriod)new Year(2002), 41287.0D, "Landfilled");
    timeTableXYDataset.add((TimePeriod)new Year(2003), 41096.0D, "Landfilled");
    timeTableXYDataset.add((TimePeriod)new Year(2004), 39603.0D, "Landfilled");
    timeTableXYDataset.add((TimePeriod)new Year(2005), 39693.0D, "Landfilled");
    timeTableXYDataset.add((TimePeriod)new Year(2006), 37227.0D, "Landfilled");
    timeTableXYDataset.add((TimePeriod)new Year(2002), 7717.0D, "Recycled");
    timeTableXYDataset.add((TimePeriod)new Year(2003), 8317.0D, "Recycled");
    timeTableXYDataset.add((TimePeriod)new Year(2004), 9493.0D, "Recycled");
    timeTableXYDataset.add((TimePeriod)new Year(2005), 11228.0D, "Recycled");
    timeTableXYDataset.add((TimePeriod)new Year(2006), 14941.0D, "Recycled");
    return (TableXYDataset)timeTableXYDataset;
  }
  
  private static JFreeChart createChart(TableXYDataset paramTableXYDataset) {
    DateAxis dateAxis = new DateAxis("Year");
    dateAxis.setTickMarkPosition(DateTickMarkPosition.MIDDLE);
    dateAxis.setLowerMargin(0.01D);
    dateAxis.setUpperMargin(0.01D);
    NumberAxis numberAxis = new NumberAxis("Tonnes");
    numberAxis.setNumberFormatOverride(new DecimalFormat("0.0%"));
    StackedXYBarRenderer stackedXYBarRenderer = new StackedXYBarRenderer(0.3D);
    stackedXYBarRenderer.setRenderAsPercentages(true);
    stackedXYBarRenderer.setDrawBarOutline(false);
    stackedXYBarRenderer.setBaseToolTipGenerator((XYToolTipGenerator)new StandardXYToolTipGenerator("{0} : {1} = {2} tonnes", new SimpleDateFormat("yyyy"), new DecimalFormat("#,##0")));
    XYPlot xYPlot = new XYPlot((XYDataset)paramTableXYDataset, (ValueAxis)dateAxis, (ValueAxis)numberAxis, (XYItemRenderer)stackedXYBarRenderer);
    xYPlot.setBackgroundPaint(Color.lightGray);
    xYPlot.setDomainGridlinePaint(Color.white);
    xYPlot.setRangeGridlinePaint(Color.white);
    JFreeChart jFreeChart = new JFreeChart("Waste Management", (Plot)xYPlot);
    jFreeChart.setBackgroundPaint(Color.white);
    jFreeChart.addSubtitle((Title)new TextTitle("St Albans City and District Council"));
    ChartUtilities.applyCurrentTheme(jFreeChart);
    GradientPaint gradientPaint1 = new GradientPaint(0.0F, 0.0F, new Color(64, 0, 0), 0.0F, 0.0F, Color.red);
    GradientPaint gradientPaint2 = new GradientPaint(0.0F, 0.0F, new Color(0, 64, 0), 0.0F, 0.0F, Color.green);
    stackedXYBarRenderer.setSeriesPaint(0, gradientPaint1);
    stackedXYBarRenderer.setSeriesPaint(1, gradientPaint2);
    stackedXYBarRenderer.setGradientPaintTransformer((GradientPaintTransformer)new StandardGradientPaintTransformer(GradientPaintTransformType.HORIZONTAL));
    return jFreeChart;
  }
  
  public static JPanel createDemoPanel() {
    JFreeChart jFreeChart = createChart(createDataset());
    return (JPanel)new ChartPanel(jFreeChart);
  }
  
  public static void main(String[] paramArrayOfString) {
    StackedXYBarChartDemo3 stackedXYBarChartDemo3 = new StackedXYBarChartDemo3("JFreeChart: StackedXYBarChartDemo3");
    stackedXYBarChartDemo3.pack();
    RefineryUtilities.centerFrameOnScreen((Window)stackedXYBarChartDemo3);
    stackedXYBarChartDemo3.setVisible(true);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/StackedXYBarChartDemo3.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */