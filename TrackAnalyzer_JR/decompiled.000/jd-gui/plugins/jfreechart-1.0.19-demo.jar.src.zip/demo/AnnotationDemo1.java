package demo;

import java.awt.Dimension;
import java.awt.Font;
import java.awt.Window;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import javax.swing.JPanel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.annotations.XYAnnotation;
import org.jfree.chart.annotations.XYTextAnnotation;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.title.TextTitle;
import org.jfree.chart.title.Title;
import org.jfree.data.xy.XYDataset;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;
import org.jfree.ui.TextAnchor;

public class AnnotationDemo1 extends ApplicationFrame {
  public AnnotationDemo1(String paramString) {
    super(paramString);
    JPanel jPanel = createDemoPanel();
    jPanel.setPreferredSize(new Dimension(360, 500));
    setContentPane(jPanel);
  }
  
  private static XYSeriesCollection createDataset() {
    XYSeriesCollection xYSeriesCollection = new XYSeriesCollection();
    try {
      BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(XYSeriesCollection.class.getClassLoader().getResourceAsStream("demo/wtageinf.txt")));
      String str = bufferedReader.readLine();
      str = bufferedReader.readLine();
      str = bufferedReader.readLine();
      str = bufferedReader.readLine();
      XYSeries xYSeries1 = new XYSeries("P3", true, false);
      XYSeries xYSeries2 = new XYSeries("P5", true, false);
      XYSeries xYSeries3 = new XYSeries("P10", true, false);
      XYSeries xYSeries4 = new XYSeries("P25", true, false);
      XYSeries xYSeries5 = new XYSeries("P50", true, false);
      XYSeries xYSeries6 = new XYSeries("P75", true, false);
      XYSeries xYSeries7 = new XYSeries("P90", true, false);
      XYSeries xYSeries8 = new XYSeries("P95", true, false);
      XYSeries xYSeries9 = new XYSeries("P97", true, false);
      for (str = bufferedReader.readLine(); str != null; str = bufferedReader.readLine()) {
        int i = Integer.parseInt(str.substring(1, 8).trim());
        float f1 = Float.parseFloat(str.substring(9, 17).trim());
        float f2 = Float.parseFloat(str.substring(69, 86).trim());
        float f3 = Float.parseFloat(str.substring(87, 103).trim());
        float f4 = Float.parseFloat(str.substring(104, 122).trim());
        float f5 = Float.parseFloat(str.substring(123, 140).trim());
        float f6 = Float.parseFloat(str.substring(141, 158).trim());
        float f7 = Float.parseFloat(str.substring(159, 176).trim());
        float f8 = Float.parseFloat(str.substring(177, 193).trim());
        float f9 = Float.parseFloat(str.substring(194, 212).trim());
        float f10 = Float.parseFloat(str.substring(212, str.length()).trim());
        if (i == 1) {
          xYSeries1.add(f1, f2);
          xYSeries2.add(f1, f3);
          xYSeries3.add(f1, f4);
          xYSeries4.add(f1, f5);
          xYSeries5.add(f1, f6);
          xYSeries6.add(f1, f7);
          xYSeries7.add(f1, f8);
          xYSeries8.add(f1, f9);
          xYSeries9.add(f1, f10);
        } 
      } 
      xYSeriesCollection.addSeries(xYSeries1);
      xYSeriesCollection.addSeries(xYSeries2);
      xYSeriesCollection.addSeries(xYSeries3);
      xYSeriesCollection.addSeries(xYSeries4);
      xYSeriesCollection.addSeries(xYSeries5);
      xYSeriesCollection.addSeries(xYSeries6);
      xYSeriesCollection.addSeries(xYSeries7);
      xYSeriesCollection.addSeries(xYSeries8);
      xYSeriesCollection.addSeries(xYSeries9);
    } catch (FileNotFoundException fileNotFoundException) {
      System.err.println(fileNotFoundException);
    } catch (IOException iOException) {
      System.err.println(iOException);
    } 
    return xYSeriesCollection;
  }
  
  private static JFreeChart createChart(XYDataset paramXYDataset) {
    JFreeChart jFreeChart = ChartFactory.createXYLineChart(null, "Age in Months", "Weight (kg)", paramXYDataset);
    TextTitle textTitle1 = new TextTitle("Growth Charts: United States", new Font("SansSerif", 1, 14));
    TextTitle textTitle2 = new TextTitle("Weight-for-age percentiles: boys, birth to 36 months", new Font("SansSerif", 0, 11));
    jFreeChart.addSubtitle((Title)textTitle1);
    jFreeChart.addSubtitle((Title)textTitle2);
    XYPlot xYPlot = (XYPlot)jFreeChart.getPlot();
    xYPlot.setDomainPannable(true);
    xYPlot.setRangePannable(true);
    NumberAxis numberAxis1 = (NumberAxis)xYPlot.getDomainAxis();
    numberAxis1.setUpperMargin(0.12D);
    numberAxis1.setStandardTickUnits(NumberAxis.createIntegerTickUnits());
    NumberAxis numberAxis2 = (NumberAxis)xYPlot.getRangeAxis();
    numberAxis2.setAutoRangeIncludesZero(false);
    Font font = new Font("SansSerif", 0, 9);
    XYTextAnnotation xYTextAnnotation = new XYTextAnnotation("3rd", 36.5D, 11.76D);
    xYTextAnnotation.setFont(font);
    xYTextAnnotation.setTextAnchor(TextAnchor.HALF_ASCENT_LEFT);
    xYPlot.addAnnotation((XYAnnotation)xYTextAnnotation);
    xYTextAnnotation = new XYTextAnnotation("5th", 36.5D, 12.04D);
    xYTextAnnotation.setFont(font);
    xYTextAnnotation.setTextAnchor(TextAnchor.HALF_ASCENT_LEFT);
    xYPlot.addAnnotation((XYAnnotation)xYTextAnnotation);
    xYTextAnnotation = new XYTextAnnotation("10th", 36.5D, 12.493D);
    xYTextAnnotation.setFont(font);
    xYTextAnnotation.setTextAnchor(TextAnchor.HALF_ASCENT_LEFT);
    xYPlot.addAnnotation((XYAnnotation)xYTextAnnotation);
    xYTextAnnotation = new XYTextAnnotation("25th", 36.5D, 13.313D);
    xYTextAnnotation.setFont(font);
    xYTextAnnotation.setTextAnchor(TextAnchor.HALF_ASCENT_LEFT);
    xYPlot.addAnnotation((XYAnnotation)xYTextAnnotation);
    xYTextAnnotation = new XYTextAnnotation("50th", 36.5D, 14.33D);
    xYTextAnnotation.setFont(font);
    xYTextAnnotation.setTextAnchor(TextAnchor.HALF_ASCENT_LEFT);
    xYPlot.addAnnotation((XYAnnotation)xYTextAnnotation);
    xYTextAnnotation = new XYTextAnnotation("75th", 36.5D, 15.478D);
    xYTextAnnotation.setFont(font);
    xYTextAnnotation.setTextAnchor(TextAnchor.HALF_ASCENT_LEFT);
    xYPlot.addAnnotation((XYAnnotation)xYTextAnnotation);
    xYTextAnnotation = new XYTextAnnotation("90th", 36.5D, 16.642D);
    xYTextAnnotation.setFont(font);
    xYTextAnnotation.setTextAnchor(TextAnchor.HALF_ASCENT_LEFT);
    xYPlot.addAnnotation((XYAnnotation)xYTextAnnotation);
    xYTextAnnotation = new XYTextAnnotation("95th", 36.5D, 17.408D);
    xYTextAnnotation.setFont(font);
    xYTextAnnotation.setTextAnchor(TextAnchor.HALF_ASCENT_LEFT);
    xYPlot.addAnnotation((XYAnnotation)xYTextAnnotation);
    xYTextAnnotation = new XYTextAnnotation("97th", 36.5D, 17.936D);
    xYTextAnnotation.setFont(font);
    xYTextAnnotation.setTextAnchor(TextAnchor.HALF_ASCENT_LEFT);
    xYPlot.addAnnotation((XYAnnotation)xYTextAnnotation);
    ChartUtilities.applyCurrentTheme(jFreeChart);
    return jFreeChart;
  }
  
  public static JPanel createDemoPanel() {
    JFreeChart jFreeChart = createChart((XYDataset)createDataset());
    ChartPanel chartPanel = new ChartPanel(jFreeChart);
    chartPanel.setMouseWheelEnabled(true);
    return (JPanel)chartPanel;
  }
  
  public static void main(String[] paramArrayOfString) {
    AnnotationDemo1 annotationDemo1 = new AnnotationDemo1("JFreeChart: AnnotationDemo1.java");
    annotationDemo1.pack();
    RefineryUtilities.centerFrameOnScreen((Window)annotationDemo1);
    annotationDemo1.setVisible(true);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/AnnotationDemo1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */