package demo;

import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Window;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.text.SimpleDateFormat;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.DateAxis;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYItemRenderer;
import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
import org.jfree.data.time.Month;
import org.jfree.data.time.RegularTimePeriod;
import org.jfree.data.time.TimeSeries;
import org.jfree.data.time.TimeSeriesCollection;
import org.jfree.data.xy.XYDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RectangleInsets;
import org.jfree.ui.RefineryUtilities;

public class ChartPanelSerializationTest extends ApplicationFrame {
  public ChartPanelSerializationTest(String paramString) {
    super(paramString);
    XYDataset xYDataset = createDataset();
    JFreeChart jFreeChart = createChart(xYDataset);
    ChartPanel chartPanel1 = new ChartPanel(jFreeChart, true);
    chartPanel1.setMouseWheelEnabled(true);
    chartPanel1.setPreferredSize(new Dimension(500, 270));
    chartPanel1.setMouseZoomable(true, true);
    ChartPanel chartPanel2 = null;
    try {
      ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
      ObjectOutputStream objectOutputStream = new ObjectOutputStream(byteArrayOutputStream);
      objectOutputStream.writeObject(chartPanel1);
      objectOutputStream.close();
      ObjectInputStream objectInputStream = new ObjectInputStream(new ByteArrayInputStream(byteArrayOutputStream.toByteArray()));
      chartPanel2 = (ChartPanel)objectInputStream.readObject();
      objectInputStream.close();
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
    setContentPane((Container)chartPanel2);
  }
  
  private JFreeChart createChart(XYDataset paramXYDataset) {
    JFreeChart jFreeChart = ChartFactory.createTimeSeriesChart("Legal & General Unit Trust Prices", "Date", "Price Per Unit", paramXYDataset, true, true, false);
    jFreeChart.setBackgroundPaint(Color.white);
    XYPlot xYPlot = (XYPlot)jFreeChart.getPlot();
    xYPlot.setBackgroundPaint(Color.lightGray);
    xYPlot.setDomainGridlinePaint(Color.white);
    xYPlot.setRangeGridlinePaint(Color.white);
    xYPlot.setAxisOffset(new RectangleInsets(5.0D, 5.0D, 5.0D, 5.0D));
    xYPlot.setDomainCrosshairVisible(true);
    xYPlot.setRangeCrosshairVisible(true);
    xYPlot.setDomainPannable(true);
    xYPlot.setRangePannable(false);
    XYItemRenderer xYItemRenderer = xYPlot.getRenderer();
    if (xYItemRenderer instanceof XYLineAndShapeRenderer) {
      XYLineAndShapeRenderer xYLineAndShapeRenderer = (XYLineAndShapeRenderer)xYItemRenderer;
      xYLineAndShapeRenderer.setBaseShapesVisible(true);
      xYLineAndShapeRenderer.setBaseShapesFilled(true);
      xYLineAndShapeRenderer.setBaseItemLabelsVisible(true);
    } 
    DateAxis dateAxis = (DateAxis)xYPlot.getDomainAxis();
    dateAxis.setDateFormatOverride(new SimpleDateFormat("MMM-yyyy"));
    return jFreeChart;
  }
  
  private XYDataset createDataset() {
    TimeSeries timeSeries1 = new TimeSeries("L&G European Index Trust");
    timeSeries1.add((RegularTimePeriod)new Month(2, 2001), 181.8D);
    timeSeries1.add((RegularTimePeriod)new Month(3, 2001), 167.3D);
    timeSeries1.add((RegularTimePeriod)new Month(4, 2001), 153.8D);
    timeSeries1.add((RegularTimePeriod)new Month(5, 2001), 167.6D);
    timeSeries1.add((RegularTimePeriod)new Month(6, 2001), 158.8D);
    timeSeries1.add((RegularTimePeriod)new Month(7, 2001), 148.3D);
    timeSeries1.add((RegularTimePeriod)new Month(8, 2001), 153.9D);
    timeSeries1.add((RegularTimePeriod)new Month(9, 2001), 142.7D);
    timeSeries1.add((RegularTimePeriod)new Month(10, 2001), 123.2D);
    timeSeries1.add((RegularTimePeriod)new Month(11, 2001), 131.8D);
    timeSeries1.add((RegularTimePeriod)new Month(12, 2001), 139.6D);
    timeSeries1.add((RegularTimePeriod)new Month(1, 2002), 142.9D);
    timeSeries1.add((RegularTimePeriod)new Month(2, 2002), 138.7D);
    timeSeries1.add((RegularTimePeriod)new Month(3, 2002), 137.3D);
    timeSeries1.add((RegularTimePeriod)new Month(4, 2002), 143.9D);
    timeSeries1.add((RegularTimePeriod)new Month(5, 2002), 139.8D);
    timeSeries1.add((RegularTimePeriod)new Month(6, 2002), 137.0D);
    timeSeries1.add((RegularTimePeriod)new Month(7, 2002), 132.8D);
    TimeSeries timeSeries2 = new TimeSeries("L&G UK Index Trust");
    timeSeries2.add((RegularTimePeriod)new Month(2, 2001), 129.6D);
    timeSeries2.add((RegularTimePeriod)new Month(3, 2001), 123.2D);
    timeSeries2.add((RegularTimePeriod)new Month(4, 2001), 117.2D);
    timeSeries2.add((RegularTimePeriod)new Month(5, 2001), 124.1D);
    timeSeries2.add((RegularTimePeriod)new Month(6, 2001), 122.6D);
    timeSeries2.add((RegularTimePeriod)new Month(7, 2001), 119.2D);
    timeSeries2.add((RegularTimePeriod)new Month(8, 2001), 116.5D);
    timeSeries2.add((RegularTimePeriod)new Month(9, 2001), 112.7D);
    timeSeries2.add((RegularTimePeriod)new Month(10, 2001), 101.5D);
    timeSeries2.add((RegularTimePeriod)new Month(11, 2001), 106.1D);
    timeSeries2.add((RegularTimePeriod)new Month(12, 2001), 110.3D);
    timeSeries2.add((RegularTimePeriod)new Month(1, 2002), 111.7D);
    timeSeries2.add((RegularTimePeriod)new Month(2, 2002), 111.0D);
    timeSeries2.add((RegularTimePeriod)new Month(3, 2002), 109.6D);
    timeSeries2.add((RegularTimePeriod)new Month(4, 2002), 113.2D);
    timeSeries2.add((RegularTimePeriod)new Month(5, 2002), 111.6D);
    timeSeries2.add((RegularTimePeriod)new Month(6, 2002), 108.8D);
    timeSeries2.add((RegularTimePeriod)new Month(7, 2002), 101.6D);
    TimeSeriesCollection timeSeriesCollection = new TimeSeriesCollection();
    timeSeriesCollection.addSeries(timeSeries1);
    timeSeriesCollection.addSeries(timeSeries2);
    return (XYDataset)timeSeriesCollection;
  }
  
  public static void main(String[] paramArrayOfString) {
    ChartPanelSerializationTest chartPanelSerializationTest = new ChartPanelSerializationTest("Serialization Test");
    chartPanelSerializationTest.pack();
    RefineryUtilities.centerFrameOnScreen((Window)chartPanelSerializationTest);
    chartPanelSerializationTest.setVisible(true);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/ChartPanelSerializationTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */