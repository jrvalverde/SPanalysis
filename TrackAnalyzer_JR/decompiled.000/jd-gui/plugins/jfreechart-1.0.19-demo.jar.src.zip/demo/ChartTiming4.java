package demo;

import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import javax.swing.Timer;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.FastScatterPlot;
import org.jfree.chart.plot.Plot;

public class ChartTiming4 implements ActionListener {
  private boolean finished;
  
  private float[][] data = new float[2][1440];
  
  public void run() {
    this.finished = false;
    populateData();
    FastScatterPlot fastScatterPlot = new FastScatterPlot(this.data, (ValueAxis)new NumberAxis("X"), (ValueAxis)new NumberAxis("Y"));
    JFreeChart jFreeChart = new JFreeChart("Fast Scatter Plot Timing", JFreeChart.DEFAULT_TITLE_FONT, (Plot)fastScatterPlot, true);
    BufferedImage bufferedImage = new BufferedImage(400, 300, 1);
    Graphics2D graphics2D = bufferedImage.createGraphics();
    Rectangle2D.Double double_ = new Rectangle2D.Double(0.0D, 0.0D, 400.0D, 300.0D);
    Timer timer = new Timer(10000, this);
    timer.setRepeats(false);
    byte b = 0;
    timer.start();
    while (!this.finished) {
      jFreeChart.draw(graphics2D, double_, null, null);
      System.out.println("Charts drawn..." + b);
      if (!this.finished)
        b++; 
    } 
    System.out.println("DONE");
  }
  
  public void actionPerformed(ActionEvent paramActionEvent) {
    this.finished = true;
  }
  
  private void populateData() {
    for (byte b = 0; b < (this.data[0]).length; b++) {
      float f = b;
      this.data[0][b] = f;
      this.data[1][b] = 100.0F + 2.0F * f + (float)Math.random() * 1440.0F;
    } 
  }
  
  public static void main(String[] paramArrayOfString) {
    ChartTiming4 chartTiming4 = new ChartTiming4();
    chartTiming4.run();
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/ChartTiming4.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */