package demo;

import java.awt.Dimension;
import java.awt.Font;
import java.awt.Window;
import java.text.NumberFormat;
import javax.swing.JPanel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.CategoryLabelPositions;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.DatasetRenderingOrder;
import org.jfree.chart.renderer.category.CategoryItemRenderer;
import org.jfree.chart.renderer.category.LineAndShapeRenderer;
import org.jfree.chart.title.TextTitle;
import org.jfree.chart.title.Title;
import org.jfree.data.DataUtilities;
import org.jfree.data.DefaultKeyedValues;
import org.jfree.data.KeyedValues;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.general.DatasetUtilities;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.HorizontalAlignment;
import org.jfree.ui.RectangleEdge;
import org.jfree.ui.RefineryUtilities;
import org.jfree.util.SortOrder;

public class ParetoChartDemo1 extends ApplicationFrame {
  public ParetoChartDemo1(String paramString) {
    super(paramString);
    JPanel jPanel = createDemoPanel();
    jPanel.setPreferredSize(new Dimension(550, 270));
    setContentPane(jPanel);
  }
  
  public static JFreeChart createChart(CategoryDataset[] paramArrayOfCategoryDataset) {
    JFreeChart jFreeChart = ChartFactory.createBarChart("TIOBE Index of Programming Languages", null, "Index Value", paramArrayOfCategoryDataset[0]);
    jFreeChart.addSubtitle((Title)new TextTitle("As at August 2013"));
    jFreeChart.removeLegend();
    CategoryPlot categoryPlot = (CategoryPlot)jFreeChart.getPlot();
    CategoryAxis categoryAxis = categoryPlot.getDomainAxis();
    categoryAxis.setLowerMargin(0.02D);
    categoryAxis.setUpperMargin(0.02D);
    categoryAxis.setCategoryLabelPositions(CategoryLabelPositions.UP_90);
    NumberAxis numberAxis1 = (NumberAxis)categoryPlot.getRangeAxis();
    numberAxis1.setStandardTickUnits(NumberAxis.createIntegerTickUnits());
    LineAndShapeRenderer lineAndShapeRenderer = new LineAndShapeRenderer();
    NumberAxis numberAxis2 = new NumberAxis("Percent");
    numberAxis2.setNumberFormatOverride(NumberFormat.getPercentInstance());
    categoryPlot.setRangeAxis(1, (ValueAxis)numberAxis2);
    categoryPlot.setDataset(1, paramArrayOfCategoryDataset[1]);
    categoryPlot.setRenderer(1, (CategoryItemRenderer)lineAndShapeRenderer);
    categoryPlot.mapDatasetToRangeAxis(1, 1);
    categoryPlot.setDatasetRenderingOrder(DatasetRenderingOrder.FORWARD);
    ChartUtilities.applyCurrentTheme(jFreeChart);
    TextTitle textTitle = new TextTitle("http://www.tiobe.com/index.php/content/paperinfo/tpci/index.html", new Font("Monospaced", 0, 10));
    textTitle.setPosition(RectangleEdge.BOTTOM);
    textTitle.setHorizontalAlignment(HorizontalAlignment.RIGHT);
    jFreeChart.addSubtitle((Title)textTitle);
    return jFreeChart;
  }
  
  public static CategoryDataset[] createDatasets() {
    DefaultKeyedValues defaultKeyedValues = new DefaultKeyedValues();
    defaultKeyedValues.addValue("C", 15.974D);
    defaultKeyedValues.addValue("C++", 9.371D);
    defaultKeyedValues.addValue("C#", 6.117D);
    defaultKeyedValues.addValue("Java", 15.978D);
    defaultKeyedValues.addValue("Javascript", 2.093D);
    defaultKeyedValues.addValue("Obj-C", 8.082D);
    defaultKeyedValues.addValue("PHP", 6.694D);
    defaultKeyedValues.addValue("Python", 3.603D);
    defaultKeyedValues.addValue("Ruby", 2.067D);
    defaultKeyedValues.addValue("VB", 3.873D);
    defaultKeyedValues.sortByValues(SortOrder.DESCENDING);
    KeyedValues keyedValues = DataUtilities.getCumulativePercentages((KeyedValues)defaultKeyedValues);
    CategoryDataset categoryDataset1 = DatasetUtilities.createCategoryDataset("Languages", (KeyedValues)defaultKeyedValues);
    CategoryDataset categoryDataset2 = DatasetUtilities.createCategoryDataset("Cumulative", keyedValues);
    return new CategoryDataset[] { categoryDataset1, categoryDataset2 };
  }
  
  public static JPanel createDemoPanel() {
    CategoryDataset[] arrayOfCategoryDataset = createDatasets();
    JFreeChart jFreeChart = createChart(arrayOfCategoryDataset);
    return (JPanel)new ChartPanel(jFreeChart);
  }
  
  public static void main(String[] paramArrayOfString) {
    ParetoChartDemo1 paretoChartDemo1 = new ParetoChartDemo1("JFreeChart: ParetoChartDemo1.java");
    paretoChartDemo1.pack();
    RefineryUtilities.centerFrameOnScreen((Window)paretoChartDemo1);
    paretoChartDemo1.setVisible(true);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/ParetoChartDemo1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */