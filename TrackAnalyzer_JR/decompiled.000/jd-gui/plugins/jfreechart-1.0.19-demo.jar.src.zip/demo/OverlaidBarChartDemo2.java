package demo;

import java.awt.BasicStroke;
import java.awt.Dimension;
import java.awt.Window;
import javax.swing.JPanel;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.labels.CategoryToolTipGenerator;
import org.jfree.chart.labels.StandardCategoryToolTipGenerator;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.DatasetRenderingOrder;
import org.jfree.chart.plot.Plot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.renderer.category.BarRenderer;
import org.jfree.chart.renderer.category.CategoryItemRenderer;
import org.jfree.chart.renderer.category.LevelRenderer;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

public class OverlaidBarChartDemo2 extends ApplicationFrame {
  public OverlaidBarChartDemo2(String paramString) {
    super(paramString);
    JPanel jPanel = createDemoPanel();
    jPanel.setPreferredSize(new Dimension(500, 270));
    setContentPane(jPanel);
  }
  
  private static JFreeChart createChart() {
    DefaultCategoryDataset defaultCategoryDataset1 = new DefaultCategoryDataset();
    defaultCategoryDataset1.addValue(1.0D, "S1", "Category 1");
    defaultCategoryDataset1.addValue(4.0D, "S1", "Category 2");
    defaultCategoryDataset1.addValue(3.0D, "S1", "Category 3");
    defaultCategoryDataset1.addValue(5.0D, "S1", "Category 4");
    defaultCategoryDataset1.addValue(5.0D, "S1", "Category 5");
    defaultCategoryDataset1.addValue(5.0D, "S2", "Category 1");
    defaultCategoryDataset1.addValue(7.0D, "S2", "Category 2");
    defaultCategoryDataset1.addValue(6.0D, "S2", "Category 3");
    defaultCategoryDataset1.addValue(8.0D, "S2", "Category 4");
    defaultCategoryDataset1.addValue(4.0D, "S2", "Category 5");
    BarRenderer barRenderer = new BarRenderer();
    barRenderer.setBaseToolTipGenerator((CategoryToolTipGenerator)new StandardCategoryToolTipGenerator());
    CategoryPlot categoryPlot = new CategoryPlot();
    categoryPlot.setDataset((CategoryDataset)defaultCategoryDataset1);
    categoryPlot.setRenderer((CategoryItemRenderer)barRenderer);
    categoryPlot.setDomainAxis(new CategoryAxis("Category"));
    categoryPlot.setRangeAxis((ValueAxis)new NumberAxis("Value"));
    categoryPlot.setOrientation(PlotOrientation.VERTICAL);
    categoryPlot.setRangeGridlinesVisible(true);
    categoryPlot.setDomainGridlinesVisible(true);
    categoryPlot.setRangeZeroBaselineVisible(true);
    categoryPlot.setRangePannable(true);
    DefaultCategoryDataset defaultCategoryDataset2 = new DefaultCategoryDataset();
    defaultCategoryDataset2.addValue(6.0D, "Prior 1", "Category 1");
    defaultCategoryDataset2.addValue(7.0D, "Prior 1", "Category 2");
    defaultCategoryDataset2.addValue(2.0D, "Prior 1", "Category 3");
    defaultCategoryDataset2.addValue(6.0D, "Prior 1", "Category 4");
    defaultCategoryDataset2.addValue(6.0D, "Prior 1", "Category 5");
    defaultCategoryDataset2.addValue(4.0D, "Prior 2", "Category 1");
    defaultCategoryDataset2.addValue(2.0D, "Prior 2", "Category 2");
    defaultCategoryDataset2.addValue(1.0D, "Prior 2", "Category 3");
    defaultCategoryDataset2.addValue(3.0D, "Prior 2", "Category 4");
    defaultCategoryDataset2.addValue(2.0D, "Prior 2", "Category 5");
    LevelRenderer levelRenderer = new LevelRenderer();
    categoryPlot.setDataset(1, (CategoryDataset)defaultCategoryDataset2);
    categoryPlot.setRenderer(1, (CategoryItemRenderer)levelRenderer);
    categoryPlot.setDatasetRenderingOrder(DatasetRenderingOrder.FORWARD);
    JFreeChart jFreeChart = new JFreeChart((Plot)categoryPlot);
    jFreeChart.setTitle("OverlaidBarChartDemo2");
    ChartUtilities.applyCurrentTheme(jFreeChart);
    levelRenderer.setSeriesStroke(0, new BasicStroke(2.0F));
    levelRenderer.setSeriesStroke(1, new BasicStroke(2.0F));
    return jFreeChart;
  }
  
  public static JPanel createDemoPanel() {
    JFreeChart jFreeChart = createChart();
    ChartPanel chartPanel = new ChartPanel(jFreeChart);
    chartPanel.setMouseWheelEnabled(true);
    return (JPanel)chartPanel;
  }
  
  public static void main(String[] paramArrayOfString) {
    OverlaidBarChartDemo2 overlaidBarChartDemo2 = new OverlaidBarChartDemo2("JFreeChart: OverlaidBarChartDemo2.java");
    overlaidBarChartDemo2.pack();
    RefineryUtilities.centerFrameOnScreen((Window)overlaidBarChartDemo2);
    overlaidBarChartDemo2.setVisible(true);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/OverlaidBarChartDemo2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */