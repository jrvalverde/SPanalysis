package demo;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GradientPaint;
import java.awt.Point;
import java.awt.Window;
import java.text.DecimalFormat;
import javax.swing.JPanel;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.CenterTextMode;
import org.jfree.chart.plot.Plot;
import org.jfree.chart.plot.RingPlot;
import org.jfree.chart.title.TextTitle;
import org.jfree.data.general.DefaultPieDataset;
import org.jfree.data.general.PieDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.HorizontalAlignment;
import org.jfree.ui.RectangleInsets;
import org.jfree.ui.RefineryUtilities;

public class RingChartDemo2 extends ApplicationFrame {
  private static final long serialVersionUID = 1L;
  
  public RingChartDemo2(String paramString) {
    super(paramString);
    setContentPane(createDemoPanel());
  }
  
  private static PieDataset createDataset() {
    DefaultPieDataset defaultPieDataset = new DefaultPieDataset();
    defaultPieDataset.setValue("A", new Double(0.653D));
    defaultPieDataset.setValue("B", new Double(0.347D));
    return (PieDataset)defaultPieDataset;
  }
  
  private static JFreeChart createChart(PieDataset paramPieDataset) {
    RingPlot ringPlot = new RingPlot(paramPieDataset);
    ringPlot.setCenterTextMode(CenterTextMode.VALUE);
    ringPlot.setCenterTextFont(new Font("SansSerif", 1, 24));
    ringPlot.setCenterTextColor(Color.LIGHT_GRAY);
    ringPlot.setCenterTextFormatter(new DecimalFormat("0.0%"));
    JFreeChart jFreeChart = new JFreeChart("Machine Capacity", JFreeChart.DEFAULT_TITLE_FONT, (Plot)ringPlot, false);
    jFreeChart.setBackgroundPaint(new GradientPaint(new Point(0, 0), new Color(20, 20, 20), new Point(400, 200), Color.DARK_GRAY));
    TextTitle textTitle = jFreeChart.getTitle();
    textTitle.setHorizontalAlignment(HorizontalAlignment.LEFT);
    textTitle.setPaint(new Color(240, 240, 240));
    textTitle.setFont(new Font("Arial", 1, 26));
    ringPlot.setBackgroundPaint(null);
    ringPlot.setOutlineVisible(false);
    ringPlot.setLabelGenerator(null);
    ringPlot.setSectionPaint("A", Color.ORANGE);
    ringPlot.setSectionPaint("B", new Color(100, 100, 100));
    ringPlot.setSectionDepth(0.05D);
    ringPlot.setSectionOutlinesVisible(false);
    ringPlot.setShadowPaint(null);
    return jFreeChart;
  }
  
  public static JPanel createDemoPanel() {
    JFreeChart jFreeChart = createChart(createDataset());
    jFreeChart.setPadding(new RectangleInsets(4.0D, 8.0D, 2.0D, 2.0D));
    ChartPanel chartPanel = new ChartPanel(jFreeChart);
    chartPanel.setMouseWheelEnabled(true);
    chartPanel.setPreferredSize(new Dimension(600, 300));
    return (JPanel)chartPanel;
  }
  
  public static void main(String[] paramArrayOfString) {
    RingChartDemo2 ringChartDemo2 = new RingChartDemo2("JFreeChart: Ring Chart Demo 2");
    ringChartDemo2.pack();
    RefineryUtilities.centerFrameOnScreen((Window)ringChartDemo2);
    ringChartDemo2.setVisible(true);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/RingChartDemo2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */