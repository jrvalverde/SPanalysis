package demo;

import java.awt.Color;
import java.awt.Container;
import java.awt.Window;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.jdbc.JDBCCategoryDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

public class JDBCCategoryChartDemo extends ApplicationFrame {
  public JDBCCategoryChartDemo(String paramString) {
    super(paramString);
    CategoryDataset categoryDataset = readData();
    JFreeChart jFreeChart = ChartFactory.createBarChart3D("JDBC Category Chart Demo", "Category", "Value", categoryDataset, PlotOrientation.VERTICAL, true, true, false);
    jFreeChart.setBackgroundPaint(Color.yellow);
    ChartPanel chartPanel = new ChartPanel(jFreeChart);
    setContentPane((Container)chartPanel);
  }
  
  private CategoryDataset readData() {
    JDBCCategoryDataset jDBCCategoryDataset = null;
    String str = "jdbc:postgresql://localhost/jfreechartdb";
    try {
      Class.forName("org.postgresql.Driver");
    } catch (ClassNotFoundException classNotFoundException) {
      System.err.print("ClassNotFoundException: ");
      System.err.println(classNotFoundException.getMessage());
    } 
    try {
      Connection connection = DriverManager.getConnection(str, "jfreechart", "password");
      jDBCCategoryDataset = new JDBCCategoryDataset(connection);
      String str1 = "SELECT * FROM CATEGORYDATA1;";
      System.out.println("Once...");
      jDBCCategoryDataset.executeQuery(str1);
      System.out.println("Again...");
      jDBCCategoryDataset.executeQuery(str1);
      System.out.println("Done.");
      connection.close();
    } catch (SQLException sQLException) {
      System.err.print("SQLException: ");
      System.err.println(sQLException.getMessage());
    } catch (Exception exception) {
      System.err.print("Exception: ");
      System.err.println(exception.getMessage());
    } 
    return (CategoryDataset)jDBCCategoryDataset;
  }
  
  public static void main(String[] paramArrayOfString) {
    JDBCCategoryChartDemo jDBCCategoryChartDemo = new JDBCCategoryChartDemo("JDBC Category Chart Demo");
    jDBCCategoryChartDemo.pack();
    RefineryUtilities.centerFrameOnScreen((Window)jDBCCategoryChartDemo);
    jDBCCategoryChartDemo.setVisible(true);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/JDBCCategoryChartDemo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */