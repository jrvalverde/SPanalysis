package demo;

import java.awt.Dimension;
import java.awt.Window;
import javax.swing.JPanel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.CategoryLabelPositions;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.renderer.category.BarRenderer3D;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

public class BarChart3DDemo1 extends ApplicationFrame {
  public BarChart3DDemo1(String paramString) {
    super(paramString);
    JPanel jPanel = createDemoPanel();
    setContentPane(jPanel);
  }
  
  private static CategoryDataset createDataset() {
    DefaultCategoryDataset defaultCategoryDataset = new DefaultCategoryDataset();
    defaultCategoryDataset.addValue(10.0D, "Series 1", "Category 1");
    defaultCategoryDataset.addValue(4.0D, "Series 1", "Category 2");
    defaultCategoryDataset.addValue(15.0D, "Series 1", "Category 3");
    defaultCategoryDataset.addValue(14.0D, "Series 1", "Category 4");
    defaultCategoryDataset.addValue(-5.0D, "Series 2", "Category 1");
    defaultCategoryDataset.addValue(-7.0D, "Series 2", "Category 2");
    defaultCategoryDataset.addValue(14.0D, "Series 2", "Category 3");
    defaultCategoryDataset.addValue(-3.0D, "Series 2", "Category 4");
    defaultCategoryDataset.addValue(6.0D, "Series 3", "Category 1");
    defaultCategoryDataset.addValue(17.0D, "Series 3", "Category 2");
    defaultCategoryDataset.addValue(-12.0D, "Series 3", "Category 3");
    defaultCategoryDataset.addValue(7.0D, "Series 3", "Category 4");
    defaultCategoryDataset.addValue(7.0D, "Series 4", "Category 1");
    defaultCategoryDataset.addValue(15.0D, "Series 4", "Category 2");
    defaultCategoryDataset.addValue(11.0D, "Series 4", "Category 3");
    defaultCategoryDataset.addValue(0.0D, "Series 4", "Category 4");
    defaultCategoryDataset.addValue(-8.0D, "Series 5", "Category 1");
    defaultCategoryDataset.addValue(-6.0D, "Series 5", "Category 2");
    defaultCategoryDataset.addValue(10.0D, "Series 5", "Category 3");
    defaultCategoryDataset.addValue(-9.0D, "Series 5", "Category 4");
    defaultCategoryDataset.addValue(9.0D, "Series 6", "Category 1");
    defaultCategoryDataset.addValue(8.0D, "Series 6", "Category 2");
    defaultCategoryDataset.addValue(0.0D, "Series 6", "Category 3");
    defaultCategoryDataset.addValue(6.0D, "Series 6", "Category 4");
    defaultCategoryDataset.addValue(-10.0D, "Series 7", "Category 1");
    defaultCategoryDataset.addValue(9.0D, "Series 7", "Category 2");
    defaultCategoryDataset.addValue(7.0D, "Series 7", "Category 3");
    defaultCategoryDataset.addValue(7.0D, "Series 7", "Category 4");
    defaultCategoryDataset.addValue(11.0D, "Series 8", "Category 1");
    defaultCategoryDataset.addValue(13.0D, "Series 8", "Category 2");
    defaultCategoryDataset.addValue(9.0D, "Series 8", "Category 3");
    defaultCategoryDataset.addValue(9.0D, "Series 8", "Category 4");
    defaultCategoryDataset.addValue(-3.0D, "Series 9", "Category 1");
    defaultCategoryDataset.addValue(7.0D, "Series 9", "Category 2");
    defaultCategoryDataset.addValue(11.0D, "Series 9", "Category 3");
    defaultCategoryDataset.addValue(-10.0D, "Series 9", "Category 4");
    return (CategoryDataset)defaultCategoryDataset;
  }
  
  private static JFreeChart createChart(CategoryDataset paramCategoryDataset) {
    JFreeChart jFreeChart = ChartFactory.createBarChart3D("3D Bar Chart Demo", "Category", "Value", paramCategoryDataset);
    CategoryPlot categoryPlot = (CategoryPlot)jFreeChart.getPlot();
    categoryPlot.setOutlineVisible(false);
    categoryPlot.setDomainGridlinesVisible(true);
    CategoryAxis categoryAxis = categoryPlot.getDomainAxis();
    categoryAxis.setCategoryLabelPositions(CategoryLabelPositions.createUpRotationLabelPositions(0.39269908169872414D));
    categoryAxis.setCategoryMargin(0.0D);
    BarRenderer3D barRenderer3D = (BarRenderer3D)categoryPlot.getRenderer();
    barRenderer3D.setDrawBarOutline(false);
    return jFreeChart;
  }
  
  public static JPanel createDemoPanel() {
    JFreeChart jFreeChart = createChart(createDataset());
    ChartPanel chartPanel = new ChartPanel(jFreeChart);
    chartPanel.setPreferredSize(new Dimension(600, 400));
    chartPanel.setMouseWheelEnabled(true);
    return (JPanel)chartPanel;
  }
  
  public static void main(String[] paramArrayOfString) {
    BarChart3DDemo1 barChart3DDemo1 = new BarChart3DDemo1("JFreeChart: BarChart3DDemo1.java");
    barChart3DDemo1.pack();
    RefineryUtilities.centerFrameOnScreen((Window)barChart3DDemo1);
    barChart3DDemo1.setVisible(true);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/BarChart3DDemo1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */