package demo;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.GradientPaint;
import java.awt.Paint;
import java.awt.Window;
import javax.swing.JPanel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.labels.CategoryToolTipGenerator;
import org.jfree.chart.labels.StandardCategoryToolTipGenerator;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.renderer.category.CategoryItemRenderer;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.GradientPaintTransformType;
import org.jfree.ui.GradientPaintTransformer;
import org.jfree.ui.RefineryUtilities;
import org.jfree.ui.StandardGradientPaintTransformer;

public class CylinderChartDemo2 extends ApplicationFrame {
  public CylinderChartDemo2(String paramString) {
    super(paramString);
    ChartPanel chartPanel = (ChartPanel)createDemoPanel();
    chartPanel.setPreferredSize(new Dimension(500, 270));
    setContentPane((Container)chartPanel);
  }
  
  private static CategoryDataset createDataset() {
    DefaultCategoryDataset defaultCategoryDataset = new DefaultCategoryDataset();
    defaultCategoryDataset.addValue(4.0D, "S1", "Monday");
    defaultCategoryDataset.addValue(5.0D, "S1", "Tuesday");
    defaultCategoryDataset.addValue(-7.0D, "S1", "Wednesday");
    defaultCategoryDataset.addValue(6.0D, "S1", "Thursday");
    defaultCategoryDataset.addValue(4.0D, "S1", "Friday");
    return (CategoryDataset)defaultCategoryDataset;
  }
  
  private static JFreeChart createChart(CategoryDataset paramCategoryDataset) {
    JFreeChart jFreeChart = ChartFactory.createBarChart3D("Cylinder Chart Demo 2", "Category", "Value", paramCategoryDataset, PlotOrientation.HORIZONTAL, false, true, false);
    CategoryPlot categoryPlot = (CategoryPlot)jFreeChart.getPlot();
    categoryPlot.setRangePannable(true);
    Paint[] arrayOfPaint = createPaint();
    CustomCylinderRenderer customCylinderRenderer = new CustomCylinderRenderer(arrayOfPaint);
    customCylinderRenderer.setGradientPaintTransformer((GradientPaintTransformer)new StandardGradientPaintTransformer(GradientPaintTransformType.CENTER_VERTICAL));
    customCylinderRenderer.setBaseOutlinePaint(Color.gray);
    customCylinderRenderer.setBaseOutlineStroke(new BasicStroke(0.3F));
    customCylinderRenderer.setBaseToolTipGenerator((CategoryToolTipGenerator)new StandardCategoryToolTipGenerator());
    categoryPlot.setRenderer((CategoryItemRenderer)customCylinderRenderer);
    ChartUtilities.applyCurrentTheme(jFreeChart);
    return jFreeChart;
  }
  
  private static Paint[] createPaint() {
    Paint[] arrayOfPaint = new Paint[5];
    arrayOfPaint[0] = new GradientPaint(0.0F, 0.0F, Color.white, 0.0F, 0.0F, Color.red);
    arrayOfPaint[1] = new GradientPaint(0.0F, 0.0F, Color.white, 0.0F, 0.0F, Color.green);
    arrayOfPaint[2] = new GradientPaint(0.0F, 0.0F, Color.white, 0.0F, 0.0F, Color.blue);
    arrayOfPaint[3] = new GradientPaint(0.0F, 0.0F, Color.white, 0.0F, 0.0F, Color.orange);
    arrayOfPaint[4] = new GradientPaint(0.0F, 0.0F, Color.white, 0.0F, 0.0F, Color.magenta);
    return arrayOfPaint;
  }
  
  public static JPanel createDemoPanel() {
    JFreeChart jFreeChart = createChart(createDataset());
    ChartPanel chartPanel = new ChartPanel(jFreeChart);
    chartPanel.setMouseWheelEnabled(true);
    return (JPanel)chartPanel;
  }
  
  public static void main(String[] paramArrayOfString) {
    CylinderChartDemo2 cylinderChartDemo2 = new CylinderChartDemo2("JFreeChart: CylinderChartDemo2.java");
    cylinderChartDemo2.pack();
    RefineryUtilities.centerFrameOnScreen((Window)cylinderChartDemo2);
    cylinderChartDemo2.setVisible(true);
  }
  
  static class CustomCylinderRenderer extends CylinderRenderer {
    private Paint[] colors;
    
    public CustomCylinderRenderer(Paint[] param1ArrayOfPaint) {
      this.colors = param1ArrayOfPaint;
    }
    
    public Paint getItemPaint(int param1Int1, int param1Int2) {
      return this.colors[param1Int2 % this.colors.length];
    }
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/CylinderChartDemo2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */