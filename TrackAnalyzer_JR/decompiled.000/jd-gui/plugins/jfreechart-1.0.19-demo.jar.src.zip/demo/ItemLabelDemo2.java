package demo;

import java.awt.Dimension;
import java.awt.Window;
import java.text.NumberFormat;
import javax.swing.JPanel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.AxisLocation;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.labels.AbstractCategoryItemLabelGenerator;
import org.jfree.chart.labels.CategoryItemLabelGenerator;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.renderer.category.BarRenderer;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

public class ItemLabelDemo2 extends ApplicationFrame {
  public ItemLabelDemo2(String paramString) {
    super(paramString);
    JPanel jPanel = createDemoPanel();
    jPanel.setPreferredSize(new Dimension(500, 270));
    setContentPane(jPanel);
  }
  
  private static CategoryDataset createDataset() {
    DefaultCategoryDataset defaultCategoryDataset = new DefaultCategoryDataset();
    defaultCategoryDataset.addValue(100.0D, "S1", "C1");
    defaultCategoryDataset.addValue(44.3D, "S1", "C2");
    defaultCategoryDataset.addValue(93.0D, "S1", "C3");
    defaultCategoryDataset.addValue(80.0D, "S2", "C1");
    defaultCategoryDataset.addValue(75.1D, "S2", "C2");
    defaultCategoryDataset.addValue(15.1D, "S2", "C3");
    return (CategoryDataset)defaultCategoryDataset;
  }
  
  private static JFreeChart createChart(CategoryDataset paramCategoryDataset) {
    JFreeChart jFreeChart = ChartFactory.createBarChart("Item Label Demo 2", "Category", "Value", paramCategoryDataset, PlotOrientation.HORIZONTAL, true, true, false);
    CategoryPlot categoryPlot = (CategoryPlot)jFreeChart.getPlot();
    categoryPlot.setRangeAxisLocation(AxisLocation.BOTTOM_OR_LEFT);
    categoryPlot.setRangePannable(true);
    categoryPlot.setRangeZeroBaselineVisible(true);
    NumberAxis numberAxis = (NumberAxis)categoryPlot.getRangeAxis();
    numberAxis.setUpperMargin(0.25D);
    BarRenderer barRenderer = (BarRenderer)categoryPlot.getRenderer();
    barRenderer.setBaseItemLabelsVisible(true);
    barRenderer.setItemLabelAnchorOffset(7.0D);
    barRenderer.setBaseItemLabelGenerator(new LabelGenerator(null));
    return jFreeChart;
  }
  
  public static JPanel createDemoPanel() {
    JFreeChart jFreeChart = createChart(createDataset());
    ChartPanel chartPanel = new ChartPanel(jFreeChart);
    chartPanel.setMouseWheelEnabled(true);
    return (JPanel)chartPanel;
  }
  
  public static void main(String[] paramArrayOfString) {
    ItemLabelDemo2 itemLabelDemo2 = new ItemLabelDemo2("JFreeChart: ItemLabelDemo2.java");
    itemLabelDemo2.pack();
    RefineryUtilities.centerFrameOnScreen((Window)itemLabelDemo2);
    itemLabelDemo2.setVisible(true);
  }
  
  static class LabelGenerator extends AbstractCategoryItemLabelGenerator implements CategoryItemLabelGenerator {
    private Integer category;
    
    private NumberFormat formatter = NumberFormat.getPercentInstance();
    
    public LabelGenerator(int param1Int) {
      this(new Integer(param1Int));
    }
    
    public LabelGenerator(Integer param1Integer) {
      super("", NumberFormat.getInstance());
      this.category = param1Integer;
    }
    
    public String generateLabel(CategoryDataset param1CategoryDataset, int param1Int1, int param1Int2) {
      String str = null;
      double d = 0.0D;
      if (this.category != null) {
        Number number1 = param1CategoryDataset.getValue(param1Int1, this.category.intValue());
        d = number1.doubleValue();
      } else {
        d = calculateSeriesTotal(param1CategoryDataset, param1Int1);
      } 
      Number number = param1CategoryDataset.getValue(param1Int1, param1Int2);
      if (number != null) {
        double d1 = number.doubleValue();
        str = number.toString() + " (" + this.formatter.format(d1 / d) + ")";
      } 
      return str;
    }
    
    private double calculateSeriesTotal(CategoryDataset param1CategoryDataset, int param1Int) {
      double d = 0.0D;
      for (byte b = 0; b < param1CategoryDataset.getColumnCount(); b++) {
        Number number = param1CategoryDataset.getValue(param1Int, b);
        if (number != null)
          d += number.doubleValue(); 
      } 
      return d;
    }
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/ItemLabelDemo2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */