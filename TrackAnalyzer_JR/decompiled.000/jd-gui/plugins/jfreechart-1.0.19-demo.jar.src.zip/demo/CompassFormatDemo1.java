package demo;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Window;
import java.text.NumberFormat;
import javax.swing.JPanel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.CompassFormat;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.axis.NumberTickUnit;
import org.jfree.chart.axis.TickUnit;
import org.jfree.chart.axis.TickUnitSource;
import org.jfree.chart.axis.TickUnits;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYAreaRenderer;
import org.jfree.chart.renderer.xy.XYItemRenderer;
import org.jfree.data.time.Minute;
import org.jfree.data.time.RegularTimePeriod;
import org.jfree.data.time.TimeSeries;
import org.jfree.data.time.TimeSeriesCollection;
import org.jfree.data.xy.XYDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

public class CompassFormatDemo1 extends ApplicationFrame {
  public CompassFormatDemo1(String paramString) {
    super(paramString);
    JPanel jPanel = createDemoPanel();
    jPanel.setPreferredSize(new Dimension(500, 270));
    setContentPane(jPanel);
  }
  
  private static XYDataset createDirectionDataset(int paramInt) {
    TimeSeriesCollection timeSeriesCollection = new TimeSeriesCollection();
    TimeSeries timeSeries = new TimeSeries("Wind Direction");
    Minute minute = new Minute();
    double d = 180.0D;
    for (byte b = 0; b < paramInt; b++) {
      timeSeries.add((RegularTimePeriod)minute, d);
      RegularTimePeriod regularTimePeriod = minute.next();
      d += (Math.random() - 0.5D) * 15.0D;
      if (d < 0.0D) {
        d += 360.0D;
      } else if (d > 360.0D) {
        d -= 360.0D;
      } 
    } 
    timeSeriesCollection.addSeries(timeSeries);
    return (XYDataset)timeSeriesCollection;
  }
  
  private static XYDataset createForceDataset(int paramInt) {
    TimeSeriesCollection timeSeriesCollection = new TimeSeriesCollection();
    TimeSeries timeSeries = new TimeSeries("Wind Force");
    Minute minute = new Minute();
    double d = 3.0D;
    for (byte b = 0; b < paramInt; b++) {
      timeSeries.add((RegularTimePeriod)minute, d);
      RegularTimePeriod regularTimePeriod = minute.next();
      d = Math.max(0.5D, d + (Math.random() - 0.5D) * 0.5D);
    } 
    timeSeriesCollection.addSeries(timeSeries);
    return (XYDataset)timeSeriesCollection;
  }
  
  private static JFreeChart createChart() {
    XYDataset xYDataset = createDirectionDataset(600);
    JFreeChart jFreeChart = ChartFactory.createTimeSeriesChart("Time", "Date", "Direction", xYDataset, true, true, false);
    XYPlot xYPlot = (XYPlot)jFreeChart.getPlot();
    xYPlot.setDomainPannable(true);
    xYPlot.setRangePannable(true);
    xYPlot.getDomainAxis().setLowerMargin(0.0D);
    xYPlot.getDomainAxis().setUpperMargin(0.0D);
    NumberAxis numberAxis1 = (NumberAxis)xYPlot.getRangeAxis();
    numberAxis1.setAutoRangeIncludesZero(false);
    TickUnits tickUnits = new TickUnits();
    tickUnits.add((TickUnit)new NumberTickUnit(180.0D, (NumberFormat)new CompassFormat()));
    tickUnits.add((TickUnit)new NumberTickUnit(90.0D, (NumberFormat)new CompassFormat()));
    tickUnits.add((TickUnit)new NumberTickUnit(45.0D, (NumberFormat)new CompassFormat()));
    tickUnits.add((TickUnit)new NumberTickUnit(22.5D, (NumberFormat)new CompassFormat()));
    numberAxis1.setStandardTickUnits((TickUnitSource)tickUnits);
    xYPlot.setRangeAxis((ValueAxis)numberAxis1);
    XYAreaRenderer xYAreaRenderer = new XYAreaRenderer();
    NumberAxis numberAxis2 = new NumberAxis("Force");
    numberAxis2.setRange(0.0D, 12.0D);
    xYAreaRenderer.setSeriesPaint(0, new Color(0, 0, 255, 128));
    xYPlot.setDataset(1, createForceDataset(600));
    xYPlot.setRenderer(1, (XYItemRenderer)xYAreaRenderer);
    xYPlot.setRangeAxis(1, (ValueAxis)numberAxis2);
    xYPlot.mapDatasetToRangeAxis(1, 1);
    ChartUtilities.applyCurrentTheme(jFreeChart);
    return jFreeChart;
  }
  
  public static JPanel createDemoPanel() {
    JFreeChart jFreeChart = createChart();
    ChartPanel chartPanel = new ChartPanel(jFreeChart);
    chartPanel.setMouseWheelEnabled(true);
    return (JPanel)chartPanel;
  }
  
  public static void main(String[] paramArrayOfString) {
    CompassFormatDemo1 compassFormatDemo1 = new CompassFormatDemo1("JFreeChart: CompassFormatDemo1.java");
    compassFormatDemo1.pack();
    RefineryUtilities.centerFrameOnScreen((Window)compassFormatDemo1);
    compassFormatDemo1.setVisible(true);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/CompassFormatDemo1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */