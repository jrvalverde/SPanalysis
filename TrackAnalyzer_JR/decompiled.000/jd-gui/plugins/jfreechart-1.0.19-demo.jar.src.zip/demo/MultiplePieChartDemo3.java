package demo;

import java.awt.Container;
import java.awt.Dimension;
import java.awt.Window;
import javax.swing.JPanel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.MultiplePiePlot;
import org.jfree.chart.plot.PiePlot;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;
import org.jfree.util.TableOrder;

public class MultiplePieChartDemo3 extends ApplicationFrame {
  public MultiplePieChartDemo3(String paramString) {
    super(paramString);
    CategoryDataset categoryDataset = createDataset();
    JFreeChart jFreeChart = createChart(categoryDataset);
    ChartPanel chartPanel = new ChartPanel(jFreeChart, true, true, true, false, true);
    chartPanel.setPreferredSize(new Dimension(600, 380));
    setContentPane((Container)chartPanel);
  }
  
  private static CategoryDataset createDataset() {
    DefaultCategoryDataset defaultCategoryDataset = new DefaultCategoryDataset();
    defaultCategoryDataset.addValue(5.6D, "Row 0", "Column 0");
    defaultCategoryDataset.addValue(4.3D, "Row 0", "Column 1");
    defaultCategoryDataset.addValue(6.7D, "Row 0", "Column 2");
    defaultCategoryDataset.addValue(4.4D, "Row 0", "Column 3");
    defaultCategoryDataset.addValue(6.1D, "Row 0", "Column 4");
    defaultCategoryDataset.addValue(5.8D, "Row 1", "Column 0");
    defaultCategoryDataset.addValue(3.2D, "Row 1", "Column 1");
    defaultCategoryDataset.addValue(4.5D, "Row 1", "Column 2");
    defaultCategoryDataset.addValue(7.0D, "Row 1", "Column 3");
    defaultCategoryDataset.addValue(5.8D, "Row 1", "Column 4");
    defaultCategoryDataset.addValue(5.3D, "Row 2", "Column 0");
    defaultCategoryDataset.addValue(6.7D, "Row 2", "Column 1");
    defaultCategoryDataset.addValue(7.1D, "Row 2", "Column 2");
    defaultCategoryDataset.addValue(4.2D, "Row 2", "Column 3");
    defaultCategoryDataset.addValue(9.0D, "Row 2", "Column 4");
    defaultCategoryDataset.addValue(5.6D, "Row 3", "Column 0");
    defaultCategoryDataset.addValue(5.6D, "Row 3", "Column 1");
    defaultCategoryDataset.addValue(5.6D, "Row 3", "Column 2");
    defaultCategoryDataset.addValue(5.6D, "Row 3", "Column 3");
    defaultCategoryDataset.addValue(5.6D, "Row 3", "Column 4");
    defaultCategoryDataset.addValue(5.6D, "Row 4", "Column 0");
    defaultCategoryDataset.addValue(5.6D, "Row 4", "Column 1");
    defaultCategoryDataset.addValue(5.6D, "Row 4", "Column 2");
    defaultCategoryDataset.addValue(5.6D, "Row 4", "Column 3");
    defaultCategoryDataset.addValue(5.6D, "Row 4", "Column 4");
    return (CategoryDataset)defaultCategoryDataset;
  }
  
  private static JFreeChart createChart(CategoryDataset paramCategoryDataset) {
    JFreeChart jFreeChart = ChartFactory.createMultiplePieChart3D("Multiple Pie Chart Demo 3", paramCategoryDataset, TableOrder.BY_COLUMN, true, true, false);
    MultiplePiePlot multiplePiePlot = (MultiplePiePlot)jFreeChart.getPlot();
    PiePlot piePlot = (PiePlot)multiplePiePlot.getPieChart().getPlot();
    piePlot.setMaximumLabelWidth(0.18D);
    return jFreeChart;
  }
  
  public static JPanel createDemoPanel() {
    JFreeChart jFreeChart = createChart(createDataset());
    return (JPanel)new ChartPanel(jFreeChart);
  }
  
  public static void main(String[] paramArrayOfString) {
    MultiplePieChartDemo3 multiplePieChartDemo3 = new MultiplePieChartDemo3("JFreeChart: MultiplePieChartDemo3.java");
    multiplePieChartDemo3.pack();
    RefineryUtilities.centerFrameOnScreen((Window)multiplePieChartDemo3);
    multiplePieChartDemo3.setVisible(true);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/MultiplePieChartDemo3.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */