package demo;

import java.awt.Dimension;
import java.awt.Window;
import javax.swing.JPanel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

public class LineChart3DDemo1 extends ApplicationFrame {
  public LineChart3DDemo1(String paramString) {
    super(paramString);
    JPanel jPanel = createDemoPanel();
    jPanel.setPreferredSize(new Dimension(500, 270));
    setContentPane(jPanel);
  }
  
  private static CategoryDataset createDataset() {
    DefaultCategoryDataset defaultCategoryDataset = new DefaultCategoryDataset();
    defaultCategoryDataset.addValue(143.2D, "S1", "C1");
    defaultCategoryDataset.addValue(120.2D, "S1", "C2");
    defaultCategoryDataset.addValue(135.0D, "S1", "C3");
    defaultCategoryDataset.addValue(115.0D, "S1", "C4");
    defaultCategoryDataset.addValue(98.7D, "S2", "C1");
    defaultCategoryDataset.addValue(63.2D, "S2", "C2");
    defaultCategoryDataset.addValue(71.4D, "S2", "C3");
    defaultCategoryDataset.addValue(55.0D, "S2", "C4");
    return (CategoryDataset)defaultCategoryDataset;
  }
  
  private static JFreeChart createChart(CategoryDataset paramCategoryDataset) {
    JFreeChart jFreeChart = ChartFactory.createLineChart3D("Line Chart 3D Demo 1", null, "Class Count", paramCategoryDataset, PlotOrientation.VERTICAL, false, true, false);
    CategoryPlot categoryPlot = (CategoryPlot)jFreeChart.getPlot();
    NumberAxis numberAxis = (NumberAxis)categoryPlot.getRangeAxis();
    numberAxis.setAutoRangeIncludesZero(false);
    numberAxis.setStandardTickUnits(NumberAxis.createIntegerTickUnits());
    return jFreeChart;
  }
  
  public static JPanel createDemoPanel() {
    JFreeChart jFreeChart = createChart(createDataset());
    return (JPanel)new ChartPanel(jFreeChart);
  }
  
  public static void main(String[] paramArrayOfString) {
    LineChart3DDemo1 lineChart3DDemo1 = new LineChart3DDemo1("JFreeChart: LineChart3DDemo1.java");
    lineChart3DDemo1.pack();
    RefineryUtilities.centerFrameOnScreen((Window)lineChart3DDemo1);
    lineChart3DDemo1.setVisible(true);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/LineChart3DDemo1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */