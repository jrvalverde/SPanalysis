package demo;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Window;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.JTabbedPane;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.FontChooserPanel;
import org.jfree.ui.RefineryUtilities;
import org.jfree.ui.TextAnchor;

public class DrawStringDemo extends ApplicationFrame implements ActionListener, ChangeListener {
  private JComboBox combo1;
  
  private JComboBox combo2;
  
  private JComboBox combo3;
  
  private JSlider rotation;
  
  private DrawStringPanel drawStringPanel1;
  
  private DrawStringPanel drawStringPanel2;
  
  public DrawStringDemo(String paramString) {
    super(paramString);
    setContentPane(createContentPane());
  }
  
  public void actionPerformed(ActionEvent paramActionEvent) {
    if (paramActionEvent.getActionCommand().equals("fontButton.clicked"))
      displayFontDialog(); 
    if (paramActionEvent.getActionCommand().equals("combo1.changed"))
      handleCombo1Change(); 
    if (paramActionEvent.getActionCommand().equals("combo2.changed"))
      handleCombo2Change(); 
    if (paramActionEvent.getActionCommand().equals("combo3.changed"))
      handleCombo3Change(); 
  }
  
  public void stateChanged(ChangeEvent paramChangeEvent) {
    int i = this.rotation.getValue();
    double d = 6.283185307179586D * i / 360.0D;
    this.drawStringPanel2.setAngle(d);
    this.drawStringPanel2.invalidate();
    this.drawStringPanel2.repaint();
  }
  
  private void handleCombo1Change() {
    String str = this.combo1.getSelectedItem().toString();
    this.drawStringPanel1.setAnchor(convertStringToAnchor(str));
    this.drawStringPanel1.invalidate();
    this.drawStringPanel1.repaint();
  }
  
  private void handleCombo2Change() {
    String str = this.combo2.getSelectedItem().toString();
    this.drawStringPanel2.setAnchor(convertStringToAnchor(str));
    this.drawStringPanel2.invalidate();
    this.drawStringPanel2.repaint();
  }
  
  private void handleCombo3Change() {
    String str = this.combo3.getSelectedItem().toString();
    this.drawStringPanel2.setRotationAnchor(convertStringToAnchor(str));
    this.drawStringPanel2.invalidate();
    this.drawStringPanel2.repaint();
  }
  
  private JPanel createContentPane() {
    JPanel jPanel = new JPanel(new BorderLayout());
    JTabbedPane jTabbedPane = new JTabbedPane();
    jTabbedPane.add("Alignment", createTab1Content());
    jTabbedPane.add("Rotation", createTab2Content());
    jPanel.add(jTabbedPane);
    return jPanel;
  }
  
  private JPanel createTab1Content() {
    JPanel jPanel1 = new JPanel(new BorderLayout());
    this.combo1 = new JComboBox();
    this.combo1.setActionCommand("combo1.changed");
    populateTextAnchorCombo(this.combo1);
    this.combo1.addActionListener(this);
    JPanel jPanel2 = new JPanel();
    jPanel2.add(this.combo1);
    JButton jButton = new JButton("Select Font...");
    jButton.setActionCommand("fontButton.clicked");
    jButton.addActionListener(this);
    jPanel2.add(jButton);
    jPanel1.add(jPanel2, "North");
    this.drawStringPanel1 = new DrawStringPanel("0123456789", false);
    jPanel1.add(this.drawStringPanel1);
    return jPanel1;
  }
  
  private JPanel createTab2Content() {
    JPanel jPanel1 = new JPanel(new BorderLayout());
    JPanel jPanel2 = new JPanel();
    jPanel2.add(new JLabel("Text anchor: "));
    this.combo2 = new JComboBox();
    populateTextAnchorCombo(this.combo2);
    this.combo2.setActionCommand("combo2.changed");
    this.combo2.addActionListener(this);
    jPanel2.add(this.combo2);
    jPanel2.add(new JLabel("Rotation anchor: "));
    this.combo3 = new JComboBox();
    populateTextAnchorCombo(this.combo3);
    this.combo3.setActionCommand("combo3.changed");
    this.combo3.addActionListener(this);
    jPanel2.add(this.combo3);
    this.rotation = new JSlider(-360, 360, 0);
    this.rotation.setMajorTickSpacing(60);
    this.rotation.setMinorTickSpacing(10);
    this.rotation.setPaintLabels(true);
    this.rotation.setPaintTicks(true);
    this.rotation.addChangeListener(this);
    jPanel1.add(this.rotation, "South");
    jPanel1.add(jPanel2, "North");
    this.drawStringPanel2 = new DrawStringPanel("Rotated Text", true);
    jPanel1.add(this.drawStringPanel2);
    return jPanel1;
  }
  
  private void displayFontDialog() {
    FontChooserPanel fontChooserPanel = new FontChooserPanel(this.drawStringPanel1.getFont());
    int i = JOptionPane.showConfirmDialog((Component)this, fontChooserPanel, "Font Selection", 2, -1);
    if (i == 0) {
      this.drawStringPanel1.setFont(fontChooserPanel.getSelectedFont());
      this.drawStringPanel2.setFont(fontChooserPanel.getSelectedFont());
    } 
  }
  
  private void populateTextAnchorCombo(JComboBox<String> paramJComboBox) {
    paramJComboBox.addItem("TextAnchor.TOP_LEFT");
    paramJComboBox.addItem("TextAnchor.TOP_CENTER");
    paramJComboBox.addItem("TextAnchor.TOP_RIGHT");
    paramJComboBox.addItem("TextAnchor.HALF_ASCENT_LEFT");
    paramJComboBox.addItem("TextAnchor.HALF_ASCENT_CENTER");
    paramJComboBox.addItem("TextAnchor.HALF_ASCENT_RIGHT");
    paramJComboBox.addItem("TextAnchor.CENTER_LEFT");
    paramJComboBox.addItem("TextAnchor.CENTER");
    paramJComboBox.addItem("TextAnchor.CENTER_RIGHT");
    paramJComboBox.addItem("TextAnchor.BASELINE_LEFT");
    paramJComboBox.addItem("TextAnchor.BASELINE_CENTER");
    paramJComboBox.addItem("TextAnchor.BASELINE_RIGHT");
    paramJComboBox.addItem("TextAnchor.BOTTOM_LEFT");
    paramJComboBox.addItem("TextAnchor.BOTTOM_CENTER");
    paramJComboBox.addItem("TextAnchor.BOTTOM_RIGHT");
  }
  
  private TextAnchor convertStringToAnchor(String paramString) {
    return paramString.equals("TextAnchor.TOP_LEFT") ? TextAnchor.TOP_LEFT : (paramString.equals("TextAnchor.TOP_CENTER") ? TextAnchor.TOP_CENTER : (paramString.equals("TextAnchor.TOP_RIGHT") ? TextAnchor.TOP_RIGHT : (paramString.equals("TextAnchor.CENTER_LEFT") ? TextAnchor.CENTER_LEFT : (paramString.equals("TextAnchor.CENTER") ? TextAnchor.CENTER : (paramString.equals("TextAnchor.CENTER_RIGHT") ? TextAnchor.CENTER_RIGHT : (paramString.equals("TextAnchor.HALF_ASCENT_LEFT") ? TextAnchor.HALF_ASCENT_LEFT : (paramString.equals("TextAnchor.HALF_ASCENT_CENTER") ? TextAnchor.HALF_ASCENT_CENTER : (paramString.equals("TextAnchor.HALF_ASCENT_RIGHT") ? TextAnchor.HALF_ASCENT_RIGHT : (paramString.equals("TextAnchor.BASELINE_LEFT") ? TextAnchor.BASELINE_LEFT : (paramString.equals("TextAnchor.BASELINE_CENTER") ? TextAnchor.BASELINE_CENTER : (paramString.equals("TextAnchor.BASELINE_RIGHT") ? TextAnchor.BASELINE_RIGHT : (paramString.equals("TextAnchor.BOTTOM_LEFT") ? TextAnchor.BOTTOM_LEFT : (paramString.equals("TextAnchor.BOTTOM_CENTER") ? TextAnchor.BOTTOM_CENTER : (paramString.equals("TextAnchor.BOTTOM_RIGHT") ? TextAnchor.BOTTOM_RIGHT : null))))))))))))));
  }
  
  public static void main(String[] paramArrayOfString) {
    DrawStringDemo drawStringDemo = new DrawStringDemo("DrawString Demo");
    drawStringDemo.pack();
    RefineryUtilities.centerFrameOnScreen((Window)drawStringDemo);
    drawStringDemo.setVisible(true);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/DrawStringDemo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */