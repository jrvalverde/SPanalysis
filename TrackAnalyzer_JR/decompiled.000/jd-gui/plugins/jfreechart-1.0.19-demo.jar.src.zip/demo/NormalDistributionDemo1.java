package demo;

import java.awt.Dimension;
import java.awt.Window;
import javax.swing.JPanel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.function.Function2D;
import org.jfree.data.function.NormalDistributionFunction2D;
import org.jfree.data.general.DatasetUtilities;
import org.jfree.data.xy.XYDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

public class NormalDistributionDemo1 extends ApplicationFrame {
  public NormalDistributionDemo1(String paramString) {
    super(paramString);
    JPanel jPanel = createDemoPanel();
    jPanel.setPreferredSize(new Dimension(500, 270));
    setContentPane(jPanel);
  }
  
  public static JPanel createDemoPanel() {
    JFreeChart jFreeChart = createChart(createDataset());
    return (JPanel)new ChartPanel(jFreeChart);
  }
  
  public static XYDataset createDataset() {
    NormalDistributionFunction2D normalDistributionFunction2D = new NormalDistributionFunction2D(0.0D, 1.0D);
    return DatasetUtilities.sampleFunction2D((Function2D)normalDistributionFunction2D, -5.0D, 5.0D, 100, "Normal");
  }
  
  public static JFreeChart createChart(XYDataset paramXYDataset) {
    return ChartFactory.createXYLineChart("Normal Distribution", "X", "Y", paramXYDataset, PlotOrientation.VERTICAL, true, true, false);
  }
  
  public static void main(String[] paramArrayOfString) {
    NormalDistributionDemo1 normalDistributionDemo1 = new NormalDistributionDemo1("JFreeChart: NormalDistributionDemo1.java");
    normalDistributionDemo1.pack();
    RefineryUtilities.centerFrameOnScreen((Window)normalDistributionDemo1);
    normalDistributionDemo1.setVisible(true);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/NormalDistributionDemo1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */