package demo;

import java.awt.Container;
import java.awt.Dimension;
import java.awt.Window;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import javax.swing.JPanel;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.DateAxis;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.labels.StandardXYToolTipGenerator;
import org.jfree.chart.labels.XYToolTipGenerator;
import org.jfree.chart.plot.CombinedRangeXYPlot;
import org.jfree.chart.plot.Plot;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.StandardXYItemRenderer;
import org.jfree.chart.renderer.xy.XYBarRenderer;
import org.jfree.chart.renderer.xy.XYItemRenderer;
import org.jfree.data.time.Day;
import org.jfree.data.time.RegularTimePeriod;
import org.jfree.data.time.TimeSeries;
import org.jfree.data.time.TimeSeriesCollection;
import org.jfree.data.xy.IntervalXYDataset;
import org.jfree.data.xy.XYDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

public class CombinedXYPlotDemo2 extends ApplicationFrame {
  public CombinedXYPlotDemo2(String paramString) {
    super(paramString);
    JFreeChart jFreeChart = createCombinedChart();
    ChartPanel chartPanel = new ChartPanel(jFreeChart, true, true, true, true, true);
    chartPanel.setPreferredSize(new Dimension(500, 270));
    setContentPane((Container)chartPanel);
  }
  
  private static JFreeChart createCombinedChart() {
    IntervalXYDataset intervalXYDataset = createDataset1();
    XYBarRenderer xYBarRenderer = new XYBarRenderer(0.2D);
    xYBarRenderer.setBaseToolTipGenerator((XYToolTipGenerator)new StandardXYToolTipGenerator("{0}: ({1}, {2})", new SimpleDateFormat("d-MMM-yyyy"), new DecimalFormat("0,000.0")));
    XYPlot xYPlot1 = new XYPlot((XYDataset)intervalXYDataset, (ValueAxis)new DateAxis("Date"), null, (XYItemRenderer)xYBarRenderer);
    XYDataset xYDataset = createDataset2();
    StandardXYItemRenderer standardXYItemRenderer = new StandardXYItemRenderer();
    standardXYItemRenderer.setBaseToolTipGenerator((XYToolTipGenerator)new StandardXYToolTipGenerator("{0}: ({1}, {2})", new SimpleDateFormat("d-MMM-yyyy"), new DecimalFormat("0,000.0")));
    XYPlot xYPlot2 = new XYPlot(xYDataset, (ValueAxis)new DateAxis("Date"), null, (XYItemRenderer)standardXYItemRenderer);
    NumberAxis numberAxis = new NumberAxis("Value");
    numberAxis.setTickMarkInsideLength(3.0F);
    CombinedRangeXYPlot combinedRangeXYPlot = new CombinedRangeXYPlot((ValueAxis)numberAxis);
    combinedRangeXYPlot.add(xYPlot1, 1);
    combinedRangeXYPlot.add(xYPlot2, 1);
    JFreeChart jFreeChart = new JFreeChart("Combined (Range) XY Plot", JFreeChart.DEFAULT_TITLE_FONT, (Plot)combinedRangeXYPlot, true);
    ChartUtilities.applyCurrentTheme(jFreeChart);
    return jFreeChart;
  }
  
  private static IntervalXYDataset createDataset1() {
    TimeSeries timeSeries = new TimeSeries("Series 1");
    timeSeries.add((RegularTimePeriod)new Day(1, 3, 2002), 12353.3D);
    timeSeries.add((RegularTimePeriod)new Day(2, 3, 2002), 13734.4D);
    timeSeries.add((RegularTimePeriod)new Day(3, 3, 2002), 14525.3D);
    timeSeries.add((RegularTimePeriod)new Day(4, 3, 2002), 13984.3D);
    timeSeries.add((RegularTimePeriod)new Day(5, 3, 2002), 12999.4D);
    timeSeries.add((RegularTimePeriod)new Day(6, 3, 2002), 14274.3D);
    timeSeries.add((RegularTimePeriod)new Day(7, 3, 2002), 15943.5D);
    timeSeries.add((RegularTimePeriod)new Day(8, 3, 2002), 14845.3D);
    timeSeries.add((RegularTimePeriod)new Day(9, 3, 2002), 14645.4D);
    timeSeries.add((RegularTimePeriod)new Day(10, 3, 2002), 16234.6D);
    timeSeries.add((RegularTimePeriod)new Day(11, 3, 2002), 17232.3D);
    timeSeries.add((RegularTimePeriod)new Day(12, 3, 2002), 14232.2D);
    timeSeries.add((RegularTimePeriod)new Day(13, 3, 2002), 13102.2D);
    timeSeries.add((RegularTimePeriod)new Day(14, 3, 2002), 14230.2D);
    timeSeries.add((RegularTimePeriod)new Day(15, 3, 2002), 11235.2D);
    return (IntervalXYDataset)new TimeSeriesCollection(timeSeries);
  }
  
  private static XYDataset createDataset2() {
    TimeSeries timeSeries = new TimeSeries("Series 2");
    timeSeries.add((RegularTimePeriod)new Day(3, 3, 2002), 6853.2D);
    timeSeries.add((RegularTimePeriod)new Day(4, 3, 2002), 9642.3D);
    timeSeries.add((RegularTimePeriod)new Day(5, 3, 2002), 8253.5D);
    timeSeries.add((RegularTimePeriod)new Day(6, 3, 2002), 5352.3D);
    timeSeries.add((RegularTimePeriod)new Day(7, 3, 2002), 3532.0D);
    timeSeries.add((RegularTimePeriod)new Day(8, 3, 2002), 2635.3D);
    timeSeries.add((RegularTimePeriod)new Day(9, 3, 2002), 3998.2D);
    timeSeries.add((RegularTimePeriod)new Day(10, 3, 2002), 1943.2D);
    timeSeries.add((RegularTimePeriod)new Day(11, 3, 2002), 6943.9D);
    timeSeries.add((RegularTimePeriod)new Day(12, 3, 2002), 7843.2D);
    timeSeries.add((RegularTimePeriod)new Day(13, 3, 2002), 6495.3D);
    timeSeries.add((RegularTimePeriod)new Day(14, 3, 2002), 7943.6D);
    timeSeries.add((RegularTimePeriod)new Day(15, 3, 2002), 8500.7D);
    timeSeries.add((RegularTimePeriod)new Day(16, 3, 2002), 9595.9D);
    return (XYDataset)new TimeSeriesCollection(timeSeries);
  }
  
  public static JPanel createDemoPanel() {
    JFreeChart jFreeChart = createCombinedChart();
    return (JPanel)new ChartPanel(jFreeChart);
  }
  
  public static void main(String[] paramArrayOfString) {
    CombinedXYPlotDemo2 combinedXYPlotDemo2 = new CombinedXYPlotDemo2("JFreeChart: CombinedXYPlotDemo2.java");
    combinedXYPlotDemo2.pack();
    RefineryUtilities.centerFrameOnScreen((Window)combinedXYPlotDemo2);
    combinedXYPlotDemo2.setVisible(true);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/CombinedXYPlotDemo2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */