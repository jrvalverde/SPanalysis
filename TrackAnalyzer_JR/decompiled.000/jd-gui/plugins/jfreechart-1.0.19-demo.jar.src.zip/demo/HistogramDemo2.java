package demo;

import java.awt.Dimension;
import java.awt.Window;
import javax.swing.JPanel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYBarRenderer;
import org.jfree.data.statistics.SimpleHistogramBin;
import org.jfree.data.statistics.SimpleHistogramDataset;
import org.jfree.data.xy.IntervalXYDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

public class HistogramDemo2 extends ApplicationFrame {
  public HistogramDemo2(String paramString) {
    super(paramString);
    JPanel jPanel = createDemoPanel();
    jPanel.setPreferredSize(new Dimension(500, 270));
    setContentPane(jPanel);
  }
  
  private static IntervalXYDataset createDataset() {
    SimpleHistogramDataset simpleHistogramDataset = new SimpleHistogramDataset("Series 1");
    SimpleHistogramBin simpleHistogramBin1 = new SimpleHistogramBin(0.0D, 1.0D, true, false);
    SimpleHistogramBin simpleHistogramBin2 = new SimpleHistogramBin(1.0D, 2.0D, true, false);
    SimpleHistogramBin simpleHistogramBin3 = new SimpleHistogramBin(2.0D, 3.0D, true, false);
    SimpleHistogramBin simpleHistogramBin4 = new SimpleHistogramBin(3.0D, 4.0D, true, true);
    simpleHistogramBin1.setItemCount(1);
    simpleHistogramBin2.setItemCount(10);
    simpleHistogramBin3.setItemCount(15);
    simpleHistogramBin4.setItemCount(20);
    simpleHistogramDataset.addBin(simpleHistogramBin1);
    simpleHistogramDataset.addBin(simpleHistogramBin2);
    simpleHistogramDataset.addBin(simpleHistogramBin3);
    simpleHistogramDataset.addBin(simpleHistogramBin4);
    return (IntervalXYDataset)simpleHistogramDataset;
  }
  
  private static JFreeChart createChart(IntervalXYDataset paramIntervalXYDataset) {
    JFreeChart jFreeChart = ChartFactory.createHistogram("HistogramDemo2", null, null, paramIntervalXYDataset, PlotOrientation.VERTICAL, true, true, false);
    XYPlot xYPlot = (XYPlot)jFreeChart.getPlot();
    xYPlot.setForegroundAlpha(0.85F);
    xYPlot.setDomainPannable(true);
    xYPlot.setRangePannable(true);
    NumberAxis numberAxis = (NumberAxis)xYPlot.getRangeAxis();
    numberAxis.setStandardTickUnits(NumberAxis.createIntegerTickUnits());
    XYBarRenderer xYBarRenderer = (XYBarRenderer)xYPlot.getRenderer();
    xYBarRenderer.setDrawBarOutline(false);
    return jFreeChart;
  }
  
  public static JPanel createDemoPanel() {
    JFreeChart jFreeChart = createChart(createDataset());
    ChartPanel chartPanel = new ChartPanel(jFreeChart);
    chartPanel.setMouseWheelEnabled(true);
    return (JPanel)chartPanel;
  }
  
  public static void main(String[] paramArrayOfString) {
    HistogramDemo2 histogramDemo2 = new HistogramDemo2("JFreeChart: HistogramDemo2.java");
    histogramDemo2.pack();
    RefineryUtilities.centerFrameOnScreen((Window)histogramDemo2);
    histogramDemo2.setVisible(true);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/HistogramDemo2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */