package demo;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Window;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JCheckBox;
import javax.swing.JPanel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYItemRenderer;
import org.jfree.data.xy.DefaultXYZDataset;
import org.jfree.data.xy.XYZDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

public class HideSeriesDemo3 extends ApplicationFrame {
  public HideSeriesDemo3(String paramString) {
    super(paramString);
    setContentPane(new MyDemoPanel());
  }
  
  public static JPanel createDemoPanel() {
    return new MyDemoPanel();
  }
  
  public static void main(String[] paramArrayOfString) {
    HideSeriesDemo3 hideSeriesDemo3 = new HideSeriesDemo3("JFreeChart: HideSeriesDemo3.java");
    hideSeriesDemo3.pack();
    RefineryUtilities.centerFrameOnScreen((Window)hideSeriesDemo3);
    hideSeriesDemo3.setVisible(true);
  }
  
  static class MyDemoPanel extends DemoPanel implements ActionListener {
    private XYItemRenderer renderer;
    
    public MyDemoPanel() {
      super(new BorderLayout());
      XYZDataset xYZDataset = createSampleDataset();
      JFreeChart jFreeChart = createChart(xYZDataset);
      addChart(jFreeChart);
      ChartPanel chartPanel = new ChartPanel(jFreeChart);
      chartPanel.setMouseWheelEnabled(true);
      JPanel jPanel = new JPanel();
      JCheckBox jCheckBox1 = new JCheckBox("Series 1");
      jCheckBox1.setActionCommand("S1");
      jCheckBox1.addActionListener(this);
      jCheckBox1.setSelected(true);
      JCheckBox jCheckBox2 = new JCheckBox("Series 2");
      jCheckBox2.setActionCommand("S2");
      jCheckBox2.addActionListener(this);
      jCheckBox2.setSelected(true);
      JCheckBox jCheckBox3 = new JCheckBox("Series 3");
      jCheckBox3.setActionCommand("S3");
      jCheckBox3.addActionListener(this);
      jCheckBox3.setSelected(true);
      jPanel.add(jCheckBox1);
      jPanel.add(jCheckBox2);
      jPanel.add(jCheckBox3);
      add((Component)chartPanel);
      add(jPanel, "South");
      chartPanel.setPreferredSize(new Dimension(500, 270));
    }
    
    private XYZDataset createSampleDataset() {
      DefaultXYZDataset defaultXYZDataset = new DefaultXYZDataset();
      double[] arrayOfDouble1 = { 2.1D, 2.3D, 2.3D };
      double[] arrayOfDouble2 = { 14.1D, 11.1D, 10.0D };
      double[] arrayOfDouble3 = { 2.4D, 2.7D, 2.7D };
      double[][] arrayOfDouble = { arrayOfDouble1, arrayOfDouble2, arrayOfDouble3 };
      defaultXYZDataset.addSeries("Series 1", arrayOfDouble);
      arrayOfDouble1 = new double[] { 2.2D, 2.2D, 1.8D };
      arrayOfDouble2 = new double[] { 14.1D, 11.1D, 10.0D };
      arrayOfDouble3 = new double[] { 2.2D, 2.2D, 2.2D };
      arrayOfDouble = new double[][] { arrayOfDouble1, arrayOfDouble2, arrayOfDouble3 };
      defaultXYZDataset.addSeries("Series 2", arrayOfDouble);
      arrayOfDouble1 = new double[] { 1.8D, 1.9D, 2.3D, 3.8D };
      arrayOfDouble2 = new double[] { 5.4D, 4.1D, 4.1D, 25.0D };
      arrayOfDouble3 = new double[] { 2.1D, 2.2D, 1.6D, 4.0D };
      arrayOfDouble = new double[][] { arrayOfDouble1, arrayOfDouble2, arrayOfDouble3 };
      defaultXYZDataset.addSeries("Series 3", arrayOfDouble);
      return (XYZDataset)defaultXYZDataset;
    }
    
    private JFreeChart createChart(XYZDataset param1XYZDataset) {
      JFreeChart jFreeChart = ChartFactory.createBubbleChart("Hide Series Demo 3", "X", "Y", param1XYZDataset, PlotOrientation.VERTICAL, true, true, false);
      XYPlot xYPlot = (XYPlot)jFreeChart.getPlot();
      xYPlot.setDomainPannable(true);
      xYPlot.setRangePannable(true);
      this.renderer = xYPlot.getRenderer(0);
      return jFreeChart;
    }
    
    public void actionPerformed(ActionEvent param1ActionEvent) {
      byte b = -1;
      if (param1ActionEvent.getActionCommand().equals("S1")) {
        b = 0;
      } else if (param1ActionEvent.getActionCommand().equals("S2")) {
        b = 1;
      } else if (param1ActionEvent.getActionCommand().equals("S3")) {
        b = 2;
      } 
      if (b >= 0) {
        boolean bool = this.renderer.getItemVisible(b, 0);
        this.renderer.setSeriesVisible(b, Boolean.valueOf(!bool));
      } 
    }
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/HideSeriesDemo3.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */