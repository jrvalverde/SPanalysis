package demo;

import java.awt.Dimension;
import java.awt.Font;
import java.awt.Window;
import javax.swing.JPanel;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.CategoryLabelPositions;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.labels.CategoryToolTipGenerator;
import org.jfree.chart.labels.StandardCategoryToolTipGenerator;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.CombinedRangeCategoryPlot;
import org.jfree.chart.plot.Plot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.renderer.category.BarRenderer;
import org.jfree.chart.renderer.category.CategoryItemRenderer;
import org.jfree.chart.renderer.category.LineAndShapeRenderer;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

public class CombinedCategoryPlotDemo2 extends ApplicationFrame {
  public CombinedCategoryPlotDemo2(String paramString) {
    super(paramString);
    JPanel jPanel = createDemoPanel();
    jPanel.setPreferredSize(new Dimension(500, 270));
    setContentPane(jPanel);
  }
  
  public static CategoryDataset createDataset1() {
    DefaultCategoryDataset defaultCategoryDataset = new DefaultCategoryDataset();
    String str1 = "First";
    String str2 = "Second";
    String str3 = "Type 1";
    String str4 = "Type 2";
    String str5 = "Type 3";
    String str6 = "Type 4";
    String str7 = "Type 5";
    String str8 = "Type 6";
    String str9 = "Type 7";
    String str10 = "Type 8";
    defaultCategoryDataset.addValue(1.0D, str1, str3);
    defaultCategoryDataset.addValue(4.0D, str1, str4);
    defaultCategoryDataset.addValue(3.0D, str1, str5);
    defaultCategoryDataset.addValue(5.0D, str1, str6);
    defaultCategoryDataset.addValue(5.0D, str1, str7);
    defaultCategoryDataset.addValue(7.0D, str1, str8);
    defaultCategoryDataset.addValue(7.0D, str1, str9);
    defaultCategoryDataset.addValue(8.0D, str1, str10);
    defaultCategoryDataset.addValue(5.0D, str2, str3);
    defaultCategoryDataset.addValue(7.0D, str2, str4);
    defaultCategoryDataset.addValue(6.0D, str2, str5);
    defaultCategoryDataset.addValue(8.0D, str2, str6);
    defaultCategoryDataset.addValue(4.0D, str2, str7);
    defaultCategoryDataset.addValue(4.0D, str2, str8);
    defaultCategoryDataset.addValue(2.0D, str2, str9);
    defaultCategoryDataset.addValue(1.0D, str2, str10);
    return (CategoryDataset)defaultCategoryDataset;
  }
  
  public static CategoryDataset createDataset2() {
    DefaultCategoryDataset defaultCategoryDataset = new DefaultCategoryDataset();
    String str1 = "Third";
    String str2 = "Fourth";
    String str3 = "Sector 1";
    String str4 = "Sector 2";
    String str5 = "Sector 3";
    String str6 = "Sector 4";
    defaultCategoryDataset.addValue(11.0D, str1, str3);
    defaultCategoryDataset.addValue(14.0D, str1, str4);
    defaultCategoryDataset.addValue(13.0D, str1, str5);
    defaultCategoryDataset.addValue(15.0D, str1, str6);
    defaultCategoryDataset.addValue(15.0D, str2, str3);
    defaultCategoryDataset.addValue(17.0D, str2, str4);
    defaultCategoryDataset.addValue(16.0D, str2, str5);
    defaultCategoryDataset.addValue(18.0D, str2, str6);
    return (CategoryDataset)defaultCategoryDataset;
  }
  
  private static JFreeChart createChart() {
    CategoryDataset categoryDataset1 = createDataset1();
    CategoryAxis categoryAxis1 = new CategoryAxis("Class 1");
    categoryAxis1.setCategoryLabelPositions(CategoryLabelPositions.UP_45);
    categoryAxis1.setMaximumCategoryLabelWidthRatio(5.0F);
    LineAndShapeRenderer lineAndShapeRenderer = new LineAndShapeRenderer();
    lineAndShapeRenderer.setBaseToolTipGenerator((CategoryToolTipGenerator)new StandardCategoryToolTipGenerator());
    CategoryPlot categoryPlot1 = new CategoryPlot(categoryDataset1, categoryAxis1, null, (CategoryItemRenderer)lineAndShapeRenderer);
    categoryPlot1.setDomainGridlinesVisible(true);
    CategoryDataset categoryDataset2 = createDataset2();
    CategoryAxis categoryAxis2 = new CategoryAxis("Class 2");
    categoryAxis2.setCategoryLabelPositions(CategoryLabelPositions.UP_45);
    categoryAxis2.setMaximumCategoryLabelWidthRatio(5.0F);
    BarRenderer barRenderer = new BarRenderer();
    barRenderer.setBaseToolTipGenerator((CategoryToolTipGenerator)new StandardCategoryToolTipGenerator());
    CategoryPlot categoryPlot2 = new CategoryPlot(categoryDataset2, categoryAxis2, null, (CategoryItemRenderer)barRenderer);
    categoryPlot2.setDomainGridlinesVisible(true);
    NumberAxis numberAxis = new NumberAxis("Value");
    CombinedRangeCategoryPlot combinedRangeCategoryPlot = new CombinedRangeCategoryPlot((ValueAxis)numberAxis);
    combinedRangeCategoryPlot.setRangePannable(true);
    combinedRangeCategoryPlot.add(categoryPlot1, 3);
    combinedRangeCategoryPlot.add(categoryPlot2, 2);
    combinedRangeCategoryPlot.setOrientation(PlotOrientation.HORIZONTAL);
    JFreeChart jFreeChart = new JFreeChart("Combined Range Category Plot Demo", new Font("SansSerif", 1, 12), (Plot)combinedRangeCategoryPlot, true);
    ChartUtilities.applyCurrentTheme(jFreeChart);
    return jFreeChart;
  }
  
  public static JPanel createDemoPanel() {
    JFreeChart jFreeChart = createChart();
    return (JPanel)new ChartPanel(jFreeChart);
  }
  
  public static void main(String[] paramArrayOfString) {
    String str = "JFreeChart: CombinedCategoryPlotDemo2.java";
    CombinedCategoryPlotDemo2 combinedCategoryPlotDemo2 = new CombinedCategoryPlotDemo2(str);
    combinedCategoryPlotDemo2.pack();
    RefineryUtilities.centerFrameOnScreen((Window)combinedCategoryPlotDemo2);
    combinedCategoryPlotDemo2.setVisible(true);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/CombinedCategoryPlotDemo2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */