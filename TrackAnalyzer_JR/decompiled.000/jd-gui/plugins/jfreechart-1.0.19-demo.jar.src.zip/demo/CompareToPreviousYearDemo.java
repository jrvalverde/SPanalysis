package demo;

import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Window;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import javax.swing.JPanel;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.DateAxis;
import org.jfree.chart.axis.DateTickMarkPosition;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.labels.StandardXYToolTipGenerator;
import org.jfree.chart.labels.XYToolTipGenerator;
import org.jfree.chart.plot.Plot;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYItemRenderer;
import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
import org.jfree.data.time.Month;
import org.jfree.data.time.RegularTimePeriod;
import org.jfree.data.time.TimePeriodAnchor;
import org.jfree.data.time.TimeSeries;
import org.jfree.data.time.TimeSeriesCollection;
import org.jfree.data.xy.XYDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

public class CompareToPreviousYearDemo extends ApplicationFrame {
  public CompareToPreviousYearDemo(String paramString) {
    super(paramString);
    ChartPanel chartPanel = (ChartPanel)createDemoPanel();
    chartPanel.setPreferredSize(new Dimension(500, 270));
    chartPanel.setMouseZoomable(true, true);
    setContentPane((Container)chartPanel);
  }
  
  private static JFreeChart createChart() {
    XYDataset xYDataset1 = createDataset2006();
    XYDataset xYDataset2 = createDataset2007();
    DateAxis dateAxis1 = new DateAxis("Date");
    Month month1 = new Month(1, 2007);
    Month month2 = new Month(12, 2007);
    dateAxis1.setRange(month1.getFirstMillisecond(), month2.getLastMillisecond());
    dateAxis1.setDateFormatOverride(new SimpleDateFormat("MMM"));
    dateAxis1.setTickMarkPosition(DateTickMarkPosition.MIDDLE);
    XYLineAndShapeRenderer xYLineAndShapeRenderer1 = new XYLineAndShapeRenderer();
    xYLineAndShapeRenderer1.setUseFillPaint(true);
    xYLineAndShapeRenderer1.setBaseFillPaint(Color.white);
    xYLineAndShapeRenderer1.setBaseToolTipGenerator((XYToolTipGenerator)new StandardXYToolTipGenerator("{1}: {2}", new SimpleDateFormat("MMM-yyyy"), new DecimalFormat("0.00")));
    XYPlot xYPlot = new XYPlot(xYDataset2, (ValueAxis)dateAxis1, (ValueAxis)new NumberAxis("Sales"), (XYItemRenderer)xYLineAndShapeRenderer1);
    xYPlot.setDomainPannable(true);
    xYPlot.setRangePannable(true);
    DateAxis dateAxis2 = new DateAxis();
    dateAxis2.setVisible(false);
    xYPlot.setDomainAxis(1, (ValueAxis)dateAxis2);
    xYPlot.setDataset(1, xYDataset1);
    xYPlot.mapDatasetToDomainAxis(1, 1);
    XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new XYLineAndShapeRenderer();
    xYLineAndShapeRenderer2.setSeriesPaint(0, Color.blue);
    xYLineAndShapeRenderer2.setUseFillPaint(true);
    xYLineAndShapeRenderer2.setBaseFillPaint(Color.white);
    xYLineAndShapeRenderer2.setBaseToolTipGenerator((XYToolTipGenerator)new StandardXYToolTipGenerator("{1}: {2}", new SimpleDateFormat("MMM-yyyy"), new DecimalFormat("0.00")));
    xYPlot.setRenderer(1, (XYItemRenderer)xYLineAndShapeRenderer2);
    JFreeChart jFreeChart = new JFreeChart("Sales Comparison Chart", (Plot)xYPlot);
    xYPlot.setDomainCrosshairVisible(true);
    xYPlot.setRangeCrosshairVisible(true);
    DateAxis dateAxis3 = (DateAxis)xYPlot.getDomainAxis();
    dateAxis3.setDateFormatOverride(new SimpleDateFormat("MMM-yyyy"));
    ChartUtilities.applyCurrentTheme(jFreeChart);
    return jFreeChart;
  }
  
  private static XYDataset createDataset2006() {
    TimeSeries timeSeries = new TimeSeries("Sales 2006");
    timeSeries.add((RegularTimePeriod)new Month(1, 2006), 100.0D);
    timeSeries.add((RegularTimePeriod)new Month(2, 2006), 102.3D);
    timeSeries.add((RegularTimePeriod)new Month(3, 2006), 105.7D);
    timeSeries.add((RegularTimePeriod)new Month(4, 2006), 104.2D);
    timeSeries.add((RegularTimePeriod)new Month(5, 2006), 114.7D);
    timeSeries.add((RegularTimePeriod)new Month(6, 2006), 121.7D);
    timeSeries.add((RegularTimePeriod)new Month(7, 2006), 155.6D);
    timeSeries.add((RegularTimePeriod)new Month(8, 2006), 143.2D);
    timeSeries.add((RegularTimePeriod)new Month(9, 2006), 131.9D);
    timeSeries.add((RegularTimePeriod)new Month(10, 2006), 120.0D);
    timeSeries.add((RegularTimePeriod)new Month(11, 2006), 109.9D);
    timeSeries.add((RegularTimePeriod)new Month(12, 2006), 99.6D);
    TimeSeriesCollection timeSeriesCollection = new TimeSeriesCollection();
    timeSeriesCollection.addSeries(timeSeries);
    timeSeriesCollection.setXPosition(TimePeriodAnchor.MIDDLE);
    return (XYDataset)timeSeriesCollection;
  }
  
  private static XYDataset createDataset2007() {
    TimeSeries timeSeries = new TimeSeries("Sales 2007");
    timeSeries.add((RegularTimePeriod)new Month(1, 2007), 163.9D);
    timeSeries.add((RegularTimePeriod)new Month(2, 2007), 163.8D);
    timeSeries.add((RegularTimePeriod)new Month(3, 2007), 162.0D);
    timeSeries.add((RegularTimePeriod)new Month(4, 2007), 167.1D);
    timeSeries.add((RegularTimePeriod)new Month(5, 2007), 170.0D);
    timeSeries.add((RegularTimePeriod)new Month(6, 2007), 175.7D);
    timeSeries.add((RegularTimePeriod)new Month(7, 2007), 171.9D);
    TimeSeriesCollection timeSeriesCollection = new TimeSeriesCollection();
    timeSeriesCollection.addSeries(timeSeries);
    timeSeriesCollection.setXPosition(TimePeriodAnchor.MIDDLE);
    return (XYDataset)timeSeriesCollection;
  }
  
  public static JPanel createDemoPanel() {
    JFreeChart jFreeChart = createChart();
    ChartPanel chartPanel = new ChartPanel(jFreeChart);
    chartPanel.setMouseWheelEnabled(true);
    return (JPanel)chartPanel;
  }
  
  public static void main(String[] paramArrayOfString) {
    CompareToPreviousYearDemo compareToPreviousYearDemo = new CompareToPreviousYearDemo("JFreeChart: CompareToPreviousYearDemo.java");
    compareToPreviousYearDemo.pack();
    RefineryUtilities.centerFrameOnScreen((Window)compareToPreviousYearDemo);
    compareToPreviousYearDemo.setVisible(true);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/jfreechart-1.0.19-demo.jar!/demo/CompareToPreviousYearDemo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */