/*     */ package fiji.plugin.trackmate.features.edges;
/*     */ 
/*     */ import fiji.plugin.trackmate.Dimension;
/*     */ import fiji.plugin.trackmate.FeatureModel;
/*     */ import fiji.plugin.trackmate.Model;
/*     */ import fiji.plugin.trackmate.Spot;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.swing.ImageIcon;
/*     */ import org.jgrapht.graph.DefaultWeightedEdge;
/*     */ import org.scijava.plugin.Plugin;
/*     */ 
/*     */ 
/*     */ 
/*     */ @Plugin(type = EdgeAnalyzer.class)
/*     */ public class EdgeAngleAnalyzer
/*     */   implements EdgeAnalyzer
/*     */ {
/*     */   private static final String KEY = "Edge angle";
/*     */   private static final String EDGE_ANGLE = "EDGE_ANGLE";
/*  25 */   private String INFO_TEXT = "angle between adjacent spots and the x-axis";
/*     */   private long processingTime;
/*     */   private int numThreads;
/*  28 */   private static final List<String> FEATURES = new ArrayList<>(1);
/*  29 */   private static final Map<String, Boolean> IS_INT = new HashMap<>(1);
/*  30 */   public static final Map<String, String> FEATURE_NAMES = new HashMap<>(1);
/*  31 */   public static final Map<String, String> FEATURE_SHORT_NAMES = new HashMap<>(1);
/*  32 */   public static final Map<String, Dimension> FEATURE_DIMENSIONS = new HashMap<>(1);
/*     */   
/*     */   static {
/*  35 */     FEATURES.add("EDGE_ANGLE");
/*  36 */     IS_INT.put("EDGE_ANGLE", Boolean.valueOf(false));
/*  37 */     FEATURE_NAMES.put("EDGE_ANGLE", "Link angle");
/*  38 */     FEATURE_SHORT_NAMES.put("EDGE_ANGLE", "Angle");
/*  39 */     FEATURE_DIMENSIONS.put("EDGE_ANGLE", Dimension.ANGLE);
/*     */   }
/*     */ 
/*     */   
/*     */   public long getProcessingTime() {
/*  44 */     return this.processingTime;
/*     */   }
/*     */ 
/*     */   
/*     */   public List<String> getFeatures() {
/*  49 */     return FEATURES;
/*     */   }
/*     */ 
/*     */   
/*     */   public Map<String, String> getFeatureShortNames() {
/*  54 */     return FEATURE_SHORT_NAMES;
/*     */   }
/*     */ 
/*     */   
/*     */   public Map<String, String> getFeatureNames() {
/*  59 */     return FEATURE_NAMES;
/*     */   }
/*     */ 
/*     */   
/*     */   public Map<String, Dimension> getFeatureDimensions() {
/*  64 */     return FEATURE_DIMENSIONS;
/*     */   }
/*     */ 
/*     */   
/*     */   public Map<String, Boolean> getIsIntFeature() {
/*  69 */     return Collections.unmodifiableMap(IS_INT);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isManualFeature() {
/*  74 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getInfoText() {
/*  79 */     return this.INFO_TEXT;
/*     */   }
/*     */ 
/*     */   
/*     */   public ImageIcon getIcon() {
/*  84 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getKey() {
/*  89 */     return "Edge angle";
/*     */   }
/*     */ 
/*     */   
/*     */   public String getName() {
/*  94 */     return "Edge angle";
/*     */   }
/*     */ 
/*     */   
/*     */   public int getNumThreads() {
/*  99 */     return this.numThreads;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setNumThreads() {
/* 104 */     this.numThreads = Runtime.getRuntime().availableProcessors();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setNumThreads(int numThreads) {
/* 109 */     this.numThreads = numThreads;
/*     */   }
/*     */ 
/*     */   
/*     */   public void process(Collection<DefaultWeightedEdge> edges, Model model) {
/* 114 */     FeatureModel fm = model.getFeatureModel();
/* 115 */     for (DefaultWeightedEdge edge : edges) {
/*     */       
/* 117 */       Spot source = model.getTrackModel().getEdgeSource(edge);
/* 118 */       Spot target = model.getTrackModel().getEdgeTarget(edge);
/*     */       
/* 120 */       double x1 = source.getDoublePosition(0);
/* 121 */       double y1 = source.getDoublePosition(1);
/* 122 */       double x2 = target.getDoublePosition(0);
/* 123 */       double y2 = target.getDoublePosition(1);
/*     */       
/* 125 */       double angle = Math.atan2(y2 - y1, x2 - x1);
/* 126 */       fm.putEdgeFeature(edge, "EDGE_ANGLE", Double.valueOf(angle));
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isLocal() {
/* 132 */     return true;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/RonnyTrackMate_-0.0.6-SNAPSHOT.jar!/fiji/plugin/trackmate/features/edges/EdgeAngleAnalyzer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */