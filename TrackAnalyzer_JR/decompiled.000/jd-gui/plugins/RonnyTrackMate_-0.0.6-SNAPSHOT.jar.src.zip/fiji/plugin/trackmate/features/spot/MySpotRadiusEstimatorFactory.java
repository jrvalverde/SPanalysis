/*     */ package fiji.plugin.trackmate.features.spot;
/*     */ 
/*     */ import fiji.plugin.trackmate.Dimension;
/*     */ import fiji.plugin.trackmate.Model;
/*     */ import fiji.plugin.trackmate.Spot;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.swing.ImageIcon;
/*     */ import net.imagej.ImgPlus;
/*     */ import net.imglib2.meta.view.HyperSliceImgPlus;
/*     */ import net.imglib2.type.NativeType;
/*     */ import net.imglib2.type.numeric.RealType;
/*     */ import org.scijava.plugin.Plugin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Plugin(type = SpotAnalyzerFactory.class, priority = 0.0D)
/*     */ public class MySpotRadiusEstimatorFactory<T extends RealType<T> & NativeType<T>>
/*     */   implements SpotAnalyzerFactory<T>
/*     */ {
/*     */   public static final String ESTIMATED_DIAMETER = "ESTIMATED_DIAMETER";
/*  34 */   public static final ArrayList<String> FEATURES = new ArrayList<>(1);
/*     */   
/*  36 */   public static final HashMap<String, String> FEATURE_NAMES = new HashMap<>(1);
/*     */   
/*  38 */   public static final HashMap<String, String> FEATURE_SHORT_NAMES = new HashMap<>(1);
/*     */   
/*  40 */   public static final HashMap<String, Dimension> FEATURE_DIMENSIONS = new HashMap<>(1);
/*     */   
/*  42 */   public static final Map<String, Boolean> IS_INT = new HashMap<>(1);
/*     */   public static final String KEY = "Spot radius estimator";
/*     */   
/*     */   static {
/*  46 */     FEATURES.add("ESTIMATED_DIAMETER");
/*  47 */     FEATURE_NAMES.put("ESTIMATED_DIAMETER", "Estimated diameter");
/*  48 */     FEATURE_SHORT_NAMES.put("ESTIMATED_DIAMETER", "Diam.");
/*  49 */     FEATURE_DIMENSIONS.put("ESTIMATED_DIAMETER", Dimension.LENGTH);
/*  50 */     IS_INT.put("ESTIMATED_DIAMETER", Boolean.FALSE);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MySpotRadiusEstimator<T> getAnalyzer(Model model, ImgPlus<T> img, int frame, int channel) {
/*  62 */     ImgPlus<T> imgC = HyperSliceImgPlus.fixChannelAxis(img, channel);
/*  63 */     ImgPlus<T> imgCT = HyperSliceImgPlus.fixTimeAxis(imgC, frame);
/*  64 */     Iterator<Spot> spots = model.getSpots().iterator(Integer.valueOf(frame), false);
/*  65 */     return (MySpotRadiusEstimator)new MySpotRadiusEstimator<>(imgCT, spots);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getKey() {
/*  71 */     return "Spot radius estimator";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public List<String> getFeatures() {
/*  77 */     return FEATURES;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, String> getFeatureShortNames() {
/*  83 */     return FEATURE_SHORT_NAMES;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, String> getFeatureNames() {
/*  89 */     return FEATURE_NAMES;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, Dimension> getFeatureDimensions() {
/*  95 */     return FEATURE_DIMENSIONS;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getInfoText() {
/* 101 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ImageIcon getIcon() {
/* 107 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/* 113 */     return "Spot radius estimator";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, Boolean> getIsIntFeature() {
/* 119 */     return IS_INT;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isManualFeature() {
/* 125 */     return false;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/RonnyTrackMate_-0.0.6-SNAPSHOT.jar!/fiji/plugin/trackmate/features/spot/MySpotRadiusEstimatorFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */