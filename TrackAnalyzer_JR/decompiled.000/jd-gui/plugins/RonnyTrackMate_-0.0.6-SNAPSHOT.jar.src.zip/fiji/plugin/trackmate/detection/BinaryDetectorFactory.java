/*     */ package fiji.plugin.trackmate.detection;
/*     */ 
/*     */ import fiji.plugin.trackmate.Model;
/*     */ import fiji.plugin.trackmate.Settings;
/*     */ import fiji.plugin.trackmate.gui.ConfigurationPanel;
/*     */ import fiji.plugin.trackmate.io.IOUtils;
/*     */ import fiji.plugin.trackmate.util.TMUtils;
/*     */ import ij.ImagePlus;
/*     */ import ij.plugin.filter.Analyzer;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.swing.ImageIcon;
/*     */ import net.imagej.ImgPlus;
/*     */ import net.imagej.ImgPlusMetadata;
/*     */ import net.imglib2.Interval;
/*     */ import net.imglib2.RandomAccessibleInterval;
/*     */ import net.imglib2.type.NativeType;
/*     */ import net.imglib2.type.numeric.RealType;
/*     */ import net.imglib2.view.IntervalView;
/*     */ import net.imglib2.view.Views;
/*     */ import org.jdom2.Element;
/*     */ import org.scijava.plugin.Plugin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Plugin(type = SpotDetectorFactory.class)
/*     */ public class BinaryDetectorFactory<T extends RealType<T> & NativeType<T>>
/*     */   implements SpotDetectorFactory<T>
/*     */ {
/*     */   public static final String DETECTOR_KEY = "BINARY_DETECTOR";
/*     */   public static final String NAME = "Binary detector";
/*     */   public static final String INFO_TEXT = "<html>This detector uses a binary image for determining objects.</html>";
/*     */   public static final String KEY_MIN = "KEY_MIN";
/*     */   public static final String KEY_MAX = "KEY_MAX";
/*     */   public static final String KEY_OPTIONS = "KEY_OPTIONS";
/*     */   public static final String KEY_CIRC_MIN = "CIRC_MIN";
/*     */   public static final String KEY_CIRC_MAX = "CIRC_MAX";
/*     */   public static final int DEFAULT_MIN = 10;
/*     */   public static final int DEFAULT_MAX = 10000;
/*     */   public static final int DEFAULT_OPTIONS = 1096;
/*     */   private static final double DEFAULT_CIRC_MAX = 1.0D;
/*     */   private static final double DEFAULT_CIRC_MIN = 0.0D;
/*     */   protected ImgPlus<T> img;
/*     */   protected Map<String, Object> settings;
/*     */   protected String errorMessage;
/*     */   private ImagePlus imp;
/*     */   
/*     */   public ImageIcon getIcon() {
/*  77 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getInfoText() {
/*  82 */     return "<html>This detector uses a binary image for determining objects.</html>";
/*     */   }
/*     */ 
/*     */   
/*     */   public String getKey() {
/*  87 */     return "BINARY_DETECTOR";
/*     */   }
/*     */ 
/*     */   
/*     */   public String getName() {
/*  92 */     return "Binary detector";
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean checkSettings(Map<String, Object> settings) {
/*  97 */     boolean ok = true;
/*  98 */     StringBuilder errorHolder = new StringBuilder();
/*  99 */     ok &= TMUtils.checkParameter(settings, "TARGET_CHANNEL", Integer.class, errorHolder);
/* 100 */     ok &= TMUtils.checkParameter(settings, "KEY_MIN", Integer.class, errorHolder);
/* 101 */     ok &= TMUtils.checkParameter(settings, "KEY_MAX", Integer.class, errorHolder);
/* 102 */     ok &= TMUtils.checkParameter(settings, "KEY_OPTIONS", Integer.class, errorHolder);
/* 103 */     ok &= TMUtils.checkParameter(settings, "CIRC_MAX", Double.class, errorHolder);
/* 104 */     ok &= TMUtils.checkParameter(settings, "CIRC_MIN", Double.class, errorHolder);
/* 105 */     List<String> mandatoryKeys = new ArrayList<>();
/* 106 */     mandatoryKeys.add("TARGET_CHANNEL");
/* 107 */     mandatoryKeys.add("KEY_MIN");
/* 108 */     mandatoryKeys.add("KEY_MAX");
/* 109 */     mandatoryKeys.add("KEY_OPTIONS");
/* 110 */     mandatoryKeys.add("CIRC_MAX");
/* 111 */     mandatoryKeys.add("CIRC_MIN");
/* 112 */     ok &= TMUtils.checkMapKeys(settings, mandatoryKeys, null, errorHolder);
/* 113 */     if (!ok) {
/* 114 */       this.errorMessage = errorHolder.toString();
/*     */     }
/* 116 */     return ok;
/*     */   }
/*     */ 
/*     */   
/*     */   public Map<String, Object> getDefaultSettings() {
/* 121 */     Map<String, Object> settings = new HashMap<>(4);
/* 122 */     settings.put("TARGET_CHANNEL", Integer.valueOf(1));
/* 123 */     settings.put("KEY_MIN", Integer.valueOf(10));
/* 124 */     settings.put("KEY_MAX", Integer.valueOf(10000));
/* 125 */     settings.put("CIRC_MAX", Double.valueOf(1.0D));
/* 126 */     settings.put("CIRC_MIN", Double.valueOf(0.0D));
/* 127 */     settings.put("KEY_OPTIONS", Integer.valueOf(1096));
/* 128 */     return settings;
/*     */   }
/*     */ 
/*     */   
/*     */   public SpotDetector<T> getDetector(Interval interval, int frame) {
/* 133 */     Integer min = (Integer)this.settings.get("KEY_MIN");
/* 134 */     Integer max = (Integer)this.settings.get("KEY_MAX");
/* 135 */     Integer options = (Integer)this.settings.get("KEY_OPTIONS");
/* 136 */     Double circMin = (Double)this.settings.get("CIRC_MIN");
/* 137 */     Double circMax = (Double)this.settings.get("CIRC_MAX");
/*     */     
/* 139 */     Integer measurements = Integer.valueOf(Analyzer.getMeasurements());
/* 140 */     if ((measurements.intValue() & 0x4000) == 0)
/* 141 */       measurements = Integer.valueOf(measurements.intValue() | 0x4000); 
/* 142 */     if ((measurements.intValue() & 0x2000) == 0)
/* 143 */       measurements = Integer.valueOf(measurements.intValue() | 0x2000); 
/* 144 */     if ((measurements.intValue() & 0x40) == 0)
/* 145 */       measurements = Integer.valueOf(measurements.intValue() | 0x40); 
/* 146 */     if ((measurements.intValue() & 0x10) == 0)
/* 147 */       measurements = Integer.valueOf(measurements.intValue() | 0x10); 
/* 148 */     RandomAccessibleInterval<T> imFrame = prepareFrameImg(frame);
/*     */     
/* 150 */     BinaryDetector<T> detector = new BinaryDetector<>(imFrame, min.intValue(), max.intValue(), circMin.doubleValue(), circMax.doubleValue(), options.intValue(), measurements.intValue());
/* 151 */     return detector;
/*     */   }
/*     */ 
/*     */   
/*     */   public ConfigurationPanel getDetectorConfigurationPanel(Settings settings, Model model) {
/* 156 */     this.imp = settings.imp;
/* 157 */     return new BinaryDetectorConfigurationPanel(this.imp, "<html>This detector uses a binary image for determining objects.</html>", "Binary detector", model);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getErrorMessage() {
/* 163 */     return this.errorMessage;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean marshall(Map<String, Object> settings, Element element) {
/* 168 */     StringBuilder errorHolder = new StringBuilder();
/* 169 */     boolean ok = (IOUtils.writeTargetChannel(settings, element, errorHolder) && 
/* 170 */       IOUtils.writeAttribute(settings, element, "KEY_MAX", Integer.class, errorHolder) && 
/* 171 */       IOUtils.writeAttribute(settings, element, "KEY_MIN", Integer.class, errorHolder) && 
/* 172 */       IOUtils.writeAttribute(settings, element, "KEY_OPTIONS", Integer.class, errorHolder));
/* 173 */     if (!ok) {
/* 174 */       this.errorMessage = errorHolder.toString();
/*     */     }
/* 176 */     return ok;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean setTarget(ImgPlus<T> img, Map<String, Object> settings) {
/* 181 */     this.img = img;
/* 182 */     this.settings = settings;
/* 183 */     return checkSettings(settings);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean unmarshall(Element element, Map<String, Object> settings) {
/* 188 */     settings.clear();
/* 189 */     StringBuilder errorHolder = new StringBuilder();
/* 190 */     boolean ok = true;
/* 191 */     ok &= IOUtils.readIntegerAttribute(element, settings, "KEY_MIN", errorHolder);
/* 192 */     ok &= IOUtils.readIntegerAttribute(element, settings, "KEY_MAX", errorHolder);
/* 193 */     ok &= IOUtils.readIntegerAttribute(element, settings, "KEY_OPTIONS", errorHolder);
/* 194 */     ok &= IOUtils.readIntegerAttribute(element, settings, "TARGET_CHANNEL", errorHolder);
/* 195 */     if (!ok) {
/* 196 */       this.errorMessage = errorHolder.toString();
/* 197 */       return false;
/*     */     } 
/* 199 */     return checkSettings(settings);
/*     */   }
/*     */   
/*     */   protected RandomAccessibleInterval<T> prepareFrameImg(int frame) {
/*     */     IntervalView intervalView;
/* 204 */     double[] calibration = TMUtils.getSpatialCalibration((ImgPlusMetadata)this.img);
/*     */     
/* 206 */     int cDim = TMUtils.findCAxisIndex((ImgPlusMetadata)this.img);
/* 207 */     if (cDim < 0) {
/*     */       
/* 209 */       ImgPlus<T> imgPlus = this.img;
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 214 */       int channel = ((Integer)this.settings.get("TARGET_CHANNEL")).intValue() - 1;
/* 215 */       intervalView = Views.hyperSlice((RandomAccessibleInterval)this.img, cDim, channel);
/*     */     } 
/*     */     
/* 218 */     int timeDim = TMUtils.findTAxisIndex((ImgPlusMetadata)this.img);
/* 219 */     if (timeDim >= 0) {
/*     */       
/* 221 */       if (cDim >= 0 && timeDim > cDim)
/*     */       {
/* 223 */         timeDim--;
/*     */       }
/* 225 */       intervalView = Views.hyperSlice((RandomAccessibleInterval)intervalView, timeDim, frame);
/*     */     } 
/*     */ 
/*     */     
/* 229 */     if (this.img.dimension(0) < 2L) {
/*     */       
/* 231 */       calibration[0] = calibration[1];
/* 232 */       calibration[1] = 1.0D;
/* 233 */       intervalView = Views.hyperSlice((RandomAccessibleInterval)intervalView, 0, 0L);
/*     */     } 
/* 235 */     if (this.img.dimension(1) < 2L)
/*     */     {
/* 237 */       intervalView = Views.hyperSlice((RandomAccessibleInterval)intervalView, 1, 0L);
/*     */     }
/*     */     
/* 240 */     return (RandomAccessibleInterval<T>)intervalView;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/RonnyTrackMate_-0.0.6-SNAPSHOT.jar!/fiji/plugin/trackmate/detection/BinaryDetectorFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */