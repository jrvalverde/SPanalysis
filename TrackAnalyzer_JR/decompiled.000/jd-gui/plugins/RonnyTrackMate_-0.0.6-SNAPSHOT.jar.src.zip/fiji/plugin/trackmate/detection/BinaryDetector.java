/*     */ package fiji.plugin.trackmate.detection;
/*     */ 
/*     */ import fiji.plugin.trackmate.Spot;
/*     */ import ij.ImagePlus;
/*     */ import ij.measure.ResultsTable;
/*     */ import ij.plugin.filter.ParticleAnalyzer;
/*     */ import ij.process.ImageProcessor;
/*     */ import java.util.ArrayList;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import net.imglib2.RandomAccessibleInterval;
/*     */ import net.imglib2.img.display.imagej.ImageJFunctions;
/*     */ import net.imglib2.type.NativeType;
/*     */ import net.imglib2.type.numeric.RealType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BinaryDetector<T extends RealType<T> & NativeType<T>>
/*     */   implements SpotDetector<T>
/*     */ {
/*     */   private static final String BASE_ERROR_MESSAGE = "LogDetector: ";
/*     */   private ImageProcessor ip;
/*     */   protected String errorMessage;
/*     */   private long processingTime;
/*     */   private ImagePlus imp;
/*  28 */   protected List<Spot> spots = new ArrayList<>();
/*     */   private int minSize;
/*     */   private int maxSize;
/*     */   private int options;
/*     */   private int measurements;
/*     */   private double circMin;
/*     */   private double circMax;
/*     */   
/*     */   public BinaryDetector(RandomAccessibleInterval<T> img, int minSize, int maxSize, double circMin, double circMax, int options, int measurements) {
/*  37 */     this.imp = ImageJFunctions.wrap(img, "");
/*  38 */     this.ip = this.imp.getProcessor();
/*  39 */     this.minSize = minSize;
/*  40 */     this.maxSize = maxSize;
/*  41 */     this.circMin = circMin;
/*  42 */     this.circMax = circMax;
/*  43 */     this.options = options;
/*  44 */     this.measurements = measurements;
/*     */   }
/*     */ 
/*     */   
/*     */   public List<Spot> getResult() {
/*  49 */     return this.spots;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean checkInput() {
/*  54 */     if (this.imp == null) {
/*  55 */       this.errorMessage = "LogDetector: Image is null.";
/*  56 */       return false;
/*     */     } 
/*  58 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getErrorMessage() {
/*  63 */     return this.errorMessage;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean process() {
/*  68 */     long start = System.currentTimeMillis();
/*  69 */     if (!this.ip.isInvertedLut())
/*  70 */       this.ip.invertLut(); 
/*  71 */     ResultsTable results = new ResultsTable();
/*  72 */     ParticleAnalyzer analyzer = new ParticleAnalyzer(this.options, this.measurements, results, this.minSize, this.maxSize, this.circMin, this.circMax);
/*  73 */     analyzer.setHideOutputImage(true);
/*  74 */     analyzer.analyze(this.imp, this.ip);
/*  75 */     ResultsTableToSpots(results);
/*  76 */     long end = System.currentTimeMillis();
/*  77 */     this.processingTime = end - start;
/*  78 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public long getProcessingTime() {
/*  83 */     return this.processingTime;
/*     */   }
/*     */   
/*     */   private void ResultsTableToSpots(ResultsTable rt) {
/*  87 */     Map<String, double[]> table = (Map)new LinkedHashMap<>();
/*  88 */     String[] headings = rt.getHeadings();
/*  89 */     for (int i = 0; i < headings.length; i++) {
/*  90 */       int ret = rt.getColumnIndex(headings[i]);
/*  91 */       if (ret != -1) {
/*  92 */         double[] col = rt.getColumnAsDoubles(ret);
/*  93 */         if (col != null)
/*  94 */           table.put(headings[i], col); 
/*     */       } 
/*  96 */     }  for (int j = 0; j < rt.getCounter(); j++) {
/*  97 */       double radius = (((double[])table.get("Feret"))[j] + ((double[])table.get("MinFeret"))[j]) / 4.0D;
/*  98 */       Spot spot = new Spot(((double[])table.get("XM"))[j], ((double[])table.get("YM"))[j], 0.0D, radius, ((double[])table.get("Max"))[j]);
/*  99 */       spot.putFeature("Area", Double.valueOf(((double[])table.get("Area"))[j]));
/* 100 */       spot.putFeature("Circ.", Double.valueOf(((double[])table.get("Circ."))[j]));
/* 101 */       this.spots.add(spot);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/RonnyTrackMate_-0.0.6-SNAPSHOT.jar!/fiji/plugin/trackmate/detection/BinaryDetector.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */