/*     */ package fiji.plugin.trackmate.detection;
/*     */ 
/*     */ import fiji.plugin.trackmate.Logger;
/*     */ import fiji.plugin.trackmate.Model;
/*     */ import fiji.plugin.trackmate.Settings;
/*     */ import fiji.plugin.trackmate.Spot;
/*     */ import fiji.plugin.trackmate.SpotCollection;
/*     */ import fiji.plugin.trackmate.TrackMate;
/*     */ import fiji.plugin.trackmate.gui.ConfigurationPanel;
/*     */ import fiji.plugin.trackmate.gui.TrackMateWizard;
/*     */ import fiji.plugin.trackmate.util.JLabelLogger;
/*     */ import fiji.util.NumberParser;
/*     */ import ij.ImagePlus;
/*     */ import java.awt.Component;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Font;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JSlider;
/*     */ import javax.swing.JTextField;
/*     */ import javax.swing.SpringLayout;
/*     */ import javax.swing.event.ChangeEvent;
/*     */ import javax.swing.event.ChangeListener;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BinaryDetectorConfigurationPanel
/*     */   extends ConfigurationPanel
/*     */ {
/*     */   private ImagePlus imp;
/*     */   private Model model;
/*     */   private Logger localLogger;
/*     */   private int options;
/*     */   private static final long serialVersionUID = 1L;
/*     */   private JButton btnPreview;
/*     */   private JTextField textFieldMin;
/*     */   private JTextField textFieldMax;
/*     */   private JSlider sliderChannel;
/*     */   private JTextField textFieldCircMin;
/*     */   private JTextField textFieldCircMax;
/*     */   
/*     */   public BinaryDetectorConfigurationPanel(ImagePlus imp, String infoText, String detectorName, Model model) {
/*  54 */     this.imp = imp;
/*  55 */     this.model = model;
/*  56 */     SpringLayout springLayout = new SpringLayout();
/*  57 */     setLayout(springLayout);
/*     */     
/*  59 */     JLabel lblHelpText = new JLabel();
/*  60 */     springLayout.putConstraint("North", lblHelpText, 35, "North", (Component)this);
/*  61 */     springLayout.putConstraint("West", lblHelpText, 10, "West", (Component)this);
/*  62 */     lblHelpText.setFont(TrackMateWizard.FONT.deriveFont(2));
/*  63 */     lblHelpText.setText(infoText.replace("<br>", "").replace("<p>", "<p align=\"justify\">").replace("<html>", "<html><p align=\"justify\">"));
/*  64 */     add(lblHelpText);
/*     */     
/*  66 */     JLabel lblMaximumSize = new JLabel("Maximum Size");
/*  67 */     springLayout.putConstraint("West", lblMaximumSize, 0, "West", lblHelpText);
/*  68 */     lblMaximumSize.setFont(TrackMateWizard.FONT);
/*  69 */     add(lblMaximumSize);
/*     */     
/*  71 */     JLabel lblSettings = new JLabel("Settings for: " + detectorName);
/*  72 */     springLayout.putConstraint("West", lblSettings, 0, "West", lblHelpText);
/*  73 */     springLayout.putConstraint("South", lblSettings, -8, "North", lblHelpText);
/*  74 */     lblSettings.setFont(TrackMateWizard.BIG_FONT);
/*  75 */     add(lblSettings);
/*     */     
/*  77 */     this.btnPreview = new JButton("Preview");
/*  78 */     springLayout.putConstraint("West", this.btnPreview, 0, "West", lblHelpText);
/*  79 */     this.btnPreview.addActionListener(new ActionListener() {
/*     */           public void actionPerformed(ActionEvent evt) {
/*  81 */             BinaryDetectorConfigurationPanel.this.preview();
/*     */           }
/*     */         });
/*  84 */     add(this.btnPreview);
/*     */     
/*  86 */     JLabel lblSegmentInChannel = new JLabel("Segment in channel:");
/*  87 */     springLayout.putConstraint("North", this.btnPreview, 19, "South", lblSegmentInChannel);
/*  88 */     springLayout.putConstraint("West", lblSegmentInChannel, 0, "West", lblHelpText);
/*  89 */     springLayout.putConstraint("East", lblSegmentInChannel, 116, "West", (Component)this);
/*  90 */     lblSegmentInChannel.setFont(TrackMateWizard.SMALL_FONT);
/*  91 */     add(lblSegmentInChannel);
/*     */     
/*  93 */     final JLabel labelChannel = new JLabel("1");
/*  94 */     springLayout.putConstraint("North", labelChannel, 177, "North", (Component)this);
/*  95 */     springLayout.putConstraint("East", labelChannel, -85, "East", (Component)this);
/*  96 */     springLayout.putConstraint("North", lblSegmentInChannel, 0, "North", labelChannel);
/*  97 */     labelChannel.setHorizontalAlignment(0);
/*  98 */     labelChannel.setFont(TrackMateWizard.SMALL_FONT);
/*  99 */     add(labelChannel);
/*     */     
/* 101 */     JLabelLogger labelLogger = new JLabelLogger();
/* 102 */     springLayout.putConstraint("North", (Component)labelLogger, 138, "South", lblHelpText);
/* 103 */     springLayout.putConstraint("West", (Component)labelLogger, 0, "West", lblHelpText);
/* 104 */     add((Component)labelLogger);
/*     */     
/* 106 */     JLabel lblMinimumSize = new JLabel("Minimum Size");
/* 107 */     springLayout.putConstraint("North", lblMinimumSize, 25, "South", lblHelpText);
/* 108 */     springLayout.putConstraint("West", lblMinimumSize, 0, "West", lblHelpText);
/* 109 */     springLayout.putConstraint("North", lblMaximumSize, 20, "South", lblMinimumSize);
/* 110 */     lblMinimumSize.setFont(new Font("Arial", 0, 10));
/* 111 */     add(lblMinimumSize);
/*     */     
/* 113 */     this.textFieldMin = new JTextField();
/* 114 */     springLayout.putConstraint("North", this.textFieldMin, -6, "North", lblMinimumSize);
/* 115 */     springLayout.putConstraint("West", this.textFieldMin, 20, "East", lblMinimumSize);
/* 116 */     springLayout.putConstraint("East", this.textFieldMin, -150, "East", (Component)this);
/* 117 */     this.textFieldMin.setFont(TrackMateWizard.FONT);
/* 118 */     this.textFieldMin.setHorizontalAlignment(11);
/* 119 */     this.textFieldMin.setText("10");
/* 120 */     add(this.textFieldMin);
/* 121 */     this.textFieldMin.setColumns(10);
/*     */     
/* 123 */     this.textFieldMax = new JTextField();
/* 124 */     springLayout.putConstraint("North", this.textFieldMax, -6, "North", lblMaximumSize);
/* 125 */     springLayout.putConstraint("West", this.textFieldMax, 0, "West", this.textFieldMin);
/* 126 */     springLayout.putConstraint("East", this.textFieldMax, -150, "East", (Component)this);
/* 127 */     this.textFieldMax.setFont(TrackMateWizard.FONT);
/* 128 */     this.textFieldMax.setHorizontalAlignment(11);
/* 129 */     this.textFieldMax.setText("10000");
/* 130 */     add(this.textFieldMax);
/* 131 */     this.textFieldMax.setColumns(10);
/*     */     
/* 133 */     this.sliderChannel = new JSlider();
/* 134 */     springLayout.putConstraint("North", this.sliderChannel, 173, "North", (Component)this);
/* 135 */     springLayout.putConstraint("South", this.sliderChannel, -259, "South", (Component)this);
/* 136 */     springLayout.putConstraint("East", this.sliderChannel, -121, "East", (Component)this);
/* 137 */     springLayout.putConstraint("West", labelChannel, 2, "East", this.sliderChannel);
/* 138 */     springLayout.putConstraint("West", this.sliderChannel, 6, "East", lblSegmentInChannel);
/* 139 */     this.sliderChannel.addChangeListener(new ChangeListener() {
/*     */           public void stateChanged(ChangeEvent arg0) {
/* 141 */             labelChannel.setText(BinaryDetectorConfigurationPanel.this.sliderChannel.getValue());
/*     */           }
/*     */         });
/* 144 */     add(this.sliderChannel);
/*     */     
/* 146 */     JLabel lblCircularity = new JLabel("Circularity");
/* 147 */     springLayout.putConstraint("West", lblCircularity, 0, "West", lblHelpText);
/* 148 */     lblCircularity.setFont(TrackMateWizard.FONT);
/* 149 */     add(lblCircularity);
/*     */     
/* 151 */     this.textFieldCircMin = new JTextField();
/* 152 */     springLayout.putConstraint("West", this.textFieldCircMin, 39, "East", lblCircularity);
/* 153 */     springLayout.putConstraint("East", this.textFieldCircMin, -147, "East", (Component)this);
/* 154 */     springLayout.putConstraint("North", lblCircularity, 6, "North", this.textFieldCircMin);
/* 155 */     springLayout.putConstraint("North", this.textFieldCircMin, 6, "South", this.textFieldMax);
/* 156 */     this.textFieldCircMin.setMaximumSize(new Dimension(100, 30));
/* 157 */     this.textFieldCircMin.setMinimumSize(new Dimension(50, 28));
/* 158 */     this.textFieldCircMin.setHorizontalAlignment(0);
/* 159 */     this.textFieldCircMin.setText("0.00");
/* 160 */     this.textFieldCircMin.setFont(TrackMateWizard.FONT);
/* 161 */     add(this.textFieldCircMin);
/* 162 */     this.textFieldCircMin.setColumns(10);
/*     */     
/* 164 */     this.textFieldCircMax = new JTextField();
/* 165 */     springLayout.putConstraint("North", this.textFieldCircMax, -6, "North", lblCircularity);
/* 166 */     springLayout.putConstraint("West", this.textFieldCircMax, 0, "West", labelChannel);
/* 167 */     springLayout.putConstraint("East", this.textFieldCircMax, -56, "East", (Component)this);
/* 168 */     this.textFieldCircMax.setMinimumSize(new Dimension(50, 28));
/* 169 */     this.textFieldCircMax.setMaximumSize(new Dimension(100, 30));
/* 170 */     this.textFieldCircMax.setHorizontalAlignment(0);
/* 171 */     this.textFieldCircMax.setFont(TrackMateWizard.FONT);
/* 172 */     this.textFieldCircMax.setText("1.00");
/* 173 */     add(this.textFieldCircMax);
/* 174 */     this.textFieldCircMax.setColumns(10);
/*     */     
/* 176 */     JLabel lblStrich = new JLabel("-");
/* 177 */     springLayout.putConstraint("North", lblStrich, -3, "North", lblCircularity);
/* 178 */     springLayout.putConstraint("West", lblStrich, 6, "East", this.textFieldCircMin);
/* 179 */     add(lblStrich);
/*     */ 
/*     */ 
/*     */     
/* 183 */     int n_channels = imp.getNChannels();
/*     */     
/* 185 */     if (n_channels <= 1) {
/* 186 */       labelChannel.setVisible(false);
/* 187 */       lblSegmentInChannel.setVisible(false);
/* 188 */       this.sliderChannel.setVisible(false);
/*     */     } else {
/* 190 */       labelChannel.setVisible(true);
/* 191 */       lblSegmentInChannel.setVisible(true);
/* 192 */       this.sliderChannel.setVisible(true);
/*     */     } 
/* 194 */     this.localLogger = labelLogger.getLogger();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, Object> getSettings() {
/* 207 */     HashMap<String, Object> settings = new HashMap<>(4);
/* 208 */     settings.put("KEY_OPTIONS", Integer.valueOf(this.options));
/* 209 */     settings.put("KEY_MIN", Integer.valueOf(NumberParser.parseInteger(this.textFieldMin.getText())));
/* 210 */     settings.put("KEY_MAX", Integer.valueOf(NumberParser.parseInteger(this.textFieldMax.getText())));
/* 211 */     settings.put("TARGET_CHANNEL", Integer.valueOf(this.sliderChannel.getValue()));
/* 212 */     settings.put("CIRC_MIN", Double.valueOf(NumberParser.parseDouble(this.textFieldCircMin.getText())));
/* 213 */     settings.put("CIRC_MAX", Double.valueOf(NumberParser.parseDouble(this.textFieldCircMax.getText())));
/* 214 */     return settings;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setSettings(Map<String, Object> settings) {
/* 219 */     this.textFieldMin.setText(String.valueOf(settings.get("KEY_MIN")));
/* 220 */     this.textFieldMax.setText(String.valueOf(settings.get("KEY_MAX")));
/* 221 */     this.options = ((Integer)settings.get("KEY_OPTIONS")).intValue();
/* 222 */     this.sliderChannel.setValue(((Integer)settings.get("TARGET_CHANNEL")).intValue());
/* 223 */     this.textFieldCircMin.setText(String.valueOf(settings.get("CIRC_MIN")));
/* 224 */     this.textFieldCircMax.setText(String.valueOf(settings.get("CIRC_MAX")));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected SpotDetectorFactory<?> getDetectorFactory() {
/* 237 */     return new BinaryDetectorFactory();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void preview() {
/* 245 */     this.btnPreview.setEnabled(false);
/* 246 */     (new Thread("TrackMate preview detection thread")
/*     */       {
/*     */         public void run()
/*     */         {
/* 250 */           Settings settings = new Settings();
/* 251 */           settings.setFrom(BinaryDetectorConfigurationPanel.this.imp);
/* 252 */           int frame = BinaryDetectorConfigurationPanel.this.imp.getFrame() - 1;
/* 253 */           settings.tstart = frame;
/* 254 */           settings.tend = frame;
/*     */           
/* 256 */           settings.detectorFactory = BinaryDetectorConfigurationPanel.this.getDetectorFactory();
/* 257 */           settings.detectorSettings = BinaryDetectorConfigurationPanel.this.getSettings();
/*     */           
/* 259 */           TrackMate trackmate = new TrackMate(settings);
/* 260 */           trackmate.getModel().setLogger(BinaryDetectorConfigurationPanel.this.localLogger);
/*     */           
/* 262 */           boolean detectionOk = trackmate.execDetection();
/* 263 */           if (!detectionOk) {
/* 264 */             BinaryDetectorConfigurationPanel.this.localLogger.error(trackmate.getErrorMessage());
/*     */             return;
/*     */           } 
/* 267 */           BinaryDetectorConfigurationPanel.this.localLogger.log("Found " + trackmate.getModel().getSpots().getNSpots(false) + " spots.");
/*     */ 
/*     */           
/* 270 */           SpotCollection newspots = trackmate.getModel().getSpots();
/* 271 */           Iterator<Spot> it = newspots.iterator(Integer.valueOf(frame), false);
/* 272 */           ArrayList<Spot> spotsToCopy = new ArrayList<>(newspots.getNSpots(frame, false));
/* 273 */           while (it.hasNext()) {
/* 274 */             spotsToCopy.add(it.next());
/*     */           }
/*     */           
/* 277 */           BinaryDetectorConfigurationPanel.this.model.getSpots().put(frame, spotsToCopy);
/*     */           
/* 279 */           for (Spot spot : spotsToCopy) {
/* 280 */             spot.putFeature("VISIBILITY", SpotCollection.ONE);
/*     */           }
/*     */           
/* 283 */           BinaryDetectorConfigurationPanel.this.model.setSpots(BinaryDetectorConfigurationPanel.this.model.getSpots(), true);
/*     */           
/* 285 */           BinaryDetectorConfigurationPanel.this.btnPreview.setEnabled(true);
/*     */         }
/* 287 */       }).start();
/*     */   }
/*     */   
/*     */   public void clean() {}
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/RonnyTrackMate_-0.0.6-SNAPSHOT.jar!/fiji/plugin/trackmate/detection/BinaryDetectorConfigurationPanel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */