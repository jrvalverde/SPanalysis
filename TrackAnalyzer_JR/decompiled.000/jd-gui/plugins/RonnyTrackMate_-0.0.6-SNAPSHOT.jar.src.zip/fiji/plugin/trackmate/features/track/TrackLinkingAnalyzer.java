/*     */ package fiji.plugin.trackmate.features.track;
/*     */ 
/*     */ import fiji.plugin.trackmate.Dimension;
/*     */ import fiji.plugin.trackmate.FeatureModel;
/*     */ import fiji.plugin.trackmate.Model;
/*     */ import fiji.plugin.trackmate.Spot;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ArrayBlockingQueue;
/*     */ import javax.swing.ImageIcon;
/*     */ import net.imglib2.multithreading.SimpleMultiThreading;
/*     */ import org.jgrapht.graph.DefaultWeightedEdge;
/*     */ import org.scijava.plugin.Plugin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Plugin(type = TrackAnalyzer.class)
/*     */ public class TrackLinkingAnalyzer
/*     */   implements TrackAnalyzer
/*     */ {
/*     */   public static final String KEY = "Track linking";
/*     */   public static final String TRACK_MEAN_LINK_COST = "TRACK_MEAN_LINK_COST";
/*     */   public static final String TRACK_LENGTH = "TRACK_LENGTH";
/*     */   public static final String TRACK_ANGLE = "TRACK_ANGLE";
/*     */   private static final int numFeatures = 3;
/*  41 */   public static final List<String> FEATURES = new ArrayList<>(3);
/*     */   
/*  43 */   public static final Map<String, String> FEATURE_NAMES = new HashMap<>(3);
/*     */   
/*  45 */   public static final Map<String, String> FEATURE_SHORT_NAMES = new HashMap<>(3);
/*     */   
/*  47 */   public static final Map<String, Dimension> FEATURE_DIMENSIONS = new HashMap<>(3);
/*     */   
/*  49 */   public static final Map<String, Boolean> IS_INT = new HashMap<>(3);
/*     */   
/*     */   private int numThreads;
/*     */   
/*     */   private long processingTime;
/*     */   
/*     */   static {
/*  56 */     FEATURES.add("TRACK_MEAN_LINK_COST");
/*  57 */     FEATURES.add("TRACK_LENGTH");
/*  58 */     FEATURES.add("TRACK_ANGLE");
/*     */     
/*  60 */     FEATURE_NAMES.put("TRACK_MEAN_LINK_COST", "Mean linking cost");
/*  61 */     FEATURE_NAMES.put("TRACK_LENGTH", "Track length");
/*  62 */     FEATURE_NAMES.put("TRACK_ANGLE", "Track angle");
/*     */     
/*  64 */     FEATURE_SHORT_NAMES.put("TRACK_MEAN_LINK_COST", "Mean linking cost");
/*  65 */     FEATURE_SHORT_NAMES.put("TRACK_LENGTH", "Track length");
/*  66 */     FEATURE_SHORT_NAMES.put("TRACK_ANGLE", "Track angle");
/*     */     
/*  68 */     FEATURE_DIMENSIONS.put("TRACK_MEAN_LINK_COST", Dimension.NONE);
/*  69 */     FEATURE_DIMENSIONS.put("TRACK_LENGTH", Dimension.LENGTH);
/*  70 */     FEATURE_DIMENSIONS.put("TRACK_ANGLE", Dimension.NONE);
/*     */     
/*  72 */     IS_INT.put("TRACK_MEAN_LINK_COST", Boolean.FALSE);
/*  73 */     IS_INT.put("TRACK_LENGTH", Boolean.FALSE);
/*  74 */     IS_INT.put("TRACK_ANGLE", Boolean.FALSE);
/*     */   }
/*     */   
/*     */   public TrackLinkingAnalyzer() {
/*  78 */     setNumThreads();
/*     */   }
/*     */ 
/*     */   
/*     */   public List<String> getFeatures() {
/*  83 */     return FEATURES;
/*     */   }
/*     */ 
/*     */   
/*     */   public Map<String, String> getFeatureShortNames() {
/*  88 */     return FEATURE_SHORT_NAMES;
/*     */   }
/*     */ 
/*     */   
/*     */   public Map<String, String> getFeatureNames() {
/*  93 */     return FEATURE_NAMES;
/*     */   }
/*     */ 
/*     */   
/*     */   public Map<String, Dimension> getFeatureDimensions() {
/*  98 */     return FEATURE_DIMENSIONS;
/*     */   }
/*     */ 
/*     */   
/*     */   public Map<String, Boolean> getIsIntFeature() {
/* 103 */     return IS_INT;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isManualFeature() {
/* 108 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getInfoText() {
/* 113 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public ImageIcon getIcon() {
/* 118 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getKey() {
/* 123 */     return "Track linking";
/*     */   }
/*     */ 
/*     */   
/*     */   public String getName() {
/* 128 */     return "Track linking";
/*     */   }
/*     */ 
/*     */   
/*     */   public int getNumThreads() {
/* 133 */     return this.numThreads;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setNumThreads() {
/* 138 */     this.numThreads = Runtime.getRuntime().availableProcessors();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setNumThreads(int numThreads) {
/* 143 */     this.numThreads = numThreads;
/*     */   }
/*     */ 
/*     */   
/*     */   public long getProcessingTime() {
/* 148 */     return this.processingTime;
/*     */   }
/*     */ 
/*     */   
/*     */   public void process(Collection<Integer> trackIDs, final Model model) {
/* 153 */     if (trackIDs.isEmpty())
/*     */       return; 
/* 155 */     final ArrayBlockingQueue<Integer> queue = new ArrayBlockingQueue<>(trackIDs.size(), false, trackIDs);
/* 156 */     final FeatureModel fm = model.getFeatureModel();
/*     */     
/* 158 */     Thread[] threads = SimpleMultiThreading.newThreads(this.numThreads);
/* 159 */     for (int i = 0; i < threads.length; i++) {
/* 160 */       threads[i] = new Thread("TrackLinkingAnalyzer thread " + i)
/*     */         {
/*     */           public void run()
/*     */           {
/*     */             Integer trackID;
/* 165 */             while ((trackID = queue.poll()) != null) {
/* 166 */               Set<DefaultWeightedEdge> track = model.getTrackModel().trackEdges(trackID);
/*     */               
/* 168 */               double mean = 0.0D;
/* 169 */               double sum = 0.0D;
/* 170 */               double length = 0.0D;
/*     */               
/* 172 */               for (DefaultWeightedEdge edge : track) {
/*     */                 
/* 174 */                 Spot source = model.getTrackModel().getEdgeSource(edge);
/* 175 */                 Spot target = model.getTrackModel().getEdgeTarget(edge);
/*     */                 
/* 177 */                 length += Math.sqrt(source.squareDistanceTo(target));
/* 178 */                 sum += model.getTrackModel().getEdgeWeight(edge);
/*     */               } 
/* 180 */               mean = sum / track.size();
/*     */               
/* 182 */               fm.putTrackFeature(trackID, "TRACK_MEAN_LINK_COST", Double.valueOf(mean));
/* 183 */               fm.putTrackFeature(trackID, "TRACK_LENGTH", Double.valueOf(length));
/*     */               
/* 185 */               Set<Spot> spots = model.getTrackModel().trackSpots(trackID);
/* 186 */               Comparator<Spot> comparator = Spot.frameComparator;
/* 187 */               List<Spot> sorted = new ArrayList<>(spots);
/* 188 */               Collections.sort(sorted, comparator);
/*     */               
/* 190 */               Spot first = sorted.get(0);
/* 191 */               Spot last = sorted.get(sorted.size() - 1);
/* 192 */               double x1 = first.getDoublePosition(0);
/* 193 */               double y1 = first.getDoublePosition(1);
/* 194 */               double x2 = last.getDoublePosition(0);
/* 195 */               double y2 = last.getDoublePosition(1);
/*     */               
/* 197 */               double angle = Math.atan2(y2 - y1, x2 - x1);
/*     */               
/* 199 */               fm.putTrackFeature(trackID, "TRACK_ANGLE", Double.valueOf(angle));
/*     */             } 
/*     */           }
/*     */         };
/*     */     } 
/*     */ 
/*     */     
/* 206 */     long start = System.currentTimeMillis();
/* 207 */     SimpleMultiThreading.startAndJoin(threads);
/* 208 */     long end = System.currentTimeMillis();
/* 209 */     this.processingTime = end - start;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isLocal() {
/* 214 */     return true;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/RonnyTrackMate_-0.0.6-SNAPSHOT.jar!/fiji/plugin/trackmate/features/track/TrackLinkingAnalyzer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */