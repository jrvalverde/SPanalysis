/*     */ package fiji.plugin.trackmate.features.spot;
/*     */ 
/*     */ import fiji.plugin.trackmate.Spot;
/*     */ import fiji.plugin.trackmate.util.SpotNeighborhood;
/*     */ import fiji.plugin.trackmate.util.SpotNeighborhoodCursor;
/*     */ import java.util.Iterator;
/*     */ import net.imagej.ImgPlus;
/*     */ import net.imglib2.type.numeric.RealType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MySpotRadiusEstimator<T extends RealType<T>>
/*     */   extends IndependentSpotFeatureAnalyzer<T>
/*     */ {
/*     */   private static final double MIN_DIAMETER_RATIO = 0.019999999552965164D;
/*     */   private static final double MAX_DIAMETER_RATIO = 10.0D;
/*  20 */   protected int nDiameters = 50;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MySpotRadiusEstimator(ImgPlus<T> img, Iterator<Spot> spots) {
/*  36 */     super(img, spots);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void process(Spot spot) {
/*  43 */     double bestDiameter, radius = spot.getFeature("RADIUS").doubleValue();
/*  44 */     double[] diameters = prepareDiameters(radius * 2.0D, this.nDiameters);
/*  45 */     double[] r2 = new double[this.nDiameters];
/*  46 */     for (int i = 0; i < r2.length; i++) {
/*  47 */       r2[i] = diameters[i] * diameters[i] / 4.0D;
/*     */     }
/*     */ 
/*     */     
/*  51 */     double[] ring_intensities = new double[this.nDiameters];
/*  52 */     int[] ring_volumes = new int[this.nDiameters];
/*     */ 
/*     */     
/*  55 */     Spot tmpSpot = new Spot(spot);
/*  56 */     tmpSpot.putFeature("RADIUS", Double.valueOf(diameters[this.nDiameters - 1] / 2.0D));
/*     */     
/*  58 */     SpotNeighborhood<T> neighborhood = new SpotNeighborhood(tmpSpot, this.img);
/*  59 */     SpotNeighborhoodCursor<T> cursor = neighborhood.cursor();
/*     */ 
/*     */     
/*  62 */     while (cursor.hasNext()) {
/*  63 */       cursor.fwd();
/*  64 */       double d2 = cursor.getDistanceSquared();
/*  65 */       double val = cursor.get().getRealDouble();
/*  66 */       for (int n = 0; n < this.nDiameters && d2 > r2[n]; n++) {
/*  67 */         ring_intensities[n] = ring_intensities[n] + val;
/*  68 */         ring_volumes[n] = ring_volumes[n] + 1;
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/*  73 */     double[] mean_intensities = new double[diameters.length];
/*  74 */     for (int j = 0; j < mean_intensities.length; j++) {
/*  75 */       mean_intensities[j] = ring_intensities[j] / ring_volumes[j];
/*     */     }
/*     */ 
/*     */     
/*  79 */     double[] contrasts = new double[diameters.length - 1];
/*  80 */     for (int k = 0; k < contrasts.length - 1; k++) {
/*  81 */       contrasts[k + 1] = -(mean_intensities[k + 1] - mean_intensities[k]);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  87 */     double maxConstrast = Double.NEGATIVE_INFINITY;
/*  88 */     int maxIndex = 0;
/*  89 */     for (int m = 0; m < contrasts.length; m++) {
/*  90 */       if (contrasts[m] > maxConstrast) {
/*  91 */         maxConstrast = contrasts[m];
/*  92 */         maxIndex = m;
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/*  97 */     if (1 >= maxIndex || contrasts.length - 1 == maxIndex) {
/*  98 */       bestDiameter = diameters[maxIndex];
/*     */     } else {
/* 100 */       bestDiameter = quadratic1DInterpolation(diameters[maxIndex - 1], contrasts[maxIndex - 1], diameters[maxIndex], contrasts[maxIndex], diameters[maxIndex + 1], contrasts[maxIndex + 1]);
/*     */     } 
/* 102 */     spot.putFeature("ESTIMATED_DIAMETER", Double.valueOf(bestDiameter));
/*     */   }
/*     */   
/*     */   private static final double quadratic1DInterpolation(double x1, double y1, double x2, double y2, double x3, double y3) {
/* 106 */     double d2 = 2.0D * ((y3 - y2) / (x3 - x2) - (y2 - y1) / (x2 - x1)) / (x3 - x1);
/* 107 */     if (d2 == 0.0D) {
/* 108 */       return x2;
/*     */     }
/* 110 */     double d1 = (y3 - y2) / (x3 - x2) - d2 / 2.0D * (x3 - x2);
/* 111 */     return x2 - d1 / d2;
/*     */   }
/*     */ 
/*     */   
/*     */   private static final double[] prepareDiameters(double centralDiameter, int nDiameters) {
/* 116 */     double[] diameters = new double[nDiameters];
/* 117 */     for (int i = 0; i < diameters.length; i++) {
/* 118 */       diameters[i] = centralDiameter * (0.019999999552965164D + i * 9.980000000447035D / (nDiameters - 1));
/*     */     }
/* 120 */     return diameters;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/RonnyTrackMate_-0.0.6-SNAPSHOT.jar!/fiji/plugin/trackmate/features/spot/MySpotRadiusEstimator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */