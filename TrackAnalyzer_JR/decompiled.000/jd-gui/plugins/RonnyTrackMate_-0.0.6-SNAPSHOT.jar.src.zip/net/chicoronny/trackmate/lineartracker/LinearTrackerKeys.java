package net.chicoronny.trackmate.lineartracker;

public class LinearTrackerKeys {
  public static final String XML_ATTRIBUTE_TRACKER_NAME = "TRACKER_NAME";
  
  public static final String KEY_INITIAL_DISTANCE = "INITIAL_DISTANCE";
  
  public static final String KEY_SUCCEEDING_DISTANCE = "SUCCEEDING_DISTANCE";
  
  public static final String KEY_STICK_RADIUS = "STICK_RADIUS";
  
  public static final String KEY_MAX_COST = "MAX_COST";
  
  public static final String KEY_ESTIMATE_RADIUS = "ESTIMATE_RADIUS";
  
  public static final double DEFAULT_INITIAL_DISTANCE = 10.0D;
  
  public static final double DEFAULT_SUCCEEDING_DISTANCE = 5.0D;
  
  public static final double DEFAULT_STICK_RADIUS = 2.0D;
  
  public static final double DEFAULT_MAX_COST = 100.0D;
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/RonnyTrackMate_-0.0.6-SNAPSHOT.jar!/net/chicoronny/trackmate/lineartracker/LinearTrackerKeys.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */