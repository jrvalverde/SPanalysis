/*     */ package net.chicoronny.trackmate.lineartracker;
/*     */ 
/*     */ import fiji.plugin.trackmate.gui.ConfigurationPanel;
/*     */ import fiji.plugin.trackmate.gui.TrackMateWizard;
/*     */ import fiji.plugin.trackmate.gui.panels.components.JNumericTextField;
/*     */ import java.awt.Component;
/*     */ import java.awt.Dimension;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import javax.swing.JCheckBox;
/*     */ import javax.swing.JLabel;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LinearTrackerSettingsPanel
/*     */   extends ConfigurationPanel
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private final String trackerName;
/*     */   private final String spaceUnits;
/*     */   private JLabel labelTracker;
/*     */   private JLabel labelTrackerDescription;
/*     */   private final String infoText;
/*     */   private JLabel labelUnits;
/*     */   private JNumericTextField initDistField;
/*     */   private JNumericTextField initSuccField;
/*     */   private JLabel labelUnit2;
/*     */   private JNumericTextField initStickField;
/*     */   private JLabel labelUnit3;
/*     */   private JNumericTextField maxCostField;
/*     */   private JCheckBox chckbxEstimateRadius;
/*     */   
/*     */   public LinearTrackerSettingsPanel(String name, String infoText, String spaceUnits) {
/*  81 */     this.trackerName = name;
/*  82 */     this.spaceUnits = spaceUnits;
/*  83 */     this.infoText = infoText;
/*  84 */     initGUI();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void initGUI() {
/*  91 */     setPreferredSize(new Dimension(300, 500));
/*  92 */     setLayout(null);
/*     */     
/*  94 */     JLabel lblSettingsForTracker = new JLabel("Settings for tracker:");
/*  95 */     lblSettingsForTracker.setBounds(10, 11, 280, 20);
/*  96 */     lblSettingsForTracker.setFont(TrackMateWizard.FONT);
/*  97 */     add(lblSettingsForTracker);
/*     */     
/*  99 */     this.labelTracker = new JLabel(this.trackerName);
/* 100 */     this.labelTracker.setFont(TrackMateWizard.BIG_FONT);
/* 101 */     this.labelTracker.setHorizontalAlignment(0);
/* 102 */     this.labelTracker.setBounds(10, 42, 280, 20);
/* 103 */     add(this.labelTracker);
/*     */     
/* 105 */     this.labelTrackerDescription = new JLabel("<tracker description>");
/* 106 */     this.labelTrackerDescription.setFont(TrackMateWizard.FONT.deriveFont(2));
/* 107 */     this.labelTrackerDescription.setBounds(10, 67, 280, 225);
/* 108 */     this.labelTrackerDescription.setText(this.infoText.replace("<br>", "")
/* 109 */         .replace("<p>", "<p align=\"justify\">")
/* 110 */         .replace("<html>", "<html><p align=\"justify\">"));
/* 111 */     add(this.labelTrackerDescription);
/*     */     
/* 113 */     JLabel lblInitDistance = new JLabel("Initial distance: ");
/* 114 */     lblInitDistance.setFont(TrackMateWizard.FONT);
/* 115 */     lblInitDistance.setBounds(10, 314, 164, 20);
/* 116 */     add(lblInitDistance);
/*     */     
/* 118 */     this.initDistField = new JNumericTextField();
/* 119 */     this.initDistField.setFont(TrackMateWizard.FONT);
/* 120 */     this.initDistField.setBounds(184, 316, 62, 20);
/* 121 */     this.initDistField.setSize(TrackMateWizard.TEXTFIELD_DIMENSION);
/* 122 */     add((Component)this.initDistField);
/*     */     
/* 124 */     JLabel lblSuccDistance = new JLabel("Succeeding distance: ");
/* 125 */     lblSuccDistance.setFont(TrackMateWizard.FONT);
/* 126 */     lblSuccDistance.setBounds(10, 342, 164, 20);
/* 127 */     add(lblSuccDistance);
/*     */     
/* 129 */     this.initSuccField = new JNumericTextField();
/* 130 */     this.initSuccField.setFont(TrackMateWizard.FONT);
/* 131 */     this.initSuccField.setBounds(184, 344, 62, 20);
/* 132 */     this.initSuccField.setSize(TrackMateWizard.TEXTFIELD_DIMENSION);
/* 133 */     add((Component)this.initSuccField);
/*     */     
/* 135 */     JLabel lblStickDistance = new JLabel("Stick radius: ");
/* 136 */     lblStickDistance.setFont(TrackMateWizard.FONT);
/* 137 */     lblStickDistance.setBounds(10, 370, 164, 20);
/* 138 */     add(lblStickDistance);
/*     */     
/* 140 */     this.initStickField = new JNumericTextField();
/* 141 */     this.initStickField.setFont(TrackMateWizard.FONT);
/* 142 */     this.initStickField.setBounds(184, 372, 62, 20);
/* 143 */     this.initStickField.setSize(TrackMateWizard.TEXTFIELD_DIMENSION);
/* 144 */     add((Component)this.initStickField);
/*     */     
/* 146 */     JLabel lblMaxCost = new JLabel("Maximal Cost: ");
/* 147 */     lblMaxCost.setFont(TrackMateWizard.FONT);
/* 148 */     lblMaxCost.setBounds(10, 396, 164, 20);
/* 149 */     add(lblMaxCost);
/*     */     
/* 151 */     this.maxCostField = new JNumericTextField();
/* 152 */     this.maxCostField.setFont(TrackMateWizard.FONT);
/* 153 */     this.maxCostField.setBounds(184, 398, 62, 20);
/* 154 */     this.maxCostField.setSize(TrackMateWizard.TEXTFIELD_DIMENSION);
/* 155 */     add((Component)this.maxCostField);
/*     */     
/* 157 */     this.labelUnits = new JLabel(this.spaceUnits);
/* 158 */     this.labelUnits.setFont(TrackMateWizard.FONT);
/* 159 */     this.labelUnits.setBounds(236, 314, 34, 20);
/* 160 */     add(this.labelUnits);
/*     */     
/* 162 */     this.labelUnit2 = new JLabel(this.spaceUnits);
/* 163 */     this.labelUnit2.setFont(TrackMateWizard.FONT);
/* 164 */     this.labelUnit2.setBounds(236, 342, 34, 20);
/* 165 */     add(this.labelUnit2);
/*     */     
/* 167 */     this.labelUnit3 = new JLabel(this.spaceUnits);
/* 168 */     this.labelUnit3.setFont(TrackMateWizard.FONT);
/* 169 */     this.labelUnit3.setBounds(236, 368, 34, 20);
/* 170 */     add(this.labelUnit3);
/*     */     
/* 172 */     this.chckbxEstimateRadius = new JCheckBox("Estimate Radius");
/* 173 */     this.chckbxEstimateRadius.setFont(TrackMateWizard.FONT);
/* 174 */     this.chckbxEstimateRadius.setBounds(10, 428, 128, 23);
/* 175 */     add(this.chckbxEstimateRadius);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSettings(Map<String, Object> settings) {
/* 186 */     this.initDistField.setText(String.format("%.1f", new Object[] { settings.get("INITIAL_DISTANCE") }));
/* 187 */     this.initSuccField.setText(String.format("%.1f", new Object[] { settings.get("SUCCEEDING_DISTANCE") }));
/* 188 */     this.initStickField.setText(String.format("%.1f", new Object[] { settings.get("STICK_RADIUS") }));
/* 189 */     this.maxCostField.setText(String.format("%.1f", new Object[] { settings.get("MAX_COST") }));
/* 190 */     this.chckbxEstimateRadius.setSelected(((Boolean)settings.get("ESTIMATE_RADIUS")).booleanValue());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, Object> getSettings() {
/* 198 */     Map<String, Object> settings = new HashMap<>();
/* 199 */     settings.put("INITIAL_DISTANCE", Double.valueOf(this.initDistField.getValue()));
/* 200 */     settings.put("SUCCEEDING_DISTANCE", Double.valueOf(this.initSuccField.getValue()));
/* 201 */     settings.put("STICK_RADIUS", Double.valueOf(this.initStickField.getValue()));
/* 202 */     settings.put("MAX_COST", Double.valueOf(this.maxCostField.getValue()));
/* 203 */     settings.put("ESTIMATE_RADIUS", Boolean.valueOf(this.chckbxEstimateRadius.isSelected()));
/* 204 */     return settings;
/*     */   }
/*     */   
/*     */   public void clean() {}
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/RonnyTrackMate_-0.0.6-SNAPSHOT.jar!/net/chicoronny/trackmate/lineartracker/LinearTrackerSettingsPanel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */