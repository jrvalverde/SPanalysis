/*     */ package net.chicoronny.trackmate.lineartracker;
/*     */ 
/*     */ import fiji.plugin.trackmate.Model;
/*     */ import fiji.plugin.trackmate.SpotCollection;
/*     */ import fiji.plugin.trackmate.gui.ConfigurationPanel;
/*     */ import fiji.plugin.trackmate.io.IOUtils;
/*     */ import fiji.plugin.trackmate.providers.TrackerProvider;
/*     */ import fiji.plugin.trackmate.tracking.SpotTracker;
/*     */ import fiji.plugin.trackmate.tracking.SpotTrackerFactory;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import javax.swing.ImageIcon;
/*     */ import org.jdom2.Element;
/*     */ import org.scijava.plugin.Plugin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Plugin(type = SpotTrackerFactory.class)
/*     */ public class LinearTrackerFactory
/*     */   implements SpotTrackerFactory
/*     */ {
/*     */   public static final String TRACKER_KEY = "LINEAR_TRACKER";
/*     */   public static final String NAME = "Linear Tracker";
/*     */   public static final String INFO_TEXT = "<html>This tracker is linking neighbours by calculation of a cost function which calculates the differences and angles between current and expected position, as well as spot radii differences.It uses a two-step algorithm which indentifies possible track starters in a different radius than succeeding track followers. It can close gaps of 1 frame. <br></html>";
/*     */   private String errorMessage;
/*     */   
/*     */   public String getInfoText() {
/*  57 */     return "<html>This tracker is linking neighbours by calculation of a cost function which calculates the differences and angles between current and expected position, as well as spot radii differences.It uses a two-step algorithm which indentifies possible track starters in a different radius than succeeding track followers. It can close gaps of 1 frame. <br></html>";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ImageIcon getIcon() {
/*  65 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getKey() {
/*  73 */     return "LINEAR_TRACKER";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/*  81 */     return "Linear Tracker";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SpotTracker create(SpotCollection spots, Map<String, Object> settings) {
/*  89 */     return new LinearTracker(spots, settings);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ConfigurationPanel getTrackerConfigurationPanel(Model model) {
/*  97 */     String spaceUnits = model.getSpaceUnits();
/*  98 */     return new LinearTrackerSettingsPanel("Linear Tracker", "<html>This tracker is linking neighbours by calculation of a cost function which calculates the differences and angles between current and expected position, as well as spot radii differences.It uses a two-step algorithm which indentifies possible track starters in a different radius than succeeding track followers. It can close gaps of 1 frame. <br></html>", spaceUnits);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean marshall(Map<String, Object> settings, Element element) {
/* 106 */     StringBuilder str = new StringBuilder();
/* 107 */     boolean ok = true;
/* 108 */     ok &= IOUtils.writeAttribute(settings, element, "INITIAL_DISTANCE", Double.class, str);
/* 109 */     ok &= IOUtils.writeAttribute(settings, element, "SUCCEEDING_DISTANCE", Double.class, str);
/* 110 */     ok &= IOUtils.writeAttribute(settings, element, "STICK_RADIUS", Double.class, str);
/* 111 */     ok &= IOUtils.writeAttribute(settings, element, "MAX_COST", Double.class, str);
/* 112 */     ok &= IOUtils.writeAttribute(settings, element, "ESTIMATE_RADIUS", Boolean.class, str);
/*     */     
/* 114 */     if (!ok) {
/* 115 */       this.errorMessage = str.toString();
/*     */     }
/* 117 */     return ok;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean unmarshall(Element element, Map<String, Object> settings) {
/* 125 */     boolean ok = true;
/* 126 */     StringBuilder errorHolder = new StringBuilder();
/* 127 */     settings.clear();
/* 128 */     ok &= IOUtils.readDoubleAttribute(element, settings, "INITIAL_DISTANCE", errorHolder);
/* 129 */     ok &= IOUtils.readDoubleAttribute(element, settings, "SUCCEEDING_DISTANCE", errorHolder);
/* 130 */     ok &= IOUtils.readDoubleAttribute(element, settings, "STICK_RADIUS", errorHolder);
/* 131 */     ok &= IOUtils.readDoubleAttribute(element, settings, "MAX_COST", errorHolder);
/* 132 */     ok &= IOUtils.readBooleanAttribute(element, settings, "ESTIMATE_RADIUS", errorHolder);
/*     */     
/* 134 */     if (!ok) {
/* 135 */       this.errorMessage = errorHolder.toString();
/*     */     }
/* 137 */     return ok;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString(Map<String, Object> sm) {
/* 145 */     if (!checkSettingsValidity(sm)) {
/* 146 */       return this.errorMessage;
/*     */     }
/* 148 */     StringBuilder str = new StringBuilder();
/* 149 */     str.append(String.format("Initial distance: %.1f\n", new Object[] { sm.get("INITIAL_DISTANCE") }));
/* 150 */     str.append(String.format("Succeeding distance: %.1f\n", new Object[] { sm.get("SUCCEEDING_DISTANCE") }));
/* 151 */     str.append(String.format("Stick Radius: %.1f\n", new Object[] { sm.get("STICK_RADIUS") }));
/* 152 */     str.append(String.format("Max Cost: %.1f\n", new Object[] { sm.get("MAX_COST") }));
/* 153 */     str.append(String.format("Estimate Radius: %b\n", new Object[] { sm.get("ESTIMATE_RADIUS") }));
/* 154 */     return str.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, Object> getDefaultSettings() {
/* 162 */     Map<String, Object> settings = new HashMap<>();
/* 163 */     settings.put("INITIAL_DISTANCE", Double.valueOf(10.0D));
/* 164 */     settings.put("SUCCEEDING_DISTANCE", Double.valueOf(5.0D));
/* 165 */     settings.put("STICK_RADIUS", Double.valueOf(2.0D));
/* 166 */     settings.put("MAX_COST", Double.valueOf(100.0D));
/* 167 */     settings.put("ESTIMATE_RADIUS", Boolean.valueOf(false));
/* 168 */     return settings;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean checkSettingsValidity(Map<String, Object> settings) {
/* 176 */     StringBuilder str = new StringBuilder();
/* 177 */     boolean ok = LinearTracker.checkInput(settings, str);
/* 178 */     if (!ok) {
/* 179 */       this.errorMessage = str.toString();
/*     */     }
/* 181 */     return ok;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getErrorMessage() {
/* 189 */     return this.errorMessage;
/*     */   }
/*     */ 
/*     */   
/*     */   public static void main(String[] args) {
/* 194 */     TrackerProvider provider = new TrackerProvider();
/* 195 */     System.out.println(provider.echo());
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/RonnyTrackMate_-0.0.6-SNAPSHOT.jar!/net/chicoronny/trackmate/lineartracker/LinearTrackerFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */