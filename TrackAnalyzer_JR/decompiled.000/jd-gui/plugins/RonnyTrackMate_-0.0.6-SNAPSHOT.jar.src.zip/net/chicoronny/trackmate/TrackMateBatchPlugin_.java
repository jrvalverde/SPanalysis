/*     */ package net.chicoronny.trackmate;
/*     */ 
/*     */ import fiji.plugin.trackmate.Logger;
/*     */ import fiji.plugin.trackmate.Model;
/*     */ import fiji.plugin.trackmate.Settings;
/*     */ import fiji.plugin.trackmate.Spot;
/*     */ import fiji.plugin.trackmate.TrackMate;
/*     */ import fiji.plugin.trackmate.detection.SpotDetectorFactory;
/*     */ import fiji.plugin.trackmate.features.FeatureFilter;
/*     */ import fiji.plugin.trackmate.features.edges.EdgeAnalyzer;
/*     */ import fiji.plugin.trackmate.features.spot.SpotAnalyzerFactory;
/*     */ import fiji.plugin.trackmate.features.track.TrackAnalyzer;
/*     */ import fiji.plugin.trackmate.providers.DetectorProvider;
/*     */ import fiji.plugin.trackmate.providers.TrackerProvider;
/*     */ import fiji.plugin.trackmate.tracking.SpotTrackerFactory;
/*     */ import ij.ImageJ;
/*     */ import ij.ImagePlus;
/*     */ import ij.io.DirectoryChooser;
/*     */ import ij.plugin.PlugIn;
/*     */ import java.io.File;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.FileReader;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import loci.formats.FormatException;
/*     */ import loci.plugins.BF;
/*     */ import net.chicoronny.trackmate.action.ExportTracksToSQL;
/*     */ import net.chicoronny.trackmate.lineartracker.LTUtils;
/*     */ import net.imglib2.util.ValuePair;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TrackMateBatchPlugin_
/*     */   implements PlugIn
/*     */ {
/*     */   private static final String KEY = "BatchPlugin";
/*     */   private double INITIAL_DISTANCE;
/*     */   private double SUCCEEDING_DISTANCE;
/*     */   private double STICK_RADIUS;
/*     */   private double PRE_QUALITY;
/*  86 */   private final String DEFAULT_ONE = "1";
/*     */ 
/*     */   
/*  89 */   private final String DEFAULT_FALSE = "FALSE";
/*     */ 
/*     */ 
/*     */   
/*     */   private double RADIUS;
/*     */ 
/*     */ 
/*     */   
/*     */   private double THRESHOLD;
/*     */ 
/*     */ 
/*     */   
/*     */   private String DETECTOR;
/*     */ 
/*     */ 
/*     */   
/*     */   private Boolean MEDIAN_FILTERING;
/*     */ 
/*     */ 
/*     */   
/*     */   private String[] TRACK_FILTER;
/*     */ 
/*     */ 
/*     */   
/*     */   private String[] SPOT_FILTER;
/*     */ 
/*     */ 
/*     */   
/*     */   private ArrayList<ValuePair<String, Double>> trackfilters;
/*     */ 
/*     */ 
/*     */   
/*     */   private ArrayList<ValuePair<String, Double>> spotfilters;
/*     */ 
/*     */ 
/*     */   
/*     */   private String[] EXTENSIONS;
/*     */ 
/*     */ 
/*     */   
/*     */   private String TRACKER;
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean ALLOW_TRACK_MERGING;
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean ALLOW_TRACK_SPLITTING;
/*     */ 
/*     */   
/*     */   private double GAP_CLOSING_MAX_DISTANCE;
/*     */ 
/*     */   
/*     */   private int GAP_CLOSING_MAX_FRAME_GAP;
/*     */ 
/*     */   
/*     */   private double LINKING_MAX_DISTANCE;
/*     */ 
/*     */   
/*     */   private double MERGING_MAX_DISTANCE;
/*     */ 
/*     */   
/*     */   private double SPLITTING_MAX_DISTANCE;
/*     */ 
/*     */   
/*     */   private boolean ALLOW_GAP_CLOSING;
/*     */ 
/*     */   
/*     */   private String[] SPOTANALYZER;
/*     */ 
/*     */   
/*     */   private String[] TRACKANALYZER;
/*     */ 
/*     */   
/*     */   private String[] EDGEANALYZER;
/*     */ 
/*     */   
/*     */   private Object MAX_COST;
/*     */ 
/*     */   
/*     */   private File file;
/*     */ 
/*     */   
/*     */   private double KALMAN_SEARCH_RADIUS;
/*     */ 
/*     */ 
/*     */   
/*     */   public void run(String imagePath) {
/* 178 */     Locale curLocale = Locale.getDefault();
/* 179 */     Locale usLocale = new Locale("en", "US");
/* 180 */     Locale.setDefault(usLocale);
/*     */     
/* 182 */     DirectoryChooser.setDefaultDirectory("/media/data/users/Sofia/tiffs");
/* 183 */     DirectoryChooser dc = new DirectoryChooser("Choose a folder to process");
/* 184 */     String dname = dc.getDirectory();
/* 185 */     if (dname == null) {
/*     */       return;
/*     */     }
/* 188 */     File folder = new File(dname);
/* 189 */     File parent = folder.getParentFile();
/* 190 */     Logger logger = Logger.IJ_LOGGER;
/*     */ 
/*     */     
/*     */     try {
/* 194 */       this.file = new File(parent, "TrackMate.properties");
/*     */     }
/* 196 */     catch (NullPointerException e) {
/*     */       
/* 198 */       logger.log(e.getMessage());
/*     */       return;
/*     */     } 
/* 201 */     logger.log("Using " + this.file.getAbsolutePath());
/*     */ 
/*     */     
/*     */     try {
/* 205 */       FileReader reader = new FileReader(this.file);
/* 206 */       Properties props = new Properties();
/* 207 */       props.load(reader);
/* 208 */       this.EXTENSIONS = props.getProperty("EXTENSIONS").split(",");
/* 209 */       this.INITIAL_DISTANCE = Double.parseDouble(props.getProperty("INITIAL_DISTANCE", "1"));
/* 210 */       this.SUCCEEDING_DISTANCE = Double.parseDouble(props.getProperty("SUCCEEDING_DISTANCE", "1"));
/* 211 */       this.STICK_RADIUS = Double.parseDouble(props.getProperty("STICK_RADIUS", "1"));
/* 212 */       this.MAX_COST = Double.valueOf(Double.parseDouble(props.getProperty("MAX_COST", "1")));
/* 213 */       this.PRE_QUALITY = Double.parseDouble(props.getProperty("PRE_QUALITY", "1"));
/* 214 */       this.RADIUS = Double.parseDouble(props.getProperty("RADIUS", "1"));
/* 215 */       this.THRESHOLD = Double.parseDouble(props.getProperty("THRESHOLD", "1"));
/* 216 */       this.MEDIAN_FILTERING = Boolean.valueOf(Boolean.parseBoolean(props.getProperty("MEDIAN_FILTERING", "FALSE")));
/* 217 */       this.DETECTOR = props.getProperty("DETECTOR", "DOG_DETECTOR");
/* 218 */       this.TRACKER = props.getProperty("TRACKER", "LINEAR_TRACKER");
/* 219 */       this.TRACK_FILTER = props.getProperty("TRACK_FILTER", "").split("\n");
/* 220 */       this.SPOT_FILTER = props.getProperty("SPOT_FILTER", "").split("\n");
/* 221 */       this.ALLOW_TRACK_MERGING = Boolean.parseBoolean(props.getProperty("ALLOW_TRACK_MERGING", "FALSE"));
/* 222 */       this.ALLOW_TRACK_SPLITTING = Boolean.parseBoolean(props.getProperty("ALLOW_TRACK_SPLITTING", "FALSE"));
/* 223 */       this.ALLOW_GAP_CLOSING = Boolean.parseBoolean(props.getProperty("ALLOW_GAP_CLOSING", "1"));
/* 224 */       this.GAP_CLOSING_MAX_DISTANCE = Double.parseDouble(props.getProperty("GAP_CLOSING_MAX_DISTANCE", "1"));
/* 225 */       this.GAP_CLOSING_MAX_FRAME_GAP = Integer.parseInt(props.getProperty("GAP_CLOSING_MAX_FRAME_GAP", "1"));
/* 226 */       this.LINKING_MAX_DISTANCE = Double.parseDouble(props.getProperty("LINKING_MAX_DISTANCE", "1"));
/* 227 */       this.MERGING_MAX_DISTANCE = Double.parseDouble(props.getProperty("MERGING_MAX_DISTANCE", "1"));
/* 228 */       this.SPLITTING_MAX_DISTANCE = Double.parseDouble(props.getProperty("SPLITTING_MAX_DISTANCE", "1"));
/* 229 */       this.SPOTANALYZER = props.getProperty("SPOTANALYZER", "").split("[,\n]");
/* 230 */       this.TRACKANALYZER = props.getProperty("TRACKANALYZER", "").split("[,\n]");
/* 231 */       this.EDGEANALYZER = props.getProperty("EDGEANALYZER", "").split("[,\n]");
/* 232 */       this.KALMAN_SEARCH_RADIUS = Double.parseDouble(props.getProperty("KALMAN_SEARCH_RADIUS", "1"));
/* 233 */       reader.close();
/*     */     }
/* 235 */     catch (FileNotFoundException e1) {
/*     */       
/* 237 */       logger.log(e1.getMessage());
/*     */       
/*     */       return;
/* 240 */     } catch (IOException e1) {
/*     */       
/* 242 */       logger.log(e1.getMessage());
/*     */     } 
/*     */     
/* 245 */     this.trackfilters = new ArrayList<>(); byte b; int i; String[] arrayOfString;
/* 246 */     for (i = (arrayOfString = this.TRACK_FILTER).length, b = 0; b < i; ) { String f = arrayOfString[b];
/*     */       
/* 248 */       String[] splitted = f.split(",");
/* 249 */       if (splitted.length == 2)
/*     */       {
/* 251 */         this.trackfilters.add(new ValuePair(splitted[0], Double.valueOf(Double.parseDouble(splitted[1]))));
/*     */       }
/*     */       b++; }
/*     */     
/* 255 */     this.spotfilters = new ArrayList<>();
/* 256 */     for (i = (arrayOfString = this.SPOT_FILTER).length, b = 0; b < i; ) { String f = arrayOfString[b];
/*     */       
/* 258 */       String[] splitted = f.split(",");
/* 259 */       if (splitted.length == 2)
/*     */       {
/* 261 */         this.spotfilters.add(new ValuePair(splitted[0], Double.valueOf(Double.parseDouble(splitted[1]))));
/*     */       }
/*     */       
/*     */       b++; }
/*     */     
/*     */     try {
/* 267 */       process(folder);
/*     */     }
/* 269 */     catch (IOException e2) {
/*     */       
/* 271 */       logger.log(e2.getMessage());
/*     */     }
/* 273 */     catch (FormatException e3) {
/*     */       
/* 275 */       logger.log(e3.getMessage());
/*     */     } 
/* 277 */     Locale.setDefault(curLocale);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void process(File folder) throws IOException, FormatException {
/* 295 */     long start = System.currentTimeMillis();
/* 296 */     Logger logger = Logger.IJ_LOGGER;
/*     */     
/* 298 */     Collection<File> fList = LTUtils.listFiles(folder, this.EXTENSIONS);
/*     */     
/* 300 */     for (File file : fList) {
/* 301 */       logger.log("Processing " + file.getName());
/*     */       
/* 303 */       ImagePlus[] imps = BF.openImagePlus(file.getAbsolutePath());
/* 304 */       ImagePlus imp = imps[0];
/* 305 */       Settings settings = new Settings();
/*     */       
/* 307 */       imp.killRoi();
/* 308 */       settings.setFrom(imp);
/*     */ 
/*     */       
/* 311 */       DetectorProvider provider = new DetectorProvider();
/* 312 */       if (this.DETECTOR.equalsIgnoreCase("DOG_DETECTOR"))
/* 313 */         settings.detectorFactory = (SpotDetectorFactory)provider.getFactory("LOG_DETECTOR"); 
/* 314 */       if (this.DETECTOR.equalsIgnoreCase("LOG_DETECTOR"))
/* 315 */         settings.detectorFactory = (SpotDetectorFactory)provider.getFactory("LOG_DETECTOR"); 
/* 316 */       if (settings.detectorFactory == null) {
/* 317 */         logger.log("No Detector provided!");
/*     */         return;
/*     */       } 
/* 320 */       Map<String, Object> dmap = settings.detectorFactory.getDefaultSettings();
/* 321 */       dmap.put("RADIUS", Double.valueOf(this.RADIUS));
/* 322 */       dmap.put("THRESHOLD", Double.valueOf(this.THRESHOLD));
/* 323 */       dmap.put("DO_MEDIAN_FILTERING", this.MEDIAN_FILTERING);
/* 324 */       settings.detectorSettings = dmap;
/* 325 */       settings.initialSpotFilterValue = Double.valueOf(this.PRE_QUALITY);
/*     */ 
/*     */       
/* 328 */       TrackerProvider tp = new TrackerProvider();
/* 329 */       if (this.TRACKER.startsWith("LINEAR_TRACKER")) {
/* 330 */         settings.trackerFactory = (SpotTrackerFactory)tp.getFactory("LINEAR_TRACKER");
/* 331 */         Map<String, Object> ts = settings.trackerFactory.getDefaultSettings();
/* 332 */         ts.put("INITIAL_DISTANCE", Double.valueOf(this.INITIAL_DISTANCE));
/* 333 */         ts.put("SUCCEEDING_DISTANCE", Double.valueOf(this.SUCCEEDING_DISTANCE));
/* 334 */         ts.put("STICK_RADIUS", Double.valueOf(this.STICK_RADIUS));
/* 335 */         ts.put("MAX_COST", this.MAX_COST);
/* 336 */         settings.trackerSettings = ts;
/* 337 */       } else if (this.TRACKER.startsWith("FAST_LAP_TRACKER")) {
/* 338 */         settings.trackerFactory = (SpotTrackerFactory)tp.getFactory("LAP_TRACKER");
/* 339 */         Map<String, Object> fl = settings.trackerFactory.getDefaultSettings();
/* 340 */         fl.put("ALLOW_GAP_CLOSING", Boolean.valueOf(this.ALLOW_GAP_CLOSING));
/* 341 */         fl.put("ALLOW_TRACK_MERGING", Boolean.valueOf(this.ALLOW_TRACK_MERGING));
/* 342 */         fl.put("ALLOW_TRACK_SPLITTING", Boolean.valueOf(this.ALLOW_TRACK_SPLITTING));
/* 343 */         fl.put("GAP_CLOSING_MAX_DISTANCE", Double.valueOf(this.GAP_CLOSING_MAX_DISTANCE));
/* 344 */         fl.put("MAX_FRAME_GAP", Integer.valueOf(this.GAP_CLOSING_MAX_FRAME_GAP));
/* 345 */         fl.put("LINKING_MAX_DISTANCE", Double.valueOf(this.LINKING_MAX_DISTANCE));
/* 346 */         fl.put("MERGING_MAX_DISTANCE", Double.valueOf(this.MERGING_MAX_DISTANCE));
/* 347 */         fl.put("SPLITTING_MAX_DISTANCE", Double.valueOf(this.SPLITTING_MAX_DISTANCE));
/* 348 */         settings.trackerSettings = fl;
/* 349 */       } else if (this.TRACKER.startsWith("SIMPLE_FAST_LAP_TRACKER")) {
/* 350 */         settings.trackerFactory = (SpotTrackerFactory)tp.getFactory("LAP_TRACKER");
/* 351 */         Map<String, Object> sfl = settings.trackerFactory.getDefaultSettings();
/* 352 */         sfl.put("ALLOW_GAP_CLOSING", Boolean.valueOf(this.ALLOW_GAP_CLOSING));
/* 353 */         sfl.put("GAP_CLOSING_MAX_DISTANCE", Double.valueOf(this.GAP_CLOSING_MAX_DISTANCE));
/* 354 */         sfl.put("MAX_FRAME_GAP", Integer.valueOf(this.GAP_CLOSING_MAX_FRAME_GAP));
/* 355 */         sfl.put("LINKING_MAX_DISTANCE", Double.valueOf(this.LINKING_MAX_DISTANCE));
/* 356 */         settings.trackerSettings = sfl;
/* 357 */       } else if (this.TRACKER.startsWith("LAP_TRACKER")) {
/* 358 */         settings.trackerFactory = (SpotTrackerFactory)tp.getFactory("LAP_TRACKER");
/* 359 */         Map<String, Object> l = settings.trackerFactory.getDefaultSettings();
/* 360 */         l.put("ALLOW_GAP_CLOSING", Boolean.valueOf(this.ALLOW_GAP_CLOSING));
/* 361 */         l.put("ALLOW_TRACK_MERGING", Boolean.valueOf(this.ALLOW_TRACK_MERGING));
/* 362 */         l.put("ALLOW_TRACK_SPLITTING", Boolean.valueOf(this.ALLOW_TRACK_SPLITTING));
/* 363 */         l.put("GAP_CLOSING_MAX_DISTANCE", Double.valueOf(this.GAP_CLOSING_MAX_DISTANCE));
/* 364 */         l.put("MAX_FRAME_GAP", Integer.valueOf(this.GAP_CLOSING_MAX_FRAME_GAP));
/* 365 */         l.put("LINKING_MAX_DISTANCE", Double.valueOf(this.LINKING_MAX_DISTANCE));
/* 366 */         l.put("MERGING_MAX_DISTANCE", Double.valueOf(this.MERGING_MAX_DISTANCE));
/* 367 */         l.put("SPLITTING_MAX_DISTANCE", Double.valueOf(this.SPLITTING_MAX_DISTANCE));
/* 368 */         settings.trackerSettings = l;
/* 369 */       } else if (this.TRACKER.startsWith("SPARSE_LAP_TRACKER")) {
/* 370 */         settings.trackerFactory = (SpotTrackerFactory)tp.getFactory("LAP_TRACKER");
/* 371 */         Map<String, Object> slp = settings.trackerFactory.getDefaultSettings();
/* 372 */         slp.put("ALLOW_GAP_CLOSING", Boolean.valueOf(this.ALLOW_GAP_CLOSING));
/* 373 */         slp.put("ALLOW_TRACK_MERGING", Boolean.valueOf(this.ALLOW_TRACK_MERGING));
/* 374 */         slp.put("ALLOW_TRACK_SPLITTING", Boolean.valueOf(this.ALLOW_TRACK_SPLITTING));
/* 375 */         slp.put("GAP_CLOSING_MAX_DISTANCE", Double.valueOf(this.GAP_CLOSING_MAX_DISTANCE));
/* 376 */         slp.put("MAX_FRAME_GAP", Integer.valueOf(this.GAP_CLOSING_MAX_FRAME_GAP));
/* 377 */         slp.put("LINKING_MAX_DISTANCE", Double.valueOf(this.LINKING_MAX_DISTANCE));
/* 378 */         slp.put("MERGING_MAX_DISTANCE", Double.valueOf(this.MERGING_MAX_DISTANCE));
/* 379 */         slp.put("SPLITTING_MAX_DISTANCE", Double.valueOf(this.SPLITTING_MAX_DISTANCE));
/* 380 */         settings.trackerSettings = slp;
/* 381 */       } else if (this.TRACKER.startsWith("SIMPLE_LAP_TRACKER")) {
/* 382 */         settings.trackerFactory = (SpotTrackerFactory)tp.getFactory("LAP_TRACKER");
/* 383 */         Map<String, Object> sl = settings.trackerFactory.getDefaultSettings();
/* 384 */         sl.put("ALLOW_GAP_CLOSING", Boolean.valueOf(this.ALLOW_GAP_CLOSING));
/* 385 */         sl.put("GAP_CLOSING_MAX_DISTANCE", Double.valueOf(this.GAP_CLOSING_MAX_DISTANCE));
/* 386 */         sl.put("MAX_FRAME_GAP", Integer.valueOf(this.GAP_CLOSING_MAX_FRAME_GAP));
/* 387 */         sl.put("LINKING_MAX_DISTANCE", Double.valueOf(this.LINKING_MAX_DISTANCE));
/* 388 */         settings.trackerSettings = sl;
/* 389 */       } else if (this.TRACKER.startsWith("KALMAN_TRACKER")) {
/* 390 */         settings.trackerFactory = (SpotTrackerFactory)tp.getFactory("KALMAN_TRACKER");
/* 391 */         Map<String, Object> ka = settings.trackerFactory.getDefaultSettings();
/* 392 */         ka.put("KALMAN_SEARCH_RADIUS", Double.valueOf(this.KALMAN_SEARCH_RADIUS));
/* 393 */         ka.put("MAX_FRAME_GAP", Integer.valueOf(this.GAP_CLOSING_MAX_FRAME_GAP));
/* 394 */         ka.put("LINKING_MAX_DISTANCE", Double.valueOf(this.LINKING_MAX_DISTANCE));
/* 395 */         settings.trackerSettings = ka;
/*     */       } else {
/*     */         
/* 398 */         logger.log("No Tracker found in TrackMate.properties");
/*     */         
/*     */         return;
/*     */       } 
/* 402 */       ClassLoader cl = ClassLoader.getSystemClassLoader(); byte b; int i;
/*     */       String[] arrayOfString;
/* 404 */       for (i = (arrayOfString = this.SPOTANALYZER).length, b = 0; b < i; ) { String a = arrayOfString[b];
/*     */         try {
/* 406 */           Class<?> c = cl.loadClass("fiji.plugin.trackmate.features.spot." + a.trim());
/*     */           
/* 408 */           Class<? extends SpotAnalyzerFactory> ac = c.asSubclass(SpotAnalyzerFactory.class);
/* 409 */           settings.addSpotAnalyzerFactory(ac.newInstance());
/* 410 */         } catch (ClassNotFoundException e) {
/* 411 */           logger.log(e.getMessage());
/*     */           return;
/* 413 */         } catch (InstantiationException e) {
/* 414 */           e.printStackTrace();
/* 415 */         } catch (IllegalAccessException e) {
/* 416 */           e.printStackTrace();
/*     */         } 
/*     */         b++; }
/*     */       
/* 420 */       for (i = (arrayOfString = this.TRACKANALYZER).length, b = 0; b < i; ) { String a = arrayOfString[b];
/*     */         try {
/* 422 */           Class<?> c = cl.loadClass("fiji.plugin.trackmate.features.track." + a.trim());
/* 423 */           Class<? extends TrackAnalyzer> ac = c.asSubclass(TrackAnalyzer.class);
/* 424 */           settings.addTrackAnalyzer(ac.newInstance());
/* 425 */         } catch (ClassNotFoundException e) {
/* 426 */           logger.log(e.getMessage());
/*     */           return;
/* 428 */         } catch (InstantiationException e) {
/* 429 */           e.printStackTrace();
/* 430 */         } catch (IllegalAccessException e) {
/* 431 */           e.printStackTrace();
/*     */         } 
/*     */         b++; }
/*     */       
/* 435 */       for (i = (arrayOfString = this.EDGEANALYZER).length, b = 0; b < i; ) { String a = arrayOfString[b];
/*     */         try {
/* 437 */           Class<?> c = cl.loadClass("fiji.plugin.trackmate.features.edges." + a.trim());
/* 438 */           Class<? extends EdgeAnalyzer> ac = c.asSubclass(EdgeAnalyzer.class);
/* 439 */           settings.addEdgeAnalyzer(ac.newInstance());
/* 440 */         } catch (ClassNotFoundException e) {
/* 441 */           logger.log(e.getMessage());
/*     */           return;
/* 443 */         } catch (InstantiationException e) {
/* 444 */           e.printStackTrace();
/* 445 */         } catch (IllegalAccessException e) {
/* 446 */           e.printStackTrace();
/*     */         } 
/*     */         
/*     */         b++; }
/*     */       
/* 451 */       List<SpotAnalyzerFactory<?>> spotFactories = settings.getSpotAnalyzerFactories();
/* 452 */       for (ValuePair<String, Double> f : this.spotfilters) {
/* 453 */         boolean isAbove = (((Double)f.getB()).doubleValue() >= 0.0D);
/* 454 */         FeatureFilter filter = new FeatureFilter((String)f.getA(), Math.abs(((Double)f.getB()).doubleValue()), isAbove);
/* 455 */         Iterator<SpotAnalyzerFactory<?>> fIt = spotFactories.iterator();
/* 456 */         while (fIt.hasNext()) {
/* 457 */           List<String> curAnalyzer = ((SpotAnalyzerFactory)fIt.next()).getFeatures();
/* 458 */           if (curAnalyzer.contains(f.getA()))
/* 459 */             settings.getSpotFilters().add(filter); 
/*     */         } 
/* 461 */         Collection<String> spotFeatures = Spot.FEATURES;
/* 462 */         if (spotFeatures.contains(f.getA())) {
/* 463 */           settings.getSpotFilters().add(filter);
/*     */         }
/*     */       } 
/*     */       
/* 467 */       List<TrackAnalyzer> trackAnalyzers = settings.getTrackAnalyzers();
/* 468 */       for (ValuePair<String, Double> f : this.trackfilters) {
/* 469 */         boolean isAbove = (((Double)f.getB()).doubleValue() >= 0.0D);
/* 470 */         FeatureFilter filter = new FeatureFilter((String)f.getA(), Math.abs(((Double)f.getB()).doubleValue()), isAbove);
/* 471 */         Iterator<TrackAnalyzer> tIt = trackAnalyzers.iterator();
/* 472 */         while (tIt.hasNext()) {
/* 473 */           List<String> curFeatures = ((TrackAnalyzer)tIt.next()).getFeatures();
/* 474 */           if (curFeatures.contains(f.getA())) {
/* 475 */             settings.getTrackFilters().add(filter);
/*     */           }
/*     */         } 
/*     */       } 
/* 479 */       logger.log(settings.toString());
/*     */ 
/*     */       
/* 482 */       Model model = new Model();
/* 483 */       model.setLogger(Logger.IJ_LOGGER);
/*     */       
/* 485 */       TrackMate trackmate = new TrackMate(model, settings);
/* 486 */       boolean ok = trackmate.checkInput();
/* 487 */       if (!ok) {
/* 488 */         logger.log(trackmate.getErrorMessage());
/*     */         
/*     */         return;
/*     */       } 
/* 492 */       ok &= trackmate.process();
/* 493 */       if (!ok) {
/* 494 */         logger.log(trackmate.getErrorMessage());
/*     */         
/*     */         continue;
/*     */       } 
/*     */       
/* 499 */       String newName = String.valueOf(file.getAbsolutePath().substring(0, file.getAbsolutePath().length() - 4)) + "_B.db";
/* 500 */       File _file = new File(newName);
/*     */       
/* 502 */       ExportTracksToSQL ex = new ExportTracksToSQL();
/* 503 */       ex.export(trackmate.getModel(), trackmate.getSettings(), _file);
/*     */     } 
/* 505 */     long end = System.currentTimeMillis();
/* 506 */     logger.log("All Done in " + ((end - start) / 1000L) + "s.");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void main(String[] args) {
/* 517 */     ImageJ.main(args);
/*     */     
/* 519 */     TrackMateBatchPlugin_ plugIn = new TrackMateBatchPlugin_();
/* 520 */     plugIn.run("TrackMate.properties");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getKey() {
/* 531 */     return "BatchPlugin";
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/RonnyTrackMate_-0.0.6-SNAPSHOT.jar!/net/chicoronny/trackmate/TrackMateBatchPlugin_.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */