/*     */ package net.chicoronny.trackmate.action;
/*     */ 
/*     */ import fiji.plugin.trackmate.FeatureModel;
/*     */ import fiji.plugin.trackmate.Logger;
/*     */ import fiji.plugin.trackmate.Model;
/*     */ import fiji.plugin.trackmate.Settings;
/*     */ import fiji.plugin.trackmate.Spot;
/*     */ import fiji.plugin.trackmate.TrackMate;
/*     */ import fiji.plugin.trackmate.TrackModel;
/*     */ import fiji.plugin.trackmate.action.AbstractTMAction;
/*     */ import fiji.plugin.trackmate.action.TrackMateAction;
/*     */ import fiji.plugin.trackmate.action.TrackMateActionFactory;
/*     */ import fiji.plugin.trackmate.gui.TrackMateGUIController;
/*     */ import fiji.plugin.trackmate.gui.TrackMateWizard;
/*     */ import ij.io.SaveDialog;
/*     */ import java.io.File;
/*     */ import java.sql.Connection;
/*     */ import java.sql.DriverManager;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Statement;
/*     */ import java.util.Collection;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.TreeSet;
/*     */ import javax.swing.ImageIcon;
/*     */ import org.jgrapht.graph.DefaultWeightedEdge;
/*     */ import org.scijava.plugin.Plugin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ExportTracksToSQL
/*     */   extends AbstractTMAction
/*     */ {
/*     */   public static final String INFO_TEXT = "<html>Export the tracks in the current model content to a SQL database <p> The file will have one element per track, and each track contains several spot elements. These spots are sorted by frame number<p>As such, this format <u>cannot</u> handle track merging and splitting properly, and is suited only for non-branching tracks.</html>";
/*     */   public static final String NAME = "Export tracks to SQLITE database";
/*     */   public static final String KEY = "EXPORT_TRACKS_TO_SQLITE";
/*  48 */   public static final ImageIcon ICON = new ImageIcon(TrackMateWizard.class.getResource("images/page_save.png"));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void export(Model model, Settings settings, File file) {
/*  65 */     Logger logger = Logger.IJ_LOGGER;
/*  66 */     file.delete();
/*  67 */     Statement statement = null;
/*  68 */     long start = System.currentTimeMillis();
/*     */     try {
/*  70 */       statement = createDatabase();
/*  71 */       marshall(model, settings, statement);
/*  72 */       statement.executeUpdate("backup to '" + file.getAbsolutePath() + "'");
/*  73 */     } catch (SQLException e) {
/*  74 */       logger.log(e.getMessage());
/*  75 */       e.printStackTrace();
/*     */     } finally {
/*  77 */       if (statement != null)
/*     */         try {
/*  79 */           statement.close();
/*  80 */         } catch (SQLException e) {
/*  81 */           logger.log(e.getMessage());
/*     */         }  
/*     */     } 
/*  84 */     long end = System.currentTimeMillis();
/*  85 */     logger.log("Exported to SQLite " + file.getName() + " in " + (end - start) + " ms.");
/*     */   }
/*     */   
/*     */   public void execute(TrackMate trackmate) {
/*     */     File folder;
/*     */     String filename;
/*  91 */     this.logger.log("Exporting tracks to SQLite database.\n");
/*  92 */     long start = System.currentTimeMillis();
/*  93 */     Model model = trackmate.getModel();
/*  94 */     int ntracks = model.getTrackModel().nTracks(true);
/*  95 */     if (ntracks == 0) {
/*  96 */       this.logger.log("No visible track found. Aborting.\n");
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/*     */     try {
/* 102 */       folder = new File(((trackmate.getSettings()).imp.getOriginalFileInfo()).directory);
/* 103 */     } catch (NullPointerException npe) {
/* 104 */       folder = (new File(System.getProperty("user.dir"))).getParentFile().getParentFile();
/*     */     } 
/*     */ 
/*     */     
/*     */     try {
/* 109 */       filename = (trackmate.getSettings()).imageFileName;
/* 110 */       filename = filename.substring(0, filename.indexOf("."));
/* 111 */       filename = String.valueOf(folder.getPath()) + File.separator + filename + "_Tracks.db";
/* 112 */     } catch (NullPointerException npe) {
/* 113 */       filename = String.valueOf(folder.getPath()) + File.separator + "Tracks.db";
/*     */     } 
/* 115 */     SaveDialog sd = new SaveDialog("Save Database File", filename, ".db");
/*     */     
/* 117 */     String fileName = sd.getFileName();
/*     */     
/* 119 */     if (fileName == null || fileName.isEmpty())
/*     */       return; 
/* 121 */     File file = new File(String.valueOf(sd.getDirectory()) + fileName);
/*     */     
/* 123 */     if (file.delete()) {
/* 124 */       this.logger.log("File will be overwritten!\n");
/*     */     }
/* 126 */     Statement statement = null;
/*     */     try {
/* 128 */       statement = createDatabase();
/* 129 */       marshall(model, trackmate.getSettings(), statement);
/* 130 */       statement.executeUpdate("backup to '" + file.getAbsolutePath() + "'");
/* 131 */     } catch (SQLException e) {
/* 132 */       this.logger.log("SQL Error:" + e.getMessage());
/*     */     } finally {
/* 134 */       if (statement != null)
/*     */         try {
/* 136 */           statement.close();
/* 137 */         } catch (SQLException e) {
/* 138 */           this.logger.log("SQL Error:" + e.getMessage());
/*     */         }  
/*     */     } 
/* 141 */     long end = System.currentTimeMillis();
/* 142 */     this.logger.log("Done in " + (end - start) + " ms.");
/*     */   }
/*     */ 
/*     */   
/*     */   private static void marshall(Model model, Settings settings, Statement statement) throws SQLException {
/* 147 */     FeatureModel fm = model.getFeatureModel();
/* 148 */     TrackModel tm = model.getTrackModel();
/* 149 */     Set<Integer> trackIDs = tm.trackIDs(true);
/* 150 */     Collection<String> spotFeatures = fm.getSpotFeatures();
/* 151 */     Collection<String> edgeFeatures = fm.getEdgeFeatures();
/* 152 */     Collection<String> trackFeatures = fm.getTrackFeatures();
/* 153 */     Map<String, Boolean> intMapSpot = fm.getSpotFeatureIsInt();
/* 154 */     Map<String, Boolean> intMapEdge = fm.getEdgeFeatureIsInt();
/* 155 */     Map<String, Boolean> intMapTrack = fm.getTrackFeatureIsInt();
/* 156 */     String CREATETSPOTQUERY = "CREATE TABLE spots (id INTEGER PRIMARY KEY, track_id INTEGER, ";
/* 157 */     String CREATEEDGEQUERY = "CREATE TABLE edges (id INTEGER PRIMARY KEY, track_id INTEGER, ";
/* 158 */     String CREATETRACKQUERY = "CREATE TABLE tracks (id INTEGER PRIMARY KEY, ";
/*     */ 
/*     */     
/* 161 */     for (String feature : trackFeatures) {
/* 162 */       if (((Boolean)intMapTrack.get(feature)).booleanValue()) {
/* 163 */         CREATETRACKQUERY = String.valueOf(CREATETRACKQUERY) + feature.toLowerCase() + " INTEGER, "; continue;
/*     */       } 
/* 165 */       CREATETRACKQUERY = String.valueOf(CREATETRACKQUERY) + feature.toLowerCase() + " FLOAT (5,8), ";
/*     */     } 
/* 167 */     CREATETRACKQUERY = CREATETRACKQUERY.substring(0, CREATETRACKQUERY.length() - 2);
/* 168 */     CREATETRACKQUERY = String.valueOf(CREATETRACKQUERY) + ")";
/* 169 */     statement.executeUpdate(CREATETRACKQUERY);
/*     */     
/* 171 */     for (String feature : spotFeatures) {
/* 172 */       if (((Boolean)intMapSpot.get(feature)).booleanValue()) {
/* 173 */         CREATETSPOTQUERY = String.valueOf(CREATETSPOTQUERY) + feature.toLowerCase() + " INTEGER, "; continue;
/*     */       } 
/* 175 */       CREATETSPOTQUERY = String.valueOf(CREATETSPOTQUERY) + feature.toLowerCase() + " FLOAT (5,8), ";
/*     */     } 
/* 177 */     CREATETSPOTQUERY = CREATETSPOTQUERY.substring(0, CREATETSPOTQUERY.length() - 2);
/* 178 */     CREATETSPOTQUERY = String.valueOf(CREATETSPOTQUERY) + ", FOREIGN KEY (track_id) REFERENCES tracks(id))";
/* 179 */     statement.executeUpdate(CREATETSPOTQUERY);
/*     */     
/* 181 */     for (String feature : edgeFeatures) {
/* 182 */       if (((Boolean)intMapEdge.get(feature)).booleanValue()) {
/* 183 */         CREATEEDGEQUERY = String.valueOf(CREATEEDGEQUERY) + feature.toLowerCase() + " INTEGER, "; continue;
/*     */       } 
/* 185 */       CREATEEDGEQUERY = String.valueOf(CREATEEDGEQUERY) + feature.toLowerCase() + " FLOAT (5,8), ";
/*     */     } 
/* 187 */     CREATEEDGEQUERY = CREATEEDGEQUERY.substring(0, CREATEEDGEQUERY.length() - 2);
/* 188 */     CREATEEDGEQUERY = String.valueOf(CREATEEDGEQUERY) + ", FOREIGN KEY (track_id) REFERENCES tracks(id))";
/* 189 */     statement.executeUpdate(CREATEEDGEQUERY);
/*     */     
/* 191 */     for (Integer trackID : trackIDs) {
/* 192 */       Set<Spot> trackSpots = tm.trackSpots(trackID);
/* 193 */       Set<DefaultWeightedEdge> trackEdges = tm.trackEdges(trackID);
/*     */ 
/*     */       
/* 196 */       TreeSet<Spot> sortedTrack = new TreeSet<>(Spot.timeComparator);
/* 197 */       sortedTrack.addAll(trackSpots);
/*     */       
/* 199 */       String Track_String = "insert into tracks (id, ";
/* 200 */       for (String feature : trackFeatures)
/* 201 */         Track_String = String.valueOf(Track_String) + feature.toLowerCase() + ", "; 
/* 202 */       Track_String = Track_String.substring(0, Track_String.length() - 2);
/* 203 */       Track_String = String.valueOf(Track_String) + ") values (";
/* 204 */       Track_String = String.valueOf(Track_String) + trackID.intValue() + ", ";
/*     */       
/* 206 */       for (String feature : trackFeatures) {
/* 207 */         Double val = fm.getTrackFeature(trackID, feature);
/* 208 */         if (val == null || Double.isNaN(val.doubleValue()) || Double.isInfinite(val.doubleValue()))
/* 209 */           val = Double.valueOf(0.0D); 
/* 210 */         if (((Boolean)intMapTrack.get(feature)).booleanValue()) {
/* 211 */           Track_String = String.valueOf(Track_String) + String.format("%d, ", new Object[] { Integer.valueOf(val.intValue()) }); continue;
/*     */         } 
/* 213 */         Track_String = String.valueOf(Track_String) + String.format(Locale.US, "%.8f, ", new Object[] { Float.valueOf(val.floatValue()) });
/*     */       } 
/* 215 */       Track_String = Track_String.substring(0, Track_String.length() - 2);
/* 216 */       Track_String = String.valueOf(Track_String) + ")";
/*     */       
/* 218 */       statement.executeUpdate(Track_String);
/*     */       
/* 220 */       for (Spot spot : sortedTrack) {
/* 221 */         String SpotString = "insert into spots (id, track_id, ";
/* 222 */         for (String feature : spotFeatures)
/* 223 */           SpotString = String.valueOf(SpotString) + feature.toLowerCase() + ", "; 
/* 224 */         SpotString = SpotString.substring(0, SpotString.length() - 2);
/* 225 */         SpotString = String.valueOf(SpotString) + ") values (";
/* 226 */         SpotString = String.valueOf(SpotString) + spot.ID() + ", ";
/* 227 */         SpotString = String.valueOf(SpotString) + trackID.intValue() + ", ";
/*     */         
/* 229 */         for (String feature : spotFeatures) {
/* 230 */           Double val = spot.getFeature(feature);
/* 231 */           if (val == null || Double.isNaN(val.doubleValue()) || Double.isInfinite(val.doubleValue()))
/* 232 */             val = Double.valueOf(0.0D); 
/* 233 */           if (((Boolean)intMapSpot.get(feature)).booleanValue()) {
/* 234 */             SpotString = String.valueOf(SpotString) + String.format("%d, ", new Object[] { Integer.valueOf(val.intValue()) }); continue;
/*     */           } 
/* 236 */           SpotString = String.valueOf(SpotString) + String.format(Locale.US, "%.8f, ", new Object[] { Float.valueOf(val.floatValue()) });
/*     */         } 
/* 238 */         SpotString = SpotString.substring(0, SpotString.length() - 2);
/* 239 */         SpotString = String.valueOf(SpotString) + ")";
/*     */         
/* 241 */         statement.executeUpdate(SpotString);
/*     */       } 
/*     */       
/* 244 */       for (DefaultWeightedEdge edge : trackEdges) {
/*     */         
/* 246 */         String EdgeString = "insert into edges (track_id, ";
/* 247 */         for (String feature : edgeFeatures)
/* 248 */           EdgeString = String.valueOf(EdgeString) + feature.toLowerCase() + ", "; 
/* 249 */         EdgeString = EdgeString.substring(0, EdgeString.length() - 2);
/* 250 */         EdgeString = String.valueOf(EdgeString) + ") values (";
/* 251 */         EdgeString = String.valueOf(EdgeString) + trackID.intValue() + ", ";
/*     */         
/* 253 */         for (String feature : edgeFeatures) {
/*     */           
/* 255 */           Double val = fm.getEdgeFeature(edge, feature);
/* 256 */           if (val == null || Double.isNaN(val.doubleValue()) || Double.isInfinite(val.doubleValue()))
/* 257 */             val = Double.valueOf(0.0D); 
/* 258 */           if (((Boolean)intMapEdge.get(feature)).booleanValue()) {
/* 259 */             EdgeString = String.valueOf(EdgeString) + String.format("%d, ", new Object[] { Integer.valueOf(val.intValue()) }); continue;
/*     */           } 
/* 261 */           EdgeString = String.valueOf(EdgeString) + String.format(Locale.US, "%.8f, ", new Object[] { Float.valueOf(val.floatValue()) });
/*     */         } 
/* 263 */         EdgeString = EdgeString.substring(0, EdgeString.length() - 2);
/* 264 */         EdgeString = String.valueOf(EdgeString) + ")";
/*     */         
/* 266 */         statement.executeUpdate(EdgeString);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static Statement createDatabase() throws SQLException {
/*     */     try {
/* 274 */       Class.forName("org.sqlite.JDBC");
/* 275 */     } catch (ClassNotFoundException e) {
/* 276 */       System.err.println(e.getMessage());
/*     */     } 
/* 278 */     Connection connection = null;
/* 279 */     connection = DriverManager.getConnection("jdbc:sqlite::memory:");
/* 280 */     Statement statement = connection.createStatement();
/* 281 */     statement.setQueryTimeout(30);
/* 282 */     statement.executeUpdate("PRAGMA foreign_keys = ON");
/* 283 */     return statement;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Plugin(type = TrackMateActionFactory.class)
/*     */   public static class Factory
/*     */     implements TrackMateActionFactory
/*     */   {
/*     */     public String getInfoText() {
/* 294 */       return "<html>Export the tracks in the current model content to a SQL database <p> The file will have one element per track, and each track contains several spot elements. These spots are sorted by frame number<p>As such, this format <u>cannot</u> handle track merging and splitting properly, and is suited only for non-branching tracks.</html>";
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public String getName() {
/* 300 */       return "Export tracks to SQLITE database";
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public String getKey() {
/* 306 */       return "EXPORT_TRACKS_TO_SQLITE";
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public TrackMateAction create(TrackMateGUIController controller) {
/* 312 */       return (TrackMateAction)new ExportTracksToSQL();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public ImageIcon getIcon() {
/* 318 */       return ExportTracksToSQL.ICON;
/*     */     }
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/RonnyTrackMate_-0.0.6-SNAPSHOT.jar!/net/chicoronny/trackmate/action/ExportTracksToSQL.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */