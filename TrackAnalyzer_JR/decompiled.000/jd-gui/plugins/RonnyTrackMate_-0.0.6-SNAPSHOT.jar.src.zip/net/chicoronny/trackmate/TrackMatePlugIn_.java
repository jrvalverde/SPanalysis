/*     */ package net.chicoronny.trackmate;
/*     */ 
/*     */ import fiji.plugin.trackmate.Model;
/*     */ import fiji.plugin.trackmate.Settings;
/*     */ import fiji.plugin.trackmate.TrackMate;
/*     */ import fiji.plugin.trackmate.gui.GuiUtils;
/*     */ import fiji.plugin.trackmate.gui.TrackMateGUIController;
/*     */ import ij.IJ;
/*     */ import ij.ImageJ;
/*     */ import ij.ImagePlus;
/*     */ import ij.WindowManager;
/*     */ import ij.plugin.PlugIn;
/*     */ import java.awt.Component;
/*     */ import javax.swing.JFrame;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TrackMatePlugIn_
/*     */   implements PlugIn
/*     */ {
/*     */   protected TrackMate trackmate;
/*     */   protected Settings settings;
/*     */   protected Model model;
/*     */   
/*     */   public void run(String imagePath) {
/*     */     ImagePlus imp;
/*  37 */     if (imagePath != null && imagePath.length() > 0) {
/*     */       
/*  39 */       imp = new ImagePlus(imagePath);
/*  40 */       if (imp.getOriginalFileInfo() == null) {
/*     */         
/*  42 */         IJ.error("TrackMate v3.7.0", "Could not load image with path " + imagePath + ".");
/*     */ 
/*     */         
/*     */         return;
/*     */       } 
/*     */     } else {
/*  48 */       imp = WindowManager.getCurrentImage();
/*  49 */       if (imp == null) {
/*     */         
/*  51 */         IJ.error("TrackMate v3.7.0", "Please open an image before running TrackMate.");
/*     */         return;
/*     */       } 
/*     */     } 
/*  55 */     if (!imp.isVisible()) {
/*     */       
/*  57 */       imp.setOpenAsHyperStack(true);
/*  58 */       imp.show();
/*     */     } 
/*  60 */     GuiUtils.userCheckImpDimensions(imp);
/*     */     
/*  62 */     this.settings = createSettings(imp);
/*  63 */     this.model = createModel();
/*  64 */     this.trackmate = createTrackMate();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  70 */     TrackMateGUIController controller = new TrackMateGUIController(this.trackmate);
/*  71 */     if (imp != null)
/*     */     {
/*  73 */       GuiUtils.positionWindow((JFrame)controller.getGUI(), (Component)imp.getWindow());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Model createModel() {
/*  91 */     return new Model();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Settings createSettings(ImagePlus imp) {
/* 104 */     Settings settings = new Settings();
/* 105 */     settings.setFrom(imp);
/* 106 */     return settings;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected TrackMate createTrackMate() {
/* 121 */     String spaceUnits = this.settings.imp.getCalibration().getXUnit();
/* 122 */     String timeUnits = this.settings.imp.getCalibration().getTimeUnit();
/* 123 */     this.model.setPhysicalUnits(spaceUnits, timeUnits);
/*     */     
/* 125 */     return new TrackMate(this.model, this.settings);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void main(String[] args) {
/* 138 */     ImageJ.main(args);
/* 139 */     (new TrackMatePlugIn_()).run("samples/FakeTracks.tif");
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/RonnyTrackMate_-0.0.6-SNAPSHOT.jar!/net/chicoronny/trackmate/TrackMatePlugIn_.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */