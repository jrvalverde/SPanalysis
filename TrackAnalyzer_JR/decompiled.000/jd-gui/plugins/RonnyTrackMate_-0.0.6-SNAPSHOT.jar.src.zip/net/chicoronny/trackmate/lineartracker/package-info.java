package net.chicoronny.trackmate.lineartracker;


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/RonnyTrackMate_-0.0.6-SNAPSHOT.jar!/net/chicoronny/trackmate/lineartracker/package-info.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */