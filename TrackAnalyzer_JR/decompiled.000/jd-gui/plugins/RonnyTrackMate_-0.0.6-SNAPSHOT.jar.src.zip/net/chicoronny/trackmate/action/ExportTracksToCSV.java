/*     */ package net.chicoronny.trackmate.action;
/*     */ 
/*     */ import fiji.plugin.trackmate.Model;
/*     */ import fiji.plugin.trackmate.Spot;
/*     */ import fiji.plugin.trackmate.TrackMate;
/*     */ import fiji.plugin.trackmate.action.AbstractTMAction;
/*     */ import fiji.plugin.trackmate.action.TrackMateAction;
/*     */ import fiji.plugin.trackmate.action.TrackMateActionFactory;
/*     */ import fiji.plugin.trackmate.gui.TrackMateGUIController;
/*     */ import fiji.plugin.trackmate.gui.TrackMateWizard;
/*     */ import ij.io.SaveDialog;
/*     */ import java.io.File;
/*     */ import java.io.FileWriter;
/*     */ import java.io.IOException;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Locale;
/*     */ import java.util.Set;
/*     */ import java.util.TreeSet;
/*     */ import javax.swing.ImageIcon;
/*     */ import org.scijava.plugin.Plugin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ExportTracksToCSV
/*     */   extends AbstractTMAction
/*     */ {
/*     */   public static final String INFO_TEXT = "<html>Export the tracks in the current model content to CSV Files <p> The file will have one element per track, and each track contains several spot elements. These spots are sorted by frame number<p>As such, this format <u>cannot</u> handle track merging and splitting properly, and is suited only for non-branching tracks.</html>";
/*     */   public static final String NAME = "Export tracks to CSV files";
/*     */   public static final String KEY = "EXPORT_TRACKS_TO_CSV";
/*  43 */   public static final ImageIcon ICON = new ImageIcon(TrackMateWizard.class.getResource("images/page_save.png"));
/*     */   
/*     */   public static final String TRACK_ID = "TRACK_ID";
/*     */   
/*     */   public static final String TRACK_MEAN_SPEED = "TRACK_MEAN_SPEED";
/*     */   
/*     */   public static final String TRACK_MAX_SPEED = "TRACK_MAX_SPEED";
/*     */   
/*     */   public static final String TRACK_MIN_SPEED = "TRACK_MIN_SPEED";
/*     */   
/*     */   public static final String TRACK_MEDIAN_SPEED = "TRACK_MEDIAN_SPEED";
/*     */   
/*     */   public static final String TRACK_STD_SPEED = "TRACK_STD_SPEED";
/*     */   
/*     */   public static final String TRACK_DURATION = "TRACK_DURATION";
/*     */   
/*     */   public static final String TRACK_START = "TRACK_START";
/*     */   
/*     */   public static final String TRACK_STOP = "TRACK_STOP";
/*     */   
/*     */   public static final String TRACK_DISPLACEMENT = "TRACK_DISPLACEMENT";
/*     */   
/*  65 */   public static final Collection<String> trackFeatures = new LinkedHashSet<>(
/*  66 */       Arrays.asList(new String[] { "TRACK_ID", "TRACK_MEAN_SPEED", "TRACK_MAX_SPEED", "TRACK_MIN_SPEED", "TRACK_MEDIAN_SPEED", "TRACK_STD_SPEED", 
/*  67 */           "TRACK_DURATION", "TRACK_START", "TRACK_STOP", "TRACK_DISPLACEMENT" }));
/*     */   
/*     */   public static final String CONTRAST = "CONTRAST";
/*     */   
/*     */   public static final String SNR = "SNR";
/*     */   
/*     */   public static final String MEAN_INTENSITY = "MEAN_INTENSITY";
/*     */   
/*     */   public static final String MEDIAN_INTENSITY = "MEDIAN_INTENSITY";
/*     */   
/*     */   public static final String MIN_INTENSITY = "MIN_INTENSITY";
/*     */   
/*     */   public static final String MAX_INTENSITY = "MAX_INTENSITY";
/*     */   
/*     */   public static final String TOTAL_INTENSITY = "TOTAL_INTENSITY";
/*     */   
/*     */   public static final String STANDARD_DEVIATION = "STANDARD_DEVIATION";
/*     */   
/*     */   public static final String AREA = "Area";
/*     */   
/*     */   public static final String CIRC = "Circ.";
/*     */   
/*  89 */   public static Collection<String> spotFeatures = new LinkedHashSet<>(
/*  90 */       Arrays.asList(new String[] { "FRAME", "POSITION_X", "POSITION_Y", "RADIUS", "QUALITY", 
/*  91 */           "Area", "Circ.", "CONTRAST", "SNR", "MEAN_INTENSITY", "MEDIAN_INTENSITY", "MIN_INTENSITY", "MAX_INTENSITY", 
/*  92 */           "TOTAL_INTENSITY", "STANDARD_DEVIATION" }));
/*     */ 
/*     */ 
/*     */   
/*     */   public void execute(TrackMate trackmate) {
/*     */     File folder;
/*     */     String filename;
/*  99 */     this.logger.log("Exporting tracks to CSV files.\n");
/* 100 */     long start = System.currentTimeMillis();
/* 101 */     Model model = trackmate.getModel();
/* 102 */     int ntracks = model.getTrackModel().nTracks(true);
/* 103 */     if (ntracks == 0) {
/* 104 */       this.logger.log("No visible track found. Aborting.\n");
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/*     */     try {
/* 110 */       folder = new File(((trackmate.getSettings()).imp.getOriginalFileInfo()).directory);
/* 111 */     } catch (NullPointerException npe) {
/* 112 */       folder = (new File(System.getProperty("user.dir"))).getParentFile().getParentFile();
/*     */     } 
/*     */ 
/*     */     
/*     */     try {
/* 117 */       filename = (trackmate.getSettings()).imageFileName;
/* 118 */       filename = filename.substring(0, filename.indexOf("."));
/* 119 */       filename = String.valueOf(folder.getPath()) + File.separator + filename + ".csv";
/* 120 */     } catch (NullPointerException npe) {
/* 121 */       filename = String.valueOf(folder.getPath()) + File.separator + "Tracks.csv";
/*     */     } 
/*     */     
/* 124 */     SaveDialog sd = new SaveDialog("Save CSV Files", filename, ".csv");
/* 125 */     String fileName = sd.getFileName();
/*     */     
/* 127 */     if (fileName.isEmpty())
/*     */       return; 
/* 129 */     File fileTracks = new File(String.valueOf(sd.getDirectory()) + fileName.substring(0, fileName.length() - 4) + "_tracks.csv");
/* 130 */     File fileSpots = new File(String.valueOf(sd.getDirectory()) + fileName.substring(0, fileName.length() - 4) + "_spots.csv");
/*     */     
/* 132 */     if (fileTracks.delete()) {
/* 133 */       this.logger.log("File will be overwritten!\n");
/*     */     }
/*     */     try {
/* 136 */       FileWriter writerTracks = new FileWriter(fileTracks);
/* 137 */       FileWriter writerSpots = new FileWriter(fileSpots);
/*     */       
/* 139 */       Set<Integer> trackIDs = model.getTrackModel().trackIDs(true);
/*     */       
/* 141 */       String Header_String = "";
/* 142 */       for (String feature : trackFeatures)
/* 143 */         Header_String = String.valueOf(Header_String) + feature + ", "; 
/* 144 */       Header_String = String.valueOf(Header_String.substring(0, Header_String.length() - 2)) + "\n";
/* 145 */       writerTracks.write(Header_String);
/*     */       
/* 147 */       Header_String = "TrackID, SpotID, ";
/* 148 */       for (String feature : spotFeatures)
/* 149 */         Header_String = String.valueOf(Header_String) + feature + ", "; 
/* 150 */       Header_String = String.valueOf(Header_String.substring(0, Header_String.length() - 2)) + "\n";
/* 151 */       writerSpots.write(Header_String);
/*     */       
/* 153 */       for (Integer trackID : trackIDs) {
/* 154 */         Set<Spot> trackSpots = model.getTrackModel().trackSpots(trackID);
/*     */ 
/*     */         
/* 157 */         TreeSet<Spot> sortedTrack = new TreeSet<>(Spot.timeComparator);
/* 158 */         sortedTrack.addAll(trackSpots);
/*     */         
/* 160 */         String Track_String = "";
/* 161 */         Iterator<String> it = trackFeatures.iterator();
/* 162 */         Double val = model.getFeatureModel().getTrackFeature(trackID, it.next());
/* 163 */         Track_String = String.valueOf(Track_String) + String.format(Locale.US, "%d, ", new Object[] { Integer.valueOf(val.intValue()) });
/*     */         
/* 165 */         while (it.hasNext()) {
/* 166 */           val = model.getFeatureModel().getTrackFeature(trackID, it.next());
/* 167 */           if (val == null || Double.isNaN(val.doubleValue()) || Double.isInfinite(val.doubleValue()))
/* 168 */             val = Double.valueOf(0.0D); 
/* 169 */           Track_String = String.valueOf(Track_String) + String.format(Locale.US, "%.4f, ", new Object[] { Float.valueOf(val.floatValue()) });
/*     */         } 
/* 171 */         Track_String = String.valueOf(Track_String.substring(0, Track_String.length() - 2)) + "\n";
/* 172 */         writerTracks.write(Track_String);
/*     */         
/* 174 */         for (Spot spot : sortedTrack) {
/* 175 */           String Spot_String = "";
/* 176 */           Spot_String = String.valueOf(Spot_String) + String.format(Locale.US, "%d, ", new Object[] { Integer.valueOf(trackID.intValue()) });
/* 177 */           Spot_String = String.valueOf(Spot_String) + String.format(Locale.US, "%d, ", new Object[] { Integer.valueOf(spot.ID()) });
/* 178 */           for (String feature : spotFeatures) {
/* 179 */             Number value = spot.getFeature(feature);
/* 180 */             if (value == null)
/* 181 */               continue;  Spot_String = String.valueOf(Spot_String) + String.format(Locale.US, "%.4f, ", new Object[] { Float.valueOf(value.floatValue()) });
/*     */           } 
/* 183 */           Spot_String = String.valueOf(Spot_String.substring(0, Spot_String.length() - 2)) + "\n";
/* 184 */           writerSpots.write(Spot_String);
/*     */         } 
/*     */       } 
/* 187 */       writerTracks.close();
/* 188 */       writerSpots.close();
/*     */     }
/* 190 */     catch (IOException e) {
/* 191 */       e.printStackTrace();
/*     */     } 
/*     */     
/* 194 */     long end = System.currentTimeMillis();
/* 195 */     this.logger.log("Done in " + (end - start) + " ms.");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Plugin(type = TrackMateActionFactory.class)
/*     */   public static class Factory
/*     */     implements TrackMateActionFactory
/*     */   {
/*     */     public String getInfoText() {
/* 205 */       return "<html>Export the tracks in the current model content to CSV Files <p> The file will have one element per track, and each track contains several spot elements. These spots are sorted by frame number<p>As such, this format <u>cannot</u> handle track merging and splitting properly, and is suited only for non-branching tracks.</html>";
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public String getName() {
/* 211 */       return "Export tracks to CSV files";
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public String getKey() {
/* 217 */       return "EXPORT_TRACKS_TO_CSV";
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public TrackMateAction create(TrackMateGUIController controller) {
/* 223 */       return (TrackMateAction)new ExportTracksToCSV();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public ImageIcon getIcon() {
/* 229 */       return ExportTracksToCSV.ICON;
/*     */     }
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/RonnyTrackMate_-0.0.6-SNAPSHOT.jar!/net/chicoronny/trackmate/action/ExportTracksToCSV.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */