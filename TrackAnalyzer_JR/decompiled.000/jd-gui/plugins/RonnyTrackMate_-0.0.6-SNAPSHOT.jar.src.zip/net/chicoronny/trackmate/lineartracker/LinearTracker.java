/*     */ package net.chicoronny.trackmate.lineartracker;
/*     */ 
/*     */ import fiji.plugin.trackmate.Logger;
/*     */ import fiji.plugin.trackmate.Spot;
/*     */ import fiji.plugin.trackmate.SpotCollection;
/*     */ import fiji.plugin.trackmate.tracking.SpotTracker;
/*     */ import fiji.plugin.trackmate.tracking.kdtree.FlagNode;
/*     */ import fiji.plugin.trackmate.util.TMUtils;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import net.imglib2.KDTree;
/*     */ import net.imglib2.KDTreeNode;
/*     */ import net.imglib2.RealLocalizable;
/*     */ import net.imglib2.RealPoint;
/*     */ import net.imglib2.algorithm.MultiThreaded;
/*     */ import net.imglib2.util.ValuePair;
/*     */ import org.jgrapht.graph.DefaultWeightedEdge;
/*     */ import org.jgrapht.graph.SimpleWeightedGraph;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LinearTracker
/*     */   implements SpotTracker, MultiThreaded
/*     */ {
/*  58 */   private Logger logger = Logger.VOID_LOGGER;
/*     */ 
/*     */   
/*     */   private SimpleWeightedGraph<Spot, DefaultWeightedEdge> graph;
/*     */ 
/*     */   
/*     */   private final SpotCollection spots;
/*     */ 
/*     */   
/*     */   private final Map<String, Object> settings;
/*     */ 
/*     */   
/*     */   private String errorMessage;
/*     */   
/*     */   private int numThreads;
/*     */   
/*  74 */   protected int MAX_GAP = 2;
/*     */   
/*  76 */   private double ANGLE_DIFF = 0.1745D;
/*     */   
/*  78 */   private double LOC_DIFF = 0.26D;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LinearTracker(SpotCollection spots, Map<String, Object> settings) {
/*  89 */     this.spots = spots;
/*  90 */     this.settings = settings;
/*  91 */     this.graph = new SimpleWeightedGraph(DefaultWeightedEdge.class);
/*  92 */     setNumThreads();
/*  93 */     Iterator<Spot> it = spots.iterator(true);
/*  94 */     while (it.hasNext()) {
/*  95 */       this.graph.addVertex(it.next());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SimpleWeightedGraph<Spot, DefaultWeightedEdge> getResult() {
/* 104 */     return this.graph;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean checkInput() {
/* 112 */     StringBuilder errrorHolder = new StringBuilder();
/* 113 */     boolean ok = checkInput(this.settings, errrorHolder);
/* 114 */     if (!ok) {
/* 115 */       this.errorMessage = errrorHolder.toString();
/*     */     }
/* 117 */     return ok;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getErrorMessage() {
/* 125 */     return this.errorMessage;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean process() {
/* 136 */     if (this.spots == null) {
/* 137 */       this.errorMessage = "The spot collection is null.";
/* 138 */       return false;
/*     */     } 
/*     */ 
/*     */     
/* 142 */     if (this.spots.keySet().isEmpty()) {
/* 143 */       this.errorMessage = "The spot collection is empty.";
/* 144 */       return false;
/*     */     } 
/*     */ 
/*     */     
/* 148 */     boolean empty = true;
/* 149 */     for (Iterator<Integer> iterator1 = this.spots.keySet().iterator(); iterator1.hasNext(); ) { int frame = ((Integer)iterator1.next()).intValue();
/* 150 */       if (this.spots.getNSpots(frame, true) > 0) {
/* 151 */         empty = false;
/*     */         break;
/*     */       }  }
/*     */     
/* 155 */     if (empty) {
/* 156 */       this.errorMessage = "The spot collection is empty.";
/* 157 */       return false;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 163 */     double initR = ((Double)this.settings.get("INITIAL_DISTANCE")).doubleValue();
/* 164 */     double succR = ((Double)this.settings.get("SUCCEEDING_DISTANCE")).doubleValue();
/* 165 */     double stickR = ((Double)this.settings.get("STICK_RADIUS")).doubleValue();
/* 166 */     double maxCost = ((Double)this.settings.get("MAX_COST")).doubleValue();
/* 167 */     boolean estimRadius = ((Boolean)this.settings.get("ESTIMATE_RADIUS")).booleanValue();
/*     */ 
/*     */     
/* 170 */     int nFrames = this.spots.keySet().size();
/* 171 */     List<KDTree<FlagNode<Spot>>> treeList = new ArrayList<>(nFrames);
/* 172 */     Iterator<Integer> frameIt = this.spots.keySet().iterator();
/*     */     
/* 174 */     while (frameIt.hasNext()) {
/* 175 */       int curFrame = ((Integer)frameIt.next()).intValue();
/* 176 */       int nNextSpots = this.spots.getNSpots(curFrame, true);
/*     */       
/* 178 */       List<RealPoint> nextCoords = new ArrayList<>(nNextSpots);
/* 179 */       List<FlagNode<Spot>> nextNodes = new ArrayList<>(nNextSpots);
/* 180 */       Iterator<Spot> nextIt = this.spots.iterator(Integer.valueOf(curFrame), true);
/* 181 */       while (nextIt.hasNext()) {
/* 182 */         Spot spot; double[] coords = new double[3];
/*     */ 
/*     */         
/* 185 */         if (estimRadius) {
/* 186 */           spot = LTUtils.RadiusToEstimated(nextIt.next());
/*     */         } else {
/* 188 */           spot = nextIt.next();
/* 189 */         }  TMUtils.localize(spot, coords);
/* 190 */         nextCoords.add(new RealPoint(coords));
/* 191 */         nextNodes.add(new FlagNode(spot));
/*     */       } 
/* 193 */       if (!nextNodes.isEmpty() && !nextCoords.isEmpty()) treeList.add(new KDTree(nextNodes, nextCoords));
/*     */     
/*     */     } 
/* 196 */     nFrames = treeList.size();
/* 197 */     KDTree<FlagNode<Spot>> frameTree = treeList.get(0);
/*     */     
/* 199 */     int dd = 0;
/*     */     
/* 201 */     Map<Integer, ArrayList<DefaultWeightedEdge>> edgesMap = new HashMap<>();
/* 202 */     Integer edgesHash = Integer.valueOf(0);
/* 203 */     KDTree.KDTreeCursor kDTreeCursor = frameTree.cursor();
/* 204 */     while (kDTreeCursor.hasNext()) {
/* 205 */       FlagNode<Spot> source = (FlagNode<Spot>)kDTreeCursor.next();
/*     */       
/* 207 */       int curFrame = 1;
/* 208 */       List<FlagNode<Spot>> nodeList = new ArrayList<>();
/* 209 */       while (curFrame < nFrames) {
/* 210 */         RadiusNeighborFlagSearchOnKDTree bsearch = new RadiusNeighborFlagSearchOnKDTree(treeList.get(curFrame));
/* 211 */         curFrame++;
/* 212 */         bsearch.search((RealLocalizable)source.getValue(), stickR, false);
/* 213 */         if (bsearch.numNeighbors() > 0) {
/* 214 */           ArrayList<ValuePair<KDTreeNode<FlagNode<Spot>>, Double>> cur = bsearch.getResults();
/* 215 */           nodeList.add((FlagNode<Spot>)((KDTreeNode)((ValuePair)cur.get(0)).getA()).get());
/*     */         } 
/*     */       } 
/*     */       
/* 219 */       int burn = (int)Math.round(nFrames * 0.8D);
/* 220 */       if (nodeList.size() > burn) {
/* 221 */         Iterator<FlagNode<Spot>> ii = nodeList.iterator();
/* 222 */         FlagNode<Spot> oldNode = source;
/* 223 */         oldNode.setVisited(true);
/* 224 */         dd++;
/* 225 */         while (ii.hasNext()) {
/* 226 */           FlagNode<Spot> loopNode = ii.next();
/* 227 */           loopNode.setVisited(true);
/*     */           
/* 229 */           Spot begin = (Spot)oldNode.getValue();
/* 230 */           Spot fin = (Spot)loopNode.getValue();
/* 231 */           if (!this.graph.containsEdge(begin, fin)) {
/*     */             
/* 233 */             DefaultWeightedEdge edge = (DefaultWeightedEdge)this.graph.addEdge(begin, fin);
/* 234 */             this.graph.setEdgeWeight(edge, 0.0D);
/*     */           } 
/*     */           
/* 237 */           oldNode = loopNode;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 242 */     this.logger.log("Sticking:" + dd + "\n");
/*     */     
/* 244 */     frameTree = treeList.get(0);
/*     */     
/* 246 */     for (int Tree = 1; Tree < nFrames; Tree++) {
/*     */       
/* 248 */       RadiusNeighborFlagSearchOnKDTree rsearch = new RadiusNeighborFlagSearchOnKDTree(treeList.get(Tree));
/*     */ 
/*     */       
/* 251 */       KDTree.KDTreeCursor kDTreeCursor1 = frameTree.cursor();
/* 252 */       while (kDTreeCursor1.hasNext()) {
/*     */         
/* 254 */         Spot source = (Spot)((FlagNode)kDTreeCursor1.next()).getValue();
/* 255 */         double[] sourceCoords = new double[3];
/* 256 */         TMUtils.localize(source, sourceCoords);
/* 257 */         rsearch.search((RealLocalizable)source, initR, source.getFeature("RADIUS").floatValue(), maxCost, true);
/*     */         
/* 259 */         if (rsearch.numNeighbors() < 1)
/*     */           continue; 
/* 261 */         FlagNode<Spot> foundNode = (FlagNode<Spot>)rsearch.getSampler(0).get();
/*     */ 
/*     */         
/* 264 */         double cost = rsearch.getSquareDistance(0);
/* 265 */         double[] searchCoords = new double[3];
/* 266 */         TMUtils.localize((Spot)foundNode.getValue(), searchCoords);
/* 267 */         double[] preVector = LTUtils.Subtract(searchCoords, sourceCoords);
/* 268 */         double[] estim = new double[3];
/* 269 */         estim[0] = 0.0D;
/* 270 */         estim[1] = 0.0D;
/* 271 */         estim[2] = 0.0D;
/* 272 */         int count = 1;
/* 273 */         FlagNode<Spot> oldNode = foundNode;
/* 274 */         int succFrame = Tree + 1;
/* 275 */         int Run = 0;
/* 276 */         ArrayList<DefaultWeightedEdge> edges = new ArrayList<>();
/*     */         
/* 278 */         while (succFrame < nFrames - 1) {
/* 279 */           RadiusNeighborFlagSearchOnKDTree lsearch = new RadiusNeighborFlagSearchOnKDTree(treeList.get(succFrame));
/* 280 */           estim = LTUtils.Add(estim, preVector);
/* 281 */           double[] estimMean = LTUtils.DivideScalar(estim, count);
/* 282 */           double[] estimCoords = LTUtils.Add(searchCoords, estimMean);
/* 283 */           double[] oldCoords = (double[])searchCoords.clone();
/* 284 */           Spot estimSpot = new Spot(
/* 285 */               estimCoords[0], estimCoords[1], estimCoords[2], ((Spot)oldNode.getValue()).getFeature("RADIUS").doubleValue(), ((Spot)oldNode.getValue()).getFeature(
/* 286 */                 "QUALITY").doubleValue());
/*     */           
/* 288 */           lsearch.search(estimSpot, succR, oldCoords, maxCost, true);
/*     */           
/* 290 */           if (lsearch.numNeighbors() < 1) {
/* 291 */             if (Run < this.MAX_GAP) {
/*     */               
/* 293 */               Run++;
/* 294 */               succFrame++;
/* 295 */               count++;
/*     */               continue;
/*     */             } 
/*     */             break;
/*     */           } 
/* 300 */           Run = 0;
/*     */           
/* 302 */           ValuePair<KDTreeNode<FlagNode<Spot>>, Double> cur = lsearch.getResults().get(0);
/*     */           
/* 304 */           FlagNode<Spot> loopNode = (FlagNode<Spot>)((KDTreeNode)cur.getA()).get();
/* 305 */           cost = ((Double)cur.getB()).doubleValue();
/*     */           
/* 307 */           Spot begin = (Spot)oldNode.getValue();
/* 308 */           Spot fin = (Spot)loopNode.getValue();
/*     */           
/* 310 */           TMUtils.localize(fin, searchCoords);
/* 311 */           preVector = LTUtils.Subtract(searchCoords, oldCoords);
/*     */ 
/*     */           
/* 314 */           if (!this.graph.containsEdge(begin, fin)) {
/* 315 */             DefaultWeightedEdge edge = (DefaultWeightedEdge)this.graph.addEdge(begin, fin);
/* 316 */             this.graph.setEdgeWeight(edge, cost);
/* 317 */             edges.add(edge);
/* 318 */             oldNode.setVisited(true);
/* 319 */             loopNode.setVisited(true);
/*     */           } 
/*     */           
/* 322 */           oldNode = loopNode;
/* 323 */           count++;
/* 324 */           succFrame++;
/*     */         } 
/* 326 */         if (!edges.isEmpty()) { edgesHash = Integer.valueOf(edgesHash.intValue() + 1); edgesMap.put(edgesHash, edges); }
/*     */       
/* 328 */       }  frameTree = treeList.get(Tree);
/* 329 */       this.logger.setProgress((Tree / nFrames));
/*     */     } 
/* 331 */     this.logger.setProgress(1.0D);
/* 332 */     this.logger.setStatus("");
/*     */ 
/*     */     
/* 335 */     int cc = 0;
/* 336 */     for (ArrayList<DefaultWeightedEdge> current : edgesMap.values()) {
/*     */       
/* 338 */       if (current.size() < 1)
/* 339 */         continue;  Spot source = (Spot)this.graph.getEdgeSource(current.get(current.size() - 1));
/* 340 */       Spot target = (Spot)this.graph.getEdgeTarget(current.get(current.size() - 1));
/*     */       
/* 342 */       double x1 = source.getDoublePosition(0);
/* 343 */       double y1 = source.getDoublePosition(1);
/* 344 */       double x2 = target.getDoublePosition(0);
/* 345 */       double y2 = target.getDoublePosition(1);
/*     */       
/* 347 */       double angle = Math.atan2(y2 - y1, x2 - x1);
/*     */       
/* 349 */       ArrayList<ValuePair<Spot, Double>> resultPoints = new ArrayList<>();
/*     */       
/* 351 */       Map<Integer, ArrayList<DefaultWeightedEdge>> reducedSet = new HashMap<>(edgesMap);
/* 352 */       for (ArrayList<DefaultWeightedEdge> icurrent : reducedSet.values()) {
/* 353 */         Spot isource = (Spot)this.graph.getEdgeSource(icurrent.get(0));
/* 354 */         Spot itarget = (Spot)this.graph.getEdgeTarget(icurrent.get(0));
/*     */         
/* 356 */         double ix1 = isource.getDoublePosition(0);
/* 357 */         double iy1 = isource.getDoublePosition(1);
/* 358 */         double ix2 = itarget.getDoublePosition(0);
/* 359 */         double iy2 = itarget.getDoublePosition(1);
/*     */         
/* 361 */         double iangle = Math.atan2(iy2 - iy1, ix2 - ix1);
/* 362 */         double zangle = Math.atan2(iy1 - y2, ix1 - x2);
/* 363 */         double diffa = Math.abs(iangle - angle);
/* 364 */         double diffb = Math.abs(zangle - angle);
/*     */ 
/*     */         
/* 367 */         double linkgap = Math.abs(isource.diffTo(target, "FRAME"));
/*     */         
/* 369 */         if (diffa < this.ANGLE_DIFF && diffb < this.LOC_DIFF && linkgap < (this.MAX_GAP * 2)) {
/*     */           
/* 371 */           double spotRadiusDiff = 1.0D + Math.abs(isource.getFeature("RADIUS").floatValue() - 
/* 372 */               target.getFeature("RADIUS").floatValue()) * 1.5D;
/* 373 */           double angleSum = (diffa + diffb) * 180.0D / Math.PI;
/* 374 */           double cost = target.squareDistanceTo(isource) / 4.0D + spotRadiusDiff + angleSum / 10.0D;
/* 375 */           if (cost < maxCost) resultPoints.add(new ValuePair(isource, Double.valueOf(cost)));
/*     */         
/*     */         } 
/*     */       } 
/* 379 */       if (!resultPoints.isEmpty()) {
/* 380 */         Collections.sort(resultPoints, new Comparator<ValuePair<Spot, Double>>()
/*     */             {
/*     */               public int compare(ValuePair<Spot, Double> o1, ValuePair<Spot, Double> o2) {
/* 383 */                 return Double.compare(((Double)o1.b).doubleValue(), ((Double)o2.b).doubleValue());
/*     */               }
/*     */             });
/* 386 */         ValuePair<Spot, Double> res = resultPoints.get(0);
/* 387 */         if (!this.graph.containsEdge(target, res.getA())) {
/* 388 */           DefaultWeightedEdge newEdge = (DefaultWeightedEdge)this.graph.addEdge(target, res.getA());
/* 389 */           this.graph.setEdgeWeight(newEdge, ((Double)res.getB()).doubleValue());
/*     */           
/* 391 */           cc++;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 396 */     this.logger.log("2nd run:" + cc + " added edges\n");
/*     */ 
/*     */     
/* 399 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLogger(Logger logger) {
/* 407 */     this.logger = logger;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean checkInput(Map<String, Object> settings, StringBuilder errorHolder) {
/* 420 */     boolean ok = true;
/* 421 */     ok &= TMUtils.checkParameter(settings, "INITIAL_DISTANCE", Double.class, errorHolder);
/* 422 */     ok &= TMUtils.checkParameter(settings, "SUCCEEDING_DISTANCE", Double.class, errorHolder);
/* 423 */     ok &= TMUtils.checkParameter(settings, "STICK_RADIUS", Double.class, errorHolder);
/* 424 */     ok &= TMUtils.checkParameter(settings, "MAX_COST", Double.class, errorHolder);
/* 425 */     ok &= TMUtils.checkParameter(settings, "ESTIMATE_RADIUS", Boolean.class, errorHolder);
/* 426 */     List<String> mandatoryKeys = new ArrayList<>();
/* 427 */     mandatoryKeys.add("INITIAL_DISTANCE");
/* 428 */     mandatoryKeys.add("SUCCEEDING_DISTANCE");
/* 429 */     mandatoryKeys.add("STICK_RADIUS");
/* 430 */     mandatoryKeys.add("MAX_COST");
/* 431 */     mandatoryKeys.add("ESTIMATE_RADIUS");
/* 432 */     ok &= TMUtils.checkMapKeys(settings, mandatoryKeys, null, errorHolder);
/* 433 */     return ok;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setNumThreads() {
/* 443 */     this.numThreads = Runtime.getRuntime().availableProcessors();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setNumThreads(int numThreads) {
/* 452 */     this.numThreads = numThreads;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getNumThreads() {
/* 461 */     return this.numThreads;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/RonnyTrackMate_-0.0.6-SNAPSHOT.jar!/net/chicoronny/trackmate/lineartracker/LinearTracker.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */