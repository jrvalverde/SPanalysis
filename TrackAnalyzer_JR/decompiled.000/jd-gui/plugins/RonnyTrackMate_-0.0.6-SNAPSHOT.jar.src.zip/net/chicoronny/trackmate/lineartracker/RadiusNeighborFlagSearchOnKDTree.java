/*     */ package net.chicoronny.trackmate.lineartracker;
/*     */ 
/*     */ import fiji.plugin.trackmate.Spot;
/*     */ import fiji.plugin.trackmate.tracking.kdtree.FlagNode;
/*     */ import fiji.plugin.trackmate.util.TMUtils;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import net.imglib2.KDTree;
/*     */ import net.imglib2.KDTreeNode;
/*     */ import net.imglib2.RealLocalizable;
/*     */ import net.imglib2.Sampler;
/*     */ import net.imglib2.neighborsearch.RadiusNeighborSearch;
/*     */ import net.imglib2.util.ValuePair;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RadiusNeighborFlagSearchOnKDTree
/*     */   implements RadiusNeighborSearch<FlagNode<Spot>>
/*     */ {
/*     */   protected KDTree<FlagNode<Spot>> tree;
/*     */   protected final int n;
/*     */   protected final double[] pos;
/*     */   protected ArrayList<ValuePair<KDTreeNode<FlagNode<Spot>>, Double>> resultPoints;
/*     */   
/*     */   public RadiusNeighborFlagSearchOnKDTree(KDTree<FlagNode<Spot>> tree) {
/*  43 */     this.n = tree.numDimensions();
/*  44 */     this.pos = new double[this.n];
/*  45 */     this.tree = tree;
/*  46 */     this.resultPoints = new ArrayList<>();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void searchNode(KDTreeNode<FlagNode<Spot>> current, double squRadius, float spotRadius, float quality, double[] oldCoords, double maxCost) {
/*  71 */     double squDistance = current.squDistanceTo(this.pos);
/*  72 */     boolean visited = ((FlagNode)current.get()).isVisited();
/*  73 */     Spot currentSpot = (Spot)((FlagNode)current.get()).getValue();
/*     */     
/*  75 */     double[] currentPos = new double[3];
/*  76 */     TMUtils.localize(currentSpot, currentPos);
/*     */     
/*  78 */     if (squDistance <= squRadius && !visited) {
/*     */       
/*  80 */       double[] longVector = LTUtils.Subtract(this.pos, oldCoords);
/*     */       
/*  82 */       double qualityDiff = Math.abs(currentSpot.getFeature("QUALITY").floatValue() - quality);
/*     */       
/*  84 */       double spotRadiusDiff = 1.0D + Math.abs(currentSpot.getFeature("RADIUS").floatValue() - spotRadius) * 3.0D;
/*     */       
/*  86 */       double angle = LTUtils.angleFromVectors(longVector, LTUtils.Subtract(currentPos, oldCoords));
/*     */       
/*  88 */       double cost = squDistance / 8.0D + spotRadiusDiff + qualityDiff / 4.0D + angle;
/*     */       
/*  90 */       if (cost < maxCost) {
/*  91 */         this.resultPoints.add(new ValuePair(current, Double.valueOf(cost)));
/*     */       }
/*     */     } 
/*  94 */     double axisDiff = this.pos[current.getSplitDimension()] - current.getSplitCoordinate();
/*  95 */     double axisSquDistance = axisDiff * axisDiff;
/*  96 */     boolean leftIsNearBranch = (axisDiff < 0.0D);
/*     */ 
/*     */     
/*  99 */     KDTreeNode<FlagNode<Spot>> nearChild = leftIsNearBranch ? current.left : current.right;
/* 100 */     KDTreeNode<FlagNode<Spot>> awayChild = leftIsNearBranch ? current.right : current.left;
/* 101 */     if (nearChild != null) {
/* 102 */       searchNode(nearChild, squRadius, spotRadius, quality, oldCoords, maxCost);
/*     */     }
/*     */     
/* 105 */     if (axisSquDistance <= squRadius && awayChild != null) {
/* 106 */       searchNode(awayChild, squRadius, spotRadius, quality, oldCoords, maxCost);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ArrayList<ValuePair<KDTreeNode<FlagNode<Spot>>, Double>> getResults() {
/* 115 */     return this.resultPoints;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int numDimensions() {
/* 123 */     return this.n;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getDistance(int i) {
/* 131 */     return Math.sqrt(((Double)((ValuePair)this.resultPoints.get(i)).b).doubleValue());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RealLocalizable getPosition(int i) {
/* 139 */     return (RealLocalizable)((ValuePair)this.resultPoints.get(i)).a;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Sampler<FlagNode<Spot>> getSampler(int i) {
/* 147 */     return (Sampler<FlagNode<Spot>>)((ValuePair)this.resultPoints.get(i)).a;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getSquareDistance(int i) {
/* 155 */     return ((Double)((ValuePair)this.resultPoints.get(i)).b).doubleValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int numNeighbors() {
/* 163 */     return this.resultPoints.size();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void search(Spot reference, double radius, double[] oldCoords, double maxCost, boolean sortResults) {
/* 181 */     TMUtils.localize(reference, this.pos);
/* 182 */     float sourceSpotRadius = reference.getFeature("RADIUS").floatValue();
/* 183 */     float quality = reference.getFeature("QUALITY").floatValue();
/* 184 */     this.resultPoints.clear();
/* 185 */     searchNode(this.tree.getRoot(), radius * radius, sourceSpotRadius, quality, oldCoords, maxCost);
/* 186 */     if (sortResults) {
/* 187 */       Collections.sort(this.resultPoints, 
/* 188 */           new Comparator<ValuePair<KDTreeNode<FlagNode<Spot>>, Double>>()
/*     */           {
/*     */             
/*     */             public int compare(ValuePair<KDTreeNode<FlagNode<Spot>>, Double> o1, ValuePair<KDTreeNode<FlagNode<Spot>>, Double> o2)
/*     */             {
/* 193 */               return Double.compare(((Double)o1.b).doubleValue(), ((Double)o2.b).doubleValue());
/*     */             }
/*     */           });
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void search(RealLocalizable reference, double radius, boolean sortResults) {
/* 205 */     assert radius >= 0.0D;
/* 206 */     reference.localize(this.pos);
/* 207 */     this.resultPoints.clear();
/* 208 */     searchNode(this.tree.getRoot(), radius * radius, 3.0F, 255.0F, new double[3], 100000.0D);
/* 209 */     if (sortResults) {
/* 210 */       Collections.sort(this.resultPoints, 
/* 211 */           new Comparator<ValuePair<KDTreeNode<FlagNode<Spot>>, Double>>()
/*     */           {
/*     */             public int compare(ValuePair<KDTreeNode<FlagNode<Spot>>, Double> o1, ValuePair<KDTreeNode<FlagNode<Spot>>, Double> o2) {
/* 214 */               return Double.compare(((Double)o1.b).doubleValue(), ((Double)o2.b).doubleValue());
/*     */             }
/*     */           });
/*     */     }
/*     */   }
/*     */   
/*     */   public void search(RealLocalizable reference, double radius, float spotRadius, double maxCost, boolean sortResults) {
/* 221 */     assert radius >= 0.0D;
/* 222 */     reference.localize(this.pos);
/* 223 */     this.resultPoints.clear();
/* 224 */     searchNode(this.tree.getRoot(), radius * radius, spotRadius, 255.0F, new double[3], maxCost);
/* 225 */     if (sortResults)
/* 226 */       Collections.sort(this.resultPoints, 
/* 227 */           new Comparator<ValuePair<KDTreeNode<FlagNode<Spot>>, Double>>()
/*     */           {
/*     */             public int compare(ValuePair<KDTreeNode<FlagNode<Spot>>, Double> o1, ValuePair<KDTreeNode<FlagNode<Spot>>, Double> o2) {
/* 230 */               return Double.compare(((Double)o1.b).doubleValue(), ((Double)o2.b).doubleValue());
/*     */             }
/*     */           }); 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/RonnyTrackMate_-0.0.6-SNAPSHOT.jar!/net/chicoronny/trackmate/lineartracker/RadiusNeighborFlagSearchOnKDTree.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */