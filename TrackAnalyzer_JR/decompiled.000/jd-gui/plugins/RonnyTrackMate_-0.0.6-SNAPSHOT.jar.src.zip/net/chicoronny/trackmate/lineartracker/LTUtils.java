/*     */ package net.chicoronny.trackmate.lineartracker;
/*     */ 
/*     */ import fiji.plugin.trackmate.Spot;
/*     */ import java.io.File;
/*     */ import java.io.FileFilter;
/*     */ import java.util.Collection;
/*     */ import java.util.LinkedList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LTUtils
/*     */ {
/*     */   public static final double[] Subtract(double[] first, double[] second) {
/*  21 */     assert first.length == 3;
/*  22 */     assert second.length == 3;
/*  23 */     double[] res = new double[3];
/*  24 */     res[0] = first[0] - second[0];
/*  25 */     res[1] = first[1] - second[1];
/*  26 */     res[2] = first[2] - second[2];
/*  27 */     return res;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final double[] Add(double[] first, double[] second) {
/*  40 */     assert first.length == 3;
/*  41 */     assert second.length == 3;
/*  42 */     double[] res = new double[3];
/*  43 */     res[0] = first[0] + second[0];
/*  44 */     res[1] = first[1] + second[1];
/*  45 */     res[2] = first[2] + second[2];
/*  46 */     return res;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final double[] DivideScalar(double[] first, double second) {
/*  59 */     assert first.length == 3;
/*  60 */     assert second != 0.0D;
/*  61 */     double[] res = new double[3];
/*  62 */     res[0] = first[0] / second;
/*  63 */     res[1] = first[1] / second;
/*  64 */     res[2] = first[2] / second;
/*  65 */     return res;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final double angleFromVectors(double[] first, double[] second) {
/*  80 */     assert first.length == 3;
/*  81 */     assert second.length == 3;
/*  82 */     double lenFirst = Math.sqrt(first[0] * first[0] + first[1] * first[1] + first[2] * first[2]);
/*  83 */     double lenSecond = Math.sqrt(second[0] * second[0] + second[1] * second[1] + second[2] * second[2]);
/*  84 */     double dotProduct = first[0] * second[0] + first[1] * second[1] + first[2] * second[2];
/*  85 */     if (lenFirst == 0.0D || lenSecond == 0.0D)
/*  86 */       return 0.0D; 
/*  87 */     return Math.acos(Math.abs(dotProduct / lenFirst * lenSecond)) * 180.0D / Math.PI;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final Spot RadiusToEstimated(Spot spot) {
/*  98 */     Double diameter = spot.getFeature("ESTIMATED_DIAMETER");
/*  99 */     if (diameter == null || diameter.doubleValue() == 0.0D) {
/* 100 */       return spot;
/*     */     }
/* 102 */     spot.putFeature("RADIUS", Double.valueOf(diameter.doubleValue() / 2.0D));
/* 103 */     return spot;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Collection<File> listFiles(File dir, String[] ext) {
/* 117 */     if (!dir.isDirectory())
/* 118 */       throw new IllegalArgumentException("Parameter 'dir' is not a directory"); 
/* 119 */     if (ext == null) {
/* 120 */       throw new NullPointerException("Parameter 'ext' is null");
/*     */     }
/* 122 */     String[] suffixes = new String[ext.length];
/* 123 */     for (int i = 0; i < ext.length; i++) {
/* 124 */       suffixes[i] = "." + ext[i];
/*     */     }
/*     */     class SuffixFileFilter
/*     */       implements FileFilter
/*     */     {
/*     */       private String[] suffixes;
/*     */       
/*     */       public SuffixFileFilter(String[] suffixes) {
/* 132 */         if (suffixes == null)
/* 133 */           throw new IllegalArgumentException("The array of suffixes must not be null"); 
/* 134 */         this.suffixes = suffixes;
/*     */       }
/*     */ 
/*     */ 
/*     */       
/*     */       public boolean accept(File file) {
/* 140 */         if (file.isDirectory()) return true; 
/* 141 */         String name = file.getName();
/* 142 */         for (int i = 0; i < this.suffixes.length; i++) {
/* 143 */           if (name.endsWith(this.suffixes[i]))
/* 144 */             return true; 
/*     */         } 
/* 146 */         return false;
/*     */       }
/*     */     };
/*     */     
/* 150 */     FileFilter filter = new SuffixFileFilter(suffixes);
/*     */     
/* 152 */     Collection<File> files = new LinkedList<>();
/* 153 */     innerListFiles(files, dir, filter);
/*     */     
/* 155 */     return files;
/*     */   }
/*     */   
/*     */   private static void innerListFiles(Collection<File> files, File dir, FileFilter filter) {
/* 159 */     File[] found = dir.listFiles(filter);
/* 160 */     if (found != null)
/* 161 */       for (int i = 0; i < found.length; i++) {
/* 162 */         if (found[i].isDirectory()) {
/* 163 */           innerListFiles(files, found[i], filter);
/*     */         } else {
/* 165 */           files.add(found[i]);
/*     */         } 
/*     */       }  
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/RonnyTrackMate_-0.0.6-SNAPSHOT.jar!/net/chicoronny/trackmate/lineartracker/LTUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */