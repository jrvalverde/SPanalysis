/*    */ package com.orsonpdf;
/*    */ 
/*    */ import com.orsonpdf.util.Args;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class Function
/*    */   extends PDFObject
/*    */ {
/*    */   private FunctionType functionType;
/*    */   private double[] domain;
/*    */   protected Dictionary dictionary;
/*    */   
/*    */   protected Function(int number, FunctionType functionType) {
/* 38 */     super(number);
/* 39 */     Args.nullNotPermitted(functionType, "functionType");
/* 40 */     this.functionType = functionType;
/* 41 */     this.domain = new double[] { 0.0D, 1.0D };
/* 42 */     this.dictionary = new Dictionary();
/* 43 */     this.dictionary.put("/Domain", PDFUtils.toPDFArray(this.domain));
/* 44 */     this.dictionary.put("/FunctionType", String.valueOf(functionType.getNumber()));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public FunctionType getFunctionType() {
/* 54 */     return this.functionType;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public double[] getDomain() {
/* 63 */     return (double[])this.domain.clone();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setDomain(double[] domain) {
/* 72 */     Args.nullNotPermitted(domain, "domain");
/* 73 */     this.domain = (double[])domain.clone();
/* 74 */     this.dictionary.put("/Domain", PDFUtils.toPDFArray(this.domain));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public byte[] getObjectBytes() {
/* 85 */     return this.dictionary.toPDFBytes();
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsonpdf-1.6-eval.jar!/com/orsonpdf/Function.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */