/*     */ package com.orsonpdf;
/*     */ 
/*     */ import com.orsonpdf.filter.Filter;
/*     */ import com.orsonpdf.util.Args;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Stream
/*     */   extends PDFObject
/*     */ {
/*     */   private List<Filter> filters;
/*     */   
/*     */   Stream(int number) {
/*  35 */     super(number);
/*  36 */     this.filters = new ArrayList<Filter>();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addFilter(Filter f) {
/*  47 */     Args.nullNotPermitted(f, "f");
/*  48 */     this.filters.add(f);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeFilters() {
/*  57 */     this.filters.clear();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getObjectBytes() throws IOException {
/*  70 */     ByteArrayOutputStream baos = new ByteArrayOutputStream();
/*  71 */     byte[] streamData = getRawStreamData();
/*  72 */     for (Filter f : this.filters) {
/*  73 */       streamData = f.encode(streamData);
/*     */     }
/*  75 */     Dictionary dictionary = createDictionary(streamData.length);
/*  76 */     baos.write(dictionary.toPDFBytes());
/*  77 */     baos.write(PDFUtils.toBytes("stream\n"));
/*  78 */     baos.write(streamData);
/*  79 */     baos.write(PDFUtils.toBytes("endstream\n"));
/*  80 */     return baos.toByteArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Dictionary createDictionary(int streamLength) {
/*  93 */     Dictionary dictionary = new Dictionary();
/*  94 */     dictionary.put("/Length", Integer.valueOf(streamLength));
/*  95 */     if (!this.filters.isEmpty()) {
/*  96 */       String[] decodes = new String[this.filters.size()];
/*  97 */       int count = this.filters.size();
/*  98 */       for (int i = 0; i < count; i++) {
/*  99 */         Filter f = this.filters.get(count - i - 1);
/* 100 */         decodes[i] = f.getFilterType().getDecode();
/*     */       } 
/* 102 */       dictionary.put("/Filter", decodes);
/*     */     } 
/* 104 */     return dictionary;
/*     */   }
/*     */   
/*     */   public abstract byte[] getRawStreamData();
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsonpdf-1.6-eval.jar!/com/orsonpdf/Stream.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */