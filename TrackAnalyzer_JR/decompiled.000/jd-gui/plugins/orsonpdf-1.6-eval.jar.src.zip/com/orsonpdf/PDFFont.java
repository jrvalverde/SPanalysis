/*     */ package com.orsonpdf;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PDFFont
/*     */   extends PDFObject
/*     */ {
/*     */   public static final String HELVETICA = "Helvetica";
/*     */   public static final String HELVETICA_BOLD = "Helvetica-Bold";
/*     */   public static final String HELVETICA_OBLIQUE = "Helvetica-Oblique";
/*     */   public static final String HELVETICA_BOLDOBLIQUE = "Helvetica-BoldOblique";
/*     */   public static final String TIMES_ROMAN = "Times-Roman";
/*     */   public static final String TIMES_BOLD = "Times-Bold";
/*     */   public static final String TIMES_ITALIC = "Times-Italic";
/*     */   public static final String TIMES_BOLDITALIC = "Times-BoldItalic";
/*     */   public static final String COURIER = "Courier";
/*     */   public static final String COURIER_BOLD = "Courier-Bold";
/*     */   public static final String COURIER_ITALIC = "Courier-Italic";
/*     */   public static final String COURIER_BOLDITALIC = "Courier-BoldItalic";
/*     */   private String name;
/*     */   private String baseFont;
/*     */   private String encoding;
/*     */   
/*     */   PDFFont(int number, int generation, String name, String baseFont, String encoding) {
/*  72 */     super(number, generation);
/*  73 */     this.name = name;
/*  74 */     this.baseFont = baseFont;
/*  75 */     this.encoding = encoding;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/*  85 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getObjectBytes() {
/*  96 */     return createDictionary().toPDFBytes();
/*     */   }
/*     */   
/*     */   private Dictionary createDictionary() {
/* 100 */     Dictionary dictionary = new Dictionary("/Font");
/* 101 */     dictionary.put("/Subtype", "/Type1");
/* 102 */     dictionary.put("/Name", this.name);
/* 103 */     dictionary.put("/BaseFont", this.baseFont);
/* 104 */     dictionary.put("/Encoding", this.encoding);
/* 105 */     return dictionary;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsonpdf-1.6-eval.jar!/com/orsonpdf/PDFFont.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */