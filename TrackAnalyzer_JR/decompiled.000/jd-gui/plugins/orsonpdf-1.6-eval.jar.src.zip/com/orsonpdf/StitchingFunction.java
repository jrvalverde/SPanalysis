/*    */ package com.orsonpdf;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class StitchingFunction
/*    */   extends Function
/*    */ {
/*    */   private Function[] functions;
/*    */   private float[] bounds;
/*    */   private float[] encode;
/*    */   
/*    */   public StitchingFunction(int number, Function[] functions, float[] bounds, float[] encode) {
/* 34 */     super(number, FunctionType.STITCHING);
/* 35 */     this.functions = functions;
/* 36 */     this.dictionary.put("/Functions", functions);
/* 37 */     this.bounds = bounds;
/* 38 */     this.dictionary.put("/Bounds", bounds);
/* 39 */     this.encode = encode;
/* 40 */     this.dictionary.put("/Encode", encode);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsonpdf-1.6-eval.jar!/com/orsonpdf/StitchingFunction.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */