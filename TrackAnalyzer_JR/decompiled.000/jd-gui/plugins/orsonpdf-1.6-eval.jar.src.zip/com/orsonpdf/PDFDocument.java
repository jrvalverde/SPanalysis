/*     */ package com.orsonpdf;
/*     */ 
/*     */ import com.orsonpdf.util.Args;
/*     */ import java.awt.geom.Rectangle2D;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Date;
/*     */ import java.util.List;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PDFDocument
/*     */ {
/*  44 */   private static final Logger LOGGER = Logger.getLogger(PDFDocument.class.getName());
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String PRODUCER = "OrsonPDF 1.6-eval";
/*     */ 
/*     */   
/*     */   private static final boolean EVAL_VERSION = true;
/*     */ 
/*     */   
/*     */   private DictionaryObject catalog;
/*     */ 
/*     */   
/*     */   private DictionaryObject outlines;
/*     */ 
/*     */   
/*     */   private DictionaryObject info;
/*     */ 
/*     */   
/*     */   private String title;
/*     */ 
/*     */   
/*     */   private String author;
/*     */ 
/*     */   
/*     */   private Pages pages;
/*     */ 
/*     */   
/*     */   private List<PDFObject> otherObjects;
/*     */ 
/*     */   
/*  75 */   private int nextNumber = 1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private GraphicsStream evaluationGraphicsStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean debug;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PDFDocument() {
/*  96 */     this.catalog = new DictionaryObject(this.nextNumber++, "/Catalog");
/*  97 */     this.outlines = new DictionaryObject(this.nextNumber++, "/Outlines");
/*  98 */     this.info = new DictionaryObject(this.nextNumber++, "/Info");
/*  99 */     StringBuilder producer = (new StringBuilder("(")).append("OrsonPDF 1.6-eval");
/*     */     
/* 101 */     producer.append(" Evaluation Version");
/*     */     
/* 103 */     producer.append(")");
/* 104 */     this.info.put("Producer", producer.toString());
/* 105 */     Date now = new Date();
/* 106 */     String creationDateStr = "(" + PDFUtils.toDateFormat(now) + ")";
/* 107 */     this.info.put("CreationDate", creationDateStr);
/* 108 */     this.info.put("ModDate", creationDateStr);
/* 109 */     this.outlines.put("Count", Integer.valueOf(0));
/* 110 */     this.catalog.put("Outlines", this.outlines);
/* 111 */     this.pages = new Pages(this.nextNumber++, 0, this);
/* 112 */     this.catalog.put("Pages", this.pages);
/* 113 */     this.otherObjects = new ArrayList<PDFObject>();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final boolean isEvaluationVersion() {
/* 124 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final GraphicsStream getEvaluationWatermark() {
/* 134 */     return this.evaluationGraphicsStream;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final void setEvaluationWatermark(GraphicsStream gs) {
/* 144 */     if (gs != null) {
/* 145 */       this.otherObjects.add(gs);
/*     */     }
/* 147 */     this.evaluationGraphicsStream = gs;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getTitle() {
/* 157 */     return this.title;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTitle(String title) {
/* 166 */     this.title = title;
/* 167 */     if (title != null) {
/* 168 */       this.info.put("Title", "(" + title + ")");
/*     */     } else {
/* 170 */       this.info.remove("Title");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getAuthor() {
/* 181 */     return this.author;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAuthor(String author) {
/* 190 */     this.author = author;
/* 191 */     if (author != null) {
/* 192 */       this.info.put("Author", "(" + this.author + ")");
/*     */     } else {
/* 194 */       this.info.remove("Author");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isDebugMode() {
/* 207 */     return this.debug;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDebugMode(boolean debug) {
/* 219 */     this.debug = debug;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Page createPage(Rectangle2D bounds) {
/* 231 */     Page page = new Page(this.nextNumber++, 0, this.pages, bounds, !this.debug);
/*     */     
/* 233 */     this.pages.add(page);
/* 234 */     return page;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addObject(PDFObject object) {
/* 243 */     Args.nullNotPermitted(object, "object");
/* 244 */     this.otherObjects.add(object);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getNextNumber() {
/* 255 */     int result = this.nextNumber;
/* 256 */     this.nextNumber++;
/* 257 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getPDFBytes() {
/* 266 */     int[] xref = new int[this.nextNumber];
/* 267 */     ByteArrayOutputStream bos = new ByteArrayOutputStream();
/*     */     try {
/* 269 */       bos.write(toBytes("%PDF-1.4\n"));
/* 270 */       bos.write(new byte[] { 37, Byte.MIN_VALUE, -127, -126, -125, 10 });
/*     */       
/* 272 */       xref[this.catalog.getNumber() - 1] = bos.size();
/* 273 */       bos.write(this.catalog.toPDFBytes());
/* 274 */       xref[this.outlines.getNumber() - 1] = bos.size();
/* 275 */       bos.write(this.outlines.toPDFBytes());
/* 276 */       xref[this.info.getNumber() - 1] = bos.size();
/* 277 */       bos.write(this.info.toPDFBytes());
/* 278 */       xref[this.pages.getNumber() - 1] = bos.size();
/* 279 */       bos.write(this.pages.toPDFBytes());
/* 280 */       for (Page page : this.pages.getPages()) {
/* 281 */         xref[page.getNumber() - 1] = bos.size();
/* 282 */         bos.write(page.toPDFBytes());
/* 283 */         PDFObject contents = page.getContents();
/* 284 */         xref[contents.getNumber() - 1] = bos.size();
/* 285 */         bos.write(contents.toPDFBytes());
/*     */       } 
/* 287 */       for (PDFFont font : this.pages.getFonts()) {
/* 288 */         xref[font.getNumber() - 1] = bos.size();
/* 289 */         bos.write(font.toPDFBytes());
/*     */       } 
/* 291 */       for (PDFObject object : this.otherObjects) {
/* 292 */         xref[object.getNumber() - 1] = bos.size();
/* 293 */         bos.write(object.toPDFBytes());
/*     */       } 
/* 295 */       xref[xref.length - 1] = bos.size();
/*     */       
/* 297 */       bos.write(toBytes("xref\n"));
/* 298 */       bos.write(toBytes("0 " + String.valueOf(this.nextNumber) + "\n"));
/*     */       
/* 300 */       bos.write(toBytes("0000000000 65535 f \n"));
/* 301 */       for (int i = 0; i < this.nextNumber - 1; i++) {
/* 302 */         String offset = String.valueOf(xref[i]);
/* 303 */         int len = offset.length();
/* 304 */         String offset10 = "0000000000".substring(len) + offset;
/* 305 */         bos.write(toBytes(offset10 + " 00000 n \n"));
/*     */       } 
/*     */ 
/*     */       
/* 309 */       bos.write(toBytes("trailer\n"));
/* 310 */       Dictionary trailer = new Dictionary();
/* 311 */       trailer.put("/Size", Integer.valueOf(this.nextNumber));
/* 312 */       trailer.put("/Root", this.catalog);
/* 313 */       trailer.put("/Info", this.info);
/* 314 */       bos.write(trailer.toPDFBytes());
/* 315 */       bos.write(toBytes("startxref\n"));
/* 316 */       bos.write(toBytes(String.valueOf(xref[this.nextNumber - 1]) + "\n"));
/*     */       
/* 318 */       bos.write(toBytes("%%EOF"));
/* 319 */     } catch (IOException ex) {
/* 320 */       throw new RuntimeException(ex);
/*     */     } 
/* 322 */     return bos.toByteArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeToFile(File f) {
/* 332 */     FileOutputStream fos = null;
/*     */     try {
/* 334 */       fos = new FileOutputStream(f);
/* 335 */       fos.write(getPDFBytes());
/* 336 */     } catch (FileNotFoundException ex) {
/* 337 */       LOGGER.log(Level.SEVERE, (String)null, ex);
/* 338 */     } catch (IOException ex) {
/* 339 */       LOGGER.log(Level.SEVERE, (String)null, ex);
/*     */     } finally {
/*     */       try {
/* 342 */         if (fos != null) {
/* 343 */           fos.close();
/*     */         }
/* 345 */       } catch (IOException ex) {
/* 346 */         LOGGER.log(Level.SEVERE, (String)null, ex);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private byte[] toBytes(String s) {
/* 359 */     byte[] result = null;
/*     */     try {
/* 361 */       result = s.getBytes("US-ASCII");
/* 362 */     } catch (UnsupportedEncodingException ex) {
/* 363 */       throw new RuntimeException(ex);
/*     */     } 
/* 365 */     return result;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsonpdf-1.6-eval.jar!/com/orsonpdf/PDFDocument.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */