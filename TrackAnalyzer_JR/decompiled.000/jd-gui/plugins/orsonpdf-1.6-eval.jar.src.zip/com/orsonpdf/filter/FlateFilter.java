/*    */ package com.orsonpdf.filter;
/*    */ 
/*    */ import java.io.ByteArrayOutputStream;
/*    */ import java.io.IOException;
/*    */ import java.util.zip.DeflaterOutputStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FlateFilter
/*    */   implements Filter
/*    */ {
/*    */   public FilterType getFilterType() {
/* 36 */     return FilterType.FLATE;
/*    */   }
/*    */ 
/*    */   
/*    */   public byte[] encode(byte[] source) {
/* 41 */     ByteArrayOutputStream baos = new ByteArrayOutputStream();
/* 42 */     DeflaterOutputStream out = new DeflaterOutputStream(baos);
/*    */     try {
/* 44 */       out.write(source);
/* 45 */       out.flush();
/* 46 */       out.close();
/* 47 */     } catch (IOException e) {
/*    */       
/* 49 */       throw new RuntimeException(e);
/*    */     } 
/* 51 */     return baos.toByteArray();
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsonpdf-1.6-eval.jar!/com/orsonpdf/filter/FlateFilter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */