/*     */ package com.orsonpdf.filter;
/*     */ 
/*     */ import java.io.FilterOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Ascii85OutputStream
/*     */   extends FilterOutputStream
/*     */ {
/*  61 */   private int width = 72;
/*     */   
/*     */   private int pos;
/*     */   
/*     */   private int tuple;
/*     */   
/*     */   private int count;
/*     */   
/*     */   private boolean encoding;
/*     */   
/*     */   private boolean useSpaceCompression;
/*     */ 
/*     */   
/*     */   public Ascii85OutputStream(OutputStream out) {
/*  75 */     super(out);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Ascii85OutputStream(OutputStream out, boolean useSpaceCompression) {
/*  86 */     this(out);
/*  87 */     this.useSpaceCompression = useSpaceCompression;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Ascii85OutputStream(OutputStream out, int width, boolean useSpaceCompression) {
/*  99 */     this(out);
/* 100 */     this.width = width;
/* 101 */     this.useSpaceCompression = useSpaceCompression;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void startEncoding() throws IOException {
/* 108 */     this.encoding = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(int b) throws IOException {
/* 120 */     if (!this.encoding) {
/* 121 */       startEncoding();
/*     */     }
/* 123 */     switch (this.count++) {
/*     */       case 0:
/* 125 */         this.tuple |= (b & 0xFF) << 24;
/*     */         break;
/*     */       case 1:
/* 128 */         this.tuple |= (b & 0xFF) << 16;
/*     */         break;
/*     */       case 2:
/* 131 */         this.tuple |= (b & 0xFF) << 8;
/*     */         break;
/*     */       case 3:
/* 134 */         this.tuple |= b & 0xFF;
/* 135 */         if (this.tuple == 0) {
/*     */           
/* 137 */           this.out.write(122);
/* 138 */           if (this.pos++ >= this.width) {
/* 139 */             this.pos = 0;
/* 140 */             this.out.write(13);
/* 141 */             this.out.write(10);
/*     */           } 
/* 143 */         } else if (this.useSpaceCompression && this.tuple == 538976288) {
/*     */           
/* 145 */           this.out.write(121);
/* 146 */           if (this.pos++ >= this.width) {
/* 147 */             this.pos = 0;
/* 148 */             this.out.write(13);
/* 149 */             this.out.write(10);
/*     */           } 
/*     */         } else {
/* 152 */           encode(this.tuple, this.count);
/*     */         } 
/* 154 */         this.tuple = 0;
/* 155 */         this.count = 0;
/*     */         break;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeUnencoded(int b) throws IOException {
/* 170 */     super.write(b);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeUnencoded(byte[] b) throws IOException {
/* 183 */     writeUnencoded(b, 0, b.length);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeUnencoded(byte[] b, int off, int len) throws IOException {
/* 198 */     for (int i = 0; i < len; i++) {
/* 199 */       writeUnencoded(b[off + i]);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void encode(int tuple, int count) throws IOException {
/* 212 */     int i = 5;
/* 213 */     byte[] buf = new byte[5];
/* 214 */     short bufPos = 0;
/*     */     
/* 216 */     long longTuple = tuple & 0xFFFFFFFFL;
/*     */     
/*     */     do {
/* 219 */       bufPos = (short)(bufPos + 1); buf[bufPos] = (byte)(int)(longTuple % 85L);
/* 220 */       longTuple /= 85L;
/* 221 */     } while (--i > 0);
/*     */     
/* 223 */     i = count;
/*     */     do {
/* 225 */       bufPos = (short)(bufPos - 1); this.out.write(buf[bufPos] + 33);
/* 226 */       if (this.pos++ < this.width)
/* 227 */         continue;  this.pos = 0;
/* 228 */       this.out.write(13);
/* 229 */       this.out.write(10);
/*     */     }
/* 231 */     while (i-- > 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void flush() throws IOException {
/* 242 */     if (this.encoding) {
/* 243 */       if (this.count > 0)
/* 244 */         encode(this.tuple, this.count); 
/* 245 */       if (this.pos + 2 > this.width) {
/* 246 */         this.out.write(13);
/* 247 */         this.out.write(10);
/*     */       } 
/*     */       
/* 250 */       this.out.write(126);
/* 251 */       this.out.write(62);
/* 252 */       this.out.write(13);
/* 253 */       this.out.write(10);
/*     */       
/* 255 */       this.encoding = false;
/* 256 */       this.tuple = this.count = 0;
/*     */     } 
/*     */     
/* 259 */     super.flush();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsonpdf-1.6-eval.jar!/com/orsonpdf/filter/Ascii85OutputStream.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */