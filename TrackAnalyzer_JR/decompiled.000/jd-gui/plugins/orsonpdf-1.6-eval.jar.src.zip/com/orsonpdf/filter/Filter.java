package com.orsonpdf.filter;

public interface Filter {
  FilterType getFilterType();
  
  byte[] encode(byte[] paramArrayOfbyte);
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsonpdf-1.6-eval.jar!/com/orsonpdf/filter/Filter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */