/*    */ package com.orsonpdf.filter;
/*    */ 
/*    */ import com.orsonpdf.util.Args;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum FilterType
/*    */ {
/* 21 */   ASCII85("/ASCII85Decode"),
/*    */ 
/*    */   
/* 24 */   FLATE("/FlateDecode");
/*    */ 
/*    */ 
/*    */   
/*    */   private String decode;
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   FilterType(String decode) {
/* 34 */     Args.nullNotPermitted(decode, "decode");
/* 35 */     this.decode = decode;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getDecode() {
/* 45 */     return this.decode;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsonpdf-1.6-eval.jar!/com/orsonpdf/filter/FilterType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */