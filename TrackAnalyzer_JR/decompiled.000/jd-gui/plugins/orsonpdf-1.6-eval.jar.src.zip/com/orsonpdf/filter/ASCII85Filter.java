/*    */ package com.orsonpdf.filter;
/*    */ 
/*    */ import java.io.ByteArrayOutputStream;
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ASCII85Filter
/*    */   implements Filter
/*    */ {
/*    */   public FilterType getFilterType() {
/* 34 */     return FilterType.ASCII85;
/*    */   }
/*    */ 
/*    */   
/*    */   public byte[] encode(byte[] source) {
/* 39 */     ByteArrayOutputStream baos = new ByteArrayOutputStream();
/* 40 */     Ascii85OutputStream out = new Ascii85OutputStream(baos);
/*    */     try {
/* 42 */       out.write(source);
/* 43 */       out.flush();
/* 44 */       out.close();
/* 45 */     } catch (IOException e) {
/*    */       
/* 47 */       throw new RuntimeException(e);
/*    */     } 
/* 49 */     return baos.toByteArray();
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsonpdf-1.6-eval.jar!/com/orsonpdf/filter/ASCII85Filter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */