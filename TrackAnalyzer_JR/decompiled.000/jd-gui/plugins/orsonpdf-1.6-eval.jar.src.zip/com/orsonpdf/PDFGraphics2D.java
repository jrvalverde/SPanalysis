/*      */ package com.orsonpdf;
/*      */ 
/*      */ import com.orsonpdf.util.Args;
/*      */ import com.orsonpdf.util.GraphicsUtils;
/*      */ import java.awt.AlphaComposite;
/*      */ import java.awt.BasicStroke;
/*      */ import java.awt.Color;
/*      */ import java.awt.Composite;
/*      */ import java.awt.Font;
/*      */ import java.awt.FontMetrics;
/*      */ import java.awt.GradientPaint;
/*      */ import java.awt.Graphics;
/*      */ import java.awt.Graphics2D;
/*      */ import java.awt.GraphicsConfiguration;
/*      */ import java.awt.Image;
/*      */ import java.awt.Paint;
/*      */ import java.awt.RadialGradientPaint;
/*      */ import java.awt.Rectangle;
/*      */ import java.awt.RenderingHints;
/*      */ import java.awt.Shape;
/*      */ import java.awt.Stroke;
/*      */ import java.awt.font.FontRenderContext;
/*      */ import java.awt.font.GlyphVector;
/*      */ import java.awt.font.TextLayout;
/*      */ import java.awt.geom.AffineTransform;
/*      */ import java.awt.geom.Arc2D;
/*      */ import java.awt.geom.Area;
/*      */ import java.awt.geom.Ellipse2D;
/*      */ import java.awt.geom.GeneralPath;
/*      */ import java.awt.geom.Line2D;
/*      */ import java.awt.geom.NoninvertibleTransformException;
/*      */ import java.awt.geom.Path2D;
/*      */ import java.awt.geom.Rectangle2D;
/*      */ import java.awt.geom.RoundRectangle2D;
/*      */ import java.awt.image.BufferedImage;
/*      */ import java.awt.image.BufferedImageOp;
/*      */ import java.awt.image.ImageObserver;
/*      */ import java.awt.image.RenderedImage;
/*      */ import java.awt.image.renderable.RenderableImage;
/*      */ import java.text.AttributedCharacterIterator;
/*      */ import java.text.AttributedString;
/*      */ import java.util.Map;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class PDFGraphics2D
/*      */   extends Graphics2D
/*      */ {
/*      */   int width;
/*      */   int height;
/*      */   private RenderingHints hints;
/*   71 */   private Paint paint = Color.WHITE;
/*      */   
/*   73 */   private Color color = Color.WHITE;
/*      */   
/*   75 */   private Color background = Color.WHITE;
/*      */   
/*   77 */   private Composite composite = AlphaComposite.getInstance(3, 1.0F);
/*      */ 
/*      */   
/*   80 */   private Stroke stroke = new BasicStroke(1.0F);
/*      */   
/*   82 */   private AffineTransform transform = new AffineTransform();
/*      */ 
/*      */   
/*   85 */   private Shape clip = null;
/*      */   
/*   87 */   private Font font = new Font("SansSerif", 0, 12);
/*      */ 
/*      */   
/*   90 */   private BufferedImage image = new BufferedImage(10, 10, 1);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Line2D line;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Rectangle2D rect;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private RoundRectangle2D roundRect;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Ellipse2D oval;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Arc2D arc;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private GraphicsStream gs;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private GraphicsConfiguration deviceConfiguration;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public PDFGraphics2D(GraphicsStream gs, int width, int height) {
/*  138 */     this(gs, width, height, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public PDFGraphics2D(GraphicsStream gs, int width, int height, boolean skipJava2DTransform) {
/*  155 */     Args.nullNotPermitted(gs, "gs");
/*  156 */     this.width = width;
/*  157 */     this.height = height;
/*  158 */     this.hints = new RenderingHints(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
/*      */     
/*  160 */     this.gs = gs;
/*      */     
/*  162 */     if (!skipJava2DTransform) {
/*  163 */       this.gs.applyTransform(AffineTransform.getTranslateInstance(0.0D, height));
/*      */       
/*  165 */       this.gs.applyTransform(AffineTransform.getScaleInstance(1.0D, -1.0D));
/*      */     } 
/*  167 */     this.gs.applyFont(getFont());
/*  168 */     this.gs.applyStrokeColor(getColor());
/*  169 */     this.gs.applyFillColor(getColor());
/*  170 */     this.gs.applyStroke(getStroke());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Graphics create() {
/*  180 */     throw new UnsupportedOperationException("Not supported yet.");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Paint getPaint() {
/*  193 */     return this.paint;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setPaint(Paint paint) {
/*  209 */     if (paint == null) {
/*      */       return;
/*      */     }
/*  212 */     if (paint instanceof Color) {
/*  213 */       setColor((Color)paint);
/*      */       return;
/*      */     } 
/*  216 */     this.paint = paint;
/*  217 */     if (paint instanceof GradientPaint) {
/*  218 */       GradientPaint gp = (GradientPaint)paint;
/*  219 */       this.gs.applyStrokeGradient(gp);
/*  220 */       this.gs.applyFillGradient(gp);
/*  221 */     } else if (paint instanceof RadialGradientPaint) {
/*  222 */       RadialGradientPaint rgp = (RadialGradientPaint)paint;
/*  223 */       this.gs.applyStrokeGradient(rgp);
/*  224 */       this.gs.applyFillGradient(rgp);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Color getColor() {
/*  238 */     return this.color;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setColor(Color c) {
/*  252 */     if (c == null || this.paint.equals(c)) {
/*      */       return;
/*      */     }
/*  255 */     this.color = c;
/*  256 */     this.paint = c;
/*  257 */     this.gs.applyStrokeColor(c);
/*  258 */     this.gs.applyFillColor(c);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Color getBackground() {
/*  271 */     return this.background;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBackground(Color color) {
/*  287 */     this.background = color;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Composite getComposite() {
/*  299 */     return this.composite;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setComposite(Composite comp) {
/*  311 */     Args.nullNotPermitted(comp, "comp");
/*  312 */     this.composite = comp;
/*  313 */     if (comp instanceof AlphaComposite) {
/*  314 */       AlphaComposite ac = (AlphaComposite)comp;
/*  315 */       this.gs.applyComposite(ac);
/*      */     } else {
/*  317 */       this.gs.applyComposite(null);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Stroke getStroke() {
/*  330 */     return this.stroke;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setStroke(Stroke s) {
/*  343 */     Args.nullNotPermitted(s, "s");
/*  344 */     if (this.stroke.equals(s)) {
/*      */       return;
/*      */     }
/*  347 */     this.stroke = s;
/*  348 */     this.gs.applyStroke(s);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getRenderingHint(RenderingHints.Key hintKey) {
/*  365 */     return this.hints.get(hintKey);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setRenderingHint(RenderingHints.Key hintKey, Object hintValue) {
/*  379 */     this.hints.put(hintKey, hintValue);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public RenderingHints getRenderingHints() {
/*  393 */     return (RenderingHints)this.hints.clone();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setRenderingHints(Map<?, ?> hints) {
/*  405 */     this.hints.clear();
/*  406 */     this.hints.putAll(hints);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addRenderingHints(Map<?, ?> hints) {
/*  416 */     this.hints.putAll(hints);
/*      */   }
/*      */   
/*      */   private Shape invTransformedClip(Shape clip) {
/*  420 */     Shape result = clip;
/*      */     try {
/*  422 */       AffineTransform inv = this.transform.createInverse();
/*  423 */       result = inv.createTransformedShape(clip);
/*  424 */     } catch (NoninvertibleTransformException e) {}
/*      */ 
/*      */     
/*  427 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void draw(Shape s) {
/*  442 */     if (!(this.stroke instanceof BasicStroke)) {
/*  443 */       fill(this.stroke.createStrokedShape(s));
/*      */       return;
/*      */     } 
/*  446 */     if (s instanceof Line2D) {
/*  447 */       if (this.clip != null) {
/*  448 */         this.gs.pushGraphicsState();
/*  449 */         this.gs.applyClip(invTransformedClip(this.clip));
/*  450 */         this.gs.drawLine((Line2D)s);
/*  451 */         this.gs.popGraphicsState();
/*      */       } else {
/*  453 */         this.gs.drawLine((Line2D)s);
/*      */       } 
/*  455 */     } else if (s instanceof Path2D) {
/*  456 */       if (this.clip != null) {
/*  457 */         this.gs.pushGraphicsState();
/*  458 */         this.gs.applyClip(invTransformedClip(this.clip));
/*  459 */         this.gs.drawPath2D((Path2D)s);
/*  460 */         this.gs.popGraphicsState();
/*      */       } else {
/*  462 */         this.gs.drawPath2D((Path2D)s);
/*      */       } 
/*      */     } else {
/*  465 */       draw(new GeneralPath(s));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void fill(Shape s) {
/*  480 */     if (s instanceof Path2D) {
/*  481 */       if (this.clip != null) {
/*  482 */         this.gs.pushGraphicsState();
/*  483 */         this.gs.applyClip(invTransformedClip(this.clip));
/*  484 */         this.gs.fillPath2D((Path2D)s);
/*  485 */         this.gs.popGraphicsState();
/*      */       } else {
/*  487 */         this.gs.fillPath2D((Path2D)s);
/*      */       } 
/*      */     } else {
/*  490 */       fill(new GeneralPath(s));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Font getFont() {
/*  503 */     return this.font;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFont(Font font) {
/*  515 */     if (font == null || this.font.equals(font)) {
/*      */       return;
/*      */     }
/*  518 */     this.font = font;
/*  519 */     this.gs.applyFont(font);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public FontMetrics getFontMetrics(Font f) {
/*  531 */     return this.image.createGraphics().getFontMetrics(f);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public FontRenderContext getFontRenderContext() {
/*  543 */     return this.image.createGraphics().getFontRenderContext();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void drawString(String str, int x, int y) {
/*  558 */     drawString(str, x, y);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void drawString(String str, float x, float y) {
/*  571 */     if (str == null) {
/*  572 */       throw new NullPointerException("Null 'str' argument.");
/*      */     }
/*  574 */     if (this.clip != null) {
/*  575 */       this.gs.pushGraphicsState();
/*  576 */       this.gs.applyClip(invTransformedClip(this.clip));
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  581 */     if (!PDFHints.VALUE_DRAW_STRING_TYPE_VECTOR.equals(this.hints.get(PDFHints.KEY_DRAW_STRING_TYPE))) {
/*      */       
/*  583 */       this.gs.drawString(str, x, y);
/*      */     } else {
/*  585 */       AttributedString as = new AttributedString(str, (Map)this.font.getAttributes());
/*      */       
/*  587 */       drawString(as.getIterator(), x, y);
/*      */     } 
/*      */     
/*  590 */     if (this.clip != null) {
/*  591 */       this.gs.popGraphicsState();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void drawString(AttributedCharacterIterator iterator, int x, int y) {
/*  606 */     drawString(iterator, x, y);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void drawString(AttributedCharacterIterator iterator, float x, float y) {
/*  623 */     TextLayout layout = new TextLayout(iterator, getFontRenderContext());
/*  624 */     layout.draw(this, x, y);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void drawGlyphVector(GlyphVector g, float x, float y) {
/*  636 */     fill(g.getOutline(x, y));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void translate(int tx, int ty) {
/*  650 */     translate(tx, ty);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void translate(double tx, double ty) {
/*  661 */     AffineTransform t = getTransform();
/*  662 */     t.translate(tx, ty);
/*  663 */     setTransform(t);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void rotate(double theta) {
/*  673 */     AffineTransform t = getTransform();
/*  674 */     t.rotate(theta);
/*  675 */     setTransform(t);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void rotate(double theta, double x, double y) {
/*  687 */     translate(x, y);
/*  688 */     rotate(theta);
/*  689 */     translate(-x, -y);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void scale(double sx, double sy) {
/*  700 */     AffineTransform t = getTransform();
/*  701 */     t.scale(sx, sy);
/*  702 */     setTransform(t);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void shear(double shx, double shy) {
/*  718 */     AffineTransform t = AffineTransform.getShearInstance(shx, shy);
/*  719 */     transform(t);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void transform(AffineTransform t) {
/*  729 */     AffineTransform tx = getTransform();
/*  730 */     tx.concatenate(t);
/*  731 */     setTransform(tx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AffineTransform getTransform() {
/*  743 */     return (AffineTransform)this.transform.clone();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTransform(AffineTransform t) {
/*  756 */     if (t == null) {
/*  757 */       this.transform = new AffineTransform();
/*      */     } else {
/*  759 */       this.transform = new AffineTransform(t);
/*      */     } 
/*  761 */     this.gs.setTransform(this.transform);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean hit(Rectangle rect, Shape s, boolean onStroke) {
/*      */     Shape ts;
/*  778 */     if (onStroke) {
/*  779 */       ts = this.transform.createTransformedShape(this.stroke.createStrokedShape(s));
/*      */     } else {
/*      */       
/*  782 */       ts = this.transform.createTransformedShape(s);
/*      */     } 
/*  784 */     if (!rect.getBounds2D().intersects(ts.getBounds2D())) {
/*  785 */       return false;
/*      */     }
/*  787 */     Area a1 = new Area(rect);
/*  788 */     Area a2 = new Area(ts);
/*  789 */     a1.intersect(a2);
/*  790 */     return !a1.isEmpty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public GraphicsConfiguration getDeviceConfiguration() {
/*  801 */     if (this.deviceConfiguration == null) {
/*  802 */       this.deviceConfiguration = new PDFGraphicsConfiguration(this.width, this.height);
/*      */     }
/*      */     
/*  805 */     return this.deviceConfiguration;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setPaintMode() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setXORMode(Color c) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Shape getClip() {
/*  836 */     if (this.clip == null) {
/*  837 */       return null;
/*      */     }
/*      */     
/*      */     try {
/*  841 */       AffineTransform inv = this.transform.createInverse();
/*  842 */       return inv.createTransformedShape(this.clip);
/*  843 */     } catch (NoninvertibleTransformException ex) {
/*  844 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setClip(Shape shape) {
/*  858 */     this.clip = this.transform.createTransformedShape(shape);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Rectangle getClipBounds() {
/*  876 */     Shape s = getClip();
/*  877 */     return (s != null) ? s.getBounds() : null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void clip(Shape s) {
/*  895 */     if (this.clip == null) {
/*  896 */       setClip(s);
/*      */       return;
/*      */     } 
/*  899 */     Shape ts = this.transform.createTransformedShape(s);
/*  900 */     if (!ts.intersects(this.clip.getBounds2D())) {
/*  901 */       setClip(new Rectangle2D.Double());
/*      */     } else {
/*  903 */       Area a1 = new Area(ts);
/*  904 */       Area a2 = new Area(this.clip);
/*  905 */       a1.intersect(a2);
/*  906 */       this.clip = new Path2D.Double(a1);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void clipRect(int x, int y, int width, int height) {
/*  921 */     setRect(x, y, width, height);
/*  922 */     clip(this.rect);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setClip(int x, int y, int width, int height) {
/*  938 */     setClip(new Rectangle(x, y, width, height));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void drawLine(int x1, int y1, int x2, int y2) {
/*  952 */     if (this.line == null) {
/*  953 */       this.line = new Line2D.Double(x1, y1, x2, y2);
/*      */     } else {
/*  955 */       this.line.setLine(x1, y1, x2, y2);
/*      */     } 
/*  957 */     draw(this.line);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void fillRect(int x, int y, int width, int height) {
/*  970 */     if (this.rect == null) {
/*  971 */       this.rect = new Rectangle2D.Double(x, y, width, height);
/*      */     } else {
/*  973 */       this.rect.setRect(x, y, width, height);
/*      */     } 
/*  975 */     fill(this.rect);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void clearRect(int x, int y, int width, int height) {
/*  992 */     if (getBackground() == null) {
/*      */       return;
/*      */     }
/*  995 */     Paint saved = getPaint();
/*  996 */     setPaint(getBackground());
/*  997 */     fillRect(x, y, width, height);
/*  998 */     setPaint(saved);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void drawRoundRect(int x, int y, int width, int height, int arcWidth, int arcHeight) {
/* 1017 */     setRoundRect(x, y, width, height, arcWidth, arcHeight);
/* 1018 */     draw(this.roundRect);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void fillRoundRect(int x, int y, int width, int height, int arcWidth, int arcHeight) {
/* 1034 */     setRoundRect(x, y, width, height, arcWidth, arcHeight);
/* 1035 */     fill(this.roundRect);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void drawOval(int x, int y, int width, int height) {
/* 1051 */     setOval(x, y, width, height);
/* 1052 */     draw(this.oval);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void fillOval(int x, int y, int width, int height) {
/* 1067 */     setOval(x, y, width, height);
/* 1068 */     fill(this.oval);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void drawArc(int x, int y, int width, int height, int startAngle, int arcAngle) {
/* 1089 */     setArc(x, y, width, height, startAngle, arcAngle);
/* 1090 */     draw(this.arc);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void fillArc(int x, int y, int width, int height, int startAngle, int arcAngle) {
/* 1111 */     setArc(x, y, width, height, startAngle, arcAngle);
/* 1112 */     fill(this.arc);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void drawPolyline(int[] xPoints, int[] yPoints, int nPoints) {
/* 1125 */     GeneralPath p = GraphicsUtils.createPolygon(xPoints, yPoints, nPoints, false);
/*      */     
/* 1127 */     draw(p);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void drawPolygon(int[] xPoints, int[] yPoints, int nPoints) {
/* 1141 */     GeneralPath p = GraphicsUtils.createPolygon(xPoints, yPoints, nPoints, true);
/*      */     
/* 1143 */     draw(p);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void fillPolygon(int[] xPoints, int[] yPoints, int nPoints) {
/* 1157 */     GeneralPath p = GraphicsUtils.createPolygon(xPoints, yPoints, nPoints, true);
/*      */     
/* 1159 */     fill(p);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean drawImage(Image img, AffineTransform xform, ImageObserver obs) {
/* 1175 */     AffineTransform savedTransform = getTransform();
/* 1176 */     transform(xform);
/* 1177 */     boolean result = drawImage(img, 0, 0, obs);
/* 1178 */     setTransform(savedTransform);
/* 1179 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void drawImage(BufferedImage img, BufferedImageOp op, int x, int y) {
/* 1193 */     BufferedImage imageToDraw = op.filter(img, null);
/* 1194 */     drawImage(imageToDraw, new AffineTransform(1.0F, 0.0F, 0.0F, 1.0F, x, y), null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void drawRenderedImage(RenderedImage img, AffineTransform xform) {
/* 1205 */     BufferedImage bi = GraphicsUtils.convertRenderedImage(img);
/* 1206 */     drawImage(bi, xform, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void drawRenderableImage(RenderableImage img, AffineTransform xform) {
/* 1218 */     RenderedImage ri = img.createDefaultRendering();
/* 1219 */     drawRenderedImage(ri, xform);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean drawImage(Image img, int x, int y, ImageObserver observer) {
/* 1235 */     int w = img.getWidth(observer);
/* 1236 */     if (w < 0) {
/* 1237 */       return false;
/*      */     }
/* 1239 */     int h = img.getHeight(observer);
/* 1240 */     if (h < 0) {
/* 1241 */       return false;
/*      */     }
/* 1243 */     return drawImage(img, x, y, w, h, observer);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean drawImage(Image img, int x, int y, int w, int h, ImageObserver observer) {
/* 1263 */     if (this.clip != null) {
/* 1264 */       this.gs.pushGraphicsState();
/* 1265 */       this.gs.applyClip(invTransformedClip(this.clip));
/* 1266 */       this.gs.drawImage(img, x, y, w, h);
/* 1267 */       this.gs.popGraphicsState();
/*      */     } else {
/* 1269 */       this.gs.drawImage(img, x, y, w, h);
/*      */     } 
/* 1271 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean drawImage(Image img, int x, int y, Color bgcolor, ImageObserver observer) {
/* 1289 */     int w = img.getWidth(null);
/* 1290 */     if (w < 0) {
/* 1291 */       return false;
/*      */     }
/* 1293 */     int h = img.getHeight(null);
/* 1294 */     if (h < 0) {
/* 1295 */       return false;
/*      */     }
/* 1297 */     return drawImage(img, x, y, w, h, bgcolor, observer);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean drawImage(Image img, int x, int y, int w, int h, Color bgcolor, ImageObserver observer) {
/* 1318 */     Paint saved = getPaint();
/* 1319 */     setPaint(bgcolor);
/* 1320 */     fillRect(x, y, w, h);
/* 1321 */     setPaint(saved);
/* 1322 */     return drawImage(img, x, y, w, h, observer);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean drawImage(Image img, int dx1, int dy1, int dx2, int dy2, int sx1, int sy1, int sx2, int sy2, ImageObserver observer) {
/* 1346 */     int w = dx2 - dx1;
/* 1347 */     int h = dy2 - dy1;
/* 1348 */     BufferedImage img2 = new BufferedImage(2, w, h);
/*      */     
/* 1350 */     Graphics2D g2 = img2.createGraphics();
/* 1351 */     g2.drawImage(img, 0, 0, w, h, sx1, sy1, sx2, sy2, null);
/* 1352 */     return drawImage(img2, dx1, dx2, (ImageObserver)null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean drawImage(Image img, int dx1, int dy1, int dx2, int dy2, int sx1, int sy1, int sx2, int sy2, Color bgcolor, ImageObserver observer) {
/* 1380 */     Paint saved = getPaint();
/* 1381 */     setPaint(bgcolor);
/* 1382 */     fillRect(dx1, dy1, dx2 - dx1, dy2 - dy1);
/* 1383 */     setPaint(saved);
/* 1384 */     return drawImage(img, dx1, dy1, dx2, dy2, sx1, sy1, sx2, sy2, observer);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void copyArea(int x, int y, int width, int height, int dx, int dy) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void dispose() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void setRect(int x, int y, int width, int height) {
/* 1423 */     if (this.rect == null) {
/* 1424 */       this.rect = new Rectangle2D.Double(x, y, width, height);
/*      */     } else {
/* 1426 */       this.rect.setRect(x, y, width, height);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void setRoundRect(int x, int y, int width, int height, int arcWidth, int arcHeight) {
/* 1444 */     if (this.roundRect == null) {
/* 1445 */       this.roundRect = new RoundRectangle2D.Double(x, y, width, height, arcWidth, arcHeight);
/*      */     } else {
/*      */       
/* 1448 */       this.roundRect.setRoundRect(x, y, width, height, arcWidth, arcHeight);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void setOval(int x, int y, int width, int height) {
/* 1464 */     if (this.oval == null) {
/* 1465 */       this.oval = new Ellipse2D.Double(x, y, width, height);
/*      */     } else {
/* 1467 */       this.oval.setFrame(x, y, width, height);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void setArc(int x, int y, int width, int height, int startAngle, int arcAngle) {
/* 1485 */     if (this.arc == null) {
/* 1486 */       this.arc = new Arc2D.Double(x, y, width, height, startAngle, arcAngle, 0);
/*      */     } else {
/*      */       
/* 1489 */       this.arc.setArc(x, y, width, height, startAngle, arcAngle, 0);
/*      */     } 
/*      */   }
/*      */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsonpdf-1.6-eval.jar!/com/orsonpdf/PDFGraphics2D.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */