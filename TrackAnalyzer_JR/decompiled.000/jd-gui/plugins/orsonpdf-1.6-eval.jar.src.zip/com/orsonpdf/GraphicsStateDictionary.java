/*    */ package com.orsonpdf;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GraphicsStateDictionary
/*    */   extends DictionaryObject
/*    */ {
/*    */   private float strokeAlpha;
/*    */   private float nonStrokeAlpha;
/*    */   
/*    */   public GraphicsStateDictionary(int number) {
/* 28 */     super(number, "/ExtGState");
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public float getStrokeAlpha() {
/* 37 */     return this.strokeAlpha;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setStrokeAlpha(float alpha) {
/* 46 */     this.strokeAlpha = alpha;
/* 47 */     this.dictionary.put("/CA", Float.valueOf(alpha));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public float getNonStrokeAlpha() {
/* 56 */     return this.nonStrokeAlpha;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setNonStrokeAlpha(float alpha) {
/* 65 */     this.nonStrokeAlpha = alpha;
/* 66 */     this.dictionary.put("/ca", Float.valueOf(alpha));
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsonpdf-1.6-eval.jar!/com/orsonpdf/GraphicsStateDictionary.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */