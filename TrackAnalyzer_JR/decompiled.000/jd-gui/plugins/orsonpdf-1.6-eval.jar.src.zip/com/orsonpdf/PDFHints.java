/*    */ package com.orsonpdf;
/*    */ 
/*    */ import java.awt.RenderingHints;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class PDFHints
/*    */ {
/* 40 */   public static final Key KEY_DRAW_STRING_TYPE = new Key(0);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 46 */   public static final Object VALUE_DRAW_STRING_TYPE_STANDARD = "VALUE_DRAW_STRING_TYPE_STANDARD";
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 53 */   public static final Object VALUE_DRAW_STRING_TYPE_VECTOR = "VALUE_DRAW_STRING_TYPE_VECTOR";
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static class Key
/*    */     extends RenderingHints.Key
/*    */   {
/*    */     public Key(int privateKey) {
/* 62 */       super(privateKey);
/*    */     }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/*    */     public boolean isCompatibleValue(Object val) {
/* 75 */       switch (intKey()) {
/*    */         case 0:
/* 77 */           return (val == null || PDFHints.VALUE_DRAW_STRING_TYPE_STANDARD.equals(val) || PDFHints.VALUE_DRAW_STRING_TYPE_VECTOR.equals(val));
/*    */       } 
/*    */ 
/*    */       
/* 81 */       throw new RuntimeException("Not expected!");
/*    */     }
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsonpdf-1.6-eval.jar!/com/orsonpdf/PDFHints.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */