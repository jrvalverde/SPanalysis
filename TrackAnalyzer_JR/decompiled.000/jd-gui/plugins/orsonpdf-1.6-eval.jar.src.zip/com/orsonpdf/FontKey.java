/*     */ package com.orsonpdf;
/*     */ 
/*     */ import com.orsonpdf.util.Args;
/*     */ import com.orsonpdf.util.ObjectUtils;
/*     */ import java.awt.Font;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FontKey
/*     */ {
/*     */   private String name;
/*     */   private boolean isBold;
/*     */   private boolean isItalic;
/*     */   
/*     */   public static FontKey createFontKey(Font f) {
/*  40 */     Args.nullNotPermitted(f, "f");
/*  41 */     String family = f.getFamily().replace(' ', '_');
/*  42 */     boolean bold = f.isBold();
/*  43 */     boolean italic = f.isItalic();
/*  44 */     return new FontKey(family, bold, italic);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FontKey(String name, boolean bold, boolean italic) {
/*  57 */     this.name = name;
/*  58 */     this.isBold = bold;
/*  59 */     this.isItalic = italic;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/*  71 */     if (obj == null) {
/*  72 */       return false;
/*     */     }
/*  74 */     if (getClass() != obj.getClass()) {
/*  75 */       return false;
/*     */     }
/*  77 */     FontKey other = (FontKey)obj;
/*  78 */     if (!ObjectUtils.equals(this.name, other.name)) {
/*  79 */       return false;
/*     */     }
/*  81 */     if (this.isBold != other.isBold) {
/*  82 */       return false;
/*     */     }
/*  84 */     if (this.isItalic != other.isItalic) {
/*  85 */       return false;
/*     */     }
/*  87 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*  97 */     int hash = 3;
/*  98 */     hash = 97 * hash + ObjectUtils.hashCode(this.name);
/*  99 */     hash = 97 * hash + (this.isBold ? 1 : 0);
/* 100 */     hash = 97 * hash + (this.isItalic ? 1 : 0);
/* 101 */     return hash;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 112 */     StringBuilder sb = new StringBuilder();
/* 113 */     sb.append("FontKey[name=").append(this.name);
/* 114 */     sb.append(",isBold=").append(this.isBold);
/* 115 */     sb.append(",isItalic=").append(this.isItalic);
/* 116 */     sb.append("]");
/* 117 */     return sb.toString();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsonpdf-1.6-eval.jar!/com/orsonpdf/FontKey.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */