/*     */ package com.orsonpdf;
/*     */ 
/*     */ import com.orsonpdf.util.Args;
/*     */ import java.awt.Font;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Pages
/*     */   extends PDFObject
/*     */ {
/*     */   private PDFDocument parent;
/*     */   private List<Page> pages;
/*     */   private List<PDFFont> fonts;
/*     */   private Map<FontKey, PDFFont> fontMap;
/*  38 */   private int nextFont = 1;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private FontMapper fontMapper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Pages(int number, int generation, PDFDocument parent) {
/*  50 */     super(number, generation);
/*  51 */     Args.nullNotPermitted(parent, "parent");
/*  52 */     this.parent = parent;
/*  53 */     this.pages = new ArrayList<Page>();
/*  54 */     this.fonts = new ArrayList<PDFFont>();
/*  55 */     this.fontMap = new HashMap<FontKey, PDFFont>();
/*  56 */     this.fontMapper = new DefaultFontMapper();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PDFDocument getDocument() {
/*  65 */     return this.parent;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Page> getPages() {
/*  74 */     return this.pages;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<PDFFont> getFonts() {
/*  83 */     return this.fonts;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PDFFont getFont(String name) {
/*  95 */     for (PDFFont f : this.fonts) {
/*  96 */       if (f.getName().equals(name)) {
/*  97 */         return f;
/*     */       }
/*     */     } 
/* 100 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void add(Page page) {
/* 108 */     this.pages.add(page);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String findOrCreateFontReference(Font f) {
/* 120 */     FontKey fontKey = FontKey.createFontKey(f);
/* 121 */     PDFFont pdfFont = this.fontMap.get(fontKey);
/* 122 */     if (pdfFont == null) {
/* 123 */       int number = this.parent.getNextNumber();
/* 124 */       String name = "/F" + this.nextFont + "-" + f.getFamily().replace(' ', '_');
/* 125 */       String baseFont = this.fontMapper.mapToBaseFont(f);
/* 126 */       this.nextFont++;
/* 127 */       pdfFont = new PDFFont(number, 0, name, "/" + baseFont, "/MacRomanEncoding");
/*     */       
/* 129 */       this.fonts.add(pdfFont);
/* 130 */       this.fontMap.put(fontKey, pdfFont);
/*     */     } 
/* 132 */     return pdfFont.getName();
/*     */   }
/*     */   
/*     */   private Dictionary createDictionary() {
/* 136 */     Dictionary dictionary = new Dictionary("/Pages");
/* 137 */     Page[] pagesArray = new Page[this.pages.size()];
/* 138 */     for (int i = 0; i < this.pages.size(); i++) {
/* 139 */       pagesArray[i] = this.pages.get(i);
/*     */     }
/* 141 */     dictionary.put("/Kids", pagesArray);
/* 142 */     dictionary.put("/Count", Integer.valueOf(this.pages.size()));
/* 143 */     return dictionary;
/*     */   }
/*     */ 
/*     */   
/*     */   public byte[] getObjectBytes() {
/* 148 */     return createDictionary().toPDFBytes();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsonpdf-1.6-eval.jar!/com/orsonpdf/Pages.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */