/*    */ package com.orsonpdf;
/*    */ 
/*    */ import java.awt.Font;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DefaultFontMapper
/*    */   implements FontMapper
/*    */ {
/*    */   private final Map<FontKey, String> map;
/*    */   
/*    */   public DefaultFontMapper() {
/* 36 */     this.map = new HashMap<FontKey, String>();
/* 37 */     this.map.put(new FontKey("Dialog", false, false), "Helvetica");
/* 38 */     this.map.put(new FontKey("Dialog", true, false), "Helvetica-Bold");
/* 39 */     this.map.put(new FontKey("Dialog", false, true), "Helvetica-Oblique");
/* 40 */     this.map.put(new FontKey("Dialog", true, true), "Helvetica-BoldOblique");
/* 41 */     this.map.put(new FontKey("Arial", false, false), "Helvetica");
/* 42 */     this.map.put(new FontKey("Arial", true, false), "Helvetica-Bold");
/* 43 */     this.map.put(new FontKey("Arial", false, true), "Helvetica-Oblique");
/* 44 */     this.map.put(new FontKey("Arial", true, true), "Helvetica-BoldOblique");
/* 45 */     this.map.put(new FontKey("Courier", false, false), "Courier");
/* 46 */     this.map.put(new FontKey("Courier", true, false), "Courier-Bold");
/* 47 */     this.map.put(new FontKey("Courier", false, true), "Courier-Italic");
/* 48 */     this.map.put(new FontKey("Courier", true, true), "Courier-BoldItalic");
/* 49 */     this.map.put(new FontKey("Courier_New", false, false), "Courier");
/* 50 */     this.map.put(new FontKey("Courier_New", true, false), "Courier-Bold");
/* 51 */     this.map.put(new FontKey("Courier_New", false, true), "Courier-Italic");
/* 52 */     this.map.put(new FontKey("Courier_New", true, true), "Courier-BoldItalic");
/* 53 */     this.map.put(new FontKey("DialogInput", false, false), "Helvetica");
/* 54 */     this.map.put(new FontKey("DialogInput", true, false), "Helvetica-Bold");
/* 55 */     this.map.put(new FontKey("DialogInput", false, true), "Helvetica-Oblique");
/* 56 */     this.map.put(new FontKey("DialogInput", true, true), "Helvetica-BoldOblique");
/* 57 */     this.map.put(new FontKey("MgOpen_Cosmetica", false, false), "Times-Roman");
/* 58 */     this.map.put(new FontKey("MgOpen_Cosmetica", true, false), "Times-Bold");
/* 59 */     this.map.put(new FontKey("MgOpen_Cosmetica", false, true), "Times-Italic");
/* 60 */     this.map.put(new FontKey("MgOpen_Cosmetica", true, true), "Times-BoldItalic");
/* 61 */     this.map.put(new FontKey("Monospaced", false, false), "Courier");
/* 62 */     this.map.put(new FontKey("Monospaced", true, false), "Courier-Bold");
/* 63 */     this.map.put(new FontKey("Monospaced", false, true), "Courier-Italic");
/* 64 */     this.map.put(new FontKey("Monospaced", true, true), "Courier-BoldItalic");
/* 65 */     this.map.put(new FontKey("Palatino", false, false), "Times-Roman");
/* 66 */     this.map.put(new FontKey("Palatino", true, false), "Times-Bold");
/* 67 */     this.map.put(new FontKey("Palatino", false, true), "Times-Italic");
/* 68 */     this.map.put(new FontKey("Palatino", true, true), "Times-BoldItalic");
/* 69 */     this.map.put(new FontKey("SansSerif", false, false), "Helvetica");
/* 70 */     this.map.put(new FontKey("SansSerif", true, false), "Helvetica-Bold");
/* 71 */     this.map.put(new FontKey("SansSerif", false, true), "Helvetica-Oblique");
/* 72 */     this.map.put(new FontKey("SansSerif", true, true), "Helvetica-BoldOblique");
/* 73 */     this.map.put(new FontKey("Serif", false, false), "Times-Roman");
/* 74 */     this.map.put(new FontKey("Serif", true, false), "Times-Bold");
/* 75 */     this.map.put(new FontKey("Serif", false, true), "Times-Italic");
/* 76 */     this.map.put(new FontKey("Serif", true, true), "Times-BoldItalic");
/* 77 */     this.map.put(new FontKey("Tahoma", false, false), "Times-Roman");
/* 78 */     this.map.put(new FontKey("Tahoma", true, false), "Times-Bold");
/* 79 */     this.map.put(new FontKey("Tahoma", false, true), "Times-Italic");
/* 80 */     this.map.put(new FontKey("Tahoma", true, true), "Times-BoldItalic");
/* 81 */     this.map.put(new FontKey("Times_New_Roman", false, false), "Times-Roman");
/* 82 */     this.map.put(new FontKey("Times_New_Roman", true, false), "Times-Bold");
/* 83 */     this.map.put(new FontKey("Times_New_Roman", false, true), "Times-Italic");
/* 84 */     this.map.put(new FontKey("Times_New_Roman", true, true), "Times-BoldItalic");
/*    */   }
/*    */ 
/*    */   
/*    */   public String mapToBaseFont(Font f) {
/* 89 */     String result = this.map.get(FontKey.createFontKey(f));
/* 90 */     if (result == null) {
/* 91 */       result = "Courier";
/*    */     }
/* 93 */     return result;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsonpdf-1.6-eval.jar!/com/orsonpdf/DefaultFontMapper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */