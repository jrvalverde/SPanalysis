/*    */ package com.orsonpdf;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ExponentialInterpolationFunction
/*    */   extends Function
/*    */ {
/*    */   double n;
/*    */   float[] c0;
/*    */   float[] c1;
/*    */   
/*    */   public ExponentialInterpolationFunction(int number, float[] c0, float[] c1) {
/* 33 */     super(number, FunctionType.EXPONENTIAL_INTERPOLATION);
/* 34 */     this.dictionary.put("/N", "1");
/* 35 */     this.n = 1.0D;
/* 36 */     setC0(c0);
/* 37 */     setC1(c1);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public double getN() {
/* 47 */     return this.n;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setN(double n) {
/* 56 */     this.n = n;
/* 57 */     this.dictionary.put("/N", String.valueOf(n));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public float[] getC0() {
/* 67 */     return (float[])this.c0.clone();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setC0(float[] c0) {
/* 76 */     this.c0 = (float[])c0.clone();
/* 77 */     this.dictionary.put("/C0", PDFUtils.toPDFArray(c0));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public float[] getC1() {
/* 87 */     return (float[])this.c1.clone();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setC1(float[] c1) {
/* 96 */     this.c1 = (float[])c1.clone();
/* 97 */     this.dictionary.put("/C1", PDFUtils.toPDFArray(c1));
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsonpdf-1.6-eval.jar!/com/orsonpdf/ExponentialInterpolationFunction.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */