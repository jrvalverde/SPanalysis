/*    */ package com.orsonpdf;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum FunctionType
/*    */ {
/* 21 */   SAMPLED(0),
/*    */ 
/*    */   
/* 24 */   EXPONENTIAL_INTERPOLATION(2),
/*    */ 
/*    */   
/* 27 */   STITCHING(3),
/*    */ 
/*    */   
/* 30 */   POSTSCRIPT_CALCULATOR(4);
/*    */   
/*    */   private int number;
/*    */ 
/*    */   
/*    */   FunctionType(int number) {
/* 36 */     this.number = number;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int getNumber() {
/* 45 */     return this.number;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsonpdf-1.6-eval.jar!/com/orsonpdf/FunctionType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */