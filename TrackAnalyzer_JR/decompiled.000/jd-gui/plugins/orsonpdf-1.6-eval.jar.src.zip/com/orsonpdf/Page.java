/*     */ package com.orsonpdf;
/*     */ 
/*     */ import com.orsonpdf.filter.Filter;
/*     */ import com.orsonpdf.filter.FlateFilter;
/*     */ import com.orsonpdf.shading.AxialShading;
/*     */ import com.orsonpdf.shading.RadialShading;
/*     */ import com.orsonpdf.shading.Shading;
/*     */ import com.orsonpdf.util.Args;
/*     */ import com.orsonpdf.util.GradientPaintKey;
/*     */ import com.orsonpdf.util.RadialGradientPaintKey;
/*     */ import com.orsonpdf.util.TextAnchor;
/*     */ import com.orsonpdf.util.TextUtils;
/*     */ import java.awt.Color;
/*     */ import java.awt.Font;
/*     */ import java.awt.GradientPaint;
/*     */ import java.awt.Image;
/*     */ import java.awt.MultipleGradientPaint;
/*     */ import java.awt.RadialGradientPaint;
/*     */ import java.awt.geom.AffineTransform;
/*     */ import java.awt.geom.Rectangle2D;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Page
/*     */   extends PDFObject
/*     */ {
/*     */   private Pages parent;
/*     */   private Rectangle2D bounds;
/*     */   private GraphicsStream contents;
/*     */   private PDFGraphics2D graphics2d;
/*     */   private List<String> fontsOnPage;
/*     */   private Map<GradientPaintKey, String> gradientPaintsOnPage;
/*     */   private Map<RadialGradientPaintKey, String> radialGradientPaintsOnPage;
/*     */   private Dictionary patterns;
/*     */   private Dictionary graphicsStates;
/*     */   private AffineTransform j2DTransform;
/*  81 */   private Dictionary xObjects = new Dictionary();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Map<Integer, String> alphaDictionaries;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Page(int number, int generation, Pages parent, Rectangle2D bounds) {
/*  93 */     this(number, generation, parent, bounds, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Page(int number, int generation, Pages parent, Rectangle2D bounds, boolean filter) {
/* 112 */     super(number, generation);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 314 */     this.alphaDictionaries = new HashMap<Integer, String>(); Args.nullNotPermitted(bounds, "bounds"); this.parent = parent; this.bounds = (Rectangle2D)bounds.clone(); this.fontsOnPage = new ArrayList<String>(); int n = this.parent.getDocument().getNextNumber(); this.contents = new GraphicsStream(n, this); if (filter)
/*     */       this.contents.addFilter((Filter)new FlateFilter());  this.gradientPaintsOnPage = new HashMap<GradientPaintKey, String>(); this.radialGradientPaintsOnPage = new HashMap<RadialGradientPaintKey, String>(); this.patterns = new Dictionary(); this.graphicsStates = new Dictionary(); this.j2DTransform = AffineTransform.getTranslateInstance(0.0D, bounds.getHeight()); this.j2DTransform.concatenate(AffineTransform.getScaleInstance(1.0D, -1.0D)); PDFDocument doc = this.parent.getDocument(); if (doc.isEvaluationVersion() && doc.getEvaluationWatermark() == null) {
/*     */       n = this.parent.getDocument().getNextNumber(); GraphicsStream gs = new GraphicsStream(n, this); PDFGraphics2D g2 = new PDFGraphics2D(gs, (int)this.bounds.getWidth(), (int)this.bounds.getHeight(), true); g2.setFont(new Font("Monospaced", 1, 20)); g2.setPaint(Color.DARK_GRAY); TextUtils.drawAlignedString("Evaluation version of OrsonPDF", g2, (float)this.bounds.getCenterX(), (float)this.bounds.getCenterY(), TextAnchor.CENTER); g2.dispose();
/*     */       doc.setEvaluationWatermark(gs);
/*     */     } 
/*     */   } public Rectangle2D getBounds() { return (Rectangle2D)this.bounds.clone(); } public PDFObject getContents() { return this.contents; }
/*     */   public PDFGraphics2D getGraphics2D() { if (this.graphics2d == null)
/*     */       this.graphics2d = new PDFGraphics2D(this.contents, (int)this.bounds.getWidth(), (int)this.bounds.getHeight()); 
/*     */     return this.graphics2d; }
/*     */   String findOrCreateFontReference(Font font) { String ref = this.parent.findOrCreateFontReference(font);
/*     */     if (!this.fontsOnPage.contains(ref))
/*     */       this.fontsOnPage.add(ref); 
/*     */     return ref; }
/* 327 */   String findOrCreateGSDictionary(int alpha) { Integer key = Integer.valueOf(alpha);
/* 328 */     float alphaValue = alpha / 255.0F;
/* 329 */     String name = this.alphaDictionaries.get(key);
/* 330 */     if (name == null) {
/* 331 */       PDFDocument pdfDoc = this.parent.getDocument();
/* 332 */       GraphicsStateDictionary gsd = new GraphicsStateDictionary(pdfDoc.getNextNumber());
/*     */       
/* 334 */       gsd.setNonStrokeAlpha(alphaValue);
/* 335 */       gsd.setStrokeAlpha(alphaValue);
/* 336 */       pdfDoc.addObject(gsd);
/* 337 */       name = "/GS" + (this.graphicsStates.size() + 1);
/* 338 */       this.graphicsStates.put(name, gsd);
/* 339 */       this.alphaDictionaries.put(key, name);
/*     */     } 
/* 341 */     return name; } private Dictionary createFontDictionary() { Dictionary d = new Dictionary(); for (String name : this.fontsOnPage) {
/*     */       PDFFont f = this.parent.getFont(name); d.put(name, f.getReference());
/*     */     }  return d; }
/*     */   String findOrCreatePattern(GradientPaint gp) { GradientPaintKey key = new GradientPaintKey(gp); String patternName = this.gradientPaintsOnPage.get(key); if (patternName == null) {
/*     */       PDFDocument doc = this.parent.getDocument(); Function f = new ExponentialInterpolationFunction(doc.getNextNumber(), gp.getColor1().getRGBColorComponents(null), gp.getColor2().getRGBColorComponents(null)); doc.addObject(f); double[] coords = new double[4]; coords[0] = gp.getPoint1().getX(); coords[1] = gp.getPoint1().getY(); coords[2] = gp.getPoint2().getX();
/*     */       coords[3] = gp.getPoint2().getY();
/*     */       AxialShading axialShading = new AxialShading(doc.getNextNumber(), coords, f);
/*     */       doc.addObject((PDFObject)axialShading);
/*     */       Pattern p = new Pattern.ShadingPattern(doc.getNextNumber(), (Shading)axialShading, this.j2DTransform);
/*     */       doc.addObject(p);
/*     */       patternName = "/P" + (this.patterns.size() + 1);
/*     */       this.patterns.put(patternName, p);
/*     */       this.gradientPaintsOnPage.put(key, patternName);
/*     */     } 
/*     */     return patternName; }
/* 356 */   String addImage(Image img) { Args.nullNotPermitted(img, "img");
/* 357 */     PDFDocument pdfDoc = this.parent.getDocument();
/* 358 */     PDFImage image = new PDFImage(pdfDoc.getNextNumber(), img);
/* 359 */     image.addFilter((Filter)new FlateFilter());
/* 360 */     pdfDoc.addObject(image);
/* 361 */     String reference = "/Image" + this.xObjects.size();
/* 362 */     this.xObjects.put(reference, image);
/* 363 */     return reference; }
/*     */   String findOrCreatePattern(RadialGradientPaint gp) { RadialGradientPaintKey key = new RadialGradientPaintKey(gp); String patternName = this.radialGradientPaintsOnPage.get(key); if (patternName == null) {
/*     */       PDFDocument doc = this.parent.getDocument(); Function f = createFunctionForMultipleGradient(gp); doc.addObject(f); double[] coords = new double[6]; coords[0] = gp.getFocusPoint().getX(); coords[1] = gp.getFocusPoint().getY(); coords[2] = 0.0D; coords[3] = gp.getCenterPoint().getX(); coords[4] = gp.getCenterPoint().getY(); coords[5] = gp.getRadius(); RadialShading radialShading = new RadialShading(doc.getNextNumber(), coords, f); doc.addObject((PDFObject)radialShading); Pattern p = new Pattern.ShadingPattern(doc.getNextNumber(), (Shading)radialShading, this.j2DTransform); doc.addObject(p); patternName = "/P" + (this.patterns.size() + 1); this.patterns.put(patternName, p);
/*     */       this.radialGradientPaintsOnPage.put(key, patternName);
/*     */     } 
/* 368 */     return patternName; } public byte[] getObjectBytes() { return createDictionary().toPDFBytes(); }
/*     */   private Function createFunctionForMultipleGradient(MultipleGradientPaint mgp) { PDFDocument doc = this.parent.getDocument(); if ((mgp.getColors()).length == 2) { Function f = new ExponentialInterpolationFunction(doc.getNextNumber(), mgp.getColors()[0].getRGBColorComponents(null), mgp.getColors()[1].getRGBColorComponents(null)); return f; }
/*     */      int count = (mgp.getColors()).length - 1; Function[] functions = new Function[count]; float[] fbounds = new float[count - 1]; float[] encode = new float[count * 2]; for (int i = 0; i < count; i++) { functions[i] = new ExponentialInterpolationFunction(doc.getNextNumber(), mgp.getColors()[i].getRGBColorComponents(null), mgp.getColors()[i + 1].getRGBColorComponents(null)); doc.addObject(functions[i]); if (i < count - 1)
/*     */         fbounds[i] = mgp.getFractions()[i + 1];  encode[i * 2] = 0.0F; encode[i * 2 + 1] = 1.0F; }
/* 372 */      return new StitchingFunction(doc.getNextNumber(), functions, fbounds, encode); } private Dictionary createDictionary() { Dictionary dictionary = new Dictionary("/Page");
/* 373 */     dictionary.put("/Parent", this.parent);
/* 374 */     dictionary.put("/MediaBox", this.bounds);
/* 375 */     PDFDocument doc = this.parent.getDocument();
/* 376 */     if (doc.getEvaluationWatermark() != null) {
/* 377 */       dictionary.put("/Contents", new PDFObject[] { this.contents, doc.getEvaluationWatermark() });
/*     */     } else {
/*     */       
/* 380 */       dictionary.put("/Contents", this.contents);
/*     */     } 
/* 382 */     Dictionary resources = new Dictionary();
/* 383 */     resources.put("/ProcSet", "[/PDF /Text /ImageB /ImageC /ImageI]");
/* 384 */     if (!this.xObjects.isEmpty()) {
/* 385 */       resources.put("/XObject", this.xObjects);
/*     */     }
/* 387 */     if (!this.fontsOnPage.isEmpty()) {
/* 388 */       resources.put("/Font", createFontDictionary());
/*     */     }
/* 390 */     if (!this.patterns.isEmpty()) {
/* 391 */       resources.put("/Pattern", this.patterns);
/*     */     }
/* 393 */     if (!this.graphicsStates.isEmpty()) {
/* 394 */       resources.put("/ExtGState", this.graphicsStates);
/*     */     }
/* 396 */     dictionary.put("/Resources", resources);
/* 397 */     return dictionary; }
/*     */ 
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsonpdf-1.6-eval.jar!/com/orsonpdf/Page.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */