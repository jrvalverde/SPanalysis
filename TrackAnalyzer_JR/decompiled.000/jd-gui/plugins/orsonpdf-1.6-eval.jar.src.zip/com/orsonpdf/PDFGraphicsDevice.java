/*    */ package com.orsonpdf;
/*    */ 
/*    */ import java.awt.GraphicsConfiguration;
/*    */ import java.awt.GraphicsDevice;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PDFGraphicsDevice
/*    */   extends GraphicsDevice
/*    */ {
/*    */   private String id;
/*    */   GraphicsConfiguration defaultConfig;
/*    */   
/*    */   public PDFGraphicsDevice(String id, GraphicsConfiguration defaultConfig) {
/* 32 */     this.id = id;
/* 33 */     this.defaultConfig = defaultConfig;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int getType() {
/* 43 */     return 1;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getIDstring() {
/* 53 */     return this.id;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public GraphicsConfiguration[] getConfigurations() {
/* 63 */     return new GraphicsConfiguration[] { getDefaultConfiguration() };
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public GraphicsConfiguration getDefaultConfiguration() {
/* 73 */     return this.defaultConfig;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsonpdf-1.6-eval.jar!/com/orsonpdf/PDFGraphicsDevice.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */