/*    */ package com.orsonpdf.font;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TableInfo
/*    */ {
/*    */   private String tag;
/*    */   private int checksum;
/*    */   private int offset;
/*    */   private int size;
/*    */   
/*    */   public TableInfo(String tag, int checksum, int offset, int size) {
/* 21 */     this.tag = tag;
/* 22 */     this.checksum = checksum;
/* 23 */     this.offset = offset;
/* 24 */     this.size = size;
/*    */   }
/*    */   
/*    */   public String getTag() {
/* 28 */     return this.tag;
/*    */   }
/*    */   
/*    */   public int getOffset() {
/* 32 */     return this.offset;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 36 */     StringBuilder sb = new StringBuilder(this.tag);
/* 37 */     sb.append(": checksum=").append(this.checksum).append(", ");
/* 38 */     sb.append("offset=").append(this.offset).append(", ");
/* 39 */     sb.append("size=").append(this.size).append(";");
/* 40 */     return sb.toString();
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsonpdf-1.6-eval.jar!/com/orsonpdf/font/TableInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */