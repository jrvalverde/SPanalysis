/*    */ package com.orsonpdf.font;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TrueTypeTable
/*    */ {
/*    */   private String tag;
/*    */   private int checkSum;
/*    */   private int offset;
/*    */   private int length;
/*    */   
/*    */   public TrueTypeTable(String tag) {
/* 21 */     this.tag = tag;
/*    */   }
/*    */   
/*    */   public String getTag() {
/* 25 */     return this.tag;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsonpdf-1.6-eval.jar!/com/orsonpdf/font/TrueTypeTable.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */