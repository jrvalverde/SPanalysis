/*     */ package com.orsonpdf.font;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.nio.channels.FileChannel;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TrueTypeFont
/*     */ {
/*     */   private List<TableInfo> tableInfoList;
/*     */   
/*     */   private static TrueTypeTable readcmapTable(TableInfo info, FileInputStream in) throws IOException {
/*  24 */     System.out.println("Reading cmap table...");
/*  25 */     FileChannel channel = in.getChannel();
/*  26 */     channel.position(info.getOffset());
/*  27 */     int version = readUInt2(in);
/*  28 */     System.out.println("version = " + version);
/*  29 */     int numTables = readUInt2(in);
/*  30 */     System.out.println("numTables=" + numTables);
/*  31 */     for (int i = 0; i < numTables; i++) {
/*  32 */       int platformID = readUInt2(in);
/*  33 */       int encodingID = readUInt2(in);
/*  34 */       int offset = readInt4(in);
/*  35 */       long savePosition = channel.position();
/*  36 */       System.out.println("subtable: platformID=" + platformID + ", encodingID=" + encodingID + ", offset=" + offset);
/*  37 */       channel.position((info.getOffset() + offset));
/*  38 */       readcmapSubTable(info, in);
/*  39 */       channel.position(savePosition);
/*     */     } 
/*  41 */     return null;
/*     */   }
/*     */   
/*     */   private static Object readcmapSubTable(TableInfo info, FileInputStream in) throws IOException {
/*  45 */     int format = readUInt2(in);
/*  46 */     System.out.println("format=" + format);
/*  47 */     int length = readUInt2(in);
/*  48 */     System.out.println("length=" + length);
/*  49 */     int language = readUInt2(in);
/*  50 */     System.out.println("language=" + language);
/*  51 */     if (format == 0) {
/*  52 */       for (int i = 0; i < 256; i++) {
/*  53 */         int index = readByte(in);
/*  54 */         System.out.print(index + " ");
/*     */       } 
/*  56 */       System.out.println();
/*  57 */     } else if (format == 4) {
/*  58 */       int segCountX2 = readUInt2(in);
/*  59 */       int segCount = segCountX2 / 2;
/*  60 */       System.out.println("segCountX2=" + segCountX2);
/*  61 */       int searchRange = readUInt2(in);
/*  62 */       System.out.println("searchRange=" + searchRange);
/*  63 */       int entrySelector = readUInt2(in);
/*  64 */       System.out.println("entrySelector=" + entrySelector);
/*  65 */       int rangeShift = readUInt2(in);
/*  66 */       System.out.println("rangeShift=" + rangeShift);
/*  67 */       for (int i = 0; i < segCount; i++) {
/*  68 */         int end = readUInt2(in);
/*  69 */         System.out.print(end + " ");
/*     */       } 
/*  71 */       System.out.println();
/*  72 */       int reservePad = readUInt2(in); int j;
/*  73 */       for (j = 0; j < segCount; j++) {
/*  74 */         int start = readUInt2(in);
/*  75 */         System.out.print(start + " ");
/*     */       } 
/*  77 */       System.out.println();
/*  78 */       for (j = 0; j < segCount; j++) {
/*  79 */         int idDelta = readInt2(in);
/*  80 */         System.out.print(idDelta + " ");
/*     */       } 
/*  82 */       System.out.println();
/*  83 */       for (j = 0; j < segCount; j++) {
/*  84 */         int idRangeOffset = readUInt2(in);
/*  85 */         System.out.print(idRangeOffset + " ");
/*     */       } 
/*  87 */       System.out.println();
/*  88 */       System.out.println("Remains: " + length + "-16-8x" + segCount + "=");
/*  89 */       int entryCount = (length - 16 - 8 * segCount) / 2;
/*  90 */       System.out.println(entryCount);
/*  91 */       for (int k = 0; k < entryCount; k++) {
/*  92 */         int entry = readUInt2(in);
/*  93 */         System.out.print(entry + " ");
/*     */       } 
/*  95 */       System.out.println();
/*     */     } 
/*  97 */     return null;
/*     */   }
/*     */   
/*     */   private static TrueTypeTable readhheaTable(TableInfo info, FileInputStream in) throws IOException {
/* 101 */     FileChannel channel = in.getChannel();
/* 102 */     channel.position(info.getOffset());
/* 103 */     int v1 = readUInt2(in);
/* 104 */     int v2 = readUInt2(in);
/* 105 */     System.out.println("Version " + v1 + "." + v2);
/* 106 */     int ascender = readWord2(in);
/* 107 */     System.out.println("ascender=" + ascender);
/* 108 */     int descender = readWord2(in);
/* 109 */     System.out.println("descender=" + descender);
/* 110 */     int lineGap = readWord2(in);
/* 111 */     System.out.println("lineGap=" + lineGap);
/* 112 */     int advanceWidthMax = readUInt2(in);
/* 113 */     System.out.println("advanceWidthMax=" + advanceWidthMax);
/* 114 */     int minLeftSideBearing = readWord2(in);
/* 115 */     System.out.println("minLeftSideBearing=" + minLeftSideBearing);
/* 116 */     int minRightSideBearing = readWord2(in);
/* 117 */     System.out.println("minRightSideBearing=" + minRightSideBearing);
/* 118 */     int xMaxExtent = readWord2(in);
/* 119 */     System.out.println("xMaxExtent=" + xMaxExtent);
/* 120 */     int caretSlopeRise = readInt2(in);
/* 121 */     System.out.println("caretSlopeRise=" + caretSlopeRise);
/* 122 */     int caretSlopeRun = readInt2(in);
/* 123 */     System.out.println("caretSlopeRun=" + caretSlopeRun);
/* 124 */     int caretOffset = readInt2(in);
/* 125 */     System.out.println("caretOffset=" + caretOffset);
/* 126 */     int ignore = readInt2(in);
/* 127 */     ignore = readInt2(in);
/* 128 */     ignore = readInt2(in);
/* 129 */     ignore = readInt2(in);
/* 130 */     int metricDataFormat = readInt2(in);
/* 131 */     System.out.println("metricDataFormat=" + metricDataFormat);
/* 132 */     int numberOfHMetrics = readUInt2(in);
/* 133 */     System.out.println("numberOfHMetrics=" + numberOfHMetrics);
/* 134 */     return null;
/*     */   }
/*     */   
/*     */   private static TrueTypeTable readhmtxTable(TableInfo info, FileInputStream in, int entries) throws IOException {
/* 138 */     FileChannel channel = in.getChannel();
/* 139 */     channel.position(info.getOffset());
/* 140 */     for (int i = 0; i < 3381; i++) {
/* 141 */       int advanceWidth = readInt2(in);
/* 142 */       int lsb = readUInt2(in);
/*     */     } 
/*     */     
/* 145 */     return null;
/*     */   }
/*     */   
/*     */   private static int readByte(InputStream in) throws IOException {
/* 149 */     byte[] data = new byte[1];
/* 150 */     in.read(data);
/* 151 */     return data[0] & 0xFF;
/*     */   }
/*     */   
/*     */   private static int readUInt2(InputStream in) throws IOException {
/* 155 */     byte[] data = new byte[2];
/* 156 */     in.read(data);
/* 157 */     return (data[0] & 0xFF) << 8 | data[1] & 0xFF;
/*     */   }
/*     */   
/*     */   private static int readInt2(InputStream in) throws IOException {
/* 161 */     byte[] data = new byte[2];
/* 162 */     in.read(data);
/* 163 */     return data[0] * 256 + data[1];
/*     */   }
/*     */   
/*     */   private static int readWord2(InputStream in) throws IOException {
/* 167 */     byte[] data = new byte[2];
/* 168 */     in.read(data);
/* 169 */     return data[0] * 256 + (data[1] & 0xFF);
/*     */   }
/*     */ 
/*     */   
/*     */   private static int readInt4(InputStream in) throws IOException {
/* 174 */     byte[] data = new byte[4];
/* 175 */     in.read(data);
/* 176 */     int d0 = data[0] & 0xFF;
/* 177 */     int d1 = data[1] & 0xFF;
/* 178 */     int d2 = data[2] & 0xFF;
/* 179 */     int d3 = data[3] & 0xFF;
/* 180 */     return 16777216 * d0 + 65536 * d1 + 256 * d2 + d3;
/*     */   }
/*     */   
/*     */   private static String readTag(InputStream in) throws IOException {
/* 184 */     byte[] b = new byte[4];
/* 185 */     in.read(b);
/* 186 */     StringBuilder sb = new StringBuilder();
/* 187 */     for (int i = 0; i < 4; i++) {
/* 188 */       sb.append((char)b[i]);
/*     */     }
/* 190 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public static TrueTypeFont createFont(File file) throws FileNotFoundException, IOException {
/* 195 */     TrueTypeFont font = new TrueTypeFont();
/* 196 */     FileInputStream fis = new FileInputStream(file);
/*     */     try {
/* 198 */       byte[] version = new byte[4];
/* 199 */       fis.read(version);
/* 200 */       int tableCount = readUInt2(fis);
/* 201 */       int ignore1 = readUInt2(fis);
/* 202 */       int ignore2 = readUInt2(fis);
/* 203 */       int ignore3 = readUInt2(fis);
/* 204 */       for (int i = 0; i < tableCount; i++) {
/* 205 */         String tag = readTag(fis);
/* 206 */         System.out.println(tag);
/* 207 */         int checksum = readInt4(fis);
/* 208 */         int offset = readInt4(fis);
/* 209 */         int length = readInt4(fis);
/* 210 */         TableInfo tableInfo = new TableInfo(tag, checksum, offset, length);
/* 211 */         font.addTableInfo(tableInfo);
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 218 */       TableInfo cmapInfo = font.getTableInfo("cmap");
/* 219 */       System.out.println(cmapInfo);
/* 220 */       readcmapTable(cmapInfo, fis);
/*     */       
/* 222 */       TableInfo info = font.getTableInfo("hhea");
/* 223 */       System.out.println(info);
/* 224 */       TrueTypeTable t = readhheaTable(info, fis);
/* 225 */       info = font.getTableInfo("hmtx");
/* 226 */       System.out.println(info);
/* 227 */       TrueTypeTable t2 = readhmtxTable(info, fis, 0);
/*     */     } finally {
/* 229 */       fis.close();
/*     */     } 
/* 231 */     return font;
/*     */   }
/*     */   
/*     */   private TrueTypeFont() {
/* 235 */     this.tableInfoList = new ArrayList<TableInfo>();
/*     */   }
/*     */   
/*     */   public void addTableInfo(TableInfo tableInfo) {
/* 239 */     this.tableInfoList.add(tableInfo);
/*     */   }
/*     */   
/*     */   public TableInfo getTableInfo(String tag) {
/* 243 */     for (TableInfo ti : this.tableInfoList) {
/* 244 */       if (tag.equals(ti.getTag())) {
/* 245 */         return ti;
/*     */       }
/*     */     } 
/* 248 */     return null;
/*     */   }
/*     */   
/*     */   public static void main(String[] args) throws FileNotFoundException, IOException {
/* 252 */     File f = new File("/Library/Fonts/Arial.ttf");
/* 253 */     TrueTypeFont font = createFont(f);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsonpdf-1.6-eval.jar!/com/orsonpdf/font/TrueTypeFont.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */