/*    */ package com.orsonpdf.util;
/*    */ 
/*    */ import java.awt.GradientPaint;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class GradientPaintKey
/*    */ {
/*    */   private GradientPaint paint;
/*    */   
/*    */   public GradientPaintKey(GradientPaint paint) {
/* 32 */     Args.nullNotPermitted(paint, "paint");
/* 33 */     this.paint = paint;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public GradientPaint getPaint() {
/* 43 */     return this.paint;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean equals(Object obj) {
/* 55 */     if (obj == this) {
/* 56 */       return true;
/*    */     }
/* 58 */     if (!(obj instanceof GradientPaintKey)) {
/* 59 */       return false;
/*    */     }
/* 61 */     GradientPaintKey that = (GradientPaintKey)obj;
/* 62 */     GradientPaint thisGP = this.paint;
/* 63 */     GradientPaint thatGP = that.getPaint();
/* 64 */     if (!thisGP.getColor1().equals(thatGP.getColor1())) {
/* 65 */       return false;
/*    */     }
/* 67 */     if (!thisGP.getColor2().equals(thatGP.getColor2())) {
/* 68 */       return false;
/*    */     }
/* 70 */     if (!thisGP.getPoint1().equals(thatGP.getPoint1())) {
/* 71 */       return false;
/*    */     }
/* 73 */     if (!thisGP.getPoint2().equals(thatGP.getPoint2())) {
/* 74 */       return false;
/*    */     }
/* 76 */     if (thisGP.getTransparency() != thatGP.getTransparency()) {
/* 77 */       return false;
/*    */     }
/* 79 */     if (thisGP.isCyclic() != thatGP.isCyclic()) {
/* 80 */       return false;
/*    */     }
/* 82 */     return true;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 92 */     int hash = 5;
/* 93 */     hash = 47 * hash + this.paint.getPoint1().hashCode();
/* 94 */     hash = 47 * hash + this.paint.getPoint2().hashCode();
/* 95 */     hash = 47 * hash + this.paint.getColor1().hashCode();
/* 96 */     hash = 47 * hash + this.paint.getColor2().hashCode();
/* 97 */     return hash;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsonpdf-1.6-eval.jar!/com/orsonpdf/util/GradientPaintKey.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */