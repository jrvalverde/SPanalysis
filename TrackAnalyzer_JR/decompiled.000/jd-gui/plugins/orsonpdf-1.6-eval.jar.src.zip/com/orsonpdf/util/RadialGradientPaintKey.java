/*    */ package com.orsonpdf.util;
/*    */ 
/*    */ import java.awt.RadialGradientPaint;
/*    */ import java.util.Arrays;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RadialGradientPaintKey
/*    */ {
/*    */   private RadialGradientPaint paint;
/* 27 */   float f = 0.0F;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public RadialGradientPaintKey(RadialGradientPaint rgp) {
/* 35 */     Args.nullNotPermitted(rgp, "rgp");
/* 36 */     this.paint = rgp;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public RadialGradientPaint getPaint() {
/* 46 */     return this.paint;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean equals(Object obj) {
/* 58 */     if (obj == this) {
/* 59 */       return true;
/*    */     }
/* 61 */     if (!(obj instanceof RadialGradientPaint)) {
/* 62 */       return false;
/*    */     }
/* 64 */     RadialGradientPaint that = (RadialGradientPaint)obj;
/* 65 */     if (!this.paint.getCenterPoint().equals(that.getCenterPoint())) {
/* 66 */       return false;
/*    */     }
/* 68 */     if (!this.paint.getFocusPoint().equals(that.getCenterPoint())) {
/* 69 */       return false;
/*    */     }
/* 71 */     if (!Arrays.equals((Object[])this.paint.getColors(), (Object[])that.getColors())) {
/* 72 */       return false;
/*    */     }
/* 74 */     if (!Arrays.equals(this.paint.getFractions(), that.getFractions())) {
/* 75 */       return false;
/*    */     }
/* 77 */     return true;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 87 */     int hash = 5;
/* 88 */     hash = 47 * hash + this.paint.getCenterPoint().hashCode();
/* 89 */     hash = 47 * hash + this.paint.getFocusPoint().hashCode();
/* 90 */     hash = 47 * hash + Float.floatToIntBits(this.paint.getRadius());
/* 91 */     hash = 47 * hash + Arrays.hashCode((Object[])this.paint.getColors());
/* 92 */     hash = 47 * hash + Arrays.hashCode(this.paint.getFractions());
/* 93 */     return hash;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsonpdf-1.6-eval.jar!/com/orsonpdf/util/RadialGradientPaintKey.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */