/*    */ package com.orsonpdf.util;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Args
/*    */ {
/*    */   public static void nullNotPermitted(Object obj, String ref) {
/* 31 */     if (obj == null) {
/* 32 */       throw new IllegalArgumentException("Null '" + ref + "' argument.");
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static void arrayMustHaveLength(int length, boolean[] array, String ref) {
/* 47 */     nullNotPermitted(array, "array");
/* 48 */     if (array.length != length) {
/* 49 */       throw new IllegalArgumentException("Array '" + ref + "' requires length " + length);
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static void arrayMustHaveLength(int length, double[] array, String ref) {
/* 65 */     nullNotPermitted(array, "array");
/* 66 */     if (array.length != length)
/* 67 */       throw new IllegalArgumentException("Array '" + ref + "' requires length " + length); 
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsonpdf-1.6-eval.jar!/com/orsonpdf/util/Args.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */