/*     */ package com.orsonpdf.util;
/*     */ 
/*     */ import java.awt.Font;
/*     */ import java.awt.FontMetrics;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.font.FontRenderContext;
/*     */ import java.awt.font.LineMetrics;
/*     */ import java.awt.geom.AffineTransform;
/*     */ import java.awt.geom.Rectangle2D;
/*     */ import java.text.AttributedString;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TextUtils
/*     */ {
/*     */   public static Rectangle2D drawAlignedString(String text, Graphics2D g2, float x, float y, TextAnchor anchor) {
/*  46 */     Rectangle2D textBounds = new Rectangle2D.Double();
/*  47 */     float[] adjust = deriveTextBoundsAnchorOffsets(g2, text, anchor, textBounds);
/*     */ 
/*     */     
/*  50 */     textBounds.setRect((x + adjust[0]), (y + adjust[1] + adjust[2]), textBounds.getWidth(), textBounds.getHeight());
/*     */     
/*  52 */     g2.drawString(text, x + adjust[0], y + adjust[1]);
/*  53 */     return textBounds;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static float[] deriveTextBoundsAnchorOffsets(Graphics2D g2, String text, TextAnchor anchor) {
/*  72 */     float[] result = new float[2];
/*  73 */     FontRenderContext frc = g2.getFontRenderContext();
/*  74 */     Font f = g2.getFont();
/*  75 */     FontMetrics fm = g2.getFontMetrics(f);
/*  76 */     Rectangle2D bounds = getTextBounds(text, g2, fm);
/*  77 */     LineMetrics metrics = f.getLineMetrics(text, frc);
/*  78 */     float ascent = metrics.getAscent();
/*  79 */     float halfAscent = ascent / 2.0F;
/*  80 */     float descent = metrics.getDescent();
/*  81 */     float leading = metrics.getLeading();
/*  82 */     float xAdj = 0.0F;
/*  83 */     float yAdj = 0.0F;
/*     */     
/*  85 */     if (anchor.isHorizontalCenter()) {
/*  86 */       xAdj = (float)-bounds.getWidth() / 2.0F;
/*     */     }
/*  88 */     else if (anchor.isRight()) {
/*  89 */       xAdj = (float)-bounds.getWidth();
/*     */     } 
/*     */     
/*  92 */     if (anchor.isTop()) {
/*  93 */       yAdj = -descent - leading + (float)bounds.getHeight();
/*     */     }
/*  95 */     else if (anchor.isHalfAscent()) {
/*  96 */       yAdj = halfAscent;
/*     */     }
/*  98 */     else if (anchor.isHalfHeight()) {
/*  99 */       yAdj = -descent - leading + (float)(bounds.getHeight() / 2.0D);
/*     */     }
/* 101 */     else if (anchor.isBaseline()) {
/* 102 */       yAdj = 0.0F;
/*     */     }
/* 104 */     else if (anchor.isBottom()) {
/* 105 */       yAdj = -metrics.getDescent() - metrics.getLeading();
/*     */     } 
/* 107 */     result[0] = xAdj;
/* 108 */     result[1] = yAdj;
/* 109 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static float[] deriveTextBoundsAnchorOffsets(Graphics2D g2, String text, TextAnchor anchor, Rectangle2D textBounds) {
/* 131 */     float[] result = new float[3];
/* 132 */     FontRenderContext frc = g2.getFontRenderContext();
/* 133 */     Font f = g2.getFont();
/* 134 */     FontMetrics fm = g2.getFontMetrics(f);
/* 135 */     Rectangle2D bounds = getTextBounds(text, g2, fm);
/* 136 */     LineMetrics metrics = f.getLineMetrics(text, frc);
/* 137 */     float ascent = metrics.getAscent();
/* 138 */     result[2] = -ascent;
/* 139 */     float halfAscent = ascent / 2.0F;
/* 140 */     float descent = metrics.getDescent();
/* 141 */     float leading = metrics.getLeading();
/* 142 */     float xAdj = 0.0F;
/* 143 */     float yAdj = 0.0F;
/*     */     
/* 145 */     if (anchor.isHorizontalCenter()) {
/* 146 */       xAdj = (float)-bounds.getWidth() / 2.0F;
/*     */     }
/* 148 */     else if (anchor.isRight()) {
/* 149 */       xAdj = (float)-bounds.getWidth();
/*     */     } 
/*     */     
/* 152 */     if (anchor.isTop()) {
/* 153 */       yAdj = -descent - leading + (float)bounds.getHeight();
/*     */     }
/* 155 */     else if (anchor.isHalfAscent()) {
/* 156 */       yAdj = halfAscent;
/*     */     }
/* 158 */     else if (anchor.isHalfHeight()) {
/* 159 */       yAdj = -descent - leading + (float)(bounds.getHeight() / 2.0D);
/*     */     }
/* 161 */     else if (anchor.isBaseline()) {
/* 162 */       yAdj = 0.0F;
/*     */     }
/* 164 */     else if (anchor.isBottom()) {
/* 165 */       yAdj = -metrics.getDescent() - metrics.getLeading();
/*     */     } 
/* 167 */     if (textBounds != null) {
/* 168 */       textBounds.setRect(bounds);
/*     */     }
/* 170 */     result[0] = xAdj;
/* 171 */     result[1] = yAdj;
/* 172 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Rectangle2D getTextBounds(String text, Graphics2D g2, FontMetrics fm) {
/* 188 */     double width = fm.stringWidth(text);
/* 189 */     double height = fm.getHeight();
/* 190 */     return new Rectangle2D.Double(0.0D, -fm.getAscent(), width, height);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void drawRotatedString(String text, Graphics2D g2, float x, float y, TextAnchor textAnchor, double angle, float rotationX, float rotationY) {
/* 209 */     if (text == null || text.equals("")) {
/*     */       return;
/*     */     }
/* 212 */     float[] textAdj = deriveTextBoundsAnchorOffsets(g2, text, textAnchor);
/* 213 */     drawRotatedString(text, g2, x + textAdj[0], y + textAdj[1], angle, rotationX, rotationY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void drawRotatedString(String text, Graphics2D g2, float x, float y, TextAnchor textAnchor, double angle, TextAnchor rotationAnchor) {
/* 233 */     if (text == null || text.equals("")) {
/*     */       return;
/*     */     }
/* 236 */     float[] textAdj = deriveTextBoundsAnchorOffsets(g2, text, textAnchor);
/* 237 */     float[] rotateAdj = deriveRotationAnchorOffsets(g2, text, rotationAnchor);
/*     */     
/* 239 */     drawRotatedString(text, g2, x + textAdj[0], y + textAdj[1], angle, x + textAdj[0] + rotateAdj[0], y + textAdj[1] + rotateAdj[1]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static float[] deriveRotationAnchorOffsets(Graphics2D g2, String text, TextAnchor anchor) {
/* 258 */     float[] result = new float[2];
/* 259 */     FontRenderContext frc = g2.getFontRenderContext();
/* 260 */     LineMetrics metrics = g2.getFont().getLineMetrics(text, frc);
/* 261 */     FontMetrics fm = g2.getFontMetrics();
/* 262 */     Rectangle2D bounds = getTextBounds(text, g2, fm);
/* 263 */     float ascent = metrics.getAscent();
/* 264 */     float halfAscent = ascent / 2.0F;
/* 265 */     float descent = metrics.getDescent();
/* 266 */     float leading = metrics.getLeading();
/* 267 */     float xAdj = 0.0F;
/* 268 */     float yAdj = 0.0F;
/*     */     
/* 270 */     if (anchor.isLeft()) {
/* 271 */       xAdj = 0.0F;
/*     */     }
/* 273 */     else if (anchor.isHorizontalCenter()) {
/* 274 */       xAdj = (float)bounds.getWidth() / 2.0F;
/*     */     }
/* 276 */     else if (anchor.isRight()) {
/* 277 */       xAdj = (float)bounds.getWidth();
/*     */     } 
/*     */     
/* 280 */     if (anchor.isTop()) {
/* 281 */       yAdj = descent + leading - (float)bounds.getHeight();
/*     */     }
/* 283 */     else if (anchor.isHalfHeight()) {
/* 284 */       yAdj = descent + leading - (float)(bounds.getHeight() / 2.0D);
/*     */     }
/* 286 */     else if (anchor.isHalfAscent()) {
/* 287 */       yAdj = -halfAscent;
/*     */     }
/* 289 */     else if (anchor.isBaseline()) {
/* 290 */       yAdj = 0.0F;
/*     */     }
/* 292 */     else if (anchor.isBottom()) {
/* 293 */       yAdj = metrics.getDescent() + metrics.getLeading();
/*     */     } 
/* 295 */     result[0] = xAdj;
/* 296 */     result[1] = yAdj;
/* 297 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void drawRotatedString(String text, Graphics2D g2, double angle, float x, float y) {
/* 314 */     drawRotatedString(text, g2, x, y, angle, x, y);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void drawRotatedString(String text, Graphics2D g2, float textX, float textY, double angle, float rotateX, float rotateY) {
/* 335 */     if (text == null || text.equals("")) {
/*     */       return;
/*     */     }
/*     */     
/* 339 */     AffineTransform saved = g2.getTransform();
/*     */ 
/*     */     
/* 342 */     AffineTransform rotate = AffineTransform.getRotateInstance(angle, rotateX, rotateY);
/*     */     
/* 344 */     g2.transform(rotate);
/*     */     
/* 346 */     AttributedString as = new AttributedString(text, (Map)g2.getFont().getAttributes());
/*     */     
/* 348 */     g2.drawString(as.getIterator(), textX, textY);
/* 349 */     g2.setTransform(saved);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsonpdf-1.6-eval.jar!/com/orsonpdf/util/TextUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */