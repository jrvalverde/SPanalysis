/*     */ package com.orsonpdf.util;
/*     */ 
/*     */ import java.awt.Polygon;
/*     */ import java.awt.Shape;
/*     */ import java.awt.geom.Arc2D;
/*     */ import java.awt.geom.Ellipse2D;
/*     */ import java.awt.geom.GeneralPath;
/*     */ import java.awt.geom.Line2D;
/*     */ import java.awt.geom.Path2D;
/*     */ import java.awt.geom.Rectangle2D;
/*     */ import java.awt.geom.RoundRectangle2D;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.awt.image.ColorModel;
/*     */ import java.awt.image.RenderedImage;
/*     */ import java.awt.image.WritableRaster;
/*     */ import java.util.Hashtable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GraphicsUtils
/*     */ {
/*     */   public static Shape copyOf(Shape shape) {
/*  45 */     Args.nullNotPermitted(shape, "shape");
/*  46 */     if (shape instanceof Line2D) {
/*  47 */       Line2D l = (Line2D)shape;
/*  48 */       return new Line2D.Double(l.getX1(), l.getY1(), l.getX2(), l.getY2());
/*     */     } 
/*  50 */     if (shape instanceof Rectangle2D) {
/*  51 */       Rectangle2D r = (Rectangle2D)shape;
/*  52 */       return new Rectangle2D.Double(r.getX(), r.getY(), r.getWidth(), r.getHeight());
/*     */     } 
/*     */     
/*  55 */     if (shape instanceof RoundRectangle2D) {
/*  56 */       RoundRectangle2D rr = (RoundRectangle2D)shape;
/*  57 */       return new RoundRectangle2D.Double(rr.getX(), rr.getY(), rr.getWidth(), rr.getHeight(), rr.getArcWidth(), rr.getArcHeight());
/*     */     } 
/*     */ 
/*     */     
/*  61 */     if (shape instanceof Arc2D) {
/*  62 */       Arc2D arc = (Arc2D)shape;
/*  63 */       return new Arc2D.Double(arc.getX(), arc.getY(), arc.getWidth(), arc.getHeight(), arc.getAngleStart(), arc.getAngleExtent(), arc.getArcType());
/*     */     } 
/*     */ 
/*     */     
/*  67 */     if (shape instanceof Ellipse2D) {
/*  68 */       Ellipse2D ell = (Ellipse2D)shape;
/*  69 */       return new Ellipse2D.Double(ell.getX(), ell.getY(), ell.getWidth(), ell.getHeight());
/*     */     } 
/*     */     
/*  72 */     if (shape instanceof Polygon) {
/*  73 */       Polygon p = (Polygon)shape;
/*  74 */       return new Polygon(p.xpoints, p.ypoints, p.npoints);
/*     */     } 
/*  76 */     return new Path2D.Double(shape);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static GeneralPath createPolygon(int[] xPoints, int[] yPoints, int nPoints, boolean close) {
/*  92 */     GeneralPath p = new GeneralPath();
/*  93 */     p.moveTo(xPoints[0], yPoints[0]);
/*  94 */     for (int i = 1; i < nPoints; i++) {
/*  95 */       p.lineTo(xPoints[i], yPoints[i]);
/*     */     }
/*  97 */     if (close) {
/*  98 */       p.closePath();
/*     */     }
/* 100 */     return p;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static BufferedImage convertRenderedImage(RenderedImage img) {
/* 115 */     if (img instanceof BufferedImage) {
/* 116 */       return (BufferedImage)img;
/*     */     }
/* 118 */     ColorModel cm = img.getColorModel();
/* 119 */     int width = img.getWidth();
/* 120 */     int height = img.getHeight();
/* 121 */     WritableRaster raster = cm.createCompatibleWritableRaster(width, height);
/* 122 */     boolean isAlphaPremultiplied = cm.isAlphaPremultiplied();
/* 123 */     Hashtable<Object, Object> properties = new Hashtable<Object, Object>();
/* 124 */     String[] keys = img.getPropertyNames();
/* 125 */     if (keys != null) {
/* 126 */       for (int i = 0; i < keys.length; i++) {
/* 127 */         properties.put(keys[i], img.getProperty(keys[i]));
/*     */       }
/*     */     }
/* 130 */     BufferedImage result = new BufferedImage(cm, raster, isAlphaPremultiplied, properties);
/*     */     
/* 132 */     img.copyData(raster);
/* 133 */     return result;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsonpdf-1.6-eval.jar!/com/orsonpdf/util/GraphicsUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */