/*     */ package com.orsonpdf.util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public enum TextAnchor
/*     */ {
/*  20 */   TOP_LEFT("TextAnchor.TOP_LEFT"),
/*     */ 
/*     */   
/*  23 */   TOP_CENTER("TextAnchor.TOP_CENTER"),
/*     */ 
/*     */   
/*  26 */   TOP_RIGHT("TextAnchor.TOP_RIGHT"),
/*     */ 
/*     */   
/*  29 */   HALF_ASCENT_LEFT("TextAnchor.HALF_ASCENT_LEFT"),
/*     */ 
/*     */   
/*  32 */   HALF_ASCENT_CENTER("TextAnchor.HALF_ASCENT_CENTER"),
/*     */ 
/*     */   
/*  35 */   HALF_ASCENT_RIGHT("TextAnchor.HALF_ASCENT_RIGHT"),
/*     */ 
/*     */   
/*  38 */   CENTER_LEFT("TextAnchor.CENTER_LEFT"),
/*     */ 
/*     */   
/*  41 */   CENTER("TextAnchor.CENTER"),
/*     */ 
/*     */   
/*  44 */   CENTER_RIGHT("TextAnchor.CENTER_RIGHT"),
/*     */ 
/*     */   
/*  47 */   BASELINE_LEFT("TextAnchor.BASELINE_LEFT"),
/*     */ 
/*     */   
/*  50 */   BASELINE_CENTER("TextAnchor.BASELINE_CENTER"),
/*     */ 
/*     */   
/*  53 */   BASELINE_RIGHT("TextAnchor.BASELINE_RIGHT"),
/*     */ 
/*     */   
/*  56 */   BOTTOM_LEFT("TextAnchor.BOTTOM_LEFT"),
/*     */ 
/*     */   
/*  59 */   BOTTOM_CENTER("TextAnchor.BOTTOM_CENTER"),
/*     */ 
/*     */   
/*  62 */   BOTTOM_RIGHT("TextAnchor.BOTTOM_RIGHT");
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String name;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   TextAnchor(String name) {
/*  73 */     this.name = name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isLeft() {
/*  83 */     return (this == TOP_LEFT || this == CENTER_LEFT || this == HALF_ASCENT_LEFT || this == BASELINE_LEFT || this == BOTTOM_LEFT);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isHorizontalCenter() {
/*  95 */     return (this == TOP_CENTER || this == CENTER || this == HALF_ASCENT_CENTER || this == BASELINE_CENTER || this == BOTTOM_CENTER);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isRight() {
/* 107 */     return (this == TOP_RIGHT || this == CENTER_RIGHT || this == HALF_ASCENT_RIGHT || this == BASELINE_RIGHT || this == BOTTOM_RIGHT);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isTop() {
/* 119 */     return (this == TOP_LEFT || this == TOP_CENTER || this == TOP_RIGHT);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isHalfAscent() {
/* 129 */     return (this == HALF_ASCENT_LEFT || this == HALF_ASCENT_CENTER || this == HALF_ASCENT_RIGHT);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isHalfHeight() {
/* 140 */     return (this == CENTER_LEFT || this == CENTER || this == CENTER_RIGHT);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isBaseline() {
/* 150 */     return (this == BASELINE_LEFT || this == BASELINE_CENTER || this == BASELINE_RIGHT);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isBottom() {
/* 161 */     return (this == BOTTOM_LEFT || this == BOTTOM_CENTER || this == BOTTOM_RIGHT);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 172 */     return this.name;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsonpdf-1.6-eval.jar!/com/orsonpdf/util/TextAnchor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */