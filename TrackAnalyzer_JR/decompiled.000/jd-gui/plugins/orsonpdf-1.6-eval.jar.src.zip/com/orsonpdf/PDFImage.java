/*    */ package com.orsonpdf;
/*    */ 
/*    */ import com.orsonpdf.util.Args;
/*    */ import java.awt.Graphics2D;
/*    */ import java.awt.Image;
/*    */ import java.awt.image.BufferedImage;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PDFImage
/*    */   extends Stream
/*    */ {
/*    */   int width;
/*    */   int height;
/*    */   Image image;
/*    */   
/*    */   public PDFImage(int number, Image img) {
/* 39 */     super(number);
/* 40 */     Args.nullNotPermitted(img, "img");
/* 41 */     this.width = img.getWidth(null);
/* 42 */     this.height = img.getHeight(null);
/* 43 */     this.image = img;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public byte[] getRawStreamData() {
/*    */     BufferedImage bi;
/* 56 */     if (!(this.image instanceof BufferedImage)) {
/* 57 */       bi = new BufferedImage(this.width, this.height, 1);
/*    */       
/* 59 */       Graphics2D g2 = bi.createGraphics();
/* 60 */       g2.drawImage(this.image, 0, 0, null);
/*    */     } else {
/* 62 */       bi = (BufferedImage)this.image;
/*    */     } 
/*    */     
/* 65 */     byte[] result = new byte[this.width * this.height * 3];
/* 66 */     int i = 0;
/* 67 */     for (int hh = this.height - 1; hh >= 0; hh--) {
/* 68 */       for (int ww = 0; ww < this.width; ww++) {
/* 69 */         int rgb = bi.getRGB(ww, hh);
/* 70 */         result[i++] = (byte)(rgb >> 16);
/* 71 */         result[i++] = (byte)(rgb >> 8);
/* 72 */         result[i++] = (byte)rgb;
/*    */       } 
/*    */     } 
/* 75 */     return result;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected Dictionary createDictionary(int streamLength) {
/* 88 */     Dictionary dictionary = super.createDictionary(streamLength);
/* 89 */     dictionary.setType("/XObject");
/* 90 */     dictionary.put("/Subtype", "/Image");
/* 91 */     dictionary.put("/ColorSpace", "/DeviceRGB");
/* 92 */     dictionary.put("/BitsPerComponent", Integer.valueOf(8));
/* 93 */     dictionary.put("/Width", Integer.valueOf(this.width));
/* 94 */     dictionary.put("/Height", Integer.valueOf(this.height));
/* 95 */     return dictionary;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsonpdf-1.6-eval.jar!/com/orsonpdf/PDFImage.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */