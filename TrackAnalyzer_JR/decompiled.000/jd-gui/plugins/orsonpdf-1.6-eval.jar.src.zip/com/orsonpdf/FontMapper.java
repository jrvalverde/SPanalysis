package com.orsonpdf;

import java.awt.Font;

public interface FontMapper {
  String mapToBaseFont(Font paramFont);
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsonpdf-1.6-eval.jar!/com/orsonpdf/FontMapper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */