/*    */ package com.orsonpdf;
/*    */ 
/*    */ import com.orsonpdf.util.Args;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DictionaryObject
/*    */   extends PDFObject
/*    */ {
/*    */   protected Dictionary dictionary;
/*    */   
/*    */   DictionaryObject(int number, String type) {
/* 32 */     super(number);
/* 33 */     this.dictionary = new Dictionary(type);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void put(String name, Object value) {
/* 44 */     Args.nullNotPermitted(value, "value");
/* 45 */     this.dictionary.put("/" + name, value);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Object remove(String name) {
/* 56 */     return this.dictionary.remove("/" + name);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public byte[] getObjectBytes() {
/* 67 */     return this.dictionary.toPDFBytes();
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsonpdf-1.6-eval.jar!/com/orsonpdf/DictionaryObject.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */