/*     */ package com.orsonpdf;
/*     */ 
/*     */ import com.orsonpdf.util.Args;
/*     */ import java.awt.AlphaComposite;
/*     */ import java.awt.BasicStroke;
/*     */ import java.awt.Color;
/*     */ import java.awt.Font;
/*     */ import java.awt.GradientPaint;
/*     */ import java.awt.Image;
/*     */ import java.awt.RadialGradientPaint;
/*     */ import java.awt.Shape;
/*     */ import java.awt.Stroke;
/*     */ import java.awt.geom.AffineTransform;
/*     */ import java.awt.geom.Line2D;
/*     */ import java.awt.geom.NoninvertibleTransformException;
/*     */ import java.awt.geom.Path2D;
/*     */ import java.awt.geom.PathIterator;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.text.DecimalFormat;
/*     */ import java.text.DecimalFormatSymbols;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GraphicsStream
/*     */   extends Stream
/*     */ {
/*     */   private Page page;
/*     */   private ByteArrayOutputStream content;
/*     */   private Font font;
/*     */   private int alpha;
/*     */   private AffineTransform prevTransInv;
/*     */   private DecimalFormat geometryFormat;
/*     */   private DecimalFormat transformFormat;
/*     */   private float alphaFactor;
/*     */   
/*     */   private void addContent(String s) {
/*     */     try {
/*     */       this.content.write(PDFUtils.toBytes(s));
/*     */     } catch (IOException e) {
/*     */       throw new RuntimeException(e);
/*     */     } 
/*     */   }
/*     */   
/*     */   void pushGraphicsState() {
/*     */     addContent("q\n");
/*     */   }
/*     */   
/*     */   void popGraphicsState() {
/*     */     addContent("Q\n");
/*     */   }
/*     */   
/*     */   void applyTransform(AffineTransform t) {
/*     */     StringBuilder b = new StringBuilder();
/*     */     b.append(transformDP(t.getScaleX())).append(" ");
/*     */     b.append(transformDP(t.getShearY())).append(" ");
/*     */     b.append(transformDP(t.getShearX())).append(" ");
/*     */     b.append(transformDP(t.getScaleY())).append(" ");
/*     */     b.append(transformDP(t.getTranslateX())).append(" ");
/*     */     b.append(transformDP(t.getTranslateY())).append(" cm\n");
/*     */     addContent(b.toString());
/*     */   }
/*     */   
/*     */   GraphicsStream(int number, Page page) {
/*  77 */     super(number);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 288 */     this.alphaFactor = 1.0F; this.page = page; this.content = new ByteArrayOutputStream(); this.font = new Font("Dialog", 0, 12); this.alpha = 255; DecimalFormatSymbols dfs = new DecimalFormatSymbols(); dfs.setDecimalSeparator('.'); this.geometryFormat = new DecimalFormat("0.##", dfs); this.transformFormat = new DecimalFormat("0.######", dfs);
/*     */   } void setTransform(AffineTransform t) { AffineTransform tt = new AffineTransform(t); try { AffineTransform comb, inv = tt.createInverse(); if (this.prevTransInv != null) { comb = new AffineTransform(this.prevTransInv); comb.concatenate(tt); }
/*     */       else
/*     */       { comb = tt; }
/*     */        this.prevTransInv = inv; applyTransform(comb); }
/*     */     catch (NoninvertibleTransformException e) {} } void applyTextTransform(AffineTransform t) { StringBuilder b = new StringBuilder(); b.append(t.getScaleX()).append(" "); b.append(t.getShearY()).append(" "); b.append(t.getShearX()).append(" "); b.append(t.getScaleY()).append(" "); b.append(t.getTranslateX()).append(" "); b.append(t.getTranslateY()).append(" Tm\n"); addContent(b.toString()); }
/*     */   void applyClip(Shape clip) { Args.nullNotPermitted(clip, "clip"); StringBuilder b = new StringBuilder(); Path2D p = new Path2D.Double(clip); b.append(getPDFPath(p)); b.append("W n\n"); addContent(b.toString()); }
/* 295 */   void applyComposite(AlphaComposite alphaComp) { if (alphaComp == null) {
/* 296 */       this.alphaFactor = 1.0F;
/*     */     } else {
/* 298 */       this.alphaFactor = alphaComp.getAlpha();
/* 299 */       int a = (int)(alphaComp.getAlpha() * 255.0F);
/* 300 */       if (this.alpha != a) {
/* 301 */         String name = this.page.findOrCreateGSDictionary(a);
/* 302 */         StringBuilder b = new StringBuilder();
/* 303 */         b.append(name).append(" gs\n");
/* 304 */         addContent(b.toString());
/* 305 */         this.alpha = a;
/*     */       } 
/*     */     }  }
/*     */   void applyStroke(Stroke s) { if (!(s instanceof BasicStroke))
/*     */       return;  BasicStroke bs = (BasicStroke)s; StringBuilder b = new StringBuilder(); b.append(bs.getLineWidth()).append(" ").append("w\n"); b.append(bs.getEndCap()).append(" J\n"); b.append(bs.getLineJoin()).append(" j\n"); float[] dashArray = bs.getDashArray(); if (dashArray != null) {
/*     */       b.append(PDFUtils.toPDFArray(dashArray)).append(" 0 d\n");
/*     */     } else {
/*     */       b.append("[] 0 d\n");
/*     */     }  addContent(b.toString()); }
/*     */   void applyStrokeColor(Color c) { float red = c.getRed() / 255.0F; float green = c.getGreen() / 255.0F; float blue = c.getBlue() / 255.0F; StringBuilder b = new StringBuilder(); b.append(red).append(" ").append(green).append(" ").append(blue).append(" RG\n"); addContent(b.toString()); applyAlpha(c.getAlpha()); }
/*     */   void applyFillColor(Color c) { float red = c.getRed() / 255.0F; float green = c.getGreen() / 255.0F; float blue = c.getBlue() / 255.0F; StringBuilder b = new StringBuilder(); b.append(red).append(" ").append(green).append(" ").append(blue).append(" rg\n"); addContent(b.toString());
/* 316 */     applyAlpha(c.getAlpha()); } void applyAlpha(int alpha) { int a = (int)(alpha * this.alphaFactor);
/* 317 */     if (this.alpha != a) {
/* 318 */       String name = this.page.findOrCreateGSDictionary(a);
/* 319 */       StringBuilder b = new StringBuilder();
/* 320 */       b.append(name).append(" gs\n");
/* 321 */       addContent(b.toString());
/* 322 */       this.alpha = a;
/*     */     }  }
/*     */   void applyStrokeGradient(GradientPaint gp) { String patternName = this.page.findOrCreatePattern(gp); StringBuilder b = new StringBuilder("/Pattern CS\n"); b.append(patternName).append(" SCN\n"); addContent(b.toString()); }
/*     */   void applyStrokeGradient(RadialGradientPaint rgp) { String patternName = this.page.findOrCreatePattern(rgp); StringBuilder b = new StringBuilder("/Pattern CS\n"); b.append(patternName).append(" SCN\n"); addContent(b.toString()); }
/*     */   void applyFillGradient(GradientPaint gp) { String patternName = this.page.findOrCreatePattern(gp); StringBuilder b = new StringBuilder("/Pattern cs\n"); b.append(patternName).append(" scn\n"); addContent(b.toString()); }
/* 327 */   void applyFillGradient(RadialGradientPaint rgp) { String patternName = this.page.findOrCreatePattern(rgp); StringBuilder b = new StringBuilder("/Pattern cs\n"); b.append(patternName).append(" scn\n"); addContent(b.toString()); } private String geomDP(double d) { if (this.geometryFormat != null) {
/* 328 */       return this.geometryFormat.format(d);
/*     */     }
/* 330 */     return String.valueOf(d); }
/*     */ 
/*     */ 
/*     */   
/*     */   private String transformDP(double d) {
/* 335 */     if (this.transformFormat != null) {
/* 336 */       return this.transformFormat.format(d);
/*     */     }
/* 338 */     return String.valueOf(d);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void drawLine(Line2D line) {
/* 348 */     StringBuilder b = new StringBuilder();
/* 349 */     b.append(geomDP(line.getX1())).append(" ").append(geomDP(line.getY1())).append(" ").append("m\n");
/*     */     
/* 351 */     b.append(geomDP(line.getX2())).append(" ").append(geomDP(line.getY2())).append(" ").append("l\n");
/*     */     
/* 353 */     b.append("S\n");
/* 354 */     addContent(b.toString());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void drawPath2D(Path2D path) {
/* 363 */     StringBuilder b = new StringBuilder();
/* 364 */     b.append(getPDFPath(path)).append("S\n");
/* 365 */     addContent(b.toString());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void fillPath2D(Path2D path) {
/* 374 */     StringBuilder b = new StringBuilder();
/* 375 */     b.append(getPDFPath(path)).append("f\n");
/* 376 */     addContent(b.toString());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void applyFont(Font font) {
/* 386 */     this.font = font;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void drawString(String text, float x, float y) {
/* 399 */     String fontRef = this.page.findOrCreateFontReference(this.font);
/* 400 */     addContent("BT ");
/* 401 */     AffineTransform t = new AffineTransform(1.0D, 0.0D, 0.0D, -1.0D, 0.0D, (y * 2.0F));
/*     */     
/* 403 */     applyTextTransform(t);
/* 404 */     StringBuilder b = new StringBuilder();
/* 405 */     b.append(fontRef).append(" ").append(this.font.getSize()).append(" Tf ");
/*     */     
/* 407 */     b.append(geomDP(x)).append(" ").append(geomDP(y)).append(" Td (").append(text).append(") Tj ET\n");
/*     */     
/* 409 */     addContent(b.toString());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void drawImage(Image img, int x, int y, int w, int h) {
/* 422 */     String imageRef = this.page.addImage(img);
/* 423 */     StringBuilder b = new StringBuilder();
/* 424 */     b.append("q\n");
/* 425 */     b.append(geomDP(w)).append(" 0 0 ").append(geomDP(h)).append(" ");
/* 426 */     b.append(geomDP(x)).append(" ").append(geomDP(y)).append(" cm\n");
/* 427 */     b.append(imageRef).append(" Do\n");
/* 428 */     b.append("Q\n");
/* 429 */     addContent(b.toString());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String getPDFPath(Path2D path) {
/* 441 */     StringBuilder b = new StringBuilder();
/* 442 */     float[] coords = new float[6];
/* 443 */     float lastX = 0.0F;
/* 444 */     float lastY = 0.0F;
/* 445 */     PathIterator iterator = path.getPathIterator(null);
/* 446 */     while (!iterator.isDone()) {
/* 447 */       float x0, y0, x1, y1; int type = iterator.currentSegment(coords);
/* 448 */       switch (type) {
/*     */         case 0:
/* 450 */           b.append(geomDP(coords[0])).append(" ");
/* 451 */           b.append(geomDP(coords[1])).append(" m\n");
/* 452 */           lastX = coords[0];
/* 453 */           lastY = coords[1];
/*     */           break;
/*     */         case 1:
/* 456 */           b.append(geomDP(coords[0])).append(" ");
/* 457 */           b.append(geomDP(coords[1])).append(" l\n");
/* 458 */           lastX = coords[0];
/* 459 */           lastY = coords[1];
/*     */           break;
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         case 2:
/* 466 */           x0 = 0.25F * lastX + 0.75F * coords[0];
/* 467 */           y0 = 0.25F * lastY + 0.75F * coords[1];
/* 468 */           x1 = 0.5F * coords[0] + 0.5F * coords[2];
/* 469 */           y1 = 0.5F * coords[1] + 0.5F * coords[3];
/* 470 */           b.append(geomDP(x0)).append(" ");
/* 471 */           b.append(geomDP(y0)).append(" ");
/* 472 */           b.append(geomDP(x1)).append(" ");
/* 473 */           b.append(geomDP(y1)).append(" ");
/* 474 */           b.append(geomDP(coords[2])).append(" ");
/* 475 */           b.append(geomDP(coords[3])).append(" c\n");
/* 476 */           lastX = coords[2];
/* 477 */           lastY = coords[3];
/*     */           break;
/*     */         case 3:
/* 480 */           b.append(geomDP(coords[0])).append(" ");
/* 481 */           b.append(geomDP(coords[1])).append(" ");
/* 482 */           b.append(geomDP(coords[2])).append(" ");
/* 483 */           b.append(geomDP(coords[3])).append(" ");
/* 484 */           b.append(geomDP(coords[4])).append(" ");
/* 485 */           b.append(geomDP(coords[5])).append(" c\n");
/* 486 */           lastX = coords[4];
/* 487 */           lastY = coords[5];
/*     */           break;
/*     */         case 4:
/* 490 */           b.append("h\n");
/*     */           break;
/*     */       } 
/*     */ 
/*     */       
/* 495 */       iterator.next();
/*     */     } 
/* 497 */     return b.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public byte[] getRawStreamData() {
/* 502 */     return this.content.toByteArray();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsonpdf-1.6-eval.jar!/com/orsonpdf/GraphicsStream.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */