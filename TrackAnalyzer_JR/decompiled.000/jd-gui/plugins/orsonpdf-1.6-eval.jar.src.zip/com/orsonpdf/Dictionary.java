/*     */ package com.orsonpdf;
/*     */ 
/*     */ import java.awt.geom.Rectangle2D;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Dictionary
/*     */ {
/*     */   private String type;
/*     */   private Map map;
/*     */   
/*     */   public Dictionary() {
/*  41 */     this(null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Dictionary(String type) {
/*  51 */     this.type = type;
/*  52 */     this.map = new HashMap<Object, Object>();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getType() {
/*  61 */     return this.type;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setType(String type) {
/*  70 */     this.type = type;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/*  82 */     return this.map.isEmpty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int size() {
/*  91 */     return this.map.size();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void put(String key, Object value) {
/* 101 */     this.map.put(key, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object remove(String key) {
/* 113 */     return this.map.remove(key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] toPDFBytes() {
/* 122 */     ByteArrayOutputStream baos = new ByteArrayOutputStream();
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 127 */       baos.write(PDFUtils.toBytes(toPDFString()));
/* 128 */     } catch (IOException ex) {
/* 129 */       throw new RuntimeException("Dictionary.toPDFBytes() failed.");
/*     */     } 
/* 131 */     return baos.toByteArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toPDFString() {
/* 142 */     StringBuilder b = new StringBuilder();
/* 143 */     b.append("<< ");
/* 144 */     if (this.type != null) {
/* 145 */       b.append("/Type ").append(this.type).append("\n");
/*     */     }
/*     */     
/* 148 */     for (Object key : this.map.keySet()) {
/* 149 */       Object value = this.map.get(key);
/* 150 */       if (value instanceof Number || value instanceof String) {
/* 151 */         b.append(key.toString()).append(" ");
/* 152 */         b.append(value.toString()).append("\n"); continue;
/* 153 */       }  if (value instanceof PDFObject) {
/* 154 */         PDFObject pdfObj = (PDFObject)value;
/* 155 */         b.append(key.toString()).append(" ");
/* 156 */         b.append(pdfObj.getReference()).append("\n"); continue;
/* 157 */       }  if (value instanceof String[]) {
/* 158 */         b.append(key.toString()).append(" ");
/* 159 */         String[] array = (String[])value;
/* 160 */         b.append("[");
/* 161 */         for (int i = 0; i < array.length; i++) {
/* 162 */           if (i != 0) {
/* 163 */             b.append(" ");
/*     */           }
/* 165 */           b.append(array[i]);
/*     */         } 
/* 167 */         b.append("]\n"); continue;
/* 168 */       }  if (value instanceof PDFObject[]) {
/* 169 */         b.append(key.toString()).append(" ");
/* 170 */         PDFObject[] array = (PDFObject[])value;
/* 171 */         b.append("[");
/* 172 */         for (int i = 0; i < array.length; i++) {
/* 173 */           if (i != 0) {
/* 174 */             b.append(" ");
/*     */           }
/* 176 */           b.append(array[i].getReference());
/*     */         } 
/* 178 */         b.append("]\n"); continue;
/* 179 */       }  if (value instanceof Rectangle2D) {
/* 180 */         Rectangle2D r = (Rectangle2D)value;
/* 181 */         b.append(key.toString()).append(" ");
/* 182 */         b.append("[").append(r.getX()).append(" ");
/* 183 */         b.append(r.getY()).append(" ").append(r.getWidth()).append(" ");
/* 184 */         b.append(r.getHeight()).append("]\n"); continue;
/* 185 */       }  if (value instanceof Dictionary) {
/* 186 */         b.append(key.toString()).append(" ");
/* 187 */         Dictionary d = (Dictionary)value;
/* 188 */         b.append(d.toPDFString()); continue;
/* 189 */       }  if (value instanceof float[]) {
/* 190 */         b.append(key.toString()).append(" ");
/* 191 */         float[] array = (float[])value;
/* 192 */         b.append("[");
/* 193 */         for (int i = 0; i < array.length; i++) {
/* 194 */           if (i != 0) {
/* 195 */             b.append(" ");
/*     */           }
/* 197 */           b.append(array[i]);
/*     */         } 
/* 199 */         b.append("]\n");
/*     */         
/*     */         continue;
/*     */       } 
/* 203 */       throw new RuntimeException("Unrecognised value type: " + value);
/*     */     } 
/*     */     
/* 206 */     b.append(">>\n");
/* 207 */     return b.toString();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsonpdf-1.6-eval.jar!/com/orsonpdf/Dictionary.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */