/*     */ package com.orsonpdf;
/*     */ 
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class PDFObject
/*     */ {
/*     */   private int number;
/*     */   private int generation;
/*     */   
/*     */   protected PDFObject(int number) {
/*  35 */     this(number, 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected PDFObject(int number, int generation) {
/*  46 */     this.number = number;
/*  47 */     this.generation = generation;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getNumber() {
/*  56 */     return this.number;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getGeneration() {
/*  65 */     return this.generation;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getReference() {
/*  76 */     return this.number + " " + this.generation + " R";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] toPDFBytes() throws IOException {
/*  87 */     ByteArrayOutputStream baos = new ByteArrayOutputStream();
/*  88 */     baos.write(PDFUtils.toBytes(objectIntroString()));
/*  89 */     baos.write(getObjectBytes());
/*  90 */     baos.write(PDFUtils.toBytes("endobj\n"));
/*  91 */     return baos.toByteArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract byte[] getObjectBytes() throws IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String objectIntroString() {
/* 103 */     StringBuilder b = new StringBuilder();
/* 104 */     b.append(this.number).append(" ").append(this.generation).append(" ");
/* 105 */     b.append("obj\n");
/* 106 */     return b.toString();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsonpdf-1.6-eval.jar!/com/orsonpdf/PDFObject.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */