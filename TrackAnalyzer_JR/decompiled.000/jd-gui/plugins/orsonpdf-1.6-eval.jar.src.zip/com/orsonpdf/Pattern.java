/*    */ package com.orsonpdf;
/*    */ 
/*    */ import com.orsonpdf.shading.Shading;
/*    */ import com.orsonpdf.util.Args;
/*    */ import java.awt.geom.AffineTransform;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class Pattern
/*    */   extends PDFObject
/*    */ {
/*    */   protected Dictionary dictionary;
/*    */   
/*    */   public static final class ShadingPattern
/*    */     extends Pattern
/*    */   {
/*    */     private Shading shading;
/*    */     
/*    */     public ShadingPattern(int number, Shading shading, AffineTransform t) {
/* 37 */       super(number);
/* 38 */       this.dictionary.put("/PatternType", "2");
/* 39 */       this.dictionary.put("/Matrix", PDFUtils.transformToPDF(t));
/* 40 */       setShading(shading);
/*    */     }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/*    */     public Shading getShading() {
/* 49 */       return this.shading;
/*    */     }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/*    */     public void setShading(Shading shading) {
/* 58 */       Args.nullNotPermitted(shading, "shading");
/* 59 */       this.shading = shading;
/* 60 */       this.dictionary.put("/Shading", this.shading);
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected Pattern(int number) {
/* 72 */     super(number);
/* 73 */     this.dictionary = new Dictionary("/Pattern");
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public byte[] getObjectBytes() {
/* 84 */     return this.dictionary.toPDFBytes();
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsonpdf-1.6-eval.jar!/com/orsonpdf/Pattern.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */