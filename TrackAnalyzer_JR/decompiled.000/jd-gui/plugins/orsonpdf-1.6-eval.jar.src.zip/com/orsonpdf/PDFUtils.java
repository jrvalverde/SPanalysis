/*     */ package com.orsonpdf;
/*     */ 
/*     */ import com.orsonpdf.util.Args;
/*     */ import java.awt.geom.AffineTransform;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.text.DateFormat;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Calendar;
/*     */ import java.util.Date;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PDFUtils
/*     */ {
/*     */   public static String toPDFArray(boolean[] b) {
/*  38 */     Args.nullNotPermitted(b, "b");
/*  39 */     StringBuilder sb = new StringBuilder("[");
/*  40 */     for (int i = 0; i < b.length; i++) {
/*  41 */       if (i != 0) {
/*  42 */         sb.append(" ");
/*     */       }
/*  44 */       sb.append(String.valueOf(b[i]));
/*     */     } 
/*  46 */     return sb.append("]").toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String toPDFArray(float[] f) {
/*  57 */     Args.nullNotPermitted(f, "f");
/*  58 */     StringBuilder b = new StringBuilder("[");
/*  59 */     for (int i = 0; i < f.length; i++) {
/*  60 */       if (i != 0) {
/*  61 */         b.append(" ");
/*     */       }
/*  63 */       b.append(String.valueOf(f[i]));
/*     */     } 
/*  65 */     return b.append("]").toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String toPDFArray(double[] d) {
/*  76 */     Args.nullNotPermitted(d, "d");
/*  77 */     StringBuilder b = new StringBuilder("[");
/*  78 */     for (int i = 0; i < d.length; i++) {
/*  79 */       if (i != 0) {
/*  80 */         b.append(" ");
/*     */       }
/*  82 */       b.append(String.valueOf(d[i]));
/*     */     } 
/*  84 */     return b.append("]").toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String transformToPDF(AffineTransform t) {
/*  95 */     Args.nullNotPermitted(t, "t");
/*  96 */     StringBuilder b = new StringBuilder("[");
/*  97 */     b.append(t.getScaleX()).append(" ");
/*  98 */     b.append(t.getShearY()).append(" ");
/*  99 */     b.append(t.getShearX()).append(" ");
/* 100 */     b.append(t.getScaleY()).append(" ");
/* 101 */     b.append(t.getTranslateX()).append(" ");
/* 102 */     b.append(t.getTranslateY());
/* 103 */     return b.append("]").toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String toDateFormat(Date date) {
/* 115 */     Calendar c = Calendar.getInstance();
/* 116 */     c.setTime(date);
/* 117 */     return toPDFDateFormat(c);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String toPDFDateFormat(Calendar calendar) {
/*     */     String tzinfo;
/* 129 */     Date d = calendar.getTime();
/* 130 */     DateFormat df1 = new SimpleDateFormat("yyyyMMddHHmmss");
/* 131 */     DateFormat df2 = new SimpleDateFormat("Z");
/* 132 */     String part1 = df1.format(d);
/* 133 */     String part2 = df2.format(d);
/*     */     
/* 135 */     if (part2.equals("z")) {
/* 136 */       tzinfo = "Z00'00'";
/*     */     } else {
/* 138 */       tzinfo = part2.substring(0, 3) + "'" + part2.substring(4) + "'";
/*     */     } 
/* 140 */     return "D:" + part1 + tzinfo;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte[] toBytes(String s) {
/* 151 */     byte[] result = null;
/*     */     try {
/* 153 */       result = s.getBytes("US-ASCII");
/* 154 */     } catch (UnsupportedEncodingException ex) {
/* 155 */       throw new RuntimeException(ex);
/*     */     } 
/* 157 */     return result;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsonpdf-1.6-eval.jar!/com/orsonpdf/PDFUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */