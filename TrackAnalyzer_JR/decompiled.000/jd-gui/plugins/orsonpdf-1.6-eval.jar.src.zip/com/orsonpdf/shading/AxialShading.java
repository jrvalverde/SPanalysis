/*     */ package com.orsonpdf.shading;
/*     */ 
/*     */ import com.orsonpdf.Function;
/*     */ import com.orsonpdf.PDFUtils;
/*     */ import com.orsonpdf.util.Args;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class AxialShading
/*     */   extends Shading
/*     */ {
/*     */   private double[] coords;
/*     */   private Function function;
/*     */   private double[] domain;
/*     */   private boolean[] extend;
/*     */   
/*     */   public AxialShading(int number, double[] coords, Function function) {
/*  43 */     super(number, ShadingType.AXIAL);
/*  44 */     Args.arrayMustHaveLength(4, coords, "coords");
/*  45 */     Args.nullNotPermitted(function, "function");
/*  46 */     this.dictionary.put("/ColorSpace", "/DeviceRGB");
/*  47 */     setCoords(coords);
/*  48 */     setFunction(function);
/*  49 */     setExtend(new boolean[] { true, true });
/*  50 */     this.domain = new double[] { 0.0D, 1.0D };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double[] getCoords() {
/*  60 */     return (double[])this.coords.clone();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCoords(double[] coords) {
/*  70 */     Args.arrayMustHaveLength(4, coords, "coords");
/*  71 */     this.coords = (double[])coords.clone();
/*  72 */     this.dictionary.put("/Coords", PDFUtils.toPDFArray(this.coords));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Function getFunction() {
/*  81 */     return this.function;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFunction(Function function) {
/*  90 */     Args.nullNotPermitted(function, "function");
/*  91 */     this.function = function;
/*  92 */     this.dictionary.put("/Function", this.function);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double[] getDomain() {
/* 102 */     return (double[])this.domain.clone();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDomain(double[] domain) {
/* 111 */     Args.arrayMustHaveLength(2, domain, "domain");
/* 112 */     this.domain = (double[])domain.clone();
/* 113 */     this.dictionary.put("/Domain", PDFUtils.toPDFArray(this.domain));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean[] getExtend() {
/* 122 */     return (boolean[])this.extend.clone();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setExtend(boolean[] extend) {
/* 131 */     Args.arrayMustHaveLength(2, extend, "extend");
/* 132 */     this.extend = (boolean[])extend.clone();
/* 133 */     this.dictionary.put("/Extend", PDFUtils.toPDFArray(this.extend));
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsonpdf-1.6-eval.jar!/com/orsonpdf/shading/AxialShading.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */