/*    */ package com.orsonpdf.shading;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum ShadingType
/*    */ {
/* 18 */   FUNCTION(1),
/*    */ 
/*    */   
/* 21 */   AXIAL(2),
/*    */ 
/*    */   
/* 24 */   RADIAL(3),
/*    */   
/* 26 */   FREE_FORM(4),
/*    */   
/* 28 */   LATTICE_FORM(5),
/*    */   
/* 30 */   COONS(6),
/*    */   
/* 32 */   TENSOR(7);
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private int number;
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   ShadingType(int number) {
/* 43 */     this.number = number;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int getNumber() {
/* 52 */     return this.number;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsonpdf-1.6-eval.jar!/com/orsonpdf/shading/ShadingType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */