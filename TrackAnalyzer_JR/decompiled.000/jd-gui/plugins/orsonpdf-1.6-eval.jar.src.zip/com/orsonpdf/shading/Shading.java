/*    */ package com.orsonpdf.shading;
/*    */ 
/*    */ import com.orsonpdf.Dictionary;
/*    */ import com.orsonpdf.PDFObject;
/*    */ import com.orsonpdf.util.Args;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class Shading
/*    */   extends PDFObject
/*    */ {
/*    */   private ShadingType shadingType;
/*    */   protected Dictionary dictionary;
/*    */   
/*    */   protected Shading(int number, ShadingType shadingType) {
/* 36 */     super(number);
/* 37 */     Args.nullNotPermitted(shadingType, "shadingType");
/* 38 */     this.shadingType = shadingType;
/* 39 */     this.dictionary = new Dictionary();
/* 40 */     this.dictionary.put("/ShadingType", String.valueOf(shadingType.getNumber()));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ShadingType getShadingType() {
/* 50 */     return this.shadingType;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public byte[] getObjectBytes() {
/* 61 */     return this.dictionary.toPDFBytes();
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsonpdf-1.6-eval.jar!/com/orsonpdf/shading/Shading.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */