package com.orsonpdf.shading;

interface package-info {}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/orsonpdf-1.6-eval.jar!/com/orsonpdf/shading/package-info.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */