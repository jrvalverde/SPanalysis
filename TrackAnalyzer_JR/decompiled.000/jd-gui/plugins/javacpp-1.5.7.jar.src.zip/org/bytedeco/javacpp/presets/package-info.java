/**
 * Contains base presets which can be inherited.
 */
@org.osgi.annotation.bundle.Export
package org.bytedeco.javacpp.presets;
