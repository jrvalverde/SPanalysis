/**
 * Contains classes used at build time by JavaCPP.
 */
@org.osgi.annotation.bundle.Export(
		attribute="exclude:=\"BuildMojo,ParseMojo,CacheMojo\"")
package org.bytedeco.javacpp.tools;
