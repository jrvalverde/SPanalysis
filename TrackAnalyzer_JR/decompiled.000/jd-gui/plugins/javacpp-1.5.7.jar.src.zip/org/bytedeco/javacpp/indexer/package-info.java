/**
 * Contains classes for multidimensional access of arrays and buffers.
 */
@org.osgi.annotation.bundle.Export
package org.bytedeco.javacpp.indexer;
