/*     */ package org.apache.commons.math3;
/*     */ 
/*     */ import java.util.Random;
/*     */ import java.util.concurrent.Callable;
/*     */ import org.apache.commons.math3.exception.MathIllegalStateException;
/*     */ import org.apache.commons.math3.exception.util.LocalizedFormats;
/*     */ import org.apache.commons.math3.stat.descriptive.StatisticalSummary;
/*     */ import org.apache.commons.math3.stat.descriptive.SummaryStatistics;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PerfTestUtils
/*     */ {
/*     */   public static final double NANO_TO_MILLI = 1.0E-6D;
/*     */   private static final int DEFAULT_REPEAT_CHUNK = 1000;
/*     */   private static final int DEFAULT_REPEAT_STAT = 10000;
/*  37 */   private static Random rng = new Random();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static StatisticalSummary[] time(int repeatChunk, int repeatStat, boolean runGC, Callable<Double>... methods) {
/*  58 */     double[][][] times = timesAndResults(repeatChunk, repeatStat, runGC, methods);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  63 */     int len = methods.length;
/*  64 */     StatisticalSummary[] stats = new StatisticalSummary[len];
/*  65 */     for (int j = 0; j < len; j++) {
/*  66 */       SummaryStatistics s = new SummaryStatistics();
/*  67 */       for (int k = 0; k < repeatStat; k++) {
/*  68 */         s.addValue(times[j][k][0]);
/*     */       }
/*  70 */       stats[j] = s.getSummary();
/*     */     } 
/*     */     
/*  73 */     return stats;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static double[][][] timesAndResults(int repeatChunk, int repeatStat, boolean runGC, Callable<Double>... methods) {
/* 103 */     int numMethods = methods.length;
/* 104 */     double[][][] timesAndResults = new double[numMethods][repeatStat][2];
/*     */     
/*     */     try {
/* 107 */       for (int k = 0; k < repeatStat; k++) {
/* 108 */         for (int i = 0; i < numMethods; i++) {
/* 109 */           if (runGC)
/*     */           {
/* 111 */             System.gc();
/*     */           }
/*     */           
/* 114 */           Callable<Double> r = methods[i];
/* 115 */           double[] result = new double[repeatChunk];
/*     */ 
/*     */           
/* 118 */           long start = System.nanoTime();
/* 119 */           for (int m = 0; m < repeatChunk; m++) {
/* 120 */             result[m] = ((Double)r.call()).doubleValue();
/*     */           }
/* 122 */           long stop = System.nanoTime();
/*     */ 
/*     */           
/* 125 */           timesAndResults[i][k][0] = (stop - start) * 1.0E-6D;
/*     */           
/* 127 */           timesAndResults[i][k][1] = result[rng.nextInt(repeatChunk)];
/*     */         } 
/*     */       } 
/* 130 */     } catch (Exception e) {
/*     */       
/* 132 */       throw new MathIllegalStateException(LocalizedFormats.SIMPLE_MESSAGE, new Object[] { e.getMessage() });
/*     */     } 
/*     */     
/* 135 */     double normFactor = 1.0D / repeatChunk;
/* 136 */     for (int j = 0; j < numMethods; j++) {
/* 137 */       for (int k = 0; k < repeatStat; k++) {
/* 138 */         timesAndResults[j][k][0] = timesAndResults[j][k][0] * normFactor;
/*     */       }
/*     */     } 
/*     */     
/* 142 */     return timesAndResults;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static StatisticalSummary[] timeAndReport(String title, int repeatChunk, int repeatStat, boolean runGC, RunTest... methods) {
/* 170 */     String hFormat = "%s (calls per timed block: %d, timed blocks: %d, time unit: ms)";
/*     */ 
/*     */     
/* 173 */     int nameLength = 0;
/* 174 */     for (RunTest m : methods) {
/* 175 */       int len = m.getName().length();
/* 176 */       if (len > nameLength) {
/* 177 */         nameLength = len;
/*     */       }
/*     */     } 
/* 180 */     String nameLengthFormat = "%" + nameLength + "s";
/*     */ 
/*     */     
/* 183 */     String cFormat = nameLengthFormat + " %14s %14s %10s %10s %15s";
/*     */     
/* 185 */     String format = nameLengthFormat + " %.8e %.8e %.4e %.4e % .8e";
/*     */     
/* 187 */     System.out.println(String.format("%s (calls per timed block: %d, timed blocks: %d, time unit: ms)", new Object[] { title, Integer.valueOf(repeatChunk), Integer.valueOf(repeatStat) }));
/*     */ 
/*     */ 
/*     */     
/* 191 */     System.out.println(String.format(cFormat, new Object[] { "name", "time/call", "std error", "total time", "ratio", "difference" }));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 198 */     StatisticalSummary[] time = time(repeatChunk, repeatStat, runGC, (Callable<Double>[])methods);
/*     */ 
/*     */ 
/*     */     
/* 202 */     double refSum = time[0].getSum() * repeatChunk;
/* 203 */     for (int i = 0, max = time.length; i < max; i++) {
/* 204 */       StatisticalSummary s = time[i];
/* 205 */       double sum = s.getSum() * repeatChunk;
/* 206 */       System.out.println(String.format(format, new Object[] { methods[i].getName(), Double.valueOf(s.getMean()), Double.valueOf(s.getStandardDeviation()), Double.valueOf(sum), Double.valueOf(sum / refSum), Double.valueOf(sum - refSum) }));
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 215 */     return time;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static StatisticalSummary[] timeAndReport(String title, RunTest... methods) {
/* 232 */     return timeAndReport(title, 1000, 10000, false, methods);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static abstract class RunTest
/*     */     implements Callable<Double>
/*     */   {
/*     */     private final String name;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public RunTest(String name) {
/* 249 */       this.name = name;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getName() {
/* 256 */       return this.name;
/*     */     }
/*     */     
/*     */     public abstract Double call() throws Exception;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/commons-math3-3.6.1-tools.jar!/org/apache/commons/math3/PerfTestUtils.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */