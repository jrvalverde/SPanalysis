/**
 * The base package for the <b>JFreeSVG</b> library.  This package 
 * contains utility and other supporting classes.
 */
package org.jfree.graphics2d;