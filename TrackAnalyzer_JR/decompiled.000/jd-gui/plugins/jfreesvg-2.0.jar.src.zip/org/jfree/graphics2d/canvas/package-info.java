/**
 * Contains {@link org.jfree.graphics2d.canvas.CanvasGraphics2D}  to allow 
 * Java2D rendering to a Javascript function that will render the vector 
 * graphics on an HTML5 Canvas.
 */
package org.jfree.graphics2d.canvas;