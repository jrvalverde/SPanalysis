package jwizardcomponent;

public interface Action {
  void performAction();
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/JWizardComponent.jar!/jwizardcomponent/Action.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */