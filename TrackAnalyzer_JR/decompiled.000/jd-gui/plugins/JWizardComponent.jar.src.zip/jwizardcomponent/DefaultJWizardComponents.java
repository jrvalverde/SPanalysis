package jwizardcomponent;

import java.awt.CardLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import javax.swing.JButton;
import javax.swing.JPanel;

public class DefaultJWizardComponents implements JWizardComponents {
  private ResourceBundle resourceBundle = ResourceBundle.getBundle("jwizardcomponent/i18n");
  
  JButton backButton;
  
  JButton nextButton;
  
  JButton finishButton;
  
  JButton cancelButton;
  
  FinishAction finishAction;
  
  CancelAction cancelAction;
  
  List panelList;
  
  int currentIndex;
  
  JPanel wizardPanelsContainer;
  
  PropertyChangeSupport propertyChangeListeners;
  
  public DefaultJWizardComponents() {
    try {
      init();
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
  }
  
  public void addWizardPanel(JWizardPanel paramJWizardPanel) {
    getWizardPanelList().add(paramJWizardPanel);
    this.wizardPanelsContainer.add(paramJWizardPanel, (getWizardPanelList().size() - 1) + "");
  }
  
  public void addWizardPanel(int paramInt, JWizardPanel paramJWizardPanel) {
    getWizardPanelList().add(paramInt, paramJWizardPanel);
    this.wizardPanelsContainer.add(paramJWizardPanel, paramInt + "", paramInt);
    if (paramInt < getWizardPanelList().size() - 1)
      for (int i = paramInt + 1; i < getWizardPanelList().size(); i++)
        this.wizardPanelsContainer.add(getWizardPanelList().get(i), i + "");  
  }
  
  public void addWizardPanelAfter(JWizardPanel paramJWizardPanel1, JWizardPanel paramJWizardPanel2) {
    addWizardPanel(getWizardPanelList().indexOf(paramJWizardPanel1) + 1, paramJWizardPanel2);
  }
  
  public void addWizardPanelBefore(JWizardPanel paramJWizardPanel1, JWizardPanel paramJWizardPanel2) {
    addWizardPanel(getWizardPanelList().indexOf(paramJWizardPanel1) - 1, paramJWizardPanel2);
  }
  
  public void addWizardPanelAfterCurrent(JWizardPanel paramJWizardPanel) {
    addWizardPanel(getCurrentIndex() + 1, paramJWizardPanel);
  }
  
  public JWizardPanel removeWizardPanel(JWizardPanel paramJWizardPanel) {
    int i = getWizardPanelList().indexOf(paramJWizardPanel);
    getWizardPanelList().remove(paramJWizardPanel);
    this.wizardPanelsContainer.remove(paramJWizardPanel);
    for (int j = i; j < getWizardPanelList().size(); j++)
      this.wizardPanelsContainer.add(getWizardPanelList().get(j), j + ""); 
    return paramJWizardPanel;
  }
  
  public JWizardPanel removeWizardPanel(int paramInt) {
    this.wizardPanelsContainer.remove(paramInt);
    JWizardPanel jWizardPanel = getWizardPanelList().remove(paramInt);
    for (int i = paramInt; i < getWizardPanelList().size(); i++)
      this.wizardPanelsContainer.add(getWizardPanelList().get(i), i + ""); 
    return jWizardPanel;
  }
  
  public JWizardPanel removeWizardPanelAfter(JWizardPanel paramJWizardPanel) {
    return removeWizardPanel(getWizardPanelList().indexOf(paramJWizardPanel) + 1);
  }
  
  public JWizardPanel removeWizardPanelBefore(JWizardPanel paramJWizardPanel) {
    return removeWizardPanel(getWizardPanelList().indexOf(paramJWizardPanel) - 1);
  }
  
  public JWizardPanel getWizardPanel(int paramInt) {
    return getWizardPanelList().get(paramInt);
  }
  
  public int getIndexOfPanel(JWizardPanel paramJWizardPanel) {
    return getWizardPanelList().indexOf(paramJWizardPanel);
  }
  
  public boolean onLastPanel() {
    return (getCurrentIndex() == getWizardPanelList().size() - 1);
  }
  
  private void init() throws Exception {
    this.propertyChangeListeners = new PropertyChangeSupport(this);
    this.backButton = new JButton();
    this.nextButton = new JButton();
    this.finishButton = new JButton();
    this.cancelButton = new JButton();
    this.panelList = new ArrayList();
    this.currentIndex = 0;
    this.wizardPanelsContainer = new JPanel();
    this.backButton.setText(this.resourceBundle.getString("L_BackButton"));
    this.backButton.setMnemonic(this.resourceBundle.getString("L_BackButtonMnem").charAt(0));
    this.backButton.addActionListener(new ActionListener(this) {
          private final DefaultJWizardComponents this$0;
          
          public void actionPerformed(ActionEvent param1ActionEvent) {
            this.this$0.backButton_actionPerformed(param1ActionEvent);
          }
        });
    this.nextButton.setText(this.resourceBundle.getString("L_NextButton"));
    this.nextButton.setMnemonic(this.resourceBundle.getString("L_NextButtonMnem").charAt(0));
    this.nextButton.addActionListener(new ActionListener(this) {
          private final DefaultJWizardComponents this$0;
          
          public void actionPerformed(ActionEvent param1ActionEvent) {
            this.this$0.nextButton_actionPerformed(param1ActionEvent);
          }
        });
    this.cancelButton.setText(this.resourceBundle.getString("L_CancelButton"));
    this.cancelButton.setMnemonic(this.resourceBundle.getString("L_CancelButtonMnem").charAt(0));
    this.cancelButton.addActionListener(new ActionListener(this) {
          private final DefaultJWizardComponents this$0;
          
          public void actionPerformed(ActionEvent param1ActionEvent) {
            this.this$0.cancelButton_actionPerformed(param1ActionEvent);
          }
        });
    this.finishButton.setText(this.resourceBundle.getString("L_FinishButton"));
    this.finishButton.setMnemonic(this.resourceBundle.getString("L_FinishButtonMnem").charAt(0));
    this.finishButton.addActionListener(new ActionListener(this) {
          private final DefaultJWizardComponents this$0;
          
          public void actionPerformed(ActionEvent param1ActionEvent) {
            this.this$0.finishButton_actionPerformed(param1ActionEvent);
          }
        });
    this.wizardPanelsContainer.setLayout(new CardLayout());
  }
  
  void cancelButton_actionPerformed(ActionEvent paramActionEvent) {
    getCancelAction().performAction();
  }
  
  void finishButton_actionPerformed(ActionEvent paramActionEvent) {
    getFinishAction().performAction();
  }
  
  void nextButton_actionPerformed(ActionEvent paramActionEvent) {
    try {
      getCurrentPanel().next();
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
  }
  
  void backButton_actionPerformed(ActionEvent paramActionEvent) {
    try {
      getCurrentPanel().back();
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
  }
  
  public JWizardPanel getCurrentPanel() throws Exception {
    if (getWizardPanelList().get(this.currentIndex) != null)
      return getWizardPanelList().get(this.currentIndex); 
    throw new Exception("No panels in panelList");
  }
  
  public void updateComponents() {
    try {
      CardLayout cardLayout = (CardLayout)this.wizardPanelsContainer.getLayout();
      cardLayout.show(this.wizardPanelsContainer, this.currentIndex + "");
      if (this.currentIndex == 0) {
        this.backButton.setEnabled(false);
      } else {
        this.backButton.setEnabled(true);
      } 
      if (onLastPanel()) {
        this.nextButton.setEnabled(false);
        this.finishButton.setEnabled(true);
      } else {
        this.finishButton.setEnabled(false);
        this.nextButton.setEnabled(true);
      } 
      getCurrentPanel().update();
      PropertyChangeEvent propertyChangeEvent = new PropertyChangeEvent(this, "currentPanel", null, getCurrentPanel());
      this.propertyChangeListeners.firePropertyChange(propertyChangeEvent);
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
  }
  
  public List getWizardPanelList() {
    return this.panelList;
  }
  
  public void setWizardPanelList(ArrayList paramArrayList) {
    this.panelList = paramArrayList;
  }
  
  public FinishAction getFinishAction() {
    return this.finishAction;
  }
  
  public void setFinishAction(FinishAction paramFinishAction) {
    this.finishAction = paramFinishAction;
  }
  
  public CancelAction getCancelAction() {
    return this.cancelAction;
  }
  
  public void setCancelAction(CancelAction paramCancelAction) {
    this.cancelAction = paramCancelAction;
  }
  
  public int getCurrentIndex() {
    return this.currentIndex;
  }
  
  public void setCurrentIndex(int paramInt) {
    this.currentIndex = paramInt;
  }
  
  public JPanel getWizardPanelsContainer() {
    return this.wizardPanelsContainer;
  }
  
  public void setWizardPanelsContainer(JPanel paramJPanel) {
    this.wizardPanelsContainer = paramJPanel;
  }
  
  public JButton getBackButton() {
    return this.backButton;
  }
  
  public void setBackButton(JButton paramJButton) {
    this.backButton = paramJButton;
  }
  
  public JButton getNextButton() {
    return this.nextButton;
  }
  
  public void setNextButton(JButton paramJButton) {
    this.nextButton = paramJButton;
  }
  
  public JButton getCancelButton() {
    return this.cancelButton;
  }
  
  public void setCancelButton(JButton paramJButton) {
    this.cancelButton = paramJButton;
  }
  
  public JButton getFinishButton() {
    return this.finishButton;
  }
  
  public void setFinishButton(JButton paramJButton) {
    this.finishButton = paramJButton;
  }
  
  public void setWizardPanelList(List paramList) {
    this.panelList = paramList;
  }
  
  public void addPropertyChangeListener(PropertyChangeListener paramPropertyChangeListener) {
    this.propertyChangeListeners.addPropertyChangeListener(paramPropertyChangeListener);
  }
  
  public void removePropertyChangeListener(PropertyChangeListener paramPropertyChangeListener) {
    this.propertyChangeListeners.removePropertyChangeListener(paramPropertyChangeListener);
  }
  
  public ResourceBundle getResourceBundle() {
    return this.resourceBundle;
  }
  
  public void setResourceBundle(ResourceBundle paramResourceBundle) {
    this.resourceBundle = paramResourceBundle;
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/JWizardComponent.jar!/jwizardcomponent/DefaultJWizardComponents.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */