package jwizardcomponent;

import java.util.List;

public interface JWizard {
  List getWizardPanelList();
  
  void setWizardPanelList(List paramList);
  
  void addWizardPanel(JWizardPanel paramJWizardPanel);
  
  void addWizardPanel(int paramInt, JWizardPanel paramJWizardPanel);
  
  JWizardPanel removeWizardPanel(JWizardPanel paramJWizardPanel);
  
  JWizardPanel removeWizardPanel(int paramInt);
  
  JWizardPanel getWizardPanel(int paramInt);
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/JWizardComponent.jar!/jwizardcomponent/JWizard.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */