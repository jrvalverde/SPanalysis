package jwizardcomponent.dialog;

import java.awt.Color;
import java.awt.Frame;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import javax.swing.ImageIcon;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSeparator;
import jwizardcomponent.CancelAction;
import jwizardcomponent.DefaultJWizardComponents;
import jwizardcomponent.FinishAction;
import jwizardcomponent.JWizardComponents;
import jwizardcomponent.common.SimpleButtonPanel;

public class SimpleLogoJWizardDialog extends JDialog {
  DefaultJWizardComponents wizardComponents;
  
  JPanel buttonPanel;
  
  JLabel statusLabel = new JLabel();
  
  ImageIcon logo;
  
  public SimpleLogoJWizardDialog(ImageIcon paramImageIcon) {
    this.logo = paramImageIcon;
    this.wizardComponents = new DefaultJWizardComponents();
    init();
  }
  
  public SimpleLogoJWizardDialog(Frame paramFrame, ImageIcon paramImageIcon, boolean paramBoolean) {
    super(paramFrame, paramBoolean);
    this.logo = paramImageIcon;
    this.wizardComponents = new DefaultJWizardComponents();
    init();
  }
  
  private void init() {
    String str;
    getContentPane().setLayout(new GridBagLayout());
    JPanel jPanel = new JPanel();
    if (this.logo.toString().indexOf("file:") < 0 && this.logo.toString().indexOf("http:") < 0) {
      str = "file:///" + System.getProperty("user.dir") + "/" + this.logo.toString();
      str = str.replaceAll("\\\\", "/");
    } else {
      str = this.logo.toString();
    } 
    jPanel.add(new JLabel("<html><img src='" + str + "'></html>"), "Center");
    jPanel.setBackground(Color.WHITE);
    getContentPane().add(jPanel, new GridBagConstraints(0, 0, 1, 1, 0.3D, 0.9D, 10, 1, new Insets(0, 0, 0, 0), 0, 0));
    getContentPane().add(this.wizardComponents.getWizardPanelsContainer(), new GridBagConstraints(1, 0, 1, 1, 0.7D, 0.9D, 10, 1, new Insets(0, 0, 0, 0), 0, 0));
    getContentPane().add(new JSeparator(), new GridBagConstraints(0, 1, 2, 0, 1.0D, 0.01D, 17, 1, new Insets(1, 1, 1, 1), 0, 0));
    this.buttonPanel = (JPanel)new SimpleButtonPanel((JWizardComponents)this.wizardComponents);
    getContentPane().add(this.buttonPanel, new GridBagConstraints(0, 2, 2, 1, 1.0D, 0.09D, 17, 1, new Insets(0, 0, 0, 0), 0, 0));
    this.wizardComponents.setFinishAction(new FinishAction(this, (JWizardComponents)this.wizardComponents) {
          private final SimpleLogoJWizardDialog this$0;
          
          public void performAction() {
            this.this$0.dispose();
          }
        });
    this.wizardComponents.setCancelAction(new CancelAction(this, (JWizardComponents)this.wizardComponents) {
          private final SimpleLogoJWizardDialog this$0;
          
          public void performAction() {
            this.this$0.dispose();
          }
        });
  }
  
  public DefaultJWizardComponents getWizardComponents() {
    return this.wizardComponents;
  }
  
  public void setWizardComponents(DefaultJWizardComponents paramDefaultJWizardComponents) {
    this.wizardComponents = paramDefaultJWizardComponents;
  }
  
  public void show() {
    this.wizardComponents.updateComponents();
    super.show();
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/JWizardComponent.jar!/jwizardcomponent/dialog/SimpleLogoJWizardDialog.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */