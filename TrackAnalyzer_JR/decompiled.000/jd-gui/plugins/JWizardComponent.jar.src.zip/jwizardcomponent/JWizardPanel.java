package jwizardcomponent;

import javax.swing.JPanel;

public abstract class JWizardPanel extends JPanel {
  private JWizardComponents wizardComponents;
  
  private String panelTitle;
  
  public JWizardPanel(JWizardComponents paramJWizardComponents) {
    this(paramJWizardComponents, null);
  }
  
  public JWizardPanel(JWizardComponents paramJWizardComponents, String paramString) {
    this.wizardComponents = paramJWizardComponents;
    this.panelTitle = paramString;
  }
  
  public void update() {}
  
  public void next() {
    goNext();
  }
  
  public void back() {
    goBack();
  }
  
  public JWizardComponents getWizardComponents() {
    return this.wizardComponents;
  }
  
  public void setWizardComponents(JWizardComponents paramJWizardComponents) {
    this.wizardComponents = paramJWizardComponents;
  }
  
  public String getPanelTitle() {
    return this.panelTitle;
  }
  
  public void setPanelTitle(String paramString) {
    this.panelTitle = paramString;
  }
  
  protected boolean goNext() {
    if (this.wizardComponents.getWizardPanelList().size() > this.wizardComponents.getCurrentIndex() + 1) {
      this.wizardComponents.setCurrentIndex(this.wizardComponents.getCurrentIndex() + 1);
      this.wizardComponents.updateComponents();
      return true;
    } 
    return false;
  }
  
  protected boolean goBack() {
    if (this.wizardComponents.getCurrentIndex() - 1 >= 0) {
      this.wizardComponents.setCurrentIndex(this.wizardComponents.getCurrentIndex() - 1);
      this.wizardComponents.updateComponents();
      return true;
    } 
    return false;
  }
  
  protected void switchPanel(int paramInt) {
    getWizardComponents().setCurrentIndex(paramInt);
    getWizardComponents().updateComponents();
  }
  
  protected void setBackButtonEnabled(boolean paramBoolean) {
    this.wizardComponents.getBackButton().setEnabled(paramBoolean);
  }
  
  protected void setNextButtonEnabled(boolean paramBoolean) {
    this.wizardComponents.getNextButton().setEnabled(paramBoolean);
  }
  
  protected void setFinishButtonEnabled(boolean paramBoolean) {
    this.wizardComponents.getFinishButton().setEnabled(paramBoolean);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/JWizardComponent.jar!/jwizardcomponent/JWizardPanel.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */