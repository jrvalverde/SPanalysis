package jwizardcomponent;

public abstract class CancelAction implements Action {
  JWizardComponents wizardComponents;
  
  public CancelAction(JWizardComponents paramJWizardComponents) {
    this.wizardComponents = paramJWizardComponents;
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/JWizardComponent.jar!/jwizardcomponent/CancelAction.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */