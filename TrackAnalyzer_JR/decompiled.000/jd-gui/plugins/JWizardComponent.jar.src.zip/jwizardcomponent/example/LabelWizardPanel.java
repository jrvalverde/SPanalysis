package jwizardcomponent.example;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import javax.swing.JLabel;
import jwizardcomponent.JWizardComponents;
import jwizardcomponent.JWizardPanel;

class LabelWizardPanel extends JWizardPanel {
  public LabelWizardPanel(JWizardComponents paramJWizardComponents, String paramString) {
    super(paramJWizardComponents);
    setLayout(new GridBagLayout());
    add(new JLabel(paramString), new GridBagConstraints(0, 0, 1, 1, 0.0D, 0.0D, 10, 1, new Insets(0, 0, 0, 0), 0, 0));
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/JWizardComponent.jar!/jwizardcomponent/example/LabelWizardPanel.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */