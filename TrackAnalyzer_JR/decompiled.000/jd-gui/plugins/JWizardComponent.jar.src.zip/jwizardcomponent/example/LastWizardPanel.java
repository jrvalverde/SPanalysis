package jwizardcomponent.example;

import jwizardcomponent.JWizardComponents;

class LastWizardPanel extends LabelWizardPanel {
  public LastWizardPanel(JWizardComponents paramJWizardComponents) {
    super(paramJWizardComponents, "Last panel, you can finish now");
    setPanelTitle("Last simple static panel");
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/JWizardComponent.jar!/jwizardcomponent/example/LastWizardPanel.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */