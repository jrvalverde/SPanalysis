package jwizardcomponent.example;

import java.awt.Component;
import jwizardcomponent.Utilities;
import jwizardcomponent.frame.JWizardFrame;

public class DynamicJWizard extends JWizardFrame {
  public static final int PANEL_FIRST = 0;
  
  public static final int PANEL_CHOOSER = 1;
  
  public static final int PANEL_OPTION_A = 2;
  
  public static final int PANEL_OPTION_B = 3;
  
  public static final int PANEL_LAST = 4;
  
  public DynamicJWizard() {
    init();
  }
  
  private void init() {
    setTitle("Dynamic JWizardComponent example");
    FirstWizardPanel firstWizardPanel = null;
    firstWizardPanel = new FirstWizardPanel(getWizardComponents());
    getWizardComponents().addWizardPanel(0, firstWizardPanel);
    ChooserWizardPanel chooserWizardPanel = new ChooserWizardPanel(getWizardComponents());
    getWizardComponents().addWizardPanel(1, chooserWizardPanel);
    OptionWizardPanel optionWizardPanel = new OptionWizardPanel(getWizardComponents(), "A");
    getWizardComponents().addWizardPanel(2, optionWizardPanel);
    optionWizardPanel = new OptionWizardPanel(getWizardComponents(), "B");
    getWizardComponents().addWizardPanel(3, optionWizardPanel);
    LastWizardPanel lastWizardPanel = new LastWizardPanel(getWizardComponents());
    getWizardComponents().addWizardPanel(4, lastWizardPanel);
    setSize(500, 300);
    Utilities.centerComponentOnScreen((Component)this);
  }
  
  public static void main(String[] paramArrayOfString) {
    DynamicJWizard dynamicJWizard = new DynamicJWizard();
    dynamicJWizard.setVisible(true);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/JWizardComponent.jar!/jwizardcomponent/example/DynamicJWizard.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */