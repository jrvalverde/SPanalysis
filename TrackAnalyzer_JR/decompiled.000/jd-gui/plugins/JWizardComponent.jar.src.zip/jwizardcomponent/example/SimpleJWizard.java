package jwizardcomponent.example;

import java.awt.Component;
import javax.swing.JLabel;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import jwizardcomponent.JWizardComponents;
import jwizardcomponent.Utilities;
import jwizardcomponent.frame.SimpleJWizardFrame;

public class SimpleJWizard extends SimpleJWizardFrame {
  public static void main(String[] paramArrayOfString) {
    try {
      SimpleJWizardFrame simpleJWizardFrame = new SimpleJWizardFrame();
      simpleJWizardFrame.setDefaultCloseOperation(3);
      UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
      SwingUtilities.updateComponentTreeUI((Component)simpleJWizardFrame);
      simpleJWizardFrame.setTitle("Simple JWizardComponent");
      simpleJWizardFrame.getWizardComponents().addWizardPanel(new SimpleLabelWizardPanel((JWizardComponents)simpleJWizardFrame.getWizardComponents(), new JLabel("Yo")));
      simpleJWizardFrame.getWizardComponents().addWizardPanel(new SimpleLabelWizardPanel((JWizardComponents)simpleJWizardFrame.getWizardComponents(), new JLabel("This")));
      simpleJWizardFrame.getWizardComponents().addWizardPanel(new SimpleLabelWizardPanel((JWizardComponents)simpleJWizardFrame.getWizardComponents(), new JLabel("Is")));
      simpleJWizardFrame.getWizardComponents().addWizardPanel(new SimpleLabelWizardPanel((JWizardComponents)simpleJWizardFrame.getWizardComponents(), new JLabel("A")));
      simpleJWizardFrame.getWizardComponents().addWizardPanel(new SimpleLabelWizardPanel((JWizardComponents)simpleJWizardFrame.getWizardComponents(), new JLabel("Test!")));
      simpleJWizardFrame.setSize(500, 300);
      Utilities.centerComponentOnScreen((Component)simpleJWizardFrame);
      simpleJWizardFrame.show();
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/JWizardComponent.jar!/jwizardcomponent/example/SimpleJWizard.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */