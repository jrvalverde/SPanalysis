package jwizardcomponent.example;

import jwizardcomponent.JWizardComponents;

class OptionWizardPanel extends LabelWizardPanel {
  public OptionWizardPanel(JWizardComponents paramJWizardComponents, String paramString) {
    super(paramJWizardComponents, "Option " + paramString + " was choosed");
    setPanelTitle("Option " + paramString + " panel");
  }
  
  public void next() {
    switchPanel(4);
  }
  
  public void back() {
    switchPanel(1);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/JWizardComponent.jar!/jwizardcomponent/example/OptionWizardPanel.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */