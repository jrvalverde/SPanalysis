package jwizardcomponent.example;

import java.awt.Component;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import jwizardcomponent.DefaultJWizardComponents;
import jwizardcomponent.JWizardComponents;
import jwizardcomponent.Utilities;
import jwizardcomponent.frame.SimpleLogoJWizardFrame;

public class SimpleDynamicLogoJWizard {
  static ImageIcon LOGO;
  
  public static void main(String[] paramArrayOfString) {
    try {
      LOGO = new ImageIcon(DefaultJWizardComponents.class.getResource("images/logo.jpeg"));
      SimpleLogoJWizardFrame simpleLogoJWizardFrame = new SimpleLogoJWizardFrame(LOGO);
      simpleLogoJWizardFrame.setDefaultCloseOperation(3);
      UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
      SwingUtilities.updateComponentTreeUI((Component)simpleLogoJWizardFrame);
      simpleLogoJWizardFrame.setTitle("Simple Logo Dynamic JWizardComponent");
      simpleLogoJWizardFrame.getWizardComponents().addWizardPanel(new SimpleLabelWizardPanel((JWizardComponents)simpleLogoJWizardFrame.getWizardComponents(), new JLabel("Dynamic Test")));
      simpleLogoJWizardFrame.getWizardComponents().addWizardPanel(new SimpleDynamicWizardPanel((JWizardComponents)simpleLogoJWizardFrame.getWizardComponents()));
      simpleLogoJWizardFrame.getWizardComponents().addWizardPanel(new SimpleLabelWizardPanel((JWizardComponents)simpleLogoJWizardFrame.getWizardComponents(), new JLabel("Done!")));
      simpleLogoJWizardFrame.setSize(500, 300);
      Utilities.centerComponentOnScreen((Component)simpleLogoJWizardFrame);
      simpleLogoJWizardFrame.show();
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/JWizardComponent.jar!/jwizardcomponent/example/SimpleDynamicLogoJWizard.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */