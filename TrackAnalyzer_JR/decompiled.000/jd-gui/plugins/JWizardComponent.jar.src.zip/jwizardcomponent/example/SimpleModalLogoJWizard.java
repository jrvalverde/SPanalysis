package jwizardcomponent.example;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import jwizardcomponent.JWizardComponents;
import jwizardcomponent.Utilities;
import jwizardcomponent.dialog.SimpleLogoJWizardDialog;

public class SimpleModalLogoJWizard {
  static ImageIcon LOGO;
  
  public static void main(String[] paramArrayOfString) {
    try {
      UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
      JFrame jFrame = new JFrame("Simple demo of a modal wizard with a logo icon.");
      jFrame.getContentPane().setLayout(new BorderLayout());
      jFrame.getContentPane().add("North", new JLabel("Click the button to get a modal wizard dialog for this JFrame.", 0));
      JButton jButton = new JButton("open modal wizard");
      jButton.addActionListener(new ActionListener(jFrame) {
            private final JFrame val$mainWindow;
            
            public void actionPerformed(ActionEvent param1ActionEvent) {
              SimpleLogoJWizardDialog simpleLogoJWizardDialog = new SimpleLogoJWizardDialog(this.val$mainWindow, SimpleModalLogoJWizard.LOGO, true);
              SwingUtilities.updateComponentTreeUI((Component)simpleLogoJWizardDialog);
              simpleLogoJWizardDialog.setTitle("Simple Logo JWizardComponent");
              simpleLogoJWizardDialog.getWizardComponents().addWizardPanel(new SimpleLabelWizardPanel((JWizardComponents)simpleLogoJWizardDialog.getWizardComponents(), new JLabel("This")));
              simpleLogoJWizardDialog.getWizardComponents().addWizardPanel(new SimpleLabelWizardPanel((JWizardComponents)simpleLogoJWizardDialog.getWizardComponents(), new JLabel("is")));
              simpleLogoJWizardDialog.getWizardComponents().addWizardPanel(new SimpleLabelWizardPanel((JWizardComponents)simpleLogoJWizardDialog.getWizardComponents(), new JLabel("a")));
              simpleLogoJWizardDialog.getWizardComponents().addWizardPanel(new SimpleLabelWizardPanel((JWizardComponents)simpleLogoJWizardDialog.getWizardComponents(), new JLabel("modal")));
              simpleLogoJWizardDialog.getWizardComponents().addWizardPanel(new SimpleLabelWizardPanel((JWizardComponents)simpleLogoJWizardDialog.getWizardComponents(), new JLabel("wizard!")));
              simpleLogoJWizardDialog.setSize(500, 300);
              simpleLogoJWizardDialog.setDefaultCloseOperation(2);
              Utilities.centerComponentOnScreen((Component)simpleLogoJWizardDialog);
              simpleLogoJWizardDialog.show();
            }
          });
      jFrame.getContentPane().add("South", jButton);
      jFrame.setSize(400, 100);
      jFrame.setDefaultCloseOperation(3);
      LOGO = new ImageIcon("images/logo.jpeg");
      jFrame.show();
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/JWizardComponent.jar!/jwizardcomponent/example/SimpleModalLogoJWizard.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */