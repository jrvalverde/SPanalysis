package jwizardcomponent.example;

import java.awt.Component;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import jwizardcomponent.JWizardComponents;
import jwizardcomponent.Utilities;
import jwizardcomponent.frame.SimpleJWizardFrame;
import jwizardcomponent.frame.SimpleLogoJWizardFrame;

public class SimpleLogoJWizard extends SimpleJWizardFrame {
  static ImageIcon LOGO;
  
  public static void main(String[] paramArrayOfString) {
    try {
      LOGO = new ImageIcon("images/logo.jpeg");
      SimpleLogoJWizardFrame simpleLogoJWizardFrame = new SimpleLogoJWizardFrame(LOGO);
      simpleLogoJWizardFrame.setDefaultCloseOperation(3);
      UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
      SwingUtilities.updateComponentTreeUI((Component)simpleLogoJWizardFrame);
      simpleLogoJWizardFrame.setTitle("Simple Logo JWizardComponent");
      simpleLogoJWizardFrame.getWizardComponents().addWizardPanel(new SimpleLabelWizardPanel((JWizardComponents)simpleLogoJWizardFrame.getWizardComponents(), new JLabel("Yo")));
      simpleLogoJWizardFrame.getWizardComponents().addWizardPanel(new SimpleLabelWizardPanel((JWizardComponents)simpleLogoJWizardFrame.getWizardComponents(), new JLabel("This")));
      simpleLogoJWizardFrame.getWizardComponents().addWizardPanel(new SimpleLabelWizardPanel((JWizardComponents)simpleLogoJWizardFrame.getWizardComponents(), new JLabel("Is")));
      simpleLogoJWizardFrame.getWizardComponents().addWizardPanel(new SimpleLabelWizardPanel((JWizardComponents)simpleLogoJWizardFrame.getWizardComponents(), new JLabel("A")));
      simpleLogoJWizardFrame.getWizardComponents().addWizardPanel(new SimpleLabelWizardPanel((JWizardComponents)simpleLogoJWizardFrame.getWizardComponents(), new JLabel("Test!")));
      simpleLogoJWizardFrame.setSize(500, 300);
      Utilities.centerComponentOnScreen((Component)simpleLogoJWizardFrame);
      simpleLogoJWizardFrame.show();
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/JWizardComponent.jar!/jwizardcomponent/example/SimpleLogoJWizard.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */