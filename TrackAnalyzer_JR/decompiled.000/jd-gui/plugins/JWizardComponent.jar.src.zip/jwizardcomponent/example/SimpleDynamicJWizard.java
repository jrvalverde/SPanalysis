package jwizardcomponent.example;

import java.awt.Component;
import javax.swing.JLabel;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import jwizardcomponent.JWizardComponents;
import jwizardcomponent.Utilities;
import jwizardcomponent.frame.SimpleJWizardFrame;

public class SimpleDynamicJWizard extends SimpleJWizardFrame {
  public static void main(String[] paramArrayOfString) {
    try {
      SimpleJWizardFrame simpleJWizardFrame = new SimpleJWizardFrame();
      simpleJWizardFrame.setDefaultCloseOperation(3);
      UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
      SwingUtilities.updateComponentTreeUI((Component)simpleJWizardFrame);
      simpleJWizardFrame.setTitle("Simple Dynamic JWizardComponent");
      simpleJWizardFrame.getWizardComponents().addWizardPanel(new SimpleLabelWizardPanel((JWizardComponents)simpleJWizardFrame.getWizardComponents(), new JLabel("Dynamic Test")));
      simpleJWizardFrame.getWizardComponents().addWizardPanel(new SimpleDynamicWizardPanel((JWizardComponents)simpleJWizardFrame.getWizardComponents()));
      simpleJWizardFrame.getWizardComponents().addWizardPanel(new SimpleLabelWizardPanel((JWizardComponents)simpleJWizardFrame.getWizardComponents(), new JLabel("Done!")));
      simpleJWizardFrame.setSize(500, 300);
      Utilities.centerComponentOnScreen((Component)simpleJWizardFrame);
      simpleJWizardFrame.show();
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/JWizardComponent.jar!/jwizardcomponent/example/SimpleDynamicJWizard.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */