package jwizardcomponent.example;

import jwizardcomponent.JWizardComponents;

class FirstWizardPanel extends LabelWizardPanel {
  public FirstWizardPanel(JWizardComponents paramJWizardComponents) {
    super(paramJWizardComponents, "First panel");
    setPanelTitle("First simple static panel");
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/JWizardComponent.jar!/jwizardcomponent/example/FirstWizardPanel.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */