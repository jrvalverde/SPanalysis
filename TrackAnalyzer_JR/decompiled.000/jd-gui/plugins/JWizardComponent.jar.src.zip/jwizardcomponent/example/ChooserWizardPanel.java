package jwizardcomponent.example;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import javax.swing.ButtonGroup;
import javax.swing.JLabel;
import javax.swing.JRadioButton;
import jwizardcomponent.JWizardComponents;
import jwizardcomponent.JWizardPanel;

class ChooserWizardPanel extends JWizardPanel {
  private JRadioButton optionARadioButton;
  
  private JRadioButton optionBRadioButton;
  
  private JRadioButton optionFRadioButton;
  
  private ButtonGroup bg;
  
  private char selectedOption = 'N';
  
  public ChooserWizardPanel(JWizardComponents paramJWizardComponents) {
    super(paramJWizardComponents, "Choose option A or B or F for finish ");
    init();
  }
  
  private void init() {
    this.optionARadioButton = new JRadioButton();
    this.optionBRadioButton = new JRadioButton();
    this.optionFRadioButton = new JRadioButton();
    ButtonGroup buttonGroup = new ButtonGroup();
    buttonGroup.add(this.optionARadioButton);
    buttonGroup.add(this.optionBRadioButton);
    buttonGroup.add(this.optionFRadioButton);
    setLayout(new GridBagLayout());
    add(this.optionARadioButton, new GridBagConstraints(0, 0, 1, 1, 0.0D, 0.0D, 17, 1, new Insets(0, 0, 0, 0), 0, 0));
    this.optionARadioButton.addItemListener(new ItemListener(this) {
          private final ChooserWizardPanel this$0;
          
          public void itemStateChanged(ItemEvent param1ItemEvent) {
            if (param1ItemEvent.getStateChange() == 1) {
              this.this$0.selectedOption = 'A';
              this.this$0.update();
            } 
          }
        });
    add(new JLabel("Choose option A"), new GridBagConstraints(1, 0, 1, 1, 0.0D, 0.0D, 17, 1, new Insets(0, 0, 0, 0), 0, 0));
    add(this.optionBRadioButton, new GridBagConstraints(0, 1, 1, 1, 0.0D, 0.0D, 17, 1, new Insets(0, 0, 0, 0), 0, 0));
    this.optionBRadioButton.addItemListener(new ItemListener(this) {
          private final ChooserWizardPanel this$0;
          
          public void itemStateChanged(ItemEvent param1ItemEvent) {
            if (param1ItemEvent.getStateChange() == 1) {
              this.this$0.selectedOption = 'B';
              this.this$0.update();
            } 
          }
        });
    add(new JLabel("Choose option B"), new GridBagConstraints(1, 1, 1, 1, 0.0D, 0.0D, 17, 1, new Insets(0, 0, 0, 0), 0, 0));
    add(this.optionFRadioButton, new GridBagConstraints(0, 2, 1, 1, 0.0D, 0.0D, 17, 1, new Insets(0, 0, 0, 0), 0, 0));
    this.optionFRadioButton.addItemListener(new ItemListener(this) {
          private final ChooserWizardPanel this$0;
          
          public void itemStateChanged(ItemEvent param1ItemEvent) {
            if (param1ItemEvent.getStateChange() == 1) {
              this.this$0.selectedOption = 'F';
              this.this$0.update();
            } 
          }
        });
    add(new JLabel("Choose option F"), new GridBagConstraints(1, 2, 1, 1, 0.0D, 0.0D, 17, 1, new Insets(0, 0, 0, 0), 0, 0));
  }
  
  public void update() {
    setNextButtonEnabled((this.selectedOption == 'A' || this.selectedOption == 'B'));
    setFinishButtonEnabled((this.selectedOption == 'F'));
    setBackButtonEnabled(false);
  }
  
  public void next() {
    if (this.selectedOption == 'A') {
      switchPanel(2);
    } else if (this.selectedOption == 'B') {
      switchPanel(3);
    } 
  }
  
  public void back() {}
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/JWizardComponent.jar!/jwizardcomponent/example/ChooserWizardPanel.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */