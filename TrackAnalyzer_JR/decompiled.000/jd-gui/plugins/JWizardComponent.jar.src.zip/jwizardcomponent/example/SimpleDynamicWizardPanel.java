package jwizardcomponent.example;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.ItemSelectable;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.SwingUtilities;
import jwizardcomponent.JWizardComponents;
import jwizardcomponent.JWizardPanel;

public class SimpleDynamicWizardPanel extends JWizardPanel {
  JCheckBox screen3CheckBox = new JCheckBox();
  
  JCheckBox screen4CheckBox = new JCheckBox();
  
  JCheckBox screen5CheckBox = new JCheckBox();
  
  JWizardPanel screen3Panel;
  
  JWizardPanel screen4Panel;
  
  JWizardPanel screen5Panel;
  
  public SimpleDynamicWizardPanel(JWizardComponents paramJWizardComponents) {
    super(paramJWizardComponents);
    ItemListener itemListener = new ItemListener(this) {
        private final SimpleDynamicWizardPanel this$0;
        
        public void itemStateChanged(ItemEvent param1ItemEvent) {
          ItemSelectable itemSelectable = param1ItemEvent.getItemSelectable();
          if (param1ItemEvent.getStateChange() == 2) {
            if (itemSelectable.equals(this.this$0.screen3CheckBox) && this.this$0.getWizardComponents().getWizardPanelList().contains(this.this$0.screen3Panel)) {
              this.this$0.getWizardComponents().removeWizardPanel(this.this$0.screen3Panel);
            } else if (itemSelectable.equals(this.this$0.screen4CheckBox) && this.this$0.getWizardComponents().getWizardPanelList().contains(this.this$0.screen4Panel)) {
              this.this$0.getWizardComponents().removeWizardPanel(this.this$0.screen4Panel);
            } else if (itemSelectable.equals(this.this$0.screen5CheckBox) && this.this$0.getWizardComponents().getWizardPanelList().contains(this.this$0.screen5Panel)) {
              this.this$0.getWizardComponents().removeWizardPanel(this.this$0.screen5Panel);
            } 
          } else if (itemSelectable.equals(this.this$0.screen3CheckBox) && !this.this$0.getWizardComponents().getWizardPanelList().contains(this.this$0.screen3Panel)) {
            this.this$0.screen3Panel = new SimpleLabelWizardPanel(this.this$0.getWizardComponents(), new JLabel("Screen 3"));
            this.this$0.getWizardComponents().addWizardPanelAfterCurrent(this.this$0.screen3Panel);
          } else if (itemSelectable.equals(this.this$0.screen4CheckBox) && !this.this$0.getWizardComponents().getWizardPanelList().contains(this.this$0.screen4Panel)) {
            int i;
            if (this.this$0.getWizardComponents().getWizardPanelList().contains(this.this$0.screen3Panel)) {
              i = this.this$0.getWizardComponents().getWizardPanelList().indexOf(this.this$0.screen3Panel) + 1;
            } else {
              i = this.this$0.getWizardComponents().getCurrentIndex() + 1;
            } 
            this.this$0.screen4Panel = new SimpleLabelWizardPanel(this.this$0.getWizardComponents(), new JLabel("Screen 4"));
            this.this$0.getWizardComponents().addWizardPanel(i, this.this$0.screen4Panel);
          } else if (itemSelectable.equals(this.this$0.screen5CheckBox) && !this.this$0.getWizardComponents().getWizardPanelList().contains(this.this$0.screen5Panel)) {
            int i;
            if (this.this$0.getWizardComponents().getWizardPanelList().contains(this.this$0.screen4Panel)) {
              i = this.this$0.getWizardComponents().getWizardPanelList().indexOf(this.this$0.screen4Panel) + 1;
            } else if (this.this$0.getWizardComponents().getWizardPanelList().contains(this.this$0.screen3Panel)) {
              i = this.this$0.getWizardComponents().getWizardPanelList().indexOf(this.this$0.screen3Panel) + 1;
            } else {
              i = this.this$0.getWizardComponents().getCurrentIndex() + 1;
            } 
            this.this$0.screen5Panel = new SimpleLabelWizardPanel(this.this$0.getWizardComponents(), new JLabel("Screen 5"));
            this.this$0.getWizardComponents().addWizardPanel(i, this.this$0.screen5Panel);
          } 
        }
      };
    setLayout(new GridBagLayout());
    add(this.screen3CheckBox, new GridBagConstraints(0, 0, 1, 1, 0.0D, 0.0D, 17, 1, new Insets(0, 0, 0, 0), 0, 0));
    this.screen3CheckBox.addItemListener(itemListener);
    add(new JLabel("Show Screen 3"), new GridBagConstraints(1, 0, 1, 1, 0.0D, 0.0D, 17, 1, new Insets(0, 0, 0, 0), 0, 0));
    add(this.screen4CheckBox, new GridBagConstraints(0, 1, 1, 1, 0.0D, 0.0D, 17, 1, new Insets(0, 0, 0, 0), 0, 0));
    this.screen4CheckBox.addItemListener(itemListener);
    add(new JLabel("Show Screen 4"), new GridBagConstraints(1, 1, 1, 1, 0.0D, 0.0D, 17, 1, new Insets(0, 0, 0, 0), 0, 0));
    add(this.screen5CheckBox, new GridBagConstraints(0, 2, 1, 1, 0.0D, 0.0D, 17, 1, new Insets(0, 0, 0, 0), 0, 0));
    this.screen5CheckBox.addItemListener(itemListener);
    add(new JLabel("Show Screen 5"), new GridBagConstraints(1, 2, 1, 1, 0.0D, 0.0D, 17, 1, new Insets(0, 0, 0, 0), 0, 0));
  }
  
  public void next() {
    super.next();
    if (getWizardComponents().onLastPanel()) {
      getWizardComponents().getNextButton().setVisible(false);
      SwingUtilities.invokeLater(new Runnable(this) {
            private final SimpleDynamicWizardPanel this$0;
            
            public void run() {
              this.this$0.getWizardComponents().getFinishButton().setVisible(true);
              this.this$0.getWizardComponents().getFinishButton().requestFocus();
            }
          });
    } else {
      getWizardComponents().getNextButton().setVisible(true);
      getWizardComponents().getFinishButton().setVisible(false);
    } 
  }
  
  public void back() {
    super.back();
    if (getWizardComponents().onLastPanel()) {
      getWizardComponents().getNextButton().setVisible(false);
      getWizardComponents().getFinishButton().setVisible(true);
    } else {
      getWizardComponents().getNextButton().setVisible(true);
      getWizardComponents().getFinishButton().setVisible(false);
    } 
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/JWizardComponent.jar!/jwizardcomponent/example/SimpleDynamicWizardPanel.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */