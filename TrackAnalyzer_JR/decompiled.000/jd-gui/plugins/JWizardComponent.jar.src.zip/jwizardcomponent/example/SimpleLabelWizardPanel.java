package jwizardcomponent.example;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import javax.swing.JLabel;
import javax.swing.SwingUtilities;
import jwizardcomponent.JWizardComponents;
import jwizardcomponent.JWizardPanel;

public class SimpleLabelWizardPanel extends JWizardPanel {
  public SimpleLabelWizardPanel(JWizardComponents paramJWizardComponents, JLabel paramJLabel) {
    super(paramJWizardComponents);
    setLayout(new GridBagLayout());
    add(paramJLabel, new GridBagConstraints(0, 0, 1, 1, 0.0D, 0.0D, 10, 1, new Insets(0, 0, 0, 0), 0, 0));
    if (!getWizardComponents().onLastPanel())
      getWizardComponents().getFinishButton().setVisible(false); 
  }
  
  public void next() {
    super.next();
    if (getWizardComponents().onLastPanel()) {
      getWizardComponents().getNextButton().setVisible(false);
      SwingUtilities.invokeLater(new Runnable(this) {
            private final SimpleLabelWizardPanel this$0;
            
            public void run() {
              this.this$0.getWizardComponents().getFinishButton().setVisible(true);
              this.this$0.getWizardComponents().getFinishButton().requestFocus();
            }
          });
    } else {
      getWizardComponents().getNextButton().setVisible(true);
      getWizardComponents().getFinishButton().setVisible(false);
    } 
  }
  
  public void back() {
    super.back();
    if (getWizardComponents().onLastPanel()) {
      getWizardComponents().getNextButton().setVisible(false);
      getWizardComponents().getFinishButton().setVisible(true);
    } else {
      getWizardComponents().getNextButton().setVisible(true);
      getWizardComponents().getFinishButton().setVisible(false);
    } 
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/JWizardComponent.jar!/jwizardcomponent/example/SimpleLabelWizardPanel.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */