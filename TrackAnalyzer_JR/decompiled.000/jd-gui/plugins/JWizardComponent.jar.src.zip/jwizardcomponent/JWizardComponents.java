package jwizardcomponent;

import java.beans.PropertyChangeListener;
import java.util.List;
import javax.swing.JButton;
import javax.swing.JPanel;

public interface JWizardComponents extends JWizard {
  public static final String CURRENT_PANEL_PROPERTY = "currentPanel";
  
  void addWizardPanel(JWizardPanel paramJWizardPanel);
  
  void addWizardPanel(int paramInt, JWizardPanel paramJWizardPanel);
  
  void addWizardPanelAfter(JWizardPanel paramJWizardPanel1, JWizardPanel paramJWizardPanel2);
  
  void addWizardPanelBefore(JWizardPanel paramJWizardPanel1, JWizardPanel paramJWizardPanel2);
  
  void addWizardPanelAfterCurrent(JWizardPanel paramJWizardPanel);
  
  JWizardPanel removeWizardPanel(JWizardPanel paramJWizardPanel);
  
  JWizardPanel removeWizardPanel(int paramInt);
  
  JWizardPanel removeWizardPanelAfter(JWizardPanel paramJWizardPanel);
  
  JWizardPanel removeWizardPanelBefore(JWizardPanel paramJWizardPanel);
  
  JWizardPanel getWizardPanel(int paramInt);
  
  int getIndexOfPanel(JWizardPanel paramJWizardPanel);
  
  void updateComponents();
  
  JWizardPanel getCurrentPanel() throws Exception;
  
  FinishAction getFinishAction();
  
  void setFinishAction(FinishAction paramFinishAction);
  
  CancelAction getCancelAction();
  
  void setCancelAction(CancelAction paramCancelAction);
  
  int getCurrentIndex();
  
  void setCurrentIndex(int paramInt);
  
  JPanel getWizardPanelsContainer();
  
  void setWizardPanelsContainer(JPanel paramJPanel);
  
  JButton getBackButton();
  
  void setBackButton(JButton paramJButton);
  
  JButton getNextButton();
  
  void setNextButton(JButton paramJButton);
  
  JButton getCancelButton();
  
  void setCancelButton(JButton paramJButton);
  
  JButton getFinishButton();
  
  void setFinishButton(JButton paramJButton);
  
  List getWizardPanelList();
  
  void setWizardPanelList(List paramList);
  
  boolean onLastPanel();
  
  void addPropertyChangeListener(PropertyChangeListener paramPropertyChangeListener);
  
  void removePropertyChangeListener(PropertyChangeListener paramPropertyChangeListener);
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/JWizardComponent.jar!/jwizardcomponent/JWizardComponents.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */