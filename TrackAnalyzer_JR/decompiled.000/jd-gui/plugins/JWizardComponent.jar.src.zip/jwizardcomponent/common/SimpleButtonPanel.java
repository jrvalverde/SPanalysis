package jwizardcomponent.common;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import javax.swing.JLabel;
import javax.swing.JPanel;
import jwizardcomponent.JWizardComponents;

public class SimpleButtonPanel extends JPanel {
  JLabel statusLabel = new JLabel();
  
  public SimpleButtonPanel(JWizardComponents paramJWizardComponents) {
    setLayout(new GridBagLayout());
    add(this.statusLabel, new GridBagConstraints(0, 0, 1, 1, 0.7D, 0.0D, 17, 1, new Insets(2, 0, 2, 0), 0, 0));
    add(paramJWizardComponents.getBackButton(), new GridBagConstraints(1, 0, 1, 1, 0.1D, 0.0D, 13, 1, new Insets(2, 0, 2, 0), 0, 0));
    add(paramJWizardComponents.getNextButton(), new GridBagConstraints(2, 0, 1, 1, 0.1D, 0.0D, 13, 1, new Insets(2, 0, 2, 0), 0, 0));
    add(paramJWizardComponents.getFinishButton(), new GridBagConstraints(3, 0, 1, 1, 0.1D, 0.0D, 13, 1, new Insets(2, 0, 2, 0), 0, 0));
    add(paramJWizardComponents.getCancelButton(), new GridBagConstraints(4, 0, 1, 1, 0.1D, 0.0D, 13, 1, new Insets(2, 3, 2, 2), 0, 0));
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/JWizardComponent.jar!/jwizardcomponent/common/SimpleButtonPanel.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */