package jwizardcomponent;

import java.awt.Component;
import java.awt.Dimension;
import java.awt.Point;
import java.awt.Toolkit;

public class Utilities {
  public static void centerComponentOnScreen(Component paramComponent) {
    Toolkit toolkit = Toolkit.getDefaultToolkit();
    Dimension dimension = toolkit.getScreenSize();
    Point point = new Point();
    point.x += (dimension.width - paramComponent.getWidth()) / 2;
    point.y += (dimension.height - paramComponent.getHeight()) / 2;
    if (point.x < 0)
      point.x = 0; 
    if (point.y < 0)
      point.y = 0; 
    paramComponent.setLocation(point);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/JWizardComponent.jar!/jwizardcomponent/Utilities.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */