package jwizardcomponent.frame;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSeparator;
import jwizardcomponent.CancelAction;
import jwizardcomponent.DefaultJWizardComponents;
import jwizardcomponent.FinishAction;
import jwizardcomponent.JWizardComponents;
import jwizardcomponent.common.SimpleButtonPanel;

public class SimpleJWizardFrame extends JFrame {
  DefaultJWizardComponents wizardComponents = new DefaultJWizardComponents();
  
  JPanel buttonPanel;
  
  JLabel statusLabel = new JLabel();
  
  JPanel bottomPanel = new JPanel();
  
  public SimpleJWizardFrame() {
    init();
  }
  
  private void init() {
    getContentPane().setLayout(new GridBagLayout());
    getContentPane().add(this.wizardComponents.getWizardPanelsContainer(), new GridBagConstraints(0, 0, 1, 1, 1.0D, 0.9D, 10, 1, new Insets(0, 0, 0, 0), 0, 0));
    getContentPane().add(new JSeparator(), new GridBagConstraints(0, 1, 1, 0, 1.0D, 0.01D, 17, 1, new Insets(1, 1, 1, 1), 0, 0));
    this.buttonPanel = (JPanel)new SimpleButtonPanel((JWizardComponents)this.wizardComponents);
    getContentPane().add(this.buttonPanel, new GridBagConstraints(0, 2, 1, 1, 1.0D, 0.09D, 17, 1, new Insets(0, 0, 0, 0), 0, 0));
    this.wizardComponents.setFinishAction(new FinishAction(this, (JWizardComponents)this.wizardComponents) {
          private final SimpleJWizardFrame this$0;
          
          public void performAction() {
            this.this$0.dispose();
          }
        });
    this.wizardComponents.setCancelAction(new CancelAction(this, (JWizardComponents)this.wizardComponents) {
          private final SimpleJWizardFrame this$0;
          
          public void performAction() {
            this.this$0.dispose();
          }
        });
  }
  
  public DefaultJWizardComponents getWizardComponents() {
    return this.wizardComponents;
  }
  
  public void setWizardComponents(DefaultJWizardComponents paramDefaultJWizardComponents) {
    this.wizardComponents = paramDefaultJWizardComponents;
  }
  
  public void show() {
    this.wizardComponents.updateComponents();
    super.show();
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/JWizardComponent.jar!/jwizardcomponent/frame/SimpleJWizardFrame.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */