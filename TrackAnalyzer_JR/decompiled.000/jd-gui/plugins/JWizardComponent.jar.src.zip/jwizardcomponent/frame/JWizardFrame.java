package jwizardcomponent.frame;

import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSeparator;
import jwizardcomponent.CancelAction;
import jwizardcomponent.DefaultJWizardComponents;
import jwizardcomponent.FinishAction;
import jwizardcomponent.JWizardComponents;
import jwizardcomponent.JWizardPanel;

public class JWizardFrame extends JFrame {
  private JWizardComponents wizardComponents;
  
  private JPanel buttonPanel;
  
  private JLabel panelTitleLabel;
  
  public JWizardFrame() {
    init();
  }
  
  private void init() {
    this.wizardComponents = (JWizardComponents)new DefaultJWizardComponents();
    this.wizardComponents.addPropertyChangeListener(new PropertyChangeListener(this) {
          private final JWizardFrame this$0;
          
          public void propertyChange(PropertyChangeEvent param1PropertyChangeEvent) {
            this.this$0.setPanelTitle(((JWizardPanel)param1PropertyChangeEvent.getNewValue()).getPanelTitle());
          }
        });
    getContentPane().setLayout(new GridBagLayout());
    getContentPane().add(createTitlePanel(), new GridBagConstraints(0, 0, 1, 1, 1.0D, 0.0D, 10, 1, new Insets(5, 5, 5, 5), 0, 0));
    getContentPane().add(new JSeparator(), new GridBagConstraints(0, 1, 1, 1, 1.0D, 0.0D, 17, 1, new Insets(1, 1, 1, 1), 0, 0));
    getContentPane().add(this.wizardComponents.getWizardPanelsContainer(), new GridBagConstraints(0, 2, 1, 1, 1.0D, 1.0D, 10, 1, new Insets(0, 0, 0, 0), 0, 0));
    getContentPane().add(new JSeparator(), new GridBagConstraints(0, 3, 1, 1, 1.0D, 0.0D, 17, 1, new Insets(1, 1, 1, 1), 0, 0));
    getContentPane().add(createButtonPanel(), new GridBagConstraints(0, 4, 1, 1, 1.0D, 0.0D, 13, 0, new Insets(5, 5, 5, 5), 0, 0));
    this.wizardComponents.setFinishAction(createFinishAction());
    this.wizardComponents.setCancelAction(createCancelAction());
    handleWindowClosing();
  }
  
  public JWizardComponents getWizardComponents() {
    return this.wizardComponents;
  }
  
  public void setWizardComponents(JWizardComponents paramJWizardComponents) {
    this.wizardComponents = paramJWizardComponents;
  }
  
  public void show() {
    this.wizardComponents.updateComponents();
    super.show();
  }
  
  protected void setPanelTitle(String paramString) {
    this.panelTitleLabel.setText(paramString);
  }
  
  protected JPanel createTitlePanel() {
    JPanel jPanel = new JPanel(new FlowLayout(0));
    this.panelTitleLabel = new JLabel();
    this.panelTitleLabel.setHorizontalAlignment(10);
    jPanel.add(this.panelTitleLabel);
    return jPanel;
  }
  
  protected JPanel createButtonPanel() {
    JPanel jPanel = new JPanel(new GridLayout());
    jPanel.add(this.wizardComponents.getBackButton());
    jPanel.add(this.wizardComponents.getNextButton());
    jPanel.add(this.wizardComponents.getFinishButton());
    jPanel.add(this.wizardComponents.getCancelButton());
    return jPanel;
  }
  
  protected FinishAction createFinishAction() {
    return new FinishAction(this, this.wizardComponents) {
        private final JWizardFrame this$0;
        
        public void performAction() {
          System.out.println("FinishAction performed");
          this.this$0.dispose();
        }
      };
  }
  
  protected CancelAction createCancelAction() {
    return new CancelAction(this, this.wizardComponents) {
        private final JWizardFrame this$0;
        
        public void performAction() {
          System.out.println("CancelAction performed");
          this.this$0.dispose();
        }
      };
  }
  
  protected void handleWindowClosing() {
    setDefaultCloseOperation(0);
    addWindowListener(new WindowAdapter(this) {
          private final JWizardFrame this$0;
          
          public void windowClosing(WindowEvent param1WindowEvent) {
            this.this$0.wizardComponents.getCancelAction().performAction();
          }
        });
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/JWizardComponent.jar!/jwizardcomponent/frame/JWizardFrame.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */