package org.jacorb.ssl;

/**
 * Generated from IDL interface "SSLPolicy".
 *
 * @author JacORB IDL compiler V 3.9
 * @version generated at 31-Aug-2017 12:20:32
 */

public interface SSLPolicy
	extends SSLPolicyOperations, org.omg.CORBA.LocalInterface, org.omg.CORBA.portable.IDLEntity, org.omg.CORBA.Policy
{
}
