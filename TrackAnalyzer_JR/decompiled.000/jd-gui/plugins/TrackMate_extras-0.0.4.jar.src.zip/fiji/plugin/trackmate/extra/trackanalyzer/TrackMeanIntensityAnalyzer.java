/*     */ package fiji.plugin.trackmate.extra.trackanalyzer;
/*     */ 
/*     */ import fiji.plugin.trackmate.Dimension;
/*     */ import fiji.plugin.trackmate.FeatureModel;
/*     */ import fiji.plugin.trackmate.Model;
/*     */ import fiji.plugin.trackmate.Spot;
/*     */ import fiji.plugin.trackmate.TrackMatePlugIn_;
/*     */ import fiji.plugin.trackmate.extra.spotanalyzer.SpotMultiChannelIntensityAnalyzerFactory;
/*     */ import fiji.plugin.trackmate.features.track.TrackAnalyzer;
/*     */ import ij.ImageJ;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ArrayBlockingQueue;
/*     */ import javax.swing.ImageIcon;
/*     */ import net.imglib2.algorithm.Benchmark;
/*     */ import net.imglib2.multithreading.SimpleMultiThreading;
/*     */ import org.scijava.plugin.Plugin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Plugin(type = TrackAnalyzer.class)
/*     */ public class TrackMeanIntensityAnalyzer
/*     */   implements TrackAnalyzer, Benchmark
/*     */ {
/*     */   public static final String KEY = "TRACK_MEAN_INTENSITY";
/*  38 */   public static final ArrayList<String> FEATURES = new ArrayList<>(10);
/*     */   
/*  40 */   public static final HashMap<String, String> FEATURE_NAMES = new HashMap<>(10);
/*     */   
/*  42 */   public static final HashMap<String, String> FEATURE_SHORT_NAMES = new HashMap<>(10);
/*     */   
/*  44 */   public static final HashMap<String, Dimension> FEATURE_DIMENSIONS = new HashMap<>(10);
/*     */   
/*  46 */   public static final Map<String, Boolean> IS_INT = new HashMap<>(10);
/*     */   
/*     */   static {
/*  49 */     for (int i = 0; i < 10; i++) {
/*     */       
/*  51 */       FEATURES.add("MEAN_TRACK_INTENSITY" + String.format("%02d", new Object[] { Integer.valueOf(i + 1) }));
/*  52 */       FEATURE_NAMES.put(FEATURES.get(i), "Mean track intensity channel " + String.format("%02d", new Object[] { Integer.valueOf(i + 1) }));
/*  53 */       FEATURE_SHORT_NAMES.put(FEATURES.get(i), "Mean track Ch" + String.format("%02d", new Object[] { Integer.valueOf(i + 1) }));
/*  54 */       FEATURE_DIMENSIONS.put(FEATURES.get(i), Dimension.INTENSITY);
/*  55 */       IS_INT.put(FEATURES.get(i), Boolean.FALSE);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private int numThreads;
/*     */   
/*     */   private long processingTime;
/*     */   
/*     */   public TrackMeanIntensityAnalyzer() {
/*  65 */     setNumThreads();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isLocal() {
/*  75 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void process(Collection<Integer> trackIDs, final Model model) {
/*  81 */     if (trackIDs.isEmpty())
/*  82 */       return;  final FeatureModel fm = model.getFeatureModel();
/*     */     
/*  84 */     final ArrayBlockingQueue<Integer> queue = new ArrayBlockingQueue<>(trackIDs.size(), false, trackIDs);
/*     */     
/*  86 */     Thread[] threads = SimpleMultiThreading.newThreads(this.numThreads);
/*  87 */     for (int i = 0; i < threads.length; i++) {
/*     */       
/*  89 */       threads[i] = new Thread("TrackMeanIntensityAnalyzer thread " + i)
/*     */         {
/*     */           public void run()
/*     */           {
/*     */             Integer trackID;
/*     */             
/*  95 */             while ((trackID = queue.poll()) != null) {
/*     */               
/*  97 */               Set<Spot> track = model.getTrackModel().trackSpots(trackID);
/*     */               
/*  99 */               for (int c = 0; c < 10; c++) {
/*     */                 
/* 101 */                 String intensityFeature = SpotMultiChannelIntensityAnalyzerFactory.FEATURES.get(c);
/* 102 */                 double sum = 0.0D;
/* 103 */                 int n = 0;
/* 104 */                 for (Spot spot : track) {
/*     */                   
/* 106 */                   Double feature = spot.getFeature(intensityFeature);
/* 107 */                   if (null == feature) {
/*     */                     continue;
/*     */                   }
/* 110 */                   double val = feature.doubleValue();
/* 111 */                   n++;
/* 112 */                   sum += val;
/*     */                 } 
/* 114 */                 double mean = sum / n;
/* 115 */                 if (n != 0) {
/* 116 */                   fm.putTrackFeature(trackID, TrackMeanIntensityAnalyzer.FEATURES.get(c), Double.valueOf(mean));
/*     */                 } else {
/* 118 */                   fm.putTrackFeature(trackID, TrackMeanIntensityAnalyzer.FEATURES.get(c), null);
/*     */                 } 
/*     */               } 
/*     */             } 
/*     */           }
/*     */         };
/*     */     } 
/* 125 */     long start = System.currentTimeMillis();
/* 126 */     SimpleMultiThreading.startAndJoin(threads);
/* 127 */     long end = System.currentTimeMillis();
/* 128 */     this.processingTime = end - start;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getNumThreads() {
/* 134 */     return this.numThreads;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setNumThreads() {
/* 140 */     this.numThreads = Runtime.getRuntime().availableProcessors();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setNumThreads(int numThreads) {
/* 146 */     this.numThreads = numThreads;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getProcessingTime() {
/* 153 */     return this.processingTime;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getKey() {
/* 159 */     return "TRACK_MEAN_INTENSITY";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public List<String> getFeatures() {
/* 165 */     return FEATURES;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, String> getFeatureShortNames() {
/* 171 */     return FEATURE_SHORT_NAMES;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, String> getFeatureNames() {
/* 177 */     return FEATURE_NAMES;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, Dimension> getFeatureDimensions() {
/* 183 */     return FEATURE_DIMENSIONS;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getInfoText() {
/* 189 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ImageIcon getIcon() {
/* 195 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/* 201 */     return "TRACK_MEAN_INTENSITY";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, Boolean> getIsIntFeature() {
/* 207 */     return IS_INT;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isManualFeature() {
/* 213 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public static void main(String[] args) {
/* 218 */     ImageJ.main(args);
/* 219 */     String imageFile = "/Users/tinevez/Desktop/DUP_TIM1 GFP clat dsred TIRF-5.tif";
/*     */ 
/*     */     
/* 222 */     TrackMatePlugIn_ pg = new TrackMatePlugIn_();
/* 223 */     pg.run("/Users/tinevez/Desktop/DUP_TIM1 GFP clat dsred TIRF-5.tif");
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate_extras-0.0.4.jar!/fiji/plugin/trackmate/extra/trackanalyzer/TrackMeanIntensityAnalyzer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */