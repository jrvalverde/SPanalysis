/*     */ package fiji.plugin.trackmate.extra.spotanalyzer;
/*     */ 
/*     */ import fiji.plugin.trackmate.Dimension;
/*     */ import fiji.plugin.trackmate.Model;
/*     */ import fiji.plugin.trackmate.features.spot.SpotAnalyzer;
/*     */ import fiji.plugin.trackmate.features.spot.SpotAnalyzerFactory;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.swing.ImageIcon;
/*     */ import net.imagej.ImgPlus;
/*     */ import net.imagej.axis.Axes;
/*     */ import net.imglib2.meta.view.HyperSliceImgPlus;
/*     */ import net.imglib2.type.NativeType;
/*     */ import net.imglib2.type.numeric.RealType;
/*     */ import org.scijava.plugin.Plugin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Plugin(type = SpotAnalyzerFactory.class, priority = 0.0D)
/*     */ public class SpotMultiChannelIntensityAnalyzerFactory<T extends RealType<T> & NativeType<T>>
/*     */   implements SpotAnalyzerFactory<T>
/*     */ {
/*     */   public static final String KEY = "Spot intensity per channel";
/*     */   public static final int nlocal_feat = 10;
/*  34 */   public static final ArrayList<String> FEATURES = new ArrayList<>(10);
/*     */   
/*  36 */   public static final HashMap<String, String> FEATURE_NAMES = new HashMap<>(10);
/*     */   
/*  38 */   public static final HashMap<String, String> FEATURE_SHORT_NAMES = new HashMap<>(10);
/*     */   
/*  40 */   public static final HashMap<String, Dimension> FEATURE_DIMENSIONS = new HashMap<>(10);
/*     */   
/*  42 */   public static final Map<String, Boolean> IS_INT = new HashMap<>(10);
/*     */   
/*     */   static {
/*  45 */     for (int i = 0; i < 10; i++) {
/*     */       
/*  47 */       FEATURES.add("MEAN_INTENSITY" + String.format("%02d", new Object[] { Integer.valueOf(i + 1) }));
/*  48 */       FEATURE_NAMES.put(FEATURES.get(i), "Mean intensity channel " + String.format("%02d", new Object[] { Integer.valueOf(i + 1) }));
/*  49 */       FEATURE_SHORT_NAMES.put(FEATURES.get(i), "Mean Ch" + String.format("%02d", new Object[] { Integer.valueOf(i + 1) }));
/*  50 */       FEATURE_DIMENSIONS.put(FEATURES.get(i), Dimension.INTENSITY);
/*  51 */       IS_INT.put(FEATURES.get(i), Boolean.FALSE);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SpotMultiChannelIntensityAnalyzer<T> getAnalyzer(Model model, ImgPlus<T> img, int frame, int channel) {
/*  64 */     ImgPlus<T> imgT = HyperSliceImgPlus.fixTimeAxis(img, frame);
/*     */ 
/*     */     
/*  67 */     long[] dimensions = new long[img.numDimensions()];
/*  68 */     img.dimensions(dimensions);
/*  69 */     int ch_dim = img.dimensionIndex(Axes.CHANNEL);
/*  70 */     int nCh = 1;
/*  71 */     if (ch_dim >= 0) {
/*  72 */       nCh = (int)dimensions[ch_dim];
/*     */     }
/*  74 */     return (SpotMultiChannelIntensityAnalyzer)new SpotMultiChannelIntensityAnalyzer<>(imgT, model, frame, nCh);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getKey() {
/*  80 */     return "Spot intensity per channel";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public List<String> getFeatures() {
/*  86 */     return FEATURES;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, String> getFeatureShortNames() {
/*  92 */     return FEATURE_SHORT_NAMES;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, String> getFeatureNames() {
/*  98 */     return FEATURE_NAMES;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, Dimension> getFeatureDimensions() {
/* 104 */     return FEATURE_DIMENSIONS;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getInfoText() {
/* 110 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ImageIcon getIcon() {
/* 116 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/* 122 */     return "Spot intensity per channel";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, Boolean> getIsIntFeature() {
/* 128 */     return IS_INT;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isManualFeature() {
/* 134 */     return false;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate_extras-0.0.4.jar!/fiji/plugin/trackmate/extra/spotanalyzer/SpotMultiChannelIntensityAnalyzerFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */