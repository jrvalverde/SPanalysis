/*     */ package fiji.plugin.trackmate.extra.action;
/*     */ 
/*     */ import fiji.plugin.trackmate.LoadTrackMatePlugIn_;
/*     */ import fiji.plugin.trackmate.Spot;
/*     */ import fiji.plugin.trackmate.TrackMate;
/*     */ import fiji.plugin.trackmate.action.AbstractTMAction;
/*     */ import fiji.plugin.trackmate.action.TrackMateAction;
/*     */ import fiji.plugin.trackmate.action.TrackMateActionFactory;
/*     */ import fiji.plugin.trackmate.gui.TrackMateGUIController;
/*     */ import fiji.plugin.trackmate.visualization.TrackMateModelView;
/*     */ import fiji.plugin.trackmate.visualization.hyperstack.HyperStackDisplayer;
/*     */ import ij.ImageJ;
/*     */ import ij.ImagePlus;
/*     */ import ij.gui.PointRoi;
/*     */ import ij.gui.Roi;
/*     */ import ij.plugin.frame.RoiManager;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.NavigableSet;
/*     */ import javax.swing.ImageIcon;
/*     */ import org.scijava.plugin.Plugin;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RoiExporter
/*     */   extends AbstractTMAction
/*     */ {
/*  28 */   public static final ImageIcon ICON = new ImageIcon(RoiExporter.class.getResource("MultiPointRoiIcon.png"));
/*     */ 
/*     */   
/*     */   public static final String NAME = "Export current spots to IJ rois";
/*     */ 
/*     */   
/*     */   public static final String KEY = "EXPORT_TO_IJ_ROIS";
/*     */ 
/*     */   
/*     */   public static final String INFO_TEXT = "<html>Generates an IJ multi-point ROI from the visible spots and add them all to the ROI manager. There is one multi-point ROI created by frame. </html>";
/*     */ 
/*     */   
/*     */   private final ImagePlus imp;
/*     */ 
/*     */   
/*     */   public RoiExporter(ImagePlus imp) {
/*  44 */     this.imp = imp;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void execute(TrackMate trackmate) {
/*  50 */     if (this.imp == null) {
/*     */       
/*  52 */       this.logger.error("Could not find a suitable target image in this TrackMate session.\n");
/*     */       
/*     */       return;
/*     */     } 
/*  56 */     double dx = (this.imp.getCalibration()).pixelWidth;
/*  57 */     double dy = (this.imp.getCalibration()).pixelHeight;
/*     */     
/*  59 */     RoiManager roiManager = RoiManager.getInstance();
/*  60 */     if (null == roiManager)
/*     */     {
/*  62 */       roiManager = new RoiManager();
/*     */     }
/*  64 */     roiManager.reset();
/*     */     
/*  66 */     NavigableSet<Integer> frames = trackmate.getModel().getSpots().keySet();
/*  67 */     for (Iterator<Integer> iterator = frames.iterator(); iterator.hasNext(); ) { int frame = ((Integer)iterator.next()).intValue();
/*     */       
/*  69 */       int points = trackmate.getModel().getSpots().getNSpots(frame, true);
/*  70 */       float[] ox = new float[points];
/*  71 */       float[] oy = new float[points];
/*  72 */       Iterable<Spot> iterable = trackmate.getModel().getSpots().iterable(frame, true);
/*  73 */       int index = 0;
/*  74 */       for (Spot spot : iterable) {
/*     */         
/*  76 */         double x = spot.getDoublePosition(0) / dx;
/*  77 */         double y = spot.getDoublePosition(1) / dy;
/*     */         
/*  79 */         ox[index] = (float)x;
/*  80 */         oy[index] = (float)y;
/*     */         
/*  82 */         index++;
/*     */       } 
/*     */       
/*  85 */       PointRoi roi = new PointRoi(ox, oy, points);
/*  86 */       roiManager.addRoi((Roi)roi); }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Plugin(type = TrackMateActionFactory.class)
/*     */   public static class Factory
/*     */     implements TrackMateActionFactory
/*     */   {
/*     */     public String getInfoText() {
/*  97 */       return "<html>Generates an IJ multi-point ROI from the visible spots and add them all to the ROI manager. There is one multi-point ROI created by frame. </html>";
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public ImageIcon getIcon() {
/* 103 */       return RoiExporter.ICON;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public String getKey() {
/* 109 */       return "EXPORT_TO_IJ_ROIS";
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public String getName() {
/* 115 */       return "Export current spots to IJ rois";
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public TrackMateAction create(TrackMateGUIController controller) {
/* 121 */       Collection<TrackMateModelView> views = controller.getGuimodel().getViews();
/* 122 */       ImagePlus imp = null;
/* 123 */       for (TrackMateModelView view : views) {
/*     */         
/* 125 */         if (view.getKey().equals("HYPERSTACKDISPLAYER")) {
/*     */           
/* 127 */           HyperStackDisplayer hsd = (HyperStackDisplayer)view;
/* 128 */           imp = hsd.getImp();
/*     */           
/*     */           break;
/*     */         } 
/*     */       } 
/* 133 */       return (TrackMateAction)new RoiExporter(imp);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void main(String[] args) {
/* 140 */     ImageJ.main(args);
/* 141 */     LoadTrackMatePlugIn_ plugIn = new LoadTrackMatePlugIn_();
/* 142 */     plugIn.run("samples/FakeTracks.xml");
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate_extras-0.0.4.jar!/fiji/plugin/trackmate/extra/action/RoiExporter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */