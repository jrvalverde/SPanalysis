/*    */ package fiji.plugin.trackmate.extra.spotanalyzer;
/*    */ 
/*    */ import fiji.plugin.trackmate.Model;
/*    */ import fiji.plugin.trackmate.Spot;
/*    */ import fiji.plugin.trackmate.features.spot.SpotAnalyzer;
/*    */ import fiji.plugin.trackmate.util.SpotNeighborhood;
/*    */ import fiji.plugin.trackmate.util.SpotNeighborhoodCursor;
/*    */ import java.util.Iterator;
/*    */ import net.imagej.ImgPlus;
/*    */ import net.imglib2.meta.view.HyperSliceImgPlus;
/*    */ import net.imglib2.type.numeric.RealType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SpotMultiChannelIntensityAnalyzer<T extends RealType<T>>
/*    */   implements SpotAnalyzer<T>
/*    */ {
/*    */   private final ImgPlus<T> img;
/*    */   private final Model model;
/*    */   private final int frame;
/*    */   private String errorMessage;
/*    */   private long processingTime;
/*    */   private final int NumChannel;
/*    */   
/*    */   public SpotMultiChannelIntensityAnalyzer(ImgPlus<T> img, Model model, int frame, int NumChannel) {
/* 34 */     this.img = img;
/* 35 */     this.model = model;
/* 36 */     this.frame = frame;
/* 37 */     this.NumChannel = NumChannel;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean checkInput() {
/* 47 */     return true;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean process() {
/* 54 */     for (int ch = 0; ch < this.NumChannel; ch++) {
/*    */       
/* 56 */       ImgPlus<T> imgC = HyperSliceImgPlus.fixChannelAxis(this.img, ch);
/* 57 */       Iterator<Spot> spots = this.model.getSpots().iterator(Integer.valueOf(this.frame), false);
/*    */       
/* 59 */       while (spots.hasNext()) {
/*    */         
/* 61 */         Spot spot = spots.next();
/* 62 */         SpotNeighborhood<T> neighborhood = new SpotNeighborhood(spot, imgC);
/* 63 */         double mean = 0.0D;
/*    */         
/* 65 */         for (SpotNeighborhoodCursor<RealType> spotNeighborhoodCursor = neighborhood.iterator(); spotNeighborhoodCursor.hasNext(); ) { RealType realType = spotNeighborhoodCursor.next();
/* 66 */           mean += realType.getRealDouble(); }
/*    */         
/* 68 */         mean /= neighborhood.size();
/* 69 */         spot.putFeature(SpotMultiChannelIntensityAnalyzerFactory.FEATURES.get(ch), Double.valueOf(mean));
/*    */       } 
/*    */     } 
/*    */     
/* 73 */     return true;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String getErrorMessage() {
/* 79 */     return this.errorMessage;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public long getProcessingTime() {
/* 85 */     return this.processingTime;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/TrackMate_extras-0.0.4.jar!/fiji/plugin/trackmate/extra/spotanalyzer/SpotMultiChannelIntensityAnalyzer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */